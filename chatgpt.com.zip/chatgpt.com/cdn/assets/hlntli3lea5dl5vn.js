import {
    h as f
} from "./fg33krlcm0qyi6yw.js";
import {
    j8 as V,
    gf as b,
    fj as q
} from "./dykg4ktvbu3mhmdo.js";
var r, u;

function v() {
    if (u) return r;
    u = 1;
    var t = V(),
        n = b(),
        o = q();

    function i(p, a) {
        var e = {};
        return a = o(a, 3), n(p, function(l, s, m) {
            t(e, s, a(l, s, m))
        }), e
    }
    return r = i, r
}
var c = v();
const j = f(c);
export {
    j as m
};
//# sourceMappingURL=hlntli3lea5dl5vn.js.map