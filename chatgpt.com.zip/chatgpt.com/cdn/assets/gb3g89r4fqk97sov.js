import {
    j as e
} from "./fg33krlcm0qyi6yw.js";
import {
    bg as x
} from "./dykg4ktvbu3mhmdo.js";

function p({
    size: r = 60,
    strokeWidth: t = 2,
    arcPercentage: i = .25,
    initialOffset: o = 0,
    ariaMessage: l,
    children: s
}) {
    const a = (r - t) / 2,
        n = 2 * Math.PI * a,
        c = n * i,
        m = "".concat(c, " ").concat(n - c);
    return e.jsxs("div", {
        className: "relative flex items-center justify-center",
        role: "progressbar",
        "aria-live": "assertive",
        "aria-valuetext": l,
        children: [e.jsxs(x.svg, {
            width: r,
            height: r,
            viewBox: "0 0 ".concat(r, " ").concat(r),
            animate: {
                rotate: 360
            },
            transition: {
                repeat: 1 / 0,
                duration: 1.2,
                ease: "linear"
            },
            children: [e.jsx("circle", {
                className: "text-[var(--sidebar-surface-secondary)]",
                stroke: "currentColor",
                fill: "transparent",
                strokeWidth: t,
                cx: r / 2,
                cy: r / 2,
                r: a
            }), e.jsx("circle", {
                className: "text-[var(--main-surface-primary-inverse)]",
                stroke: "currentColor",
                fill: "transparent",
                strokeWidth: t,
                strokeDasharray: m,
                strokeDashoffset: o,
                strokeLinecap: "butt",
                cx: r / 2,
                cy: r / 2,
                r: a
            })]
        }), s && e.jsx("div", {
            className: "absolute inset-0 flex items-center justify-center",
            children: s
        })]
    })
}
export {
    p as C
};
//# sourceMappingURL=gb3g89r4fqk97sov.js.map