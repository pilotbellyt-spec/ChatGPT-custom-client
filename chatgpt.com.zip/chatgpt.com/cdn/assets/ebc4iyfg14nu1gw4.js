var Ye = Object.defineProperty,
    Je = Object.defineProperties;
var Ge = Object.getOwnPropertyDescriptors;
var H = Object.getOwnPropertySymbols;
var se = Object.prototype.hasOwnProperty,
    ue = Object.prototype.propertyIsEnumerable;
var ie = (e, n, t) => n in e ? Ye(e, n, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : e[n] = t,
    T = (e, n) => {
        for (var t in n || (n = {})) se.call(n, t) && ie(e, t, n[t]);
        if (H)
            for (var t of H(n)) ue.call(n, t) && ie(e, t, n[t]);
        return e
    },
    ce = (e, n) => Je(e, Ge(n));
var pe = (e, n) => {
    var t = {};
    for (var l in e) se.call(e, l) && n.indexOf(l) < 0 && (t[l] = e[l]);
    if (e != null && H)
        for (var l of H(e)) n.indexOf(l) < 0 && ue.call(e, l) && (t[l] = e[l]);
    return t
};
import {
    o as _,
    u as Ze
} from "./gy1lpvuoewmzh42c.js";
import {
    h as Qe,
    j as X
} from "./fg33krlcm0qyi6yw.js";
import {
    V as De,
    u as en,
    a as nn
} from "./jed1ux7qibe55pmj.js";
import {
    b as fe,
    r as tn
} from "./nfccle6oyncifphl.js";
import {
    Cm as ln,
    F6 as q,
    c5 as Oe
} from "./k15yxxoybkkir2ou.js";

function j(e) {
    const n = [];
    let t = -1,
        l = 0,
        r = 0;
    for (; ++t < e.length;) {
        const o = e.charCodeAt(t);
        let a = "";
        if (o === 37 && fe(e.charCodeAt(t + 1)) && fe(e.charCodeAt(t + 2))) r = 2;
        else if (o < 128) /[!#$&-;=?-Z_a-z~]/.test(String.fromCharCode(o)) || (a = String.fromCharCode(o));
        else if (o > 55295 && o < 57344) {
            const s = e.charCodeAt(t + 1);
            o < 56320 && s > 56319 && s < 57344 ? (a = String.fromCharCode(o, s), r = 1) : a = "�"
        } else a = String.fromCharCode(o);
        a && (n.push(e.slice(l, t), encodeURIComponent(a)), l = t + r + 1, a = ""), r && (t += r, r = 0)
    }
    return n.join("") + e.slice(l)
}

function zt(e) {
    for (var n = [], t = String(e || ""), l = t.indexOf(","), r = 0, o, a; !o;) l === -1 && (l = t.length, o = !0), a = t.slice(r, l).trim(), (a || !o) && n.push(a), r = l + 1, l = t.indexOf(",", r);
    return n
}

function rn(e, n) {
    var t = n || {};
    return e[e.length - 1] === "" && (e = e.concat("")), e.join((t.padRight ? " " : "") + "," + (t.padLeft === !1 ? "" : " ")).trim()
}
const on = new RegExp("^[$_\\p{ID_Start}][$_\\u{200C}\\u{200D}\\p{ID_Continue}]*$", "u"),
    an = new RegExp("^[$_\\p{ID_Start}][-$_\\u{200C}\\u{200D}\\p{ID_Continue}]*$", "u"),
    sn = {};

function de(e, n) {
    return (sn.jsx ? an : on).test(e)
}
const un = /[ \t\n\f\r]/g;

function cn(e) {
    return typeof e == "object" ? e.type === "text" ? he(e.value) : !1 : he(e)
}

function he(e) {
    return e.replace(un, "") === ""
}
class B {
    constructor(n, t, l) {
        this.property = n, this.normal = t, l && (this.space = l)
    }
}
B.prototype.property = {};
B.prototype.normal = {};
B.prototype.space = null;

function Le(e, n) {
    const t = {},
        l = {};
    let r = -1;
    for (; ++r < e.length;) Object.assign(t, e[r].property), Object.assign(l, e[r].normal);
    return new B(t, l, n)
}

function Y(e) {
    return e.toLowerCase()
}
class O {
    constructor(n, t) {
        this.property = n, this.attribute = t
    }
}
O.prototype.space = null;
O.prototype.boolean = !1;
O.prototype.booleanish = !1;
O.prototype.overloadedBoolean = !1;
O.prototype.number = !1;
O.prototype.commaSeparated = !1;
O.prototype.spaceSeparated = !1;
O.prototype.commaOrSpaceSeparated = !1;
O.prototype.mustUseProperty = !1;
O.prototype.defined = !1;
let pn = 0;
const f = R(),
    C = R(),
    Ne = R(),
    i = R(),
    x = R(),
    I = R(),
    P = R();

function R() {
    return 2 ** ++pn
}
const J = Object.freeze(Object.defineProperty({
        __proto__: null,
        boolean: f,
        booleanish: C,
        commaOrSpaceSeparated: P,
        commaSeparated: I,
        number: i,
        overloadedBoolean: Ne,
        spaceSeparated: x
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    K = Object.keys(J);
class Z extends O {
    constructor(n, t, l, r) {
        let o = -1;
        if (super(n, t), me(this, "space", r), typeof l == "number")
            for (; ++o < K.length;) {
                const a = K[o];
                me(this, K[o], (l & J[a]) === J[a])
            }
    }
}
Z.prototype.defined = !0;

function me(e, n, t) {
    t && (e[n] = t)
}
const fn = {}.hasOwnProperty;

function U(e) {
    const n = {},
        t = {};
    let l;
    for (l in e.properties)
        if (fn.call(e.properties, l)) {
            const r = e.properties[l],
                o = new Z(l, e.transform(e.attributes || {}, l), r, e.space);
            e.mustUseProperty && e.mustUseProperty.includes(l) && (o.mustUseProperty = !0), n[l] = o, t[Y(l)] = l, t[Y(o.attribute)] = l
        }
    return new B(n, t, e.space)
}
const Ae = U({
        space: "xlink",
        transform(e, n) {
            return "xlink:" + n.slice(5).toLowerCase()
        },
        properties: {
            xLinkActuate: null,
            xLinkArcRole: null,
            xLinkHref: null,
            xLinkRole: null,
            xLinkShow: null,
            xLinkTitle: null,
            xLinkType: null
        }
    }),
    Te = U({
        space: "xml",
        transform(e, n) {
            return "xml:" + n.slice(3).toLowerCase()
        },
        properties: {
            xmlLang: null,
            xmlBase: null,
            xmlSpace: null
        }
    });

function Re(e, n) {
    return n in e ? e[n] : n
}

function Me(e, n) {
    return Re(e, n.toLowerCase())
}
const Ie = U({
        space: "xmlns",
        attributes: {
            xmlnsxlink: "xmlns:xlink"
        },
        transform: Me,
        properties: {
            xmlns: null,
            xmlnsXLink: null
        }
    }),
    je = U({
        transform(e, n) {
            return n === "role" ? n : "aria-" + n.slice(4).toLowerCase()
        },
        properties: {
            ariaActiveDescendant: null,
            ariaAtomic: C,
            ariaAutoComplete: null,
            ariaBusy: C,
            ariaChecked: C,
            ariaColCount: i,
            ariaColIndex: i,
            ariaColSpan: i,
            ariaControls: x,
            ariaCurrent: null,
            ariaDescribedBy: x,
            ariaDetails: null,
            ariaDisabled: C,
            ariaDropEffect: x,
            ariaErrorMessage: null,
            ariaExpanded: C,
            ariaFlowTo: x,
            ariaGrabbed: C,
            ariaHasPopup: null,
            ariaHidden: C,
            ariaInvalid: null,
            ariaKeyShortcuts: null,
            ariaLabel: null,
            ariaLabelledBy: x,
            ariaLevel: i,
            ariaLive: null,
            ariaModal: C,
            ariaMultiLine: C,
            ariaMultiSelectable: C,
            ariaOrientation: null,
            ariaOwns: x,
            ariaPlaceholder: null,
            ariaPosInSet: i,
            ariaPressed: C,
            ariaReadOnly: C,
            ariaRelevant: null,
            ariaRequired: C,
            ariaRoleDescription: x,
            ariaRowCount: i,
            ariaRowIndex: i,
            ariaRowSpan: i,
            ariaSelected: C,
            ariaSetSize: i,
            ariaSort: null,
            ariaValueMax: i,
            ariaValueMin: i,
            ariaValueNow: i,
            ariaValueText: null,
            role: null
        }
    }),
    dn = U({
        space: "html",
        attributes: {
            acceptcharset: "accept-charset",
            classname: "class",
            htmlfor: "for",
            httpequiv: "http-equiv"
        },
        transform: Me,
        mustUseProperty: ["checked", "multiple", "muted", "selected"],
        properties: {
            abbr: null,
            accept: I,
            acceptCharset: x,
            accessKey: x,
            action: null,
            allow: null,
            allowFullScreen: f,
            allowPaymentRequest: f,
            allowUserMedia: f,
            alt: null,
            as: null,
            async: f,
            autoCapitalize: null,
            autoComplete: x,
            autoFocus: f,
            autoPlay: f,
            capture: f,
            charSet: null,
            checked: f,
            cite: null,
            className: x,
            cols: i,
            colSpan: null,
            content: null,
            contentEditable: C,
            controls: f,
            controlsList: x,
            coords: i | I,
            crossOrigin: null,
            data: null,
            dateTime: null,
            decoding: null,
            default: f,
            defer: f,
            dir: null,
            dirName: null,
            disabled: f,
            download: Ne,
            draggable: C,
            encType: null,
            enterKeyHint: null,
            form: null,
            formAction: null,
            formEncType: null,
            formMethod: null,
            formNoValidate: f,
            formTarget: null,
            headers: x,
            height: i,
            hidden: f,
            high: i,
            href: null,
            hrefLang: null,
            htmlFor: x,
            httpEquiv: x,
            id: null,
            imageSizes: null,
            imageSrcSet: null,
            inputMode: null,
            integrity: null,
            is: null,
            isMap: f,
            itemId: null,
            itemProp: x,
            itemRef: x,
            itemScope: f,
            itemType: x,
            kind: null,
            label: null,
            lang: null,
            language: null,
            list: null,
            loading: null,
            loop: f,
            low: i,
            manifest: null,
            max: null,
            maxLength: i,
            media: null,
            method: null,
            min: null,
            minLength: i,
            multiple: f,
            muted: f,
            name: null,
            nonce: null,
            noModule: f,
            noValidate: f,
            onAbort: null,
            onAfterPrint: null,
            onAuxClick: null,
            onBeforePrint: null,
            onBeforeUnload: null,
            onBlur: null,
            onCancel: null,
            onCanPlay: null,
            onCanPlayThrough: null,
            onChange: null,
            onClick: null,
            onClose: null,
            onContextLost: null,
            onContextMenu: null,
            onContextRestored: null,
            onCopy: null,
            onCueChange: null,
            onCut: null,
            onDblClick: null,
            onDrag: null,
            onDragEnd: null,
            onDragEnter: null,
            onDragExit: null,
            onDragLeave: null,
            onDragOver: null,
            onDragStart: null,
            onDrop: null,
            onDurationChange: null,
            onEmptied: null,
            onEnded: null,
            onError: null,
            onFocus: null,
            onFormData: null,
            onHashChange: null,
            onInput: null,
            onInvalid: null,
            onKeyDown: null,
            onKeyPress: null,
            onKeyUp: null,
            onLanguageChange: null,
            onLoad: null,
            onLoadedData: null,
            onLoadedMetadata: null,
            onLoadEnd: null,
            onLoadStart: null,
            onMessage: null,
            onMessageError: null,
            onMouseDown: null,
            onMouseEnter: null,
            onMouseLeave: null,
            onMouseMove: null,
            onMouseOut: null,
            onMouseOver: null,
            onMouseUp: null,
            onOffline: null,
            onOnline: null,
            onPageHide: null,
            onPageShow: null,
            onPaste: null,
            onPause: null,
            onPlay: null,
            onPlaying: null,
            onPopState: null,
            onProgress: null,
            onRateChange: null,
            onRejectionHandled: null,
            onReset: null,
            onResize: null,
            onScroll: null,
            onSecurityPolicyViolation: null,
            onSeeked: null,
            onSeeking: null,
            onSelect: null,
            onSlotChange: null,
            onStalled: null,
            onStorage: null,
            onSubmit: null,
            onSuspend: null,
            onTimeUpdate: null,
            onToggle: null,
            onUnhandledRejection: null,
            onUnload: null,
            onVolumeChange: null,
            onWaiting: null,
            onWheel: null,
            open: f,
            optimum: i,
            pattern: null,
            ping: x,
            placeholder: null,
            playsInline: f,
            poster: null,
            preload: null,
            readOnly: f,
            referrerPolicy: null,
            rel: x,
            required: f,
            reversed: f,
            rows: i,
            rowSpan: i,
            sandbox: x,
            scope: null,
            scoped: f,
            seamless: f,
            selected: f,
            shape: null,
            size: i,
            sizes: null,
            slot: null,
            span: i,
            spellCheck: C,
            src: null,
            srcDoc: null,
            srcLang: null,
            srcSet: null,
            start: i,
            step: null,
            style: null,
            tabIndex: i,
            target: null,
            title: null,
            translate: null,
            type: null,
            typeMustMatch: f,
            useMap: null,
            value: C,
            width: i,
            wrap: null,
            align: null,
            aLink: null,
            archive: x,
            axis: null,
            background: null,
            bgColor: null,
            border: i,
            borderColor: null,
            bottomMargin: i,
            cellPadding: null,
            cellSpacing: null,
            char: null,
            charOff: null,
            classId: null,
            clear: null,
            code: null,
            codeBase: null,
            codeType: null,
            color: null,
            compact: f,
            declare: f,
            event: null,
            face: null,
            frame: null,
            frameBorder: null,
            hSpace: i,
            leftMargin: i,
            link: null,
            longDesc: null,
            lowSrc: null,
            marginHeight: i,
            marginWidth: i,
            noResize: f,
            noHref: f,
            noShade: f,
            noWrap: f,
            object: null,
            profile: null,
            prompt: null,
            rev: null,
            rightMargin: i,
            rules: null,
            scheme: null,
            scrolling: C,
            standby: null,
            summary: null,
            text: null,
            topMargin: i,
            valueType: null,
            version: null,
            vAlign: null,
            vLink: null,
            vSpace: i,
            allowTransparency: null,
            autoCorrect: null,
            autoSave: null,
            disablePictureInPicture: f,
            disableRemotePlayback: f,
            prefix: null,
            property: null,
            results: i,
            security: null,
            unselectable: null
        }
    }),
    hn = U({
        space: "svg",
        attributes: {
            accentHeight: "accent-height",
            alignmentBaseline: "alignment-baseline",
            arabicForm: "arabic-form",
            baselineShift: "baseline-shift",
            capHeight: "cap-height",
            className: "class",
            clipPath: "clip-path",
            clipRule: "clip-rule",
            colorInterpolation: "color-interpolation",
            colorInterpolationFilters: "color-interpolation-filters",
            colorProfile: "color-profile",
            colorRendering: "color-rendering",
            crossOrigin: "crossorigin",
            dataType: "datatype",
            dominantBaseline: "dominant-baseline",
            enableBackground: "enable-background",
            fillOpacity: "fill-opacity",
            fillRule: "fill-rule",
            floodColor: "flood-color",
            floodOpacity: "flood-opacity",
            fontFamily: "font-family",
            fontSize: "font-size",
            fontSizeAdjust: "font-size-adjust",
            fontStretch: "font-stretch",
            fontStyle: "font-style",
            fontVariant: "font-variant",
            fontWeight: "font-weight",
            glyphName: "glyph-name",
            glyphOrientationHorizontal: "glyph-orientation-horizontal",
            glyphOrientationVertical: "glyph-orientation-vertical",
            hrefLang: "hreflang",
            horizAdvX: "horiz-adv-x",
            horizOriginX: "horiz-origin-x",
            horizOriginY: "horiz-origin-y",
            imageRendering: "image-rendering",
            letterSpacing: "letter-spacing",
            lightingColor: "lighting-color",
            markerEnd: "marker-end",
            markerMid: "marker-mid",
            markerStart: "marker-start",
            navDown: "nav-down",
            navDownLeft: "nav-down-left",
            navDownRight: "nav-down-right",
            navLeft: "nav-left",
            navNext: "nav-next",
            navPrev: "nav-prev",
            navRight: "nav-right",
            navUp: "nav-up",
            navUpLeft: "nav-up-left",
            navUpRight: "nav-up-right",
            onAbort: "onabort",
            onActivate: "onactivate",
            onAfterPrint: "onafterprint",
            onBeforePrint: "onbeforeprint",
            onBegin: "onbegin",
            onCancel: "oncancel",
            onCanPlay: "oncanplay",
            onCanPlayThrough: "oncanplaythrough",
            onChange: "onchange",
            onClick: "onclick",
            onClose: "onclose",
            onCopy: "oncopy",
            onCueChange: "oncuechange",
            onCut: "oncut",
            onDblClick: "ondblclick",
            onDrag: "ondrag",
            onDragEnd: "ondragend",
            onDragEnter: "ondragenter",
            onDragExit: "ondragexit",
            onDragLeave: "ondragleave",
            onDragOver: "ondragover",
            onDragStart: "ondragstart",
            onDrop: "ondrop",
            onDurationChange: "ondurationchange",
            onEmptied: "onemptied",
            onEnd: "onend",
            onEnded: "onended",
            onError: "onerror",
            onFocus: "onfocus",
            onFocusIn: "onfocusin",
            onFocusOut: "onfocusout",
            onHashChange: "onhashchange",
            onInput: "oninput",
            onInvalid: "oninvalid",
            onKeyDown: "onkeydown",
            onKeyPress: "onkeypress",
            onKeyUp: "onkeyup",
            onLoad: "onload",
            onLoadedData: "onloadeddata",
            onLoadedMetadata: "onloadedmetadata",
            onLoadStart: "onloadstart",
            onMessage: "onmessage",
            onMouseDown: "onmousedown",
            onMouseEnter: "onmouseenter",
            onMouseLeave: "onmouseleave",
            onMouseMove: "onmousemove",
            onMouseOut: "onmouseout",
            onMouseOver: "onmouseover",
            onMouseUp: "onmouseup",
            onMouseWheel: "onmousewheel",
            onOffline: "onoffline",
            onOnline: "ononline",
            onPageHide: "onpagehide",
            onPageShow: "onpageshow",
            onPaste: "onpaste",
            onPause: "onpause",
            onPlay: "onplay",
            onPlaying: "onplaying",
            onPopState: "onpopstate",
            onProgress: "onprogress",
            onRateChange: "onratechange",
            onRepeat: "onrepeat",
            onReset: "onreset",
            onResize: "onresize",
            onScroll: "onscroll",
            onSeeked: "onseeked",
            onSeeking: "onseeking",
            onSelect: "onselect",
            onShow: "onshow",
            onStalled: "onstalled",
            onStorage: "onstorage",
            onSubmit: "onsubmit",
            onSuspend: "onsuspend",
            onTimeUpdate: "ontimeupdate",
            onToggle: "ontoggle",
            onUnload: "onunload",
            onVolumeChange: "onvolumechange",
            onWaiting: "onwaiting",
            onZoom: "onzoom",
            overlinePosition: "overline-position",
            overlineThickness: "overline-thickness",
            paintOrder: "paint-order",
            panose1: "panose-1",
            pointerEvents: "pointer-events",
            referrerPolicy: "referrerpolicy",
            renderingIntent: "rendering-intent",
            shapeRendering: "shape-rendering",
            stopColor: "stop-color",
            stopOpacity: "stop-opacity",
            strikethroughPosition: "strikethrough-position",
            strikethroughThickness: "strikethrough-thickness",
            strokeDashArray: "stroke-dasharray",
            strokeDashOffset: "stroke-dashoffset",
            strokeLineCap: "stroke-linecap",
            strokeLineJoin: "stroke-linejoin",
            strokeMiterLimit: "stroke-miterlimit",
            strokeOpacity: "stroke-opacity",
            strokeWidth: "stroke-width",
            tabIndex: "tabindex",
            textAnchor: "text-anchor",
            textDecoration: "text-decoration",
            textRendering: "text-rendering",
            typeOf: "typeof",
            underlinePosition: "underline-position",
            underlineThickness: "underline-thickness",
            unicodeBidi: "unicode-bidi",
            unicodeRange: "unicode-range",
            unitsPerEm: "units-per-em",
            vAlphabetic: "v-alphabetic",
            vHanging: "v-hanging",
            vIdeographic: "v-ideographic",
            vMathematical: "v-mathematical",
            vectorEffect: "vector-effect",
            vertAdvY: "vert-adv-y",
            vertOriginX: "vert-origin-x",
            vertOriginY: "vert-origin-y",
            wordSpacing: "word-spacing",
            writingMode: "writing-mode",
            xHeight: "x-height",
            playbackOrder: "playbackorder",
            timelineBegin: "timelinebegin"
        },
        transform: Re,
        properties: {
            about: P,
            accentHeight: i,
            accumulate: null,
            additive: null,
            alignmentBaseline: null,
            alphabetic: i,
            amplitude: i,
            arabicForm: null,
            ascent: i,
            attributeName: null,
            attributeType: null,
            azimuth: i,
            bandwidth: null,
            baselineShift: null,
            baseFrequency: null,
            baseProfile: null,
            bbox: null,
            begin: null,
            bias: i,
            by: null,
            calcMode: null,
            capHeight: i,
            className: x,
            clip: null,
            clipPath: null,
            clipPathUnits: null,
            clipRule: null,
            color: null,
            colorInterpolation: null,
            colorInterpolationFilters: null,
            colorProfile: null,
            colorRendering: null,
            content: null,
            contentScriptType: null,
            contentStyleType: null,
            crossOrigin: null,
            cursor: null,
            cx: null,
            cy: null,
            d: null,
            dataType: null,
            defaultAction: null,
            descent: i,
            diffuseConstant: i,
            direction: null,
            display: null,
            dur: null,
            divisor: i,
            dominantBaseline: null,
            download: f,
            dx: null,
            dy: null,
            edgeMode: null,
            editable: null,
            elevation: i,
            enableBackground: null,
            end: null,
            event: null,
            exponent: i,
            externalResourcesRequired: null,
            fill: null,
            fillOpacity: i,
            fillRule: null,
            filter: null,
            filterRes: null,
            filterUnits: null,
            floodColor: null,
            floodOpacity: null,
            focusable: null,
            focusHighlight: null,
            fontFamily: null,
            fontSize: null,
            fontSizeAdjust: null,
            fontStretch: null,
            fontStyle: null,
            fontVariant: null,
            fontWeight: null,
            format: null,
            fr: null,
            from: null,
            fx: null,
            fy: null,
            g1: I,
            g2: I,
            glyphName: I,
            glyphOrientationHorizontal: null,
            glyphOrientationVertical: null,
            glyphRef: null,
            gradientTransform: null,
            gradientUnits: null,
            handler: null,
            hanging: i,
            hatchContentUnits: null,
            hatchUnits: null,
            height: null,
            href: null,
            hrefLang: null,
            horizAdvX: i,
            horizOriginX: i,
            horizOriginY: i,
            id: null,
            ideographic: i,
            imageRendering: null,
            initialVisibility: null,
            in: null,
            in2: null,
            intercept: i,
            k: i,
            k1: i,
            k2: i,
            k3: i,
            k4: i,
            kernelMatrix: P,
            kernelUnitLength: null,
            keyPoints: null,
            keySplines: null,
            keyTimes: null,
            kerning: null,
            lang: null,
            lengthAdjust: null,
            letterSpacing: null,
            lightingColor: null,
            limitingConeAngle: i,
            local: null,
            markerEnd: null,
            markerMid: null,
            markerStart: null,
            markerHeight: null,
            markerUnits: null,
            markerWidth: null,
            mask: null,
            maskContentUnits: null,
            maskUnits: null,
            mathematical: null,
            max: null,
            media: null,
            mediaCharacterEncoding: null,
            mediaContentEncodings: null,
            mediaSize: i,
            mediaTime: null,
            method: null,
            min: null,
            mode: null,
            name: null,
            navDown: null,
            navDownLeft: null,
            navDownRight: null,
            navLeft: null,
            navNext: null,
            navPrev: null,
            navRight: null,
            navUp: null,
            navUpLeft: null,
            navUpRight: null,
            numOctaves: null,
            observer: null,
            offset: null,
            onAbort: null,
            onActivate: null,
            onAfterPrint: null,
            onBeforePrint: null,
            onBegin: null,
            onCancel: null,
            onCanPlay: null,
            onCanPlayThrough: null,
            onChange: null,
            onClick: null,
            onClose: null,
            onCopy: null,
            onCueChange: null,
            onCut: null,
            onDblClick: null,
            onDrag: null,
            onDragEnd: null,
            onDragEnter: null,
            onDragExit: null,
            onDragLeave: null,
            onDragOver: null,
            onDragStart: null,
            onDrop: null,
            onDurationChange: null,
            onEmptied: null,
            onEnd: null,
            onEnded: null,
            onError: null,
            onFocus: null,
            onFocusIn: null,
            onFocusOut: null,
            onHashChange: null,
            onInput: null,
            onInvalid: null,
            onKeyDown: null,
            onKeyPress: null,
            onKeyUp: null,
            onLoad: null,
            onLoadedData: null,
            onLoadedMetadata: null,
            onLoadStart: null,
            onMessage: null,
            onMouseDown: null,
            onMouseEnter: null,
            onMouseLeave: null,
            onMouseMove: null,
            onMouseOut: null,
            onMouseOver: null,
            onMouseUp: null,
            onMouseWheel: null,
            onOffline: null,
            onOnline: null,
            onPageHide: null,
            onPageShow: null,
            onPaste: null,
            onPause: null,
            onPlay: null,
            onPlaying: null,
            onPopState: null,
            onProgress: null,
            onRateChange: null,
            onRepeat: null,
            onReset: null,
            onResize: null,
            onScroll: null,
            onSeeked: null,
            onSeeking: null,
            onSelect: null,
            onShow: null,
            onStalled: null,
            onStorage: null,
            onSubmit: null,
            onSuspend: null,
            onTimeUpdate: null,
            onToggle: null,
            onUnload: null,
            onVolumeChange: null,
            onWaiting: null,
            onZoom: null,
            opacity: null,
            operator: null,
            order: null,
            orient: null,
            orientation: null,
            origin: null,
            overflow: null,
            overlay: null,
            overlinePosition: i,
            overlineThickness: i,
            paintOrder: null,
            panose1: null,
            path: null,
            pathLength: i,
            patternContentUnits: null,
            patternTransform: null,
            patternUnits: null,
            phase: null,
            ping: x,
            pitch: null,
            playbackOrder: null,
            pointerEvents: null,
            points: null,
            pointsAtX: i,
            pointsAtY: i,
            pointsAtZ: i,
            preserveAlpha: null,
            preserveAspectRatio: null,
            primitiveUnits: null,
            propagate: null,
            property: P,
            r: null,
            radius: null,
            referrerPolicy: null,
            refX: null,
            refY: null,
            rel: P,
            rev: P,
            renderingIntent: null,
            repeatCount: null,
            repeatDur: null,
            requiredExtensions: P,
            requiredFeatures: P,
            requiredFonts: P,
            requiredFormats: P,
            resource: null,
            restart: null,
            result: null,
            rotate: null,
            rx: null,
            ry: null,
            scale: null,
            seed: null,
            shapeRendering: null,
            side: null,
            slope: null,
            snapshotTime: null,
            specularConstant: i,
            specularExponent: i,
            spreadMethod: null,
            spacing: null,
            startOffset: null,
            stdDeviation: null,
            stemh: null,
            stemv: null,
            stitchTiles: null,
            stopColor: null,
            stopOpacity: null,
            strikethroughPosition: i,
            strikethroughThickness: i,
            string: null,
            stroke: null,
            strokeDashArray: P,
            strokeDashOffset: null,
            strokeLineCap: null,
            strokeLineJoin: null,
            strokeMiterLimit: i,
            strokeOpacity: i,
            strokeWidth: null,
            style: null,
            surfaceScale: i,
            syncBehavior: null,
            syncBehaviorDefault: null,
            syncMaster: null,
            syncTolerance: null,
            syncToleranceDefault: null,
            systemLanguage: P,
            tabIndex: i,
            tableValues: null,
            target: null,
            targetX: i,
            targetY: i,
            textAnchor: null,
            textDecoration: null,
            textRendering: null,
            textLength: null,
            timelineBegin: null,
            title: null,
            transformBehavior: null,
            type: null,
            typeOf: P,
            to: null,
            transform: null,
            u1: null,
            u2: null,
            underlinePosition: i,
            underlineThickness: i,
            unicode: null,
            unicodeBidi: null,
            unicodeRange: null,
            unitsPerEm: i,
            values: null,
            vAlphabetic: i,
            vMathematical: i,
            vectorEffect: null,
            vHanging: i,
            vIdeographic: i,
            version: null,
            vertAdvY: i,
            vertOriginX: i,
            vertOriginY: i,
            viewBox: null,
            viewTarget: null,
            visibility: null,
            width: null,
            widths: null,
            wordSpacing: null,
            writingMode: null,
            x: null,
            x1: null,
            x2: null,
            xChannelSelector: null,
            xHeight: i,
            y: null,
            y1: null,
            y2: null,
            yChannelSelector: null,
            z: null,
            zoomAndPan: null
        }
    }),
    mn = /^data[-\w.:]+$/i,
    ge = /-[a-z]/g,
    gn = /[A-Z]/g;

function yn(e, n) {
    const t = Y(n);
    let l = n,
        r = O;
    if (t in e.normal) return e.property[e.normal[t]];
    if (t.length > 4 && t.slice(0, 4) === "data" && mn.test(n)) {
        if (n.charAt(4) === "-") {
            const o = n.slice(5).replace(ge, xn);
            l = "data" + o.charAt(0).toUpperCase() + o.slice(1)
        } else {
            const o = n.slice(4);
            if (!ge.test(o)) {
                let a = o.replace(gn, vn);
                a.charAt(0) !== "-" && (a = "-" + a), n = "data" + a
            }
        }
        r = Z
    }
    return new r(l, n)
}

function vn(e) {
    return "-" + e.toLowerCase()
}

function xn(e) {
    return e.charAt(1).toUpperCase()
}
const bn = {
        classId: "classID",
        dataType: "datatype",
        itemId: "itemID",
        strokeDashArray: "strokeDasharray",
        strokeDashOffset: "strokeDashoffset",
        strokeLineCap: "strokeLinecap",
        strokeLineJoin: "strokeLinejoin",
        strokeMiterLimit: "strokeMiterlimit",
        typeOf: "typeof",
        xLinkActuate: "xlinkActuate",
        xLinkArcRole: "xlinkArcrole",
        xLinkHref: "xlinkHref",
        xLinkRole: "xlinkRole",
        xLinkShow: "xlinkShow",
        xLinkTitle: "xlinkTitle",
        xLinkType: "xlinkType",
        xmlnsXLink: "xmlnsXlink"
    },
    kn = Le([Te, Ae, Ie, je, dn], "html"),
    Q = Le([Te, Ae, Ie, je, hn], "svg");
var M = {},
    W, ye;

function wn() {
    if (ye) return W;
    ye = 1;
    var e = /\/\*[^*]*\*+([^/*][^*]*\*+)*\//g,
        n = /\n/g,
        t = /^\s*/,
        l = /^(\*?[-#/*\\\w]+(\[[0-9a-z_-]+\])?)\s*/,
        r = /^:\s*/,
        o = /^((?:'(?:\\'|.)*?'|"(?:\\"|.)*?"|\([^)]*?\)|[^};])+)/,
        a = /^[;\s]*/,
        s = /^\s+|\s+$/g,
        c = "\n",
        y = "/",
        u = "*",
        h = "",
        w = "comment",
        k = "declaration";
    W = function(m, b) {
        if (typeof m != "string") throw new TypeError("First argument must be a string");
        if (!m) return [];
        b = b || {};
        var D = 1,
            p = 1;

        function E(v) {
            var d = v.match(n);
            d && (D += d.length);
            var L = v.lastIndexOf(c);
            p = ~L ? v.length - L : p + v.length
        }

        function N() {
            var v = {
                line: D,
                column: p
            };
            return function(d) {
                return d.position = new S(v), re(), d
            }
        }

        function S(v) {
            this.start = v, this.end = {
                line: D,
                column: p
            }, this.source = b.source
        }
        S.prototype.content = m;

        function z(v) {
            var d = new Error(b.source + ":" + D + ":" + p + ": " + v);
            if (d.reason = v, d.filename = b.source, d.line = D, d.column = p, d.source = m, !b.silent) throw d
        }

        function A(v) {
            var d = v.exec(m);
            if (d) {
                var L = d[0];
                return E(L), m = m.slice(L.length), d
            }
        }

        function re() {
            A(t)
        }

        function oe(v) {
            var d;
            for (v = v || []; d = ae();) d !== !1 && v.push(d);
            return v
        }

        function ae() {
            var v = N();
            if (!(y != m.charAt(0) || u != m.charAt(1))) {
                for (var d = 2; h != m.charAt(d) && (u != m.charAt(d) || y != m.charAt(d + 1));) ++d;
                if (d += 2, h === m.charAt(d - 1)) return z("End of comment missing");
                var L = m.slice(2, d - 2);
                return p += 2, E(L), m = m.slice(d), p += 2, v({
                    type: w,
                    comment: L
                })
            }
        }

        function Ke() {
            var v = N(),
                d = A(l);
            if (d) {
                if (ae(), !A(r)) return z("property missing ':'");
                var L = A(o),
                    $e = v({
                        type: k,
                        property: g(d[0].replace(e, h)),
                        value: L ? g(L[0].replace(e, h)) : h
                    });
                return A(a), $e
            }
        }

        function We() {
            var v = [];
            oe(v);
            for (var d; d = Ke();) d !== !1 && (v.push(d), oe(v));
            return v
        }
        return re(), We()
    };

    function g(m) {
        return m ? m.replace(s, h) : h
    }
    return W
}
var ve;

function Cn() {
    if (ve) return M;
    ve = 1;
    var e = M && M.__importDefault || function(l) {
        return l && l.__esModule ? l : {
            default: l
        }
    };
    Object.defineProperty(M, "__esModule", {
        value: !0
    });
    var n = e(wn());

    function t(l, r) {
        var o = null;
        if (!l || typeof l != "string") return o;
        var a = (0, n.default)(l),
            s = typeof r == "function";
        return a.forEach(function(c) {
            if (c.type === "declaration") {
                var y = c.property,
                    u = c.value;
                s ? r(y, u, c) : u && (o = o || {}, o[y] = u)
            }
        }), o
    }
    return M.default = t, M
}
var Sn = Cn();
const xe = Qe(Sn),
    En = xe.default || xe,
    Ue = _e("end"),
    ee = _e("start");

function _e(e) {
    return n;

    function n(t) {
        const l = t && t.position && t.position[e] || {};
        if (typeof l.line == "number" && l.line > 0 && typeof l.column == "number" && l.column > 0) return {
            line: l.line,
            column: l.column,
            offset: typeof l.offset == "number" && l.offset > -1 ? l.offset : void 0
        }
    }
}

function Pn(e) {
    const n = ee(e),
        t = Ue(e);
    if (n && t) return {
        start: n,
        end: t
    }
}
const ne = {}.hasOwnProperty,
    Dn = new Map,
    On = /[A-Z]/g,
    Ln = /-([a-z])/g,
    Nn = new Set(["table", "tbody", "thead", "tfoot", "tr"]),
    An = new Set(["td", "th"]),
    Fe = "https://github.com/syntax-tree/hast-util-to-jsx-runtime";

function Tn(e, n) {
    if (!n || n.Fragment === void 0) throw new TypeError("Expected `Fragment` in options");
    const t = n.filePath || void 0;
    let l;
    if (n.development) {
        if (typeof n.jsxDEV != "function") throw new TypeError("Expected `jsxDEV` in options when `development: true`");
        l = Bn(t, n.jsxDEV)
    } else {
        if (typeof n.jsx != "function") throw new TypeError("Expected `jsx` in production options");
        if (typeof n.jsxs != "function") throw new TypeError("Expected `jsxs` in production options");
        l = Fn(t, n.jsx, n.jsxs)
    }
    const r = {
            Fragment: n.Fragment,
            ancestors: [],
            components: n.components || {},
            create: l,
            elementAttributeNameCase: n.elementAttributeNameCase || "react",
            evaluater: n.createEvaluater ? n.createEvaluater() : void 0,
            filePath: t,
            ignoreInvalidStyle: n.ignoreInvalidStyle || !1,
            passKeys: n.passKeys !== !1,
            passNode: n.passNode || !1,
            schema: n.space === "svg" ? Q : kn,
            stylePropertyNameCase: n.stylePropertyNameCase || "dom",
            tableCellAlignToStyle: n.tableCellAlignToStyle !== !1
        },
        o = Be(r, e, void 0);
    return o && typeof o != "string" ? o : r.create(e, r.Fragment, {
        children: o || void 0
    }, void 0)
}

function Be(e, n, t) {
    if (n.type === "element") return Rn(e, n, t);
    if (n.type === "mdxFlowExpression" || n.type === "mdxTextExpression") return Mn(e, n);
    if (n.type === "mdxJsxFlowElement" || n.type === "mdxJsxTextElement") return jn(e, n, t);
    if (n.type === "mdxjsEsm") return In(e, n);
    if (n.type === "root") return Un(e, n, t);
    if (n.type === "text") return _n(e, n)
}

function Rn(e, n, t) {
    const l = e.schema;
    let r = l;
    n.tagName.toLowerCase() === "svg" && l.space === "html" && (r = Q, e.schema = r), e.ancestors.push(n);
    const o = He(e, n.tagName, !1),
        a = zn(e, n);
    let s = le(e, n);
    return Nn.has(n.tagName) && (s = s.filter(function(c) {
        return typeof c == "string" ? !cn(c) : !0
    })), ze(e, a, o, n), te(a, s), e.ancestors.pop(), e.schema = l, e.create(n, o, a, t)
}

function Mn(e, n) {
    if (n.data && n.data.estree && e.evaluater) {
        const l = n.data.estree.body[0];
        return _(l.type === "ExpressionStatement"), e.evaluater.evaluateExpression(l.expression)
    }
    F(e, n.position)
}

function In(e, n) {
    if (n.data && n.data.estree && e.evaluater) return e.evaluater.evaluateProgram(n.data.estree);
    F(e, n.position)
}

function jn(e, n, t) {
    const l = e.schema;
    let r = l;
    n.name === "svg" && l.space === "html" && (r = Q, e.schema = r), e.ancestors.push(n);
    const o = n.name === null ? e.Fragment : He(e, n.name, !0),
        a = Hn(e, n),
        s = le(e, n);
    return ze(e, a, o, n), te(a, s), e.ancestors.pop(), e.schema = l, e.create(n, o, a, t)
}

function Un(e, n, t) {
    const l = {};
    return te(l, le(e, n)), e.create(n, e.Fragment, l, t)
}

function _n(e, n) {
    return n.value
}

function ze(e, n, t, l) {
    typeof t != "string" && t !== e.Fragment && e.passNode && (n.node = l)
}

function te(e, n) {
    if (n.length > 0) {
        const t = n.length > 1 ? n : n[0];
        t && (e.children = t)
    }
}

function Fn(e, n, t) {
    return l;

    function l(r, o, a, s) {
        const y = Array.isArray(a.children) ? t : n;
        return s ? y(o, a, s) : y(o, a)
    }
}

function Bn(e, n) {
    return t;

    function t(l, r, o, a) {
        const s = Array.isArray(o.children),
            c = ee(l);
        return n(r, o, a, s, {
            columnNumber: c ? c.column - 1 : void 0,
            fileName: e,
            lineNumber: c ? c.line : void 0
        }, void 0)
    }
}

function zn(e, n) {
    const t = {};
    let l, r;
    for (r in n.properties)
        if (r !== "children" && ne.call(n.properties, r)) {
            const o = Vn(e, r, n.properties[r]);
            if (o) {
                const [a, s] = o;
                e.tableCellAlignToStyle && a === "align" && typeof s == "string" && An.has(n.tagName) ? l = s : t[a] = s
            }
        }
    if (l) {
        const o = t.style || (t.style = {});
        o[e.stylePropertyNameCase === "css" ? "text-align" : "textAlign"] = l
    }
    return t
}

function Hn(e, n) {
    const t = {};
    for (const l of n.attributes)
        if (l.type === "mdxJsxExpressionAttribute")
            if (l.data && l.data.estree && e.evaluater) {
                const o = l.data.estree.body[0];
                _(o.type === "ExpressionStatement");
                const a = o.expression;
                _(a.type === "ObjectExpression");
                const s = a.properties[0];
                _(s.type === "SpreadElement"), Object.assign(t, e.evaluater.evaluateExpression(s.argument))
            } else F(e, n.position);
    else {
        const r = l.name;
        let o;
        if (l.value && typeof l.value == "object")
            if (l.value.data && l.value.data.estree && e.evaluater) {
                const s = l.value.data.estree.body[0];
                _(s.type === "ExpressionStatement"), o = e.evaluater.evaluateExpression(s.expression)
            } else F(e, n.position);
        else o = l.value === null ? !0 : l.value;
        t[r] = o
    }
    return t
}

function le(e, n) {
    const t = [];
    let l = -1;
    const r = e.passKeys ? new Map : Dn;
    for (; ++l < n.children.length;) {
        const o = n.children[l];
        let a;
        if (e.passKeys) {
            const c = o.type === "element" ? o.tagName : o.type === "mdxJsxFlowElement" || o.type === "mdxJsxTextElement" ? o.name : void 0;
            if (c) {
                const y = r.get(c) || 0;
                a = c + "-" + y, r.set(c, y + 1)
            }
        }
        const s = Be(e, o, a);
        s !== void 0 && t.push(s)
    }
    return t
}

function Vn(e, n, t) {
    const l = yn(e.schema, n);
    if (!(t == null || typeof t == "number" && Number.isNaN(t))) {
        if (Array.isArray(t) && (t = l.commaSeparated ? rn(t) : ln(t)), l.property === "style") {
            let r = typeof t == "object" ? t : qn(e, String(t));
            return e.stylePropertyNameCase === "css" && (r = Xn(r)), ["style", r]
        }
        return [e.elementAttributeNameCase === "react" && l.space ? bn[l.property] || l.property : l.attribute, t]
    }
}

function qn(e, n) {
    const t = {};
    try {
        En(n, l)
    } catch (r) {
        if (!e.ignoreInvalidStyle) {
            const o = r,
                a = new De("Cannot parse `style` attribute", {
                    ancestors: e.ancestors,
                    cause: o,
                    ruleId: "style",
                    source: "hast-util-to-jsx-runtime"
                });
            throw a.file = e.filePath || void 0, a.url = Fe + "#cannot-parse-style-attribute", a
        }
    }
    return t;

    function l(r, o) {
        let a = r;
        a.slice(0, 2) !== "--" && (a.slice(0, 4) === "-ms-" && (a = "ms-" + a.slice(4)), a = a.replace(Ln, Wn)), t[a] = o
    }
}

function He(e, n, t) {
    let l;
    if (!t) l = {
        type: "Literal",
        value: n
    };
    else if (n.includes(".")) {
        const r = n.split(".");
        let o = -1,
            a;
        for (; ++o < r.length;) {
            const s = de(r[o]) ? {
                type: "Identifier",
                name: r[o]
            } : {
                type: "Literal",
                value: r[o]
            };
            a = a ? {
                type: "MemberExpression",
                object: a,
                property: s,
                computed: !!(o && s.type === "Literal"),
                optional: !1
            } : s
        }
        l = a
    } else l = de(n) && !/^[a-z]/.test(n) ? {
        type: "Identifier",
        name: n
    } : {
        type: "Literal",
        value: n
    };
    if (l.type === "Literal") {
        const r = l.value;
        return ne.call(e.components, r) ? e.components[r] : r
    }
    if (e.evaluater) return e.evaluater.evaluateExpression(l);
    F(e)
}

function F(e, n) {
    const t = new De("Cannot handle MDX estrees without `createEvaluater`", {
        ancestors: e.ancestors,
        place: n,
        ruleId: "mdx-estree",
        source: "hast-util-to-jsx-runtime"
    });
    throw t.file = e.filePath || void 0, t.url = Fe + "#cannot-handle-mdx-estrees-without-createevaluater", t
}

function Xn(e) {
    const n = {};
    let t;
    for (t in e) ne.call(e, t) && (n[Kn(t)] = e[t]);
    return n
}

function Kn(e) {
    let n = e.replace(On, $n);
    return n.slice(0, 3) === "ms-" && (n = "-" + n), n
}

function Wn(e, n) {
    return n.toUpperCase()
}

function $n(e) {
    return "-" + e.toLowerCase()
}
const $ = {
    action: ["form"],
    cite: ["blockquote", "del", "ins", "q"],
    data: ["object"],
    formAction: ["button", "input"],
    href: ["a", "area", "base", "link"],
    icon: ["menuitem"],
    itemId: null,
    manifest: ["html"],
    ping: ["a", "area"],
    poster: ["video"],
    src: ["audio", "embed", "iframe", "img", "input", "script", "source", "track", "video"]
};

function Yn(e, n) {
    const t = {
        type: "element",
        tagName: "blockquote",
        properties: {},
        children: e.wrap(e.all(n), !0)
    };
    return e.patch(n, t), e.applyData(n, t)
}

function Jn(e, n) {
    const t = {
        type: "element",
        tagName: "br",
        properties: {},
        children: []
    };
    return e.patch(n, t), [e.applyData(n, t), {
        type: "text",
        value: "\n"
    }]
}

function Gn(e, n) {
    const t = n.value ? n.value + "\n" : "",
        l = {};
    n.lang && (l.className = ["language-" + n.lang]);
    let r = {
        type: "element",
        tagName: "code",
        properties: l,
        children: [{
            type: "text",
            value: t
        }]
    };
    return n.meta && (r.data = {
        meta: n.meta
    }), e.patch(n, r), r = e.applyData(n, r), r = {
        type: "element",
        tagName: "pre",
        properties: {},
        children: [r]
    }, e.patch(n, r), r
}

function Zn(e, n) {
    const t = {
        type: "element",
        tagName: "del",
        properties: {},
        children: e.all(n)
    };
    return e.patch(n, t), e.applyData(n, t)
}

function Qn(e, n) {
    const t = {
        type: "element",
        tagName: "em",
        properties: {},
        children: e.all(n)
    };
    return e.patch(n, t), e.applyData(n, t)
}

function et(e, n) {
    const t = typeof e.options.clobberPrefix == "string" ? e.options.clobberPrefix : "user-content-",
        l = String(n.identifier).toUpperCase(),
        r = j(l.toLowerCase()),
        o = e.footnoteOrder.indexOf(l);
    let a, s = e.footnoteCounts.get(l);
    s === void 0 ? (s = 0, e.footnoteOrder.push(l), a = e.footnoteOrder.length) : a = o + 1, s += 1, e.footnoteCounts.set(l, s);
    const c = {
        type: "element",
        tagName: "a",
        properties: {
            href: "#" + t + "fn-" + r,
            id: t + "fnref-" + r + (s > 1 ? "-" + s : ""),
            dataFootnoteRef: !0,
            ariaDescribedBy: ["footnote-label"]
        },
        children: [{
            type: "text",
            value: String(a)
        }]
    };
    e.patch(n, c);
    const y = {
        type: "element",
        tagName: "sup",
        properties: {},
        children: [c]
    };
    return e.patch(n, y), e.applyData(n, y)
}

function nt(e, n) {
    const t = {
        type: "element",
        tagName: "h" + n.depth,
        properties: {},
        children: e.all(n)
    };
    return e.patch(n, t), e.applyData(n, t)
}

function tt(e, n) {
    if (e.options.allowDangerousHtml) {
        const t = {
            type: "raw",
            value: n.value
        };
        return e.patch(n, t), e.applyData(n, t)
    }
}

function Ve(e, n) {
    const t = n.referenceType;
    let l = "]";
    if (t === "collapsed" ? l += "[]" : t === "full" && (l += "[" + (n.label || n.identifier) + "]"), n.type === "imageReference") return [{
        type: "text",
        value: "![" + n.alt + l
    }];
    const r = e.all(n),
        o = r[0];
    o && o.type === "text" ? o.value = "[" + o.value : r.unshift({
        type: "text",
        value: "["
    });
    const a = r[r.length - 1];
    return a && a.type === "text" ? a.value += l : r.push({
        type: "text",
        value: l
    }), r
}

function lt(e, n) {
    const t = String(n.identifier).toUpperCase(),
        l = e.definitionById.get(t);
    if (!l) return Ve(e, n);
    const r = {
        src: j(l.url || ""),
        alt: n.alt
    };
    l.title !== null && l.title !== void 0 && (r.title = l.title);
    const o = {
        type: "element",
        tagName: "img",
        properties: r,
        children: []
    };
    return e.patch(n, o), e.applyData(n, o)
}

function rt(e, n) {
    const t = {
        src: j(n.url)
    };
    n.alt !== null && n.alt !== void 0 && (t.alt = n.alt), n.title !== null && n.title !== void 0 && (t.title = n.title);
    const l = {
        type: "element",
        tagName: "img",
        properties: t,
        children: []
    };
    return e.patch(n, l), e.applyData(n, l)
}

function ot(e, n) {
    const t = {
        type: "text",
        value: n.value.replace(/\r?\n|\r/g, " ")
    };
    e.patch(n, t);
    const l = {
        type: "element",
        tagName: "code",
        properties: {},
        children: [t]
    };
    return e.patch(n, l), e.applyData(n, l)
}

function at(e, n) {
    const t = String(n.identifier).toUpperCase(),
        l = e.definitionById.get(t);
    if (!l) return Ve(e, n);
    const r = {
        href: j(l.url || "")
    };
    l.title !== null && l.title !== void 0 && (r.title = l.title);
    const o = {
        type: "element",
        tagName: "a",
        properties: r,
        children: e.all(n)
    };
    return e.patch(n, o), e.applyData(n, o)
}

function it(e, n) {
    const t = {
        href: j(n.url)
    };
    n.title !== null && n.title !== void 0 && (t.title = n.title);
    const l = {
        type: "element",
        tagName: "a",
        properties: t,
        children: e.all(n)
    };
    return e.patch(n, l), e.applyData(n, l)
}

function st(e, n, t) {
    const l = e.all(n),
        r = t ? ut(t) : qe(n),
        o = {},
        a = [];
    if (typeof n.checked == "boolean") {
        const u = l[0];
        let h;
        u && u.type === "element" && u.tagName === "p" ? h = u : (h = {
            type: "element",
            tagName: "p",
            properties: {},
            children: []
        }, l.unshift(h)), h.children.length > 0 && h.children.unshift({
            type: "text",
            value: " "
        }), h.children.unshift({
            type: "element",
            tagName: "input",
            properties: {
                type: "checkbox",
                checked: n.checked,
                disabled: !0
            },
            children: []
        }), o.className = ["task-list-item"]
    }
    let s = -1;
    for (; ++s < l.length;) {
        const u = l[s];
        (r || s !== 0 || u.type !== "element" || u.tagName !== "p") && a.push({
            type: "text",
            value: "\n"
        }), u.type === "element" && u.tagName === "p" && !r ? a.push(...u.children) : a.push(u)
    }
    const c = l[l.length - 1];
    c && (r || c.type !== "element" || c.tagName !== "p") && a.push({
        type: "text",
        value: "\n"
    });
    const y = {
        type: "element",
        tagName: "li",
        properties: o,
        children: a
    };
    return e.patch(n, y), e.applyData(n, y)
}

function ut(e) {
    let n = !1;
    if (e.type === "list") {
        n = e.spread || !1;
        const t = e.children;
        let l = -1;
        for (; !n && ++l < t.length;) n = qe(t[l])
    }
    return n
}

function qe(e) {
    const n = e.spread;
    return n == null ? e.children.length > 1 : n
}

function ct(e, n) {
    const t = {},
        l = e.all(n);
    let r = -1;
    for (typeof n.start == "number" && n.start !== 1 && (t.start = n.start); ++r < l.length;) {
        const a = l[r];
        if (a.type === "element" && a.tagName === "li" && a.properties && Array.isArray(a.properties.className) && a.properties.className.includes("task-list-item")) {
            t.className = ["contains-task-list"];
            break
        }
    }
    const o = {
        type: "element",
        tagName: n.ordered ? "ol" : "ul",
        properties: t,
        children: e.wrap(l, !0)
    };
    return e.patch(n, o), e.applyData(n, o)
}

function pt(e, n) {
    const t = {
        type: "element",
        tagName: "p",
        properties: {},
        children: e.all(n)
    };
    return e.patch(n, t), e.applyData(n, t)
}

function ft(e, n) {
    const t = {
        type: "root",
        children: e.wrap(e.all(n))
    };
    return e.patch(n, t), e.applyData(n, t)
}

function dt(e, n) {
    const t = {
        type: "element",
        tagName: "strong",
        properties: {},
        children: e.all(n)
    };
    return e.patch(n, t), e.applyData(n, t)
}

function ht(e, n) {
    const t = e.all(n),
        l = t.shift(),
        r = [];
    if (l) {
        const a = {
            type: "element",
            tagName: "thead",
            properties: {},
            children: e.wrap([l], !0)
        };
        e.patch(n.children[0], a), r.push(a)
    }
    if (t.length > 0) {
        const a = {
                type: "element",
                tagName: "tbody",
                properties: {},
                children: e.wrap(t, !0)
            },
            s = ee(n.children[1]),
            c = Ue(n.children[n.children.length - 1]);
        s && c && (a.position = {
            start: s,
            end: c
        }), r.push(a)
    }
    const o = {
        type: "element",
        tagName: "table",
        properties: {},
        children: e.wrap(r, !0)
    };
    return e.patch(n, o), e.applyData(n, o)
}

function mt(e, n, t) {
    const l = t ? t.children : void 0,
        o = (l ? l.indexOf(n) : 1) === 0 ? "th" : "td",
        a = t && t.type === "table" ? t.align : void 0,
        s = a ? a.length : n.children.length;
    let c = -1;
    const y = [];
    for (; ++c < s;) {
        const h = n.children[c],
            w = {},
            k = a ? a[c] : void 0;
        k && (w.align = k);
        let g = {
            type: "element",
            tagName: o,
            properties: w,
            children: []
        };
        h && (g.children = e.all(h), e.patch(h, g), g = e.applyData(h, g)), y.push(g)
    }
    const u = {
        type: "element",
        tagName: "tr",
        properties: {},
        children: e.wrap(y, !0)
    };
    return e.patch(n, u), e.applyData(n, u)
}

function gt(e, n) {
    const t = {
        type: "element",
        tagName: "td",
        properties: {},
        children: e.all(n)
    };
    return e.patch(n, t), e.applyData(n, t)
}
const be = 9,
    ke = 32;

function yt(e) {
    const n = String(e),
        t = /\r?\n|\r/g;
    let l = t.exec(n),
        r = 0;
    const o = [];
    for (; l;) o.push(we(n.slice(r, l.index), r > 0, !0), l[0]), r = l.index + l[0].length, l = t.exec(n);
    return o.push(we(n.slice(r), r > 0, !1)), o.join("")
}

function we(e, n, t) {
    let l = 0,
        r = e.length;
    if (n) {
        let o = e.codePointAt(l);
        for (; o === be || o === ke;) l++, o = e.codePointAt(l)
    }
    if (t) {
        let o = e.codePointAt(r - 1);
        for (; o === be || o === ke;) r--, o = e.codePointAt(r - 1)
    }
    return r > l ? e.slice(l, r) : ""
}

function vt(e, n) {
    const t = {
        type: "text",
        value: yt(String(n.value))
    };
    return e.patch(n, t), e.applyData(n, t)
}

function xt(e, n) {
    const t = {
        type: "element",
        tagName: "hr",
        properties: {},
        children: []
    };
    return e.patch(n, t), e.applyData(n, t)
}
const bt = {
    blockquote: Yn,
    break: Jn,
    code: Gn,
    delete: Zn,
    emphasis: Qn,
    footnoteReference: et,
    heading: nt,
    html: tt,
    imageReference: lt,
    image: rt,
    inlineCode: ot,
    linkReference: at,
    link: it,
    listItem: st,
    list: ct,
    paragraph: pt,
    root: ft,
    strong: dt,
    table: ht,
    tableCell: gt,
    tableRow: mt,
    text: vt,
    thematicBreak: xt,
    toml: V,
    yaml: V,
    definition: V,
    footnoteDefinition: V
};

function V() {}

function kt(e, n) {
    const t = [{
        type: "text",
        value: "↩"
    }];
    return n > 1 && t.push({
        type: "element",
        tagName: "sup",
        properties: {},
        children: [{
            type: "text",
            value: String(n)
        }]
    }), t
}

function wt(e, n) {
    return "Back to reference " + (e + 1) + (n > 1 ? "-" + n : "")
}

function Ct(e) {
    const n = typeof e.options.clobberPrefix == "string" ? e.options.clobberPrefix : "user-content-",
        t = e.options.footnoteBackContent || kt,
        l = e.options.footnoteBackLabel || wt,
        r = e.options.footnoteLabel || "Footnotes",
        o = e.options.footnoteLabelTagName || "h2",
        a = e.options.footnoteLabelProperties || {
            className: ["sr-only"]
        },
        s = [];
    let c = -1;
    for (; ++c < e.footnoteOrder.length;) {
        const y = e.footnoteById.get(e.footnoteOrder[c]);
        if (!y) continue;
        const u = e.all(y),
            h = String(y.identifier).toUpperCase(),
            w = j(h.toLowerCase());
        let k = 0;
        const g = [],
            m = e.footnoteCounts.get(h);
        for (; m !== void 0 && ++k <= m;) {
            g.length > 0 && g.push({
                type: "text",
                value: " "
            });
            let p = typeof t == "string" ? t : t(c, k);
            typeof p == "string" && (p = {
                type: "text",
                value: p
            }), g.push({
                type: "element",
                tagName: "a",
                properties: {
                    href: "#" + n + "fnref-" + w + (k > 1 ? "-" + k : ""),
                    dataFootnoteBackref: "",
                    ariaLabel: typeof l == "string" ? l : l(c, k),
                    className: ["data-footnote-backref"]
                },
                children: Array.isArray(p) ? p : [p]
            })
        }
        const b = u[u.length - 1];
        if (b && b.type === "element" && b.tagName === "p") {
            const p = b.children[b.children.length - 1];
            p && p.type === "text" ? p.value += " " : b.children.push({
                type: "text",
                value: " "
            }), b.children.push(...g)
        } else u.push(...g);
        const D = {
            type: "element",
            tagName: "li",
            properties: {
                id: n + "fn-" + w
            },
            children: e.wrap(u, !0)
        };
        e.patch(y, D), s.push(D)
    }
    if (s.length !== 0) return {
        type: "element",
        tagName: "section",
        properties: {
            dataFootnotes: !0,
            className: ["footnotes"]
        },
        children: [{
            type: "element",
            tagName: o,
            properties: ce(T({}, q(a)), {
                id: "footnote-label"
            }),
            children: [{
                type: "text",
                value: r
            }]
        }, {
            type: "text",
            value: "\n"
        }, {
            type: "element",
            tagName: "ol",
            properties: {},
            children: e.wrap(s, !0)
        }, {
            type: "text",
            value: "\n"
        }]
    }
}
const G = {}.hasOwnProperty,
    St = {};

function Et(e, n) {
    const t = n || St,
        l = new Map,
        r = new Map,
        o = new Map,
        a = T(T({}, bt), t.handlers),
        s = {
            all: y,
            applyData: Dt,
            definitionById: l,
            footnoteById: r,
            footnoteCounts: o,
            footnoteOrder: [],
            handlers: a,
            one: c,
            options: t,
            patch: Pt,
            wrap: Lt
        };
    return Oe(e, function(u) {
        if (u.type === "definition" || u.type === "footnoteDefinition") {
            const h = u.type === "definition" ? l : r,
                w = String(u.identifier).toUpperCase();
            h.has(w) || h.set(w, u)
        }
    }), s;

    function c(u, h) {
        const w = u.type,
            k = s.handlers[w];
        if (G.call(s.handlers, w) && k) return k(s, u, h);
        if (s.options.passThrough && s.options.passThrough.includes(w)) {
            if ("children" in u) {
                const m = u,
                    {
                        children: b
                    } = m,
                    D = pe(m, ["children"]),
                    p = q(D);
                return p.children = s.all(u), p
            }
            return q(u)
        }
        return (s.options.unknownHandler || Ot)(s, u, h)
    }

    function y(u) {
        const h = [];
        if ("children" in u) {
            const w = u.children;
            let k = -1;
            for (; ++k < w.length;) {
                const g = s.one(w[k], u);
                if (g) {
                    if (k && w[k - 1].type === "break" && (!Array.isArray(g) && g.type === "text" && (g.value = Ce(g.value)), !Array.isArray(g) && g.type === "element")) {
                        const m = g.children[0];
                        m && m.type === "text" && (m.value = Ce(m.value))
                    }
                    Array.isArray(g) ? h.push(...g) : h.push(g)
                }
            }
        }
        return h
    }
}

function Pt(e, n) {
    e.position && (n.position = Pn(e))
}

function Dt(e, n) {
    let t = n;
    if (e && e.data) {
        const l = e.data.hName,
            r = e.data.hChildren,
            o = e.data.hProperties;
        if (typeof l == "string")
            if (t.type === "element") t.tagName = l;
            else {
                const a = "children" in t ? t.children : [t];
                t = {
                    type: "element",
                    tagName: l,
                    properties: {},
                    children: a
                }
            }
        t.type === "element" && o && Object.assign(t.properties, q(o)), "children" in t && t.children && r !== null && r !== void 0 && (t.children = r)
    }
    return t
}

function Ot(e, n) {
    const t = n.data || {},
        l = "value" in n && !(G.call(t, "hProperties") || G.call(t, "hChildren")) ? {
            type: "text",
            value: n.value
        } : {
            type: "element",
            tagName: "div",
            properties: {},
            children: e.all(n)
        };
    return e.patch(n, l), e.applyData(n, l)
}

function Lt(e, n) {
    const t = [];
    let l = -1;
    for (n && t.push({
            type: "text",
            value: "\n"
        }); ++l < e.length;) l && t.push({
        type: "text",
        value: "\n"
    }), t.push(e[l]);
    return n && e.length > 0 && t.push({
        type: "text",
        value: "\n"
    }), t
}

function Ce(e) {
    let n = 0,
        t = e.charCodeAt(n);
    for (; t === 9 || t === 32;) n++, t = e.charCodeAt(n);
    return e.slice(n)
}

function Se(e, n) {
    const t = Et(e, n),
        l = t.one(e, void 0),
        r = Ct(t),
        o = Array.isArray(l) ? {
            type: "root",
            children: l
        } : l || {
            type: "root",
            children: []
        };
    return r && o.children.push({
        type: "text",
        value: "\n"
    }, r), o
}

function Nt(e, n) {
    return e && "run" in e ? async function(t, l) {
        const r = Se(t, T({
            file: l
        }, n));
        await e.run(r, l)
    } : function(t, l) {
        return Se(t, T({
            file: l
        }, e || n))
    }
}
const At = "https://github.com/remarkjs/react-markdown/blob/main/changelog.md",
    Ee = [],
    Pe = {
        allowDangerousHtml: !0
    },
    Tt = /^(https?|ircs?|mailto|xmpp)$/i,
    Rt = [{
        from: "astPlugins",
        id: "remove-buggy-html-in-markdown-parser"
    }, {
        from: "allowDangerousHtml",
        id: "remove-buggy-html-in-markdown-parser"
    }, {
        from: "allowNode",
        id: "replace-allownode-allowedtypes-and-disallowedtypes",
        to: "allowElement"
    }, {
        from: "allowedTypes",
        id: "replace-allownode-allowedtypes-and-disallowedtypes",
        to: "allowedElements"
    }, {
        from: "disallowedTypes",
        id: "replace-allownode-allowedtypes-and-disallowedtypes",
        to: "disallowedElements"
    }, {
        from: "escapeHtml",
        id: "remove-buggy-html-in-markdown-parser"
    }, {
        from: "includeElementIndex",
        id: "#remove-includeelementindex"
    }, {
        from: "includeNodeIndex",
        id: "change-includenodeindex-to-includeelementindex"
    }, {
        from: "linkTarget",
        id: "remove-linktarget"
    }, {
        from: "plugins",
        id: "change-plugins-to-remarkplugins",
        to: "remarkPlugins"
    }, {
        from: "rawSourcePos",
        id: "#remove-rawsourcepos"
    }, {
        from: "renderers",
        id: "change-renderers-to-components",
        to: "components"
    }, {
        from: "source",
        id: "change-source-to-children",
        to: "children"
    }, {
        from: "sourcePos",
        id: "#remove-sourcepos"
    }, {
        from: "transformImageUri",
        id: "#add-urltransform",
        to: "urlTransform"
    }, {
        from: "transformLinkUri",
        id: "#add-urltransform",
        to: "urlTransform"
    }];

function Mt(e) {
    const n = e.allowedElements,
        t = e.allowElement,
        l = e.children || "",
        r = e.className,
        o = e.components,
        a = e.disallowedElements,
        s = e.rehypePlugins || Ee,
        c = e.remarkPlugins || Ee,
        y = e.remarkRehypeOptions ? T(T({}, e.remarkRehypeOptions), Pe) : Pe,
        u = e.skipHtml,
        h = e.unwrapDisallowed,
        w = e.urlTransform || Xe,
        k = en().use(tn).use(c).use(Nt, y).use(s),
        g = new nn;
    typeof l == "string" && (g.value = l);
    for (const p of Rt) Object.hasOwn(e, p.from) && Ze("Unexpected `" + p.from + "` prop, " + (p.to ? "use `" + p.to + "` instead" : "remove it") + " (see <" + At + "#" + p.id + "> for more info)");
    const m = k.parse(g);
    let b = k.runSync(m, g);
    return r && (b = {
        type: "element",
        tagName: "div",
        properties: {
            className: r
        },
        children: b.type === "root" ? b.children : [b]
    }), Oe(b, D), Tn(b, {
        Fragment: X.Fragment,
        components: o,
        ignoreInvalidStyle: !0,
        jsx: X.jsx,
        jsxs: X.jsxs,
        passKeys: !0,
        passNode: !0
    });

    function D(p, E, N) {
        if (p.type === "raw" && N && typeof E == "number") return u ? N.children.splice(E, 1) : N.children[E] = {
            type: "text",
            value: p.value
        }, E;
        if (p.type === "element") {
            let S;
            for (S in $)
                if (Object.hasOwn($, S) && Object.hasOwn(p.properties, S)) {
                    const z = p.properties[S],
                        A = $[S];
                    (A === null || A.includes(p.tagName)) && (p.properties[S] = w(String(z || ""), S, p))
                }
        }
        if (p.type === "element") {
            let S = n ? !n.includes(p.tagName) : a ? a.includes(p.tagName) : !1;
            if (!S && t && typeof E == "number" && (S = !t(p, E, N)), S && N && typeof E == "number") return h && p.children ? N.children.splice(E, 1, ...p.children) : N.children.splice(E, 1), E
        }
    }
}

function Xe(e) {
    const n = e.indexOf(":"),
        t = e.indexOf("?"),
        l = e.indexOf("#"),
        r = e.indexOf("/");
    return n < 0 || r > -1 && n > r || t > -1 && n > t || l > -1 && n > l || Tt.test(e.slice(0, n)) ? e : ""
}
const Ht = Object.freeze(Object.defineProperty({
    __proto__: null,
    default: Mt,
    defaultUrlTransform: Xe
}, Symbol.toStringTag, {
    value: "Module"
}));
export {
    Mt as M, rn as a, Xe as d, yn as f, kn as h, Ht as i, Y as n, zt as p, Nt as r, Q as s, cn as w
};
//# sourceMappingURL=ebc4iyfg14nu1gw4.js.map