var y = Object.defineProperty,
    C = Object.defineProperties;
var T = Object.getOwnPropertyDescriptors;
var d = Object.getOwnPropertySymbols;
var b = Object.prototype.hasOwnProperty,
    g = Object.prototype.propertyIsEnumerable;
var x = (t, s, e) => s in t ? y(t, s, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : t[s] = e,
    p = (t, s) => {
        for (var e in s || (s = {})) b.call(s, e) && x(t, e, s[e]);
        if (d)
            for (var e of d(s)) g.call(s, e) && x(t, e, s[e]);
        return t
    },
    m = (t, s) => C(t, T(s));
var h = (t, s) => {
    var e = {};
    for (var o in t) b.call(t, o) && s.indexOf(o) < 0 && (e[o] = t[o]);
    if (t != null && d)
        for (var o of d(t)) s.indexOf(o) < 0 && g.call(t, o) && (e[o] = t[o]);
    return e
};
import {
    r as u,
    e as N,
    j as n
} from "./fg33krlcm0qyi6yw.js";
import {
    fp as R,
    ca as k,
    c$ as w,
    ij as I
} from "./k15yxxoybkkir2ou.js";
import {
    T as S,
    da as E,
    l as f
} from "./dykg4ktvbu3mhmdo.js";
import {
    t as j
} from "./oxont9zeuaiwb679.js";
const M = ({
        onClick: t
    }) => {
        const [s, e] = u.useState(!1), o = R(), l = N(), a = c => {
            t(c), e(!0), setTimeout(() => {
                o() && e(!1)
            }, 2e3)
        }, r = s ? k : w, i = l.formatMessage({
            id: "uG/ayY",
            defaultMessage: "Copy table"
        });
        return n.jsx(S, {
            label: i,
            side: "bottom",
            align: "center",
            alignOffset: 0,
            children: n.jsx("button", {
                "aria-label": i,
                onClick: a,
                className: "hover:bg-token-bg-tertiary text-token-text-secondary my-1 rounded-sm p-1 transition-opacity group-[:not(:hover):not(:focus-within)]:pointer-events-none group-[:not(:hover):not(:focus-within)]:opacity-0",
                children: n.jsx(r, {
                    className: "icon"
                })
            })
        })
    },
    L = l => {
        var a = l,
            {
                onClickCopy: t,
                children: s,
                unstyledContainer: e
            } = a,
            o = h(a, ["onClickCopy", "children", "unstyledContainer"]);
        const r = u.useRef(null),
            i = u.useRef(null);
        return E(() => {
            var c;
            I({
                axis: "height",
                target: (c = r.current) == null ? void 0 : c.firstElementChild,
                onChange: ({
                    height: v
                }) => {
                    i.current && (i.current.style.height = "".concat(v, "px"))
                }
            })
        }, []), n.jsx("div", {
            className: f(e ? void 0 : j.tableContainer),
            children: n.jsxs("div", {
                tabIndex: -1,
                className: f("group", f(e ? void 0 : j.tableWrapper, "flex w-fit flex-col-reverse")),
                children: [n.jsx("table", m(p({}, o), {
                    className: "w-fit min-w-(--thread-content-width)",
                    ref: r,
                    children: s
                })), n.jsx("div", {
                    className: f("sticky h-0 select-none", e ? "end-0 self-end" : "end-(--thread-content-margin) self-end"),
                    children: n.jsx("div", {
                        className: "absolute end-0 flex items-end",
                        ref: i,
                        children: n.jsx(M, {
                            onClick: t
                        })
                    })
                })]
            })
        })
    },
    W = o => {
        var l = o,
            {
                node: t,
                children: s
            } = l,
            e = h(l, ["node", "children"]);
        return n.jsx("td", m(p({}, e), {
            children: u.Children.map(s, (a, r) => a === "<br>" ? n.jsx("br", {}, r) : a)
        }))
    };
export {
    L as T, W as a
};
//# sourceMappingURL=g0f4hjqp90x9s4o7.js.map