var Q = Object.defineProperty,
    $ = Object.defineProperties;
var G = Object.getOwnPropertyDescriptors;
var R = Object.getOwnPropertySymbols;
var K = Object.prototype.hasOwnProperty,
    X = Object.prototype.propertyIsEnumerable;
var F = (o, t, a) => t in o ? Q(o, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: a
    }) : o[t] = a,
    u = (o, t) => {
        for (var a in t || (t = {})) K.call(t, a) && F(o, a, t[a]);
        if (R)
            for (var a of R(t)) X.call(t, a) && F(o, a, t[a]);
        return o
    },
    j = (o, t) => $(o, G(t));
import {
    e as Y,
    a as Z,
    r as M,
    u as ee,
    j as e,
    M as L
} from "./fg33krlcm0qyi6yw.js";
import {
    m as se,
    o as te,
    p,
    q as ae,
    L as oe,
    H as ie,
    D as ne,
    t as re,
    W as _
} from "./k15yxxoybkkir2ou.js";
import {
    E as le
} from "./jkejdo8v5ynnt9ff.js";
import {
    ag as ce,
    m as de,
    R as ue,
    bJ as pe,
    b as xe,
    bv as me,
    bg as fe,
    i9 as ge,
    a9 as he
} from "./dykg4ktvbu3mhmdo.js";
import {
    u as we
} from "./k2oaaf8ac9lafsub.js";
import "./lans8a2ikbh9ax9r.js";

function be() {
    return e.jsx("div", {
        className: "static w-full",
        role: "list",
        "data-testid": "workspace-list",
        children: e.jsxs("div", {
            className: "static flex w-full flex-col rounded-2xl border py-1.5",
            children: [e.jsx(_, {}, 1), e.jsx(_, {}, 2)]
        })
    })
}

function Ee({
    onClose: o,
    mode: t = "blocking",
    section: a = "existing",
    source: A = "unknown"
}) {
    var S, C;
    const {
        data: m,
        isFetching: H
    } = we(), n = ce(), I = (S = n == null ? void 0 : n.email) != null ? S : "", f = Y(), V = xe(), P = (n == null ? void 0 : n.email_domain_type) === "professional", y = a === "existing" || a === "both", x = (a === "discoverable" || a === "both") && P, {
        data: r,
        isFetching: B
    } = se(x), T = Z(), [U, g] = M.useState(null), z = de(), {
        setHasSeenWorkspaceDiscoveryFirstLoginDontInvalidateCache: h
    } = te(), N = ee({
        mutationFn: async s => {
            await ue.safePost("/accounts/{account_id}/invites/request", {
                parameters: {
                    path: {
                        account_id: s
                    }
                }
            })
        },
        onSuccess: (s, i) => {
            T.setQueryData(["discoverable-workspaces"], c => c != null && c.workspaces ? j(u({}, c), {
                workspaces: c.workspaces.map(k => k.id === i ? j(u({}, k), {
                    requested: !0
                }) : k)
            }) : c)
        },
        onError: (s, i) => {
            g(null), z.danger(f.formatMessage(p.requestAccessError), {
                toastId: "request-access-".concat(i)
            })
        },
        onSettled: () => {
            g(null)
        }
    }), D = x && !!(r != null && r.has_more), d = y && H || x && B, l = [];
    if (y && l.push(...(m != null ? m : []).map(s => ({
            type: "existing",
            w: s
        }))), x) {
        const s = (C = r == null ? void 0 : r.workspaces) != null ? C : [];
        l.push(...s.map(i => ({
            type: "discoverable",
            w: i
        })))
    }
    const w = l.filter(s => s.type === "existing").length,
        b = l.filter(s => s.type === "discoverable").length,
        {
            hasLoggedFullscreenView: W,
            logFullscreenViewedOnce: q,
            logExitEvent: v,
            logRequestButtonClicked: J,
            logRequestButtonHovered: O
        } = ae({
            source: A,
            existingCount: w,
            discoverableCount: b
        });
    if (M.useEffect(() => {
            !W && !d && q()
        }, [W, q, d]), t === "blocking" && w === 0 && !d) return null;
    const E = pe(V, "2133596510").get("enabled", !1);
    return e.jsx(me, {
        children: e.jsx(fe.div, {
            initial: {
                opacity: 0
            },
            animate: {
                opacity: 1
            },
            exit: {
                opacity: 0
            },
            transition: {
                duration: .4
            },
            "data-testid": "fullscreen-workspace-switcher",
            className: "bg-token-bg-primary absolute inset-0 start-0 top-0 z-50 h-full w-full",
            role: "dialog",
            "aria-modal": "true",
            "aria-label": f.formatMessage(p.title),
            children: e.jsxs("div", {
                className: "flex h-full max-h-full flex-col",
                children: [t === "dismissible" && e.jsx("div", {
                    className: "absolute end-4 top-4",
                    children: e.jsx("button", {
                        type: "button",
                        "aria-label": f.formatMessage(p.close),
                        onClick: () => {
                            h(), v("close"), o()
                        },
                        className: "rounded-full p-2 hover:bg-transparent",
                        children: e.jsx(ge, {
                            className: "icon"
                        })
                    })
                }), e.jsx("div", {
                    className: "flex flex-1 items-start justify-center px-6 pt-[15vh] pb-12",
                    children: e.jsxs("div", {
                        className: "flex w-[440px] flex-col items-center",
                        children: [d ? e.jsxs(e.Fragment, {
                            children: [e.jsx(oe, {
                                showCollaborationSubtitle: E
                            }), e.jsx(be, {})]
                        }) : e.jsxs(e.Fragment, {
                            children: [e.jsx(ie, {
                                existingCount: w,
                                discoverableCount: b,
                                accountEmail: I,
                                showCollaborationSubtitle: E
                            }), l.length > 0 && e.jsx("div", {
                                className: "static w-full",
                                role: "list",
                                "data-testid": "workspace-list",
                                children: e.jsx("div", {
                                    className: "static flex w-full flex-col rounded-2xl border py-1.5",
                                    children: l.map(s => s.type === "existing" ? e.jsx(le, {
                                        workspace: s.w,
                                        onOpen: () => {
                                            h(), v("open_workspace")
                                        }
                                    }, s.w.id) : e.jsx(ne, {
                                        workspace: s.w,
                                        isLoading: N.isPending && U === s.w.id,
                                        onHoverRequest: i => {
                                            O(i)
                                        },
                                        onRequestAccess: i => {
                                            g(i.id), J(i), N.mutate(i.id)
                                        }
                                    }, s.w.id))
                                })
                            })]
                        }), a === "discoverable" && b === 0 && !d && e.jsx("div", {
                            className: "w-full",
                            children: e.jsx("div", {
                                className: "flex w-full flex-col rounded-2xl border py-20",
                                children: e.jsx("div", {
                                    className: "text-token-text-secondary text-center text-sm",
                                    children: e.jsx(L, u({}, p.noWorkspacesToJoin))
                                })
                            })
                        }), t === "dismissible" && e.jsx("div", {
                            className: "mt-4 w-full",
                            children: e.jsx(he, {
                                fullWidth: !0,
                                onClick: () => {
                                    h(), v("close"), o()
                                },
                                children: e.jsx(L, u({}, p.done))
                            })
                        }), e.jsx(re, {
                            showHiddenWorkspacesNote: D
                        })]
                    })
                })]
            })
        })
    })
}
export {
    Ee as
    default
};
//# sourceMappingURL=k7bax4ffse9ora8u.js.map