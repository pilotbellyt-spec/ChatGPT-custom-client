const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/ebc4iyfg14nu1gw4.js", "assets/gy1lpvuoewmzh42c.js", "assets/fg33krlcm0qyi6yw.js", "assets/jed1ux7qibe55pmj.js", "assets/h1em0bjkpkjv8ykw.js", "assets/nfccle6oyncifphl.js", "assets/hu1bt0oauegdhua6.js", "assets/k15yxxoybkkir2ou.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/conversation-small-332fs9rk.css", "assets/kyiatma5dshbc5mg.js"]))) => i.map(i => d[i]);
var nt = Object.defineProperty,
    ot = Object.defineProperties;
var it = Object.getOwnPropertyDescriptors;
var ge = Object.getOwnPropertySymbols;
var De = Object.prototype.hasOwnProperty,
    Fe = Object.prototype.propertyIsEnumerable;
var Ae = (t, e, a) => e in t ? nt(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: a
    }) : t[e] = a,
    A = (t, e) => {
        for (var a in e || (e = {})) De.call(e, a) && Ae(t, a, e[a]);
        if (ge)
            for (var a of ge(e)) Fe.call(e, a) && Ae(t, a, e[a]);
        return t
    },
    q = (t, e) => ot(t, it(e));
var fe = (t, e) => {
    var a = {};
    for (var o in t) De.call(t, o) && e.indexOf(o) < 0 && (a[o] = t[o]);
    if (t != null && ge)
        for (var o of ge(t)) e.indexOf(o) < 0 && Fe.call(t, o) && (a[o] = t[o]);
    return a
};
import {
    _ as He,
    c as F,
    j as s,
    r as D,
    i as rt,
    M as T,
    e as lt,
    f as ct
} from "./fg33krlcm0qyi6yw.js";
import {
    bh as Ce,
    dF as me,
    dH as qe,
    f1 as dt,
    l as K,
    c0 as Ke,
    bX as ut,
    f4 as re,
    f5 as ie,
    kz as gt,
    fN as Re,
    eh as Qe,
    d as je,
    b as ke,
    hv as ft,
    P as le,
    $ as mt,
    iU as Me,
    en as ht,
    fF as pt,
    hN as xt,
    dQ as _t,
    a9 as Oe,
    gM as yt,
    e7 as Mt,
    kn as Tt,
    kH as ve,
    i as Ye,
    ba as bt,
    eo as Xe,
    f$ as Et,
    bJ as jt,
    o as vt,
    sF as Ct,
    sG as Rt,
    _ as kt,
    oX as St,
    h7 as ze,
    fc as It,
    sH as wt,
    fz as Nt,
    mO as Lt,
    e4 as Pt,
    fh as Be
} from "./dykg4ktvbu3mhmdo.js";
import {
    b0 as At,
    gO as Ze,
    bM as Dt,
    gP as Ft,
    gQ as Ot,
    gR as Bt,
    gS as Ut,
    gT as Ue,
    ak as Gt,
    gU as Wt,
    gV as $t,
    gW as Vt,
    gX as Ht,
    gY as qt,
    gZ as Kt,
    g_ as Qt,
    g$ as Yt,
    h0 as Xt,
    h1 as zt,
    h2 as Zt,
    h3 as Jt,
    h4 as es,
    h5 as ts,
    aC as ss,
    h6 as as,
    aj as Te,
    ai as be,
    eq as Ee,
    h7 as ns,
    h8 as os,
    h9 as is,
    ha as rs,
    hb as ls,
    hc as cs,
    aY as ds,
    hd as us,
    he as gs
} from "./k15yxxoybkkir2ou.js";
const fs = Ce(() => He(() =>
        import ("./ebc4iyfg14nu1gw4.js").then(t => t.i), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]))),
    ms = t => {
        "use forget";
        const e = F.c(40),
            {
                errorState: a,
                nodeId: o,
                conversation: n,
                isFeedbackEnabled: l,
                isUserTurn: r,
                isCompletionInProgress: u
            } = t,
            d = u === void 0 ? !1 : u;
        let g;
        e[0] !== n.id || e[1] !== o ? (g = me.isLastActorMessage(qe(n.id), o), e[0] = n.id, e[1] = o, e[2] = g) : g = e[2];
        const x = g,
            y = a.canRetry && x && !d,
            b = a.flagSeverity === "info" && a.errCode === dt.NetworkErrorWithReconnection;
        if (r) {
            const w = a.flagSeverity === "danger" && "text-token-text-error",
                i = a.flagSeverity === "warning" && "text-orange-600",
                m = (a.flagSeverity === "info" || !a.flagSeverity) && "text-token-text-secondary";
            let E;
            e[3] !== w || e[4] !== i || e[5] !== m ? (E = K("flex max-w-[var(--user-chat-width,70%)] flex-row-reverse items-start gap-1 text-start text-sm", w, i, m), e[3] = w, e[4] = i, e[5] = m, e[6] = E) : E = e[6];
            let k;
            e[7] !== b ? (k = b ? s.jsx(Ke, {
                className: "icon-lg mt-[0.0625em]"
            }) : s.jsx(ut, {
                className: "icon mt-[0.0625em]"
            }), e[7] = b, e[8] = k) : k = e[8];
            let h;
            e[9] !== n || e[10] !== a || e[11] !== l ? (h = s.jsx(Ge, {
                errorState: a,
                conversation: n,
                isFeedbackEnabled: l
            }), e[9] = n, e[10] = a, e[11] = l, e[12] = h) : h = e[12];
            let _;
            e[13] !== E || e[14] !== k || e[15] !== h ? (_ = s.jsxs("div", {
                className: E,
                children: [k, h]
            }), e[13] = E, e[14] = k, e[15] = h, e[16] = _) : _ = e[16];
            let S;
            e[17] !== n || e[18] !== a || e[19] !== y || e[20] !== o ? (S = y && s.jsx($e, {
                conversation: n,
                nodeId: o,
                errorState: a
            }), e[17] = n, e[18] = a, e[19] = y, e[20] = o, e[21] = S) : S = e[21];
            let N;
            return e[22] !== S || e[23] !== _ ? (N = s.jsxs("div", {
                className: "flex w-full flex-col items-end justify-between gap-2",
                children: [_, S]
            }), e[22] = S, e[23] = _, e[24] = N) : N = e[24], N
        }
        const I = a == null ? void 0 : a.flagSeverity;
        let c;
        e[25] !== n || e[26] !== a || e[27] !== y || e[28] !== o ? (c = y && s.jsx($e, {
            conversation: n,
            nodeId: o,
            errorState: a
        }), e[25] = n, e[26] = a, e[27] = y, e[28] = o, e[29] = c) : c = e[29];
        const C = b ? Cs : void 0;
        let f;
        e[30] !== n || e[31] !== a || e[32] !== l ? (f = s.jsx("div", {
            className: "flex flex-row items-center justify-between gap-4",
            children: s.jsx("div", {
                className: "min-w-0 text-pretty break-words whitespace-pre-wrap",
                children: s.jsx(Ge, {
                    errorState: a,
                    conversation: n,
                    isFeedbackEnabled: l
                })
            })
        }), e[30] = n, e[31] = a, e[32] = l, e[33] = f) : f = e[33];
        let M;
        return e[34] !== b || e[35] !== I || e[36] !== c || e[37] !== C || e[38] !== f ? (M = s.jsx(At, {
            type: I,
            className: "mb-2 w-fit max-w-full self-start",
            primaryAction: c,
            customIcon: C,
            iconCentered: b,
            children: f
        }), e[34] = b, e[35] = I, e[36] = c, e[37] = C, e[38] = f, e[39] = M) : M = e[39], M
    },
    Ge = t => {
        "use forget";
        const e = F.c(35),
            {
                errorState: a,
                conversation: o,
                isFeedbackEnabled: n
            } = t,
            {
                errCode: l,
                errMessage: r
            } = a,
            [u, d] = D.useState(!1);
        let g;
        e[0] !== r ? (g = r != null ? ps(r) : 0, e[0] = r, e[1] = g) : g = e[1];
        const x = !1;
        let y;
        e[2] !== r ? (y = i => {
            r && ft(r, void 0, i)
        }, e[2] = r, e[3] = y) : y = e[3];
        const b = y;
        let I;
        e[4] !== b || e[5] !== x ? (I = null, e[4] = b, e[5] = x, e[6] = I) : I = e[6];
        let c, C;
        e[7] !== o || e[8] !== l || e[9] !== r ? (c = () => {
            var i, m;
            le.logEvent("message_error_notice_shown", {
                conversationId: (i = o.serverId$()) != null ? i : o.id,
                errorCode: l != null ? l : "unknown",
                errorMessage: r != null ? r : "unknown"
            }), mt.logEvent("chatgpt_message_error_notice_shown", null, {
                conversationId: (m = o.serverId$()) != null ? m : o.id,
                errorCode: l != null ? l : "unknown",
                errorMessage: r != null ? r : "unknown"
            })
        }, C = [l, r, o], e[7] = o, e[8] = l, e[9] = r, e[10] = c, e[11] = C) : (c = e[10], C = e[11]), D.useEffect(c, C);
        let f;
        e[12] === Symbol.for("react.memo_cache_sentinel") ? (f = () => {
            d(!1)
        }, e[12] = f) : f = e[12];
        let M;
        e[13] !== r ? (M = [r], e[13] = r, e[14] = M) : M = e[14], D.useEffect(f, M);
        const w = Rs;
        switch (l) {
            case ie.ContentPolicy:
                {
                    let i;
                    return e[15] !== n ? (i = s.jsx(bs, {
                        isFeedbackEnabled: n
                    }), e[15] = n, e[16] = i) : i = e[16],
                    i
                }
            case ie.BioSafetyContentPolicy:
                {
                    let i;
                    return e[17] === Symbol.for("react.memo_cache_sentinel") ? (i = s.jsx(Es, {}), e[17] = i) : i = e[17],
                    i
                }
            case ie.ModelIncompatibility:
                {
                    let i;
                    return e[18] === Symbol.for("react.memo_cache_sentinel") ? (i = s.jsx(T, {
                        id: "cyOWhN",
                        defaultMessage: "Your request was flagged as potentially violating our usage policy. Please try again with a different prompt."
                    }), e[18] = i) : i = e[18],
                    i
                }
            case ie.ContentOrTos:
                {
                    let i;
                    return e[19] !== n ? (i = s.jsx(Ms, {
                        isFeedbackEnabled: n
                    }), e[19] = n, e[20] = i) : i = e[20],
                    i
                }
            case ie.ContentRegurgitation:
                {
                    let i;
                    return e[21] === Symbol.for("react.memo_cache_sentinel") ? (i = s.jsx(Ts, {}), e[21] = i) : i = e[21],
                    i
                }
            case re.ModelCapExceeded:
                {
                    let i;
                    return e[22] !== o ? (i = s.jsx(xs, {
                        conversation: o
                    }), e[22] = o, e[23] = i) : i = e[23],
                    i
                }
            case re.HistoryDisabledConversationNotFound:
                {
                    let i;
                    return e[24] === Symbol.for("react.memo_cache_sentinel") ? (i = s.jsx(T, {
                        id: "TextMessageDisplay.historyDisabledConversationMissing",
                        defaultMessage: "Sorry, conversations created when Chat History is off expire after 6 hours of inactivity. Please start a new conversation to continue using ChatGPT."
                    }), e[24] = i) : i = e[24],
                    i
                }
            case re.MissingLastCompletion:
            case re.InterruptionServerError:
                {
                    let i;
                    return e[25] === Symbol.for("react.memo_cache_sentinel") ? (i = s.jsx(T, {
                        id: "TextMessageDisplay.somethingWentWrong",
                        defaultMessage: "Something went wrong."
                    }), e[25] = i) : i = e[25],
                    i
                }
            default:
                {
                    if (!r) return null;
                    let i;
                    return e[33] !== r ? (i = w(r), e[33] = r, e[34] = i) : i = e[34],
                    i
                }
        }
    },
    hs = /\r\n|\r|\n/;

function ps(t) {
    if (!t) return 0;
    const e = t.split(hs);
    return e.length === 0 ? 0 : e[e.length - 1] === "" ? e.length - 1 : e.length
}

function xs(t) {
    "use forget";
    const e = F.c(6),
        {
            conversation: a
        } = t,
        o = Ze(ys);
    let n;
    e[0] !== o ? (n = Ut(o), e[0] = o, e[1] = n) : n = e[1];
    const l = n,
        r = Re(a.id, _s),
        u = r && r.kind !== Qe.PrimaryAssistant;
    if (o) {
        let g;
        return e[2] === Symbol.for("react.memo_cache_sentinel") ? (g = s.jsx(T, {
            id: "TextMessageDisplay.gptUsageCapExceededExpired",
            defaultMessage: "You previously reached your usage cap for GPT-4, but you can now try sending your message again"
        }), e[2] = g) : g = e[2], g
    }
    let d;
    return e[3] !== l || e[4] !== u ? (d = s.jsx("span", {
        children: u != null ? s.jsx(T, {
            id: "TextMessageDisplay.gptUsageCapExceededCustomFeature",
            defaultMessage: "You've reached the current usage cap for GPT-4, please try again {formattedTime}. <link>Learn more</link>",
            values: {
                link: We,
                formattedTime: l
            }
        }) : s.jsx(T, {
            id: "TextMessageDisplay.gptUsageCapExceeded",
            defaultMessage: "You've reached the current usage cap for GPT-4. You can continue with the default model now, or try again {formattedTime}. <link>Learn more</link>",
            values: {
                link: We,
                formattedTime: l
            }
        })
    }), e[3] = l, e[4] = u, e[5] = d) : d = e[5], d
}

function _s(t) {
    return t == null ? void 0 : t.mode
}

function ys(t) {
    return t.isoDate
}
const We = t => s.jsx("a", {
    href: "https://share.hsforms.com/16d0ZZVM3QZirXnCD_q7u1Q4sk30",
    target: "_blank",
    rel: "noreferrer",
    className: "underline hover:no-underline",
    children: t
});

function Ms(t) {
    "use forget";
    const e = F.c(10),
        {
            isFeedbackEnabled: a
        } = t,
        o = a ? "font-semibold" : "";
    let n;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (n = s.jsx(T, {
        id: "TextMessageDisplay.contentOrTosViolationNoFeedback",
        defaultMessage: "This content may violate our <termsLink>Terms of Use</termsLink> or <contentPolicyLink>usage policies</contentPolicyLink>.",
        values: {
            contentPolicyLink: Je,
            termsLink: js
        }
    }), e[0] = n) : n = e[0];
    let l;
    e[1] !== o ? (l = s.jsx("div", {
        className: o,
        children: n
    }), e[1] = o, e[2] = l) : l = e[2];
    let r;
    e[3] !== a ? (r = a && s.jsx(T, {
        id: "TextMessageDisplay.contentPolicyFeedback",
        defaultMessage: "Did we get it wrong? Please tell us by giving this response a thumbs down."
    }), e[3] = a, e[4] = r) : r = e[4];
    let u;
    e[5] !== r ? (u = s.jsx("div", {
        children: r
    }), e[5] = r, e[6] = u) : u = e[6];
    let d;
    return e[7] !== l || e[8] !== u ? (d = s.jsxs("div", {
        children: [l, u]
    }), e[7] = l, e[8] = u, e[9] = d) : d = e[9], d
}

function Ts() {
    "use forget";
    const t = F.c(2);
    let e;
    t[0] === Symbol.for("react.memo_cache_sentinel") ? (e = s.jsx("div", {
        className: "font-semibold",
        children: s.jsx(T, {
            id: "kAMQnd",
            defaultMessage: "ChatGPT isn't designed to provide this type of content."
        })
    }), t[0] = e) : e = t[0];
    let a;
    return t[1] === Symbol.for("react.memo_cache_sentinel") ? (a = s.jsxs("div", {
        children: [e, s.jsx("div", {
            children: s.jsx(T, {
                id: "fQ0JYv",
                defaultMessage: "Read the <modelSpecLink>Model Spec</modelSpecLink> for more on how ChatGPT handles creators' content.",
                values: {
                    modelSpecLink: et
                }
            })
        })]
    }), t[1] = a) : a = t[1], a
}

function bs(t) {
    "use forget";
    const e = F.c(10),
        {
            isFeedbackEnabled: a
        } = t,
        o = a ? "font-semibold" : "";
    let n;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (n = s.jsx(T, {
        id: "TextMessageDisplay.contentPolicyViolationNoFeedback",
        defaultMessage: "This content may violate our <contentPolicyLink>usage policies</contentPolicyLink>.",
        values: {
            contentPolicyLink: Je
        }
    }), e[0] = n) : n = e[0];
    let l;
    e[1] !== o ? (l = s.jsx("div", {
        className: o,
        children: n
    }), e[1] = o, e[2] = l) : l = e[2];
    let r;
    e[3] !== a ? (r = a && s.jsx(T, {
        id: "TextMessageDisplay.contentPolicyFeedback",
        defaultMessage: "Did we get it wrong? Please tell us by giving this response a thumbs down."
    }), e[3] = a, e[4] = r) : r = e[4];
    let u;
    e[5] !== r ? (u = s.jsx("div", {
        children: r
    }), e[5] = r, e[6] = u) : u = e[6];
    let d;
    return e[7] !== l || e[8] !== u ? (d = s.jsxs("div", {
        children: [l, u]
    }), e[7] = l, e[8] = u, e[9] = d) : d = e[9], d
}

function Es() {
    "use forget";
    const t = F.c(2);
    let e;
    t[0] === Symbol.for("react.memo_cache_sentinel") ? (e = s.jsx("div", {
        className: "font-semibold",
        children: s.jsx(T, {
            id: "TextMessageDisplay.bioSafetyContentPolicyViolationNoFeedback1",
            defaultMessage: "We've limited access to this content for safety reasons."
        })
    }), t[0] = e) : e = t[0];
    let a;
    return t[1] === Symbol.for("react.memo_cache_sentinel") ? (a = s.jsxs("div", {
        children: [e, s.jsx("div", {
            children: s.jsx(T, {
                id: "TextMessageDisplay.bioSafetyContentPolicyViolationNoFeedback2",
                defaultMessage: "This type of information may be used to benefit or to harm people. We are continuously refining our work in this area, and you can read more about our approach in our <bioSafetyBlogPostLink>blog post</bioSafetyBlogPostLink> and <modelSpecLink>Model Spec</modelSpecLink>.",
                values: {
                    bioSafetyBlogPostLink: vs,
                    modelSpecLink: et
                }
            })
        })]
    }), t[1] = a) : a = t[1], a
}
const Je = t => s.jsx(he, {
        href: "https://openai.com/policies/usage-policies",
        children: t
    }),
    js = t => s.jsx(he, {
        href: "https://openai.com/policies/terms-of-use",
        children: t
    }),
    et = t => s.jsx(he, {
        href: "https://model-spec.openai.com",
        children: t
    }),
    vs = t => s.jsx(he, {
        href: "https://openai.com/index/preparing-for-future-ai-capabilities-in-biology/",
        children: t
    }),
    he = t => {
        "use forget";
        const e = F.c(3),
            {
                href: a,
                children: o
            } = t;
        let n;
        return e[0] !== o || e[1] !== a ? (n = s.jsx("a", {
            target: "_blank",
            rel: "noreferrer",
            href: a,
            className: "underline hover:no-underline",
            children: o
        }), e[0] = o, e[1] = a, e[2] = n) : n = e[2], n
    },
    $e = t => {
        "use forget";
        const e = F.c(22),
            {
                conversation: a,
                nodeId: o,
                errorState: n
            } = t,
            l = ke(),
            r = rt();
        let u;
        e[0] !== a.id ? (u = {
            clientThreadId: a.id
        }, e[0] = a.id, e[1] = u) : u = e[1];
        const d = gt(u),
            g = (n == null ? void 0 : n.errCode) === re.ModelCapExceeded,
            x = Ze(ks),
            y = g && !!x,
            b = Re(a.id, Ss),
            I = b && b.kind !== Qe.PrimaryAssistant,
            c = y && !I,
            C = y && I,
            f = je(a.serverId$);
        let M;
        e[2] !== a || e[3] !== l || e[4] !== (n == null ? void 0 : n.errCode) || e[5] !== g || e[6] !== o || e[7] !== d || e[8] !== c ? (M = h => {
            var S;
            g ? le.logEventWithStatsig("chatgpt_regenerate_due_to_rate_limit_button_clicked", "chatgpt_regenerate_due_to_rate_limit_button_clicked", q(A({}, Me({
                clientThreadId: a.id
            })), {
                useDefaultModel: c ? "true" : "false"
            })) : le.logEventWithStatsig("chatgpt_regenerate_due_to_error_button_clicked", "chatgpt_regenerate_due_to_error_button_clicked", q(A({}, Me({
                clientThreadId: a.id
            })), {
                inlineButton: "true",
                errorCode: (S = n == null ? void 0 : n.errCode) != null ? S : ""
            }));
            const _ = ht(() => pt(l).id);
            c && _ ? (xt(a, _), d({
                sourceEvent: h,
                nodeId: o,
                requestedModelId: _
            })) : d({
                sourceEvent: h,
                nodeId: o
            })
        }, e[2] = a, e[3] = l, e[4] = n == null ? void 0 : n.errCode, e[5] = g, e[6] = o, e[7] = d, e[8] = c, e[9] = M) : M = e[9];
        const w = M;
        let i;
        e[10] !== a.id || e[11] !== r ? (i = () => {
            const h = me.getParentPromptNode(qe(a.id)),
                _ = h != null && h.message ? _t(h.message) : "";
            le.logEventWithStatsig("chatgpt_edit_clicked_no_server_thread_id", "chatgpt_edit_clicked_no_server_thread_id", A({}, Me({
                clientThreadId: a.id
            }))), le.logNewChatButtonClicked({
                location: "Message Error"
            }), Dt(r, {
                params: new URLSearchParams({
                    prompt: _
                })
            })
        }, e[10] = a.id, e[11] = r, e[12] = i) : i = e[12];
        const m = i;
        if (!f) {
            let h;
            e[13] === Symbol.for("react.memo_cache_sentinel") ? (h = s.jsx(T, {
                id: "MessageError.buttonRetryResponse",
                defaultMessage: "Retry"
            }), e[13] = h) : h = e[13];
            let _;
            return e[14] !== m ? (_ = s.jsx(Oe, {
                as: "button",
                color: "secondary",
                onClick: m,
                icon: Ft,
                children: h
            }), e[14] = m, e[15] = _) : _ = e[15], _
        }
        if (!f) return null;
        let E;
        e[16] !== c ? (E = c ? s.jsx(T, {
            id: "MessageError.buttonUseDefaultModel",
            defaultMessage: "Use default model"
        }) : s.jsx(T, {
            id: "MessageError.buttonRetryResponse",
            defaultMessage: "Retry"
        }), e[16] = c, e[17] = E) : E = e[17];
        let k;
        return e[18] !== C || e[19] !== w || e[20] !== E ? (k = s.jsx(Oe, {
            as: "button",
            color: "secondary",
            disabled: C,
            onClick: w,
            icon: Ot,
            "data-testid": "regenerate-thread-error-button",
            children: E
        }), e[18] = C, e[19] = w, e[20] = E, e[21] = k) : k = e[21], k
    };

function Cs(t) {
    return s.jsx(Ke, q(A({}, t), {
        className: "icon-lg"
    }))
}

function Rs(t) {
    return s.jsx(fs, {
        rehypePlugins: [
            [Bt, {
                target: "_new",
                rel: "noopener noreferrer"
            }]
        ],
        className: "markdown break-words [&>:last-child]:mb-0",
        children: t
    })
}

function ks(t) {
    return t.isoDate
}

function Ss(t) {
    return t == null ? void 0 : t.mode
}
const Is = 300,
    ws = 6,
    Ns = 8.5,
    Ls = Ce(() => He(() =>
        import ("./kyiatma5dshbc5mg.js"), __vite__mapDeps([11, 2, 8, 9, 7, 10])).then(t => t.TextMessageImageGroup));
Ce(async () => () => null);

function Vs({
    attachments: t,
    citations: e,
    contentReferences: a,
    className: o,
    conversation: n,
    displayParts: l,
    isCompletionInProgress: r,
    hasActiveRequest: u,
    id: d,
    isActivelyStreaming: g,
    isUserTurn: x,
    isFinalUserTurn: y,
    turnIndex: b,
    isFeedbackEnabled: I,
    messages: c,
    parts: C,
    prevGroupedMessageType: f,
    prevGroupedMessages: M,
    citableMessages: w,
    size: i = "medium",
    errorState: m,
    superWidgetContent: E
}) {
    var O, te, se, ae, ne, oe, p, j, $, V, B, U, G, v, L;
    const k = ke(),
        h = D.useRef(!1),
        _ = c.length > 1,
        S = C.some(R => R !== ""),
        N = !S && ((se = (te = (O = c[0].metadata) == null ? void 0 : O.content_references) == null ? void 0 : te.length) != null ? se : 0) === 0,
        z = (oe = (ae = c[0].metadata) == null ? void 0 : ae.targeted_reply_label) != null ? oe : (ne = c[0].metadata) == null ? void 0 : ne.targeted_reply,
        Z = (p = c[0].metadata) == null ? void 0 : p.targeted_reply_icon,
        J = (j = c[0].metadata) == null ? void 0 : j.targeted_reply_source_message_id,
        pe = ($ = c[0].metadata) == null ? void 0 : $.targeted_reply_source_range,
        ce = (V = c[0].metadata) == null ? void 0 : V.is_visually_hidden_from_conversation;
    D.useEffect(() => {
        var P, H;
        const R = c[0];
        if (((P = R.author.metadata) == null ? void 0 : P.real_author) === "tool:".concat(Mt.SEARCHGPT) && S) {
            const W = (H = R.metadata) == null ? void 0 : H.search_source;
            Ue.logEvent("Search Tool Request Time To First Text Token", n.id, R.id, {
                search_source: W
            }, () => {
                W === Tt.InstantQuery && Gt.logEvent("Search Tool Page Load Time To First Text Token", {
                    message_id: R.id,
                    search_source: W
                })
            })
        }
    }, [n.id, S, c]), D.useEffect(() => {
        if (!N) switch (f) {
            case ve.Browsing:
                Ue.logEvent("Browsing Time To First Text Token", n.id, c[0].id);
                break
        }
    }, [N, c, n.id, f]);
    const xe = Ye(k),
        de = bt(Xe);
    Wt(de, x, S);
    const ee = Et(),
        Q = jt(k, "3253785454").get("should_animate_user_message", !1),
        _e = Re(n.id, R => {
            if (!Q || !y || !u || ee || h.current || xe) return !1;
            const P = ze(c, H => !It(H));
            return P != null && me.getNode(R, P.id).children.length === 1 ? (h.current = !0, !0) : !1
        }),
        ue = (B = c[0].metadata) == null ? void 0 : B.from_shopping_app_decision_boundary_classifier;
    return s.jsxs("div", {
        "data-message-author-role": c[0].author.role,
        "data-message-id": c[0].id,
        dir: "auto",
        className: K(o, "text-message relative flex w-full flex-col items-end gap-2 text-start break-words whitespace-normal [.text-message+&]:mt-1", _e && es.slideUp),
        "data-message-model-slug": (U = c[0].metadata) == null ? void 0 : U.model_slug,
        children: [z && s.jsx($t, {
            label: z,
            icon: (() => {
                switch (Z) {
                    case "product_tag":
                        return s.jsx(qt, {
                            className: "icon"
                        });
                    default:
                        return s.jsx(Ht, {
                            className: "icon"
                        })
                }
            })(),
            as: J ? "button" : "div",
            onClick: J ? () => Vt({
                messageId: J,
                messageRange: pe,
                shouldHighlight: !0,
                scrollMarginBottom: "100px"
            }) : void 0
        }), x && s.jsx(Kt, {
            messages: c,
            clientThreadId: n.id
        }), x && s.jsx(Qt, {
            hint: (v = (G = c[0]) == null ? void 0 : G.metadata) == null ? void 0 : v.retrieval_hint_file_data
        }), x && !1, s.jsx(Yt, {
            messages: c,
            clientThreadId: n.id
        }), s.jsx(Xt, {
            messages: c,
            clientThreadId: n.id
        }), !ce && s.jsx(Ps, {
            parts: C,
            attachments: t,
            isUserTurn: x,
            isCompletionInProgress: r,
            turnIndex: b,
            displayParts: l,
            isActivelyStreaming: g,
            shouldHideContent: !!(m != null && m.shouldHideContent) && !I,
            conversation: n,
            id: d,
            isEmpty: N,
            prevGroupedMessageType: f,
            prevGroupedMessages: M,
            citableMessages: w,
            flagSeverity: m == null ? void 0 : m.flagSeverity,
            messages: c,
            citations: e,
            contentReferences: a,
            size: i,
            isOptimisticPlaceholder: (L = c[0].clientMetadata) == null ? void 0 : L.isOptimisticPlaceholder,
            superWidgetContent: E
        }), m && s.jsx(ms, {
            errorState: m,
            nodeId: d,
            isFeedbackEnabled: I,
            conversation: n,
            isUserTurn: x,
            isCompletionInProgress: r
        }), ue && s.jsx(zt, {
            conversation: n,
            messages: c
        }), s.jsx(Zt, {
            message: _ ? void 0 : c[0]
        }), !x && !g && M && f === ve.SearchResult && s.jsx(Jt, {
            messages: M
        })]
    })
}

function Ps({
    conversation: t,
    id: e,
    displayParts: a,
    turnIndex: o,
    isActivelyStreaming: n,
    shouldHideContent: l,
    isEmpty: r,
    prevGroupedMessageType: u,
    prevGroupedMessages: d,
    citableMessages: g,
    messages: x,
    citations: y,
    contentReferences: b,
    size: I,
    isUserTurn: c,
    parts: C,
    attachments: f,
    isWithinFirstAssistantTurns: M,
    superWidgetContent: w,
    isOptimisticPlaceholder: i
}) {
    var se, ae, ne, oe;
    const m = ke(),
        E = lt(),
        k = Ye(m),
        h = ts(),
        _ = je(() => Xe(m)),
        S = vt(m, "84110054"),
        N = M && _,
        z = D.useRef(!1),
        Z = (se = x[0].metadata) == null ? void 0 : se.serialization_metadata,
        J = (oe = (ne = (ae = x[0].metadata) == null ? void 0 : ae.image_results) == null ? void 0 : ne.length) != null ? oe : 0,
        pe = D.useMemo(() => ({
            clientThreadId: t.id,
            messageId: e,
            turnIndex: o
        }), [t.id, e, o]),
        {
            toggleThreadSidebar: ce
        } = ss(),
        xe = D.useCallback((p, j) => {
            ce({
                type: "searchSources",
                scrollToHeader: j,
                turnIndex: o,
                messageId: e
            })
        }, [o, e, ce]),
        de = s.jsx(gs, {
            parts: C,
            attachments: f,
            isUserTurn: c,
            conversation: t
        }, "files-and-tables"),
        ee = !!(f != null && f.length || a.some(p => p.type === "images")),
        Q = je(() => {
            var j;
            return (j = Ds(t)[o - 1]) != null ? j : 0
        }),
        _e = as();

    function ue(p, j) {
        var Ie, we, Ne, Le, Pe;
        const $ = u === ve.CodeInterpreter ? d : void 0,
            {
                text: V,
                contentReferences: B
            } = is(j, y != null ? y : [], b != null ? b : []);
        let U = B;
        _e && (U = B.filter(Y => Y.type !== "attribution"));
        const G = Ct(V, U, n ? void 0 : $, !1, n, g);
        let {
            processedText: v
        } = G;
        const {
            displayedContentReferences: L
        } = G;
        v.includes(Rt) && !z.current && !n && (z.current = !0, kt.addError(new Error("Failed replaceTextWithDirectives"), {
            text: v,
            displayedContentReferences: L
        }));
        let R = [];
        const P = x[0];
        R = (we = (Ie = P.metadata) == null ? void 0 : Ie[rs]) != null ? we : [], R.length && (v = ls(v, R));
        const H = (Ne = P.metadata) == null ? void 0 : Ne.message_locale,
            W = x.find(Y => Y.id === e),
            tt = cs(W),
            st = !!((Le = W == null ? void 0 : W.metadata) != null && Le.n7jupd_message),
            at = ds(m) ? "streaming-animation block-entry-animation" : "streaming-animation";
        let Se = v ? at : "result-thinking";
        N && (Se += " ms-1");
        let ye = s.jsx(Ee, {
            conversation: t,
            componentOverrides: st ? Bs : tt ? Os : null,
            messageId: e,
            size: I,
            isActivelyStreaming: n,
            className: K(n && Se),
            isDeepResearchResultMessage: (Pe = P.metadata) == null ? void 0 : Pe.is_async_task_result_message,
            children: v === "" ? "&#8203;" : v
        });
        if (H != null) {
            const Y = St(H);
            Y != null && (ye = s.jsx(wt, {
                locale: Y,
                children: ye
            }))
        }
        return s.jsx(us.Provider, {
            value: {
                analyticsMetadata: pe,
                message: P,
                contentReferences: L,
                n7jupdCrefs: R,
                onShowSearchResults: xe,
                numImageResults: J,
                isActivelyStreaming: n,
                useSafeUrls: !0,
                clientThreadId: t.id,
                superWidgetContent: w
            },
            children: ye
        }, p)
    }
    const O = a.map((p, j) => {
            var $, V, B, U, G;
            if (p.type === "transcription") {
                if (!c) return l ? null : ue(j, p.text);
                let v = null;
                if (l) v = s.jsx("span", {
                    className: "italic opacity-30",
                    children: s.jsx(T, A({}, X.contentRemoved))
                });
                else {
                    const L = p.text.trim(),
                        R = (($ = x[0]) == null ? void 0 : $.status) === "in_progress";
                    v = L.length === 0 ? s.jsx("span", {
                        className: "italic opacity-30",
                        children: s.jsx(Te, {
                            text: E.formatMessage(X.transcriptUnavailable),
                            customSymbolOffsets: void 0
                        })
                    }) : s.jsx("span", {
                        className: "italic opacity-65",
                        children: s.jsx(Te, {
                            text: R ? L : "“".concat(L, "”"),
                            customSymbolOffsets: void 0
                        })
                    })
                }
                return s.jsx(be, {
                    containsImagesOrAttachments: ee,
                    children: v
                }, j)
            } else if (p.type === "text") {
                if (!c) return i && Q > 0 ? s.jsx(Ee, {
                    className: K("loading-shimmer aria-busy", N && "ms-1"),
                    children: E.formatMessage(X.handlingImages, {
                        numSentImages: Q
                    })
                }, j) : !r && !l ? ue(j, p.text) : r && n && Q > 0 ? s.jsx(Ee, {
                    className: K("loading-shimmer aria-busy", N && "ms-1"),
                    children: E.formatMessage(X.handlingImages, {
                        numSentImages: Q
                    })
                }, j) : r && n ? S ? s.jsx(ns, {}) : s.jsx("div", {
                    className: K("result-streaming pulse aria-busy", N && "ms-1"),
                    children: s.jsx("span", {
                        children: s.jsx("pre", {})
                    })
                }, j) : null;
                const v = (B = (V = p.text.match(/\n|\r\n/g)) == null ? void 0 : V.length) != null ? B : 0,
                    L = k && !l && (p.text.length > Is || v >= ws),
                    R = L && h,
                    P = p.text ? s.jsx(Te, {
                        text: p.text,
                        customSymbolOffsets: Z == null ? void 0 : Z.custom_symbol_offsets
                    }) : null;
                return s.jsx(be, {
                    containsImagesOrAttachments: ee,
                    isMaxWidthMessage: R,
                    children: l ? s.jsx("span", {
                        className: "italic opacity-30",
                        children: s.jsx(T, A({}, X.contentRemoved))
                    }) : p.text ? s.jsxs(s.Fragment, {
                        children: [L && s.jsx(os, {
                            collapsedHeight: Ns,
                            children: P
                        }), !L && P]
                    }) : null
                }, j)
            } else if (p.type === "images") {
                const v = (G = (U = x[0].metadata) == null ? void 0 : U.attachments) != null ? G : [];
                return s.jsx(Ls, {
                    assets: p.imageAssets,
                    attachments: v,
                    isUserTurn: c,
                    isOptimisticPlaceholder: i,
                    clientThreadId: t.id
                }, j)
            } else return null
        }),
        te = a.findIndex(p => p.type === "text");
    if (te !== -1 ? O.splice(te, 0, de) : O.push(de), l && c) O.length = 0, O.push(s.jsx(be, {
        containsImagesOrAttachments: ee,
        children: s.jsx("span", {
            className: "italic opacity-30",
            children: s.jsx(T, A({}, X.contentRemoved))
        })
    }));
    else if (l && !c) return null;
    return s.jsx("div", {
        className: As(c),
        children: O
    })
}

function As(t) {
    return K("flex w-full flex-col gap-1 empty:hidden", t && "items-end rtl:items-start", !t && "first:pt-[1px]")
}
const X = ct({
        contentRemoved: {
            id: "textMessage.contentRemoved",
            defaultMessage: "Content removed"
        },
        handlingImages: {
            id: "textMessage.handlingImages",
            defaultMessage: "Analyzing {numSentImages, plural, one {image} other {images}}"
        },
        transcriptUnavailable: {
            id: "textMessage.transcriptUnavailable",
            defaultMessage: "Transcript Unavailable"
        }
    }),
    Ds = yt(t => {
        if (!t) return Ve;
        const e = me.getConversationTurns(t);
        return e.length ? e.map(a => {
            const o = ze(a.messages, Lt);
            return Fs(o)
        }) : Ve
    }, {
        equals: Nt
    }),
    Ve = [];

function Fs(t) {
    var e, a, o, n, l, r, u;
    return t ? t.content.content_type === Pt.MultimodalText ? t.content.parts.filter(d => typeof d != "string" && (d.content_type === Be.ImageAssetPointer || d.content_type === Be.Image)).length : (n = (o = (a = (e = t.metadata) == null ? void 0 : e.dalle) == null ? void 0 : a.from_client) == null ? void 0 : o.operation) != null && n.original_file_id ? 1 : (u = (r = (l = t.metadata) == null ? void 0 : l.attachments) == null ? void 0 : r.filter(d => {
        var g;
        return (g = d.mime_type) == null ? void 0 : g.startsWith("image/")
    }).length) != null ? u : 0 : 0
}
const Os = {
        del: t => {
            const n = t,
                {
                    node: e,
                    children: a
                } = n,
                o = fe(n, ["node", "children"]);
            return s.jsx("span", q(A({}, o), {
                children: a
            }))
        },
        a: t => {
            const n = t,
                {
                    node: e,
                    children: a
                } = n,
                o = fe(n, ["node", "children"]);
            return s.jsx("span", q(A({}, o), {
                children: a
            }))
        }
    },
    Bs = {
        del: t => {
            const n = t,
                {
                    node: e,
                    children: a
                } = n,
                o = fe(n, ["node", "children"]);
            return s.jsx("span", q(A({}, o), {
                children: a
            }))
        }
    };
export {
    Ps as D, ms as M, Bs as N, Vs as T, As as g
};
//# sourceMappingURL=ou2xm3xmri21t4zm.js.map