var j = Object.defineProperty,
    E = Object.defineProperties;
var P = Object.getOwnPropertyDescriptors;
var h = Object.getOwnPropertySymbols;
var w = Object.prototype.hasOwnProperty,
    A = Object.prototype.propertyIsEnumerable;
var p = (e, s, n) => s in e ? j(e, s, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : e[s] = n,
    d = (e, s) => {
        for (var n in s || (s = {})) w.call(s, n) && p(e, n, s[n]);
        if (h)
            for (var n of h(s)) A.call(s, n) && p(e, n, s[n]);
        return e
    },
    x = (e, s) => E(e, P(s));
import {
    r as l,
    j as t
} from "./fg33krlcm0qyi6yw.js";
import {
    o as N,
    b,
    fN as G,
    dF as I,
    e2 as M,
    kH as _,
    kl as k
} from "./dykg4ktvbu3mhmdo.js";
import {
    af as S,
    ag as v,
    ah as T,
    ai as R,
    aj as y,
    ak as F,
    al as U,
    am as K
} from "./k15yxxoybkkir2ou.js";
import {
    g as L
} from "./ou2xm3xmri21t4zm.js";
const B = l.createContext(void 0);

function V(e) {
    var i;
    const s = I.getConversationTurns(e),
        n = s.findIndex(a => a.role === M.Assistant);
    if (n === -1) return;
    const r = s[n];
    for (let a = 0; a < r.messageGroups.length; a++)
        if (r.messageGroups[a].type === _.SearchGPTQuery) {
            const o = r.messageGroups.slice(a + 1).find(({
                type: c
            }) => c === _.Text);
            if (o == null) return;
            const m = k(o.messages[0]);
            if (((i = m == null ? void 0 : m[0]) == null ? void 0 : i.type) === "navigation") return {
                turnIndex: n,
                navigationCitation: m[0],
                message: o.messages[0]
            }
        }
}

function C(e, s) {
    var r, i;
    if (s == null || e == null) return e;
    const n = new Set(e.domains.map(a => a.url));
    return x(d({}, e), {
        domains: [...e.domains, ...s.domains.filter(a => !n.has(a.url))],
        safe_urls: [...(r = e.safe_urls) != null ? r : [], ...(i = s.safe_urls) != null ? i : []]
    })
}

function H({
    query: e
}) {
    return t.jsx(S, {
        horizontalPadding: "standard",
        children: t.jsx(v, {
            className: T({
                isUserTurn: !0
            }),
            children: t.jsx("div", {
                className: L(!0),
                children: t.jsx(R, {
                    containsImagesOrAttachments: !1,
                    children: t.jsx(y, {
                        text: e
                    })
                })
            })
        })
    })
}

function J({
    clientThreadId: e,
    prefetchNavlink: s,
    clearPrefetchNavlink: n
}) {
    var c;
    const r = l.use(s),
        i = b(),
        a = N(i, "1032814809");
    l.useEffect(() => {
        window.__oai_SSR_NAVLINK && F.logEvent("Search Tool Page Load Time To Fast Nav SSR", {
            server_timing: r == null ? void 0 : r.timing
        }, window.__oai_SSR_NAVLINK)
    }, []), l.useEffect(() => {
        r == null && n()
    }, [r, n]);
    const u = l.useMemo(() => r == null ? null : x(d({}, r.navlink), {
            domains: r.navlink.domains.map(f => {
                var g;
                return x(d({}, f), {
                    subtitle: (g = f.subtitle) != null ? g : f.domain
                })
            })
        }), [r]),
        o = G(e, V),
        m = l.useMemo(() => C(u, o == null ? void 0 : o.navigationCitation), [o, u]);
    return r == null || m == null ? null : t.jsxs("div", {
        children: [t.jsx("div", {
            className: "mt-10",
            children: t.jsx(S, {
                horizontalPadding: "standard",
                children: t.jsxs(v, {
                    className: T({
                        isUserTurn: !1
                    }),
                    children: [t.jsx(U, {
                        clientThreadId: e,
                        turnIndex: (c = o == null ? void 0 : o.turnIndex) != null ? c : 2,
                        nextMessage: o == null ? void 0 : o.message,
                        navigationCitation: m
                    }), a ? t.jsxs("div", {
                        className: "text-token-text-secondary relative -top-2 flex justify-end gap-2 font-mono text-xs",
                        children: [t.jsxs("div", {
                            elementtiming: "navlink",
                            children: ["server: ", r.timing, "ms"]
                        }), t.jsx(z, {})]
                    }) : null]
                })
            })
        }), t.jsx(K, {
            scriptSrc: "requestAnimationFrame(()=>window.__oai_SSR_NAVLINK=window.__oai_SSR_NAVLINK||performance.now());"
        })]
    })
}

function z() {
    const [e, s] = l.useState(null);
    return l.useEffect(() => {
        const n = new PerformanceObserver(r => {
            r.getEntries().forEach(i => {
                if (i.identifier === "navlink") {
                    const a = i.renderTime;
                    s(u => u == null ? a : u)
                }
            })
        });
        return n.observe({
            type: "element",
            buffered: !0
        }), () => n.disconnect()
    }, []), e == null ? null : t.jsxs("span", {
        children: ["render: ", e, "ms"]
    })
}
export {
    B as P, H as a, J as b
};
//# sourceMappingURL=ib78f9d5brp6znzf.js.map