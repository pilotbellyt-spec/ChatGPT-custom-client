const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/dusl493dou663zd3.js", "assets/fg33krlcm0qyi6yw.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/k15yxxoybkkir2ou.js", "assets/conversation-small-332fs9rk.css", "assets/bjw7ec8hl3mvsw3f.js", "assets/j1yhxbhy635tgovp.js", "assets/kweqkb9nipntd4gy.js", "assets/of7p31pxtd9sx4co.js", "assets/d4j0ytwo9nyfcfx6.js"]))) => i.map(i => d[i]);
var Ct = Object.defineProperty;
var De = Object.getOwnPropertySymbols;
var Pt = Object.prototype.hasOwnProperty,
    Tt = Object.prototype.propertyIsEnumerable;
var Fe = (t, e, s) => e in t ? Ct(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : t[e] = s,
    q = (t, e) => {
        for (var s in e || (e = {})) Pt.call(e, s) && Fe(t, s, e[s]);
        if (De)
            for (var s of De(e)) Tt.call(e, s) && Fe(t, s, e[s]);
        return t
    };
import {
    c as N,
    i as we,
    e as Q,
    r as P,
    j as o,
    M as A,
    _ as Se,
    a as kt,
    l as Ke,
    f as Et
} from "./fg33krlcm0qyi6yw.js";
import {
    h9 as wt,
    b as G,
    d as O,
    l as J,
    gC as B,
    T as be,
    af as Lt,
    qt as Ve,
    aW as zt,
    aP as Mt,
    eo as Le,
    cU as he,
    hd as Pe,
    P as re,
    qp as Te,
    bh as xe,
    gt as Nt,
    nQ as Qe,
    m as At,
    nu as Dt,
    qz as Ft,
    I as je,
    hX as Ye,
    ib as Ze,
    uG as Gt,
    uH as $t,
    qy as Ot,
    w7 as Bt,
    he as Ut,
    g2 as X,
    hf as Ge,
    qo as ke,
    g9 as $e,
    bv as Ht,
    bg as Wt,
    ga as qt,
    iy as Rt,
    iC as Kt,
    gK as Xe,
    i8 as Vt,
    r8 as Qt,
    H as ze,
    qE as Yt,
    qj as Je,
    gJ as Me,
    iG as Zt,
    ic as et,
    ws as tt,
    o as Xt,
    or as Jt,
    Z as st,
    S as ot,
    ha as nt,
    hb as _e,
    j as it,
    gF as at,
    c_ as rt,
    ke as es,
    i as ts,
    i9 as Oe,
    qq as ss,
    fP as os,
    tH as ns,
    hh as is,
    mx as as,
    gy as rs,
    en as ls,
    hg as lt,
    aK as cs,
    oZ as ds,
    f as ct,
    h as dt,
    wt as ms,
    e as mt,
    od as fs,
    qu as Be,
    B as Ue,
    a9 as He,
    d8 as ft,
    $ as ut
} from "./dykg4ktvbu3mhmdo.js";
import {
    ck as us,
    b_ as gs,
    dr as Ie,
    bq as ie,
    jp as ps,
    bW as Ce,
    bp as gt,
    gN as pt,
    j_ as hs,
    qY as Ss,
    qZ as bs,
    q_ as ht,
    q$ as We,
    c4 as St,
    r0 as bt,
    mn as xs,
    bV as xt,
    da as js,
    r1 as vs,
    r2 as ys,
    r3 as _s,
    eN as Is,
    pQ as qe,
    Y as Cs,
    cx as Ps,
    dQ as Ts,
    cL as ks,
    r4 as Es,
    P as ge,
    r5 as ws,
    r6 as Ls,
    N as zs,
    r7 as Ms,
    r8 as Ee,
    r9 as Ns,
    ra as As,
    mA as Ds,
    mx as Fs,
    rb as Gs,
    rc as $s,
    rd as Os,
    re as Bs,
    Z as jt,
    a6 as Us,
    a9 as Hs,
    bv as vt,
    kX as Ws,
    ff as qs,
    rf as Rs,
    rg as Ks,
    rh as Vs,
    G as Qs
} from "./k15yxxoybkkir2ou.js";
import {
    useProjectsDragDropWithoutTargetProject as Ys,
    useProjectsDragDropWithTargetProject as Zs
} from "./f0qxu1nkng007y6r.js";
import {
    P as Xs,
    f as Js
} from "./f78b2oufkmgyeo1t.js";
import {
    S as eo
} from "./jlu292yvnhcpthaw.js";

function yt(t) {
    "use forget";
    const e = N.c(34),
        {
            hasProjects: s
        } = t,
        i = we(),
        n = Q(),
        a = G(),
        [c, r] = P.useState(!1),
        {
            onDropConversation: m,
            canDropConversation: u
        } = Ys("sidebar_header_plus");
    let p;
    e[0] !== s ? (p = {
        hasProjects: s
    }, e[0] = s, e[1] = p) : p = e[1];
    const {
        eligibleNux: l,
        announcementKey: d
    } = to(p), {
        canCreate: f
    } = wt();
    let x;
    e[2] !== a ? (x = () => Le(a), e[2] = a, e[3] = x) : x = e[3];
    const _ = O(x),
        b = c && "bg-token-bg-tertiary";
    let h;
    e[4] !== b ? (h = J(b), e[4] = b, e[5] = h) : h = e[5];
    let g;
    e[6] !== u ? (g = L => {
        u && (L.preventDefault(), r(!0))
    }, e[6] = u, e[7] = g) : g = e[7];
    let S;
    e[8] !== u || e[9] !== m ? (S = L => {
        u && (L.preventDefault(), L.stopPropagation(), r(!1), m())
    }, e[8] = u, e[9] = m, e[10] = S) : S = e[10];
    let j;
    e[11] === Symbol.for("react.memo_cache_sentinel") ? (j = () => {
        r(!1)
    }, e[11] = j) : j = e[11];
    const y = !f,
        I = (l == null ? void 0 : l.type) === "badge" ? us : gs;
    let T;
    e[12] !== d || e[13] !== a || e[14] !== _ || e[15] !== i ? (T = L => {
        _ && (L.preventDefault(), L.stopPropagation()), he(a, Ce, {
            onClose: () => Pe(a, Ce),
            onSuccess: D => {
                D && (i("/g/".concat(D, "/project")), Pe(a, Ce))
            }
        }), d && gt(a, d), re.logEventWithStatsig("Projects: Create Open", "chatgpt_web_projects_create_open", {
            source: "sidebar_row_button"
        })
    }, e[12] = d, e[13] = a, e[14] = _, e[15] = i, e[16] = T) : T = e[16];
    const z = (l == null ? void 0 : l.type) === "badge" ? l.title : void 0;
    let E;
    e[17] !== (l == null ? void 0 : l.type) || e[18] !== s ? (E = !s || (l == null ? void 0 : l.type) === "badge" ? o.jsx(A, q({}, B.newProjectButtonWithNoProjects)) : o.jsx(A, q({}, B.newProjectButton)), e[17] = l == null ? void 0 : l.type, e[18] = s, e[19] = E) : E = e[19];
    let w;
    e[20] !== T || e[21] !== z || e[22] !== E || e[23] !== h || e[24] !== g || e[25] !== S || e[26] !== y || e[27] !== I ? (w = o.jsx(pt, {
        className: h,
        onDragEnter: g,
        onDrop: S,
        onDragLeave: j,
        disabled: y,
        icon: I,
        onClick: T,
        badge: z,
        label: E
    }), e[20] = T, e[21] = z, e[22] = E, e[23] = h, e[24] = g, e[25] = S, e[26] = y, e[27] = I, e[28] = w) : w = e[28];
    const C = w;
    let k;
    return e[29] !== f || e[30] !== l || e[31] !== n || e[32] !== C ? (k = f ? o.jsx(so, {
        nux: l,
        children: C
    }) : o.jsx(be, {
        label: n.formatMessage(B.createProjectDisabledByAdmin),
        children: C
    }), e[29] = f, e[30] = l, e[31] = n, e[32] = C, e[33] = k) : k = e[33], k
}

function to({
    hasProjects: t
}) {
    const e = Q(),
        s = G(),
        i = Lt(s).checkGate("2711769261"),
        n = Ie(ie.hasSeenProjectsWebNuxTooltip),
        a = Ie(ie.hasSeenProjectsUpdateNuxTooltip),
        c = Ie(ie.hasSeenProjectsToFree),
        r = !t && !c.isLoading && c.eligible,
        m = t && i && !a.isLoading && a.eligible,
        u = !m && !a.isLoading && !n.isLoading && n.eligible,
        p = {
            announcement: c,
            description: "",
            key: ie.hasSeenProjectsToFree,
            title: e.formatMessage(B.projectsToFreeTitle),
            type: "badge"
        },
        l = {
            announcement: a,
            description: e.formatMessage(B.projectsUpdateTooltipDescription),
            key: ie.hasSeenProjectsUpdateNuxTooltip,
            title: e.formatMessage(B.projectsUpdateTooltipTitle),
            type: "tooltip"
        },
        d = {
            announcement: n,
            description: e.formatMessage(B.projectsNuxTooltipDescription),
            key: ie.hasSeenProjectsWebNuxTooltip,
            title: e.formatMessage(B.projectsNuxTooltipTitle),
            type: "tooltip"
        };
    let f = null;
    return r ? f = p : m ? f = l : u && (f = d), {
        announcementKey: f == null ? void 0 : f.key,
        eligibleNux: f,
        projectUpdateTooltip: l,
        projectTooltip: d,
        showProjectUpdateTooltip: m,
        showProjectTooltip: u
    }
}

function so(t) {
    "use forget";
    const e = N.c(11),
        {
            children: s,
            nux: i
        } = t,
        n = G(),
        a = Ve(),
        c = zt(),
        r = Mt();
    if (!i || c || !r || !a || i.type === "badge") {
        let p;
        return e[0] !== s ? (p = o.jsx(o.Fragment, {
            children: s
        }), e[0] = s, e[1] = p) : p = e[1], p
    }
    let m;
    e[2] !== n || e[3] !== i.key ? (m = () => gt(n, i.key), e[2] = n, e[3] = i.key, e[4] = m) : m = e[4];
    let u;
    return e[5] !== s || e[6] !== i.description || e[7] !== i.key || e[8] !== i.title || e[9] !== m ? (u = o.jsx(ps, {
        announcementKey: i.key,
        theme: "bright",
        side: "right",
        show: !0,
        badge: "new",
        dismissOnOutsideClick: !0,
        title: i.title,
        description: i.description,
        onDismiss: m,
        sideOffset: -5,
        children: s
    }), e[5] = s, e[6] = i.description, e[7] = i.key, e[8] = i.title, e[9] = m, e[10] = u) : u = e[10], u
}

function oo(t) {
    "use forget";
    const e = N.c(17),
        {
            showAppsSidebarItem: s,
            showGPTsSidebarItem: i,
            showNewProjectButton: n,
            numLoadingItems: a,
            ptnSidebarProps: c,
            jobsSidebarProps: r
        } = t,
        m = a === void 0 ? 0 : a;
    let u;
    e[0] !== s ? (u = s && o.jsx(Ss, {}), e[0] = s, e[1] = u) : u = e[1];
    let p;
    e[2] !== r || e[3] !== c ? (p = o.jsx(bs, {
        ptnSidebarProps: c,
        jobsSidebarProps: r
    }), e[2] = r, e[3] = c, e[4] = p) : p = e[4];
    let l;
    e[5] !== i ? (l = i && o.jsx(ht, {}), e[5] = i, e[6] = l) : l = e[6];
    let d;
    e[7] !== n ? (d = n && o.jsx(yt, {
        hasProjects: !1
    }), e[7] = n, e[8] = d) : d = e[8];
    let f;
    e[9] !== m ? (f = hs(m, no), e[9] = m, e[10] = f) : f = e[10];
    let x;
    return e[11] !== u || e[12] !== p || e[13] !== l || e[14] !== d || e[15] !== f ? (x = o.jsxs("div", {
        className: "pb-[calc(var(--sidebar-section-margin-top)-var(--sidebar-section-first-margin-top))]",
        children: [u, p, l, d, f]
    }), e[11] = u, e[12] = p, e[13] = l, e[14] = d, e[15] = f, e[16] = x) : x = e[16], x
}

function no(t) {
    return o.jsx(Te, {
        size: "long"
    }, t)
}
const io = {
    open: {
        opacity: 1,
        y: 0,
        transition: {
            duration: .15,
            ease: "easeOut"
        }
    },
    closed: {
        opacity: 0,
        y: -5,
        transition: {
            duration: .15,
            ease: "easeIn"
        }
    }
};

function ao(t) {
    "use forget";
    const e = N.c(21),
        {
            color: s,
            emoji: i,
            isFolderExpanded: n,
            gizmoId: a,
            isSharedProject: c
        } = t,
        r = G(),
        m = Q(),
        [u, p] = P.useState(!1);
    let l;
    e[0] !== m || e[1] !== n ? (l = m.formatMessage(n ? B.hideChatsForProjectTooltip : B.showChatsForProjectTooltip), e[0] = m, e[1] = n, e[2] = l) : l = e[2];
    let d;
    e[3] !== r || e[4] !== a || e[5] !== n ? (d = h => {
        h.preventDefault(), St(r, a, !n)
    }, e[3] = r, e[4] = a, e[5] = n, e[6] = d) : d = e[6];
    let f, x;
    e[7] === Symbol.for("react.memo_cache_sentinel") ? (f = () => p(!0), x = () => p(!1), e[7] = f, e[8] = x) : (f = e[7], x = e[8]);
    let v;
    e[9] !== s || e[10] !== i || e[11] !== n || e[12] !== u || e[13] !== c ? (v = i ? o.jsx(xt, {
        color: s,
        emoji: i,
        isSharedProject: c,
        strict: !0
    }) : o.jsx(_s, {
        isOpen: !!n,
        isHovered: u,
        color: s,
        isSharedProject: c
    }), e[9] = s, e[10] = i, e[11] = n, e[12] = u, e[13] = c, e[14] = v) : v = e[14];
    let _;
    e[15] !== d || e[16] !== v ? (_ = o.jsx("button", {
        className: "icon",
        onClick: d,
        onMouseEnter: f,
        onMouseLeave: x,
        children: v
    }), e[15] = d, e[16] = v, e[17] = _) : _ = e[17];
    let b;
    return e[18] !== l || e[19] !== _ ? (b = o.jsx(be, {
        label: l,
        triggerAs: null,
        children: _
    }), e[18] = l, e[19] = _, e[20] = b) : b = e[20], b
}

function Ne({
    gizmo: t,
    historyDisabled: e,
    flair: s,
    onClick: i,
    isActive: n,
    hideOverflowMenu: a = !1,
    inGPTDropdown: c = !1
}) {
    "use no forget";
    var U, ee, Y;
    const r = G(),
        m = Nt(),
        u = O(() => m == null ? void 0 : m.serverId$()),
        p = we(),
        l = Q(),
        d = Qe(r),
        f = t.gizmo.id,
        x = O(() => We(r, f)),
        v = At(),
        _ = !!((U = t.gizmo.tags) != null && U.includes(Dt.FirstParty)),
        {
            items: b = [],
            hasNextPage: h
        } = Ft(t.gizmo.id),
        g = (ee = je(r)) == null ? void 0 : ee.normalizedAccountUserId,
        S = P.useMemo(() => g ? b.filter(M => {
            var $;
            return "owner" in M ? (($ = M.owner) == null ? void 0 : $.user_id) === g : !0
        }) : b, [b, g]),
        j = Ye(r, f),
        y = Ze(r, f),
        I = O(() => y.isSkeleton$() ? Gt(r, t) : y.theme$()),
        T = O(() => y.isSkeleton$() ? $t(r, t) : y.emoji$()),
        z = O(() => y.isSkeleton$() ? Ot(r, t) : y.title$()),
        E = O(() => d.projects.renamingProjectId$() === f),
        w = n && (!j || !(x && u));
    P.useEffect(() => {
        We(r, f) == null && n && u && St(r, f, !0)
    }, [r, n, u, f]);
    let C;
    t != null ? C = (Y = j ? z : t.gizmo.display.name) != null ? Y : Bt : e ? C = l.formatMessage(bt.clearChat) : C = Yt;
    const [k, L] = P.useState(!1), {
        canDropConversation: D,
        onDropConversation: R
    } = Zs("sidebar_row_button", t), K = () => {
        P.startTransition(() => {
            $e(() => {
                d.composer.reset(), d.projects.reset()
            })
        })
    }, V = E ? o.jsx(ys, {
        initialValue: C,
        onCommit: async M => {
            K();
            try {
                const {
                    resource: $
                } = await y.queueUpdate$({
                    name: M
                }), W = window.location.pathname;
                $ && n && W === window.location.pathname && p(Ge(r, $), {
                    replace: !0
                })
            } catch ($) {
                const W = qt($);
                return v == null || v.warning(W != null ? W : "Error", {
                    duration: 5,
                    hasCloseButton: !0
                }), {
                    id: y.id
                }
            }
        },
        onCancel: K
    }) : C, F = c && !j ? X.LinkItem : xs, H = t && j ? Ut(t) : !1;
    return o.jsxs(o.Fragment, {
        children: [o.jsx(F, {
            className: J(k && "[&>*]:pointer-events-none"),
            highlighted: k,
            onDrop: M => {
                D && (M.preventDefault(), M.stopPropagation(), L(!1), R())
            },
            onDragEnter: M => {
                D && M.target === M.currentTarget && j && (M.preventDefault(), L(!0))
            },
            onDragLeave: M => {
                M.target === M.currentTarget && L(!1)
            },
            to: Ge(r, t),
            onDoubleClick: () => {
                $e(() => {
                    d.projects.renamingProjectId$.set(f), d.composer.autofocusDisabled$.set(!0)
                })
            },
            onClick: M => {
                var W;
                const $ = (W = t == null ? void 0 : t.gizmo.id) != null ? W : "primary";
                re.logNewChatButtonClicked({
                    location: "Sidebar gizmo list",
                    gizmo_id: $
                }), re.logEvent("Sidebar Click Gizmo", {
                    gizmo_id: $
                }), i == null || i(M)
            },
            active: k ? !1 : w,
            icon: j ? S.length > 0 ? o.jsx(ao, {
                color: I,
                emoji: T,
                isFolderExpanded: x,
                gizmoId: f,
                isSharedProject: H
            }) : o.jsx(xt, {
                color: I,
                emoji: T,
                isSharedProject: H,
                strict: !0
            }) : o.jsx(js, {
                simple: !0,
                isFirstParty: _,
                src: t == null ? void 0 : t.gizmo.display.profile_picture_url,
                className: "icon",
                alt: ""
            }),
            label: V,
            trailing: s === ke.Workspace && o.jsx(ro, {}),
            highlightTrailing: !a && !k && !E && (j ? o.jsx(fo, {
                gizmoResource: t,
                isActive: n
            }) : o.jsx(mo, {
                gizmoResource: t,
                flair: s
            }))
        }), o.jsx(Ht, {
            initial: !1,
            children: j && x && S.length > 0 && o.jsx(Wt.div, {
                initial: "closed",
                animate: "open",
                exit: "closed",
                variants: io,
                className: "overflow-hidden",
                children: o.jsx(vs, {
                    gizmoResource: t,
                    serverThreadId: u,
                    isOnProjectPage: w,
                    conversations: S,
                    hasNextPage: h
                })
            }, "nested-conversations")
        })]
    })
}
const ro = () => {
        "use forget";
        var r;
        const t = N.c(8),
            e = Q(),
            s = ze();
        let i;
        t[0] !== s || t[1] !== e ? (i = s != null && s.name ? e.formatMessage({
            id: "gizmo.workspaceRecommended",
            defaultMessage: "Recommended at {workspace_name}"
        }, {
            workspace_name: (r = s.name) != null ? r : "Your Workspace"
        }) : e.formatMessage({
            id: "gizmo.workspaceRecommended.noWorkplaceName",
            defaultMessage: "Recommended at your workplace"
        }), t[0] = s, t[1] = e, t[2] = i) : i = t[2];
        const n = i;
        let a;
        t[3] !== n ? (a = o.jsx(Is, {
            className: "icon",
            alt: n
        }), t[3] = n, t[4] = a) : a = t[4];
        let c;
        return t[5] !== n || t[6] !== a ? (c = o.jsx(be, {
            side: "right",
            label: n,
            children: a
        }), t[5] = n, t[6] = a, t[7] = c) : c = t[7], c
    },
    _t = xe(() => Se(() =>
        import ("./dusl493dou663zd3.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5])).then(t => t.GizmoKeepInSidebarMenuItem)),
    lo = xe(() => Se(() =>
        import ("./bjw7ec8hl3mvsw3f.js"), __vite__mapDeps([6, 1, 7, 2, 3, 8, 4, 5])).then(t => t.SnorlaxDeletionModalWrapper)),
    co = xe(() => Se(() =>
        import ("./bjw7ec8hl3mvsw3f.js"), __vite__mapDeps([6, 1, 7, 2, 3, 8, 4, 5])).then(t => t.SnorlaxLeaveModalWrapper)),
    mo = t => {
        "use forget";
        const e = N.c(10),
            {
                gizmoResource: s,
                flair: i
            } = t,
            n = kt();
        let a;
        e[0] === Symbol.for("react.memo_cache_sentinel") ? (a = o.jsx(Je, {
            onMouseOver: uo,
            icon: Me
        }), e[0] = a) : a = e[0];
        let c;
        e[1] !== i || e[2] !== s || e[3] !== n ? (c = (i === ke.Recent || i === ke.Mine) && o.jsx(X.Item, {
            onClick: () => {
                Vt.updateGizmoSidebar(n, Qt, s.gizmo.id, "keep", "sidebar")
            },
            children: o.jsx(A, q({}, bt.keepInSidebar))
        }), e[1] = i, e[2] = s, e[3] = n, e[4] = c) : c = e[4];
        let r;
        e[5] !== s ? (r = o.jsx(_t, {
            gizmoResource: s,
            location: "sidebar"
        }), e[5] = s, e[6] = r) : r = e[6];
        let m;
        return e[7] !== c || e[8] !== r ? (m = o.jsxs(Xe, {
            triggerButton: a,
            contentAlign: "start",
            sideOffset: -4,
            alignOffset: -8,
            size: "auto",
            children: [c, r]
        }), e[7] = c, e[8] = r, e[9] = m) : m = e[9], m
    },
    fo = t => {
        "use forget";
        var b;
        const e = N.c(39),
            {
                gizmoResource: s,
                isActive: i
            } = t,
            n = G(),
            a = we();
        let c;
        e[0] !== n ? (c = Qe(n), e[0] = n, e[1] = c) : c = e[1];
        const r = c,
            m = je(n),
            u = ((b = s.gizmo.author) == null ? void 0 : b.user_id) === (m == null ? void 0 : m.normalizedAccountUserId),
            {
                canDelete: p
            } = Rt(s);
        let l;
        e[2] !== n || e[3] !== s.gizmo.id ? (l = Ze(n, s.gizmo.id), e[2] = n, e[3] = s.gizmo.id, e[4] = l) : l = e[4];
        const d = l;
        let f;
        e[5] !== n || e[6] !== s ? (f = () => {
            he(n, qe, {
                gizmo: Zt(s),
                publishedGizmo: s,
                onClose: () => Pe(n, qe)
            })
        }, e[5] = n, e[6] = s, e[7] = f) : f = e[7];
        const x = f,
            v = [];
        if (O(() => Kt(d)())) {
            let h;
            e[8] === Symbol.for("react.memo_cache_sentinel") ? (h = o.jsx(A, q({}, B.projectShareButton)), e[8] = h) : h = e[8];
            let g;
            e[9] !== x ? (g = o.jsx(X.Item, {
                onClick: x,
                icon: Cs,
                children: h
            }, "share"), e[9] = x, e[10] = g) : g = e[10], v.push(g)
        }
        if (u) {
            let h;
            e[11] !== s.gizmo.id || e[12] !== r.composer.autofocusDisabled$ || e[13] !== r.projects.renamingProjectId$ ? (h = () => {
                r.composer.autofocusDisabled$.set(!0), r.projects.renamingProjectId$.set(s.gizmo.id)
            }, e[11] = s.gizmo.id, e[12] = r.composer.autofocusDisabled$, e[13] = r.projects.renamingProjectId$, e[14] = h) : h = e[14];
            let g;
            e[15] === Symbol.for("react.memo_cache_sentinel") ? (g = o.jsx(A, q({}, B.editProjectNameDropdownButton)), e[15] = g) : g = e[15];
            let S;
            e[16] !== h ? (S = o.jsx(X.Item, {
                onClick: h,
                icon: Ps,
                children: g
            }, "rename"), e[16] = h, e[17] = S) : S = e[17], v.push(S)
        } else {
            let h;
            e[18] !== n || e[19] !== s.gizmo.display.name || e[20] !== s.gizmo.id || e[21] !== i || e[22] !== a ? (h = y => {
                y.preventDefault(), y.stopPropagation();
                const I = () => {
                    i && a("/")
                };
                he(n, co, {
                    gizmoId: s.gizmo.id,
                    projectName: s.gizmo.display.name,
                    onLeaveComplete: I
                })
            }, e[18] = n, e[19] = s.gizmo.display.name, e[20] = s.gizmo.id, e[21] = i, e[22] = a, e[23] = h) : h = e[23];
            let g;
            e[24] === Symbol.for("react.memo_cache_sentinel") ? (g = o.jsx(A, q({}, B.leaveProjectDropdownButton)), e[24] = g) : g = e[24];
            let S;
            e[25] !== h ? (S = o.jsx(X.Item, {
                color: "danger",
                onClick: h,
                icon: Ts,
                children: g
            }, "leave"), e[25] = h, e[26] = S) : S = e[26];
            const j = S;
            v.push(j)
        }
        if (p) {
            let h;
            e[27] !== n || e[28] !== s.gizmo.id || e[29] !== i || e[30] !== a ? (h = T => {
                T.preventDefault(), T.stopPropagation();
                const z = () => {
                    i && a("/")
                };
                he(n, lo, {
                    gizmoId: s.gizmo.id,
                    onDeleted: z
                })
            }, e[27] = n, e[28] = s.gizmo.id, e[29] = i, e[30] = a, e[31] = h) : h = e[31];
            let g;
            e[32] === Symbol.for("react.memo_cache_sentinel") ? (g = o.jsx(A, q({}, B.deleteProjectDropdownButton)), e[32] = g) : g = e[32];
            let S;
            e[33] !== h ? (S = o.jsx(X.Item, {
                color: "danger",
                onClick: h,
                icon: ks,
                children: g
            }, "delete"), e[33] = h, e[34] = S) : S = e[34];
            const j = S,
                y = v.length > 0;
            let I;
            e[35] !== j || e[36] !== y ? (I = y ? o.jsx(X.Group, {
                separator: y,
                children: j
            }, "delete-group") : j, e[35] = j, e[36] = y, e[37] = I) : I = e[37], v.push(I)
        }
        if (v.length === 0) return null;
        let _;
        return e[38] === Symbol.for("react.memo_cache_sentinel") ? (_ = o.jsx(Je, {
            icon: Me
        }), e[38] = _) : _ = e[38], o.jsx(o.Fragment, {
            children: o.jsx(Xe, {
                triggerButton: _,
                contentAlign: "start",
                sideOffset: -4,
                alignOffset: -8,
                size: "auto",
                children: v
            })
        })
    };

function uo() {
    return _t.prefetch()
}

function go(t) {
    "use forget";
    const e = N.c(21),
        {
            currentGizmoId: s
        } = t,
        i = ze(),
        n = G();
    let a;
    e[0] !== n ? (a = et(n), e[0] = n, e[1] = a) : a = e[1];
    const c = a,
        {
            data: r
        } = tt();
    let m;
    e[2] !== r ? (m = r === void 0 ? {} : r, e[2] = r, e[3] = m) : m = e[3];
    const {
        gizmos: u
    } = m;
    let p;
    e[4] !== u ? (p = u === void 0 ? [] : u, e[4] = u, e[5] = p) : p = e[5];
    const l = p;
    let d;
    e[6] !== n ? (d = Xt(n, "1524046265"), e[6] = n, e[7] = d) : d = e[7];
    const f = d;
    let x;
    e[8] !== l || e[9] !== c ? (x = c ? l.filter(po) : l, e[8] = l, e[9] = c, e[10] = x) : x = e[10];
    const v = x;
    let _;
    e[11] !== v || e[12] !== f ? (_ = Es(v, f), e[11] = v, e[12] = f, e[13] = _) : _ = e[13];
    const {
        topGizmos: b,
        remainingGizmos: h
    } = _;
    let g;
    e[14] !== h || e[15] !== b ? (g = {
        topGizmos: b,
        remainingGizmos: h
    }, e[14] = h, e[15] = b, e[16] = g) : g = e[16];
    const {
        topGizmos: S,
        remainingGizmos: j
    } = g;
    if (!i) return null;
    let y;
    return e[17] !== s || e[18] !== j || e[19] !== S ? (y = o.jsx(ho, {
        currentGizmoId: s,
        maxToShowOnLoad: 4,
        topGizmos: S,
        remainingGizmos: j
    }), e[17] = s, e[18] = j, e[19] = S, e[20] = y) : y = e[20], y
}

function po(t) {
    return !Jt(t.resource)
}
const ho = t => {
    "use forget";
    var _;
    const e = N.c(16),
        {
            currentGizmoId: s,
            maxToShowOnLoad: i,
            topGizmos: n,
            remainingGizmos: a
        } = t;
    let c;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (c = !((_ = st.getItem(ot.IsGptListCollapsed)) == null || _), e[0] = c) : c = e[0];
    const [r, m] = P.useState(c), u = Math.max(n.length, i);
    let p;
    e[1] !== a || e[2] !== n ? (p = [...n, ...a], e[1] = a, e[2] = n, e[3] = p) : p = e[3];
    let l = p;
    const d = l.length > u;
    if (d && !r) {
        let b;
        e[4] !== l || e[5] !== u ? (b = l.slice(0, u - 1), e[4] = l, e[5] = u, e[6] = b) : b = e[6], l = b
    }
    let f;
    e[7] !== s || e[8] !== l ? (f = l.map(b => o.jsx(Ne, {
        gizmo: b.resource,
        isActive: b.resource.gizmo.id === s,
        flair: b.flair.kind
    }, b.resource.gizmo.id)), e[7] = s, e[8] = l, e[9] = f) : f = e[9];
    let x;
    e[10] !== d || e[11] !== r ? (x = d && o.jsx(pt, {
        onClick: b => {
            b.preventDefault(), m(So)
        },
        icon: Me,
        children: r ? o.jsx(A, {
            id: "GizmoSidebarList.showLess",
            defaultMessage: "Show less"
        }) : o.jsx(A, {
            id: "GizmoSidebarList.showMoreItems",
            defaultMessage: "Show more"
        })
    }), e[10] = d, e[11] = r, e[12] = x) : x = e[12];
    let v;
    return e[13] !== f || e[14] !== x ? (v = o.jsxs(o.Fragment, {
        children: [f, x]
    }), e[13] = f, e[14] = x, e[15] = v) : v = e[15], v
};

function So(t) {
    const e = !t;
    return st.setItem(ot.IsGptListCollapsed, !e), e
}

function bo({
    snorlaxes: t,
    currentGizmoId: e
}) {
    return o.jsx(o.Fragment, {
        children: t.map(s => o.jsx(Ne, {
            gizmo: s.gizmo,
            isActive: s.gizmo.gizmo.id === e
        }, s.gizmo.gizmo.id))
    })
}

function xo({
    currentGizmoId: t
}) {
    const e = G(),
        {
            snorlaxes: s,
            data: i,
            isLoading: n,
            isError: a,
            refetch: c,
            hasNextPage: r
        } = nt(),
        m = s.slice(0, _e),
        u = Ye(e, t),
        p = P.useRef(!1),
        [l, d] = P.useState(!0),
        f = P.useCallback(function(j) {
            j && d(!1), c()
        }, [c, d]),
        x = a || i === void 0 && !n && p.current;
    ge.markStart("SnorlaxSidebarList", ge.NS_SIDEBAR), i != null && !n && ge.markRendered("SnorlaxSidebarList", ge.NS_SIDEBAR), i === void 0 && !n && !p.current && (p.current = !0, f(!1));
    const _ = s == null ? void 0 : s.find(S => S.gizmo.gizmo.id === t),
        b = m.some(S => S.gizmo.gizmo.id === t),
        h = s && ((s == null ? void 0 : s.length) > (!u || b ? _e : _e + 1) || r),
        g = o.jsx(o.Fragment, {
            children: n ? o.jsxs(o.Fragment, {
                children: [o.jsx(Te, {}), o.jsx(Te, {})]
            }) : o.jsxs(o.Fragment, {
                children: [o.jsx(yt, {
                    hasProjects: (s == null ? void 0 : s.length) > 0
                }), !1, o.jsx(bo, {
                    snorlaxes: m,
                    currentGizmoId: t
                }), _ && !b && o.jsx(Ne, {
                    gizmo: _.gizmo,
                    isActive: !0
                }), h && o.jsx(ws, {
                    currentGizmoId: t
                })]
            })
        });
    return o.jsxs(o.Fragment, {
        children: [x && o.jsx(Ls, {
            showRetry: l,
            refetch: f
        }), !x && g]
    })
}

function jo(t) {
    "use forget";
    const e = N.c(27),
        {
            currentGizmoId: s,
            activeId: i,
            isSnorlaxEnabled: n,
            hasProjects: a,
            hasChats: c,
            isLoadingChats: r
        } = t,
        m = G();
    let u;
    e[0] !== m ? (u = zs(m), e[0] = m, e[1] = u) : u = e[1];
    const p = u;
    let l;
    e[2] !== m ? (l = () => it(m), e[2] = m, e[3] = l) : l = e[3];
    const d = O(l),
        f = c || d && r,
        x = d ? P.Fragment : P.Suspense,
        v = d ? P.Suspense : P.Fragment;
    let _;
    e[4] !== s ? (_ = o.jsx(at, {
        name: "GPTsExpandoSection",
        children: o.jsx(vo, {
            currentGizmoId: s
        })
    }), e[4] = s, e[5] = _) : _ = e[5];
    let b;
    e[6] !== s || e[7] !== a || e[8] !== n ? (b = n && a && o.jsx(Ee, {
        id: "projects",
        title: o.jsx(A, {
            id: "sidebar.projects",
            defaultMessage: "Projects"
        }),
        children: o.jsx(xo, {
            currentGizmoId: s
        })
    }), e[6] = s, e[7] = a, e[8] = n, e[9] = b) : b = e[9];
    let h;
    e[10] !== p.hasAccess ? (h = p.hasAccess ? o.jsx(Ms, {}) : null, e[10] = p.hasAccess, e[11] = h) : h = e[11];
    let g;
    e[12] !== v || e[13] !== _ || e[14] !== b || e[15] !== h ? (g = o.jsxs(v, {
        children: [_, b, h]
    }), e[12] = v, e[13] = _, e[14] = b, e[15] = h, e[16] = g) : g = e[16];
    let S;
    e[17] !== i || e[18] !== p.hasAccess || e[19] !== c || e[20] !== d || e[21] !== f ? (S = f && o.jsx(Ee, {
        id: "chats",
        title: d && !c ? null : p.hasAccess ? o.jsx(A, {
            id: "zPF8DN",
            defaultMessage: "Your chats"
        }) : o.jsx(A, {
            id: "sidebar.chats",
            defaultMessage: "Chats"
        }),
        children: o.jsx(Ns, {
            activeId: i
        })
    }), e[17] = i, e[18] = p.hasAccess, e[19] = c, e[20] = d, e[21] = f, e[22] = S) : S = e[22];
    let j;
    return e[23] !== x || e[24] !== g || e[25] !== S ? (j = o.jsxs(x, {
        children: [g, S]
    }), e[23] = x, e[24] = g, e[25] = S, e[26] = j) : j = e[26], j
}

function vo(t) {
    "use forget";
    const e = N.c(6),
        {
            currentGizmoId: s
        } = t,
        {
            data: i
        } = tt(),
        {
            gizmos: n
        } = i === void 0 ? {} : i;
    if ((n === void 0 ? [] : n).length === 0) return null;
    let c;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (c = o.jsx(A, {
        id: "sidebar.gpts",
        defaultMessage: "GPTs"
    }), e[0] = c) : c = e[0];
    let r;
    e[1] !== s ? (r = o.jsx(go, {
        currentGizmoId: s
    }), e[1] = s, e[2] = r) : r = e[2];
    let m;
    e[3] === Symbol.for("react.memo_cache_sentinel") ? (m = o.jsx(ht, {
        inExpandoSidebarSection: !0
    }), e[3] = m) : m = e[3];
    let u;
    return e[4] !== r ? (u = o.jsxs(Ee, {
        id: "gpts",
        title: c,
        children: [r, m]
    }), e[4] = r, e[5] = u) : u = e[5], u
}

function yo(t) {
    "use forget";
    const e = N.c(6),
        {
            clientThreadId: s,
            sidebarGizmoIdOverride: i
        } = t,
        n = G(),
        a = is(s),
        c = as(s),
        r = i != null ? i : c,
        m = rs();
    let u;
    e[0] !== n ? (u = et(n), e[0] = n, e[1] = u) : u = e[1];
    const p = u,
        l = m ? void 0 : a;
    let d;
    return e[2] !== r || e[3] !== p || e[4] !== l ? (d = o.jsx(_o, {
        currentGizmoId: r,
        activeId: l,
        isSnorlaxEnabled: p
    }), e[2] = r, e[3] = p, e[4] = l, e[5] = d) : d = e[5], d
}

function _o(t) {
    "use forget";
    var Ae;
    const e = N.c(61),
        {
            currentGizmoId: s,
            activeId: i,
            isSnorlaxEnabled: n
        } = t,
        a = G(),
        {
            snorlaxes: c,
            isLoading: r
        } = nt(),
        m = c.length > 0;
    let u;
    e[0] !== a ? (u = !1, e[0] = a, e[1] = u) : u = e[1];
    const p = u;
    let l;
    e[2] !== a ? (l = !1, e[2] = a, e[3] = l) : l = e[3];
    const d = l,
        {
            conversations: f,
            isLoading: x,
            refetch: v
        } = ss(),
        {
            conversations: _,
            isLoading: b
        } = Gs(),
        h = f.length > 0 || _.length > 0,
        g = x || b;
    let S;
    e[4] !== a ? (S = () => ({
        data: null,
        isLoading: !1
    }), e[4] = a, e[5] = S) : S = e[5];
    const {
        data: j,
        isLoading: y
    } = O(S);
    let I;
    e[6] !== a ? (I = () => Le(a), e[6] = a, e[7] = I) : I = e[7];
    const T = O(I),
        z = os(Io);
    let E = null,
        w = null;
    if (j)
        if (e[8] !== j || e[9] !== d || e[10] !== p) {
            for (const Z of j);
            e[8] = j, e[9] = d, e[10] = p, e[11] = E, e[12] = w
        } else E = e[11], w = e[12];
    const {
        data: C,
        isLoading: k
    } = ns();
    let L;
    e[13] !== C ? (L = C === void 0 ? {} : C, e[13] = C, e[14] = L) : L = e[14];
    const {
        gizmos: D
    } = L;
    let R;
    e[15] !== D ? (R = D === void 0 ? [] : D, e[15] = D, e[16] = R) : R = e[16];
    const V = R.length > 0;
    let F, H;
    if (e[17] !== a) {
        const Z = je(a);
        F = Z == null ? void 0 : Z.hasPaidSubscription(), H = Z == null ? void 0 : Z.isFreeWorkspace(), e[17] = a, e[18] = F, e[19] = H
    } else F = e[18], H = e[19];
    const U = H,
        ee = !V && ((Ae = F != null ? F : U) != null ? Ae : !1) && !k;
    let Y;
    e[20] !== a ? (Y = $s(a), e[20] = a, e[21] = Y) : Y = e[21];
    const M = Y,
        $ = n && !m && !r;
    let W = 0;
    T && (k && W++, n && r && W++);
    const ve = W;
    let le;
    e[22] !== a || e[23] !== v ? (le = () => {
        ls(() => it(a)) && v()
    }, e[22] = a, e[23] = v, e[24] = le) : le = e[24];
    const ye = P.useEffectEvent(le);
    let ce;
    e[25] !== z || e[26] !== ye ? (ce = () => {
        z && ye()
    }, e[25] = z, e[26] = ye, e[27] = ce) : ce = e[27];
    let de;
    e[28] !== z ? (de = [z], e[28] = z, e[29] = de) : de = e[29], P.useEffect(ce, de);
    let me;
    e[30] === Symbol.for("react.memo_cache_sentinel") ? (me = o.jsx(Xs, {}), e[30] = me) : me = e[30];
    let te;
    e[31] !== i || e[32] !== s || e[33] !== y || e[34] !== p || e[35] !== E ? (te = {
        isPtnEnabled: p,
        isFirstPartySnorlaxLoading: y,
        ptnSnorlax: E,
        currentGizmoId: s,
        activeThreadId: i
    }, e[31] = i, e[32] = s, e[33] = y, e[34] = p, e[35] = E, e[36] = te) : te = e[36];
    let se;
    e[37] !== i || e[38] !== s || e[39] !== y || e[40] !== d || e[41] !== w ? (se = {
        isJobsEnabled: d,
        isFirstPartySnorlaxLoading: y,
        jobsSnorlax: w,
        currentGizmoId: s,
        activeThreadId: i
    }, e[37] = i, e[38] = s, e[39] = y, e[40] = d, e[41] = w, e[42] = se) : se = e[42];
    let oe;
    e[43] !== ve || e[44] !== M || e[45] !== ee || e[46] !== $ || e[47] !== te || e[48] !== se ? (oe = o.jsx(oo, {
        showAppsSidebarItem: M,
        showGPTsSidebarItem: ee,
        showNewProjectButton: $,
        numLoadingItems: ve,
        ptnSidebarProps: te,
        jobsSidebarProps: se
    }), e[43] = ve, e[44] = M, e[45] = ee, e[46] = $, e[47] = te, e[48] = se, e[49] = oe) : oe = e[49];
    let fe;
    e[50] === Symbol.for("react.memo_cache_sentinel") ? (fe = o.jsx(Os, {}), e[50] = fe) : fe = e[50];
    let ne;
    e[51] !== i || e[52] !== s || e[53] !== h || e[54] !== m || e[55] !== g || e[56] !== n ? (ne = o.jsxs(lt, {
        fallback: null,
        children: [fe, o.jsx(at, {
            name: "ExpandoSidebar",
            children: o.jsx(jo, {
                currentGizmoId: s,
                activeId: i,
                isSnorlaxEnabled: n,
                hasProjects: m,
                hasChats: h,
                isLoadingChats: g
            })
        })]
    }), e[51] = i, e[52] = s, e[53] = h, e[54] = m, e[55] = g, e[56] = n, e[57] = ne) : ne = e[57];
    let ue;
    return e[58] !== oe || e[59] !== ne ? (ue = o.jsxs(o.Fragment, {
        children: [me, oe, ne]
    }), e[58] = oe, e[59] = ne, e[60] = ue) : ue = e[60], ue
}

function Io(t) {
    return t.isPopoverSidebarOpen
}

function Uo(t) {
    "use forget";
    const e = N.c(4),
        {
            clientThreadId: s,
            sidebarGizmoIdOverride: i
        } = t,
        n = G();
    let a;
    return e[0] !== s || e[1] !== n || e[2] !== i ? (a = rt() ? o.jsx(yo, {
        clientThreadId: s,
        sidebarGizmoIdOverride: i
    }) : null, e[0] = s, e[1] = n, e[2] = i, e[3] = a) : a = e[3], a
}

function Ho() {
    "use forget";
    const t = N.c(25),
        e = G(),
        s = Q(),
        i = es(Po);
    let n;
    t[0] !== e ? (n = As(e), t[0] = e, t[1] = n) : n = t[1];
    const a = n;
    let c;
    t[2] !== s ? (c = s.formatMessage({
        id: "Q6nsOM",
        defaultMessage: "Close sidebar"
    }), t[2] = s, t[3] = c) : c = t[3];
    const r = c,
        m = P.useContext(Ds),
        u = Ve(),
        p = ts(e),
        l = p ? Oe : Fs;
    let d;
    t[4] !== i ? (d = i != null && i.visible && i.getTitlebarAreaRect().left > 0 ? "justify-end" : "justify-between", t[4] = i, t[5] = d) : d = t[5];
    let f;
    t[6] !== d ? (f = J("h-header-height flex items-center", d), t[6] = d, t[7] = f) : f = t[7];
    let x;
    t[8] === Symbol.for("react.memo_cache_sentinel") ? (x = o.jsx(To, {}), t[8] = x) : x = t[8];
    let v;
    t[9] !== a ? (v = a && o.jsx(Bs, {}), t[9] = a, t[10] = v) : v = t[10];
    const _ = p ? void 0 : r,
        b = m === "popover" || u,
        h = m === "popover" ? "stage-popover-sidebar" : "stage-slideover-sidebar";
    let g;
    t[11] !== l || t[12] !== r || t[13] !== b || t[14] !== h ? (g = o.jsx(jt, {
        className: "no-draggable cursor-w-resize rtl:cursor-e-resize",
        color: "tertiary",
        "aria-expanded": b,
        "aria-controls": h,
        "aria-label": r,
        onClick: Co,
        icon: l,
        mobileIcon: Oe,
        "data-testid": "close-sidebar-button"
    }), t[11] = l, t[12] = r, t[13] = b, t[14] = h, t[15] = g) : g = t[15];
    let S;
    t[16] !== _ || t[17] !== g ? (S = o.jsx(be, {
        label: _,
        triggerAs: null,
        children: g
    }), t[16] = _, t[17] = g, t[18] = S) : S = t[18];
    let j;
    t[19] !== S || t[20] !== v ? (j = o.jsxs("div", {
        className: "flex",
        children: [v, S]
    }), t[19] = S, t[20] = v, t[21] = j) : j = t[21];
    let y;
    return t[22] !== j || t[23] !== f ? (y = o.jsxs("div", {
        id: "sidebar-header",
        className: f,
        onClick: It,
        children: [x, j]
    }), t[22] = j, t[23] = f, t[24] = y) : y = t[24], y
}

function Co() {
    cs.setSidebarOpen(!1)
}

function Po() {
    return navigator.windowControlsOverlay
}

function To() {
    "use forget";
    const t = N.c(10),
        e = G(),
        s = Q(),
        i = Us();
    let n;
    t[0] !== e ? (n = m => {
        It(m) ? (m.preventDefault(), m.stopPropagation()) : Hs(e, m, {
            location: "Blossom"
        })
    }, t[0] = e, t[1] = n) : n = t[1];
    let a;
    t[2] !== s ? (a = s.formatMessage({
        id: "H6SRdK",
        defaultMessage: "Home"
    }), t[2] = s, t[3] = a) : a = t[3];
    let c;
    t[4] !== i ? (c = {
        to: "/",
        state: i
    }, t[4] = i, t[5] = c) : c = t[5];
    let r;
    return t[6] !== n || t[7] !== a || t[8] !== c ? (r = o.jsx(jt, {
        onClick: n,
        icon: ds,
        iconClassName: "icon-lg",
        color: "primary",
        "data-sidebar-item": !0,
        "aria-label": a,
        as: "link",
        linkProps: c
    }), t[6] = n, t[7] = a, t[8] = c, t[9] = r) : r = t[9], r
}

function It(t) {
    const e = t.currentTarget.closest("nav"),
        s = e != null && e.scrollTop > 0;
    return s && e.scrollTo({
        top: 0,
        behavior: "smooth"
    }), s
}
const ko = xe(() => Se(() =>
        import ("./of7p31pxtd9sx4co.js"), __vite__mapDeps([9, 1, 2, 3, 10, 4, 5])).then(t => t.OnboardingSidebarEntry)),
    pe = ct(() => dt(!1)),
    Re = ct(() => dt(!1));

function Wo(t) {
    "use forget";
    const e = N.c(41),
        {
            navHeader: s,
            children: i,
            className: n
        } = t;
    let a;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (a = mt(), e[0] = a) : a = e[0];
    const c = a;
    let r;
    e[1] === Symbol.for("react.memo_cache_sentinel") ? (r = () => Le(c), e[1] = r) : r = e[1];
    const m = O(r);
    let u;
    e[2] === Symbol.for("react.memo_cache_sentinel") ? (u = () => Js(c), e[2] = u) : u = e[2];
    const p = O(u),
        l = Ke();
    let d;
    e[3] !== l ? (d = vt(l, "images-app"), e[3] = l, e[4] = d) : d = e[4];
    const f = d;
    let x;
    e[5] === Symbol.for("react.memo_cache_sentinel") ? (x = () => pe(c), e[5] = x) : x = e[5];
    const v = O(x),
        _ = Q(),
        [b, h] = P.useState(!1),
        g = p ? "".concat(p, "px") : void 0;
    let S;
    e[6] !== g ? (S = {
        "--primary-items-height": g
    }, e[6] = g, e[7] = S) : S = e[7];
    const j = S;
    let y, I;
    e[8] === Symbol.for("react.memo_cache_sentinel") ? (y = () => () => {
        P.startTransition(() => {
            pe.set(c, !1)
        })
    }, I = [c], e[8] = y, e[9] = I) : (y = e[8], I = e[9]), P.useEffect(y, I);
    let T, z;
    e[10] === Symbol.for("react.memo_cache_sentinel") ? (T = () => {
        const U = new AbortController;
        return fs.postTask(async () => {
            await new Promise(wo), !U.signal.aborted && P.startTransition(() => {
                U.signal.aborted || h(!0)
            })
        }, {
            signal: U.signal
        }).catch(Eo), () => {
            U.abort("Expected cleanup")
        }
    }, z = [], e[10] = T, e[11] = z) : (T = e[10], z = e[11]), P.useEffect(T, z);
    let E;
    e[12] === Symbol.for("react.memo_cache_sentinel") ? (E = o.jsx(ms, {
        asChild: !0,
        children: o.jsx("h2", {
            children: o.jsx(A, q({}, ae.chatHistoryLabel))
        })
    }), e[12] = E) : E = e[12];
    let w;
    e[13] !== f || e[14] !== v || e[15] !== j ? (w = f && o.jsx(P.Activity, {
        mode: v ? "visible" : "hidden",
        children: o.jsx("div", {
            className: "short:h-[calc(var(--header-height)+2px)] short:backdrop-blur-[2px] short:bg-token-bg-primary/10 pointer-events-none absolute inset-x-0 z-1 h-[calc(var(--header-height)+var(--primary-items-height,0)+4px)] w-full bg-(--sidebar-mask-bg) bg-[linear-gradient(180deg,oklch(1_0_0/0.3)_80%,transparent_100%)] [backdrop-filter:var(--sidebar-sticky-backdrop)] contain-size group-data-scrolled-from-top/scrollport:bg-none! dark:bg-[linear-gradient(180deg,oklch(0.5_0_0/0.3)_80%,transparent_100%)]",
            style: j
        })
    }), e[13] = f, e[14] = v, e[15] = j, e[16] = w) : w = e[16];
    let C;
    e[17] !== n ? (C = J("relative flex h-full w-full flex-1 flex-col overflow-y-auto transition-opacity motion-safe:duration-500", n), e[17] = n, e[18] = C) : C = e[18];
    let k;
    e[19] !== _ ? (k = _.formatMessage(ae.chatHistoryLabel), e[19] = _, e[20] = k) : k = e[20];
    let L;
    e[21] !== s ? (L = o.jsx("div", {
        className: "short:group-data-scrolled-from-top/scrollport:shadow-sharp-edge-top sticky top-0 z-30 bg-(--sidebar-mask-bg,var(--bg-elevated-secondary))",
        children: o.jsx("div", {
            className: "touch:px-1.5 px-2",
            children: s
        })
    }), e[21] = s, e[22] = L) : L = e[22];
    let D;
    e[23] !== b ? (D = b && o.jsx(Be, {
        setIsScrolledToEdge: U => {
            P.startTransition(() => {
                pe.set(c, U)
            })
        },
        options: {
            threshold: 0,
            rootMargin: "-50px 0px"
        },
        className: "-mb-px"
    }), e[23] = b, e[24] = D) : D = e[24];
    let R;
    e[25] === Symbol.for("react.memo_cache_sentinel") ? (R = o.jsx("div", {
        className: "grow"
    }), e[25] = R) : R = e[25];
    let K;
    e[26] !== b ? (K = b && o.jsx(Be, {
        setIsScrolledToEdge: U => {
            P.startTransition(() => {
                Re.set(c, U)
            })
        },
        options: {
            threshold: 0
        }
    }), e[26] = b, e[27] = K) : K = e[27];
    let V;
    e[28] !== m ? (V = !m && o.jsx(Lo, {}), e[28] = m, e[29] = V) : V = e[29];
    let F;
    e[30] !== i || e[31] !== C || e[32] !== k || e[33] !== L || e[34] !== D || e[35] !== K || e[36] !== V ? (F = o.jsxs(Ws, {
        className: C,
        isScrolledFromTopEdge$: pe,
        isScrolledFromBottomEdge$: Re,
        "aria-label": k,
        children: [L, D, i, R, K, V]
    }), e[30] = i, e[31] = C, e[32] = k, e[33] = L, e[34] = D, e[35] = K, e[36] = V, e[37] = F) : F = e[37];
    let H;
    return e[38] !== w || e[39] !== F ? (H = o.jsxs(o.Fragment, {
        children: [E, w, F]
    }), e[38] = w, e[39] = F, e[40] = H) : H = e[40], H
}

function Eo() {}

function wo(t) {
    return setTimeout(t, 350)
}

function Lo() {
    "use forget";
    var z, E, w, C;
    const t = N.c(22),
        e = mt(),
        s = je(e),
        i = ze(),
        n = !rt(),
        a = Ke(),
        c = vt(a, "images-app"),
        r = (z = s == null ? void 0 : s.isSelfServeBusiness()) != null ? z : !1,
        m = (E = s == null ? void 0 : s.isK12()) != null ? E : !1,
        u = (w = s == null ? void 0 : s.isFreeWorkspace()) != null ? w : !1;
    let p;
    t[0] !== i ? (p = (C = i == null ? void 0 : i.canInviteMembers()) != null ? C : !1, t[0] = i, t[1] = p) : p = t[1];
    const d = r || m && p || u,
        {
            style: f,
            isEligible: x,
            hasDismissed: v
        } = qs();
    if (!s) return null;
    if (n) {
        let k;
        return t[2] === Symbol.for("react.memo_cache_sentinel") ? (k = o.jsx(zo, {}), t[2] = k) : k = t[2], k
    }
    const _ = c ? "bg-(--sidebar-mask-bg) [backdrop-filter:var(--sidebar-sticky-backdrop)]" : "bg-token-bg-elevated-secondary";
    let b;
    t[3] !== _ ? (b = J("group-data-scrolled-from-end/scrollport:shadow-sharp-edge-bottom sticky bottom-0 z-30 py-1.5 empty:hidden", _), t[3] = _, t[4] = b) : b = t[4];
    let h;
    t[5] !== v || t[6] !== x || t[7] !== f ? (h = x && f && !v && o.jsx(ko, {}), t[5] = v, t[6] = x, t[7] = f, t[8] = h) : h = t[8];
    let g;
    t[9] !== d ? (g = d && o.jsx("div", {
        className: J("l-0 r-0 pointer-events-none absolute top-[-56px] z-0 h-[50px] w-full", "group-data-scrolled-from-end/scrollport:shadow-sharp-edge-top"),
        children: o.jsx("div", {
            "aria-hidden": "true",
            className: J("h-full w-full", "bg-token-bg-elevated-secondary", "mask-[linear-gradient(180deg,transparent_33.62%,black_100%)] [-webkit-mask-image:linear-gradient(180deg,transparent_33.62%,black_100%)]", "opacity-0 group-data-scrolled-from-end/scrollport:opacity-85", "motion-safe:transition-opacity motion-safe:duration-150 motion-safe:ease-out")
        })
    }), t[9] = d, t[10] = g) : g = t[10];
    let S, j;
    t[11] === Symbol.for("react.memo_cache_sentinel") ? (S = o.jsx(lt, {
        children: o.jsx(Rs, {})
    }), j = o.jsx(eo, {}), t[11] = S, t[12] = j) : (S = t[11], j = t[12]);
    let y;
    t[13] !== d ? (y = d && o.jsx(Ks, {}), t[13] = d, t[14] = y) : y = t[14];
    let I;
    t[15] !== g || t[16] !== y ? (I = o.jsxs("div", {
        className: "relative",
        children: [g, S, j, y]
    }), t[15] = g, t[16] = y, t[17] = I) : I = t[17];
    let T;
    return t[18] !== b || t[19] !== h || t[20] !== I ? (T = o.jsxs("div", {
        className: b,
        children: [h, I]
    }), t[18] = b, t[19] = h, t[20] = I, t[21] = T) : T = t[21], T
}
const zo = () => {
        "use forget";
        const t = N.c(30),
            e = G();
        let s;
        t[0] !== e ? (s = Vs(e), t[0] = e, t[1] = s) : s = t[1];
        const i = s;
        let n;
        t[2] !== e ? (n = Qs(e, ae.unauthSignupCta), t[2] = e, t[3] = n) : n = t[3];
        const a = n;
        let c;
        t[4] !== e ? (c = () => {
            Ue(e, {
                fallbackScreenHint: "login",
                callback: Mo,
                skipLoginModal: !1
            })
        }, t[4] = e, t[5] = c) : c = t[5];
        const r = c;
        let m;
        t[6] !== e ? (m = () => {
            Ue(e, {
                fallbackScreenHint: "signup",
                callback: No,
                skipLoginModal: !1
            })
        }, t[6] = e, t[7] = m) : m = t[7];
        const u = m,
            p = i ? "secondary" : "primary";
        let l;
        t[8] !== a ? (l = o.jsx(A, q({}, a)), t[8] = a, t[9] = l) : l = t[9];
        let d;
        t[10] !== u || t[11] !== p || t[12] !== l ? (d = o.jsx(He, {
            as: "button",
            size: "medium",
            color: p,
            "data-testid": "signup-button",
            onClick: u,
            children: l
        }, "signup-button"), t[10] = u, t[11] = p, t[12] = l, t[13] = d) : d = t[13];
        const f = d,
            x = i ? "primary" : "secondary";
        let v;
        t[14] === Symbol.for("react.memo_cache_sentinel") ? (v = o.jsx(A, q({}, ae.unauthLoginCta)), t[14] = v) : v = t[14];
        let _;
        t[15] !== r || t[16] !== x ? (_ = o.jsx(He, {
            as: "button",
            size: "medium",
            color: x,
            "data-testid": "login-button",
            onClick: r,
            children: v
        }, "login-button"), t[15] = r, t[16] = x, t[17] = _) : _ = t[17];
        const b = _,
            h = i ? ae.logInOrSignUp : ae.signUpOrLogIn;
        let g;
        t[18] !== h ? (g = o.jsx("p", {
            className: "text-token-text-primary mb-1 text-sm font-semibold",
            children: o.jsx(A, q({}, h))
        }), t[18] = h, t[19] = g) : g = t[19];
        let S;
        t[20] === Symbol.for("react.memo_cache_sentinel") ? (S = o.jsx("p", {
            className: "text-token-text-secondary text-sm",
            children: o.jsx(A, {
                id: "tr+zlt",
                defaultMessage: "Get smarter responses, upload files and images, and save your conversations."
            })
        }), t[20] = S) : S = t[20];
        let j;
        t[21] !== g ? (j = o.jsxs("div", {
            className: "mt-2 mb-4",
            children: [g, S]
        }), t[21] = g, t[22] = j) : j = t[22];
        let y;
        t[23] !== i || t[24] !== b || t[25] !== f ? (y = o.jsx("div", {
            className: "flex flex-row items-start gap-2",
            children: i ? [b, f] : [f, b]
        }), t[23] = i, t[24] = b, t[25] = f, t[26] = y) : y = t[26];
        let I;
        return t[27] !== j || t[28] !== y ? (I = o.jsxs("div", {
            className: "bg-token-bg-elevated-secondary sticky bottom-0 z-30 p-2",
            children: [j, y]
        }), t[27] = j, t[28] = y, t[29] = I) : I = t[29], I
    },
    ae = Et({
        chatHistoryLabel: {
            id: "NavigationContent.chatHistoryLabel",
            defaultMessage: "Chat history"
        },
        signInToChat: {
            id: "NavigationContent.signInToChat",
            defaultMessage: "Sign in to ChatGPT"
        },
        signUpOrLogIn: {
            id: "NavigationContent.signUpOrLogIn",
            defaultMessage: "Sign up or log in"
        },
        logInOrSignUp: {
            id: "NavigationContent.logInOrSignUp",
            defaultMessage: "Log in or sign up for free"
        },
        unauthSignupCta: {
            id: "NavigationContent.unauthSignupCta",
            defaultMessage: "Sign up"
        },
        unauthLoginCta: {
            id: "NavigationContent.unauthLoginCta",
            defaultMessage: "Log in"
        }
    });

function Mo(t) {
    re.logLogInButtonClicked({
        location: "Sidebar bottom unit",
        provider: t
    }, ft.ACCESS_FLOW_ENTRY_POINT_SIDEBAR_BOTTOM_UNIT), ut.logEvent("chatgpt_sidebar_login_button_clicked")
}

function No(t) {
    re.logSignUpButtonClicked({
        location: "Sidebar bottom unit",
        provider: t
    }, ft.ACCESS_FLOW_ENTRY_POINT_SIDEBAR_BOTTOM_UNIT), ut.logEvent("chatgpt_sidebar_signup_button_clicked")
}
export {
    Uo as C, Wo as N, Ho as S, _o as a
};
//# sourceMappingURL=cw1lyo20zi7916n8.js.map