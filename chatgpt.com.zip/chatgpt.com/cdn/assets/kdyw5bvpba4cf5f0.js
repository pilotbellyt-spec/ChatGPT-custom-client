var ue = Object.defineProperty,
    de = Object.defineProperties;
var fe = Object.getOwnPropertyDescriptors;
var Rn = Object.getOwnPropertySymbols;
var me = Object.prototype.hasOwnProperty,
    ge = Object.prototype.propertyIsEnumerable;
var _n = t => {
    throw TypeError(t)
};
var kn = (t, n, e) => n in t ? ue(t, n, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : t[n] = e,
    Q = (t, n) => {
        for (var e in n || (n = {})) me.call(n, e) && kn(t, e, n[e]);
        if (Rn)
            for (var e of Rn(n)) ge.call(n, e) && kn(t, e, n[e]);
        return t
    },
    ln = (t, n) => de(t, fe(n));
var En = (t, n, e) => n.has(t) || _n("Cannot " + e);
var x = (t, n, e) => (En(t, n, "read from private field"), e ? e.call(t) : n.get(t)),
    M = (t, n, e) => n.has(t) ? _n("Cannot add the same private member more than once") : n instanceof WeakSet ? n.add(t) : n.set(t, e),
    T = (t, n, e, s) => (En(t, n, "write to private field"), s ? s.call(t, e) : n.set(t, e), e);
import {
    r as d,
    h as pe,
    j as c,
    M as k,
    e as ve
} from "./fg33krlcm0qyi6yw.js";
import {
    gH as be,
    k_ as vn,
    xm as he,
    mX as xe,
    wT as Ae,
    ky as ye,
    jq as Se,
    bb as Yn,
    Z as In,
    S as Ce,
    l as V,
    a9 as nn,
    c0 as Pn,
    o7 as we,
    b as Fe,
    c_ as Me,
    o1 as De,
    dF as Ln,
    dH as zn,
    b6 as Te,
    B as Re,
    P as ke,
    d8 as _e,
    o3 as Ee,
    o2 as Ie,
    _ as Pe,
    bg as Le,
    py as ze
} from "./dykg4ktvbu3mhmdo.js";
import {
    Ac as Zn,
    mX as Ne,
    Ad as $n,
    uT as Ue,
    rj as Be,
    jN as Oe,
    jO as je,
    nE as qe,
    jM as cn,
    df as He,
    jf as Ve,
    jg as We,
    eB as Ge,
    Ae as Ke,
    Af as Ye,
    fx as Ze
} from "./k15yxxoybkkir2ou.js";
import {
    u as $e
} from "./fz8xw1971c2kf2eb.js";
import {
    u as hn,
    B as an,
    G as Xe
} from "./dapgo43htqk76ir6.js";
const Je = 2,
    Qe = ({
        viewport: t,
        canvasSize: n,
        shouldMeasurePerf: e,
        source: s
    }) => {
        const o = d.useRef({}),
            f = d.useCallback(r => {
                const l = r.getExtension("WEBGL_debug_renderer_info");
                l && (o.current.vendor = r.getParameter(l.UNMASKED_VENDOR_WEBGL), o.current.renderer = r.getParameter(l.UNMASKED_RENDERER_WEBGL))
            }, []);
        return d.useEffect(() => {
            var a, u;
            const r = {
                vendor: (a = o.current.vendor) != null ? a : "(unavailable)",
                renderer: (u = o.current.renderer) != null ? u : "(unavailable)",
                width: t[0],
                height: t[1],
                canvasWidth: n[0],
                canvasHeight: n[1],
                dpr: window.devicePixelRatio,
                source: s
            };
            !be(r, o.current) && e && (o.current = r, Zn(Je).then(i => {
                vn.bloop.performance(ln(Q({}, r), {
                    fps: i
                }))
            }))
        }, [n, e, t, s]), f
    },
    nt = .25,
    et = 3,
    Nn = 28,
    un = 55,
    dn = 200,
    Un = 1.1,
    tt = ({
        viewport: t,
        initialScale: n,
        shouldCalibrate: e
    }) => {
        const [s, o] = d.useState(n), f = d.useRef(void 0), r = d.useRef(void 0), l = d.useRef(void 0), a = d.useRef("down"), u = d.useCallback(() => {
            const i = a.current === "up" ? et : nt;
            Zn(i).then(p => {
                if (p < Nn) {
                    a.current = "down";
                    const m = Math.max(p, 1),
                        b = Math.sqrt(m / Nn);
                    o(g => g * b), r.current = window.setTimeout(u, dn)
                } else if (l.current) {
                    const m = p >= un,
                        b = p >= l.current * Un;
                    if (m || b) a.current = "up", o(g => g * Un), r.current = window.setTimeout(u, dn);
                    else if (p < un) {
                        a.current = "down";
                        const g = Math.sqrt(p / un);
                        o(h => h * g)
                    }
                }
                l.current = p
            })
        }, []);
        return d.useEffect(() => {
            var h;
            const [i, p] = t, [m, b] = (h = f.current) != null ? h : [];
            return e && (m !== i || b !== p) && (f.current = t, clearTimeout(r.current), o(n), r.current = window.setTimeout(u, dn)), () => {
                clearTimeout(r.current)
            }
        }, [e, u, n, t]), s
    };
var fn, Bn;

function ot() {
    if (Bn) return fn;
    Bn = 1;
    var t = he(),
        n = xe(),
        e = Ae(),
        s = ye(),
        o = Ne(),
        f = Math.max;

    function r(l) {
        if (!(l && l.length)) return [];
        var a = 0;
        return l = t(l, function(u) {
            if (o(u)) return a = f(u.length, a), !0
        }), s(a, function(u) {
            return n(l, e(u))
        })
    }
    return fn = r, fn
}
var mn, On;

function at() {
    if (On) return mn;
    On = 1;
    var t = Se(),
        n = ot(),
        e = t(n);
    return mn = e, mn
}
var st = at();
const gn = pe(st),
    xn = 240,
    Xn = 2048,
    Jn = new Array(xn).fill(0),
    it = t => {
        const n = hn(t, {
            bands: xn,
            updateInterval: an,
            loPass: 0,
            hiPass: 400,
            analyserOptions: {
                fftSize: Xn
            }
        });
        return n.length === 0 ? Jn : n
    },
    An = t => {
        const {
            magnitudes: n,
            binCount: e,
            gainMultiplier: s
        } = t;
        if (n.length === 0) return new Array(e).fill(0);
        const o = Math.ceil(n.length / e),
            f = [];
        for (let r = 0; r < n.length; r += o) {
            const l = Math.min(r + o, n.length),
                a = n.slice(r, l).sort((m, b) => m - b),
                u = Math.floor(a.length / 2);
            let i;
            a.length % 2 === 0 ? i = (a[u - 1] + a[u]) / 2 : i = a[u], i = Math.abs(i), i *= s;
            const p = i / (i + 1);
            f.push(p)
        }
        return f
    },
    Qn = (t, n) => {
        const e = n.sampleRate,
            s = t.length,
            o = n.bandCount,
            f = n.binCount,
            r = n.gainMultipliers;
        if (r.length !== o) throw new Error("gainMultipliers must have length equal to bandCount");
        const l = s * 2,
            a = e / l,
            u = t.map((g, h) => h * a),
            i = 20,
            p = e / 2,
            m = new Array(o + 1).fill(0).map((g, h) => i * Math.pow(p / i, h / o)),
            b = new Array(o).fill(null).map(() => []);
        for (let g = 0; g < u.length; g += 1)
            for (let h = 0; h < o; h += 1)
                if (u[g] >= m[h] && u[g] < m[h + 1]) {
                    b[h].push(t[g]);
                    break
                }
        for (let g = 0; g < o; g += 1) {
            const h = b[g],
                C = r[g];
            b[g] = An({
                magnitudes: h,
                binCount: f,
                gainMultiplier: C
            })
        }
        return b
    },
    jn = 60,
    ne = 48e3,
    rt = 1,
    lt = 2,
    ct = 40,
    ut = 2;

function qn({
    time: t,
    timeConstant: n
}) {
    return 1 - Math.exp(-t / n)
}

function Hn(t, n) {
    const e = n[1] - n[0];
    return n[0] + t * e
}
const pn = t => {
        if (!Array.isArray(t) || t.length !== 2 || typeof t[0] != "number" || typeof t[1] != "number") throw new Error("zip failed - received a value that is not a [number, number] tuple")
    },
    dt = t => {
        const {
            prevAudioData: n,
            prevCumulativeAudioData: e,
            deltaTimeS: s,
            audioDataRaw: o
        } = t, f = o.map(m => m * s * jn * rt), r = qn({
            time: s,
            timeConstant: lt
        }), l = gn(n, f).map(m => (pn(m), Hn(r, m))), a = o.map(m => m * s * jn * ct), u = gn(e, a).map(m => (pn(m), m[0] + m[1])), i = qn({
            time: s,
            timeConstant: ut
        }), p = gn(e, u).map(m => (pn(m), Hn(i, m)));
        return {
            audioData: l,
            cumulativeAudioData: p
        }
    },
    Pt = (t, n) => {
        const e = it(t),
            s = Qn(e, {
                sampleRate: ne,
                binCount: n.bins,
                bandCount: n.bands,
                gainMultipliers: n.gainMultipliers
            }),
            o = An({
                magnitudes: e,
                binCount: 1,
                gainMultiplier: 1
            });
        return {
            bandMagnitudes: s,
            cumulativeMagnitude: o
        }
    },
    ft = "/cdn/assets/noise-watercolor-m3j88gni.webp",
    mt = {
        src: ft
    };
let ee;
const en = new window.Image;
en.crossOrigin = "anonymous";
en.src = mt.src;
en.onload = () => {
    ee = en
};
var gt = "#version 300 es\n#define E (2.71828182846)\n#define pi (3.14159265358979323844)\n#define NUM_OCTAVES (4)\n\nprecision highp float;\n\nstruct ColoredSDF {\n  float distance;\n  vec4 color;\n};\n\nstruct SDFArgs {\n  vec2 st;\n  float amount;\n  float duration;\n  float time;\n  float mainRadius;\n};\n\nfloat triangle(float t, float p) {\n  return 2.0 * abs(t / p - floor(t / p + 0.5));\n}\n\nfloat spring(float t, float d) {\n  return 1.0 - exp(-E * 2.0 * t) * cos((1.0 - d) * 115.0 * t);\n}\n\nfloat silkySmooth(float t, float k) {\n  return atan(k * sin((t - 0.5) * pi)) / atan(k) * 0.5 + 0.5;\n}\n\nfloat scaled(float edge0, float edge1, float x) {\n  return clamp((x - edge0) / (edge1 - edge0), float(0), float(1));\n}\n\nfloat fixedSpring(float t, float d) {\n  float s = mix(\n    1.0 - exp(-E * 2.0 * t) * cos((1.0 - d) * 115.0 * t),\n    1.0,\n    scaled(0.0, 1.0, t)\n  );\n  return s * (1.0 - t) + t;\n}\n\nfloat bounce(float t, float d) {\n  return -sin(pi * (1.0 - d) * t) *\n  (1.0 - t) *\n  exp(-2.71828182846 * 2.0 * t) *\n  t *\n  10.0;\n}\n\nfloat random(vec2 st) {\n  return fract(sin(dot(st.xy, vec2(12.9898, 78.233))) * 43758.5453123);\n}\n\nfloat random(ivec2 st) {\n  return random(vec2(st));\n}\n\nfloat random(float p) {\n  return random(vec2(p));\n}\n\nfloat opSmoothUnion(float d1, float d2, float k) {\n  if (k <= 0.0) {\n    k = 0.000001;\n  }\n  float h = clamp(0.5 + 0.5 * (d2 - d1) / k, 0.0, 1.0);\n  return mix(d2, d1, h) - k * h * (1.0 - h);\n}\n\nfloat opSmoothSubtraction(float d1, float d2, float k) {\n  if (k <= 0.0) {\n    k = 0.000001;\n  }\n  float h = clamp(0.5 - 0.5 * (d2 + d1) / k, 0.0, 1.0);\n  return mix(d2, -d1, h) + k * h * (1.0 - h);\n}\n\nfloat opSmoothIntersection(float d1, float d2, float k) {\n  if (k <= 0.0) {\n    k = 0.000001;\n  }\n  float h = clamp(0.5 - 0.5 * (d2 - d1) / k, 0.0, 1.0);\n  return mix(d2, d1, h) + k * h * (1.0 - h);\n}\n\nfloat sdRoundedBox(vec2 p, vec2 b, vec4 r) {\n  r.xy = p.x > 0.0 ? r.xy : r.zw;\n  r.x = p.y > 0.0 ? r.x : r.y;\n  vec2 q = abs(p) - b + r.x;\n  return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r.x;\n}\n\nfloat sdSegment(vec2 p, vec2 a, vec2 b) {\n  vec2 pa = p - a;\n  vec2 ba = b - a;\n  float h = clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0);\n  return length(pa - ba * h);\n}\n\nfloat sdArc(vec2 p, vec2 sca, vec2 scb, float ra, float rb) {\n  p *= mat2(sca.x, sca.y, -sca.y, sca.x);\n  p.x = abs(p.x);\n  return scb.y * p.x > scb.x * p.y\n    ? length(p - ra * scb) - rb\n    : abs(length(p) - ra) - rb;\n}\n\nfloat arc(vec2 st, float startAngle, float length, float radius, float width) {\n  return sdArc(\n    st,\n    vec2(sin(startAngle), cos(startAngle)),\n    vec2(sin(length), cos(length)),\n    radius,\n    width\n  );\n}\n\nvec2 rotate(vec2 v, float a) {\n  float s = sin(a);\n  float c = cos(a);\n  mat2 m = mat2(c, s, -s, c);\n  return m * v;\n}\n\nvec3 blendLinearBurn_13_5(vec3 base, vec3 blend) {\n  \n  return max(base + blend - vec3(1.0), vec3(0.0));\n}\n\nvec3 blendLinearBurn_13_5(vec3 base, vec3 blend, float opacity) {\n  return blendLinearBurn_13_5(base, blend) * opacity + base * (1.0 - opacity);\n}\n\nvec4 permute(vec4 x) {\n  return mod((x * 34.0 + 1.0) * x, 289.0);\n}\nvec4 taylorInvSqrt(vec4 r) {\n  return 1.79284291400159 - 0.85373472095314 * r;\n}\nvec3 fade(vec3 t) {\n  return t * t * t * (t * (t * 6.0 - 15.0) + 10.0);\n}\n\nfloat cnoise(vec3 P) {\n  vec3 Pi0 = floor(P);\n  vec3 Pi1 = Pi0 + vec3(1.0);\n  Pi0 = mod(Pi0, 289.0);\n  Pi1 = mod(Pi1, 289.0);\n  vec3 Pf0 = fract(P);\n  vec3 Pf1 = Pf0 - vec3(1.0);\n  vec4 ix = vec4(Pi0.x, Pi1.x, Pi0.x, Pi1.x);\n  vec4 iy = vec4(Pi0.yy, Pi1.yy);\n  vec4 iz0 = vec4(Pi0.z);\n  vec4 iz1 = vec4(Pi1.z);\n\n  vec4 ixy = permute(permute(ix) + iy);\n  vec4 ixy0 = permute(ixy + iz0);\n  vec4 ixy1 = permute(ixy + iz1);\n\n  vec4 gx0 = ixy0 / 7.0;\n  vec4 gy0 = fract(floor(gx0) / 7.0) - 0.5;\n  gx0 = fract(gx0);\n  vec4 gz0 = vec4(0.5) - abs(gx0) - abs(gy0);\n  vec4 sz0 = step(gz0, vec4(0.0));\n  gx0 -= sz0 * (step(vec4(0.0), gx0) - 0.5);\n  gy0 -= sz0 * (step(vec4(0.0), gy0) - 0.5);\n\n  vec4 gx1 = ixy1 / 7.0;\n  vec4 gy1 = fract(floor(gx1) / 7.0) - 0.5;\n  gx1 = fract(gx1);\n  vec4 gz1 = vec4(0.5) - abs(gx1) - abs(gy1);\n  vec4 sz1 = step(gz1, vec4(0.0));\n  gx1 -= sz1 * (step(vec4(0.0), gx1) - 0.5);\n  gy1 -= sz1 * (step(vec4(0.0), gy1) - 0.5);\n\n  vec3 g000 = vec3(gx0.x, gy0.x, gz0.x);\n  vec3 g100 = vec3(gx0.y, gy0.y, gz0.y);\n  vec3 g010 = vec3(gx0.z, gy0.z, gz0.z);\n  vec3 g110 = vec3(gx0.w, gy0.w, gz0.w);\n  vec3 g001 = vec3(gx1.x, gy1.x, gz1.x);\n  vec3 g101 = vec3(gx1.y, gy1.y, gz1.y);\n  vec3 g011 = vec3(gx1.z, gy1.z, gz1.z);\n  vec3 g111 = vec3(gx1.w, gy1.w, gz1.w);\n\n  vec4 norm0 = taylorInvSqrt(\n    vec4(dot(g000, g000), dot(g010, g010), dot(g100, g100), dot(g110, g110))\n  );\n  g000 *= norm0.x;\n  g010 *= norm0.y;\n  g100 *= norm0.z;\n  g110 *= norm0.w;\n  vec4 norm1 = taylorInvSqrt(\n    vec4(dot(g001, g001), dot(g011, g011), dot(g101, g101), dot(g111, g111))\n  );\n  g001 *= norm1.x;\n  g011 *= norm1.y;\n  g101 *= norm1.z;\n  g111 *= norm1.w;\n\n  float n000 = dot(g000, Pf0);\n  float n100 = dot(g100, vec3(Pf1.x, Pf0.yz));\n  float n010 = dot(g010, vec3(Pf0.x, Pf1.y, Pf0.z));\n  float n110 = dot(g110, vec3(Pf1.xy, Pf0.z));\n  float n001 = dot(g001, vec3(Pf0.xy, Pf1.z));\n  float n101 = dot(g101, vec3(Pf1.x, Pf0.y, Pf1.z));\n  float n011 = dot(g011, vec3(Pf0.x, Pf1.yz));\n  float n111 = dot(g111, Pf1);\n\n  vec3 fade_xyz = fade(Pf0);\n  vec4 n_z = mix(\n    vec4(n000, n100, n010, n110),\n    vec4(n001, n101, n011, n111),\n    fade_xyz.z\n  );\n  vec2 n_yz = mix(n_z.xy, n_z.zw, fade_xyz.y);\n  float n_xyz = mix(n_yz.x, n_yz.y, fade_xyz.x);\n  return 2.2 * n_xyz;\n}\n\nfloat rand(vec2 n) {\n  return fract(sin(dot(n, vec2(12.9898, 4.1414))) * 43758.5453);\n}\n\nfloat noise(vec2 p) {\n  vec2 ip = floor(p);\n  vec2 u = fract(p);\n  u = u * u * (3.0 - 2.0 * u);\n\n  float res = mix(\n    mix(rand(ip), rand(ip + vec2(1.0, 0.0)), u.x),\n    mix(rand(ip + vec2(0.0, 1.0)), rand(ip + vec2(1.0, 1.0)), u.x),\n    u.y\n  );\n  return res * res;\n}\n\nfloat fbm(vec2 x) {\n  float v = 0.0;\n  float a = 0.5;\n  vec2 shift = vec2(100.0);\n  \n  mat2 rot = mat2(cos(0.5), sin(0.5), -sin(0.5), cos(0.5));\n  for (int i = 0; i < NUM_OCTAVES; ++i) {\n    v += a * noise(x);\n    x = rot * x * 2.0 + shift;\n    a *= 0.5;\n  }\n  return v;\n}\n\n/**\n * End new code for colored orb\n */\n\nColoredSDF applyIdleState(\n  ColoredSDF sdf,\n  SDFArgs args,\n  bool isDarkMode /**\n * new bool\n */\n) {\n  float midRadius = 0.12; \n  float maxRadius = 0.3; \n  float t1 = 1.0; \n  float gamma = 3.0; \n  float omega = pi / 2.0; \n\n  \n  float k = exp(-gamma) * omega;\n\n  float radius;\n  if (args.time <= t1) {\n    \n    float t_prime = args.time / t1;\n    \n    float springValue = 1.0 - exp(-gamma * t_prime) * cos(omega * t_prime);\n    radius = midRadius * springValue;\n  } else {\n    \n    float adjustedTime = args.time - t1;\n    \n    radius =\n      midRadius + (maxRadius - midRadius) * (1.0 - exp(-k * adjustedTime));\n  }\n\n  \n  float distance = length(args.st) - radius;\n\n  \n  sdf.distance = mix(sdf.distance, distance, args.amount);\n\n  \n  \n  float alpha = sin(pi / 0.7 * args.time) * 0.3 + 0.7;\n  vec4 color = vec4(isDarkMode ? vec3(1.0) : vec3(0.0), alpha);\n\n  \n  sdf.color = mix(sdf.color, color, args.amount);\n\n  return sdf;\n}\n\nColoredSDF applyIdleStateLegacy(ColoredSDF sdf, SDFArgs args, bool isDarkMode) {\n  float connectedLinearAnimation = scaled(0.0, 2.0, args.duration);\n  float connectedAnimation = fixedSpring(connectedLinearAnimation, 0.96);\n  float circleSize =\n    mix(\n      pow(scaled(0.0, 3.0, args.time), 2.0) * 0.75 + 0.1,\n      1.0,\n      connectedAnimation\n    ) *\n    0.33;\n  vec2 rotatedCoords = rotate(\n    args.st,\n    -args.time * pi -\n      connectedAnimation * pi * 2.0 -\n      pi * 2.0 * 5.0 * silkySmooth(scaled(0.0, 5.0, args.time), 2.0)\n  );\n\n  float strokeWidth = mix(circleSize / 2.0, circleSize, connectedAnimation);\n  float connecting = abs(length(args.st) - circleSize) - strokeWidth;\n\n  float connected = length(args.st) - circleSize;\n  float idleDist = mix(connecting, connected, connectedAnimation);\n\n  float d = min(sdf.distance, idleDist);\n  sdf.distance = mix(sdf.distance, d, args.amount);\n  float angle = atan(rotatedCoords.y, rotatedCoords.x);\n  float alpha = mix(\n    min(1.0, scaled(-pi, pi, angle)),\n    1.0,\n    connectedLinearAnimation\n  );\n\n  float spinningCircleDist =\n    length(\n      rotatedCoords -\n        vec2(-mix(circleSize, strokeWidth, connectedAnimation), 0.0)\n    ) -\n    strokeWidth;\n\n  alpha = min(\n    1.0,\n    max(\n      alpha,\n      smoothstep(0.005, 0.0, spinningCircleDist) + connectedAnimation * 4.0\n    )\n  );\n\n  sdf.color = mix(\n    sdf.color,\n    vec4(isDarkMode ? vec3(1.0) : vec3(0.0), alpha),\n    args.amount\n  );\n  return sdf;\n}\n\nColoredSDF applyListenState(\n  ColoredSDF sdf,\n  SDFArgs args,\n  float micLevel,\n  float listenTimestamp, /* new */\n  float touchDownTimestamp, /* new */\n  float touchUpTimestamp, /* new */\n  bool fadeBloopWhileListening /* new */\n) {\n  float breathingSequence = sin(args.time) * 0.5 + 0.5;\n  float entryAnimation = fixedSpring(scaled(0.0, 3.0, args.duration), 0.9);\n\n  float touch =\n    fixedSpring(scaled(0.0, 1.0, args.time - touchDownTimestamp), 0.99) -\n    fixedSpring(scaled(0.0, 0.8, args.time - touchUpTimestamp), 1.0);\n\n  float listenAnimation = clamp(\n    spring(scaled(0.0, 0.9, args.duration), 1.0),\n    0.0,\n    1.0\n  );\n  float radius = 0.0;\n  float smoothlevel = micLevel;\n  float l1 = smoothlevel;\n  radius = 0.38 + l1 * 0.05 + breathingSequence * 0.03;\n  radius *= 1.0 - (1.0 - entryAnimation) * 0.25;\n\n  float ring = 10000.0;\n\n  \n  if (touch > 0.0) {\n    touch = min(touch, listenAnimation); \n    float arcWidth = radius * 0.1;\n\n    \n    radius -= touch * arcWidth * 2.3;\n    \n    radius = min(\n      radius,\n      mix(radius, args.mainRadius - arcWidth * 2.3 - l1 * 0.01, touch)\n    );\n\n    float startAngle = 0.0;\n    float arcLengthTouch =\n      smoothstep(0.04, 1.0, touch) * pi * (1.0 - arcWidth / 3.0 / radius);\n\n    float arcLength = 0.0;\n    float radiusTouch =\n      radius * fixedSpring(scaled(0.0, 1.0, args.duration), 1.0) * args.amount +\n      l1 * 0.01;\n\n    radiusTouch +=\n      arcWidth * 1.3 * mix(-1.0, 1.0, smoothstep(0.0, 0.12, touch));\n\n    float ringRadius = 0.0;\n    arcLength = arcLengthTouch;\n    ringRadius = radiusTouch;\n    startAngle = pi / 2.0 - (args.time - touchDownTimestamp) / 2.0;\n\n    ring = arc(args.st, startAngle, arcLength, ringRadius, arcWidth); \n  }\n\n  float d = length(args.st) - radius;\n\n  d = min(d, ring);\n\n  sdf.distance = mix(sdf.distance, d, args.amount);\n\n  if (fadeBloopWhileListening) {\n    \n    sdf.color.a = mix(\n      sdf.color.a,\n      mix(1.0, 1.0 - l1 * 0.6, listenAnimation),\n      args.amount\n    );\n  } else {\n    sdf.color.a = 1.0;\n  }\n\n  return sdf;\n}\n\nColoredSDF applyThinkState(ColoredSDF sdf, SDFArgs args) {\n  float d = 1000.0; \n  int count = 5; \n  float entryAnimation = spring(scaled(0.0, 1.0, args.duration), 1.0);\n\n  float thinkingDotEntryAnimation = spring(\n    scaled(0.1, 1.1, args.duration),\n    1.0\n  );\n  float thinkingDotRadius =\n    mix(0.2, 0.06, thinkingDotEntryAnimation) * args.amount;\n\n  \n  args.st.x -= thinkingDotRadius * 0.5 * thinkingDotEntryAnimation;\n\n  for (int i = 0; i < count; i++) {\n    float f = float(float(i) + 0.5) / float(count); \n    float a =\n      -f * pi * 2.0 +\n      args.time / 3.0 +\n      spring(scaled(0.0, 10.0, args.duration), 1.0) * pi / 2.0;\n    float ringRadi = args.mainRadius * 0.45 * entryAnimation;\n\n    \n    ringRadi -=\n      (sin(\n        entryAnimation * pi * 4.0 +\n          a * pi * 2.0 +\n          args.time * 3.0 -\n          silkySmooth(args.time / 4.0, 2.0) * pi * 1.0\n      ) *\n        0.5 +\n        0.5) *\n      args.mainRadius *\n      0.1;\n\n    vec2 pos = vec2(cos(a), sin(a)) * ringRadi;\n    float dd = length(args.st - pos) - args.mainRadius * 0.5;\n\n    \n    d = opSmoothUnion(\n      d,\n      dd,\n      0.03 * scaled(0.0, 10.0, args.duration) + 0.8 * (1.0 - entryAnimation)\n    );\n\n    \n    float dotAngle = f * pi * 2.0;\n    float dotRingRadius =\n      (sin(\n        thinkingDotEntryAnimation * pi * 4.0 +\n          a * pi * 2.0 +\n          args.time * 0.1 * pi * 4.0\n      ) *\n        0.5 +\n        0.5) *\n      thinkingDotRadius *\n      0.3;\n    vec2 dotPos =\n      vec2(-args.mainRadius, args.mainRadius) * 0.8 * thinkingDotEntryAnimation;\n    vec2 dotOffset =\n      vec2(cos(dotAngle + args.time), sin(dotAngle + args.time)) *\n      dotRingRadius;\n    float dotD = length(args.st - dotPos - dotOffset) - thinkingDotRadius * 0.8;\n    d = opSmoothUnion(\n      d,\n      dotD,\n      (1.0 - min(thinkingDotEntryAnimation, args.amount)) * thinkingDotRadius\n    );\n  }\n  sdf.distance = mix(sdf.distance, d, args.amount);\n  sdf.color.a = 1.0;\n  return sdf;\n}\n\nColoredSDF applySpeakState(\n  ColoredSDF sdf,\n  SDFArgs args,\n  vec4 avgMag,\n  float silenceAmount,\n  float silenceDuration\n) {\n  float d = 1000.0;\n  int barCount = 4;\n  for (int i = 0; i < barCount; i++) {\n    float f = float(float(i) + 0.5) / float(barCount); \n\n    \n    float w = 1.0 / float(barCount) * 0.44;\n    float h = w;\n\n    \n    float wave = sin(f * pi * 0.8 + args.time) * 0.5 + 0.5;\n    float entryAnimation = spring(\n      scaled(0.1 + wave * 0.4, 1.0 + wave * 0.4, args.duration),\n      0.98\n    );\n    vec2 pos = vec2(f - 0.5, 0.0) * args.mainRadius * 1.9;\n    pos.y = 0.25 * (1.0 - entryAnimation);\n\n    \n    if (silenceAmount > 0.0) {\n      float bounceStagger = f / 5.0;\n      float bounceDelay = 0.6;\n      float bounceTimer = scaled(\n        bounceDelay,\n        bounceDelay + 1.0,\n        fract((silenceDuration + bounceStagger) / 2.0) * 2.0\n      );\n      pos.y +=\n        bounce(bounceTimer, 6.0) *\n        w *\n        0.25 *\n        silenceAmount *\n        pow(entryAnimation, 4.0) *\n        pow(args.amount, 4.0); \n    }\n\n    \n    h += avgMag[i] * (0.1 + (1.0 - abs(f - 0.5) * 2.0) * 0.1);\n\n    float dd = sdRoundedBox(args.st - pos, vec2(w, h), vec4(w));\n    d = opSmoothUnion(d, dd, 0.2 * (1.0 - args.amount));\n\n  }\n\n  sdf.distance = mix(sdf.distance, d, args.amount);\n  sdf.color.a = 1.0;\n  return sdf;\n}\n\nColoredSDF applyListenAndSpeakState(\n  ColoredSDF sdf,\n  SDFArgs args,\n  float micLevel,\n  vec4 avgMag,\n  vec4 cumulativeAudio,\n  int binCount,\n  vec3 bloopColorMain,\n  vec3 bloopColorLow,\n  vec3 bloopColorMid,\n  vec3 bloopColorHigh,\n  sampler2D uTextureNoise,\n  bool listening,\n  bool isAdvancedBloop\n) {\n  float entryAnimation = fixedSpring(scaled(0.0, 2.0, args.duration), 0.92);\n\n  \n  \n  float radius =\n    (listening ? 0.37 : 0.43) * (1.0 - (1.0 - entryAnimation) * 0.25) +\n    micLevel * 0.065;\n\n  \n  \n  \n  float maxDisplacement = 0.01;\n\n  \n  float oscillationPeriod = 4.0;\n  \n  float displacementOffset =\n    maxDisplacement * sin(2.0 * pi / oscillationPeriod * args.time);\n  \n  vec2 adjusted_st = args.st - vec2(0.0, displacementOffset);\n\n  \n  if (!isAdvancedBloop) {\n    sdf.color = mix(sdf.color, vec4(bloopColorMain, 1.0), args.amount);\n    sdf.distance = mix(sdf.distance, length(adjusted_st) - radius, args.amount);\n    return sdf;\n  }\n\n  \n  \n  vec4 uAudioAverage = avgMag;\n  vec4 uCumulativeAudio = cumulativeAudio;\n\n  \n  float scaleFactor = 1.0 / (2.0 * radius);\n  vec2 uv = adjusted_st * scaleFactor + 0.5;\n  uv.y = 1.0 - uv.y;\n\n  \n  float noiseScale = 1.25; \n  float windSpeed = 0.075; \n  float warpPower = 0.19; \n  float waterColorNoiseScale = 18.0; \n  float waterColorNoiseStrength = 0.01; \n  float textureNoiseScale = 1.0; \n  float textureNoiseStrength = 0.08; \n  float verticalOffset = 0.09; \n  float waveSpread = 1.0; \n  float layer1Amplitude = 1.0; \n  float layer1Frequency = 1.0; \n  float layer2Amplitude = 1.0; \n  float layer2Frequency = 1.0; \n  float layer3Amplitude = 1.0; \n  float layer3Frequency = 1.0; \n  float fbmStrength = 1.0; \n  float fbmPowerDamping = 0.55; \n  float overallSoundScale = 1.0; \n  float blurRadius = 1.0;\n  float timescale = 1.0;\n\n  \n  float time = args.time * timescale * 0.85;\n\n  vec3 sinOffsets = vec3(\n    uCumulativeAudio.x * 0.15 * overallSoundScale,\n    -uCumulativeAudio.y * 0.5 * overallSoundScale,\n    uCumulativeAudio.z * 1.5 * overallSoundScale\n  );\n  verticalOffset += 1.0 - waveSpread;\n\n  \n  float noiseX = cnoise(\n    vec3(\n      uv * 1.0 + vec2(0.0, 74.8572),\n      (time + uCumulativeAudio.x * 0.05 * overallSoundScale) * 0.3\n    )\n  );\n  float noiseY = cnoise(\n    vec3(\n      uv * 1.0 + vec2(203.91282, 10.0),\n      (time + uCumulativeAudio.z * 0.05 * overallSoundScale) * 0.3\n    )\n  );\n\n  uv += vec2(noiseX * 2.0, noiseY) * warpPower;\n\n  \n  float noiseA =\n    cnoise(vec3(uv * waterColorNoiseScale + vec2(344.91282, 0.0), time * 0.3)) +\n    cnoise(\n      vec3(uv * waterColorNoiseScale * 2.2 + vec2(723.937, 0.0), time * 0.4)\n    ) *\n      0.5;\n  uv += noiseA * waterColorNoiseStrength;\n  uv.y -= verticalOffset;\n\n  \n  vec2 textureUv = uv * textureNoiseScale;\n  float textureSampleR0 = texture(uTextureNoise, textureUv).r;\n  float textureSampleG0 = texture(\n    uTextureNoise,\n    vec2(textureUv.x, 1.0 - textureUv.y)\n  ).g;\n  float textureNoiseDisp0 =\n    mix(\n      textureSampleR0 - 0.5,\n      textureSampleG0 - 0.5,\n      (sin(time + uCumulativeAudio.a * 2.0) + 1.0) * 0.5\n    ) *\n    textureNoiseStrength;\n  textureUv += vec2(63.861 + uCumulativeAudio.x * 0.05, 368.937);\n  float textureSampleR1 = texture(uTextureNoise, textureUv).r;\n  float textureSampleG1 = texture(\n    uTextureNoise,\n    vec2(textureUv.x, 1.0 - textureUv.y)\n  ).g;\n  float textureNoiseDisp1 =\n    mix(\n      textureSampleR1 - 0.5,\n      textureSampleG1 - 0.5,\n      (sin(time + uCumulativeAudio.a * 2.0) + 1.0) * 0.5\n    ) *\n    textureNoiseStrength;\n  textureUv += vec2(272.861, 829.937 + uCumulativeAudio.y * 0.1);\n  textureUv += vec2(180.302 - uCumulativeAudio.z * 0.1, 819.871);\n  float textureSampleR3 = texture(uTextureNoise, textureUv).r;\n  float textureSampleG3 = texture(\n    uTextureNoise,\n    vec2(textureUv.x, 1.0 - textureUv.y)\n  ).g;\n  float textureNoiseDisp3 =\n    mix(\n      textureSampleR3 - 0.5,\n      textureSampleG3 - 0.5,\n      (sin(time + uCumulativeAudio.a * 2.0) + 1.0) * 0.5\n    ) *\n    textureNoiseStrength;\n  uv += textureNoiseDisp0;\n\n  \n  vec2 st = uv * noiseScale;\n\n  vec2 q = vec2(0.0);\n  q.x = fbm(\n    st * 0.5 +\n      windSpeed * (time + uCumulativeAudio.a * 0.175 * overallSoundScale)\n  );\n  q.y = fbm(\n    st * 0.5 +\n      windSpeed * (time + uCumulativeAudio.x * 0.136 * overallSoundScale)\n  );\n\n  vec2 r = vec2(0.0);\n  r.x = fbm(\n    st +\n      1.0 * q +\n      vec2(0.3, 9.2) +\n      0.15 * (time + uCumulativeAudio.y * 0.234 * overallSoundScale)\n  );\n  r.y = fbm(\n    st +\n      1.0 * q +\n      vec2(8.3, 0.8) +\n      0.126 * (time + uCumulativeAudio.z * 0.165 * overallSoundScale)\n  );\n\n  float f = fbm(st + r - q);\n  float fullFbm = (f + 0.6 * f * f + 0.7 * f + 0.5) * 0.5;\n  fullFbm = pow(fullFbm, fbmPowerDamping);\n  fullFbm *= fbmStrength;\n\n  \n  blurRadius = blurRadius * 1.5;\n  vec2 snUv =\n    (uv + vec2((fullFbm - 0.5) * 1.2) + vec2(0.0, 0.025) + textureNoiseDisp0) *\n    vec2(layer1Frequency, 1.0);\n  float sn =\n    noise(\n      snUv * 2.0 + vec2(sin(sinOffsets.x * 0.25), time * 0.5 + sinOffsets.x)\n    ) *\n    2.0 *\n    layer1Amplitude;\n  float sn2 = smoothstep(\n    sn - 1.2 * blurRadius,\n    sn + 1.2 * blurRadius,\n    (snUv.y - 0.5 * waveSpread) *\n      (5.0 - uAudioAverage.x * 0.1 * overallSoundScale * 0.5) +\n      0.5\n  );\n\n  vec2 snUvBis =\n    (uv + vec2((fullFbm - 0.5) * 0.85) + vec2(0.0, 0.025) + textureNoiseDisp1) *\n    vec2(layer2Frequency, 1.0);\n  float snBis =\n    noise(\n      snUvBis * 4.0 +\n        vec2(\n          sin(sinOffsets.y * 0.15) * 2.4 + 293.0,\n          time * 1.0 + sinOffsets.y * 0.5\n        )\n    ) *\n    2.0 *\n    layer2Amplitude;\n  float sn2Bis = smoothstep(\n    snBis - (0.9 + uAudioAverage.y * 0.4 * overallSoundScale) * blurRadius,\n    snBis + (0.9 + uAudioAverage.y * 0.8 * overallSoundScale) * blurRadius,\n    (snUvBis.y - 0.6 * waveSpread) * (5.0 - uAudioAverage.y * 0.75) + 0.5\n  );\n\n  vec2 snUvThird =\n    (uv + vec2((fullFbm - 0.5) * 1.1) + textureNoiseDisp3) *\n    vec2(layer3Frequency, 1.0);\n  float snThird =\n    noise(\n      snUvThird * 6.0 +\n        vec2(\n          sin(sinOffsets.z * 0.1) * 2.4 + 153.0,\n          time * 1.2 + sinOffsets.z * 0.8\n        )\n    ) *\n    2.0 *\n    layer3Amplitude;\n  float sn2Third = smoothstep(\n    snThird - 0.7 * blurRadius,\n    snThird + 0.7 * blurRadius,\n    (snUvThird.y - 0.9 * waveSpread) * 6.0 + 0.5\n  );\n\n  sn2 = pow(sn2, 0.8);\n  sn2Bis = pow(sn2Bis, 0.9);\n\n  \n  vec3 sinColor;\n  sinColor = blendLinearBurn_13_5(bloopColorMain, bloopColorLow, 1.0 - sn2);\n  sinColor = blendLinearBurn_13_5(\n    sinColor,\n    mix(bloopColorMain, bloopColorMid, 1.0 - sn2Bis),\n    sn2\n  );\n  sinColor = mix(\n    sinColor,\n    mix(bloopColorMain, bloopColorHigh, 1.0 - sn2Third),\n    sn2 * sn2Bis\n  );\n\n  \n  sdf.color = mix(sdf.color, vec4(sinColor, 1), args.amount);\n\n  \n  sdf.distance = mix(sdf.distance, length(adjusted_st) - radius, args.amount);\n\n  return sdf;\n}\n\nfloat micSdf(vec2 st, float muted) {\n  float d = 100.0;\n  float strokeWidth = 0.03;\n  vec2 elementSize = vec2(0.12, 0.26);\n  vec2 elementPos = vec2(0.0, elementSize.y * 0.585);\n  float element = sdRoundedBox(\n    st - elementPos,\n    elementSize,\n    vec4(min(elementSize.x, elementSize.y))\n  );\n  element = element - strokeWidth;\n  d = min(d, element);\n\n  vec2 standSize = elementSize * 2.2;\n  vec2 standPos = vec2(elementPos.x, elementPos.y - 0.05);\n  st.y += 0.08;\n  float ta = -pi / 2.0; \n  float tb = pi / 2.0; \n  float w = 0.0;\n  float stand = sdArc(\n    st - standPos,\n    vec2(sin(ta), cos(ta)),\n    vec2(sin(tb), cos(tb)),\n    standSize.x,\n    w\n  );\n  stand = min(\n    stand,\n    sdSegment(st - standPos, vec2(standSize.x, 0.06), vec2(standSize.x, 0.0))\n  );\n  stand = min(\n    stand,\n    sdSegment(st - standPos, vec2(-standSize.x, 0.06), vec2(-standSize.x, 0.0))\n  );\n\n  float foot = sdSegment(\n    st - standPos,\n    vec2(0.0, -standSize.x),\n    vec2(0.0, -standSize.x * 1.66)\n  );\n  foot = min(\n    foot,\n    sdSegment(\n      st - standPos,\n      vec2(-standSize.x * 0.68, -standSize.x * 1.66),\n      vec2(standSize.x * 0.68, -standSize.x * 1.66)\n    )\n  );\n  stand = min(stand, foot);\n\n  d = min(d, abs(stand) - strokeWidth);\n\n  return d;\n}\n\nColoredSDF applyBottomAlignedBarsAndMicState(\n  ColoredSDF sdf,\n  SDFArgs args,\n  vec4 avgMag,\n  float micLevel,\n  bool isDarkMode\n) {\n  float d = 1000.0;\n  int barCount = 5;\n  int loopCount = barCount;\n  if (args.amount == 0.0) {\n    loopCount = 1; \n  }\n  for (int i = 0; i < loopCount; i++) {\n    float f = float(float(i) + 0.5) / float(barCount); \n\n    \n    float w = 1.0 / float(barCount) * 0.42;\n    float h = w;\n\n    \n    float entryDuration = 1.8;\n    float entryAnimation =\n      fixedSpring(scaled(0.0, entryDuration, args.duration), 0.94) *\n      args.amount;\n    vec2 pos = vec2(f - 0.5, 0.0) * args.mainRadius * 1.9;\n    pos.x *= entryAnimation;\n\n    if (i == 0) {\n      float micScale = mix(6.0 - micLevel * 2.0, 6.0, args.amount);\n      float yOffset = w * 2.0;\n      d =\n        micSdf(\n          (args.st - pos + vec2(-w * 0.15 * args.amount, yOffset)) * micScale,\n          1.0 - args.amount\n        ) /\n        micScale;\n    } else {\n      \n      h += avgMag[i - 1] * (0.1 + (1.0 - abs(f - 0.5) * 2.0) * 0.1) * 0.7;\n      h = mix(w, h, smoothstep(0.8, 1.0, entryAnimation));\n\n      float bubbleInDur = 0.5;\n      float bubbleOutDur = 0.4;\n\n      \n      float bubbleEffect =\n        fixedSpring(\n          scaled(\n            f / 4.0,\n            f / 4.0 + bubbleInDur,\n            args.duration - entryDuration / 8.0\n          ),\n          1.0\n        ) *\n        pow(\n          1.0 -\n            scaled(\n              f / 8.0 + bubbleInDur / 8.0,\n              f / 4.0 + bubbleInDur / 8.0 + bubbleOutDur,\n              args.duration - entryDuration / 8.0\n            ),\n          2.0\n        );\n\n      h += bubbleEffect * min(h, w);\n\n      \n      w *= args.amount;\n      h *= args.amount;\n\n      h = min(h, 0.23); \n\n      pos.y -= 0.25;\n      pos.y += h;\n      pos.y += bubbleEffect * w * 0.5;\n\n      float dd = sdRoundedBox(args.st - pos, vec2(w, h), vec4(w));\n      d = min(d, dd);\n    }\n  }\n\n  sdf.distance = d; \n  sdf.color = mix(\n    sdf.color,\n    isDarkMode\n      ? vec4(1.0)\n      : vec4(0.0, 0.0, 0.0, 1.0),\n    args.amount\n  );\n  return sdf;\n}\n\nColoredSDF applyHaltState(ColoredSDF sdf, SDFArgs args) {\n  \n  float radius = mix(\n    0.4,\n    mix(0.4, 0.45, args.amount),\n    sin(args.time * 0.25) * 0.5 + 0.5\n  );\n  float strokeWidth = mix(radius / 2.0, 0.02, args.amount);\n\n  \n  radius -= strokeWidth;\n\n  radius *= mix(0.7, 1.0, args.amount);\n  float circle = abs(length(args.st) - radius) - strokeWidth;\n\n  sdf.distance = mix(sdf.distance, circle, args.amount);\n  sdf.color.a = mix(sdf.color.a, pow(0.8, 2.2), scaled(0.5, 1.0, args.amount));\n  return sdf;\n}\n\nvec3 blendNormal(vec3 base, vec3 blend) {\n  return blend;\n}\n\nvec3 blendNormal(vec3 base, vec3 blend, float opacity) {\n  return blendNormal(base, blend) * opacity + base * (1.0 - opacity);\n}\n\nin vec2 out_uv;\nout vec4 fragColor;\n\nlayout(std140) uniform BlorbUniformsObject {\n  float time;\n  float micLevel;\n  float touchDownTimestamp;\n  float touchUpTimestamp;\n  float stateListen;\n  float listenTimestamp;\n  float stateThink;\n  float thinkTimestamp;\n  float stateSpeak;\n  float speakTimestamp;\n  float readyTimestamp;\n  float stateHalt;\n  float haltTimestamp;\n  float stateFailedToConnect;\n  float failedToConnectTimestamp;\n  vec4 avgMag;\n  vec4 cumulativeAudio;\n  vec2 viewport;\n  float screenScaleFactor;\n  float silenceAmount;\n  float silenceTimestamp;\n  bool isDarkMode;\n  bool fadeBloopWhileListening;\n  bool isNewBloop;\n  bool isAdvancedBloop;\n  vec3 bloopColorMain;\n  vec3 bloopColorLow;\n  vec3 bloopColorMid;\n  vec3 bloopColorHigh;\n} ubo; \n\nuniform sampler2D uTextureNoise; \n\nvoid main() {\n  vec2 st = out_uv - 0.5;\n  float viewRatio = ubo.viewport.y / ubo.viewport.x;\n  st.y *= viewRatio;\n\n  ColoredSDF sdf;\n  sdf.distance = 1000.0;\n  sdf.color = vec4(1.0);\n\n  SDFArgs args;\n  args.st = st;\n  args.time = ubo.time;\n  args.mainRadius = 0.49;\n\n  SDFArgs idleArgs = args;\n  SDFArgs listenArgs = args;\n  SDFArgs thinkArgs = args;\n  SDFArgs speakArgs = args;\n  SDFArgs haltArgs = args;\n  SDFArgs failedToConnectArgs = args;\n\n  idleArgs.amount = 1.0;\n  listenArgs.amount = ubo.stateListen;\n  thinkArgs.amount = ubo.stateThink;\n  speakArgs.amount = ubo.stateSpeak;\n  haltArgs.amount = ubo.stateHalt;\n  failedToConnectArgs.amount = ubo.stateFailedToConnect;\n\n  idleArgs.duration = ubo.time - ubo.readyTimestamp;\n  listenArgs.duration = ubo.time - ubo.listenTimestamp;\n  thinkArgs.duration = ubo.time - ubo.thinkTimestamp;\n  speakArgs.duration = ubo.time - ubo.speakTimestamp;\n  haltArgs.duration = ubo.time - ubo.haltTimestamp;\n  failedToConnectArgs.duration = ubo.time - ubo.failedToConnectTimestamp;\n\n  if (ubo.isNewBloop) {\n    sdf = applyIdleState(sdf, idleArgs, ubo.isDarkMode);\n  } else {\n    sdf = applyIdleStateLegacy(sdf, idleArgs, ubo.isDarkMode);\n  }\n\n  if (failedToConnectArgs.amount > 0.0) {\n    sdf = applyHaltState(sdf, failedToConnectArgs);\n  }\n\n  if (listenArgs.amount > 0.0) {\n    if (ubo.isAdvancedBloop) {\n      if (speakArgs.amount > 0.0) {\n        listenArgs.amount = 1.0;\n      }\n\n      \n      int binCount = 1;\n      sdf = applyListenAndSpeakState(\n        sdf,\n        listenArgs,\n        ubo.micLevel,\n        ubo.avgMag,\n        ubo.cumulativeAudio,\n        binCount,\n        ubo.bloopColorMain,\n        ubo.bloopColorLow,\n        ubo.bloopColorMid,\n        ubo.bloopColorHigh,\n        uTextureNoise,\n        true,\n        ubo.isAdvancedBloop\n      );\n    } else {\n      sdf = applyListenState(\n        sdf,\n        listenArgs,\n        ubo.micLevel,\n        ubo.listenTimestamp,\n        ubo.touchDownTimestamp,\n        ubo.touchUpTimestamp,\n        ubo.fadeBloopWhileListening\n      );\n    }\n  }\n\n  if (thinkArgs.amount > 0.0) {\n    sdf = applyThinkState(sdf, thinkArgs);\n  }\n\n  if (speakArgs.amount > 0.0) {\n    if (ubo.isAdvancedBloop) {\n      int binCount = 1;\n      sdf = applyListenAndSpeakState(\n        sdf,\n        speakArgs,\n        ubo.micLevel,\n        ubo.avgMag,\n        ubo.cumulativeAudio,\n        binCount,\n        ubo.bloopColorMain,\n        ubo.bloopColorLow,\n        ubo.bloopColorMid,\n        ubo.bloopColorHigh,\n        uTextureNoise,\n        false,\n        ubo.isAdvancedBloop\n      );\n    } else {\n      float silenceDuration = ubo.time - ubo.silenceTimestamp;\n      sdf = applySpeakState(\n        sdf,\n        speakArgs,\n        ubo.avgMag,\n        ubo.silenceAmount,\n        silenceDuration\n      );\n    }\n  }\n\n  if (haltArgs.amount > 0.0) {\n    sdf = applyHaltState(sdf, haltArgs);\n  }\n\n  float clampingTolerance = 0.0075 / ubo.screenScaleFactor;\n  float clampedShape = smoothstep(clampingTolerance, 0.0, sdf.distance);\n  float alpha = sdf.color.a * clampedShape;\n  if (!ubo.isNewBloop) {\n    alpha *= scaled(0.0, 1.0, ubo.time);\n  }\n  fragColor = vec4(sdf.color.rgb * alpha, alpha);\n}",
    pt = "#version 300 es\n\nout vec4 out_position;\nout vec2 out_uv;\n\nconst vec4 blitFullscreenTrianglePositions[6] = vec4[](\n  vec4(-1.0, -1.0, 0.0, 1.0),\n  vec4(3.0, -1.0, 0.0, 1.0),\n  vec4(-1.0, 3.0, 0.0, 1.0),\n  vec4(-1.0, -1.0, 0.0, 1.0),\n  vec4(3.0, -1.0, 0.0, 1.0),\n  vec4(-1.0, 3.0, 0.0, 1.0)\n);\n\nvoid main() {\n  out_position = blitFullscreenTrianglePositions[gl_VertexID];\n  out_uv = out_position.xy * 0.5 + 0.5;\n  out_uv.y = 1.0 - out_uv.y;\n  gl_Position = out_position;\n}",
    L, W, w, z, N, _, E, tn;
const on = class on {
    constructor(n, e) {
        M(this, L);
        M(this, W);
        M(this, w);
        M(this, z, []);
        M(this, N, {});
        M(this, _);
        M(this, E);
        T(this, w, n);
        const s = n.getUniformBlockIndex(e, x(on, tn)),
            o = n.getActiveUniformBlockParameter(e, s, n.UNIFORM_BLOCK_DATA_SIZE);
        T(this, _, n.createBuffer()), n.bindBuffer(n.UNIFORM_BUFFER, x(this, _)), n.bufferData(n.UNIFORM_BUFFER, o, n.DYNAMIC_DRAW);
        const f = 0;
        n.bindBufferBase(n.UNIFORM_BUFFER, f, x(this, _)), n.uniformBlockBinding(e, s, f);
        const r = n.getActiveUniformBlockParameter(e, s, n.UNIFORM_BLOCK_ACTIVE_UNIFORM_INDICES);
        T(this, z, []), T(this, N, {});
        for (let l = 0; l < r.length; l++) {
            const a = r[l],
                u = n.getActiveUniform(e, a);
            if (!u) throw new Error("No uniformInfo for index " + a);
            let i = u.name;
            i = i.replace(/\[0\]$/, "");
            const p = n.getActiveUniforms(e, [a], n.UNIFORM_OFFSET)[0];
            x(this, z).push(i), x(this, N)[i] = p
        }
        T(this, E, new ArrayBuffer(o)), T(this, L, new Float32Array(x(this, E))), T(this, W, new Int32Array(x(this, E)))
    }
    setVariablesAndRender(n) {
        for (const e of x(this, z)) {
            const [, s] = e.split("."), f = x(this, N)[e] / 4, r = n[s];
            typeof r == "number" ? x(this, L)[f] = r : typeof r == "boolean" ? x(this, W)[f] = r ? 1 : 0 : Array.isArray(r) && x(this, L).set(r, f)
        }
        x(this, w).bindBuffer(x(this, w).UNIFORM_BUFFER, x(this, _)), x(this, w).bufferSubData(x(this, w).UNIFORM_BUFFER, 0, x(this, E)), x(this, w).drawArrays(x(this, w).TRIANGLE_STRIP, 0, 6)
    }
};
L = new WeakMap, W = new WeakMap, w = new WeakMap, z = new WeakMap, N = new WeakMap, _ = new WeakMap, E = new WeakMap, tn = new WeakMap, M(on, tn, "BlorbUniformsObject");
let bn = on;

function v(t) {
    const n = t.replace("#", ""),
        e = parseInt(n.substring(0, 2), 16) / 255,
        s = parseInt(n.substring(2, 4), 16) / 255,
        o = parseInt(n.substring(4, 6), 16) / 255;
    return new Float32Array([e, s, o])
}
const q = {
        BLUE: {
            bloopColorMain: v("#DCF7FF"),
            bloopColorLow: v("#0181FE"),
            bloopColorMid: v("#A4EFFF"),
            bloopColorHigh: v("#FFFDEF")
        },
        DARK_BLUE: {
            bloopColorMain: v("#DAF5FF"),
            bloopColorLow: v("#0066CC"),
            bloopColorMid: v("#2EC6F5"),
            bloopColorHigh: v("#72EAF5")
        },
        GREYSCALE: {
            bloopColorMain: v("#D7D7D7"),
            bloopColorLow: v("#303030"),
            bloopColorMid: v("#989898"),
            bloopColorHigh: v("#FFFFFF")
        },
        WHITE: {
            bloopColorMain: v("#FFFFFF"),
            bloopColorLow: v("#FFFFFF"),
            bloopColorMid: v("#FFFFFF"),
            bloopColorHigh: v("#FFFFFF")
        },
        BLACK: {
            bloopColorMain: v("#000000"),
            bloopColorLow: v("#000000"),
            bloopColorMid: v("#000000"),
            bloopColorHigh: v("#000000")
        },
        ANGSTY_BLACK: {
            bloopColorMain: v("#494949"),
            bloopColorLow: v("#000000"),
            bloopColorMid: v("#7F7F7F"),
            bloopColorHigh: v("#696969")
        },
        HELLO_TIBOR: {
            bloopColorMain: v("#FFE987"),
            bloopColorLow: v("#E58B28"),
            bloopColorMid: v("#FB7256"),
            bloopColorHigh: v("#F3FDFE")
        }
    },
    vt = ({
        isAdvanced: t,
        overrideColor: n
    }) => {
        const e = Yn();
        return n && q[n] ? q[n] : t ? q.BLUE : e ? q.WHITE : q.BLACK
    },
    bt = () => $n().some(n => n.voice === "shade"),
    Vn = Ce.JumpToShade,
    ht = () => {
        const t = In.getItem(Vn) === "true",
            n = d.useCallback(() => {
                In.setItem(Vn, "true")
            }, []);
        return {
            alreadyTriggered: t,
            setAlreadyTriggered: n
        }
    };

function xt() {
    let t = null,
        n, e = 0;
    const s = 350;
    let o;
    const f = (l, a, u) => l + (a - l) * u,
        r = (l, a) => {
            if (l.length !== a.length) return !1;
            for (let u = 0; u < l.length; u++)
                if (l[u] !== a[u]) return !1;
            return !0
        };
    return function(a) {
        const u = performance.now();
        if (!t) return n = {
            bloopColorMain: new Float32Array(a.bloopColorMain),
            bloopColorLow: new Float32Array(a.bloopColorLow),
            bloopColorMid: new Float32Array(a.bloopColorMid),
            bloopColorHigh: new Float32Array(a.bloopColorHigh)
        }, t = {
            bloopColorMain: new Float32Array(a.bloopColorMain),
            bloopColorLow: new Float32Array(a.bloopColorLow),
            bloopColorMid: new Float32Array(a.bloopColorMid),
            bloopColorHigh: new Float32Array(a.bloopColorHigh)
        }, e = u, o = n, o;
        let i = !1;
        const p = ["bloopColorMain", "bloopColorLow", "bloopColorMid", "bloopColorHigh"];
        for (const g of p)
            if (!r(a[g], t[g])) {
                i = !0;
                break
            }
        i && (n = {
            bloopColorMain: new Float32Array(o.bloopColorMain),
            bloopColorLow: new Float32Array(o.bloopColorLow),
            bloopColorMid: new Float32Array(o.bloopColorMid),
            bloopColorHigh: new Float32Array(o.bloopColorHigh)
        }, e = u, t = {
            bloopColorMain: new Float32Array(a.bloopColorMain),
            bloopColorLow: new Float32Array(a.bloopColorLow),
            bloopColorMid: new Float32Array(a.bloopColorMid),
            bloopColorHigh: new Float32Array(a.bloopColorHigh)
        });
        let m = (u - e) / s;
        m > 1 && (m = 1);
        const b = {
            bloopColorMain: new Float32Array(n.bloopColorMain.length),
            bloopColorLow: new Float32Array(n.bloopColorLow.length),
            bloopColorMid: new Float32Array(n.bloopColorMid.length),
            bloopColorHigh: new Float32Array(n.bloopColorHigh.length)
        };
        for (const g of p) {
            const h = n[g].length;
            for (let C = 0; C < h; C++) {
                const R = n[g][C],
                    U = a[g][C];
                b[g][C] = f(R, U, m)
            }
        }
        return o = b, b
    }
}
const Wn = [300, 300],
    At = {
        bands: 4,
        loPass: 0,
        hiPass: 400
    },
    yt = t => {
        const n = hn(t, {
            bands: xn,
            updateInterval: an,
            loPass: 0,
            hiPass: 400,
            analyserOptions: {
                fftSize: Xn
            }
        });
        return n.length === 0 ? Jn : n
    },
    St = (t, n) => {
        const e = yt(t),
            s = Qn(e, {
                sampleRate: ne,
                binCount: n.bins,
                bandCount: n.bands,
                gainMultipliers: n.gainMultipliers
            }),
            o = An({
                magnitudes: e,
                binCount: 1,
                gainMultiplier: 1
            });
        return {
            bandMagnitudes: s,
            cumulativeMagnitude: o
        }
    },
    Ct = t => {
        const [n, e] = d.useState({
            audioData: [0, 0, 0, 0],
            cumulativeAudioData: [0, 0, 0, 0]
        }), s = d.useRef([0, 0, 0, 0]), o = d.useRef(void 0), f = d.useRef(performance.now()), {
            bandMagnitudes: r,
            cumulativeMagnitude: l
        } = St(t, {
            bands: 3,
            bins: 1,
            gainMultipliers: [10, 1, 1]
        });
        s.current = [...r, l].flat();
        const a = d.useCallback(() => {
            const u = performance.now(),
                i = (u - f.current) / 1e3;
            f.current = u;
            const p = s.current,
                {
                    audioData: m,
                    cumulativeAudioData: b
                } = n,
                g = dt({
                    deltaTimeS: i,
                    audioDataRaw: p,
                    prevAudioData: m,
                    prevCumulativeAudioData: b
                });
            e(g)
        }, [n]);
        return d.useEffect(() => (o.current || (o.current = window.setInterval(a, an)), () => {
            clearInterval(o.current), o.current = void 0
        }), [a]), n
    },
    Gn = Promise.resolve();

function te({
    url: t,
    readyToPlay: n
}) {
    const e = d.useRef(void 0),
        s = d.useRef(Gn);
    return d.useEffect(() => (e.current || (e.current = document.createElement("audio")), () => {
        s.current.then(() => {
            e.current && (e.current.pause(), e.current.removeAttribute("src"), e.current.remove(), s.current = Gn)
        })
    }), []), d.useEffect(() => {
        t && e.current && e.current.src !== t && n && s.current.then(() => {
            e.current && (e.current.crossOrigin = "anonymous", e.current.src = t, s.current = e.current.play())
        })
    }, [n, t]), e.current
}

function wt({
    className: t,
    url: n
}) {
    const [e, s] = d.useState(!1), o = te({
        url: n,
        readyToPlay: e
    }), f = hn(o, At), r = d.useMemo(() => [0, 0, 0, 0], []);
    return c.jsx(oe, {
        className: t,
        isAdvanced: !1,
        avgMag: f,
        cumulativeAudioData: r,
        onRenderComplete: () => s(!0)
    })
}

function Ft({
    className: t,
    url: n,
    overrideColor: e
}) {
    const [s, o] = d.useState(!1), f = te({
        url: n,
        readyToPlay: s
    }), r = Ct(f), {
        audioData: l,
        cumulativeAudioData: a
    } = r;
    return c.jsx(oe, {
        className: t,
        isAdvanced: !0,
        overrideColor: e,
        avgMag: l,
        cumulativeAudioData: a,
        onRenderComplete: () => o(!0)
    })
}
const oe = ({
    className: t,
    avgMag: n,
    cumulativeAudioData: e,
    isAdvanced: s,
    overrideColor: o,
    onRenderComplete: f
}) => {
    const r = Yn(),
        l = d.useMemo(() => performance.now() / 1e3, []),
        a = d.useMemo(() => performance.now() / 1e3, []),
        u = d.useRef(void 0),
        i = d.useRef(xt()),
        [p, m] = d.useState(Wn),
        {
            canvasSizeRef: b,
            handleCanvasSizeUpdate: g
        } = Ue(Wn),
        h = d.useCallback(P => {
            m([P.width, P.height])
        }, []),
        [C, R] = d.useState(performance.now() / 1e3);
    d.useEffect(() => {
        const P = setInterval(() => {
            R(performance.now() / 1e3)
        }, an);
        return () => clearInterval(P)
    }, []);
    const U = vt({
            isAdvanced: s,
            overrideColor: o
        }),
        I = i.current(U),
        A = Qe({
            viewport: p,
            canvasSize: b.current,
            shouldMeasurePerf: !0,
            source: "VoicePicker"
        }),
        D = tt({
            shouldCalibrate: !0,
            viewport: p,
            initialScale: 1
        });
    return u.current = {
        time: C,
        micLevel: 0,
        stateListen: 0,
        listenTimestamp: 0,
        stateThink: 0,
        thinkTimestamp: 0,
        stateSpeak: 1,
        speakTimestamp: a,
        readyTimestamp: l,
        stateHalt: 0,
        haltTimestamp: 0,
        touchDownTimestamp: 0,
        touchUpTimestamp: 0,
        stateFailedToConnect: 0,
        failedToConnectTimestamp: 0,
        avgMag: n,
        cumulativeAudio: e,
        isNewBloop: !0,
        isAdvancedBloop: s,
        bloopColorMain: Array.from(I.bloopColorMain),
        bloopColorLow: Array.from(I.bloopColorLow),
        bloopColorMid: Array.from(I.bloopColorMid),
        bloopColorHigh: Array.from(I.bloopColorHigh),
        isDarkMode: r,
        screenScaleFactor: window.devicePixelRatio,
        viewport: p,
        silenceAmount: 0,
        silenceTimestamp: 0,
        fadeBloopWhileListening: !1
    }, c.jsx(Xe, {
        className: V("flex items-center justify-center", t),
        variablesRef: u,
        onViewportUpdate: h,
        onRenderComplete: f,
        textureImage: ee,
        textureName: "uTextureNoise",
        onGlAvailable: A,
        onCanvasSizeUpdate: g,
        scale: D,
        GLUniformsSetter: bn,
        vert: pt,
        frag: gt
    })
};

function Mt({
    isUnauthenticated: t,
    loading: n,
    handleLoginClick: e,
    handleCancelClick: s,
    handleConfirmClick: o,
    selectedVoice: f,
    currentVoiceName: r,
    cameFromNux: l
}) {
    const a = "w-52 whitespace-nowrap rounded-full px-20 py-3 font-semibold";
    return t ? c.jsxs(c.Fragment, {
        children: [c.jsx(nn, {
            className: a,
            onClick: e,
            children: n ? c.jsx(Pn, {}) : c.jsx(k, {
                id: "IRALWH",
                defaultMessage: "Log in"
            })
        }), c.jsx(nn, {
            className: V(a, "text-black dark:text-white"),
            color: "ghost",
            onClick: s,
            children: c.jsx(k, {
                id: "8fumUc",
                defaultMessage: "Back to chat"
            })
        })]
    }) : c.jsxs(c.Fragment, {
        children: [c.jsx(nn, {
            className: V(a),
            onClick: o,
            children: n ? c.jsx(Pn, {}) : (f == null ? void 0 : f.voice) === r && !l ? c.jsx(k, {
                id: "MyKAgb",
                defaultMessage: "Done"
            }) : c.jsx(k, {
                id: "7+3LaJ",
                defaultMessage: "Start new chat"
            })
        }), c.jsx(nn, {
            className: V(a, "text-black dark:text-white"),
            color: "ghost",
            onClick: s,
            children: c.jsx(k, {
                id: "dUn4Wd",
                defaultMessage: "Cancel"
            })
        })]
    })
}
const Dt = {
    offscreenLeft: {
        x: "-24rem",
        opacity: 0
    },
    left: {
        x: "-12rem",
        opacity: .5
    },
    center: {
        x: "0",
        opacity: 1
    },
    right: {
        x: "12rem",
        opacity: .5
    },
    offscreenRight: {
        x: "24rem",
        opacity: 0
    }
};

function Lt({
    conversationId: t,
    onClose: n,
    cameFromNux: e = !1,
    initialVoiceName: s
}) {
    const o = Fe(),
        f = we(o),
        r = !Me(),
        {
            voiceName: l
        } = Be(),
        a = Oe(),
        u = De(),
        i = $n(),
        [p, m] = d.useState(!1),
        b = Ln.getGizmoId(zn(t)),
        [g, h] = d.useState(!1),
        [C, R] = d.useState(!1);
    d.useEffect(() => {
        requestAnimationFrame(() => h(!0))
    }, []);
    const [U, I] = d.useState(!1), [A, D] = d.useState(null);
    d.useEffect(() => {
        if (i.length > 0) {
            const y = i.findIndex(F => F.voice === (s || l));
            y >= 0 ? D(y) : D(2), I(!0)
        }
    }, [i, l, s]);
    const P = A != null ? (A - 2 + i.length) % i.length : 0,
        G = A != null ? (A - 1 + i.length) % i.length : 1,
        K = A != null ? (A + 1) % i.length : 3,
        ae = A != null ? (A + 2) % i.length : 4,
        S = i[A != null ? A : 0],
        Y = i[P],
        Z = i[G],
        $ = i[K],
        X = i[ae],
        B = bt(),
        {
            alreadyTriggered: yn,
            setAlreadyTriggered: sn
        } = ht();
    d.useEffect(() => {
        if (B && !yn) {
            const y = i.findIndex(F => F.voice === "shade");
            y !== -1 && (D(y), sn())
        }
        return () => {
            B && sn()
        }
    }, [B, yn, i, D, sn]);
    const se = d.useMemo(() => {
            if (B && (S == null ? void 0 : S.voice) === "shade") return "ANGSTY_BLACK"
        }, [S == null ? void 0 : S.voice, B]),
        J = y => {
            D(y)
        },
        {
            stopVoiceMode: Sn,
            startVoiceMode: Cn
        } = $e({
            requestMicPermissions: e
        }),
        {
            setValue: wn
        } = je(Te.VoiceName),
        ie = qe(y => y.voiceMode),
        rn = e && !b ? "advanced" : ie,
        re = d.useCallback(() => {
            R(!e), setTimeout(() => {
                var F, O;
                const y = A != null ? (F = i[A]) == null ? void 0 : F.voice : (O = i[0]) == null ? void 0 : O.voice;
                sessionStorage.setItem("selectedVoiceName", y), Re(o, {
                    fallbackScreenHint: "login",
                    callback: j => {
                        ke.logLogInButtonClicked({
                            provider: j,
                            location: "Voice Picker Page"
                        }, _e.ACCESS_FLOW_ENTRY_POINT_VOICE_PICKER_PAGE)
                    },
                    skipLoginModal: !1
                })
            }, cn)
        }, [e, o, A, i]),
        le = d.useCallback(async () => {
            R(!e), setTimeout(async () => {
                var F, O;
                m(!0);
                const y = A != null ? (F = i[A]) == null ? void 0 : F.voice : (O = i[0]) == null ? void 0 : O.voice;
                if (e || y !== l) {
                    e || vn.voiceSelected.click({
                        action: "changed",
                        voice: y
                    }), wn(y), await Sn(), He("/");
                    try {
                        Ve(We.ModalVoicePicker), e ? f ? (Ge({
                            type: "START"
                        }), Ke(), Ee({
                            showVoiceNuxFullPage: !1
                        })) : a.setState(j => {
                            j.isVoiceModeActive = !0
                        }) : await Cn({
                            conversation_id: void 0,
                            eventSource: "voice_picker",
                            voice_mode: rn,
                            voice: y,
                            clientThreadId: Ie(),
                            gizmo_id: Ln.getGizmoId(zn(t)),
                            skipCacheReason: "user-switched-voice"
                        })
                    } catch (j) {
                        Pe.addError("Failed to start voice mode after voice picker: ".concat(j), {
                            protocol: u
                        })
                    }
                } else vn.voiceSelected.click({
                    action: "kept",
                    voice: l
                });
                m(!1), n()
            }, cn)
        }, [e, A, i, l, n, wn, Sn, f, a, Cn, rn, t, u]),
        ce = () => {
            R(!0), setTimeout(n, cn)
        };
    Ye({
        setSelectedVoiceIndex: D,
        prevVoiceIndex: G,
        nextVoiceIndex: K
    });
    const [Fn, Mn] = d.useState(!1), Dn = y => {
        y === "prev" ? J(G) : y === "next" && J(K), Mn(!0), setTimeout(() => {
            Mn(!1)
        }, 175)
    }, Tn = d.useMemo(() => ({
        className: "h-max min-h-bloop w-max min-w-bloop",
        url: S == null ? void 0 : S.preview_url
    }), [S == null ? void 0 : S.preview_url]);
    return !U || A == null ? c.jsx("div", {
        className: "bg-token-main-surface-primary fixed start-0 top-0 z-50 flex h-full w-full"
    }) : c.jsxs("div", {
        className: "fixed start-0 top-0 z-50 flex h-full w-full flex-col items-center justify-center bg-white transition-opacity duration-300 dark:bg-gray-800 ".concat(g && !C ? "opacity-100" : "opacity-0"),
        children: [c.jsx("h1", {
            className: "mt-36 mb-8 text-3xl font-semibold",
            children: r ? c.jsx(k, {
                id: "P4GR/e",
                defaultMessage: "Try voice mode for free"
            }) : c.jsx(k, {
                id: "2whyE9",
                defaultMessage: "Choose a voice"
            })
        }), c.jsx("div", {
            className: "flex h-full w-full items-center justify-center",
            children: S ? e && !b || rn === "advanced" ? c.jsx(Ft, ln(Q({}, Tn), {
                overrideColor: se
            })) : c.jsx(wt, Q({}, Tn)) : null
        }), c.jsx("div", {
            className: "mb-8 flex items-center justify-between text-center",
            children: c.jsxs("div", {
                className: "relative flex h-24 w-48",
                children: [c.jsx(H, {
                    voice: Y,
                    variant: "offscreenLeft"
                }, Y == null ? void 0 : Y.name), c.jsx(H, {
                    voice: Z,
                    variant: "left",
                    onClick: () => J(G)
                }, Z == null ? void 0 : Z.name), c.jsx(Kn, {
                    direction: "prev",
                    onClick: () => Dn("prev"),
                    isFading: Fn
                }), c.jsx(H, {
                    voice: S,
                    variant: "center"
                }, S == null ? void 0 : S.name), c.jsx(Kn, {
                    direction: "next",
                    onClick: () => Dn("next"),
                    isFading: Fn
                }), c.jsx(H, {
                    voice: $,
                    variant: "right",
                    onClick: () => J(K)
                }, $ == null ? void 0 : $.name), c.jsx(H, {
                    voice: X,
                    variant: "offscreenRight"
                }, X == null ? void 0 : X.name), c.jsx("div", {
                    className: "pointer-events-none absolute h-full w-full -translate-x-52 transform bg-linear-to-r from-[var(--main-surface-background)] to-transparent"
                }), c.jsx("div", {
                    className: "pointer-events-none absolute h-full w-full translate-x-52 transform bg-linear-to-l from-[var(--main-surface-background)] to-transparent"
                }), c.jsx("div", {
                    className: "pointer-events-none absolute h-full w-full -translate-x-96 transform bg-white dark:bg-gray-800"
                }), c.jsx("div", {
                    className: "pointer-events-none absolute h-full w-full translate-x-96 transform bg-white dark:bg-gray-800"
                })]
            })
        }), c.jsx("div", {
            className: "mb-36 flex flex-col space-y-3",
            children: c.jsx(Mt, {
                isUnauthenticated: r,
                loading: p,
                handleLoginClick: re,
                handleCancelClick: ce,
                handleConfirmClick: le,
                selectedVoice: S,
                currentVoiceName: l,
                cameFromNux: e
            })
        })]
    })
}

function H({
    voice: t,
    variant: n,
    onClick: e
}) {
    return c.jsxs(Le.button, {
        onClick: e,
        className: "absolute flex w-48 flex-col items-center justify-center select-none",
        variants: Dt,
        animate: n,
        initial: n,
        transition: {
            duration: .25,
            ease: "easeInOut"
        },
        children: [c.jsx("p", {
            className: "text-lg ".concat(n === "center" ? "font-semibold" : ""),
            children: t == null ? void 0 : t.name
        }), c.jsx("p", {
            className: "text-sm text-gray-600 dark:text-[var(--text-secondary)]",
            children: t == null ? void 0 : t.description
        })]
    })
}

function Kn({
    direction: t,
    onClick: n,
    isFading: e
}) {
    const s = t === "prev" ? ze : Ze,
        o = ve(),
        f = t === "prev" ? o.formatMessage({
            id: "ajuz05",
            defaultMessage: "Previous voice"
        }) : o.formatMessage({
            id: "Dr8wrw",
            defaultMessage: "Next voice"
        });
    return c.jsx("button", {
        className: V("absolute top-2 z-50 transition-opacity duration-175", t === "prev" ? "-start-4" : "-end-4", e ? "opacity-20" : "opacity-100"),
        onClick: n,
        "aria-label": f,
        children: c.jsx(s, {
            className: "text-token-text-quaternary hover:text-token-text-secondary h-6 w-6"
        })
    })
}
export {
    bn as B, Lt as V, vt as a, Qe as b, tt as c, gt as d, bt as e, ht as f, ee as n, dt as s, Pt as u, pt as v
};
//# sourceMappingURL=kdyw5bvpba4cf5f0.js.map