var ae = Object.defineProperty,
    ie = Object.defineProperties;
var oe = Object.getOwnPropertyDescriptors;
var C = Object.getOwnPropertySymbols;
var G = Object.prototype.hasOwnProperty,
    Y = Object.prototype.propertyIsEnumerable;
var $ = (e, t, s) => t in e ? ae(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : e[t] = s,
    c = (e, t) => {
        for (var s in t || (t = {})) G.call(t, s) && $(e, s, t[s]);
        if (C)
            for (var s of C(t)) Y.call(t, s) && $(e, s, t[s]);
        return e
    },
    v = (e, t) => ie(e, oe(t));
var X = e => typeof e == "symbol" ? e : e + "",
    Z = (e, t) => {
        var s = {};
        for (var a in e) G.call(e, a) && t.indexOf(a) < 0 && (s[a] = e[a]);
        if (e != null && C)
            for (var a of C(e)) t.indexOf(a) < 0 && Y.call(e, a) && (s[a] = e[a]);
        return s
    };
import {
    c as A,
    m as ue,
    i as ce,
    r as I,
    b as f,
    w as P,
    x as le
} from "./fg33krlcm0qyi6yw.js";
import {
    Z as m,
    S as h,
    de as fe,
    o as me,
    b as he,
    eu as B,
    p as de
} from "./dykg4ktvbu3mhmdo.js";
import {
    W as l,
    i as ye
} from "./mvhcdm28zmc6uy2d.js";
const ge = 10080 * 60 * 1e3,
    pe = 5,
    Te = {},
    Re = {};

function ee() {
    return Date.now()
}

function H(e) {
    return typeof e == "object" && e != null
}

function te(e) {
    return ee() - e.updatedAt > ge
}

function ne(e) {
    if (!H(e)) return null;
    const t = e.branch,
        s = e.updatedAt;
    return typeof t != "string" || typeof s != "number" ? null : {
        branch: t,
        updatedAt: s
    }
}

function we(e) {
    if (!H(e) || Array.isArray(e)) return c({}, Te);
    const t = {};
    for (const [s, a] of Object.entries(e)) {
        const n = ne(a);
        n && (t[s] = n)
    }
    return t
}

function ve(e) {
    if (!H(e) || Array.isArray(e)) return c({}, Re);
    const t = {};
    for (const [s, a] of Object.entries(e)) {
        if (!Array.isArray(a)) continue;
        const n = [];
        for (const r of a) {
            const i = ne(r);
            i && n.push(i)
        }
        n.length > 0 && (t[s] = n)
    }
    return t
}

function Q(e) {
    Object.keys(e).length === 0 ? m.removeItem(h.WhamRepoRecentBranchesById) : m.setItem(h.WhamRepoRecentBranchesById, e)
}

function N(e, t) {
    if (e.length !== t.length) return !1;
    for (let s = 0; s < e.length; s += 1) {
        const a = e[s],
            n = t[s];
        if (a.branch !== n.branch || a.updatedAt !== n.updatedAt) return !1
    }
    return !0
}

function O(e) {
    if (!e || e.length === 0) return [];
    const t = [...e].sort((n, r) => r.updatedAt - n.updatedAt),
        s = [],
        a = new Set;
    for (const n of t)
        if (!te(n) && !a.has(n.branch) && (s.push(n), a.add(n.branch), s.length === pe)) break;
    return s
}

function Ee(e) {
    let t = !1;
    for (const [s, a] of Object.entries(e)) {
        const n = O(a);
        if (n.length === 0) {
            a.length > 0 && (t = !0, delete e[s]);
            continue
        }
        N(n, a) || (e[s] = n, t = !0)
    }
    return t
}

function be() {
    const e = m.getItem(h.WhamRepoLastBranchById);
    return we(e)
}

function _e(e) {
    var n;
    const t = be();
    if (Object.keys(t).length === 0) return !1;
    let a = !1;
    for (const [r, i] of Object.entries(t)) {
        if (te(i)) {
            a = !0;
            continue
        }
        const o = (n = e[r]) != null ? n : [],
            u = O([i, ...o]);
        u.length > 0 && !N(u, o) && (e[r] = u, a = !0)
    }
    return m.removeItem(h.WhamRepoLastBranchById), a
}

function U() {
    const e = m.getItem(h.WhamRepoRecentBranchesById),
        t = ve(e),
        s = Ee(t),
        a = _e(t);
    return (s || a) && Q(t), t
}

function We(e, t, s) {
    var r;
    if (s.length === 0) {
        e[t] && (delete e[t], Q(e));
        return
    }
    const a = O(s),
        n = (r = e[t]) != null ? r : [];
    N(a, n) || (e[t] = a, Q(e))
}

function Se(e, t, s) {
    var r;
    if (!t || !s) return;
    const a = (r = e[t]) != null ? r : [],
        n = O([{
            branch: s,
            updatedAt: ee()
        }, ...a]);
    We(e, t, n)
}

function se(e) {
    if (!e) return null;
    const s = U()[e];
    return !s || s.length === 0 ? null : s[0].branch
}

function Fe(e, t) {
    if (!e || !t) return;
    const s = U();
    Se(s, e, t)
}

function Ye(e) {
    var s, a;
    return e ? (a = (s = U()[e]) == null ? void 0 : s.map(n => n.branch)) != null ? a : [] : []
}
const Ae = () => {
        const e = m.getItem(h.WhamLastRepositoryId);
        return typeof e == "string" ? e : null
    },
    L = Ae(),
    ke = () => L ? se(L) : null,
    k = fe()((e, t) => {
        var s, a;
        return {
            environmentId: m.getItem(h.LastEnvironment),
            branch: ke(),
            manuallyAddedBranches: [],
            promptDraft: (s = m.getItem(h.PromptDraft)) != null ? s : "",
            selectedRepositoryId: L != null ? L : null,
            taskTurnMap: {},
            showReactQueryDevtools: !1,
            lastClickedChangelogDate: (a = m.getItem(h.WhamChangelogClickedDate)) != null ? a : null,
            pendingTaskIds: {},
            pendingCodeReviewIds: {},
            fixReviewTasksInFlight: {},
            hasSubmittedTaskInSession: !1,
            lastViewedTaskId: null,
            bestOfN: m.getItem(h.WhamBestOfN),
            codexOnboardingState: m.getItem(h.WhamCodexOnboardingState),
            preferredEditor: (function() {
                const n = m.getItem(h.WhamPreferredEditor);
                return ["cursor", "vscode", "windsurf"].includes(n) ? n : "vscode"
            })(),
            homeTab: "all",
            autoCreatedEnvironmentId: null,
            showEnvironmentOnboardingPopover: !1,
            shouldHighlightTasksTab: !1,
            useRepositoryAsEnvironment: !1,
            _fetchedRateLimitStatus: null,
            _forcedRateLimit: (function() {
                return null
            })(),
            setShowReactQueryDevtools: n => {
                m.setItem(h.ReactQueryDevtoolsVisible, n), e({
                    showReactQueryDevtools: n
                })
            },
            setLastClickedChangelogDate: n => {
                m.setItem(h.WhamChangelogClickedDate, n), e({
                    lastClickedChangelogDate: n
                })
            },
            setPromptDraft: n => {
                m.setItem(h.PromptDraft, n), e({
                    promptDraft: n
                })
            },
            setEnvironmentId: n => {
                n == null ? m.removeItem(h.LastEnvironment) : m.setItem(h.LastEnvironment, n), e(r => ({
                    environmentId: n,
                    useRepositoryAsEnvironment: n != null ? !1 : r.useRepositoryAsEnvironment
                }))
            },
            setBranch: n => e(r => {
                const i = r.selectedRepositoryId;
                return i && n && Fe(i, n), {
                    branch: n
                }
            }),
            setSelectedRepositoryId: n => {
                n == null ? m.removeItem(h.WhamLastRepositoryId) : m.setItem(h.WhamLastRepositoryId, n), e(r => {
                    const i = n != null ? se(n) : null;
                    return {
                        selectedRepositoryId: n,
                        branch: n != null ? i != null ? i : null : r.branch,
                        useRepositoryAsEnvironment: n ? r.useRepositoryAsEnvironment : !1
                    }
                })
            },
            setUseRepositoryAsEnvironment: n => e({
                useRepositoryAsEnvironment: n
            }),
            addManuallyAddedBranch: n => e(r => r.manuallyAddedBranches.includes(n) ? {} : {
                manuallyAddedBranches: [n, ...r.manuallyAddedBranches]
            }),
            setHomeTabValue: n => e({
                homeTab: n
            }),
            setLastViewedTaskId: n => e({
                lastViewedTaskId: n
            }),
            setAutoCreatedEnvironment: n => e({
                autoCreatedEnvironmentId: n,
                showEnvironmentOnboardingPopover: !0
            }),
            dismissEnvironmentOnboardingPopover: () => e({
                showEnvironmentOnboardingPopover: !1
            }),
            setHasSubmittedTaskInSession: n => e({
                hasSubmittedTaskInSession: n
            }),
            addTurnToTaskMap: (n, r) => {
                e(i => {
                    const o = i.taskTurnMap[n],
                        u = o ? c({}, o) : {};
                    return u[r.id] = r, {
                        taskTurnMap: v(c({}, i.taskTurnMap), {
                            [n]: u
                        })
                    }
                })
            },
            updateTurnDiscarded: (n, r, i) => {
                e(o => {
                    const u = o.taskTurnMap[n],
                        d = u == null ? void 0 : u[r];
                    return !u || !d ? {} : {
                        taskTurnMap: v(c({}, o.taskTurnMap), {
                            [n]: v(c({}, u), {
                                [r]: v(c({}, d), {
                                    discarded: i
                                })
                            })
                        })
                    }
                })
            },
            getTurnsForTask: n => {
                var i;
                const r = (i = t().taskTurnMap[n]) != null ? i : [];
                return Object.values(r).sort((o, u) => o.created_at - u.created_at)
            },
            addPendingTaskId: n => {
                const r = c({}, t().pendingTaskIds);
                r[n] = n, e({
                    pendingTaskIds: r
                })
            },
            removePendingTaskId: n => {
                const r = c({}, t().pendingTaskIds);
                delete r[n], e({
                    pendingTaskIds: r
                })
            },
            removePendingTaskByTaskId: n => {
                var o;
                const r = t().pendingTaskIds,
                    [i] = (o = Object.entries(r).find(([u, d]) => d === n)) != null ? o : [];
                if (i) {
                    const u = c({}, r);
                    delete u[i], e({
                        pendingTaskIds: u
                    })
                }
            },
            assignPendingTaskToFinalTask: (n, r) => e(i => ({
                pendingTaskIds: v(c({}, i.pendingTaskIds), {
                    [n]: r
                })
            })),
            addPendingCodeReviewId: n => {
                const r = c({}, t().pendingCodeReviewIds);
                r[n] = n, e({
                    pendingCodeReviewIds: r
                })
            },
            removePendingCodeReviewId: n => {
                const r = c({}, t().pendingCodeReviewIds);
                delete r[n], e({
                    pendingCodeReviewIds: r
                })
            },
            assignPendingCodeReviewToFinalTask: (n, r) => e(i => ({
                pendingCodeReviewIds: v(c({}, i.pendingCodeReviewIds), {
                    [n]: r
                })
            })),
            markFixReviewTaskInFlight: n => e(r => ({
                fixReviewTasksInFlight: v(c({}, r.fixReviewTasksInFlight), {
                    [n]: !0
                })
            })),
            clearFixReviewTaskInFlight: n => e(r => {
                if (!r.fixReviewTasksInFlight[n]) return {};
                const u = r.fixReviewTasksInFlight,
                    {
                        [n]: i
                    } = u;
                return {
                    fixReviewTasksInFlight: Z(u, [X(n)])
                }
            }),
            resetFixedReviewTasks: () => e(() => ({
                fixReviewTasksInFlight: {}
            })),
            getRateLimitStatus: () => t()._fetchedRateLimitStatus,
            setRateLimitStatus: n => e({
                _fetchedRateLimitStatus: n
            }),
            forceRateLimit: n => {},
            setBestOfN: n => {
                m.setItem(h.WhamBestOfN, n), e({
                    bestOfN: n
                })
            },
            setPreferredEditor: n => {
                m.setItem(h.WhamPreferredEditor, n), e({
                    preferredEditor: n
                })
            },
            setCodexOnboardingState: n => {
                m.setItem(h.WhamCodexOnboardingState, n), e({
                    codexOnboardingState: n
                })
            },
            setShouldHighlightTasksTab: n => e({
                shouldHighlightTasksTab: n
            })
        }
    });

function qe(e) {
    return me(e, "2894268612") || void 0
}
const J = "tab";

function De(e) {
    switch (e) {
        case "code_reviews":
            return "code_reviews";
        case "archived":
            return "archived";
        case "all":
        default:
            return "all"
    }
}

function Le(e) {
    return e === "archived" ? "archived" : e === "code_reviews" ? "code_review" : "current"
}

function Xe() {
    "use forget";
    const e = A.c(35),
        t = he(),
        s = ue(),
        a = ce(),
        n = k(Me),
        r = k(Ke);
    let i;
    e[0] !== t ? (i = qe(t), e[0] = t, e[1] = i) : i = e[1];
    const o = i;
    let u;
    e[2] !== s.search ? (u = new URLSearchParams(s.search), e[2] = s.search, e[3] = u) : u = e[3];
    const d = u;
    let g, T;
    e[4] !== d ? (g = d.get(J), T = De(g), e[4] = d, e[5] = g, e[6] = T) : (g = e[5], T = e[6]);
    const p = T,
        E = g != null;
    let y;
    e[7] !== o || e[8] !== E || e[9] !== p || e[10] !== n ? (y = E ? p : n, y === "code_reviews" && !o && (y = "all"), e[7] = o, e[8] = E, e[9] = p, e[10] = n, e[11] = y) : y = e[11];
    let b;
    e[12] !== y || e[13] !== r || e[14] !== n ? (b = () => {
        n !== y && r(y)
    }, e[12] = y, e[13] = r, e[14] = n, e[15] = b) : b = e[15];
    let R;
    e[16] !== y || e[17] !== r || e[18] !== n ? (R = [y, r, n], e[16] = y, e[17] = r, e[18] = n, e[19] = R) : R = e[19], I.useEffect(b, R);
    let _;
    e[20] !== o || e[21] !== s.pathname || e[22] !== s.search || e[23] !== a || e[24] !== r ? (_ = z => {
        const V = z === "code_reviews" && !o ? "all" : z;
        r(V);
        const j = new URLSearchParams(s.search);
        j.set(J, V), a({
            pathname: s.pathname,
            search: j.toString()
        }, {
            replace: !0
        })
    }, e[20] = o, e[21] = s.pathname, e[22] = s.search, e[23] = a, e[24] = r, e[25] = _) : _ = e[25];
    const w = _;
    let W, F;
    e[26] !== o || e[27] !== g || e[28] !== w ? (W = () => {
        g === "code_reviews" && !o && w("all")
    }, F = [o, g, w], e[26] = o, e[27] = g, e[28] = w, e[29] = W, e[30] = F) : (W = e[29], F = e[30]), I.useEffect(W, F);
    let M;
    return e[31] !== E || e[32] !== y || e[33] !== w ? (M = {
        homeTab: y,
        setHomeTab: w,
        hasExplicitTab: E
    }, e[31] = E, e[32] = y, e[33] = w, e[34] = M) : M = e[34], M
}

function Ke(e) {
    return e.setHomeTabValue
}

function Me(e) {
    return e.homeTab
}
const q = ["wham", "environments", "with-creators", "infinite"],
    K = ["wham", "environments", "with-creators", "list"],
    D = ["wham", "recent_environments"];

function Ze(e) {
    return [...q, {
        pageSize: e.pageSize,
        enforceRepoAccess: e.enforceRepoAccess
    }]
}
const S = 60 * 1e3,
    Je = (e, t, s) => c({
        staleTime: 0,
        queryKey: ["wham", "task", e, t],
        enabled: !!e && !!t,
        queryFn: () => l.getTaskTurn(e != null ? e : "", t != null ? t : "")
    }, s || {}),
    Ce = (e, t) => c({
        queryKey: ["wham", "task", e],
        staleTime: 0,
        enabled: !!e,
        queryFn: async () => await l.getTaskDetails(e != null ? e : "")
    }, t || {}),
    et = (e, t) => {
        const s = Ce(e, t);
        return f(s)
    },
    Oe = 19;

function re(e) {
    return le({
        queryKey: ["wham", "tasks", e],
        queryFn: ({
            pageParam: t
        }) => l.getTasksForList(Oe, t != null ? t : null, e),
        initialPageParam: null,
        getNextPageParam: ({
            cursor: t
        }) => t,
        staleTime: 15 * 1e3
    })
}

function tt({
    filter: e,
    enabled: t = !0,
    refetchOnMount: s = !1,
    refetchOnWindowFocus: a = !1
} = {}) {
    const n = k(({
            homeTab: i
        }) => i),
        r = e != null ? e : Le(n);
    return P(v(c({}, re(r)), {
        enabled: t,
        refetchOnMount: s,
        refetchOnWindowFocus: a
    }))
}

function nt({
    enabled: e = !0
} = {}) {
    return f({
        queryKey: ["wham", "tasks", "has-any"],
        queryFn: async () => {
            var s, a;
            return ((a = (s = (await l.getTasksForList(1, null, "all")).items) == null ? void 0 : s.length) != null ? a : 0) > 0
        },
        enabled: e
    })
}

function st() {
    return P(v(c({}, re("all")), {
        select: e => {
            var s, a;
            const t = e.pages[0];
            return ((a = (s = t == null ? void 0 : t.items) == null ? void 0 : s.length) != null ? a : 0) >= 5
        }
    }))
}

function rt(e) {
    "use forget";
    const t = A.c(18),
        s = k(xe),
        a = k(Qe);
    let n;
    t[0] !== e || t[1] !== s ? (n = typeof e == "function" ? e(s) : e, t[0] = e, t[1] = s, t[2] = n) : n = t[2];
    const r = n;
    let i;
    t[3] !== r ? (i = r != null ? r : {}, t[3] = r, t[4] = i) : i = t[4];
    const {
        staleTime: o,
        enabled: u,
        refetchOnWindowFocus: d,
        refetchInterval: g
    } = i, T = o === void 0 ? S : o, p = u === void 0 ? !0 : u, E = d === void 0 ? !1 : d;
    let y;
    t[5] === Symbol.for("react.memo_cache_sentinel") ? (y = ["wham", "usage", "rate-limit-status"], t[5] = y) : y = t[5];
    let b;
    t[6] !== p || t[7] !== g || t[8] !== E || t[9] !== T ? (b = {
        queryKey: y,
        queryFn: Ie,
        staleTime: T,
        retry: !1,
        enabled: p,
        refetchOnWindowFocus: E,
        refetchInterval: g
    }, t[6] = p, t[7] = g, t[8] = E, t[9] = T, t[10] = b) : b = t[10];
    const R = f(b);
    let _, w;
    t[11] !== R.data || t[12] !== a ? (_ = () => {
        var F;
        typeof R.data > "u" || a((F = R.data) != null ? F : null)
    }, w = [R.data, a], t[11] = R.data, t[12] = a, t[13] = _, t[14] = w) : (_ = t[13], w = t[14]), I.useEffect(_, w);
    let W;
    return t[15] !== R || t[16] !== s ? (W = v(c({}, R), {
        data: s
    }), t[15] = R, t[16] = s, t[17] = W) : W = t[17], W
}

function Ie() {
    return l.getRateLimitStatus()
}

function Qe(e) {
    return e.setRateLimitStatus
}

function xe(e) {
    return e.getRateLimitStatus()
}

function at(e) {
    "use forget";
    const t = A.c(5);
    let s;
    t[0] !== e ? (s = {}, t[0] = e, t[1] = s) : s = t[1];
    const {
        staleTime: a
    } = s, n = a === void 0 ? S : a;
    let r;
    t[2] === Symbol.for("react.memo_cache_sentinel") ? (r = ["wham", "usage", "daily-token-usage-breakdown"], t[2] = r) : r = t[2];
    let i;
    return t[3] !== n ? (i = {
        queryKey: r,
        queryFn: Pe,
        staleTime: n,
        retry: !1
    }, t[3] = n, t[4] = i) : i = t[4], f(i)
}

function Pe() {
    return l.getDailyTokenUsageBreakdown()
}

function it(e) {
    "use forget";
    const t = A.c(6);
    let s;
    t[0] !== e ? (s = e === void 0 ? {} : e, t[0] = e, t[1] = s) : s = t[1];
    const {
        staleTime: a,
        enabled: n
    } = s, r = a === void 0 ? S : a, i = n === void 0 ? !0 : n;
    let o;
    t[2] === Symbol.for("react.memo_cache_sentinel") ? (o = ["wham", "usage", "daily-enterprise-token-usage-breakdown"], t[2] = o) : o = t[2];
    let u;
    return t[3] !== i || t[4] !== r ? (u = {
        queryKey: o,
        queryFn: Be,
        staleTime: r,
        retry: !1,
        enabled: i
    }, t[3] = i, t[4] = r, t[5] = u) : u = t[5], f(u)
}

function Be() {
    return l.getDailyEnterpriseTokenUsageBreakdown()
}

function ot(e) {
    "use forget";
    const t = A.c(6);
    let s;
    t[0] !== e ? (s = {}, t[0] = e, t[1] = s) : s = t[1];
    const {
        staleTime: a,
        enabled: n
    } = s, r = a === void 0 ? S : a, i = n === void 0 ? !0 : n;
    let o;
    t[2] === Symbol.for("react.memo_cache_sentinel") ? (o = ["wham", "usage", "credit-usage-events"], t[2] = o) : o = t[2];
    let u;
    return t[3] !== i || t[4] !== r ? (u = {
        queryKey: o,
        queryFn: He,
        staleTime: r,
        retry: !1,
        enabled: i
    }, t[3] = i, t[4] = r, t[5] = u) : u = t[5], f(u)
}

function He() {
    return l.getCreditUsageEvents()
}

function ut({
    retry: e = 0
} = {}) {
    return f({
        queryKey: ["wham", "environments"],
        queryFn: () => l.getEnvironments(),
        retry: e
    })
}

function ct({
    retry: e = 0
} = {}) {
    return f({
        queryKey: D,
        queryFn: () => l.getRecentEnvironments(),
        retry: e
    })
}

function lt() {
    return f({
        queryKey: ["wham", "githubLogin"],
        queryFn: () => l.getUserHandle()
    })
}

function ft(e = !0) {
    return f({
        queryKey: ["wham", "githubInstallationsV2"],
        queryFn: () => l.getGithubInstallationsV2(),
        staleTime: 0,
        refetchOnWindowFocus: !0,
        refetchOnMount: !0,
        enabled: e
    })
}

function mt() {
    return f({
        queryKey: ["wham", "tasks", "samples"],
        queryFn: () => l.getSampleTasks(10, null)
    })
}

function ht(e, t, s) {
    const a = v(c({}, t), {
        creator: s
    });
    e.setQueryData(["wham", "environments"], n => n ? [t, ...n] : [t]), e.getQueriesData({
        queryKey: q
    }).forEach(([n]) => {
        e.setQueryData(n, r => r && B(r, i => {
            i.pages.length > 0 && i.pages[0].items.unshift(a)
        }))
    }), e.getQueriesData({
        queryKey: K
    }).forEach(([n]) => {
        e.setQueryData(n, r => r ? [a, ...r] : [a])
    }), e.setQueryData(D, n => {
        if (!n) return n;
        const r = n.filter(i => i.id !== t.id);
        return [t, ...r]
    })
}

function dt(e, t) {
    e.setQueryData(["wham", "environments"], s => s == null ? void 0 : s.filter(a => a.id !== t)), e.getQueriesData({
        queryKey: q
    }).forEach(([s]) => {
        e.setQueryData(s, a => a && B(a, n => {
            n.pages.forEach(r => {
                r.items = r.items.filter(i => i.id !== t)
            })
        }))
    }), e.getQueriesData({
        queryKey: K
    }).forEach(([s]) => {
        e.setQueryData(s, a => a == null ? void 0 : a.filter(n => n.id !== t))
    }), e.setQueryData(D, s => s == null ? void 0 : s.filter(a => a.id !== t))
}

function yt(e, t, s) {
    e.setQueryData(["wham", "environments"], a => a == null ? void 0 : a.map(n => n.id === t ? s : n)), e.getQueriesData({
        queryKey: q
    }).forEach(([a]) => {
        e.setQueryData(a, n => n && B(n, r => {
            r.pages.forEach(i => {
                i.items = i.items.map(o => o.id === t ? c(c({}, o), s) : o)
            })
        }))
    }), e.setQueryData(["environments", t, "withCreatorAndMachine"], a => a ? c(c({}, a), s) : void 0), e.getQueriesData({
        queryKey: K
    }).forEach(([a]) => {
        e.setQueryData(a, n => n == null ? void 0 : n.map(r => r.id === t ? c(c({}, r), s) : r))
    }), e.setQueryData(D, a => a == null ? void 0 : a.map(n => n.id === t ? c(c({}, n), s) : n))
}

function gt(e) {
    return f({
        queryKey: ["environments", e, "withCreatorAndMachine"],
        queryFn: () => l.getEnvironmentWithCreatorAndMachine(e)
    })
}

function pt() {
    return f({
        queryKey: ["wham", "userPreferences"],
        queryFn: () => l.getUserPreferences()
    })
}

function Tt() {
    return f({
        queryKey: ["wham", "githubInstallationEventsV2"],
        queryFn: () => l.getGithubInstallationEventsV2(),
        staleTime: 0,
        refetchOnWindowFocus: !0,
        refetchOnMount: !0
    })
}

function Ne(e) {
    if (!e) return null;
    let t = e.trim().toLowerCase();
    if (!t) return null;
    const s = ["https://", "http://"];
    for (const i of s)
        if (t.startsWith(i)) {
            t = t.slice(i.length);
            break
        }
    for (t.startsWith("www.") && (t = t.slice(4)), t.startsWith("github.com/") && (t = t.slice(11)), t.endsWith(".git") && (t = t.slice(0, -4)); t.startsWith("/");) t = t.slice(1);
    for (; t.endsWith("/");) t = t.slice(0, -1);
    const a = t.split("/").filter(Boolean);
    if (a.length < 2) return null;
    const [n, r] = a;
    return !n || !r ? null : "".concat(n, "/").concat(r)
}
const Ue = 20;

function Rt(e, t = {}) {
    var u;
    const s = e.trim(),
        a = t.installationIds,
        n = a ? [...a].sort() : void 0,
        r = (u = t.limit) != null ? u : Ue,
        i = s.length > 0,
        o = n;
    return P({
        queryKey: ["wham", "codeReviewRepositories", "v2", s, n, r],
        initialPageParam: i ? 1 : null,
        queryFn: async ({
            pageParam: d
        }) => {
            const g = Ne(s),
                T = d == null || d === 1;
            if (g && T) try {
                return {
                    repo_review_settings: [await l.getCodeReviewRepository("github", g)],
                    next_token: null
                }
            } catch (p) {
                if (!(p instanceof de && (p.status === 400 || p.status === 403 || p.status === 404))) throw p
            }
            return i ? l.searchCodeReviewRepositories({
                query: s,
                limit: r,
                installationIds: o,
                page: d != null ? d : 1
            }) : l.getCodeReviewRepositories({
                search: s || void 0,
                nextToken: void 0
            })
        },
        getNextPageParam: (d, g) => {
            var T, p;
            return i ? ((p = (T = d == null ? void 0 : d.repo_review_settings) == null ? void 0 : T.length) != null ? p : 0) < r ? null : g.length + 1 : null
        },
        refetchOnWindowFocus: !0
    })
}

function wt() {
    return f({
        queryKey: ["wham", "userPreferencesConfig"],
        queryFn: () => l.getUserPreferencesConfig()
    })
}
async function vt(e) {
    await Promise.all([e.invalidateQueries({
        queryKey: ["wham", "environments"]
    }), e.invalidateQueries({
        queryKey: q
    }), e.invalidateQueries({
        queryKey: K
    }), e.invalidateQueries({
        queryKey: D
    })])
}
async function Et(e, t) {
    await Promise.all([e.invalidateQueries({
        queryKey: ["environments", t, "withCreatorAndMachine"]
    }), e.invalidateQueries({
        queryKey: q
    }), e.invalidateQueries({
        queryKey: K
    }), e.invalidateQueries({
        queryKey: D
    })])
}

function bt(e) {
    return e.invalidateQueries({
        queryKey: ["wham", "userPreferences"]
    })
}

function _t(e) {
    const t = k(s => s.addTurnToTaskMap);
    return f({
        queryKey: ["wham", "task", e, "turns"],
        queryFn: async () => {
            const s = await l.getTurns(e != null ? e : "");
            return Object.values(s.turn_mapping).forEach(a => {
                t(e != null ? e : "", a.turn)
            }), s
        },
        enabled: !!e,
        staleTime: 15 * 1e3,
        refetchOnWindowFocus: !0,
        refetchOnMount: !0
    })
}

function Wt(e, t) {
    return f({
        queryKey: ["wham", "task", e, "turns", t, "logs"],
        queryFn: () => l.getTurnLogs(e != null ? e : "", t != null ? t : ""),
        enabled: !!e && !!t
    })
}

function St(e, t, s) {
    return f({
        queryKey: ["wham", "task", e, "turns", t, "latest"],
        enabled: s && !!e && !!t,
        queryFn: () => l.getLatestTaskTurns(e != null ? e : "", t != null ? t : ""),
        staleTime: 0,
        refetchInterval: ({
            state: a
        }) => {
            var i, o;
            return a.data && ((o = (i = a.data) == null ? void 0 : i.latest_turns) == null ? void 0 : o.every(u => ye(u.turn_status))) ? !1 : 5e3
        }
    })
}

function x(e) {
    if (e != null) {
        if (Array.isArray(e)) return e.map(x);
        if (typeof e == "object" && e !== null) {
            const t = {};
            for (const [s, a] of Object.entries(e)) {
                const n = x(a);
                n !== void 0 && (t[s] = n)
            }
            return t
        }
        return e
    }
}

function ze(e) {
    return e == null || typeof e != "object" || !("openapi" in e) ? null : x(e)
}

function Ft({
    enabled: e = !0
} = {}) {
    return f({
        queryKey: ["wham", "analytics", "api-reference"],
        queryFn: () => l.getAnalyticsApiReference(),
        staleTime: S,
        enabled: e,
        select: ze
    })
}

function At() {
    return f({
        queryKey: ["wham", "analytics", "daily-code-review-metrics"],
        queryFn: () => l.getDailyCodeReviewMetrics(),
        staleTime: S
    })
}

function kt() {
    return f({
        queryKey: ["wham", "analytics", "daily-workspace-usage-counts"],
        queryFn: () => l.getDailyWorkspaceUsageCounts(),
        staleTime: S
    })
}

function qt({
    enabled: e = !0,
    includeEmails: t = !1
} = {}) {
    return f({
        queryKey: ["wham", "analytics", "daily-sessions-messages-counts", t],
        queryFn: () => l.getDailySessionsMessagesCounts({
            includeEmails: t
        }),
        staleTime: S,
        enabled: e
    })
}

function Dt(e) {
    "use forget";
    const t = A.c(2);
    let s;
    return t[0] !== e ? (s = {
        queryKey: ["wham", "repositories", "repository-row-section", e],
        queryFn: async () => e.length === 0 ? await l.listRepositories({
            page: 1,
            per_page: 10
        }) : await l.searchRepositoriesAllInstallations({
            query: e,
            limit: 10
        }),
        staleTime: 6e4
    }, t[0] = e, t[1] = s) : s = t[1], f(s)
}

function Lt(e) {
    "use forget";
    const t = A.c(2);
    let s;
    return t[0] !== e ? (s = {
        queryKey: ["wham", "usage", "approximate-credit-usage", e],
        queryFn: () => l.getApproximateCreditUsage(e),
        staleTime: S
    }, t[0] = e, t[1] = s) : s = t[1], f(s)
}
export {
    it as A, ot as B, Ue as C, At as D, kt as E, qt as F, se as G, Ye as H, Dt as I, ct as J, St as K, Le as L, st as M, mt as N, Xe as O, qe as P, re as Q, Wt as R, q as W, Et as a, bt as b, Lt as c, gt as d, yt as e, ut as f, nt as g, k as h, vt as i, Je as j, D as k, Rt as l, ft as m, et as n, _t as o, ht as p, tt as q, dt as r, lt as s, Tt as t, Ft as u, pt as v, Ze as w, rt as x, wt as y, at as z
};
//# sourceMappingURL=jb9b7tatrnyq635u.js.map