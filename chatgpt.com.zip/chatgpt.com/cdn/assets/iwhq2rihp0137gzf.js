var _t = Object.defineProperty,
    It = Object.defineProperties;
var Tt = Object.getOwnPropertyDescriptors;
var gt = Object.getOwnPropertySymbols;
var wt = Object.prototype.hasOwnProperty,
    Ot = Object.prototype.propertyIsEnumerable;
var yt = (e, t, o) => t in e ? _t(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: o
    }) : e[t] = o,
    C = (e, t) => {
        for (var o in t || (t = {})) wt.call(t, o) && yt(e, o, t[o]);
        if (gt)
            for (var o of gt(t)) Ot.call(t, o) && yt(e, o, t[o]);
        return e
    },
    E = (e, t) => It(e, Tt(t));
import {
    rV as Dt,
    rW as Q,
    aj as Lt
} from "./k15yxxoybkkir2ou.js";
import {
    a as Mt,
    D as At,
    Z as J
} from "./ce3hgmw4iyyhicud.js";
import {
    l as N,
    iZ as Bt,
    de as Pt,
    bg as xt,
    a9 as Rt,
    iw as Gt,
    bv as Vt,
    pg as Ht,
    fZ as Yt,
    aU as tt
} from "./dykg4ktvbu3mhmdo.js";
import {
    j as n,
    c as Et,
    r as m,
    e as Wt
} from "./fg33krlcm0qyi6yw.js";
import {
    T as Ut,
    E as Ft,
    b as Zt,
    c as Xt
} from "./coi95al0vrqe13ds.js";
import {
    C as Kt,
    a as $t
} from "./h1j5sazq8s0md41z.js";
import {
    S as qt
} from "./f76gy0b8ieo4s693.js";

function Ne(e, t, o) {
    const s = new Map;
    return e.forEach((a, r) => {
        const i = Dt(a, t, o);
        i && s.set(r, i)
    }), s
}

function zt(e, t) {
    return {
        "bg-yellow-100 dark:bg-yellow-400": !0,
        "bg-yellow-400/40 dark:bg-yellow-400/50": e && !t,
        "bg-yellow-400/60 dark:bg-yellow-500/70": t,
        "bg-yellow-100 dark:bg-yellow-400/30": !e && !t
    }
}
const Jt = {
    "bg-transparent!": !0
};

function je({
    isHovered: e,
    isFocused: t,
    isCode: o,
    diffStatus: s
}) {
    return N(o ? Mt : At, "cursor-text group is-comment transition-colors", C({}, s === Q.REMOVED ? Jt : zt(e, t)), "group-[.is-comment]:bg-opacity-40")
}

function Se(e, t) {
    return e.map(o => {
        const s = t.get(o.id);
        return s ? E(C({}, o), {
            at: s
        }) : null
    }).filter(Bt)
}
var Qt = (e => (e.ASK = "ask", e.CREATE_TEXTDOC = "create_textdoc", e.COMMENT = "comment", e.EDIT = "edit", e))(Qt || {}),
    te = (e => (e.SELECTION = "selection", e.BLOCK = "block", e))(te || {});

function _e(e) {
    return (e == null ? void 0 : e.type) === "selection"
}
const ee = Pt(() => ({
        commentingOn: null,
        hoveredCommentId: null,
        focusedCommentId: null,
        visibleBlockCommentLauncher_DEBUG_ONLY: null,
        hoveredBlockCommentLauncherPos: null
    })),
    {
        setState: v,
        getInitialState: oe
    } = ee,
    se = {
        reset: () => v(oe()),
        startCommentingOn: e => v(t => E(C({}, t), {
            commentingOn: e
        })),
        cancelCommentingOn: () => v(e => E(C({}, e), {
            commentingOn: null
        })),
        focusComment: e => v(t => E(C({}, t), {
            focusedCommentId: e
        })),
        blurComment: () => v(e => E(C({}, e), {
            focusedCommentId: null
        })),
        mouseEnterComment: e => v(t => E(C({}, t), {
            hoveredCommentId: e
        })),
        mouseLeaveComment: () => v(e => E(C({}, e), {
            hoveredCommentId: null
        })),
        mouseEnterBlock: e => v(t => E(C({}, t), {
            hoveredBlockCommentLauncherPos: e
        })),
        mouseLeaveBlock: () => v(e => E(C({}, e), {
            hoveredBlockCommentLauncherPos: null
        })),
        setVisibleBlockComment_DEBUG_ONLY: e => v(t => E(C({}, t), {
            visibleBlockCommentLauncher_DEBUG_ONLY: e
        }))
    };

function ne(e) {
    switch (e) {
        case "dark_gray":
            return {
                normal: "text-token-text-secondary dark:text-white-400",
                hover: "cursor-pointer hover:text-token-text-primary group-hover:text-token-text-primary"
            };
        case "light_gray":
            return {
                normal: "text-gray-400",
                hover: "cursor-pointer hover:text-token-text-secondary group-hover:text-token-text-secondary"
            };
        case "error":
            return {
                normal: "text-red-500",
                hover: "cursor-pointer hover:text-red-500 group-hover:text-red-500"
            }
    }
}

function Ct({
    children: e,
    className: t,
    onClick: o,
    isClickable: s = !1,
    theme: a = "dark_gray"
}) {
    const r = ne(a),
        i = (o != null || s) && r.hover;
    return n.jsxs("div", {
        className: N("icon relative inline-block transition-opacity", t, i, r.normal),
        onClick: o,
        children: [e ? n.jsx(Kt, {
            className: "icon"
        }) : n.jsx($t, {
            className: "icon"
        }), n.jsx("span", {
            className: N("absolute inset-0 flex items-center justify-center text-[8px] font-black", i, r.normal),
            children: e
        })]
    })
}

function vt() {
    return n.jsx(Ct, {
        theme: "light_gray",
        children: n.jsx(Ut, {})
    })
}

function ae({
    count: e,
    isLoading: t,
    onClick: o,
    isError: s = !1
}) {
    return t ? n.jsx(vt, {}) : n.jsx(Ct, {
        onClick: o,
        theme: s ? "error" : "dark_gray",
        children: e
    })
}

function Ie({
    isLoading: e = !1,
    onClick: t
}) {
    return e ? n.jsx(vt, {}) : n.jsx(Ct, {
        isClickable: !0,
        onClick: t,
        theme: "light_gray"
    })
}
const bt = {
        type: "spring",
        bounce: .12,
        duration: .5
    },
    kt = "opacity-50",
    Te = e => {
        "use forget";
        const t = Et.c(16),
            {
                position: o,
                count: s,
                offsetY: a,
                isLoading: r,
                onClick: i,
                isError: j
            } = e,
            b = o === void 0 ? "absolute" : o,
            p = r === void 0 ? !1 : r,
            h = j === void 0 ? !1 : j;
        let u;
        t[0] !== b ? (u = N("flex", b, J.collapsedComment), t[0] = b, t[1] = u) : u = t[1];
        let g, c;
        t[2] === Symbol.for("react.memo_cache_sentinel") ? (g = {
            opacity: 0
        }, c = {
            opacity: 1
        }, t[2] = g, t[3] = c) : (g = t[2], c = t[3]);
        let f;
        t[4] !== a ? (f = {
            translateY: a
        }, t[4] = a, t[5] = f) : f = t[5];
        let S;
        t[6] === Symbol.for("react.memo_cache_sentinel") ? (S = {
            opacity: 0
        }, t[6] = S) : S = t[6];
        let k;
        t[7] !== s || t[8] !== h || t[9] !== p || t[10] !== i ? (k = n.jsx(ae, {
            count: s,
            isLoading: p,
            onClick: i,
            isError: h
        }), t[7] = s, t[8] = h, t[9] = p, t[10] = i, t[11] = k) : k = t[11];
        let _;
        return t[12] !== u || t[13] !== f || t[14] !== k ? (_ = n.jsx(xt.div, {
            className: u,
            initial: g,
            animate: c,
            style: f,
            transition: bt,
            exit: S,
            children: k
        }), t[12] = u, t[13] = f, t[14] = k, t[15] = _) : _ = t[15], _
    },
    re = ({
        isFocused: e,
        isHovered: t
    }) => {
        const o = e || t ? "grow font-medium text-token-text-primary transition-colors" : "grow font-medium text-token-text-secondary transition-colors",
            s = e || t ? "opacity-100 transition" : "opacity-75 transition";
        return n.jsxs(n.Fragment, {
            children: [n.jsx("div", {
                className: s,
                children: n.jsx("div", {
                    className: "gizmo-bot-avatar rounded-full",
                    children: n.jsx(Ht, {
                        iconName: "openai"
                    })
                })
            }), n.jsx("span", {
                className: o,
                children: "ChatGPT"
            })]
        })
    },
    ie = ({
        comment: {
            diffStatus: e,
            content: t
        },
        isFocused: o,
        isSomeCommentFocused: s,
        isHovered: a
    }) => {
        const r = e === Q.REMOVED;
        return n.jsx("div", {
            className: N("text-token-text-primary mt-2 transition-all", {
                "opacity-80": !o && !s && !a && !r,
                "opacity-40": !o && s && !a && !r,
                [kt]: r
            }),
            children: n.jsx(Lt, {
                text: t
            })
        })
    },
    le = e => {
        "use forget";
        const t = Et.c(80),
            {
                acceptButtonLabel: o,
                position: s,
                left: a,
                right: r,
                comment: i,
                disableAnimations: j,
                onClick: b,
                onMouseEnter: p,
                onMouseLeave: h,
                onAccept: u,
                onDismiss: g,
                translateY: c,
                isFocused: f,
                isSomeCommentFocused: S,
                disableActions: k,
                isHovered: _,
                ref: ot
            } = e,
            st = s === void 0 ? "absolute" : s,
            d = j === void 0 ? !1 : j,
            l = f === void 0 ? !1 : f,
            Z = S === void 0 ? !1 : S,
            x = k === void 0 ? !1 : k,
            y = _ === void 0 ? !1 : _,
            [pt, ht] = m.useState(!1),
            nt = i.diffStatus === Q.ADDED,
            I = i.diffStatus === Q.REMOVED,
            at = i.diffStatus != null;
        let X;
        t[0] !== p ? (X = () => {
            ht(!0), p == null || p()
        }, t[0] = p, t[1] = X) : X = t[1];
        const Nt = X;
        let K;
        t[2] !== h ? (K = () => {
            ht(!1), h == null || h()
        }, t[2] = h, t[3] = K) : K = t[3];
        const jt = K,
            T = Wt(),
            rt = l || pt && !Z,
            it = !l;
        let w;
        t[4] !== l || t[5] !== y || t[6] !== st || t[7] !== it ? (w = N(st, J.expandedComment, {
            "cursor-default": l,
            "cursor-pointer": it,
            [J.expandedCommentFocused]: l,
            [J.expandedCommentHovered]: y
        }), t[4] = l, t[5] = y, t[6] = st, t[7] = it, t[8] = w) : w = t[8];
        let O;
        t[9] !== a || t[10] !== r ? (O = {
            left: a,
            right: r
        }, t[9] = a, t[10] = r, t[11] = O) : O = t[11];
        let D;
        t[12] !== d || t[13] !== c ? (D = d ? !1 : {
            translateY: c,
            scale: .85,
            opacity: 0
        }, t[12] = d, t[13] = c, t[14] = D) : D = t[14];
        let L;
        t[15] !== d || t[16] !== l || t[17] !== c ? (L = d ? void 0 : {
            translateY: c,
            scale: l ? 1 : .97,
            opacity: 1
        }, t[15] = d, t[16] = l, t[17] = c, t[18] = L) : L = t[18];
        let M;
        t[19] !== d ? (M = d ? void 0 : {
            scale: .85,
            opacity: 0,
            filter: "blur(16px)"
        }, t[19] = d, t[20] = M) : M = t[20];
        const lt = x ? void 0 : Nt,
            ct = x ? void 0 : jt,
            St = i.id,
            mt = !l && !y,
            dt = y && !l,
            ut = l || pt && !Z;
        let A;
        t[21] !== at || t[22] !== nt || t[23] !== I || t[24] !== mt || t[25] !== dt || t[26] !== ut ? (A = N("flex min-h-8 flex-col overflow-hidden rounded-2xl border p-4 pt-2 text-start text-sm transition-all", {
            "border-transparent bg-gray-50 dark:bg-gray-800": mt,
            "border-token-border-default bg-token-main-surface-primary": dt,
            "border-token-border-default bg-token-main-surface-primary shadow-xl": ut,
            "relative after:absolute after:start-0 after:top-0 after:bottom-0 after:w-1": at,
            "after:bg-green-500": nt,
            "after:bg-red-500": I
        }), t[21] = at, t[22] = nt, t[23] = I, t[24] = mt, t[25] = dt, t[26] = ut, t[27] = A) : A = t[27];
        let $;
        t[28] === Symbol.for("react.memo_cache_sentinel") ? ($ = {
            width: Ft
        }, t[28] = $) : $ = t[28];
        let B;
        t[29] !== I ? (B = N("flex h-8 flex-row items-center gap-2.5", {
            [kt]: I
        }), t[29] = I, t[30] = B) : B = t[30];
        let P;
        t[31] !== l || t[32] !== y ? (P = n.jsx(re, {
            isFocused: l,
            isHovered: y
        }), t[31] = l, t[32] = y, t[33] = P) : P = t[33];
        const ft = !x;
        let R;
        t[34] !== x || t[35] !== ft ? (R = N("text-token-text-secondary -me-1 rounded-full bg-transparent p-1", {
            "hover:text-token-text-primary cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700": ft,
            "cursor-not-allowed": x
        }), t[34] = x, t[35] = ft, t[36] = R) : R = t[36];
        let G;
        t[37] !== T ? (G = T.formatMessage({
            id: "fYDa3C",
            defaultMessage: "Dismiss comment"
        }), t[37] = T, t[38] = G) : G = t[38];
        let q;
        t[39] === Symbol.for("react.memo_cache_sentinel") ? (q = n.jsx(Gt, {
            className: "icon-sm"
        }), t[39] = q) : q = t[39];
        let V;
        t[40] !== x || t[41] !== g || t[42] !== R || t[43] !== G ? (V = n.jsx("button", {
            className: R,
            onClick: g,
            disabled: x,
            "aria-label": G,
            children: q
        }), t[40] = x, t[41] = g, t[42] = R, t[43] = G, t[44] = V) : V = t[44];
        let H;
        t[45] !== B || t[46] !== P || t[47] !== V ? (H = n.jsxs("div", {
            className: B,
            children: [P, V]
        }), t[45] = B, t[46] = P, t[47] = V, t[48] = H) : H = t[48];
        let Y;
        t[49] !== i || t[50] !== l || t[51] !== y || t[52] !== Z ? (Y = n.jsx(ie, {
            comment: i,
            isFocused: l,
            isHovered: y,
            isSomeCommentFocused: Z
        }), t[49] = i, t[50] = l, t[51] = y, t[52] = Z, t[53] = Y) : Y = t[53];
        let W;
        t[54] !== o || t[55] !== x || t[56] !== d || t[57] !== T || t[58] !== u || t[59] !== rt ? (W = rt && n.jsx(xt.div, {
            initial: d ? !1 : {
                opacity: 0,
                height: 0
            },
            animate: {
                opacity: 1,
                height: "auto",
                transition: {
                    opacity: {
                        delay: .14,
                        duration: .2
                    },
                    height: {
                        type: "spring",
                        bounce: 0
                    }
                }
            },
            exit: d ? void 0 : {
                opacity: 0,
                height: 0,
                transition: {
                    opacity: {
                        duration: .08
                    },
                    height: {
                        type: "spring",
                        bounce: 0
                    }
                }
            },
            className: "flex items-center justify-start",
            children: n.jsx("div", {
                className: "mt-2.5",
                children: n.jsx(Rt, {
                    color: "secondary",
                    onClick: u,
                    disabled: x,
                    children: o != null ? o : T.formatMessage({
                        id: "WIW5OL",
                        defaultMessage: "Apply"
                    })
                })
            })
        }), t[54] = o, t[55] = x, t[56] = d, t[57] = T, t[58] = u, t[59] = rt, t[60] = W) : W = t[60];
        let U;
        t[61] !== W ? (U = n.jsx(Vt, {
            initial: !1,
            children: W
        }), t[61] = W, t[62] = U) : U = t[62];
        let F;
        t[63] !== A || t[64] !== H || t[65] !== Y || t[66] !== U ? (F = n.jsxs("div", {
            className: A,
            style: $,
            children: [H, Y, U]
        }), t[63] = A, t[64] = H, t[65] = Y, t[66] = U, t[67] = F) : F = t[67];
        let z;
        return t[68] !== i.id || t[69] !== b || t[70] !== ot || t[71] !== w || t[72] !== O || t[73] !== D || t[74] !== L || t[75] !== M || t[76] !== lt || t[77] !== ct || t[78] !== F ? (z = n.jsx(xt.div, {
            ref: ot,
            className: w,
            style: O,
            initial: D,
            animate: L,
            exit: M,
            transition: bt,
            onClick: b,
            onMouseEnter: lt,
            onMouseLeave: ct,
            "data-comment-id": St,
            children: F
        }), t[68] = i.id, t[69] = b, t[70] = ot, t[71] = w, t[72] = O, t[73] = D, t[74] = L, t[75] = M, t[76] = lt, t[77] = ct, t[78] = F, t[79] = z) : z = t[79], z
    },
    we = ({
        offsetY: e,
        opensOverDocument: t = !1,
        disableActions: o = !1,
        isFocused: s = !1,
        isSomeCommentFocused: a = !1,
        onAccept: r,
        onClick: i,
        onDismiss: j,
        onMouseEnter: b,
        onMouseLeave: p,
        comment: h,
        isHovered: u = !1
    }) => {
        const g = m.useRef(null);
        return m.useEffect(() => Yt(document, {
            mousedown: ({
                target: c
            }) => {
                var f;
                c instanceof HTMLElement && !c.closest("[data-comment-id]") && !((f = g.current) != null && f.contains(c)) && se.blurComment()
            }
        })), n.jsx(le, {
            ref: g,
            comment: h,
            disableActions: o,
            onAccept: r,
            onDismiss: j,
            onMouseEnter: b,
            onMouseLeave: p,
            isSomeCommentFocused: a,
            isHovered: u,
            onClick: i,
            translateY: e,
            isFocused: s,
            left: t ? void 0 : Xt,
            right: t ? Zt : void 0
        })
    };

function et(e) {
    if (e.type.name !== "text") {
        const {
            start: a,
            end: r
        } = e.attrs;
        return a == null || r == null ? null : {
            start: a,
            end: r
        }
    }
    const t = e.marks.find(a => a.type.name === qt.proseMirrorMarkName());
    if (!t) return null;
    const {
        start: o,
        end: s
    } = t.attrs;
    return o == null || s == null ? null : {
        start: o,
        end: s
    }
}

function ce(e, t) {
    const {
        parent: o,
        textOffset: s
    } = t, a = e.nodeAt(t.pos);
    if (!a) return tt(et(o)).end;
    const {
        start: r
    } = tt(et(a));
    return r + s
}

function me(e, t) {
    const o = e.nodeAt(t.pos);
    if (o) {
        const {
            start: s
        } = tt(et(o));
        return s + t.textOffset
    }
    return tt(et(t.parent)).end
}

function Oe(e, t) {
    const o = new Map;
    for (const [s, a] of t) {
        const r = ce(e, e.resolve(a.start)),
            i = me(e, e.resolve(a.end));
        o.set(s, {
            start: r,
            end: i
        })
    }
    return o
}
const de = m.createContext(() => null),
    ue = m.createContext(null),
    fe = m.createContext(0),
    De = () => m.useContext(de),
    Le = () => m.useContext(ue),
    Me = () => m.useContext(fe),
    xe = m.createContext(() => null),
    Ce = m.createContext(null),
    Ae = m.createContext(0),
    Be = () => m.useContext(xe),
    Pe = () => m.useContext(Ce);
export {
    se as C, we as E, Qt as S, Ne as a, De as b, je as c, Le as d, Me as e, ee as f, me as g, Be as h, et as i, Pe as j, te as k, _e as l, de as m, ue as n, fe as o, ce as p, Ie as q, Te as r, vt as s, le as t, Se as u, Oe as v, xe as w, Ce as x, Ae as y
};
//# sourceMappingURL=iwhq2rihp0137gzf.js.map