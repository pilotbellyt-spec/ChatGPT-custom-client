import {
    c as e,
    s as o
} from "./dykg4ktvbu3mhmdo.js";
const s = e(o, "a5b9af", 20, 20);
export {
    s as A
};
//# sourceMappingURL=lfdsdf4it937c4a2.js.map