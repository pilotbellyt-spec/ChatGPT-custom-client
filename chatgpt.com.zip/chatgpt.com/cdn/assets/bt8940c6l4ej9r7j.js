var z = Object.defineProperty,
    H = Object.defineProperties;
var A = Object.getOwnPropertyDescriptors;
var b = Object.getOwnPropertySymbols;
var F = Object.prototype.hasOwnProperty,
    G = Object.prototype.propertyIsEnumerable;
var k = (n, t, e) => t in n ? z(n, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : n[t] = e,
    S = (n, t) => {
        for (var e in t || (t = {})) F.call(t, e) && k(n, e, t[e]);
        if (b)
            for (var e of b(t)) G.call(t, e) && k(n, e, t[e]);
        return n
    },
    D = (n, t) => H(n, A(t));
var d = (n, t, e) => k(n, typeof t != "symbol" ? t + "" : t, e);
import {
    gn as J,
    qC as j
} from "./k15yxxoybkkir2ou.js";
import {
    C as q,
    M as W
} from "./fgxxkkb4il90gii6.js";
import {
    E as Z,
    M as X,
    N as Q
} from "./f76gy0b8ieo4s693.js";
import {
    stripDirectivePlugin as Y
} from "./e7ytp4eqtgc6bl6p.js";
import {
    x6 as $,
    xI as _,
    x3 as ee,
    aU as O,
    xJ as I,
    _ as te,
    lu as ne,
    iZ as se,
    wJ as re,
    wV as V,
    xK as oe,
    xL as L
} from "./dykg4ktvbu3mhmdo.js";
import {
    i as ie
} from "./eafv7vq0yf9bv0fi.js";
import {
    u as ae
} from "./jed1ux7qibe55pmj.js";
class ce extends Z {
    unifiedInitializationHook(t) {
        return t.use(Y)
    }
}
class le {
    constructor(t, e) {
        d(this, "rules");
        this.rules = [].concat.apply([], t.syntaxExtensions().map(s => s.proseMirrorInputRules(e)))
    }
    build() {
        return ie({
            rules: this.rules
        })
    }
}
class ue {
    constructor(t, e) {
        d(this, "keymap");
        this.keymap = new Map;
        for (const s of t.syntaxExtensions()) this.addKeymap(s.proseMirrorKeymap(e));
        this.addKeymap($)
    }
    build() {
        const t = {};
        return this.keymap.forEach((e, s) => {
            t[s] = _(...e)
        }), ee(t)
    }
    addKeymap(t) {
        for (const e in t) this.keymap.get(e) || this.keymap.set(e, []), O(this.keymap.get(e)).push(t[e])
    }
}
class pe {
    constructor(t) {
        d(this, "nodeViews");
        this.nodeViews = {};
        for (const e of t.nodeExtensions()) {
            const s = e.proseMirrorNodeName(),
                r = e.proseMirrorNodeView();
            s !== q.proseMirrorNodeName() && s != null && r != null && (this.nodeViews[s] = r)
        }
    }
    build() {
        return this.nodeViews
    }
}
class me {
    constructor(t) {
        d(this, "nodes", {});
        d(this, "marks", {});
        for (const e of t.nodeExtensions()) {
            const s = e.proseMirrorNodeName(),
                r = e.proseMirrorNodeSpec();
            s != null && r != null && (s !== "text" && (r.attrs = D(S({}, r.attrs), {
                start: {
                    default: void 0
                },
                end: {
                    default: void 0
                }
            })), this.nodes[s] = r)
        }
        for (const e of t.markExtensions()) {
            const s = e.proseMirrorMarkName(),
                r = e.proseMirrorMarkSpec();
            s != null && r != null && (this.marks[s] = r)
        }
    }
    build() {
        try {
            return new I({
                nodes: this.nodes,
                marks: this.marks
            })
        } catch (t) {
            te.addError(t, {
                nodes: this.nodes
            })
        }
        return new I({
            nodes: {
                doc: {
                    content: "block+"
                },
                paragraph: {
                    content: "inline*",
                    group: "block",
                    parseDOM: [{
                        tag: "p",
                        preserveWhitespace: "full"
                    }],
                    toDOM: () => ["p", 0]
                },
                text: {
                    group: "inline"
                }
            },
            marks: this.marks
        })
    }
}
class de {
    constructor(t) {
        d(this, "extensionManager");
        this.extensionManager = t
    }
    build() {
        let t = ae();
        for (const e of this.extensionManager.extensions()) t = e.unifiedInitializationHook(t);
        return t
    }
}

function fe(n) {
    return n instanceof Q
}

function he(n) {
    return n instanceof X
}
class ge {
    constructor(t) {
        d(this, "markExtensionList");
        d(this, "nodeExtensionList");
        d(this, "otherExtensionList");
        this.markExtensionList = new Map, this.nodeExtensionList = new Map, this.otherExtensionList = new Map;
        for (const e of t) this.add(e)
    }
    extensions() {
        return this.syntaxExtensions().concat(Array.from(this.otherExtensionList.values()))
    }
    markExtensions() {
        return Array.from(this.markExtensionList.values())
    }
    nodeExtensions() {
        return Array.from(this.nodeExtensionList.values())
    }
    syntaxExtensions() {
        return this.nodeExtensions().concat(this.markExtensions())
    }
    add(t) {
        for (const e of t.dependencies()) this.add(e);
        if (he(t)) {
            this.markExtensionList.set(t.constructor, t);
            return
        }
        if (fe(t)) {
            this.nodeExtensionList.set(t.constructor, t);
            return
        }
        this.otherExtensionList.set(t.constructor, t)
    }
}
class ve {
    constructor(t) {
        d(this, "extensionManager");
        this.extensionManager = t
    }
    convert(t) {
        const e = this.convertNode(t);
        if (e.length !== 1) throw new Error("Couldn't find any way to convert the root ProseMirror node.");
        return e[0]
    }
    convertNode(t) {
        let e = null;
        const s = [];
        for (const r of this.extensionManager.nodeExtensions()) {
            if (!r.proseMirrorToUnistTest(t)) continue;
            s.push(r);
            let o = [];
            for (let i = 0; i < t.childCount; ++i) o = o.concat(this.convertNode(t.child(i)));
            e = r.proseMirrorNodeToUnistNodes(t, o)
        }
        return e == null ? (console.warn("Couldn't find any way to convert ProseMirror node of type \"" + t.type.name + '" to a unist node.'), []) : e.map(r => {
            for (const o of t.marks) {
                const {
                    type: {
                        name: i
                    }
                } = o;
                if (s.some(m => {
                        var u;
                        const l = (u = m.proseMirrorNodeSpec()) == null ? void 0 : u.marks;
                        return l != null && !l.includes(i)
                    })) continue;
                let c = !1;
                for (const m of this.extensionManager.markExtensions()) o.type.name === m.proseMirrorMarkName() && (r = m.processConvertedUnistNode(r, o), c = !0);
                c || console.warn("Couldn't find any way to convert ProseMirror mark of type \"" + i + '" to a unist node.')
            }
            return r
        })
    }
}
class P {
    constructor(t, e) {
        d(this, "extensionManager");
        d(this, "proseMirrorSchema");
        this.extensionManager = t, this.proseMirrorSchema = e
    }
    static unistNodeIsParent(t) {
        return "children" in t
    }
    convert(t) {
        const e = {},
            s = this.convertNode(t, e);
        for (const r of this.extensionManager.syntaxExtensions()) r.postUnistToProseMirrorHook(e);
        if (s.length !== 1) throw new Error("Couldn't find any way to convert the root unist node.");
        return s[0]
    }
    convertNode(t, e) {
        let s = 0;
        const r = (o, i) => {
            var a;
            for (const c of this.extensionManager.syntaxExtensions()) {
                if (!c.unistToProseMirrorTest(o) || J(o) && c.customDirectiveName() != null && c.customDirectiveName() !== o.name) continue;
                let m = [];
                P.unistNodeIsParent(o) && (m = o.children.flatMap(x => r(x, i)));
                const {
                    position: l
                } = o, u = (a = l == null ? void 0 : l.start.offset) != null ? a : s;
                let p = l == null ? void 0 : l.end.offset;
                if (p == null && "value" in o && typeof o.value == "string") {
                    const {
                        value: x
                    } = o;
                    p = u + x.length
                }
                p == null && (p = u), s = p;
                const f = {
                    start: u,
                    end: p
                };
                return ne(c.unistNodeToProseMirrorNodes({
                    node: o,
                    schema: this.proseMirrorSchema,
                    convertedChildren: m,
                    context: i,
                    attrs: f
                })).filter(se)
            }
            return console.warn("Couldn't find any way to convert unist node of type \"" + o.type + '" to a ProseMirror node.'), []
        };
        return r(t, e)
    }
}
const Me = 5;
class we {
    constructor(t = []) {
        d(this, "builtSchema");
        d(this, "inputRulesBuilder");
        d(this, "keymapBuilder");
        d(this, "nodeViewBuilder");
        d(this, "unistToProseMirrorConverter");
        d(this, "proseMirrorToUnistConverter");
        d(this, "unified");
        d(this, "memoizedProsemirrorDocs", new Map);
        const e = new ge(t);
        this.builtSchema = new me(e).build(), this.inputRulesBuilder = new le(e, this.builtSchema), this.keymapBuilder = new ue(e, this.builtSchema), this.nodeViewBuilder = new pe(e), this.unistToProseMirrorConverter = new P(e, this.builtSchema), this.proseMirrorToUnistConverter = new ve(e), this.unified = new de(e).build()
    }
    parse(t) {
        try {
            if (this.memoizedProsemirrorDocs.has(t)) return O(this.memoizedProsemirrorDocs.get(t));
            const e = this.unistToProseMirrorConverter.convert(this.parseUnist(t));
            if (this.memoizedProsemirrorDocs.set(t, e), this.memoizedProsemirrorDocs.size > Me) {
                const s = this.memoizedProsemirrorDocs.keys().next().value;
                s && this.memoizedProsemirrorDocs.delete(s)
            }
            return e
        } catch (e) {
            j.logError("Failed to parse document", e)
        }
        return this.schema().text(" ")
    }
    parseUnist(t) {
        return this.unified.runSync(this.unified.parse(t))
    }
    schema() {
        return this.builtSchema
    }
    inputRulesPlugin() {
        return this.inputRulesBuilder.build()
    }
    keymapPlugin() {
        return this.keymapBuilder.build()
    }
    nodeViews() {
        return this.nodeViewBuilder.build()
    }
    serialize(t) {
        const e = this.proseMirrorToUnistConverter.convert(t);
        return this.unified.stringify(e)
    }
}
const R = new Map;

function Ve(n = {}) {
    const t = JSON.stringify(n);
    let e = R.get(t);
    return e == null && (e = new we([new W, ...n != null && n.shouldStripDirectives ? [new ce] : []]), R.set(t, e)), e
}
const xe = 500,
    g = class g {
        constructor(t, e) {
            this.items = t, this.eventCount = e
        }
        popEvent(t, e) {
            if (this.eventCount == 0) return null;
            let s = this.items.length;
            for (;; s--)
                if (this.items.get(s - 1).selection) {
                    --s;
                    break
                }
            let r, o;
            e && (r = this.remapping(s, this.items.length), o = r.maps.length);
            const i = t.tr;
            let a, c;
            const m = [],
                l = [];
            return this.items.forEach((u, p) => {
                if (!u.step) {
                    r || (r = this.remapping(s, p + 1), o = r.maps.length), o--, l.push(u);
                    return
                }
                if (r) {
                    l.push(new h(u.map));
                    const f = u.step.map(r.slice(o));
                    let v;
                    f && i.maybeStep(f).doc && (v = i.mapping.maps[i.mapping.maps.length - 1], m.push(new h(v, void 0, void 0, m.length + l.length))), o--, v && r.appendMap(v, o)
                } else i.maybeStep(u.step);
                if (u.selection) return a = r ? u.selection.map(r.slice(o)) : u.selection, c = new g(this.items.slice(0, s).append(l.reverse().concat(m)), this.eventCount - 1), !1
            }, this.items.length, 0), {
                remaining: c,
                transform: i,
                selection: a
            }
        }
        addTransform(t, e, s, r) {
            const o = [];
            let i = this.eventCount,
                a = this.items,
                c = !r && a.length ? a.get(a.length - 1) : null;
            for (let l = 0; l < t.steps.length; l++) {
                const u = t.steps[l].invert(t.docs[l]);
                let p = new h(t.mapping.maps[l], u, e),
                    f;
                (f = c && c.merge(p)) && (p = f, l ? o.pop() : a = a.slice(0, a.length - 1)), o.push(p), e && (i++, e = void 0), r || (c = p)
            }
            const m = i - s.depth;
            return m > ye && (a = Ee(a, m), i -= m), new g(a.append(o), i)
        }
        remapping(t, e) {
            const s = new oe;
            return this.items.forEach((r, o) => {
                const i = r.mirrorOffset != null && o - r.mirrorOffset >= t ? s.maps.length - r.mirrorOffset : void 0;
                s.appendMap(r.map, i)
            }, t, e), s
        }
        addMaps(t) {
            return this.eventCount == 0 ? this : new g(this.items.append(t.map(e => new h(e))), this.eventCount)
        }
        rebased(t, e) {
            if (!this.eventCount) return this;
            const s = [],
                r = Math.max(0, this.items.length - e),
                o = t.mapping;
            let i = t.steps.length,
                a = this.eventCount;
            this.items.forEach(p => {
                p.selection && a--
            }, r);
            let c = e;
            this.items.forEach(p => {
                const f = o.getMirror(--c);
                if (f == null) return;
                i = Math.min(i, f);
                const v = o.maps[f];
                if (p.step) {
                    const x = t.steps[f].invert(t.docs[f]),
                        T = p.selection && p.selection.map(o.slice(c + 1, f));
                    T && a++, s.push(new h(v, x, T))
                } else s.push(new h(v))
            }, r);
            const m = [];
            for (let p = e; p < i; p++) m.push(new h(o.maps[p]));
            const l = this.items.slice(0, r).append(m).append(s);
            let u = new g(l, a);
            return u.emptyItemCount() > xe && (u = u.compress(this.items.length - s.length)), u
        }
        emptyItemCount() {
            let t = 0;
            return this.items.forEach(e => {
                e.step || t++
            }), t
        }
        compress(t = this.items.length) {
            const e = this.remapping(0, t);
            let s = e.maps.length;
            const r = [];
            let o = 0;
            return this.items.forEach((i, a) => {
                if (a >= t) r.push(i), i.selection && o++;
                else if (i.step) {
                    const c = i.step.map(e.slice(s)),
                        m = c && c.getMap();
                    if (s--, m && e.appendMap(m, s), c) {
                        const l = i.selection && i.selection.map(e.slice(s));
                        l && o++;
                        const u = new h(m.invert(), c, l),
                            p = r.length - 1;
                        let f;
                        (f = r.length && r[p].merge(u)) ? r[p] = f: r.push(u)
                    }
                } else i.map && s--
            }, this.items.length, 0), new g(L.from(r.reverse()), o)
        }
    };
d(g, "empty", new g(L.empty, 0));
let E = g;

function Ee(n, t) {
    let e;
    return n.forEach((s, r) => {
        if (s.selection && t-- == 0) return e = r, !1
    }), n.slice(e)
}
class h {
    constructor(t, e, s, r) {
        this.map = t, this.step = e, this.selection = s, this.mirrorOffset = r
    }
    merge(t) {
        if (this.step && t.step && !t.selection) {
            const e = t.step.merge(this.step);
            if (e) return new h(e.getMap().invert(), e, this.selection)
        }
    }
}
class M {
    constructor(t, e, s, r, o) {
        this.done = t, this.undone = e, this.prevRanges = s, this.prevTime = r, this.prevComposition = o
    }
}
const ye = 20;

function ke(n, t, e, s) {
    const r = e.getMeta(w);
    let o;
    if (r) return r.historyState;
    e.getMeta(Pe) && (n = new M(n.done, n.undone, null, 0, -1));
    const i = e.getMeta("appendedTransaction");
    if (e.steps.length == 0) return n;
    if (i && i.getMeta(w)) return i.getMeta(w).redo ? new M(n.done.addTransform(e, void 0, s, y(t)), n.undone, U(e.mapping.maps), n.prevTime, n.prevComposition) : new M(n.done, n.undone.addTransform(e, void 0, s, y(t)), null, n.prevTime, n.prevComposition);
    if (e.getMeta("addToHistory") !== !1 && !(i && i.getMeta("addToHistory") === !1)) {
        const a = e.getMeta("composition"),
            c = n.prevTime == 0 || !i && n.prevComposition != a && (n.prevTime < (e.time || 0) - s.newGroupDelay || !Ce(e, n.prevRanges)),
            m = i ? C(n.prevRanges, e.mapping) : U(e.mapping.maps);
        return new M(n.done.addTransform(e, c ? t.selection.getBookmark() : void 0, s, y(t)), E.empty, m, e.time, a == null ? n.prevComposition : a)
    } else return (o = e.getMeta("rebased")) ? new M(n.done.rebased(e, o), n.undone.rebased(e, o), C(n.prevRanges, e.mapping), n.prevTime, n.prevComposition) : new M(n.done.addMaps(e.mapping.maps), n.undone.addMaps(e.mapping.maps), C(n.prevRanges, e.mapping), n.prevTime, n.prevComposition)
}

function Ce(n, t) {
    if (!t) return !1;
    if (!n.docChanged) return !0;
    let e = !1;
    return n.mapping.maps[0].forEach((s, r) => {
        for (let o = 0; o < t.length; o += 2) s <= t[o + 1] && r >= t[o] && (e = !0)
    }), e
}

function U(n) {
    const t = [];
    for (let e = n.length - 1; e >= 0 && t.length == 0; e--) n[e].forEach((s, r, o, i) => t.push(o, i));
    return t
}

function C(n, t) {
    if (!n) return null;
    const e = [];
    for (let s = 0; s < n.length; s += 2) {
        const r = t.map(n[s], 1),
            o = t.map(n[s + 1], -1);
        r <= o && e.push(r, o)
    }
    return e
}

function Ne(n, t, e) {
    const s = y(t),
        r = w.get(t).spec.config,
        o = (e ? n.undone : n.done).popEvent(t, s);
    if (!o) return null;
    const i = o.selection.resolve(o.transform.doc),
        a = (e ? n.done : n.undone).addTransform(o.transform, t.selection.getBookmark(), r, s),
        c = new M(e ? a : o.remaining, e ? o.remaining : a, null, 0, -1);
    return o.transform.setSelection(i).setMeta(w, {
        redo: e,
        historyState: c
    })
}
let N = !1,
    B = null;

function y(n) {
    const t = n.plugins;
    if (B != t) {
        N = !1, B = t;
        for (let e = 0; e < t.length; e++)
            if (t[e].spec.historyPreserveItems) {
                N = !0;
                break
            }
    }
    return N
}
const w = new V("history"),
    Pe = new V("closeHistory");

function Ke(n = {}, t = void 0) {
    return n = {
        depth: n.depth || 100,
        newGroupDelay: n.newGroupDelay || 500
    }, new re({
        key: w,
        state: {
            init() {
                return t != null ? t : new M(E.empty, E.empty, null, 0, -1)
            },
            apply(e, s, r) {
                return ke(s, r, e, n)
            }
        },
        config: n,
        props: {
            handleDOMEvents: {
                beforeinput(e, s) {
                    const r = s.inputType,
                        o = r == "historyUndo" ? Te : r == "historyRedo" ? be : null;
                    return !o || !e.editable ? !1 : (s.preventDefault(), o(e.state, e.dispatch))
                }
            }
        }
    })
}

function K(n, t) {
    return (e, s) => {
        const r = w.getState(e);
        if (!r || (n ? r.undone : r.done).eventCount == 0) return !1;
        if (s) {
            const o = Ne(r, e, n);
            o && s(t ? o.scrollIntoView() : o)
        }
        return !0
    }
}
const Te = K(!1, !0),
    be = K(!0, !0);
export {
    we as P, ce as S, w as a, Ve as g, Ke as h, be as r, Te as u
};
//# sourceMappingURL=bt8940c6l4ej9r7j.js.map