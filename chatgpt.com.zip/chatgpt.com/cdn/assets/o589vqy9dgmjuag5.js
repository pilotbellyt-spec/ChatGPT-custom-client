import {
    j as o
} from "./fg33krlcm0qyi6yw.js";
import {
    Z as s
} from "./ce3hgmw4iyyhicud.js";
import {
    bg as r,
    l as m
} from "./dykg4ktvbu3mhmdo.js";

function c({
    className: t,
    zIndexKey: i,
    onClick: a
}) {
    return o.jsx(r.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        className: m("absolute inset-0", t, s[i]),
        onClick: a
    })
}
export {
    c as O
};
//# sourceMappingURL=o589vqy9dgmjuag5.js.map