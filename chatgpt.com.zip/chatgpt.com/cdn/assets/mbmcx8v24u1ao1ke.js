function c(t) {
    var n = Object.create(null);
    return function(e) {
        return n[e] === void 0 && (n[e] = t(e)), n[e]
    }
}
export {
    c as m
};
//# sourceMappingURL=mbmcx8v24u1ao1ke.js.map