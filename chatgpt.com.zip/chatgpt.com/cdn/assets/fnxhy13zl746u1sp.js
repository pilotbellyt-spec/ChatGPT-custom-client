import {
    c as e,
    s as t
} from "./dykg4ktvbu3mhmdo.js";
import "./fg33krlcm0qyi6yw.js";
const a = e(t, "e6a16c", 20, 20);
export {
    a as
    default
};
//# sourceMappingURL=fnxhy13zl746u1sp.js.map