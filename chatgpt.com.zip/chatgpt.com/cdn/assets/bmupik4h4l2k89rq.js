var A = Object.freeze,
    W = Object.defineProperty;
var D = (s, n) => A(W(s, "raw", {
    value: A(n || s.slice())
}));
import {
    e as Q,
    a as G,
    r as v,
    i as H,
    b as V,
    j as e,
    M as m,
    u as Z,
    d as J
} from "./fg33krlcm0qyi6yw.js";
import {
    I as X,
    b as Y,
    P as b,
    C as $,
    a9 as z,
    F as ee,
    m as se,
    R as L,
    T as te,
    g2 as j
} from "./dykg4ktvbu3mhmdo.js";
import {
    d5 as ae,
    d6 as re,
    d7 as U,
    d8 as K,
    cV as ne,
    cL as oe,
    d9 as ie,
    cw as le,
    da as de
} from "./k15yxxoybkkir2ou.js";
import {
    T as M
} from "./hn5e71c3hkpkv00z.js";
import {
    M as me,
    R as ce,
    t as ue
} from "./cgt1h5qo3k52ojx3.js";

function he({
    gizmo: s,
    memory: n
}) {
    var h;
    const o = Q(),
        d = se(),
        l = G(),
        {
            mutate: t,
            isPending: c
        } = Z({
            mutationFn: async y => {
                const {
                    success: w
                } = await L.safeDelete("/memories/{memory_id}", {
                    parameters: {
                        path: {
                            memory_id: y
                        }
                    },
                    requestBody: {
                        gizmo_id: s == null ? void 0 : s.id
                    }
                });
                if (!w) throw new Error("An error occurred while deleting the memory")
            },
            onSettled: () => {
                l.invalidateQueries({
                    queryKey: U(s == null ? void 0 : s.id)
                }), l.invalidateQueries({
                    queryKey: K()
                })
            },
            onError: () => {
                d.danger(J({
                    id: "MemoriesModal.deleteFailed",
                    defaultMessage: "Failed to forget memory"
                }), {
                    id: "memoryDeleteFailed",
                    toastId: "memory_delete_failed"
                })
            }
        }),
        [p, u] = v.useState(!1),
        a = o.formatMessage({
            id: "N0czuB",
            defaultMessage: "Remove"
        });
    return e.jsxs(e.Fragment, {
        children: [e.jsxs(M.Row, {
            disabled: c,
            children: [e.jsx(M.Cell, {
                children: e.jsx("div", {
                    className: "py-2 whitespace-pre-wrap",
                    children: n.content
                })
            }), e.jsx(M.Cell, {
                textAlign: "right",
                children: e.jsx(M.Actions, {
                    children: e.jsx("button", {
                        onClick: () => {
                            b.logEvent("Memory Manage Modal Memory Delete Clicked"), u(!0)
                        },
                        "aria-label": a,
                        className: "text-token-text-tertiary hover:text-token-text-secondary",
                        children: e.jsx(te, {
                            className: "leading-none",
                            label: a,
                            side: "top",
                            children: e.jsx(oe, {
                                className: "icon-sm"
                            })
                        })
                    })
                })
            })]
        }), p && e.jsx(ie, {
            isOpen: !0,
            primaryButtonColor: "danger",
            title: a,
            confirmText: o.formatMessage({
                id: "fCn0ar",
                defaultMessage: "Forget"
            }),
            onConfirm: () => {
                b.logEvent("Memory Manage Modal Memory Delete Confirmed"), t(n.id), u(!1)
            },
            onClose: () => {
                u(!1)
            },
            children: e.jsx(m, {
                id: "j2cZHW",
                defaultMessage: 'Remove "{title}" from {name}’s saved memories. This can’t be undone. <link>Learn more</link>',
                values: {
                    name: (h = s == null ? void 0 : s.name) != null ? h : "ChatGPT",
                    title: e.jsx("strong", {
                        children: ue(n.content, {
                            length: 130,
                            omission: "..."
                        })
                    }),
                    link: y => e.jsx("a", {
                        href: "https://help.openai.com/en/articles/8590148-memory-faq",
                        target: "_blank",
                        className: "underline",
                        rel: "noreferrer",
                        children: y
                    })
                }
            })
        })]
    })
}

function xe({
    selectedGizmoId: s,
    onSelect: n,
    items: o
}) {
    const d = o.find(t => t.id === s);

    function l(t) {
        var c;
        return e.jsx(de, {
            isFirstParty: t.id === void 0,
            src: (c = t.iconUrl) != null ? c : null,
            className: "icon"
        })
    }
    return e.jsx("div", {
        className: "border-token-border-medium mb-2 inline-flex rounded-md border",
        children: e.jsxs(j.Root, {
            children: [e.jsx(j.Trigger, {
                children: e.jsxs("div", {
                    className: "flex items-center gap-2",
                    children: [d ? e.jsxs(e.Fragment, {
                        children: [l(d), e.jsx("span", {
                            className: "text-token-text-primary",
                            children: d.name
                        })]
                    }) : e.jsx(m, {
                        id: "MemoriesModal.unknownGizmo",
                        defaultMessage: "Unknown GPT"
                    }), e.jsx(le, {
                        className: "icon-sm text-token-text-tertiary"
                    })]
                })
            }), e.jsx(j.Portal, {
                children: e.jsx(j.Content, {
                    children: o.map(t => e.jsxs(j.Item, {
                        className: "flex items-center gap-3",
                        onClick: () => {
                            n(t.id)
                        },
                        children: [l(t), t.name]
                    }, t.id))
                })
            })]
        })
    })
}
var B;
const F = ee.div(B || (B = D(["flex h-full items-center justify-center pb-8 text-sm text-token-text-tertiary rounded-lg border border-token-border-default"])));

function ve({
    onClose: s,
    initialGizmoId: n,
    exclusiveToGizmo: o = !1,
    showResetMemoriesButton: d = !0,
    contextScopes: l,
    requiredContextScopes: t
}) {
    var R, I, S;
    const c = Q(),
        p = G(),
        u = ae(),
        [a, h] = v.useState(n),
        y = Y(),
        w = H(),
        C = X(y),
        T = C == null ? void 0 : C.hasPlusFeatures();
    v.useEffect(() => {
        b.logEvent("Memory Modal Shown")
    }, []);
    const {
        data: x,
        isLoading: N,
        isError: k,
        refetch: E
    } = re({
        gizmoId: a,
        exclusiveToGizmo: o,
        enabled: u,
        contextScopes: l,
        requiredContextScopes: t
    }), f = x == null ? void 0 : x.memories, {
        data: P,
        refetch: O
    } = V({
        queryKey: ["memory_gizmos"],
        queryFn: () => L.safeGet("/memories/gizmos"),
        refetchOnMount: "always"
    }), _ = [{
        id: void 0,
        name: "ChatGPT",
        iconUrl: null
    }, ...(R = P == null ? void 0 : P.items.map(({
        gizmo: r
    }) => {
        var q;
        return {
            id: r.id,
            name: r.display.name,
            iconUrl: (q = r.display.profile_picture_url) != null ? q : null
        }
    })) != null ? R : []], i = _.find(r => r.id === a);
    v.useEffect(() => {
        !o && !N && !k && a !== void 0 && (!f || f.length === 0) && h(void 0)
    }, [o, N, k, f, a]);
    let g;
    return N ? g = e.jsx(F, {
        children: e.jsx(m, {
            id: "MemoriesModal.loading",
            defaultMessage: "Loading..."
        })
    }) : k ? g = e.jsx(F, {
        children: e.jsxs("div", {
            className: "max-w-sm text-center",
            children: [e.jsx("div", {
                className: "mb-4 text-red-500",
                children: e.jsx(m, {
                    id: "MemoriesModal.somethingWentWrong",
                    defaultMessage: "Something went wrong..."
                })
            }), e.jsx("div", {
                children: e.jsx(z, {
                    color: "secondary",
                    onClick: () => {
                        E()
                    },
                    children: e.jsx(m, {
                        id: "MemoriesModal.retry",
                        defaultMessage: "Retry"
                    })
                })
            })]
        })
    }) : !f || f.length === 0 ? g = e.jsx(F, {
        children: e.jsx("div", {
            className: "max-w-sm text-center",
            children: u ? e.jsx(m, {
                id: "MemoriesModal.noMemories.1",
                defaultMessage: "As you chat with {name}, the details and preferences it saves will be shown here.",
                values: {
                    name: (I = i == null ? void 0 : i.name) != null ? I : "ChatGPT"
                }
            }) : e.jsx(m, {
                id: "MemoriesModal.noMemoriesAndDisabled",
                defaultMessage: "Memory is disabled. ChatGPT won't use or save memories."
            })
        })
    }) : g = e.jsx(M.Root, {
        className: "border-token-border-default h-full",
        size: "compact",
        bordered: !0,
        children: e.jsx(M.Body, {
            children: f.map(r => e.jsx(he, {
                gizmo: i ? {
                    id: i.id,
                    name: i.name
                } : void 0,
                memory: r
            }, r.id))
        })
    }), e.jsxs($, {
        testId: "modal-memories",
        isOpen: !0,
        onClose: s,
        size: "custom",
        className: "max-w-5xl",
        type: "success",
        title: c.formatMessage({
            id: "MemoriesModal.title",
            defaultMessage: "Saved memories"
        }),
        showCloseButton: !0,
        children: [T && _.length > 1 && e.jsx("div", {
            className: "mb-4",
            children: e.jsx(xe, {
                selectedGizmoId: a,
                items: _,
                onSelect: r => {
                    p.invalidateQueries({
                        queryKey: U(r)
                    }), p.invalidateQueries({
                        queryKey: K()
                    }), h(r)
                }
            })
        }), e.jsx(me, {
            memoryFullPct: x == null ? void 0 : x.memoryFullPct,
            isPaid: T,
            showUpgradeCTA: !1,
            onUpgrade: () => {
                b.logEventWithStatsig("Memories Upgrade Button Clicked", "chatgpt_memories_upgrade_button_clicked_settings"), ne(w, "chatgpt_memories_upgrade_button")
            },
            className: "mb-5"
        }), e.jsx("div", {
            className: "h-[24rem]",
            children: g
        }), d && e.jsx("div", {
            className: "mt-5 flex justify-end",
            children: e.jsx(ce, {
                onReset: () => {
                    E(), O(), a && h(void 0)
                },
                gizmoId: a,
                memoryName: (S = i == null ? void 0 : i.name) != null ? S : "ChatGPT",
                contextScopes: l,
                requiredContextScopes: t
            })
        })]
    })
}
export {
    ve as
    default
};
//# sourceMappingURL=bmupik4h4l2k89rq.js.map