import {
    r as t
} from "./fg33krlcm0qyi6yw.js";
const r = t.createContext(void 0);
export {
    r as W
};
//# sourceMappingURL=zqbip2ya77i1mx4s.js.map