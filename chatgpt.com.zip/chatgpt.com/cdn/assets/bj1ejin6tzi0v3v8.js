function t(e) {
    if (e) return "textdoc-message-".concat(e)
}
export {
    t as g
};
//# sourceMappingURL=bj1ejin6tzi0v3v8.js.map