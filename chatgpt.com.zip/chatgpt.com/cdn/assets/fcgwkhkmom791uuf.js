import {
    qT as o,
    qS as s,
    qR as d
} from "./dykg4ktvbu3mhmdo.js";
import "./fg33krlcm0qyi6yw.js";
export {
    o as
    default, s as meta, d as shouldRevalidate
};
//# sourceMappingURL=fcgwkhkmom791uuf.js.map