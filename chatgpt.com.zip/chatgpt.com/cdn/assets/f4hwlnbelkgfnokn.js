const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/3pw8457xvsfag90w.js", "assets/fg33krlcm0qyi6yw.js", "assets/k15yxxoybkkir2ou.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/conversation-small-332fs9rk.css", "assets/fu96nxanm8bvt745.js", "assets/gd2ozzf4upgi0amm.js", "assets/ctvu3ya1jzfn0gdq.js", "assets/d6c194b8r37zigga.js", "assets/ii1vbrsyheft91cc.js", "assets/hpmzcrnchtp2pgs4.js", "assets/k2oaaf8ac9lafsub.js", "assets/lans8a2ikbh9ax9r.js", "assets/j63amn1eooyu8ua6.js", "assets/k7bax4ffse9ora8u.js", "assets/jkejdo8v5ynnt9ff.js", "assets/o67bv4dtwt5l98l7.js", "assets/fj4bpqcms0mhjoda.js", "assets/eejiqzdptzp07q5y.js", "assets/ew68kf01y1h7e4uk.js", "assets/jttqqjx6qab96ezg.js", "assets/e3ddui4ro6nb7fig.js", "assets/iw47v9tf328v3kli.js", "assets/ib78f9d5brp6znzf.js", "assets/ou2xm3xmri21t4zm.js", "assets/hz9475nc5ndyfqsu.js", "assets/omy347b79inqzbaj.js", "assets/i5kvudettvxsr7pw.js", "assets/jlu292yvnhcpthaw.js", "assets/f78b2oufkmgyeo1t.js", "assets/vozjnukg4phajo4v.js", "assets/ipesqf5fzqgtmnar.js", "assets/bdob0mmccomv88dh.js", "assets/cdnrxzg58mayu5uf.js", "assets/gmop4abenl57iboh.js", "assets/jhvz2qkf3st8xisu.js", "assets/lts8z3c38wfynrxz.js", "assets/ccj0kc5w6drbfrlh.js", "assets/ef7gr7kimbtxrws9.js", "assets/nr0ly5umft9hqfl0.js", "assets/gjyisy9q1t8rz8p4.js", "assets/lqog7ixiwnif6sbp.js", "assets/nzl91iujqafxz8y1.js", "assets/ebc4iyfg14nu1gw4.js", "assets/gy1lpvuoewmzh42c.js", "assets/jed1ux7qibe55pmj.js", "assets/h1em0bjkpkjv8ykw.js", "assets/nfccle6oyncifphl.js", "assets/hu1bt0oauegdhua6.js", "assets/b5s349mvbdzayaxi.js", "assets/dbshkzvpochy4889.js", "assets/zdzro29lk5w2w085.js", "assets/mplxh51rlu001wdb.js", "assets/cu0e6szsqsyduwov.js", "assets/ftef8970ba1zoykr.js"]))) => i.map(i => d[i]);
var q = Object.defineProperty,
    U = Object.defineProperties;
var Q = Object.getOwnPropertyDescriptors;
var O = Object.getOwnPropertySymbols;
var $ = Object.prototype.hasOwnProperty,
    J = Object.prototype.propertyIsEnumerable;
var W = (i, e, o) => e in i ? q(i, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: o
    }) : i[e] = o,
    A = (i, e) => {
        for (var o in e || (e = {})) $.call(e, o) && W(i, o, e[o]);
        if (O)
            for (var o of O(e)) J.call(e, o) && W(i, o, e[o]);
        return i
    },
    L = (i, e) => U(i, Q(e));
import {
    j as t,
    r as D,
    _ as g,
    c as K
} from "./fg33krlcm0qyi6yw.js";
import {
    B as X
} from "./ii1vbrsyheft91cc.js";
import {
    mB as Y,
    mC as Z,
    mD as ee,
    hD as M,
    l1 as te,
    bo as R,
    eF as B,
    mE as se,
    dV as ie,
    dm as oe,
    by as le,
    T as re,
    dW as ae,
    i6 as ne,
    mF as de,
    mG as ce,
    mH as me
} from "./k15yxxoybkkir2ou.js";
import {
    kQ as he,
    ot as z,
    bv as fe,
    uF as xe,
    bg as H,
    bh as I,
    I as ue,
    e as _e,
    qv as pe,
    qx as je,
    qw as ge
} from "./dykg4ktvbu3mhmdo.js";
import {
    P as Ie
} from "./o67bv4dtwt5l98l7.js";
import {
    T as Pe
} from "./iw47v9tf328v3kli.js";

function ve({
    conversation: i
}) {
    const e = Y();
    return t.jsxs(t.Fragment, {
        children: [e && t.jsx(Z, {
            conversation: i
        }), t.jsx(Ce, {
            conversation: i
        })]
    })
}

function Ce({
    conversation: i
}) {
    const e = D.useContext(he),
        [o, s] = D.useState(!!(e != null && e.postWithProfile) && e.postWithProfile.post.attachments && e.postWithProfile.post.attachments.every(l => l.kind === "media_generation"));
    return !(e != null && e.postWithProfile) || !o ? null : t.jsx(z, {
        conversation: i,
        children: t.jsx(Ie, {
            clientThreadId: i.id,
            postWithProfile: e.postWithProfile,
            onClose: () => s(!1)
        })
    })
}
const be = 450;

function Se({
    children: i,
    conversation: e,
    isOpen: o,
    onClose: s,
    type: l
}) {
    return t.jsx(fe, {
        children: o && t.jsx(xe, {
            children: t.jsx(ee.Provider, {
                value: {
                    isEmbeddedInFocusedView: !0,
                    type: l
                },
                children: t.jsxs("div", {
                    className: "absolute inset-0 flex flex-col",
                    children: [t.jsx(H.div, A({
                        className: "bg-token-main-surface-secondary h-full w-full"
                    }, M)), t.jsxs("div", {
                        className: "absolute inset-0 flex",
                        children: [t.jsx("div", {
                            className: "grow overflow-auto",
                            children: i
                        }), t.jsx(H.div, L(A({
                            className: "border-token-border-medium bg-token-main-surface-primary relative shrink-0 border-s",
                            style: {
                                width: be
                            }
                        }, M), {
                            children: t.jsx("div", {
                                className: "h-svh",
                                children: t.jsx(Pe, {
                                    conversation: e,
                                    hideDisclaimer: !0
                                }, e.id)
                            })
                        }))]
                    })]
                })
            })
        })
    })
}
const Te = I(() => g(() =>
        import ("./3pw8457xvsfag90w.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7]))),
    Ee = I(() => g(() =>
        import ("./ctvu3ya1jzfn0gdq.js"), __vite__mapDeps([8, 1, 3, 4, 2, 5, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30])).then(i => i.ImageEditor));

function Fe({
    conversation: i
}) {
    const e = te();
    D.useEffect(() => {
        R.close()
    }, [i.id]);
    let o;
    return (e == null ? void 0 : e.type) === B.ADAVisualization ? o = t.jsx(Te, {
        clientThreadId: i.id,
        visualization: e.visualization
    }) : (e == null ? void 0 : e.type) === B.Image && (o = t.jsx(Ee, {
        clientThreadId: i.id,
        messageId: e.messageId,
        image: e.image,
        allImages: e.allImages
    }, e.image.asset_pointer)), t.jsx(Se, {
        conversation: i,
        isOpen: e != null,
        onClose: R.close,
        type: e == null ? void 0 : e.type,
        children: o
    })
}
const we = I(() => g(() =>
        import ("./vozjnukg4phajo4v.js"), __vite__mapDeps([31, 1, 2, 3, 4, 5, 12, 13]))),
    ye = I(() => g(() =>
        import ("./ipesqf5fzqgtmnar.js").then(i => i.s), __vite__mapDeps([32, 1, 33, 3, 4, 2, 5, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52])).then(i => i.CheckoutModal)),
    Ve = () => null,
    ke = I(() => g(() =>
        import ("./mplxh51rlu001wdb.js"), __vite__mapDeps([53, 1, 2, 3, 4, 5, 54, 55])).then(i => i.VoiceNavigationBlocker));

function Re(i) {
    "use forget";
    var N;
    const e = K.c(50),
        {
            children: o,
            conversation: s,
            filepickerStore: l,
            redirects: k
        } = i;
    let P;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (P = (N = ue(_e())) == null ? void 0 : N.getWorkspaceId(), e[0] = P) : P = e[0];
    const G = P;
    let v;
    e[1] === Symbol.for("react.memo_cache_sentinel") ? (v = t.jsx(ke, {}), e[1] = v) : v = e[1];
    let r, a;
    e[2] !== s.id ? (r = t.jsx(X, {
        clientThreadId: s.id,
        page: "chat"
    }, G), a = t.jsx(se, {
        clientThreadId: s.id
    }), e[2] = s.id, e[3] = r, e[4] = a) : (r = e[3], a = e[4]);
    let C, b, S;
    e[5] === Symbol.for("react.memo_cache_sentinel") ? (C = t.jsx(we, {}), b = t.jsx(ne, {}), S = t.jsx(de, {}), e[5] = C, e[6] = b, e[7] = S) : (C = e[5], b = e[6], S = e[7]);
    let n, d;
    e[8] !== s ? (n = t.jsx(ve, {
        conversation: s
    }), d = t.jsx(Fe, {
        conversation: s
    }), e[8] = s, e[9] = n, e[10] = d) : (n = e[9], d = e[10]);
    let c;
    e[11] !== s.id ? (c = t.jsx(ie, {
        clientThreadId: s.id
    }), e[11] = s.id, e[12] = c) : c = e[12];
    let T;
    e[13] === Symbol.for("react.memo_cache_sentinel") ? (T = t.jsx(ce, {}), e[13] = T) : T = e[13];
    let m;
    e[14] !== s.id ? (m = t.jsx(oe, {
        clientThreadId: s.id
    }), e[14] = s.id, e[15] = m) : m = e[15];
    let E;
    e[16] === Symbol.for("react.memo_cache_sentinel") ? (E = t.jsx(me, {}), e[16] = E) : E = e[16];
    let h;
    e[17] !== o || e[18] !== c || e[19] !== m || e[20] !== r || e[21] !== a || e[22] !== n || e[23] !== d ? (h = t.jsxs(le.Context, {
        children: [r, a, C, b, S, o, n, d, c, T, m, E]
    }), e[17] = o, e[18] = c, e[19] = m, e[20] = r, e[21] = a, e[22] = n, e[23] = d, e[24] = h) : h = e[24];
    let f;
    e[25] !== s || e[26] !== h ? (f = t.jsx(z, {
        conversation: s,
        children: h
    }), e[25] = s, e[26] = h, e[27] = f) : f = e[27];
    let x;
    e[28] !== s || e[29] !== f ? (x = t.jsx(je, {
        conversation: s,
        children: f
    }), e[28] = s, e[29] = f, e[30] = x) : x = e[30];
    let u;
    e[31] !== s.id || e[32] !== x ? (u = t.jsx(re, {
        clientThreadId: s.id,
        children: x
    }), e[31] = s.id, e[32] = x, e[33] = u) : u = e[33];
    let _;
    e[34] !== s.id || e[35] !== u ? (_ = t.jsx(ae, {
        clientThreadId: s.id,
        children: u
    }), e[34] = s.id, e[35] = u, e[36] = _) : _ = e[36];
    let F, w;
    e[37] === Symbol.for("react.memo_cache_sentinel") ? (F = t.jsx(ye, {}), w = t.jsx(Ve, {}), e[37] = F, e[38] = w) : (F = e[37], w = e[38]);
    let p;
    e[39] !== s.id ? (p = !1, e[39] = s.id, e[40] = p) : p = e[40];
    let y;
    e[41] === Symbol.for("react.memo_cache_sentinel") ? (y = !1, e[41] = y) : y = e[41];
    let j;
    e[42] !== l || e[43] !== _ || e[44] !== p ? (j = t.jsxs(ge, {
        store: l,
        children: [_, F, w, p, y]
    }), e[42] = l, e[43] = _, e[44] = p, e[45] = j) : j = e[45];
    let V;
    return e[46] !== s || e[47] !== k || e[48] !== j ? (V = t.jsxs(pe.Provider, {
        value: s,
        children: [k, v, j]
    }), e[46] = s, e[47] = k, e[48] = j, e[49] = V) : V = e[49], V
}
export {
    Re as C, be as F
};
//# sourceMappingURL=f4hwlnbelkgfnokn.js.map