class s extends Worker {
    constructor(e, r) {
        const t = String(e);
        super(t.includes("://") && !t.startsWith(location.origin) ? URL.createObjectURL(new Blob(['import("'.concat(t, '")')], {
            type: "text/javascript"
        })) : e, r)
    }
}
export {
    s as L
};
//# sourceMappingURL=iiok29s29bpdre61.js.map