var O = Object.defineProperty,
    A = Object.defineProperties;
var F = Object.getOwnPropertyDescriptors;
var x = Object.getOwnPropertySymbols;
var B = Object.prototype.hasOwnProperty,
    $ = Object.prototype.propertyIsEnumerable;
var b = (r, n, e) => n in r ? O(r, n, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : r[n] = e,
    h = (r, n) => {
        for (var e in n || (n = {})) B.call(n, e) && b(r, e, n[e]);
        if (x)
            for (var e of x(n)) $.call(n, e) && b(r, e, n[e]);
        return r
    },
    g = (r, n) => A(r, F(n));
import {
    c5 as q,
    Cb as M,
    zr as Q
} from "./k15yxxoybkkir2ou.js";
import {
    t as _
} from "./hu1bt0oauegdhua6.js";

function U(r, n, e, c) {
    const u = e.enter("blockquote"),
        f = e.createTracker(c);
    f.move("> "), f.shift(2);
    const t = e.indentLines(e.containerFlow(r, f.current()), D);
    return u(), t
}

function D(r, n, e) {
    return ">" + (e ? "" : " ") + r
}

function G(r, n) {
    return d(r, n.inConstruct, !0) && !d(r, n.notInConstruct, !1)
}

function d(r, n, e) {
    if (typeof n == "string" && (n = [n]), !n || n.length === 0) return e;
    let c = -1;
    for (; ++c < n.length;)
        if (r.includes(n[c])) return !0;
    return !1
}

function w(r, n, e, c) {
    let u = -1;
    for (; ++u < e.unsafe.length;)
        if (e.unsafe[u].character === "\n" && G(e.stack, e.unsafe[u])) return /[ \t]/.test(c.before) ? "" : " ";
    return "\\\n"
}

function H(r, n) {
    const e = String(r);
    let c = e.indexOf(n),
        u = c,
        f = 0,
        t = 0;
    if (typeof n != "string" || n.length !== 1) throw new Error("Expected character");
    for (; c !== -1;) c === u ? ++f > t && (t = f) : f = 1, u = c + 1, c = e.indexOf(n, u);
    return t
}

function J(r, n) {
    return !!(n.options.fences === !1 && r.value && !r.lang && /[^ \r\n]/.test(r.value) && !/^[\t ]*(?:[\r\n]|$)|(?:^|[\r\n])[\t ]*$/.test(r.value))
}

function W(r) {
    const n = r.options.fence || "`";
    if (n !== "`" && n !== "~") throw new Error("Cannot serialize code with `" + n + "` for `options.fence`, expected `` ` `` or `~`");
    return n
}

function X(r, n, e, c) {
    const u = W(e),
        f = r.value || "",
        t = u === "`" ? "GraveAccent" : "Tilde";
    if (J(r, e)) {
        const a = e.enter("codeIndented"),
            m = e.indentLines(f, j);
        return a(), m
    }
    const l = e.createTracker(c),
        o = u.repeat(Math.max(H(f, u) + 1, 3)),
        i = e.enter("codeFenced");
    let s = l.move(o);
    if (r.lang) {
        const a = e.enter("codeFencedLang".concat(t));
        s += l.move(e.safe(r.lang, h({
            before: s,
            after: " ",
            encode: ["`"]
        }, l.current()))), a()
    }
    if (r.lang && r.meta) {
        const a = e.enter("codeFencedMeta".concat(t));
        s += l.move(" "), s += l.move(e.safe(r.meta, h({
            before: s,
            after: "\n",
            encode: ["`"]
        }, l.current()))), a()
    }
    return s += l.move("\n"), f && (s += l.move(f + "\n")), s += l.move(o), i(), s
}

function j(r, n, e) {
    return (e ? "" : "    ") + r
}

function p(r) {
    const n = r.options.quote || '"';
    if (n !== '"' && n !== "'") throw new Error("Cannot serialize title with `" + n + "` for `options.quote`, expected `\"`, or `'`");
    return n
}

function K(r, n, e, c) {
    const u = p(e),
        f = u === '"' ? "Quote" : "Apostrophe",
        t = e.enter("definition");
    let l = e.enter("label");
    const o = e.createTracker(c);
    let i = o.move("[");
    return i += o.move(e.safe(e.associationId(r), h({
        before: i,
        after: "]"
    }, o.current()))), i += o.move("]: "), l(), !r.url || /[\0- \u007F]/.test(r.url) ? (l = e.enter("destinationLiteral"), i += o.move("<"), i += o.move(e.safe(r.url, h({
        before: i,
        after: ">"
    }, o.current()))), i += o.move(">")) : (l = e.enter("destinationRaw"), i += o.move(e.safe(r.url, h({
        before: i,
        after: r.title ? " " : "\n"
    }, o.current())))), l(), r.title && (l = e.enter("title".concat(f)), i += o.move(" " + u), i += o.move(e.safe(r.title, h({
        before: i,
        after: u
    }, o.current()))), i += o.move(u), l()), t(), i
}

function N(r) {
    const n = r.options.emphasis || "*";
    if (n !== "*" && n !== "_") throw new Error("Cannot serialize emphasis with `" + n + "` for `options.emphasis`, expected `*`, or `_`");
    return n
}
C.peek = V;

function C(r, n, e, c) {
    const u = N(e),
        f = e.enter("emphasis"),
        t = e.createTracker(c);
    let l = t.move(u);
    return l += t.move(e.containerPhrasing(r, h({
        before: l,
        after: u
    }, t.current()))), l += t.move(u), f(), l
}

function V(r, n, e) {
    return e.options.emphasis || "*"
}

function Y(r, n) {
    let e = !1;
    return q(r, function(c) {
        if ("value" in c && /\r?\n|\r/.test(c.value) || c.type === "break") return e = !0, M
    }), !!((!r.depth || r.depth < 3) && _(r) && (n.options.setext || e))
}

function Z(r, n, e, c) {
    const u = Math.max(Math.min(6, r.depth || 1), 1),
        f = e.createTracker(c);
    if (Y(r, e)) {
        const s = e.enter("headingSetext"),
            a = e.enter("phrasing"),
            m = e.containerPhrasing(r, g(h({}, f.current()), {
                before: "\n",
                after: "\n"
            }));
        return a(), s(), m + "\n" + (u === 1 ? "=" : "-").repeat(m.length - (Math.max(m.lastIndexOf("\r"), m.lastIndexOf("\n")) + 1))
    }
    const t = "#".repeat(u),
        l = e.enter("headingAtx"),
        o = e.enter("phrasing");
    f.move(t + " ");
    let i = e.containerPhrasing(r, h({
        before: "# ",
        after: "\n"
    }, f.current()));
    return /^[\t ]/.test(i) && (i = "&#x" + i.charCodeAt(0).toString(16).toUpperCase() + ";" + i.slice(1)), i = i ? t + " " + i : t, e.options.closeAtx && (i += " " + t), o(), l(), i
}
I.peek = ee;

function I(r) {
    return r.value || ""
}

function ee() {
    return "<"
}
P.peek = re;

function P(r, n, e, c) {
    const u = p(e),
        f = u === '"' ? "Quote" : "Apostrophe",
        t = e.enter("image");
    let l = e.enter("label");
    const o = e.createTracker(c);
    let i = o.move("![");
    return i += o.move(e.safe(r.alt, h({
        before: i,
        after: "]"
    }, o.current()))), i += o.move("]("), l(), !r.url && r.title || /[\0- \u007F]/.test(r.url) ? (l = e.enter("destinationLiteral"), i += o.move("<"), i += o.move(e.safe(r.url, h({
        before: i,
        after: ">"
    }, o.current()))), i += o.move(">")) : (l = e.enter("destinationRaw"), i += o.move(e.safe(r.url, h({
        before: i,
        after: r.title ? " " : ")"
    }, o.current())))), l(), r.title && (l = e.enter("title".concat(f)), i += o.move(" " + u), i += o.move(e.safe(r.title, h({
        before: i,
        after: u
    }, o.current()))), i += o.move(u), l()), i += o.move(")"), t(), i
}

function re() {
    return "!"
}
E.peek = ne;

function E(r, n, e, c) {
    const u = r.referenceType,
        f = e.enter("imageReference");
    let t = e.enter("label");
    const l = e.createTracker(c);
    let o = l.move("![");
    const i = e.safe(r.alt, h({
        before: o,
        after: "]"
    }, l.current()));
    o += l.move(i + "]["), t();
    const s = e.stack;
    e.stack = [], t = e.enter("reference");
    const a = e.safe(e.associationId(r), h({
        before: o,
        after: "]"
    }, l.current()));
    return t(), e.stack = s, f(), u === "full" || !i || i !== a ? o += l.move(a + "]") : u === "shortcut" ? o = o.slice(0, -1) : o += l.move("]"), o
}

function ne() {
    return "!"
}
R.peek = te;

function R(r, n, e) {
    let c = r.value || "",
        u = "`",
        f = -1;
    for (; new RegExp("(^|[^`])" + u + "([^`]|$)").test(c);) u += "`";
    for (/[^ \r\n]/.test(c) && (/^[ \r\n]/.test(c) && /[ \r\n]$/.test(c) || /^`|`$/.test(c)) && (c = " " + c + " "); ++f < e.unsafe.length;) {
        const t = e.unsafe[f],
            l = e.compilePattern(t);
        let o;
        if (t.atBreak)
            for (; o = l.exec(c);) {
                let i = o.index;
                c.charCodeAt(i) === 10 && c.charCodeAt(i - 1) === 13 && i--, c = c.slice(0, i) + " " + c.slice(o.index + 1)
            }
    }
    return u + c + u
}

function te() {
    return "`"
}

function S(r, n) {
    const e = _(r);
    return !!(!n.options.resourceLink && r.url && !r.title && r.children && r.children.length === 1 && r.children[0].type === "text" && (e === r.url || "mailto:" + e === r.url) && /^[a-z][a-z+.-]+:/i.test(r.url) && !/[\0- <>\u007F]/.test(r.url))
}
T.peek = ie;

function T(r, n, e, c) {
    const u = p(e),
        f = u === '"' ? "Quote" : "Apostrophe",
        t = e.createTracker(c);
    let l, o;
    if (S(r, e)) {
        const s = e.stack;
        e.stack = [], l = e.enter("autolink");
        let a = t.move("<");
        return a += t.move(e.containerPhrasing(r, h({
            before: a,
            after: ">"
        }, t.current()))), a += t.move(">"), l(), e.stack = s, a
    }
    l = e.enter("link"), o = e.enter("label");
    let i = t.move("[");
    return i += t.move(e.containerPhrasing(r, h({
        before: i,
        after: "]("
    }, t.current()))), i += t.move("]("), o(), !r.url && r.title || /[\0- \u007F]/.test(r.url) ? (o = e.enter("destinationLiteral"), i += t.move("<"), i += t.move(e.safe(r.url, h({
        before: i,
        after: ">"
    }, t.current()))), i += t.move(">")) : (o = e.enter("destinationRaw"), i += t.move(e.safe(r.url, h({
        before: i,
        after: r.title ? " " : ")"
    }, t.current())))), o(), r.title && (o = e.enter("title".concat(f)), i += t.move(" " + u), i += t.move(e.safe(r.title, h({
        before: i,
        after: u
    }, t.current()))), i += t.move(u), o()), i += t.move(")"), l(), i
}

function ie(r, n, e) {
    return S(r, e) ? "<" : "["
}
L.peek = oe;

function L(r, n, e, c) {
    const u = r.referenceType,
        f = e.enter("linkReference");
    let t = e.enter("label");
    const l = e.createTracker(c);
    let o = l.move("[");
    const i = e.containerPhrasing(r, h({
        before: o,
        after: "]"
    }, l.current()));
    o += l.move(i + "]["), t();
    const s = e.stack;
    e.stack = [], t = e.enter("reference");
    const a = e.safe(e.associationId(r), h({
        before: o,
        after: "]"
    }, l.current()));
    return t(), e.stack = s, f(), u === "full" || !i || i !== a ? o += l.move(a + "]") : u === "shortcut" ? o = o.slice(0, -1) : o += l.move("]"), o
}

function oe() {
    return "["
}

function k(r) {
    const n = r.options.bullet || "*";
    if (n !== "*" && n !== "+" && n !== "-") throw new Error("Cannot serialize items with `" + n + "` for `options.bullet`, expected `*`, `+`, or `-`");
    return n
}

function ce(r) {
    const n = k(r),
        e = r.options.bulletOther;
    if (!e) return n === "*" ? "-" : "*";
    if (e !== "*" && e !== "+" && e !== "-") throw new Error("Cannot serialize items with `" + e + "` for `options.bulletOther`, expected `*`, `+`, or `-`");
    if (e === n) throw new Error("Expected `bullet` (`" + n + "`) and `bulletOther` (`" + e + "`) to be different");
    return e
}

function le(r) {
    const n = r.options.bulletOrdered || ".";
    if (n !== "." && n !== ")") throw new Error("Cannot serialize items with `" + n + "` for `options.bulletOrdered`, expected `.` or `)`");
    return n
}

function y(r) {
    const n = r.options.rule || "*";
    if (n !== "*" && n !== "-" && n !== "_") throw new Error("Cannot serialize rules with `" + n + "` for `options.rule`, expected `*`, `-`, or `_`");
    return n
}

function ue(r, n, e, c) {
    const u = e.enter("list"),
        f = e.bulletCurrent;
    let t = r.ordered ? le(e) : k(e);
    const l = r.ordered ? t === "." ? ")" : "." : ce(e);
    let o = n && e.bulletLastUsed ? t === e.bulletLastUsed : !1;
    if (!r.ordered) {
        const s = r.children ? r.children[0] : void 0;
        if ((t === "*" || t === "-") && s && (!s.children || !s.children[0]) && e.stack[e.stack.length - 1] === "list" && e.stack[e.stack.length - 2] === "listItem" && e.stack[e.stack.length - 3] === "list" && e.stack[e.stack.length - 4] === "listItem" && e.indexStack[e.indexStack.length - 1] === 0 && e.indexStack[e.indexStack.length - 2] === 0 && e.indexStack[e.indexStack.length - 3] === 0 && (o = !0), y(e) === t && s) {
            let a = -1;
            for (; ++a < r.children.length;) {
                const m = r.children[a];
                if (m && m.type === "listItem" && m.children && m.children[0] && m.children[0].type === "thematicBreak") {
                    o = !0;
                    break
                }
            }
        }
    }
    o && (t = l), e.bulletCurrent = t;
    const i = e.containerFlow(r, c);
    return e.bulletLastUsed = t, e.bulletCurrent = f, u(), i
}

function fe(r) {
    const n = r.options.listItemIndent || "one";
    if (n !== "tab" && n !== "one" && n !== "mixed") throw new Error("Cannot serialize items with `" + n + "` for `options.listItemIndent`, expected `tab`, `one`, or `mixed`");
    return n
}

function se(r, n, e, c) {
    const u = fe(e);
    let f = e.bulletCurrent || k(e);
    n && n.type === "list" && n.ordered && (f = (typeof n.start == "number" && n.start > -1 ? n.start : 1) + (e.options.incrementListMarker === !1 ? 0 : n.children.indexOf(r)) + f);
    let t = f.length + 1;
    (u === "tab" || u === "mixed" && (n && n.type === "list" && n.spread || r.spread)) && (t = Math.ceil(t / 4) * 4);
    const l = e.createTracker(c);
    l.move(f + " ".repeat(t - f.length)), l.shift(t);
    const o = e.enter("listItem"),
        i = e.indentLines(e.containerFlow(r, l.current()), s);
    return o(), i;

    function s(a, m, v) {
        return m ? (v ? "" : " ".repeat(t)) + a : (v ? f : f + " ".repeat(t - f.length)) + a
    }
}

function ae(r, n, e, c) {
    const u = e.enter("paragraph"),
        f = e.enter("phrasing"),
        t = e.containerPhrasing(r, c);
    return f(), u(), t
}
const he = Q(["break", "delete", "emphasis", "footnote", "footnoteReference", "image", "imageReference", "inlineCode", "inlineMath", "link", "linkReference", "mdxJsxTextElement", "mdxTextExpression", "strong", "text", "textDirective"]);

function me(r, n, e, c) {
    return (r.children.some(function(t) {
        return he(t)
    }) ? e.containerPhrasing : e.containerFlow).call(e, r, c)
}

function pe(r) {
    const n = r.options.strong || "*";
    if (n !== "*" && n !== "_") throw new Error("Cannot serialize strong with `" + n + "` for `options.strong`, expected `*`, or `_`");
    return n
}
z.peek = ke;

function z(r, n, e, c) {
    const u = pe(e),
        f = e.enter("strong"),
        t = e.createTracker(c);
    let l = t.move(u + u);
    return l += t.move(e.containerPhrasing(r, h({
        before: l,
        after: u
    }, t.current()))), l += t.move(u + u), f(), l
}

function ke(r, n, e) {
    return e.options.strong || "*"
}

function ve(r, n, e, c) {
    return e.safe(r.value, c)
}

function xe(r) {
    const n = r.options.ruleRepetition || 3;
    if (n < 3) throw new Error("Cannot serialize rules with repetition `" + n + "` for `options.ruleRepetition`, expected `3` or more");
    return n
}

function be(r, n, e) {
    const c = (y(e) + (e.options.ruleSpaces ? " " : "")).repeat(xe(e));
    return e.options.ruleSpaces ? c.slice(0, -1) : c
}
const _e = {
    blockquote: U,
    break: w,
    code: X,
    definition: K,
    emphasis: C,
    hardBreak: w,
    heading: Z,
    html: I,
    image: P,
    imageReference: E,
    inlineCode: R,
    link: T,
    linkReference: L,
    list: ue,
    listItem: se,
    paragraph: ae,
    root: me,
    strong: z,
    text: ve,
    thematicBreak: be
};
export {
    Y as a, J as f, _e as h, H as l, G as p
};
//# sourceMappingURL=dbshkzvpochy4889.js.map