var j = Object.defineProperty;
var O = Object.getOwnPropertySymbols;
var M = Object.prototype.hasOwnProperty,
    C = Object.prototype.propertyIsEnumerable;
var w = (e, t, a) => t in e ? j(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: a
    }) : e[t] = a,
    v = (e, t) => {
        for (var a in t || (t = {})) M.call(t, a) && w(e, a, t[a]);
        if (O)
            for (var a of O(t)) C.call(t, a) && w(e, a, t[a]);
        return e
    };
import {
    e as P,
    r as c,
    u as p,
    j as r,
    M as l
} from "./fg33krlcm0qyi6yw.js";
import {
    h as b,
    E as F
} from "./dmkpfqcl39i5eaqb.js";
import {
    m as R,
    P as o,
    a9 as x,
    R as T,
    ti as B,
    b as N,
    p as S
} from "./dykg4ktvbu3mhmdo.js";
import {
    ds as k
} from "./k15yxxoybkkir2ou.js";
import {
    m as s,
    a as W
} from "./mqaxq6uz189xwrrs.js";
class V extends Error {
    constructor(t) {
        super(t), this.name = "OtpValidationError"
    }
}
const I = (e, t) => {
        if (t.length !== 6) return e.formatMessage(s.verifyOtpFailureInvalidFormat);
        try {
            parseInt(t)
        } catch (a) {
            return e.formatMessage(s.verifyOtpFailureInvalidFormat)
        }
        return null
    },
    X = (e, t, a) => {
        switch (a.status) {
            case 403:
                throw new Error(e.formatMessage(s.verifyOtpFailureEmailAlreadyLinked, {
                    branch: t ? "email" : "other",
                    emailValue: t
                }));
            case 429:
                throw new Error(e.formatMessage(s.verifyOtpFailureRateLimited));
            case 401:
            case 422:
                throw new Error(e.formatMessage(s.verifyOtpFailureInvalidOtp));
            default:
                return
        }
    };

function q(e) {
    var _;
    const t = N(),
        a = P(),
        y = R(),
        [f, u] = c.useState(null),
        E = (_ = e.showChangeEmailButton) != null ? _ : !0,
        h = c.useCallback(i => {
            var g;
            const n = i.target.value.trim();
            if (typeof n == "string") {
                if (n.match(/\D/)) {
                    i.preventDefault();
                    return
                }(g = e.onOtpChange) == null || g.call(e, n.substring(0, 6))
            }
        }, [e]),
        d = p({
            mutationFn: async () => {
                var i, n;
                try {
                    return e.onResendOtp ? await e.onResendOtp() : await W((i = e.email) != null ? i : "")
                } catch (g) {
                    throw g instanceof S && b(a, (n = e.email) != null ? n : "", g), new Error(a.formatMessage(s.sendEmailFailure))
                }
            },
            onSuccess: () => {
                e.setStep("verifyOtp")
            },
            onError: i => {
                u(i.message), o.logEventWithStatsig("Email Verify Verify OTP Step - Error Resending OTP", "chatgpt_email_verify_verify_otp_step_resend_error", {
                    error: i.message
                })
            }
        }),
        m = p({
            mutationFn: async i => {
                try {
                    const n = I(a, i.code);
                    if (n) throw new V(n);
                    if (e.onVerifyOtp) return await e.onVerifyOtp(i.code, i.email);
                    await T.safePost("/accounts/add_email/verify", {
                        requestBody: i
                    }), await B(t, {
                        reason: "verify_otp"
                    })
                } catch (n) {
                    throw n instanceof V ? n : (n instanceof S && X(a, e.email, n), new Error(a.formatMessage(s.verifyOtpFailure)))
                }
            },
            onSuccess: () => {
                var i;
                y.success(a.formatMessage(s.verifyOtpSuccess)), (i = e.onVerified) == null || i.call(e)
            },
            onError: i => {
                u(i.message), o.logEventWithStatsig("Email Verify Verify OTP Step - Error Verifying OTP", "chatgpt_email_verify_verify_otp_step_error", {
                    error: i.message
                })
            }
        });
    return c.useEffect(() => {
        o.logEventWithStatsig("Email Verify Verify OTP Step - Shown", "chatgpt_email_verify_verify_otp_step_shown")
    }, []), r.jsxs("div", {
        className: "flex w-full flex-col items-center gap-3",
        children: [r.jsx("p", {
            className: "text-3xl font-semibold",
            children: r.jsx(l, {
                id: "verifyOtp.title",
                defaultMessage: "Check your email"
            })
        }), r.jsxs("p", {
            className: "text-center",
            children: [r.jsx("span", {
                className: "text-token-text-primary text-base",
                children: r.jsx(l, {
                    id: "verifyOtp.description",
                    defaultMessage: "Enter the verification code we just sent to"
                })
            }), e.email && r.jsx("br", {}), r.jsx("span", {
                className: "text-token-text-primary text-base leading-snug ".concat(e.email && "font-semibold"),
                children: r.jsx(l, {
                    id: "verifyOtp.email",
                    defaultMessage: "{branch, select, email {{emailValue}} other { your email.}}",
                    values: {
                        branch: e.email ? "email" : "other",
                        emailValue: e.email
                    }
                })
            })]
        }), r.jsxs("form", {
            onSubmit: i => {
                var n;
                i.preventDefault(), m.mutate({
                    code: e.otp,
                    email: (n = e.email) != null ? n : ""
                }), o.logEventWithStatsig("Email Verify Verify OTP Step - Attempted Continue", "chatgpt_email_verify_verify_otp_step_continue")
            },
            className: "flex w-full flex-col items-center gap-3",
            children: [r.jsx(k, {
                error: f != null ? f : void 0,
                ariaLabel: a.formatMessage({
                    id: "emailVerify.otpAriaLabel",
                    defaultMessage: "OTP"
                }),
                value: e.otp,
                onChange: i => {
                    u(null), h(i), o.logEventWithStatsig("Email Verify Verify OTP Step - Typed", "chatgpt_email_verify_verify_otp_step_type")
                },
                name: "otp",
                type: "text",
                placeholder: "XXXXXX",
                className: "mt-6 w-full",
                autoComplete: "off",
                autoFocus: !0
            }), r.jsx(x, {
                className: "w-full rounded-md",
                color: "green",
                type: "submit",
                loading: m.isPending,
                disabled: m.isPending,
                children: r.jsx(l, {
                    id: "verifyOtp.continue",
                    defaultMessage: "Continue"
                })
            }), e.cancelFlowButton]
        }), r.jsxs("div", {
            className: "mt-6 flex w-full flex-col items-center gap-3",
            children: [r.jsx("p", {
                className: "text-token-text-primary text-sm",
                children: r.jsx(l, {
                    id: "verifyOtp.resendMessage",
                    defaultMessage: "Didn't receive the code?"
                })
            }), r.jsx(x, {
                className: "w-full rounded-md",
                color: "secondary",
                onClick: () => {
                    d.mutate(), o.logEventWithStatsig("Email Verify Verify OTP Step - Resend", "chatgpt_email_verify_verify_otp_step_resend")
                },
                loading: d.isPending,
                disabled: d.isPending,
                children: r.jsx(l, {
                    id: "verifyOtp.resend",
                    defaultMessage: "Resend code"
                })
            }), E && r.jsx(x, {
                className: "w-full rounded-md",
                color: "secondary",
                onClick: () => {
                    e.setStep("enterEmail"), o.logEventWithStatsig("Email Verify Verify OTP Step - Back to Enter Email Step", "chatgpt_email_verify_verify_otp_step_change_email")
                },
                children: r.jsx(l, {
                    id: "verifyOtp.changeEmail",
                    defaultMessage: "Change email"
                })
            })]
        })]
    })
}

function H(e) {
    var m;
    const [t, a] = c.useState((m = e.initialStep) != null ? m : "enterEmail"), [y, f] = c.useState(""), [u, E] = c.useState(""), h = e.email ? {
        email: e.email,
        onEmailChange: e.onEmailChange
    } : {
        email: y,
        onEmailChange: f
    }, d = e.otp ? {
        otp: e.otp,
        onOtpChange: e.onOtpChange
    } : {
        otp: u,
        onOtpChange: E
    };
    return t === "enterEmail" ? r.jsx(F, v({
        title: e.enterEmailTitle,
        description: e.enterEmailDescription,
        cancelFlowButton: e.cancelFlowButton,
        step: t,
        setStep: a
    }, h)) : r.jsx(q, v({
        email: h.email,
        onVerified: e.onVerified,
        cancelFlowButton: e.cancelFlowButton,
        step: t,
        setStep: a,
        showChangeEmailButton: e.showChangeEmailButton,
        onResendOtp: e.onResendOtp,
        onVerifyOtp: e.onVerifyOtp
    }, d))
}
export {
    H as E
};
//# sourceMappingURL=9xukfjm3wk4gydlw.js.map