import {
    tV as wr,
    tW as br,
    tX as yr
} from "./dykg4ktvbu3mhmdo.js";
class O {
    lineAt(t) {
        if (t < 0 || t > this.length) throw new RangeError("Invalid position ".concat(t, " in document of length ").concat(this.length));
        return this.lineInner(t, !1, 1, 0)
    }
    line(t) {
        if (t < 1 || t > this.lines) throw new RangeError("Invalid line number ".concat(t, " in ").concat(this.lines, "-line document"));
        return this.lineInner(t, !0, 1, 0)
    }
    replace(t, e, i) {
        [t, e] = Vt(this, t, e);
        let s = [];
        return this.decompose(0, t, s, 2), i.length && i.decompose(0, i.length, s, 3), this.decompose(e, this.length, s, 1), et.from(s, this.length - (e - t) + i.length)
    }
    append(t) {
        return this.replace(this.length, this.length, t)
    }
    slice(t, e = this.length) {
        [t, e] = Vt(this, t, e);
        let i = [];
        return this.decompose(t, e, i, 0), et.from(i, e - t)
    }
    eq(t) {
        if (t == this) return !0;
        if (t.length != this.length || t.lines != this.lines) return !1;
        let e = this.scanIdentical(t, 1),
            i = this.length - this.scanIdentical(t, -1),
            s = new _t(this),
            r = new _t(t);
        for (let o = e, l = e;;) {
            if (s.next(o), r.next(o), o = 0, s.lineBreak != r.lineBreak || s.done != r.done || s.value != r.value) return !1;
            if (l += s.value.length, s.done || l >= i) return !0
        }
    }
    iter(t = 1) {
        return new _t(this, t)
    }
    iterRange(t, e = this.length) {
        return new Xs(this, t, e)
    }
    iterLines(t, e) {
        let i;
        if (t == null) i = this.iter();
        else {
            e == null && (e = this.lines + 1);
            let s = this.line(t).from;
            i = this.iterRange(s, Math.max(s, e == this.lines + 1 ? this.length : e <= 1 ? 0 : this.line(e - 1).to))
        }
        return new Us(i)
    }
    toString() {
        return this.sliceString(0)
    }
    toJSON() {
        let t = [];
        return this.flatten(t), t
    }
    constructor() {}
    static of (t) {
        if (t.length == 0) throw new RangeError("A document must have at least one line");
        return t.length == 1 && !t[0] ? O.empty : t.length <= 32 ? new L(t) : et.from(L.split(t, []))
    }
}
class L extends O {
    constructor(t, e = xr(t)) {
        super(), this.text = t, this.length = e
    }
    get lines() {
        return this.text.length
    }
    get children() {
        return null
    }
    lineInner(t, e, i, s) {
        for (let r = 0;; r++) {
            let o = this.text[r],
                l = s + o.length;
            if ((e ? i : l) >= t) return new Sr(s, l, i, o);
            s = l + 1, i++
        }
    }
    decompose(t, e, i, s) {
        let r = t <= 0 && e >= this.length ? this : new L(Ui(this.text, t, e), Math.min(e, this.length) - Math.max(0, t));
        if (s & 1) {
            let o = i.pop(),
                l = Te(r.text, o.text.slice(), 0, r.length);
            if (l.length <= 32) i.push(new L(l, o.length + r.length));
            else {
                let h = l.length >> 1;
                i.push(new L(l.slice(0, h)), new L(l.slice(h)))
            }
        } else i.push(r)
    }
    replace(t, e, i) {
        if (!(i instanceof L)) return super.replace(t, e, i);
        [t, e] = Vt(this, t, e);
        let s = Te(this.text, Te(i.text, Ui(this.text, 0, t)), e),
            r = this.length + i.length - (e - t);
        return s.length <= 32 ? new L(s, r) : et.from(L.split(s, []), r)
    }
    sliceString(t, e = this.length, i = "\n") {
        [t, e] = Vt(this, t, e);
        let s = "";
        for (let r = 0, o = 0; r <= e && o < this.text.length; o++) {
            let l = this.text[o],
                h = r + l.length;
            r > t && o && (s += i), t < h && e > r && (s += l.slice(Math.max(0, t - r), e - r)), r = h + 1
        }
        return s
    }
    flatten(t) {
        for (let e of this.text) t.push(e)
    }
    scanIdentical() {
        return 0
    }
    static split(t, e) {
        let i = [],
            s = -1;
        for (let r of t) i.push(r), s += r.length + 1, i.length == 32 && (e.push(new L(i, s)), i = [], s = -1);
        return s > -1 && e.push(new L(i, s)), e
    }
}
class et extends O {
    constructor(t, e) {
        super(), this.children = t, this.length = e, this.lines = 0;
        for (let i of t) this.lines += i.lines
    }
    lineInner(t, e, i, s) {
        for (let r = 0;; r++) {
            let o = this.children[r],
                l = s + o.length,
                h = i + o.lines - 1;
            if ((e ? h : l) >= t) return o.lineInner(t, e, i, s);
            s = l + 1, i = h + 1
        }
    }
    decompose(t, e, i, s) {
        for (let r = 0, o = 0; o <= e && r < this.children.length; r++) {
            let l = this.children[r],
                h = o + l.length;
            if (t <= h && e >= o) {
                let f = s & ((o <= t ? 1 : 0) | (h >= e ? 2 : 0));
                o >= t && h <= e && !f ? i.push(l) : l.decompose(t - o, e - o, i, f)
            }
            o = h + 1
        }
    }
    replace(t, e, i) {
        if ([t, e] = Vt(this, t, e), i.lines < this.lines)
            for (let s = 0, r = 0; s < this.children.length; s++) {
                let o = this.children[s],
                    l = r + o.length;
                if (t >= r && e <= l) {
                    let h = o.replace(t - r, e - r, i),
                        f = this.lines - o.lines + h.lines;
                    if (h.lines < f >> 4 && h.lines > f >> 6) {
                        let a = this.children.slice();
                        return a[s] = h, new et(a, this.length - (e - t) + i.length)
                    }
                    return super.replace(r, l, h)
                }
                r = l + 1
            }
        return super.replace(t, e, i)
    }
    sliceString(t, e = this.length, i = "\n") {
        [t, e] = Vt(this, t, e);
        let s = "";
        for (let r = 0, o = 0; r < this.children.length && o <= e; r++) {
            let l = this.children[r],
                h = o + l.length;
            o > t && r && (s += i), t < h && e > o && (s += l.sliceString(t - o, e - o, i)), o = h + 1
        }
        return s
    }
    flatten(t) {
        for (let e of this.children) e.flatten(t)
    }
    scanIdentical(t, e) {
        if (!(t instanceof et)) return 0;
        let i = 0,
            [s, r, o, l] = e > 0 ? [0, 0, this.children.length, t.children.length] : [this.children.length - 1, t.children.length - 1, -1, -1];
        for (;; s += e, r += e) {
            if (s == o || r == l) return i;
            let h = this.children[s],
                f = t.children[r];
            if (h != f) return i + h.scanIdentical(f, e);
            i += h.length + 1
        }
    }
    static from(t, e = t.reduce((i, s) => i + s.length + 1, -1)) {
        let i = 0;
        for (let d of t) i += d.lines;
        if (i < 32) {
            let d = [];
            for (let g of t) g.flatten(d);
            return new L(d, e)
        }
        let s = Math.max(32, i >> 5),
            r = s << 1,
            o = s >> 1,
            l = [],
            h = 0,
            f = -1,
            a = [];

        function c(d) {
            let g;
            if (d.lines > r && d instanceof et)
                for (let m of d.children) c(m);
            else d.lines > o && (h > o || !h) ? (u(), l.push(d)) : d instanceof L && h && (g = a[a.length - 1]) instanceof L && d.lines + g.lines <= 32 ? (h += d.lines, f += d.length + 1, a[a.length - 1] = new L(g.text.concat(d.text), g.length + 1 + d.length)) : (h + d.lines > s && u(), h += d.lines, f += d.length + 1, a.push(d))
        }

        function u() {
            h != 0 && (l.push(a.length == 1 ? a[0] : et.from(a, f)), f = -1, h = a.length = 0)
        }
        for (let d of t) c(d);
        return u(), l.length == 1 ? l[0] : new et(l, e)
    }
}
O.empty = new L([""], 0);

function xr(n) {
    let t = -1;
    for (let e of n) t += e.length + 1;
    return t
}

function Te(n, t, e = 0, i = 1e9) {
    for (let s = 0, r = 0, o = !0; r < n.length && s <= i; r++) {
        let l = n[r],
            h = s + l.length;
        h >= e && (h > i && (l = l.slice(0, i - s)), s < e && (l = l.slice(e - s)), o ? (t[t.length - 1] += l, o = !1) : t.push(l)), s = h + 1
    }
    return t
}

function Ui(n, t, e) {
    return Te(n, [""], t, e)
}
class _t {
    constructor(t, e = 1) {
        this.dir = e, this.done = !1, this.lineBreak = !1, this.value = "", this.nodes = [t], this.offsets = [e > 0 ? 1 : (t instanceof L ? t.text.length : t.children.length) << 1]
    }
    nextInner(t, e) {
        for (this.done = this.lineBreak = !1;;) {
            let i = this.nodes.length - 1,
                s = this.nodes[i],
                r = this.offsets[i],
                o = r >> 1,
                l = s instanceof L ? s.text.length : s.children.length;
            if (o == (e > 0 ? l : 0)) {
                if (i == 0) return this.done = !0, this.value = "", this;
                e > 0 && this.offsets[i - 1]++, this.nodes.pop(), this.offsets.pop()
            } else if ((r & 1) == (e > 0 ? 0 : 1)) {
                if (this.offsets[i] += e, t == 0) return this.lineBreak = !0, this.value = "\n", this;
                t--
            } else if (s instanceof L) {
                let h = s.text[o + (e < 0 ? -1 : 0)];
                if (this.offsets[i] += e, h.length > Math.max(0, t)) return this.value = t == 0 ? h : e > 0 ? h.slice(t) : h.slice(0, h.length - t), this;
                t -= h.length
            } else {
                let h = s.children[o + (e < 0 ? -1 : 0)];
                t > h.length ? (t -= h.length, this.offsets[i] += e) : (e < 0 && this.offsets[i]--, this.nodes.push(h), this.offsets.push(e > 0 ? 1 : (h instanceof L ? h.text.length : h.children.length) << 1))
            }
        }
    }
    next(t = 0) {
        return t < 0 && (this.nextInner(-t, -this.dir), t = this.value.length), this.nextInner(t, this.dir)
    }
}
class Xs {
    constructor(t, e, i) {
        this.value = "", this.done = !1, this.cursor = new _t(t, e > i ? -1 : 1), this.pos = e > i ? t.length : 0, this.from = Math.min(e, i), this.to = Math.max(e, i)
    }
    nextInner(t, e) {
        if (e < 0 ? this.pos <= this.from : this.pos >= this.to) return this.value = "", this.done = !0, this;
        t += Math.max(0, e < 0 ? this.pos - this.to : this.from - this.pos);
        let i = e < 0 ? this.pos - this.from : this.to - this.pos;
        t > i && (t = i), i -= t;
        let {
            value: s
        } = this.cursor.next(t);
        return this.pos += (s.length + t) * e, this.value = s.length <= i ? s : e < 0 ? s.slice(s.length - i) : s.slice(0, i), this.done = !this.value, this
    }
    next(t = 0) {
        return t < 0 ? t = Math.max(t, this.from - this.pos) : t > 0 && (t = Math.min(t, this.to - this.pos)), this.nextInner(t, this.cursor.dir)
    }
    get lineBreak() {
        return this.cursor.lineBreak && this.value != ""
    }
}
class Us {
    constructor(t) {
        this.inner = t, this.afterBreak = !0, this.value = "", this.done = !1
    }
    next(t = 0) {
        let {
            done: e,
            lineBreak: i,
            value: s
        } = this.inner.next(t);
        return e && this.afterBreak ? (this.value = "", this.afterBreak = !1) : e ? (this.done = !0, this.value = "") : i ? this.afterBreak ? this.value = "" : (this.afterBreak = !0, this.next()) : (this.value = s, this.afterBreak = !1), this
    }
    get lineBreak() {
        return !1
    }
}
typeof Symbol < "u" && (O.prototype[Symbol.iterator] = function() {
    return this.iter()
}, _t.prototype[Symbol.iterator] = Xs.prototype[Symbol.iterator] = Us.prototype[Symbol.iterator] = function() {
    return this
});
class Sr {
    constructor(t, e, i, s) {
        this.from = t, this.to = e, this.number = i, this.text = s
    }
    get length() {
        return this.to - this.from
    }
}

function Vt(n, t, e) {
    return t = Math.max(0, Math.min(n.length, t)), [t, Math.max(t, Math.min(n.length, e))]
}
let Bt = "lc,34,7n,7,7b,19,,,,2,,2,,,20,b,1c,l,g,,2t,7,2,6,2,2,,4,z,,u,r,2j,b,1m,9,9,,o,4,,9,,3,,5,17,3,3b,f,,w,1j,,,,4,8,4,,3,7,a,2,t,,1m,,,,2,4,8,,9,,a,2,q,,2,2,1l,,4,2,4,2,2,3,3,,u,2,3,,b,2,1l,,4,5,,2,4,,k,2,m,6,,,1m,,,2,,4,8,,7,3,a,2,u,,1n,,,,c,,9,,14,,3,,1l,3,5,3,,4,7,2,b,2,t,,1m,,2,,2,,3,,5,2,7,2,b,2,s,2,1l,2,,,2,4,8,,9,,a,2,t,,20,,4,,2,3,,,8,,29,,2,7,c,8,2q,,2,9,b,6,22,2,r,,,,,,1j,e,,5,,2,5,b,,10,9,,2u,4,,6,,2,2,2,p,2,4,3,g,4,d,,2,2,6,,f,,jj,3,qa,3,t,3,t,2,u,2,1s,2,,7,8,,2,b,9,,19,3,3b,2,y,,3a,3,4,2,9,,6,3,63,2,2,,1m,,,7,,,,,2,8,6,a,2,,1c,h,1r,4,1c,7,,,5,,14,9,c,2,w,4,2,2,,3,1k,,,2,3,,,3,1m,8,2,2,48,3,,d,,7,4,,6,,3,2,5i,1m,,5,ek,,5f,x,2da,3,3x,,2o,w,fe,6,2x,2,n9w,4,,a,w,2,28,2,7k,,3,,4,,p,2,5,,47,2,q,i,d,,12,8,p,b,1a,3,1c,,2,4,2,2,13,,1v,6,2,2,2,2,c,,8,,1b,,1f,,,3,2,2,5,2,,,16,2,8,,6m,,2,,4,,fn4,,kh,g,g,g,a6,2,gt,,6a,,45,5,1ae,3,,2,5,4,14,3,4,,4l,2,fx,4,ar,2,49,b,4w,,1i,f,1k,3,1d,4,2,2,1x,3,10,5,,8,1q,,c,2,1g,9,a,4,2,,2n,3,2,,,2,6,,4g,,3,8,l,2,1l,2,,,,,m,,e,7,3,5,5f,8,2,3,,,n,,29,,2,6,,,2,,,2,,2,6j,,2,4,6,2,,2,r,2,2d,8,2,,,2,2y,,,,2,6,,,2t,3,2,4,,5,77,9,,2,6t,,a,2,,,4,,40,4,2,2,4,,w,a,14,6,2,4,8,,9,6,2,3,1a,d,,2,ba,7,,6,,,2a,m,2,7,,2,,2,3e,6,3,,,2,,7,,,20,2,3,,,,9n,2,f0b,5,1n,7,t4,,1r,4,29,,f5k,2,43q,,,3,4,5,8,8,2,7,u,4,44,3,1iz,1j,4,1e,8,,e,,m,5,,f,11s,7,,h,2,7,,2,,5,79,7,c5,4,15s,7,31,7,240,5,gx7k,2o,3k,6o".split(",").map(n => n ? parseInt(n, 36) : 1);
for (let n = 1; n < Bt.length; n++) Bt[n] += Bt[n - 1];

function vr(n) {
    for (let t = 1; t < Bt.length; t += 2)
        if (Bt[t] > n) return Bt[t - 1] <= n;
    return !1
}

function Ji(n) {
    return n >= 127462 && n <= 127487
}
const Qi = 8205;

function st(n, t, e = !0, i = !0) {
    return (e ? Js : kr)(n, t, i)
}

function Js(n, t, e) {
    if (t == n.length) return t;
    t && Qs(n.charCodeAt(t)) && Zs(n.charCodeAt(t - 1)) && t--;
    let i = te(n, t);
    for (t += si(i); t < n.length;) {
        let s = te(n, t);
        if (i == Qi || s == Qi || e && vr(s)) t += si(s), i = s;
        else if (Ji(s)) {
            let r = 0,
                o = t - 2;
            for (; o >= 0 && Ji(te(n, o));) r++, o -= 2;
            if (r % 2 == 0) break;
            t += 2
        } else break
    }
    return t
}

function kr(n, t, e) {
    for (; t > 0;) {
        let i = Js(n, t - 2, e);
        if (i < t) return i;
        t--
    }
    return 0
}

function Qs(n) {
    return n >= 56320 && n < 57344
}

function Zs(n) {
    return n >= 55296 && n < 56320
}

function te(n, t) {
    let e = n.charCodeAt(t);
    if (!Zs(e) || t + 1 == n.length) return e;
    let i = n.charCodeAt(t + 1);
    return Qs(i) ? (e - 55296 << 10) + (i - 56320) + 65536 : e
}

function Jl(n) {
    return n <= 65535 ? String.fromCharCode(n) : (n -= 65536, String.fromCharCode((n >> 10) + 55296, (n & 1023) + 56320))
}

function si(n) {
    return n < 65536 ? 1 : 2
}
const ni = /\r\n?|\n/;
var U = (function(n) {
    return n[n.Simple = 0] = "Simple", n[n.TrackDel = 1] = "TrackDel", n[n.TrackBefore = 2] = "TrackBefore", n[n.TrackAfter = 3] = "TrackAfter", n
})(U || (U = {}));
class at {
    constructor(t) {
        this.sections = t
    }
    get length() {
        let t = 0;
        for (let e = 0; e < this.sections.length; e += 2) t += this.sections[e];
        return t
    }
    get newLength() {
        let t = 0;
        for (let e = 0; e < this.sections.length; e += 2) {
            let i = this.sections[e + 1];
            t += i < 0 ? this.sections[e] : i
        }
        return t
    }
    get empty() {
        return this.sections.length == 0 || this.sections.length == 2 && this.sections[1] < 0
    }
    iterGaps(t) {
        for (let e = 0, i = 0, s = 0; e < this.sections.length;) {
            let r = this.sections[e++],
                o = this.sections[e++];
            o < 0 ? (t(i, s, r), s += r) : s += o, i += r
        }
    }
    iterChangedRanges(t, e = !1) {
        ri(this, t, e)
    }
    get invertedDesc() {
        let t = [];
        for (let e = 0; e < this.sections.length;) {
            let i = this.sections[e++],
                s = this.sections[e++];
            s < 0 ? t.push(i, s) : t.push(s, i)
        }
        return new at(t)
    }
    composeDesc(t) {
        return this.empty ? t : t.empty ? this : _s(this, t)
    }
    mapDesc(t, e = !1) {
        return t.empty ? this : oi(this, t, e)
    }
    mapPos(t, e = -1, i = U.Simple) {
        let s = 0,
            r = 0;
        for (let o = 0; o < this.sections.length;) {
            let l = this.sections[o++],
                h = this.sections[o++],
                f = s + l;
            if (h < 0) {
                if (f > t) return r + (t - s);
                r += l
            } else {
                if (i != U.Simple && f >= t && (i == U.TrackDel && s < t && f > t || i == U.TrackBefore && s < t || i == U.TrackAfter && f > t)) return null;
                if (f > t || f == t && e < 0 && !l) return t == s || e < 0 ? r : r + h;
                r += h
            }
            s = f
        }
        if (t > s) throw new RangeError("Position ".concat(t, " is out of range for changeset of length ").concat(s));
        return r
    }
    touchesRange(t, e = t) {
        for (let i = 0, s = 0; i < this.sections.length && s <= e;) {
            let r = this.sections[i++],
                o = this.sections[i++],
                l = s + r;
            if (o >= 0 && s <= e && l >= t) return s < t && l > e ? "cover" : !0;
            s = l
        }
        return !1
    }
    toString() {
        let t = "";
        for (let e = 0; e < this.sections.length;) {
            let i = this.sections[e++],
                s = this.sections[e++];
            t += (t ? " " : "") + i + (s >= 0 ? ":" + s : "")
        }
        return t
    }
    toJSON() {
        return this.sections
    }
    static fromJSON(t) {
        if (!Array.isArray(t) || t.length % 2 || t.some(e => typeof e != "number")) throw new RangeError("Invalid JSON representation of ChangeDesc");
        return new at(t)
    }
    static create(t) {
        return new at(t)
    }
}
class H extends at {
    constructor(t, e) {
        super(t), this.inserted = e
    }
    apply(t) {
        if (this.length != t.length) throw new RangeError("Applying change set to a document with the wrong length");
        return ri(this, (e, i, s, r, o) => t = t.replace(s, s + (i - e), o), !1), t
    }
    mapDesc(t, e = !1) {
        return oi(this, t, e, !0)
    }
    invert(t) {
        let e = this.sections.slice(),
            i = [];
        for (let s = 0, r = 0; s < e.length; s += 2) {
            let o = e[s],
                l = e[s + 1];
            if (l >= 0) {
                e[s] = l, e[s + 1] = o;
                let h = s >> 1;
                for (; i.length < h;) i.push(O.empty);
                i.push(o ? t.slice(r, r + o) : O.empty)
            }
            r += o
        }
        return new H(e, i)
    }
    compose(t) {
        return this.empty ? t : t.empty ? this : _s(this, t, !0)
    }
    map(t, e = !1) {
        return t.empty ? this : oi(this, t, e, !0)
    }
    iterChanges(t, e = !1) {
        ri(this, t, e)
    }
    get desc() {
        return at.create(this.sections)
    }
    filter(t) {
        let e = [],
            i = [],
            s = [],
            r = new re(this);
        t: for (let o = 0, l = 0;;) {
            let h = o == t.length ? 1e9 : t[o++];
            for (; l < h || l == h && r.len == 0;) {
                if (r.done) break t;
                let a = Math.min(r.len, h - l);
                q(s, a, -1);
                let c = r.ins == -1 ? -1 : r.off == 0 ? r.ins : 0;
                q(e, a, c), c > 0 && wt(i, e, r.text), r.forward(a), l += a
            }
            let f = t[o++];
            for (; l < f;) {
                if (r.done) break t;
                let a = Math.min(r.len, f - l);
                q(e, a, -1), q(s, a, r.ins == -1 ? -1 : r.off == 0 ? r.ins : 0), r.forward(a), l += a
            }
        }
        return {
            changes: new H(e, i),
            filtered: at.create(s)
        }
    }
    toJSON() {
        let t = [];
        for (let e = 0; e < this.sections.length; e += 2) {
            let i = this.sections[e],
                s = this.sections[e + 1];
            s < 0 ? t.push(i) : s == 0 ? t.push([i]) : t.push([i].concat(this.inserted[e >> 1].toJSON()))
        }
        return t
    }
    static of (t, e, i) {
        let s = [],
            r = [],
            o = 0,
            l = null;

        function h(a = !1) {
            if (!a && !s.length) return;
            o < e && q(s, e - o, -1);
            let c = new H(s, r);
            l = l ? l.compose(c.map(l)) : c, s = [], r = [], o = 0
        }

        function f(a) {
            if (Array.isArray(a))
                for (let c of a) f(c);
            else if (a instanceof H) {
                if (a.length != e) throw new RangeError("Mismatched change set length (got ".concat(a.length, ", expected ").concat(e, ")"));
                h(), l = l ? l.compose(a.map(l)) : a
            } else {
                let {
                    from: c,
                    to: u = c,
                    insert: d
                } = a;
                if (c > u || c < 0 || u > e) throw new RangeError("Invalid change range ".concat(c, " to ").concat(u, " (in doc of length ").concat(e, ")"));
                let g = d ? typeof d == "string" ? O.of(d.split(i || ni)) : d : O.empty,
                    m = g.length;
                if (c == u && m == 0) return;
                c < o && h(), c > o && q(s, c - o, -1), q(s, u - c, m), wt(r, s, g), o = u
            }
        }
        return f(t), h(!l), l
    }
    static empty(t) {
        return new H(t ? [t, -1] : [], [])
    }
    static fromJSON(t) {
        if (!Array.isArray(t)) throw new RangeError("Invalid JSON representation of ChangeSet");
        let e = [],
            i = [];
        for (let s = 0; s < t.length; s++) {
            let r = t[s];
            if (typeof r == "number") e.push(r, -1);
            else {
                if (!Array.isArray(r) || typeof r[0] != "number" || r.some((o, l) => l && typeof o != "string")) throw new RangeError("Invalid JSON representation of ChangeSet");
                if (r.length == 1) e.push(r[0], 0);
                else {
                    for (; i.length < s;) i.push(O.empty);
                    i[s] = O.of(r.slice(1)), e.push(r[0], i[s].length)
                }
            }
        }
        return new H(e, i)
    }
    static createSet(t, e) {
        return new H(t, e)
    }
}

function q(n, t, e, i = !1) {
    if (t == 0 && e <= 0) return;
    let s = n.length - 2;
    s >= 0 && e <= 0 && e == n[s + 1] ? n[s] += t : t == 0 && n[s] == 0 ? n[s + 1] += e : i ? (n[s] += t, n[s + 1] += e) : n.push(t, e)
}

function wt(n, t, e) {
    if (e.length == 0) return;
    let i = t.length - 2 >> 1;
    if (i < n.length) n[n.length - 1] = n[n.length - 1].append(e);
    else {
        for (; n.length < i;) n.push(O.empty);
        n.push(e)
    }
}

function ri(n, t, e) {
    let i = n.inserted;
    for (let s = 0, r = 0, o = 0; o < n.sections.length;) {
        let l = n.sections[o++],
            h = n.sections[o++];
        if (h < 0) s += l, r += l;
        else {
            let f = s,
                a = r,
                c = O.empty;
            for (; f += l, a += h, h && i && (c = c.append(i[o - 2 >> 1])), !(e || o == n.sections.length || n.sections[o + 1] < 0);) l = n.sections[o++], h = n.sections[o++];
            t(s, f, r, a, c), s = f, r = a
        }
    }
}

function oi(n, t, e, i = !1) {
    let s = [],
        r = i ? [] : null,
        o = new re(n),
        l = new re(t);
    for (let h = -1;;)
        if (o.ins == -1 && l.ins == -1) {
            let f = Math.min(o.len, l.len);
            q(s, f, -1), o.forward(f), l.forward(f)
        } else if (l.ins >= 0 && (o.ins < 0 || h == o.i || o.off == 0 && (l.len < o.len || l.len == o.len && !e))) {
        let f = l.len;
        for (q(s, l.ins, -1); f;) {
            let a = Math.min(o.len, f);
            o.ins >= 0 && h < o.i && o.len <= a && (q(s, 0, o.ins), r && wt(r, s, o.text), h = o.i), o.forward(a), f -= a
        }
        l.next()
    } else if (o.ins >= 0) {
        let f = 0,
            a = o.len;
        for (; a;)
            if (l.ins == -1) {
                let c = Math.min(a, l.len);
                f += c, a -= c, l.forward(c)
            } else if (l.ins == 0 && l.len < a) a -= l.len, l.next();
        else break;
        q(s, f, h < o.i ? o.ins : 0), r && h < o.i && wt(r, s, o.text), h = o.i, o.forward(o.len - a)
    } else {
        if (o.done && l.done) return r ? H.createSet(s, r) : at.create(s);
        throw new Error("Mismatched change set lengths")
    }
}

function _s(n, t, e = !1) {
    let i = [],
        s = e ? [] : null,
        r = new re(n),
        o = new re(t);
    for (let l = !1;;) {
        if (r.done && o.done) return s ? H.createSet(i, s) : at.create(i);
        if (r.ins == 0) q(i, r.len, 0, l), r.next();
        else if (o.len == 0 && !o.done) q(i, 0, o.ins, l), s && wt(s, i, o.text), o.next();
        else {
            if (r.done || o.done) throw new Error("Mismatched change set lengths"); {
                let h = Math.min(r.len2, o.len),
                    f = i.length;
                if (r.ins == -1) {
                    let a = o.ins == -1 ? -1 : o.off ? 0 : o.ins;
                    q(i, h, a, l), s && a && wt(s, i, o.text)
                } else o.ins == -1 ? (q(i, r.off ? 0 : r.len, h, l), s && wt(s, i, r.textBit(h))) : (q(i, r.off ? 0 : r.len, o.off ? 0 : o.ins, l), s && !o.off && wt(s, i, o.text));
                l = (r.ins > h || o.ins >= 0 && o.len > h) && (l || i.length > f), r.forward2(h), o.forward(h)
            }
        }
    }
}
class re {
    constructor(t) {
        this.set = t, this.i = 0, this.next()
    }
    next() {
        let {
            sections: t
        } = this.set;
        this.i < t.length ? (this.len = t[this.i++], this.ins = t[this.i++]) : (this.len = 0, this.ins = -2), this.off = 0
    }
    get done() {
        return this.ins == -2
    }
    get len2() {
        return this.ins < 0 ? this.len : this.ins
    }
    get text() {
        let {
            inserted: t
        } = this.set, e = this.i - 2 >> 1;
        return e >= t.length ? O.empty : t[e]
    }
    textBit(t) {
        let {
            inserted: e
        } = this.set, i = this.i - 2 >> 1;
        return i >= e.length && !t ? O.empty : e[i].slice(this.off, t == null ? void 0 : this.off + t)
    }
    forward(t) {
        t == this.len ? this.next() : (this.len -= t, this.off += t)
    }
    forward2(t) {
        this.ins == -1 ? this.forward(t) : t == this.ins ? this.next() : (this.ins -= t, this.off += t)
    }
}
class Ct {
    constructor(t, e, i) {
        this.from = t, this.to = e, this.flags = i
    }
    get anchor() {
        return this.flags & 32 ? this.to : this.from
    }
    get head() {
        return this.flags & 32 ? this.from : this.to
    }
    get empty() {
        return this.from == this.to
    }
    get assoc() {
        return this.flags & 8 ? -1 : this.flags & 16 ? 1 : 0
    }
    get bidiLevel() {
        let t = this.flags & 7;
        return t == 7 ? null : t
    }
    get goalColumn() {
        let t = this.flags >> 6;
        return t == 16777215 ? void 0 : t
    }
    map(t, e = -1) {
        let i, s;
        return this.empty ? i = s = t.mapPos(this.from, e) : (i = t.mapPos(this.from, 1), s = t.mapPos(this.to, -1)), i == this.from && s == this.to ? this : new Ct(i, s, this.flags)
    }
    extend(t, e = t) {
        if (t <= this.anchor && e >= this.anchor) return S.range(t, e);
        let i = Math.abs(t - this.anchor) > Math.abs(e - this.anchor) ? t : e;
        return S.range(this.anchor, i)
    }
    eq(t, e = !1) {
        return this.anchor == t.anchor && this.head == t.head && (!e || !this.empty || this.assoc == t.assoc)
    }
    toJSON() {
        return {
            anchor: this.anchor,
            head: this.head
        }
    }
    static fromJSON(t) {
        if (!t || typeof t.anchor != "number" || typeof t.head != "number") throw new RangeError("Invalid JSON representation for SelectionRange");
        return S.range(t.anchor, t.head)
    }
    static create(t, e, i) {
        return new Ct(t, e, i)
    }
}
class S {
    constructor(t, e) {
        this.ranges = t, this.mainIndex = e
    }
    map(t, e = -1) {
        return t.empty ? this : S.create(this.ranges.map(i => i.map(t, e)), this.mainIndex)
    }
    eq(t, e = !1) {
        if (this.ranges.length != t.ranges.length || this.mainIndex != t.mainIndex) return !1;
        for (let i = 0; i < this.ranges.length; i++)
            if (!this.ranges[i].eq(t.ranges[i], e)) return !1;
        return !0
    }
    get main() {
        return this.ranges[this.mainIndex]
    }
    asSingle() {
        return this.ranges.length == 1 ? this : new S([this.main], 0)
    }
    addRange(t, e = !0) {
        return S.create([t].concat(this.ranges), e ? 0 : this.mainIndex + 1)
    }
    replaceRange(t, e = this.mainIndex) {
        let i = this.ranges.slice();
        return i[e] = t, S.create(i, this.mainIndex)
    }
    toJSON() {
        return {
            ranges: this.ranges.map(t => t.toJSON()),
            main: this.mainIndex
        }
    }
    static fromJSON(t) {
        if (!t || !Array.isArray(t.ranges) || typeof t.main != "number" || t.main >= t.ranges.length) throw new RangeError("Invalid JSON representation for EditorSelection");
        return new S(t.ranges.map(e => Ct.fromJSON(e)), t.main)
    }
    static single(t, e = t) {
        return new S([S.range(t, e)], 0)
    }
    static create(t, e = 0) {
        if (t.length == 0) throw new RangeError("A selection needs at least one range");
        for (let i = 0, s = 0; s < t.length; s++) {
            let r = t[s];
            if (r.empty ? r.from <= i : r.from < i) return S.normalized(t.slice(), e);
            i = r.to
        }
        return new S(t, e)
    }
    static cursor(t, e = 0, i, s) {
        return Ct.create(t, t, (e == 0 ? 0 : e < 0 ? 8 : 16) | (i == null ? 7 : Math.min(6, i)) | (s != null ? s : 16777215) << 6)
    }
    static range(t, e, i, s) {
        let r = (i != null ? i : 16777215) << 6 | (s == null ? 7 : Math.min(6, s));
        return e < t ? Ct.create(e, t, 48 | r) : Ct.create(t, e, (e > t ? 8 : 0) | r)
    }
    static normalized(t, e = 0) {
        let i = t[e];
        t.sort((s, r) => s.from - r.from), e = t.indexOf(i);
        for (let s = 1; s < t.length; s++) {
            let r = t[s],
                o = t[s - 1];
            if (r.empty ? r.from <= o.to : r.from < o.to) {
                let l = o.from,
                    h = Math.max(r.to, o.to);
                s <= e && e--, t.splice(--s, 2, r.anchor > r.head ? S.range(h, l) : S.range(l, h))
            }
        }
        return new S(t, e)
    }
}

function tn(n, t) {
    for (let e of n.ranges)
        if (e.to > t) throw new RangeError("Selection points outside of document")
}
let Ii = 0;
class C {
    constructor(t, e, i, s, r) {
        this.combine = t, this.compareInput = e, this.compare = i, this.isStatic = s, this.id = Ii++, this.default = t([]), this.extensions = typeof r == "function" ? r(this) : r
    }
    get reader() {
        return this
    }
    static define(t = {}) {
        return new C(t.combine || (e => e), t.compareInput || ((e, i) => e === i), t.compare || (t.combine ? (e, i) => e === i : Hi), !!t.static, t.enables)
    } of (t) {
        return new Re([], this, 0, t)
    }
    compute(t, e) {
        if (this.isStatic) throw new Error("Can't compute a static facet");
        return new Re(t, this, 1, e)
    }
    computeN(t, e) {
        if (this.isStatic) throw new Error("Can't compute a static facet");
        return new Re(t, this, 2, e)
    }
    from(t, e) {
        return e || (e = i => i), this.compute([t], i => e(i.field(t)))
    }
}

function Hi(n, t) {
    return n == t || n.length == t.length && n.every((e, i) => e === t[i])
}
class Re {
    constructor(t, e, i, s) {
        this.dependencies = t, this.facet = e, this.type = i, this.value = s, this.id = Ii++
    }
    dynamicSlot(t) {
        var e;
        let i = this.value,
            s = this.facet.compareInput,
            r = this.id,
            o = t[r] >> 1,
            l = this.type == 2,
            h = !1,
            f = !1,
            a = [];
        for (let c of this.dependencies) c == "doc" ? h = !0 : c == "selection" ? f = !0 : (((e = t[c.id]) !== null && e !== void 0 ? e : 1) & 1) == 0 && a.push(t[c.id]);
        return {
            create(c) {
                return c.values[o] = i(c), 1
            },
            update(c, u) {
                if (h && u.docChanged || f && (u.docChanged || u.selection) || li(c, a)) {
                    let d = i(c);
                    if (l ? !Zi(d, c.values[o], s) : !s(d, c.values[o])) return c.values[o] = d, 1
                }
                return 0
            },
            reconfigure: (c, u) => {
                let d, g = u.config.address[r];
                if (g != null) {
                    let m = He(u, g);
                    if (this.dependencies.every(p => p instanceof C ? u.facet(p) === c.facet(p) : p instanceof qt ? u.field(p, !1) == c.field(p, !1) : !0) || (l ? Zi(d = i(c), m, s) : s(d = i(c), m))) return c.values[o] = m, 0
                } else d = i(c);
                return c.values[o] = d, 1
            }
        }
    }
}

function Zi(n, t, e) {
    if (n.length != t.length) return !1;
    for (let i = 0; i < n.length; i++)
        if (!e(n[i], t[i])) return !1;
    return !0
}

function li(n, t) {
    let e = !1;
    for (let i of t) ee(n, i) & 1 && (e = !0);
    return e
}

function Cr(n, t, e) {
    let i = e.map(h => n[h.id]),
        s = e.map(h => h.type),
        r = i.filter(h => !(h & 1)),
        o = n[t.id] >> 1;

    function l(h) {
        let f = [];
        for (let a = 0; a < i.length; a++) {
            let c = He(h, i[a]);
            if (s[a] == 2)
                for (let u of c) f.push(u);
            else f.push(c)
        }
        return t.combine(f)
    }
    return {
        create(h) {
            for (let f of i) ee(h, f);
            return h.values[o] = l(h), 1
        },
        update(h, f) {
            if (!li(h, r)) return 0;
            let a = l(h);
            return t.compare(a, h.values[o]) ? 0 : (h.values[o] = a, 1)
        },
        reconfigure(h, f) {
            let a = li(h, i),
                c = f.config.facets[t.id],
                u = f.facet(t);
            if (c && !a && Hi(e, c)) return h.values[o] = u, 0;
            let d = l(h);
            return t.compare(d, u) ? (h.values[o] = u, 0) : (h.values[o] = d, 1)
        }
    }
}
const _i = C.define({
    static: !0
});
class qt {
    constructor(t, e, i, s, r) {
        this.id = t, this.createF = e, this.updateF = i, this.compareF = s, this.spec = r, this.provides = void 0
    }
    static define(t) {
        let e = new qt(Ii++, t.create, t.update, t.compare || ((i, s) => i === s), t);
        return t.provide && (e.provides = t.provide(e)), e
    }
    create(t) {
        let e = t.facet(_i).find(i => i.field == this);
        return ((e == null ? void 0 : e.create) || this.createF)(t)
    }
    slot(t) {
        let e = t[this.id] >> 1;
        return {
            create: i => (i.values[e] = this.create(i), 1),
            update: (i, s) => {
                let r = i.values[e],
                    o = this.updateF(r, s);
                return this.compareF(r, o) ? 0 : (i.values[e] = o, 1)
            },
            reconfigure: (i, s) => s.config.address[this.id] != null ? (i.values[e] = s.field(this), 0) : (i.values[e] = this.create(i), 1)
        }
    }
    init(t) {
        return [this, _i.of({
            field: this,
            create: t
        })]
    }
    get extension() {
        return this
    }
}
const kt = {
    lowest: 4,
    low: 3,
    default: 2,
    high: 1,
    highest: 0
};

function Gt(n) {
    return t => new en(t, n)
}
const Fi = {
    highest: Gt(kt.highest),
    high: Gt(kt.high),
    default: Gt(kt.default),
    low: Gt(kt.low),
    lowest: Gt(kt.lowest)
};
class en {
    constructor(t, e) {
        this.inner = t, this.prec = e
    }
}
class Ke { of (t) {
        return new hi(this, t)
    }
    reconfigure(t) {
        return Ke.reconfigure.of({
            compartment: this,
            extension: t
        })
    }
    get(t) {
        return t.config.compartments.get(this)
    }
}
class hi {
    constructor(t, e) {
        this.compartment = t, this.inner = e
    }
}
class Ie {
    constructor(t, e, i, s, r, o) {
        for (this.base = t, this.compartments = e, this.dynamicSlots = i, this.address = s, this.staticValues = r, this.facets = o, this.statusTemplate = []; this.statusTemplate.length < i.length;) this.statusTemplate.push(0)
    }
    staticFacet(t) {
        let e = this.address[t.id];
        return e == null ? t.default : this.staticValues[e >> 1]
    }
    static resolve(t, e, i) {
        let s = [],
            r = Object.create(null),
            o = new Map;
        for (let u of Mr(t, e, o)) u instanceof qt ? s.push(u) : (r[u.facet.id] || (r[u.facet.id] = [])).push(u);
        let l = Object.create(null),
            h = [],
            f = [];
        for (let u of s) l[u.id] = f.length << 1, f.push(d => u.slot(d));
        let a = i == null ? void 0 : i.config.facets;
        for (let u in r) {
            let d = r[u],
                g = d[0].facet,
                m = a && a[u] || [];
            if (d.every(p => p.type == 0))
                if (l[g.id] = h.length << 1 | 1, Hi(m, d)) h.push(i.facet(g));
                else {
                    let p = g.combine(d.map(w => w.value));
                    h.push(i && g.compare(p, i.facet(g)) ? i.facet(g) : p)
                }
            else {
                for (let p of d) p.type == 0 ? (l[p.id] = h.length << 1 | 1, h.push(p.value)) : (l[p.id] = f.length << 1, f.push(w => p.dynamicSlot(w)));
                l[g.id] = f.length << 1, f.push(p => Cr(p, g, d))
            }
        }
        let c = f.map(u => u(l));
        return new Ie(t, o, c, l, h, r)
    }
}

function Mr(n, t, e) {
    let i = [
            [],
            [],
            [],
            [],
            []
        ],
        s = new Map;

    function r(o, l) {
        let h = s.get(o);
        if (h != null) {
            if (h <= l) return;
            let f = i[h].indexOf(o);
            f > -1 && i[h].splice(f, 1), o instanceof hi && e.delete(o.compartment)
        }
        if (s.set(o, l), Array.isArray(o))
            for (let f of o) r(f, l);
        else if (o instanceof hi) {
            if (e.has(o.compartment)) throw new RangeError("Duplicate use of compartment in extensions");
            let f = t.get(o.compartment) || o.inner;
            e.set(o.compartment, f), r(f, l)
        } else if (o instanceof en) r(o.inner, o.prec);
        else if (o instanceof qt) i[l].push(o), o.provides && r(o.provides, l);
        else if (o instanceof Re) i[l].push(o), o.facet.extensions && r(o.facet.extensions, kt.default);
        else {
            let f = o.extension;
            if (!f) throw new Error("Unrecognized extension value in extension set (".concat(o, "). This sometimes happens because multiple instances of @codemirror/state are loaded, breaking instanceof checks."));
            r(f, l)
        }
    }
    return r(n, kt.default), i.reduce((o, l) => o.concat(l))
}

function ee(n, t) {
    if (t & 1) return 2;
    let e = t >> 1,
        i = n.status[e];
    if (i == 4) throw new Error("Cyclic dependency between fields and/or facets");
    if (i & 2) return i;
    n.status[e] = 4;
    let s = n.computeSlot(n, n.config.dynamicSlots[e]);
    return n.status[e] = 2 | s
}

function He(n, t) {
    return t & 1 ? n.config.staticValues[t >> 1] : n.values[t >> 1]
}
const sn = C.define(),
    ai = C.define({
        combine: n => n.some(t => t),
        static: !0
    }),
    nn = C.define({
        combine: n => n.length ? n[0] : void 0,
        static: !0
    }),
    rn = C.define(),
    on = C.define(),
    ln = C.define(),
    hn = C.define({
        combine: n => n.length ? n[0] : !1
    });
class Kt {
    constructor(t, e) {
        this.type = t, this.value = e
    }
    static define() {
        return new Ar
    }
}
class Ar { of (t) {
        return new Kt(this, t)
    }
}
class Or {
    constructor(t) {
        this.map = t
    } of (t) {
        return new F(this, t)
    }
}
class F {
    constructor(t, e) {
        this.type = t, this.value = e
    }
    map(t) {
        let e = this.type.map(this.value, t);
        return e === void 0 ? void 0 : e == this.value ? this : new F(this.type, e)
    }
    is(t) {
        return this.type == t
    }
    static define(t = {}) {
        return new Or(t.map || (e => e))
    }
    static mapEffects(t, e) {
        if (!t.length) return t;
        let i = [];
        for (let s of t) {
            let r = s.map(e);
            r && i.push(r)
        }
        return i
    }
}
F.reconfigure = F.define();
F.appendConfig = F.define();
class j {
    constructor(t, e, i, s, r, o) {
        this.startState = t, this.changes = e, this.selection = i, this.effects = s, this.annotations = r, this.scrollIntoView = o, this._doc = null, this._state = null, i && tn(i, e.newLength), r.some(l => l.type == j.time) || (this.annotations = r.concat(j.time.of(Date.now())))
    }
    static create(t, e, i, s, r, o) {
        return new j(t, e, i, s, r, o)
    }
    get newDoc() {
        return this._doc || (this._doc = this.changes.apply(this.startState.doc))
    }
    get newSelection() {
        return this.selection || this.startState.selection.map(this.changes)
    }
    get state() {
        return this._state || this.startState.applyTransaction(this), this._state
    }
    annotation(t) {
        for (let e of this.annotations)
            if (e.type == t) return e.value
    }
    get docChanged() {
        return !this.changes.empty
    }
    get reconfigured() {
        return this.startState.config != this.state.config
    }
    isUserEvent(t) {
        let e = this.annotation(j.userEvent);
        return !!(e && (e == t || e.length > t.length && e.slice(0, t.length) == t && e[t.length] == "."))
    }
}
j.time = Kt.define();
j.userEvent = Kt.define();
j.addToHistory = Kt.define();
j.remote = Kt.define();

function Dr(n, t) {
    let e = [];
    for (let i = 0, s = 0;;) {
        let r, o;
        if (i < n.length && (s == t.length || t[s] >= n[i])) r = n[i++], o = n[i++];
        else if (s < t.length) r = t[s++], o = t[s++];
        else return e;
        !e.length || e[e.length - 1] < r ? e.push(r, o) : e[e.length - 1] < o && (e[e.length - 1] = o)
    }
}

function an(n, t, e) {
    var i;
    let s, r, o;
    return e ? (s = t.changes, r = H.empty(t.changes.length), o = n.changes.compose(t.changes)) : (s = t.changes.map(n.changes), r = n.changes.mapDesc(t.changes, !0), o = n.changes.compose(s)), {
        changes: o,
        selection: t.selection ? t.selection.map(r) : (i = n.selection) === null || i === void 0 ? void 0 : i.map(s),
        effects: F.mapEffects(n.effects, s).concat(F.mapEffects(t.effects, r)),
        annotations: n.annotations.length ? n.annotations.concat(t.annotations) : t.annotations,
        scrollIntoView: n.scrollIntoView || t.scrollIntoView
    }
}

function fi(n, t, e) {
    let i = t.selection,
        s = Pt(t.annotations);
    return t.userEvent && (s = s.concat(j.userEvent.of(t.userEvent))), {
        changes: t.changes instanceof H ? t.changes : H.of(t.changes || [], e, n.facet(nn)),
        selection: i && (i instanceof S ? i : S.single(i.anchor, i.head)),
        effects: Pt(t.effects),
        annotations: s,
        scrollIntoView: !!t.scrollIntoView
    }
}

function fn(n, t, e) {
    let i = fi(n, t.length ? t[0] : {}, n.doc.length);
    t.length && t[0].filter === !1 && (e = !1);
    for (let r = 1; r < t.length; r++) {
        t[r].filter === !1 && (e = !1);
        let o = !!t[r].sequential;
        i = an(i, fi(n, t[r], o ? i.changes.newLength : n.doc.length), o)
    }
    let s = j.create(n, i.changes, i.selection, i.effects, i.annotations, i.scrollIntoView);
    return Rr(e ? Tr(s) : s)
}

function Tr(n) {
    let t = n.startState,
        e = !0;
    for (let s of t.facet(rn)) {
        let r = s(n);
        if (r === !1) {
            e = !1;
            break
        }
        Array.isArray(r) && (e = e === !0 ? r : Dr(e, r))
    }
    if (e !== !0) {
        let s, r;
        if (e === !1) r = n.changes.invertedDesc, s = H.empty(t.doc.length);
        else {
            let o = n.changes.filter(e);
            s = o.changes, r = o.filtered.mapDesc(o.changes).invertedDesc
        }
        n = j.create(t, s, n.selection && n.selection.map(r), F.mapEffects(n.effects, r), n.annotations, n.scrollIntoView)
    }
    let i = t.facet(on);
    for (let s = i.length - 1; s >= 0; s--) {
        let r = i[s](n);
        r instanceof j ? n = r : Array.isArray(r) && r.length == 1 && r[0] instanceof j ? n = r[0] : n = fn(t, Pt(r), !1)
    }
    return n
}

function Rr(n) {
    let t = n.startState,
        e = t.facet(ln),
        i = n;
    for (let s = e.length - 1; s >= 0; s--) {
        let r = e[s](n);
        r && Object.keys(r).length && (i = an(i, fi(t, r, n.changes.newLength), !0))
    }
    return i == n ? n : j.create(t, n.changes, n.selection, i.effects, i.annotations, i.scrollIntoView)
}
const Er = [];

function Pt(n) {
    return n == null ? Er : Array.isArray(n) ? n : [n]
}
var lt = (function(n) {
    return n[n.Word = 0] = "Word", n[n.Space = 1] = "Space", n[n.Other = 2] = "Other", n
})(lt || (lt = {}));
const Br = /[\u00df\u0587\u0590-\u05f4\u0600-\u06ff\u3040-\u309f\u30a0-\u30ff\u3400-\u4db5\u4e00-\u9fcc\uac00-\ud7af]/;
let ci;
try {
    ci = new RegExp("[\\p{Alphabetic}\\p{Number}_]", "u")
} catch (n) {}

function Pr(n) {
    if (ci) return ci.test(n);
    for (let t = 0; t < n.length; t++) {
        let e = n[t];
        if (/\w/.test(e) || e > "" && (e.toUpperCase() != e.toLowerCase() || Br.test(e))) return !0
    }
    return !1
}

function Lr(n) {
    return t => {
        if (!/\S/.test(t)) return lt.Space;
        if (Pr(t)) return lt.Word;
        for (let e = 0; e < n.length; e++)
            if (t.indexOf(n[e]) > -1) return lt.Word;
        return lt.Other
    }
}
class B {
    constructor(t, e, i, s, r, o) {
        this.config = t, this.doc = e, this.selection = i, this.values = s, this.status = t.statusTemplate.slice(), this.computeSlot = r, o && (o._state = this);
        for (let l = 0; l < this.config.dynamicSlots.length; l++) ee(this, l << 1);
        this.computeSlot = null
    }
    field(t, e = !0) {
        let i = this.config.address[t.id];
        if (i == null) {
            if (e) throw new RangeError("Field is not present in this state");
            return
        }
        return ee(this, i), He(this, i)
    }
    update(...t) {
        return fn(this, t, !0)
    }
    applyTransaction(t) {
        let e = this.config,
            {
                base: i,
                compartments: s
            } = e;
        for (let l of t.effects) l.is(Ke.reconfigure) ? (e && (s = new Map, e.compartments.forEach((h, f) => s.set(f, h)), e = null), s.set(l.value.compartment, l.value.extension)) : l.is(F.reconfigure) ? (e = null, i = l.value) : l.is(F.appendConfig) && (e = null, i = Pt(i).concat(l.value));
        let r;
        e ? r = t.startState.values.slice() : (e = Ie.resolve(i, s, this), r = new B(e, this.doc, this.selection, e.dynamicSlots.map(() => null), (h, f) => f.reconfigure(h, this), null).values);
        let o = t.startState.facet(ai) ? t.newSelection : t.newSelection.asSingle();
        new B(e, t.newDoc, o, r, (l, h) => h.update(l, t), t)
    }
    replaceSelection(t) {
        return typeof t == "string" && (t = this.toText(t)), this.changeByRange(e => ({
            changes: {
                from: e.from,
                to: e.to,
                insert: t
            },
            range: S.cursor(e.from + t.length)
        }))
    }
    changeByRange(t) {
        let e = this.selection,
            i = t(e.ranges[0]),
            s = this.changes(i.changes),
            r = [i.range],
            o = Pt(i.effects);
        for (let l = 1; l < e.ranges.length; l++) {
            let h = t(e.ranges[l]),
                f = this.changes(h.changes),
                a = f.map(s);
            for (let u = 0; u < l; u++) r[u] = r[u].map(a);
            let c = s.mapDesc(f, !0);
            r.push(h.range.map(c)), s = s.compose(a), o = F.mapEffects(o, a).concat(F.mapEffects(Pt(h.effects), c))
        }
        return {
            changes: s,
            selection: S.create(r, e.mainIndex),
            effects: o
        }
    }
    changes(t = []) {
        return t instanceof H ? t : H.of(t, this.doc.length, this.facet(B.lineSeparator))
    }
    toText(t) {
        return O.of(t.split(this.facet(B.lineSeparator) || ni))
    }
    sliceDoc(t = 0, e = this.doc.length) {
        return this.doc.sliceString(t, e, this.lineBreak)
    }
    facet(t) {
        let e = this.config.address[t.id];
        return e == null ? t.default : (ee(this, e), He(this, e))
    }
    toJSON(t) {
        let e = {
            doc: this.sliceDoc(),
            selection: this.selection.toJSON()
        };
        if (t)
            for (let i in t) {
                let s = t[i];
                s instanceof qt && this.config.address[s.id] != null && (e[i] = s.spec.toJSON(this.field(t[i]), this))
            }
        return e
    }
    static fromJSON(t, e = {}, i) {
        if (!t || typeof t.doc != "string") throw new RangeError("Invalid JSON representation for EditorState");
        let s = [];
        if (i) {
            for (let r in i)
                if (Object.prototype.hasOwnProperty.call(t, r)) {
                    let o = i[r],
                        l = t[r];
                    s.push(o.init(h => o.spec.fromJSON(l, h)))
                }
        }
        return B.create({
            doc: t.doc,
            selection: S.fromJSON(t.selection),
            extensions: e.extensions ? s.concat([e.extensions]) : s
        })
    }
    static create(t = {}) {
        let e = Ie.resolve(t.extensions || [], new Map),
            i = t.doc instanceof O ? t.doc : O.of((t.doc || "").split(e.staticFacet(B.lineSeparator) || ni)),
            s = t.selection ? t.selection instanceof S ? t.selection : S.single(t.selection.anchor, t.selection.head) : S.single(0);
        return tn(s, i.length), e.staticFacet(ai) || (s = s.asSingle()), new B(e, i, s, e.dynamicSlots.map(() => null), (r, o) => o.create(r), null)
    }
    get tabSize() {
        return this.facet(B.tabSize)
    }
    get lineBreak() {
        return this.facet(B.lineSeparator) || "\n"
    }
    get readOnly() {
        return this.facet(hn)
    }
    phrase(t, ...e) {
        for (let i of this.facet(B.phrases))
            if (Object.prototype.hasOwnProperty.call(i, t)) {
                t = i[t];
                break
            }
        return e.length && (t = t.replace(/\$(\$|\d*)/g, (i, s) => {
            if (s == "$") return "$";
            let r = +(s || 1);
            return !r || r > e.length ? i : e[r - 1]
        })), t
    }
    languageDataAt(t, e, i = -1) {
        let s = [];
        for (let r of this.facet(sn))
            for (let o of r(this, e, i)) Object.prototype.hasOwnProperty.call(o, t) && s.push(o[t]);
        return s
    }
    charCategorizer(t) {
        return Lr(this.languageDataAt("wordChars", t).join(""))
    }
    wordAt(t) {
        let {
            text: e,
            from: i,
            length: s
        } = this.doc.lineAt(t), r = this.charCategorizer(t), o = t - i, l = t - i;
        for (; o > 0;) {
            let h = st(e, o, !1);
            if (r(e.slice(h, o)) != lt.Word) break;
            o = h
        }
        for (; l < s;) {
            let h = st(e, l);
            if (r(e.slice(l, h)) != lt.Word) break;
            l = h
        }
        return o == l ? null : S.range(o + i, l + i)
    }
}
B.allowMultipleSelections = ai;
B.tabSize = C.define({
    combine: n => n.length ? n[0] : 4
});
B.lineSeparator = nn;
B.readOnly = hn;
B.phrases = C.define({
    compare(n, t) {
        let e = Object.keys(n),
            i = Object.keys(t);
        return e.length == i.length && e.every(s => n[s] == t[s])
    }
});
B.languageData = sn;
B.changeFilter = rn;
B.transactionFilter = on;
B.transactionExtender = ln;
Ke.reconfigure = F.define();

function Wi(n, t, e = {}) {
    let i = {};
    for (let s of n)
        for (let r of Object.keys(s)) {
            let o = s[r],
                l = i[r];
            if (l === void 0) i[r] = o;
            else if (!(l === o || o === void 0))
                if (Object.hasOwnProperty.call(e, r)) i[r] = e[r](l, o);
                else throw new Error("Config merge conflict for field " + r)
        }
    for (let s in t) i[s] === void 0 && (i[s] = t[s]);
    return i
}
class It {
    eq(t) {
        return this == t
    }
    range(t, e = t) {
        return oe.create(t, e, this)
    }
}
It.prototype.startSide = It.prototype.endSide = 0;
It.prototype.point = !1;
It.prototype.mapMode = U.TrackDel;
class oe {
    constructor(t, e, i) {
        this.from = t, this.to = e, this.value = i
    }
    static create(t, e, i) {
        return new oe(t, e, i)
    }
}

function ui(n, t) {
    return n.from - t.from || n.value.startSide - t.value.startSide
}
class zi {
    constructor(t, e, i, s) {
        this.from = t, this.to = e, this.value = i, this.maxPoint = s
    }
    get length() {
        return this.to[this.to.length - 1]
    }
    findIndex(t, e, i, s = 0) {
        let r = i ? this.to : this.from;
        for (let o = s, l = r.length;;) {
            if (o == l) return o;
            let h = o + l >> 1,
                f = r[h] - t || (i ? this.value[h].endSide : this.value[h].startSide) - e;
            if (h == o) return f >= 0 ? o : l;
            f >= 0 ? l = h : o = h + 1
        }
    }
    between(t, e, i, s) {
        for (let r = this.findIndex(e, -1e9, !0), o = this.findIndex(i, 1e9, !1, r); r < o; r++)
            if (s(this.from[r] + t, this.to[r] + t, this.value[r]) === !1) return !1
    }
    map(t, e) {
        let i = [],
            s = [],
            r = [],
            o = -1,
            l = -1;
        for (let h = 0; h < this.value.length; h++) {
            let f = this.value[h],
                a = this.from[h] + t,
                c = this.to[h] + t,
                u, d;
            if (a == c) {
                let g = e.mapPos(a, f.startSide, f.mapMode);
                if (g == null || (u = d = g, f.startSide != f.endSide && (d = e.mapPos(a, f.endSide), d < u))) continue
            } else if (u = e.mapPos(a, f.startSide), d = e.mapPos(c, f.endSide), u > d || u == d && f.startSide > 0 && f.endSide <= 0) continue;
            (d - u || f.endSide - f.startSide) < 0 || (o < 0 && (o = u), f.point && (l = Math.max(l, d - u)), i.push(f), s.push(u - o), r.push(d - o))
        }
        return {
            mapped: i.length ? new zi(s, r, i, l) : null,
            pos: o
        }
    }
}
class A {
    constructor(t, e, i, s) {
        this.chunkPos = t, this.chunk = e, this.nextLayer = i, this.maxPoint = s
    }
    static create(t, e, i, s) {
        return new A(t, e, i, s)
    }
    get length() {
        let t = this.chunk.length - 1;
        return t < 0 ? 0 : Math.max(this.chunkEnd(t), this.nextLayer.length)
    }
    get size() {
        if (this.isEmpty) return 0;
        let t = this.nextLayer.size;
        for (let e of this.chunk) t += e.value.length;
        return t
    }
    chunkEnd(t) {
        return this.chunkPos[t] + this.chunk[t].length
    }
    update(t) {
        let {
            add: e = [],
            sort: i = !1,
            filterFrom: s = 0,
            filterTo: r = this.length
        } = t, o = t.filter;
        if (e.length == 0 && !o) return this;
        if (i && (e = e.slice().sort(ui)), this.isEmpty) return e.length ? A.of(e) : this;
        let l = new cn(this, null, -1).goto(0),
            h = 0,
            f = [],
            a = new le;
        for (; l.value || h < e.length;)
            if (h < e.length && (l.from - e[h].from || l.startSide - e[h].value.startSide) >= 0) {
                let c = e[h++];
                a.addInner(c.from, c.to, c.value) || f.push(c)
            } else l.rangeIndex == 1 && l.chunkIndex < this.chunk.length && (h == e.length || this.chunkEnd(l.chunkIndex) < e[h].from) && (!o || s > this.chunkEnd(l.chunkIndex) || r < this.chunkPos[l.chunkIndex]) && a.addChunk(this.chunkPos[l.chunkIndex], this.chunk[l.chunkIndex]) ? l.nextChunk() : ((!o || s > l.to || r < l.from || o(l.from, l.to, l.value)) && (a.addInner(l.from, l.to, l.value) || f.push(oe.create(l.from, l.to, l.value))), l.next());
        return a.finishInner(this.nextLayer.isEmpty && !f.length ? A.empty : this.nextLayer.update({
            add: f,
            filter: o,
            filterFrom: s,
            filterTo: r
        }))
    }
    map(t) {
        if (t.empty || this.isEmpty) return this;
        let e = [],
            i = [],
            s = -1;
        for (let o = 0; o < this.chunk.length; o++) {
            let l = this.chunkPos[o],
                h = this.chunk[o],
                f = t.touchesRange(l, l + h.length);
            if (f === !1) s = Math.max(s, h.maxPoint), e.push(h), i.push(t.mapPos(l));
            else if (f === !0) {
                let {
                    mapped: a,
                    pos: c
                } = h.map(l, t);
                a && (s = Math.max(s, a.maxPoint), e.push(a), i.push(c))
            }
        }
        let r = this.nextLayer.map(t);
        return e.length == 0 ? r : new A(i, e, r || A.empty, s)
    }
    between(t, e, i) {
        if (!this.isEmpty) {
            for (let s = 0; s < this.chunk.length; s++) {
                let r = this.chunkPos[s],
                    o = this.chunk[s];
                if (e >= r && t <= r + o.length && o.between(r, t - r, e - r, i) === !1) return
            }
            this.nextLayer.between(t, e, i)
        }
    }
    iter(t = 0) {
        return he.from([this]).goto(t)
    }
    get isEmpty() {
        return this.nextLayer == this
    }
    static iter(t, e = 0) {
        return he.from(t).goto(e)
    }
    static compare(t, e, i, s, r = -1) {
        let o = t.filter(c => c.maxPoint > 0 || !c.isEmpty && c.maxPoint >= r),
            l = e.filter(c => c.maxPoint > 0 || !c.isEmpty && c.maxPoint >= r),
            h = ts(o, l, i),
            f = new Yt(o, h, r),
            a = new Yt(l, h, r);
        i.iterGaps((c, u, d) => es(f, c, a, u, d, s)), i.empty && i.length == 0 && es(f, 0, a, 0, 0, s)
    }
    static eq(t, e, i = 0, s) {
        s == null && (s = 999999999);
        let r = t.filter(a => !a.isEmpty && e.indexOf(a) < 0),
            o = e.filter(a => !a.isEmpty && t.indexOf(a) < 0);
        if (r.length != o.length) return !1;
        if (!r.length) return !0;
        let l = ts(r, o),
            h = new Yt(r, l, 0).goto(i),
            f = new Yt(o, l, 0).goto(i);
        for (;;) {
            if (h.to != f.to || !di(h.active, f.active) || h.point && (!f.point || !h.point.eq(f.point))) return !1;
            if (h.to > s) return !0;
            h.next(), f.next()
        }
    }
    static spans(t, e, i, s, r = -1) {
        let o = new Yt(t, null, r).goto(e),
            l = e,
            h = o.openStart;
        for (;;) {
            let f = Math.min(o.to, i);
            if (o.point) {
                let a = o.activeForPoint(o.to),
                    c = o.pointFrom < e ? a.length + 1 : o.point.startSide < 0 ? a.length : Math.min(a.length, h);
                s.point(l, f, o.point, a, c, o.pointRank), h = Math.min(o.openEnd(f), a.length)
            } else f > l && (s.span(l, f, o.active, h), h = o.openEnd(f));
            if (o.to > i) return h + (o.point && o.to > i ? 1 : 0);
            l = o.to, o.next()
        }
    }
    static of (t, e = !1) {
        let i = new le;
        for (let s of t instanceof oe ? [t] : e ? Nr(t) : t) i.add(s.from, s.to, s.value);
        return i.finish()
    }
    static join(t) {
        if (!t.length) return A.empty;
        let e = t[t.length - 1];
        for (let i = t.length - 2; i >= 0; i--)
            for (let s = t[i]; s != A.empty; s = s.nextLayer) e = new A(s.chunkPos, s.chunk, e, Math.max(s.maxPoint, e.maxPoint));
        return e
    }
}
A.empty = new A([], [], null, -1);

function Nr(n) {
    if (n.length > 1)
        for (let t = n[0], e = 1; e < n.length; e++) {
            let i = n[e];
            if (ui(t, i) > 0) return n.slice().sort(ui);
            t = i
        }
    return n
}
A.empty.nextLayer = A.empty;
class le {
    finishChunk(t) {
        this.chunks.push(new zi(this.from, this.to, this.value, this.maxPoint)), this.chunkPos.push(this.chunkStart), this.chunkStart = -1, this.setMaxPoint = Math.max(this.setMaxPoint, this.maxPoint), this.maxPoint = -1, t && (this.from = [], this.to = [], this.value = [])
    }
    constructor() {
        this.chunks = [], this.chunkPos = [], this.chunkStart = -1, this.last = null, this.lastFrom = -1e9, this.lastTo = -1e9, this.from = [], this.to = [], this.value = [], this.maxPoint = -1, this.setMaxPoint = -1, this.nextLayer = null
    }
    add(t, e, i) {
        this.addInner(t, e, i) || (this.nextLayer || (this.nextLayer = new le)).add(t, e, i)
    }
    addInner(t, e, i) {
        let s = t - this.lastTo || i.startSide - this.last.endSide;
        if (s <= 0 && (t - this.lastFrom || i.startSide - this.last.startSide) < 0) throw new Error("Ranges must be added sorted by `from` position and `startSide`");
        return s < 0 ? !1 : (this.from.length == 250 && this.finishChunk(!0), this.chunkStart < 0 && (this.chunkStart = t), this.from.push(t - this.chunkStart), this.to.push(e - this.chunkStart), this.last = i, this.lastFrom = t, this.lastTo = e, this.value.push(i), i.point && (this.maxPoint = Math.max(this.maxPoint, e - t)), !0)
    }
    addChunk(t, e) {
        if ((t - this.lastTo || e.value[0].startSide - this.last.endSide) < 0) return !1;
        this.from.length && this.finishChunk(!0), this.setMaxPoint = Math.max(this.setMaxPoint, e.maxPoint), this.chunks.push(e), this.chunkPos.push(t);
        let i = e.value.length - 1;
        return this.last = e.value[i], this.lastFrom = e.from[i] + t, this.lastTo = e.to[i] + t, !0
    }
    finish() {
        return this.finishInner(A.empty)
    }
    finishInner(t) {
        if (this.from.length && this.finishChunk(!1), this.chunks.length == 0) return t;
        let e = A.create(this.chunkPos, this.chunks, this.nextLayer ? this.nextLayer.finishInner(t) : t, this.setMaxPoint);
        return this.from = null, e
    }
}

function ts(n, t, e) {
    let i = new Map;
    for (let r of n)
        for (let o = 0; o < r.chunk.length; o++) r.chunk[o].maxPoint <= 0 && i.set(r.chunk[o], r.chunkPos[o]);
    let s = new Set;
    for (let r of t)
        for (let o = 0; o < r.chunk.length; o++) {
            let l = i.get(r.chunk[o]);
            l != null && (e ? e.mapPos(l) : l) == r.chunkPos[o] && !(e != null && e.touchesRange(l, l + r.chunk[o].length)) && s.add(r.chunk[o])
        }
    return s
}
class cn {
    constructor(t, e, i, s = 0) {
        this.layer = t, this.skip = e, this.minPoint = i, this.rank = s
    }
    get startSide() {
        return this.value ? this.value.startSide : 0
    }
    get endSide() {
        return this.value ? this.value.endSide : 0
    }
    goto(t, e = -1e9) {
        return this.chunkIndex = this.rangeIndex = 0, this.gotoInner(t, e, !1), this
    }
    gotoInner(t, e, i) {
        for (; this.chunkIndex < this.layer.chunk.length;) {
            let s = this.layer.chunk[this.chunkIndex];
            if (!(this.skip && this.skip.has(s) || this.layer.chunkEnd(this.chunkIndex) < t || s.maxPoint < this.minPoint)) break;
            this.chunkIndex++, i = !1
        }
        if (this.chunkIndex < this.layer.chunk.length) {
            let s = this.layer.chunk[this.chunkIndex].findIndex(t - this.layer.chunkPos[this.chunkIndex], e, !0);
            (!i || this.rangeIndex < s) && this.setRangeIndex(s)
        }
        this.next()
    }
    forward(t, e) {
        (this.to - t || this.endSide - e) < 0 && this.gotoInner(t, e, !0)
    }
    next() {
        for (;;)
            if (this.chunkIndex == this.layer.chunk.length) {
                this.from = this.to = 1e9, this.value = null;
                break
            } else {
                let t = this.layer.chunkPos[this.chunkIndex],
                    e = this.layer.chunk[this.chunkIndex],
                    i = t + e.from[this.rangeIndex];
                if (this.from = i, this.to = t + e.to[this.rangeIndex], this.value = e.value[this.rangeIndex], this.setRangeIndex(this.rangeIndex + 1), this.minPoint < 0 || this.value.point && this.to - this.from >= this.minPoint) break
            }
    }
    setRangeIndex(t) {
        if (t == this.layer.chunk[this.chunkIndex].value.length) {
            if (this.chunkIndex++, this.skip)
                for (; this.chunkIndex < this.layer.chunk.length && this.skip.has(this.layer.chunk[this.chunkIndex]);) this.chunkIndex++;
            this.rangeIndex = 0
        } else this.rangeIndex = t
    }
    nextChunk() {
        this.chunkIndex++, this.rangeIndex = 0, this.next()
    }
    compare(t) {
        return this.from - t.from || this.startSide - t.startSide || this.rank - t.rank || this.to - t.to || this.endSide - t.endSide
    }
}
class he {
    constructor(t) {
        this.heap = t
    }
    static from(t, e = null, i = -1) {
        let s = [];
        for (let r = 0; r < t.length; r++)
            for (let o = t[r]; !o.isEmpty; o = o.nextLayer) o.maxPoint >= i && s.push(new cn(o, e, i, r));
        return s.length == 1 ? s[0] : new he(s)
    }
    get startSide() {
        return this.value ? this.value.startSide : 0
    }
    goto(t, e = -1e9) {
        for (let i of this.heap) i.goto(t, e);
        for (let i = this.heap.length >> 1; i >= 0; i--) Ge(this.heap, i);
        return this.next(), this
    }
    forward(t, e) {
        for (let i of this.heap) i.forward(t, e);
        for (let i = this.heap.length >> 1; i >= 0; i--) Ge(this.heap, i);
        (this.to - t || this.value.endSide - e) < 0 && this.next()
    }
    next() {
        if (this.heap.length == 0) this.from = this.to = 1e9, this.value = null, this.rank = -1;
        else {
            let t = this.heap[0];
            this.from = t.from, this.to = t.to, this.value = t.value, this.rank = t.rank, t.value && t.next(), Ge(this.heap, 0)
        }
    }
}

function Ge(n, t) {
    for (let e = n[t];;) {
        let i = (t << 1) + 1;
        if (i >= n.length) break;
        let s = n[i];
        if (i + 1 < n.length && s.compare(n[i + 1]) >= 0 && (s = n[i + 1], i++), e.compare(s) < 0) break;
        n[i] = e, n[t] = s, t = i
    }
}
class Yt {
    constructor(t, e, i) {
        this.minPoint = i, this.active = [], this.activeTo = [], this.activeRank = [], this.minActive = -1, this.point = null, this.pointFrom = 0, this.pointRank = 0, this.to = -1e9, this.endSide = 0, this.openStart = -1, this.cursor = he.from(t, e, i)
    }
    goto(t, e = -1e9) {
        return this.cursor.goto(t, e), this.active.length = this.activeTo.length = this.activeRank.length = 0, this.minActive = -1, this.to = t, this.endSide = e, this.openStart = -1, this.next(), this
    }
    forward(t, e) {
        for (; this.minActive > -1 && (this.activeTo[this.minActive] - t || this.active[this.minActive].endSide - e) < 0;) this.removeActive(this.minActive);
        this.cursor.forward(t, e)
    }
    removeActive(t) {
        be(this.active, t), be(this.activeTo, t), be(this.activeRank, t), this.minActive = is(this.active, this.activeTo)
    }
    addActive(t) {
        let e = 0,
            {
                value: i,
                to: s,
                rank: r
            } = this.cursor;
        for (; e < this.activeRank.length && (r - this.activeRank[e] || s - this.activeTo[e]) > 0;) e++;
        ye(this.active, e, i), ye(this.activeTo, e, s), ye(this.activeRank, e, r), t && ye(t, e, this.cursor.from), this.minActive = is(this.active, this.activeTo)
    }
    next() {
        let t = this.to,
            e = this.point;
        this.point = null;
        let i = this.openStart < 0 ? [] : null;
        for (;;) {
            let s = this.minActive;
            if (s > -1 && (this.activeTo[s] - this.cursor.from || this.active[s].endSide - this.cursor.startSide) < 0) {
                if (this.activeTo[s] > t) {
                    this.to = this.activeTo[s], this.endSide = this.active[s].endSide;
                    break
                }
                this.removeActive(s), i && be(i, s)
            } else if (this.cursor.value)
                if (this.cursor.from > t) {
                    this.to = this.cursor.from, this.endSide = this.cursor.startSide;
                    break
                } else {
                    let r = this.cursor.value;
                    if (!r.point) this.addActive(i), this.cursor.next();
                    else if (e && this.cursor.to == this.to && this.cursor.from < this.cursor.to) this.cursor.next();
                    else {
                        this.point = r, this.pointFrom = this.cursor.from, this.pointRank = this.cursor.rank, this.to = this.cursor.to, this.endSide = r.endSide, this.cursor.next(), this.forward(this.to, this.endSide);
                        break
                    }
                }
            else {
                this.to = this.endSide = 1e9;
                break
            }
        }
        if (i) {
            this.openStart = 0;
            for (let s = i.length - 1; s >= 0 && i[s] < t; s--) this.openStart++
        }
    }
    activeForPoint(t) {
        if (!this.active.length) return this.active;
        let e = [];
        for (let i = this.active.length - 1; i >= 0 && !(this.activeRank[i] < this.pointRank); i--)(this.activeTo[i] > t || this.activeTo[i] == t && this.active[i].endSide >= this.point.endSide) && e.push(this.active[i]);
        return e.reverse()
    }
    openEnd(t) {
        let e = 0;
        for (let i = this.activeTo.length - 1; i >= 0 && this.activeTo[i] > t; i--) e++;
        return e
    }
}

function es(n, t, e, i, s, r) {
    n.goto(t), e.goto(i);
    let o = i + s,
        l = i,
        h = i - t;
    for (;;) {
        let f = n.to + h - e.to || n.endSide - e.endSide,
            a = f < 0 ? n.to + h : e.to,
            c = Math.min(a, o);
        if (n.point || e.point ? n.point && e.point && (n.point == e.point || n.point.eq(e.point)) && di(n.activeForPoint(n.to), e.activeForPoint(e.to)) || r.comparePoint(l, c, n.point, e.point) : c > l && !di(n.active, e.active) && r.compareRange(l, c, n.active, e.active), a > o) break;
        l = a, f <= 0 && n.next(), f >= 0 && e.next()
    }
}

function di(n, t) {
    if (n.length != t.length) return !1;
    for (let e = 0; e < n.length; e++)
        if (n[e] != t[e] && !n[e].eq(t[e])) return !1;
    return !0
}

function be(n, t) {
    for (let e = t, i = n.length - 1; e < i; e++) n[e] = n[e + 1];
    n.pop()
}

function ye(n, t, e) {
    for (let i = n.length - 1; i >= t; i--) n[i + 1] = n[i];
    n[t] = e
}

function is(n, t) {
    let e = -1,
        i = 1e9;
    for (let s = 0; s < t.length; s++)(t[s] - i || n[s].endSide - n[e].endSide) < 0 && (e = s, i = t[s]);
    return e
}

function Vr(n, t, e = n.length) {
    let i = 0;
    for (let s = 0; s < e;) n.charCodeAt(s) == 9 ? (i += t - i % t, s++) : (i++, s = st(n, s));
    return i
}

function Ir(n, t, e, i) {
    for (let s = 0, r = 0;;) {
        if (r >= t) return s;
        if (s == n.length) break;
        r += n.charCodeAt(s) == 9 ? e - r % e : 1, s = st(n, s)
    }
    return n.length
}
const gi = "ͼ",
    ss = typeof Symbol > "u" ? "__" + gi : Symbol.for(gi),
    pi = typeof Symbol > "u" ? "__styleSet" + Math.floor(Math.random() * 1e8) : Symbol("styleSet"),
    ns = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : {};
class Ht {
    constructor(t, e) {
        this.rules = [];
        let {
            finish: i
        } = e || {};

        function s(o) {
            return /^@/.test(o) ? [o] : o.split(/,\s*/)
        }

        function r(o, l, h, f) {
            let a = [],
                c = /^@(\w+)\b/.exec(o[0]),
                u = c && c[1] == "keyframes";
            if (c && l == null) return h.push(o[0] + ";");
            for (let d in l) {
                let g = l[d];
                if (/&/.test(d)) r(d.split(/,\s*/).map(m => o.map(p => m.replace(/&/, p))).reduce((m, p) => m.concat(p)), g, h);
                else if (g && typeof g == "object") {
                    if (!c) throw new RangeError("The value of a property (" + d + ") should be a primitive value.");
                    r(s(d), g, a, u)
                } else g != null && a.push(d.replace(/_.*/, "").replace(/[A-Z]/g, m => "-" + m.toLowerCase()) + ": " + g + ";")
            }(a.length || u) && h.push((i && !c && !f ? o.map(i) : o).join(", ") + " {" + a.join(" ") + "}")
        }
        for (let o in t) r(s(o), t[o], this.rules)
    }
    getRules() {
        return this.rules.join("\n")
    }
    static newName() {
        let t = ns[ss] || 1;
        return ns[ss] = t + 1, gi + t.toString(36)
    }
    static mount(t, e, i) {
        let s = t[pi],
            r = i && i.nonce;
        s ? r && s.setNonce(r) : s = new Hr(t, r), s.mount(Array.isArray(e) ? e : [e], t)
    }
}
let rs = new Map;
class Hr {
    constructor(t, e) {
        let i = t.ownerDocument || t,
            s = i.defaultView;
        if (!t.head && t.adoptedStyleSheets && s.CSSStyleSheet) {
            let r = rs.get(i);
            if (r) return t[pi] = r;
            this.sheet = new s.CSSStyleSheet, rs.set(i, this)
        } else this.styleTag = i.createElement("style"), e && this.styleTag.setAttribute("nonce", e);
        this.modules = [], t[pi] = this
    }
    mount(t, e) {
        let i = this.sheet,
            s = 0,
            r = 0;
        for (let o = 0; o < t.length; o++) {
            let l = t[o],
                h = this.modules.indexOf(l);
            if (h < r && h > -1 && (this.modules.splice(h, 1), r--, h = -1), h == -1) {
                if (this.modules.splice(r++, 0, l), i)
                    for (let f = 0; f < l.rules.length; f++) i.insertRule(l.rules[f], s++)
            } else {
                for (; r < h;) s += this.modules[r++].rules.length;
                s += l.rules.length, r++
            }
        }
        if (i) e.adoptedStyleSheets.indexOf(this.sheet) < 0 && (e.adoptedStyleSheets = [this.sheet, ...e.adoptedStyleSheets]);
        else {
            let o = "";
            for (let h = 0; h < this.modules.length; h++) o += this.modules[h].getRules() + "\n";
            this.styleTag.textContent = o;
            let l = e.head || e;
            this.styleTag.parentNode != l && l.insertBefore(this.styleTag, l.firstChild)
        }
    }
    setNonce(t) {
        this.styleTag && this.styleTag.getAttribute("nonce") != t && this.styleTag.setAttribute("nonce", t)
    }
}

function ae(n) {
    let t;
    return n.nodeType == 11 ? t = n.getSelection ? n : n.ownerDocument : t = n, t.getSelection()
}

function mi(n, t) {
    return t ? n == t || n.contains(t.nodeType != 1 ? t.parentNode : t) : !1
}

function Fr(n) {
    let t = n.activeElement;
    for (; t && t.shadowRoot;) t = t.shadowRoot.activeElement;
    return t
}

function Ee(n, t) {
    if (!t.anchorNode) return !1;
    try {
        return mi(n, t.anchorNode)
    } catch (e) {
        return !1
    }
}

function Ft(n) {
    return n.nodeType == 3 ? Ot(n, 0, n.nodeValue.length).getClientRects() : n.nodeType == 1 ? n.getClientRects() : []
}

function ie(n, t, e, i) {
    return e ? os(n, t, e, i, -1) || os(n, t, e, i, 1) : !1
}

function At(n) {
    for (var t = 0;; t++)
        if (n = n.previousSibling, !n) return t
}

function Fe(n) {
    return n.nodeType == 1 && /^(DIV|P|LI|UL|OL|BLOCKQUOTE|DD|DT|H\d|SECTION|PRE)$/.test(n.nodeName)
}

function os(n, t, e, i, s) {
    for (;;) {
        if (n == e && t == i) return !0;
        if (t == (s < 0 ? 0 : ct(n))) {
            if (n.nodeName == "DIV") return !1;
            let r = n.parentNode;
            if (!r || r.nodeType != 1) return !1;
            t = At(n) + (s < 0 ? 0 : 1), n = r
        } else if (n.nodeType == 1) {
            if (n = n.childNodes[t + (s < 0 ? -1 : 0)], n.nodeType == 1 && n.contentEditable == "false") return !1;
            t = s < 0 ? ct(n) : 0
        } else return !1
    }
}

function ct(n) {
    return n.nodeType == 3 ? n.nodeValue.length : n.childNodes.length
}

function je(n, t) {
    let e = t ? n.left : n.right;
    return {
        left: e,
        right: e,
        top: n.top,
        bottom: n.bottom
    }
}

function Wr(n) {
    let t = n.visualViewport;
    return t ? {
        left: 0,
        right: t.width,
        top: 0,
        bottom: t.height
    } : {
        left: 0,
        right: n.innerWidth,
        top: 0,
        bottom: n.innerHeight
    }
}

function un(n, t) {
    let e = t.width / n.offsetWidth,
        i = t.height / n.offsetHeight;
    return (e > .995 && e < 1.005 || !isFinite(e) || Math.abs(t.width - n.offsetWidth) < 1) && (e = 1), (i > .995 && i < 1.005 || !isFinite(i) || Math.abs(t.height - n.offsetHeight) < 1) && (i = 1), {
        scaleX: e,
        scaleY: i
    }
}

function zr(n, t, e, i, s, r, o, l) {
    let h = n.ownerDocument,
        f = h.defaultView || window;
    for (let a = n, c = !1; a && !c;)
        if (a.nodeType == 1) {
            let u, d = a == h.body,
                g = 1,
                m = 1;
            if (d) u = Wr(f);
            else {
                if (/^(fixed|sticky)$/.test(getComputedStyle(a).position) && (c = !0), a.scrollHeight <= a.clientHeight && a.scrollWidth <= a.clientWidth) {
                    a = a.assignedSlot || a.parentNode;
                    continue
                }
                let y = a.getBoundingClientRect();
                ({
                    scaleX: g,
                    scaleY: m
                } = un(a, y)), u = {
                    left: y.left,
                    right: y.left + a.clientWidth * g,
                    top: y.top,
                    bottom: y.top + a.clientHeight * m
                }
            }
            let p = 0,
                w = 0;
            if (s == "nearest") t.top < u.top ? (w = -(u.top - t.top + o), e > 0 && t.bottom > u.bottom + w && (w = t.bottom - u.bottom + w + o)) : t.bottom > u.bottom && (w = t.bottom - u.bottom + o, e < 0 && t.top - w < u.top && (w = -(u.top + w - t.top + o)));
            else {
                let y = t.bottom - t.top,
                    v = u.bottom - u.top;
                w = (s == "center" && y <= v ? t.top + y / 2 - v / 2 : s == "start" || s == "center" && e < 0 ? t.top - o : t.bottom - v + o) - u.top
            }
            if (i == "nearest" ? t.left < u.left ? (p = -(u.left - t.left + r), e > 0 && t.right > u.right + p && (p = t.right - u.right + p + r)) : t.right > u.right && (p = t.right - u.right + r, e < 0 && t.left < u.left + p && (p = -(u.left + p - t.left + r))) : p = (i == "center" ? t.left + (t.right - t.left) / 2 - (u.right - u.left) / 2 : i == "start" == l ? t.left - r : t.right - (u.right - u.left) + r) - u.left, p || w)
                if (d) f.scrollBy(p, w);
                else {
                    let y = 0,
                        v = 0;
                    if (w) {
                        let x = a.scrollTop;
                        a.scrollTop += w / m, v = (a.scrollTop - x) * m
                    }
                    if (p) {
                        let x = a.scrollLeft;
                        a.scrollLeft += p / g, y = (a.scrollLeft - x) * g
                    }
                    t = {
                        left: t.left - y,
                        top: t.top - v,
                        right: t.right - y,
                        bottom: t.bottom - v
                    }, y && Math.abs(y - p) < 1 && (i = "nearest"), v && Math.abs(v - w) < 1 && (s = "nearest")
                }
            if (d) break;
            a = a.assignedSlot || a.parentNode
        } else if (a.nodeType == 11) a = a.host;
    else break
}

function qr(n) {
    let t = n.ownerDocument,
        e, i;
    for (let s = n.parentNode; s && !(s == t.body || e && i);)
        if (s.nodeType == 1) !i && s.scrollHeight > s.clientHeight && (i = s), !e && s.scrollWidth > s.clientWidth && (e = s), s = s.assignedSlot || s.parentNode;
        else if (s.nodeType == 11) s = s.host;
    else break;
    return {
        x: e,
        y: i
    }
}
class Kr {
    constructor() {
        this.anchorNode = null, this.anchorOffset = 0, this.focusNode = null, this.focusOffset = 0
    }
    eq(t) {
        return this.anchorNode == t.anchorNode && this.anchorOffset == t.anchorOffset && this.focusNode == t.focusNode && this.focusOffset == t.focusOffset
    }
    setRange(t) {
        let {
            anchorNode: e,
            focusNode: i
        } = t;
        this.set(e, Math.min(t.anchorOffset, e ? ct(e) : 0), i, Math.min(t.focusOffset, i ? ct(i) : 0))
    }
    set(t, e, i, s) {
        this.anchorNode = t, this.anchorOffset = e, this.focusNode = i, this.focusOffset = s
    }
}
let Rt = null;

function dn(n) {
    if (n.setActive) return n.setActive();
    if (Rt) return n.focus(Rt);
    let t = [];
    for (let e = n; e && (t.push(e, e.scrollTop, e.scrollLeft), e != e.ownerDocument); e = e.parentNode);
    if (n.focus(Rt == null ? {
            get preventScroll() {
                return Rt = {
                    preventScroll: !0
                }, !0
            }
        } : void 0), !Rt) {
        Rt = !1;
        for (let e = 0; e < t.length;) {
            let i = t[e++],
                s = t[e++],
                r = t[e++];
            i.scrollTop != s && (i.scrollTop = s), i.scrollLeft != r && (i.scrollLeft = r)
        }
    }
}
let ls;

function Ot(n, t, e = t) {
    let i = ls || (ls = document.createRange());
    return i.setEnd(n, e), i.setStart(n, t), i
}

function Lt(n, t, e, i) {
    let s = {
        key: t,
        code: t,
        keyCode: e,
        which: e,
        cancelable: !0
    };
    i && ({
        altKey: s.altKey,
        ctrlKey: s.ctrlKey,
        shiftKey: s.shiftKey,
        metaKey: s.metaKey
    } = i);
    let r = new KeyboardEvent("keydown", s);
    r.synthetic = !0, n.dispatchEvent(r);
    let o = new KeyboardEvent("keyup", s);
    return o.synthetic = !0, n.dispatchEvent(o), r.defaultPrevented || o.defaultPrevented
}

function jr(n) {
    for (; n;) {
        if (n && (n.nodeType == 9 || n.nodeType == 11 && n.host)) return n;
        n = n.assignedSlot || n.parentNode
    }
    return null
}

function gn(n) {
    for (; n.attributes.length;) n.removeAttributeNode(n.attributes[0])
}

function $r(n, t) {
    let e = t.focusNode,
        i = t.focusOffset;
    if (!e || t.anchorNode != e || t.anchorOffset != i) return !1;
    for (i = Math.min(i, ct(e));;)
        if (i) {
            if (e.nodeType != 1) return !1;
            let s = e.childNodes[i - 1];
            s.contentEditable == "false" ? i-- : (e = s, i = ct(e))
        } else {
            if (e == n) return !0;
            i = At(e), e = e.parentNode
        }
}

function pn(n) {
    return n.scrollTop > Math.max(1, n.scrollHeight - n.clientHeight - 4)
}

function mn(n, t) {
    for (let e = n, i = t;;) {
        if (e.nodeType == 3 && i > 0) return {
            node: e,
            offset: i
        };
        if (e.nodeType == 1 && i > 0) {
            if (e.contentEditable == "false") return null;
            e = e.childNodes[i - 1], i = ct(e)
        } else if (e.parentNode && !Fe(e)) i = At(e), e = e.parentNode;
        else return null
    }
}

function wn(n, t) {
    for (let e = n, i = t;;) {
        if (e.nodeType == 3 && i < e.nodeValue.length) return {
            node: e,
            offset: i
        };
        if (e.nodeType == 1 && i < e.childNodes.length) {
            if (e.contentEditable == "false") return null;
            e = e.childNodes[i], i = 0
        } else if (e.parentNode && !Fe(e)) i = At(e) + 1, e = e.parentNode;
        else return null
    }
}
class K {
    constructor(t, e, i = !0) {
        this.node = t, this.offset = e, this.precise = i
    }
    static before(t, e) {
        return new K(t.parentNode, At(t), e)
    }
    static after(t, e) {
        return new K(t.parentNode, At(t) + 1, e)
    }
}
const qi = [];
class R {
    constructor() {
        this.parent = null, this.dom = null, this.flags = 2
    }
    get overrideDOMText() {
        return null
    }
    get posAtStart() {
        return this.parent ? this.parent.posBefore(this) : 0
    }
    get posAtEnd() {
        return this.posAtStart + this.length
    }
    posBefore(t) {
        let e = this.posAtStart;
        for (let i of this.children) {
            if (i == t) return e;
            e += i.length + i.breakAfter
        }
        throw new RangeError("Invalid child in posBefore")
    }
    posAfter(t) {
        return this.posBefore(t) + t.length
    }
    sync(t, e) {
        if (this.flags & 2) {
            let i = this.dom,
                s = null,
                r;
            for (let o of this.children) {
                if (o.flags & 7) {
                    if (!o.dom && (r = s ? s.nextSibling : i.firstChild)) {
                        let l = R.get(r);
                        (!l || !l.parent && l.canReuseDOM(o)) && o.reuseDOM(r)
                    }
                    o.sync(t, e), o.flags &= -8
                }
                if (r = s ? s.nextSibling : i.firstChild, e && !e.written && e.node == i && r != o.dom && (e.written = !0), o.dom.parentNode == i)
                    for (; r && r != o.dom;) r = hs(r);
                else i.insertBefore(o.dom, r);
                s = o.dom
            }
            for (r = s ? s.nextSibling : i.firstChild, r && e && e.node == i && (e.written = !0); r;) r = hs(r)
        } else if (this.flags & 1)
            for (let i of this.children) i.flags & 7 && (i.sync(t, e), i.flags &= -8)
    }
    reuseDOM(t) {}
    localPosFromDOM(t, e) {
        let i;
        if (t == this.dom) i = this.dom.childNodes[e];
        else {
            let s = ct(t) == 0 ? 0 : e == 0 ? -1 : 1;
            for (;;) {
                let r = t.parentNode;
                if (r == this.dom) break;
                s == 0 && r.firstChild != r.lastChild && (t == r.firstChild ? s = -1 : s = 1), t = r
            }
            s < 0 ? i = t : i = t.nextSibling
        }
        if (i == this.dom.firstChild) return 0;
        for (; i && !R.get(i);) i = i.nextSibling;
        if (!i) return this.length;
        for (let s = 0, r = 0;; s++) {
            let o = this.children[s];
            if (o.dom == i) return r;
            r += o.length + o.breakAfter
        }
    }
    domBoundsAround(t, e, i = 0) {
        let s = -1,
            r = -1,
            o = -1,
            l = -1;
        for (let h = 0, f = i, a = i; h < this.children.length; h++) {
            let c = this.children[h],
                u = f + c.length;
            if (f < t && u > e) return c.domBoundsAround(t, e, f);
            if (u >= t && s == -1 && (s = h, r = f), f > e && c.dom.parentNode == this.dom) {
                o = h, l = a;
                break
            }
            a = u, f = u + c.breakAfter
        }
        return {
            from: r,
            to: l < 0 ? i + this.length : l,
            startDOM: (s ? this.children[s - 1].dom.nextSibling : null) || this.dom.firstChild,
            endDOM: o < this.children.length && o >= 0 ? this.children[o].dom : null
        }
    }
    markDirty(t = !1) {
        this.flags |= 2, this.markParentsDirty(t)
    }
    markParentsDirty(t) {
        for (let e = this.parent; e; e = e.parent) {
            if (t && (e.flags |= 2), e.flags & 1) return;
            e.flags |= 1, t = !1
        }
    }
    setParent(t) {
        this.parent != t && (this.parent = t, this.flags & 7 && this.markParentsDirty(!0))
    }
    setDOM(t) {
        this.dom != t && (this.dom && (this.dom.cmView = null), this.dom = t, t.cmView = this)
    }
    get rootView() {
        for (let t = this;;) {
            let e = t.parent;
            if (!e) return t;
            t = e
        }
    }
    replaceChildren(t, e, i = qi) {
        this.markDirty();
        for (let s = t; s < e; s++) {
            let r = this.children[s];
            r.parent == this && i.indexOf(r) < 0 && r.destroy()
        }
        this.children.splice(t, e - t, ...i);
        for (let s = 0; s < i.length; s++) i[s].setParent(this)
    }
    ignoreMutation(t) {
        return !1
    }
    ignoreEvent(t) {
        return !1
    }
    childCursor(t = this.length) {
        return new bn(this.children, t, this.children.length)
    }
    childPos(t, e = 1) {
        return this.childCursor().findPos(t, e)
    }
    toString() {
        let t = this.constructor.name.replace("View", "");
        return t + (this.children.length ? "(" + this.children.join() + ")" : this.length ? "[" + (t == "Text" ? this.text : this.length) + "]" : "") + (this.breakAfter ? "#" : "")
    }
    static get(t) {
        return t.cmView
    }
    get isEditable() {
        return !0
    }
    get isWidget() {
        return !1
    }
    get isHidden() {
        return !1
    }
    merge(t, e, i, s, r, o) {
        return !1
    }
    become(t) {
        return !1
    }
    canReuseDOM(t) {
        return t.constructor == this.constructor && !((this.flags | t.flags) & 8)
    }
    getSide() {
        return 0
    }
    destroy() {
        for (let t of this.children) t.parent == this && t.destroy();
        this.parent = null
    }
}
R.prototype.breakAfter = 0;

function hs(n) {
    let t = n.nextSibling;
    return n.parentNode.removeChild(n), t
}
class bn {
    constructor(t, e, i) {
        this.children = t, this.pos = e, this.i = i, this.off = 0
    }
    findPos(t, e = 1) {
        for (;;) {
            if (t > this.pos || t == this.pos && (e > 0 || this.i == 0 || this.children[this.i - 1].breakAfter)) return this.off = t - this.pos, this;
            let i = this.children[--this.i];
            this.pos -= i.length + i.breakAfter
        }
    }
}

function yn(n, t, e, i, s, r, o, l, h) {
    let {
        children: f
    } = n, a = f.length ? f[t] : null, c = r.length ? r[r.length - 1] : null, u = c ? c.breakAfter : o;
    if (!(t == i && a && !o && !u && r.length < 2 && a.merge(e, s, r.length ? c : null, e == 0, l, h))) {
        if (i < f.length) {
            let d = f[i];
            d && (s < d.length || d.breakAfter && (c != null && c.breakAfter)) ? (t == i && (d = d.split(s), s = 0), !u && c && d.merge(0, s, c, !0, 0, h) ? r[r.length - 1] = d : ((s || d.children.length && !d.children[0].length) && d.merge(0, s, null, !1, 0, h), r.push(d))) : d != null && d.breakAfter && (c ? c.breakAfter = 1 : o = 1), i++
        }
        for (a && (a.breakAfter = o, e > 0 && (!o && r.length && a.merge(e, a.length, r[0], !1, l, 0) ? a.breakAfter = r.shift().breakAfter : (e < a.length || a.children.length && a.children[a.children.length - 1].length == 0) && a.merge(e, a.length, null, !1, l, 0), t++)); t < i && r.length;)
            if (f[i - 1].become(r[r.length - 1])) i--, r.pop(), h = r.length ? 0 : l;
            else if (f[t].become(r[0])) t++, r.shift(), l = r.length ? 0 : h;
        else break;
        !r.length && t && i < f.length && !f[t - 1].breakAfter && f[i].merge(0, 0, f[t - 1], !1, l, h) && t--, (t < i || r.length) && n.replaceChildren(t, i, r)
    }
}

function xn(n, t, e, i, s, r) {
    let o = n.childCursor(),
        {
            i: l,
            off: h
        } = o.findPos(e, 1),
        {
            i: f,
            off: a
        } = o.findPos(t, -1),
        c = t - e;
    for (let u of i) c += u.length;
    n.length += c, yn(n, f, a, l, h, i, 0, s, r)
}
let Y = typeof navigator < "u" ? navigator : {
        userAgent: "",
        vendor: "",
        platform: ""
    },
    wi = typeof document < "u" ? document : {
        documentElement: {
            style: {}
        }
    };
const bi = /Edge\/(\d+)/.exec(Y.userAgent),
    Sn = /MSIE \d/.test(Y.userAgent),
    yi = /Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(Y.userAgent),
    $e = !!(Sn || yi || bi),
    as = !$e && /gecko\/(\d+)/i.test(Y.userAgent),
    Ye = !$e && /Chrome\/(\d+)/.exec(Y.userAgent),
    Gr = "webkitFontSmoothing" in wi.documentElement.style,
    vn = !$e && /Apple Computer/.test(Y.vendor),
    fs = vn && (/Mobile\/\w+/.test(Y.userAgent) || Y.maxTouchPoints > 2);
var b = {
    mac: fs || /Mac/.test(Y.platform),
    windows: /Win/.test(Y.platform),
    linux: /Linux|X11/.test(Y.platform),
    ie: $e,
    ie_version: Sn ? wi.documentMode || 6 : yi ? +yi[1] : bi ? +bi[1] : 0,
    gecko: as,
    gecko_version: as ? +(/Firefox\/(\d+)/.exec(Y.userAgent) || [0, 0])[1] : 0,
    chrome: !!Ye,
    chrome_version: Ye ? +Ye[1] : 0,
    ios: fs,
    android: /Android\b/.test(Y.userAgent),
    safari: vn,
    webkit_version: Gr ? +(/\bAppleWebKit\/(\d+)/.exec(Y.userAgent) || [0, 0])[1] : 0,
    tabSize: wi.documentElement.style.tabSize != null ? "tab-size" : "-moz-tab-size"
};
const Yr = 256;
class Z extends R {
    constructor(t) {
        super(), this.text = t
    }
    get length() {
        return this.text.length
    }
    createDOM(t) {
        this.setDOM(t || document.createTextNode(this.text))
    }
    sync(t, e) {
        this.dom || this.createDOM(), this.dom.nodeValue != this.text && (e && e.node == this.dom && (e.written = !0), this.dom.nodeValue = this.text)
    }
    reuseDOM(t) {
        t.nodeType == 3 && this.createDOM(t)
    }
    merge(t, e, i) {
        return this.flags & 8 || i && (!(i instanceof Z) || this.length - (e - t) + i.length > Yr || i.flags & 8) ? !1 : (this.text = this.text.slice(0, t) + (i ? i.text : "") + this.text.slice(e), this.markDirty(), !0)
    }
    split(t) {
        let e = new Z(this.text.slice(t));
        return this.text = this.text.slice(0, t), this.markDirty(), e.flags |= this.flags & 8, e
    }
    localPosFromDOM(t, e) {
        return t == this.dom ? e : e ? this.text.length : 0
    }
    domAtPos(t) {
        return new K(this.dom, t)
    }
    domBoundsAround(t, e, i) {
        return {
            from: i,
            to: i + this.length,
            startDOM: this.dom,
            endDOM: this.dom.nextSibling
        }
    }
    coordsAt(t, e) {
        return Xr(this.dom, t, e)
    }
}
class ut extends R {
    constructor(t, e = [], i = 0) {
        super(), this.mark = t, this.children = e, this.length = i;
        for (let s of e) s.setParent(this)
    }
    setAttrs(t) {
        if (gn(t), this.mark.class && (t.className = this.mark.class), this.mark.attrs)
            for (let e in this.mark.attrs) t.setAttribute(e, this.mark.attrs[e]);
        return t
    }
    canReuseDOM(t) {
        return super.canReuseDOM(t) && !((this.flags | t.flags) & 8)
    }
    reuseDOM(t) {
        t.nodeName == this.mark.tagName.toUpperCase() && (this.setDOM(t), this.flags |= 6)
    }
    sync(t, e) {
        this.dom ? this.flags & 4 && this.setAttrs(this.dom) : this.setDOM(this.setAttrs(document.createElement(this.mark.tagName))), super.sync(t, e)
    }
    merge(t, e, i, s, r, o) {
        return i && (!(i instanceof ut && i.mark.eq(this.mark)) || t && r <= 0 || e < this.length && o <= 0) ? !1 : (xn(this, t, e, i ? i.children.slice() : [], r - 1, o - 1), this.markDirty(), !0)
    }
    split(t) {
        let e = [],
            i = 0,
            s = -1,
            r = 0;
        for (let l of this.children) {
            let h = i + l.length;
            h > t && e.push(i < t ? l.split(t - i) : l), s < 0 && i >= t && (s = r), i = h, r++
        }
        let o = this.length - t;
        return this.length = t, s > -1 && (this.children.length = s, this.markDirty()), new ut(this.mark, e, o)
    }
    domAtPos(t) {
        return kn(this, t)
    }
    coordsAt(t, e) {
        return Mn(this, t, e)
    }
}

function Xr(n, t, e) {
    let i = n.nodeValue.length;
    t > i && (t = i);
    let s = t,
        r = t,
        o = 0;
    t == 0 && e < 0 || t == i && e >= 0 ? b.chrome || b.gecko || (t ? (s--, o = 1) : r < i && (r++, o = -1)) : e < 0 ? s-- : r < i && r++;
    let l = Ot(n, s, r).getClientRects();
    if (!l.length) return null;
    let h = l[(o ? o < 0 : e >= 0) ? 0 : l.length - 1];
    return b.safari && !o && h.width == 0 && (h = Array.prototype.find.call(l, f => f.width) || h), o ? je(h, o < 0) : h || null
}
class Mt extends R {
    static create(t, e, i) {
        return new Mt(t, e, i)
    }
    constructor(t, e, i) {
        super(), this.widget = t, this.length = e, this.side = i, this.prevWidget = null
    }
    split(t) {
        let e = Mt.create(this.widget, this.length - t, this.side);
        return this.length -= t, e
    }
    sync(t) {
        (!this.dom || !this.widget.updateDOM(this.dom, t)) && (this.dom && this.prevWidget && this.prevWidget.destroy(this.dom), this.prevWidget = null, this.setDOM(this.widget.toDOM(t)), this.widget.editable || (this.dom.contentEditable = "false"))
    }
    getSide() {
        return this.side
    }
    merge(t, e, i, s, r, o) {
        return i && (!(i instanceof Mt) || !this.widget.compare(i.widget) || t > 0 && r <= 0 || e < this.length && o <= 0) ? !1 : (this.length = t + (i ? i.length : 0) + (this.length - e), !0)
    }
    become(t) {
        return t instanceof Mt && t.side == this.side && this.widget.constructor == t.widget.constructor ? (this.widget.compare(t.widget) || this.markDirty(!0), this.dom && !this.prevWidget && (this.prevWidget = this.widget), this.widget = t.widget, this.length = t.length, !0) : !1
    }
    ignoreMutation() {
        return !0
    }
    ignoreEvent(t) {
        return this.widget.ignoreEvent(t)
    }
    get overrideDOMText() {
        if (this.length == 0) return O.empty;
        let t = this;
        for (; t.parent;) t = t.parent;
        let {
            view: e
        } = t, i = e && e.state.doc, s = this.posAtStart;
        return i ? i.slice(s, s + this.length) : O.empty
    }
    domAtPos(t) {
        return (this.length ? t == 0 : this.side > 0) ? K.before(this.dom) : K.after(this.dom, t == this.length)
    }
    domBoundsAround() {
        return null
    }
    coordsAt(t, e) {
        let i = this.widget.coordsAt(this.dom, t, e);
        if (i) return i;
        let s = this.dom.getClientRects(),
            r = null;
        if (!s.length) return null;
        let o = this.side ? this.side < 0 : t > 0;
        for (let l = o ? s.length - 1 : 0; r = s[l], !(t > 0 ? l == 0 : l == s.length - 1 || r.top < r.bottom); l += o ? -1 : 1);
        return je(r, !o)
    }
    get isEditable() {
        return !1
    }
    get isWidget() {
        return !0
    }
    get isHidden() {
        return this.widget.isHidden
    }
    destroy() {
        super.destroy(), this.dom && this.widget.destroy(this.dom)
    }
}
class Wt extends R {
    constructor(t) {
        super(), this.side = t
    }
    get length() {
        return 0
    }
    merge() {
        return !1
    }
    become(t) {
        return t instanceof Wt && t.side == this.side
    }
    split() {
        return new Wt(this.side)
    }
    sync() {
        if (!this.dom) {
            let t = document.createElement("img");
            t.className = "cm-widgetBuffer", t.setAttribute("aria-hidden", "true"), this.setDOM(t)
        }
    }
    getSide() {
        return this.side
    }
    domAtPos(t) {
        return this.side > 0 ? K.before(this.dom) : K.after(this.dom)
    }
    localPosFromDOM() {
        return 0
    }
    domBoundsAround() {
        return null
    }
    coordsAt(t) {
        return this.dom.getBoundingClientRect()
    }
    get overrideDOMText() {
        return O.empty
    }
    get isHidden() {
        return !0
    }
}
Z.prototype.children = Mt.prototype.children = Wt.prototype.children = qi;

function kn(n, t) {
    let e = n.dom,
        {
            children: i
        } = n,
        s = 0;
    for (let r = 0; s < i.length; s++) {
        let o = i[s],
            l = r + o.length;
        if (!(l == r && o.getSide() <= 0)) {
            if (t > r && t < l && o.dom.parentNode == e) return o.domAtPos(t - r);
            if (t <= r) break;
            r = l
        }
    }
    for (let r = s; r > 0; r--) {
        let o = i[r - 1];
        if (o.dom.parentNode == e) return o.domAtPos(o.length)
    }
    for (let r = s; r < i.length; r++) {
        let o = i[r];
        if (o.dom.parentNode == e) return o.domAtPos(0)
    }
    return new K(e, 0)
}

function Cn(n, t, e) {
    let i, {
        children: s
    } = n;
    e > 0 && t instanceof ut && s.length && (i = s[s.length - 1]) instanceof ut && i.mark.eq(t.mark) ? Cn(i, t.children[0], e - 1) : (s.push(t), t.setParent(n)), n.length += t.length
}

function Mn(n, t, e) {
    let i = null,
        s = -1,
        r = null,
        o = -1;

    function l(f, a) {
        for (let c = 0, u = 0; c < f.children.length && u <= a; c++) {
            let d = f.children[c],
                g = u + d.length;
            g >= a && (d.children.length ? l(d, a - u) : (!r || r.isHidden && e > 0) && (g > a || u == g && d.getSide() > 0) ? (r = d, o = a - u) : (u < a || u == g && d.getSide() < 0 && !d.isHidden) && (i = d, s = a - u)), u = g
        }
    }
    l(n, t);
    let h = (e < 0 ? i : r) || i || r;
    return h ? h.coordsAt(Math.max(0, h == i ? s : o), e) : Ur(n)
}

function Ur(n) {
    let t = n.dom.lastChild;
    if (!t) return n.dom.getBoundingClientRect();
    let e = Ft(t);
    return e[e.length - 1] || null
}

function xi(n, t) {
    for (let e in n) e == "class" && t.class ? t.class += " " + n.class : e == "style" && t.style ? t.style += ";" + n.style : t[e] = n[e];
    return t
}
const cs = Object.create(null);

function We(n, t, e) {
    if (n == t) return !0;
    n || (n = cs), t || (t = cs);
    let i = Object.keys(n),
        s = Object.keys(t);
    if (i.length - (e && i.indexOf(e) > -1 ? 1 : 0) != s.length - (e && s.indexOf(e) > -1 ? 1 : 0)) return !1;
    for (let r of i)
        if (r != e && (s.indexOf(r) == -1 || n[r] !== t[r])) return !1;
    return !0
}

function Si(n, t, e) {
    let i = !1;
    if (t)
        for (let s in t) e && s in e || (i = !0, s == "style" ? n.style.cssText = "" : n.removeAttribute(s));
    if (e)
        for (let s in e) t && t[s] == e[s] || (i = !0, s == "style" ? n.style.cssText = e[s] : n.setAttribute(s, e[s]));
    return i
}

function Jr(n) {
    let t = Object.create(null);
    for (let e = 0; e < n.attributes.length; e++) {
        let i = n.attributes[e];
        t[i.name] = i.value
    }
    return t
}
class N extends R {
    constructor() {
        super(...arguments), this.children = [], this.length = 0, this.prevAttrs = void 0, this.attrs = null, this.breakAfter = 0
    }
    merge(t, e, i, s, r, o) {
        if (i) {
            if (!(i instanceof N)) return !1;
            this.dom || i.transferDOM(this)
        }
        return s && this.setDeco(i ? i.attrs : null), xn(this, t, e, i ? i.children.slice() : [], r, o), !0
    }
    split(t) {
        let e = new N;
        if (e.breakAfter = this.breakAfter, this.length == 0) return e;
        let {
            i,
            off: s
        } = this.childPos(t);
        s && (e.append(this.children[i].split(s), 0), this.children[i].merge(s, this.children[i].length, null, !1, 0, 0), i++);
        for (let r = i; r < this.children.length; r++) e.append(this.children[r], 0);
        for (; i > 0 && this.children[i - 1].length == 0;) this.children[--i].destroy();
        return this.children.length = i, this.markDirty(), this.length = t, e
    }
    transferDOM(t) {
        this.dom && (this.markDirty(), t.setDOM(this.dom), t.prevAttrs = this.prevAttrs === void 0 ? this.attrs : this.prevAttrs, this.prevAttrs = void 0, this.dom = null)
    }
    setDeco(t) {
        We(this.attrs, t) || (this.dom && (this.prevAttrs = this.attrs, this.markDirty()), this.attrs = t)
    }
    append(t, e) {
        Cn(this, t, e)
    }
    addLineDeco(t) {
        let e = t.spec.attributes,
            i = t.spec.class;
        e && (this.attrs = xi(e, this.attrs || {})), i && (this.attrs = xi({
            class: i
        }, this.attrs || {}))
    }
    domAtPos(t) {
        return kn(this, t)
    }
    reuseDOM(t) {
        t.nodeName == "DIV" && (this.setDOM(t), this.flags |= 6)
    }
    sync(t, e) {
        var i;
        this.dom ? this.flags & 4 && (gn(this.dom), this.dom.className = "cm-line", this.prevAttrs = this.attrs ? null : void 0) : (this.setDOM(document.createElement("div")), this.dom.className = "cm-line", this.prevAttrs = this.attrs ? null : void 0), this.prevAttrs !== void 0 && (Si(this.dom, this.prevAttrs, this.attrs), this.dom.classList.add("cm-line"), this.prevAttrs = void 0), super.sync(t, e);
        let s = this.dom.lastChild;
        for (; s && R.get(s) instanceof ut;) s = s.lastChild;
        if (!s || !this.length || s.nodeName != "BR" && ((i = R.get(s)) === null || i === void 0 ? void 0 : i.isEditable) == !1 && (!b.ios || !this.children.some(r => r instanceof Z))) {
            let r = document.createElement("BR");
            r.cmIgnore = !0, this.dom.appendChild(r)
        }
    }
    measureTextSize() {
        if (this.children.length == 0 || this.length > 20) return null;
        let t = 0,
            e;
        for (let i of this.children) {
            if (!(i instanceof Z) || /[^ -~]/.test(i.text)) return null;
            let s = Ft(i.dom);
            if (s.length != 1) return null;
            t += s[0].width, e = s[0].height
        }
        return t ? {
            lineHeight: this.dom.getBoundingClientRect().height,
            charWidth: t / this.length,
            textHeight: e
        } : null
    }
    coordsAt(t, e) {
        let i = Mn(this, t, e);
        if (!this.children.length && i && this.parent) {
            let {
                heightOracle: s
            } = this.parent.view.viewState, r = i.bottom - i.top;
            if (Math.abs(r - s.lineHeight) < 2 && s.textHeight < r) {
                let o = (r - s.textHeight) / 2;
                return {
                    top: i.top + o,
                    bottom: i.bottom - o,
                    left: i.left,
                    right: i.left
                }
            }
        }
        return i
    }
    become(t) {
        return t instanceof N && this.children.length == 0 && t.children.length == 0 && We(this.attrs, t.attrs) && this.breakAfter == t.breakAfter
    }
    covers() {
        return !0
    }
    static find(t, e) {
        for (let i = 0, s = 0; i < t.children.length; i++) {
            let r = t.children[i],
                o = s + r.length;
            if (o >= e) {
                if (r instanceof N) return r;
                if (o > e) break
            }
            s = o + r.breakAfter
        }
        return null
    }
}
class ft extends R {
    constructor(t, e, i) {
        super(), this.widget = t, this.length = e, this.deco = i, this.breakAfter = 0, this.prevWidget = null
    }
    merge(t, e, i, s, r, o) {
        return i && (!(i instanceof ft) || !this.widget.compare(i.widget) || t > 0 && r <= 0 || e < this.length && o <= 0) ? !1 : (this.length = t + (i ? i.length : 0) + (this.length - e), !0)
    }
    domAtPos(t) {
        return t == 0 ? K.before(this.dom) : K.after(this.dom, t == this.length)
    }
    split(t) {
        let e = this.length - t;
        this.length = t;
        let i = new ft(this.widget, e, this.deco);
        return i.breakAfter = this.breakAfter, i
    }
    get children() {
        return qi
    }
    sync(t) {
        (!this.dom || !this.widget.updateDOM(this.dom, t)) && (this.dom && this.prevWidget && this.prevWidget.destroy(this.dom), this.prevWidget = null, this.setDOM(this.widget.toDOM(t)), this.widget.editable || (this.dom.contentEditable = "false"))
    }
    get overrideDOMText() {
        return this.parent ? this.parent.view.state.doc.slice(this.posAtStart, this.posAtEnd) : O.empty
    }
    domBoundsAround() {
        return null
    }
    become(t) {
        return t instanceof ft && t.widget.constructor == this.widget.constructor ? (t.widget.compare(this.widget) || this.markDirty(!0), this.dom && !this.prevWidget && (this.prevWidget = this.widget), this.widget = t.widget, this.length = t.length, this.deco = t.deco, this.breakAfter = t.breakAfter, !0) : !1
    }
    ignoreMutation() {
        return !0
    }
    ignoreEvent(t) {
        return this.widget.ignoreEvent(t)
    }
    get isEditable() {
        return !1
    }
    get isWidget() {
        return !0
    }
    coordsAt(t, e) {
        return this.widget.coordsAt(this.dom, t, e)
    }
    destroy() {
        super.destroy(), this.dom && this.widget.destroy(this.dom)
    }
    covers(t) {
        let {
            startSide: e,
            endSide: i
        } = this.deco;
        return e == i ? !1 : t < 0 ? e < 0 : i > 0
    }
}
class jt {
    eq(t) {
        return !1
    }
    updateDOM(t, e) {
        return !1
    }
    compare(t) {
        return this == t || this.constructor == t.constructor && this.eq(t)
    }
    get estimatedHeight() {
        return -1
    }
    get lineBreaks() {
        return 0
    }
    ignoreEvent(t) {
        return !0
    }
    coordsAt(t, e, i) {
        return null
    }
    get isHidden() {
        return !1
    }
    get editable() {
        return !1
    }
    destroy(t) {}
}
var $ = (function(n) {
    return n[n.Text = 0] = "Text", n[n.WidgetBefore = 1] = "WidgetBefore", n[n.WidgetAfter = 2] = "WidgetAfter", n[n.WidgetRange = 3] = "WidgetRange", n
})($ || ($ = {}));
class V extends It {
    constructor(t, e, i, s) {
        super(), this.startSide = t, this.endSide = e, this.widget = i, this.spec = s
    }
    get heightRelevant() {
        return !1
    }
    static mark(t) {
        return new ue(t)
    }
    static widget(t) {
        let e = Math.max(-1e4, Math.min(1e4, t.side || 0)),
            i = !!t.block;
        return e += i && !t.inlineOrder ? e > 0 ? 3e8 : -4e8 : e > 0 ? 1e8 : -1e8, new yt(t, e, e, i, t.widget || null, !1)
    }
    static replace(t) {
        let e = !!t.block,
            i, s;
        if (t.isBlockGap) i = -5e8, s = 4e8;
        else {
            let {
                start: r,
                end: o
            } = An(t, e);
            i = (r ? e ? -3e8 : -1 : 5e8) - 1, s = (o ? e ? 2e8 : 1 : -6e8) + 1
        }
        return new yt(t, i, s, e, t.widget || null, !0)
    }
    static line(t) {
        return new de(t)
    }
    static set(t, e = !1) {
        return A.of(t, e)
    }
    hasHeight() {
        return this.widget ? this.widget.estimatedHeight > -1 : !1
    }
}
V.none = A.empty;
class ue extends V {
    constructor(t) {
        let {
            start: e,
            end: i
        } = An(t);
        super(e ? -1 : 5e8, i ? 1 : -6e8, null, t), this.tagName = t.tagName || "span", this.class = t.class || "", this.attrs = t.attributes || null
    }
    eq(t) {
        var e, i;
        return this == t || t instanceof ue && this.tagName == t.tagName && (this.class || ((e = this.attrs) === null || e === void 0 ? void 0 : e.class)) == (t.class || ((i = t.attrs) === null || i === void 0 ? void 0 : i.class)) && We(this.attrs, t.attrs, "class")
    }
    range(t, e = t) {
        if (t >= e) throw new RangeError("Mark decorations may not be empty");
        return super.range(t, e)
    }
}
ue.prototype.point = !1;
class de extends V {
    constructor(t) {
        super(-2e8, -2e8, null, t)
    }
    eq(t) {
        return t instanceof de && this.spec.class == t.spec.class && We(this.spec.attributes, t.spec.attributes)
    }
    range(t, e = t) {
        if (e != t) throw new RangeError("Line decoration ranges must be zero-length");
        return super.range(t, e)
    }
}
de.prototype.mapMode = U.TrackBefore;
de.prototype.point = !0;
class yt extends V {
    constructor(t, e, i, s, r, o) {
        super(e, i, r, t), this.block = s, this.isReplace = o, this.mapMode = s ? e <= 0 ? U.TrackBefore : U.TrackAfter : U.TrackDel
    }
    get type() {
        return this.startSide != this.endSide ? $.WidgetRange : this.startSide <= 0 ? $.WidgetBefore : $.WidgetAfter
    }
    get heightRelevant() {
        return this.block || !!this.widget && (this.widget.estimatedHeight >= 5 || this.widget.lineBreaks > 0)
    }
    eq(t) {
        return t instanceof yt && Qr(this.widget, t.widget) && this.block == t.block && this.startSide == t.startSide && this.endSide == t.endSide
    }
    range(t, e = t) {
        if (this.isReplace && (t > e || t == e && this.startSide > 0 && this.endSide <= 0)) throw new RangeError("Invalid range for replacement decoration");
        if (!this.isReplace && e != t) throw new RangeError("Widget decorations can only have zero-length ranges");
        return super.range(t, e)
    }
}
yt.prototype.point = !0;

function An(n, t = !1) {
    let {
        inclusiveStart: e,
        inclusiveEnd: i
    } = n;
    return e == null && (e = n.inclusive), i == null && (i = n.inclusive), {
        start: e != null ? e : t,
        end: i != null ? i : t
    }
}

function Qr(n, t) {
    return n == t || !!(n && t && n.compare(t))
}

function vi(n, t, e, i = 0) {
    let s = e.length - 1;
    s >= 0 && e[s] + i >= n ? e[s] = Math.max(e[s], t) : e.push(n, t)
}
class se {
    constructor(t, e, i, s) {
        this.doc = t, this.pos = e, this.end = i, this.disallowBlockEffectsFor = s, this.content = [], this.curLine = null, this.breakAtStart = 0, this.pendingBuffer = 0, this.bufferMarks = [], this.atCursorPos = !0, this.openStart = -1, this.openEnd = -1, this.text = "", this.textOff = 0, this.cursor = t.iter(), this.skip = e
    }
    posCovered() {
        if (this.content.length == 0) return !this.breakAtStart && this.doc.lineAt(this.pos).from != this.pos;
        let t = this.content[this.content.length - 1];
        return !(t.breakAfter || t instanceof ft && t.deco.endSide < 0)
    }
    getLine() {
        return this.curLine || (this.content.push(this.curLine = new N), this.atCursorPos = !0), this.curLine
    }
    flushBuffer(t = this.bufferMarks) {
        this.pendingBuffer && (this.curLine.append(xe(new Wt(-1), t), t.length), this.pendingBuffer = 0)
    }
    addBlockWidget(t) {
        this.flushBuffer(), this.curLine = null, this.content.push(t)
    }
    finish(t) {
        this.pendingBuffer && t <= this.bufferMarks.length ? this.flushBuffer() : this.pendingBuffer = 0, !this.posCovered() && !(t && this.content.length && this.content[this.content.length - 1] instanceof ft) && this.getLine()
    }
    buildText(t, e, i) {
        for (; t > 0;) {
            if (this.textOff == this.text.length) {
                let {
                    value: r,
                    lineBreak: o,
                    done: l
                } = this.cursor.next(this.skip);
                if (this.skip = 0, l) throw new Error("Ran out of text content when drawing inline views");
                if (o) {
                    this.posCovered() || this.getLine(), this.content.length ? this.content[this.content.length - 1].breakAfter = 1 : this.breakAtStart = 1, this.flushBuffer(), this.curLine = null, this.atCursorPos = !0, t--;
                    continue
                } else this.text = r, this.textOff = 0
            }
            let s = Math.min(this.text.length - this.textOff, t, 512);
            this.flushBuffer(e.slice(e.length - i)), this.getLine().append(xe(new Z(this.text.slice(this.textOff, this.textOff + s)), e), i), this.atCursorPos = !0, this.textOff += s, t -= s, i = 0
        }
    }
    span(t, e, i, s) {
        this.buildText(e - t, i, s), this.pos = e, this.openStart < 0 && (this.openStart = s)
    }
    point(t, e, i, s, r, o) {
        if (this.disallowBlockEffectsFor[o] && i instanceof yt) {
            if (i.block) throw new RangeError("Block decorations may not be specified via plugins");
            if (e > this.doc.lineAt(this.pos).to) throw new RangeError("Decorations that replace line breaks may not be specified via plugins")
        }
        let l = e - t;
        if (i instanceof yt)
            if (i.block) i.startSide > 0 && !this.posCovered() && this.getLine(), this.addBlockWidget(new ft(i.widget || zt.block, l, i));
            else {
                let h = Mt.create(i.widget || zt.inline, l, l ? 0 : i.startSide),
                    f = this.atCursorPos && !h.isEditable && r <= s.length && (t < e || i.startSide > 0),
                    a = !h.isEditable && (t < e || r > s.length || i.startSide <= 0),
                    c = this.getLine();
                this.pendingBuffer == 2 && !f && !h.isEditable && (this.pendingBuffer = 0), this.flushBuffer(s), f && (c.append(xe(new Wt(1), s), r), r = s.length + Math.max(0, r - s.length)), c.append(xe(h, s), r), this.atCursorPos = a, this.pendingBuffer = a ? t < e || r > s.length ? 1 : 2 : 0, this.pendingBuffer && (this.bufferMarks = s.slice())
            }
        else this.doc.lineAt(this.pos).from == this.pos && this.getLine().addLineDeco(i);
        l && (this.textOff + l <= this.text.length ? this.textOff += l : (this.skip += l - (this.text.length - this.textOff), this.text = "", this.textOff = 0), this.pos = e), this.openStart < 0 && (this.openStart = r)
    }
    static build(t, e, i, s, r) {
        let o = new se(t, e, i, r);
        return o.openEnd = A.spans(s, e, i, o), o.openStart < 0 && (o.openStart = o.openEnd), o.finish(o.openEnd), o
    }
}

function xe(n, t) {
    for (let e of t) n = new ut(e, [n], n.length);
    return n
}
class zt extends jt {
    constructor(t) {
        super(), this.tag = t
    }
    eq(t) {
        return t.tag == this.tag
    }
    toDOM() {
        return document.createElement(this.tag)
    }
    updateDOM(t) {
        return t.nodeName.toLowerCase() == this.tag
    }
    get isHidden() {
        return !0
    }
}
zt.inline = new zt("span");
zt.block = new zt("div");
var I = (function(n) {
    return n[n.LTR = 0] = "LTR", n[n.RTL = 1] = "RTL", n
})(I || (I = {}));
const Dt = I.LTR,
    Ki = I.RTL;

function On(n) {
    let t = [];
    for (let e = 0; e < n.length; e++) t.push(1 << +n[e]);
    return t
}
const Zr = On("88888888888888888888888888888888888666888888787833333333337888888000000000000000000000000008888880000000000000000000000000088888888888888888888888888888888888887866668888088888663380888308888800000000000000000000000800000000000000000000000000000008"),
    _r = On("4444448826627288999999999992222222222222222222222222222222222222222222222229999999999999999999994444444444644222822222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222999999949999999229989999223333333333"),
    ki = Object.create(null),
    tt = [];
for (let n of ["()", "[]", "{}"]) {
    let t = n.charCodeAt(0),
        e = n.charCodeAt(1);
    ki[t] = e, ki[e] = -t
}

function Dn(n) {
    return n <= 247 ? Zr[n] : 1424 <= n && n <= 1524 ? 2 : 1536 <= n && n <= 1785 ? _r[n - 1536] : 1774 <= n && n <= 2220 ? 4 : 8192 <= n && n <= 8204 ? 256 : 64336 <= n && n <= 65023 ? 4 : 1
}
const to = /[\u0590-\u05f4\u0600-\u06ff\u0700-\u08ac\ufb50-\ufdff]/;
class bt {
    get dir() {
        return this.level % 2 ? Ki : Dt
    }
    constructor(t, e, i) {
        this.from = t, this.to = e, this.level = i
    }
    side(t, e) {
        return this.dir == e == t ? this.to : this.from
    }
    forward(t, e) {
        return t == (this.dir == e)
    }
    static find(t, e, i, s) {
        let r = -1;
        for (let o = 0; o < t.length; o++) {
            let l = t[o];
            if (l.from <= e && l.to >= e) {
                if (l.level == i) return o;
                (r < 0 || (s != 0 ? s < 0 ? l.from < e : l.to > e : t[r].level > l.level)) && (r = o)
            }
        }
        if (r < 0) throw new RangeError("Index out of range");
        return r
    }
}

function Tn(n, t) {
    if (n.length != t.length) return !1;
    for (let e = 0; e < n.length; e++) {
        let i = n[e],
            s = t[e];
        if (i.from != s.from || i.to != s.to || i.direction != s.direction || !Tn(i.inner, s.inner)) return !1
    }
    return !0
}
const T = [];

function eo(n, t, e, i, s) {
    for (let r = 0; r <= i.length; r++) {
        let o = r ? i[r - 1].to : t,
            l = r < i.length ? i[r].from : e,
            h = r ? 256 : s;
        for (let f = o, a = h, c = h; f < l; f++) {
            let u = Dn(n.charCodeAt(f));
            u == 512 ? u = a : u == 8 && c == 4 && (u = 16), T[f] = u == 4 ? 2 : u, u & 7 && (c = u), a = u
        }
        for (let f = o, a = h, c = h; f < l; f++) {
            let u = T[f];
            if (u == 128) f < l - 1 && a == T[f + 1] && a & 24 ? u = T[f] = a : T[f] = 256;
            else if (u == 64) {
                let d = f + 1;
                for (; d < l && T[d] == 64;) d++;
                let g = f && a == 8 || d < e && T[d] == 8 ? c == 1 ? 1 : 8 : 256;
                for (let m = f; m < d; m++) T[m] = g;
                f = d - 1
            } else u == 8 && c == 1 && (T[f] = 1);
            a = u, u & 7 && (c = u)
        }
    }
}

function io(n, t, e, i, s) {
    let r = s == 1 ? 2 : 1;
    for (let o = 0, l = 0, h = 0; o <= i.length; o++) {
        let f = o ? i[o - 1].to : t,
            a = o < i.length ? i[o].from : e;
        for (let c = f, u, d, g; c < a; c++)
            if (d = ki[u = n.charCodeAt(c)])
                if (d < 0) {
                    for (let m = l - 3; m >= 0; m -= 3)
                        if (tt[m + 1] == -d) {
                            let p = tt[m + 2],
                                w = p & 2 ? s : p & 4 ? p & 1 ? r : s : 0;
                            w && (T[c] = T[tt[m]] = w), l = m;
                            break
                        }
                } else {
                    if (tt.length == 189) break;
                    tt[l++] = c, tt[l++] = u, tt[l++] = h
                }
        else if ((g = T[c]) == 2 || g == 1) {
            let m = g == s;
            h = m ? 0 : 1;
            for (let p = l - 3; p >= 0; p -= 3) {
                let w = tt[p + 2];
                if (w & 2) break;
                if (m) tt[p + 2] |= 2;
                else {
                    if (w & 4) break;
                    tt[p + 2] |= 4
                }
            }
        }
    }
}

function so(n, t, e, i) {
    for (let s = 0, r = i; s <= e.length; s++) {
        let o = s ? e[s - 1].to : n,
            l = s < e.length ? e[s].from : t;
        for (let h = o; h < l;) {
            let f = T[h];
            if (f == 256) {
                let a = h + 1;
                for (;;)
                    if (a == l) {
                        if (s == e.length) break;
                        a = e[s++].to, l = s < e.length ? e[s].from : t
                    } else if (T[a] == 256) a++;
                else break;
                let c = r == 1,
                    u = (a < t ? T[a] : i) == 1,
                    d = c == u ? c ? 1 : 2 : i;
                for (let g = a, m = s, p = m ? e[m - 1].to : n; g > h;) g == p && (g = e[--m].from, p = m ? e[m - 1].to : n), T[--g] = d;
                h = a
            } else r = f, h++
        }
    }
}

function Ci(n, t, e, i, s, r, o) {
    let l = i % 2 ? 2 : 1;
    if (i % 2 == s % 2)
        for (let h = t, f = 0; h < e;) {
            let a = !0,
                c = !1;
            if (f == r.length || h < r[f].from) {
                let m = T[h];
                m != l && (a = !1, c = m == 16)
            }
            let u = !a && l == 1 ? [] : null,
                d = a ? i : i + 1,
                g = h;
            t: for (;;)
                if (f < r.length && g == r[f].from) {
                    if (c) break t;
                    let m = r[f];
                    if (!a)
                        for (let p = m.to, w = f + 1;;) {
                            if (p == e) break t;
                            if (w < r.length && r[w].from == p) p = r[w++].to;
                            else {
                                if (T[p] == l) break t;
                                break
                            }
                        }
                    if (f++, u) u.push(m);
                    else {
                        m.from > h && o.push(new bt(h, m.from, d));
                        let p = m.direction == Dt != !(d % 2);
                        Mi(n, p ? i + 1 : i, s, m.inner, m.from, m.to, o), h = m.to
                    }
                    g = m.to
                } else {
                    if (g == e || (a ? T[g] != l : T[g] == l)) break;
                    g++
                }
            u ? Ci(n, h, g, i + 1, s, u, o) : h < g && o.push(new bt(h, g, d)), h = g
        } else
            for (let h = e, f = r.length; h > t;) {
                let a = !0,
                    c = !1;
                if (!f || h > r[f - 1].to) {
                    let m = T[h - 1];
                    m != l && (a = !1, c = m == 16)
                }
                let u = !a && l == 1 ? [] : null,
                    d = a ? i : i + 1,
                    g = h;
                t: for (;;)
                    if (f && g == r[f - 1].to) {
                        if (c) break t;
                        let m = r[--f];
                        if (!a)
                            for (let p = m.from, w = f;;) {
                                if (p == t) break t;
                                if (w && r[w - 1].to == p) p = r[--w].from;
                                else {
                                    if (T[p - 1] == l) break t;
                                    break
                                }
                            }
                        if (u) u.push(m);
                        else {
                            m.to < h && o.push(new bt(m.to, h, d));
                            let p = m.direction == Dt != !(d % 2);
                            Mi(n, p ? i + 1 : i, s, m.inner, m.from, m.to, o), h = m.from
                        }
                        g = m.from
                    } else {
                        if (g == t || (a ? T[g - 1] != l : T[g - 1] == l)) break;
                        g--
                    }
                u ? Ci(n, g, h, i + 1, s, u, o) : g < h && o.push(new bt(g, h, d)), h = g
            }
}

function Mi(n, t, e, i, s, r, o) {
    let l = t % 2 ? 2 : 1;
    eo(n, s, r, i, l), io(n, s, r, i, l), so(s, r, i, l), Ci(n, s, r, t, e, i, o)
}

function no(n, t, e) {
    if (!n) return [new bt(0, 0, t == Ki ? 1 : 0)];
    if (t == Dt && !e.length && !to.test(n)) return Rn(n.length);
    if (e.length)
        for (; n.length > T.length;) T[T.length] = 256;
    let i = [],
        s = t == Dt ? 0 : 1;
    return Mi(n, s, s, e, 0, n.length, i), i
}

function Rn(n) {
    return [new bt(0, n, 0)]
}
let En = "";

function ro(n, t, e, i, s) {
    var r;
    let o = i.head - n.from,
        l = bt.find(t, o, (r = i.bidiLevel) !== null && r !== void 0 ? r : -1, i.assoc),
        h = t[l],
        f = h.side(s, e);
    if (o == f) {
        let u = l += s ? 1 : -1;
        if (u < 0 || u >= t.length) return null;
        h = t[l = u], o = h.side(!s, e), f = h.side(s, e)
    }
    let a = st(n.text, o, h.forward(s, e));
    (a < h.from || a > h.to) && (a = f), En = n.text.slice(Math.min(o, a), Math.max(o, a));
    let c = l == (s ? t.length - 1 : 0) ? null : t[l + (s ? 1 : -1)];
    return c && a == f && c.level + (s ? 0 : 1) < h.level ? S.cursor(c.side(!s, e) + n.from, c.forward(s, e) ? 1 : -1, c.level) : S.cursor(a + n.from, h.forward(s, e) ? -1 : 1, h.level)
}

function oo(n, t, e) {
    for (let i = t; i < e; i++) {
        let s = Dn(n.charCodeAt(i));
        if (s == 1) return Dt;
        if (s == 2 || s == 4) return Ki
    }
    return Dt
}
const Bn = C.define(),
    Pn = C.define(),
    Ln = C.define(),
    Nn = C.define(),
    Ai = C.define(),
    Vn = C.define(),
    In = C.define(),
    Hn = C.define({
        combine: n => n.some(t => t)
    }),
    Fn = C.define({
        combine: n => n.some(t => t)
    }),
    Wn = C.define();
class Nt {
    constructor(t, e = "nearest", i = "nearest", s = 5, r = 5, o = !1) {
        this.range = t, this.y = e, this.x = i, this.yMargin = s, this.xMargin = r, this.isSnapshot = o
    }
    map(t) {
        return t.empty ? this : new Nt(this.range.map(t), this.y, this.x, this.yMargin, this.xMargin, this.isSnapshot)
    }
    clip(t) {
        return this.range.to <= t.doc.length ? this : new Nt(S.cursor(t.doc.length), this.y, this.x, this.yMargin, this.xMargin, this.isSnapshot)
    }
}
const Se = F.define({
        map: (n, t) => n.map(t)
    }),
    zn = F.define();

function ht(n, t, e) {
    let i = n.facet(Nn);
    i.length ? i[0](t) : window.onerror ? window.onerror(String(t), e, void 0, void 0, t) : e ? console.error(e + ":", t) : console.error(t)
}
const pt = C.define({
    combine: n => n.length ? n[0] : !0
});
let lo = 0;
const Ut = C.define();
class nt {
    constructor(t, e, i, s, r) {
        this.id = t, this.create = e, this.domEventHandlers = i, this.domEventObservers = s, this.extension = r(this)
    }
    static define(t, e) {
        const {
            eventHandlers: i,
            eventObservers: s,
            provide: r,
            decorations: o
        } = e || {};
        return new nt(lo++, t, i, s, l => {
            let h = [Ut.of(l)];
            return o && h.push(fe.of(f => {
                let a = f.plugin(l);
                return a ? o(a) : V.none
            })), r && h.push(r(l)), h
        })
    }
    static fromClass(t, e) {
        return nt.define(i => new t(i), e)
    }
}
class Xe {
    constructor(t) {
        this.spec = t, this.mustUpdate = null, this.value = null
    }
    update(t) {
        if (this.value) {
            if (this.mustUpdate) {
                let e = this.mustUpdate;
                if (this.mustUpdate = null, this.value.update) try {
                    this.value.update(e)
                } catch (i) {
                    if (ht(e.state, i, "CodeMirror plugin crashed"), this.value.destroy) try {
                        this.value.destroy()
                    } catch (s) {}
                    this.deactivate()
                }
            }
        } else if (this.spec) try {
            this.value = this.spec.create(t)
        } catch (e) {
            ht(t.state, e, "CodeMirror plugin crashed"), this.deactivate()
        }
        return this
    }
    destroy(t) {
        var e;
        if (!((e = this.value) === null || e === void 0) && e.destroy) try {
            this.value.destroy()
        } catch (i) {
            ht(t.state, i, "CodeMirror plugin crashed")
        }
    }
    deactivate() {
        this.spec = this.value = null
    }
}
const qn = C.define(),
    ji = C.define(),
    fe = C.define(),
    Kn = C.define(),
    $i = C.define(),
    jn = C.define();

function us(n, t) {
    let e = n.state.facet(jn);
    if (!e.length) return e;
    let i = e.map(r => r instanceof Function ? r(n) : r),
        s = [];
    return A.spans(i, t.from, t.to, {
        point() {},
        span(r, o, l, h) {
            let f = r - t.from,
                a = o - t.from,
                c = s;
            for (let u = l.length - 1; u >= 0; u--, h--) {
                let d = l[u].spec.bidiIsolate,
                    g;
                if (d == null && (d = oo(t.text, f, a)), h > 0 && c.length && (g = c[c.length - 1]).to == f && g.direction == d) g.to = a, c = g.inner;
                else {
                    let m = {
                        from: f,
                        to: a,
                        direction: d,
                        inner: []
                    };
                    c.push(m), c = m.inner
                }
            }
        }
    }), s
}
const $n = C.define();

function Gn(n) {
    let t = 0,
        e = 0,
        i = 0,
        s = 0;
    for (let r of n.state.facet($n)) {
        let o = r(n);
        o && (o.left != null && (t = Math.max(t, o.left)), o.right != null && (e = Math.max(e, o.right)), o.top != null && (i = Math.max(i, o.top)), o.bottom != null && (s = Math.max(s, o.bottom)))
    }
    return {
        left: t,
        right: e,
        top: i,
        bottom: s
    }
}
const Jt = C.define();
class J {
    constructor(t, e, i, s) {
        this.fromA = t, this.toA = e, this.fromB = i, this.toB = s
    }
    join(t) {
        return new J(Math.min(this.fromA, t.fromA), Math.max(this.toA, t.toA), Math.min(this.fromB, t.fromB), Math.max(this.toB, t.toB))
    }
    addToSet(t) {
        let e = t.length,
            i = this;
        for (; e > 0; e--) {
            let s = t[e - 1];
            if (!(s.fromA > i.toA)) {
                if (s.toA < i.fromA) break;
                i = i.join(s), t.splice(e - 1, 1)
            }
        }
        return t.splice(e, 0, i), t
    }
    static extendWithRanges(t, e) {
        if (e.length == 0) return t;
        let i = [];
        for (let s = 0, r = 0, o = 0, l = 0;; s++) {
            let h = s == t.length ? null : t[s],
                f = o - l,
                a = h ? h.fromB : 1e9;
            for (; r < e.length && e[r] < a;) {
                let c = e[r],
                    u = e[r + 1],
                    d = Math.max(l, c),
                    g = Math.min(a, u);
                if (d <= g && new J(d + f, g + f, d, g).addToSet(i), u > a) break;
                r += 2
            }
            if (!h) return i;
            new J(h.fromA, h.toA, h.fromB, h.toB).addToSet(i), o = h.toA, l = h.toB
        }
    }
}
class ze {
    constructor(t, e, i) {
        this.view = t, this.state = e, this.transactions = i, this.flags = 0, this.startState = t.state, this.changes = H.empty(this.startState.doc.length);
        for (let r of i) this.changes = this.changes.compose(r.changes);
        let s = [];
        this.changes.iterChangedRanges((r, o, l, h) => s.push(new J(r, o, l, h))), this.changedRanges = s
    }
    static create(t, e, i) {
        return new ze(t, e, i)
    }
    get viewportChanged() {
        return (this.flags & 4) > 0
    }
    get heightChanged() {
        return (this.flags & 2) > 0
    }
    get geometryChanged() {
        return this.docChanged || (this.flags & 10) > 0
    }
    get focusChanged() {
        return (this.flags & 1) > 0
    }
    get docChanged() {
        return !this.changes.empty
    }
    get selectionSet() {
        return this.transactions.some(t => t.selection)
    }
    get empty() {
        return this.flags == 0 && this.transactions.length == 0
    }
}
class ds extends R {
    get length() {
        return this.view.state.doc.length
    }
    constructor(t) {
        super(), this.view = t, this.decorations = [], this.dynamicDecorationMap = [!1], this.domChanged = null, this.hasComposition = null, this.markedForComposition = new Set, this.editContextFormatting = V.none, this.lastCompositionAfterCursor = !1, this.minWidth = 0, this.minWidthFrom = 0, this.minWidthTo = 0, this.impreciseAnchor = null, this.impreciseHead = null, this.forceSelection = !1, this.lastUpdate = Date.now(), this.setDOM(t.contentDOM), this.children = [new N], this.children[0].setParent(this), this.updateDeco(), this.updateInner([new J(0, 0, 0, t.state.doc.length)], 0, null)
    }
    update(t) {
        var e;
        let i = t.changedRanges;
        this.minWidth > 0 && i.length && (i.every(({
            fromA: f,
            toA: a
        }) => a < this.minWidthFrom || f > this.minWidthTo) ? (this.minWidthFrom = t.changes.mapPos(this.minWidthFrom, 1), this.minWidthTo = t.changes.mapPos(this.minWidthTo, 1)) : this.minWidth = this.minWidthFrom = this.minWidthTo = 0), this.updateEditContextFormatting(t);
        let s = -1;
        this.view.inputState.composing >= 0 && !this.view.observer.editContext && (!((e = this.domChanged) === null || e === void 0) && e.newSel ? s = this.domChanged.newSel.head : !po(t.changes, this.hasComposition) && !t.selectionSet && (s = t.state.selection.main.head));
        let r = s > -1 ? ao(this.view, t.changes, s) : null;
        if (this.domChanged = null, this.hasComposition) {
            this.markedForComposition.clear();
            let {
                from: f,
                to: a
            } = this.hasComposition;
            i = new J(f, a, t.changes.mapPos(f, -1), t.changes.mapPos(a, 1)).addToSet(i.slice())
        }
        this.hasComposition = r ? {
            from: r.range.fromB,
            to: r.range.toB
        } : null, (b.ie || b.chrome) && !r && t && t.state.doc.lines != t.startState.doc.lines && (this.forceSelection = !0);
        let o = this.decorations,
            l = this.updateDeco(),
            h = uo(o, l, t.changes);
        return i = J.extendWithRanges(i, h), !(this.flags & 7) && i.length == 0 ? !1 : (this.updateInner(i, t.startState.doc.length, r), t.transactions.length && (this.lastUpdate = Date.now()), !0)
    }
    updateInner(t, e, i) {
        this.view.viewState.mustMeasureContent = !0, this.updateChildren(t, e, i);
        let {
            observer: s
        } = this.view;
        s.ignore(() => {
            this.dom.style.height = this.view.viewState.contentHeight / this.view.scaleY + "px", this.dom.style.flexBasis = this.minWidth ? this.minWidth + "px" : "";
            let o = b.chrome || b.ios ? {
                node: s.selectionRange.focusNode,
                written: !1
            } : void 0;
            this.sync(this.view, o), this.flags &= -8, o && (o.written || s.selectionRange.focusNode != o.node) && (this.forceSelection = !0), this.dom.style.height = ""
        }), this.markedForComposition.forEach(o => o.flags &= -9);
        let r = [];
        if (this.view.viewport.from || this.view.viewport.to < this.view.state.doc.length)
            for (let o of this.children) o instanceof ft && o.widget instanceof gs && r.push(o.dom);
        s.updateGaps(r)
    }
    updateChildren(t, e, i) {
        let s = i ? i.range.addToSet(t.slice()) : t,
            r = this.childCursor(e);
        for (let o = s.length - 1;; o--) {
            let l = o >= 0 ? s[o] : null;
            if (!l) break;
            let {
                fromA: h,
                toA: f,
                fromB: a,
                toB: c
            } = l, u, d, g, m;
            if (i && i.range.fromB < c && i.range.toB > a) {
                let x = se.build(this.view.state.doc, a, i.range.fromB, this.decorations, this.dynamicDecorationMap),
                    k = se.build(this.view.state.doc, i.range.toB, c, this.decorations, this.dynamicDecorationMap);
                d = x.breakAtStart, g = x.openStart, m = k.openEnd;
                let M = this.compositionView(i);
                k.breakAtStart ? M.breakAfter = 1 : k.content.length && M.merge(M.length, M.length, k.content[0], !1, k.openStart, 0) && (M.breakAfter = k.content[0].breakAfter, k.content.shift()), x.content.length && M.merge(0, 0, x.content[x.content.length - 1], !0, 0, x.openEnd) && x.content.pop(), u = x.content.concat(M).concat(k.content)
            } else({
                content: u,
                breakAtStart: d,
                openStart: g,
                openEnd: m
            } = se.build(this.view.state.doc, a, c, this.decorations, this.dynamicDecorationMap));
            let {
                i: p,
                off: w
            } = r.findPos(f, 1), {
                i: y,
                off: v
            } = r.findPos(h, -1);
            yn(this, y, v, p, w, u, d, g, m)
        }
        i && this.fixCompositionDOM(i)
    }
    updateEditContextFormatting(t) {
        this.editContextFormatting = this.editContextFormatting.map(t.changes);
        for (let e of t.transactions)
            for (let i of e.effects) i.is(zn) && (this.editContextFormatting = i.value)
    }
    compositionView(t) {
        let e = new Z(t.text.nodeValue);
        e.flags |= 8;
        for (let {
                deco: s
            } of t.marks) e = new ut(s, [e], e.length);
        let i = new N;
        return i.append(e, 0), i
    }
    fixCompositionDOM(t) {
        let e = (r, o) => {
                o.flags |= 8 | (o.children.some(h => h.flags & 7) ? 1 : 0), this.markedForComposition.add(o);
                let l = R.get(r);
                l && l != o && (l.dom = null), o.setDOM(r)
            },
            i = this.childPos(t.range.fromB, 1),
            s = this.children[i.i];
        e(t.line, s);
        for (let r = t.marks.length - 1; r >= -1; r--) i = s.childPos(i.off, 1), s = s.children[i.i], e(r >= 0 ? t.marks[r].node : t.text, s)
    }
    updateSelection(t = !1, e = !1) {
        (t || !this.view.observer.selectionRange.focusNode) && this.view.observer.readSelectionRange();
        let i = this.view.root.activeElement,
            s = i == this.dom,
            r = !s && Ee(this.dom, this.view.observer.selectionRange) && !(i && this.dom.contains(i));
        if (!(s || e || r)) return;
        let o = this.forceSelection;
        this.forceSelection = !1;
        let l = this.view.state.selection.main,
            h = this.moveToLine(this.domAtPos(l.anchor)),
            f = l.empty ? h : this.moveToLine(this.domAtPos(l.head));
        if (b.gecko && l.empty && !this.hasComposition && ho(h)) {
            let c = document.createTextNode("");
            this.view.observer.ignore(() => h.node.insertBefore(c, h.node.childNodes[h.offset] || null)), h = f = new K(c, 0), o = !0
        }
        let a = this.view.observer.selectionRange;
        (o || !a.focusNode || (!ie(h.node, h.offset, a.anchorNode, a.anchorOffset) || !ie(f.node, f.offset, a.focusNode, a.focusOffset)) && !this.suppressWidgetCursorChange(a, l)) && (this.view.observer.ignore(() => {
            b.android && b.chrome && this.dom.contains(a.focusNode) && go(a.focusNode, this.dom) && (this.dom.blur(), this.dom.focus({
                preventScroll: !0
            }));
            let c = ae(this.view.root);
            if (c)
                if (l.empty) {
                    if (b.gecko) {
                        let u = fo(h.node, h.offset);
                        if (u && u != 3) {
                            let d = (u == 1 ? mn : wn)(h.node, h.offset);
                            d && (h = new K(d.node, d.offset))
                        }
                    }
                    c.collapse(h.node, h.offset), l.bidiLevel != null && c.caretBidiLevel !== void 0 && (c.caretBidiLevel = l.bidiLevel)
                } else if (c.extend) {
                c.collapse(h.node, h.offset);
                try {
                    c.extend(f.node, f.offset)
                } catch (u) {}
            } else {
                let u = document.createRange();
                l.anchor > l.head && ([h, f] = [f, h]), u.setEnd(f.node, f.offset), u.setStart(h.node, h.offset), c.removeAllRanges(), c.addRange(u)
            }
            r && this.view.root.activeElement == this.dom && (this.dom.blur(), i && i.focus())
        }), this.view.observer.setSelectionRange(h, f)), this.impreciseAnchor = h.precise ? null : new K(a.anchorNode, a.anchorOffset), this.impreciseHead = f.precise ? null : new K(a.focusNode, a.focusOffset)
    }
    suppressWidgetCursorChange(t, e) {
        return this.hasComposition && e.empty && ie(t.focusNode, t.focusOffset, t.anchorNode, t.anchorOffset) && this.posFromDOM(t.focusNode, t.focusOffset) == e.head
    }
    enforceCursorAssoc() {
        if (this.hasComposition) return;
        let {
            view: t
        } = this, e = t.state.selection.main, i = ae(t.root), {
            anchorNode: s,
            anchorOffset: r
        } = t.observer.selectionRange;
        if (!i || !e.empty || !e.assoc || !i.modify) return;
        let o = N.find(this, e.head);
        if (!o) return;
        let l = o.posAtStart;
        if (e.head == l || e.head == l + o.length) return;
        let h = this.coordsAt(e.head, -1),
            f = this.coordsAt(e.head, 1);
        if (!h || !f || h.bottom > f.top) return;
        let a = this.domAtPos(e.head + e.assoc);
        i.collapse(a.node, a.offset), i.modify("move", e.assoc < 0 ? "forward" : "backward", "lineboundary"), t.observer.readSelectionRange();
        let c = t.observer.selectionRange;
        t.docView.posFromDOM(c.anchorNode, c.anchorOffset) != e.from && i.collapse(s, r)
    }
    moveToLine(t) {
        let e = this.dom,
            i;
        if (t.node != e) return t;
        for (let s = t.offset; !i && s < e.childNodes.length; s++) {
            let r = R.get(e.childNodes[s]);
            r instanceof N && (i = r.domAtPos(0))
        }
        for (let s = t.offset - 1; !i && s >= 0; s--) {
            let r = R.get(e.childNodes[s]);
            r instanceof N && (i = r.domAtPos(r.length))
        }
        return i ? new K(i.node, i.offset, !0) : t
    }
    nearest(t) {
        for (let e = t; e;) {
            let i = R.get(e);
            if (i && i.rootView == this) return i;
            e = e.parentNode
        }
        return null
    }
    posFromDOM(t, e) {
        let i = this.nearest(t);
        if (!i) throw new RangeError("Trying to find position for a DOM position outside of the document");
        return i.localPosFromDOM(t, e) + i.posAtStart
    }
    domAtPos(t) {
        let {
            i: e,
            off: i
        } = this.childCursor().findPos(t, -1);
        for (; e < this.children.length - 1;) {
            let s = this.children[e];
            if (i < s.length || s instanceof N) break;
            e++, i = 0
        }
        return this.children[e].domAtPos(i)
    }
    coordsAt(t, e) {
        let i = null,
            s = 0;
        for (let r = this.length, o = this.children.length - 1; o >= 0; o--) {
            let l = this.children[o],
                h = r - l.breakAfter,
                f = h - l.length;
            if (h < t) break;
            if (f <= t && (f < t || l.covers(-1)) && (h > t || l.covers(1)) && (!i || l instanceof N && !(i instanceof N && e >= 0))) i = l, s = f;
            else if (i && f == t && h == t && l instanceof ft && Math.abs(e) < 2) {
                if (l.deco.startSide < 0) break;
                o && (i = null)
            }
            r = f
        }
        return i ? i.coordsAt(t - s, e) : null
    }
    coordsForChar(t) {
        let {
            i: e,
            off: i
        } = this.childPos(t, 1), s = this.children[e];
        if (!(s instanceof N)) return null;
        for (; s.children.length;) {
            let {
                i: l,
                off: h
            } = s.childPos(i, 1);
            for (;; l++) {
                if (l == s.children.length) return null;
                if ((s = s.children[l]).length) break
            }
            i = h
        }
        if (!(s instanceof Z)) return null;
        let r = st(s.text, i);
        if (r == i) return null;
        let o = Ot(s.dom, i, r).getClientRects();
        for (let l = 0; l < o.length; l++) {
            let h = o[l];
            if (l == o.length - 1 || h.top < h.bottom && h.left < h.right) return h
        }
        return null
    }
    measureVisibleLineHeights(t) {
        let e = [],
            {
                from: i,
                to: s
            } = t,
            r = this.view.contentDOM.clientWidth,
            o = r > Math.max(this.view.scrollDOM.clientWidth, this.minWidth) + 1,
            l = -1,
            h = this.view.textDirection == I.LTR;
        for (let f = 0, a = 0; a < this.children.length; a++) {
            let c = this.children[a],
                u = f + c.length;
            if (u > s) break;
            if (f >= i) {
                let d = c.dom.getBoundingClientRect();
                if (e.push(d.height), o) {
                    let g = c.dom.lastChild,
                        m = g ? Ft(g) : [];
                    if (m.length) {
                        let p = m[m.length - 1],
                            w = h ? p.right - d.left : d.right - p.left;
                        w > l && (l = w, this.minWidth = r, this.minWidthFrom = f, this.minWidthTo = u)
                    }
                }
            }
            f = u + c.breakAfter
        }
        return e
    }
    textDirectionAt(t) {
        let {
            i: e
        } = this.childPos(t, 1);
        return getComputedStyle(this.children[e].dom).direction == "rtl" ? I.RTL : I.LTR
    }
    measureTextSize() {
        for (let r of this.children)
            if (r instanceof N) {
                let o = r.measureTextSize();
                if (o) return o
            }
        let t = document.createElement("div"),
            e, i, s;
        return t.className = "cm-line", t.style.width = "99999px", t.style.position = "absolute", t.textContent = "abc def ghi jkl mno pqr stu", this.view.observer.ignore(() => {
            this.dom.appendChild(t);
            let r = Ft(t.firstChild)[0];
            e = t.getBoundingClientRect().height, i = r ? r.width / 27 : 7, s = r ? r.height : e, t.remove()
        }), {
            lineHeight: e,
            charWidth: i,
            textHeight: s
        }
    }
    childCursor(t = this.length) {
        let e = this.children.length;
        return e && (t -= this.children[--e].length), new bn(this.children, t, e)
    }
    computeBlockGapDeco() {
        let t = [],
            e = this.view.viewState;
        for (let i = 0, s = 0;; s++) {
            let r = s == e.viewports.length ? null : e.viewports[s],
                o = r ? r.from - 1 : this.length;
            if (o > i) {
                let l = (e.lineBlockAt(o).bottom - e.lineBlockAt(i).top) / this.view.scaleY;
                t.push(V.replace({
                    widget: new gs(l),
                    block: !0,
                    inclusive: !0,
                    isBlockGap: !0
                }).range(i, o))
            }
            if (!r) break;
            i = r.to + 1
        }
        return V.set(t)
    }
    updateDeco() {
        let t = 1,
            e = this.view.state.facet(fe).map(r => (this.dynamicDecorationMap[t++] = typeof r == "function") ? r(this.view) : r),
            i = !1,
            s = this.view.state.facet(Kn).map((r, o) => {
                let l = typeof r == "function";
                return l && (i = !0), l ? r(this.view) : r
            });
        for (s.length && (this.dynamicDecorationMap[t++] = i, e.push(A.join(s))), this.decorations = [this.editContextFormatting, ...e, this.computeBlockGapDeco(), this.view.viewState.lineGapDeco]; t < this.decorations.length;) this.dynamicDecorationMap[t++] = !1;
        return this.decorations
    }
    scrollIntoView(t) {
        if (t.isSnapshot) {
            let f = this.view.viewState.lineBlockAt(t.range.head);
            this.view.scrollDOM.scrollTop = f.top - t.yMargin, this.view.scrollDOM.scrollLeft = t.xMargin;
            return
        }
        for (let f of this.view.state.facet(Wn)) try {
            if (f(this.view, t.range, t)) return !0
        } catch (a) {
            ht(this.view.state, a, "scroll handler")
        }
        let {
            range: e
        } = t, i = this.coordsAt(e.head, e.empty ? e.assoc : e.head > e.anchor ? -1 : 1), s;
        if (!i) return;
        !e.empty && (s = this.coordsAt(e.anchor, e.anchor > e.head ? -1 : 1)) && (i = {
            left: Math.min(i.left, s.left),
            top: Math.min(i.top, s.top),
            right: Math.max(i.right, s.right),
            bottom: Math.max(i.bottom, s.bottom)
        });
        let r = Gn(this.view),
            o = {
                left: i.left - r.left,
                top: i.top - r.top,
                right: i.right + r.right,
                bottom: i.bottom + r.bottom
            },
            {
                offsetWidth: l,
                offsetHeight: h
            } = this.view.scrollDOM;
        zr(this.view.scrollDOM, o, e.head < e.anchor ? -1 : 1, t.x, t.y, Math.max(Math.min(t.xMargin, l), -l), Math.max(Math.min(t.yMargin, h), -h), this.view.textDirection == I.LTR)
    }
}

function ho(n) {
    return n.node.nodeType == 1 && n.node.firstChild && (n.offset == 0 || n.node.childNodes[n.offset - 1].contentEditable == "false") && (n.offset == n.node.childNodes.length || n.node.childNodes[n.offset].contentEditable == "false")
}
class gs extends jt {
    constructor(t) {
        super(), this.height = t
    }
    toDOM() {
        let t = document.createElement("div");
        return t.className = "cm-gap", this.updateDOM(t), t
    }
    eq(t) {
        return t.height == this.height
    }
    updateDOM(t) {
        return t.style.height = this.height + "px", !0
    }
    get editable() {
        return !0
    }
    get estimatedHeight() {
        return this.height
    }
    ignoreEvent() {
        return !1
    }
}

function Yn(n, t) {
    let e = n.observer.selectionRange;
    if (!e.focusNode) return null;
    let i = mn(e.focusNode, e.focusOffset),
        s = wn(e.focusNode, e.focusOffset),
        r = i || s;
    if (s && i && s.node != i.node) {
        let l = R.get(s.node);
        if (!l || l instanceof Z && l.text != s.node.nodeValue) r = s;
        else if (n.docView.lastCompositionAfterCursor) {
            let h = R.get(i.node);
            !h || h instanceof Z && h.text != i.node.nodeValue || (r = s)
        }
    }
    if (n.docView.lastCompositionAfterCursor = r != i, !r) return null;
    let o = t - r.offset;
    return {
        from: o,
        to: o + r.node.nodeValue.length,
        node: r.node
    }
}

function ao(n, t, e) {
    let i = Yn(n, e);
    if (!i) return null;
    let {
        node: s,
        from: r,
        to: o
    } = i, l = s.nodeValue;
    if (/[\n\r]/.test(l) || n.state.doc.sliceString(i.from, i.to) != l) return null;
    let h = t.invertedDesc,
        f = new J(h.mapPos(r), h.mapPos(o), r, o),
        a = [];
    for (let c = s.parentNode;; c = c.parentNode) {
        let u = R.get(c);
        if (u instanceof ut) a.push({
            node: c,
            deco: u.mark
        });
        else {
            if (u instanceof N || c.nodeName == "DIV" && c.parentNode == n.contentDOM) return {
                range: f,
                text: s,
                marks: a,
                line: c
            };
            if (c != n.contentDOM) a.push({
                node: c,
                deco: new ue({
                    inclusive: !0,
                    attributes: Jr(c),
                    tagName: c.tagName.toLowerCase()
                })
            });
            else return null
        }
    }
}

function fo(n, t) {
    return n.nodeType != 1 ? 0 : (t && n.childNodes[t - 1].contentEditable == "false" ? 1 : 0) | (t < n.childNodes.length && n.childNodes[t].contentEditable == "false" ? 2 : 0)
}
let co = class {
    constructor() {
        this.changes = []
    }
    compareRange(t, e) {
        vi(t, e, this.changes)
    }
    comparePoint(t, e) {
        vi(t, e, this.changes)
    }
};

function uo(n, t, e) {
    let i = new co;
    return A.compare(n, t, e, i), i.changes
}

function go(n, t) {
    for (let e = n; e && e != t; e = e.assignedSlot || e.parentNode)
        if (e.nodeType == 1 && e.contentEditable == "false") return !0;
    return !1
}

function po(n, t) {
    let e = !1;
    return t && n.iterChangedRanges((i, s) => {
        i < t.to && s > t.from && (e = !0)
    }), e
}

function mo(n, t, e = 1) {
    let i = n.charCategorizer(t),
        s = n.doc.lineAt(t),
        r = t - s.from;
    if (s.length == 0) return S.cursor(t);
    r == 0 ? e = 1 : r == s.length && (e = -1);
    let o = r,
        l = r;
    e < 0 ? o = st(s.text, r, !1) : l = st(s.text, r);
    let h = i(s.text.slice(o, l));
    for (; o > 0;) {
        let f = st(s.text, o, !1);
        if (i(s.text.slice(f, o)) != h) break;
        o = f
    }
    for (; l < s.length;) {
        let f = st(s.text, l);
        if (i(s.text.slice(l, f)) != h) break;
        l = f
    }
    return S.range(o + s.from, l + s.from)
}

function wo(n, t) {
    return t.left > n ? t.left - n : Math.max(0, n - t.right)
}

function bo(n, t) {
    return t.top > n ? t.top - n : Math.max(0, n - t.bottom)
}

function Ue(n, t) {
    return n.top < t.bottom - 1 && n.bottom > t.top + 1
}

function ps(n, t) {
    return t < n.top ? {
        top: t,
        left: n.left,
        right: n.right,
        bottom: n.bottom
    } : n
}

function ms(n, t) {
    return t > n.bottom ? {
        top: n.top,
        left: n.left,
        right: n.right,
        bottom: t
    } : n
}

function Oi(n, t, e) {
    let i, s, r, o, l = !1,
        h, f, a, c;
    for (let g = n.firstChild; g; g = g.nextSibling) {
        let m = Ft(g);
        for (let p = 0; p < m.length; p++) {
            let w = m[p];
            s && Ue(s, w) && (w = ps(ms(w, s.bottom), s.top));
            let y = wo(t, w),
                v = bo(e, w);
            if (y == 0 && v == 0) return g.nodeType == 3 ? ws(g, t, e) : Oi(g, t, e);
            if (!i || o > v || o == v && r > y) {
                i = g, s = w, r = y, o = v;
                let x = v ? e < w.top ? -1 : 1 : y ? t < w.left ? -1 : 1 : 0;
                l = !x || (x > 0 ? p < m.length - 1 : p > 0)
            }
            y == 0 ? e > w.bottom && (!a || a.bottom < w.bottom) ? (h = g, a = w) : e < w.top && (!c || c.top > w.top) && (f = g, c = w) : a && Ue(a, w) ? a = ms(a, w.bottom) : c && Ue(c, w) && (c = ps(c, w.top))
        }
    }
    if (a && a.bottom >= e ? (i = h, s = a) : c && c.top <= e && (i = f, s = c), !i) return {
        node: n,
        offset: 0
    };
    let u = Math.max(s.left, Math.min(s.right, t));
    if (i.nodeType == 3) return ws(i, u, e);
    if (l && i.contentEditable != "false") return Oi(i, u, e);
    let d = Array.prototype.indexOf.call(n.childNodes, i) + (t >= (s.left + s.right) / 2 ? 1 : 0);
    return {
        node: n,
        offset: d
    }
}

function ws(n, t, e) {
    let i = n.nodeValue.length,
        s = -1,
        r = 1e9,
        o = 0;
    for (let l = 0; l < i; l++) {
        let h = Ot(n, l, l + 1).getClientRects();
        for (let f = 0; f < h.length; f++) {
            let a = h[f];
            if (a.top == a.bottom) continue;
            o || (o = t - a.left);
            let c = (a.top > e ? a.top - e : e - a.bottom) - 1;
            if (a.left - 1 <= t && a.right + 1 >= t && c < r) {
                let u = t >= (a.left + a.right) / 2,
                    d = u;
                if ((b.chrome || b.gecko) && Ot(n, l).getBoundingClientRect().left == a.right && (d = !u), c <= 0) return {
                    node: n,
                    offset: l + (d ? 1 : 0)
                };
                s = l + (d ? 1 : 0), r = c
            }
        }
    }
    return {
        node: n,
        offset: s > -1 ? s : o > 0 ? n.nodeValue.length : 0
    }
}

function Xn(n, t, e, i = -1) {
    var s, r;
    let o = n.contentDOM.getBoundingClientRect(),
        l = o.top + n.viewState.paddingTop,
        h, {
            docHeight: f
        } = n.viewState,
        {
            x: a,
            y: c
        } = t,
        u = c - l;
    if (u < 0) return 0;
    if (u > f) return n.state.doc.length;
    for (let x = n.viewState.heightOracle.textHeight / 2, k = !1; h = n.elementAtHeight(u), h.type != $.Text;)
        for (; u = i > 0 ? h.bottom + x : h.top - x, !(u >= 0 && u <= f);) {
            if (k) return e ? null : 0;
            k = !0, i = -i
        }
    c = l + u;
    let d = h.from;
    if (d < n.viewport.from) return n.viewport.from == 0 ? 0 : e ? null : bs(n, o, h, a, c);
    if (d > n.viewport.to) return n.viewport.to == n.state.doc.length ? n.state.doc.length : e ? null : bs(n, o, h, a, c);
    let g = n.dom.ownerDocument,
        m = n.root.elementFromPoint ? n.root : g,
        p = m.elementFromPoint(a, c);
    p && !n.contentDOM.contains(p) && (p = null), p || (a = Math.max(o.left + 1, Math.min(o.right - 1, a)), p = m.elementFromPoint(a, c), p && !n.contentDOM.contains(p) && (p = null));
    let w, y = -1;
    if (p && ((s = n.docView.nearest(p)) === null || s === void 0 ? void 0 : s.isEditable) != !1) {
        if (g.caretPositionFromPoint) {
            let x = g.caretPositionFromPoint(a, c);
            x && ({
                offsetNode: w,
                offset: y
            } = x)
        } else if (g.caretRangeFromPoint) {
            let x = g.caretRangeFromPoint(a, c);
            x && ({
                startContainer: w,
                startOffset: y
            } = x, (!n.contentDOM.contains(w) || b.safari && yo(w, y, a) || b.chrome && xo(w, y, a)) && (w = void 0))
        }
    }
    if (!w || !n.docView.dom.contains(w)) {
        let x = N.find(n.docView, d);
        if (!x) return u > h.top + h.height / 2 ? h.to : h.from;
        ({
            node: w,
            offset: y
        } = Oi(x.dom, a, c))
    }
    let v = n.docView.nearest(w);
    if (!v) return null;
    if (v.isWidget && ((r = v.dom) === null || r === void 0 ? void 0 : r.nodeType) == 1) {
        let x = v.dom.getBoundingClientRect();
        return t.y < x.top || t.y <= x.bottom && t.x <= (x.left + x.right) / 2 ? v.posAtStart : v.posAtEnd
    } else return v.localPosFromDOM(w, y) + v.posAtStart
}

function bs(n, t, e, i, s) {
    let r = Math.round((i - t.left) * n.defaultCharacterWidth);
    if (n.lineWrapping && e.height > n.defaultLineHeight * 1.5) {
        let l = n.viewState.heightOracle.textHeight,
            h = Math.floor((s - e.top - (n.defaultLineHeight - l) * .5) / l);
        r += h * n.viewState.heightOracle.lineLength
    }
    let o = n.state.sliceDoc(e.from, e.to);
    return e.from + Ir(o, r, n.state.tabSize)
}

function yo(n, t, e) {
    let i;
    if (n.nodeType != 3 || t != (i = n.nodeValue.length)) return !1;
    for (let s = n.nextSibling; s; s = s.nextSibling)
        if (s.nodeType != 1 || s.nodeName != "BR") return !1;
    return Ot(n, i - 1, i).getBoundingClientRect().left > e
}

function xo(n, t, e) {
    if (t != 0) return !1;
    for (let s = n;;) {
        let r = s.parentNode;
        if (!r || r.nodeType != 1 || r.firstChild != s) return !1;
        if (r.classList.contains("cm-line")) break;
        s = r
    }
    let i = n.nodeType == 1 ? n.getBoundingClientRect() : Ot(n, 0, Math.max(n.nodeValue.length, 1)).getBoundingClientRect();
    return e - i.left > 5
}

function Di(n, t) {
    let e = n.lineBlockAt(t);
    if (Array.isArray(e.type)) {
        for (let i of e.type)
            if (i.to > t || i.to == t && (i.to == e.to || i.type == $.Text)) return i
    }
    return e
}

function So(n, t, e, i) {
    let s = Di(n, t.head),
        r = !i || s.type != $.Text || !(n.lineWrapping || s.widgetLineBreaks) ? null : n.coordsAtPos(t.assoc < 0 && t.head > s.from ? t.head - 1 : t.head);
    if (r) {
        let o = n.dom.getBoundingClientRect(),
            l = n.textDirectionAt(s.from),
            h = n.posAtCoords({
                x: e == (l == I.LTR) ? o.right - 1 : o.left + 1,
                y: (r.top + r.bottom) / 2
            });
        if (h != null) return S.cursor(h, e ? -1 : 1)
    }
    return S.cursor(e ? s.to : s.from, e ? -1 : 1)
}

function ys(n, t, e, i) {
    let s = n.state.doc.lineAt(t.head),
        r = n.bidiSpans(s),
        o = n.textDirectionAt(s.from);
    for (let l = t, h = null;;) {
        let f = ro(s, r, o, l, e),
            a = En;
        if (!f) {
            if (s.number == (e ? n.state.doc.lines : 1)) return l;
            a = "\n", s = n.state.doc.line(s.number + (e ? 1 : -1)), r = n.bidiSpans(s), f = n.visualLineSide(s, !e)
        }
        if (h) {
            if (!h(a)) return l
        } else {
            if (!i) return f;
            h = i(a)
        }
        l = f
    }
}

function vo(n, t, e) {
    let i = n.state.charCategorizer(t),
        s = i(e);
    return r => {
        let o = i(r);
        return s == lt.Space && (s = o), s == o
    }
}

function ko(n, t, e, i) {
    let s = t.head,
        r = e ? 1 : -1;
    if (s == (e ? n.state.doc.length : 0)) return S.cursor(s, t.assoc);
    let o = t.goalColumn,
        l, h = n.contentDOM.getBoundingClientRect(),
        f = n.coordsAtPos(s, t.assoc || -1),
        a = n.documentTop;
    if (f) o == null && (o = f.left - h.left), l = r < 0 ? f.top : f.bottom;
    else {
        let d = n.viewState.lineBlockAt(s);
        o == null && (o = Math.min(h.right - h.left, n.defaultCharacterWidth * (s - d.from))), l = (r < 0 ? d.top : d.bottom) + a
    }
    let c = h.left + o,
        u = i != null ? i : n.viewState.heightOracle.textHeight >> 1;
    for (let d = 0;; d += 10) {
        let g = l + (u + d) * r,
            m = Xn(n, {
                x: c,
                y: g
            }, !1, r);
        if (g < h.top || g > h.bottom || (r < 0 ? m < s : m > s)) {
            let p = n.docView.coordsForChar(m),
                w = !p || g < p.top ? -1 : 1;
            return S.cursor(m, w, void 0, o)
        }
    }
}

function Be(n, t, e) {
    for (;;) {
        let i = 0;
        for (let s of n) s.between(t - 1, t + 1, (r, o, l) => {
            if (t > r && t < o) {
                let h = i || e || (t - r < o - t ? -1 : 1);
                t = h < 0 ? r : o, i = h
            }
        });
        if (!i) return t
    }
}

function Je(n, t, e) {
    let i = Be(n.state.facet($i).map(s => s(n)), e.from, t.head > e.from ? -1 : 1);
    return i == e.from ? e : S.cursor(i, i < e.from ? 1 : -1)
}
class Co {
    setSelectionOrigin(t) {
        this.lastSelectionOrigin = t, this.lastSelectionTime = Date.now()
    }
    constructor(t) {
        this.view = t, this.lastKeyCode = 0, this.lastKeyTime = 0, this.lastTouchTime = 0, this.lastFocusTime = 0, this.lastScrollTop = 0, this.lastScrollLeft = 0, this.pendingIOSKey = void 0, this.tabFocusMode = -1, this.lastSelectionOrigin = null, this.lastSelectionTime = 0, this.lastContextMenu = 0, this.scrollHandlers = [], this.handlers = Object.create(null), this.composing = -1, this.compositionFirstChange = null, this.compositionEndedAt = 0, this.compositionPendingKey = !1, this.compositionPendingChange = !1, this.mouseSelection = null, this.draggedContent = null, this.handleEvent = this.handleEvent.bind(this), this.notifiedFocused = t.hasFocus, b.safari && t.contentDOM.addEventListener("input", () => null), b.gecko && Wo(t.contentDOM.ownerDocument)
    }
    handleEvent(t) {
        !Bo(this.view, t) || this.ignoreDuringComposition(t) || t.type == "keydown" && this.keydown(t) || this.runHandlers(t.type, t)
    }
    runHandlers(t, e) {
        let i = this.handlers[t];
        if (i) {
            for (let s of i.observers) s(this.view, e);
            for (let s of i.handlers) {
                if (e.defaultPrevented) break;
                if (s(this.view, e)) {
                    e.preventDefault();
                    break
                }
            }
        }
    }
    ensureHandlers(t) {
        let e = Mo(t),
            i = this.handlers,
            s = this.view.contentDOM;
        for (let r in e)
            if (r != "scroll") {
                let o = !e[r].handlers.length,
                    l = i[r];
                l && o != !l.handlers.length && (s.removeEventListener(r, this.handleEvent), l = null), l || s.addEventListener(r, this.handleEvent, {
                    passive: o
                })
            }
        for (let r in i) r != "scroll" && !e[r] && s.removeEventListener(r, this.handleEvent);
        this.handlers = e
    }
    keydown(t) {
        if (this.lastKeyCode = t.keyCode, this.lastKeyTime = Date.now(), t.keyCode == 9 && this.tabFocusMode > -1 && (!this.tabFocusMode || Date.now() <= this.tabFocusMode)) return !0;
        if (this.tabFocusMode > 0 && t.keyCode != 27 && Jn.indexOf(t.keyCode) < 0 && (this.tabFocusMode = -1), b.android && b.chrome && !t.synthetic && (t.keyCode == 13 || t.keyCode == 8)) return this.view.observer.delayAndroidKey(t.key, t.keyCode), !0;
        let e;
        return b.ios && !t.synthetic && !t.altKey && !t.metaKey && ((e = Un.find(i => i.keyCode == t.keyCode)) && !t.ctrlKey || Ao.indexOf(t.key) > -1 && t.ctrlKey && !t.shiftKey) ? (this.pendingIOSKey = e || t, setTimeout(() => this.flushIOSKey(), 250), !0) : (t.keyCode != 229 && this.view.observer.forceFlush(), !1)
    }
    flushIOSKey(t) {
        let e = this.pendingIOSKey;
        return !e || e.key == "Enter" && t && t.from < t.to && /^\S+$/.test(t.insert.toString()) ? !1 : (this.pendingIOSKey = void 0, Lt(this.view.contentDOM, e.key, e.keyCode, e instanceof KeyboardEvent ? e : void 0))
    }
    ignoreDuringComposition(t) {
        return /^key/.test(t.type) ? this.composing > 0 ? !0 : b.safari && !b.ios && this.compositionPendingKey && Date.now() - this.compositionEndedAt < 100 ? (this.compositionPendingKey = !1, !0) : !1 : !1
    }
    startMouseSelection(t) {
        this.mouseSelection && this.mouseSelection.destroy(), this.mouseSelection = t
    }
    update(t) {
        this.view.observer.update(t), this.mouseSelection && this.mouseSelection.update(t), this.draggedContent && t.docChanged && (this.draggedContent = this.draggedContent.map(t.changes)), t.transactions.length && (this.lastKeyCode = this.lastSelectionTime = 0)
    }
    destroy() {
        this.mouseSelection && this.mouseSelection.destroy()
    }
}

function xs(n, t) {
    return (e, i) => {
        try {
            return t.call(n, i, e)
        } catch (s) {
            ht(e.state, s)
        }
    }
}

function Mo(n) {
    let t = Object.create(null);

    function e(i) {
        return t[i] || (t[i] = {
            observers: [],
            handlers: []
        })
    }
    for (let i of n) {
        let s = i.spec;
        if (s && s.domEventHandlers)
            for (let r in s.domEventHandlers) {
                let o = s.domEventHandlers[r];
                o && e(r).handlers.push(xs(i.value, o))
            }
        if (s && s.domEventObservers)
            for (let r in s.domEventObservers) {
                let o = s.domEventObservers[r];
                o && e(r).observers.push(xs(i.value, o))
            }
    }
    for (let i in _) e(i).handlers.push(_[i]);
    for (let i in Q) e(i).observers.push(Q[i]);
    return t
}
const Un = [{
        key: "Backspace",
        keyCode: 8,
        inputType: "deleteContentBackward"
    }, {
        key: "Enter",
        keyCode: 13,
        inputType: "insertParagraph"
    }, {
        key: "Enter",
        keyCode: 13,
        inputType: "insertLineBreak"
    }, {
        key: "Delete",
        keyCode: 46,
        inputType: "deleteContentForward"
    }],
    Ao = "dthko",
    Jn = [16, 17, 18, 20, 91, 92, 224, 225],
    ve = 6;

function ke(n) {
    return Math.max(0, n) * .7 + 8
}

function Oo(n, t) {
    return Math.max(Math.abs(n.clientX - t.clientX), Math.abs(n.clientY - t.clientY))
}
class Do {
    constructor(t, e, i, s) {
        this.view = t, this.startEvent = e, this.style = i, this.mustSelect = s, this.scrollSpeed = {
            x: 0,
            y: 0
        }, this.scrolling = -1, this.lastEvent = e, this.scrollParents = qr(t.contentDOM), this.atoms = t.state.facet($i).map(o => o(t));
        let r = t.contentDOM.ownerDocument;
        r.addEventListener("mousemove", this.move = this.move.bind(this)), r.addEventListener("mouseup", this.up = this.up.bind(this)), this.extend = e.shiftKey, this.multiple = t.state.facet(B.allowMultipleSelections) && To(t, e), this.dragging = Eo(t, e) && tr(e) == 1 ? null : !1
    }
    start(t) {
        this.dragging === !1 && this.select(t)
    }
    move(t) {
        if (t.buttons == 0) return this.destroy();
        if (this.dragging || this.dragging == null && Oo(this.startEvent, t) < 10) return;
        this.select(this.lastEvent = t);
        let e = 0,
            i = 0,
            s = 0,
            r = 0,
            o = this.view.win.innerWidth,
            l = this.view.win.innerHeight;
        this.scrollParents.x && ({
            left: s,
            right: o
        } = this.scrollParents.x.getBoundingClientRect()), this.scrollParents.y && ({
            top: r,
            bottom: l
        } = this.scrollParents.y.getBoundingClientRect());
        let h = Gn(this.view);
        t.clientX - h.left <= s + ve ? e = -ke(s - t.clientX) : t.clientX + h.right >= o - ve && (e = ke(t.clientX - o)), t.clientY - h.top <= r + ve ? i = -ke(r - t.clientY) : t.clientY + h.bottom >= l - ve && (i = ke(t.clientY - l)), this.setScrollSpeed(e, i)
    }
    up(t) {
        this.dragging == null && this.select(this.lastEvent), this.dragging || t.preventDefault(), this.destroy()
    }
    destroy() {
        this.setScrollSpeed(0, 0);
        let t = this.view.contentDOM.ownerDocument;
        t.removeEventListener("mousemove", this.move), t.removeEventListener("mouseup", this.up), this.view.inputState.mouseSelection = this.view.inputState.draggedContent = null
    }
    setScrollSpeed(t, e) {
        this.scrollSpeed = {
            x: t,
            y: e
        }, t || e ? this.scrolling < 0 && (this.scrolling = setInterval(() => this.scroll(), 50)) : this.scrolling > -1 && (clearInterval(this.scrolling), this.scrolling = -1)
    }
    scroll() {
        let {
            x: t,
            y: e
        } = this.scrollSpeed;
        t && this.scrollParents.x && (this.scrollParents.x.scrollLeft += t, t = 0), e && this.scrollParents.y && (this.scrollParents.y.scrollTop += e, e = 0), (t || e) && this.view.win.scrollBy(t, e), this.dragging === !1 && this.select(this.lastEvent)
    }
    skipAtoms(t) {
        let e = null;
        for (let i = 0; i < t.ranges.length; i++) {
            let s = t.ranges[i],
                r = null;
            if (s.empty) {
                let o = Be(this.atoms, s.from, 0);
                o != s.from && (r = S.cursor(o, -1))
            } else {
                let o = Be(this.atoms, s.from, -1),
                    l = Be(this.atoms, s.to, 1);
                (o != s.from || l != s.to) && (r = S.range(s.from == s.anchor ? o : l, s.from == s.head ? o : l))
            }
            r && (e || (e = t.ranges.slice()), e[i] = r)
        }
        return e ? S.create(e, t.mainIndex) : t
    }
    select(t) {
        let {
            view: e
        } = this, i = this.skipAtoms(this.style.get(t, this.extend, this.multiple));
        (this.mustSelect || !i.eq(e.state.selection, this.dragging === !1)) && this.view.dispatch({
            selection: i,
            userEvent: "select.pointer"
        }), this.mustSelect = !1
    }
    update(t) {
        t.transactions.some(e => e.isUserEvent("input.type")) ? this.destroy() : this.style.update(t) && setTimeout(() => this.select(this.lastEvent), 20)
    }
}

function To(n, t) {
    let e = n.state.facet(Bn);
    return e.length ? e[0](t) : b.mac ? t.metaKey : t.ctrlKey
}

function Ro(n, t) {
    let e = n.state.facet(Pn);
    return e.length ? e[0](t) : b.mac ? !t.altKey : !t.ctrlKey
}

function Eo(n, t) {
    let {
        main: e
    } = n.state.selection;
    if (e.empty) return !1;
    let i = ae(n.root);
    if (!i || i.rangeCount == 0) return !0;
    let s = i.getRangeAt(0).getClientRects();
    for (let r = 0; r < s.length; r++) {
        let o = s[r];
        if (o.left <= t.clientX && o.right >= t.clientX && o.top <= t.clientY && o.bottom >= t.clientY) return !0
    }
    return !1
}

function Bo(n, t) {
    if (!t.bubbles) return !0;
    if (t.defaultPrevented) return !1;
    for (let e = t.target, i; e != n.contentDOM; e = e.parentNode)
        if (!e || e.nodeType == 11 || (i = R.get(e)) && i.ignoreEvent(t)) return !1;
    return !0
}
const _ = Object.create(null),
    Q = Object.create(null),
    Qn = b.ie && b.ie_version < 15 || b.ios && b.webkit_version < 604;

function Po(n) {
    let t = n.dom.parentNode;
    if (!t) return;
    let e = t.appendChild(document.createElement("textarea"));
    e.style.cssText = "position: fixed; left: -10000px; top: 10px", e.focus(), setTimeout(() => {
        n.focus(), e.remove(), Zn(n, e.value)
    }, 50)
}

function Zn(n, t) {
    let {
        state: e
    } = n, i, s = 1, r = e.toText(t), o = r.lines == e.selection.ranges.length;
    if (Ti != null && e.selection.ranges.every(h => h.empty) && Ti == r.toString()) {
        let h = -1;
        i = e.changeByRange(f => {
            let a = e.doc.lineAt(f.from);
            if (a.from == h) return {
                range: f
            };
            h = a.from;
            let c = e.toText((o ? r.line(s++).text : t) + e.lineBreak);
            return {
                changes: {
                    from: a.from,
                    insert: c
                },
                range: S.cursor(f.from + c.length)
            }
        })
    } else o ? i = e.changeByRange(h => {
        let f = r.line(s++);
        return {
            changes: {
                from: h.from,
                to: h.to,
                insert: f.text
            },
            range: S.cursor(h.from + f.length)
        }
    }) : i = e.replaceSelection(r);
    n.dispatch(i, {
        userEvent: "input.paste",
        scrollIntoView: !0
    })
}
Q.scroll = n => {
    n.inputState.lastScrollTop = n.scrollDOM.scrollTop, n.inputState.lastScrollLeft = n.scrollDOM.scrollLeft
};
_.keydown = (n, t) => (n.inputState.setSelectionOrigin("select"), t.keyCode == 27 && n.inputState.tabFocusMode != 0 && (n.inputState.tabFocusMode = Date.now() + 2e3), !1);
Q.touchstart = (n, t) => {
    n.inputState.lastTouchTime = Date.now(), n.inputState.setSelectionOrigin("select.pointer")
};
Q.touchmove = n => {
    n.inputState.setSelectionOrigin("select.pointer")
};
_.mousedown = (n, t) => {
    if (n.observer.flush(), n.inputState.lastTouchTime > Date.now() - 2e3) return !1;
    let e = null;
    for (let i of n.state.facet(Ln))
        if (e = i(n, t), e) break;
    if (!e && t.button == 0 && (e = Vo(n, t)), e) {
        let i = !n.hasFocus;
        n.inputState.startMouseSelection(new Do(n, t, e, i)), i && n.observer.ignore(() => {
            dn(n.contentDOM);
            let r = n.root.activeElement;
            r && !r.contains(n.contentDOM) && r.blur()
        });
        let s = n.inputState.mouseSelection;
        if (s) return s.start(t), s.dragging === !1
    }
    return !1
};

function Ss(n, t, e, i) {
    if (i == 1) return S.cursor(t, e);
    if (i == 2) return mo(n.state, t, e); {
        let s = N.find(n.docView, t),
            r = n.state.doc.lineAt(s ? s.posAtEnd : t),
            o = s ? s.posAtStart : r.from,
            l = s ? s.posAtEnd : r.to;
        return l < n.state.doc.length && l == r.to && l++, S.range(o, l)
    }
}
let _n = (n, t) => n >= t.top && n <= t.bottom,
    vs = (n, t, e) => _n(t, e) && n >= e.left && n <= e.right;

function Lo(n, t, e, i) {
    let s = N.find(n.docView, t);
    if (!s) return 1;
    let r = t - s.posAtStart;
    if (r == 0) return 1;
    if (r == s.length) return -1;
    let o = s.coordsAt(r, -1);
    if (o && vs(e, i, o)) return -1;
    let l = s.coordsAt(r, 1);
    return l && vs(e, i, l) ? 1 : o && _n(i, o) ? -1 : 1
}

function ks(n, t) {
    let e = n.posAtCoords({
        x: t.clientX,
        y: t.clientY
    }, !1);
    return {
        pos: e,
        bias: Lo(n, e, t.clientX, t.clientY)
    }
}
const No = b.ie && b.ie_version <= 11;
let Cs = null,
    Ms = 0,
    As = 0;

function tr(n) {
    if (!No) return n.detail;
    let t = Cs,
        e = As;
    return Cs = n, As = Date.now(), Ms = !t || e > Date.now() - 400 && Math.abs(t.clientX - n.clientX) < 2 && Math.abs(t.clientY - n.clientY) < 2 ? (Ms + 1) % 3 : 1
}

function Vo(n, t) {
    let e = ks(n, t),
        i = tr(t),
        s = n.state.selection;
    return {
        update(r) {
            r.docChanged && (e.pos = r.changes.mapPos(e.pos), s = s.map(r.changes))
        },
        get(r, o, l) {
            let h = ks(n, r),
                f, a = Ss(n, h.pos, h.bias, i);
            if (e.pos != h.pos && !o) {
                let c = Ss(n, e.pos, e.bias, i),
                    u = Math.min(c.from, a.from),
                    d = Math.max(c.to, a.to);
                a = u < a.from ? S.range(u, d) : S.range(d, u)
            }
            return o ? s.replaceRange(s.main.extend(a.from, a.to)) : l && i == 1 && s.ranges.length > 1 && (f = Io(s, h.pos)) ? f : l ? s.addRange(a) : S.create([a])
        }
    }
}

function Io(n, t) {
    for (let e = 0; e < n.ranges.length; e++) {
        let {
            from: i,
            to: s
        } = n.ranges[e];
        if (i <= t && s >= t) return S.create(n.ranges.slice(0, e).concat(n.ranges.slice(e + 1)), n.mainIndex == e ? 0 : n.mainIndex - (n.mainIndex > e ? 1 : 0))
    }
    return null
}
_.dragstart = (n, t) => {
    let {
        selection: {
            main: e
        }
    } = n.state;
    if (t.target.draggable) {
        let s = n.docView.nearest(t.target);
        if (s && s.isWidget) {
            let r = s.posAtStart,
                o = r + s.length;
            (r >= e.to || o <= e.from) && (e = S.range(r, o))
        }
    }
    let {
        inputState: i
    } = n;
    return i.mouseSelection && (i.mouseSelection.dragging = !0), i.draggedContent = e, t.dataTransfer && (t.dataTransfer.setData("Text", n.state.sliceDoc(e.from, e.to)), t.dataTransfer.effectAllowed = "copyMove"), !1
};
_.dragend = n => (n.inputState.draggedContent = null, !1);

function Os(n, t, e, i) {
    if (!e) return;
    let s = n.posAtCoords({
            x: t.clientX,
            y: t.clientY
        }, !1),
        {
            draggedContent: r
        } = n.inputState,
        o = i && r && Ro(n, t) ? {
            from: r.from,
            to: r.to
        } : null,
        l = {
            from: s,
            insert: e
        },
        h = n.state.changes(o ? [o, l] : l);
    n.focus(), n.dispatch({
        changes: h,
        selection: {
            anchor: h.mapPos(s, -1),
            head: h.mapPos(s, 1)
        },
        userEvent: o ? "move.drop" : "input.drop"
    }), n.inputState.draggedContent = null
}
_.drop = (n, t) => {
    if (!t.dataTransfer) return !1;
    if (n.state.readOnly) return !0;
    let e = t.dataTransfer.files;
    if (e && e.length) {
        let i = Array(e.length),
            s = 0,
            r = () => {
                ++s == e.length && Os(n, t, i.filter(o => o != null).join(n.state.lineBreak), !1)
            };
        for (let o = 0; o < e.length; o++) {
            let l = new FileReader;
            l.onerror = r, l.onload = () => {
                /[\x00-\x08\x0e-\x1f]{2}/.test(l.result) || (i[o] = l.result), r()
            }, l.readAsText(e[o])
        }
        return !0
    } else {
        let i = t.dataTransfer.getData("Text");
        if (i) return Os(n, t, i, !0), !0
    }
    return !1
};
_.paste = (n, t) => {
    if (n.state.readOnly) return !0;
    n.observer.flush();
    let e = Qn ? null : t.clipboardData;
    return e ? (Zn(n, e.getData("text/plain") || e.getData("text/uri-list")), !0) : (Po(n), !1)
};

function Ho(n, t) {
    let e = n.dom.parentNode;
    if (!e) return;
    let i = e.appendChild(document.createElement("textarea"));
    i.style.cssText = "position: fixed; left: -10000px; top: 10px", i.value = t, i.focus(), i.selectionEnd = t.length, i.selectionStart = 0, setTimeout(() => {
        i.remove(), n.focus()
    }, 50)
}

function Fo(n) {
    let t = [],
        e = [],
        i = !1;
    for (let s of n.selection.ranges) s.empty || (t.push(n.sliceDoc(s.from, s.to)), e.push(s));
    if (!t.length) {
        let s = -1;
        for (let {
                from: r
            } of n.selection.ranges) {
            let o = n.doc.lineAt(r);
            o.number > s && (t.push(o.text), e.push({
                from: o.from,
                to: Math.min(n.doc.length, o.to + 1)
            })), s = o.number
        }
        i = !0
    }
    return {
        text: t.join(n.lineBreak),
        ranges: e,
        linewise: i
    }
}
let Ti = null;
_.copy = _.cut = (n, t) => {
    let {
        text: e,
        ranges: i,
        linewise: s
    } = Fo(n.state);
    if (!e && !s) return !1;
    Ti = s ? e : null, t.type == "cut" && !n.state.readOnly && n.dispatch({
        changes: i,
        scrollIntoView: !0,
        userEvent: "delete.cut"
    });
    let r = Qn ? null : t.clipboardData;
    return r ? (r.clearData(), r.setData("text/plain", e), !0) : (Ho(n, e), !1)
};
const er = Kt.define();

function ir(n, t) {
    let e = [];
    for (let i of n.facet(In)) {
        let s = i(n, t);
        s && e.push(s)
    }
    return e ? n.update({
        effects: e,
        annotations: er.of(!0)
    }) : null
}

function sr(n) {
    setTimeout(() => {
        let t = n.hasFocus;
        if (t != n.inputState.notifiedFocused) {
            let e = ir(n.state, t);
            e ? n.dispatch(e) : n.update([])
        }
    }, 10)
}
Q.focus = n => {
    n.inputState.lastFocusTime = Date.now(), !n.scrollDOM.scrollTop && (n.inputState.lastScrollTop || n.inputState.lastScrollLeft) && (n.scrollDOM.scrollTop = n.inputState.lastScrollTop, n.scrollDOM.scrollLeft = n.inputState.lastScrollLeft), sr(n)
};
Q.blur = n => {
    n.observer.clearSelectionRange(), sr(n)
};
Q.compositionstart = Q.compositionupdate = n => {
    n.observer.editContext || (n.inputState.compositionFirstChange == null && (n.inputState.compositionFirstChange = !0), n.inputState.composing < 0 && (n.inputState.composing = 0))
};
Q.compositionend = n => {
    n.observer.editContext || (n.inputState.composing = -1, n.inputState.compositionEndedAt = Date.now(), n.inputState.compositionPendingKey = !0, n.inputState.compositionPendingChange = n.observer.pendingRecords().length > 0, n.inputState.compositionFirstChange = null, b.chrome && b.android ? n.observer.flushSoon() : n.inputState.compositionPendingChange ? Promise.resolve().then(() => n.observer.flush()) : setTimeout(() => {
        n.inputState.composing < 0 && n.docView.hasComposition && n.update([])
    }, 50))
};
Q.contextmenu = n => {
    n.inputState.lastContextMenu = Date.now()
};
_.beforeinput = (n, t) => {
    var e;
    let i;
    if (b.chrome && b.android && (i = Un.find(s => s.inputType == t.inputType)) && (n.observer.delayAndroidKey(i.key, i.keyCode), i.key == "Backspace" || i.key == "Delete")) {
        let s = ((e = window.visualViewport) === null || e === void 0 ? void 0 : e.height) || 0;
        setTimeout(() => {
            var r;
            (((r = window.visualViewport) === null || r === void 0 ? void 0 : r.height) || 0) > s + 10 && n.hasFocus && (n.contentDOM.blur(), n.focus())
        }, 100)
    }
    return b.ios && t.inputType == "deleteContentForward" && n.observer.flushSoon(), b.safari && t.inputType == "insertText" && n.inputState.composing >= 0 && setTimeout(() => Q.compositionend(n, t), 20), !1
};
const Ds = new Set;

function Wo(n) {
    Ds.has(n) || (Ds.add(n), n.addEventListener("copy", () => {}), n.addEventListener("cut", () => {}))
}
const Ts = ["pre-wrap", "normal", "pre-line", "break-spaces"];
class zo {
    constructor(t) {
        this.lineWrapping = t, this.doc = O.empty, this.heightSamples = {}, this.lineHeight = 14, this.charWidth = 7, this.textHeight = 14, this.lineLength = 30, this.heightChanged = !1
    }
    heightForGap(t, e) {
        let i = this.doc.lineAt(e).number - this.doc.lineAt(t).number + 1;
        return this.lineWrapping && (i += Math.max(0, Math.ceil((e - t - i * this.lineLength * .5) / this.lineLength))), this.lineHeight * i
    }
    heightForLine(t) {
        return this.lineWrapping ? (1 + Math.max(0, Math.ceil((t - this.lineLength) / (this.lineLength - 5)))) * this.lineHeight : this.lineHeight
    }
    setDoc(t) {
        return this.doc = t, this
    }
    mustRefreshForWrapping(t) {
        return Ts.indexOf(t) > -1 != this.lineWrapping
    }
    mustRefreshForHeights(t) {
        let e = !1;
        for (let i = 0; i < t.length; i++) {
            let s = t[i];
            s < 0 ? i++ : this.heightSamples[Math.floor(s * 10)] || (e = !0, this.heightSamples[Math.floor(s * 10)] = !0)
        }
        return e
    }
    refresh(t, e, i, s, r, o) {
        let l = Ts.indexOf(t) > -1,
            h = Math.round(e) != Math.round(this.lineHeight) || this.lineWrapping != l;
        if (this.lineWrapping = l, this.lineHeight = e, this.charWidth = i, this.textHeight = s, this.lineLength = r, h) {
            this.heightSamples = {};
            for (let f = 0; f < o.length; f++) {
                let a = o[f];
                a < 0 ? f++ : this.heightSamples[Math.floor(a * 10)] = !0
            }
        }
        return h
    }
}
class qo {
    constructor(t, e) {
        this.from = t, this.heights = e, this.index = 0
    }
    get more() {
        return this.index < this.heights.length
    }
}
class it {
    constructor(t, e, i, s, r) {
        this.from = t, this.length = e, this.top = i, this.height = s, this._content = r
    }
    get type() {
        return typeof this._content == "number" ? $.Text : Array.isArray(this._content) ? this._content : this._content.type
    }
    get to() {
        return this.from + this.length
    }
    get bottom() {
        return this.top + this.height
    }
    get widget() {
        return this._content instanceof yt ? this._content.widget : null
    }
    get widgetLineBreaks() {
        return typeof this._content == "number" ? this._content : 0
    }
    join(t) {
        let e = (Array.isArray(this._content) ? this._content : [this]).concat(Array.isArray(t._content) ? t._content : [t]);
        return new it(this.from, this.length + t.length, this.top, this.height + t.height, e)
    }
}
var E = (function(n) {
    return n[n.ByPos = 0] = "ByPos", n[n.ByHeight = 1] = "ByHeight", n[n.ByPosNoHeight = 2] = "ByPosNoHeight", n
})(E || (E = {}));
const Pe = .001;
class G {
    constructor(t, e, i = 2) {
        this.length = t, this.height = e, this.flags = i
    }
    get outdated() {
        return (this.flags & 2) > 0
    }
    set outdated(t) {
        this.flags = (t ? 2 : 0) | this.flags & -3
    }
    setHeight(t, e) {
        this.height != e && (Math.abs(this.height - e) > Pe && (t.heightChanged = !0), this.height = e)
    }
    replace(t, e, i) {
        return G.of(i)
    }
    decomposeLeft(t, e) {
        e.push(this)
    }
    decomposeRight(t, e) {
        e.push(this)
    }
    applyChanges(t, e, i, s) {
        let r = this,
            o = i.doc;
        for (let l = s.length - 1; l >= 0; l--) {
            let {
                fromA: h,
                toA: f,
                fromB: a,
                toB: c
            } = s[l], u = r.lineAt(h, E.ByPosNoHeight, i.setDoc(e), 0, 0), d = u.to >= f ? u : r.lineAt(f, E.ByPosNoHeight, i, 0, 0);
            for (c += d.to - f, f = d.to; l > 0 && u.from <= s[l - 1].toA;) h = s[l - 1].fromA, a = s[l - 1].fromB, l--, h < u.from && (u = r.lineAt(h, E.ByPosNoHeight, i, 0, 0));
            a += u.from - h, h = u.from;
            let g = Gi.build(i.setDoc(o), t, a, c);
            r = r.replace(h, f, g)
        }
        return r.updateHeight(i, 0)
    }
    static empty() {
        return new X(0, 0)
    }
    static of (t) {
        if (t.length == 1) return t[0];
        let e = 0,
            i = t.length,
            s = 0,
            r = 0;
        for (;;)
            if (e == i)
                if (s > r * 2) {
                    let l = t[e - 1];
                    l.break ? t.splice(--e, 1, l.left, null, l.right) : t.splice(--e, 1, l.left, l.right), i += 1 + l.break, s -= l.size
                } else if (r > s * 2) {
            let l = t[i];
            l.break ? t.splice(i, 1, l.left, null, l.right) : t.splice(i, 1, l.left, l.right), i += 2 + l.break, r -= l.size
        } else break;
        else if (s < r) {
            let l = t[e++];
            l && (s += l.size)
        } else {
            let l = t[--i];
            l && (r += l.size)
        }
        let o = 0;
        return t[e - 1] == null ? (o = 1, e--) : t[e] == null && (o = 1, i++), new Ko(G.of(t.slice(0, e)), o, G.of(t.slice(i)))
    }
}
G.prototype.size = 1;
class nr extends G {
    constructor(t, e, i) {
        super(t, e), this.deco = i
    }
    blockAt(t, e, i, s) {
        return new it(s, this.length, i, this.height, this.deco || 0)
    }
    lineAt(t, e, i, s, r) {
        return this.blockAt(0, i, s, r)
    }
    forEachLine(t, e, i, s, r, o) {
        t <= r + this.length && e >= r && o(this.blockAt(0, i, s, r))
    }
    updateHeight(t, e = 0, i = !1, s) {
        return s && s.from <= e && s.more && this.setHeight(t, s.heights[s.index++]), this.outdated = !1, this
    }
    toString() {
        return "block(".concat(this.length, ")")
    }
}
class X extends nr {
    constructor(t, e) {
        super(t, e, null), this.collapsed = 0, this.widgetHeight = 0, this.breaks = 0
    }
    blockAt(t, e, i, s) {
        return new it(s, this.length, i, this.height, this.breaks)
    }
    replace(t, e, i) {
        let s = i[0];
        return i.length == 1 && (s instanceof X || s instanceof z && s.flags & 4) && Math.abs(this.length - s.length) < 10 ? (s instanceof z ? s = new X(s.length, this.height) : s.height = this.height, this.outdated || (s.outdated = !1), s) : G.of(i)
    }
    updateHeight(t, e = 0, i = !1, s) {
        return s && s.from <= e && s.more ? this.setHeight(t, s.heights[s.index++]) : (i || this.outdated) && this.setHeight(t, Math.max(this.widgetHeight, t.heightForLine(this.length - this.collapsed)) + this.breaks * t.lineHeight), this.outdated = !1, this
    }
    toString() {
        return "line(".concat(this.length).concat(this.collapsed ? -this.collapsed : "").concat(this.widgetHeight ? ":" + this.widgetHeight : "", ")")
    }
}
class z extends G {
    constructor(t) {
        super(t, 0)
    }
    heightMetrics(t, e) {
        let i = t.doc.lineAt(e).number,
            s = t.doc.lineAt(e + this.length).number,
            r = s - i + 1,
            o, l = 0;
        if (t.lineWrapping) {
            let h = Math.min(this.height, t.lineHeight * r);
            o = h / r, this.length > r + 1 && (l = (this.height - h) / (this.length - r - 1))
        } else o = this.height / r;
        return {
            firstLine: i,
            lastLine: s,
            perLine: o,
            perChar: l
        }
    }
    blockAt(t, e, i, s) {
        let {
            firstLine: r,
            lastLine: o,
            perLine: l,
            perChar: h
        } = this.heightMetrics(e, s);
        if (e.lineWrapping) {
            let f = s + (t < e.lineHeight ? 0 : Math.round(Math.max(0, Math.min(1, (t - i) / this.height)) * this.length)),
                a = e.doc.lineAt(f),
                c = l + a.length * h,
                u = Math.max(i, t - c / 2);
            return new it(a.from, a.length, u, c, 0)
        } else {
            let f = Math.max(0, Math.min(o - r, Math.floor((t - i) / l))),
                {
                    from: a,
                    length: c
                } = e.doc.line(r + f);
            return new it(a, c, i + l * f, l, 0)
        }
    }
    lineAt(t, e, i, s, r) {
        if (e == E.ByHeight) return this.blockAt(t, i, s, r);
        if (e == E.ByPosNoHeight) {
            let {
                from: d,
                to: g
            } = i.doc.lineAt(t);
            return new it(d, g - d, 0, 0, 0)
        }
        let {
            firstLine: o,
            perLine: l,
            perChar: h
        } = this.heightMetrics(i, r), f = i.doc.lineAt(t), a = l + f.length * h, c = f.number - o, u = s + l * c + h * (f.from - r - c);
        return new it(f.from, f.length, Math.max(s, Math.min(u, s + this.height - a)), a, 0)
    }
    forEachLine(t, e, i, s, r, o) {
        t = Math.max(t, r), e = Math.min(e, r + this.length);
        let {
            firstLine: l,
            perLine: h,
            perChar: f
        } = this.heightMetrics(i, r);
        for (let a = t, c = s; a <= e;) {
            let u = i.doc.lineAt(a);
            if (a == t) {
                let g = u.number - l;
                c += h * g + f * (t - r - g)
            }
            let d = h + f * u.length;
            o(new it(u.from, u.length, c, d, 0)), c += d, a = u.to + 1
        }
    }
    replace(t, e, i) {
        let s = this.length - e;
        if (s > 0) {
            let r = i[i.length - 1];
            r instanceof z ? i[i.length - 1] = new z(r.length + s) : i.push(null, new z(s - 1))
        }
        if (t > 0) {
            let r = i[0];
            r instanceof z ? i[0] = new z(t + r.length) : i.unshift(new z(t - 1), null)
        }
        return G.of(i)
    }
    decomposeLeft(t, e) {
        e.push(new z(t - 1), null)
    }
    decomposeRight(t, e) {
        e.push(null, new z(this.length - t - 1))
    }
    updateHeight(t, e = 0, i = !1, s) {
        let r = e + this.length;
        if (s && s.from <= e + this.length && s.more) {
            let o = [],
                l = Math.max(e, s.from),
                h = -1;
            for (s.from > e && o.push(new z(s.from - e - 1).updateHeight(t, e)); l <= r && s.more;) {
                let a = t.doc.lineAt(l).length;
                o.length && o.push(null);
                let c = s.heights[s.index++];
                h == -1 ? h = c : Math.abs(c - h) >= Pe && (h = -2);
                let u = new X(a, c);
                u.outdated = !1, o.push(u), l += a + 1
            }
            l <= r && o.push(null, new z(r - l).updateHeight(t, l));
            let f = G.of(o);
            return (h < 0 || Math.abs(f.height - this.height) >= Pe || Math.abs(h - this.heightMetrics(t, e).perLine) >= Pe) && (t.heightChanged = !0), f
        } else(i || this.outdated) && (this.setHeight(t, t.heightForGap(e, e + this.length)), this.outdated = !1);
        return this
    }
    toString() {
        return "gap(".concat(this.length, ")")
    }
}
class Ko extends G {
    constructor(t, e, i) {
        super(t.length + e + i.length, t.height + i.height, e | (t.outdated || i.outdated ? 2 : 0)), this.left = t, this.right = i, this.size = t.size + i.size
    }
    get break() {
        return this.flags & 1
    }
    blockAt(t, e, i, s) {
        let r = i + this.left.height;
        return t < r ? this.left.blockAt(t, e, i, s) : this.right.blockAt(t, e, r, s + this.left.length + this.break)
    }
    lineAt(t, e, i, s, r) {
        let o = s + this.left.height,
            l = r + this.left.length + this.break,
            h = e == E.ByHeight ? t < o : t < l,
            f = h ? this.left.lineAt(t, e, i, s, r) : this.right.lineAt(t, e, i, o, l);
        if (this.break || (h ? f.to < l : f.from > l)) return f;
        let a = e == E.ByPosNoHeight ? E.ByPosNoHeight : E.ByPos;
        return h ? f.join(this.right.lineAt(l, a, i, o, l)) : this.left.lineAt(l, a, i, s, r).join(f)
    }
    forEachLine(t, e, i, s, r, o) {
        let l = s + this.left.height,
            h = r + this.left.length + this.break;
        if (this.break) t < h && this.left.forEachLine(t, e, i, s, r, o), e >= h && this.right.forEachLine(t, e, i, l, h, o);
        else {
            let f = this.lineAt(h, E.ByPos, i, s, r);
            t < f.from && this.left.forEachLine(t, f.from - 1, i, s, r, o), f.to >= t && f.from <= e && o(f), e > f.to && this.right.forEachLine(f.to + 1, e, i, l, h, o)
        }
    }
    replace(t, e, i) {
        let s = this.left.length + this.break;
        if (e < s) return this.balanced(this.left.replace(t, e, i), this.right);
        if (t > this.left.length) return this.balanced(this.left, this.right.replace(t - s, e - s, i));
        let r = [];
        t > 0 && this.decomposeLeft(t, r);
        let o = r.length;
        for (let l of i) r.push(l);
        if (t > 0 && Rs(r, o - 1), e < this.length) {
            let l = r.length;
            this.decomposeRight(e, r), Rs(r, l)
        }
        return G.of(r)
    }
    decomposeLeft(t, e) {
        let i = this.left.length;
        if (t <= i) return this.left.decomposeLeft(t, e);
        e.push(this.left), this.break && (i++, t >= i && e.push(null)), t > i && this.right.decomposeLeft(t - i, e)
    }
    decomposeRight(t, e) {
        let i = this.left.length,
            s = i + this.break;
        if (t >= s) return this.right.decomposeRight(t - s, e);
        t < i && this.left.decomposeRight(t, e), this.break && t < s && e.push(null), e.push(this.right)
    }
    balanced(t, e) {
        return t.size > 2 * e.size || e.size > 2 * t.size ? G.of(this.break ? [t, null, e] : [t, e]) : (this.left = t, this.right = e, this.height = t.height + e.height, this.outdated = t.outdated || e.outdated, this.size = t.size + e.size, this.length = t.length + this.break+e.length, this)
    }
    updateHeight(t, e = 0, i = !1, s) {
        let {
            left: r,
            right: o
        } = this, l = e + r.length + this.break, h = null;
        return s && s.from <= e + r.length && s.more ? h = r = r.updateHeight(t, e, i, s) : r.updateHeight(t, e, i), s && s.from <= l + o.length && s.more ? h = o = o.updateHeight(t, l, i, s) : o.updateHeight(t, l, i), h ? this.balanced(r, o) : (this.height = this.left.height + this.right.height, this.outdated = !1, this)
    }
    toString() {
        return this.left + (this.break ? " " : "-") + this.right
    }
}

function Rs(n, t) {
    let e, i;
    n[t] == null && (e = n[t - 1]) instanceof z && (i = n[t + 1]) instanceof z && n.splice(t - 1, 3, new z(e.length + 1 + i.length))
}
const jo = 5;
class Gi {
    constructor(t, e) {
        this.pos = t, this.oracle = e, this.nodes = [], this.lineStart = -1, this.lineEnd = -1, this.covering = null, this.writtenTo = t
    }
    get isCovered() {
        return this.covering && this.nodes[this.nodes.length - 1] == this.covering
    }
    span(t, e) {
        if (this.lineStart > -1) {
            let i = Math.min(e, this.lineEnd),
                s = this.nodes[this.nodes.length - 1];
            s instanceof X ? s.length += i - this.pos : (i > this.pos || !this.isCovered) && this.nodes.push(new X(i - this.pos, -1)), this.writtenTo = i, e > i && (this.nodes.push(null), this.writtenTo++, this.lineStart = -1)
        }
        this.pos = e
    }
    point(t, e, i) {
        if (t < e || i.heightRelevant) {
            let s = i.widget ? i.widget.estimatedHeight : 0,
                r = i.widget ? i.widget.lineBreaks : 0;
            s < 0 && (s = this.oracle.lineHeight);
            let o = e - t;
            i.block ? this.addBlock(new nr(o, s, i)) : (o || r || s >= jo) && this.addLineDeco(s, r, o)
        } else e > t && this.span(t, e);
        this.lineEnd > -1 && this.lineEnd < this.pos && (this.lineEnd = this.oracle.doc.lineAt(this.pos).to)
    }
    enterLine() {
        if (this.lineStart > -1) return;
        let {
            from: t,
            to: e
        } = this.oracle.doc.lineAt(this.pos);
        this.lineStart = t, this.lineEnd = e, this.writtenTo < t && ((this.writtenTo < t - 1 || this.nodes[this.nodes.length - 1] == null) && this.nodes.push(this.blankContent(this.writtenTo, t - 1)), this.nodes.push(null)), this.pos > t && this.nodes.push(new X(this.pos - t, -1)), this.writtenTo = this.pos
    }
    blankContent(t, e) {
        let i = new z(e - t);
        return this.oracle.doc.lineAt(t).to == e && (i.flags |= 4), i
    }
    ensureLine() {
        this.enterLine();
        let t = this.nodes.length ? this.nodes[this.nodes.length - 1] : null;
        if (t instanceof X) return t;
        let e = new X(0, -1);
        return this.nodes.push(e), e
    }
    addBlock(t) {
        this.enterLine();
        let e = t.deco;
        e && e.startSide > 0 && !this.isCovered && this.ensureLine(), this.nodes.push(t), this.writtenTo = this.pos = this.pos + t.length, e && e.endSide > 0 && (this.covering = t)
    }
    addLineDeco(t, e, i) {
        let s = this.ensureLine();
        s.length += i, s.collapsed += i, s.widgetHeight = Math.max(s.widgetHeight, t), s.breaks += e, this.writtenTo = this.pos = this.pos + i
    }
    finish(t) {
        let e = this.nodes.length == 0 ? null : this.nodes[this.nodes.length - 1];
        this.lineStart > -1 && !(e instanceof X) && !this.isCovered ? this.nodes.push(new X(0, -1)) : (this.writtenTo < this.pos || e == null) && this.nodes.push(this.blankContent(this.writtenTo, this.pos));
        let i = t;
        for (let s of this.nodes) s instanceof X && s.updateHeight(this.oracle, i), i += s ? s.length : 1;
        return this.nodes
    }
    static build(t, e, i, s) {
        let r = new Gi(i, t);
        return A.spans(e, i, s, r, 0), r.finish(i)
    }
}

function $o(n, t, e) {
    let i = new Go;
    return A.compare(n, t, e, i, 0), i.changes
}
class Go {
    constructor() {
        this.changes = []
    }
    compareRange() {}
    comparePoint(t, e, i, s) {
        (t < e || i && i.heightRelevant || s && s.heightRelevant) && vi(t, e, this.changes, 5)
    }
}

function Yo(n, t) {
    let e = n.getBoundingClientRect(),
        i = n.ownerDocument,
        s = i.defaultView || window,
        r = Math.max(0, e.left),
        o = Math.min(s.innerWidth, e.right),
        l = Math.max(0, e.top),
        h = Math.min(s.innerHeight, e.bottom);
    for (let f = n.parentNode; f && f != i.body;)
        if (f.nodeType == 1) {
            let a = f,
                c = window.getComputedStyle(a);
            if ((a.scrollHeight > a.clientHeight || a.scrollWidth > a.clientWidth) && c.overflow != "visible") {
                let u = a.getBoundingClientRect();
                r = Math.max(r, u.left), o = Math.min(o, u.right), l = Math.max(l, u.top), h = f == n.parentNode ? u.bottom : Math.min(h, u.bottom)
            }
            f = c.position == "absolute" || c.position == "fixed" ? a.offsetParent : a.parentNode
        } else if (f.nodeType == 11) f = f.host;
    else break;
    return {
        left: r - e.left,
        right: Math.max(r, o) - e.left,
        top: l - (e.top + t),
        bottom: Math.max(l, h) - (e.top + t)
    }
}

function Xo(n, t) {
    let e = n.getBoundingClientRect();
    return {
        left: 0,
        right: e.right - e.left,
        top: t,
        bottom: e.bottom - (e.top + t)
    }
}
class Qe {
    constructor(t, e, i) {
        this.from = t, this.to = e, this.size = i
    }
    static same(t, e) {
        if (t.length != e.length) return !1;
        for (let i = 0; i < t.length; i++) {
            let s = t[i],
                r = e[i];
            if (s.from != r.from || s.to != r.to || s.size != r.size) return !1
        }
        return !0
    }
    draw(t, e) {
        return V.replace({
            widget: new Uo(this.size * (e ? t.scaleY : t.scaleX), e)
        }).range(this.from, this.to)
    }
}
class Uo extends jt {
    constructor(t, e) {
        super(), this.size = t, this.vertical = e
    }
    eq(t) {
        return t.size == this.size && t.vertical == this.vertical
    }
    toDOM() {
        let t = document.createElement("div");
        return this.vertical ? t.style.height = this.size + "px" : (t.style.width = this.size + "px", t.style.height = "2px", t.style.display = "inline-block"), t
    }
    get estimatedHeight() {
        return this.vertical ? this.size : -1
    }
}
class Es {
    constructor(t) {
        this.state = t, this.pixelViewport = {
            left: 0,
            right: window.innerWidth,
            top: 0,
            bottom: 0
        }, this.inView = !0, this.paddingTop = 0, this.paddingBottom = 0, this.contentDOMWidth = 0, this.contentDOMHeight = 0, this.editorHeight = 0, this.editorWidth = 0, this.scrollTop = 0, this.scrolledToBottom = !1, this.scaleX = 1, this.scaleY = 1, this.scrollAnchorPos = 0, this.scrollAnchorHeight = -1, this.scaler = Bs, this.scrollTarget = null, this.printing = !1, this.mustMeasureContent = !0, this.defaultTextDirection = I.LTR, this.visibleRanges = [], this.mustEnforceCursorAssoc = !1;
        let e = t.facet(ji).some(i => typeof i != "function" && i.class == "cm-lineWrapping");
        this.heightOracle = new zo(e), this.stateDeco = t.facet(fe).filter(i => typeof i != "function"), this.heightMap = G.empty().applyChanges(this.stateDeco, O.empty, this.heightOracle.setDoc(t.doc), [new J(0, 0, 0, t.doc.length)]);
        for (let i = 0; i < 2 && (this.viewport = this.getViewport(0, null), !!this.updateForViewport()); i++);
        this.updateViewportLines(), this.lineGaps = this.ensureLineGaps([]), this.lineGapDeco = V.set(this.lineGaps.map(i => i.draw(this, !1))), this.computeVisibleRanges()
    }
    updateForViewport() {
        let t = [this.viewport],
            {
                main: e
            } = this.state.selection;
        for (let i = 0; i <= 1; i++) {
            let s = i ? e.head : e.anchor;
            if (!t.some(({
                    from: r,
                    to: o
                }) => s >= r && s <= o)) {
                let {
                    from: r,
                    to: o
                } = this.lineBlockAt(s);
                t.push(new Ce(r, o))
            }
        }
        return this.viewports = t.sort((i, s) => i.from - s.from), this.updateScaler()
    }
    updateScaler() {
        let t = this.scaler;
        return this.scaler = this.heightMap.height <= 7e6 ? Bs : new Yi(this.heightOracle, this.heightMap, this.viewports), t.eq(this.scaler) ? 0 : 2
    }
    updateViewportLines() {
        this.viewportLines = [], this.heightMap.forEachLine(this.viewport.from, this.viewport.to, this.heightOracle.setDoc(this.state.doc), 0, 0, t => {
            this.viewportLines.push(Qt(t, this.scaler))
        })
    }
    update(t, e = null) {
        this.state = t.state;
        let i = this.stateDeco;
        this.stateDeco = this.state.facet(fe).filter(a => typeof a != "function");
        let s = t.changedRanges,
            r = J.extendWithRanges(s, $o(i, this.stateDeco, t ? t.changes : H.empty(this.state.doc.length))),
            o = this.heightMap.height,
            l = this.scrolledToBottom ? null : this.scrollAnchorAt(this.scrollTop);
        this.heightMap = this.heightMap.applyChanges(this.stateDeco, t.startState.doc, this.heightOracle.setDoc(this.state.doc), r), this.heightMap.height != o && (t.flags |= 2), l ? (this.scrollAnchorPos = t.changes.mapPos(l.from, -1), this.scrollAnchorHeight = l.top) : (this.scrollAnchorPos = -1, this.scrollAnchorHeight = this.heightMap.height);
        let h = r.length ? this.mapViewport(this.viewport, t.changes) : this.viewport;
        (e && (e.range.head < h.from || e.range.head > h.to) || !this.viewportIsAppropriate(h)) && (h = this.getViewport(0, e));
        let f = h.from != this.viewport.from || h.to != this.viewport.to;
        this.viewport = h, t.flags |= this.updateForViewport(), (f || !t.changes.empty || t.flags & 2) && this.updateViewportLines(), (this.lineGaps.length || this.viewport.to - this.viewport.from > 4e3) && this.updateLineGaps(this.ensureLineGaps(this.mapLineGaps(this.lineGaps, t.changes))), t.flags |= this.computeVisibleRanges(), e && (this.scrollTarget = e), !this.mustEnforceCursorAssoc && t.selectionSet && t.view.lineWrapping && t.state.selection.main.empty && t.state.selection.main.assoc && !t.state.facet(Fn) && (this.mustEnforceCursorAssoc = !0)
    }
    measure(t) {
        let e = t.contentDOM,
            i = window.getComputedStyle(e),
            s = this.heightOracle,
            r = i.whiteSpace;
        this.defaultTextDirection = i.direction == "rtl" ? I.RTL : I.LTR;
        let o = this.heightOracle.mustRefreshForWrapping(r),
            l = e.getBoundingClientRect(),
            h = o || this.mustMeasureContent || this.contentDOMHeight != l.height;
        this.contentDOMHeight = l.height, this.mustMeasureContent = !1;
        let f = 0,
            a = 0;
        if (l.width && l.height) {
            let {
                scaleX: x,
                scaleY: k
            } = un(e, l);
            (x > .005 && Math.abs(this.scaleX - x) > .005 || k > .005 && Math.abs(this.scaleY - k) > .005) && (this.scaleX = x, this.scaleY = k, f |= 8, o = h = !0)
        }
        let c = (parseInt(i.paddingTop) || 0) * this.scaleY,
            u = (parseInt(i.paddingBottom) || 0) * this.scaleY;
        (this.paddingTop != c || this.paddingBottom != u) && (this.paddingTop = c, this.paddingBottom = u, f |= 10), this.editorWidth != t.scrollDOM.clientWidth && (s.lineWrapping && (h = !0), this.editorWidth = t.scrollDOM.clientWidth, f |= 8);
        let d = t.scrollDOM.scrollTop * this.scaleY;
        this.scrollTop != d && (this.scrollAnchorHeight = -1, this.scrollTop = d), this.scrolledToBottom = pn(t.scrollDOM);
        let g = (this.printing ? Xo : Yo)(e, this.paddingTop),
            m = g.top - this.pixelViewport.top,
            p = g.bottom - this.pixelViewport.bottom;
        this.pixelViewport = g;
        let w = this.pixelViewport.bottom > this.pixelViewport.top && this.pixelViewport.right > this.pixelViewport.left;
        if (w != this.inView && (this.inView = w, w && (h = !0)), !this.inView && !this.scrollTarget) return 0;
        let y = l.width;
        if ((this.contentDOMWidth != y || this.editorHeight != t.scrollDOM.clientHeight) && (this.contentDOMWidth = l.width, this.editorHeight = t.scrollDOM.clientHeight, f |= 8), h) {
            let x = t.docView.measureVisibleLineHeights(this.viewport);
            if (s.mustRefreshForHeights(x) && (o = !0), o || s.lineWrapping && Math.abs(y - this.contentDOMWidth) > s.charWidth) {
                let {
                    lineHeight: k,
                    charWidth: M,
                    textHeight: P
                } = t.docView.measureTextSize();
                o = k > 0 && s.refresh(r, k, M, P, y / M, x), o && (t.docView.minWidth = 0, f |= 8)
            }
            m > 0 && p > 0 ? a = Math.max(m, p) : m < 0 && p < 0 && (a = Math.min(m, p)), s.heightChanged = !1;
            for (let k of this.viewports) {
                let M = k.from == this.viewport.from ? x : t.docView.measureVisibleLineHeights(k);
                this.heightMap = (o ? G.empty().applyChanges(this.stateDeco, O.empty, this.heightOracle, [new J(0, 0, 0, t.state.doc.length)]) : this.heightMap).updateHeight(s, 0, o, new qo(k.from, M))
            }
            s.heightChanged && (f |= 2)
        }
        let v = !this.viewportIsAppropriate(this.viewport, a) || this.scrollTarget && (this.scrollTarget.range.head < this.viewport.from || this.scrollTarget.range.head > this.viewport.to);
        return v && (f & 2 && (f |= this.updateScaler()), this.viewport = this.getViewport(a, this.scrollTarget), f |= this.updateForViewport()), (f & 2 || v) && this.updateViewportLines(), (this.lineGaps.length || this.viewport.to - this.viewport.from > 4e3) && this.updateLineGaps(this.ensureLineGaps(o ? [] : this.lineGaps, t)), f |= this.computeVisibleRanges(), this.mustEnforceCursorAssoc && (this.mustEnforceCursorAssoc = !1, t.docView.enforceCursorAssoc()), f
    }
    get visibleTop() {
        return this.scaler.fromDOM(this.pixelViewport.top)
    }
    get visibleBottom() {
        return this.scaler.fromDOM(this.pixelViewport.bottom)
    }
    getViewport(t, e) {
        let i = .5 - Math.max(-.5, Math.min(.5, t / 1e3 / 2)),
            s = this.heightMap,
            r = this.heightOracle,
            {
                visibleTop: o,
                visibleBottom: l
            } = this,
            h = new Ce(s.lineAt(o - i * 1e3, E.ByHeight, r, 0, 0).from, s.lineAt(l + (1 - i) * 1e3, E.ByHeight, r, 0, 0).to);
        if (e) {
            let {
                head: f
            } = e.range;
            if (f < h.from || f > h.to) {
                let a = Math.min(this.editorHeight, this.pixelViewport.bottom - this.pixelViewport.top),
                    c = s.lineAt(f, E.ByPos, r, 0, 0),
                    u;
                e.y == "center" ? u = (c.top + c.bottom) / 2 - a / 2 : e.y == "start" || e.y == "nearest" && f < h.from ? u = c.top : u = c.bottom - a, h = new Ce(s.lineAt(u - 1e3 / 2, E.ByHeight, r, 0, 0).from, s.lineAt(u + a + 1e3 / 2, E.ByHeight, r, 0, 0).to)
            }
        }
        return h
    }
    mapViewport(t, e) {
        let i = e.mapPos(t.from, -1),
            s = e.mapPos(t.to, 1);
        return new Ce(this.heightMap.lineAt(i, E.ByPos, this.heightOracle, 0, 0).from, this.heightMap.lineAt(s, E.ByPos, this.heightOracle, 0, 0).to)
    }
    viewportIsAppropriate({
        from: t,
        to: e
    }, i = 0) {
        if (!this.inView) return !0;
        let {
            top: s
        } = this.heightMap.lineAt(t, E.ByPos, this.heightOracle, 0, 0), {
            bottom: r
        } = this.heightMap.lineAt(e, E.ByPos, this.heightOracle, 0, 0), {
            visibleTop: o,
            visibleBottom: l
        } = this;
        return (t == 0 || s <= o - Math.max(10, Math.min(-i, 250))) && (e == this.state.doc.length || r >= l + Math.max(10, Math.min(i, 250))) && s > o - 2 * 1e3 && r < l + 2 * 1e3
    }
    mapLineGaps(t, e) {
        if (!t.length || e.empty) return t;
        let i = [];
        for (let s of t) e.touchesRange(s.from, s.to) || i.push(new Qe(e.mapPos(s.from), e.mapPos(s.to), s.size));
        return i
    }
    ensureLineGaps(t, e) {
        let i = this.heightOracle.lineWrapping,
            s = i ? 1e4 : 2e3,
            r = s >> 1,
            o = s << 1;
        if (this.defaultTextDirection != I.LTR && !i) return [];
        let l = [],
            h = (a, c, u, d) => {
                if (c - a < r) return;
                let g = this.state.selection.main,
                    m = [g.from];
                g.empty || m.push(g.to);
                for (let w of m)
                    if (w > a && w < c) {
                        h(a, w - 10, u, d), h(w + 10, c, u, d);
                        return
                    }
                let p = Qo(t, w => w.from >= u.from && w.to <= u.to && Math.abs(w.from - a) < r && Math.abs(w.to - c) < r && !m.some(y => w.from < y && w.to > y));
                if (!p) {
                    if (c < u.to && e && i && e.visibleRanges.some(w => w.from <= c && w.to >= c)) {
                        let w = e.moveToLineBoundary(S.cursor(c), !1, !0).head;
                        w > a && (c = w)
                    }
                    p = new Qe(a, c, this.gapSize(u, a, c, d))
                }
                l.push(p)
            },
            f = a => {
                if (a.length < o || a.type != $.Text) return;
                let c = Jo(a.from, a.to, this.stateDeco);
                if (c.total < o) return;
                let u = this.scrollTarget ? this.scrollTarget.range.head : null,
                    d, g;
                if (i) {
                    let m = s / this.heightOracle.lineLength * this.heightOracle.lineHeight,
                        p, w;
                    if (u != null) {
                        let y = Ae(c, u),
                            v = ((this.visibleBottom - this.visibleTop) / 2 + m) / a.height;
                        p = y - v, w = y + v
                    } else p = (this.visibleTop - a.top - m) / a.height, w = (this.visibleBottom - a.top + m) / a.height;
                    d = Me(c, p), g = Me(c, w)
                } else {
                    let m = c.total * this.heightOracle.charWidth,
                        p = s * this.heightOracle.charWidth,
                        w, y;
                    if (u != null) {
                        let v = Ae(c, u),
                            x = ((this.pixelViewport.right - this.pixelViewport.left) / 2 + p) / m;
                        w = v - x, y = v + x
                    } else w = (this.pixelViewport.left - p) / m, y = (this.pixelViewport.right + p) / m;
                    d = Me(c, w), g = Me(c, y)
                }
                d > a.from && h(a.from, d, a, c), g < a.to && h(g, a.to, a, c)
            };
        for (let a of this.viewportLines) Array.isArray(a.type) ? a.type.forEach(f) : f(a);
        return l
    }
    gapSize(t, e, i, s) {
        let r = Ae(s, i) - Ae(s, e);
        return this.heightOracle.lineWrapping ? t.height * r : s.total * this.heightOracle.charWidth * r
    }
    updateLineGaps(t) {
        Qe.same(t, this.lineGaps) || (this.lineGaps = t, this.lineGapDeco = V.set(t.map(e => e.draw(this, this.heightOracle.lineWrapping))))
    }
    computeVisibleRanges() {
        let t = this.stateDeco;
        this.lineGaps.length && (t = t.concat(this.lineGapDeco));
        let e = [];
        A.spans(t, this.viewport.from, this.viewport.to, {
            span(s, r) {
                e.push({
                    from: s,
                    to: r
                })
            },
            point() {}
        }, 20);
        let i = e.length != this.visibleRanges.length || this.visibleRanges.some((s, r) => s.from != e[r].from || s.to != e[r].to);
        return this.visibleRanges = e, i ? 4 : 0
    }
    lineBlockAt(t) {
        return t >= this.viewport.from && t <= this.viewport.to && this.viewportLines.find(e => e.from <= t && e.to >= t) || Qt(this.heightMap.lineAt(t, E.ByPos, this.heightOracle, 0, 0), this.scaler)
    }
    lineBlockAtHeight(t) {
        return t >= this.viewportLines[0].top && t <= this.viewportLines[this.viewportLines.length - 1].bottom && this.viewportLines.find(e => e.top <= t && e.bottom >= t) || Qt(this.heightMap.lineAt(this.scaler.fromDOM(t), E.ByHeight, this.heightOracle, 0, 0), this.scaler)
    }
    scrollAnchorAt(t) {
        let e = this.lineBlockAtHeight(t + 8);
        return e.from >= this.viewport.from || this.viewportLines[0].top - t > 200 ? e : this.viewportLines[0]
    }
    elementAtHeight(t) {
        return Qt(this.heightMap.blockAt(this.scaler.fromDOM(t), this.heightOracle, 0, 0), this.scaler)
    }
    get docHeight() {
        return this.scaler.toDOM(this.heightMap.height)
    }
    get contentHeight() {
        return this.docHeight + this.paddingTop + this.paddingBottom
    }
}
class Ce {
    constructor(t, e) {
        this.from = t, this.to = e
    }
}

function Jo(n, t, e) {
    let i = [],
        s = n,
        r = 0;
    return A.spans(e, n, t, {
        span() {},
        point(o, l) {
            o > s && (i.push({
                from: s,
                to: o
            }), r += o - s), s = l
        }
    }, 20), s < t && (i.push({
        from: s,
        to: t
    }), r += t - s), {
        total: r,
        ranges: i
    }
}

function Me({
    total: n,
    ranges: t
}, e) {
    if (e <= 0) return t[0].from;
    if (e >= 1) return t[t.length - 1].to;
    let i = Math.floor(n * e);
    for (let s = 0;; s++) {
        let {
            from: r,
            to: o
        } = t[s], l = o - r;
        if (i <= l) return r + i;
        i -= l
    }
}

function Ae(n, t) {
    let e = 0;
    for (let {
            from: i,
            to: s
        } of n.ranges) {
        if (t <= s) {
            e += t - i;
            break
        }
        e += s - i
    }
    return e / n.total
}

function Qo(n, t) {
    for (let e of n)
        if (t(e)) return e
}
const Bs = {
    toDOM(n) {
        return n
    },
    fromDOM(n) {
        return n
    },
    scale: 1,
    eq(n) {
        return n == this
    }
};
class Yi {
    constructor(t, e, i) {
        let s = 0,
            r = 0,
            o = 0;
        this.viewports = i.map(({
            from: l,
            to: h
        }) => {
            let f = e.lineAt(l, E.ByPos, t, 0, 0).top,
                a = e.lineAt(h, E.ByPos, t, 0, 0).bottom;
            return s += a - f, {
                from: l,
                to: h,
                top: f,
                bottom: a,
                domTop: 0,
                domBottom: 0
            }
        }), this.scale = (7e6 - s) / (e.height - s);
        for (let l of this.viewports) l.domTop = o + (l.top - r) * this.scale, o = l.domBottom = l.domTop + (l.bottom - l.top), r = l.bottom
    }
    toDOM(t) {
        for (let e = 0, i = 0, s = 0;; e++) {
            let r = e < this.viewports.length ? this.viewports[e] : null;
            if (!r || t < r.top) return s + (t - i) * this.scale;
            if (t <= r.bottom) return r.domTop + (t - r.top);
            i = r.bottom, s = r.domBottom
        }
    }
    fromDOM(t) {
        for (let e = 0, i = 0, s = 0;; e++) {
            let r = e < this.viewports.length ? this.viewports[e] : null;
            if (!r || t < r.domTop) return i + (t - s) / this.scale;
            if (t <= r.domBottom) return r.top + (t - r.domTop);
            i = r.bottom, s = r.domBottom
        }
    }
    eq(t) {
        return t instanceof Yi ? this.scale == t.scale && this.viewports.length == t.viewports.length && this.viewports.every((e, i) => e.from == t.viewports[i].from && e.to == t.viewports[i].to) : !1
    }
}

function Qt(n, t) {
    if (t.scale == 1) return n;
    let e = t.toDOM(n.top),
        i = t.toDOM(n.bottom);
    return new it(n.from, n.length, e, i - e, Array.isArray(n._content) ? n._content.map(s => Qt(s, t)) : n._content)
}
const Oe = C.define({
        combine: n => n.join(" ")
    }),
    Ri = C.define({
        combine: n => n.indexOf(!0) > -1
    }),
    Ei = Ht.newName(),
    rr = Ht.newName(),
    or = Ht.newName(),
    lr = {
        "&light": "." + rr,
        "&dark": "." + or
    };

function Bi(n, t, e) {
    return new Ht(t, {
        finish(i) {
            return /&/.test(i) ? i.replace(/&\w*/, s => {
                if (s == "&") return n;
                if (!e || !e[s]) throw new RangeError("Unsupported selector: ".concat(s));
                return e[s]
            }) : n + " " + i
        }
    })
}
const Zo = Bi("." + Ei, {
        "&": {
            position: "relative !important",
            boxSizing: "border-box",
            "&.cm-focused": {
                outline: "1px dotted #212121"
            },
            display: "flex !important",
            flexDirection: "column"
        },
        ".cm-scroller": {
            display: "flex !important",
            alignItems: "flex-start !important",
            fontFamily: "monospace",
            lineHeight: 1.4,
            height: "100%",
            overflowX: "auto",
            position: "relative",
            zIndex: 0
        },
        ".cm-content": {
            margin: 0,
            flexGrow: 2,
            flexShrink: 0,
            display: "block",
            whiteSpace: "pre",
            wordWrap: "normal",
            boxSizing: "border-box",
            minHeight: "100%",
            padding: "4px 0",
            outline: "none",
            "&[contenteditable=true]": {
                WebkitUserModify: "read-write-plaintext-only"
            }
        },
        ".cm-lineWrapping": {
            whiteSpace_fallback: "pre-wrap",
            whiteSpace: "break-spaces",
            wordBreak: "break-word",
            overflowWrap: "anywhere",
            flexShrink: 1
        },
        "&light .cm-content": {
            caretColor: "black"
        },
        "&dark .cm-content": {
            caretColor: "white"
        },
        ".cm-line": {
            display: "block",
            padding: "0 2px 0 6px"
        },
        ".cm-layer": {
            position: "absolute",
            left: 0,
            top: 0,
            contain: "size style",
            "& > *": {
                position: "absolute"
            }
        },
        "&light .cm-selectionBackground": {
            background: "#d9d9d9"
        },
        "&dark .cm-selectionBackground": {
            background: "#222"
        },
        "&light.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground": {
            background: "#d7d4f0"
        },
        "&dark.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground": {
            background: "#233"
        },
        ".cm-cursorLayer": {
            pointerEvents: "none"
        },
        "&.cm-focused > .cm-scroller > .cm-cursorLayer": {
            animation: "steps(1) cm-blink 1.2s infinite"
        },
        "@keyframes cm-blink": {
            "0%": {},
            "50%": {
                opacity: 0
            },
            "100%": {}
        },
        "@keyframes cm-blink2": {
            "0%": {},
            "50%": {
                opacity: 0
            },
            "100%": {}
        },
        ".cm-cursor, .cm-dropCursor": {
            borderLeft: "1.2px solid black",
            marginLeft: "-0.6px",
            pointerEvents: "none"
        },
        ".cm-cursor": {
            display: "none"
        },
        "&dark .cm-cursor": {
            borderLeftColor: "#444"
        },
        ".cm-dropCursor": {
            position: "absolute"
        },
        "&.cm-focused > .cm-scroller > .cm-cursorLayer .cm-cursor": {
            display: "block"
        },
        ".cm-iso": {
            unicodeBidi: "isolate"
        },
        ".cm-announced": {
            position: "fixed",
            top: "-10000px"
        },
        "@media print": {
            ".cm-announced": {
                display: "none"
            }
        },
        "&light .cm-activeLine": {
            backgroundColor: "#cceeff44"
        },
        "&dark .cm-activeLine": {
            backgroundColor: "#99eeff33"
        },
        "&light .cm-specialChar": {
            color: "red"
        },
        "&dark .cm-specialChar": {
            color: "#f78"
        },
        ".cm-gutters": {
            flexShrink: 0,
            display: "flex",
            height: "100%",
            boxSizing: "border-box",
            insetInlineStart: 0,
            zIndex: 200
        },
        "&light .cm-gutters": {
            backgroundColor: "#f5f5f5",
            color: "#6c6c6c",
            borderRight: "1px solid #ddd"
        },
        "&dark .cm-gutters": {
            backgroundColor: "#333338",
            color: "#ccc"
        },
        ".cm-gutter": {
            display: "flex !important",
            flexDirection: "column",
            flexShrink: 0,
            boxSizing: "border-box",
            minHeight: "100%",
            overflow: "hidden"
        },
        ".cm-gutterElement": {
            boxSizing: "border-box"
        },
        ".cm-lineNumbers .cm-gutterElement": {
            padding: "0 3px 0 5px",
            minWidth: "20px",
            textAlign: "right",
            whiteSpace: "nowrap"
        },
        "&light .cm-activeLineGutter": {
            backgroundColor: "#e2f2ff"
        },
        "&dark .cm-activeLineGutter": {
            backgroundColor: "#222227"
        },
        ".cm-panels": {
            boxSizing: "border-box",
            position: "sticky",
            left: 0,
            right: 0
        },
        "&light .cm-panels": {
            backgroundColor: "#f5f5f5",
            color: "black"
        },
        "&light .cm-panels-top": {
            borderBottom: "1px solid #ddd"
        },
        "&light .cm-panels-bottom": {
            borderTop: "1px solid #ddd"
        },
        "&dark .cm-panels": {
            backgroundColor: "#333338",
            color: "white"
        },
        ".cm-tab": {
            display: "inline-block",
            overflow: "hidden",
            verticalAlign: "bottom"
        },
        ".cm-widgetBuffer": {
            verticalAlign: "text-top",
            height: "1em",
            width: 0,
            display: "inline"
        },
        ".cm-placeholder": {
            color: "#888",
            display: "inline-block",
            verticalAlign: "top"
        },
        ".cm-highlightSpace:before": {
            content: "attr(data-display)",
            position: "absolute",
            pointerEvents: "none",
            color: "#888"
        },
        ".cm-highlightTab": {
            backgroundImage: 'url(\'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="200" height="20"><path stroke="%23888" stroke-width="1" fill="none" d="M1 10H196L190 5M190 15L196 10M197 4L197 16"/></svg>\')',
            backgroundSize: "auto 100%",
            backgroundPosition: "right 90%",
            backgroundRepeat: "no-repeat"
        },
        ".cm-trailingSpace": {
            backgroundColor: "#ff332255"
        },
        ".cm-button": {
            verticalAlign: "middle",
            color: "inherit",
            fontSize: "70%",
            padding: ".2em 1em",
            borderRadius: "1px"
        },
        "&light .cm-button": {
            backgroundImage: "linear-gradient(#eff1f5, #d9d9df)",
            border: "1px solid #888",
            "&:active": {
                backgroundImage: "linear-gradient(#b4b4b4, #d0d3d6)"
            }
        },
        "&dark .cm-button": {
            backgroundImage: "linear-gradient(#393939, #111)",
            border: "1px solid #888",
            "&:active": {
                backgroundImage: "linear-gradient(#111, #333)"
            }
        },
        ".cm-textfield": {
            verticalAlign: "middle",
            color: "inherit",
            fontSize: "70%",
            border: "1px solid silver",
            padding: ".2em .5em"
        },
        "&light .cm-textfield": {
            backgroundColor: "white"
        },
        "&dark .cm-textfield": {
            border: "1px solid #555",
            backgroundColor: "inherit"
        }
    }, lr),
    Zt = "￿";
class _o {
    constructor(t, e) {
        this.points = t, this.text = "", this.lineSeparator = e.facet(B.lineSeparator)
    }
    append(t) {
        this.text += t
    }
    lineBreak() {
        this.text += Zt
    }
    readRange(t, e) {
        if (!t) return this;
        let i = t.parentNode;
        for (let s = t;;) {
            this.findPointBefore(i, s);
            let r = this.text.length;
            this.readNode(s);
            let o = s.nextSibling;
            if (o == e) break;
            let l = R.get(s),
                h = R.get(o);
            (l && h ? l.breakAfter : (l ? l.breakAfter : Fe(s)) || Fe(o) && (s.nodeName != "BR" || s.cmIgnore) && this.text.length > r) && this.lineBreak(), s = o
        }
        return this.findPointBefore(i, e), this
    }
    readTextNode(t) {
        let e = t.nodeValue;
        for (let i of this.points) i.node == t && (i.pos = this.text.length + Math.min(i.offset, e.length));
        for (let i = 0, s = this.lineSeparator ? null : /\r\n?|\n/g;;) {
            let r = -1,
                o = 1,
                l;
            if (this.lineSeparator ? (r = e.indexOf(this.lineSeparator, i), o = this.lineSeparator.length) : (l = s.exec(e)) && (r = l.index, o = l[0].length), this.append(e.slice(i, r < 0 ? e.length : r)), r < 0) break;
            if (this.lineBreak(), o > 1)
                for (let h of this.points) h.node == t && h.pos > this.text.length && (h.pos -= o - 1);
            i = r + o
        }
    }
    readNode(t) {
        if (t.cmIgnore) return;
        let e = R.get(t),
            i = e && e.overrideDOMText;
        if (i != null) {
            this.findPointInside(t, i.length);
            for (let s = i.iter(); !s.next().done;) s.lineBreak ? this.lineBreak() : this.append(s.value)
        } else t.nodeType == 3 ? this.readTextNode(t) : t.nodeName == "BR" ? t.nextSibling && this.lineBreak() : t.nodeType == 1 && this.readRange(t.firstChild, null)
    }
    findPointBefore(t, e) {
        for (let i of this.points) i.node == t && t.childNodes[i.offset] == e && (i.pos = this.text.length)
    }
    findPointInside(t, e) {
        for (let i of this.points)(t.nodeType == 3 ? i.node == t : t.contains(i.node)) && (i.pos = this.text.length + (tl(t, i.node, i.offset) ? e : 0))
    }
}

function tl(n, t, e) {
    for (;;) {
        if (!t || e < ct(t)) return !1;
        if (t == n) return !0;
        e = At(t) + 1, t = t.parentNode
    }
}
class Ps {
    constructor(t, e) {
        this.node = t, this.offset = e, this.pos = -1
    }
}
class el {
    constructor(t, e, i, s) {
        this.typeOver = s, this.bounds = null, this.text = "", this.domChanged = e > -1;
        let {
            impreciseHead: r,
            impreciseAnchor: o
        } = t.docView;
        if (t.state.readOnly && e > -1) this.newSel = null;
        else if (e > -1 && (this.bounds = t.docView.domBoundsAround(e, i, 0))) {
            let l = r || o ? [] : nl(t),
                h = new _o(l, t.state);
            h.readRange(this.bounds.startDOM, this.bounds.endDOM), this.text = h.text, this.newSel = rl(l, this.bounds.from)
        } else {
            let l = t.observer.selectionRange,
                h = r && r.node == l.focusNode && r.offset == l.focusOffset || !mi(t.contentDOM, l.focusNode) ? t.state.selection.main.head : t.docView.posFromDOM(l.focusNode, l.focusOffset),
                f = o && o.node == l.anchorNode && o.offset == l.anchorOffset || !mi(t.contentDOM, l.anchorNode) ? t.state.selection.main.anchor : t.docView.posFromDOM(l.anchorNode, l.anchorOffset),
                a = t.viewport;
            if ((b.ios || b.chrome) && t.state.selection.main.empty && h != f && (a.from > 0 || a.to < t.state.doc.length)) {
                let c = Math.min(h, f),
                    u = Math.max(h, f),
                    d = a.from - c,
                    g = a.to - u;
                (d == 0 || d == 1 || c == 0) && (g == 0 || g == -1 || u == t.state.doc.length) && (h = 0, f = t.state.doc.length)
            }
            this.newSel = S.single(f, h)
        }
    }
}

function hr(n, t) {
    let e, {
            newSel: i
        } = t,
        s = n.state.selection.main,
        r = n.inputState.lastKeyTime > Date.now() - 100 ? n.inputState.lastKeyCode : -1;
    if (t.bounds) {
        let {
            from: o,
            to: l
        } = t.bounds, h = s.from, f = null;
        (r === 8 || b.android && t.text.length < l - o) && (h = s.to, f = "end");
        let a = sl(n.state.doc.sliceString(o, l, Zt), t.text, h - o, f);
        a && (b.chrome && r == 13 && a.toB == a.from + 2 && t.text.slice(a.from, a.toB) == Zt + Zt && a.toB--, e = {
            from: o + a.from,
            to: o + a.toA,
            insert: O.of(t.text.slice(a.from, a.toB).split(Zt))
        })
    } else i && (!n.hasFocus && n.state.facet(pt) || i.main.eq(s)) && (i = null);
    if (!e && !i) return !1;
    if (!e && t.typeOver && !s.empty && i && i.main.empty ? e = {
            from: s.from,
            to: s.to,
            insert: n.state.doc.slice(s.from, s.to)
        } : e && e.from >= s.from && e.to <= s.to && (e.from != s.from || e.to != s.to) && s.to - s.from - (e.to - e.from) <= 4 ? e = {
            from: s.from,
            to: s.to,
            insert: n.state.doc.slice(s.from, e.from).append(e.insert).append(n.state.doc.slice(e.to, s.to))
        } : (b.mac || b.android) && e && e.from == e.to && e.from == s.head - 1 && /^\. ?$/.test(e.insert.toString()) && n.contentDOM.getAttribute("autocorrect") == "off" ? (i && e.insert.length == 2 && (i = S.single(i.main.anchor - 1, i.main.head - 1)), e = {
            from: s.from,
            to: s.to,
            insert: O.of([" "])
        }) : b.chrome && e && e.from == e.to && e.from == s.head && e.insert.toString() == "\n " && n.lineWrapping && (i && (i = S.single(i.main.anchor - 1, i.main.head - 1)), e = {
            from: s.from,
            to: s.to,
            insert: O.of([" "])
        }), e) return ar(n, e, i, r);
    if (i && !i.main.eq(s)) {
        let o = !1,
            l = "select";
        return n.inputState.lastSelectionTime > Date.now() - 50 && (n.inputState.lastSelectionOrigin == "select" && (o = !0), l = n.inputState.lastSelectionOrigin), n.dispatch({
            selection: i,
            scrollIntoView: o,
            userEvent: l
        }), !0
    } else return !1
}

function ar(n, t, e, i = -1) {
    if (b.ios && n.inputState.flushIOSKey(t)) return !0;
    let s = n.state.selection.main;
    if (b.android && (t.to == s.to && (t.from == s.from || t.from == s.from - 1 && n.state.sliceDoc(t.from, s.from) == " ") && t.insert.length == 1 && t.insert.lines == 2 && Lt(n.contentDOM, "Enter", 13) || (t.from == s.from - 1 && t.to == s.to && t.insert.length == 0 || i == 8 && t.insert.length < t.to - t.from && t.to > s.head) && Lt(n.contentDOM, "Backspace", 8) || t.from == s.from && t.to == s.to + 1 && t.insert.length == 0 && Lt(n.contentDOM, "Delete", 46))) return !0;
    let r = t.insert.toString();
    n.inputState.composing >= 0 && n.inputState.composing++;
    let o, l = () => o || (o = il(n, t, e));
    return n.state.facet(Vn).some(h => h(n, t.from, t.to, r, l)) || n.dispatch(l()), !0
}

function il(n, t, e) {
    let i, s = n.state,
        r = s.selection.main;
    if (t.from >= r.from && t.to <= r.to && t.to - t.from >= (r.to - r.from) / 3 && (!e || e.main.empty && e.main.from == t.from + t.insert.length) && n.inputState.composing < 0) {
        let l = r.from < t.from ? s.sliceDoc(r.from, t.from) : "",
            h = r.to > t.to ? s.sliceDoc(t.to, r.to) : "";
        i = s.replaceSelection(n.state.toText(l + t.insert.sliceString(0, void 0, n.state.lineBreak) + h))
    } else {
        let l = s.changes(t),
            h = e && e.main.to <= l.newLength ? e.main : void 0;
        if (s.selection.ranges.length > 1 && n.inputState.composing >= 0 && t.to <= r.to && t.to >= r.to - 10) {
            let f = n.state.sliceDoc(t.from, t.to),
                a, c = e && Yn(n, e.main.head);
            if (c) {
                let g = t.insert.length - (t.to - t.from);
                a = {
                    from: c.from,
                    to: c.to - g
                }
            } else a = n.state.doc.lineAt(r.head);
            let u = r.to - t.to,
                d = r.to - r.from;
            i = s.changeByRange(g => {
                if (g.from == r.from && g.to == r.to) return {
                    changes: l,
                    range: h || g.map(l)
                };
                let m = g.to - u,
                    p = m - f.length;
                if (g.to - g.from != d || n.state.sliceDoc(p, m) != f || g.to >= a.from && g.from <= a.to) return {
                    range: g
                };
                let w = s.changes({
                        from: p,
                        to: m,
                        insert: t.insert
                    }),
                    y = g.to - r.to;
                return {
                    changes: w,
                    range: h ? S.range(Math.max(0, h.anchor + y), Math.max(0, h.head + y)) : g.map(w)
                }
            })
        } else i = {
            changes: l,
            selection: h && s.selection.replaceRange(h)
        }
    }
    let o = "input.type";
    return (n.composing || n.inputState.compositionPendingChange && n.inputState.compositionEndedAt > Date.now() - 50) && (n.inputState.compositionPendingChange = !1, o += ".compose", n.inputState.compositionFirstChange && (o += ".start", n.inputState.compositionFirstChange = !1)), s.update(i, {
        userEvent: o,
        scrollIntoView: !0
    })
}

function sl(n, t, e, i) {
    let s = Math.min(n.length, t.length),
        r = 0;
    for (; r < s && n.charCodeAt(r) == t.charCodeAt(r);) r++;
    if (r == s && n.length == t.length) return null;
    let o = n.length,
        l = t.length;
    for (; o > 0 && l > 0 && n.charCodeAt(o - 1) == t.charCodeAt(l - 1);) o--, l--;
    if (i == "end") {
        let h = Math.max(0, r - Math.min(o, l));
        e -= o + h - r
    }
    if (o < r && n.length < t.length) {
        let h = e <= r && e >= o ? r - e : 0;
        r -= h, l = r + (l - o), o = r
    } else if (l < r) {
        let h = e <= r && e >= l ? r - e : 0;
        r -= h, o = r + (o - l), l = r
    }
    return {
        from: r,
        toA: o,
        toB: l
    }
}

function nl(n) {
    let t = [];
    if (n.root.activeElement != n.contentDOM) return t;
    let {
        anchorNode: e,
        anchorOffset: i,
        focusNode: s,
        focusOffset: r
    } = n.observer.selectionRange;
    return e && (t.push(new Ps(e, i)), (s != e || r != i) && t.push(new Ps(s, r))), t
}

function rl(n, t) {
    if (n.length == 0) return null;
    let e = n[0].pos,
        i = n.length == 2 ? n[1].pos : e;
    return e > -1 && i > -1 ? S.single(e + t, i + t) : null
}
const ol = {
        childList: !0,
        characterData: !0,
        subtree: !0,
        attributes: !0,
        characterDataOldValue: !0
    },
    Ze = b.ie && b.ie_version <= 11;
class ll {
    constructor(t) {
        this.view = t, this.active = !1, this.editContext = null, this.selectionRange = new Kr, this.selectionChanged = !1, this.delayedFlush = -1, this.resizeTimeout = -1, this.queue = [], this.delayedAndroidKey = null, this.flushingAndroidKey = -1, this.lastChange = 0, this.scrollTargets = [], this.intersection = null, this.resizeScroll = null, this.intersecting = !1, this.gapIntersection = null, this.gaps = [], this.printQuery = null, this.parentCheck = -1, this.dom = t.contentDOM, this.observer = new MutationObserver(e => {
            for (let i of e) this.queue.push(i);
            (b.ie && b.ie_version <= 11 || b.ios && t.composing) && e.some(i => i.type == "childList" && i.removedNodes.length || i.type == "characterData" && i.oldValue.length > i.target.nodeValue.length) ? this.flushSoon() : this.flush()
        }), window.EditContext && t.constructor.EDIT_CONTEXT !== !1 && !(b.chrome && b.chrome_version < 126) && (this.editContext = new al(t), t.state.facet(pt) && (t.contentDOM.editContext = this.editContext.editContext)), Ze && (this.onCharData = e => {
            this.queue.push({
                target: e.target,
                type: "characterData",
                oldValue: e.prevValue
            }), this.flushSoon()
        }), this.onSelectionChange = this.onSelectionChange.bind(this), this.onResize = this.onResize.bind(this), this.onPrint = this.onPrint.bind(this), this.onScroll = this.onScroll.bind(this), window.matchMedia && (this.printQuery = window.matchMedia("print")), typeof ResizeObserver == "function" && (this.resizeScroll = new ResizeObserver(() => {
            var e;
            ((e = this.view.docView) === null || e === void 0 ? void 0 : e.lastUpdate) < Date.now() - 75 && this.onResize()
        }), this.resizeScroll.observe(t.scrollDOM)), this.addWindowListeners(this.win = t.win), this.start(), typeof IntersectionObserver == "function" && (this.intersection = new IntersectionObserver(e => {
            this.parentCheck < 0 && (this.parentCheck = setTimeout(this.listenForScroll.bind(this), 1e3)), e.length > 0 && e[e.length - 1].intersectionRatio > 0 != this.intersecting && (this.intersecting = !this.intersecting, this.intersecting != this.view.inView && this.onScrollChanged(document.createEvent("Event")))
        }, {
            threshold: [0, .001]
        }), this.intersection.observe(this.dom), this.gapIntersection = new IntersectionObserver(e => {
            e.length > 0 && e[e.length - 1].intersectionRatio > 0 && this.onScrollChanged(document.createEvent("Event"))
        }, {})), this.listenForScroll(), this.readSelectionRange()
    }
    onScrollChanged(t) {
        this.view.inputState.runHandlers("scroll", t), this.intersecting && this.view.measure()
    }
    onScroll(t) {
        this.intersecting && this.flush(!1), this.editContext && this.view.requestMeasure(this.editContext.measureReq), this.onScrollChanged(t)
    }
    onResize() {
        this.resizeTimeout < 0 && (this.resizeTimeout = setTimeout(() => {
            this.resizeTimeout = -1, this.view.requestMeasure()
        }, 50))
    }
    onPrint(t) {
        t.type == "change" && !t.matches || (this.view.viewState.printing = !0, this.view.measure(), setTimeout(() => {
            this.view.viewState.printing = !1, this.view.requestMeasure()
        }, 500))
    }
    updateGaps(t) {
        if (this.gapIntersection && (t.length != this.gaps.length || this.gaps.some((e, i) => e != t[i]))) {
            this.gapIntersection.disconnect();
            for (let e of t) this.gapIntersection.observe(e);
            this.gaps = t
        }
    }
    onSelectionChange(t) {
        let e = this.selectionChanged;
        if (!this.readSelectionRange() || this.delayedAndroidKey) return;
        let {
            view: i
        } = this, s = this.selectionRange;
        if (i.state.facet(pt) ? i.root.activeElement != this.dom : !Ee(i.dom, s)) return;
        let r = s.anchorNode && i.docView.nearest(s.anchorNode);
        if (r && r.ignoreEvent(t)) {
            e || (this.selectionChanged = !1);
            return
        }(b.ie && b.ie_version <= 11 || b.android && b.chrome) && !i.state.selection.main.empty && s.focusNode && ie(s.focusNode, s.focusOffset, s.anchorNode, s.anchorOffset) ? this.flushSoon() : this.flush(!1)
    }
    readSelectionRange() {
        let {
            view: t
        } = this, e = ae(t.root);
        if (!e) return !1;
        let i = b.safari && t.root.nodeType == 11 && Fr(this.dom.ownerDocument) == this.dom && hl(this.view, e) || e;
        if (!i || this.selectionRange.eq(i)) return !1;
        let s = Ee(this.dom, i);
        return s && !this.selectionChanged && t.inputState.lastFocusTime > Date.now() - 200 && t.inputState.lastTouchTime < Date.now() - 300 && $r(this.dom, i) ? (this.view.inputState.lastFocusTime = 0, t.docView.updateSelection(), !1) : (this.selectionRange.setRange(i), s && (this.selectionChanged = !0), !0)
    }
    setSelectionRange(t, e) {
        this.selectionRange.set(t.node, t.offset, e.node, e.offset), this.selectionChanged = !1
    }
    clearSelectionRange() {
        this.selectionRange.set(null, 0, null, 0)
    }
    listenForScroll() {
        this.parentCheck = -1;
        let t = 0,
            e = null;
        for (let i = this.dom; i;)
            if (i.nodeType == 1) !e && t < this.scrollTargets.length && this.scrollTargets[t] == i ? t++ : e || (e = this.scrollTargets.slice(0, t)), e && e.push(i), i = i.assignedSlot || i.parentNode;
            else if (i.nodeType == 11) i = i.host;
        else break;
        if (t < this.scrollTargets.length && !e && (e = this.scrollTargets.slice(0, t)), e) {
            for (let i of this.scrollTargets) i.removeEventListener("scroll", this.onScroll);
            for (let i of this.scrollTargets = e) i.addEventListener("scroll", this.onScroll)
        }
    }
    ignore(t) {
        if (!this.active) return t();
        try {
            return this.stop(), t()
        } finally {
            this.start(), this.clear()
        }
    }
    start() {
        this.active || (this.observer.observe(this.dom, ol), Ze && this.dom.addEventListener("DOMCharacterDataModified", this.onCharData), this.active = !0)
    }
    stop() {
        this.active && (this.active = !1, this.observer.disconnect(), Ze && this.dom.removeEventListener("DOMCharacterDataModified", this.onCharData))
    }
    clear() {
        this.processRecords(), this.queue.length = 0, this.selectionChanged = !1
    }
    delayAndroidKey(t, e) {
        var i;
        if (!this.delayedAndroidKey) {
            let s = () => {
                let r = this.delayedAndroidKey;
                r && (this.clearDelayedAndroidKey(), this.view.inputState.lastKeyCode = r.keyCode, this.view.inputState.lastKeyTime = Date.now(), !this.flush() && r.force && Lt(this.dom, r.key, r.keyCode))
            };
            this.flushingAndroidKey = this.view.win.requestAnimationFrame(s)
        }(!this.delayedAndroidKey || t == "Enter") && (this.delayedAndroidKey = {
            key: t,
            keyCode: e,
            force: this.lastChange < Date.now() - 50 || !!(!((i = this.delayedAndroidKey) === null || i === void 0) && i.force)
        })
    }
    clearDelayedAndroidKey() {
        this.win.cancelAnimationFrame(this.flushingAndroidKey), this.delayedAndroidKey = null, this.flushingAndroidKey = -1
    }
    flushSoon() {
        this.delayedFlush < 0 && (this.delayedFlush = this.view.win.requestAnimationFrame(() => {
            this.delayedFlush = -1, this.flush()
        }))
    }
    forceFlush() {
        this.delayedFlush >= 0 && (this.view.win.cancelAnimationFrame(this.delayedFlush), this.delayedFlush = -1), this.flush()
    }
    pendingRecords() {
        for (let t of this.observer.takeRecords()) this.queue.push(t);
        return this.queue
    }
    processRecords() {
        let t = this.pendingRecords();
        t.length && (this.queue = []);
        let e = -1,
            i = -1,
            s = !1;
        for (let r of t) {
            let o = this.readMutation(r);
            o && (o.typeOver && (s = !0), e == -1 ? {
                from: e,
                to: i
            } = o : (e = Math.min(o.from, e), i = Math.max(o.to, i)))
        }
        return {
            from: e,
            to: i,
            typeOver: s
        }
    }
    readChange() {
        let {
            from: t,
            to: e,
            typeOver: i
        } = this.processRecords(), s = this.selectionChanged && Ee(this.dom, this.selectionRange);
        if (t < 0 && !s) return null;
        t > -1 && (this.lastChange = Date.now()), this.view.inputState.lastFocusTime = 0, this.selectionChanged = !1;
        let r = new el(this.view, t, e, i);
        return this.view.docView.domChanged = {
            newSel: r.newSel ? r.newSel.main : null
        }, r
    }
    flush(t = !0) {
        if (this.delayedFlush >= 0 || this.delayedAndroidKey) return !1;
        t && this.readSelectionRange();
        let e = this.readChange();
        if (!e) return this.view.requestMeasure(), !1;
        let i = this.view.state,
            s = hr(this.view, e);
        return this.view.state == i && (e.domChanged || e.newSel && !e.newSel.main.eq(this.view.state.selection.main)) && this.view.update([]), s
    }
    readMutation(t) {
        let e = this.view.docView.nearest(t.target);
        if (!e || e.ignoreMutation(t)) return null;
        if (e.markDirty(t.type == "attributes"), t.type == "attributes" && (e.flags |= 4), t.type == "childList") {
            let i = Ls(e, t.previousSibling || t.target.previousSibling, -1),
                s = Ls(e, t.nextSibling || t.target.nextSibling, 1);
            return {
                from: i ? e.posAfter(i) : e.posAtStart,
                to: s ? e.posBefore(s) : e.posAtEnd,
                typeOver: !1
            }
        } else return t.type == "characterData" ? {
            from: e.posAtStart,
            to: e.posAtEnd,
            typeOver: t.target.nodeValue == t.oldValue
        } : null
    }
    setWindow(t) {
        t != this.win && (this.removeWindowListeners(this.win), this.win = t, this.addWindowListeners(this.win))
    }
    addWindowListeners(t) {
        t.addEventListener("resize", this.onResize), this.printQuery ? this.printQuery.addEventListener("change", this.onPrint) : t.addEventListener("beforeprint", this.onPrint), t.addEventListener("scroll", this.onScroll), t.document.addEventListener("selectionchange", this.onSelectionChange)
    }
    removeWindowListeners(t) {
        t.removeEventListener("scroll", this.onScroll), t.removeEventListener("resize", this.onResize), this.printQuery ? this.printQuery.removeEventListener("change", this.onPrint) : t.removeEventListener("beforeprint", this.onPrint), t.document.removeEventListener("selectionchange", this.onSelectionChange)
    }
    update(t) {
        this.editContext && (this.editContext.update(t), t.startState.facet(pt) != t.state.facet(pt) && (t.view.contentDOM.editContext = t.state.facet(pt) ? this.editContext.editContext : null))
    }
    destroy() {
        var t, e, i;
        this.stop(), (t = this.intersection) === null || t === void 0 || t.disconnect(), (e = this.gapIntersection) === null || e === void 0 || e.disconnect(), (i = this.resizeScroll) === null || i === void 0 || i.disconnect();
        for (let s of this.scrollTargets) s.removeEventListener("scroll", this.onScroll);
        this.removeWindowListeners(this.win), clearTimeout(this.parentCheck), clearTimeout(this.resizeTimeout), this.win.cancelAnimationFrame(this.delayedFlush), this.win.cancelAnimationFrame(this.flushingAndroidKey), this.editContext && (this.view.contentDOM.editContext = null, this.editContext.destroy())
    }
}

function Ls(n, t, e) {
    for (; t;) {
        let i = R.get(t);
        if (i && i.parent == n) return i;
        let s = t.parentNode;
        t = s != n.dom ? s : e > 0 ? t.nextSibling : t.previousSibling
    }
    return null
}

function Ns(n, t) {
    let e = t.startContainer,
        i = t.startOffset,
        s = t.endContainer,
        r = t.endOffset,
        o = n.docView.domAtPos(n.state.selection.main.anchor);
    return ie(o.node, o.offset, s, r) && ([e, i, s, r] = [s, r, e, i]), {
        anchorNode: e,
        anchorOffset: i,
        focusNode: s,
        focusOffset: r
    }
}

function hl(n, t) {
    if (t.getComposedRanges) {
        let s = t.getComposedRanges(n.root)[0];
        if (s) return Ns(n, s)
    }
    let e = null;

    function i(s) {
        s.preventDefault(), s.stopImmediatePropagation(), e = s.getTargetRanges()[0]
    }
    return n.contentDOM.addEventListener("beforeinput", i, !0), n.dom.ownerDocument.execCommand("indent"), n.contentDOM.removeEventListener("beforeinput", i, !0), e ? Ns(n, e) : null
}
class al {
    constructor(t) {
        this.from = 0, this.to = 0, this.pendingContextChange = null, this.handlers = Object.create(null), this.resetRange(t.state);
        let e = this.editContext = new window.EditContext({
            text: t.state.doc.sliceString(this.from, this.to),
            selectionStart: this.toContextPos(Math.max(this.from, Math.min(this.to, t.state.selection.main.anchor))),
            selectionEnd: this.toContextPos(t.state.selection.main.head)
        });
        this.handlers.textupdate = i => {
            let {
                anchor: s
            } = t.state.selection.main, r = {
                from: this.toEditorPos(i.updateRangeStart),
                to: this.toEditorPos(i.updateRangeEnd),
                insert: O.of(i.text.split("\n"))
            };
            r.from == this.from && s < this.from ? r.from = s : r.to == this.to && s > this.to && (r.to = s), !(r.from == r.to && !r.insert.length) && (this.pendingContextChange = r, ar(t, r, S.single(this.toEditorPos(i.selectionStart), this.toEditorPos(i.selectionEnd))), this.pendingContextChange && (this.revertPending(t.state), this.setSelection(t.state)))
        }, this.handlers.characterboundsupdate = i => {
            let s = [],
                r = null;
            for (let o = this.toEditorPos(i.rangeStart), l = this.toEditorPos(i.rangeEnd); o < l; o++) {
                let h = t.coordsForChar(o);
                r = h && new DOMRect(h.left, h.top, h.right - h.left, h.bottom - h.top) || r || new DOMRect, s.push(r)
            }
            e.updateCharacterBounds(i.rangeStart, s)
        }, this.handlers.textformatupdate = i => {
            let s = [];
            for (let r of i.getTextFormats()) {
                let o = r.underlineStyle,
                    l = r.underlineThickness;
                if (o != "None" && l != "None") {
                    let h = "text-decoration: underline ".concat(o == "Dashed" ? "dashed " : o == "Squiggle" ? "wavy " : "").concat(l == "Thin" ? 1 : 2, "px");
                    s.push(V.mark({
                        attributes: {
                            style: h
                        }
                    }).range(this.toEditorPos(r.rangeStart), this.toEditorPos(r.rangeEnd)))
                }
            }
            t.dispatch({
                effects: zn.of(V.set(s))
            })
        }, this.handlers.compositionstart = () => {
            t.inputState.composing < 0 && (t.inputState.composing = 0, t.inputState.compositionFirstChange = !0)
        }, this.handlers.compositionend = () => {
            t.inputState.composing = -1, t.inputState.compositionFirstChange = null
        };
        for (let i in this.handlers) e.addEventListener(i, this.handlers[i]);
        this.measureReq = {
            read: i => {
                this.editContext.updateControlBounds(i.contentDOM.getBoundingClientRect());
                let s = ae(i.root);
                s && s.rangeCount && this.editContext.updateSelectionBounds(s.getRangeAt(0).getBoundingClientRect())
            }
        }
    }
    applyEdits(t) {
        let e = 0,
            i = !1,
            s = this.pendingContextChange;
        return t.changes.iterChanges((r, o, l, h, f) => {
            if (i) return;
            let a = f.length - (o - r);
            if (s && o >= s.to)
                if (s.from == r && s.to == o && s.insert.eq(f)) {
                    s = this.pendingContextChange = null, e += a, this.to += a;
                    return
                } else s = null, this.revertPending(t.state);
            if (r += e, o += e, o <= this.from) this.from += a, this.to += a;
            else if (r < this.to) {
                if (r < this.from || o > this.to || this.to - this.from + f.length > 3e4) {
                    i = !0;
                    return
                }
                this.editContext.updateText(this.toContextPos(r), this.toContextPos(o), f.toString()), this.to += a
            }
            e += a
        }), s && !i && this.revertPending(t.state), !i
    }
    update(t) {
        let e = this.pendingContextChange;
        !this.applyEdits(t) || !this.rangeIsValid(t.state) ? (this.pendingContextChange = null, this.resetRange(t.state), this.editContext.updateText(0, this.editContext.text.length, t.state.doc.sliceString(this.from, this.to)), this.setSelection(t.state)) : (t.docChanged || t.selectionSet || e) && this.setSelection(t.state), (t.geometryChanged || t.docChanged || t.selectionSet) && t.view.requestMeasure(this.measureReq)
    }
    resetRange(t) {
        let {
            head: e
        } = t.selection.main;
        this.from = Math.max(0, e - 1e4), this.to = Math.min(t.doc.length, e + 1e4)
    }
    revertPending(t) {
        let e = this.pendingContextChange;
        this.pendingContextChange = null, this.editContext.updateText(this.toContextPos(e.from), this.toContextPos(e.from + e.insert.length), t.doc.sliceString(e.from, e.to))
    }
    setSelection(t) {
        let {
            main: e
        } = t.selection, i = this.toContextPos(Math.max(this.from, Math.min(this.to, e.anchor))), s = this.toContextPos(e.head);
        (this.editContext.selectionStart != i || this.editContext.selectionEnd != s) && this.editContext.updateSelection(i, s)
    }
    rangeIsValid(t) {
        let {
            head: e
        } = t.selection.main;
        return !(this.from > 0 && e - this.from < 500 || this.to < t.doc.length && this.to - e < 500 || this.to - this.from > 1e4 * 3)
    }
    toEditorPos(t) {
        return t + this.from
    }
    toContextPos(t) {
        return t - this.from
    }
    destroy() {
        for (let t in this.handlers) this.editContext.removeEventListener(t, this.handlers[t])
    }
}
class D {
    get state() {
        return this.viewState.state
    }
    get viewport() {
        return this.viewState.viewport
    }
    get visibleRanges() {
        return this.viewState.visibleRanges
    }
    get inView() {
        return this.viewState.inView
    }
    get composing() {
        return this.inputState.composing > 0
    }
    get compositionStarted() {
        return this.inputState.composing >= 0
    }
    get root() {
        return this._root
    }
    get win() {
        return this.dom.ownerDocument.defaultView || window
    }
    constructor(t = {}) {
        this.plugins = [], this.pluginMap = new Map, this.editorAttrs = {}, this.contentAttrs = {}, this.bidiCache = [], this.destroyed = !1, this.updateState = 2, this.measureScheduled = -1, this.measureRequests = [], this.contentDOM = document.createElement("div"), this.scrollDOM = document.createElement("div"), this.scrollDOM.tabIndex = -1, this.scrollDOM.className = "cm-scroller", this.scrollDOM.appendChild(this.contentDOM), this.announceDOM = document.createElement("div"), this.announceDOM.className = "cm-announced", this.announceDOM.setAttribute("aria-live", "polite"), this.dom = document.createElement("div"), this.dom.appendChild(this.announceDOM), this.dom.appendChild(this.scrollDOM), t.parent && t.parent.appendChild(this.dom);
        let {
            dispatch: e
        } = t;
        this.dispatchTransactions = t.dispatchTransactions || e && (i => i.forEach(s => e(s, this))) || (i => this.update(i)), this.dispatch = this.dispatch.bind(this), this._root = t.root || jr(t.parent) || document, this.viewState = new Es(t.state || B.create(t)), t.scrollTo && t.scrollTo.is(Se) && (this.viewState.scrollTarget = t.scrollTo.value.clip(this.viewState.state)), this.plugins = this.state.facet(Ut).map(i => new Xe(i));
        for (let i of this.plugins) i.update(this);
        this.observer = new ll(this), this.inputState = new Co(this), this.inputState.ensureHandlers(this.plugins), this.docView = new ds(this), this.mountStyles(), this.updateAttrs(), this.updateState = 0, this.requestMeasure()
    }
    dispatch(...t) {
        let e = t.length == 1 && t[0] instanceof j ? t : t.length == 1 && Array.isArray(t[0]) ? t[0] : [this.state.update(...t)];
        this.dispatchTransactions(e, this)
    }
    update(t) {
        if (this.updateState != 0) throw new Error("Calls to EditorView.update are not allowed while an update is in progress");
        let e = !1,
            i = !1,
            s, r = this.state;
        for (let u of t) {
            if (u.startState != r) throw new RangeError("Trying to update state with a transaction that doesn't start from the previous state.");
            r = u.state
        }
        if (this.destroyed) {
            this.viewState.state = r;
            return
        }
        let o = this.hasFocus,
            l = 0,
            h = null;
        t.some(u => u.annotation(er)) ? (this.inputState.notifiedFocused = o, l = 1) : o != this.inputState.notifiedFocused && (this.inputState.notifiedFocused = o, h = ir(r, o), h || (l = 1));
        let f = this.observer.delayedAndroidKey,
            a = null;
        if (f ? (this.observer.clearDelayedAndroidKey(), a = this.observer.readChange(), (a && !this.state.doc.eq(r.doc) || !this.state.selection.eq(r.selection)) && (a = null)) : this.observer.clear(), r.facet(B.phrases) != this.state.facet(B.phrases)) return this.setState(r);
        s = ze.create(this, r, t), s.flags |= l;
        let c = this.viewState.scrollTarget;
        try {
            this.updateState = 2;
            for (let u of t) {
                if (c && (c = c.map(u.changes)), u.scrollIntoView) {
                    let {
                        main: d
                    } = u.state.selection;
                    c = new Nt(d.empty ? d : S.cursor(d.head, d.head > d.anchor ? -1 : 1))
                }
                for (let d of u.effects) d.is(Se) && (c = d.value.clip(this.state))
            }
            this.viewState.update(s, c), this.bidiCache = qe.update(this.bidiCache, s.changes), s.empty || (this.updatePlugins(s), this.inputState.update(s)), e = this.docView.update(s), this.state.facet(Jt) != this.styleModules && this.mountStyles(), i = this.updateAttrs(), this.showAnnouncements(t), this.docView.updateSelection(e, t.some(u => u.isUserEvent("select.pointer")))
        } finally {
            this.updateState = 0
        }
        if (s.startState.facet(Oe) != s.state.facet(Oe) && (this.viewState.mustMeasureContent = !0), (e || i || c || this.viewState.mustEnforceCursorAssoc || this.viewState.mustMeasureContent) && this.requestMeasure(), e && this.docViewUpdate(), !s.empty)
            for (let u of this.state.facet(Ai)) try {
                u(s)
            } catch (d) {
                ht(this.state, d, "update listener")
            }(h || a) && Promise.resolve().then(() => {
                h && this.state == h.startState && this.dispatch(h), a && !hr(this, a) && f.force && Lt(this.contentDOM, f.key, f.keyCode)
            })
    }
    setState(t) {
        if (this.updateState != 0) throw new Error("Calls to EditorView.setState are not allowed while an update is in progress");
        if (this.destroyed) {
            this.viewState.state = t;
            return
        }
        this.updateState = 2;
        let e = this.hasFocus;
        try {
            for (let i of this.plugins) i.destroy(this);
            this.viewState = new Es(t), this.plugins = t.facet(Ut).map(i => new Xe(i)), this.pluginMap.clear();
            for (let i of this.plugins) i.update(this);
            this.docView.destroy(), this.docView = new ds(this), this.inputState.ensureHandlers(this.plugins), this.mountStyles(), this.updateAttrs(), this.bidiCache = []
        } finally {
            this.updateState = 0
        }
        e && this.focus(), this.requestMeasure()
    }
    updatePlugins(t) {
        let e = t.startState.facet(Ut),
            i = t.state.facet(Ut);
        if (e != i) {
            let s = [];
            for (let r of i) {
                let o = e.indexOf(r);
                if (o < 0) s.push(new Xe(r));
                else {
                    let l = this.plugins[o];
                    l.mustUpdate = t, s.push(l)
                }
            }
            for (let r of this.plugins) r.mustUpdate != t && r.destroy(this);
            this.plugins = s, this.pluginMap.clear()
        } else
            for (let s of this.plugins) s.mustUpdate = t;
        for (let s = 0; s < this.plugins.length; s++) this.plugins[s].update(this);
        e != i && this.inputState.ensureHandlers(this.plugins)
    }
    docViewUpdate() {
        for (let t of this.plugins) {
            let e = t.value;
            if (e && e.docViewUpdate) try {
                e.docViewUpdate(this)
            } catch (i) {
                ht(this.state, i, "doc view update listener")
            }
        }
    }
    measure(t = !0) {
        if (this.destroyed) return;
        if (this.measureScheduled > -1 && this.win.cancelAnimationFrame(this.measureScheduled), this.observer.delayedAndroidKey) {
            this.measureScheduled = -1, this.requestMeasure();
            return
        }
        this.measureScheduled = 0, t && this.observer.forceFlush();
        let e = null,
            i = this.scrollDOM,
            s = i.scrollTop * this.scaleY,
            {
                scrollAnchorPos: r,
                scrollAnchorHeight: o
            } = this.viewState;
        Math.abs(s - this.viewState.scrollTop) > 1 && (o = -1), this.viewState.scrollAnchorHeight = -1;
        try {
            for (let l = 0;; l++) {
                if (o < 0)
                    if (pn(i)) r = -1, o = this.viewState.heightMap.height;
                    else {
                        let d = this.viewState.scrollAnchorAt(s);
                        r = d.from, o = d.top
                    }
                this.updateState = 1;
                let h = this.viewState.measure(this);
                if (!h && !this.measureRequests.length && this.viewState.scrollTarget == null) break;
                if (l > 5) {
                    console.warn(this.measureRequests.length ? "Measure loop restarted more than 5 times" : "Viewport failed to stabilize");
                    break
                }
                let f = [];
                h & 4 || ([this.measureRequests, f] = [f, this.measureRequests]);
                let a = f.map(d => {
                        try {
                            return d.read(this)
                        } catch (g) {
                            return ht(this.state, g), Vs
                        }
                    }),
                    c = ze.create(this, this.state, []),
                    u = !1;
                c.flags |= h, e ? e.flags |= h : e = c, this.updateState = 2, c.empty || (this.updatePlugins(c), this.inputState.update(c), this.updateAttrs(), u = this.docView.update(c), u && this.docViewUpdate());
                for (let d = 0; d < f.length; d++)
                    if (a[d] != Vs) try {
                        let g = f[d];
                        g.write && g.write(a[d], this)
                    } catch (g) {
                        ht(this.state, g)
                    }
                if (u && this.docView.updateSelection(!0), !c.viewportChanged && this.measureRequests.length == 0) {
                    if (this.viewState.editorHeight)
                        if (this.viewState.scrollTarget) {
                            this.docView.scrollIntoView(this.viewState.scrollTarget), this.viewState.scrollTarget = null, o = -1;
                            continue
                        } else {
                            let g = (r < 0 ? this.viewState.heightMap.height : this.viewState.lineBlockAt(r).top) - o;
                            if (g > 1 || g < -1) {
                                s = s + g, i.scrollTop = s / this.scaleY, o = -1;
                                continue
                            }
                        }
                    break
                }
            }
        } finally {
            this.updateState = 0, this.measureScheduled = -1
        }
        if (e && !e.empty)
            for (let l of this.state.facet(Ai)) l(e)
    }
    get themeClasses() {
        return Ei + " " + (this.state.facet(Ri) ? or : rr) + " " + this.state.facet(Oe)
    }
    updateAttrs() {
        let t = Is(this, qn, {
                class: "cm-editor" + (this.hasFocus ? " cm-focused " : " ") + this.themeClasses
            }),
            e = {
                spellcheck: "false",
                autocorrect: "off",
                autocapitalize: "off",
                translate: "no",
                contenteditable: this.state.facet(pt) ? "true" : "false",
                class: "cm-content",
                style: "".concat(b.tabSize, ": ").concat(this.state.tabSize),
                role: "textbox",
                "aria-multiline": "true"
            };
        this.state.readOnly && (e["aria-readonly"] = "true"), Is(this, ji, e);
        let i = this.observer.ignore(() => {
            let s = Si(this.contentDOM, this.contentAttrs, e),
                r = Si(this.dom, this.editorAttrs, t);
            return s || r
        });
        return this.editorAttrs = t, this.contentAttrs = e, i
    }
    showAnnouncements(t) {
        let e = !0;
        for (let i of t)
            for (let s of i.effects)
                if (s.is(D.announce)) {
                    e && (this.announceDOM.textContent = ""), e = !1;
                    let r = this.announceDOM.appendChild(document.createElement("div"));
                    r.textContent = s.value
                }
    }
    mountStyles() {
        this.styleModules = this.state.facet(Jt);
        let t = this.state.facet(D.cspNonce);
        Ht.mount(this.root, this.styleModules.concat(Zo).reverse(), t ? {
            nonce: t
        } : void 0)
    }
    readMeasured() {
        if (this.updateState == 2) throw new Error("Reading the editor layout isn't allowed during an update");
        this.updateState == 0 && this.measureScheduled > -1 && this.measure(!1)
    }
    requestMeasure(t) {
        if (this.measureScheduled < 0 && (this.measureScheduled = this.win.requestAnimationFrame(() => this.measure())), t) {
            if (this.measureRequests.indexOf(t) > -1) return;
            if (t.key != null) {
                for (let e = 0; e < this.measureRequests.length; e++)
                    if (this.measureRequests[e].key === t.key) {
                        this.measureRequests[e] = t;
                        return
                    }
            }
            this.measureRequests.push(t)
        }
    }
    plugin(t) {
        let e = this.pluginMap.get(t);
        return (e === void 0 || e && e.spec != t) && this.pluginMap.set(t, e = this.plugins.find(i => i.spec == t) || null), e && e.update(this).value
    }
    get documentTop() {
        return this.contentDOM.getBoundingClientRect().top + this.viewState.paddingTop
    }
    get documentPadding() {
        return {
            top: this.viewState.paddingTop,
            bottom: this.viewState.paddingBottom
        }
    }
    get scaleX() {
        return this.viewState.scaleX
    }
    get scaleY() {
        return this.viewState.scaleY
    }
    elementAtHeight(t) {
        return this.readMeasured(), this.viewState.elementAtHeight(t)
    }
    lineBlockAtHeight(t) {
        return this.readMeasured(), this.viewState.lineBlockAtHeight(t)
    }
    get viewportLineBlocks() {
        return this.viewState.viewportLines
    }
    lineBlockAt(t) {
        return this.viewState.lineBlockAt(t)
    }
    get contentHeight() {
        return this.viewState.contentHeight
    }
    moveByChar(t, e, i) {
        return Je(this, t, ys(this, t, e, i))
    }
    moveByGroup(t, e) {
        return Je(this, t, ys(this, t, e, i => vo(this, t.head, i)))
    }
    visualLineSide(t, e) {
        let i = this.bidiSpans(t),
            s = this.textDirectionAt(t.from),
            r = i[e ? i.length - 1 : 0];
        return S.cursor(r.side(e, s) + t.from, r.forward(!e, s) ? 1 : -1)
    }
    moveToLineBoundary(t, e, i = !0) {
        return So(this, t, e, i)
    }
    moveVertically(t, e, i) {
        return Je(this, t, ko(this, t, e, i))
    }
    domAtPos(t) {
        return this.docView.domAtPos(t)
    }
    posAtDOM(t, e = 0) {
        return this.docView.posFromDOM(t, e)
    }
    posAtCoords(t, e = !0) {
        return this.readMeasured(), Xn(this, t, e)
    }
    coordsAtPos(t, e = 1) {
        this.readMeasured();
        let i = this.docView.coordsAt(t, e);
        if (!i || i.left == i.right) return i;
        let s = this.state.doc.lineAt(t),
            r = this.bidiSpans(s),
            o = r[bt.find(r, t - s.from, -1, e)];
        return je(i, o.dir == I.LTR == e > 0)
    }
    coordsForChar(t) {
        return this.readMeasured(), this.docView.coordsForChar(t)
    }
    get defaultCharacterWidth() {
        return this.viewState.heightOracle.charWidth
    }
    get defaultLineHeight() {
        return this.viewState.heightOracle.lineHeight
    }
    get textDirection() {
        return this.viewState.defaultTextDirection
    }
    textDirectionAt(t) {
        return !this.state.facet(Hn) || t < this.viewport.from || t > this.viewport.to ? this.textDirection : (this.readMeasured(), this.docView.textDirectionAt(t))
    }
    get lineWrapping() {
        return this.viewState.heightOracle.lineWrapping
    }
    bidiSpans(t) {
        if (t.length > fl) return Rn(t.length);
        let e = this.textDirectionAt(t.from),
            i;
        for (let r of this.bidiCache)
            if (r.from == t.from && r.dir == e && (r.fresh || Tn(r.isolates, i = us(this, t)))) return r.order;
        i || (i = us(this, t));
        let s = no(t.text, e, i);
        return this.bidiCache.push(new qe(t.from, t.to, e, i, !0, s)), s
    }
    get hasFocus() {
        var t;
        return (this.dom.ownerDocument.hasFocus() || b.safari && ((t = this.inputState) === null || t === void 0 ? void 0 : t.lastContextMenu) > Date.now() - 3e4) && this.root.activeElement == this.contentDOM
    }
    focus() {
        this.observer.ignore(() => {
            dn(this.contentDOM), this.docView.updateSelection()
        })
    }
    setRoot(t) {
        this._root != t && (this._root = t, this.observer.setWindow((t.nodeType == 9 ? t : t.ownerDocument).defaultView || window), this.mountStyles())
    }
    destroy() {
        this.root.activeElement == this.contentDOM && this.contentDOM.blur();
        for (let t of this.plugins) t.destroy(this);
        this.plugins = [], this.inputState.destroy(), this.docView.destroy(), this.dom.remove(), this.observer.destroy(), this.measureScheduled > -1 && this.win.cancelAnimationFrame(this.measureScheduled), this.destroyed = !0
    }
    static scrollIntoView(t, e = {}) {
        return Se.of(new Nt(typeof t == "number" ? S.cursor(t) : t, e.y, e.x, e.yMargin, e.xMargin))
    }
    scrollSnapshot() {
        let {
            scrollTop: t,
            scrollLeft: e
        } = this.scrollDOM, i = this.viewState.scrollAnchorAt(t);
        return Se.of(new Nt(S.cursor(i.from), "start", "start", i.top - t, e, !0))
    }
    setTabFocusMode(t) {
        t == null ? this.inputState.tabFocusMode = this.inputState.tabFocusMode < 0 ? 0 : -1 : typeof t == "boolean" ? this.inputState.tabFocusMode = t ? 0 : -1 : this.inputState.tabFocusMode != 0 && (this.inputState.tabFocusMode = Date.now() + t)
    }
    static domEventHandlers(t) {
        return nt.define(() => ({}), {
            eventHandlers: t
        })
    }
    static domEventObservers(t) {
        return nt.define(() => ({}), {
            eventObservers: t
        })
    }
    static theme(t, e) {
        let i = Ht.newName(),
            s = [Oe.of(i), Jt.of(Bi(".".concat(i), t))];
        return e && e.dark && s.push(Ri.of(!0)), s
    }
    static baseTheme(t) {
        return Fi.lowest(Jt.of(Bi("." + Ei, t, lr)))
    }
    static findFromDOM(t) {
        var e;
        let i = t.querySelector(".cm-content"),
            s = i && R.get(i) || R.get(t);
        return ((e = s == null ? void 0 : s.rootView) === null || e === void 0 ? void 0 : e.view) || null
    }
}
D.styleModule = Jt;
D.inputHandler = Vn;
D.scrollHandler = Wn;
D.focusChangeEffect = In;
D.perLineTextDirection = Hn;
D.exceptionSink = Nn;
D.updateListener = Ai;
D.editable = pt;
D.mouseSelectionStyle = Ln;
D.dragMovesSelection = Pn;
D.clickAddsSelectionRange = Bn;
D.decorations = fe;
D.outerDecorations = Kn;
D.atomicRanges = $i;
D.bidiIsolatedRanges = jn;
D.scrollMargins = $n;
D.darkTheme = Ri;
D.cspNonce = C.define({
    combine: n => n.length ? n[0] : ""
});
D.contentAttributes = ji;
D.editorAttributes = qn;
D.lineWrapping = D.contentAttributes.of({
    class: "cm-lineWrapping"
});
D.announce = F.define();
const fl = 4096,
    Vs = {};
class qe {
    constructor(t, e, i, s, r, o) {
        this.from = t, this.to = e, this.dir = i, this.isolates = s, this.fresh = r, this.order = o
    }
    static update(t, e) {
        if (e.empty && !t.some(r => r.fresh)) return t;
        let i = [],
            s = t.length ? t[t.length - 1].dir : I.LTR;
        for (let r = Math.max(0, t.length - 10); r < t.length; r++) {
            let o = t[r];
            o.dir == s && !e.touchesRange(o.from, o.to) && i.push(new qe(e.mapPos(o.from, 1), e.mapPos(o.to, -1), o.dir, o.isolates, !1, o.order))
        }
        return i
    }
}

function Is(n, t, e) {
    for (let i = n.state.facet(t), s = i.length - 1; s >= 0; s--) {
        let r = i[s],
            o = typeof r == "function" ? r(n) : r;
        o && xi(o, e)
    }
    return e
}
const cl = b.mac ? "mac" : b.windows ? "win" : b.linux ? "linux" : "key";

function ul(n, t) {
    const e = n.split(/-(?!$)/);
    let i = e[e.length - 1];
    i == "Space" && (i = " ");
    let s, r, o, l;
    for (let h = 0; h < e.length - 1; ++h) {
        const f = e[h];
        if (/^(cmd|meta|m)$/i.test(f)) l = !0;
        else if (/^a(lt)?$/i.test(f)) s = !0;
        else if (/^(c|ctrl|control)$/i.test(f)) r = !0;
        else if (/^s(hift)?$/i.test(f)) o = !0;
        else if (/^mod$/i.test(f)) t == "mac" ? l = !0 : r = !0;
        else throw new Error("Unrecognized modifier name: " + f)
    }
    return s && (i = "Alt-" + i), r && (i = "Ctrl-" + i), l && (i = "Meta-" + i), o && (i = "Shift-" + i), i
}

function De(n, t, e) {
    return t.altKey && (n = "Alt-" + n), t.ctrlKey && (n = "Ctrl-" + n), t.metaKey && (n = "Meta-" + n), e !== !1 && t.shiftKey && (n = "Shift-" + n), n
}
const dl = Fi.default(D.domEventHandlers({
        keydown(n, t) {
            return bl(pl(t.state), n, t, "editor")
        }
    })),
    gl = C.define({
        enables: dl
    }),
    Hs = new WeakMap;

function pl(n) {
    let t = n.facet(gl),
        e = Hs.get(t);
    return e || Hs.set(t, e = wl(t.reduce((i, s) => i.concat(s), []))), e
}
let mt = null;
const ml = 4e3;

function wl(n, t = cl) {
    let e = Object.create(null),
        i = Object.create(null),
        s = (o, l) => {
            let h = i[o];
            if (h == null) i[o] = l;
            else if (h != l) throw new Error("Key binding " + o + " is used both as a regular binding and as a multi-stroke prefix")
        },
        r = (o, l, h, f, a) => {
            var c, u;
            let d = e[o] || (e[o] = Object.create(null)),
                g = l.split(/ (?!$)/).map(w => ul(w, t));
            for (let w = 1; w < g.length; w++) {
                let y = g.slice(0, w).join(" ");
                s(y, !0), d[y] || (d[y] = {
                    preventDefault: !0,
                    stopPropagation: !1,
                    run: [v => {
                        let x = mt = {
                            view: v,
                            prefix: y,
                            scope: o
                        };
                        return setTimeout(() => {
                            mt == x && (mt = null)
                        }, ml), !0
                    }]
                })
            }
            let m = g.join(" ");
            s(m, !1);
            let p = d[m] || (d[m] = {
                preventDefault: !1,
                stopPropagation: !1,
                run: ((u = (c = d._any) === null || c === void 0 ? void 0 : c.run) === null || u === void 0 ? void 0 : u.slice()) || []
            });
            h && p.run.push(h), f && (p.preventDefault = !0), a && (p.stopPropagation = !0)
        };
    for (let o of n) {
        let l = o.scope ? o.scope.split(" ") : ["editor"];
        if (o.any)
            for (let f of l) {
                let a = e[f] || (e[f] = Object.create(null));
                a._any || (a._any = {
                    preventDefault: !1,
                    stopPropagation: !1,
                    run: []
                });
                let {
                    any: c
                } = o;
                for (let u in a) a[u].run.push(d => c(d, Pi))
            }
        let h = o[t] || o.key;
        if (h)
            for (let f of l) r(f, h, o.run, o.preventDefault, o.stopPropagation), o.shift && r(f, "Shift-" + h, o.shift, o.preventDefault, o.stopPropagation)
    }
    return e
}
let Pi = null;

function bl(n, t, e, i) {
    Pi = t;
    let s = wr(t),
        r = te(s, 0),
        o = si(r) == s.length && s != " ",
        l = "",
        h = !1,
        f = !1,
        a = !1;
    mt && mt.view == e && mt.scope == i && (l = mt.prefix + " ", Jn.indexOf(t.keyCode) < 0 && (f = !0, mt = null));
    let c = new Set,
        u = p => {
            if (p) {
                for (let w of p.run)
                    if (!c.has(w) && (c.add(w), w(e))) return p.stopPropagation && (a = !0), !0;
                p.preventDefault && (p.stopPropagation && (a = !0), f = !0)
            }
            return !1
        },
        d = n[i],
        g, m;
    return d && (u(d[l + De(s, t, !o)]) ? h = !0 : o && (t.altKey || t.metaKey || t.ctrlKey) && !(b.windows && t.ctrlKey && t.altKey) && (g = br[t.keyCode]) && g != s ? (u(d[l + De(g, t, !0)]) || t.shiftKey && (m = yr[t.keyCode]) != s && m != g && u(d[l + De(m, t, !1)])) && (h = !0) : o && t.shiftKey && u(d[l + De(s, t, !0)]) && (h = !0), !h && u(d._any) && (h = !0)), f && (h = !0), h && a && t.stopPropagation(), Pi = null, h
}
class ge {
    constructor(t, e, i, s, r) {
        this.className = t, this.left = e, this.top = i, this.width = s, this.height = r
    }
    draw() {
        let t = document.createElement("div");
        return t.className = this.className, this.adjust(t), t
    }
    update(t, e) {
        return e.className != this.className ? !1 : (this.adjust(t), !0)
    }
    adjust(t) {
        t.style.left = this.left + "px", t.style.top = this.top + "px", this.width != null && (t.style.width = this.width + "px"), t.style.height = this.height + "px"
    }
    eq(t) {
        return this.left == t.left && this.top == t.top && this.width == t.width && this.height == t.height && this.className == t.className
    }
    static forRange(t, e, i) {
        if (i.empty) {
            let s = t.coordsAtPos(i.head, i.assoc || 1);
            if (!s) return [];
            let r = fr(t);
            return [new ge(e, s.left - r.left, s.top - r.top, null, s.bottom - s.top)]
        } else return yl(t, e, i)
    }
}

function fr(n) {
    let t = n.scrollDOM.getBoundingClientRect();
    return {
        left: (n.textDirection == I.LTR ? t.left : t.right - n.scrollDOM.clientWidth * n.scaleX) - n.scrollDOM.scrollLeft * n.scaleX,
        top: t.top - n.scrollDOM.scrollTop * n.scaleY
    }
}

function Fs(n, t, e, i) {
    let s = n.coordsAtPos(t, e * 2);
    if (!s) return i;
    let r = n.dom.getBoundingClientRect(),
        o = (s.top + s.bottom) / 2,
        l = n.posAtCoords({
            x: r.left + 1,
            y: o
        }),
        h = n.posAtCoords({
            x: r.right - 1,
            y: o
        });
    return l == null || h == null ? i : {
        from: Math.max(i.from, Math.min(l, h)),
        to: Math.min(i.to, Math.max(l, h))
    }
}

function yl(n, t, e) {
    if (e.to <= n.viewport.from || e.from >= n.viewport.to) return [];
    let i = Math.max(e.from, n.viewport.from),
        s = Math.min(e.to, n.viewport.to),
        r = n.textDirection == I.LTR,
        o = n.contentDOM,
        l = o.getBoundingClientRect(),
        h = fr(n),
        f = o.querySelector(".cm-line"),
        a = f && window.getComputedStyle(f),
        c = l.left + (a ? parseInt(a.paddingLeft) + Math.min(0, parseInt(a.textIndent)) : 0),
        u = l.right - (a ? parseInt(a.paddingRight) : 0),
        d = Di(n, i),
        g = Di(n, s),
        m = d.type == $.Text ? d : null,
        p = g.type == $.Text ? g : null;
    if (m && (n.lineWrapping || d.widgetLineBreaks) && (m = Fs(n, i, 1, m)), p && (n.lineWrapping || g.widgetLineBreaks) && (p = Fs(n, s, -1, p)), m && p && m.from == p.from && m.to == p.to) return y(v(e.from, e.to, m)); {
        let k = m ? v(e.from, null, m) : x(d, !1),
            M = p ? v(null, e.to, p) : x(g, !0),
            P = [];
        return (m || d).to < (p || g).from - (m && p ? 1 : 0) || d.widgetLineBreaks > 1 && k.bottom + n.defaultLineHeight / 2 < M.top ? P.push(w(c, k.bottom, u, M.top)) : k.bottom < M.top && n.elementAtHeight((k.bottom + M.top) / 2).type == $.Text && (k.bottom = M.top = (k.bottom + M.top) / 2), y(k).concat(P).concat(y(M))
    }

    function w(k, M, P, W) {
        return new ge(t, k - h.left, M - h.top - .01, P - k, W - M + .01)
    }

    function y({
        top: k,
        bottom: M,
        horizontal: P
    }) {
        let W = [];
        for (let dt = 0; dt < P.length; dt += 2) W.push(w(P[dt], k, P[dt + 1], M));
        return W
    }

    function v(k, M, P) {
        let W = 1e9,
            dt = -1e9,
            pe = [];

        function Xi(St, gt, Tt, vt, $t) {
            let rt = n.coordsAtPos(St, St == P.to ? -2 : 2),
                ot = n.coordsAtPos(Tt, Tt == P.from ? 2 : -2);
            !rt || !ot || (W = Math.min(rt.top, ot.top, W), dt = Math.max(rt.bottom, ot.bottom, dt), $t == I.LTR ? pe.push(r && gt ? c : rt.left, r && vt ? u : ot.right) : pe.push(!r && vt ? c : ot.left, !r && gt ? u : rt.right))
        }
        let me = k != null ? k : P.from,
            we = M != null ? M : P.to;
        for (let St of n.visibleRanges)
            if (St.to > me && St.from < we)
                for (let gt = Math.max(St.from, me), Tt = Math.min(St.to, we);;) {
                    let vt = n.state.doc.lineAt(gt);
                    for (let $t of n.bidiSpans(vt)) {
                        let rt = $t.from + vt.from,
                            ot = $t.to + vt.from;
                        if (rt >= Tt) break;
                        ot > gt && Xi(Math.max(rt, gt), k == null && rt <= me, Math.min(ot, Tt), M == null && ot >= we, $t.dir)
                    }
                    if (gt = vt.to + 1, gt >= Tt) break
                }
        return pe.length == 0 && Xi(me, k == null, we, M == null, n.textDirection), {
            top: W,
            bottom: dt,
            horizontal: pe
        }
    }

    function x(k, M) {
        let P = l.top + (M ? k.top : k.bottom);
        return {
            top: P,
            bottom: P,
            horizontal: []
        }
    }
}

function xl(n, t) {
    return n.constructor == t.constructor && n.eq(t)
}
class Sl {
    constructor(t, e) {
        this.view = t, this.layer = e, this.drawn = [], this.scaleX = 1, this.scaleY = 1, this.measureReq = {
            read: this.measure.bind(this),
            write: this.draw.bind(this)
        }, this.dom = t.scrollDOM.appendChild(document.createElement("div")), this.dom.classList.add("cm-layer"), e.above && this.dom.classList.add("cm-layer-above"), e.class && this.dom.classList.add(e.class), this.scale(), this.dom.setAttribute("aria-hidden", "true"), this.setOrder(t.state), t.requestMeasure(this.measureReq), e.mount && e.mount(this.dom, t)
    }
    update(t) {
        t.startState.facet(Le) != t.state.facet(Le) && this.setOrder(t.state), (this.layer.update(t, this.dom) || t.geometryChanged) && (this.scale(), t.view.requestMeasure(this.measureReq))
    }
    docViewUpdate(t) {
        this.layer.updateOnDocViewUpdate !== !1 && t.requestMeasure(this.measureReq)
    }
    setOrder(t) {
        let e = 0,
            i = t.facet(Le);
        for (; e < i.length && i[e] != this.layer;) e++;
        this.dom.style.zIndex = String((this.layer.above ? 150 : -1) - e)
    }
    measure() {
        return this.layer.markers(this.view)
    }
    scale() {
        let {
            scaleX: t,
            scaleY: e
        } = this.view;
        (t != this.scaleX || e != this.scaleY) && (this.scaleX = t, this.scaleY = e, this.dom.style.transform = "scale(".concat(1 / t, ", ").concat(1 / e, ")"))
    }
    draw(t) {
        if (t.length != this.drawn.length || t.some((e, i) => !xl(e, this.drawn[i]))) {
            let e = this.dom.firstChild,
                i = 0;
            for (let s of t) s.update && e && s.constructor && this.drawn[i].constructor && s.update(e, this.drawn[i]) ? (e = e.nextSibling, i++) : this.dom.insertBefore(s.draw(), e);
            for (; e;) {
                let s = e.nextSibling;
                e.remove(), e = s
            }
            this.drawn = t
        }
    }
    destroy() {
        this.layer.destroy && this.layer.destroy(this.dom, this.view), this.dom.remove()
    }
}
const Le = C.define();

function cr(n) {
    return [nt.define(t => new Sl(t, n)), Le.of(n)]
}
const ur = !b.ios,
    ce = C.define({
        combine(n) {
            return Wi(n, {
                cursorBlinkRate: 1200,
                drawRangeCursor: !0
            }, {
                cursorBlinkRate: (t, e) => Math.min(t, e),
                drawRangeCursor: (t, e) => t || e
            })
        }
    });

function Zl(n = {}) {
    return [ce.of(n), vl, kl, Cl, Fn.of(!0)]
}

function dr(n) {
    return n.startState.facet(ce) != n.state.facet(ce)
}
const vl = cr({
    above: !0,
    markers(n) {
        let {
            state: t
        } = n, e = t.facet(ce), i = [];
        for (let s of t.selection.ranges) {
            let r = s == t.selection.main;
            if (s.empty ? !r || ur : e.drawRangeCursor) {
                let o = r ? "cm-cursor cm-cursor-primary" : "cm-cursor cm-cursor-secondary",
                    l = s.empty ? s : S.cursor(s.head, s.head > s.anchor ? -1 : 1);
                for (let h of ge.forRange(n, o, l)) i.push(h)
            }
        }
        return i
    },
    update(n, t) {
        n.transactions.some(i => i.selection) && (t.style.animationName = t.style.animationName == "cm-blink" ? "cm-blink2" : "cm-blink");
        let e = dr(n);
        return e && Ws(n.state, t), n.docChanged || n.selectionSet || e
    },
    mount(n, t) {
        Ws(t.state, n)
    },
    class: "cm-cursorLayer"
});

function Ws(n, t) {
    t.style.animationDuration = n.facet(ce).cursorBlinkRate + "ms"
}
const kl = cr({
        above: !1,
        markers(n) {
            return n.state.selection.ranges.map(t => t.empty ? [] : ge.forRange(n, "cm-selectionBackground", t)).reduce((t, e) => t.concat(e))
        },
        update(n, t) {
            return n.docChanged || n.selectionSet || n.viewportChanged || dr(n)
        },
        class: "cm-selectionLayer"
    }),
    Li = {
        ".cm-line": {
            "& ::selection, &::selection": {
                backgroundColor: "transparent !important"
            }
        },
        ".cm-content": {
            "& :focus": {
                caretColor: "initial !important",
                "&::selection, & ::selection": {
                    backgroundColor: "Highlight !important"
                }
            }
        }
    };
ur && (Li[".cm-line"].caretColor = Li[".cm-content"].caretColor = "transparent !important");
const Cl = Fi.highest(D.theme(Li));

function zs(n, t, e, i, s) {
    t.lastIndex = 0;
    for (let r = n.iterRange(e, i), o = e, l; !r.next().done; o += r.value.length)
        if (!r.lineBreak)
            for (; l = t.exec(r.value);) s(o + l.index, l)
}

function Ml(n, t) {
    let e = n.visibleRanges;
    if (e.length == 1 && e[0].from == n.viewport.from && e[0].to == n.viewport.to) return e;
    let i = [];
    for (let {
            from: s,
            to: r
        } of e) s = Math.max(n.state.doc.lineAt(s).from, s - t), r = Math.min(n.state.doc.lineAt(r).to, r + t), i.length && i[i.length - 1].to >= s ? i[i.length - 1].to = r : i.push({
        from: s,
        to: r
    });
    return i
}
class Al {
    constructor(t) {
        const {
            regexp: e,
            decoration: i,
            decorate: s,
            boundary: r,
            maxLength: o = 1e3
        } = t;
        if (!e.global) throw new RangeError("The regular expression given to MatchDecorator should have its 'g' flag set");
        if (this.regexp = e, s) this.addMatch = (l, h, f, a) => s(a, f, f + l[0].length, l, h);
        else if (typeof i == "function") this.addMatch = (l, h, f, a) => {
            let c = i(l, h, f);
            c && a(f, f + l[0].length, c)
        };
        else if (i) this.addMatch = (l, h, f, a) => a(f, f + l[0].length, i);
        else throw new RangeError("Either 'decorate' or 'decoration' should be provided to MatchDecorator");
        this.boundary = r, this.maxLength = o
    }
    createDeco(t) {
        let e = new le,
            i = e.add.bind(e);
        for (let {
                from: s,
                to: r
            } of Ml(t, this.maxLength)) zs(t.state.doc, this.regexp, s, r, (o, l) => this.addMatch(l, t, o, i));
        return e.finish()
    }
    updateDeco(t, e) {
        let i = 1e9,
            s = -1;
        return t.docChanged && t.changes.iterChanges((r, o, l, h) => {
            h > t.view.viewport.from && l < t.view.viewport.to && (i = Math.min(l, i), s = Math.max(h, s))
        }), t.viewportChanged || s - i > 1e3 ? this.createDeco(t.view) : s > -1 ? this.updateRange(t.view, e.map(t.changes), i, s) : e
    }
    updateRange(t, e, i, s) {
        for (let r of t.visibleRanges) {
            let o = Math.max(r.from, i),
                l = Math.min(r.to, s);
            if (l > o) {
                let h = t.state.doc.lineAt(o),
                    f = h.to < l ? t.state.doc.lineAt(l) : h,
                    a = Math.max(r.from, h.from),
                    c = Math.min(r.to, f.to);
                if (this.boundary) {
                    for (; o > h.from; o--)
                        if (this.boundary.test(h.text[o - 1 - h.from])) {
                            a = o;
                            break
                        }
                    for (; l < f.to; l++)
                        if (this.boundary.test(f.text[l - f.from])) {
                            c = l;
                            break
                        }
                }
                let u = [],
                    d, g = (m, p, w) => u.push(w.range(m, p));
                if (h == f)
                    for (this.regexp.lastIndex = a - h.from;
                        (d = this.regexp.exec(h.text)) && d.index < c - h.from;) this.addMatch(d, t, d.index + h.from, g);
                else zs(t.state.doc, this.regexp, a, c, (m, p) => this.addMatch(p, t, m, g));
                e = e.update({
                    filterFrom: a,
                    filterTo: c,
                    filter: (m, p) => m < a || p > c,
                    add: u
                })
            }
        }
        return e
    }
}
const Ni = /x/.unicode != null ? "gu" : "g",
    Ol = new RegExp("[\0-\b\n--­؜​‎‏\u2028\u2029‭‮⁦⁧⁩\uFEFF￹-￼]", Ni),
    Dl = {
        0: "null",
        7: "bell",
        8: "backspace",
        10: "newline",
        11: "vertical tab",
        13: "carriage return",
        27: "escape",
        8203: "zero width space",
        8204: "zero width non-joiner",
        8205: "zero width joiner",
        8206: "left-to-right mark",
        8207: "right-to-left mark",
        8232: "line separator",
        8237: "left-to-right override",
        8238: "right-to-left override",
        8294: "left-to-right isolate",
        8295: "right-to-left isolate",
        8297: "pop directional isolate",
        8233: "paragraph separator",
        65279: "zero width no-break space",
        65532: "object replacement"
    };
let _e = null;

function Tl() {
    var n;
    if (_e == null && typeof document < "u" && document.body) {
        let t = document.body.style;
        _e = ((n = t.tabSize) !== null && n !== void 0 ? n : t.MozTabSize) != null
    }
    return _e || !1
}
const Ne = C.define({
    combine(n) {
        let t = Wi(n, {
            render: null,
            specialChars: Ol,
            addSpecialChars: null
        });
        return (t.replaceTabs = !Tl()) && (t.specialChars = new RegExp("	|" + t.specialChars.source, Ni)), t.addSpecialChars && (t.specialChars = new RegExp(t.specialChars.source + "|" + t.addSpecialChars.source, Ni)), t
    }
});

function _l(n = {}) {
    return [Ne.of(n), Rl()]
}
let qs = null;

function Rl() {
    return qs || (qs = nt.fromClass(class {
        constructor(n) {
            this.view = n, this.decorations = V.none, this.decorationCache = Object.create(null), this.decorator = this.makeDecorator(n.state.facet(Ne)), this.decorations = this.decorator.createDeco(n)
        }
        makeDecorator(n) {
            return new Al({
                regexp: n.specialChars,
                decoration: (t, e, i) => {
                    let {
                        doc: s
                    } = e.state, r = te(t[0], 0);
                    if (r == 9) {
                        let o = s.lineAt(i),
                            l = e.state.tabSize,
                            h = Vr(o.text, l, i - o.from);
                        return V.replace({
                            widget: new Ll((l - h % l) * this.view.defaultCharacterWidth / this.view.scaleX)
                        })
                    }
                    return this.decorationCache[r] || (this.decorationCache[r] = V.replace({
                        widget: new Pl(n, r)
                    }))
                },
                boundary: n.replaceTabs ? void 0 : /[^]/
            })
        }
        update(n) {
            let t = n.state.facet(Ne);
            n.startState.facet(Ne) != t ? (this.decorator = this.makeDecorator(t), this.decorations = this.decorator.createDeco(n.view)) : this.decorations = this.decorator.updateDeco(n, this.decorations)
        }
    }, {
        decorations: n => n.decorations
    }))
}
const El = "•";

function Bl(n) {
    return n >= 32 ? El : n == 10 ? "␤" : String.fromCharCode(9216 + n)
}
class Pl extends jt {
    constructor(t, e) {
        super(), this.options = t, this.code = e
    }
    eq(t) {
        return t.code == this.code
    }
    toDOM(t) {
        let e = Bl(this.code),
            i = t.state.phrase("Control character") + " " + (Dl[this.code] || "0x" + this.code.toString(16)),
            s = this.options.render && this.options.render(this.code, i, e);
        if (s) return s;
        let r = document.createElement("span");
        return r.textContent = e, r.title = i, r.setAttribute("aria-label", i), r.className = "cm-specialChar", r
    }
    ignoreEvent() {
        return !1
    }
}
class Ll extends jt {
    constructor(t) {
        super(), this.width = t
    }
    eq(t) {
        return t.width == this.width
    }
    toDOM() {
        let t = document.createElement("span");
        return t.textContent = "	", t.className = "cm-tab", t.style.width = this.width + "px", t
    }
    ignoreEvent() {
        return !1
    }
}
class Nl extends jt {
    constructor(t) {
        super(), this.content = t
    }
    toDOM() {
        let t = document.createElement("span");
        return t.className = "cm-placeholder", t.style.pointerEvents = "none", t.appendChild(typeof this.content == "string" ? document.createTextNode(this.content) : this.content), typeof this.content == "string" ? t.setAttribute("aria-label", "placeholder " + this.content) : t.setAttribute("aria-hidden", "true"), t
    }
    coordsAt(t) {
        let e = t.firstChild ? Ft(t.firstChild) : [];
        if (!e.length) return null;
        let i = window.getComputedStyle(t.parentNode),
            s = je(e[0], i.direction != "rtl"),
            r = parseInt(i.lineHeight);
        return s.bottom - s.top > r * 1.5 ? {
            left: s.left,
            right: s.right,
            top: s.top,
            bottom: s.top + r
        } : s
    }
    ignoreEvent() {
        return !1
    }
}

function th(n) {
    return nt.fromClass(class {
        constructor(t) {
            this.view = t, this.placeholder = n ? V.set([V.widget({
                widget: new Nl(n),
                side: 1
            }).range(0)]) : V.none
        }
        get decorations() {
            return this.view.state.doc.length ? V.none : this.placeholder
        }
    }, {
        decorations: t => t.decorations
    })
}
const Xt = "-10000px";
class Vl {
    constructor(t, e, i, s) {
        this.facet = e, this.createTooltipView = i, this.removeTooltipView = s, this.input = t.state.facet(e), this.tooltips = this.input.filter(o => o);
        let r = null;
        this.tooltipViews = this.tooltips.map(o => r = i(o, r))
    }
    update(t, e) {
        var i;
        let s = t.state.facet(this.facet),
            r = s.filter(h => h);
        if (s === this.input) {
            for (let h of this.tooltipViews) h.update && h.update(t);
            return !1
        }
        let o = [],
            l = e ? [] : null;
        for (let h = 0; h < r.length; h++) {
            let f = r[h],
                a = -1;
            if (f) {
                for (let c = 0; c < this.tooltips.length; c++) {
                    let u = this.tooltips[c];
                    u && u.create == f.create && (a = c)
                }
                if (a < 0) o[h] = this.createTooltipView(f, h ? o[h - 1] : null), l && (l[h] = !!f.above);
                else {
                    let c = o[h] = this.tooltipViews[a];
                    l && (l[h] = e[a]), c.update && c.update(t)
                }
            }
        }
        for (let h of this.tooltipViews) o.indexOf(h) < 0 && (this.removeTooltipView(h), (i = h.destroy) === null || i === void 0 || i.call(h));
        return e && (l.forEach((h, f) => e[f] = h), e.length = l.length), this.input = s, this.tooltips = r, this.tooltipViews = o, !0
    }
}

function Il(n) {
    let {
        win: t
    } = n;
    return {
        top: 0,
        left: 0,
        bottom: t.innerHeight,
        right: t.innerWidth
    }
}
const ti = C.define({
        combine: n => {
            var t, e, i;
            return {
                position: b.ios ? "absolute" : ((t = n.find(s => s.position)) === null || t === void 0 ? void 0 : t.position) || "fixed",
                parent: ((e = n.find(s => s.parent)) === null || e === void 0 ? void 0 : e.parent) || null,
                tooltipSpace: ((i = n.find(s => s.tooltipSpace)) === null || i === void 0 ? void 0 : i.tooltipSpace) || Il
            }
        }
    }),
    Ks = new WeakMap,
    gr = nt.fromClass(class {
        constructor(n) {
            this.view = n, this.above = [], this.inView = !0, this.madeAbsolute = !1, this.lastTransaction = 0, this.measureTimeout = -1;
            let t = n.state.facet(ti);
            this.position = t.position, this.parent = t.parent, this.classes = n.themeClasses, this.createContainer(), this.measureReq = {
                read: this.readMeasure.bind(this),
                write: this.writeMeasure.bind(this),
                key: this
            }, this.resizeObserver = typeof ResizeObserver == "function" ? new ResizeObserver(() => this.measureSoon()) : null, this.manager = new Vl(n, Wl, (e, i) => this.createTooltip(e, i), e => {
                this.resizeObserver && this.resizeObserver.unobserve(e.dom), e.dom.remove()
            }), this.above = this.manager.tooltips.map(e => !!e.above), this.intersectionObserver = typeof IntersectionObserver == "function" ? new IntersectionObserver(e => {
                Date.now() > this.lastTransaction - 50 && e.length > 0 && e[e.length - 1].intersectionRatio < 1 && this.measureSoon()
            }, {
                threshold: [1]
            }) : null, this.observeIntersection(), n.win.addEventListener("resize", this.measureSoon = this.measureSoon.bind(this)), this.maybeMeasure()
        }
        createContainer() {
            this.parent ? (this.container = document.createElement("div"), this.container.style.position = "relative", this.container.className = this.view.themeClasses, this.parent.appendChild(this.container)) : this.container = this.view.dom
        }
        observeIntersection() {
            if (this.intersectionObserver) {
                this.intersectionObserver.disconnect();
                for (let n of this.manager.tooltipViews) this.intersectionObserver.observe(n.dom)
            }
        }
        measureSoon() {
            this.measureTimeout < 0 && (this.measureTimeout = setTimeout(() => {
                this.measureTimeout = -1, this.maybeMeasure()
            }, 50))
        }
        update(n) {
            n.transactions.length && (this.lastTransaction = Date.now());
            let t = this.manager.update(n, this.above);
            t && this.observeIntersection();
            let e = t || n.geometryChanged,
                i = n.state.facet(ti);
            if (i.position != this.position && !this.madeAbsolute) {
                this.position = i.position;
                for (let s of this.manager.tooltipViews) s.dom.style.position = this.position;
                e = !0
            }
            if (i.parent != this.parent) {
                this.parent && this.container.remove(), this.parent = i.parent, this.createContainer();
                for (let s of this.manager.tooltipViews) this.container.appendChild(s.dom);
                e = !0
            } else this.parent && this.view.themeClasses != this.classes && (this.classes = this.container.className = this.view.themeClasses);
            e && this.maybeMeasure()
        }
        createTooltip(n, t) {
            let e = n.create(this.view),
                i = t ? t.dom : null;
            if (e.dom.classList.add("cm-tooltip"), n.arrow && !e.dom.querySelector(".cm-tooltip > .cm-tooltip-arrow")) {
                let s = document.createElement("div");
                s.className = "cm-tooltip-arrow", e.dom.appendChild(s)
            }
            return e.dom.style.position = this.position, e.dom.style.top = Xt, e.dom.style.left = "0px", this.container.insertBefore(e.dom, i), e.mount && e.mount(this.view), this.resizeObserver && this.resizeObserver.observe(e.dom), e
        }
        destroy() {
            var n, t, e;
            this.view.win.removeEventListener("resize", this.measureSoon);
            for (let i of this.manager.tooltipViews) i.dom.remove(), (n = i.destroy) === null || n === void 0 || n.call(i);
            this.parent && this.container.remove(), (t = this.resizeObserver) === null || t === void 0 || t.disconnect(), (e = this.intersectionObserver) === null || e === void 0 || e.disconnect(), clearTimeout(this.measureTimeout)
        }
        readMeasure() {
            let n = this.view.dom.getBoundingClientRect(),
                t = 1,
                e = 1,
                i = !1;
            if (this.position == "fixed" && this.manager.tooltipViews.length) {
                let {
                    dom: s
                } = this.manager.tooltipViews[0];
                if (b.gecko) i = s.offsetParent != this.container.ownerDocument.body;
                else if (s.style.top == Xt && s.style.left == "0px") {
                    let r = s.getBoundingClientRect();
                    i = Math.abs(r.top + 1e4) > 1 || Math.abs(r.left) > 1
                }
            }
            if (i || this.position == "absolute")
                if (this.parent) {
                    let s = this.parent.getBoundingClientRect();
                    s.width && s.height && (t = s.width / this.parent.offsetWidth, e = s.height / this.parent.offsetHeight)
                } else({
                    scaleX: t,
                    scaleY: e
                } = this.view.viewState);
            return {
                editor: n,
                parent: this.parent ? this.container.getBoundingClientRect() : n,
                pos: this.manager.tooltips.map((s, r) => {
                    let o = this.manager.tooltipViews[r];
                    return o.getCoords ? o.getCoords(s.pos) : this.view.coordsAtPos(s.pos)
                }),
                size: this.manager.tooltipViews.map(({
                    dom: s
                }) => s.getBoundingClientRect()),
                space: this.view.state.facet(ti).tooltipSpace(this.view),
                scaleX: t,
                scaleY: e,
                makeAbsolute: i
            }
        }
        writeMeasure(n) {
            var t;
            if (n.makeAbsolute) {
                this.madeAbsolute = !0, this.position = "absolute";
                for (let l of this.manager.tooltipViews) l.dom.style.position = "absolute"
            }
            let {
                editor: e,
                space: i,
                scaleX: s,
                scaleY: r
            } = n, o = [];
            for (let l = 0; l < this.manager.tooltips.length; l++) {
                let h = this.manager.tooltips[l],
                    f = this.manager.tooltipViews[l],
                    {
                        dom: a
                    } = f,
                    c = n.pos[l],
                    u = n.size[l];
                if (!c || c.bottom <= Math.max(e.top, i.top) || c.top >= Math.min(e.bottom, i.bottom) || c.right < Math.max(e.left, i.left) - .1 || c.left > Math.min(e.right, i.right) + .1) {
                    a.style.top = Xt;
                    continue
                }
                let d = h.arrow ? f.dom.querySelector(".cm-tooltip-arrow") : null,
                    g = d ? 7 : 0,
                    m = u.right - u.left,
                    p = (t = Ks.get(f)) !== null && t !== void 0 ? t : u.bottom - u.top,
                    w = f.offset || Fl,
                    y = this.view.textDirection == I.LTR,
                    v = u.width > i.right - i.left ? y ? i.left : i.right - u.width : y ? Math.min(c.left - (d ? 14 : 0) + w.x, i.right - m) : Math.max(i.left, c.left - m + (d ? 14 : 0) - w.x),
                    x = this.above[l];
                !h.strictSide && (x ? c.top - (u.bottom - u.top) - w.y < i.top : c.bottom + (u.bottom - u.top) + w.y > i.bottom) && x == i.bottom - c.bottom > c.top - i.top && (x = this.above[l] = !x);
                let k = (x ? c.top - i.top : i.bottom - c.bottom) - g;
                if (k < p && f.resize !== !1) {
                    if (k < this.view.defaultLineHeight) {
                        a.style.top = Xt;
                        continue
                    }
                    Ks.set(f, p), a.style.height = (p = k) / r + "px"
                } else a.style.height && (a.style.height = "");
                let M = x ? c.top - p - g - w.y : c.bottom + g + w.y,
                    P = v + m;
                if (f.overlap !== !0)
                    for (let W of o) W.left < P && W.right > v && W.top < M + p && W.bottom > M && (M = x ? W.top - p - 2 - g : W.bottom + g + 2);
                if (this.position == "absolute" ? (a.style.top = (M - n.parent.top) / r + "px", a.style.left = (v - n.parent.left) / s + "px") : (a.style.top = M / r + "px", a.style.left = v / s + "px"), d) {
                    let W = c.left + (y ? w.x : -w.x) - (v + 14 - 7);
                    d.style.left = W / s + "px"
                }
                f.overlap !== !0 && o.push({
                    left: v,
                    top: M,
                    right: P,
                    bottom: M + p
                }), a.classList.toggle("cm-tooltip-above", x), a.classList.toggle("cm-tooltip-below", !x), f.positioned && f.positioned(n.space)
            }
        }
        maybeMeasure() {
            if (this.manager.tooltips.length && (this.view.inView && this.view.requestMeasure(this.measureReq), this.inView != this.view.inView && (this.inView = this.view.inView, !this.inView)))
                for (let n of this.manager.tooltipViews) n.dom.style.top = Xt
        }
    }, {
        eventObservers: {
            scroll() {
                this.maybeMeasure()
            }
        }
    }),
    Hl = D.baseTheme({
        ".cm-tooltip": {
            zIndex: 100,
            boxSizing: "border-box"
        },
        "&light .cm-tooltip": {
            border: "1px solid #bbb",
            backgroundColor: "#f5f5f5"
        },
        "&light .cm-tooltip-section:not(:first-child)": {
            borderTop: "1px solid #bbb"
        },
        "&dark .cm-tooltip": {
            backgroundColor: "#333338",
            color: "white"
        },
        ".cm-tooltip-arrow": {
            height: "7px",
            width: "14px",
            position: "absolute",
            zIndex: -1,
            overflow: "hidden",
            "&:before, &:after": {
                content: "''",
                position: "absolute",
                width: 0,
                height: 0,
                borderLeft: "7px solid transparent",
                borderRight: "7px solid transparent"
            },
            ".cm-tooltip-above &": {
                bottom: "-7px",
                "&:before": {
                    borderTop: "7px solid #bbb"
                },
                "&:after": {
                    borderTop: "7px solid #f5f5f5",
                    bottom: "1px"
                }
            },
            ".cm-tooltip-below &": {
                top: "-7px",
                "&:before": {
                    borderBottom: "7px solid #bbb"
                },
                "&:after": {
                    borderBottom: "7px solid #f5f5f5",
                    top: "1px"
                }
            }
        },
        "&dark .cm-tooltip .cm-tooltip-arrow": {
            "&:before": {
                borderTopColor: "#333338",
                borderBottomColor: "#333338"
            },
            "&:after": {
                borderTopColor: "transparent",
                borderBottomColor: "transparent"
            }
        }
    }),
    Fl = {
        x: 0,
        y: 0
    },
    Wl = C.define({
        enables: [gr, Hl]
    });

function eh(n, t) {
    let e = n.plugin(gr);
    if (!e) return null;
    let i = e.manager.tooltips.indexOf(t);
    return i < 0 ? null : e.manager.tooltipViews[i]
}
class xt extends It {
    compare(t) {
        return this == t || this.constructor == t.constructor && this.eq(t)
    }
    eq(t) {
        return !1
    }
    destroy(t) {}
}
xt.prototype.elementClass = "";
xt.prototype.toDOM = void 0;
xt.prototype.mapMode = U.TrackBefore;
xt.prototype.startSide = xt.prototype.endSide = -1;
xt.prototype.point = !0;
const Ve = C.define(),
    zl = {
        class: "",
        renderEmptyElements: !1,
        elementStyle: "",
        markers: () => A.empty,
        lineMarker: () => null,
        widgetMarker: () => null,
        lineMarkerChange: null,
        initialSpacer: null,
        updateSpacer: null,
        domEventHandlers: {}
    },
    ne = C.define();

function ih(n) {
    return [pr(), ne.of(Object.assign(Object.assign({}, zl), n))]
}
const js = C.define({
    combine: n => n.some(t => t)
});

function pr(n) {
    return [ql]
}
const ql = nt.fromClass(class {
    constructor(n) {
        this.view = n, this.prevViewport = n.viewport, this.dom = document.createElement("div"), this.dom.className = "cm-gutters", this.dom.setAttribute("aria-hidden", "true"), this.dom.style.minHeight = this.view.contentHeight / this.view.scaleY + "px", this.gutters = n.state.facet(ne).map(t => new Gs(n, t));
        for (let t of this.gutters) this.dom.appendChild(t.dom);
        this.fixed = !n.state.facet(js), this.fixed && (this.dom.style.position = "sticky"), this.syncGutters(!1), n.scrollDOM.insertBefore(this.dom, n.contentDOM)
    }
    update(n) {
        if (this.updateGutters(n)) {
            let t = this.prevViewport,
                e = n.view.viewport,
                i = Math.min(t.to, e.to) - Math.max(t.from, e.from);
            this.syncGutters(i < (e.to - e.from) * .8)
        }
        n.geometryChanged && (this.dom.style.minHeight = this.view.contentHeight / this.view.scaleY + "px"), this.view.state.facet(js) != !this.fixed && (this.fixed = !this.fixed, this.dom.style.position = this.fixed ? "sticky" : ""), this.prevViewport = n.view.viewport
    }
    syncGutters(n) {
        let t = this.dom.nextSibling;
        n && this.dom.remove();
        let e = A.iter(this.view.state.facet(Ve), this.view.viewport.from),
            i = [],
            s = this.gutters.map(r => new Kl(r, this.view.viewport, -this.view.documentPadding.top));
        for (let r of this.view.viewportLineBlocks)
            if (i.length && (i = []), Array.isArray(r.type)) {
                let o = !0;
                for (let l of r.type)
                    if (l.type == $.Text && o) {
                        Vi(e, i, l.from);
                        for (let h of s) h.line(this.view, l, i);
                        o = !1
                    } else if (l.widget)
                    for (let h of s) h.widget(this.view, l)
            } else if (r.type == $.Text) {
            Vi(e, i, r.from);
            for (let o of s) o.line(this.view, r, i)
        } else if (r.widget)
            for (let o of s) o.widget(this.view, r);
        for (let r of s) r.finish();
        n && this.view.scrollDOM.insertBefore(this.dom, t)
    }
    updateGutters(n) {
        let t = n.startState.facet(ne),
            e = n.state.facet(ne),
            i = n.docChanged || n.heightChanged || n.viewportChanged || !A.eq(n.startState.facet(Ve), n.state.facet(Ve), n.view.viewport.from, n.view.viewport.to);
        if (t == e)
            for (let s of this.gutters) s.update(n) && (i = !0);
        else {
            i = !0;
            let s = [];
            for (let r of e) {
                let o = t.indexOf(r);
                o < 0 ? s.push(new Gs(this.view, r)) : (this.gutters[o].update(n), s.push(this.gutters[o]))
            }
            for (let r of this.gutters) r.dom.remove(), s.indexOf(r) < 0 && r.destroy();
            for (let r of s) this.dom.appendChild(r.dom);
            this.gutters = s
        }
        return i
    }
    destroy() {
        for (let n of this.gutters) n.destroy();
        this.dom.remove()
    }
}, {
    provide: n => D.scrollMargins.of(t => {
        let e = t.plugin(n);
        return !e || e.gutters.length == 0 || !e.fixed ? null : t.textDirection == I.LTR ? {
            left: e.dom.offsetWidth * t.scaleX
        } : {
            right: e.dom.offsetWidth * t.scaleX
        }
    })
});

function $s(n) {
    return Array.isArray(n) ? n : [n]
}

function Vi(n, t, e) {
    for (; n.value && n.from <= e;) n.from == e && t.push(n.value), n.next()
}
class Kl {
    constructor(t, e, i) {
        this.gutter = t, this.height = i, this.i = 0, this.cursor = A.iter(t.markers, e.from)
    }
    addElement(t, e, i) {
        let {
            gutter: s
        } = this, r = (e.top - this.height) / t.scaleY, o = e.height / t.scaleY;
        if (this.i == s.elements.length) {
            let l = new mr(t, o, r, i);
            s.elements.push(l), s.dom.appendChild(l.dom)
        } else s.elements[this.i].update(t, o, r, i);
        this.height = e.bottom, this.i++
    }
    line(t, e, i) {
        let s = [];
        Vi(this.cursor, s, e.from), i.length && (s = s.concat(i));
        let r = this.gutter.config.lineMarker(t, e, s);
        r && s.unshift(r);
        let o = this.gutter;
        s.length == 0 && !o.config.renderEmptyElements || this.addElement(t, e, s)
    }
    widget(t, e) {
        let i = this.gutter.config.widgetMarker(t, e.widget, e);
        i && this.addElement(t, e, [i])
    }
    finish() {
        let t = this.gutter;
        for (; t.elements.length > this.i;) {
            let e = t.elements.pop();
            t.dom.removeChild(e.dom), e.destroy()
        }
    }
}
class Gs {
    constructor(t, e) {
        this.view = t, this.config = e, this.elements = [], this.spacer = null, this.dom = document.createElement("div"), this.dom.className = "cm-gutter" + (this.config.class ? " " + this.config.class : "");
        for (let i in e.domEventHandlers) this.dom.addEventListener(i, s => {
            let r = s.target,
                o;
            if (r != this.dom && this.dom.contains(r)) {
                for (; r.parentNode != this.dom;) r = r.parentNode;
                let h = r.getBoundingClientRect();
                o = (h.top + h.bottom) / 2
            } else o = s.clientY;
            let l = t.lineBlockAtHeight(o - t.documentTop);
            e.domEventHandlers[i](t, l, s) && s.preventDefault()
        });
        this.markers = $s(e.markers(t)), e.initialSpacer && (this.spacer = new mr(t, 0, 0, [e.initialSpacer(t)]), this.dom.appendChild(this.spacer.dom), this.spacer.dom.style.cssText += "visibility: hidden; pointer-events: none")
    }
    update(t) {
        let e = this.markers;
        if (this.markers = $s(this.config.markers(t.view)), this.spacer && this.config.updateSpacer) {
            let s = this.config.updateSpacer(this.spacer.markers[0], t);
            s != this.spacer.markers[0] && this.spacer.update(t.view, 0, 0, [s])
        }
        let i = t.view.viewport;
        return !A.eq(this.markers, e, i.from, i.to) || (this.config.lineMarkerChange ? this.config.lineMarkerChange(t) : !1)
    }
    destroy() {
        for (let t of this.elements) t.destroy()
    }
}
class mr {
    constructor(t, e, i, s) {
        this.height = -1, this.above = 0, this.markers = [], this.dom = document.createElement("div"), this.dom.className = "cm-gutterElement", this.update(t, e, i, s)
    }
    update(t, e, i, s) {
        this.height != e && (this.height = e, this.dom.style.height = e + "px"), this.above != i && (this.dom.style.marginTop = (this.above = i) ? i + "px" : ""), jl(this.markers, s) || this.setMarkers(t, s)
    }
    setMarkers(t, e) {
        let i = "cm-gutterElement",
            s = this.dom.firstChild;
        for (let r = 0, o = 0;;) {
            let l = o,
                h = r < e.length ? e[r++] : null,
                f = !1;
            if (h) {
                let a = h.elementClass;
                a && (i += " " + a);
                for (let c = o; c < this.markers.length; c++)
                    if (this.markers[c].compare(h)) {
                        l = c, f = !0;
                        break
                    }
            } else l = this.markers.length;
            for (; o < l;) {
                let a = this.markers[o++];
                if (a.toDOM) {
                    a.destroy(s);
                    let c = s.nextSibling;
                    s.remove(), s = c
                }
            }
            if (!h) break;
            h.toDOM && (f ? s = s.nextSibling : this.dom.insertBefore(h.toDOM(t), s)), f && o++
        }
        this.dom.className = i, this.markers = e
    }
    destroy() {
        this.setMarkers(null, [])
    }
}

function jl(n, t) {
    if (n.length != t.length) return !1;
    for (let e = 0; e < n.length; e++)
        if (!n[e].compare(t[e])) return !1;
    return !0
}
const $l = C.define(),
    Et = C.define({
        combine(n) {
            return Wi(n, {
                formatNumber: String,
                domEventHandlers: {}
            }, {
                domEventHandlers(t, e) {
                    let i = Object.assign({}, t);
                    for (let s in e) {
                        let r = i[s],
                            o = e[s];
                        i[s] = r ? (l, h, f) => r(l, h, f) || o(l, h, f) : o
                    }
                    return i
                }
            })
        }
    });
class ei extends xt {
    constructor(t) {
        super(), this.number = t
    }
    eq(t) {
        return this.number == t.number
    }
    toDOM() {
        return document.createTextNode(this.number)
    }
}

function ii(n, t) {
    return n.state.facet(Et).formatNumber(t, n.state)
}
const Gl = ne.compute([Et], n => ({
    class: "cm-lineNumbers",
    renderEmptyElements: !1,
    markers(t) {
        return t.state.facet($l)
    },
    lineMarker(t, e, i) {
        return i.some(s => s.toDOM) ? null : new ei(ii(t, t.state.doc.lineAt(e.from).number))
    },
    widgetMarker: () => null,
    lineMarkerChange: t => t.startState.facet(Et) != t.state.facet(Et),
    initialSpacer(t) {
        return new ei(ii(t, Ys(t.state.doc.lines)))
    },
    updateSpacer(t, e) {
        let i = ii(e.view, Ys(e.view.state.doc.lines));
        return i == t.number ? t : new ei(i)
    },
    domEventHandlers: n.facet(Et).domEventHandlers
}));

function sh(n = {}) {
    return [Et.of(n), pr(), Gl]
}

function Ys(n) {
    let t = 9;
    for (; t < n;) t = t * 10 + 9;
    return t
}
const Yl = new class extends xt {
        constructor() {
            super(...arguments), this.elementClass = "cm-activeLineGutter"
        }
    },
    Xl = Ve.compute(["selection"], n => {
        let t = [],
            e = -1;
        for (let i of n.selection.ranges) {
            let s = n.doc.lineAt(i.head).from;
            s > e && (e = s, t.push(Yl.range(s)))
        }
        return A.of(t)
    });

function nh() {
    return Xl
}
export {
    Kt as A, Zl as B, lt as C, V as D, D as E, C as F, xt as G, U as M, Fi as P, le as R, F as S, j as T, nt as V, jt as W, S as a, qt as b, Wi as c, Vr as d, B as e, Ht as f, ih as g, A as h, I as i, te as j, eh as k, ht as l, si as m, gl as n, Jl as o, It as p, O as q, st as r, Wl as s, H as t, at as u, sh as v, th as w, _l as x, nh as y, Ke as z
};
//# sourceMappingURL=ovpdmx71kjznjdh8.js.map