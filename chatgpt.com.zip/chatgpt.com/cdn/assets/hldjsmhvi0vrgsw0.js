var Oe = Object.defineProperty,
    Ne = Object.defineProperties;
var Ue = Object.getOwnPropertyDescriptors;
var F = Object.getOwnPropertySymbols;
var pe = Object.prototype.hasOwnProperty,
    fe = Object.prototype.propertyIsEnumerable;
var ge = (s, e, n) => e in s ? Oe(s, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : s[e] = n,
    l = (s, e) => {
        for (var n in e || (e = {})) pe.call(e, n) && ge(s, n, e[n]);
        if (F)
            for (var n of F(e)) fe.call(e, n) && ge(s, n, e[n]);
        return s
    },
    C = (s, e) => Ne(s, Ue(e));
var Q = (s, e) => {
    var n = {};
    for (var t in s) pe.call(s, t) && e.indexOf(t) < 0 && (n[t] = s[t]);
    if (s != null && F)
        for (var t of F(s)) e.indexOf(t) < 0 && fe.call(s, t) && (n[t] = s[t]);
    return n
};
import {
    r as p,
    j as a,
    f as ye,
    M as te,
    b as be,
    e as ke,
    c as se
} from "./fg33krlcm0qyi6yw.js";
import {
    P as y,
    C as Se,
    nW as Fe,
    M as me,
    N as Le,
    L as I,
    m as Ge,
    V as he,
    b as Ve,
    c0 as Ke,
    a9 as Pe,
    es as Z,
    T as X,
    R as He,
    dh as $e
} from "./dykg4ktvbu3mhmdo.js";
import {
    u as _e
} from "./h8afdg57t22ai4ff.js";
import {
    e6 as ze,
    io as Je,
    dg as Ye,
    ip as Qe
} from "./k15yxxoybkkir2ou.js";
import {
    E as Ze
} from "./9xukfjm3wk4gydlw.js";
import {
    a as Xe,
    u as et
} from "./oi0jufgbruu7yg53.js";
import {
    a as v,
    b as ee,
    u as tt
} from "./jd9zt1u141h04j00.js";

function st({
    isOpen: s,
    onClose: e,
    onContinue: n,
    analyticsParams: t
}) {
    p.useEffect(() => {
        s && y.logEventWithStatsig("Mobile Subscription Warning Modal Shown", "chatgpt_mobile_subscription_warning_modal_shown", t)
    }, [t, s]);
    const r = () => {
            y.logEventWithStatsig("Mobile Subscription Warning Modal Continue Clicked", "chatgpt_mobile_subscription_warning_modal_continue_clicked", t), n()
        },
        c = () => {
            y.logEventWithStatsig("Mobile Subscription Warning Modal Close Clicked", "chatgpt_mobile_subscription_warning_modal_close_clicked", t), e()
        };
    return a.jsx(Se, {
        testId: "modal-mobile-subscription-warning",
        isOpen: s,
        onClose: c,
        type: "warning",
        icon: Fe,
        title: a.jsx(te, l({}, L.checkSubscriptionHeader)),
        primaryButton: a.jsx(me.Button, {
            title: L.dismissModal.defaultMessage,
            color: "primary",
            onClick: c
        }),
        secondaryButton: a.jsx(me.Button, {
            title: L.continueToNextStep.defaultMessage,
            color: "secondary",
            onClick: r
        }),
        children: a.jsx("span", {
            className: "gap-2 text-gray-600",
            children: L.checkSubscriptionBody.defaultMessage
        })
    })
}
const L = ye({
    checkSubscriptionHeader: {
        id: "mobileSubscriptionWarningModal.checkSubscriptionHeader",
        defaultMessage: "Check your App Store subscription"
    },
    checkSubscriptionBody: {
        id: "mobileSubscriptionWarningModal.checkSubscriptionBody",
        defaultMessage: "Your subscription through the Apple App Store is currently on pause due to a payment issue. Please resolve that issue to resume using ChatGPT Plus and avoid duplicate charges."
    },
    dismissModal: {
        id: "mobileSubscriptionWarningModal.dismissModal",
        defaultMessage: "Cancel"
    },
    continueToNextStep: {
        id: "mobileSubscriptionWarningModal.continueToNextStep",
        defaultMessage: "I understand, continue anyways"
    }
});

function nt() {
    "use forget";
    const s = se.c(1);
    let e;
    return s[0] === Symbol.for("react.memo_cache_sentinel") ? (e = {
        queryKey: ["has-app-store-subscription-in-billing-retry"],
        queryFn: ot
    }, s[0] = e) : e = s[0], be(e)
}
async function ot() {
    return await He.safeGet("/subscriptions/has_app_store_subscription_in_billing_retry")
}

function at(s, e) {
    const n = Le(new Date, s);
    return new Intl.DateTimeFormat(e, {
        year: "numeric",
        month: "short",
        day: "numeric"
    }).format(n)
}

function it(s) {
    "use forget";
    var E;
    const e = se.c(10);
    let n, t, r, c;
    e[0] !== s ? (E = s, {
        testId: c,
        activeColor: n,
        children: t
    } = E, r = Q(E, ["testId", "activeColor", "children"]), e[0] = s, e[1] = n, e[2] = t, e[3] = r, e[4] = c) : (n = e[1], t = e[2], r = e[3], c = e[4]);
    const h = n != null ? n : "primary";
    let b;
    return e[5] !== t || e[6] !== r || e[7] !== h || e[8] !== c ? (b = a.jsx(Pe, C(l({
        fullWidth: !0,
        size: "large",
        color: h,
        "data-testid": c
    }, r), {
        children: t
    })), e[5] = t, e[6] = r, e[7] = h, e[8] = c, e[9] = b) : b = e[9], b
}

function ct(s, e) {
    const n = s.planType,
        t = s.getNextPlanType(),
        r = s.getDaysUntilPlanChanges(),
        c = t && v(t) < v(n);
    return e ? {
        daysUntilPlanChanges: s.getDaysUntilPlanRenews(),
        isDowngradeScheduled: !0
    } : {
        daysUntilPlanChanges: r,
        isDowngradeScheduled: c
    }
}

function rt(s) {
    "use forget";
    const e = se.c(17),
        {
            currentAccount: n,
            children: t,
            disableForMobile: r,
            promoMetadata: c,
            planType: h,
            downgradeToGoDisabled: b
        } = s,
        {
            recentlyDowngraded: E
        } = et(),
        _ = ke(),
        {
            daysUntilPlanChanges: B,
            isDowngradeScheduled: V
        } = ct(n, E),
        q = p.useRef(!1),
        x = c != null && "referrer_name" in c,
        f = Je(n);
    if (r && f) {
        let o;
        e[0] !== _ ? (o = _.formatMessage({
            id: "I2JCGZ",
            defaultMessage: "Mobile subscriptions are currently not eligible for this promotion."
        }), e[0] = _, e[1] = o) : o = e[1];
        let i;
        e[2] !== x ? (i = K => {
            K && !q.current && (x && Qe.logMobileSubscriptionTooltipOpen(), q.current = !0)
        }, e[2] = x, e[3] = i) : i = e[3];
        let S;
        return e[4] !== t || e[5] !== o || e[6] !== i ? (S = a.jsx(X, {
            side: "top",
            sideOffset: 20,
            label: o,
            onOpenChange: i,
            children: t
        }), e[4] = t, e[5] = o, e[6] = i, e[7] = S) : S = e[7], S
    }
    if (b) {
        let o;
        e[8] !== _ ? (o = _.formatMessage({
            id: "AccountPaymentModal.primaryCTA.downgradeToGoDisabledTooltip",
            defaultMessage: "Downgrading to Go is not yet available. To purchase, you must first cancel your current plan."
        }), e[8] = _, e[9] = o) : o = e[9];
        let i;
        return e[10] !== t || e[11] !== o ? (i = a.jsx(X, {
            side: "top",
            labelTextAlign: "left",
            sideOffset: 20,
            label: o,
            children: t
        }), e[10] = t, e[11] = o, e[12] = i) : i = e[12], i
    }
    if (V && B) {
        const o = at(B, _.locale);
        let i;
        return e[13] !== h ? (i = Ye(h.toLowerCase()), e[13] = h, e[14] = i) : i = e[14], a.jsx(X, {
            side: "top",
            sideOffset: 20,
            label: a.jsx(te, {
                id: "3UZynm",
                defaultMessage: "Your subscription will change to {planType} on {date}.",
                values: {
                    date: o,
                    planType: i
                }
            }),
            children: t
        })
    }
    let m;
    return e[15] !== t ? (m = a.jsx(a.Fragment, {
        children: t
    }), e[15] = t, e[16] = m) : m = e[16], m
}

function kt(lt) {
    var oe = lt,
        {
            analyticsParams: s,
            billingDetails: e,
            currentAccount: n,
            planType: t,
            planLoading: r,
            setPlanLoading: c,
            testId: h,
            onPromoClose: b,
            activeColor: E,
            disableForMobile: _ = !1,
            disabled: B,
            downgradeToGoDisabled: V = !1,
            loading: q = !1,
            overrideOnClick: x,
            promoCode: f,
            referralCode: k,
            promoCampaign: m,
            promoMetadata: o,
            autoUpgrade: i = !1,
            fromiOSWebview: S = !1,
            pricingPlan: K,
            setShouldShowCheckoutLoadingOverlay: ne,
            children: Me
        } = oe,
        Ce = Q(oe, ["analyticsParams", "billingDetails", "currentAccount", "planType", "planLoading", "setPlanLoading", "testId", "onPromoClose", "activeColor", "disableForMobile", "disabled", "downgradeToGoDisabled", "loading", "overrideOnClick", "promoCode", "referralCode", "promoCampaign", "promoMetadata", "autoUpgrade", "fromiOSWebview", "pricingPlan", "setShouldShowCheckoutLoadingOverlay", "children"]);
    "use no forget";
    const {
        data: H,
        refetch: Ee
    } = be($e), {
        trackSelectedPixels: xe
    } = _e({
        key: t
    });
    let w;
    switch (t) {
        case I.GO:
            w = "go-secondary";
            break;
        case I.PLUS:
            w = "plus-secondary";
            break;
        case I.PRO:
            w = "pro-secondary";
            break;
        case I.SELF_SERVE_BUSINESS:
            w = "team-secondary";
            break;
        default:
            w = ""
    }
    const {
        trackSelectedPixels: we
    } = _e({
        key: w
    }), j = Ve(), {
        data: {
            value: Re
        } = {}
    } = nt(), [Te, ae] = p.useState(!1), [ie, ce] = p.useState(!1), $ = p.useRef(null), [re, O] = p.useState(!1), le = p.useRef(!1), R = p.useRef(new Map), T = p.useRef(new Map), De = Ge(), z = ke(), J = n.planType, Ae = n.hasPaidSubscription() && v(t) < v(J), ve = n.hasPaidSubscription() && v(t) > v(J), je = (o == null ? void 0 : o.plan_name) === ee(t) && (o == null ? void 0 : o.plan_type_change) === "equal", N = he(j, "3950229590"), {
        prepareCheckoutSession: Y,
        navigateToCheckout: We
    } = ze(), Ie = n.hasPaidSubscription() && n.isPlus(), ue = t === I.PLUS && !Ie && N.get("enabled_prefetch_checkout_for_plus", !1);
    p.useEffect(() => {
        if (!ue) return;
        const d = {
                plan_name: ee(t),
                billing_details: e,
                promo_campaign: m ? {
                    promo_campaign_id: m,
                    is_coupon_from_query_param: !1
                } : void 0
            },
            P = C(l({}, d), {
                discount_code: l({}, f && {
                    promo_code: f
                })
            }),
            D = C(l({}, d), {
                discount_code: l({}, k && {
                    referral_code: k
                })
            }),
            g = f ? P : k ? D : d,
            u = JSON.stringify(g);
        if (R.current.has(u)) return;
        y.logEventWithStatsig("Account Pay: Prefetch Checkout Session", "chatgpt_account_payment_modal_prefetch_checkout_session", s), R.current.clear(), T.current.clear();
        const A = N.get("skip_sentinel_checkout", !1),
            M = Y(g, {
                skipSentinelCheckout: A,
                fromiOSWebview: S
            });
        R.current.set(u, M), T.current.set(u, g)
    }, [s, e, S, N, t, Y, m, f, k, ue]);
    const Be = async () => {
            var de;
            const d = {
                    plan_name: ee(t),
                    billing_details: e,
                    promo_campaign: m ? {
                        promo_campaign_id: m,
                        is_coupon_from_query_param: !1
                    } : void 0
                },
                P = C(l({}, d), {
                    discount_code: l({}, f && {
                        promo_code: f
                    })
                }),
                D = C(l({}, d), {
                    discount_code: l({}, k && {
                        referral_code: k
                    })
                }),
                g = f ? P : k ? D : d,
                u = JSON.stringify(g),
                A = R.current.get(u);
            if (A) return y.logEventWithStatsig("Account Pay: Using Prefetched Checkout Session", "chatgpt_account_payment_modal_using_prefetched_checkout_session", s), {
                response: await A,
                checkoutPayload: (de = T.current.get(u)) != null ? de : g
            };
            y.logEventWithStatsig("Account Pay: Click to Fetch Checkout Session", "chatgpt_account_payment_modal_click_to_fetch_checkout_session", s), R.current.clear(), T.current.clear();
            const M = N.get("skip_sentinel_checkout", !1),
                W = Y(g, {
                    skipSentinelCheckout: M,
                    fromiOSWebview: S
                });
            return R.current.set(u, W), T.current.set(u, g), {
                response: await W,
                checkoutPayload: T.current.get(u)
            }
        },
        qe = async ({
            skipEmailCheck: d
        }) => {
            var P, D;
            if (!(H != null && H.email) && !d) {
                O(!0);
                return
            }
            c(t), y.logEvent("Account Pay: Payment Checkout Clicked", s), Z(j, "chatgpt_account_payment_modal_upgrade_button_click", t), $.current = performance.now();
            try {
                const g = he(j, "3542930659").get("show_loading", !1);
                ne(g);
                const {
                    response: u,
                    checkoutPayload: A
                } = await Be();
                let M;
                $.current && (M = performance.now() - $.current), y.logEvent("Account Pay: Navigating to Payment Checkout", C(l({}, s), {
                    url: (P = u.url) != null ? P : "",
                    latency_ms: M
                }));
                const W = {
                    url: String((D = u.url) != null ? D : "")
                };
                M !== void 0 && (W.latency_ms = M.toString()), Z(j, "chatgpt_account_payment_modal_navigating_to_checkout", t, W), await We(u, {
                    checkoutPayload: A
                })
            } catch (g) {
                De.warning(z.formatMessage(G.paymentErrorWarning), {
                    hasCloseButton: !0
                }), ne(!1)
            }
            c(null)
        },
        U = ({
            skipAppStoreSubscriptionInBillingRetryCheck: d = !1,
            skipEmailCheck: P = !1
        } = {}) => {
            if (Re && !d) return ae(!0);
            if (x) return x(e, s);
            Ae || ve || je ? (y.logEvent("Account Pay: Payment Checkout Clicked", s), Z(j, "chatgpt_account_payment_modal_upgrade_button_click", t), ce(!0)) : (xe(), we(), qe({
                skipEmailCheck: P
            }))
        };
    return p.useEffect(() => {
        !i || le.current || (le.current = !0, U())
    }, [i]), tt(re, {
        plan: s
    }), a.jsxs(a.Fragment, {
        children: [a.jsx(rt, {
            currentAccount: n,
            disableForMobile: _,
            promoMetadata: o,
            planType: t,
            downgradeToGoDisabled: V,
            children: a.jsx(it, C(l({
                disabled: B,
                loading: q,
                onClick: () => U(),
                testId: h,
                activeColor: E
            }, Ce), {
                children: r === t ? a.jsx(Ke, {}) : Me
            }))
        }), a.jsx(st, {
            isOpen: Te,
            onClose: () => ae(!1),
            onContinue: () => U({
                skipAppStoreSubscriptionInBillingRetryCheck: !0
            }),
            analyticsParams: s
        }), ie && a.jsx(Xe, {
            isOpen: ie,
            onClose: () => ce(!1),
            accountId: n.id,
            initialPlanType: J,
            updatedPlanType: t,
            billingDetails: e,
            promoMetadata: o,
            promoCode: f,
            onPromoClose: b,
            fullPriceResumeDateString: K.fullPriceResumeDateString
        }), a.jsx(Se, {
            testId: "modal-add-email",
            isOpen: re,
            onClose: () => O(!1),
            type: "success",
            className: "max-w-sm",
            children: a.jsx(Ze, {
                enterEmailTitle: z.formatMessage(G.addEmailTitle),
                enterEmailDescription: z.formatMessage(G.addEmailDescription),
                onVerified: () => {
                    Ee(), O(!1), U({
                        skipEmailCheck: !0
                    })
                },
                cancelFlowButton: a.jsx(Pe, {
                    className: "w-full rounded-md",
                    color: "secondary",
                    onClick: () => O(!1),
                    children: a.jsx(te, l({}, G.cancelAddEmail))
                })
            })
        })]
    })
}
const G = ye({
    paymentErrorWarning: {
        id: "AccountPaymentModal.primaryCTA.paymentErrorWarning",
        defaultMessage: "The payments page encountered an error. Please try again. If the problem continues, please visit help.openai.com."
    },
    addEmailTitle: {
        id: "AccountPaymentModal.primaryCTA.addEmailTitle",
        defaultMessage: "Email required"
    },
    addEmailDescription: {
        id: "AccountPaymentModal.primaryCTA.addEmailDescription",
        defaultMessage: "You'll be able to login with this email. It will also be used for account updates (like password resets) and information about OpenAI services."
    },
    cancelAddEmail: {
        id: "AccountPaymentModal.primaryCTA.cancelAddEmail",
        defaultMessage: "Cancel"
    },
    highDemandDisabledText: {
        id: "AccountPaymentModal.primaryCTA.highDemandDisabledText",
        defaultMessage: "Due to high demand, we've temporarily paused upgrades."
    }
});
export {
    st as M, kt as P, at as f, ct as g, G as m
};
//# sourceMappingURL=hldjsmhvi0vrgsw0.js.map