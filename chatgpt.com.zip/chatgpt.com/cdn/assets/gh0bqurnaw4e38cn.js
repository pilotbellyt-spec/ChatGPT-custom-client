import {
    r as y,
    j as s
} from "./fg33krlcm0qyi6yw.js";
import {
    e2 as f,
    dF as _,
    dH as A,
    bc as p,
    bd as S,
    dJ as M
} from "./dykg4ktvbu3mhmdo.js";
import {
    A as v
} from "./h21g9slzr4ujv9kj.js";
import {
    j4 as w,
    jr as O,
    j3 as g,
    js as E,
    j7 as b,
    jt as C,
    ju as R,
    jv as T,
    jw as J,
    jx as k
} from "./k15yxxoybkkir2ou.js";

function H(u, r) {
    const {
        automationId: o,
        automationTitle: e,
        automationMessage: h
    } = y.useMemo(() => {
        const l = r.find(a => a.author.role === f.Assistant),
            n = l ? _.getParentPromptNode(A(u), l.id) : null;
        let t = n == null ? void 0 : n.message.metadata;
        if (!(t != null && t.real_author_type)) {
            const a = r.find(c => {
                var i;
                return ((i = c.metadata) == null ? void 0 : i.real_author_type) === "automation"
            });
            t = a == null ? void 0 : a.metadata
        }
        const d = (t == null ? void 0 : t.real_author_type) === "automation" ? t == null ? void 0 : t.real_author_id : null,
            m = t == null ? void 0 : t.real_author_title;
        return {
            automationId: d,
            automationTitle: m,
            automationMessage: n == null ? void 0 : n.message
        }
    }, [u, r]), {
        automation: x
    } = w(o != null ? o : "");
    return {
        automationId: o,
        automation: x,
        automationTitle: e,
        automationMessage: h
    }
}

function L({
    clientThreadId: u,
    messages: r
}) {
    var m, a;
    const {
        automationId: o,
        automation: e,
        automationTitle: h
    } = H(u, r), l = O(u).isOdysseyMode || r.some(c => {
        var i;
        return (i = c.metadata) == null ? void 0 : i.n7jupd_message
    }), n = (m = g(u)) == null ? void 0 : m.value, {
        isScheduledRun: t
    } = y.useContext(E), [j, d] = y.useState(!1);
    return y.useEffect(() => {
        o && p.count(S.JAWBONE, "jawbone_automation_source_header.open")
    }, [o]), o ? t ? s.jsx("div", {
        className: "relative my-2 w-full",
        children: s.jsx(b, {
            automation: e,
            fullWidth: !0
        })
    }) : l ? n === M.REALTIME ? null : s.jsx(C, {
        clientThreadId: u,
        children: s.jsx(R, {
            children: ({
                isScheduled: c,
                isScheduledRun: i
            }) => c && i && s.jsx(T, {})
        })
    }) : s.jsxs("div", {
        className: "text-token-text-secondary hover:text-token-text-primary mb-1 flex items-center gap-1.5 text-sm",
        children: [s.jsx(v, {
            className: "icon-sm"
        }), s.jsx("button", {
            onClick: () => {
                d(!0)
            },
            children: (a = e == null ? void 0 : e.title) != null ? a : h
        }), j && e && s.jsx(J, {
            initialScheduleComponents: e.schedule_components,
            nextRunTimes: e.next_run_times,
            children: s.jsx(k, {
                item: e,
                source: "chat",
                onClose: () => {
                    d(!1)
                }
            })
        })]
    }) : null
}
export {
    L as AutomationSourceHeader
};
//# sourceMappingURL=gh0bqurnaw4e38cn.js.map