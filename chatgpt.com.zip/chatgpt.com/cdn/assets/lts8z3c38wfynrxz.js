import {
    c as e,
    s as o
} from "./dykg4ktvbu3mhmdo.js";
const r = e(o, "9f891f", 20, 20);
export {
    r as M
};
//# sourceMappingURL=lts8z3c38wfynrxz.js.map