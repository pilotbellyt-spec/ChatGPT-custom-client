var Oe = Object.defineProperty,
    Ge = Object.defineProperties;
var He = Object.getOwnPropertyDescriptors;
var ce = Object.getOwnPropertySymbols;
var Ne = Object.prototype.hasOwnProperty,
    Me = Object.prototype.propertyIsEnumerable;
var Ee = (t, e, o) => e in t ? Oe(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: o
    }) : t[e] = o,
    me = (t, e) => {
        for (var o in e || (e = {})) Ne.call(e, o) && Ee(t, o, e[o]);
        if (ce)
            for (var o of ce(e)) Me.call(e, o) && Ee(t, o, e[o]);
        return t
    },
    fe = (t, e) => Ge(t, He(e));
var Ce = (t, e) => {
    var o = {};
    for (var n in t) Ne.call(t, n) && e.indexOf(n) < 0 && (o[n] = t[n]);
    if (t != null && ce)
        for (var n of ce(t)) e.indexOf(n) < 0 && Me.call(t, n) && (o[n] = t[n]);
    return o
};
import {
    j as s,
    e as le,
    r as h,
    w as We,
    M as K,
    c as Ke,
    i as Ue
} from "./fg33krlcm0qyi6yw.js";
import {
    c as Ve,
    T as de,
    l as te,
    c0 as ge,
    ab as qe,
    nX as ze,
    ij as Xe,
    jR as Ye,
    i6 as $e,
    t9 as Je,
    bp as ke,
    bt as ye,
    d as Ze,
    wv as Qe,
    a9 as he,
    b as es
} from "./dykg4ktvbu3mhmdo.js";
import {
    s as ss
} from "./cmaobpdpreyiep8p.js";
import {
    M as Se
} from "./ab9pr9c8apckuums.js";
import {
    kS as ts,
    cw as ns,
    fx as os,
    cM as rs,
    cD as Re,
    cE as Pe,
    uE as Be,
    e8 as as,
    ne as ls,
    z as Ie,
    de as is,
    B as cs
} from "./k15yxxoybkkir2ou.js";
import {
    C as _e
} from "./hnbtdromsi7xhy2m.js";
import {
    I as ds
} from "./j8efhdgdagw30nd8.js";
import {
    u as Le
} from "./jdbfnvyv9bb4osfa.js";
import {
    h as ue,
    G as us,
    H as ms,
    I as fs,
    J as hs,
    f as xs
} from "./jb9b7tatrnyq635u.js";
import {
    W as ps
} from "./mvhcdm28zmc6uy2d.js";
import {
    i as gs
} from "./f1b9xcddv1uk610d.js";
const pe = Ve(ss, "008295", 24, 24);

function Te({
    triggerText: t,
    toolTip: e,
    ariaLabel: o,
    Icon: n,
    truncate: l = !0,
    isLoading: i = !1
}) {
    return s.jsx(ts, {
        className: "composer-btn px-2",
        "aria-label": o,
        "aria-busy": i,
        children: s.jsx(de, {
            label: e,
            className: "text-sm font-medium",
            children: s.jsxs("div", {
                className: "flex max-w-full items-center gap-1.5 ps-1",
                children: [n, s.jsx("span", {
                    className: te("hidden sm:block", l ? "max-w-[8rem] truncate md:max-w-[10rem]" : "w-fit"),
                    children: t
                }), i && s.jsx(ge, {
                    "aria-hidden": !0,
                    className: "icon-sm"
                }), s.jsx(ns, {
                    "aria-hidden": !0,
                    className: "icon-sm"
                })]
            })
        })
    })
}

function ne(C) {
    var x = C,
        {
            children: t,
            className: e,
            onClick: o,
            isSelected: n,
            isActive: l,
            isVirtualHover: i = !1,
            label: j,
            isDisabled: d,
            tooltipLabel: r,
            isSubMenuTrigger: m,
            noDefaultHoverState: b,
            as: a = "button",
            truncateLabel: E,
            infoIcon: v,
            infoLink: N,
            icon: p
        } = x,
        g = Ce(x, ["children", "className", "onClick", "isSelected", "isActive", "isVirtualHover", "label", "isDisabled", "tooltipLabel", "isSubMenuTrigger", "noDefaultHoverState", "as", "truncateLabel", "infoIcon", "infoLink", "icon"]);
    const w = le();
    let T = s.jsx(s.Fragment, {});
    t ? T = s.jsx("div", {
        className: "flex flex-1 items-center gap-4",
        children: t
    }) : j && (T = s.jsxs("div", {
        className: te("flex items-center gap-3", E ? "w-0 flex-1" : "w-full"),
        children: [p && (h.isValidElement(p) ? p : s.jsx(vs, {
            icon: p
        })), j && s.jsx("div", {
            className: te("flex flex-col items-start py-1", d && "text-token-text-quaternary pointer-events-none", E && "w-[100%]"),
            children: s.jsx("div", {
                className: te("flex items-center text-start text-sm", E && "w-full"),
                children: s.jsx("span", {
                    className: "w-full overflow-hidden text-ellipsis whitespace-nowrap",
                    children: j
                })
            })
        })]
    }), r && (T = s.jsx(de, {
        sideOffset: -10,
        label: r,
        className: "w-full",
        children: T
    })));
    const D = s.jsxs("div", {
            className: te("flex items-center justify-center", (n || v && N || m) && "min-w-5"),
            children: [n && s.jsx(qe, {
                className: "icon color:var(--tint-color,#0285FF) icon-sm",
                "aria-label": w.formatMessage({
                    id: "wham.codexMenuRow.selected",
                    defaultMessage: "Selected"
                })
            }), v && N && s.jsx("a", {
                href: N,
                target: "_blank",
                rel: "noopener noreferrer",
                children: v
            }), m && s.jsx(os, {
                className: "icon text-token-text-tertiary w-7",
                "aria-label": w.formatMessage({
                    id: "wham.codexMenuRow.openSubmenu",
                    defaultMessage: "Open submenu"
                })
            })]
        }),
        S = te("flex cursor-pointer items-center rounded-[10px] px-2.5 py-1", (n || v && N || m) && "gap-4", l && "bg-black/5 dark:bg-white/5", !b && "hover:bg-black/5 dark:hover:bg-white/5", i && "bg-black/5 dark:bg-white/5", e);
    if (a === "div") {
        const c = g;
        return s.jsxs("div", fe(me({}, c), {
            className: S,
            children: [T, D]
        }))
    }
    const A = g;
    return s.jsxs("button", fe(me({
        type: "button"
    }, A), {
        onClick: c => {
            c.persist(), requestAnimationFrame(() => {
                o == null || o(c)
            })
        },
        className: S,
        children: [T, D]
    }))
}

function vs({
    icon: t
}) {
    const e = t;
    return s.jsx("div", {
        className: "text-token-text-secondary flex h-5 w-5 items-center justify-center",
        children: s.jsx(e, {
            className: "h-5 w-5 shrink-0",
            "aria-label": ""
        })
    })
}
const xe = "wham-environment-popover-event";

function De(t, e, o) {
    h.useEffect(() => {
        function l(i) {
            i.detail.popover !== t && o()
        }
        return window.addEventListener(xe, l), () => {
            window.removeEventListener(xe, l)
        }
    }, [t, o]);
    const n = h.useCallback(l => {
        window.dispatchEvent(new CustomEvent(xe, {
            detail: {
                popover: l
            }
        }))
    }, []);
    h.useEffect(() => {
        e && n(t)
    }, [e, n, t])
}
const Ae = ({
    items: t,
    onSelect: e,
    keyExtractor: o
}) => {
    const [n, l] = h.useState(null), [i] = h.useState(new Map);
    return {
        hoveredId: n,
        setHoveredId: l,
        getItemRef: d => r => {
            const m = o(d);
            return r && i.set(m, r), () => {
                i.delete(m)
            }
        },
        itemRefs: i,
        onKeyDown: d => {
            var v;
            const r = d.key === "ArrowDown" || d.key === "n" && d.ctrlKey,
                m = d.key === "ArrowUp" || d.key === "p" && d.ctrlKey;
            if (!(r || m || d.key === "Enter")) return;
            if (d.preventDefault(), d.key === "Enter") {
                n && e(n);
                return
            }
            const b = t.findIndex(N => o(N) === n),
                a = rs(b - (m ? 1 : -1), 0, t.length - 1),
                E = o(t[a]);
            (v = i.get(E)) == null || v.scrollIntoView({
                behavior: "instant",
                block: "nearest"
            }), l(E)
        }
    }
};

function ws({
    environment: t,
    repository: e
}) {
    var N, p, g, C;
    const o = le(),
        {
            branch: n,
            setBranch: l
        } = ue(),
        [i, j] = h.useState(""),
        [d, r] = h.useState(!1),
        m = h.useRef(null),
        b = () => r(!1),
        a = (g = (p = (N = t == null ? void 0 : t.repos) == null ? void 0 : N[0]) != null ? p : e == null ? void 0 : e.id) != null ? g : null,
        E = h.useRef(a),
        v = t ? js(t) : (C = e == null ? void 0 : e.default_branch) != null ? C : "main";
    return h.useEffect(() => {
        const x = E.current;
        if (E.current = a, !a) {
            l(null);
            return
        }
        const w = us(a);
        if (x !== a) {
            if (w) {
                l(w);
                return
            }
            l(v);
            return
        }
        n || l(w != null ? w : v)
    }, [n, a, v, l]), De("branch", d, () => r(!1)), Le([{
        key: "whamBranches",
        action: () => r(!0),
        actionMessageDescriptor: o.formatMessage({
            id: "wham.keyboardActions.whamBranches",
            defaultMessage: "Branches"
        }),
        group: Pe.Chat,
        keyboardBinding: [Re.Mod, "b"]
    }]), s.jsx("div", {
        className: "items-center rounded-full",
        children: s.jsxs(Be, {
            open: d,
            onOpenChange: r,
            children: [s.jsx(Te, {
                triggerText: n != null ? n : o.formatMessage({
                    id: "wham.codexBranchPopover.selectABranch",
                    defaultMessage: "Select a Branch"
                }),
                toolTip: n === "" || d ? "" : n != null && n.length ? n : o.formatMessage({
                    id: "wham.codexBranchPopover.searchForYourBranchTooltip",
                    defaultMessage: "Search for your branch"
                }),
                ariaLabel: o.formatMessage({
                    id: "wham.codexBranchPopover.searchForYourBranchAria",
                    defaultMessage: "Search for your branch"
                }),
                Icon: s.jsx(pe, {
                    "aria-hidden": !0,
                    className: "icon-sm"
                })
            }), s.jsx(_e, {
                align: "start",
                isOpen: d,
                closePopover: b,
                popoverContentRef: m,
                children: s.jsx(bs, {
                    defaultBranch: v,
                    repoId: a,
                    searchQuery: i,
                    setSearchQuery: j,
                    setBranch: l,
                    selectedBranch: n != null ? n : "",
                    closePopover: b
                })
            })]
        })
    })
}

function bs({
    repoId: t,
    defaultBranch: e,
    setBranch: o,
    selectedBranch: n,
    searchQuery: l,
    setSearchQuery: i,
    closePopover: j
}) {
    const d = le(),
        r = h.useRef(null),
        m = as(l, 300),
        b = h.useMemo(() => t ? ms(t) : [], [t]),
        {
            data: a,
            isLoading: E,
            fetchNextPage: v,
            hasNextPage: N,
            isFetchingNextPage: p,
            error: g
        } = We({
            queryKey: ["searchBranches", t, m],
            enabled: !!t,
            initialPageParam: null,
            queryFn: ({
                pageParam: c
            }) => ps.searchBranchesByRepository(t != null ? t : "", m, ls, c != null ? c : null),
            getNextPageParam: c => {
                var k;
                return (k = c == null ? void 0 : c.cursor) != null ? k : null
            }
        }),
        C = h.useMemo(() => {
            var U, u, B;
            const c = (B = (u = (U = a == null ? void 0 : a.pages) == null ? void 0 : U.flat().map(R => R.items.flatMap(F => F.branch))) == null ? void 0 : u.flat()) != null ? B : [],
                k = new Set,
                _ = [];
            e && !k.has(e) && (k.add(e), _.push(e));
            for (const R of b) k.has(R) || (k.add(R), _.push(R));
            for (const R of c) k.has(R) || (k.add(R), _.push(R));
            return _
        }, [a, e, b]),
        x = c => {
            o(c), j()
        },
        w = h.useMemo(() => l != null && l.trim() ? C.filter(c => c.toLowerCase().includes(l.toLowerCase())) : C != null ? C : [], [l, C]),
        {
            hoveredId: T,
            setHoveredId: D,
            onKeyDown: S,
            getItemRef: A
        } = Ae({
            items: w,
            keyExtractor: c => c,
            onSelect: x
        });
    return h.useEffect(() => {
        r.current && r.current.focus()
    }, []), s.jsxs("div", {
        className: "gap flex max-h-[280px] w-90 flex-col rounded-lg p-0 md:max-h-[360px]",
        onClick: c => {
            c.stopPropagation()
        },
        children: [s.jsx(Ie, {
            ref: r,
            className: "placeholder:text-token-text-tertiary !focus-within:ring-0 my-1.5 w-full border-0 bg-transparent ps-4 outline-none focus:border-0 focus:ring-0 focus:outline-none",
            type: "text",
            autoComplete: "off",
            inputClassName: "text-sm",
            name: "search-branch",
            value: l,
            suppressFocus: !0,
            onKeyDown: S,
            onChange: c => i(c.target.value),
            placeholder: d.formatMessage({
                id: "wham.codexBranchPopover.branch",
                defaultMessage: "Search branches…"
            }),
            ariaLabel: d.formatMessage({
                id: "wham.codexBranchPopover.createBranchAria",
                defaultMessage: "Create a new branch"
            })
        }), s.jsx("div", {
            className: "bg-token-border-default h-px w-full"
        }), s.jsxs("div", {
            className: "min-h-18 w-full overflow-y-auto p-1.5",
            children: [w == null ? void 0 : w.map(c => {
                const k = c === n;
                return s.jsx(ne, {
                    className: "w-full max-w-full whitespace-nowrap",
                    as: "button",
                    onMouseEnter: () => D(c),
                    isVirtualHover: T === c,
                    ref: A(c),
                    onClick: () => {
                        x(c)
                    },
                    isSelected: k,
                    label: c,
                    truncateLabel: !0
                }, c)
            }), g ? s.jsx("div", {
                className: "flex items-center justify-center",
                children: s.jsx(K, {
                    id: "wham.branchPopover.error",
                    defaultMessage: "Error loading branches"
                })
            }) : null, s.jsx(ds, {
                bgColor: "dark:bg-token-bg-secondary",
                hasNextPage: N,
                fetchNextPage: v,
                isFetchingNextPage: p || E
            })]
        })]
    })
}

function js(t) {
    var e;
    for (const o of t.repos) {
        const n = (e = t.repo_map) == null ? void 0 : e[o];
        if (n != null && n.default_branch) return n.default_branch
    }
    return "main"
}

function Es({
    repository: t,
    disabledRepositoryIds: e,
    isCreating: o,
    creatingRepositoryId: n,
    isSelected: l,
    onSelect: i
}) {
    var b, a;
    const j = (a = (b = t.repository_full_name) != null ? b : t.name) != null ? a : "",
        d = n === t.id,
        m = !!(e == null ? void 0 : e.has(t.id)) || !!o && !d || !!d;
    return s.jsx(ne, {
        as: "button",
        className: "w-full",
        onClick: () => {
            m || i(t)
        },
        isSelected: l,
        isDisabled: m,
        label: j
    })
}

function Ns({
    repositories: t,
    isLoading: e,
    isError: o,
    search: n,
    onSelectRepository: l,
    existingEnvironmentRepositoryIds: i,
    showRepositoriesHeader: j
}) {
    "use no forget";
    const d = ze("installations/select_target"),
        r = ue(a => a.selectedRepositoryId),
        m = ue(a => a.useRepositoryAsEnvironment),
        b = h.useMemo(() => t.length ? t.filter(a => {
            var N, p, g, C, x;
            if (!a.id || i.has(a.id)) return !1;
            if (!n) return !0;
            const E = ((p = (N = a.repository_full_name) != null ? N : a.name) != null ? p : "").toLowerCase(),
                v = (x = (C = (g = a.owner) == null ? void 0 : g.login) == null ? void 0 : C.toLowerCase()) != null ? x : "";
            return E.includes(n) || v.includes(n)
        }).sort((a, E) => {
            var p, g, C, x;
            const v = (g = (p = a.repository_full_name) != null ? p : a.name) != null ? g : "",
                N = (x = (C = E.repository_full_name) != null ? C : E.name) != null ? x : "";
            return v.localeCompare(N)
        }) : [], [i, n, t]);
    return s.jsxs("div", {
        className: "text-token-text-primary flex flex-col gap-0.5",
        children: [j && s.jsxs(s.Fragment, {
            children: [s.jsx("div", {
                className: "bg-token-border-default mt-2 h-px w-full"
            }), s.jsx("div", {
                className: "px-1.5",
                children: s.jsx(ne, {
                    as: "div",
                    className: "text-token-text-tertiary pointer-events-none w-full text-sm",
                    label: s.jsx("div", {
                        className: "flex items-center gap-2",
                        children: s.jsx(K, {
                            id: "wham.codexEnvironmentPopover.repositoriesWithoutEnvironments",
                            defaultMessage: "Repositories"
                        })
                    })
                })
            })]
        }), s.jsx("div", {
            className: "px-1.5",
            children: e ? s.jsx("div", {
                className: "flex w-full items-center justify-center py-2",
                children: s.jsx(ge, {
                    className: "ms-2"
                })
            }) : o ? s.jsx("div", {
                className: "p-5 text-center",
                children: s.jsx("p", {
                    className: "text-token-text-tertiary text-sm",
                    children: s.jsx(K, {
                        id: "wham.codexEnvironmentPopover.repositoriesWithoutEnvironmentsError",
                        defaultMessage: "Failed to load repositories"
                    })
                })
            }) : b.length === 0 ? s.jsx("div", {
                className: "p-5 text-center",
                children: s.jsx("p", {
                    className: "text-token-text-tertiary text-sm",
                    children: s.jsx(K, {
                        id: "wham.environmentPopover.noRepositories",
                        defaultMessage: "No repositories found"
                    })
                })
            }) : b.map(a => s.jsx(Es, {
                repository: a,
                isSelected: m && r === a.id,
                onSelect: l
            }, a.id))
        }), s.jsx("div", {
            className: "bg-token-border-default mt-1 h-px w-full"
        }), s.jsx("div", {
            className: "px-1.5 pb-1.5",
            children: s.jsx(ne, {
                as: "button",
                className: "mt-1 w-full",
                onClick: () => {
                    window.open(d, "_blank")
                },
                icon: s.jsx(is, {
                    className: "icon-sm inline-block"
                }),
                label: s.jsx("div", {
                    className: "flex items-center gap-2 text-sm",
                    children: s.jsx(K, {
                        id: "o1jiyf",
                        defaultMessage: "Configure Repositories on GitHub"
                    })
                })
            })
        })]
    })
}

function Fe({
    className: t
}) {
    return s.jsx(cs, {
        className: te("flex w-[8rem] items-center gap-1.5 rounded-full! md:w-[10rem]", t)
    })
}

function Ms() {
    const {
        data: t,
        isError: e
    } = hs(), {
        data: o,
        isLoading: n,
        isError: l
    } = xs();
    return {
        environments: o != null ? o : t,
        fullEnvironmentsLoading: n,
        isErrorEnvironments: l && e
    }
}

function Cs({
    onCreateEnvironment: t,
    showBranchSelector: e = !0,
    allowRepositorySelection: o = !0,
    filters: n = null
} = {}) {
    "use no forget";
    var se, M, q, ie;
    const l = le(),
        {
            environmentId: i,
            setEnvironmentId: j,
            selectedRepositoryId: d,
            setSelectedRepositoryId: r,
            setBranch: m,
            setUseRepositoryAsEnvironment: b,
            useRepositoryAsEnvironment: a
        } = ue(),
        [E, v] = h.useState(!1),
        N = h.useRef(null),
        [p, g] = h.useState(!1),
        C = h.useRef(i),
        [x, w] = h.useState(null),
        [T, D] = h.useState(""),
        {
            data: S,
            isLoading: A,
            isError: c
        } = fs(T),
        {
            environments: k,
            fullEnvironmentsLoading: _,
            isErrorEnvironments: U
        } = Ms(),
        u = h.useMemo(() => n != null && n.repos ? k == null ? void 0 : k.filter(f => gs(f.repos, n.repos).length > 0) : k, [k, n]),
        B = u == null ? void 0 : u.find(f => f.id === i),
        R = h.useCallback(f => {
            var L, O;
            if (!f) return null;
            const y = (O = f.repos) != null ? O : Object.keys((L = f.repo_map) != null ? L : {});
            if (!y.length) return null;
            const [P] = y;
            return P != null ? P : null
        }, []);
    De("environment", E, () => v(!1)), h.useEffect(() => {
        C.current !== i && (C.current = i, i != null && (g(!1), w(null)))
    }, [i]), h.useEffect(() => {
        if (!a) {
            w(null);
            return
        }
    }, [a]), h.useEffect(() => {
        if (p || _) return;
        if (i && !B) {
            j(null), r(null);
            return
        } else if (!i && (u != null && u.length)) {
            const P = Xe(u, [O => {
                var W;
                return !((W = O.is_pinned) != null && W)
            }, O => {
                var W;
                return -((W = O.task_count) != null ? W : 0)
            }])[0];
            j(P.id);
            const L = R(P);
            r(L != null ? L : null);
            return
        }
        const f = R(B);
        f != null && f !== d ? r(f) : B && f == null && d != null && r(null)
    }, [_, i, B, u, j, d, r, R, p]), h.useEffect(() => {
        var y;
        if (U || p || _ || ((y = u == null ? void 0 : u.length) != null ? y : 0) > 0 || !(S != null && S.repositories.length)) return;
        const [f] = S.repositories;
        if (f != null && f.id && o && !i) {
            if (d === f.id && a) {
                (x == null ? void 0 : x.id) !== f.id && w(f);
                return
            }
            b(!0), r(f.id), w(f), m(null)
        }
    }, [S, U, a, i, d, m, r, b, w, p, _, u == null ? void 0 : u.length, x == null ? void 0 : x.id, o]), Le([{
        key: "whamEnvironments",
        action: () => v(!0),
        actionMessageDescriptor: l.formatMessage({
            id: "wham.keyboardActions.whamEnvironments",
            defaultMessage: "Environments"
        }),
        group: Pe.Chat,
        keyboardBinding: [Re.Mod, "e"]
    }]);
    const F = h.useCallback(() => v(!1), []),
        z = h.useCallback(f => {
            f != null && f.id && (g(!0), j(null), b(!0), r(f.id), w(f), m(null), F())
        }, [F, m, j, r, b]),
        X = l.formatMessage({
            id: "wham.codexEnvironmentPopover.selectEnvironment",
            defaultMessage: "Select environment"
        }),
        Y = l.formatMessage({
            id: "wham.codexEnvironmentPopover.selectRepository",
            defaultMessage: "Select repository"
        }),
        oe = l.formatMessage({
            id: "wham.codexEnvironmentPopover.viewAllCodeEnvironments",
            defaultMessage: "View all code environments"
        }),
        I = B == null ? void 0 : B.label,
        $ = ((se = I == null ? void 0 : I.length) != null ? se : 0) > 16,
        G = o && (a || (u == null ? void 0 : u.length) === 0 && !_),
        H = (q = (M = x == null ? void 0 : x.repository_full_name) != null ? M : x == null ? void 0 : x.name) != null ? q : Y,
        J = H.length > 16,
        Z = G ? H : I != null ? I : X,
        re = G ? J ? H : "" : $ ? I != null ? I : "" : I || E ? "" : oe,
        Q = G ? s.jsx(Ye, {
            "aria-hidden": !0,
            className: "icon-sm"
        }) : s.jsx(Se, {
            "aria-hidden": !0,
            className: "icon-sm"
        }),
        ae = h.useMemo(() => {
            const f = new Set;
            return u == null || u.forEach(y => {
                var L, O;
                ((O = y.repos) != null ? O : Object.keys((L = y.repo_map) != null ? L : {})).forEach(W => {
                    W && f.add(W)
                })
            }), f
        }, [u]),
        V = o && a && x ? x : null,
        ee = e && !!(B || V);
    return _ && !(u != null && u.length) ? s.jsx("div", {
        className: "flex items-center gap-3 rounded-full",
        children: s.jsx(Fe, {})
    }) : s.jsxs("div", {
        className: "flex items-center gap-2 rounded-full",
        children: [s.jsxs(Be, {
            open: E,
            onOpenChange: v,
            children: [s.jsx(Te, {
                triggerText: Z,
                toolTip: re,
                ariaLabel: l.formatMessage({
                    id: "wham.codexEnvironmentPopover.viewAll",
                    defaultMessage: "View all code environments"
                }),
                Icon: Q
            }), s.jsx(_e, {
                align: "start",
                isOpen: E,
                closePopover: F,
                popoverContentRef: N,
                children: s.jsx(ks, {
                    searchTerm: T,
                    setSearchTerm: D,
                    repositories: (ie = S == null ? void 0 : S.repositories) != null ? ie : [],
                    isLoadingRepositories: A,
                    isErrorRepositories: c,
                    isLoading: _,
                    environments: u != null ? u : [],
                    environmentId: i,
                    setEnvironmentId: f => {
                        j(f);
                        const y = u == null ? void 0 : u.find(L => L.id === f),
                            P = R(y);
                        r(P != null ? P : null)
                    },
                    closePopover: F,
                    onSelectRepository: z,
                    disabledRepositoryIds: ae,
                    onCreateEnvironment: t,
                    allowRepositorySelection: o
                })
            })]
        }), ee && s.jsx(ws, {
            environment: B,
            repository: V
        })]
    })
}

function ks(t) {
    "use forget";
    const e = Ke.c(77),
        {
            searchTerm: o,
            setSearchTerm: n,
            repositories: l,
            isLoadingRepositories: i,
            isErrorRepositories: j,
            isLoading: d,
            environments: r,
            environmentId: m,
            setEnvironmentId: b,
            closePopover: a,
            onSelectRepository: E,
            disabledRepositoryIds: v,
            onCreateEnvironment: N,
            allowRepositorySelection: p
        } = t,
        g = le(),
        C = h.useRef(null);
    let x;
    e[0] !== a || e[1] !== b ? (x = M => {
        b(M), a()
    }, e[0] = a, e[1] = b, e[2] = x) : x = e[2];
    const w = x,
        T = Ue(),
        D = r.length > 0;
    let S;
    if (e[3] !== m || e[4] !== r || e[5] !== o) {
        e: {
            let M;e[7] !== m ? (M = y => y.slice().sort((P, L) => {
                var be, je;
                if (P.id === m) return -1;
                if (L.id === m) return 1;
                const O = !!P.is_pinned,
                    W = !!L.is_pinned;
                if (O !== W) return O ? -1 : 1;
                const ve = (be = P.task_count) != null ? be : 0,
                    we = (je = L.task_count) != null ? je : 0;
                return ve !== we ? we - ve : P.label.localeCompare(L.label)
            }), e[7] = m, e[8] = M) : M = e[8];
            const q = M,
                ie = o.trim().toLowerCase();
            if (!ie) {
                let y;
                e[9] !== r || e[10] !== q ? (y = q(r), e[9] = r, e[10] = q, e[11] = y) : y = e[11], S = y;
                break e
            }
            const f = r.filter(y => {
                var P;
                return ((P = y.label) != null ? P : "").toLowerCase().includes(ie)
            });S = q(f)
        }
        e[3] = m,
        e[4] = r,
        e[5] = o,
        e[6] = S
    }
    else S = e[6];
    const A = S;
    let c;
    e[12] !== A || e[13] !== w ? (c = {
        items: A,
        keyExtractor: Ss,
        onSelect: w
    }, e[12] = A, e[13] = w, e[14] = c) : c = e[14];
    const {
        hoveredId: k,
        setHoveredId: _,
        onKeyDown: U,
        getItemRef: u
    } = Ae(c);
    let B, R;
    e[15] === Symbol.for("react.memo_cache_sentinel") ? (B = () => {
        var M;
        (M = C.current) == null || M.focus()
    }, R = [], e[15] = B, e[16] = R) : (B = e[15], R = e[16]), h.useEffect(B, R);
    let F;
    e[17] !== n ? (F = M => n(M.target.value), e[17] = n, e[18] = F) : F = e[18];
    let z;
    e[19] !== p || e[20] !== r.length || e[21] !== g ? (z = p ? r.length > 0 ? g.formatMessage({
        id: "wham.codexEnvironmentPopover.searchEnvironmentsTooltip.envless",
        defaultMessage: "Search environments and repos…"
    }) : g.formatMessage({
        id: "wham.codexEnvironmentPopover.searchEnvironmentsTooltip.envlessRepos",
        defaultMessage: "Search repositories…"
    }) : g.formatMessage({
        id: "wham.codexEnvironmentPopover.searchEnvironmentsTooltip.environmentsOnly",
        defaultMessage: "Search environments…"
    }), e[19] = p, e[20] = r.length, e[21] = g, e[22] = z) : z = e[22];
    let X;
    e[23] !== p || e[24] !== g ? (X = p ? g.formatMessage({
        id: "wham.codexEnvironmentPopover.searchEnvironmentsAria.envless",
        defaultMessage: "Search environments and repos"
    }) : g.formatMessage({
        id: "wham.codexEnvironmentPopover.searchEnvironmentsAria.environmentsOnly",
        defaultMessage: "Search environments"
    }), e[23] = p, e[24] = g, e[25] = X) : X = e[25];
    let Y;
    e[26] !== U || e[27] !== o || e[28] !== F || e[29] !== z || e[30] !== X ? (Y = s.jsx(Ie, {
        ref: C,
        className: "placeholder:text-token-text-tertiary !focus-within:ring-0 my-1.5 w-full border-0 bg-transparent ps-4 outline-none focus:border-0 focus:ring-0 focus:outline-none",
        inputClassName: "text-sm",
        type: "text",
        autoComplete: "off",
        name: "branch-to-add",
        value: o,
        onChange: F,
        onKeyDown: U,
        suppressFocus: !0,
        placeholder: z,
        ariaLabel: X
    }), e[26] = U, e[27] = o, e[28] = F, e[29] = z, e[30] = X, e[31] = Y) : Y = e[31];
    let oe;
    e[32] === Symbol.for("react.memo_cache_sentinel") ? (oe = s.jsx("div", {
        className: "bg-token-border-default h-px w-full"
    }), e[32] = oe) : oe = e[32];
    let I;
    e[33] !== Y ? (I = s.jsxs("div", {
        className: "contents",
        onClick: ys,
        children: [Y, oe]
    }), e[33] = Y, e[34] = I) : I = e[34];
    let $;
    e[35] !== r.length ? ($ = r.length > 0 && s.jsx(ne, {
        as: "div",
        className: "text-token-text-tertiary pointer-events-none w-full text-sm",
        label: s.jsx("div", {
            className: "flex items-center gap-2",
            children: s.jsx(K, {
                id: "wham.codexEnvironmentPopover.envlessModeRepositories",
                defaultMessage: "Environments"
            })
        })
    }), e[35] = r.length, e[36] = $) : $ = e[36];
    let G;
    e[37] !== $ ? (G = s.jsx("div", {
        className: "px-1.5 pt-1.5",
        children: $
    }), e[37] = $, e[38] = G) : G = e[38];
    let H;
    e[39] !== m || e[40] !== r.length || e[41] !== A || e[42] !== u || e[43] !== w || e[44] !== k || e[45] !== d || e[46] !== _ ? (H = d ? s.jsx("div", {
        className: "px-1.5",
        children: s.jsx("div", {
            className: "flex w-full items-center justify-center py-2",
            children: s.jsx(ge, {
                className: "ms-2"
            })
        })
    }) : r.length > 0 ? A.length > 0 ? s.jsx("div", {
        className: "px-1.5",
        children: A.map(M => {
            const q = m === M.id;
            return s.jsx(ne, {
                as: "button",
                ref: u(M),
                onMouseEnter: () => _(M.id),
                className: "w-full",
                truncateLabel: !0,
                onClick: () => {
                    w(M.id)
                },
                isVirtualHover: k === M.id,
                isSelected: q,
                label: M.label
            }, M.id)
        })
    }) : s.jsx("div", {
        className: "p-1.5 text-center",
        children: s.jsx("p", {
            className: "text-token-text-tertiary text-sm",
            children: s.jsx(K, {
                id: "wham.environmentPopover.noMatches",
                defaultMessage: "No environments found"
            })
        })
    }) : null, e[39] = m, e[40] = r.length, e[41] = A, e[42] = u, e[43] = w, e[44] = k, e[45] = d, e[46] = _, e[47] = H) : H = e[47];
    let J;
    e[48] !== p || e[49] !== v || e[50] !== r.length || e[51] !== j || e[52] !== i || e[53] !== E || e[54] !== l || e[55] !== o ? (J = p ? s.jsx(Ns, {
        onSelectRepository: E,
        existingEnvironmentRepositoryIds: v,
        showRepositoriesHeader: r.length > 0,
        search: o.trim().toLowerCase(),
        repositories: l,
        isLoading: i,
        isError: j
    }) : null, e[48] = p, e[49] = v, e[50] = r.length, e[51] = j, e[52] = i, e[53] = E, e[54] = l, e[55] = o, e[56] = J) : J = e[56];
    let Z;
    e[57] !== G || e[58] !== H || e[59] !== J ? (Z = s.jsxs("div", {
        className: "flex min-h-0 flex-1 flex-col overflow-y-auto",
        children: [G, H, J]
    }), e[57] = G, e[58] = H, e[59] = J, e[60] = Z) : Z = e[60];
    let re;
    e[61] === Symbol.for("react.memo_cache_sentinel") ? (re = s.jsx("div", {
        className: "bg-token-border-default h-px w-full"
    }), e[61] = re) : re = e[61];
    let Q;
    e[62] !== D || e[63] !== T || e[64] !== N ? (Q = () => {
        !D && N ? N() : T("/codex/settings/environments")
    }, e[62] = D, e[63] = T, e[64] = N, e[65] = Q) : Q = e[65];
    let ae;
    e[66] === Symbol.for("react.memo_cache_sentinel") ? (ae = s.jsx($e, {
        className: "icon-sm"
    }), e[66] = ae) : ae = e[66];
    let V;
    e[67] !== D || e[68] !== g ? (V = D ? g.formatMessage({
        id: "wham.codexEnvironmentPopover.manageEnvironments",
        defaultMessage: "Manage environments"
    }) : g.formatMessage({
        id: "wham.codexEnvironmentPopover.createEnvironment",
        defaultMessage: "Create environment"
    }), e[67] = D, e[68] = g, e[69] = V) : V = e[69];
    let ee;
    e[70] !== Q || e[71] !== V ? (ee = s.jsx("div", {
        className: "bg-token-bg-tertiary flex flex-shrink-0 flex-col gap-1 px-2 py-1.5",
        children: s.jsx(ne, {
            className: "w-full",
            noDefaultHoverState: !0,
            onClick: Q,
            isSelected: !1,
            icon: ae,
            label: V
        }, "environment-action")
    }), e[70] = Q, e[71] = V, e[72] = ee) : ee = e[72];
    let se;
    return e[73] !== I || e[74] !== Z || e[75] !== ee ? (se = s.jsxs("div", {
        className: "flex max-h-[280px] w-80 flex-col overflow-y-auto rounded-lg md:max-h-[360px]",
        children: [I, Z, re, ee]
    }), e[73] = I, e[74] = Z, e[75] = ee, e[76] = se) : se = e[76], se
}

function ys(t) {
    t.stopPropagation()
}

function Ss(t) {
    return t.id
}

function Hs({
    onCreateEnvironment: t,
    showBranchSelector: e,
    filters: o,
    allowRepositorySelection: n
} = {}) {
    const l = es(),
        i = le(),
        {
            isConnected: j,
            isLoading: d,
            openGithubModal: r,
            error: m,
            refetch: b
        } = Je(ye.GITHUB_CONNECTOR, "github", "/codex", ke.CODEX),
        a = Ze(() => Qe(l, ye.GITHUB_CONNECTOR, {
            productSku: ke.CODEX
        }));
    return d ? s.jsx(Fe, {
        className: "h-9"
    }) : m ? s.jsx(de, {
        label: i.formatMessage({
            id: "wham.whamComposerEnvironmentsSelector.failedClickToRetry",
            defaultMessage: "Click to retry"
        }),
        children: s.jsx(he, {
            color: "secondary",
            type: "button",
            className: "border-token-border-default flex w-fit items-center gap-1.5 rounded-full! border",
            onClick: b,
            children: s.jsxs("div", {
                className: "flex items-center gap-1.5",
                children: [s.jsx(Se, {
                    "aria-hidden": !0,
                    className: "icon-sm"
                }), s.jsx(K, {
                    id: "wham.environmentsSelector.retry",
                    defaultMessage: "Failed to load environments"
                })]
            })
        })
    }) : a ? s.jsx(s.Fragment, {
        children: s.jsx("div", {
            className: "z-0 flex w-full justify-between",
            children: j ? s.jsx("div", {
                className: "flex gap-4",
                children: s.jsx(Cs, {
                    onCreateEnvironment: t,
                    showBranchSelector: e != null ? e : !0,
                    allowRepositorySelection: n != null ? n : !0,
                    filters: o != null ? o : null
                })
            }) : s.jsx("div", {
                className: "flex gap-2",
                children: s.jsxs(he, {
                    type: "button",
                    color: "secondary",
                    size: "small",
                    onClick: r,
                    children: [s.jsx(pe, {
                        "aria-hidden": !0,
                        className: "icon-sm me-1.5"
                    }), s.jsx(K, {
                        id: "wham.environmentsSelector.connectGithub",
                        defaultMessage: "Connect GitHub"
                    })]
                })
            })
        })
    }) : s.jsx(de, {
        label: i.formatMessage({
            id: "wham.whamComposerEnvironmentsSelector.disabledByWorkspaceAdmin",
            defaultMessage: "Disabled by workspace admin"
        }),
        children: s.jsxs(he, {
            type: "button",
            color: "secondary",
            onClick: r,
            disabled: !0,
            children: [s.jsx(pe, {
                "aria-hidden": !0,
                className: "icon-sm me-1.5"
            }), s.jsx(K, {
                id: "wham.environmentsSelector.connectGithub",
                defaultMessage: "Connect GitHub"
            })]
        })
    })
}
export {
    Te as C, Hs as W, ne as a, js as g
};
//# sourceMappingURL=lz6fx1tx77vtpv95.js.map