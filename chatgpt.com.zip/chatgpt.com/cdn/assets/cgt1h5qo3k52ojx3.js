import {
    h as Z,
    j as r,
    M as u,
    c as Q,
    r as F,
    e as $,
    d as P
} from "./fg33krlcm0qyi6yw.js";
import {
    d4 as ee,
    d5 as se,
    uM as re,
    wS as ae,
    wT as te,
    wU as ne,
    jm as ie,
    kd as oe,
    J as de,
    l as S,
    a9 as U,
    bg as le,
    T as ue,
    nW as ce,
    m as me,
    C as fe,
    M as L,
    P as B,
    R as ge
} from "./dykg4ktvbu3mhmdo.js";
import {
    rn as K,
    ro as xe,
    rp as pe,
    o2 as he,
    rq as Me,
    jo as ve
} from "./k15yxxoybkkir2ou.js";
var w, O;

function be() {
    if (O) return w;
    O = 1;
    var s = ee(),
        e = se(),
        n = "[object RegExp]";

    function a(t) {
        return e(t) && s(t) == n
    }
    return w = a, w
}
var C, D;

function ye() {
    if (D) return C;
    D = 1;
    var s = be(),
        e = re(),
        n = ae(),
        a = n && n.isRegExp,
        t = a ? e(a) : s;
    return C = t, C
}
var z, G;

function je() {
    if (G) return z;
    G = 1;
    var s = te(),
        e = s("length");
    return z = e, z
}
var q, H;

function Re() {
    if (H) return q;
    H = 1;
    var s = "\\ud800-\\udfff",
        e = "\\u0300-\\u036f",
        n = "\\ufe20-\\ufe2f",
        a = "\\u20d0-\\u20ff",
        t = e + n + a,
        M = "\\ufe0e\\ufe0f",
        f = "[" + s + "]",
        m = "[" + t + "]",
        g = "\\ud83c[\\udffb-\\udfff]",
        x = "(?:" + m + "|" + g + ")",
        v = "[^" + s + "]",
        y = "(?:\\ud83c[\\udde6-\\uddff]){2}",
        b = "[\\ud800-\\udbff][\\udc00-\\udfff]",
        o = "\\u200d",
        d = x + "?",
        c = "[" + M + "]?",
        l = "(?:" + o + "(?:" + [v, y, b].join("|") + ")" + c + d + ")*",
        i = c + d + l,
        j = "(?:" + [v + m + "?", m, y, b, f].join("|") + ")",
        R = RegExp(g + "(?=" + g + ")|" + j + i, "g");

    function p(h) {
        for (var _ = R.lastIndex = 0; R.test(h);) ++_;
        return _
    }
    return q = p, q
}
var E, A;

function Se() {
    if (A) return E;
    A = 1;
    var s = je(),
        e = K(),
        n = Re();

    function a(t) {
        return e(t) ? n(t) : s(t)
    }
    return E = a, E
}
var T, W;

function _e() {
    if (W) return T;
    W = 1;
    var s = ne(),
        e = xe(),
        n = K(),
        a = ie(),
        t = ye(),
        M = Se(),
        f = pe(),
        m = oe(),
        g = de(),
        x = 30,
        v = "...",
        y = /\w*$/;

    function b(o, d) {
        var c = x,
            l = v;
        if (a(d)) {
            var i = "separator" in d ? d.separator : i;
            c = "length" in d ? m(d.length) : c, l = "omission" in d ? s(d.omission) : l
        }
        o = g(o);
        var j = o.length;
        if (n(o)) {
            var R = f(o);
            j = R.length
        }
        if (c >= j) return o;
        var p = c - M(l);
        if (p < 1) return l;
        var h = R ? e(R, 0, p).join("") : o.slice(0, p);
        if (i === void 0) return h + l;
        if (R && (p += h.length - p), t(i)) {
            if (o.slice(p).search(i)) {
                var _, Y = h;
                for (i.global || (i = RegExp(i.source, g(y.exec(i)) + "g")), i.lastIndex = 0; _ = i.exec(Y);) var N = _.index;
                h = h.slice(0, N === void 0 ? p : N)
            }
        } else if (o.indexOf(s(i), p) != p) {
            var I = h.lastIndexOf(i);
            I > -1 && (h = h.slice(0, I))
        }
        return h + l
    }
    return T = b, T
}
var ke = _e();
const Te = Z(ke),
    we = 80,
    k = 100;

function V(s) {
    return s < k ? "bg-token-bg-status-warning text-token-text-status-warning" : "bg-token-bg-status-error text-token-interactive-label-danger-secondary-default"
}

function X(s) {
    return he() && s != null && s > we
}

function Ue({
    memoryFullPct: s,
    className: e,
    children: n,
    showInfoLabel: a,
    onManageMemories: t
}) {
    return X(s) ? r.jsx("div", {
        className: S("border-token-border-default rounded-lg border p-1 text-sm", e),
        children: r.jsxs(le.div, {
            className: S("flex h-7 items-center gap-1 overflow-hidden rounded-sm px-1.5 font-medium whitespace-nowrap", V(s)),
            initial: {
                width: 0
            },
            animate: {
                width: "".concat(s, "%")
            },
            transition: {
                duration: .5
            },
            children: [r.jsx(Me, {
                className: "icon-sm ms-1"
            }), r.jsx(u, {
                id: "6D2etG",
                defaultMessage: "{memoryFullPct}% full",
                values: {
                    memoryFullPct: s
                }
            }), n, a && r.jsx(ue, {
                interactive: !0,
                label: s < k ? r.jsx("div", {
                    className: "whitespace-normal",
                    children: r.jsx(u, {
                        id: "gxY4wi",
                        defaultMessage: "ChatGPT's almost out of space for new saved memories. <memoryModalLink>Manage saved memories</memoryModalLink> to create more space.",
                        values: {
                            memoryModalLink: f => r.jsx("a", {
                                href: "#",
                                className: "cursor-pointer underline",
                                onClick: m => {
                                    m.preventDefault(), t == null || t()
                                },
                                children: f
                            })
                        }
                    })
                }) : r.jsx("div", {
                    className: "whitespace-normal",
                    children: r.jsx(u, {
                        id: "1JxMf3",
                        defaultMessage: "ChatGPT's out of space for saved memories. <memoryModalLink>Manage saved memories</memoryModalLink> to create more space.",
                        values: {
                            memoryModalLink: f => r.jsx("a", {
                                href: "#",
                                className: "cursor-pointer underline",
                                onClick: m => {
                                    m.preventDefault(), t == null || t()
                                },
                                children: f
                            })
                        }
                    })
                }),
                children: r.jsx(ce, {
                    className: "icon-sm ms-1"
                })
            })]
        })
    }) : null
}

function Ne({
    memoryFullPct: s,
    className: e,
    showUpgradeCTA: n = !1,
    isPaid: a = !1,
    onUpgrade: t
}) {
    return X(s) ? r.jsxs("div", {
        className: S("border-token-border-default bg-token-main-surface-primary flex items-center justify-between gap-4 rounded-lg border p-[14px]", e),
        children: [r.jsxs("div", {
            className: "inline-block gap-1",
            children: [r.jsx("div", {
                className: S("mb-1 inline-block rounded-[6px] px-[6px] py-[2px] text-sm font-semibold", V(s != null ? s : 0)),
                children: r.jsx(u, {
                    id: "56hzv4",
                    defaultMessage: "{memoryFullPct}% full",
                    values: {
                        memoryFullPct: s
                    }
                })
            }), r.jsx("div", {
                className: "text-token-text-secondary text-sm",
                children: (s != null ? s : 0) >= k ? a ? r.jsx(u, {
                    id: "HaCKNx",
                    defaultMessage: "New memories can't be saved, so responses may feel less personalized. Delete existing memories to free up space."
                }) : r.jsx(u, {
                    id: "MXPinw",
                    defaultMessage: "New memories can't be saved, so responses may feel less personalized. Upgrade to expand memory, or delete existing memories."
                }) : a ? r.jsx(u, {
                    id: "obgK9b",
                    defaultMessage: "Once memory is full, responses may feel less personalized. Delete existing memories to free up space."
                }) : r.jsx(u, {
                    id: "PDLzFM",
                    defaultMessage: "Once memory is full, responses may feel less personalized. Upgrade to expand memory, or delete existing memories."
                })
            })]
        }), n && !a && r.jsx(U, {
            color: "primary",
            size: "medium",
            onClick: t,
            children: r.jsx(u, {
                id: "1rRvWt",
                defaultMessage: "Upgrade"
            })
        })]
    }) : null
}

function Ie({
    memoryFullPct: s,
    className: e,
    onUpgrade: n
}) {
    const a = (s != null ? s : 0) >= k,
        t = a ? "bg-token-bg-status-error text-token-interactive-label-danger-secondary-default" : "bg-token-bg-status-warning text-token-text-status-warning";
    return r.jsxs("div", {
        className: S("border-token-border-default bg-token-main-surface-primary flex items-center justify-between gap-4 rounded-2xl border p-[14px]", e),
        children: [r.jsxs("div", {
            className: "inline-block gap-1",
            children: [r.jsx("div", {
                className: S("mb-1 inline-block rounded-[6px] px-[6px] py-[2px] text-sm font-semibold", t),
                children: r.jsx(u, {
                    id: "56hzv4",
                    defaultMessage: "{memoryFullPct}% full",
                    values: {
                        memoryFullPct: s
                    }
                })
            }), r.jsx("div", {
                className: "text-token-text-secondary text-xs",
                children: a ? r.jsx(u, {
                    id: "MXPinw",
                    defaultMessage: "New memories can't be saved, so responses may feel less personalized. Upgrade to expand memory, or delete existing memories."
                }) : r.jsx(u, {
                    id: "PDLzFM",
                    defaultMessage: "Once memory is full, responses may feel less personalized. Upgrade to expand memory, or delete existing memories."
                })
            })]
        }), r.jsx(U, {
            color: "primary",
            size: "medium",
            onClick: n,
            children: r.jsx(u, {
                id: "1rRvWt",
                defaultMessage: "Upgrade"
            })
        })]
    })
}

function J({
    description: s,
    onClose: e,
    onConfirm: n
}) {
    const a = $();
    return r.jsx(fe, {
        testId: "modal-confirm-reset-memory",
        isOpen: !0,
        onClose: e,
        type: "success",
        title: a.formatMessage({
            id: "MemoriesModal.resetModalTitle",
            defaultMessage: "Are you sure?"
        }),
        description: s,
        primaryButton: r.jsx(L.Button, {
            title: a.formatMessage({
                id: "MemoriesModal.resetModalConfirm",
                defaultMessage: "Clear memory"
            }),
            color: "danger",
            onClick: n,
            "data-testid": "confirm-reset-memories-button"
        }),
        secondaryButton: r.jsx(L.Button, {
            title: a.formatMessage({
                id: "MemoriesModal.resetModalCancel",
                defaultMessage: "Cancel"
            }),
            color: "secondary",
            onClick: e
        })
    })
}

function Le(s) {
    "use forget";
    const e = Q.c(19),
        {
            onReset: n,
            gizmoId: a,
            memoryName: t,
            contextScopes: M,
            requiredContextScopes: f
        } = s,
        [m, g] = F.useState(!1),
        x = $(),
        v = me(),
        y = ve();
    let b;
    e[0] !== M || e[1] !== a || e[2] !== x || e[3] !== n || e[4] !== f || e[5] !== v ? (b = async () => {
        B.logEvent("Memory Manage Reset Button Confirmed");
        try {
            const j = {
                context_scopes: M,
                required_context_scopes: f
            };
            a && (j.gizmo_id = a), await ge.safeDelete("/settings/clear_account_user_memory", {
                requestBody: j
            }), v.success(x.formatMessage({
                id: "ResetMemoriesButton.resetSuccess",
                defaultMessage: "Memory cleared."
            })), n && n(), g(!1)
        } catch (j) {
            v.danger(P({
                id: "ResetMemoriesButton.resetFailed",
                defaultMessage: "Failed to clear memory."
            }), {
                toastId: "reset_memories_button_reset_failed"
            })
        }
    }, e[0] = M, e[1] = a, e[2] = x, e[3] = n, e[4] = f, e[5] = v, e[6] = b) : b = e[6];
    const o = b;
    let d;
    e[7] === Symbol.for("react.memo_cache_sentinel") ? (d = () => {
        B.logEvent("Memory Manage Reset Button Clicked"), g(!0)
    }, e[7] = d) : d = e[7];
    let c;
    e[8] !== a ? (c = r.jsx(U, {
        color: "danger-outline",
        onClick: d,
        "data-testid": "reset-memories-button",
        children: a ? r.jsx(u, {
            id: "ResetMemoriesButton.resetGizmo",
            defaultMessage: "Clear this GPT's memory"
        }) : r.jsx(u, {
            id: "ResetMemoriesButton.resetChatGPT",
            defaultMessage: "Delete all"
        })
    }), e[8] = a, e[9] = c) : c = e[9];
    let l;
    e[10] !== o || e[11] !== y || e[12] !== x || e[13] !== t || e[14] !== m ? (l = m && (y ? r.jsx(J, {
        description: x.formatMessage({
            id: "MemoriesModal.resetGizmoModalDescriptionUpdated",
            defaultMessage: "Deleting your saved memories means {name} may not remember this information going forward. To fully remove this information from {name}'s memory, please delete any related chats. <link>Learn more</link>"
        }, {
            name: t,
            link: Ce
        }),
        onClose: () => g(!1),
        onConfirm: o
    }) : r.jsx(J, {
        description: x.formatMessage({
            id: "MemoriesModal.resetGizmoModalDescription",
            defaultMessage: "{name} will forget everything it has remembered from your chats. This cannot be undone."
        }, {
            name: t
        }),
        onClose: () => g(!1),
        onConfirm: o
    })), e[10] = o, e[11] = y, e[12] = x, e[13] = t, e[14] = m, e[15] = l) : l = e[15];
    let i;
    return e[16] !== c || e[17] !== l ? (i = r.jsxs(r.Fragment, {
        children: [c, l]
    }), e[16] = c, e[17] = l, e[18] = i) : i = e[18], i
}

function Ce(s) {
    return r.jsx("a", {
        className: "underline",
        href: "https://help.openai.com/en/articles/8983136-what-is-memory",
        children: s
    })
}
export {
    Ne as M, Le as R, Ie as a, Ue as b, Te as t
};
//# sourceMappingURL=cgt1h5qo3k52ojx3.js.map