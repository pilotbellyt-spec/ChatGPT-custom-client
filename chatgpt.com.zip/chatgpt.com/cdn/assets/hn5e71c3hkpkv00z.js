var g = Object.defineProperty,
    k = Object.defineProperties;
var C = Object.getOwnPropertyDescriptors;
var f = Object.getOwnPropertySymbols;
var v = Object.prototype.hasOwnProperty,
    R = Object.prototype.propertyIsEnumerable;
var y = (e, t, r) => t in e ? g(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : e[t] = r,
    x = (e, t) => {
        for (var r in t || (t = {})) v.call(t, r) && y(e, r, t[r]);
        if (f)
            for (var r of f(t)) R.call(t, r) && y(e, r, t[r]);
        return e
    },
    p = (e, t) => k(e, C(t));
var w = (e, t) => {
    var r = {};
    for (var o in e) v.call(e, o) && t.indexOf(o) < 0 && (r[o] = e[o]);
    if (e != null && f)
        for (var o of f(e)) t.indexOf(o) < 0 && R.call(e, o) && (r[o] = e[o]);
    return r
};
import {
    r as n,
    j as s
} from "./fg33krlcm0qyi6yw.js";
import {
    l as c
} from "./dykg4ktvbu3mhmdo.js";
const m = n.createContext({
    rootBordered: !1
});

function H({
    children: e
}) {
    return s.jsx("thead", {
        children: s.jsx("tr", {
            children: e
        })
    })
}

function N({
    textAlign: e = "left",
    children: t,
    className: r = "",
    onClick: o
}) {
    const {
        rootBordered: a
    } = n.useContext(m);
    return s.jsx("th", {
        onClick: o,
        className: c("text-token border-token-border-medium bg-token-main-surface-primary sticky top-0 z-10 border-b-[0.5px] py-2 font-semibold", a ? "px-3" : "pe-4 last:pe-0", e === "left" ? "text-start" : e === "right" ? "text-end" : "text-center", r, {
            "hover:text-token-text-tertiary cursor-pointer": o != null
        }),
        children: t
    })
}

function B(r) {
    var o = r,
        {
            children: e
        } = o,
        t = w(o, ["children"]);
    return s.jsx("tbody", p(x({}, t), {
        children: e
    }))
}
const z = n.forwardRef(function({
    children: t,
    disabled: r = !1,
    onClick: o,
    className: a,
    tabIndex: i,
    ariaLabel: l,
    role: d
}, u) {
    return s.jsx("tr", p(x({
        tabIndex: i,
        ref: u
    }, r ? {
        "data-disabled": !0
    } : {}), {
        className: c(r ? "pointer-events-none" : "", o ? "hover:bg-token-interactive-bg-tertiary-hover cursor-pointer" : "", a),
        onClick: o,
        "aria-label": l,
        role: d,
        children: t
    }))
});

function E({
    textAlign: e = "left",
    verticalAlign: t = "top",
    children: r,
    className: o,
    divClassName: a = "min-h-[40px] items-center",
    colSpan: i,
    wrap: l = !1
}) {
    const {
        rootBordered: d
    } = n.useContext(m);
    return s.jsx("td", {
        className: c("border-token-border-medium border-b-[0.5px]", t === "top" ? "align-top" : t === "bottom" ? "align-bottom" : "align-middle", d ? "px-3" : "pe-4 last:pe-0 [tr:last-child_&]:border-b-0", e && "text-" + e, o),
        colSpan: i,
        style: l ? {
            overflowWrap: "anywhere"
        } : void 0,
        children: s.jsx("div", {
            className: c("flex [tr[data-disabled=true]_&]:opacity-50", e === "right" && "justify-end", e === "center" && "justify-center", a),
            children: r
        })
    })
}

function S({
    children: e
}) {
    return s.jsx("div", {
        className: "text-md flex items-center justify-end gap-2",
        children: e
    })
}

function O({
    children: e,
    fixed: t = !1,
    className: r,
    size: o = "normal",
    bordered: a = !1,
    disableScroll: i = !1
}) {
    const l = n.useRef(null),
        d = n.useRef(null),
        [u, T] = n.useState(!1);
    return n.useEffect(() => {
        const b = l.current,
            h = d.current;
        if (b && h) {
            const j = new ResizeObserver(() => {
                T(h.scrollHeight > b.clientHeight)
            });
            return j.observe(b), () => j.disconnect()
        }
    }, []), s.jsx(m.Provider, {
        value: {
            rootBordered: a
        },
        children: s.jsx("div", {
            className: c("text-token-text-primary", !i && "overflow-y-auto", a && "border-token-border-default rounded-lg border", o === "normal" ? "text-base" : "text-sm", u && "pe-1", r),
            ref: l,
            children: s.jsx("table", {
                className: c("w-full border-separate border-spacing-0", t && "table-fixed"),
                ref: d,
                children: e
            })
        })
    })
}
const q = {
    Root: O,
    Header: H,
    HeaderCell: N,
    Body: B,
    Row: z,
    Cell: E,
    Actions: S
};
export {
    q as T
};
//# sourceMappingURL=hn5e71c3hkpkv00z.js.map