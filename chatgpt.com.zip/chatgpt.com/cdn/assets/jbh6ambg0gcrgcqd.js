import {
    l as e
} from "./dykg4ktvbu3mhmdo.js";
const s = "text-token-text-secondary inline-flex items-center rounded-full bg-[#f4f4f4] select-none dark:bg-token-main-surface-secondary",
    l = e(s, " h-[22px] px-2 text-[0.5em] font-medium"),
    a = e(s, "h-[25px] px-3 text-xs");
e(s, "h-[32px] px-4 text-sm");
export {
    a as l, l as s
};
//# sourceMappingURL=jbh6ambg0gcrgcqd.js.map