var D = Object.defineProperty,
    k = Object.defineProperties;
var O = Object.getOwnPropertyDescriptors;
var I = Object.getOwnPropertySymbols;
var $ = Object.prototype.hasOwnProperty,
    N = Object.prototype.propertyIsEnumerable;
var T = (e, t, r) => t in e ? D(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : e[t] = r,
    _ = (e, t) => {
        for (var r in t || (t = {})) $.call(t, r) && T(e, r, t[r]);
        if (I)
            for (var r of I(t)) N.call(t, r) && T(e, r, t[r]);
        return e
    },
    w = (e, t) => k(e, O(t));
var f = (e, t, r) => T(e, typeof t != "symbol" ? t + "" : t, r);
import {
    r as R,
    b as j,
    q as Q,
    j as z
} from "./fg33krlcm0qyi6yw.js";
import {
    ak as x,
    pH as U
} from "./k15yxxoybkkir2ou.js";
import {
    eM as h,
    wu as d,
    de as V,
    jW as S,
    fz as b,
    df as W,
    fe as P,
    _ as L,
    gH as X,
    ku as Y,
    bg as J
} from "./dykg4ktvbu3mhmdo.js";
const C = {
    width: 1,
    height: 1
};

function Ee(e, t, r = C) {
    if (!e || !t) return null;
    const {
        width: n,
        height: s
    } = t;
    if (n === 0 || s === 0) return null;
    const o = n / s,
        a = r.width / r.height;
    if (Math.abs(o - a) < 1e-6) return null;
    let i = 50,
        l = 50;
    const {
        center_x_percent: c,
        center_y_percent: m
    } = e;
    if (o > a) {
        const g = o - a;
        i = (c * o - a / 2) / g * 100, i = Math.max(0, Math.min(100, i))
    } else {
        const g = 1 / o,
            E = 1 / a,
            v = g - E;
        l = (m * g - E / 2) / v * 100, l = Math.max(0, Math.min(100, l))
    }
    return "".concat(i.toFixed(1), "% ").concat(l.toFixed(1), "%")
}
var M = (e => (e.SCALLION = "scallion", e.SCALLION_RC = "scallion-rc", e.SCALLION_RC0 = "scallion-rc0", e.SCALLION_RC1 = "scallion-rc1", e.SCALLION_RC2 = "scallion-rc2", e.CHIVE = "chive", e.CHIVE_RC = "chive-rc", e.CHIVE_RC0 = "chive-rc0", e.CHIVE_RC1 = "chive-rc1", e))(M || {});
const Te = async ({
    queryKey: e
}) => {
    const [t, r] = e;
    if (r.length < 2) return [];
    const n = new URLSearchParams({
        query_fragment: r
    });
    return h.get("".concat(d, "/suggestions?").concat(n.toString())).then(s => s.suggestions).catch(() => [])
};

function K(e) {
    var t;
    return {
        settings_overrides: {
            search_results: {
                search_engines: e.use_labrador ? {
                    bing: {}
                } : {
                    bing: {
                        ranking_model: null,
                        rrf_alpha: 1,
                        rrf_input_threshold: 0
                    },
                    labrador: null
                }
            },
            model_response: {
                enable_multimodal: e.show_image_to_model,
                completion_model: e.completion_model && e.completion_model !== "production" ? {
                    model: e.completion_model,
                    clip_model: "@mmapi",
                    direct_connection_urls: []
                } : {}
            }
        },
        base_config: (t = e.base_config) != null ? t : M.SCALLION,
        eval_preset: e.eval_preset
    }
}
async function we({
    threadId: e,
    threadUserId: t,
    routePrefix: r
}) {
    let n = d;
    r && (n = n + r);
    const s = new URL("".concat(n, "/threads/").concat(e, "/with_turns"));
    return t && s.searchParams.append("thread_user_id", t), await h.get(s.toString())
}
async function ye(e) {
    const t = new FormData;
    return t.append("feedback", JSON.stringify({
        thread_id: e.threadId,
        turn_index: e.turnIndex,
        rating: e.rating,
        search_query: e.searchQuery,
        text: e.text,
        model_instructions: e.modelInstructions,
        tags: e.tags,
        user_email: e.userEmail
    })), e.screenshot && t.append("file", new File([e.screenshot], "screenshot.jpeg", {
        type: "image/jpeg"
    })), h.post("".concat(d, "/feedback/turns"), t)
}
async function G(e, t) {
    return h.post("".concat(d, "/threads/").concat(e, "/turns/").concat(t, "/images_try_hard"))
}
async function Re(e) {
    const t = new FormData;
    return e.screenshot && t.append("file", new File([e.screenshot], "screenshot.jpeg", {
        type: "image/jpeg"
    })), t.append("feedback", JSON.stringify({
        thread_id: e.threadId,
        url: e.url,
        title: e.title,
        snippet: e.snippet,
        rating: e.rating,
        search_query: e.searchQuery,
        text: e.text,
        tags: e.tags,
        user_email: e.userEmail,
        turn_index: e.turnIndex
    })), h.post("".concat(d, "/feedback/links"), t)
}

function Ie(e) {
    const t = K(e.agentSettingsOverrides);
    h.post("".concat(d, "/prefetch"), w(_({}, t), {
        turn: {
            user_query: e.query
        },
        user_metadata: e.metadata
    }))
}
class q extends Error {
    constructor(t) {
        super(t), this.name = "TurnError"
    }
}

function Z(e) {
    var t;
    return e ? ((t = e.model_response) == null ? void 0 : t.text) != null && e.model_response.text.length > 0 : !1
}

function y(e) {
    return e.execution_status === "fatal_system_error"
}

function B(e) {
    return e.execution_status === "in_progress" || e.execution_status === null
}

function ee(e) {
    return u(t => {
        var r, n;
        return (n = (r = t.thread) == null ? void 0 : r.turns.map(s => e.reduce((o, a) => (o[a] = s[a], o), {}))) != null ? n : []
    }, (t, r) => {
        if (t.length !== r.length) return !1;
        for (let n = 0; n < t.length; n++)
            if (!b(t[n], r[n])) return !1;
        return !0
    })
}

function te() {
    return u(e => {
        var t;
        return S((t = e.thread) == null ? void 0 : t.turns.flatMap(r => {
            var n;
            return (n = r.model_response) == null ? void 0 : n.citations
        }))
    }, b)
}
const A = {
        thread: null,
        error: void 0
    },
    u = V(W(() => _({}, A))),
    re = P(() => {
        L.addError(new q("got updateTurn with no current thread"))
    }, 1e3),
    ne = P(e => {
        L.addError(new q("turn not found"), {
            turnIndex: e
        })
    }, 1e3),
    p = {
        threadId: e => {
            var t, r;
            return (r = (t = e.thread) == null ? void 0 : t.id) != null ? r : null
        },
        turns: e => {
            var t, r;
            return (r = (t = e.thread) == null ? void 0 : t.turns) != null ? r : []
        },
        turnCitations: e => t => {
            var r, n, s;
            return (s = (n = (r = t.thread) == null ? void 0 : r.turns[e].model_response) == null ? void 0 : n.citations) != null ? s : []
        },
        hasResponse: e => {
            var t;
            return Z((t = e.thread) == null ? void 0 : t.turns[0])
        },
        firstTurn: e => e.thread != null ? e.thread.turns[0] : void 0,
        lastTurn: e => e.thread != null ? e.thread.turns[e.thread.turns.length - 1] : void 0,
        numTurns: e => {
            var t, r;
            return (r = (t = e.thread) == null ? void 0 : t.turns.length) != null ? r : 0
        },
        isLastTurnStreaming: e => {
            const t = e.thread != null ? e.thread.turns[e.thread.turns.length - 1] : void 0;
            return t != null && B(t)
        },
        hasModelResponseText: e => {
            var r, n;
            const t = (r = e.thread) == null ? void 0 : r.turns[0];
            return ((n = t == null ? void 0 : t.model_response) == null ? void 0 : n.text) != null
        },
        hasFirstTurnError: e => {
            var r;
            const t = (r = e.thread) == null ? void 0 : r.turns[0];
            return !!t && y(t)
        },
        hasTurnError: e => {
            var t, r;
            return (r = (t = e.thread) == null ? void 0 : t.turns.some(y)) != null ? r : !1
        },
        threadError: e => e.error,
        __deprecated_sportsWidget: e => {
            var r, n;
            const t = (r = e.thread) == null ? void 0 : r.turns[0];
            return (n = t == null ? void 0 : t.sports_widget) != null ? n : null
        }
    },
    xe = {
        appendTurn(e, t, r) {
            u.setState(n => {
                var s;
                ((s = n.thread) == null ? void 0 : s.id) !== e && (r == null || r(e), n.thread = {
                    id: e,
                    turns: []
                }), n.thread.turns.push(t)
            })
        },
        updateTurn(e, t) {
            u.setState(r => {
                const n = r.thread;
                if (!n) {
                    re();
                    return
                }
                const s = n.turns[e];
                if (!s) {
                    ne(e);
                    return
                }
                t(s)
            })
        },
        clearThread() {
            u.setState(() => _({}, A))
        },
        setError(e) {
            u.setState(t => {
                t.error = e
            })
        },
        setThread(e, t) {
            u.setState(r => {
                r.thread = {
                    id: e,
                    turns: t
                }
            })
        }
    };
class se {
    constructor() {
        f(this, "queue", []);
        f(this, "attempted", new Set);
        f(this, "isProcessing", !1)
    }
    enqueue(t) {
        this.queue.push(t), this._processQueue()
    }
    async _processQueue() {
        if (!this.isProcessing) {
            for (this.isProcessing = !0; this.queue.length > 0;) try {
                const t = this.queue.shift();
                if (!t) continue;
                await this._preload(t)
            } catch (t) {}
            this.isProcessing = !1
        }
    }
    _preload(t) {
        return new Promise(r => {
            this.attempted.has(t) && r();
            const n = new Image;
            n.onload = () => {
                this.attempted.add(t), r()
            }, n.onerror = () => {
                this.attempted.add(t), r()
            }, n.src = t
        })
    }
}
const oe = new se;

function ae(e) {
    const t = R.useRef(e);
    return X(t.current, e) || (t.current = e), t.current
}

function ie(e, {
    enabled: t = !0
} = {}) {
    const r = ae(e);
    R.useEffect(() => {
        if (!t || "connection" in navigator && navigator.connection.type === "cellular") return;
        const s = setTimeout(() => {
            r.forEach(o => {
                o && oe.enqueue(o)
            })
        }, 1e3);
        return () => {
            clearTimeout(s)
        }
    }, [t, r])
}

function Se() {
    const {
        imageResults: e
    } = ce();
    ie([...e.map(t => F(t))])
}
const ue = Y((...e) => G(...e), 5e3);

function ce(e = !1) {
    var i, l;
    const t = ee(["image_results", "image_try_hard_status", "execution_status"]),
        r = u(p.threadId),
        n = S(t.toReversed().flatMap(c => {
            var m;
            return (m = c.image_results) == null ? void 0 : m.entries
        })).map(c => w(_({}, c), {
            thumbnail_url: c.thumbnail_url.replace(/^http:\/\//, "https://"),
            content_url: c.content_url.replace(/^http:\/\//, "https://")
        })),
        s = u(p.hasModelResponseText),
        o = t.some(c => y(c));
    let a = n.length === 0 && !s;
    return r != null && e && !a && n.length === 0 && ((i = t[0]) == null ? void 0 : i.image_try_hard_status) === "not_attempted" && (ue(r, 0), a = !0), e && ((l = t[0]) == null ? void 0 : l.image_try_hard_status) === "in_progress" && (a = !0), {
        imageResults: n,
        isLoading: a,
        isErrored: n.length === 0 && o
    }
}

function be() {
    const e = te(),
        t = u(p.hasTurnError),
        r = u(p.hasModelResponseText),
        n = U(e);
    return {
        imageResults: n,
        isLoading: n.length === 0 && !r,
        isErrored: n.length === 0 && t
    }
}

function le(e, t) {
    return Q({
        queryKey: ["downloadImage", {
            imageUrl: e,
            downloadType: t
        }],
        queryFn: () => new Promise((r, n) => {
            if (!e) {
                n();
                return
            }
            const s = performance.now(),
                o = new Image;
            o.onload = () => {
                x.logEvent("Search Tool Image Download Latency", {
                    type: t,
                    image_url: e,
                    latency_ms: Math.round(performance.now() - s),
                    error: !1
                }), r({
                    width: o.width,
                    height: o.height
                })
            }, o.onerror = () => {
                x.logEvent("Search Tool Image Download Latency", {
                    type: t,
                    image_url: e,
                    latency_ms: Math.round(performance.now() - s),
                    error: !0
                }), n()
            }, o.src = e
        }),
        enabled: !!e
    })
}

function Pe(e, t) {
    return j(le(e, t))
}
const he = 474,
    H = {
        width: he,
        aspectRatio: C
    };

function F(e, t = H) {
    if (e == null || e.is_proxied_image) return;
    const r = new URL(e.thumbnail_url);
    if (r.hostname.indexOf(".bing.") === -1) return e.thumbnail_url;
    const {
        width: n,
        height: s,
        aspectRatio: o
    } = t;
    let a = Math.min(n, e.content_size.width),
        i = s != null ? s : Math.floor(o ? a * (o.height / o.width) : a * e.content_size.height / e.content_size.width);
    return !s && o && o.width === o.height && (a = i = Math.min(a, i)), r.searchParams.delete("pid"), r.searchParams.set("w", a.toString()), r.searchParams.set("h", i.toString()), r.searchParams.set("c", "7"), r.searchParams.set("p", "0"), r.toString()
}

function Le(e, t = H) {
    return R.useMemo(() => F(e, t), [e, t])
}
const de = {
    type: "spring",
    stiffness: 700,
    damping: 82
};

function Ce({
    children: e,
    className: t
}) {
    return z.jsx(J.div, {
        animate: {
            opacity: 1
        },
        initial: {
            width: "100%",
            height: "100%",
            translateX: 0,
            translateY: 0,
            opacity: 0
        },
        whileHover: {
            width: "103%",
            height: "103%",
            translateX: "-1.5%",
            translateY: "-1.5%"
        },
        transition: de,
        className: t,
        children: e
    })
}
export {
    C as A, M as B, he as D, Ce as I, p as T, ce as a, Pe as b, u as c, y as d, Re as e, Te as f, le as g, ee as h, B as i, Se as j, xe as k, we as l, Le as m, de as n, Ee as o, ye as p, Ie as r, be as u
};
//# sourceMappingURL=k57uzqpnr7k7r909.js.map