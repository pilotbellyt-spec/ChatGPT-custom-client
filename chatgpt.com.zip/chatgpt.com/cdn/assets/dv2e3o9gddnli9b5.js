var mt = Object.freeze,
    gt = Object.defineProperty,
    Bt = Object.defineProperties;
var Ut = Object.getOwnPropertyDescriptors;
var xt = Object.getOwnPropertySymbols;
var Ht = Object.prototype.hasOwnProperty,
    Qt = Object.prototype.propertyIsEnumerable;
var pt = (t, e, n) => e in t ? gt(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : t[e] = n,
    B = (t, e) => {
        for (var n in e || (e = {})) Ht.call(e, n) && pt(t, n, e[n]);
        if (xt)
            for (var n of xt(e)) Qt.call(e, n) && pt(t, n, e[n]);
        return t
    },
    Y = (t, e) => Bt(t, Ut(e));
var W = (t, e) => mt(gt(t, "raw", {
    value: mt(e || t.slice())
}));
import {
    r4 as at,
    jW as Yt,
    F as Dt,
    iU as Wt,
    P as ft,
    bg as Gt,
    T as Zt
} from "./dykg4ktvbu3mhmdo.js";
import {
    c5 as Mt,
    gn as Nt,
    hd as Xt,
    dU as Jt,
    n6 as Kt,
    pI as te,
    zs as ee
} from "./k15yxxoybkkir2ou.js";
import {
    r as It,
    j as M,
    M as ne
} from "./fg33krlcm0qyi6yw.js";
import {
    m as ie,
    b as re,
    n as ae
} from "./k57uzqpnr7k7r909.js";
import {
    c as Ot,
    j as G,
    f as O,
    m as R,
    l as U,
    b as $t,
    i as P
} from "./nfccle6oyncifphl.js";
import {
    c as vt
} from "./b5s349mvbdzayaxi.js";
import {
    o as j
} from "./gy1lpvuoewmzh42c.js";
import {
    a as bt
} from "./hu1bt0oauegdhua6.js";
import {
    l as ue
} from "./dbshkzvpochy4889.js";
const Rn = () => t => {
        Mt(t, e => {
            var s, x;
            if (!Nt(e) || e.name !== at) return;
            const n = (s = e.data) != null ? s : e.data = {},
                r = (x = e.attributes) == null ? void 0 : x.index;
            if (r == null) return;
            n.hName = at, n.hProperties = {
                index: r
            };
            let a = "inline";
            switch (e.type) {
                case "textDirective":
                    a = "inline";
                    break;
                case "leafDirective":
                    a = "block";
                    break;
                case "containerDirective":
                    a = "container";
                    break
            }
            n.hProperties.displayLayout = a
        })
    },
    dt = "contextList";

function jn() {
    return t => {
        Mt(t, e => {
            var r;
            if (!Nt(e) || e.name !== dt) return;
            const n = (r = e.data) != null ? r : e.data = {};
            n.hName = dt
        })
    }
}

function le(t) {
    var n;
    if (typeof t != "object" || t == null || !("props" in t) || t.props == null) return;
    const e = t.props;
    if (((n = e.node) == null ? void 0 : n.tagName) === at) return parseInt(e.index)
}
var zt;
const Ct = Dt.div(zt || (zt = W(["gap-6 border-b pb-4 my-4 context-list border-token-border-default"])));

function _n({
    children: t
}) {
    var x;
    const e = It.useContext(Xt),
        n = Array.isArray(t) ? t : Yt([t]);
    if (n.length === 0 || (e == null ? void 0 : e.analyticsMetadata.turnIndex) === void 0) return null;
    const [r, ...a] = n, s = le(r);
    if (s != null && e != null) {
        const h = (x = e == null ? void 0 : e.contentReferences) == null ? void 0 : x[s],
            c = (h == null ? void 0 : h.type) === "image_v2",
            g = (h == null ? void 0 : h.type) === "optimistic_image_citation";
        if (c || g) return M.jsxs(Ct, {
            className: "flex w-full",
            children: [M.jsx("div", {
                className: "grow leading-normal",
                children: a
            }), M.jsxs("div", {
                className: "mt-2 flex w-24 shrink-0",
                children: [c && h.images[0] && M.jsx(se, {
                    imageRef: h,
                    analyticsMetadata: e.analyticsMetadata
                }), g && M.jsx(oe, {
                    optimisticRef: h
                })]
            })]
        })
    }
    return M.jsx(Ct, {
        className: "leading-normal",
        children: n
    })
}
var qt;
const Pt = Dt.button(qt || (qt = W(["not-prose flex w-full h-fit	items-center justify-center overflow-hidden rounded-lg max-h-48"])));

function se({
    imageRef: t,
    analyticsMetadata: e
}) {
    const n = t.images[0],
        r = n.thumbnail_size.width / n.thumbnail_size.height,
        a = ie(n, {
            width: 200,
            height: Math.max(Math.round(200 / r), 112)
        }),
        {
            isSuccess: s
        } = re(a, "ContextListImage"),
        x = Jt.useStore(),
        h = It.useRef(!1),
        c = Y(B({}, Wt(e)), {
            type: "context_list_image_thumbnail",
            image_url: a
        });
    return h.current || (h.current = !0, ft.logEventWithStatsig("Search Content Reference Shown", "search_content_reference_shown", c)), M.jsx(Pt, {
        onClick: () => {
            x.setCurrentImage({
                image: n,
                source: Kt.Turn,
                analyticsMetadata: e
            }), ft.logEventWithStatsig("Search Content Reference Clicked", "search_content_reference_clicked", c)
        },
        children: M.jsx(Gt.img, {
            src: a,
            className: "w-full object-cover",
            alt: n.title,
            initial: {
                opacity: 0
            },
            animate: s ? {
                opacity: 1
            } : {},
            whileHover: {
                scale: 1.1,
                transition: ae
            }
        })
    })
}

function oe({
    optimisticRef: t
}) {
    return M.jsx(Pt, {
        children: t.status === "done" ? M.jsx(Zt, {
            label: M.jsx(ne, {
                id: "8JYwCi",
                defaultMessage: "Error fetching image"
            }),
            children: M.jsx(te, {
                className: "text-token-text-tertiary h-24 w-12"
            })
        }) : M.jsx("div", {
            className: "bg-token-main-surface-tertiary h-24 w-full animate-pulse"
        })
    })
}
const Rt = ["AElig", "AMP", "Aacute", "Acirc", "Agrave", "Aring", "Atilde", "Auml", "COPY", "Ccedil", "ETH", "Eacute", "Ecirc", "Egrave", "Euml", "GT", "Iacute", "Icirc", "Igrave", "Iuml", "LT", "Ntilde", "Oacute", "Ocirc", "Ograve", "Oslash", "Otilde", "Ouml", "QUOT", "REG", "THORN", "Uacute", "Ucirc", "Ugrave", "Uuml", "Yacute", "aacute", "acirc", "acute", "aelig", "agrave", "amp", "aring", "atilde", "auml", "brvbar", "ccedil", "cedil", "cent", "copy", "curren", "deg", "divide", "eacute", "ecirc", "egrave", "eth", "euml", "frac12", "frac14", "frac34", "gt", "iacute", "icirc", "iexcl", "igrave", "iquest", "iuml", "laquo", "lt", "macr", "micro", "middot", "nbsp", "not", "ntilde", "oacute", "ocirc", "ograve", "ordf", "ordm", "oslash", "otilde", "ouml", "para", "plusmn", "pound", "quot", "raquo", "reg", "sect", "shy", "sup1", "sup2", "sup3", "szlig", "thorn", "times", "uacute", "ucirc", "ugrave", "uml", "uuml", "yacute", "yen", "yuml"],
    St = {
        0: "�",
        128: "€",
        130: "‚",
        131: "ƒ",
        132: "„",
        133: "…",
        134: "†",
        135: "‡",
        136: "ˆ",
        137: "‰",
        138: "Š",
        139: "‹",
        140: "Œ",
        142: "Ž",
        145: "‘",
        146: "’",
        147: "“",
        148: "”",
        149: "•",
        150: "–",
        151: "—",
        152: "˜",
        153: "™",
        154: "š",
        155: "›",
        156: "œ",
        158: "ž",
        159: "Ÿ"
    };

function jt(t) {
    const e = typeof t == "string" ? t.charCodeAt(0) : t;
    return e >= 48 && e <= 57
}

function ce(t) {
    const e = typeof t == "string" ? t.charCodeAt(0) : t;
    return e >= 97 && e <= 102 || e >= 65 && e <= 70 || e >= 48 && e <= 57
}

function he(t) {
    const e = typeof t == "string" ? t.charCodeAt(0) : t;
    return e >= 97 && e <= 122 || e >= 65 && e <= 90
}

function wt(t) {
    return he(t) || jt(t)
}
const V = String.fromCharCode,
    me = ["", "Named character references must be terminated by a semicolon", "Numeric character references must be terminated by a semicolon", "Named character references cannot be empty", "Numeric character references cannot be empty", "Named character references must be known", "Numeric character references cannot be disallowed", "Numeric character references cannot be outside the permissible Unicode range"];

function lt(t, e = {}) {
    const n = typeof e.additional == "string" ? e.additional.charCodeAt(0) : e.additional,
        r = [];
    let a = 0,
        s = -1,
        x = "",
        h, c;
    e.position && ("start" in e.position || "indent" in e.position ? (c = e.position.indent, h = e.position.start) : h = e.position);
    let g = (h ? h.line : 0) || 1,
        p = (h ? h.column : 0) || 1,
        v = l(),
        m;
    for (a--; ++a <= t.length;)
        if (m === 10 && (p = (c ? c[s] : 0) || 1), m = t.charCodeAt(a), m === 38) {
            const i = t.charCodeAt(a + 1);
            if (i === 9 || i === 10 || i === 12 || i === 32 || i === 38 || i === 60 || Number.isNaN(i) || n && i === n) {
                x += V(m), p++;
                continue
            }
            const k = a + 1;
            let A = k,
                w = k,
                F;
            if (i === 35) {
                w = ++A;
                const S = t.charCodeAt(w);
                S === 88 || S === 120 ? (F = "hexadecimal", w = ++A) : F = "decimal"
            } else F = "named";
            let y = "",
                L = "",
                o = "";
            const T = F === "named" ? wt : F === "decimal" ? jt : ce;
            for (w--; ++w <= t.length;) {
                const S = t.charCodeAt(w);
                if (!T(S)) break;
                o += V(S), F === "named" && Rt.includes(o) && (y = o, L = bt(o))
            }
            let N = t.charCodeAt(w) === 59;
            if (N) {
                w++;
                const S = F === "named" ? bt(o) : !1;
                S && (y = o, L = S)
            }
            let z = 1 + w - k,
                D = "";
            if (!(!N && e.nonTerminated === !1))
                if (!o) F !== "named" && b(4, z);
                else if (F === "named") {
                if (N && !L) b(5, 1);
                else if (y !== o && (w = A + y.length, z = 1 + w - A, N = !1), !N) {
                    const S = y ? 1 : 3;
                    if (e.attribute) {
                        const I = t.charCodeAt(w);
                        I === 61 ? (b(S, z), L = "") : wt(I) ? L = "" : b(S, z)
                    } else b(S, z)
                }
                D = L
            } else {
                N || b(2, z);
                let S = Number.parseInt(o, F === "hexadecimal" ? 16 : 10);
                if (xe(S)) b(7, z), D = V(65533);
                else if (S in St) b(6, z), D = St[S];
                else {
                    let I = "";
                    pe(S) && b(6, z), S > 65535 && (S -= 65536, I += V(S >>> 10 | 55296), S = 56320 | S & 1023), D = I + V(S)
                }
            }
            if (D) {
                C(), v = l(), a = w - 1, p += w - k + 1, r.push(D);
                const S = l();
                S.offset++, e.reference && e.reference.call(e.referenceContext, D, {
                    start: v,
                    end: S
                }, t.slice(k - 1, w)), v = S
            } else o = t.slice(k - 1, w), x += o, p += o.length, a = w - 1
        } else m === 10 && (g++, s++, p = 0), Number.isNaN(m) ? C() : (x += V(m), p++);
    return r.join("");

    function l() {
        return {
            line: g,
            column: p,
            offset: a + ((h ? h.offset : 0) || 0)
        }
    }

    function b(i, k) {
        let A;
        e.warning && (A = l(), A.column += k, A.offset += k, e.warning.call(e.warningContext, me[i], A, i))
    }

    function C() {
        x && (r.push(x), e.text && e.text.call(e.textContext, x, {
            start: v,
            end: l()
        }), x = "")
    }
}

function xe(t) {
    return t >= 55296 && t <= 57343 || t > 1114111
}

function pe(t) {
    return t >= 1 && t <= 8 || t === 11 || t >= 13 && t <= 31 || t >= 127 && t <= 159 || t >= 64976 && t <= 65007 || (t & 65535) === 65535 || (t & 65535) === 65534
}
const ge = /["&'<>`]/g,
    fe = /[\uD800-\uDBFF][\uDC00-\uDFFF]/g,
    ve = /[\x01-\t\v\f\x0E-\x1F\x7F\x81\x8D\x8F\x90\x9D\xA0-\uFFFF]/g,
    be = /[|\\{}()[\]^$+*?.]/g,
    At = new WeakMap;

function _t(t, e) {
    if (t = t.replace(e.subset ? de(e.subset) : ge, r), e.subset || e.escapeOnly) return t;
    return t.replace(fe, n).replace(ve, r);

    function n(a, s, x) {
        return e.format((a.charCodeAt(0) - 55296) * 1024 + a.charCodeAt(1) - 56320 + 65536, x.charCodeAt(s + 2), e)
    }

    function r(a, s, x) {
        return e.format(a.charCodeAt(0), x.charCodeAt(s + 1), e)
    }
}

function de(t) {
    let e = At.get(t);
    return e || (e = Ce(t), At.set(t, e)), e
}

function Ce(t) {
    const e = [];
    let n = -1;
    for (; ++n < t.length;) e.push(t[n].replace(be, "\\$&"));
    return new RegExp("(?:" + e.join("|") + ")", "g")
}
const Se = /[\dA-Fa-f]/;

function we(t, e, n) {
    const r = "&#x" + t.toString(16).toUpperCase();
    return n && e && !Se.test(String.fromCharCode(e)) ? r : r + ";"
}
const Ae = /\d/;

function ke(t, e, n) {
    const r = "&#" + String(t);
    return n && e && !Ae.test(String.fromCharCode(e)) ? r : r + ";"
}
const Z = {
        nbsp: " ",
        iexcl: "¡",
        cent: "¢",
        pound: "£",
        curren: "¤",
        yen: "¥",
        brvbar: "¦",
        sect: "§",
        uml: "¨",
        copy: "©",
        ordf: "ª",
        laquo: "«",
        not: "¬",
        shy: "­",
        reg: "®",
        macr: "¯",
        deg: "°",
        plusmn: "±",
        sup2: "²",
        sup3: "³",
        acute: "´",
        micro: "µ",
        para: "¶",
        middot: "·",
        cedil: "¸",
        sup1: "¹",
        ordm: "º",
        raquo: "»",
        frac14: "¼",
        frac12: "½",
        frac34: "¾",
        iquest: "¿",
        Agrave: "À",
        Aacute: "Á",
        Acirc: "Â",
        Atilde: "Ã",
        Auml: "Ä",
        Aring: "Å",
        AElig: "Æ",
        Ccedil: "Ç",
        Egrave: "È",
        Eacute: "É",
        Ecirc: "Ê",
        Euml: "Ë",
        Igrave: "Ì",
        Iacute: "Í",
        Icirc: "Î",
        Iuml: "Ï",
        ETH: "Ð",
        Ntilde: "Ñ",
        Ograve: "Ò",
        Oacute: "Ó",
        Ocirc: "Ô",
        Otilde: "Õ",
        Ouml: "Ö",
        times: "×",
        Oslash: "Ø",
        Ugrave: "Ù",
        Uacute: "Ú",
        Ucirc: "Û",
        Uuml: "Ü",
        Yacute: "Ý",
        THORN: "Þ",
        szlig: "ß",
        agrave: "à",
        aacute: "á",
        acirc: "â",
        atilde: "ã",
        auml: "ä",
        aring: "å",
        aelig: "æ",
        ccedil: "ç",
        egrave: "è",
        eacute: "é",
        ecirc: "ê",
        euml: "ë",
        igrave: "ì",
        iacute: "í",
        icirc: "î",
        iuml: "ï",
        eth: "ð",
        ntilde: "ñ",
        ograve: "ò",
        oacute: "ó",
        ocirc: "ô",
        otilde: "õ",
        ouml: "ö",
        divide: "÷",
        oslash: "ø",
        ugrave: "ù",
        uacute: "ú",
        ucirc: "û",
        uuml: "ü",
        yacute: "ý",
        thorn: "þ",
        yuml: "ÿ",
        fnof: "ƒ",
        Alpha: "Α",
        Beta: "Β",
        Gamma: "Γ",
        Delta: "Δ",
        Epsilon: "Ε",
        Zeta: "Ζ",
        Eta: "Η",
        Theta: "Θ",
        Iota: "Ι",
        Kappa: "Κ",
        Lambda: "Λ",
        Mu: "Μ",
        Nu: "Ν",
        Xi: "Ξ",
        Omicron: "Ο",
        Pi: "Π",
        Rho: "Ρ",
        Sigma: "Σ",
        Tau: "Τ",
        Upsilon: "Υ",
        Phi: "Φ",
        Chi: "Χ",
        Psi: "Ψ",
        Omega: "Ω",
        alpha: "α",
        beta: "β",
        gamma: "γ",
        delta: "δ",
        epsilon: "ε",
        zeta: "ζ",
        eta: "η",
        theta: "θ",
        iota: "ι",
        kappa: "κ",
        lambda: "λ",
        mu: "μ",
        nu: "ν",
        xi: "ξ",
        omicron: "ο",
        pi: "π",
        rho: "ρ",
        sigmaf: "ς",
        sigma: "σ",
        tau: "τ",
        upsilon: "υ",
        phi: "φ",
        chi: "χ",
        psi: "ψ",
        omega: "ω",
        thetasym: "ϑ",
        upsih: "ϒ",
        piv: "ϖ",
        bull: "•",
        hellip: "…",
        prime: "′",
        Prime: "″",
        oline: "‾",
        frasl: "⁄",
        weierp: "℘",
        image: "ℑ",
        real: "ℜ",
        trade: "™",
        alefsym: "ℵ",
        larr: "←",
        uarr: "↑",
        rarr: "→",
        darr: "↓",
        harr: "↔",
        crarr: "↵",
        lArr: "⇐",
        uArr: "⇑",
        rArr: "⇒",
        dArr: "⇓",
        hArr: "⇔",
        forall: "∀",
        part: "∂",
        exist: "∃",
        empty: "∅",
        nabla: "∇",
        isin: "∈",
        notin: "∉",
        ni: "∋",
        prod: "∏",
        sum: "∑",
        minus: "−",
        lowast: "∗",
        radic: "√",
        prop: "∝",
        infin: "∞",
        ang: "∠",
        and: "∧",
        or: "∨",
        cap: "∩",
        cup: "∪",
        int: "∫",
        there4: "∴",
        sim: "∼",
        cong: "≅",
        asymp: "≈",
        ne: "≠",
        equiv: "≡",
        le: "≤",
        ge: "≥",
        sub: "⊂",
        sup: "⊃",
        nsub: "⊄",
        sube: "⊆",
        supe: "⊇",
        oplus: "⊕",
        otimes: "⊗",
        perp: "⊥",
        sdot: "⋅",
        lceil: "⌈",
        rceil: "⌉",
        lfloor: "⌊",
        rfloor: "⌋",
        lang: "〈",
        rang: "〉",
        loz: "◊",
        spades: "♠",
        clubs: "♣",
        hearts: "♥",
        diams: "♦",
        quot: '"',
        amp: "&",
        lt: "<",
        gt: ">",
        OElig: "Œ",
        oelig: "œ",
        Scaron: "Š",
        scaron: "š",
        Yuml: "Ÿ",
        circ: "ˆ",
        tilde: "˜",
        ensp: " ",
        emsp: " ",
        thinsp: " ",
        zwnj: "‌",
        zwj: "‍",
        lrm: "‎",
        rlm: "‏",
        ndash: "–",
        mdash: "—",
        lsquo: "‘",
        rsquo: "’",
        sbquo: "‚",
        ldquo: "“",
        rdquo: "”",
        bdquo: "„",
        dagger: "†",
        Dagger: "‡",
        permil: "‰",
        lsaquo: "‹",
        rsaquo: "›",
        euro: "€"
    },
    ye = ["cent", "copy", "divide", "gt", "lt", "not", "para", "times"],
    Vt = {}.hasOwnProperty,
    ut = {};
let H;
for (H in Z) Vt.call(Z, H) && (ut[Z[H]] = H);
const Fe = /[^\dA-Za-z]/;

function Te(t, e, n, r) {
    const a = String.fromCharCode(t);
    if (Vt.call(ut, a)) {
        const s = ut[a],
            x = "&" + s;
        return n && Rt.includes(s) && !ye.includes(s) && (!r || e && e !== 61 && Fe.test(String.fromCharCode(e))) ? x : x + ";"
    }
    return ""
}

function Ee(t, e, n) {
    let r = we(t, e, n.omitOptionalSemicolons),
        a;
    if ((n.useNamedReferences || n.useShortestReferences) && (a = Te(t, e, n.omitOptionalSemicolons, n.attribute)), (n.useShortestReferences || !a) && n.useShortestReferences) {
        const s = ke(t, e, n.omitOptionalSemicolons);
        s.length < r.length && (r = s)
    }
    return a && (!n.useShortestReferences || a.length < r.length) ? a : r
}

function Le(t) {
    return "&#x" + t.toString(16).toUpperCase() + ";"
}

function Vn(t, e) {
    return _t(t, Object.assign({
        format: Ee
    }, e))
}

function ze(t, e) {
    return _t(t, Object.assign({
        format: Le
    }, e))
}
const qe = {}.hasOwnProperty,
    De = {},
    kt = /^[^\t\n\r "#'.<=>`}]+$/,
    Me = /^[^\t\n\r "'<=>`}]+$/;

function Ne() {
    return {
        canContainEols: ["textDirective"],
        enter: {
            directiveContainer: Oe,
            directiveContainerAttributes: J,
            directiveContainerLabel: Re,
            directiveLeaf: $e,
            directiveLeafAttributes: J,
            directiveText: Pe,
            directiveTextAttributes: J
        },
        exit: {
            directiveContainer: rt,
            directiveContainerAttributeClassValue: tt,
            directiveContainerAttributeIdValue: K,
            directiveContainerAttributeName: nt,
            directiveContainerAttributeValue: et,
            directiveContainerAttributes: it,
            directiveContainerLabel: je,
            directiveContainerName: X,
            directiveLeaf: rt,
            directiveLeafAttributeClassValue: tt,
            directiveLeafAttributeIdValue: K,
            directiveLeafAttributeName: nt,
            directiveLeafAttributeValue: et,
            directiveLeafAttributes: it,
            directiveLeafName: X,
            directiveText: rt,
            directiveTextAttributeClassValue: tt,
            directiveTextAttributeIdValue: K,
            directiveTextAttributeName: nt,
            directiveTextAttributeValue: et,
            directiveTextAttributes: it,
            directiveTextName: X
        }
    }
}

function Ie(t) {
    const e = De;
    if (e.quote !== '"' && e.quote !== "'" && e.quote !== null && e.quote !== void 0) throw new Error("Invalid quote `" + e.quote + "`, expected `'` or `\"`");
    return n.peek = _e, {
        handlers: {
            containerDirective: n,
            leafDirective: n,
            textDirective: n
        },
        unsafe: [{
            character: "\r",
            inConstruct: ["leafDirectiveLabel", "containerDirectiveLabel"]
        }, {
            character: "\n",
            inConstruct: ["leafDirectiveLabel", "containerDirectiveLabel"]
        }, {
            before: "[^:]",
            character: ":",
            after: "[A-Za-z]",
            inConstruct: ["phrasing"]
        }, {
            atBreak: !0,
            character: ":",
            after: ":"
        }]
    };

    function n(s, x, h, c) {
        const g = h.createTracker(c),
            p = Ve(s),
            v = h.enter(s.type);
        let m = g.move(p + (s.name || "")),
            l;
        if (s.type === "containerDirective") {
            const b = (s.children || [])[0];
            l = yt(b) ? b : void 0
        } else l = s;
        if (l && l.children && l.children.length > 0) {
            const b = h.enter("label"),
                C = "".concat(s.type, "Label"),
                i = h.enter(C);
            m += g.move("["), m += g.move(h.containerPhrasing(l, Y(B({}, g.current()), {
                before: m,
                after: "]"
            }))), m += g.move("]"), i(), b()
        }
        if (m += g.move(r(s, h)), s.type === "containerDirective") {
            const b = (s.children || [])[0];
            let C = s;
            yt(b) && (C = Object.assign({}, s, {
                children: s.children.slice(1)
            })), C && C.children && C.children.length > 0 && (m += g.move("\n"), m += g.move(h.containerFlow(C, g.current()))), m += g.move("\n" + p)
        }
        return v(), m
    }

    function r(s, x) {
        const h = s.attributes || {},
            c = [];
        let g, p, v, m;
        for (m in h)
            if (qe.call(h, m) && h[m] !== void 0 && h[m] !== null) {
                const l = String(h[m]);
                if (m === "id") v = e.preferShortcut !== !1 && kt.test(l) ? "#" + l : a("id", l, s, x);
                else if (m === "class") {
                    const b = l.split(/[\t\n\r ]+/g),
                        C = [],
                        i = [];
                    let k = -1;
                    for (; ++k < b.length;)(e.preferShortcut !== !1 && kt.test(b[k]) ? i : C).push(b[k]);
                    g = C.length > 0 ? a("class", C.join(" "), s, x) : "", p = i.length > 0 ? "." + i.join(".") : ""
                } else c.push(a(m, l, s, x))
            }
        return g && c.unshift(g), p && c.unshift(p), v && c.unshift(v), c.length > 0 ? "{" + c.join(" ") + "}" : ""
    }

    function a(s, x, h, c) {
        if (e.collapseEmptyAttributes !== !1 && !x) return s;
        if (e.preferUnquoted && Me.test(x)) return s + "=" + x;
        const g = e.quote || c.options.quote || '"',
            p = g === '"' ? "'" : '"',
            v = e.quoteSmart && vt(x, g) > vt(x, p) ? p : g,
            m = h.type === "textDirective" ? [v] : [v, "\n", "\r"];
        return s + "=" + v + ze(x, {
            subset: m
        }) + v
    }
}

function Oe(t) {
    st.call(this, "containerDirective", t)
}

function $e(t) {
    st.call(this, "leafDirective", t)
}

function Pe(t) {
    st.call(this, "textDirective", t)
}

function st(t, e) {
    this.enter({
        type: t,
        name: "",
        attributes: {},
        children: []
    }, e)
}

function X(t) {
    const e = this.stack[this.stack.length - 1];
    j(e.type === "containerDirective" || e.type === "leafDirective" || e.type === "textDirective"), e.name = this.sliceSerialize(t)
}

function Re(t) {
    this.enter({
        type: "paragraph",
        data: {
            directiveLabel: !0
        },
        children: []
    }, t)
}

function je(t) {
    this.exit(t)
}

function J() {
    this.data.directiveAttributes = [], this.buffer()
}

function K(t) {
    this.data.directiveAttributes.push(["id", lt(this.sliceSerialize(t), {
        attribute: !0
    })])
}

function tt(t) {
    this.data.directiveAttributes.push(["class", lt(this.sliceSerialize(t), {
        attribute: !0
    })])
}

function et(t) {
    const e = this.data.directiveAttributes;
    e[e.length - 1][1] = lt(this.sliceSerialize(t), {
        attribute: !0
    })
}

function nt(t) {
    this.data.directiveAttributes.push([this.sliceSerialize(t), ""])
}

function it() {
    const t = this.data.directiveAttributes,
        e = {};
    let n = -1;
    for (; ++n < t.length;) {
        const a = t[n];
        a[0] === "class" && e.class ? e.class += " " + a[1] : e[a[0]] = a[1]
    }
    this.data.directiveAttributes = void 0, this.resume();
    const r = this.stack[this.stack.length - 1];
    j(r.type === "containerDirective" || r.type === "leafDirective" || r.type === "textDirective"), r.attributes = e
}

function rt(t) {
    this.exit(t)
}

function _e() {
    return ":"
}

function yt(t) {
    return !!(t && t.type === "paragraph" && t.data && t.data.directiveLabel)
}

function Ve(t) {
    let e = 0;
    return t.type === "containerDirective" ? (ee(t, function(n, r) {
        if (n.type === "containerDirective") {
            let a = r.length,
                s = 0;
            for (; a--;) r[a].type === "containerDirective" && s++;
            s > e && (e = s)
        }
    }), e += 3) : t.type === "leafDirective" ? e = 2 : e = 1, ":".repeat(e)
}

function ot(t, e, n, r, a, s, x, h, c, g, p, v, m, l, b) {
    let C, i;
    return k;

    function k(u) {
        return t.enter(r), t.enter(a), t.consume(u), t.exit(a), A
    }

    function A(u) {
        return u === 35 ? (C = x, w(u)) : u === 46 ? (C = h, w(u)) : u === 58 || u === 95 || Ot(u) ? (t.enter(s), t.enter(c), t.consume(u), L) : b && G(u) ? O(t, A, "whitespace")(u) : !b && R(u) ? U(t, A)(u) : q(u)
    }

    function w(u) {
        const _ = C + "Marker";
        return t.enter(s), t.enter(C), t.enter(_), t.consume(u), t.exit(_), F
    }

    function F(u) {
        if (u === null || u === 34 || u === 35 || u === 39 || u === 46 || u === 60 || u === 61 || u === 62 || u === 96 || u === 125 || R(u)) return n(u);
        const _ = C + "Value";
        return t.enter(_), t.consume(u), y
    }

    function y(u) {
        if (u === null || u === 34 || u === 39 || u === 60 || u === 61 || u === 62 || u === 96) return n(u);
        if (u === 35 || u === 46 || u === 125 || R(u)) {
            const _ = C + "Value";
            return t.exit(_), t.exit(C), t.exit(s), A(u)
        }
        return t.consume(u), y
    }

    function L(u) {
        return u === 45 || u === 46 || u === 58 || u === 95 || $t(u) ? (t.consume(u), L) : (t.exit(c), b && G(u) ? O(t, o, "whitespace")(u) : !b && R(u) ? U(t, o)(u) : o(u))
    }

    function o(u) {
        return u === 61 ? (t.enter(g), t.consume(u), t.exit(g), T) : (t.exit(s), A(u))
    }

    function T(u) {
        return u === null || u === 60 || u === 61 || u === 62 || u === 96 || u === 125 || b && P(u) ? n(u) : u === 34 || u === 39 ? (t.enter(p), t.enter(m), t.consume(u), t.exit(m), i = u, z) : b && G(u) ? O(t, T, "whitespace")(u) : !b && R(u) ? U(t, T)(u) : (t.enter(v), t.enter(l), t.consume(u), i = void 0, N)
    }

    function N(u) {
        return u === null || u === 34 || u === 39 || u === 60 || u === 61 || u === 62 || u === 96 ? n(u) : u === 125 || R(u) ? (t.exit(l), t.exit(v), t.exit(s), A(u)) : (t.consume(u), N)
    }

    function z(u) {
        return u === i ? (t.enter(m), t.consume(u), t.exit(m), t.exit(p), t.exit(s), I) : (t.enter(v), D(u))
    }

    function D(u) {
        return u === i ? (t.exit(v), z(u)) : u === null ? n(u) : P(u) ? b ? n(u) : U(t, D)(u) : (t.enter(l), t.consume(u), S)
    }

    function S(u) {
        return u === i || u === null || P(u) ? (t.exit(l), D(u)) : (t.consume(u), S)
    }

    function I(u) {
        return u === 125 || R(u) ? A(u) : q(u)
    }

    function q(u) {
        return u === 125 ? (t.enter(a), t.consume(u), t.exit(a), t.exit(r), e) : n(u)
    }
}

function ct(t, e, n, r, a, s, x) {
    let h = 0,
        c = 0,
        g;
    return p;

    function p(i) {
        return t.enter(r), t.enter(a), t.consume(i), t.exit(a), v
    }

    function v(i) {
        return i === 93 ? (t.enter(a), t.consume(i), t.exit(a), t.exit(r), e) : (t.enter(s), m(i))
    }

    function m(i) {
        if (i === 93 && !c) return C(i);
        const k = t.enter("chunkText", {
            contentType: "text",
            previous: g
        });
        return g && (g.next = k), g = k, l(i)
    }

    function l(i) {
        return i === null || h > 999 || i === 91 && ++c > 32 ? n(i) : i === 93 && !c-- ? (t.exit("chunkText"), C(i)) : P(i) ? x ? n(i) : (t.consume(i), t.exit("chunkText"), m) : (t.consume(i), i === 92 ? b : l)
    }

    function b(i) {
        return i === 91 || i === 92 || i === 93 ? (t.consume(i), h++, l) : l(i)
    }

    function C(i) {
        return t.exit(s), t.enter(a), t.consume(i), t.exit(a), t.exit(r), e
    }
}

function ht(t, e, n, r) {
    const a = this;
    return s;

    function s(h) {
        return Ot(h) ? (t.enter(r), t.consume(h), x) : n(h)
    }

    function x(h) {
        return h === 45 || h === 95 || $t(h) ? (t.consume(h), x) : (t.exit(r), a.previous === 45 || a.previous === 95 ? n(h) : e(h))
    }
}
const Be = {
        tokenize: Qe,
        concrete: !0
    },
    Ue = {
        tokenize: Ye,
        partial: !0
    },
    He = {
        tokenize: We,
        partial: !0
    },
    Ft = {
        tokenize: Ge,
        partial: !0
    };

function Qe(t, e, n) {
    const r = this,
        a = r.events[r.events.length - 1],
        s = a && a[1].type === "linePrefix" ? a[2].sliceSerialize(a[1], !0).length : 0;
    let x = 0,
        h;
    return c;

    function c(o) {
        return t.enter("directiveContainer"), t.enter("directiveContainerFence"), t.enter("directiveContainerSequence"), g(o)
    }

    function g(o) {
        return o === 58 ? (t.consume(o), x++, g) : x < 3 ? n(o) : (t.exit("directiveContainerSequence"), ht.call(r, t, p, n, "directiveContainerName")(o))
    }

    function p(o) {
        return o === 91 ? t.attempt(Ue, v, v)(o) : v(o)
    }

    function v(o) {
        return o === 123 ? t.attempt(He, m, m)(o) : m(o)
    }

    function m(o) {
        return O(t, l, "whitespace")(o)
    }

    function l(o) {
        return t.exit("directiveContainerFence"), o === null ? b(o) : P(o) ? r.interrupt ? e(o) : t.attempt(Ft, C, b)(o) : n(o)
    }

    function b(o) {
        return t.exit("directiveContainer"), e(o)
    }

    function C(o) {
        return o === null ? (t.exit("directiveContainer"), e(o)) : (t.enter("directiveContainerContent"), i(o))
    }

    function i(o) {
        return o === null ? y(o) : t.attempt({
            tokenize: L,
            partial: !0
        }, y, s ? O(t, k, "linePrefix", s + 1) : k)(o)
    }

    function k(o) {
        if (o === null) return y(o);
        const T = t.enter("chunkDocument", {
            contentType: "document",
            previous: h
        });
        return h && (h.next = T), h = T, A(o)
    }

    function A(o) {
        if (o === null) {
            const T = t.exit("chunkDocument");
            return r.parser.lazy[T.start.line] = !1, y(o)
        }
        return P(o) ? t.check(Ft, w, F)(o) : (t.consume(o), A)
    }

    function w(o) {
        t.consume(o);
        const T = t.exit("chunkDocument");
        return r.parser.lazy[T.start.line] = !1, i
    }

    function F(o) {
        const T = t.exit("chunkDocument");
        return r.parser.lazy[T.start.line] = !1, y(o)
    }

    function y(o) {
        return t.exit("directiveContainerContent"), t.exit("directiveContainer"), e(o)
    }

    function L(o, T, N) {
        let z = 0;
        return O(o, D, "linePrefix", 4);

        function D(q) {
            return o.enter("directiveContainerFence"), o.enter("directiveContainerSequence"), S(q)
        }

        function S(q) {
            return q === 58 ? (o.consume(q), z++, S) : z < x ? N(q) : (o.exit("directiveContainerSequence"), O(o, I, "whitespace")(q))
        }

        function I(q) {
            return q === null || P(q) ? (o.exit("directiveContainerFence"), T(q)) : N(q)
        }
    }
}

function Ye(t, e, n) {
    return ct(t, e, n, "directiveContainerLabel", "directiveContainerLabelMarker", "directiveContainerLabelString", !0)
}

function We(t, e, n) {
    return ot(t, e, n, "directiveContainerAttributes", "directiveContainerAttributesMarker", "directiveContainerAttribute", "directiveContainerAttributeId", "directiveContainerAttributeClass", "directiveContainerAttributeName", "directiveContainerAttributeInitializerMarker", "directiveContainerAttributeValueLiteral", "directiveContainerAttributeValue", "directiveContainerAttributeValueMarker", "directiveContainerAttributeValueData", !0)
}

function Ge(t, e, n) {
    const r = this;
    return a;

    function a(x) {
        return t.enter("lineEnding"), t.consume(x), t.exit("lineEnding"), s
    }

    function s(x) {
        return r.parser.lazy[r.now().line] ? n(x) : e(x)
    }
}
const Ze = {
        tokenize: Ke
    },
    Xe = {
        tokenize: tn,
        partial: !0
    },
    Je = {
        tokenize: en,
        partial: !0
    };

function Ke(t, e, n) {
    const r = this;
    return a;

    function a(p) {
        return t.enter("directiveLeaf"), t.enter("directiveLeafSequence"), t.consume(p), s
    }

    function s(p) {
        return p === 58 ? (t.consume(p), t.exit("directiveLeafSequence"), ht.call(r, t, x, n, "directiveLeafName")) : n(p)
    }

    function x(p) {
        return p === 91 ? t.attempt(Xe, h, h)(p) : h(p)
    }

    function h(p) {
        return p === 123 ? t.attempt(Je, c, c)(p) : c(p)
    }

    function c(p) {
        return O(t, g, "whitespace")(p)
    }

    function g(p) {
        return p === null || P(p) ? (t.exit("directiveLeaf"), e(p)) : n(p)
    }
}

function tn(t, e, n) {
    return ct(t, e, n, "directiveLeafLabel", "directiveLeafLabelMarker", "directiveLeafLabelString", !0)
}

function en(t, e, n) {
    return ot(t, e, n, "directiveLeafAttributes", "directiveLeafAttributesMarker", "directiveLeafAttribute", "directiveLeafAttributeId", "directiveLeafAttributeClass", "directiveLeafAttributeName", "directiveLeafAttributeInitializerMarker", "directiveLeafAttributeValueLiteral", "directiveLeafAttributeValue", "directiveLeafAttributeValueMarker", "directiveLeafAttributeValueData", !0)
}
const nn = {
        tokenize: ln,
        previous: un
    },
    rn = {
        tokenize: sn,
        partial: !0
    },
    an = {
        tokenize: on,
        partial: !0
    };

function un(t) {
    return t !== 58 || this.events[this.events.length - 1][1].type === "characterEscape"
}

function ln(t, e, n) {
    const r = this;
    return a;

    function a(c) {
        return t.enter("directiveText"), t.enter("directiveTextMarker"), t.consume(c), t.exit("directiveTextMarker"), ht.call(r, t, s, n, "directiveTextName")
    }

    function s(c) {
        return c === 58 ? n(c) : c === 91 ? t.attempt(rn, x, x)(c) : x(c)
    }

    function x(c) {
        return c === 123 ? t.attempt(an, h, h)(c) : h(c)
    }

    function h(c) {
        return t.exit("directiveText"), e(c)
    }
}

function sn(t, e, n) {
    return ct(t, e, n, "directiveTextLabel", "directiveTextLabelMarker", "directiveTextLabelString")
}

function on(t, e, n) {
    return ot(t, e, n, "directiveTextAttributes", "directiveTextAttributesMarker", "directiveTextAttribute", "directiveTextAttributeId", "directiveTextAttributeClass", "directiveTextAttributeName", "directiveTextAttributeInitializerMarker", "directiveTextAttributeValueLiteral", "directiveTextAttributeValue", "directiveTextAttributeValueMarker", "directiveTextAttributeValueData")
}

function cn() {
    return {
        text: {
            58: nn
        },
        flow: {
            58: [Be, Ze]
        }
    }
}

function Bn() {
    const e = this.data(),
        n = e.micromarkExtensions || (e.micromarkExtensions = []),
        r = e.fromMarkdownExtensions || (e.fromMarkdownExtensions = []),
        a = e.toMarkdownExtensions || (e.toMarkdownExtensions = []);
    n.push(cn()), r.push(Ne()), a.push(Ie())
}

function hn() {
    return {
        enter: {
            mathFlow: t,
            mathFlowFenceMeta: e,
            mathText: s
        },
        exit: {
            mathFlow: a,
            mathFlowFence: r,
            mathFlowFenceMeta: n,
            mathFlowValue: h,
            mathText: x,
            mathTextData: h
        }
    };

    function t(c) {
        const g = {
            type: "element",
            tagName: "code",
            properties: {
                className: ["language-math", "math-display"]
            },
            children: []
        };
        this.enter({
            type: "math",
            meta: null,
            value: "",
            data: {
                hName: "pre",
                hChildren: [g]
            }
        }, c)
    }

    function e() {
        this.buffer()
    }

    function n() {
        const c = this.resume(),
            g = this.stack[this.stack.length - 1];
        j(g.type === "math"), g.meta = c
    }

    function r() {
        this.data.mathFlowInside || (this.buffer(), this.data.mathFlowInside = !0)
    }

    function a(c) {
        const g = this.resume().replace(/^(\r?\n|\r)|(\r?\n|\r)$/g, ""),
            p = this.stack[this.stack.length - 1];
        j(p.type === "math"), this.exit(c), p.value = g;
        const v = p.data.hChildren[0];
        j(v.type === "element"), j(v.tagName === "code"), v.children.push({
            type: "text",
            value: g
        }), this.data.mathFlowInside = void 0
    }

    function s(c) {
        this.enter({
            type: "inlineMath",
            value: "",
            data: {
                hName: "code",
                hProperties: {
                    className: ["language-math", "math-inline"]
                },
                hChildren: []
            }
        }, c), this.buffer()
    }

    function x(c) {
        const g = this.resume(),
            p = this.stack[this.stack.length - 1];
        j(p.type === "inlineMath"), this.exit(c), p.value = g, p.data.hChildren.push({
            type: "text",
            value: g
        })
    }

    function h(c) {
        this.config.enter.data.call(this, c), this.config.exit.data.call(this, c)
    }
}

function mn(t) {
    let e = {}.singleDollarTextMath;
    return e == null && (e = !0), r.peek = a, {
        unsafe: [{
            character: "\r",
            inConstruct: "mathFlowMeta"
        }, {
            character: "\n",
            inConstruct: "mathFlowMeta"
        }, {
            character: "$",
            after: e ? void 0 : "\\$",
            inConstruct: "phrasing"
        }, {
            character: "$",
            inConstruct: "mathFlowMeta"
        }, {
            atBreak: !0,
            character: "$",
            after: "\\$"
        }],
        handlers: {
            math: n,
            inlineMath: r
        }
    };

    function n(s, x, h, c) {
        const g = s.value || "",
            p = h.createTracker(c),
            v = "$".repeat(Math.max(ue(g, "$") + 1, 2)),
            m = h.enter("mathFlow");
        let l = p.move(v);
        if (s.meta) {
            const b = h.enter("mathFlowMeta");
            l += p.move(h.safe(s.meta, B({
                after: "\n",
                before: l,
                encode: ["$"]
            }, p.current()))), b()
        }
        return l += p.move("\n"), g && (l += p.move(g + "\n")), l += p.move(v), m(), l
    }

    function r(s, x, h) {
        let c = s.value || "",
            g = 1;
        for (e || g++; new RegExp("(^|[^$])" + "\\$".repeat(g) + "([^$]|$)").test(c);) g++;
        const p = "$".repeat(g);
        /[^ \r\n]/.test(c) && (/^[ \r\n]/.test(c) && /[ \r\n]$/.test(c) || /^\$|\$$/.test(c)) && (c = " " + c + " ");
        let v = -1;
        for (; ++v < h.unsafe.length;) {
            const m = h.unsafe[v];
            if (!m.atBreak) continue;
            const l = h.compilePattern(m);
            let b;
            for (; b = l.exec(c);) {
                let C = b.index;
                c.codePointAt(C) === 10 && c.codePointAt(C - 1) === 13 && C--, c = c.slice(0, C) + " " + c.slice(b.index + 1)
            }
        }
        return p + c + p
    }

    function a() {
        return "$"
    }
}
const f = {
    eof: null,
    space: 32,
    dollarSign: 36,
    leftParenthesis: 40,
    rightParenthesis: 41,
    leftSquareBracket: 91,
    backslash: 92,
    rightSquareBracket: 93
};

function E(t) {
    return t !== null && t < -2
}

function Tt(t) {
    return t === -2 || t === -1 || t === 32
}

function $(t, e, n, r) {
    const a = r ? r - 1 : Number.POSITIVE_INFINITY;
    let s = 0;
    return x;

    function x(c) {
        return Tt(c) ? (t.enter(n), h(c)) : e(c)
    }

    function h(c) {
        return Tt(c) && s++ < a ? (t.consume(c), h) : (t.exit(n), e(c))
    }
}
const Q = {
        contentTypeString: "string",
        tabSize: 4
    },
    d = {
        whitespace: "whitespace",
        lineEnding: "lineEnding",
        linePrefix: "linePrefix",
        characterEscape: "characterEscape",
        chunkString: "chunkString"
    };
const xn = {
        tokenize: gn,
        concrete: !0
    },
    pn = {
        tokenize: fn,
        partial: !0
    };

function gn(t, e, n) {
    const r = this,
        a = this.events[this.events.length - 1],
        s = a && a[1].type === d.linePrefix ? a[2].sliceSerialize(a[1], !0).length : 0,
        x = [];
    return h;

    function h(i) {
        return t.enter("mathFlow"), t.enter("mathFlowFence"), t.enter("mathFlowFenceSequence"), c(i)
    }

    function c(i) {
        return i === f.backslash || i === f.leftSquareBracket && x[0] === f.backslash ? (t.consume(i), x.push(i), c) : (t.exit("mathFlowFenceSequence"), x.length < 2 ? n(i) : $(t, g, d.whitespace)(i))
    }

    function g(i) {
        return i === f.eof || E(i) ? v(i) : (t.enter("mathFlowFenceMeta"), t.enter(d.chunkString, {
            contentType: Q.contentTypeString
        }), p(i))
    }

    function p(i) {
        return i === f.eof || E(i) ? (t.exit(d.chunkString), t.exit("mathFlowFenceMeta"), v(i)) : i === f.rightSquareBracket ? n(i) : (t.consume(i), p)
    }

    function v(i) {
        return t.exit("mathFlowFence"), r.interrupt ? e(i) : m(i)
    }

    function m(i) {
        return i === f.eof ? b(i) : E(i) ? t.attempt(pn, t.attempt({
            tokenize: C,
            partial: !0
        }, b, s ? $(t, m, d.linePrefix, s + 1) : m), b)(i) : (t.enter("mathFlowValue"), l(i))
    }

    function l(i) {
        return i === f.eof || E(i) ? (t.exit("mathFlowValue"), m(i)) : (t.consume(i), l)
    }

    function b(i) {
        return t.exit("mathFlow"), e(i)
    }

    function C(i, k, A) {
        const w = [];
        return $(i, F, d.linePrefix, Q.tabSize);

        function F(o) {
            return i.enter("mathFlowFence"), i.enter("mathFlowFenceSequence"), y(o)
        }

        function y(o) {
            return o === f.backslash && w.length === 0 || o === f.rightSquareBracket && w[0] === f.backslash ? (i.consume(o), w.push(o), y) : w < x ? A(o) : (i.exit("mathFlowFenceSequence"), $(i, L, d.whitespace)(o))
        }

        function L(o) {
            return o === f.eof || E(o) ? (i.exit("mathFlowFence"), k(o)) : A(o)
        }
    }
}

function fn(t, e, n) {
    const r = this;
    return a;

    function a(x) {
        return t.enter(d.lineEnding), t.consume(x), t.exit(d.lineEnding), s
    }

    function s(x) {
        return r.parser.lazy[r.now().line] ? n(x) : e(x)
    }
}
const vn = {
        tokenize: dn,
        concrete: !0
    },
    bn = {
        tokenize: Cn,
        partial: !0
    };

function dn(t, e, n) {
    const r = this,
        a = r.events[r.events.length - 1],
        s = a && a[1].type === d.linePrefix ? a[2].sliceSerialize(a[1], !0).length : 0;
    let x = 0;
    return h;

    function h(i) {
        return t.enter("mathFlow"), t.enter("mathFlowFence"), t.enter("mathFlowFenceSequence"), c(i)
    }

    function c(i) {
        return i === f.dollarSign ? (t.consume(i), x++, c) : (t.exit("mathFlowFenceSequence"), x < 2 ? n(i) : $(t, g, d.whitespace)(i))
    }

    function g(i) {
        return i === f.eof || E(i) ? v(i) : (t.enter("mathFlowFenceMeta"), t.enter(d.chunkString, {
            contentType: Q.contentTypeString
        }), p(i))
    }

    function p(i) {
        return i === f.eof || E(i) ? (t.exit(d.chunkString), t.exit("mathFlowFenceMeta"), v(i)) : i === f.dollarSign ? n(i) : (t.consume(i), p)
    }

    function v(i) {
        return t.exit("mathFlowFence"), r.interrupt ? e(i) : m(i)
    }

    function m(i) {
        return i === f.eof ? b(i) : E(i) ? t.attempt(bn, t.attempt({
            tokenize: C,
            partial: !0
        }, b, s ? $(t, m, d.linePrefix, s + 1) : m), b)(i) : (t.enter("mathFlowValue"), l(i))
    }

    function l(i) {
        return i === f.eof || E(i) ? (t.exit("mathFlowValue"), m(i)) : (t.consume(i), l)
    }

    function b(i) {
        return t.exit("mathFlow"), e(i)
    }

    function C(i, k, A) {
        let w = 0;
        return $(i, F, d.linePrefix, Q.tabSize);

        function F(o) {
            return i.enter("mathFlowFence"), i.enter("mathFlowFenceSequence"), y(o)
        }

        function y(o) {
            return o === f.dollarSign ? (i.consume(o), w++, y) : w < x ? A(o) : (i.exit("mathFlowFenceSequence"), $(i, L, d.whitespace)(o))
        }

        function L(o) {
            return o === f.eof || E(o) ? (i.exit("mathFlowFence"), k(o)) : A(o)
        }
    }
}

function Cn(t, e, n) {
    const r = this;
    return a;

    function a(x) {
        return t.enter(d.lineEnding), t.consume(x), t.exit(d.lineEnding), s
    }

    function s(x) {
        return r.parser.lazy[r.now().line] ? n(x) : e(x)
    }
}

function Sn() {
    return {
        tokenize: t,
        resolve: wn,
        previous: Et
    };

    function t(e, n, r) {
        const a = [];
        let s = [],
            x;
        const h = this;
        return c;

        function c(l) {
            return Et.call(h, h.previous) && (h.previous, void 0), e.enter("mathText"), e.enter("mathTextSequence"), g(l)
        }

        function g(l) {
            return l === f.backslash && a.length === 0 || l === f.leftParenthesis && a.length === 1 ? (e.consume(l), a.push(l), g) : a.length < 2 ? r(l) : (e.exit("mathTextSequence"), p(l))
        }

        function p(l) {
            return l === f.eof ? r(l) : l === f.backslash ? (x = e.enter("mathTextSequence"), s = [], m(l)) : l === f.space ? (e.enter("space"), e.consume(l), e.exit("space"), p) : E(l) ? (e.enter(d.lineEnding), e.consume(l), e.exit(d.lineEnding), p) : (e.enter("mathTextData"), v(l))
        }

        function v(l) {
            return l === f.eof || l === f.space || l === f.backslash || E(l) ? (e.exit("mathTextData"), p(l)) : (e.consume(l), v)
        }

        function m(l) {
            return l === f.backslash && s.length === 0 || l === f.rightParenthesis && s.length === 1 ? (e.consume(l), s.push(l), m) : s.length === a.length ? (e.exit("mathTextSequence"), e.exit("mathText"), n(l)) : (x.type = "mathTextData", v(l))
        }
    }
}

function wn(t) {
    let e = t.length - 4,
        n = 3,
        r, a;
    if ((t[n][1].type === d.lineEnding || t[n][1].type === "space") && (t[e][1].type === d.lineEnding || t[e][1].type === "space")) {
        for (r = n; ++r < e;)
            if (t[r][1].type === "mathTextData") {
                t[e][1].type = "mathTextPadding", t[n][1].type = "mathTextPadding", n += 2, e -= 2;
                break
            }
    }
    for (r = n - 1, e++; ++r <= e;) a === void 0 ? r !== e && t[r][1].type !== d.lineEnding && (a = r) : (r === e || t[r][1].type === d.lineEnding) && (t[a][1].type = "mathTextData", r !== a + 2 && (t[a][1].end = t[r - 1][1].end, t.splice(a + 2, r - a - 2), e -= r - a - 2, r = a + 2), a = void 0);
    return t
}

function Et(t) {
    return t !== f.backslash || this.events[this.events.length - 1][1].type === d.characterEscape
}

function An() {
    return {
        tokenize: t,
        resolve: kn,
        previous: yn
    };

    function t(e, n, r) {
        let a = 0,
            s, x;
        return h;

        function h(m) {
            return e.enter("mathText"), e.enter("mathTextSequence"), c(m)
        }

        function c(m) {
            return m === f.dollarSign ? (e.consume(m), a++, c) : a < 2 ? r(m) : (e.exit("mathTextSequence"), g(m))
        }

        function g(m) {
            return m === f.eof ? r(m) : m === f.dollarSign ? (x = e.enter("mathTextSequence"), s = 0, v(m)) : m === f.space ? (e.enter("space"), e.consume(m), e.exit("space"), g) : E(m) ? (e.enter(d.lineEnding), e.consume(m), e.exit(d.lineEnding), g) : (e.enter("mathTextData"), p(m))
        }

        function p(m) {
            return m === f.eof || m === f.space || m === f.dollarSign || E(m) ? (e.exit("mathTextData"), g(m)) : (e.consume(m), p)
        }

        function v(m) {
            return m === f.dollarSign ? (e.consume(m), s++, v) : s === a ? (e.exit("mathTextSequence"), e.exit("mathText"), n(m)) : (x.type = "mathTextData", p(m))
        }
    }
}

function kn(t) {
    let e = t.length - 4,
        n = 3,
        r, a;
    if ((t[n][1].type === d.lineEnding || t[n][1].type === "space") && (t[e][1].type === d.lineEnding || t[e][1].type === "space")) {
        for (r = n; ++r < e;)
            if (t[r][1].type === "mathTextData") {
                t[e][1].type = "mathTextPadding", t[n][1].type = "mathTextPadding", n += 2, e -= 2;
                break
            }
    }
    for (r = n - 1, e++; ++r <= e;) a === void 0 ? r !== e && t[r][1].type !== d.lineEnding && (a = r) : (r === e || t[r][1].type === d.lineEnding) && (t[a][1].type = "mathTextData", r !== a + 2 && (t[a][1].end = t[r - 1][1].end, t.splice(a + 2, r - a - 2), e -= r - a - 2, r = a + 2), a = void 0);
    return t
}

function yn(t) {
    return t !== f.dollarSign || this.events[this.events.length - 1][1].type === d.characterEscape
}

function Fn() {
    return {
        tokenize: t,
        resolve: Tn,
        previous: Lt
    };

    function t(e, n, r) {
        const a = [];
        let s = [],
            x;
        const h = this;
        return c;

        function c(l) {
            return Lt.call(h, h.previous) && (h.previous, void 0), e.enter("mathText"), e.enter("mathTextSequence"), g(l)
        }

        function g(l) {
            return l === f.backslash && a.length === 0 || l === f.leftSquareBracket && a.length === 1 ? (e.consume(l), a.push(l), g) : a.length < 2 ? r(l) : (e.exit("mathTextSequence"), p(l))
        }

        function p(l) {
            return l === f.eof ? r(l) : l === f.backslash ? (x = e.enter("mathTextSequence"), s = [], m(l)) : l === f.space ? (e.enter("space"), e.consume(l), e.exit("space"), p) : E(l) ? (e.enter(d.lineEnding), e.consume(l), e.exit(d.lineEnding), p) : (e.enter("mathTextData"), v(l))
        }

        function v(l) {
            return l === f.eof || l === f.space || l === f.backslash || E(l) ? (e.exit("mathTextData"), p(l)) : (e.consume(l), v)
        }

        function m(l) {
            return l === f.backslash && s.length === 0 || l === f.rightSquareBracket && s.length === 1 ? (e.consume(l), s.push(l), m) : s.length === a.length ? (e.exit("mathTextSequence"), e.exit("mathText"), n(l)) : (x.type = "mathTextData", v(l))
        }
    }
}

function Tn(t) {
    let e = t.length - 4,
        n = 3,
        r, a;
    if ((t[n][1].type === d.lineEnding || t[n][1].type === "space") && (t[e][1].type === d.lineEnding || t[e][1].type === "space")) {
        for (r = n; ++r < e;)
            if (t[r][1].type === "mathTextData") {
                t[e][1].type = "mathTextPadding", t[n][1].type = "mathTextPadding", n += 2, e -= 2;
                break
            }
    }
    for (r = n - 1, e++; ++r <= e;) a === void 0 ? r !== e && t[r][1].type !== d.lineEnding && (a = r) : (r === e || t[r][1].type === d.lineEnding) && (t[a][1].type = "mathTextData", r !== a + 2 && (t[a][1].end = t[r - 1][1].end, t.splice(a + 2, r - a - 2), e -= r - a - 2, r = a + 2), a = void 0);
    return t
}

function Lt(t) {
    return t !== f.backslash || this.events[this.events.length - 1][1].type === d.characterEscape
}

function En() {
    return {
        flow: {
            [f.dollarSign]: vn,
            [f.backslash]: xn
        },
        text: {
            [f.dollarSign]: An(),
            [f.backslash]: [Sn(), Fn()]
        }
    }
}

function Un() {
    const t = this.data();
    e("micromarkExtensions", En()), e("fromMarkdownExtensions", hn()), e("toMarkdownExtensions", mn());

    function e(n, r) {
        (t[n] ? t[n] : t[n] = []).push(r)
    }
}
export {
    dt as C, Bn as a, Rn as b, jn as c, _n as d, Un as r, Vn as s
};
//# sourceMappingURL=dv2e3o9gddnli9b5.js.map