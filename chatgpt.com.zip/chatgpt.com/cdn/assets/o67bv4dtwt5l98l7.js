var ke = Object.defineProperty,
    Pe = Object.defineProperties;
var Re = Object.getOwnPropertyDescriptors;
var re = Object.getOwnPropertySymbols;
var Ne = Object.prototype.hasOwnProperty,
    Se = Object.prototype.propertyIsEnumerable;
var ce = (s, e, n) => e in s ? ke(s, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : s[e] = n,
    P = (s, e) => {
        for (var n in e || (e = {})) Ne.call(e, n) && ce(s, n, e[n]);
        if (re)
            for (var n of re(e)) Se.call(e, n) && ce(s, n, e[n]);
        return s
    },
    L = (s, e) => Pe(s, Re(e));
import {
    e as Q,
    i as xe,
    r as x,
    d as Fe,
    j as t,
    f as je,
    M as G,
    c as D,
    v as De
} from "./fg33krlcm0qyi6yw.js";
import {
    m as oe,
    c_ as Me,
    R as we,
    M as se,
    cQ as Ee,
    ad as Te,
    i9 as Oe,
    gK as Ie,
    g2 as ve,
    gJ as ye,
    a9 as Ae,
    B as qe,
    b as ie,
    kQ as be,
    rq as de,
    rr as Be,
    qw as Ge,
    dB as ze,
    lk as ue,
    fh as me,
    lU as Le,
    d as fe,
    lf as Ue,
    lo as pe,
    lj as He,
    lq as We,
    eW as ge,
    e4 as ae,
    _ as $e,
    bg as Ye
} from "./dykg4ktvbu3mhmdo.js";
import {
    hv as Ke,
    hw as Qe,
    g2 as Ve,
    Z as b,
    hx as Xe,
    hy as Ze,
    fu as he,
    dP as ne,
    hz as Je,
    cL as Ce,
    hA as et,
    d0 as tt,
    d1 as st,
    d2 as at,
    gd as nt,
    g0 as ot,
    hB as it,
    g3 as lt,
    hC as rt,
    hD as ct,
    hE as dt,
    hF as ut
} from "./k15yxxoybkkir2ou.js";
import {
    I as mt
} from "./fj4bpqcms0mhjoda.js";
const ft = ({
        image: s,
        onClose: e,
        onRequestCompletion: n,
        clientThreadId: d,
        currentModelId: c,
        post: o,
        canDelete: l,
        onOpenReport: a
    }) => {
        var A;
        const m = ie(),
            i = Q(),
            g = oe(),
            f = xe(),
            r = !Me(),
            [p, M] = x.useState("default"),
            u = Ke(),
            N = x.useRef(null),
            I = x.useRef(u);
        x.useEffect(() => {
            I.current = u
        }, [u]);
        const E = x.useCallback(() => Qe(i), [i]),
            _ = x.useCallback(() => {
                s && M("inpaint")
            }, [s]),
            S = x.useCallback(() => {
                M("default"), I.current.clearAllDrawings()
            }, []),
            F = x.useCallback(() => {
                s && Ve({
                    url: s.url,
                    fileName: E()
                })
            }, [s, E]),
            z = x.useCallback(() => {
                var y;
                return (y = N.current) == null ? void 0 : y.getImageData()
            }, []),
            T = x.useCallback(async () => {
                if (window.confirm(i.formatMessage({
                        id: "postReceiverModal.deletePostConfirmation",
                        defaultMessage: "Are you sure you want to delete this post?"
                    }))) try {
                    await we.safeDelete("/share/post/{post_id}", {
                        parameters: {
                            path: {
                                post_id: o.id
                            }
                        }
                    }), f("/", {
                        replace: !0
                    })
                } catch (y) {
                    g.danger(Fe({
                        id: "postReceiverModal.deletePostError",
                        defaultMessage: "Failed to delete the post"
                    }), {
                        toastId: "post_receiver_modal.delete_post_error"
                    })
                }
            }, [o.id, i, g, f]),
            O = p === "inpaint" ? i.formatMessage({
                id: "TjVqYb",
                defaultMessage: "Edit Selection"
            }) : (A = o.text) != null ? A : i.formatMessage({
                id: "htGxHc",
                defaultMessage: "Image"
            }),
            k = x.useCallback(y => {
                y.key === "Escape" && (e(), y.preventDefault())
            }, [e]);
        return x.useEffect(() => (document.addEventListener("keydown", k), () => document.removeEventListener("keydown", k)), [k]), t.jsx(se.Root, {
            isOpen: !0,
            onClose: e,
            testId: "modal-lightbox-post-share",
            shouldIgnoreClickOutside: p === "inpaint",
            children: t.jsx(se.Overlay, {
                children: t.jsxs(se.Content, {
                    size: "fullscreen",
                    removePopoverStyling: !0,
                    className: "grid min-h-0 grid-rows-[auto_minmax(0,1fr)] overflow-hidden",
                    children: [t.jsxs("header", {
                        className: "flex h-14 w-full items-center justify-between gap-2 px-2 md:px-4",
                        children: [t.jsx("div", {
                            className: "flex min-w-0 items-center gap-2",
                            children: r ? t.jsxs(t.Fragment, {
                                children: [t.jsx(b, {
                                    onClick: e,
                                    "aria-label": i.formatMessage(R.close),
                                    children: t.jsx(Ee, {
                                        className: "h-5 w-5"
                                    })
                                }), t.jsx("h2", {
                                    className: "mb-px text-base font-medium",
                                    children: t.jsx(G, P({}, Te.chatGPT))
                                })]
                            }) : t.jsxs(t.Fragment, {
                                children: [t.jsx(b, {
                                    icon: Oe,
                                    onClick: e,
                                    "aria-label": i.formatMessage(R.close)
                                }), t.jsx("h2", {
                                    className: "line-clamp-1 text-base font-medium",
                                    children: O
                                })]
                            })
                        }), t.jsx("div", {
                            className: "flex items-center gap-2",
                            children: p === "inpaint" ? t.jsxs(t.Fragment, {
                                children: [t.jsx(b, {
                                    className: "aspect-square",
                                    icon: Xe,
                                    onClick: u.undoDrawing,
                                    disabled: !u.canUndoDrawing,
                                    "aria-label": i.formatMessage({
                                        id: "OmaTPx",
                                        defaultMessage: "Undo"
                                    })
                                }), t.jsx(b, {
                                    className: "aspect-square",
                                    icon: Ze,
                                    onClick: u.redoDrawing,
                                    disabled: !u.canRedoDrawing,
                                    "aria-label": i.formatMessage({
                                        id: "ZUr4oh",
                                        defaultMessage: "Redo"
                                    })
                                }), t.jsx(b, {
                                    className: "w-auto px-3",
                                    onClick: S,
                                    children: i.formatMessage({
                                        id: "D9xvar",
                                        defaultMessage: "Cancel"
                                    })
                                })]
                            }) : t.jsx(t.Fragment, {
                                children: r ? t.jsxs(t.Fragment, {
                                    children: [t.jsx(b, {
                                        className: "aspect-square",
                                        icon: he,
                                        onClick: F,
                                        "aria-label": i.formatMessage(R.downloadImage)
                                    }), t.jsx(Ie, {
                                        size: "small",
                                        contentAlign: "end",
                                        sideOffset: 4,
                                        triggerButton: t.jsx(b, {
                                            className: "aspect-square",
                                            "aria-label": i.formatMessage(R.moreOptions),
                                            children: t.jsx(ye, {
                                                className: "icon"
                                            })
                                        }),
                                        children: t.jsx(ve.Item, {
                                            icon: ne,
                                            onClick: a,
                                            children: t.jsx(G, P({}, R.reportContent))
                                        })
                                    })]
                                }) : t.jsxs(t.Fragment, {
                                    children: [t.jsx(b, {
                                        className: "aspect-square",
                                        icon: Je,
                                        onClick: _,
                                        "aria-label": i.formatMessage({
                                            id: "pRGwlp",
                                            defaultMessage: "Edit image"
                                        })
                                    }), t.jsx(b, {
                                        className: "aspect-square",
                                        icon: he,
                                        onClick: F,
                                        "aria-label": i.formatMessage(R.downloadImage)
                                    }), t.jsx(b, {
                                        className: "aspect-square",
                                        icon: ne,
                                        onClick: a,
                                        "aria-label": i.formatMessage(R.reportContent)
                                    }), l && t.jsx(b, {
                                        className: "aspect-square",
                                        icon: Ce,
                                        onClick: T,
                                        "aria-label": i.formatMessage({
                                            id: "rzlDpj",
                                            defaultMessage: "Delete post"
                                        })
                                    })]
                                })
                            })
                        })]
                    }), t.jsxs("div", {
                        className: "grid h-full w-full grid-rows-[1fr_auto] items-center overflow-y-auto overscroll-contain",
                        children: [t.jsx("div", {
                            className: "flex h-full w-full items-center justify-center px-4 pb-4",
                            children: s && t.jsxs("div", {
                                className: "relative inline-block max-h-full rounded bg-neutral-100",
                                children: [t.jsx("img", {
                                    src: s.url,
                                    alt: O,
                                    className: "h-full max-h-[70vh] w-auto max-w-full rounded object-contain",
                                    fetchPriority: "high"
                                }), p === "inpaint" && t.jsx(et, {
                                    image: s,
                                    drawingState: u,
                                    drawingCanvasRef: N
                                }), r && t.jsx("div", {
                                    className: "mt-4 flex w-full justify-center",
                                    children: t.jsx(Ae, {
                                        type: "button",
                                        color: "primary",
                                        size: "large",
                                        className: "w-full md:w-auto",
                                        onClick: () => qe(m, {
                                            fallbackScreenHint: "login",
                                            skipLoginModal: !1
                                        }),
                                        children: t.jsx(G, P({}, R.makeImagesOnChatGPTCta))
                                    })
                                })]
                            })
                        }), !r && t.jsx("div", {
                            className: "flex w-full justify-center px-4 pb-8",
                            children: t.jsx("div", {
                                className: "w-full max-w-[768px]",
                                children: t.jsx(mt, {
                                    clientThreadId: d,
                                    currentModelId: c,
                                    onRequestCompletion: n,
                                    onClose: e,
                                    activeImage: s,
                                    currentDrawnShape: u.currentDrawnShape,
                                    getImageData: z,
                                    onCancelInpaint: S
                                })
                            })
                        })]
                    })]
                })
            })
        })
    },
    R = je({
        close: {
            id: "EYLKSm",
            defaultMessage: "Close"
        },
        downloadImage: {
            id: "9DNHka",
            defaultMessage: "Download image"
        },
        makeImagesOnChatGPTCta: {
            id: "8coyYY",
            defaultMessage: "Make images on ChatGPT"
        },
        moreOptions: {
            id: "pAyhm2",
            defaultMessage: "More options"
        },
        reportContent: {
            id: "2gNXdX",
            defaultMessage: "Report content"
        }
    });

function bt(s) {
    "use forget";
    var o, l;
    const e = D.c(7),
        {
            postWithProfile: n,
            clientThreadId: d,
            onClose: c
        } = s;
    if (((o = n.post.attachments[0]) == null ? void 0 : o.kind) === "media_generation") {
        let a;
        return e[0] !== d || e[1] !== c || e[2] !== n ? (a = t.jsx(Ge, {
            children: t.jsx(pt, {
                postWithProfile: n,
                clientThreadId: d,
                onClose: c
            })
        }), e[0] = d, e[1] = c, e[2] = n, e[3] = a) : a = e[3], a
    } else if (((l = n.post.attachments[0]) == null ? void 0 : l.kind) === "message_slice") {
        let a;
        return e[4] !== c || e[5] !== n ? (a = t.jsx(ht, {
            postWithProfile: n,
            onClose: c
        }), e[4] = c, e[5] = n, e[6] = a) : a = e[6], a
    }
    return null
}

function pt(s) {
    "use forget";
    var le;
    const e = D.c(59),
        {
            postWithProfile: n,
            clientThreadId: d,
            onClose: c
        } = s,
        o = ie();
    let l;
    e[0] !== d || e[1] !== o ? (l = ze(o, d), e[0] = d, e[1] = o, e[2] = l) : l = e[2];
    const a = l,
        m = x.useRef(null),
        [i, g] = x.useState(!1),
        {
            post: f
        } = n,
        r = f.attachments[f.attachments.length - 1];
    let p;
    e[3] !== r.asset_pointer || e[4] !== r.id ? (p = (le = r.asset_pointer) != null ? le : ue(r.id), e[3] = r.asset_pointer, e[4] = r.id, e[5] = p) : p = e[5];
    let M;
    e[6] !== r.height || e[7] !== r.url || e[8] !== r.width || e[9] !== p ? (M = {
        url: r.url,
        content_type: me.ImageAssetPointer,
        asset_pointer: p,
        size_bytes: 0,
        width: r.width,
        height: r.height
    }, e[6] = r.height, e[7] = r.url, e[8] = r.width, e[9] = p, e[10] = M) : M = e[10];
    const u = M,
        N = Q(),
        I = Le(),
        E = fe(a.serverId$),
        _ = oe();
    let S;
    e[11] !== I ? (S = w => I.getState().files.find(j => j.tempId === w), e[11] = I, e[12] = S) : S = e[12];
    const F = S,
        z = r.url;
    let T;
    e[13] !== I || e[14] !== F || e[15] !== N || e[16] !== _ ? (T = async w => {
        if (m.current) {
            const j = await m.current,
                v = j ? F(j == null ? void 0 : j.tempId) : null;
            if (v) return v
        }
        return m.current = fetch(w).then(gt).then(j => {
            const v = new File([j], "image.png", {
                    type: "image/png"
                }),
                h = Ue(v);
            return pe.uploadFile(I, h, v, He.Multimodal, [v.type], N, _).then(() => {
                const C = F(h);
                return C && C.status === We.Ready && C.fileId ? C : null
            })
        }), m.current
    }, e[13] = I, e[14] = F, e[15] = N, e[16] = _, e[17] = T) : T = e[17];
    const O = T;
    let k;
    e[18] !== a ? (k = () => ge(a).id, e[18] = a, e[19] = k) : k = e[19];
    const A = fe(k);
    let y;
    e[20] !== o ? (y = Me(), e[20] = o, e[21] = y) : y = e[21];
    const V = !y;
    let U;
    e[22] !== O || e[23] !== z || e[24] !== r.height || e[25] !== r.width ? (U = async w => {
        const j = await O(z);
        if (!j || !j.fileId || !j.fileSpec) return null;
        const v = [{
                content_type: me.ImageAssetPointer,
                asset_pointer: ue(j.fileId),
                size_bytes: j.fileSpec.size,
                width: r.width,
                height: r.height
            }, ...w.content.content_type === ae.MultimodalText || w.content.content_type === ae.Text ? w.content.parts : []],
            h = {
                content_type: ae.MultimodalText,
                parts: v
            };
        return L(P({}, w), {
            content: h
        })
    }, e[22] = O, e[23] = z, e[24] = r.height, e[25] = r.width, e[26] = U) : U = e[26];
    const X = U;
    let H;
    e[27] !== o ? (H = ot(o), e[27] = o, e[28] = H) : H = e[28];
    const Z = H;
    let W;
    e[29] !== X || e[30] !== a || e[31] !== I || e[32] !== V || e[33] !== f.id || e[34] !== Z || e[35] !== _ ? (W = w => {
        if (!w.promptMessage || V) return;
        const j = async () => {
                var C;
                const h = await X(w.promptMessage);
                return h ? L(P({
                    conversation: a
                }, w), {
                    promptMessage: h,
                    extraStreamParams: L(P({}, (C = w.extraStreamParams) != null ? C : {}), {
                        continueFromSharedPostId: f.id
                    })
                }) : null
            },
            v = (h, C) => {
                $e.addError(h, C), _.danger(jt.editImageError, {
                    toastId: "post_receiver_modal.edit_image_error",
                    hasCloseButton: !0
                })
            };
        Z(De(), {
            model: ge(a),
            optimisticMessages: [w.promptMessage, lt("Analyzing")],
            asyncWork: async () => {
                const h = await j();
                return pe.reset(I), h
            },
            lifecycleCallbacks: {
                onOptimisticRenderError: h => v(h, {
                    stage: "optimistic_render"
                }),
                onAsyncWorkError: h => v(h, {
                    stage: "async_work"
                }),
                onCompletionError: h => v(h, {
                    stage: "completion"
                })
            }
        })
    }, e[29] = X, e[30] = a, e[31] = I, e[32] = V, e[33] = f.id, e[34] = Z, e[35] = _, e[36] = W) : W = e[36];
    const J = W;
    let $;
    e[37] !== u.asset_pointer || e[38] !== u.height || e[39] !== u.url || e[40] !== u.width || e[41] !== f.id || e[42] !== E ? ($ = {
        id: f.id,
        archived: !1,
        transformationId: null,
        url: u.url,
        assetPointer: u.asset_pointer,
        thumbnail: null,
        width: u.width,
        height: u.height,
        title: null,
        conversationId: E,
        messageId: f.id
    }, e[37] = u.asset_pointer, e[38] = u.height, e[39] = u.url, e[40] = u.width, e[41] = f.id, e[42] = E, e[43] = $) : $ = e[43];
    const ee = $,
        te = !!f.permissions.can_delete;
    let Y;
    e[44] === Symbol.for("react.memo_cache_sentinel") ? (Y = () => g(!0), e[44] = Y) : Y = e[44];
    let q;
    e[45] !== ee || e[46] !== a.id || e[47] !== A || e[48] !== J || e[49] !== c || e[50] !== f || e[51] !== te ? (q = t.jsx(ft, {
        image: ee,
        onClose: c,
        onRequestCompletion: J,
        clientThreadId: a.id,
        currentModelId: A,
        post: f,
        canDelete: te,
        onOpenReport: Y
    }), e[45] = ee, e[46] = a.id, e[47] = A, e[48] = J, e[49] = c, e[50] = f, e[51] = te, e[52] = q) : q = e[52];
    let B;
    e[53] !== i || e[54] !== f ? (B = i && t.jsx(_e, {
        post: f,
        onClose: () => g(!1)
    }), e[53] = i, e[54] = f, e[55] = B) : B = e[55];
    let K;
    return e[56] !== q || e[57] !== B ? (K = t.jsxs(t.Fragment, {
        children: [q, B]
    }), e[56] = q, e[57] = B, e[58] = K) : K = e[58], K
}

function gt(s) {
    return s.blob()
}

function ht(s) {
    "use forget";
    const e = D.c(12),
        {
            postWithProfile: n,
            onClose: d
        } = s,
        [c, o] = x.useState(!1),
        {
            post: l
        } = n;
    let a;
    e[0] !== d || e[1] !== l ? (a = t.jsx(xt, {
        post: l,
        setIsReportModalOpen: o,
        onClose: d
    }), e[0] = d, e[1] = l, e[2] = a) : a = e[2];
    let m;
    e[3] !== l.attachments ? (m = t.jsx(it, {
        attachments: l.attachments,
        variant: "fullscreen"
    }), e[3] = l.attachments, e[4] = m) : m = e[4];
    let i;
    e[5] !== c || e[6] !== l ? (i = c && t.jsx(_e, {
        post: l,
        onClose: () => o(!1)
    }), e[5] = c, e[6] = l, e[7] = i) : i = e[7];
    let g;
    return e[8] !== a || e[9] !== m || e[10] !== i ? (g = t.jsxs("div", {
        className: "bg-token-bg-primary absolute start-0 end-0 top-0 bottom-0 h-full w-full",
        children: [a, m, i]
    }), e[8] = a, e[9] = m, e[10] = i, e[11] = g) : g = e[11], g
}

function xt(s) {
    "use forget";
    const e = D.c(22),
        {
            post: n,
            setIsReportModalOpen: d,
            onClose: c,
            additionalButtons: o
        } = s,
        l = xe(),
        a = Q(),
        m = oe();
    let i;
    e[0] !== a || e[1] !== l || e[2] !== n.id || e[3] !== m ? (i = async () => {
        if (window.confirm(a.formatMessage({
                id: "postReceiverModal.deletePostConfirmation",
                defaultMessage: "Are you sure you want to delete this post?"
            }))) try {
            await we.safeDelete("/share/post/{post_id}", {
                parameters: {
                    path: {
                        post_id: n.id
                    }
                }
            }), l("/", {
                replace: !0
            })
        } catch (N) {
            m.danger({
                id: "postReceiverModal.deletePostError",
                defaultMessage: "Failed to delete the post",
                description: "Error message for deleting a post"
            }, {
                toastId: "post_receiver_modal.delete_post_error"
            })
        }
    }, e[0] = a, e[1] = l, e[2] = n.id, e[3] = m, e[4] = i) : i = e[4];
    const g = i;
    let f;
    e[5] !== l || e[6] !== c ? (f = t.jsx("div", {
        className: "flex items-center justify-self-start text-start",
        children: t.jsx(dt, {
            onClose: () => {
                c(), l("/", {
                    replace: !0
                })
            }
        })
    }), e[5] = l, e[6] = c, e[7] = f) : f = e[7];
    let r;
    e[8] !== n || e[9] !== d ? (r = t.jsx("div", {
        className: "flex w-full flex-1 flex-col items-center justify-center justify-self-stretch",
        children: t.jsx(ut, {
            areButtonsFullWidth: !0,
            post: n,
            setIsReportModalOpen: d
        })
    }), e[8] = n, e[9] = d, e[10] = r) : r = e[10];
    let p;
    e[11] !== g || e[12] !== a || e[13] !== n.permissions.can_delete ? (p = n.permissions.can_delete && t.jsx(rt, {
        tooltip: a.formatMessage({
            id: "postReceiverModal.deletePost",
            defaultMessage: "Delete"
        }),
        onClick: g,
        children: t.jsx(Ce, {})
    }), e[11] = g, e[12] = a, e[13] = n.permissions.can_delete, e[14] = p) : p = e[14];
    let M;
    e[15] !== o || e[16] !== p ? (M = t.jsxs("div", {
        className: "flex items-center justify-self-end text-end",
        children: [p, o]
    }), e[15] = o, e[16] = p, e[17] = M) : M = e[17];
    let u;
    return e[18] !== f || e[19] !== r || e[20] !== M ? (u = t.jsx(t.Fragment, {
        children: t.jsxs(Ye.div, L(P({
            className: "flex h-16 w-full px-2 sm:px-4"
        }, ct), {
            children: [f, r, M]
        }))
    }), e[18] = f, e[19] = r, e[20] = M, e[21] = u) : u = e[21], u
}

function _e(s) {
    "use forget";
    var g;
    const e = D.c(7),
        {
            post: n,
            onClose: d
        } = s,
        c = ie(),
        {
            data: o
        } = tt(c, de.Post),
        l = Q(),
        a = st(c, l, n.id, de.Post, Be.ChatGPTPost);
    if (o == null) return null;
    const m = "Report ".concat((g = n.text) != null ? g : "Post");
    let i;
    return e[0] !== d || e[1] !== o.header || e[2] !== o.header_explanation || e[3] !== o.reasons || e[4] !== a || e[5] !== m ? (i = t.jsx(at, {
        reasons: o.reasons,
        submitReport: a,
        title: m,
        onClose: d,
        header: o.header,
        subHeader: o.header_explanation
    }), e[0] = d, e[1] = o.header, e[2] = o.header_explanation, e[3] = o.reasons, e[4] = a, e[5] = m, e[6] = i) : i = e[6], i
}

function Ct() {
    "use forget";
    var i;
    const s = D.c(7),
        e = x.useContext(be),
        n = (i = e == null ? void 0 : e.postWithProfile) == null ? void 0 : i.post,
        d = e == null ? void 0 : e.setIsReportModalOpen;
    if (!n || !d) return null;
    let c;
    s[0] === Symbol.for("react.memo_cache_sentinel") ? (c = t.jsx("span", {
        className: "text-token-text-secondary justify-center text-sm leading-tight",
        children: t.jsx(G, {
            id: "e2L5bY",
            defaultMessage: "Content created using ChatGPT"
        })
    }), s[0] = c) : c = s[0];
    let o;
    s[1] === Symbol.for("react.memo_cache_sentinel") ? (o = t.jsx(nt, {
        className: "rounded-full",
        label: "",
        icon: t.jsx(ye, {
            className: "icon-sm"
        })
    }), s[1] = o) : o = s[1];
    let l;
    s[2] !== d ? (l = () => d(!0), s[2] = d, s[3] = l) : l = s[3];
    let a;
    s[4] === Symbol.for("react.memo_cache_sentinel") ? (a = t.jsx(G, {
        id: "jHHbcM",
        defaultMessage: "Flag content as unsafe"
    }), s[4] = a) : a = s[4];
    let m;
    return s[5] !== l ? (m = t.jsxs("div", {
        className: "outline-token-border-default mx-4 flex items-center justify-between gap-2.5 rounded-2xl py-1 ps-4 pe-0.5 outline-1 outline-offset-[-1px]",
        children: [c, t.jsx(Ie, {
            size: "default",
            contentAlign: "end",
            sideOffset: 4,
            triggerButton: o,
            children: t.jsx(ve.Item, {
                icon: ne,
                onClick: l,
                children: a
            })
        })]
    }), s[5] = l, s[6] = m) : m = s[6], m
}

function _t() {
    "use forget";
    var o;
    const s = D.c(2),
        e = x.useContext(be),
        n = (o = e == null ? void 0 : e.postWithProfile) == null ? void 0 : o.post,
        d = e == null ? void 0 : e.setIsReportModalOpen;
    if (!n || !d) return null;
    let c;
    return s[0] !== d ? (c = t.jsx("div", {
        className: "text-token-text-secondary text-sm",
        children: t.jsx(G, {
            id: "iRpGVT",
            defaultMessage: "Content created using ChatGPT. <reportButton>Report</reportButton> if unsafe.",
            values: {
                reportButton: l => t.jsx("button", {
                    className: "text-token-text-primary decoration-token-text-primary underline",
                    onClick: () => {
                        d(!0)
                    },
                    children: l
                })
            }
        })
    }), s[0] = d, s[1] = c) : c = s[1], c
}
const jt = je({
    editImageError: {
        id: "postReceiverModal.editImageError",
        defaultMessage: "Failed to edit the image"
    }
});
export {
    bt as P, _t as S, _e as a, Ct as b
};
//# sourceMappingURL=o67bv4dtwt5l98l7.js.map