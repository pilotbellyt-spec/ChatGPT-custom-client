const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/f3pf2a8japuz6mn5.js", "assets/fg33krlcm0qyi6yw.js", "assets/dnrsdgd1ogs8ssfu.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/ntchvpvpq5wusw4s.js", "assets/ovpdmx71kjznjdh8.js", "assets/c2wfb3iy9wkb85gs.js", "assets/coi95al0vrqe13ds.js", "assets/k15yxxoybkkir2ou.js", "assets/conversation-small-332fs9rk.css", "assets/eafv7vq0yf9bv0fi.js", "assets/f76gy0b8ieo4s693.js", "assets/iwhq2rihp0137gzf.js", "assets/ce3hgmw4iyyhicud.js", "assets/h1j5sazq8s0md41z.js", "assets/comments-plugin-ivzj8m6u.css", "assets/fgxxkkb4il90gii6.js", "assets/jsd0vs4cv2vks3ah.js", "assets/dv2e3o9gddnli9b5.js", "assets/k57uzqpnr7k7r909.js", "assets/nfccle6oyncifphl.js", "assets/hu1bt0oauegdhua6.js", "assets/h1em0bjkpkjv8ykw.js", "assets/b5s349mvbdzayaxi.js", "assets/gy1lpvuoewmzh42c.js", "assets/dbshkzvpochy4889.js", "assets/loeoawlgsw5vcwar.js", "assets/17v8usp0o68l1lsz.js", "assets/l09h2qppleubii6l.js", "assets/bt8940c6l4ej9r7j.js", "assets/e7ytp4eqtgc6bl6p.js", "assets/jed1ux7qibe55pmj.js", "assets/lep2wptoy14cfe2w.js", "assets/dcboyjh87ll7k264.js", "assets/c1lw0j14sexsyj33.js", "assets/jbh6ambg0gcrgcqd.js", "assets/prosemirror-kdtc7ib2.css", "assets/eaak105t3h6pgvs1.js", "assets/o589vqy9dgmjuag5.js", "assets/bx3hw2b03xwysw4n.js", "assets/b2l059fz4znz94nm.js", "assets/gbmggnydp7mcsebl.js", "assets/1r6f1vy5gwgg645w.js", "assets/m77bejnre58pj934.js", "assets/jc2eye6u0uwos0uk.js", "assets/aozfqr1i52mjkof3.js", "assets/owg1rbxotm5jsyn7.js", "assets/mstl8wgfzorpgdoe.js", "assets/f2sn8zvpzei2915e.js", "assets/kfdkis1zwf4ccfgg.js", "assets/ol9d5wxhynx9q2is.js", "assets/mbmcx8v24u1ao1ke.js", "assets/ieglwgr2zyuektzv.js", "assets/deakbbf27g8e7ba0.js", "assets/kwqlokvhsdnnmw9d.js", "assets/kl7c6054usfnqmd4.js", "assets/k97n0y6ba9c9h39c.js", "assets/nbd6wafppmcw1yix.js", "assets/bi6phpick816e345.js", "assets/dqz86fcur874gotm.js", "assets/ebc4iyfg14nu1gw4.js"]))) => i.map(i => d[i]);
var Y = Object.defineProperty;
var w = Object.getOwnPropertySymbols;
var z = Object.prototype.hasOwnProperty,
    K = Object.prototype.propertyIsEnumerable;
var S = (e, n, t) => n in e ? Y(e, n, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : e[n] = t,
    k = (e, n) => {
        for (var t in n || (n = {})) z.call(n, t) && S(e, t, n[t]);
        if (w)
            for (var t of w(n)) K.call(n, t) && S(e, t, n[t]);
        return e
    };
import {
    j as c,
    r as x,
    _ as B,
    e as H,
    f as Z,
    c as Q,
    h as V,
    u as ee
} from "./fg33krlcm0qyi6yw.js";
import {
    O as ne
} from "./o589vqy9dgmjuag5.js";
import {
    Z as te,
    fx as oe,
    dH as se,
    ve as ae,
    hk as s,
    hg as le,
    hj as D,
    hh as ie,
    l as re,
    ca as ce,
    c$ as ue,
    vf as fe,
    qC as A,
    qD as pe,
    vg as G,
    vh as me
} from "./k15yxxoybkkir2ou.js";
import {
    l as h,
    aW as U,
    i9 as de,
    bv as be,
    dv as Ce,
    bh as Ee,
    m as W,
    b as $,
    hv as xe,
    dI as q,
    _ as ge,
    R as he,
    P as M
} from "./dykg4ktvbu3mhmdo.js";
import {
    b as N
} from "./mstl8wgfzorpgdoe.js";
import {
    _ as ye,
    a as Te,
    b as De,
    c as _e,
    u as Oe,
    B as ve,
    d as Le
} from "./f2sn8zvpzei2915e.js";
import {
    u as Ie
} from "./ieglwgr2zyuektzv.js";
import {
    a as we
} from "./coi95al0vrqe13ds.js";
import {
    C as Se
} from "./ce3hgmw4iyyhicud.js";
import {
    u as ke
} from "./l09h2qppleubii6l.js";
import {
    d as Ae
} from "./deakbbf27g8e7ba0.js";
import {
    s as J
} from "./kwqlokvhsdnnmw9d.js";
import {
    d as O
} from "./kl7c6054usfnqmd4.js";
import {
    g as Me
} from "./k97n0y6ba9c9h39c.js";

function Ne({
    zIndexKey: e,
    onClick: n
}) {
    return c.jsx(ne, {
        zIndexKey: e,
        onClick: n,
        className: "bg-gray-50/50 dark:bg-black/50"
    })
}

function Re(e) {
    var n, t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [];
    e && typeof e != "function" ? console.error('react-scroll-to-bottom: First argument passed to "useObserveScrollPosition" must be a function.') : ye(t) || console.error('react-scroll-to-bottom: Second argument passed to "useObserveScrollPosition" must be an array if specified.');
    var o = Te(),
        a = o.observeScrollPosition;
    x.useEffect(function() {
        return e && a(e)
    }, De(n = []).call(n, _e(t), [!e, a]))
}

function je() {
    var e = Oe(),
        n = e.scrollToTop;
    return n
}
const Pe = ({
        onScroll: e
    }) => (Re(({
        scrollTop: n
    }) => {
        e == null || e(n)
    }), null),
    Fe = ({
        shouldScrollToTop: e
    }) => {
        const n = je();
        return x.useEffect(() => {
            e === !0 && n({
                behavior: "smooth"
            })
        }, [e, n]), null
    },
    Be = () => {
        const e = Ie();
        x.useEffect(() => {
            e({
                behavior: "smooth"
            })
        }, [e]);
        const [n] = Le();
        return n ? null : c.jsx("button", {
            onClick: () => e({
                behavior: "smooth"
            }),
            className: "border-token-border-default bg-token-main-surface-primary text-token-text-secondary absolute end-1/2 bottom-5 z-10 flex h-8 w-8 translate-x-1/2 cursor-pointer items-center justify-center rounded-full border bg-clip-padding",
            children: c.jsx(se, {
                className: "icon text-token-text-primary"
            })
        })
    };

function He({
    children: e,
    onScroll: n,
    shouldScrollToTop: t,
    scrollToBottomMode: o = "top",
    isLoading: a = !1,
    header: i,
    height: l = "auto",
    overlay: u,
    hideChildren: p = !1,
    disableScroll: b = !1,
    ref: m,
    onCopy: C
}) {
    const r = c.jsx("div", {
        onCopy: C,
        className: h(p ? "hidden" : "block", l === "auto" ? "h-auto" : "h-full"),
        children: e
    });
    return c.jsxs("section", {
        ref: m,
        className: h("relative flex min-h-0 flex-auto grow flex-col", b && "overflow-hidden"),
        children: [c.jsx(be, {
            children: a && c.jsx(Ne, {
                zIndexKey: "textdocDiffLoadingOverlay"
            })
        }), !b && c.jsxs(ve, {
            followButtonClassName: "hidden",
            initialScrollBehavior: "auto",
            scrollViewClassName: "flex flex-col",
            className: "h-full",
            mode: o,
            children: [i, r, u && c.jsx("div", {
                className: "pointer-events-none w-full flex-1",
                children: u
            }), o === "bottom" && c.jsx(Be, {}), c.jsx(Pe, {
                onScroll: n
            }), c.jsx(Fe, {
                shouldScrollToTop: t
            })]
        }), b && c.jsxs(c.Fragment, {
            children: [i, r, u && c.jsx("div", {
                className: "pointer-events-none h-full w-full",
                children: u
            })]
        })]
    })
}

function Ge({
    className: e,
    children: n
}) {
    return c.jsx("header", {
        className: h(e, "touch:px-2.5 h-header-height flex flex-none items-center justify-between gap-1 px-2"),
        children: n
    })
}

function Ue({
    className: e,
    children: n,
    size: t = "lg",
    bold: o
}) {
    return c.jsx("h2", {
        className: h(e, "text-token-text-primary truncate", o ? "font-bold" : "font-normal", t === "lg" && "text-lg", t === "base" && "text-base"),
        children: n
    })
}
const We = ({
        onClick: e
    }) => {
        const t = U() ? oe : de;
        return c.jsx(te, {
            icon: t,
            onClick: e
        })
    },
    R = e => {
        const {
            r: n,
            g: t,
            b: o
        } = N.toRGBA(N.parse(e));
        return (n * 299 + t * 587 + o * 114) / 1e3 < 125
    },
    _ = ({
        children: e,
        isPreviewingCode: n = !1,
        transitionBackground: t = !1,
        previewBackgroundColor: o = null
    }) => {
        const a = n && o && R(o),
            i = n && o && !R(o);
        return c.jsx("section", {
            className: h("popover flex h-full w-full flex-col", t && "transition-colors", a && "dark", i && "light", n ? "bg-[rgba(249,249,249,1)] dark:bg-[rgba(33,33,33,1)]" : "bg-transparent"),
            style: {
                backgroundColor: n && o ? o : void 0
            },
            children: e
        })
    };
_.Title = Ue;
_.CloseButton = We;
_.Header = Ge;
_.Content = He;
const yn = (e = []) => e.filter(({
        status: n
    }) => n !== ae.DISMISSED),
    j = 775,
    $e = 580,
    qe = 36,
    Je = 18,
    Tn = 24,
    Dn = 16,
    Xe = ({
        numLines: e = 20
    }) => {
        const [{
            width: n
        }, t] = ke(), o = U(), a = n >= j + we ? j : $e, i = o ? Je : qe;
        return c.jsx("div", {
            className: h(Se.document, "mt-4"),
            ref: t,
            style: {
                margin: "0 ".concat(i, "px")
            },
            children: c.jsx("div", {
                style: {
                    width: a
                },
                children: c.jsx(Ce, {
                    lines: e
                })
            })
        })
    },
    Ye = Ee(() => B(() =>
        import ("./f3pf2a8japuz6mn5.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57])).then(e => e.DocumentComposer), {
        loading: ({
            value: e,
            width: n = window.innerWidth
        }) => c.jsx(Xe, {
            numLines: Math.min(Math.ceil(e.length / (n / 8)), 30)
        })
    }),
    _n = e => c.jsx(Ye, k({}, e));
var T = (e => (e.ADDED = "added", e.REMOVED = "removed", e.UNCHANGED = "unchanged", e))(T || {});

function I(e) {
    if (e === "") return 0;
    const n = e.split("\n").length;
    return e.endsWith("\n") ? n - 1 : n
}

function ze(e, n) {
    return Ae(e, n, {
        newlineIsToken: !0
    }).map(o => {
        var a;
        return {
            count: (a = o.count) != null ? a : I(o.value),
            value: o.value,
            type: o.added ? "added" : o.removed ? "removed" : "unchanged"
        }
    })
}

function Ke(e) {
    let n = "";
    for (const {
            type: t,
            value: o
        } of e)(t === "added" || t === "unchanged") && (n += o);
    return n
}

function Ze(e, n) {
    const t = I(n),
        o = en(e, t);
    return {
        changes: ze(o, n),
        numLinesDiffed: t
    }
}

function Qe(e) {
    const n = [...e],
        t = [],
        o = [];
    for (; n.length > 0;) {
        const a = n[n.length - 1];
        if (a.type === T.REMOVED) n.pop(), a.type === T.REMOVED && t.unshift(a);
        else if (a.type === T.ADDED) n.pop(), o.unshift(a);
        else break
    }
    return {
        prunedChanges: [...n, ...o],
        prunedRemovedChanges: t
    }
}

function Ve(e, n) {
    const {
        changes: t,
        numLinesDiffed: o
    } = Ze(e, n), {
        prunedChanges: a,
        prunedRemovedChanges: i
    } = Qe(t), l = Ke(a), u = i.map(b => b.value).join("\n"), p = X(e, o, "start");
    return {
        content: l + u + p,
        numLinesDiffed: I(l)
    }
}

function en(e, n) {
    if (n <= 0) return "";
    let t = 0,
        o = e.length;
    for (let a = 0; a < e.length; a++)
        if (e[a] === "\n" && (t++, t === n)) {
            o = a + 1;
            break
        }
    return e.substring(0, o)
}

function X(e, n, t = "start") {
    if (n <= 0) return e;
    if (t === "start") {
        let l = 0;
        for (let u = 0; u < e.length; u++)
            if (e[u] === "\n" && (l++, l === n)) return e.substring(u + 1);
        return ""
    }
    let o = 0,
        a = -1;
    const i = e.endsWith("\n") ? n + 1 : n;
    for (let l = e.length - 1; l >= 0; l--)
        if (e[l] === "\n" && (o++, o === i)) {
            a = l;
            break
        }
    return a === -1 ? "" : e.substring(0, a + 1)
}

function On(e, n) {
    var u, p;
    const t = (u = e == null ? void 0 : e.type) != null ? u : s.LOADING,
        o = (p = e == null ? void 0 : e.content) != null ? p : "",
        a = le(e);
    if (!D(t) || n == null || !a || !ie(e)) return {
        content: o,
        currentlyStreamingLineIndex: null
    };
    const i = X(o, 1, "end");
    if (i === "") return {
        content: n.content,
        currentlyStreamingLineIndex: 0
    };
    const l = Ve(n.content, i);
    return {
        content: l.content,
        currentlyStreamingLineIndex: l.numLinesDiffed
    }
}

function nn(e) {
    "use forget";
    const n = Q.c(8),
        {
            textdocVersion: t,
            clientThreadId: o
        } = e,
        a = $();
    let i;
    n[0] !== t ? (i = m => t && (m == null ? void 0 : m.lastCanvasAssistantMessageById[t.textdocId]), n[0] = t, n[1] = i) : i = n[1];
    const l = fe(i),
        u = t == null ? void 0 : t.type,
        p = t != null;
    let b;
    return n[2] !== o || n[3] !== a || n[4] !== p || n[5] !== l || n[6] !== u ? (b = m => {
        if (!m.selectedText) return;
        const C = q(o);
        p && C != null && l != null && G(a, {
            type: "copy",
            source: m.source,
            location: "canvas",
            selectedText: m.selectedText,
            messageId: l,
            serverThreadId: C,
            contentType: u != null && D(u) ? "code" : "text",
            productLogOnly: m.productLogOnly
        })
    }, n[2] = o, n[3] = a, n[4] = p, n[5] = l, n[6] = u, n[7] = b) : b = n[7], b
}

function vn({
    textdocVersion: e,
    clientThreadId: n
}) {
    var m;
    const t = H(),
        o = W(),
        [a, i] = x.useState(!1),
        l = re(),
        u = nn({
            textdocVersion: e,
            clientThreadId: n
        }),
        p = x.useRef((m = e == null ? void 0 : e.content) != null ? m : "");
    return x.useEffect(() => {
        var C;
        p.current = (C = e == null ? void 0 : e.content) != null ? C : ""
    }, [e]), {
        handleCopy: C => {
            a || (l(async () => {
                const r = await J(p.current);
                u({
                    source: "mouse",
                    selectedText: r
                }), A.logButtonClick(pe.COPY, {
                    contentLength: r.length,
                    textdocType: e == null ? void 0 : e.type
                });
                let f = {
                    "text/plain": r
                };
                if ((e == null ? void 0 : e.type) === s.DOCUMENT) try {
                    const {
                        markdownToClipboardContent: d
                    } = await B(async () => {
                        const {
                            markdownToClipboardContent: E
                        } = await
                        import ("./nbd6wafppmcw1yix.js");
                        return {
                            markdownToClipboardContent: E
                        }
                    }, __vite__mapDeps([58, 3, 1, 4, 59, 9, 10, 19, 20, 21, 22, 23, 24, 25, 26, 60, 32, 28, 61, 33]));
                    f = d(r, [])
                } catch (d) {
                    A.logError("Error copying rich text", d)
                }
                xe(f, o, C)
            }, 0), i(!0), l(() => i(!1), 2e3))
        },
        Icon: a ? ce : ue,
        copyLabel: t.formatMessage(tn.copy)
    }
}
const tn = Z({
        copy: {
            id: "rbIYfo",
            defaultMessage: "Copy"
        }
    }),
    P = {
        [s.CODE_BASH]: {
            filenameExtension: "sh",
            blobType: "text/x-shellscript"
        },
        [s.CODE_ZSH]: {
            filenameExtension: "zsh",
            blobType: "text/x-shellscript"
        },
        [s.CODE_JAVASCRIPT]: {
            filenameExtension: "js",
            blobType: "application/javascript"
        },
        [s.CODE_TYPESCRIPT]: {
            filenameExtension: "ts",
            blobType: "application/typescript"
        },
        [s.CODE_HTML]: {
            filenameExtension: "html",
            blobType: "text/html"
        },
        [s.CODE_CSS]: {
            filenameExtension: "css",
            blobType: "text/css"
        },
        [s.CODE_PYTHON]: {
            filenameExtension: "py",
            blobType: "text/x-python"
        },
        [s.CODE_JSON]: {
            filenameExtension: "json",
            blobType: "application/json"
        },
        [s.CODE_SQL]: {
            filenameExtension: "sql",
            blobType: "application/sql"
        },
        [s.CODE_GO]: {
            filenameExtension: "go",
            blobType: "text/x-go"
        },
        [s.CODE_YAML]: {
            filenameExtension: "yaml",
            blobType: "application/x-yaml"
        },
        [s.CODE_JAVA]: {
            filenameExtension: "java",
            blobType: "text/x-java-source"
        },
        [s.CODE_RUST]: {
            filenameExtension: "rs",
            blobType: "text/rust"
        },
        [s.CODE_CPP]: {
            filenameExtension: "cpp",
            blobType: "text/x-c++src"
        },
        [s.CODE_SWIFT]: {
            filenameExtension: "swift",
            blobType: "text/swift"
        },
        [s.CODE_PHP]: {
            filenameExtension: "php",
            blobType: "application/x-httpd-php"
        },
        [s.CODE_XML]: {
            filenameExtension: "xml",
            blobType: "application/xml"
        },
        [s.CODE_RUBY]: {
            filenameExtension: "rb",
            blobType: "text/x-ruby"
        },
        [s.CODE_HASKELL]: {
            filenameExtension: "hs",
            blobType: "text/x-haskell"
        },
        [s.CODE_KOTLIN]: {
            filenameExtension: "kt",
            blobType: "text/x-kotlin"
        },
        [s.CODE_CSHARP]: {
            filenameExtension: "cs",
            blobType: "text/x-csharp"
        },
        [s.CODE_C]: {
            filenameExtension: "c",
            blobType: "text/x-csrc"
        },
        [s.CODE_OBJECTIVEC]: {
            filenameExtension: "m",
            blobType: "text/x-objectivec"
        },
        [s.CODE_R]: {
            filenameExtension: "r",
            blobType: "text/plain"
        },
        [s.CODE_LUA]: {
            filenameExtension: "lua",
            blobType: "text/x-lua"
        },
        [s.CODE_DART]: {
            filenameExtension: "dart",
            blobType: "text/x-dart"
        },
        [s.CODE_SCALA]: {
            filenameExtension: "scala",
            blobType: "text/x-scala"
        },
        [s.CODE_PERL]: {
            filenameExtension: "pl",
            blobType: "text/x-perl"
        },
        [s.CODE_COMMONLISP]: {
            filenameExtension: "lisp",
            blobType: "text/x-common-lisp"
        },
        [s.CODE_CLOJURE]: {
            filenameExtension: "clj",
            blobType: "text/x-clojure"
        },
        [s.CODE_OCAML]: {
            filenameExtension: "ml",
            blobType: "text/x-ocaml"
        },
        [s.CODE_POWERSHELL]: {
            filenameExtension: "ps1",
            blobType: "text/x-powershell"
        },
        [s.CODE_VERILOG]: {
            filenameExtension: "v",
            blobType: "text/x-verilog"
        },
        [s.CODE_DOCKERFILE]: {
            filenameExtension: "Dockerfile",
            blobType: "text/x-dockerfile"
        },
        [s.CODE_VUE]: {
            filenameExtension: "vue",
            blobType: "text/x-vue"
        },
        [s.CODE_REACT]: {
            filenameExtension: "jsx",
            blobType: "application/javascript"
        },
        [s.CODE_OTHER]: {
            filenameExtension: "txt",
            blobType: "text/plain"
        },
        [s.DOCUMENT]: {
            filenameExtension: "md",
            blobType: "text/markdown"
        },
        [s.LOADING]: {
            filenameExtension: "txt",
            blobType: "text/plain"
        }
    };
var v, F;

function on() {
    if (F) return v;
    F = 1;
    var e = me(),
        n = e(function(t, o, a) {
            return t + (a ? "_" : "") + o.toLowerCase()
        });
    return v = n, v
}
var sn = on();
const L = V(sn);

function Ln({
    textdocVersion: e,
    clientThreadId: n
}) {
    const t = H(),
        o = W(),
        a = $(),
        i = x.useCallback((r, f) => {
            var g;
            const d = (g = e == null ? void 0 : e.messageId) != null ? g : void 0,
                E = n != null ? q(n) : void 0;
            !E || !d || G(a, {
                source: "mouse",
                type: "download",
                selectedText: r,
                location: "canvas",
                contentType: f,
                messageId: d,
                serverThreadId: E,
                productLogOnly: !0
            })
        }, [n, a, e]),
        l = t.formatMessage({
            id: "canvas.downloadFileError",
            defaultMessage: "Failed to download file. Please try again later."
        }),
        {
            mutate: u,
            isPending: p
        } = ee({
            mutationFn: async ({
                textdocId: r,
                exportType: f
            }) => {
                const d = await he.safePost("/export_doc/canvas", {
                    requestBody: {
                        textdoc_id: r,
                        export_type: f
                    },
                    skipJsonTransform: !0
                });
                if (!d.ok) throw new Error("Failed to download file");
                return d
            },
            onSuccess: async (r, {
                exportType: f
            }) => {
                var y;
                if (!e) return;
                const d = await r.blob(),
                    E = r.headers.get("Content-Disposition"),
                    g = (y = Me(E)) != null ? y : "".concat(L(e.title), ".").concat(f);
                O(d, g)
            },
            onError: r => {
                o.danger(l, {
                    toastId: "textdoc_download_button",
                    loggingTitle: l,
                    loggingDescription: "Failed to download file"
                }), ge.addError(r)
            }
        }),
        b = async r => {
            if (e && e.type !== s.LOADING && e.type === s.DOCUMENT) {
                let f;
                switch (r) {
                    case "md":
                        f = "chatgpt_canvas_md_download";
                        break;
                    case "pdf":
                        f = "chatgpt_canvas_pdf_download";
                        break;
                    case "docx":
                        f = "chatgpt_canvas_docx_download";
                        break
                }
                if (M.logEventWithStatsig("ChatGPT Canvas Download", f), i(e.content, D(e.type) ? "code" : "text"), r === "pdf" || r === "docx") u({
                    textdocId: e.textdocId,
                    exportType: r
                });
                else if (r === "md") {
                    const {
                        filenameExtension: d,
                        blobType: E
                    } = P[e.type], g = await J(e.content), y = new Blob([g], {
                        type: E
                    });
                    O(y, "".concat(L(e.title), ".").concat(d))
                }
            }
        },
        m = () => {
            if (!e) return;
            const {
                filenameExtension: r,
                blobType: f
            } = P[e.type];
            if (e.type === s.LOADING) return;
            M.logEventWithStatsig("ChatGPT Canvas Download", "chatgpt_canvas_code_download", {
                blobType: f
            });
            const d = new Blob([e.content], {
                type: f
            });
            O(d, "".concat(L(e.title), ".").concat(r)), i(e.content, D(e.type) ? "code" : "text")
        },
        C = t.formatMessage({
            id: "canvas.download-button",
            defaultMessage: "Download"
        });
    return {
        handleFileDownload: b,
        handleBlobDownload: m,
        isLoading: p,
        downloadCopyLabel: C,
        isDocument: (e == null ? void 0 : e.type) === s.DOCUMENT
    }
}
export {
    _n as A, _ as C, Xe as D, Ne as L, Tn as M, Dn as S, Ln as a, qe as b, Je as c, j as d, $e as e, yn as f, On as g, nn as h, vn as u
};
//# sourceMappingURL=bxjmpsz2dryfouus.js.map