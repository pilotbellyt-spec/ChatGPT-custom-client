import {
    h as a
} from "./fg33krlcm0qyi6yw.js";
import {
    fj as i
} from "./dykg4ktvbu3mhmdo.js";
import {
    i2 as n
} from "./k15yxxoybkkir2ou.js";
var r, t;

function f() {
    if (t) return r;
    t = 1;
    var u = i(),
        s = n();

    function m(e, o) {
        return e && e.length ? s(e, u(o, 2)) : 0
    }
    return r = m, r
}
var p = f();
const v = a(p);
export {
    v as s
};
//# sourceMappingURL=g8wlcyv24gz22o70.js.map