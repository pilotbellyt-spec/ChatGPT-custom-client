import {
    R as a,
    A as i
} from "./dykg4ktvbu3mhmdo.js";
import {
    f as l
} from "./fg33krlcm0qyi6yw.js";
var t = {};
async function d(e) {
    return a.safePost("/accounts/add_email/begin", {
        requestBody: {
            email: e,
            auth0_client_id: t.AUTH0_CLIENT_ID
        },
        authOption: i.Required
    })
}
async function u(e, r) {
    return a.safePost("/accounts/change_email/verify", {
        requestBody: {
            email: e,
            code: r
        },
        authOption: i.Required
    })
}
async function m(e) {
    return a.safePost("/accounts/change_email/begin", {
        requestBody: {
            email: e,
            auth0_client_id: t.AUTH0_CLIENT_ID
        },
        authOption: i.Required
    })
}
const o = l({
    sendEmailFailure: {
        id: "emailVerify.sendEmailFailure",
        defaultMessage: "Could not send email verification code, please try again later."
    },
    sendEmailFailureInvalidEmail: {
        id: "emailVerify.invalidEmail",
        defaultMessage: 'The email address "{email}" is not formatted correctly.'
    },
    sendEmailFailureInvalidEmailEmpty: {
        id: "emailVerify.invalidEmailEmpty",
        defaultMessage: "Please enter a valid email address to continue."
    },
    sendEmailFailureRateLimited: {
        id: "emailVerify.sendEmailFailure.rateLimited",
        defaultMessage: "You've sent too many requests. Please try again later."
    },
    verifyOtpFailure: {
        id: "emailVerify.verifyOtpFailure",
        defaultMessage: "Something went wrong, please try again later."
    },
    verifyOtpFailureInvalidOtp: {
        id: "emailVerify.verifyOtpFailure.invalidOtp",
        defaultMessage: "The code you entered is invalid. Please try again."
    },
    verifyOtpFailureInvalidFormat: {
        id: "emailVerify.verifyOtpFailure.invalidFormat",
        defaultMessage: "The code you entered is formatted incorrectly."
    },
    verifyOtpFailureEmailAlreadyLinked: {
        id: "emailVerify.verifyOtpFailure.emailAlreadyLinked",
        defaultMessage: '{branch, select, email {"{emailValue}"} other {Your email}} is already linked to another account.'
    },
    verifyOtpFailureRateLimited: {
        id: "emailVerify.verifyOtpFailure.rateLimited",
        defaultMessage: "You've sent too many requests. Please try again later."
    },
    verifyOtpSuccess: {
        id: "emailVerify.verifyOtpSuccess",
        defaultMessage: "Email confirmed."
    }
});
export {
    d as a, u as b, m as c, o as m
};
//# sourceMappingURL=mqaxq6uz189xwrrs.js.map