import {
    c as g,
    j as d
} from "./fg33krlcm0qyi6yw.js";
import {
    gd as R,
    rB as c,
    e2 as m
} from "./dykg4ktvbu3mhmdo.js";
import {
    C as x
} from "./i5kvudettvxsr7pw.js";
const h = p => {
    "use forget";
    const e = g.c(15),
        {
            messages: s,
            conversation: u
        } = p;
    let t, r, a, n, l, o;
    if (e[0] !== u || e[1] !== s) {
        o = Symbol.for("react.early_return_sentinel");
        e: {
            const f = R(s);
            if (!f) {
                o = null;
                break e
            }
            t = x,
            r = 0,
            a = u,
            n = c(m.Assistant, [], f),
            l = c(m.Assistant, [], f)
        }
        e[0] = u, e[1] = s, e[2] = t, e[3] = r, e[4] = a, e[5] = n, e[6] = l, e[7] = o
    } else t = e[2], r = e[3], a = e[4], n = e[5], l = e[6], o = e[7];
    if (o !== Symbol.for("react.early_return_sentinel")) return o;
    let i;
    return e[8] !== t || e[9] !== s || e[10] !== r || e[11] !== a || e[12] !== n || e[13] !== l ? (i = d.jsx(t, {
        turnIndex: r,
        conversation: a,
        groupedMessagesToRender: n,
        allGroupedMessages: l,
        allMessages: s,
        isUserTurn: !1,
        isFinalUserTurn: !1,
        isFinalAssistantTurn: !1,
        isCompletionRequestInProgress: !1,
        isFeedbackEnabled: !1,
        isFinalTurn: !1,
        hasActiveRequest: !1,
        onRequestCompletion: M,
        renderingView: "share-modal"
    }), e[8] = t, e[9] = s, e[10] = r, e[11] = a, e[12] = n, e[13] = l, e[14] = i) : i = e[14], i
};

function M() {}
export {
    h as R
};
//# sourceMappingURL=iji59gix74v3k54p.js.map