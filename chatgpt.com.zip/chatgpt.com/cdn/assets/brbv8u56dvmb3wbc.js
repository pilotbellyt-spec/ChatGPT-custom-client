const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/fktq24fk6qxc39of.js", "assets/fg33krlcm0qyi6yw.js"]))) => i.map(i => d[i]);
var en = Object.defineProperty,
    tn = Object.defineProperties;
var nn = Object.getOwnPropertyDescriptors;
var ct = Object.getOwnPropertySymbols;
var sn = Object.prototype.hasOwnProperty,
    on = Object.prototype.propertyIsEnumerable;
var lt = (t, e, n) => e in t ? en(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : t[e] = n,
    A = (t, e) => {
        for (var n in e || (e = {})) sn.call(e, n) && lt(t, n, e[n]);
        if (ct)
            for (var n of ct(e)) on.call(e, n) && lt(t, n, e[n]);
        return t
    },
    V = (t, e) => tn(t, nn(e));
import {
    h as rn,
    r as d,
    k as rt,
    _ as an,
    c as Y,
    j as p,
    M as je,
    e as it
} from "./fg33krlcm0qyi6yw.js";
import {
    CD as cn,
    CE as ln,
    ii as un,
    eN as fn,
    BZ as dn,
    CF as hn,
    bA as mn,
    jb as pn,
    v2 as gn,
    Ak as _n,
    nq as bn,
    aC as xn,
    jc as vn,
    g1 as yn
} from "./k15yxxoybkkir2ou.js";
import {
    u as Mn
} from "./u9jpwxvw30u3h6nc.js";
import {
    AT as wn,
    kd as Sn,
    il as Cn,
    J as En,
    d9 as Dt,
    l as ue,
    bg as jn,
    a9 as ke,
    bb as Rn,
    T as Nn,
    gt as kn,
    eh as Tn,
    lC as Pn,
    fD as Ln,
    bI as Bt,
    hA as An,
    iw as zn,
    nm as Fn,
    dB as In,
    b as Ot,
    d as et,
    xk as Dn,
    eW as Bn,
    ku as On,
    dL as Un,
    fe as $n,
    o as ut,
    qt as Hn,
    aK as tt,
    hg as Wn
} from "./dykg4ktvbu3mhmdo.js";
import {
    M as Ut
} from "./kx34yg3blv92o8xp.js";
const G = 1e-6;
let Se = typeof Float32Array < "u" ? Float32Array : Array;

function qn() {
    const t = new Se(2);
    return Se != Float32Array && (t[0] = 0, t[1] = 0), t
}

function ft(t, e, n) {
    return t[0] = e[0] + n[0], t[1] = e[1] + n[1], t
}

function Zn(t, e) {
    return t[0] = -e[0], t[1] = -e[1], t
}

function $t(t, e, n, s) {
    const o = e[0],
        r = e[1];
    return t[0] = o + s * (n[0] - o), t[1] = r + s * (n[1] - r), t
}(function() {
    const t = qn();
    return function(e, n, s, o, r, i) {
        let a, c;
        for (n || (n = 2), s || (s = 0), o ? c = Math.min(o * n + s, e.length) : c = e.length, a = s; a < c; a += n) t[0] = e[a], t[1] = e[a + 1], r(t, t, i), e[a] = t[0], e[a + 1] = t[1];
        return e
    }
})();

function Vn() {
    const t = new Se(3);
    return Se != Float32Array && (t[0] = 0, t[1] = 0, t[2] = 0), t
}

function Gn(t, e, n) {
    return t[0] = e[0] + n[0], t[1] = e[1] + n[1], t[2] = e[2] + n[2], t
}

function Xn(t, e, n) {
    return t[0] = e[0] * n[0], t[1] = e[1] * n[1], t[2] = e[2] * n[2], t
}

function Yn(t, e) {
    return t[0] = -e[0], t[1] = -e[1], t[2] = -e[2], t
}
const Kn = Xn;
(function() {
    const t = Vn();
    return function(e, n, s, o, r, i) {
        let a, c;
        for (n || (n = 3), s || (s = 0), o ? c = Math.min(o * n + s, e.length) : c = e.length, a = s; a < c; a += n) t[0] = e[a], t[1] = e[a + 1], t[2] = e[a + 2], r(t, t, i), e[a] = t[0], e[a + 1] = t[1], e[a + 2] = t[2];
        return e
    }
})();

function Jn(t, e) {
    const n = e[0],
        s = e[1],
        o = e[2],
        r = e[3],
        i = e[4],
        a = e[5],
        c = e[6],
        l = e[7],
        u = e[8],
        f = e[9],
        g = e[10],
        _ = e[11],
        y = e[12],
        M = e[13],
        x = e[14],
        b = e[15],
        w = n * a - s * i,
        m = n * c - o * i,
        h = n * l - r * i,
        v = s * c - o * a,
        S = s * l - r * a,
        R = o * l - r * c,
        E = u * M - f * y,
        k = u * x - g * y,
        T = u * b - _ * y,
        N = f * x - g * M,
        j = f * b - _ * M,
        P = g * b - _ * x;
    let C = w * P - m * j + h * N + v * T - S * k + R * E;
    return C ? (C = 1 / C, t[0] = (a * P - c * j + l * N) * C, t[1] = (o * j - s * P - r * N) * C, t[2] = (M * R - x * S + b * v) * C, t[3] = (g * S - f * R - _ * v) * C, t[4] = (c * T - i * P - l * k) * C, t[5] = (n * P - o * T + r * k) * C, t[6] = (x * h - y * R - b * m) * C, t[7] = (u * R - g * h + _ * m) * C, t[8] = (i * j - a * T + l * E) * C, t[9] = (s * T - n * j - r * E) * C, t[10] = (y * S - M * h + b * w) * C, t[11] = (f * h - u * S - _ * w) * C, t[12] = (a * k - i * N - c * E) * C, t[13] = (n * N - s * k + o * E) * C, t[14] = (M * m - y * v - x * w) * C, t[15] = (u * v - f * m + g * w) * C, t) : null
}

function Ge(t, e, n) {
    const s = e[0],
        o = e[1],
        r = e[2],
        i = e[3],
        a = e[4],
        c = e[5],
        l = e[6],
        u = e[7],
        f = e[8],
        g = e[9],
        _ = e[10],
        y = e[11],
        M = e[12],
        x = e[13],
        b = e[14],
        w = e[15];
    let m = n[0],
        h = n[1],
        v = n[2],
        S = n[3];
    return t[0] = m * s + h * a + v * f + S * M, t[1] = m * o + h * c + v * g + S * x, t[2] = m * r + h * l + v * _ + S * b, t[3] = m * i + h * u + v * y + S * w, m = n[4], h = n[5], v = n[6], S = n[7], t[4] = m * s + h * a + v * f + S * M, t[5] = m * o + h * c + v * g + S * x, t[6] = m * r + h * l + v * _ + S * b, t[7] = m * i + h * u + v * y + S * w, m = n[8], h = n[9], v = n[10], S = n[11], t[8] = m * s + h * a + v * f + S * M, t[9] = m * o + h * c + v * g + S * x, t[10] = m * r + h * l + v * _ + S * b, t[11] = m * i + h * u + v * y + S * w, m = n[12], h = n[13], v = n[14], S = n[15], t[12] = m * s + h * a + v * f + S * M, t[13] = m * o + h * c + v * g + S * x, t[14] = m * r + h * l + v * _ + S * b, t[15] = m * i + h * u + v * y + S * w, t
}

function nt(t, e, n) {
    const s = n[0],
        o = n[1],
        r = n[2];
    let i, a, c, l, u, f, g, _, y, M, x, b;
    return e === t ? (t[12] = e[0] * s + e[4] * o + e[8] * r + e[12], t[13] = e[1] * s + e[5] * o + e[9] * r + e[13], t[14] = e[2] * s + e[6] * o + e[10] * r + e[14], t[15] = e[3] * s + e[7] * o + e[11] * r + e[15]) : (i = e[0], a = e[1], c = e[2], l = e[3], u = e[4], f = e[5], g = e[6], _ = e[7], y = e[8], M = e[9], x = e[10], b = e[11], t[0] = i, t[1] = a, t[2] = c, t[3] = l, t[4] = u, t[5] = f, t[6] = g, t[7] = _, t[8] = y, t[9] = M, t[10] = x, t[11] = b, t[12] = i * s + u * o + y * r + e[12], t[13] = a * s + f * o + M * r + e[13], t[14] = c * s + g * o + x * r + e[14], t[15] = l * s + _ * o + b * r + e[15]), t
}

function Ht(t, e, n) {
    const s = n[0],
        o = n[1],
        r = n[2];
    return t[0] = e[0] * s, t[1] = e[1] * s, t[2] = e[2] * s, t[3] = e[3] * s, t[4] = e[4] * o, t[5] = e[5] * o, t[6] = e[6] * o, t[7] = e[7] * o, t[8] = e[8] * r, t[9] = e[9] * r, t[10] = e[10] * r, t[11] = e[11] * r, t[12] = e[12], t[13] = e[13], t[14] = e[14], t[15] = e[15], t
}

function Qn(t, e, n) {
    const s = Math.sin(n),
        o = Math.cos(n),
        r = e[4],
        i = e[5],
        a = e[6],
        c = e[7],
        l = e[8],
        u = e[9],
        f = e[10],
        g = e[11];
    return e !== t && (t[0] = e[0], t[1] = e[1], t[2] = e[2], t[3] = e[3], t[12] = e[12], t[13] = e[13], t[14] = e[14], t[15] = e[15]), t[4] = r * o + l * s, t[5] = i * o + u * s, t[6] = a * o + f * s, t[7] = c * o + g * s, t[8] = l * o - r * s, t[9] = u * o - i * s, t[10] = f * o - a * s, t[11] = g * o - c * s, t
}

function es(t, e, n) {
    const s = Math.sin(n),
        o = Math.cos(n),
        r = e[0],
        i = e[1],
        a = e[2],
        c = e[3],
        l = e[4],
        u = e[5],
        f = e[6],
        g = e[7];
    return e !== t && (t[8] = e[8], t[9] = e[9], t[10] = e[10], t[11] = e[11], t[12] = e[12], t[13] = e[13], t[14] = e[14], t[15] = e[15]), t[0] = r * o + l * s, t[1] = i * o + u * s, t[2] = a * o + f * s, t[3] = c * o + g * s, t[4] = l * o - r * s, t[5] = u * o - i * s, t[6] = f * o - a * s, t[7] = g * o - c * s, t
}

function ts(t, e, n, s, o) {
    const r = 1 / Math.tan(e / 2);
    if (t[0] = r / n, t[1] = 0, t[2] = 0, t[3] = 0, t[4] = 0, t[5] = r, t[6] = 0, t[7] = 0, t[8] = 0, t[9] = 0, t[11] = -1, t[12] = 0, t[13] = 0, t[15] = 0, o != null && o !== 1 / 0) {
        const i = 1 / (s - o);
        t[10] = (o + s) * i, t[14] = 2 * o * s * i
    } else t[10] = -1, t[14] = -2 * s;
    return t
}
const ns = ts;

function dt(t, e) {
    const n = t[0],
        s = t[1],
        o = t[2],
        r = t[3],
        i = t[4],
        a = t[5],
        c = t[6],
        l = t[7],
        u = t[8],
        f = t[9],
        g = t[10],
        _ = t[11],
        y = t[12],
        M = t[13],
        x = t[14],
        b = t[15],
        w = e[0],
        m = e[1],
        h = e[2],
        v = e[3],
        S = e[4],
        R = e[5],
        E = e[6],
        k = e[7],
        T = e[8],
        N = e[9],
        j = e[10],
        P = e[11],
        C = e[12],
        z = e[13],
        $ = e[14],
        X = e[15];
    return Math.abs(n - w) <= G * Math.max(1, Math.abs(n), Math.abs(w)) && Math.abs(s - m) <= G * Math.max(1, Math.abs(s), Math.abs(m)) && Math.abs(o - h) <= G * Math.max(1, Math.abs(o), Math.abs(h)) && Math.abs(r - v) <= G * Math.max(1, Math.abs(r), Math.abs(v)) && Math.abs(i - S) <= G * Math.max(1, Math.abs(i), Math.abs(S)) && Math.abs(a - R) <= G * Math.max(1, Math.abs(a), Math.abs(R)) && Math.abs(c - E) <= G * Math.max(1, Math.abs(c), Math.abs(E)) && Math.abs(l - k) <= G * Math.max(1, Math.abs(l), Math.abs(k)) && Math.abs(u - T) <= G * Math.max(1, Math.abs(u), Math.abs(T)) && Math.abs(f - N) <= G * Math.max(1, Math.abs(f), Math.abs(N)) && Math.abs(g - j) <= G * Math.max(1, Math.abs(g), Math.abs(j)) && Math.abs(_ - P) <= G * Math.max(1, Math.abs(_), Math.abs(P)) && Math.abs(y - C) <= G * Math.max(1, Math.abs(y), Math.abs(C)) && Math.abs(M - z) <= G * Math.max(1, Math.abs(M), Math.abs(z)) && Math.abs(x - $) <= G * Math.max(1, Math.abs(x), Math.abs($)) && Math.abs(b - X) <= G * Math.max(1, Math.abs(b), Math.abs(X))
}

function ss() {
    const t = new Se(4);
    return Se != Float32Array && (t[0] = 0, t[1] = 0, t[2] = 0, t[3] = 0), t
}

function os(t, e, n) {
    return t[0] = e[0] * n, t[1] = e[1] * n, t[2] = e[2] * n, t[3] = e[3] * n, t
}

function rs(t, e, n) {
    const s = e[0],
        o = e[1],
        r = e[2],
        i = e[3];
    return t[0] = n[0] * s + n[4] * o + n[8] * r + n[12] * i, t[1] = n[1] * s + n[5] * o + n[9] * r + n[13] * i, t[2] = n[2] * s + n[6] * o + n[10] * r + n[14] * i, t[3] = n[3] * s + n[7] * o + n[11] * r + n[15] * i, t
}(function() {
    const t = ss();
    return function(e, n, s, o, r, i) {
        let a, c;
        for (n || (n = 4), s || (s = 0), o ? c = Math.min(o * n + s, e.length) : c = e.length, a = s; a < c; a += n) t[0] = e[a], t[1] = e[a + 1], t[2] = e[a + 2], t[3] = e[a + 3], r(t, t, i), e[a] = t[0], e[a + 1] = t[1], e[a + 2] = t[2], e[a + 3] = t[3];
        return e
    }
})();

function Be() {
    return [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]
}

function we(t, e) {
    const n = rs([], e, t);
    return os(n, n, 1 / n[3]), n
}

function st(t, e, n) {
    return t < e ? e : t > n ? n : t
}

function is(t) {
    return Math.log(t) * Math.LOG2E
}
const as = Math.log2 || is;

function fe(t, e) {
    if (!t) throw new Error(e || "@math.gl/web-mercator: assertion failed.")
}
const ne = Math.PI,
    Wt = ne / 4,
    se = ne / 180,
    ot = 180 / ne,
    Ne = 512,
    ht = 4003e4,
    De = 85.051129,
    qt = 1.5;

function cs(t) {
    return Math.pow(2, t)
}

function Me(t) {
    const [e, n] = t;
    fe(Number.isFinite(e)), fe(Number.isFinite(n) && n >= -90 && n <= 90, "invalid latitude");
    const s = e * se,
        o = n * se,
        r = Ne * (s + ne) / (2 * ne),
        i = Ne * (ne + Math.log(Math.tan(Wt + o * .5))) / (2 * ne);
    return [r, i]
}

function Re(t) {
    const [e, n] = t, s = e / Ne * (2 * ne) - ne, o = 2 * (Math.atan(Math.exp(n / Ne * (2 * ne) - ne)) - Wt);
    return [s * ot, o * ot]
}

function ls(t) {
    const {
        latitude: e,
        longitude: n,
        highPrecision: s = !1
    } = t;
    fe(Number.isFinite(e) && Number.isFinite(n));
    const o = Ne,
        r = Math.cos(e * se),
        i = o / 360,
        a = i / r,
        c = o / ht / r,
        l = {
            unitsPerMeter: [c, c, c],
            metersPerUnit: [1 / c, 1 / c, 1 / c],
            unitsPerDegree: [i, a, c],
            degreesPerUnit: [1 / i, 1 / a, 1 / c]
        };
    if (s) {
        const u = se * Math.tan(e * se) / r,
            f = i * u / 2,
            g = o / ht * u,
            _ = g / a * c;
        l.unitsPerDegree2 = [0, f, g], l.unitsPerMeter2 = [_, 0, _]
    }
    return l
}

function us(t) {
    const {
        height: e,
        pitch: n,
        bearing: s,
        altitude: o,
        scale: r,
        center: i
    } = t, a = Be();
    nt(a, a, [0, 0, -o]), Qn(a, a, -n * se), es(a, a, s * se);
    const c = r / e;
    return Ht(a, a, [c, c, c]), i && nt(a, a, Yn([], i)), a
}

function fs(t) {
    const {
        width: e,
        height: n,
        altitude: s,
        pitch: o = 0,
        offset: r,
        center: i,
        scale: a,
        nearZMultiplier: c = 1,
        farZMultiplier: l = 1
    } = t;
    let {
        fovy: u = Oe(qt)
    } = t;
    s !== void 0 && (u = Oe(s));
    const f = u * se,
        g = o * se,
        _ = Zt(u);
    let y = _;
    i && (y += i[2] * a / Math.cos(g) / n);
    const M = f * (.5 + (r ? r[1] : 0) / n),
        x = Math.sin(M) * y / Math.sin(st(Math.PI / 2 - g - M, .01, Math.PI - .01)),
        b = Math.sin(g) * x + y,
        w = y * 10,
        m = Math.min(b * l, w);
    return {
        fov: f,
        aspect: e / n,
        focalDistance: _,
        near: c,
        far: m
    }
}

function ds(t) {
    const {
        fov: e,
        aspect: n,
        near: s,
        far: o
    } = fs(t);
    return ns([], e, n, s, o)
}

function Oe(t) {
    return 2 * Math.atan(.5 / t) * ot
}

function Zt(t) {
    return .5 / Math.tan(.5 * t * se)
}

function hs(t, e) {
    const [n, s, o = 0] = t;
    return fe(Number.isFinite(n) && Number.isFinite(s) && Number.isFinite(o)), we(e, [n, s, o, 1])
}

function mt(t, e, n = 0) {
    const [s, o, r] = t;
    if (fe(Number.isFinite(s) && Number.isFinite(o), "invalid pixel coordinate"), Number.isFinite(r)) return we(e, [s, o, r, 1]);
    const i = we(e, [s, o, 0, 1]),
        a = we(e, [s, o, 1, 1]),
        c = i[2],
        l = a[2],
        u = c === l ? 0 : ((n || 0) - c) / (l - c);
    return $t([], i, a, u)
}

function ms(t) {
    const {
        width: e,
        height: n,
        bounds: s,
        minExtent: o = 0,
        maxZoom: r = 24,
        offset: i = [0, 0]
    } = t, [
        [a, c],
        [l, u]
    ] = s, f = ps(t.padding), g = Me([a, st(u, -De, De)]), _ = Me([l, st(c, -De, De)]), y = [Math.max(Math.abs(_[0] - g[0]), o), Math.max(Math.abs(_[1] - g[1]), o)], M = [e - f.left - f.right - Math.abs(i[0]) * 2, n - f.top - f.bottom - Math.abs(i[1]) * 2];
    fe(M[0] > 0 && M[1] > 0);
    const x = M[0] / y[0],
        b = M[1] / y[1],
        w = (f.right - f.left) / 2 / x,
        m = (f.top - f.bottom) / 2 / b,
        h = [(_[0] + g[0]) / 2 + w, (_[1] + g[1]) / 2 + m],
        v = Re(h),
        S = Math.min(r, as(Math.abs(Math.min(x, b))));
    return fe(Number.isFinite(S)), {
        longitude: v[0],
        latitude: v[1],
        zoom: S
    }
}

function ps(t = 0) {
    return typeof t == "number" ? {
        top: t,
        bottom: t,
        left: t,
        right: t
    } : (fe(Number.isFinite(t.top) && Number.isFinite(t.bottom) && Number.isFinite(t.left) && Number.isFinite(t.right)), t)
}
const pt = Math.PI / 180;

function gs(t, e = 0) {
    const {
        width: n,
        height: s,
        unproject: o
    } = t, r = {
        targetZ: e
    }, i = o([0, s], r), a = o([n, s], r);
    let c, l;
    const u = t.fovy ? .5 * t.fovy * pt : Math.atan(.5 / t.altitude),
        f = (90 - t.pitch) * pt;
    return u > f - .01 ? (c = gt(t, 0, e), l = gt(t, n, e)) : (c = o([0, 0], r), l = o([n, 0], r)), [i, a, l, c]
}

function gt(t, e, n) {
    const {
        pixelUnprojectionMatrix: s
    } = t, o = we(s, [e, 0, 1, 1]), r = we(s, [e, t.height, 1, 1]), a = (n * t.distanceScales.unitsPerMeter[2] - o[2]) / (r[2] - o[2]), c = $t([], o, r, a), l = Re(c);
    return l.push(n), l
}
class Ue {
    constructor(e = {
        width: 1,
        height: 1
    }) {
        this.equals = b => b instanceof Ue ? b.width === this.width && b.height === this.height && dt(b.projectionMatrix, this.projectionMatrix) && dt(b.viewMatrix, this.viewMatrix) : !1, this.project = (b, w = {}) => {
            const {
                topLeft: m = !0
            } = w, h = this.projectPosition(b), v = hs(h, this.pixelProjectionMatrix), [S, R] = v, E = m ? R : this.height - R;
            return b.length === 2 ? [S, E] : [S, E, v[2]]
        }, this.unproject = (b, w = {}) => {
            const {
                topLeft: m = !0,
                targetZ: h = void 0
            } = w, [v, S, R] = b, E = m ? S : this.height - S, k = h && h * this.distanceScales.unitsPerMeter[2], T = mt([v, E, R], this.pixelUnprojectionMatrix, k), [N, j, P] = this.unprojectPosition(T);
            return Number.isFinite(R) ? [N, j, P] : Number.isFinite(h) ? [N, j, h] : [N, j]
        }, this.projectPosition = b => {
            const [w, m] = Me(b), h = (b[2] || 0) * this.distanceScales.unitsPerMeter[2];
            return [w, m, h]
        }, this.unprojectPosition = b => {
            const [w, m] = Re(b), h = (b[2] || 0) * this.distanceScales.metersPerUnit[2];
            return [w, m, h]
        };
        let {
            width: n,
            height: s,
            altitude: o = null,
            fovy: r = null
        } = e;
        const {
            latitude: i = 0,
            longitude: a = 0,
            zoom: c = 0,
            pitch: l = 0,
            bearing: u = 0,
            position: f = null,
            nearZMultiplier: g = .02,
            farZMultiplier: _ = 1.01
        } = e;
        n = n || 1, s = s || 1, r === null && o === null ? (o = qt, r = Oe(o)) : r === null ? r = Oe(o) : o === null && (o = Zt(r));
        const y = cs(c);
        o = Math.max(.75, o);
        const M = ls({
                longitude: a,
                latitude: i
            }),
            x = Me([a, i]);
        x.push(0), f && Gn(x, x, Kn([], f, M.unitsPerMeter)), this.projectionMatrix = ds({
            width: n,
            height: s,
            scale: y,
            center: x,
            pitch: l,
            fovy: r,
            nearZMultiplier: g,
            farZMultiplier: _
        }), this.viewMatrix = us({
            height: s,
            scale: y,
            center: x,
            pitch: l,
            bearing: u,
            altitude: o
        }), this.width = n, this.height = s, this.scale = y, this.latitude = i, this.longitude = a, this.zoom = c, this.pitch = l, this.bearing = u, this.altitude = o, this.fovy = r, this.center = x, this.meterOffset = f || [0, 0, 0], this.distanceScales = M, this._initMatrices(), Object.freeze(this)
    }
    _initMatrices() {
        const {
            width: e,
            height: n,
            projectionMatrix: s,
            viewMatrix: o
        } = this, r = Be();
        Ge(r, r, s), Ge(r, r, o), this.viewProjectionMatrix = r;
        const i = Be();
        Ht(i, i, [e / 2, -n / 2, 1]), nt(i, i, [1, -1, 0]), Ge(i, i, r);
        const a = Jn(Be(), i);
        if (!a) throw new Error("Pixel project matrix not invertible");
        this.pixelProjectionMatrix = i, this.pixelUnprojectionMatrix = a
    }
    projectFlat(e) {
        return Me(e)
    }
    unprojectFlat(e) {
        return Re(e)
    }
    getMapCenterByLngLatPosition({
        lngLat: e,
        pos: n
    }) {
        const s = mt(n, this.pixelUnprojectionMatrix),
            o = Me(e),
            r = ft([], o, Zn([], s)),
            i = ft([], this.center, r);
        return Re(i)
    }
    fitBounds(e, n = {}) {
        const {
            width: s,
            height: o
        } = this, {
            longitude: r,
            latitude: i,
            zoom: a
        } = ms(Object.assign({
            width: s,
            height: o,
            bounds: e
        }, n));
        return new Ue({
            width: s,
            height: o,
            longitude: r,
            latitude: i,
            zoom: a
        })
    }
    getBounds(e) {
        const n = this.getBoundingRegion(e),
            s = Math.min(...n.map(a => a[0])),
            o = Math.max(...n.map(a => a[0])),
            r = Math.min(...n.map(a => a[1])),
            i = Math.max(...n.map(a => a[1]));
        return [
            [s, r],
            [o, i]
        ]
    }
    getBoundingRegion(e = {}) {
        return gs(this, e.z || 0)
    }
    getLocationAtPoint({
        lngLat: e,
        pos: n
    }) {
        return this.getMapCenterByLngLatPosition({
            lngLat: e,
            pos: n
        })
    }
}

function _s(t, e, n = {}) {
    const s = {
        type: "Feature"
    };
    return (n.id === 0 || n.id) && (s.id = n.id), n.bbox && (s.bbox = n.bbox), s.properties = e || {}, s.geometry = t, s
}

function Vt(t, e, n = {}) {
    if (!t) throw new Error("coordinates is required");
    if (!Array.isArray(t)) throw new Error("coordinates must be an Array");
    if (t.length < 2) throw new Error("coordinates must be at least 2 numbers long");
    if (!_t(t[0]) || !_t(t[1])) throw new Error("coordinates must contain numbers");
    return _s({
        type: "Point",
        coordinates: t
    }, e, n)
}

function bs(t, e = {}) {
    const n = {
        type: "FeatureCollection"
    };
    return e.id && (n.id = e.id), e.bbox && (n.bbox = e.bbox), n.features = t, n
}

function _t(t) {
    return !isNaN(t) && t !== null && !Array.isArray(t)
}

function Gt(t, e, n) {
    if (t !== null)
        for (var s, o, r, i, a, c, l, u = 0, f = 0, g, _ = t.type, y = _ === "FeatureCollection", M = _ === "Feature", x = y ? t.features.length : 1, b = 0; b < x; b++) {
            l = y ? t.features[b].geometry : M ? t.geometry : t, g = l ? l.type === "GeometryCollection" : !1, a = g ? l.geometries.length : 1;
            for (var w = 0; w < a; w++) {
                var m = 0,
                    h = 0;
                if (i = g ? l.geometries[w] : l, i !== null) {
                    c = i.coordinates;
                    var v = i.type;
                    switch (u = 0, v) {
                        case null:
                            break;
                        case "Point":
                            if (e(c, f, b, m, h) === !1) return !1;
                            f++, m++;
                            break;
                        case "LineString":
                        case "MultiPoint":
                            for (s = 0; s < c.length; s++) {
                                if (e(c[s], f, b, m, h) === !1) return !1;
                                f++, v === "MultiPoint" && m++
                            }
                            v === "LineString" && m++;
                            break;
                        case "Polygon":
                        case "MultiLineString":
                            for (s = 0; s < c.length; s++) {
                                for (o = 0; o < c[s].length - u; o++) {
                                    if (e(c[s][o], f, b, m, h) === !1) return !1;
                                    f++
                                }
                                v === "MultiLineString" && m++, v === "Polygon" && h++
                            }
                            v === "Polygon" && m++;
                            break;
                        case "MultiPolygon":
                            for (s = 0; s < c.length; s++) {
                                for (h = 0, o = 0; o < c[s].length; o++) {
                                    for (r = 0; r < c[s][o].length - u; r++) {
                                        if (e(c[s][o][r], f, b, m, h) === !1) return !1;
                                        f++
                                    }
                                    h++
                                }
                                m++
                            }
                            break;
                        case "GeometryCollection":
                            for (s = 0; s < i.geometries.length; s++)
                                if (Gt(i.geometries[s], e) === !1) return !1;
                            break;
                        default:
                            throw new Error("Unknown Geometry Type")
                    }
                }
            }
        }
}

function Xt(t, e = {}) {
    if (t.bbox != null && e.recompute !== !0) return t.bbox;
    const n = [1 / 0, 1 / 0, -1 / 0, -1 / 0];
    return Gt(t, s => {
        n[0] > s[0] && (n[0] = s[0]), n[1] > s[1] && (n[1] = s[1]), n[2] < s[0] && (n[2] = s[0]), n[3] < s[1] && (n[3] = s[1])
    }), n
}
var xs = Xt;

function vs(t, e = {}) {
    const n = Xt(t),
        s = (n[0] + n[2]) / 2,
        o = (n[1] + n[3]) / 2;
    return Vt([s, o], e.properties, e)
}
var ys = vs,
    Xe, bt;

function Ms() {
    if (bt) return Xe;
    bt = 1;
    var t = wn(),
        e = Sn(),
        n = Cn(),
        s = En(),
        o = t.isFinite,
        r = Math.min;

    function i(a) {
        var c = Math[a];
        return function(l, u) {
            if (l = n(l), u = u == null ? 0 : r(e(u), 292), u && o(l)) {
                var f = (s(l) + "e").split("e"),
                    g = c(f[0] + "e" + (+f[1] + u));
                return f = (s(g) + "e").split("e"), +(f[0] + "e" + (+f[1] - u))
            }
            return c(l)
        }
    }
    return Xe = i, Xe
}
var Ye, xt;

function ws() {
    if (xt) return Ye;
    xt = 1;
    var t = Ms(),
        e = t("round");
    return Ye = e, Ye
}
var Ss = ws();
const le = rn(Ss),
    Cs = d.createContext(null);

function Es(t, e) {
    const n = Array.isArray(t) ? t[0] : t ? t.x : 0,
        s = Array.isArray(t) ? t[1] : t ? t.y : 0,
        o = Array.isArray(e) ? e[0] : e ? e.x : 0,
        r = Array.isArray(e) ? e[1] : e ? e.y : 0;
    return n === o && s === r
}

function ie(t, e) {
    if (t === e) return !0;
    if (!t || !e) return !1;
    if (Array.isArray(t)) {
        if (!Array.isArray(e) || t.length !== e.length) return !1;
        for (let n = 0; n < t.length; n++)
            if (!ie(t[n], e[n])) return !1;
        return !0
    } else if (Array.isArray(e)) return !1;
    if (typeof t == "object" && typeof e == "object") {
        const n = Object.keys(t),
            s = Object.keys(e);
        if (n.length !== s.length) return !1;
        for (const o of n)
            if (!e.hasOwnProperty(o) || !ie(t[o], e[o])) return !1;
        return !0
    }
    return !1
}

function js(t) {
    const e = t.clone();
    return e.pixelsToGLUnits = t.pixelsToGLUnits, e
}

function vt(t, e) {
    if (!t.getProjection) return;
    const n = t.getProjection(),
        s = e.getProjection();
    ie(n, s) || e.setProjection(n)
}

function yt(t) {
    return {
        longitude: t.center.lng,
        latitude: t.center.lat,
        zoom: t.zoom,
        pitch: t.pitch,
        bearing: t.bearing,
        padding: t.padding
    }
}

function Mt(t, e) {
    const n = e.viewState || e;
    let s = !1;
    if ("longitude" in n && "latitude" in n) {
        const o = t.center;
        t.center = new o.constructor(n.longitude, n.latitude), s = s || o !== t.center
    }
    if ("zoom" in n) {
        const o = t.zoom;
        t.zoom = n.zoom, s = s || o !== t.zoom
    }
    if ("bearing" in n) {
        const o = t.bearing;
        t.bearing = n.bearing, s = s || o !== t.bearing
    }
    if ("pitch" in n) {
        const o = t.pitch;
        t.pitch = n.pitch, s = s || o !== t.pitch
    }
    return n.padding && !t.isPaddingEqual(n.padding) && (s = !0, t.padding = n.padding), s
}
const Rs = ["type", "source", "source-layer", "minzoom", "maxzoom", "filter", "layout"];

function wt(t) {
    if (!t) return null;
    if (typeof t == "string" || ("toJS" in t && (t = t.toJS()), !t.layers)) return t;
    const e = {};
    for (const s of t.layers) e[s.id] = s;
    const n = t.layers.map(s => {
        let o = null;
        "interactive" in s && (o = Object.assign({}, s), delete o.interactive);
        const r = e[s.ref];
        if (r) {
            o = o || Object.assign({}, s), delete o.ref;
            for (const i of Rs) i in r && (o[i] = r[i])
        }
        return o || s
    });
    return V(A({}, t), {
        layers: n
    })
}
var St = {};
const Ct = {
        version: 8,
        sources: {},
        layers: []
    },
    Et = {
        mousedown: "onMouseDown",
        mouseup: "onMouseUp",
        mouseover: "onMouseOver",
        mousemove: "onMouseMove",
        click: "onClick",
        dblclick: "onDblClick",
        mouseenter: "onMouseEnter",
        mouseleave: "onMouseLeave",
        mouseout: "onMouseOut",
        contextmenu: "onContextMenu",
        touchstart: "onTouchStart",
        touchend: "onTouchEnd",
        touchmove: "onTouchMove",
        touchcancel: "onTouchCancel"
    },
    Ke = {
        movestart: "onMoveStart",
        move: "onMove",
        moveend: "onMoveEnd",
        dragstart: "onDragStart",
        drag: "onDrag",
        dragend: "onDragEnd",
        zoomstart: "onZoomStart",
        zoom: "onZoom",
        zoomend: "onZoomEnd",
        rotatestart: "onRotateStart",
        rotate: "onRotate",
        rotateend: "onRotateEnd",
        pitchstart: "onPitchStart",
        pitch: "onPitch",
        pitchend: "onPitchEnd"
    },
    jt = {
        wheel: "onWheel",
        boxzoomstart: "onBoxZoomStart",
        boxzoomend: "onBoxZoomEnd",
        boxzoomcancel: "onBoxZoomCancel",
        resize: "onResize",
        load: "onLoad",
        render: "onRender",
        idle: "onIdle",
        remove: "onRemove",
        data: "onData",
        styledata: "onStyleData",
        sourcedata: "onSourceData",
        error: "onError"
    },
    Ns = ["minZoom", "maxZoom", "minPitch", "maxPitch", "maxBounds", "projection", "renderWorldCopies"],
    ks = ["scrollZoom", "boxZoom", "dragRotate", "dragPan", "keyboard", "doubleClickZoom", "touchZoomRotate", "touchPitch"];
class Ce {
    constructor(e, n, s) {
        this._map = null, this._internalUpdate = !1, this._inRender = !1, this._hoveredFeatures = null, this._deferredEvents = {
            move: !1,
            zoom: !1,
            pitch: !1,
            rotate: !1
        }, this._onEvent = o => {
            const r = this.props[jt[o.type]];
            r ? r(o) : o.type === "error" && console.error(o.error)
        }, this._onPointerEvent = o => {
            (o.type === "mousemove" || o.type === "mouseout") && this._updateHover(o);
            const r = this.props[Et[o.type]];
            r && (this.props.interactiveLayerIds && o.type !== "mouseover" && o.type !== "mouseout" && (o.features = this._hoveredFeatures || this._queryRenderedFeatures(o.point)), r(o), delete o.features)
        }, this._onCameraEvent = o => {
            if (!this._internalUpdate) {
                const r = this.props[Ke[o.type]];
                r && r(o)
            }
            o.type in this._deferredEvents && (this._deferredEvents[o.type] = !1)
        }, this._MapClass = e, this.props = n, this._initialize(s)
    }
    get map() {
        return this._map
    }
    get transform() {
        return this._renderTransform
    }
    setProps(e) {
        const n = this.props;
        this.props = e;
        const s = this._updateSettings(e, n);
        s && this._createShadowTransform(this._map);
        const o = this._updateSize(e),
            r = this._updateViewState(e, !0);
        this._updateStyle(e, n), this._updateStyleComponents(e, n), this._updateHandlers(e, n), (s || o || r && !this._map.isMoving()) && this.redraw()
    }
    static reuse(e, n) {
        const s = Ce.savedMaps.pop();
        if (!s) return null;
        const o = s.map,
            r = o.getContainer();
        for (n.className = r.className; r.childNodes.length > 0;) n.appendChild(r.childNodes[0]);
        o._container = n;
        const i = o._resizeObserver;
        i && (i.disconnect(), i.observe(n)), s.setProps(V(A({}, e), {
            styleDiffing: !1
        })), o.resize();
        const {
            initialViewState: a
        } = e;
        return a && (a.bounds ? o.fitBounds(a.bounds, V(A({}, a.fitBoundsOptions), {
            duration: 0
        })) : s._updateViewState(a, !1)), o.isStyleLoaded() ? o.fire("load") : o.once("styledata", () => o.fire("load")), o._update(), s
    }
    _initialize(e) {
        const {
            props: n
        } = this, {
            mapStyle: s = Ct
        } = n, o = V(A(A({}, n), n.initialViewState), {
            accessToken: n.mapboxAccessToken || Ts() || null,
            container: e,
            style: wt(s)
        }), r = o.initialViewState || o.viewState || o;
        if (Object.assign(o, {
                center: [r.longitude || 0, r.latitude || 0],
                zoom: r.zoom || 0,
                pitch: r.pitch || 0,
                bearing: r.bearing || 0
            }), n.gl) {
            const u = HTMLCanvasElement.prototype.getContext;
            HTMLCanvasElement.prototype.getContext = () => (HTMLCanvasElement.prototype.getContext = u, n.gl)
        }
        const i = new this._MapClass(o);
        r.padding && i.setPadding(r.padding), n.cursor && (i.getCanvas().style.cursor = n.cursor), this._createShadowTransform(i);
        const a = i._render;
        i._render = u => {
            this._inRender = !0, a.call(i, u), this._inRender = !1
        };
        const c = i._renderTaskQueue.run;
        i._renderTaskQueue.run = u => {
            c.call(i._renderTaskQueue, u), this._onBeforeRepaint()
        }, i.on("render", () => this._onAfterRepaint());
        const l = i.fire;
        i.fire = this._fireEvent.bind(this, l), i.on("resize", () => {
            this._renderTransform.resize(i.transform.width, i.transform.height)
        }), i.on("styledata", () => {
            this._updateStyleComponents(this.props, {}), vt(i.transform, this._renderTransform)
        }), i.on("sourcedata", () => this._updateStyleComponents(this.props, {}));
        for (const u in Et) i.on(u, this._onPointerEvent);
        for (const u in Ke) i.on(u, this._onCameraEvent);
        for (const u in jt) i.on(u, this._onEvent);
        this._map = i
    }
    recycle() {
        const n = this.map.getContainer().querySelector("[mapboxgl-children]");
        n == null || n.remove(), Ce.savedMaps.push(this)
    }
    destroy() {
        this._map.remove()
    }
    redraw() {
        const e = this._map;
        !this._inRender && e.style && (e._frame && (e._frame.cancel(), e._frame = null), e._render())
    }
    _createShadowTransform(e) {
        const n = js(e.transform);
        e.painter.transform = n, this._renderTransform = n
    }
    _updateSize(e) {
        const {
            viewState: n
        } = e;
        if (n) {
            const s = this._map;
            if (n.width !== s.transform.width || n.height !== s.transform.height) return s.resize(), !0
        }
        return !1
    }
    _updateViewState(e, n) {
        if (this._internalUpdate) return !1;
        const s = this._map,
            o = this._renderTransform,
            {
                zoom: r,
                pitch: i,
                bearing: a
            } = o,
            c = s.isMoving();
        c && (o.cameraElevationReference = "sea");
        const l = Mt(o, A(A({}, yt(s.transform)), e));
        if (c && (o.cameraElevationReference = "ground"), l && n) {
            const u = this._deferredEvents;
            u.move = !0, u.zoom || (u.zoom = r !== o.zoom), u.rotate || (u.rotate = a !== o.bearing), u.pitch || (u.pitch = i !== o.pitch)
        }
        return c || Mt(s.transform, e), l
    }
    _updateSettings(e, n) {
        const s = this._map;
        let o = !1;
        for (const r of Ns)
            if (r in e && !ie(e[r], n[r])) {
                o = !0;
                const i = s["set".concat(r[0].toUpperCase()).concat(r.slice(1))];
                i == null || i.call(s, e[r])
            }
        return o
    }
    _updateStyle(e, n) {
        if (e.cursor !== n.cursor && (this._map.getCanvas().style.cursor = e.cursor || ""), e.mapStyle !== n.mapStyle) {
            const {
                mapStyle: s = Ct,
                styleDiffing: o = !0
            } = e, r = {
                diff: o
            };
            return "localIdeographFontFamily" in e && (r.localIdeographFontFamily = e.localIdeographFontFamily), this._map.setStyle(wt(s), r), !0
        }
        return !1
    }
    _updateStyleComponents(e, n) {
        const s = this._map;
        let o = !1;
        return s.isStyleLoaded() && ("light" in e && s.setLight && !ie(e.light, n.light) && (o = !0, s.setLight(e.light)), "fog" in e && s.setFog && !ie(e.fog, n.fog) && (o = !0, s.setFog(e.fog)), "terrain" in e && s.setTerrain && !ie(e.terrain, n.terrain) && (!e.terrain || s.getSource(e.terrain.source)) && (o = !0, s.setTerrain(e.terrain))), o
    }
    _updateHandlers(e, n) {
        var s, o;
        const r = this._map;
        let i = !1;
        for (const a of ks) {
            const c = (s = e[a]) !== null && s !== void 0 ? s : !0,
                l = (o = n[a]) !== null && o !== void 0 ? o : !0;
            ie(c, l) || (i = !0, c ? r[a].enable(c) : r[a].disable())
        }
        return i
    }
    _queryRenderedFeatures(e) {
        const n = this._map,
            s = n.transform,
            {
                interactiveLayerIds: o = []
            } = this.props;
        try {
            return n.transform = this._renderTransform, n.queryRenderedFeatures(e, {
                layers: o.filter(n.getLayer.bind(n))
            })
        } catch (r) {
            return []
        } finally {
            n.transform = s
        }
    }
    _updateHover(e) {
        var n;
        const {
            props: s
        } = this;
        if (s.interactiveLayerIds && (s.onMouseMove || s.onMouseEnter || s.onMouseLeave)) {
            const r = e.type,
                i = ((n = this._hoveredFeatures) === null || n === void 0 ? void 0 : n.length) > 0,
                a = this._queryRenderedFeatures(e.point),
                c = a.length > 0;
            !c && i && (e.type = "mouseleave", this._onPointerEvent(e)), this._hoveredFeatures = a, c && !i && (e.type = "mouseenter", this._onPointerEvent(e)), e.type = r
        } else this._hoveredFeatures = null
    }
    _fireEvent(e, n, s) {
        const o = this._map,
            r = o.transform,
            i = typeof n == "string" ? n : n.type;
        return i === "move" && this._updateViewState(this.props, !1), i in Ke && (typeof n == "object" && (n.viewState = yt(r)), this._map.isMoving()) ? (o.transform = this._renderTransform, e.call(o, n, s), o.transform = r, o) : (e.call(o, n, s), o)
    }
    _onBeforeRepaint() {
        const e = this._map;
        this._internalUpdate = !0;
        for (const s in this._deferredEvents) this._deferredEvents[s] && e.fire(s);
        this._internalUpdate = !1;
        const n = this._map.transform;
        e.transform = this._renderTransform, this._onAfterRepaint = () => {
            vt(this._renderTransform, n), e.transform = n
        }
    }
}
Ce.savedMaps = [];

function Ts() {
    let t = null;
    if (typeof location < "u") {
        const e = /access_token=([^&\/]*)/.exec(location.search);
        t = e && e[1]
    }
    try {
        t = t || St.MapboxAccessToken
    } catch (e) {}
    try {
        t = t || St.REACT_APP_MAPBOX_ACCESS_TOKEN
    } catch (e) {}
    return t
}
const Ps = ["setMaxBounds", "setMinZoom", "setMaxZoom", "setMinPitch", "setMaxPitch", "setRenderWorldCopies", "setProjection", "setStyle", "addSource", "removeSource", "addLayer", "removeLayer", "setLayerZoomRange", "setFilter", "setPaintProperty", "setLayoutProperty", "setLight", "setTerrain", "setFog", "remove"];

function Ls(t) {
    if (!t) return null;
    const e = t.map,
        n = {
            getMap: () => e,
            getCenter: () => t.transform.center,
            getZoom: () => t.transform.zoom,
            getBearing: () => t.transform.bearing,
            getPitch: () => t.transform.pitch,
            getPadding: () => t.transform.padding,
            getBounds: () => t.transform.getBounds(),
            project: s => {
                const o = e.transform;
                e.transform = t.transform;
                const r = e.project(s);
                return e.transform = o, r
            },
            unproject: s => {
                const o = e.transform;
                e.transform = t.transform;
                const r = e.unproject(s);
                return e.transform = o, r
            },
            queryTerrainElevation: (s, o) => {
                const r = e.transform;
                e.transform = t.transform;
                const i = e.queryTerrainElevation(s, o);
                return e.transform = r, i
            },
            queryRenderedFeatures: (s, o) => {
                const r = e.transform;
                e.transform = t.transform;
                const i = e.queryRenderedFeatures(s, o);
                return e.transform = r, i
            }
        };
    for (const s of As(e)) !(s in n) && !Ps.includes(s) && (n[s] = e[s].bind(e));
    return n
}

function As(t) {
    const e = new Set;
    let n = t;
    for (; n;) {
        for (const s of Object.getOwnPropertyNames(n)) s[0] !== "_" && typeof t[s] == "function" && s !== "fire" && s !== "setEventedParent" && e.add(s);
        n = Object.getPrototypeOf(n)
    }
    return Array.from(e)
}
const zs = typeof document < "u" ? d.useLayoutEffect : d.useEffect,
    Fs = ["baseApiUrl", "maxParallelImageRequests", "workerClass", "workerCount", "workerUrl"];

function Is(t, e) {
    for (const s of Fs) s in e && (t[s] = e[s]);
    const {
        RTLTextPlugin: n = "https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-rtl-text/v0.2.3/mapbox-gl-rtl-text.js"
    } = e;
    n && t.getRTLTextPluginStatus && t.getRTLTextPluginStatus() === "unavailable" && t.setRTLTextPlugin(n, s => {
        s && console.error(s)
    }, !0)
}
const $e = d.createContext(null);

function Ds(t, e, n) {
    const s = d.useContext(Cs),
        [o, r] = d.useState(null),
        i = d.useRef(),
        {
            current: a
        } = d.useRef({
            mapLib: null,
            map: null
        });
    d.useEffect(() => {
        const u = t.mapLib;
        let f = !0,
            g;
        return Promise.resolve(u || n).then(_ => {
            if (!f) return;
            if (!_) throw new Error("Invalid mapLib");
            const y = "Map" in _ ? _ : _.default;
            if (!y.Map) throw new Error("Invalid mapLib");
            if (Is(y, t), !y.supported || y.supported(t)) t.reuseMaps && (g = Ce.reuse(t, i.current)), g || (g = new Ce(y.Map, t, i.current)), a.map = Ls(g), a.mapLib = y, r(g), s == null || s.onMapMount(a.map, t.id);
            else throw new Error("Map is not supported by this browser")
        }).catch(_ => {
            const {
                onError: y
            } = t;
            y ? y({
                type: "error",
                target: null,
                originalEvent: null,
                error: _
            }) : console.error(_)
        }), () => {
            f = !1, g && (s == null || s.onMapUnmount(t.id), t.reuseMaps ? g.recycle() : g.destroy())
        }
    }, []), zs(() => {
        o && o.setProps(t)
    }), d.useImperativeHandle(e, () => a.map, [o]);
    const c = d.useMemo(() => A({
            position: "relative",
            width: "100%",
            height: "100%"
        }, t.style), [t.style]),
        l = {
            height: "100%"
        };
    return d.createElement("div", {
        id: t.id,
        ref: i,
        style: c
    }, o && d.createElement($e.Provider, {
        value: a
    }, d.createElement("div", {
        "mapboxgl-children": "",
        style: l
    }, t.children)))
}
const Bs = /box|flex|grid|column|lineHeight|fontWeight|opacity|order|tabSize|zIndex/;

function me(t, e) {
    if (!t || !e) return;
    const n = t.style;
    for (const s in e) {
        const o = e[s];
        Number.isFinite(o) && !Bs.test(s) ? n[s] = "".concat(o, "px") : n[s] = o
    }
}

function Os(t, e) {
    const {
        map: n,
        mapLib: s
    } = d.useContext($e), o = d.useRef({
        props: t
    });
    o.current.props = t;
    const r = d.useMemo(() => {
        let M = !1;
        d.Children.forEach(t.children, w => {
            w && (M = !0)
        });
        const x = V(A({}, t), {
                element: M ? document.createElement("div") : null
            }),
            b = new s.Marker(x);
        return b.setLngLat([t.longitude, t.latitude]), b.getElement().addEventListener("click", w => {
            var m, h;
            (h = (m = o.current.props).onClick) === null || h === void 0 || h.call(m, {
                type: "click",
                target: b,
                originalEvent: w
            })
        }), b.on("dragstart", w => {
            var m, h;
            const v = w;
            v.lngLat = r.getLngLat(), (h = (m = o.current.props).onDragStart) === null || h === void 0 || h.call(m, v)
        }), b.on("drag", w => {
            var m, h;
            const v = w;
            v.lngLat = r.getLngLat(), (h = (m = o.current.props).onDrag) === null || h === void 0 || h.call(m, v)
        }), b.on("dragend", w => {
            var m, h;
            const v = w;
            v.lngLat = r.getLngLat(), (h = (m = o.current.props).onDragEnd) === null || h === void 0 || h.call(m, v)
        }), b
    }, []);
    d.useEffect(() => (r.addTo(n.getMap()), () => {
        r.remove()
    }), []);
    const {
        longitude: i,
        latitude: a,
        offset: c,
        style: l,
        draggable: u = !1,
        popup: f = null,
        rotation: g = 0,
        rotationAlignment: _ = "auto",
        pitchAlignment: y = "auto"
    } = t;
    return d.useEffect(() => {
        me(r.getElement(), l)
    }, [l]), d.useImperativeHandle(e, () => r, []), (r.getLngLat().lng !== i || r.getLngLat().lat !== a) && r.setLngLat([i, a]), c && !Es(r.getOffset(), c) && r.setOffset(c), r.isDraggable() !== u && r.setDraggable(u), r.getRotation() !== g && r.setRotation(g), r.getRotationAlignment() !== _ && r.setRotationAlignment(_), r.getPitchAlignment() !== y && r.setPitchAlignment(y), r.getPopup() !== f && r.setPopup(f), rt.createPortal(t.children, r.getElement())
}
const Us = d.memo(d.forwardRef(Os));

function Rt(t) {
    return new Set(t ? t.trim().split(/\s+/) : [])
}

function $s(t, e) {
    const {
        map: n,
        mapLib: s
    } = d.useContext($e), o = d.useMemo(() => document.createElement("div"), []), r = d.useRef({
        props: t
    });
    r.current.props = t;
    const i = d.useMemo(() => {
        const a = A({}, t),
            c = new s.Popup(a);
        return c.setLngLat([t.longitude, t.latitude]), c.once("open", l => {
            var u, f;
            (f = (u = r.current.props).onOpen) === null || f === void 0 || f.call(u, l)
        }), c
    }, []);
    if (d.useEffect(() => {
            const a = c => {
                var l, u;
                (u = (l = r.current.props).onClose) === null || u === void 0 || u.call(l, c)
            };
            return i.on("close", a), i.setDOMContent(o).addTo(n.getMap()), () => {
                i.off("close", a), i.isOpen() && i.remove()
            }
        }, []), d.useEffect(() => {
            me(i.getElement(), t.style)
        }, [t.style]), d.useImperativeHandle(e, () => i, []), i.isOpen() && ((i.getLngLat().lng !== t.longitude || i.getLngLat().lat !== t.latitude) && i.setLngLat([t.longitude, t.latitude]), t.offset && !ie(i.options.offset, t.offset) && i.setOffset(t.offset), (i.options.anchor !== t.anchor || i.options.maxWidth !== t.maxWidth) && (i.options.anchor = t.anchor, i.setMaxWidth(t.maxWidth)), i.options.className !== t.className)) {
        const a = Rt(i.options.className),
            c = Rt(t.className);
        for (const l of a) c.has(l) || i.removeClassName(l);
        for (const l of c) a.has(l) || i.addClassName(l);
        i.options.className = t.className
    }
    return rt.createPortal(t.children, o)
}
d.memo(d.forwardRef($s));

function Ee(t, e, n, s) {
    const o = d.useContext($e),
        r = d.useMemo(() => t(o), []);
    return d.useEffect(() => {
        const i = e,
            a = null,
            c = typeof e == "function" ? e : null,
            {
                map: l
            } = o;
        return l.hasControl(r) || (l.addControl(r, i == null ? void 0 : i.position), a && a(o)), () => {
            c && c(o), l.hasControl(r) && l.removeControl(r)
        }
    }, []), r
}

function Hs(t) {
    const e = Ee(({
        mapLib: n
    }) => new n.AttributionControl(t), {
        position: t.position
    });
    return d.useEffect(() => {
        me(e._container, t.style)
    }, [t.style]), null
}
d.memo(Hs);

function Ws(t) {
    const e = Ee(({
        mapLib: n
    }) => new n.FullscreenControl({
        container: t.containerId && document.getElementById(t.containerId)
    }), {
        position: t.position
    });
    return d.useEffect(() => {
        me(e._controlContainer, t.style)
    }, [t.style]), null
}
d.memo(Ws);

function qs(t, e) {
    const n = d.useRef({
            props: t
        }),
        s = Ee(({
            mapLib: o
        }) => {
            const r = new o.GeolocateControl(t),
                i = r._setupUI;
            return r._setupUI = a => {
                r._container.hasChildNodes() || i(a)
            }, r.on("geolocate", a => {
                var c, l;
                (l = (c = n.current.props).onGeolocate) === null || l === void 0 || l.call(c, a)
            }), r.on("error", a => {
                var c, l;
                (l = (c = n.current.props).onError) === null || l === void 0 || l.call(c, a)
            }), r.on("outofmaxbounds", a => {
                var c, l;
                (l = (c = n.current.props).onOutOfMaxBounds) === null || l === void 0 || l.call(c, a)
            }), r.on("trackuserlocationstart", a => {
                var c, l;
                (l = (c = n.current.props).onTrackUserLocationStart) === null || l === void 0 || l.call(c, a)
            }), r.on("trackuserlocationend", a => {
                var c, l;
                (l = (c = n.current.props).onTrackUserLocationEnd) === null || l === void 0 || l.call(c, a)
            }), r
        }, {
            position: t.position
        });
    return n.current.props = t, d.useImperativeHandle(e, () => s, []), d.useEffect(() => {
        me(s._container, t.style)
    }, [t.style]), null
}
d.memo(d.forwardRef(qs));

function Zs(t) {
    const e = Ee(({
        mapLib: n
    }) => new n.NavigationControl(t), {
        position: t.position
    });
    return d.useEffect(() => {
        me(e._container, t.style)
    }, [t.style]), null
}
const Vs = d.memo(Zs);

function Gs(t) {
    const e = Ee(({
            mapLib: r
        }) => new r.ScaleControl(t), {
            position: t.position
        }),
        n = d.useRef(t),
        s = n.current;
    n.current = t;
    const {
        style: o
    } = t;
    return t.maxWidth !== void 0 && t.maxWidth !== s.maxWidth && (e.options.maxWidth = t.maxWidth), t.unit !== void 0 && t.unit !== s.unit && e.setUnit(t.unit), d.useEffect(() => {
        me(e._container, o)
    }, [o]), null
}
d.memo(Gs);
const Xs = an(() =>
        import ("./fktq24fk6qxc39of.js").then(t => t.m), __vite__mapDeps([0, 1])),
    Ys = d.forwardRef(function(e, n) {
        return Ds(e, n, Xs)
    }),
    Yt = Us,
    Ks = Vs,
    Js = t => d.createElement("svg", A({
        width: 34,
        height: 34,
        viewBox: "0 0 34 34",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
    }, t), d.createElement("g", {
        filter: "url(#filter0_dd_735_10617)"
    }, d.createElement("path", {
        d: "M17 24C21.9706 24 26 19.9706 26 15C26 10.0294 21.9706 6 17 6C12.0294 6 8 10.0294 8 15C8 19.9706 12.0294 24 17 24Z",
        fill: "#0088FF",
        style: {
            fill: "#0088ff",
            fill: "color(display-p3 0 0.5333 1)",
            fillOpacity: 1
        }
    }), d.createElement("path", {
        d: "M24.5 15C24.5 19.1421 21.1421 22.5 17 22.5C12.8579 22.5 9.5 19.1421 9.5 15C9.5 10.8579 12.8579 7.5 17 7.5C21.1421 7.5 24.5 10.8579 24.5 15Z",
        stroke: "white",
        style: {
            stroke: "white",
            strokeOpacity: 1
        },
        strokeWidth: 3
    })), d.createElement("defs", null, d.createElement("filter", {
        id: "filter0_dd_735_10617",
        x: 0,
        y: 0,
        width: 34,
        height: 34,
        filterUnits: "userSpaceOnUse",
        colorInterpolationFilters: "sRGB"
    }, d.createElement("feFlood", {
        floodOpacity: 0,
        result: "BackgroundImageFix"
    }), d.createElement("feColorMatrix", { in: "SourceAlpha",
        type: "matrix",
        values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
        result: "hardAlpha"
    }), d.createElement("feOffset", {
        dy: 2
    }), d.createElement("feGaussianBlur", {
        stdDeviation: 4
    }), d.createElement("feComposite", {
        in2: "hardAlpha",
        operator: "out"
    }), d.createElement("feColorMatrix", {
        type: "matrix",
        values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0"
    }), d.createElement("feBlend", {
        mode: "normal",
        in2: "BackgroundImageFix",
        result: "effect1_dropShadow_735_10617"
    }), d.createElement("feColorMatrix", { in: "SourceAlpha",
        type: "matrix",
        values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
        result: "hardAlpha"
    }), d.createElement("feOffset", {
        dy: 1
    }), d.createElement("feGaussianBlur", {
        stdDeviation: .5
    }), d.createElement("feComposite", {
        in2: "hardAlpha",
        operator: "out"
    }), d.createElement("feColorMatrix", {
        type: "matrix",
        values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.05 0"
    }), d.createElement("feBlend", {
        mode: "normal",
        in2: "effect1_dropShadow_735_10617",
        result: "effect2_dropShadow_735_10617"
    }), d.createElement("feBlend", {
        mode: "normal",
        in: "SourceGraphic",
        in2: "effect2_dropShadow_735_10617",
        result: "shape"
    }))));

function Qs(t) {
    "use forget";
    var de;
    const e = Y.c(64),
        {
            isSelected: n,
            idx: s,
            business: o,
            trackContentReferenceEvent: r,
            onOpenEntity: i,
            enableSidebarNavigation: a,
            showActions: c,
            imageClassName: l,
            onHoverEnter: u,
            onHoverLeave: f
        } = t,
        g = l === void 0 ? "h-23 w-23" : l,
        _ = !Dt();
    let y;
    e[0] !== s ? (y = {
        section: "map",
        section_location: "response",
        section_index: s
    }, e[0] = s, e[1] = y) : y = e[1];
    const M = y,
        x = (de = o.image_urls) == null ? void 0 : de[0],
        b = u != null && f != null;
    let w;
    e[2] === Symbol.for("react.memo_cache_sentinel") ? (w = {
        x: "0%",
        opacity: 0,
        pointerEvents: "none",
        transition: {
            duration: .1,
            ease: "easeOut"
        }
    }, e[2] = w) : w = e[2];
    let m;
    e[3] === Symbol.for("react.memo_cache_sentinel") ? (m = {
        x: "0%",
        opacity: 1,
        pointerEvents: "auto",
        transition: {
            duration: .15,
            ease: "easeOut"
        }
    }, e[3] = m) : m = e[3];
    const h = n ? "bg-token-bg-tertiary" : "bg-token-bg-primary",
        v = b && "hover:bg-token-bg-tertiary";
    let S;
    e[4] !== h || e[5] !== v ? (S = ue("relative border-red-400 text-start font-normal transition-colors duration-300", h, v), e[4] = h, e[5] = v, e[6] = S) : S = e[6];
    const R = b ? u : void 0,
        E = b ? f : void 0,
        k = a && "cursor-pointer";
    let T;
    e[7] !== g || e[8] !== k ? (T = ue("shrink-0 overflow-hidden rounded-lg", g, k), e[7] = g, e[8] = k, e[9] = T) : T = e[9];
    let N;
    e[10] !== a || e[11] !== i ? (N = a ? ae => {
        ae.preventDefault(), i == null || i()
    } : void 0, e[10] = a, e[11] = i, e[12] = N) : N = e[12];
    let j;
    e[13] !== o.name || e[14] !== x ? (j = x ? p.jsx("img", {
        className: "h-full w-full object-cover",
        src: x != null ? x : void 0,
        alt: o.name
    }) : p.jsx("div", {
        className: "h-full w-full bg-gray-100"
    }), e[13] = o.name, e[14] = x, e[15] = j) : j = e[15];
    let P;
    e[16] !== T || e[17] !== N || e[18] !== j ? (P = p.jsx("div", {
        className: T,
        onClick: N,
        children: j
    }), e[16] = T, e[17] = N, e[18] = j, e[19] = P) : P = e[19];
    let C;
    e[20] !== o.name || e[21] !== a || e[22] !== i ? (C = a ? p.jsx("div", {
        className: "hover:entity-accent line-clamp-2 w-full cursor-pointer text-base leading-tight font-medium",
        onClick: ae => {
            ae.preventDefault(), i == null || i()
        },
        title: o.name,
        children: o.name
    }) : p.jsx("div", {
        title: o.name,
        className: "text-token-text-primary line-clamp-2 w-full text-base leading-tight font-medium",
        children: o.name
    }), e[20] = o.name, e[21] = a, e[22] = i, e[23] = C) : C = e[23];
    let z;
    e[24] !== o ? (z = p.jsx(cn, {
        business: o,
        showPrice: !1,
        showHours: !1
    }), e[24] = o, e[25] = z) : z = e[25];
    let $;
    e[26] !== o ? ($ = p.jsx(ln, {
        business: o,
        showHourDetail: !1
    }), e[26] = o, e[27] = $) : $ = e[27];
    let X;
    e[28] === Symbol.for("react.memo_cache_sentinel") ? (X = p.jsx("span", {
        className: "mx-1",
        children: "•"
    }), e[28] = X) : X = e[28];
    let U;
    e[29] !== o.price_str ? (U = o.price_str ? p.jsx("span", {
        children: o.price_str
    }, "price") : null, e[29] = o.price_str, e[30] = U) : U = e[30];
    let W;
    e[31] !== $ || e[32] !== U ? (W = p.jsxs("div", {
        className: "flex",
        children: [$, X, U]
    }), e[31] = $, e[32] = U, e[33] = W) : W = e[33];
    let q;
    e[34] !== z || e[35] !== W ? (q = p.jsxs("div", {
        className: "text-token-text-primary flex flex-col gap-0.5 text-sm",
        children: [z, W]
    }), e[34] = z, e[35] = W, e[36] = q) : q = e[36];
    let F;
    e[37] !== C || e[38] !== q ? (F = p.jsxs("div", {
        className: "flex min-w-0 flex-1 flex-col justify-center gap-0.5",
        children: [C, q]
    }), e[37] = C, e[38] = q, e[39] = F) : F = e[39];
    let L;
    e[40] !== P || e[41] !== F ? (L = p.jsxs("div", {
        className: "flex gap-3",
        children: [P, F]
    }), e[40] = P, e[41] = F, e[42] = L) : L = e[42];
    let Q;
    e[43] !== o || e[44] !== _ || e[45] !== M || e[46] !== c || e[47] !== r ? (Q = !_ && c && p.jsx("div", {
        className: "mt-1",
        children: p.jsx(Nt, {
            business: o,
            trackContentReferenceEvent: r,
            metadata: M
        })
    }), e[43] = o, e[44] = _, e[45] = M, e[46] = c, e[47] = r, e[48] = Q) : Q = e[48];
    let K;
    e[49] !== L || e[50] !== Q ? (K = p.jsxs("div", {
        className: "flex flex-col gap-2 p-3",
        children: [L, Q]
    }), e[49] = L, e[50] = Q, e[51] = K) : K = e[51];
    let J;
    e[52] !== o || e[53] !== _ || e[54] !== M || e[55] !== c || e[56] !== r ? (J = _ && c && p.jsx(Nt, {
        business: o,
        trackContentReferenceEvent: r,
        metadata: M
    }), e[52] = o, e[53] = _, e[54] = M, e[55] = c, e[56] = r, e[57] = J) : J = e[57];
    let oe;
    return e[58] !== K || e[59] !== J || e[60] !== S || e[61] !== R || e[62] !== E ? (oe = p.jsx(jn.div, {
        initial: w,
        animate: m,
        children: p.jsxs("div", {
            className: S,
            onMouseEnter: R,
            onMouseLeave: E,
            children: [K, J]
        })
    }), e[58] = K, e[59] = J, e[60] = S, e[61] = R, e[62] = E, e[63] = oe) : oe = e[63], oe
}

function Nt({
    business: t,
    trackContentReferenceEvent: e,
    metadata: n
}) {
    const s = "https://www.google.com/maps/dir/?api=1&destination=".concat(encodeURIComponent([t.name, t.address].join(",")));
    return t.address && e("link_action", null, "map", V(A({}, n), {
        url: s,
        link_type: "button",
        action: "show"
    })), t.website_url && e("link_action", null, "map", V(A({}, n), {
        url: t.website_url,
        link_type: "button",
        action: "show"
    })), p.jsx(p.Fragment, {
        children: p.jsxs("div", {
            className: "text-token-text-primary mt-auto flex min-h-[30px] w-full min-w-0 flex-wrap justify-center gap-2 text-base",
            children: [t.address && p.jsx(Je, {
                to: s,
                onClick: () => {
                    e("link_action", null, "map", V(A({}, n), {
                        url: s,
                        link_type: "button",
                        action: "click"
                    }))
                },
                children: p.jsx(je, {
                    id: "+a2f/C",
                    defaultMessage: "Directions"
                })
            }), t.website_url && p.jsx(Je, {
                to: t.website_url,
                onClick: () => {
                    e("link_action", null, "map", V(A({}, n), {
                        url: t.website_url,
                        link_type: "button",
                        action: "click"
                    }))
                },
                children: p.jsx(je, {
                    id: "r0oqXM",
                    defaultMessage: "Website"
                })
            }), t.phone && p.jsx(Je, {
                to: "tel:" + t.phone,
                children: p.jsx(je, {
                    id: "B/an6M",
                    defaultMessage: "Call"
                })
            })]
        })
    })
}

function Je(t) {
    "use forget";
    const e = Y.c(4),
        {
            to: n,
            onClick: s,
            children: o
        } = t;
    let r;
    return e[0] !== o || e[1] !== s || e[2] !== n ? (r = p.jsx(ke, {
        onClick: s,
        as: "link",
        to: n,
        openNewTab: !0,
        rel: "noreferrer",
        color: "secondary",
        size: "small",
        className: "h-[30px] min-w-25 flex-1 rounded-full border",
        contentWrapperClassName: "text-token-text-primary font-semibold",
        children: o
    }), e[0] = o, e[1] = s, e[2] = n, e[3] = r) : r = e[3], r
}

function eo(t) {
    "use forget";
    const e = Y.c(40),
        {
            idx: n,
            business: s,
            tooltipContent: o,
            onOpenChange: r,
            isSelected: i,
            isVisible: a,
            isSonicSidebarEnabled: c,
            onClick: l,
            tooltipLocation: u
        } = t,
        f = u === void 0 ? "top" : u,
        g = Rn();
    let _;
    e[0] !== s || e[1] !== i ? (_ = p.jsx(kt, {
        business: s,
        isSelected: i
    }), e[0] = s, e[1] = i, e[2] = _) : _ = e[2];
    const y = a ? 1 : 0;
    let M;
    e[3] !== y ? (M = {
        opacity: y
    }, e[3] = y, e[4] = M) : M = e[4];
    let x;
    e[5] !== s.name || e[6] !== M ? (x = p.jsx("div", {
        className: "absolute start-1/2 top-full -translate-x-1/2 font-bold text-nowrap text-gray-800 [text-shadow:_-0.8px_-0.8px_0_#fff,_0.8px_-0.8px_0_#fff,_-0.8px_0.8px_0_#fff,_0.8px_0.8px_0_#fff]",
        style: M,
        children: s.name
    }), e[5] = s.name, e[6] = M, e[7] = x) : x = e[7];
    const b = c && "cursor-pointer";
    let w;
    e[8] !== b ? (w = ue("absolute inset-0 rounded-xl", b), e[8] = b, e[9] = w) : w = e[9];
    let m;
    e[10] !== c || e[11] !== l ? (m = c ? N => {
        N.preventDefault(), l == null || l()
    } : void 0, e[10] = c, e[11] = l, e[12] = m) : m = e[12];
    let h;
    e[13] !== w || e[14] !== m ? (h = p.jsx("div", {
        className: w,
        onClick: m
    }), e[13] = w, e[14] = m, e[15] = h) : h = e[15];
    let v;
    e[16] !== _ || e[17] !== x || e[18] !== h ? (v = p.jsxs("div", {
        className: "relative",
        children: [_, x, h]
    }), e[16] = _, e[17] = x, e[18] = h, e[19] = v) : v = e[19];
    const S = v,
        R = i ? 2 : 1;
    let E;
    e[20] !== R ? (E = {
        zIndex: R
    }, e[20] = R, e[21] = E) : E = e[21];
    let k;
    e[22] !== s || e[23] !== n || e[24] !== g || e[25] !== i || e[26] !== c || e[27] !== a || e[28] !== S || e[29] !== l || e[30] !== r || e[31] !== o || e[32] !== f ? (k = o ? p.jsx(Nn, {
        label: o,
        onOpenChange: r,
        delayDuration: 150,
        theme: g ? "default" : "white",
        customPaddingClassName: "bg-clip-padding",
        customBorderClassName: "border-token-border-default border",
        contentClassName: "animate-show rounded-[20px]!",
        side: f,
        sideOffset: 10,
        wide: !0,
        interactive: !0,
        children: p.jsxs("div", {
            className: "relative",
            children: [p.jsx(kt, {
                business: s,
                isSelected: i
            }), p.jsx("div", {
                className: "absolute start-1/2 top-full -translate-x-1/2 font-bold text-nowrap text-gray-800 [text-shadow:_-0.8px_-0.8px_0_#fff,_0.8px_-0.8px_0_#fff,_-0.8px_0.8px_0_#fff,_0.8px_0.8px_0_#fff]",
                style: {
                    opacity: a ? 1 : 0
                },
                children: s.name
            }), p.jsx("div", {
                className: ue("absolute inset-0 rounded-xl", c && "cursor-pointer"),
                onClick: c ? N => {
                    N.preventDefault(), l == null || l()
                } : void 0
            })]
        })
    }, n) : S, e[22] = s, e[23] = n, e[24] = g, e[25] = i, e[26] = c, e[27] = a, e[28] = S, e[29] = l, e[30] = r, e[31] = o, e[32] = f, e[33] = k) : k = e[33];
    let T;
    return e[34] !== s.latitude || e[35] !== s.longitude || e[36] !== n || e[37] !== E || e[38] !== k ? (T = p.jsx(Yt, {
        longitude: s.longitude,
        latitude: s.latitude,
        anchor: "bottom",
        style: E,
        children: k
    }, n), e[34] = s.latitude, e[35] = s.longitude, e[36] = n, e[37] = E, e[38] = k, e[39] = T) : T = e[39], T
}
const kt = t => {
    "use forget";
    var c;
    const e = Y.c(7),
        {
            business: n,
            isSelected: s
        } = t,
        o = s ? "bg-token-interactive-bg-primary-press text-token-interactive-label-primary-press" : "bg-token-bg-primary";
    let r;
    e[0] !== o ? (r = ue("border-token-border-default shadow-elevation-03 flex h-7 min-w-7 items-center justify-center rounded-full border bg-clip-padding text-xs font-medium", o), e[0] = o, e[1] = r) : r = e[1];
    let i;
    e[2] !== n.rating ? (i = n.rating ? p.jsxs("div", {
        className: "flex items-center gap-0.75 px-2.5",
        children: [p.jsx("span", {
            children: (c = n.rating) == null ? void 0 : c.toFixed(1)
        }), p.jsx(un, {
            className: "h-3 w-3"
        })]
    }) : p.jsx(fn, {
        className: "h-3 w-3"
    }), e[2] = n.rating, e[3] = i) : i = e[3];
    let a;
    return e[4] !== r || e[5] !== i ? (a = p.jsx("div", {
        className: r,
        children: i
    }), e[4] = r, e[5] = i, e[6] = a) : a = e[6], a
};

function Kt(t) {
    "use forget";
    const e = Y.c(7),
        {
            children: n,
            position: s,
            show: o
        } = t,
        r = s === void 0 ? "top-right" : s,
        i = o === void 0 ? !0 : o,
        [a, c] = d.useState(null);
    let l;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (l = () => ({
        onAdd() {
            const _ = document.createElement("div");
            return _.className = "mapboxgl-ctrl mapboxgl-ctrl-group", c(_), _
        },
        onRemove() {
            c(null)
        }
    }), e[0] = l) : l = e[0];
    let u;
    e[1] !== r ? (u = {
        position: r
    }, e[1] = r, e[2] = u) : u = e[2], Ee(l, u);
    let f;
    return e[3] !== n || e[4] !== a || e[5] !== i ? (f = a && i ? rt.createPortal(n, a) : null, e[3] = n, e[4] = a, e[5] = i, e[6] = f) : f = e[6], f
}

function to(t) {
    "use forget";
    const e = Y.c(3),
        {
            isFullScreen: n,
            onClick: s
        } = t;
    let o;
    return e[0] !== n || e[1] !== s ? (o = p.jsx(Kt, {
        position: "top-right",
        children: p.jsx(no, {
            isFullScreen: n,
            onClick: s
        })
    }), e[0] = n, e[1] = s, e[2] = o) : o = e[2], o
}

function no(t) {
    "use forget";
    const e = Y.c(9),
        {
            isFullScreen: n,
            onClick: s
        } = t,
        o = it();
    let r;
    e[0] !== s ? (r = l => {
        l.preventDefault(), s()
    }, e[0] = s, e[1] = r) : r = e[1];
    let i;
    e[2] !== o || e[3] !== n ? (i = n ? o.formatMessage({
        id: "N1ms3w",
        defaultMessage: "Exit full screen"
    }) : o.formatMessage({
        id: "676SBY",
        defaultMessage: "Enter full screen"
    }), e[2] = o, e[3] = n, e[4] = i) : i = e[4];
    let a;
    e[5] === Symbol.for("react.memo_cache_sentinel") ? (a = p.jsx(dn, {
        className: "icon h-[18px]! w-[18px]!"
    }), e[5] = a) : a = e[5];
    let c;
    return e[6] !== r || e[7] !== i ? (c = p.jsx(ke, {
        type: "button",
        color: "secondary",
        size: "small",
        className: "flex h-[30px] items-center justify-center bg-clip-padding text-black",
        contentWrapperClassName: "font-semibold",
        onClick: r,
        title: i,
        children: a
    }), e[6] = r, e[7] = i, e[8] = c) : c = e[8], c
}

function so(t) {
    "use forget";
    const e = Y.c(5),
        {
            show: n,
            onClick: s
        } = t;
    let o;
    e[0] !== s ? (o = p.jsx(oo, {
        onClick: s
    }), e[0] = s, e[1] = o) : o = e[1];
    let r;
    return e[2] !== n || e[3] !== o ? (r = p.jsx(Kt, {
        show: n,
        position: "top-right",
        children: o
    }), e[2] = n, e[3] = o, e[4] = r) : r = e[4], r
}

function oo(t) {
    "use forget";
    const e = Y.c(8),
        {
            onClick: n
        } = t,
        s = it();
    let o;
    e[0] !== n ? (o = c => {
        c.preventDefault(), n()
    }, e[0] = n, e[1] = o) : o = e[1];
    let r;
    e[2] !== s ? (r = s.formatMessage({
        id: "dUWlu0",
        defaultMessage: "Reset view"
    }), e[2] = s, e[3] = r) : r = e[3];
    let i;
    e[4] === Symbol.for("react.memo_cache_sentinel") ? (i = p.jsx(hn, {
        className: "icon h-[18px]! w-[18px]!"
    }), e[4] = i) : i = e[4];
    let a;
    return e[5] !== o || e[6] !== r ? (a = p.jsx(ke, {
        type: "button",
        color: "secondary",
        size: "small",
        className: "flex h-[30px] items-center justify-center bg-clip-padding text-black",
        contentWrapperClassName: "font-semibold",
        onClick: o,
        title: r,
        children: i
    }), e[5] = o, e[6] = r, e[7] = a) : a = e[7], a
}

function ro(t) {
    "use forget";
    const e = Y.c(11),
        {
            viewState: n,
            onClick: s
        } = t,
        o = kn();
    if (!o) return null;
    const r = n.place,
        i = r && r.city ? "Search in ".concat(r.city) : "Search this area",
        a = r && r.label ? "Search in ".concat(r.label) : "Search this area";
    let c;
    e[0] !== o || e[1] !== s || e[2] !== a || e[3] !== n.latitude || e[4] !== n.longitude || e[5] !== n.radiusMeters ? (c = async () => {
        mn(o).setHasRequestedNewData$(!0), await pn({
            conversation: o,
            promptMessage: Ln(a),
            eventSource: "mouse",
            extraStreamParams: {
                preRetrievalSettings: {
                    use_last_turn_query: !0,
                    top_n: 20,
                    query_type: "local_business",
                    query: {
                        latitude: n.latitude,
                        longitude: n.longitude,
                        radius_meters: n.radiusMeters
                    }
                },
                completionMetadata: {
                    systemHints: [Bt.Search],
                    searchSource: Pn.MAP_SEARCH_THIS_AREA_BUTTON,
                    conversationMode: {
                        kind: Tn.PrimaryAssistant
                    }
                }
            }
        }), s == null || s()
    }, e[0] = o, e[1] = s, e[2] = a, e[3] = n.latitude, e[4] = n.longitude, e[5] = n.radiusMeters, e[6] = c) : c = e[6];
    let l;
    e[7] === Symbol.for("react.memo_cache_sentinel") ? (l = p.jsx(An, {
        className: "icon-sm"
    }), e[7] = l) : l = e[7];
    let u;
    return e[8] !== i || e[9] !== c ? (u = p.jsxs(ke, {
        type: "button",
        color: "secondary",
        size: "small",
        className: "flex h-[36px] items-center justify-center bg-clip-padding px-4 text-black",
        contentWrapperClassName: "font-semibold flex items-center gap-1",
        onClick: c,
        title: i,
        children: [l, i]
    }), e[8] = i, e[9] = c, e[10] = u) : u = e[10], u
}

function io() {
    "use forget";
    const t = Y.c(12),
        [e, n] = d.useState(!1);
    let s;
    t[0] === Symbol.for("react.memo_cache_sentinel") ? (s = () => n(ao), t[0] = s) : s = t[0];
    const o = s,
        r = e ? zn : gn,
        i = e ? "w-full bg-white" : "w-5 bg-white/60 backdrop-blur-xl backdrop-filter hover:bg-white/70";
    let a;
    t[1] !== i ? (a = ue("text-token-text-primary flex h-5 items-center justify-start overflow-hidden rounded-full text-[10px] font-light whitespace-nowrap transition-all", i), t[1] = i, t[2] = a) : a = t[2];
    let c;
    t[3] === Symbol.for("react.memo_cache_sentinel") ? (c = ue("flex min-w-5 items-center justify-center transition-all"), t[3] = c) : c = t[3];
    let l;
    t[4] !== r ? (l = p.jsx("button", {
        onClick: o,
        className: c,
        children: p.jsx(r, {
            className: "icon-sm transition-colors"
        })
    }), t[4] = r, t[5] = l) : l = t[5];
    let u;
    t[6] === Symbol.for("react.memo_cache_sentinel") ? (u = p.jsx("a", {
        href: "https://www.mapbox.com/about/maps",
        target: "_blank",
        rel: "noreferrer",
        className: "text-[#2964aa]!",
        children: "Mapbox"
    }), t[6] = u) : u = t[6];
    let f;
    t[7] === Symbol.for("react.memo_cache_sentinel") ? (f = p.jsx("a", {
        href: "https://www.mapbox.com/legal/end-user-terms",
        target: "_blank",
        rel: "noreferrer",
        className: "me-2 text-[#2964aa]!",
        children: p.jsx(je, {
            id: "u3dZJq",
            defaultMessage: "Terms"
        })
    }), t[7] = f) : f = t[7];
    let g;
    t[8] === Symbol.for("react.memo_cache_sentinel") ? (g = p.jsxs("div", {
        className: "pe-2",
        children: ["© ", u, " ", f, "© ", p.jsx("a", {
            href: "http://www.openstreetmap.org/about",
            target: "_blank",
            rel: "noreferrer",
            className: "text-[#2964aa]!",
            children: "OpenStreetMap"
        })]
    }), t[8] = g) : g = t[8];
    let _;
    return t[9] !== a || t[10] !== l ? (_ = p.jsxs("div", {
        className: a,
        children: [l, g]
    }), t[9] = a, t[10] = l, t[11] = _) : _ = t[11], _
}

function ao(t) {
    return !t
}
const co = 300,
    lo = () => {
        "use forget";
        const t = Y.c(10),
            e = Fn();
        let n;
        t[0] !== e ? (n = () => !e, t[0] = e, t[1] = n) : n = t[1];
        const [s, o] = d.useState(n);
        let r;
        t[2] !== s || t[3] !== e ? (r = e ? () => {
            s || _n(() => {
                o(!0)
            }, co)
        } : void 0, t[2] = s, t[3] = e, t[4] = r) : r = t[4];
        const i = r;
        let a;
        t[5] !== s ? (a = u => {
            "use forget";
            const {
                children: f
            } = u;
            return s ? f : null
        }, t[5] = s, t[6] = a) : a = t[6];
        const c = a;
        let l;
        return t[7] !== c || t[8] !== i ? (l = {
            triggerRender: i,
            IntegratedUXDelayedRender: c
        }, t[7] = c, t[8] = i, t[9] = l) : l = t[9], l
    },
    uo = (t, e) => {
        const n = new Set(t.map(s => s.entity_data.id));
        return e.filter(s => n.has(s.entity_data.id) ? !1 : (n.add(s.entity_data.id), !0))
    },
    Tt = t => {
        var o;
        const e = Pt(t.entities),
            n = (o = t.raw_search_entities) != null && o.length ? Pt(t.raw_search_entities) : [],
            s = uo(e, n);
        return {
            businesses: e,
            additionalBusinesses: s
        }
    },
    Pt = t => t.map(e => {
        var n;
        return {
            entity_type: "local_business",
            entity_data: e.entity,
            extra_params: (n = e.extra_params) != null ? n : void 0
        }
    }),
    Po = t => {
        var n, s;
        const e = (n = t.metadata) == null ? void 0 : n.sonic_entity_data;
        if (!(!(e != null && e.status) || e.status !== "success")) return ((s = e.results) != null ? s : []).filter(o => o.entity_type === "local_business")
    },
    Lt = 50,
    At = 20,
    zt = 20,
    Ft = 20,
    fo = 50,
    ho = 400,
    mo = {
        longitude: 0,
        latitude: 0,
        zoom: 12,
        pitch: 0,
        bearing: 0
    };

function po(t) {
    "use forget";
    const e = Y.c(41),
        {
            contentReference: n,
            clientThreadId: s,
            messageId: o,
            trackContentReferenceEvent: r,
            turnIndex: i
        } = t,
        a = Ot();
    let c;
    e[0] !== a ? (c = ut(a, "3194776735"), e[0] = a, e[1] = c) : c = e[1];
    const l = c;
    let u;
    e[2] !== a ? (u = ut(a, "1950533395"), e[2] = a, e[3] = u) : u = e[3];
    const f = u,
        [g, _] = d.useState(null),
        y = Hn();
    let M;
    e[4] !== s || e[5] !== a || e[6] !== l ? (M = null, e[4] = s, e[5] = a, e[6] = l, e[7] = M) : M = e[7];
    const x = M,
        {
            openThreadSidebar: b,
            closeThreadSidebar: w
        } = xn(),
        {
            resetSidebarHistory: m
        } = vn(),
        h = Mn();
    let v;
    e[8] !== w || e[9] !== n || e[10] !== y || e[11] !== o || e[12] !== x || e[13] !== i ? (v = q => {
        const {
            businesses: F,
            additionalBusinesses: L
        } = Tt(n);
        x == null || x.setOverlayState$({
            messageId: o,
            contentReferenceStartIndex: n.start_idx,
            businesses: F,
            additionalBusinesses: L,
            wasSidebarOpen: y,
            turnIndex: i,
            viewState: q
        }), w(), tt.disableStageSidebarAnimation(), yn({
            forceFlushSync: !0,
            className: "map-with-entities",
            update: () => {
                tt.setSidebarOpen(!1), x == null || x.open$()
            }
        }).finished.then(go)
    }, e[8] = w, e[9] = n, e[10] = y, e[11] = o, e[12] = x, e[13] = i, e[14] = v) : v = e[14];
    const S = v;
    let R;
    e[15] !== x ? (R = () => x == null ? void 0 : x.isOpen$(), e[15] = x, e[16] = R) : R = e[16];
    const E = et(R);
    let k;
    e[17] !== x ? (k = () => x == null ? void 0 : x.currentMessageId$(), e[17] = x, e[18] = k) : k = e[18];
    const T = et(k);
    let N;
    e[19] !== n ? (N = Tt(n), e[19] = n, e[20] = N) : N = e[20];
    const {
        businesses: j
    } = N, P = l && !E && T === o;
    let C;
    e[21] !== s || e[22] !== n || e[23] !== h || e[24] !== o || e[25] !== b || e[26] !== m ? (C = (q, F) => {
        var L;
        s && (h || m(), b({
            type: "entity",
            debugThreadId: void 0,
            messageId: o,
            contentReferenceStartIndex: n.start_idx,
            query: F.entity_data.name,
            category: "local_business",
            extraParams: (L = F.extra_params) != null ? L : void 0
        }))
    }, e[21] = s, e[22] = n, e[23] = h, e[24] = o, e[25] = b, e[26] = m, e[27] = C) : C = e[27];
    const z = C,
        $ = l ? S : void 0,
        X = P ? "[view-transition-name:map-with-entities]" : void 0;
    let U;
    e[28] !== f || e[29] !== z || e[30] !== r ? (U = q => {
        const {
            idx: F,
            business: L,
            isSelected: Q,
            isVisible: K
        } = q;
        return p.jsx(eo, {
            idx: F,
            business: L.entity_data,
            isSelected: Q,
            isOpen: Q,
            isVisible: K,
            tooltipLocation: "top",
            tooltipContent: p.jsx(Qs, {
                idx: F,
                business: L.entity_data,
                trackContentReferenceEvent: r,
                onOpenEntity: () => {
                    _(L.entity_data.id), z == null || z(F, L)
                },
                enableSidebarNavigation: f,
                showActions: !0
            }),
            onOpenChange: J => {
                _(J ? L.entity_data.id : null)
            },
            isSonicSidebarEnabled: f,
            onClick: () => {
                _(L.entity_data.id), z == null || z(F, L)
            }
        }, F)
    }, e[28] = f, e[29] = z, e[30] = r, e[31] = U) : U = e[31];
    let W;
    return e[32] !== j || e[33] !== s || e[34] !== o || e[35] !== g || e[36] !== X || e[37] !== U || e[38] !== $ || e[39] !== r ? (W = p.jsx(Wn, {
        children: p.jsx("div", {
            className: "not-prose",
            "data-testid": "businesses-map-widget",
            children: p.jsx("div", {
                className: "pt-4",
                children: p.jsx(_o, {
                    businesses: j,
                    clientThreadId: s,
                    messageId: o,
                    trackContentReferenceEvent: r,
                    onFullScreenToggle: $,
                    containerClassName: X,
                    selectedBusinessId: g,
                    markerComponent: U
                })
            })
        })
    }), e[32] = j, e[33] = s, e[34] = o, e[35] = g, e[36] = X, e[37] = U, e[38] = $, e[39] = r, e[40] = W) : W = e[40], W
}

function go() {
    tt.enableStageSidebarAnimation()
}

function _o(t) {
    "use forget";
    const e = Y.c(60),
        {
            businesses: n,
            clientThreadId: s,
            trackContentReferenceEvent: o,
            isFullScreen: r,
            onFullScreenToggle: i,
            containerClassName: a,
            markerComponent: c,
            selectedBusinessId: l,
            initialViewState: u,
            onMoveCallback: f
        } = t,
        g = it(),
        _ = Ot();
    let y;
    e[0] !== s || e[1] !== _ ? (y = s ? In(_, s) : null, e[0] = s, e[1] = _, e[2] = y) : y = e[2];
    const M = y;
    let x;
    e[3] !== M ? (x = () => M ? Bn(M).id : null, e[3] = M, e[4] = x) : x = e[4];
    const b = et(x),
        w = d.useRef(null);
    let m, h;
    e[5] !== M || e[6] !== b ? (m = () => {
        var I, O;
        if (!M || !b) {
            (O = (I = w.current) == null ? void 0 : I.cancel) == null || O.call(I), w.current = null;
            return
        }
        const B = On(() => {
            bn(M.id, b, [Bt.Search], D => {
                Un(M.id, Z => {
                    Z.conduitToken = D, Z.prepareState = "success"
                })
            }, {
                isRegen: !1,
                isOnboardingConversation: !1,
                delayAfterCompletion: !1
            })
        }, 5e3, {
            leading: !0,
            trailing: !1
        });
        return w.current = B, () => {
            B.cancel()
        }
    }, h = [M, b], e[5] = M, e[6] = b, e[7] = m, e[8] = h) : (m = e[7], h = e[8]), d.useEffect(m, h);
    const v = u != null,
        S = d.useRef(!v),
        R = d.useRef(null),
        E = d.useRef(null);
    let k;
    e[9] !== u ? (k = A(A({}, mo), u), e[9] = u, e[10] = k) : k = e[10];
    const T = k,
        N = d.useRef(T),
        [j, P] = d.useState(T),
        C = Dn(),
        [z, $] = d.useState(!1),
        [X, U] = d.useState(!1);
    let W, q;
    e[11] !== u || e[12] !== r ? (W = () => {
        !u || !r || (P(u), N.current = u, S.current = !1, $(!1), U(!1))
    }, q = [u, r], e[11] = u, e[12] = r, e[13] = W, e[14] = q) : (W = e[13], q = e[14]), d.useEffect(W, q);
    const F = !Dt(),
        L = r || !i ? Ft : Ft + fo,
        Q = d.useRef(!1);
    let K, J;
    e[15] !== o ? (K = () => {
        Q.current || (o("Search Content Reference Shown", "search_content_reference_shown", "map"), Q.current = !0)
    }, J = [o], e[15] = o, e[16] = K, e[17] = J) : (K = e[16], J = e[17]), d.useEffect(K, J);
    let oe, de;
    e[18] === Symbol.for("react.memo_cache_sentinel") ? (oe = () => {
        if (!R.current) return;
        const B = $n(() => {
                var O;
                (O = E.current) == null || O.resize()
            }, 100),
            I = new ResizeObserver(B);
        return I.observe(R.current), () => {
            I.disconnect()
        }
    }, de = [], e[18] = oe, e[19] = de) : (oe = e[18], de = e[19]), d.useEffect(oe, de);
    let ae;
    e[20] === Symbol.for("react.memo_cache_sentinel") ? (ae = new Set, e[20] = ae) : ae = e[20];
    const [ce, Jt] = d.useState(ae), He = d.useRef(-1), [pe, Qt] = d.useState(!1);
    let Te;
    e[21] !== n || e[22] !== pe || e[23] !== j.zoom ? (Te = () => {
        var I, O, D;
        if (!E.current || !pe) return;
        const B = Mo;
        if (He.current == -1 || He.current !== j.zoom) {
            const Z = [];
            for (const H of n) {
                const te = (I = E.current) == null ? void 0 : I.project([H.entity_data.longitude, H.entity_data.latitude]);
                if (!te) return;
                const _e = te.x - 30,
                    re = te.y,
                    be = (O = H.entity_data.rating) != null ? O : 0,
                    xe = (D = H.entity_data.is_open) != null ? D : !1;
                Z.push({
                    id: H.entity_data.id,
                    x: _e,
                    y: re,
                    w: 60,
                    h: 30,
                    rating: be,
                    openNow: xe
                })
            }
            Z.sort(yo);
            const ee = new Set,
                ge = new Map(Z.map(vo));
            for (const H of Z) {
                let te = !1;
                for (const _e of ee) {
                    const re = ge.get(_e);
                    if (re && B(H, re)) {
                        te = !0;
                        break
                    }
                }
                te || ee.add(H.id)
            }
            Jt(H => H.size === ee.size && [...H].every(te => ee.has(te)) ? H : ee)
        }
        He.current = j.zoom
    }, e[21] = n, e[22] = pe, e[23] = j.zoom, e[24] = Te) : Te = e[24];
    let Pe;
    e[25] !== n || e[26] !== pe || e[27] !== j.zoom || e[28] !== ce ? (Pe = [j.zoom, ce, pe, n], e[25] = n, e[26] = pe, e[27] = j.zoom, e[28] = ce, e[29] = Pe) : Pe = e[29], d.useEffect(Te, Pe);
    let Le, Ae;
    e[30] !== n || e[31] !== L || e[32] !== l ? (Le = () => {
        const B = function() {
            var _e;
            const D = function(be, xe) {
                    const he = E.current;
                    if (!he) return !1;
                    const {
                        width: ve,
                        height: ye
                    } = he.getContainer().getBoundingClientRect(), Ve = L, Ie = he.unproject([At, Lt]), at = he.unproject([ve - zt, ye - Ve]);
                    return le(be, 5) >= le(at.lat, 5) && le(be, 5) <= le(Ie.lat, 5) && le(xe, 5) >= le(Ie.lng, 5) && le(xe, 5) <= le(at.lng, 5)
                },
                Z = l ? n.find(re => re.entity_data.id === l) : null;
            if (!S.current && l && !Z) return;
            const ee = S.current || !Z ? n : [Z],
                ge = bs(ee.map(xo)),
                H = xs(ge),
                te = ys(ge);
            if (R.current) {
                const re = R.current.clientWidth,
                    be = R.current.clientHeight,
                    xe = new Ue({
                        width: re,
                        height: be,
                        longitude: te.geometry.coordinates[0],
                        latitude: te.geometry.coordinates[1]
                    }),
                    {
                        zoom: he,
                        latitude: ve,
                        longitude: ye
                    } = xe.fitBounds([
                        [H[0], H[1]],
                        [H[2], H[3]]
                    ], {
                        maxZoom: 13.5,
                        padding: {
                            top: Lt,
                            left: At,
                            right: zt,
                            bottom: L
                        }
                    });
                S.current ? (It(E.current).then(Ve => {
                    P(Ie => V(A({}, Ie), {
                        zoom: he,
                        latitude: ve,
                        longitude: ye,
                        radiusMeters: Qe(E.current),
                        place: Ve
                    }))
                }), N.current = {
                    longitude: ye,
                    latitude: ve,
                    zoom: he,
                    pitch: 0,
                    bearing: 0
                }, S.current = !1) : D(ve, ye) || (_e = E.current) == null || _e.flyTo({
                    center: [ye, ve]
                })
            }
        };
        if (n.length === 0) return;
        if (S.current) {
            B();
            return
        }
        if (!l) return;
        const I = setTimeout(B, 200);
        return () => clearTimeout(I)
    }, Ae = [n, l, L], e[30] = n, e[31] = L, e[32] = l, e[33] = Le, e[34] = Ae) : (Le = e[33], Ae = e[34]), d.useEffect(Le, Ae);
    const {
        triggerRender: We,
        IntegratedUXDelayedRender: qe
    } = lo();
    let ze;
    if (e[35] !== n || e[36] !== c || e[37] !== l || e[38] !== ce) {
        let B;
        e[40] !== l ? (B = (O, D) => {
            const Z = O.business.entity_data.id === l,
                ee = D.business.entity_data.id === l;
            return Z && !ee ? 1 : !Z && ee ? -1 : O.idx - D.idx
        }, e[40] = l, e[41] = B) : B = e[41];
        let I;
        e[42] !== c || e[43] !== l || e[44] !== ce ? (I = O => {
            const {
                business: D,
                idx: Z
            } = O, ee = D.entity_data.id === l, ge = c;
            return p.jsx(ge, {
                idx: Z,
                business: D,
                isSelected: ee,
                isVisible: ce.has(D.entity_data.id)
            }, D.entity_data.id)
        }, e[42] = c, e[43] = l, e[44] = ce, e[45] = I) : I = e[45], ze = n.map(bo).sort(B).map(I), e[35] = n, e[36] = c, e[37] = l, e[38] = ce, e[39] = ze
    } else ze = e[39];
    const Ze = ze;
    let Fe;
    return e[46] !== qe || e[47] !== a || e[48] !== g || e[49] !== r || e[50] !== F || e[51] !== i || e[52] !== f || e[53] !== Ze || e[54] !== z || e[55] !== X || e[56] !== We || e[57] !== C || e[58] !== j ? (Fe = !F && p.jsxs("div", {
        style: {
            height: r ? "100%" : ho
        },
        className: ue("bg-token-bg-primary relative w-full", a),
        ref: R,
        children: [p.jsx("div", {
            className: "relative h-full w-full overflow-hidden rounded-3xl",
            children: p.jsxs(Ys, V(A({}, j), {
                onIdle: We,
                mapboxAccessToken: Ut,
                mapStyle: "mapbox://styles/oai-data/cmhawgfb0000n01sd7bcybf4f",
                attributionControl: !1,
                renderWorldCopies: !1,
                cooperativeGestures: !r,
                onMove: B => {
                    var D;
                    const I = Qe(E.current),
                        O = V(A({}, B.viewState), {
                            radiusMeters: I,
                            place: j.place
                        });
                    f == null || f(O), P(O), So(N.current, B) && ($(!0), U(!0), (D = w.current) == null || D.call(w))
                },
                onMoveEnd: B => {
                    It(E.current).then(I => {
                        const O = Qe(E.current),
                            D = V(A({}, B.viewState), {
                                radiusMeters: O,
                                place: I
                            });
                        f == null || f(D), P(D)
                    })
                },
                locale: {
                    "ScrollZoomBlocker.CtrlMessage": g.formatMessage({
                        id: "1aF2nO",
                        defaultMessage: "Hold Ctrl to zoom"
                    }),
                    "ScrollZoomBlocker.CmdMessage": g.formatMessage({
                        id: "8R2Dga",
                        defaultMessage: "Hold ⌘ to zoom"
                    })
                },
                ref: E,
                keyboard: !1,
                onLoad: () => {
                    Qt(!0)
                },
                children: [i && p.jsx(to, {
                    isFullScreen: !!r,
                    onClick: () => i(j)
                }), p.jsx(Ks, {
                    position: "top-right",
                    showCompass: !1,
                    style: {
                        borderRadius: 9999,
                        overflow: "hidden"
                    }
                }), p.jsx(so, {
                    show: z,
                    onClick: () => {
                        P(V(A({}, N.current), {
                            pitch: 0,
                            bearing: 0
                        })), f == null || f(V(A({}, N.current), {
                            pitch: 0,
                            bearing: 0
                        })), $(!1), U(!1)
                    }
                }), p.jsxs(qe, {
                    children: [Ze, (C == null ? void 0 : C.latitude) && (C == null ? void 0 : C.longitude) && p.jsx(Yt, {
                        longitude: C.longitude,
                        latitude: C.latitude,
                        style: {
                            zIndex: 1e3
                        },
                        children: p.jsx(Js, {
                            className: "h-8 w-8"
                        })
                    })]
                })]
            }))
        }), p.jsxs("div", {
            className: "absolute start-3 top-3 flex flex-col gap-2",
            children: [X && r && p.jsx(ro, {
                viewState: j,
                onClick: () => U(!1)
            }), p.jsx(io, {})]
        }), !r && i && p.jsx("div", {
            className: "pointer-events-none absolute inset-x-0 bottom-0 px-1 pb-1",
            children: p.jsx(ke, {
                color: "secondary",
                className: "border-token-border-default h-[44px] border border-solid bg-clip-padding opacity-[98%] active:opacity-100!",
                onClick: () => i == null ? void 0 : i(j),
                fullWidth: !0,
                children: p.jsx(je, {
                    id: "GSmA8f",
                    defaultMessage: "Show more places"
                })
            })
        })]
    }), e[46] = qe, e[47] = a, e[48] = g, e[49] = r, e[50] = F, e[51] = i, e[52] = f, e[53] = Ze, e[54] = z, e[55] = X, e[56] = We, e[57] = C, e[58] = j, e[59] = Fe) : Fe = e[59], Fe
}

function bo(t, e) {
    return {
        business: t,
        idx: e
    }
}

function xo(t) {
    return Vt([t.entity_data.longitude, t.entity_data.latitude])
}

function vo(t) {
    return [t.id, t]
}

function yo(t, e) {
    const n = t.openNow,
        s = e.openNow;
    return n && !s ? -1 : !n && s ? 1 : e.rating - t.rating
}

function Mo(t, e) {
    return !(t.x + t.w <= e.x || e.x + e.w <= t.x || t.y + t.h <= e.y || e.y + e.h <= t.y)
}
const wo = (t, e) => t.messageId === e.messageId && t.clientThreadId === e.clientThreadId && t.turnIndex === e.turnIndex && t.trackContentReferenceEvent === e.trackContentReferenceEvent && t.contentReference.entities.length === e.contentReference.entities.length,
    Lo = d.memo(po, wo),
    So = (t, e) => {
        if (t) {
            const n = Math.abs(e.viewState.zoom - t.zoom),
                s = Math.abs(e.viewState.latitude - t.latitude),
                o = Math.abs(e.viewState.longitude - t.longitude);
            return n > .05 || s > 5e-4 || o > 5e-4
        }
        return !1
    },
    Qe = t => {
        if (!t) return 0;
        const e = t.getBounds(),
            n = t.getCenter(),
            s = e == null ? void 0 : e.getNorthEast();
        return s ? n.distanceTo(s) : 0
    };

function Co(t) {
    var r, i, a, c, l, u;
    const e = (r = t == null ? void 0 : t.context) != null ? r : [],
        n = (c = (i = e.find(f => String(f.id).startsWith("place."))) == null ? void 0 : i.text) != null ? c : (a = e.find(f => String(f.id).startsWith("locality."))) == null ? void 0 : a.text,
        s = (l = e.find(f => String(f.id).startsWith("region."))) == null ? void 0 : l.text,
        o = (u = e.find(f => String(f.id).startsWith("postcode."))) == null ? void 0 : u.text;
    return {
        city: n,
        state: s,
        zipcode: o,
        label: t == null ? void 0 : t.place_name
    }
}
async function It(t) {
    var l;
    if (!t) return;
    const e = t.getCenter(),
        n = e.lat,
        s = e.lng,
        o = new URL("https://api.mapbox.com/geocoding/v5/mapbox.places/".concat(s, ",").concat(n, ".json"));
    o.searchParams.set("access_token", Ut), o.searchParams.set("types", "postcode,place,region"), o.searchParams.set("limit", "1");
    const r = await fetch(o.toString());
    if (!r.ok) return;
    const i = await r.json(),
        a = (l = i == null ? void 0 : i.features) == null ? void 0 : l[0];
    return a ? Co(a) : void 0
}
export {
    Qs as B, _o as M, Js as S, Ue as W, uo as a, eo as b, Po as c, Ys as d, Yt as e, io as f, Tt as g, bs as h, ys as i, Lo as j, Vt as p, le as r, xs as t, lo as u
};
//# sourceMappingURL=brbv8u56dvmb3wbc.js.map