import {
    e as c,
    r as d,
    u as f,
    j as r,
    M as u
} from "./fg33krlcm0qyi6yw.js";
import {
    P as n,
    a9 as g,
    p as h
} from "./dykg4ktvbu3mhmdo.js";
import {
    ds as y
} from "./k15yxxoybkkir2ou.js";
import {
    a as _,
    m as l
} from "./mqaxq6uz189xwrrs.js";
class E extends Error {
    constructor(t) {
        super(t), this.name = "EmailValidationError"
    }
}
const x = (e, t) => t.trim() === "" ? e.formatMessage(l.sendEmailFailureInvalidEmailEmpty) : /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|.(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(t) ? null : e.formatMessage(l.sendEmailFailureInvalidEmail, {
        email: t
    }),
    v = (e, t, s) => {
        switch (s.status) {
            case 429:
                throw new Error(e.formatMessage(l.sendEmailFailureRateLimited));
            case 403:
                throw new Error(e.formatMessage(l.verifyOtpFailureEmailAlreadyLinked, {
                    branch: t ? "email" : "other",
                    emailValue: t
                }));
            default:
                return
        }
    };

function V(e) {
    const t = c(),
        [s, o] = d.useState(null),
        m = f({
            mutationFn: async a => {
                try {
                    const i = x(t, a);
                    if (i) throw new E(i);
                    return await _(a)
                } catch (i) {
                    throw i instanceof E ? i : (i instanceof h && v(t, a, i), new Error(t.formatMessage(l.sendEmailFailure)))
                }
            },
            onSuccess: () => {
                e.setStep("verifyOtp")
            },
            onError: a => {
                o(a.message), n.logEventWithStatsig("Email Verify Enter Email Step - Error Sending Verification Email", "chatgpt_email_verify_enter_email_step_error", {
                    error: a.message
                })
            }
        });
    return d.useEffect(() => {
        n.logEventWithStatsig("Email Verify Enter Email Step - Shown", "chatgpt_email_verify_enter_email_step_shown")
    }, []), r.jsx("form", {
        onSubmit: a => {
            a.preventDefault(), m.mutate(e.email), n.logEventWithStatsig("Email Verify Enter Email Step - Attempted Continue", "chatgpt_email_verify_enter_email_step_continue")
        },
        noValidate: !0,
        children: r.jsxs("div", {
            className: "flex w-full flex-col items-center gap-3",
            children: [r.jsx("p", {
                className: "text-3xl font-semibold",
                children: e.title ? e.title : r.jsx(u, {
                    id: "emailVerify.enterEmailTitle",
                    defaultMessage: "Add your email"
                })
            }), e.description && r.jsx("p", {
                className: "text-token-text-primary text-center text-base",
                children: e.description
            }), r.jsx(y, {
                ariaLabel: t.formatMessage({
                    id: "emailVerify.emailAddress",
                    defaultMessage: "Email Address"
                }),
                placeholder: t.formatMessage({
                    id: "emailVerify.emailAddressPlaceholder",
                    defaultMessage: "Email Address"
                }),
                name: "email",
                type: "email",
                className: "mt-6 w-full",
                value: e.email,
                onChange: a => {
                    var i;
                    o(null), (i = e.onEmailChange) == null || i.call(e, a.target.value), n.logEventWithStatsig("Email Verify Enter Email Step - Typed", "chatgpt_email_verify_enter_email_step_type")
                },
                autoFocus: !0,
                autoComplete: "email",
                error: s != null ? s : void 0
            }), r.jsx(g, {
                className: "w-full rounded-md",
                color: "green",
                type: "submit",
                loading: m.isPending,
                disabled: m.isPending,
                children: r.jsx(u, {
                    id: "emailVerify.continue",
                    defaultMessage: "Continue"
                })
            }), e.cancelFlowButton]
        })
    })
}
export {
    V as E, v as h
};
//# sourceMappingURL=dmkpfqcl39i5eaqb.js.map