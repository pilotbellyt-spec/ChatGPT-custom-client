var ne = Object.defineProperty,
    le = Object.defineProperties;
var ie = Object.getOwnPropertyDescriptors;
var J = Object.getOwnPropertySymbols;
var re = Object.prototype.hasOwnProperty,
    ce = Object.prototype.propertyIsEnumerable;
var Q = (t, a, s) => a in t ? ne(t, a, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : t[a] = s,
    R = (t, a) => {
        for (var s in a || (a = {})) re.call(a, s) && Q(t, s, a[s]);
        if (J)
            for (var s of J(a)) ce.call(a, s) && Q(t, s, a[s]);
        return t
    },
    V = (t, a) => le(t, ie(a));
import {
    r as h,
    j as e,
    M as j,
    c as oe
} from "./fg33krlcm0qyi6yw.js";
import {
    l as S,
    bg as W,
    o as de,
    b as ue,
    _ as me,
    a9 as z,
    gy as xe,
    kM as he,
    T as H,
    bX as Y,
    mS as fe,
    qF as pe,
    bc as _e,
    bd as ge,
    g2 as F,
    nW as be
} from "./dykg4ktvbu3mhmdo.js";
import {
    a as je
} from "./lqog7ixiwnif6sbp.js";
import {
    g as ye
} from "./zdzro29lk5w2w085.js";
import {
    nJ as ve,
    cw as Ne,
    ej as U,
    eU as G,
    de as ke,
    yQ as we,
    aX as ee,
    eq as Se,
    ge as Me,
    gc as Pe,
    cr as Ce
} from "./k15yxxoybkkir2ou.js";
import {
    S as Ie,
    T as Z
} from "./djfxxaryk37v3pj1.js";
import {
    M as Te
} from "./ebc4iyfg14nu1gw4.js";
import {
    W as $
} from "./dcboyjh87ll7k264.js";
import {
    s as Ae
} from "./b31u62knn5mcc1vg.js";

function dt({
    imageUrls: t,
    title: a,
    onImageClick: s,
    isLoading: n
}) {
    const [l, c] = h.useState(0), r = h.useRef(null);
    return t ? e.jsx("div", {
        className: "overflow-clip",
        children: e.jsxs("div", {
            className: S("flex flex-col transition duration-400 ease-in-out", n && "pointer-events-none blur-lg"),
            children: [t[l] && e.jsx(W.div, {
                className: "bg-token-main-surface-secondary dark:bg-token-main-surface-primary-inverse",
                drag: "x",
                dragConstraints: {
                    left: 0,
                    right: 0
                },
                dragElastic: 0,
                onDragEnd: (d, {
                    offset: p,
                    velocity: m
                }) => {
                    const o = Math.abs(p.x) * m.x,
                        u = 1e3;
                    o < -u ? l < t.length - 1 && c(l + 1) : o > u && l > 0 && c(l - 1)
                },
                onClick: () => s(t[l]),
                children: e.jsx("img", {
                    className: "m-0 aspect-square w-full cursor-pointer object-contain mix-blend-darken",
                    src: t[l],
                    alt: a,
                    draggable: !1
                })
            }), t.length > 1 && e.jsx("div", {
                ref: r,
                className: "no-scrollbar flex flex-row gap-2 overflow-x-scroll px-6 py-3",
                children: t.map((d, p) => e.jsx("div", {
                    className: S("flex-none cursor-pointer overflow-hidden rounded-lg border-2 p-0.5", l === p ? "border-token-text-primary" : "border-transparent"),
                    onMouseEnter: () => c(p),
                    children: e.jsx("div", {
                        className: "bg-token-main-surface-secondary dark:bg-token-main-surface-primary-inverse overflow-clip rounded-[4.5px]",
                        children: e.jsx("img", {
                            className: "h-10 w-10 object-cover mix-blend-darken",
                            src: d,
                            alt: a
                        })
                    })
                }, "".concat(p, "-").concat(d)))
            })]
        })
    }) : null
}
const Ee = t => {
        var s;
        return (s = t == null ? void 0 : t.reduce((n, l) => (l.selected_option_id && (n[l.id] = l.options.find(c => c.id === l.selected_option_id)), n), {})) != null ? s : {}
    },
    De = t => {
        var a;
        return !((a = t.variants) != null && a.length) || t.variants.every(s => s.selected_option_id)
    },
    Fe = 3;

function ut({
    offers: t,
    profiler: a,
    contentReferenceStartIndex: s,
    productIndex: n,
    product: l,
    isLoading: c,
    onOpenCheckout: r,
    trackContentReferenceEvent: d,
    analyticsMetadata: p,
    className: m
}) {
    "use no forget";
    var I, T;
    const o = ue(),
        u = de(o, "3375735072"),
        x = u ? ye(o) : null,
        [w, _] = h.useState(!1),
        C = (I = l.offers_see_more_boundary) != null ? I : Fe,
        g = (T = l.variants && Object.values(Ee(l.variants)).map(i => i.label).join(" • ")) != null ? T : null,
        N = t.filter(i => i.available);
    return h.useEffect(() => {
        var i, b, k, y;
        if (!c) {
            const M = t.filter(P => P.available).length,
                v = t.filter(P => P.checkoutable).length,
                f = {
                    total_count: t.length,
                    available_count: M,
                    checkoutable_count: v,
                    is_variant: !!g,
                    source: l.provider
                };
            d("Product Offers Shown", "product_offers_shown", "product_entity", f), d("product_detail", "product_detail", "product_entity", {
                action: "updated",
                variants_count: (b = (i = l.variants) == null ? void 0 : i.length) != null ? b : 0,
                variants_with_selection_count: (y = (k = l.variants) == null ? void 0 : k.filter(P => P.selected_option_id).length) != null ? y : 0,
                offers_count: M,
                checkoutable_offers_count: v
            }), me.addAction("shopping_checkout.offers_shown", f)
        }
    }, [t, c, g]), N.length === 0 && l.variants && l.variants.length > 0 && l.variants.every(i => i.selected_option_id) && !c ? e.jsx("div", {
        className: "px-6 pt-6 text-sm",
        children: l.variants_error_state_message ? l.variants_error_state_message : e.jsx(j, {
            id: "jEsmfN",
            defaultMessage: "This combination is unavailable"
        })
    }) : N.length > 0 && e.jsxs("div", {
        className: S(m, c && "pointer-events-none opacity-50"),
        children: [N.slice(0, w ? t.length : C).map((i, b) => {
            var M, v;
            const k = (M = i.debug_info) == null ? void 0 : M.feed_id,
                y = (v = i.debug_info) == null ? void 0 : v.source;
            return e.jsx(W.div, {
                initial: {
                    opacity: 0
                },
                animate: {
                    opacity: 1
                },
                transition: {
                    duration: .3
                },
                children: e.jsx(Oe, {
                    offer: i,
                    isCheckoutEnabled: u,
                    isLoading: c,
                    isCheckoutable: u && i.checkoutable,
                    showPriceDisclosure: !!l.show_price_disclosure,
                    onOpenCheckout: (f, P) => {
                        var A, E;
                        f.stopPropagation(), r(), u && x && De(l) && i.checkout_payload && (a == null || a.startBlock("shown"), x.openNewCheckout({
                            preloadCustomerSessionClientSecret: P,
                            metadata: p,
                            items: [{
                                id: i.checkout_payload,
                                productId: l.id,
                                quantity: 1,
                                value: i.checkout_payload
                            }]
                        }), d("Product Offer Clicked", "product_offer_clicked", "product_entity", {
                            content_reference_start_index: s,
                            product_index: n,
                            offer_index: b,
                            product_id: l.id,
                            product_url: l.url,
                            offer_url: i.url,
                            offers_count: t.length,
                            price: (A = i.price) == null ? void 0 : A.toString(),
                            action: "buy_button_clicked",
                            merchant_name: i.merchant_name,
                            source: l.provider,
                            feed_id: k
                        }), d("product_offer", "product_offer", "product_entity", {
                            content_reference_start_index: s,
                            product_index: n,
                            product_id: l.id,
                            product_url: l.url,
                            action: "buy_button_clicked",
                            section: "product_detail",
                            section_location: "sidebar",
                            section_index: b,
                            offer_index: b,
                            merchant_name: i.merchant_name,
                            price: (E = i.price) == null ? void 0 : E.toString(),
                            had_buy_button: !0,
                            variants: g,
                            source: y,
                            feed_id: k
                        }))
                    },
                    onVisitMerchant: f => {
                        var P, A;
                        f.stopPropagation(), d("Product Offer Clicked", "product_offer_clicked", "product_entity", {
                            content_reference_start_index: s,
                            product_index: n,
                            offer_index: b,
                            product_id: l.id,
                            product_url: l.url,
                            offer_url: i.url,
                            offers_count: t.length,
                            price: (P = i.price) == null ? void 0 : P.toString(),
                            action: "open_site_clicked",
                            merchant_name: i.merchant_name,
                            source: l.provider,
                            feed_id: k
                        }), d("product_offer", "product_offer", "product_entity", {
                            content_reference_start_index: s,
                            product_index: n,
                            product_id: l.id,
                            product_url: l.url,
                            action: "open_site_clicked",
                            section: "product_detail",
                            section_location: "sidebar",
                            section_index: b,
                            offer_index: b,
                            merchant_name: i.merchant_name,
                            site_url: i.url,
                            price: (A = i.price) == null ? void 0 : A.toString(),
                            had_buy_button: u && i.checkoutable,
                            variants: g,
                            source: y,
                            feed_id: k
                        }), window.open(i.url, "_blank")
                    },
                    onShown: () => {
                        var f;
                        u && i.checkoutable && (a == null || a.logTimingOnce("offer_ready")), d("product_offer", "product_offer", "product_entity", {
                            content_reference_start_index: s,
                            product_index: n,
                            product_id: l.id,
                            product_url: l.url,
                            action: "shown",
                            section: "product_detail",
                            section_location: "sidebar",
                            section_index: b,
                            offer_index: b,
                            merchant_name: i.merchant_name,
                            price: (f = i.price) == null ? void 0 : f.toString(),
                            had_buy_button: u && i.checkoutable,
                            checkoutable: i.checkoutable,
                            source: y,
                            feed_id: k
                        })
                    }
                }, i.url + i.checkout_payload)
            }, i.url)
        }), t.length > C && !c && e.jsx(W.div, {
            layout: !0,
            transition: {
                type: "tween",
                ease: "easeInOut",
                duration: .1
            },
            children: e.jsxs(z, {
                className: "w-fit px-3",
                size: "small",
                color: "ghost",
                onClick: () => _(!w),
                contentWrapperClassName: "gap-1",
                children: [w ? e.jsx(j, {
                    id: "Gl3oLS",
                    defaultMessage: "See less"
                }) : e.jsx(j, {
                    id: "f9tOaY",
                    defaultMessage: "See more"
                }), w ? e.jsx(ve, {
                    className: "mt-0.5"
                }) : e.jsx(Ne, {})]
            })
        })]
    })
}

function Oe({
    offer: t,
    onVisitMerchant: a,
    onOpenCheckout: s,
    isCheckoutEnabled: n,
    isLoading: l,
    isCheckoutable: c,
    showPriceDisclosure: r,
    onShown: d
}) {
    var b, k, y, M;
    const [p, m] = h.useState(void 0), o = t.price_details, u = (o == null ? void 0 : o.base) && ((b = o.shipping) != null ? b : o.tax) && o.total, x = ((o == null ? void 0 : o.display_price) === "total_price" || u) && r, w = (o == null ? void 0 : o.display_price) === "total_price", _ = xe(), {
        showDebugConversationTurns: C
    } = he(), g = h.useRef(!1);
    h.useEffect(() => {
        l || (d(), (async () => {
            if (!l && c && t.checkout_payload && !g.current) {
                g.current = !0;
                const f = await je([{
                    id: t.checkout_payload,
                    quantity: 1,
                    value: t.checkout_payload
                }]);
                f.customer_session_client_secret && m(f.customer_session_client_secret)
            }
        })())
    }, [d, l, c, t.checkout_payload]);
    let N = null;
    u && o ? N = e.jsxs("div", {
        className: "space-y-1 text-sm",
        children: [e.jsx("div", {
            children: e.jsx(j, {
                id: "offer.breakdown.base",
                defaultMessage: "Base price: {amount}",
                values: {
                    amount: o.base
                }
            })
        }), o.shipping && e.jsx("div", {
            children: e.jsx(j, {
                id: "offer.breakdown.shipping",
                defaultMessage: "Shipping: {amount}",
                values: {
                    amount: o.shipping
                }
            })
        }), o.tax && e.jsx("div", {
            children: e.jsx(j, {
                id: "offer.breakdown.tax",
                defaultMessage: "Tax: {amount}",
                values: {
                    amount: o.tax
                }
            })
        })]
    }) : w && (N = e.jsx(j, {
        id: "ur3//V",
        defaultMessage: "Prices shown include estimated tax and shipping."
    }));
    const I = n && c && !_ ? v => s(v, p) : a,
        T = e.jsx("span", {
            className: "text-[15px] leading-snug font-semibold",
            children: t.price
        }),
        i = n && c && !_;
    return (k = t.debug_info) == null || k.source, (y = t.debug_info) == null || y.feed_id, Object.entries((M = t.debug_info) != null ? M : {}).filter(([v]) => v !== "source" && v !== "feed_id"), e.jsxs("div", {
        className: S("flex cursor-pointer flex-col rounded-xl p-3", "hover:bg-token-bg-tertiary"),
        onClick: I,
        children: [e.jsxs("div", {
            className: "flex flex-row items-start gap-2",
            children: [e.jsxs("div", {
                className: "flex min-w-0 flex-1 flex-col gap-0.5",
                children: [e.jsxs("div", {
                    className: "group flex flex-col gap-0.5",
                    onClick: a,
                    children: [e.jsxs("div", {
                        className: "flex flex-row items-center gap-1.5 text-sm font-medium",
                        children: [e.jsx(U, {
                            className: "border-token-border-light h-5 w-5 rounded-full border-1",
                            url: t.url,
                            size: 128,
                            minSize: 16,
                            fallback: e.jsx(G, {
                                className: "text-token-text-tertiary"
                            })
                        }), e.jsx("div", {
                            className: "truncate",
                            children: t.merchant_name
                        }), e.jsx(ke, {
                            className: "text-token-text-secondary mt-0.5 h-3 w-3 shrink-0 opacity-0 transition-opacity group-hover:opacity-100"
                        })]
                    }), e.jsx("div", {
                        className: "text-token-text-secondary text-xs whitespace-pre-wrap",
                        children: t.details
                    })]
                }), n && We(t.tag, i) && e.jsx(Re, {
                    tag: t.tag
                })]
            }), e.jsxs("div", {
                className: "flex flex-row items-center gap-2",
                children: [e.jsxs("div", {
                    className: "flex flex-col items-end",
                    children: [t.original_price && e.jsx("span", {
                        className: "text-token-text-secondary text-xs line-through",
                        children: t.original_price
                    }), x && N ? e.jsx(H, {
                        label: N,
                        children: e.jsxs("span", {
                            className: "flex items-center gap-0.5",
                            children: [T, e.jsx(Y, {
                                className: "text-token-text-secondary h-3 w-3"
                            })]
                        })
                    }) : T]
                }), n ? i ? e.jsx(z, {
                    className: "w-fit truncate px-4",
                    disabled: l,
                    size: "medium",
                    color: "primary",
                    children: e.jsx(j, {
                        id: "vxb4gy",
                        defaultMessage: "Buy"
                    })
                }) : e.jsx(z, {
                    className: "w-fit truncate px-4",
                    size: "medium",
                    color: "secondary",
                    disabled: l,
                    children: e.jsx(j, {
                        id: "CvthQr",
                        defaultMessage: "Visit"
                    })
                }) : e.jsx(z, {
                    className: "w-fit min-w-20 truncate",
                    size: "small",
                    color: "secondary",
                    disabled: l,
                    children: e.jsx(j, {
                        id: "CvthQr",
                        defaultMessage: "Visit"
                    })
                })]
            })]
        }), !1]
    })
}
const ze = "https://persistent.oaistatic.com/chatgpt/pink_720.jpeg",
    We = (t, a) => {
        var s;
        return !(!t || ((s = t.tooltip) == null ? void 0 : s.type) === "instant_checkout" && !a)
    },
    Re = t => {
        "use forget";
        var l, c;
        const a = oe.c(3),
            {
                tag: s
            } = t;
        if (!s) return null;
        let n;
        return a[0] !== s.text || a[1] !== s.tooltip ? (n = s.tooltip ? e.jsx(H, {
            label: e.jsxs("div", {
                className: "flex flex-col items-center justify-center overflow-hidden",
                children: [e.jsxs("div", {
                    className: "relative flex h-44 w-full items-center justify-center overflow-hidden",
                    children: [e.jsx("div", {
                        className: "bg-token-bg-elevated-secondary absolute inset-0 h-44 w-full overflow-hidden",
                        children: e.jsx("img", {
                            src: ze,
                            alt: "tag background"
                        })
                    }), e.jsx("div", {
                        className: "outline-token-border-light z-1 inline-flex h-16 w-16 items-center justify-center overflow-hidden rounded-full bg-white shadow-lg outline",
                        children: e.jsx(Ie, {
                            className: "h-[18px] w-[18px] text-black"
                        })
                    })]
                }), e.jsxs("div", {
                    className: "flex flex-col items-center justify-start gap-2 self-stretch p-6 text-start",
                    children: [e.jsx("div", {
                        className: "w-full text-base leading-normal",
                        children: (l = s.tooltip) == null ? void 0 : l.title
                    }), e.jsx(Te, {
                        className: "text-token-text-secondary text-sm leading-relaxed font-normal",
                        components: {
                            a: Ve
                        },
                        children: (c = s.tooltip) == null ? void 0 : c.body_markdown
                    })]
                })]
            }),
            theme: "primary",
            side: "top",
            align: "start",
            customPaddingClassName: "p-0",
            cornerRadius: "2xl",
            contentClassName: "bg-token-bg-primary shadow-xl",
            interactive: !0,
            delayDuration: 500,
            children: e.jsxs("div", {
                className: "text-token-interactive-label-accent-default flex items-center gap-1 text-xs",
                children: [e.jsx(Y, {
                    className: "mt-[1px] h-3 w-3"
                }), e.jsx("span", {
                    className: "leading-3",
                    children: s.text
                })]
            })
        }) : e.jsx("div", {
            className: "text-token-interactive-label-accent-default flex items-center gap-1 text-xs",
            children: e.jsx("span", {
                className: "leading-3",
                children: s.text
            })
        }), a[0] = s.text, a[1] = s.tooltip, a[2] = n) : n = a[2], n
    };

function Ve(t) {
    return e.jsx("a", {
        href: t.href,
        className: S(t.className, "underline"),
        target: "_blank",
        rel: "noreferrer",
        children: t.children
    })
}

function Be({
    rating: t
}) {
    const a = Math.round(t * 2) / 2,
        s = "★";
    return e.jsx("div", {
        className: "flex flex-row",
        children: [1, 2, 3, 4, 5].map(n => e.jsxs("div", {
            children: [n <= a && e.jsx("span", {
                className: "text-yellow-500",
                children: s
            }), n === a + .5 && e.jsxs("div", {
                className: "relative inline-block",
                children: [e.jsx("span", {
                    className: "text-gray-200",
                    children: s
                }), e.jsx("span", {
                    className: "absolute start-0 top-0 w-1/2 overflow-hidden text-yellow-500",
                    children: s
                })]
            }), n > a + .5 && e.jsx("span", {
                className: "text-gray-200",
                children: s
            })]
        }, n))
    })
}

function mt({
    rating: t
}) {
    const a = Math.max(0, Math.min(1, t)),
        s = "★";
    return e.jsxs("div", {
        className: "relative inline-block",
        children: [e.jsx("span", {
            className: "text-gray-200",
            children: s
        }), e.jsx("span", {
            className: "absolute start-0 top-0 overflow-hidden text-yellow-500",
            style: {
                width: "".concat(a * 100, "%")
            },
            children: s
        })]
    })
}

function xt({
    rating: t,
    numReviews: a,
    ratingGroupedCitation: s,
    trackContentReferenceEvent: n,
    analyticsMetadata: l
}) {
    return e.jsxs("div", {
        className: "flex flex-col gap-1",
        children: [e.jsxs("div", {
            className: "text-token-text-secondary flex flex-row items-center gap-1 text-sm text-nowrap text-ellipsis",
            children: [e.jsx(Be, {
                rating: t != null ? t : 0
            }), e.jsx(j, {
                id: "Tj10jZ",
                defaultMessage: "{rating} ({num_reviews})",
                values: {
                    rating: (t != null ? t : 0).toFixed(1),
                    num_reviews: new Intl.NumberFormat().format(a)
                }
            }), e.jsx(H, {
                label: e.jsx(j, {
                    id: "zngDZ6",
                    defaultMessage: "Ratings and pricing are sourced from third parties which may update over time"
                }),
                children: e.jsx(Y, {
                    className: "h-4 w-4"
                })
            })]
        }), s && e.jsx($, {
            webpageItem: s,
            trackContentReferenceEvent: n,
            analyticsMetadata: V(R({}, l), {
                section: "products",
                section_location: "sidebar"
            }),
            isLastHovered: !0,
            noMarginStart: !0
        })]
    })
}
const B = ({
        durationMs: t,
        delayMs: a
    }) => ({
        "--duration": "".concat(t, "ms"),
        "--delay": "".concat(a, "ms")
    }),
    L = t => !!(h.isValidElement(t) && fe(["strong", "em"], t.type) && pe(t.props) && typeof t.props.children == "string"),
    te = (t, a) => typeof t == "string" ? a(t).length : L(t) ? a(t.props.children).length : 1,
    se = (t, a) => Array.isArray(t) ? Ae(t.map(s => se(s, a))) : te(t, a),
    Le = "YfNCsW_animate",
    qe = "YfNCsW_fadeIn",
    He = "YfNCsW_hidden",
    Ye = "YfNCsW_marker",
    q = {
        animate: Le,
        fadeIn: qe,
        hidden: He,
        marker: Ye
    },
    O = ({
        hideWordsUntilStart: t = !1,
        animationTiming: a,
        children: s,
        delayMs: n,
        index: l,
        segmentText: c,
        onReady: r,
        onComplete: d
    }) => {
        const [p, m] = h.useState(0), o = c(s);
        return e.jsx(e.Fragment, {
            children: o.map((u, x) => {
                const w = n + x * a.delayMs;
                return e.jsx("span", {
                    className: S(q.fadeIn, t && p < x && "sr-only"),
                    style: B({
                        delayMs: w,
                        durationMs: a.durationMs
                    }),
                    onAnimationStart: () => {
                        r(l + x), t && m(x)
                    },
                    onAnimationEnd: () => d(l + x),
                    children: u
                }, x)
            })
        })
    },
    $e = ({
        tag: t,
        children: a,
        start: s,
        end: n,
        isMarker: l,
        isLastNode: c,
        isOnlyNode: r
    }) => {
        const d = c === "",
            p = r === "",
            {
                enqueueElement: m,
                dequeueElement: o,
                updateElementBounds: u,
                reportComplete: x,
                reportProgress: w,
                reportReady: _,
                isDisabled: C,
                animationTiming: g,
                lastPositionCompletedAnimating: N,
                activeStartPos: I,
                segmentText: T
            } = h.useContext(we),
            i = h.useRef(null),
            b = () => {
                i.current != null && window.clearTimeout(i.current), i.current = window.setTimeout(() => {
                    _e.count(ge.DEFAULT, "text_entry_animation.timeout"), _(t, s != null ? s : 0), i.current = null
                }, 2e3)
            },
            k = !C;
        h.useEffect(() => {
            if (!(s == null || !k)) return m(t, s), () => o(t, s)
        }, [t, s, k]);
        const y = (!d || l) && s != null && n != null,
            M = h.useRef(!1),
            v = l ? 1 : se(a, T),
            f = v - 1;
        h.useEffect(() => {
            s != null && n != null && u(t, s, n, v), y && M.current !== !1 && M.current >= f ? _(t, s) : y && b()
        }, [y, f, v, s, n]);
        const P = D => {
                s != null && f > 0 && w(t, s, D / f), M.current = D, y && D >= f ? _(t, s) : y && b()
            },
            A = D => {
                l || D === f && (y || p && n != null) && x(n)
            },
            E = I != null && s != null && n != null && I > s && N != null && N >= n,
            X = I != null && s != null && s <= I;
        return {
            segmentText: T,
            onReady: P,
            onComplete: A,
            isDisabled: C || E,
            shouldHide: !C && !X && !E,
            shouldAnimate: X,
            animationTiming: g
        }
    },
    Xe = ({
        tag: t,
        children: a,
        "data-start": s = null,
        "data-end": n = null,
        "data-is-last-node": l,
        "data-is-only-node": c
    }) => {
        const {
            animationTiming: r,
            shouldHide: d,
            isDisabled: p,
            segmentText: m,
            onComplete: o,
            onReady: u
        } = $e({
            isMarker: !1,
            tag: t,
            children: a,
            start: s,
            end: n,
            isLastNode: l,
            isOnlyNode: c
        });
        if (p || d) return e.jsx(t, {
            "data-start": s,
            "data-end": n,
            className: S(d && "hidden!"),
            children: a
        });
        let x = 0,
            w = 0;
        return e.jsx(t, {
            "data-start": s,
            "data-end": n,
            children: typeof a == "string" ? e.jsx(O, {
                index: 0,
                segmentText: m,
                delayMs: x,
                animationTiming: r,
                onReady: u,
                onComplete: o,
                children: a
            }, 0) : L(a) ? h.cloneElement(a, a.props, e.jsx(O, {
                index: 0,
                delayMs: x,
                animationTiming: r,
                segmentText: m,
                onReady: u,
                onComplete: o,
                children: a.props.children
            }, 0)) : Array.isArray(a) ? a.map(_ => {
                const C = x,
                    g = w,
                    N = te(_, m);
                return w += N, x += N * r.delayMs, typeof _ == "string" ? e.jsx(O, {
                    index: g,
                    delayMs: C,
                    animationTiming: r,
                    segmentText: m,
                    onReady: u,
                    onComplete: o,
                    children: _
                }, g) : L(_) ? h.cloneElement(_, _.props, e.jsx(O, {
                    index: g,
                    delayMs: C,
                    animationTiming: r,
                    segmentText: m,
                    onReady: u,
                    onComplete: o,
                    children: _.props.children
                }, g)) : e.jsx("span", {
                    className: q.fadeIn,
                    style: B({
                        delayMs: x,
                        durationMs: r.durationMs
                    }),
                    onAnimationStart: () => u(g),
                    onAnimationEnd: () => o(g),
                    children: _
                }, g)
            }) : e.jsx("span", {
                className: q.fadeIn,
                style: B({
                    delayMs: x,
                    durationMs: r.durationMs
                }),
                onAnimationStart: () => u(0),
                onAnimationEnd: () => o(0),
                children: a
            }, 0)
        })
    };

function ae({
    title: t,
    children: a
}) {
    return e.jsxs("div", {
        children: [e.jsx("div", {
            className: "border-token-border-light bg-token-bg-primary text-token-text-primary sticky top-0 z-10 flex items-center border-t px-6 py-4 text-base font-semibold",
            children: t
        }), e.jsx("div", {
            className: "px-6 pb-3",
            children: a
        })]
    })
}

function ht({
    contentReference: t,
    trackContentReferenceEvent: a,
    disableAnimation: s
}) {
    const n = h.useRef(!1);
    return h.useEffect(() => {
        t && !n.current && (n.current = !0, a("Product Sidebar Rationale Loaded", "product_sidebar_rationale_loaded", "product_rationale"))
    }, [t, a]), t ? e.jsx(ae, {
        title: e.jsx(j, {
            id: "XgsZPF",
            defaultMessage: "Why you might like this"
        }),
        children: e.jsx("div", {
            className: "text-sm",
            children: e.jsx(ee, {
                isDisabled: s,
                children: e.jsxs(Xe, {
                    tag: "p",
                    "data-start": 0,
                    "data-end": t.rationale.length,
                    children: [e.jsx("span", {
                        className: "me-1",
                        children: t.rationale
                    }), t.grouped_citation && e.jsx($, {
                        webpageItem: t.grouped_citation,
                        trackContentReferenceEvent: a,
                        analyticsMetadata: {
                            section: "product_rationale",
                            section_location: "sidebar"
                        },
                        isLastHovered: !0,
                        noMarginStart: !0
                    })]
                })
            })
        })
    }) : null
}
const Je = {
        positive: Pe,
        negative: Me,
        neutral: Z,
        mixed: Z
    },
    Qe = {
        positive: "Positive",
        negative: "Negative",
        neutral: "Mixed",
        mixed: "Mixed"
    };

function ft({
    contentReference: t,
    trackContentReferenceEvent: a,
    disableAnimation: s
}) {
    const n = h.useRef(!1);
    h.useEffect(() => {
        t && !n.current && (n.current = !0, a("Product Sidebar Reviews Loaded", "product_sidebar_reviews_loaded", "product_reviews"))
    }, [t, a]);

    function l(r) {
        return new URL(r).hostname.replace(/^www\./, "")
    }

    function c(r) {
        var d;
        return t ? r.cite ? (d = t.cite_map[r.cite]) == null ? void 0 : d.url : r.cite_url : null
    }
    return t ? e.jsx(ae, {
        title: e.jsx(j, {
            id: "p8XHcJ",
            defaultMessage: "What people are saying"
        }),
        children: e.jsxs("div", {
            className: "flex flex-col gap-6",
            children: [t.summary && e.jsx(ee, {
                isDisabled: s,
                children: e.jsx(Se, {
                    className: "-mb-2 text-sm",
                    children: t.summary
                })
            }), t.reviews.map((r, d) => {
                var o;
                const p = Je[(o = r.sentiment) != null ? o : "neutral"],
                    m = c(r);
                return e.jsxs(W.div, {
                    className: "relative flex flex-col gap-2",
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    transition: {
                        duration: s ? 0 : .4
                    },
                    children: [e.jsxs("div", {
                        className: S("flex flex-row items-center gap-2", "not-prose"),
                        children: [e.jsx(U, {
                            url: m != null ? m : "",
                            className: "h-8 w-8 rounded-full",
                            size: 128,
                            minSize: 16,
                            fallback: e.jsx(G, {
                                className: "text-token-text-tertiary"
                            })
                        }), e.jsxs("div", {
                            className: "flex flex-col",
                            children: [e.jsx("div", {
                                className: "text-sm font-semibold",
                                children: r.source
                            }), e.jsxs("div", {
                                className: "text-token-text-secondary flex flex-row gap-1 text-xs",
                                children: [e.jsx("div", {
                                    children: m ? l(m) : ""
                                }), r.sentiment && p && e.jsxs(e.Fragment, {
                                    children: ["·", e.jsx(p, {
                                        className: "icon-sm text-token-text-secondary"
                                    }), Qe[r.sentiment]]
                                })]
                            })]
                        })]
                    }), e.jsxs("div", {
                        className: "text-sm",
                        children: [r.theme && e.jsx("div", {
                            className: "font-semibold",
                            children: r.theme
                        }), e.jsx("span", {
                            className: "me-1",
                            children: r.summary
                        }), e.jsx(Ze, {
                            cite: r.cite,
                            contentReference: t,
                            trackContentReferenceEvent: a
                        })]
                    })]
                }, d)
            })]
        })
    }) : null
}

function Ze({
    cite: t,
    contentReference: a,
    trackContentReferenceEvent: s,
    analyticsMetadata: n
}) {
    const {
        cite_map: l
    } = a, c = t ? l[t] : null;
    return c ? e.jsx($, {
        webpageItem: c,
        trackContentReferenceEvent: s,
        analyticsMetadata: V(R({}, n), {
            section: "product_reviews",
            section_location: "sidebar"
        }),
        isLastHovered: !0,
        noMarginStart: !0
    }) : null
}
const Ke = ({
        options: t,
        onSelect: a,
        isErrored: s
    }) => {
        var n, l;
        return e.jsxs(F.Root, {
            children: [e.jsxs(F.Trigger, {
                className: S("radix-state-open:border-token-text-primary border-token-border-heavy bg-token-bg-primary text-token-text-secondary hover:bg-token-bg-primary h-12 w-full justify-between rounded-2xl border px-4 py-3 text-start", s && "border-token-interactive-label-danger-secondary-default"),
                children: [(l = (n = t == null ? void 0 : t.find(c => c.selected)) == null ? void 0 : n.label) != null ? l : e.jsx(j, {
                    id: "FxgwoS",
                    defaultMessage: "Choose an option"
                }), e.jsx(Ce, {
                    className: "ms-0.5 h-4 w-4 shrink-0"
                })]
            }), e.jsx(F.Portal, {
                children: e.jsx(F.Content, {
                    children: t == null ? void 0 : t.map((c, r) => {
                        var d;
                        return e.jsx(F.Item, {
                            "aria-label": (d = c.label) != null ? d : "",
                            onClick: () => a(c.id, r),
                            className: S(c.available === !1 && "text-token-text-tertiary"),
                            children: c.label
                        }, c.id)
                    })
                })
            })]
        })
    },
    Ue = ({
        options: t,
        onSelect: a
    }) => e.jsx("div", {
        className: "flex flex-wrap gap-2",
        children: t.map((s, n) => e.jsx("button", {
            type: "button",
            "aria-label": s.label,
            className: S("flex items-center justify-center rounded-full border-2 px-4 py-2 text-lg text-xs font-medium transition-all", s.selected ? "bg-token-bg-primary border-black" : "bg-token-bg-tertiary border-transparent", s.available === !1 && "opacity-50"),
            onClick: () => a(s.id, n),
            children: s.label
        }, s.id))
    }),
    Ge = ({
        options: t,
        onSelect: a
    }) => e.jsx("div", {
        className: "flex flex-wrap items-center gap-3",
        children: t.map((s, n) => e.jsx("button", {
            type: "button",
            "aria-label": s.label,
            className: S("flex h-9 w-9 items-center justify-center rounded-lg outline-2 outline-offset-1 transition-all", !s.selected && "outline-transparent", s.available === !1 && "opacity-50"),
            onClick: () => a(s.id, n),
            children: s.swatch_color_hex ? e.jsx("span", {
                className: "block h-9 w-9 rounded-lg border",
                style: {
                    backgroundColor: s.swatch_color_hex
                }
            }) : s.swatch_image_url ? e.jsx("img", {
                className: "h-9 w-9 rounded-lg object-cover",
                src: s.swatch_image_url,
                alt: s.label
            }) : null
        }, s.id))
    }),
    K = t => {
        var a;
        return (a = t == null ? void 0 : t.replace(/_/g, " ").replace(/\s+/g, " ").trim()) != null ? a : ""
    };

function pt({
    options: t,
    updateOption: a,
    showErrors: s
}) {
    return t ? e.jsx(e.Fragment, {
        children: t.map((n, l) => {
            var c;
            return e.jsxs("div", {
                className: S("flex flex-col gap-1.5", l > 0 && "mt-4"),
                children: [e.jsxs("div", {
                    className: "flex items-center gap-1",
                    children: [e.jsx("span", {
                        className: "text-sm font-medium capitalize",
                        children: K(n.label)
                    }), n.type !== "dropdown" && n.selected_option_id && e.jsxs(e.Fragment, {
                        children: [e.jsx(j, {
                            id: "6JW/+Y",
                            defaultMessage: "•"
                        }), e.jsx("span", {
                            className: "text-token-text-secondary text-sm",
                            children: K((c = n.options.find(r => r.id === n.selected_option_id)) == null ? void 0 : c.label)
                        })]
                    })]
                }), n.type === "swatch" ? e.jsx(Ge, {
                    options: n.options,
                    onSelect: (r, d) => a(n.id, r, d)
                }) : n.type === "pill" ? e.jsx(Ue, {
                    options: n.options,
                    onSelect: (r, d) => a(n.id, r, d)
                }) : e.jsx(Ke, {
                    options: n.options,
                    onSelect: (r, d) => a(n.id, r, d),
                    isErrored: s && !n.selected_option_id
                }), !n.selected_option_id && s && e.jsxs("div", {
                    className: "text-token-interactive-label-danger-secondary-default flex items-center gap-1 text-sm",
                    children: [e.jsx(be, {
                        className: "icon-sm"
                    }), e.jsx(j, {
                        id: "UsAVv3",
                        defaultMessage: "Choose an option"
                    })]
                })]
            }, n.id)
        })
    }) : null
}
export {
    mt as C, Xe as F, dt as I, xt as P, pt as a, ut as b, ht as c, ft as d, B as g, q as s, $e as u
};
//# sourceMappingURL=bcsv6m4oh341rml5.js.map