var F = Object.defineProperty,
    G = Object.defineProperties;
var H = Object.getOwnPropertyDescriptors;
var L = Object.getOwnPropertySymbols;
var J = Object.prototype.hasOwnProperty,
    O = Object.prototype.propertyIsEnumerable;
var P = (c, e, i) => e in c ? F(c, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: i
    }) : c[e] = i,
    v = (c, e) => {
        for (var i in e || (e = {})) J.call(e, i) && P(c, i, e[i]);
        if (L)
            for (var i of L(e)) O.call(e, i) && P(c, i, e[i]);
        return c
    },
    A = (c, e) => G(c, H(e));
import {
    e7 as V,
    e4 as M,
    kH as r,
    I as K,
    p5 as Q,
    e2 as W,
    _ as U
} from "./dykg4ktvbu3mhmdo.js";
import {
    groupGlauxMessages as X
} from "./obmzp3ebe8x6w67a.js";
import {
    er as h,
    es as Y,
    et as Z,
    eu as $,
    ev as ee,
    ew as se
} from "./k15yxxoybkkir2ou.js";
import {
    h as te
} from "./gd2ozzf4upgi0amm.js";
const b = new WeakMap;

function le(c, e, i) {
    const m = [];
    let _ = !1,
        f = !1;
    const T = l => {
        if (f) return !0;
        const {
            recipient: g
        } = l;
        return typeof g == "string" && g.startsWith("computer")
    };
    return e.forEach((l, g) => {
        const y = g === e.length - 1;
        let u = b.get([l, y]);
        if (!u) {
            const d = e[g - 1];
            u = ae(c, l, y, d, i), u && b.set([l, y], u)
        }
        u && m.push(...u), f || (f = l.messages.some(T)), _ || (_ = _ || l.messages.some(d => {
            var k;
            return ((k = d.metadata) == null ? void 0 : k.n7jupd_message) && d.author.name !== V.n7jupd_m && d.content.content_type !== M.StructuredThoughts && d.content.content_type !== M.ReasoningRecap
        }))
    }), {
        chunks: m,
        isAgentVisualCoT: _,
        containsAuraComputerTool: f
    }
}

function ae(c, e, i, m, _ = !1) {
    var f, T, l, g, y, u, d, k, w, z, R, I, q, S, j, N, x;
    switch (e.type) {
        case r.ReasoningRecap:
            {
                if (_ && !i && (m == null ? void 0 : m.type) === r.StructuredThoughts && m.messages.length === 1 && ((f = m.messages[0].content.thoughts) == null ? void 0 : f.length) === 0) return [];
                const t = e.messages[e.messages.length - 1],
                    s = t.content.content;
                return [{
                    type: h.Recap,
                    content: s,
                    didFailReasoning: ((T = t.metadata) == null ? void 0 : T.reasoning_status) === "reasoning_cancelled",
                    didSkipReasoning: ((l = t.metadata) == null ? void 0 : l.reasoning_status) === "reasoning_skipped"
                }]
            }
        case r.Browsing:
        case r.RetrievalBrowsing:
            {
                const t = se({
                    messages: e.messages
                });
                return [{
                    type: h.Browsing,
                    sources: t,
                    isRetrieval: e.type === r.RetrievalBrowsing,
                    title: (g = e.messages[0].metadata) == null ? void 0 : g.reasoning_title
                }]
            }
        case r.StructuredThoughts:
            {
                const t = [];
                for (const s of e.messages) {
                    const {
                        thoughts: n
                    } = s.content;
                    for (const a of n) !a.content && !a.summary || t.push({
                        type: h.Thought,
                        thought: a
                    })
                }
                return t
            }
        case r.CodeInterpreter:
        case r.Container:
            {
                let t = e.messages.slice(1);
                const s = e.messages[0];
                let n = !0;
                if (s.author.role === W.Tool) t = e.messages,
                n = !1;
                else if (s.author.role !== W.Assistant) {
                    U.addError(new Error("[cot] out of order code tool messages"));
                    break
                }
                return (t.length > 0 ? t : [null]).map((o, C) => {
                    var p, B, D;
                    return {
                        type: o != null && (te(o) || ((B = (p = o.metadata) == null ? void 0 : p.attachments) == null ? void 0 : B.length)) ? h.ImageAnalysis : h.CodeAnalysis,
                        toolMessage: o,
                        assistantMessage: C === 0 && n ? s : void 0,
                        messages: e.messages,
                        title: C === 0 && n ? (D = s.metadata) == null ? void 0 : D.reasoning_title : void 0
                    }
                })
            }
        case r.CoTSearchTool:
            {
                const t = {
                    type: h.Search,
                    queries: [],
                    sources: []
                };
                for (const s of e.messages)
                    if ((y = s.metadata) != null && y.reasoning_title && (t.title = s.metadata.reasoning_title), (d = (u = s.metadata) == null ? void 0 : u.search_queries) != null && d.length && (t.queries = s.metadata.search_queries), (w = (k = s.metadata) == null ? void 0 : k.search_result_groups) != null && w.length)
                        for (const n of s.metadata.search_result_groups)(z = t == null ? void 0 : t.sources) != null && z.some(a => a.domain === n.domain) || (R = t.sources) == null || R.push(n);
                return [t]
            }
        case r.n7jupd:
            return ee(e.messages, i);
        case r.n7jupd_x:
            return $(e);
        case r.n7jupd_a:
            return Z(e);
        case r.n7jupd_native_api_tool:
            return Y(e);
        case r.e1ld0dvz:
            {
                const t = [],
                    s = new Map;
                for (const n of e.messages)
                    if (n.content.content_type === M.Code) {
                        if ((I = n.metadata) != null && I.e1ld0dvz_tasks)
                            for (const a of n.metadata.e1ld0dvz_tasks) s.set(a.id, {
                                id: a.id,
                                status: "running",
                                model: a.model,
                                instruction: a.instruction,
                                startedAtMs: (q = n.metadata) != null && q.e1ld0dvz_task_create_time ? (S = n.metadata) == null ? void 0 : S.e1ld0dvz_task_create_time : Date.now()
                            });
                        else if ((j = n.metadata) != null && j.e1ld0dvz_task_ids)
                            for (const a of n.metadata.e1ld0dvz_task_ids)
                                if (s.has(a)) {
                                    const o = s.get(a);
                                    o && s.set(a, A(v({}, o), {
                                        status: "gathering"
                                    }))
                                } else s.set(a, {
                                    id: a,
                                    status: "gathering"
                                })
                    } else if (((N = n.metadata) == null ? void 0 : N.e1ld0dvz_status) === "completed" && ((x = n.metadata) != null && x.e1ld0dvz_task_id)) {
                    const a = n.metadata.e1ld0dvz_task_id,
                        o = s.get(a);
                    o ? s.set(a, A(v({}, o), {
                        status: "completed"
                    })) : s.set(a, {
                        id: a,
                        status: "completed"
                    })
                }
                return t.push({
                    type: h.e1ld0dvz,
                    tasks: Array.from(s.values())
                }),
                t
            }
        case r.Glaux:
            {
                const t = X(e.messages),
                    s = K(c),
                    n = Q(s == null ? void 0 : s.planType),
                    a = [];
                for (const o of t) {
                    if (o.call === "unhandled") continue;
                    const C = o.call.isMixer ? o.call.queries.map(p => ({
                        connectorName: p.connectorName,
                        query: p.query
                    })) : [{
                        connectorName: o.call.connectorName,
                        query: o.call.query
                    }];
                    if (!C.length) continue;
                    const E = o.results.map(p => v({}, p));
                    a.push({
                        type: h.Glaux,
                        queries: C,
                        results: E,
                        isEducationPlan: n
                    })
                }
                return a
            }
        case r.Strix:
            return []
    }
}
export {
    le as p
};
//# sourceMappingURL=msn8hpk3ivp7ibnw.js.map