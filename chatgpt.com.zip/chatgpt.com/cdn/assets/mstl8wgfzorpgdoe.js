var _t = Object.defineProperty;
var pt = (f, G, w) => G in f ? _t(f, G, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: w
}) : f[G] = w;
var tt = (f, G, w) => pt(f, typeof G != "symbol" ? G + "" : G, w);
var et = {},
    k = {},
    nt = {},
    at;

function ht() {
    if (at) return nt;
    at = 1, Object.defineProperty(nt, "__esModule", {
        value: !0
    }), nt.cast = G, nt.get = w, nt.set = y;
    const f = 2 ** 32;

    function G(c) {
        return c < 0 ? c + f : c
    }

    function w(c, h) {
        return c >> h & 255
    }

    function y(c, h, p) {
        return c ^ (c ^ p << h) & 255 << h
    }
    return nt
}
var ct;

function ot() {
    return ct || (ct = 1, (function(f) {
        var G = k && k.__createBinding || (Object.create ? (function(r, t, o, d) {
                d === void 0 && (d = o);
                var l = Object.getOwnPropertyDescriptor(t, o);
                (!l || ("get" in l ? !t.__esModule : l.writable || l.configurable)) && (l = {
                    enumerable: !0,
                    get: function() {
                        return t[o]
                    }
                }), Object.defineProperty(r, d, l)
            }) : (function(r, t, o, d) {
                d === void 0 && (d = o), r[d] = t[o]
            })),
            w = k && k.__setModuleDefault || (Object.create ? (function(r, t) {
                Object.defineProperty(r, "default", {
                    enumerable: !0,
                    value: t
                })
            }) : function(r, t) {
                r.default = t
            }),
            y = k && k.__importStar || function(r) {
                if (r && r.__esModule) return r;
                var t = {};
                if (r != null)
                    for (var o in r) o !== "default" && Object.prototype.hasOwnProperty.call(r, o) && G(t, r, o);
                return w(t, r), t
            };
        Object.defineProperty(f, "__esModule", {
            value: !0
        }), f.OFFSET_A = f.OFFSET_B = f.OFFSET_G = f.OFFSET_R = void 0, f.newColor = z, f.from = P, f.toNumber = Y, f.getRed = K, f.getGreen = J, f.getBlue = Z, f.getAlpha = M, f.setRed = b, f.setGreen = O, f.setBlue = R, f.setAlpha = B;
        const c = y(ht()),
            {
                cast: h,
                get: p,
                set: F
            } = c;
        f.OFFSET_R = 24, f.OFFSET_G = 16, f.OFFSET_B = 8, f.OFFSET_A = 0;

        function z(r, t, o, d) {
            return (r << f.OFFSET_R) + (t << f.OFFSET_G) + (o << f.OFFSET_B) + (d << f.OFFSET_A)
        }

        function P(r) {
            return z(p(r, f.OFFSET_R), p(r, f.OFFSET_G), p(r, f.OFFSET_B), p(r, f.OFFSET_A))
        }

        function Y(r) {
            return h(r)
        }

        function K(r) {
            return p(r, f.OFFSET_R)
        }

        function J(r) {
            return p(r, f.OFFSET_G)
        }

        function Z(r) {
            return p(r, f.OFFSET_B)
        }

        function M(r) {
            return p(r, f.OFFSET_A)
        }

        function b(r, t) {
            return F(r, f.OFFSET_R, t)
        }

        function O(r, t) {
            return F(r, f.OFFSET_G, t)
        }

        function R(r, t) {
            return F(r, f.OFFSET_B, t)
        }

        function B(r, t) {
            return F(r, f.OFFSET_A, t)
        }
    })(k)), k
}
var q = {},
    I = {},
    st;

function bt() {
    if (st) return I;
    st = 1, Object.defineProperty(I, "__esModule", {
        value: !0
    }), I.labToXyzd50 = r, I.xyzd50ToLab = t, I.oklabToXyzd65 = o, I.xyzd65ToOklab = d, I.lchToLab = l, I.labToLch = T, I.displayP3ToXyzd50 = H, I.xyzd50ToDisplayP3 = $, I.proPhotoToXyzd50 = e, I.xyzd50ToProPhoto = _, I.adobeRGBToXyzd50 = g, I.xyzd50ToAdobeRGB = A, I.rec2020ToXyzd50 = x, I.xyzd50ToRec2020 = W, I.xyzd50ToD65 = N, I.xyzd65ToD50 = rt, I.xyzd65TosRGBLinear = X, I.xyzd50TosRGBLinear = E, I.srgbLinearToXyzd50 = S, I.srgbToXyzd50 = v, I.xyzd50ToSrgb = m, I.oklchToXyzd50 = Q, I.xyzd50ToOklch = U;
    const f = .9642,
        G = 1,
        w = .8251;

    function y(u, n) {
        const s = [0, 0, 0];
        for (let i = 0; i < 3; ++i) s[i] = u[i][0] * n[0] + u[i][1] * n[1] + u[i][2] * n[2];
        return s
    }
    class c {
        constructor(n, s, i = 0, a = 0, C = 0, D = 0, j = 0) {
            tt(this, "g");
            tt(this, "a");
            tt(this, "b");
            tt(this, "c");
            tt(this, "d");
            tt(this, "e");
            tt(this, "f");
            this.g = n, this.a = s, this.b = i, this.c = a, this.d = C, this.e = D, this.f = j
        }
        eval(n) {
            const s = n < 0 ? -1 : 1,
                i = n * s;
            return i < this.d ? s * (this.c * i + this.f) : s * (Math.pow(this.a * i + this.b, this.g) + this.e)
        }
    }
    const h = {
            sRGB: new c(2.4, 1 / 1.055, .055 / 1.055, 1 / 12.92, .04045, 0, 0),
            sRGB_INVERSE: new c(.416667, 1.13728, -0, 12.92, .0031308, -.0549698, -0),
            proPhotoRGB: new c(1.8, 1),
            proPhotoRGB_INVERSE: new c(.555556, 1, -0, 0, 0, 0, 0),
            k2Dot2: new c(2.2, 1),
            k2Dot2_INVERSE: new c(.454545, 1),
            rec2020: new c(2.22222, .909672, .0903276, .222222, .0812429, 0, 0),
            rec2020_INVERSE: new c(.45, 1.23439, -0, 4.5, .018054, -.0993195, -0)
        },
        p = {
            sRGB: [
                [.436065674, .385147095, .143066406],
                [.222488403, .716873169, .06060791],
                [.013916016, .097076416, .714096069]
            ],
            sRGB_INVERSE: [
                [3.134112151374599, -1.6173924597114966, -.4906334036481285],
                [-.9787872938826594, 1.9162795854799963, .0334547139520088],
                [.07198304248352326, -.2289858493321844, 1.4053851325241447]
            ],
            displayP3: [
                [.515102, .291965, .157153],
                [.241182, .692236, .0665819],
                [-.00104941, .0418818, .784378]
            ],
            displayP3_INVERSE: [
                [2.404045155982687, -.9898986932663839, -.3976317191366333],
                [-.8422283799266768, 1.7988505115115485, .016048170293157416],
                [.04818705979712955, -.09737385156228891, 1.2735066448052303]
            ],
            adobeRGB: [
                [.60974, .20528, .14919],
                [.31111, .62567, .06322],
                [.01947, .06087, .74457]
            ],
            adobeRGB_INVERSE: [
                [1.9625385510109137, -.6106892546501431, -.3413827467482388],
                [-.9787580455521, 1.9161624707082339, .03341676594241408],
                [.028696263137883395, -.1406807819331586, 1.349252109991369]
            ],
            rec2020: [
                [.673459, .165661, .1251],
                [.279033, .675338, .0456288],
                [-.00193139, .0299794, .797162]
            ],
            rec2020_INVERSE: [
                [1.647275201661012, -.3936024771460771, -.23598028884792507],
                [-.6826176165196962, 1.647617775014935, .01281626807852422],
                [.029662725298529837, -.06291668721366285, 1.2533964313435522]
            ]
        };

    function F(u) {
        return u * (Math.PI / 180)
    }

    function z(u) {
        return u * (180 / Math.PI)
    }

    function P(u, n, s, i) {
        return [u.eval(n), u.eval(s), u.eval(i)]
    }
    const Y = [
            [.9999999984505198, .39633779217376786, .2158037580607588],
            [1.0000000088817609, -.10556134232365635, -.06385417477170591],
            [1.0000000546724108, -.08948418209496575, -1.2914855378640917]
        ],
        K = [
            [.2104542553, .7936177849999999, -.0040720468],
            [1.9779984951000003, -2.4285922049999997, .4505937099000001],
            [.025904037099999982, .7827717662, -.8086757660000001]
        ],
        J = [
            [.8190224432164319, .3619062562801221, -.12887378261216414],
            [.0329836671980271, .9292868468965546, .03614466816999844],
            [.048177199566046255, .26423952494422764, .6335478258136937]
        ],
        Z = [
            [1.226879873374156, -.5578149965554814, .2813910501772159],
            [-.040575762624313734, 1.1122868293970596, -.07171106666151703],
            [-.07637294974672144, -.4214933239627915, 1.586924024427242]
        ],
        M = [
            [.7976700747153241, .13519395152800417, .03135596341127167],
            [.28803902352472205, .7118744007923554, 8661179538844252e-20],
            [2739876695467402e-22, -14405226518969991e-22, .825211112593861]
        ],
        b = [
            [1.3459533710138858, -.25561367037652133, -.051116041522131374],
            [-.544600415668951, 1.5081687311475767, .020535163968720935],
            [-13975622054109725e-22, 2717590904589903e-21, 1.2118111696814942]
        ],
        O = [
            [1.0478573189120088, .022907374491829943, -.050162247377152525],
            [.029570500050499514, .9904755577034089, -.017061518194840468],
            [-.00924047197558879, .015052921526981566, .7519708530777581]
        ],
        R = [
            [.9555366447632887, -.02306009252137888, .06321844147263304],
            [-.028315378228764922, 1.009951351591575, .021026001591792402],
            [.012308773293784308, -.02050053471777469, 1.3301947294775631]
        ],
        B = [
            [3.2408089365140573, -1.5375788839307314, -.4985609572551541],
            [-.9692732213205414, 1.876110235238969, .041560501141251774],
            [.05567030990267439, -.2040007921971802, 1.0571046720577026]
        ];

    function r(u, n, s) {
        let i = (u + 16) / 116,
            a = i + n / 500,
            C = i - s / 200;

        function D(j) {
            return j <= .20689655172413793 ? 108 / 841 * (j - 16 / 116) : j * j * j
        }
        return a = D(a) * f, i = D(i) * G, C = D(C) * w, [a, i, C]
    }

    function t(u, n, s) {
        function i(j) {
            return j <= .008856451679035631 ? 841 / 108 * j + 16 / 116 : Math.pow(j, 1 / 3)
        }
        u = i(u / f), n = i(n / G), s = i(s / w);
        const a = 116 * n - 16,
            C = 500 * (u - n),
            D = 200 * (n - s);
        return [a, C, D]
    }

    function o(u, n, s) {
        const a = y(Y, [u, n, s]);
        return a[0] = a[0] * a[0] * a[0], a[1] = a[1] * a[1] * a[1], a[2] = a[2] * a[2] * a[2], y(Z, a)
    }

    function d(u, n, s) {
        const a = y(J, [u, n, s]);
        a[0] = Math.pow(a[0], 1 / 3), a[1] = Math.pow(a[1], 1 / 3), a[2] = Math.pow(a[2], 1 / 3);
        const C = y(K, a);
        return [C[0], C[1], C[2]]
    }

    function l(u, n, s) {
        return s === void 0 ? [u, 0, 0] : [u, n * Math.cos(F(s)), n * Math.sin(F(s))]
    }

    function T(u, n, s) {
        return [u, Math.sqrt(n * n + s * s), z(Math.atan2(s, n))]
    }

    function H(u, n, s) {
        const [i, a, C] = P(h.sRGB, u, n, s), D = [i, a, C];
        return y(p.displayP3, D)
    }

    function $(u, n, s) {
        const i = [u, n, s],
            a = y(p.displayP3_INVERSE, i);
        return P(h.sRGB_INVERSE, a[0], a[1], a[2])
    }

    function e(u, n, s) {
        const [i, a, C] = P(h.proPhotoRGB, u, n, s);
        return y(M, [i, a, C])
    }

    function _(u, n, s) {
        const a = y(b, [u, n, s]);
        return P(h.proPhotoRGB_INVERSE, a[0], a[1], a[2])
    }

    function g(u, n, s) {
        const [i, a, C] = P(h.k2Dot2, u, n, s), D = [i, a, C];
        return y(p.adobeRGB, D)
    }

    function A(u, n, s) {
        const i = [u, n, s],
            a = y(p.adobeRGB_INVERSE, i);
        return P(h.k2Dot2_INVERSE, a[0], a[1], a[2])
    }

    function x(u, n, s) {
        const [i, a, C] = P(h.rec2020, u, n, s), D = [i, a, C];
        return y(p.rec2020, D)
    }

    function W(u, n, s) {
        const i = [u, n, s],
            a = y(p.rec2020_INVERSE, i);
        return P(h.rec2020_INVERSE, a[0], a[1], a[2])
    }

    function N(u, n, s) {
        return y(R, [u, n, s])
    }

    function rt(u, n, s) {
        return y(O, [u, n, s])
    }

    function X(u, n, s) {
        return y(B, [u, n, s])
    }

    function E(u, n, s) {
        const i = [u, n, s];
        return y(p.sRGB_INVERSE, i)
    }

    function S(u, n, s) {
        const i = [u, n, s];
        return y(p.sRGB, i)
    }

    function v(u, n, s) {
        const [i, a, C] = P(h.sRGB, u, n, s), D = [i, a, C];
        return y(p.sRGB, D)
    }

    function m(u, n, s) {
        const i = [u, n, s],
            a = y(p.sRGB_INVERSE, i);
        return P(h.sRGB_INVERSE, a[0], a[1], a[2])
    }

    function Q(u, n, s) {
        const [i, a, C] = l(u, n, s), [D, j, ut] = o(i, a, C);
        return rt(D, j, ut)
    }

    function U(u, n, s) {
        const [i, a, C] = N(u, n, s), [D, j, ut] = d(i, a, C);
        return T(D, j, ut)
    }
    return I
}
var it;

function yt() {
    if (it) return q;
    it = 1;
    var f = q && q.__createBinding || (Object.create ? (function(e, _, g, A) {
            A === void 0 && (A = g);
            var x = Object.getOwnPropertyDescriptor(_, g);
            (!x || ("get" in x ? !_.__esModule : x.writable || x.configurable)) && (x = {
                enumerable: !0,
                get: function() {
                    return _[g]
                }
            }), Object.defineProperty(e, A, x)
        }) : (function(e, _, g, A) {
            A === void 0 && (A = g), e[A] = _[g]
        })),
        G = q && q.__setModuleDefault || (Object.create ? (function(e, _) {
            Object.defineProperty(e, "default", {
                enumerable: !0,
                value: _
            })
        }) : function(e, _) {
            e.default = _
        }),
        w = q && q.__importStar || function(e) {
            if (e && e.__esModule) return e;
            var _ = {};
            if (e != null)
                for (var g in e) g !== "default" && Object.prototype.hasOwnProperty.call(e, g) && f(_, e, g);
            return G(_, e), _
        };
    Object.defineProperty(q, "__esModule", {
        value: !0
    }), q.parse = J, q.parseHex = Z, q.parseColor = b;
    const y = ot(),
        c = w(bt()),
        h = 35,
        p = 37,
        F = 103,
        z = 110,
        P = 100,
        Y = 101,
        K = (() => {
            const e = "(\\w+)",
                _ = "[\\s,\\/]",
                g = "([^\\s,\\/]+)",
                A = "(?:".concat(_, "+").concat(g, ")");
            return new RegExp("".concat(e, "\\(\n      ").concat(_, "*\n      ").concat(g, "\n      ").concat(A, "\n      ").concat(A, "\n      ").concat(A, "?\n      ").concat(A, "?\n      ").concat(_, "*\n    \\)").replace(/\s/g, ""))
        })();

    function J(e) {
        return e.charCodeAt(0) === h ? Z(e) : b(e)
    }

    function Z(e) {
        let _ = 0,
            g = 0,
            A = 0,
            x = 255;
        switch (e.length) {
            case 4:
                {
                    _ = (M(e.charCodeAt(1)) << 4) + M(e.charCodeAt(1)),
                    g = (M(e.charCodeAt(2)) << 4) + M(e.charCodeAt(2)),
                    A = (M(e.charCodeAt(3)) << 4) + M(e.charCodeAt(3));
                    break
                }
            case 7:
                {
                    _ = (M(e.charCodeAt(1)) << 4) + M(e.charCodeAt(2)),
                    g = (M(e.charCodeAt(3)) << 4) + M(e.charCodeAt(4)),
                    A = (M(e.charCodeAt(5)) << 4) + M(e.charCodeAt(6));
                    break
                }
            case 9:
                {
                    _ = (M(e.charCodeAt(1)) << 4) + M(e.charCodeAt(2)),
                    g = (M(e.charCodeAt(3)) << 4) + M(e.charCodeAt(4)),
                    A = (M(e.charCodeAt(5)) << 4) + M(e.charCodeAt(6)),
                    x = (M(e.charCodeAt(7)) << 4) + M(e.charCodeAt(8));
                    break
                }
        }
        return (0, y.newColor)(_, g, A, x)
    }

    function M(e) {
        return (e & 15) + 9 * (e >> 6)
    }

    function b(e) {
        const _ = K.exec(e);
        if (_ === null) throw new Error('Color.parse(): invalid CSS color: "'.concat(e, '"'));
        const g = _[1],
            A = _[2],
            x = _[3],
            W = _[4],
            N = _[5],
            rt = _[6];
        switch (g) {
            case "rgb":
            case "rgba":
                {
                    const X = O(A),
                        E = O(x),
                        S = O(W),
                        v = N ? R(N) : 255;
                    return (0, y.newColor)(X, E, S, v)
                }
            case "hsl":
            case "hsla":
                {
                    const X = r(A),
                        E = t(x),
                        S = t(W),
                        v = N ? R(N) : 255;
                    let m, Q, U;
                    if (E === 0) m = Q = U = Math.round(S * 255);
                    else {
                        const u = S < .5 ? S * (1 + E) : S + E - S * E,
                            n = 2 * S - u;
                        m = Math.round(l(n, u, X + 1 / 3) * 255), Q = Math.round(l(n, u, X) * 255), U = Math.round(l(n, u, X - 1 / 3) * 255)
                    }
                    return (0, y.newColor)(m, Q, U, v)
                }
            case "hwb":
                {
                    const X = r(A),
                        E = t(x),
                        S = t(W),
                        v = N ? R(N) : 255,
                        m = 1,
                        Q = .5,
                        U = Q + m - Q * m,
                        u = 2 * Q - U;
                    let n = Math.round(l(u, U, X + 1 / 3) * 255),
                        s = Math.round(l(u, U, X) * 255),
                        i = Math.round(l(u, U, X - 1 / 3) * 255);
                    return n = T(n, E, S),
                    s = T(s, E, S),
                    i = T(i, E, S),
                    (0, y.newColor)(n, s, i, v)
                }
            case "lab":
                {
                    const X = d(A, 100),
                        E = d(x, 125),
                        S = d(W, 125),
                        v = N ? R(N) : 255;
                    return $(v, c.xyzd50ToSrgb(...c.labToXyzd50(X, E, S)))
                }
            case "lch":
                {
                    const X = d(A, 100),
                        E = d(x, 150),
                        S = r(W) * 360,
                        v = N ? R(N) : 255;
                    return $(v, c.xyzd50ToSrgb(...c.labToXyzd50(...c.lchToLab(X, E, S))))
                }
            case "oklab":
                {
                    const X = d(A, 1),
                        E = d(x, .4),
                        S = d(W, .4),
                        v = N ? R(N) : 255;
                    return $(v, c.xyzd50ToSrgb(...c.xyzd65ToD50(...c.oklabToXyzd65(X, E, S))))
                }
            case "oklch":
                {
                    const X = o(A),
                        E = o(x),
                        S = o(W),
                        v = N ? R(N) : 255;
                    return $(v, c.xyzd50ToSrgb(...c.oklchToXyzd50(X, E, S)))
                }
            case "color":
                {
                    const X = A,
                        E = o(x),
                        S = o(W),
                        v = o(N),
                        m = rt ? R(rt) : 255;
                    switch (X) {
                        case "srgb":
                            return $(m, [E, S, v]);
                        case "srgb-linear":
                            return $(m, c.xyzd50ToSrgb(...c.srgbLinearToXyzd50(E, S, v)));
                        case "display-p3":
                            return $(m, c.xyzd50ToSrgb(...c.displayP3ToXyzd50(E, S, v)));
                        case "a98-rgb":
                            return $(m, c.xyzd50ToSrgb(...c.adobeRGBToXyzd50(E, S, v)));
                        case "prophoto-rgb":
                            return $(m, c.xyzd50ToSrgb(...c.proPhotoToXyzd50(E, S, v)));
                        case "rec2020":
                            return $(m, c.xyzd50ToSrgb(...c.rec2020ToXyzd50(E, S, v)));
                        case "xyz":
                        case "xyz-d65":
                            return $(m, c.xyzd50ToSrgb(...c.xyzd65ToD50(E, S, v)));
                        case "xyz-d50":
                            return $(m, c.xyzd50ToSrgb(E, S, v))
                    }
                }
        }
        throw new Error('Color.parse(): invalid CSS color: "'.concat(e, '"'))
    }

    function O(e) {
        return e.charCodeAt(e.length - 1) === p ? Math.round(parseFloat(e) / 100 * 255) : Math.round(parseFloat(e))
    }

    function R(e) {
        return Math.round(B(e) * 255)
    }

    function B(e) {
        return e.charCodeAt(0) === z ? 0 : e.charCodeAt(e.length - 1) === p ? parseFloat(e) / 100 : parseFloat(e)
    }

    function r(e) {
        let _ = 1;
        switch (e.charCodeAt(e.length - 1)) {
            case Y:
                return 0;
            case P:
                {
                    e.charCodeAt(Math.max(0, e.length - 4)) === F ? _ = 400 : _ = 2 * Math.PI;
                    break
                }
            case z:
                {
                    _ = 1;
                    break
                }
            default:
                _ = 360
        }
        return parseFloat(e) / _
    }

    function t(e) {
        return e.charCodeAt(0) === z ? 0 : parseFloat(e) / 100
    }

    function o(e) {
        return e.charCodeAt(0) === z ? 0 : e.charCodeAt(e.length - 1) === p ? parseFloat(e) / 100 : parseFloat(e)
    }

    function d(e, _) {
        return e.charCodeAt(0) === z ? 0 : e.charCodeAt(e.length - 1) === p ? parseFloat(e) / 100 * _ : parseFloat(e)
    }

    function l(e, _, g) {
        return g < 0 && (g += 1), g > 1 && (g -= 1), g < 1 / 6 ? e + (_ - e) * 6 * g : g < 1 / 2 ? _ : g < 2 / 3 ? e + (_ - e) * (2 / 3 - g) * 6 : e
    }

    function T(e, _, g) {
        let A = e / 255;
        return A *= 1 - _ - g, A += _, Math.round(A * 255)
    }

    function H(e) {
        return Math.max(0, Math.min(255, e))
    }

    function $(e, _) {
        const g = H(Math.round(_[0] * 255)),
            A = H(Math.round(_[1] * 255)),
            x = H(Math.round(_[2] * 255));
        return (0, y.newColor)(g, A, x, e)
    }
    return q
}
var L = {},
    ft;

function Tt() {
    if (ft) return L;
    ft = 1;
    var f = L && L.__createBinding || (Object.create ? (function(t, o, d, l) {
            l === void 0 && (l = d);
            var T = Object.getOwnPropertyDescriptor(o, d);
            (!T || ("get" in T ? !o.__esModule : T.writable || T.configurable)) && (T = {
                enumerable: !0,
                get: function() {
                    return o[d]
                }
            }), Object.defineProperty(t, l, T)
        }) : (function(t, o, d, l) {
            l === void 0 && (l = d), t[l] = o[d]
        })),
        G = L && L.__setModuleDefault || (Object.create ? (function(t, o) {
            Object.defineProperty(t, "default", {
                enumerable: !0,
                value: o
            })
        }) : function(t, o) {
            t.default = o
        }),
        w = L && L.__importStar || function(t) {
            if (t && t.__esModule) return t;
            var o = {};
            if (t != null)
                for (var d in t) d !== "default" && Object.prototype.hasOwnProperty.call(t, d) && f(o, t, d);
            return G(o, t), o
        };
    Object.defineProperty(L, "__esModule", {
        value: !0
    }), L.format = void 0, L.formatHEXA = Y, L.formatHEX = K, L.formatRGBA = J, L.toRGBA = Z, L.formatHSLA = M, L.toHSLA = b, L.formatHWBA = O, L.toHWBA = R;
    const y = w(ot()),
        {
            getRed: c,
            getGreen: h,
            getBlue: p,
            getAlpha: F
        } = y,
        z = [0, 0, 0],
        P = Array.from({
            length: 256
        }).map((t, o) => o.toString(16).padStart(2, "0"));
    L.format = Y;

    function Y(t) {
        return "#" + P[c(t)] + P[h(t)] + P[p(t)] + P[F(t)]
    }

    function K(t) {
        return "#" + P[c(t)] + P[h(t)] + P[p(t)]
    }

    function J(t) {
        return "rgba(".concat(c(t), " ").concat(h(t), " ").concat(p(t), " / ").concat(F(t) / 255, ")")
    }

    function Z(t) {
        return {
            r: c(t),
            g: h(t),
            b: p(t),
            a: F(t)
        }
    }

    function M(t) {
        B(c(t), h(t), p(t));
        const o = z[0],
            d = z[1],
            l = z[2],
            T = F(t) / 255;
        return "hsla(".concat(o, " ").concat(d, "% ").concat(l, "% / ").concat(T, ")")
    }

    function b(t) {
        B(c(t), h(t), p(t));
        const o = z[0],
            d = z[1],
            l = z[2],
            T = F(t) / 255;
        return {
            h: o,
            s: d,
            l,
            a: T
        }
    }

    function O(t) {
        r(c(t), h(t), p(t));
        const o = z[0],
            d = z[1],
            l = z[2],
            T = F(t) / 255;
        return "hsla(".concat(o, " ").concat(d, "% ").concat(l, "% / ").concat(T, ")")
    }

    function R(t) {
        r(c(t), h(t), p(t));
        const o = z[0],
            d = z[1],
            l = z[2],
            T = F(t) / 255;
        return {
            h: o,
            w: d,
            b: l,
            a: T
        }
    }

    function B(t, o, d) {
        t /= 255, o /= 255, d /= 255;
        const l = Math.max(t, o, d),
            T = l - Math.min(t, o, d),
            H = T ? l === t ? (o - d) / T : l === o ? 2 + (d - t) / T : 4 + (t - o) / T : 0;
        z[0] = 60 * H < 0 ? 60 * H + 360 : 60 * H, z[1] = 100 * (T ? l <= .5 ? T / (2 * l - T) : T / (2 - (2 * l - T)) : 0), z[2] = 100 * (2 * l - T) / 2
    }

    function r(t, o, d) {
        t /= 255, o /= 255, d /= 255;
        const l = Math.min(t, o, d),
            T = Math.max(t, o, d),
            H = 1 - T;
        if (T === l) {
            z[0] = 0, z[1] = l, z[2] = H;
            return
        }
        let $ = t === l ? o - d : o === l ? d - t : t - o,
            e = t === l ? 3 : o === l ? 5 : 1;
        z[0] = (e - $ / (T - l)) / 6, z[1] = l, z[2] = H
    }
    return L
}
var V = {},
    dt;

function Ot() {
    if (dt) return V;
    dt = 1;
    var f = V && V.__createBinding || (Object.create ? (function(b, O, R, B) {
            B === void 0 && (B = R);
            var r = Object.getOwnPropertyDescriptor(O, R);
            (!r || ("get" in r ? !O.__esModule : r.writable || r.configurable)) && (r = {
                enumerable: !0,
                get: function() {
                    return O[R]
                }
            }), Object.defineProperty(b, B, r)
        }) : (function(b, O, R, B) {
            B === void 0 && (B = R), b[B] = O[R]
        })),
        G = V && V.__setModuleDefault || (Object.create ? (function(b, O) {
            Object.defineProperty(b, "default", {
                enumerable: !0,
                value: O
            })
        }) : function(b, O) {
            b.default = O
        }),
        w = V && V.__importStar || function(b) {
            if (b && b.__esModule) return b;
            var O = {};
            if (b != null)
                for (var R in b) R !== "default" && Object.prototype.hasOwnProperty.call(b, R) && f(O, b, R);
            return G(O, b), O
        };
    Object.defineProperty(V, "__esModule", {
        value: !0
    }), V.alpha = Y, V.darken = K, V.lighten = J, V.blend = Z, V.getLuminance = M;
    const y = w(ot()),
        {
            getRed: c,
            getGreen: h,
            getBlue: p,
            getAlpha: F,
            setAlpha: z,
            newColor: P
        } = y;

    function Y(b, O) {
        return z(b, Math.round(O * 255))
    }

    function K(b, O) {
        const R = c(b),
            B = h(b),
            r = p(b),
            t = F(b),
            o = 1 - O;
        return P(R * o, B * o, r * o, t)
    }

    function J(b, O) {
        const R = c(b),
            B = h(b),
            r = p(b),
            t = F(b);
        return P(R + (255 - R) * O, B + (255 - B) * O, r + (255 - r) * O, t)
    }

    function Z(b, O, R, B = 1) {
        const r = (l, T) => Math.round((l ** (1 / B) * (1 - R) + T ** (1 / B) * R) ** B),
            t = r(c(b), c(O)),
            o = r(h(b), h(O)),
            d = r(p(b), p(O));
        return P(t, o, d, 255)
    }

    function M(b) {
        const O = c(b) / 255,
            R = h(b) / 255,
            B = p(b) / 255,
            r = l => l <= .03928 ? l / 12.92 : ((l + .055) / 1.055) ** 2.4,
            t = r(O),
            o = r(R),
            d = r(B);
        return Math.round((.2126 * t + .7152 * o + .0722 * d) * 1e3) / 1e3
    }
    return V
}
var lt;

function gt() {
    return lt || (lt = 1, (function(f) {
        var G = et && et.__createBinding || (Object.create ? (function(y, c, h, p) {
                p === void 0 && (p = h);
                var F = Object.getOwnPropertyDescriptor(c, h);
                (!F || ("get" in F ? !c.__esModule : F.writable || F.configurable)) && (F = {
                    enumerable: !0,
                    get: function() {
                        return c[h]
                    }
                }), Object.defineProperty(y, p, F)
            }) : (function(y, c, h, p) {
                p === void 0 && (p = h), y[p] = c[h]
            })),
            w = et && et.__exportStar || function(y, c) {
                for (var h in y) h !== "default" && !Object.prototype.hasOwnProperty.call(c, h) && G(c, y, h)
            };
        Object.defineProperty(f, "__esModule", {
            value: !0
        }), w(ot(), f), w(yt(), f), w(Tt(), f), w(Ot(), f)
    })(et)), et
}
var zt = gt();
export {
    zt as b
};
//# sourceMappingURL=mstl8wgfzorpgdoe.js.map