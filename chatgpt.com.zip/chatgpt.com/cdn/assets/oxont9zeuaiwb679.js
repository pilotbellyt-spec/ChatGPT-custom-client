const a = "TyagGW_tableContainer",
    t = "TyagGW_tableWrapper",
    e = {
        tableContainer: a,
        tableWrapper: t
    };
export {
    e as t
};
//# sourceMappingURL=oxont9zeuaiwb679.js.map