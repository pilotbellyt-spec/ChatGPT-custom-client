import {
    c as e,
    s
} from "./dykg4ktvbu3mhmdo.js";
const o = e(s, "a20836", 20, 20),
    a = e(s, "fefa27", 20, 20),
    c = e(s, "68993d", 20, 20);
export {
    a as A, o as S, c as a
};
//# sourceMappingURL=ma6fexe1cysk08ib.js.map