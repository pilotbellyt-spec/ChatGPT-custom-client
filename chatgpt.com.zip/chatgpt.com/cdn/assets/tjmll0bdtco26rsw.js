import {
    _ as u,
    j as e
} from "./fg33krlcm0qyi6yw.js";
import {
    cj as N,
    iH as C,
    er as r,
    i$ as T,
    nk as S,
    nl as v,
    nm as _,
    nn as d
} from "./k15yxxoybkkir2ou.js";
import {
    c as x
} from "./nr0ly5umft9hqfl0.js";
import {
    se as L,
    l as c,
    dm as m,
    e7 as A,
    r5 as E,
    gk as I
} from "./dykg4ktvbu3mhmdo.js";
import {
    L as y
} from "./jnh7gh80gtj0452q.js";
const l = x({
        animationLoader: () => u(() =>
            import ("./doitflbvj988jrtm.js"), []),
        StaticIcon: L
    }),
    O = x({
        animationLoader: () => u(() =>
            import ("./ecrufyyzn0h8291m.js"), []),
        StaticIcon: N
    }),
    f = x({
        animationLoader: () => u(() =>
            import ("./hvsc20zw1oied9k8.js"), []),
        StaticIcon: C
    }),
    D = ({
        chunk: a,
        size: g = "small",
        isAnimated: t = !1,
        className: n,
        isHeadline: j
    }) => {
        const s = g === "small" ? c("h-[15px] w-[15px]", n) : c("icon", n),
            p = e.jsx("div", {
                className: c("bg-token-interactive-icon-tertiary-default h-[6px] w-[6px] rounded-full", n)
            });
        if (!a) return j ? e.jsx(m, {
            className: s
        }) : null;
        switch (a.type) {
            case r.N7jupdAPI:
                return a.action === "n7jupd_as" ? e.jsx(l, {
                    matchTextColor: !0,
                    className: s
                }) : a.action === "n7jupd_ag" ? e.jsx(I, {
                    className: s
                }) : a.action === "n7jupd_cf" && a.source ? e.jsx(d, {
                    connector: a.source
                }) : a.action === "n7jupd_cs" && a.source ? e.jsx(d, {
                    connector: a.source
                }) : e.jsx(m, {
                    className: s
                });
            case r.Browsing:
                if (a.sources.length > 0) {
                    const o = a.sources.find(i => i in _);
                    if (o) {
                        const i = _[o];
                        return e.jsx(i, {
                            className: s
                        }, o)
                    }
                }
                return t ? e.jsx(l, {
                    matchTextColor: !0,
                    className: s
                }) : e.jsx(I, {
                    className: s
                });
            case r.Search:
                return t ? e.jsx(f, {
                    matchTextColor: !0,
                    className: s
                }) : e.jsx(C, {
                    className: s
                });
            case r.CodeAnalysis:
                return t ? e.jsx(l, {
                    matchTextColor: !0,
                    className: s
                }) : e.jsx(v, {
                    className: s
                });
            case r.ImageAnalysis:
                return t ? e.jsx(O, {
                    matchTextColor: !0,
                    className: s
                }) : e.jsx(N, {
                    className: s
                });
            case r.Recap:
                return a.didFailReasoning ? p : e.jsx(E, {
                    className: s
                });
            case r.Glaux:
                return e.jsx(S, {
                    className: s
                });
            case r.Strix:
                return null;
            default:
                return a.type === r.ComputerOutput ? a.messages.every(o => o.author.name === A.n7jupd_m) ? e.jsx(y, {
                    className: s
                }) : t ? e.jsx(f, {
                    matchTextColor: !0,
                    className: s
                }) : e.jsx(T, {
                    className: s
                }) : j ? e.jsx(m, {
                    className: c("-ms-[3px]", s)
                }) : p
        }
    };
export {
    D as C, l as a
};
//# sourceMappingURL=tjmll0bdtco26rsw.js.map