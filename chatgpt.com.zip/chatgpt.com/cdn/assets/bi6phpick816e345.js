var Ye = Object.defineProperty,
    Je = Object.defineProperties;
var Qe = Object.getOwnPropertyDescriptors;
var Y = Object.getOwnPropertySymbols;
var Ze = Object.prototype.hasOwnProperty,
    et = Object.prototype.propertyIsEnumerable;
var J = (e, r, n) => r in e ? Ye(e, r, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : e[r] = n,
    y = (e, r) => {
        for (var n in r || (r = {})) Ze.call(r, n) && J(e, n, r[n]);
        if (Y)
            for (var n of Y(r)) et.call(r, n) && J(e, n, r[n]);
        return e
    },
    A = (e, r) => Je(e, Qe(r));
import {
    AK as tt,
    AL as nt,
    AM as rt,
    kv as S,
    r4 as j,
    rw as it
} from "./dykg4ktvbu3mhmdo.js";
import {
    Cc as Q,
    zr as F,
    Cd as x,
    zs as st,
    Ce as O,
    c5 as N,
    Cf as I,
    Cg as we,
    gR as at,
    Ch as ot,
    Ci as ct,
    Cj as lt,
    gn as xe,
    Ck as ut,
    Cl as W,
    Cm as ft,
    eT as pt
} from "./k15yxxoybkkir2ou.js";
import {
    a as $,
    b as Ce,
    c as ke,
    r as mt,
    C as ht,
    s as _
} from "./dv2e3o9gddnli9b5.js";
import {
    r as _e,
    c as Ae
} from "./dqz86fcur874gotm.js";
import {
    f as gt,
    r as U,
    c as Z
} from "./b5s349mvbdzayaxi.js";
import {
    f as Se,
    p as ee,
    n as te,
    h as ve,
    s as q,
    d as dt,
    w as R,
    a as yt,
    r as bt
} from "./ebc4iyfg14nu1gw4.js";
import {
    k as ne
} from "./lep2wptoy14cfe2w.js";
import {
    u as v
} from "./jed1ux7qibe55pmj.js";
import {
    r as E
} from "./nfccle6oyncifphl.js";
import {
    t as re
} from "./hu1bt0oauegdhua6.js";
const ie = /[#.]/g;

function Nt(e, r) {
    const n = e || "",
        t = {};
    let i = 0,
        a, s;
    for (; i < n.length;) {
        ie.lastIndex = i;
        const o = ie.exec(n),
            l = n.slice(i, o ? o.index : n.length);
        l && (a ? a === "#" ? t.id = l : Array.isArray(t.className) ? t.className.push(l) : t.className = [l] : s = l, i += l.length), o && (a = o[0], i++)
    }
    return {
        type: "element",
        tagName: s || r || "div",
        properties: t,
        children: []
    }
}
const wt = new Set(["button", "menu", "reset", "submit"]),
    P = {}.hasOwnProperty;

function Ee(e, r, n) {
    const t = n && _t(n);

    function i(a, s, ...o) {
        let l = -1,
            c;
        if (a == null) {
            c = {
                type: "root",
                children: []
            };
            const u = s;
            o.unshift(u)
        } else if (c = Nt(a, r), c.tagName = c.tagName.toLowerCase(), t && P.call(t, c.tagName) && (c.tagName = t[c.tagName]), xt(s, c.tagName)) {
            let u;
            for (u in s) P.call(s, u) && Ct(e, c.properties, u, s[u])
        } else o.unshift(s);
        for (; ++l < o.length;) B(c.children, o[l]);
        return c.type === "element" && c.tagName === "template" && (c.content = {
            type: "root",
            children: c.children
        }, c.children = []), c
    }
    return i
}

function xt(e, r) {
    return e == null || typeof e != "object" || Array.isArray(e) ? !1 : r === "input" || !e.type || typeof e.type != "string" ? !0 : "children" in e && Array.isArray(e.children) ? !1 : r === "button" ? wt.has(e.type.toLowerCase()) : !("value" in e)
}

function Ct(e, r, n, t) {
    const i = Se(e, n);
    let a = -1,
        s;
    if (t != null) {
        if (typeof t == "number") {
            if (Number.isNaN(t)) return;
            s = t
        } else typeof t == "boolean" ? s = t : typeof t == "string" ? i.spaceSeparated ? s = Q(t) : i.commaSeparated ? s = ee(t) : i.commaOrSpaceSeparated ? s = Q(ee(t).join(" ")) : s = se(i, i.property, t) : Array.isArray(t) ? s = t.concat() : s = i.property === "style" ? kt(t) : String(t);
        if (Array.isArray(s)) {
            const o = [];
            for (; ++a < s.length;) {
                const l = se(i, i.property, s[a]);
                o[a] = l
            }
            s = o
        }
        if (i.property === "className" && Array.isArray(r.className)) {
            const o = s;
            s = r.className.concat(o)
        }
        r[i.property] = s
    }
}

function B(e, r) {
    let n = -1;
    if (r != null)
        if (typeof r == "string" || typeof r == "number") e.push({
            type: "text",
            value: String(r)
        });
        else if (Array.isArray(r))
        for (; ++n < r.length;) B(e, r[n]);
    else if (typeof r == "object" && "type" in r) r.type === "root" ? B(e, r.children) : e.push(r);
    else throw new Error("Expected node, nodes, or string, got `" + r + "`")
}

function se(e, r, n) {
    if (typeof n == "string") {
        if (e.number && n && !Number.isNaN(Number(n))) return Number(n);
        if ((e.boolean || e.overloadedBoolean) && (n === "" || te(n) === te(r))) return !0
    }
    return n
}

function kt(e) {
    const r = [];
    let n;
    for (n in e) P.call(e, n) && r.push([n, e[n]].join(": "));
    return r.join("; ")
}

function _t(e) {
    const r = {};
    let n = -1;
    for (; ++n < e.length;) r[e[n].toLowerCase()] = e[n];
    return r
}
const At = ["altGlyph", "altGlyphDef", "altGlyphItem", "animateColor", "animateMotion", "animateTransform", "clipPath", "feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence", "foreignObject", "glyphRef", "linearGradient", "radialGradient", "solidColor", "textArea", "textPath"],
    St = Ee(ve, "div"),
    vt = Ee(q, "g", At),
    D = {
        html: "http://www.w3.org/1999/xhtml",
        svg: "http://www.w3.org/2000/svg"
    };

function Et(e, r) {
    return Te(e, {}) || {
        type: "root",
        children: []
    }
}

function Te(e, r) {
    const n = Tt(e, r);
    return n && r.afterTransform && r.afterTransform(e, n), n
}

function Tt(e, r) {
    switch (e.nodeType) {
        case 1:
            return Dt(e, r);
        case 3:
            return It(e);
        case 8:
            return Rt(e);
        case 9:
            return ae(e, r);
        case 10:
            return Ot();
        case 11:
            return ae(e, r);
        default:
            return
    }
}

function ae(e, r) {
    return {
        type: "root",
        children: Oe(e, r)
    }
}

function Ot() {
    return {
        type: "doctype"
    }
}

function It(e) {
    return {
        type: "text",
        value: e.nodeValue || ""
    }
}

function Rt(e) {
    return {
        type: "comment",
        value: e.nodeValue || ""
    }
}

function Dt(e, r) {
    const n = e.namespaceURI,
        t = n === D.svg ? vt : St,
        i = n === D.html ? e.tagName.toLowerCase() : e.tagName,
        a = n === D.html && i === "template" ? e.content : e,
        s = e.getAttributeNames(),
        o = {};
    let l = -1;
    for (; ++l < s.length;) o[s[l]] = e.getAttribute(s[l]) || "";
    return t(i, o, Oe(a, r))
}

function Oe(e, r) {
    const n = e.childNodes,
        t = [];
    let i = -1;
    for (; ++i < n.length;) {
        const a = Te(n[i], r);
        a !== void 0 && t.push(a)
    }
    return t
}
new DOMParser;

function Lt(e, r) {
    const n = Pt(e);
    return Et(n)
}

function Pt(e) {
    const r = document.createElement("template");
    return r.innerHTML = e, r.content
}
const oe = (function(e, r, n) {
        const t = F(n);
        if (!e || !e.type || !e.children) throw new Error("Expected parent node");
        if (typeof r == "number") {
            if (r < 0 || r === Number.POSITIVE_INFINITY) throw new Error("Expected positive finite number as index")
        } else if (r = e.children.indexOf(r), r < 0) throw new Error("Expected child node or index");
        for (; ++r < e.children.length;)
            if (t(e.children[r], r, e)) return e.children[r]
    }),
    ce = /\n/g,
    le = /[\t ]+/g,
    M = x("br"),
    ue = x(qt),
    Bt = x("p"),
    fe = x("tr"),
    Mt = x(["datalist", "head", "noembed", "noframes", "noscript", "rp", "script", "style", "template", "title", Ut, zt]),
    Ie = x(["address", "article", "aside", "blockquote", "body", "caption", "center", "dd", "dialog", "dir", "dl", "dt", "div", "figure", "figcaption", "footer", "form,", "h1", "h2", "h3", "h4", "h5", "h6", "header", "hgroup", "hr", "html", "legend", "li", "listing", "main", "menu", "nav", "ol", "p", "plaintext", "pre", "section", "ul", "xmp"]);

function jt(e, r) {
    const n = r || {},
        t = "children" in e ? e.children : [],
        i = Ie(e),
        a = Le(e, {
            whitespace: n.whitespace || "normal"
        }),
        s = [];
    (e.type === "text" || e.type === "comment") && s.push(...De(e, {
        breakBefore: !0,
        breakAfter: !0
    }));
    let o = -1;
    for (; ++o < t.length;) s.push(...Re(t[o], e, {
        whitespace: a,
        breakBefore: o ? void 0 : i,
        breakAfter: o < t.length - 1 ? M(t[o + 1]) : i
    }));
    const l = [];
    let c;
    for (o = -1; ++o < s.length;) {
        const u = s[o];
        typeof u == "number" ? c !== void 0 && u > c && (c = u) : u && (c !== void 0 && c > -1 && l.push("\n".repeat(c) || " "), c = -1, l.push(u))
    }
    return l.join("")
}

function Re(e, r, n) {
    return e.type === "element" ? Ft(e, r, n) : e.type === "text" ? n.whitespace === "normal" ? De(e, n) : Wt(e) : []
}

function Ft(e, r, n) {
    const t = Le(e, n),
        i = e.children || [];
    let a = -1,
        s = [];
    if (Mt(e)) return s;
    let o, l;
    for (M(e) || fe(e) && oe(r, e, fe) ? l = "\n" : Bt(e) ? (o = 2, l = 2) : Ie(e) && (o = 1, l = 1); ++a < i.length;) s = s.concat(Re(i[a], e, {
        whitespace: t,
        breakBefore: a ? void 0 : o,
        breakAfter: a < i.length - 1 ? M(i[a + 1]) : l
    }));
    return ue(e) && oe(r, e, ue) && s.push("	"), o && s.unshift(o), l && s.push(l), s
}

function De(e, r) {
    const n = String(e.value),
        t = [],
        i = [];
    let a = 0;
    for (; a <= n.length;) {
        ce.lastIndex = a;
        const l = ce.exec(n),
            c = l && "index" in l ? l.index : n.length;
        t.push($t(n.slice(a, c).replace(/[\u061C\u200E\u200F\u202A-\u202E\u2066-\u2069]/g, ""), a === 0 ? r.breakBefore : !0, c === n.length ? r.breakAfter : !0)), a = c + 1
    }
    let s = -1,
        o;
    for (; ++s < t.length;) t[s].charCodeAt(t[s].length - 1) === 8203 || s < t.length - 1 && t[s + 1].charCodeAt(0) === 8203 ? (i.push(t[s]), o = void 0) : t[s] ? (typeof o == "number" && i.push(o), i.push(t[s]), o = 0) : (s === 0 || s === t.length - 1) && i.push(0);
    return i
}

function Wt(e) {
    return [String(e.value)]
}

function $t(e, r, n) {
    const t = [];
    let i = 0,
        a;
    for (; i < e.length;) {
        le.lastIndex = i;
        const s = le.exec(e);
        a = s ? s.index : e.length, !i && !a && s && !r && t.push(""), i !== a && t.push(e.slice(i, a)), i = s ? a + s[0].length : a
    }
    return i !== a && !n && t.push(""), t.join(" ")
}

function Le(e, r) {
    if (e.type === "element") {
        const n = e.properties || {};
        switch (e.tagName) {
            case "listing":
            case "plaintext":
            case "xmp":
                return "pre";
            case "nobr":
                return "nowrap";
            case "pre":
                return n.wrap ? "pre-wrap" : "pre";
            case "td":
            case "th":
                return n.noWrap ? "nowrap" : r.whitespace;
            case "textarea":
                return "pre-wrap"
        }
    }
    return r.whitespace
}

function Ut(e) {
    return !!(e.properties || {}).hidden
}

function qt(e) {
    return e.tagName === "td" || e.tagName === "th"
}

function zt(e) {
    return e.tagName === "dialog" && !(e.properties || {}).open
}
const Gt = {},
    Ht = [];

function Pe(e) {
    const r = e || Gt;
    return function(n, t) {
        st(n, "element", function(i, a) {
            const s = Array.isArray(i.properties.className) ? i.properties.className : Ht,
                o = s.includes("language-math"),
                l = s.includes("math-display"),
                c = s.includes("math-inline");
            let u = l;
            if (!o && !l && !c) return;
            let p = a[a.length - 1],
                f = i;
            if (i.tagName === "code" && o && p && p.type === "element" && p.tagName === "pre" && (f = p, p = a[a.length - 2], u = !0), !p) return;
            const g = jt(f, {
                whitespace: "pre"
            });
            let h;
            try {
                h = ne.renderToString(g, A(y({}, r), {
                    displayMode: u,
                    throwOnError: !0
                }))
            } catch (d) {
                const V = d,
                    X = V.name.toLowerCase();
                t.message("Could not render math with KaTeX", {
                    ancestors: [...a, i],
                    cause: V,
                    place: i.position,
                    ruleId: X,
                    source: "rehype-katex"
                }), X === "parseerror" ? h = ne.renderToString(g, A(y({}, r), {
                    displayMode: u,
                    strict: "ignore",
                    throwOnError: !1
                })) : h = [{
                    type: "element",
                    tagName: "span",
                    properties: {
                        className: ["katex-error"],
                        style: "color:" + (r.errorColor || "#cc0000"),
                        title: String(d)
                    },
                    children: [{
                        type: "text",
                        value: g
                    }]
                }]
            }
            typeof h == "string" && (h = Lt(h).children);
            const C = p.children.indexOf(f);
            return p.children.splice(C, 1, ...h), O
        })
    }
}

function Kt(e) {
    gt(e, [/\r?\n|\r/g, Vt])
}

function Vt() {
    return {
        type: "break"
    }
}

function Be() {
    return function(e) {
        Kt(e)
    }
}

function Xt() {
    return e => {
        N(e, {
            tagName: "table"
        }, r => {
            var i, a, s, o, l, c, u, p;
            const n = (s = (a = (i = r.children.find(f => k(f, "thead"))) == null ? void 0 : i.children.find(f => k(f, "tr"))) == null ? void 0 : a.children.filter(f => k(f, "th"))) != null ? s : [],
                t = (c = (l = (o = r.children.find(f => k(f, "tbody"))) == null ? void 0 : o.children.filter(f => k(f, "tr"))) == null ? void 0 : l.map(f => f.children.filter(g => k(g, "td")))) != null ? c : [];
            for (let f = 0; f < n.length; f++) {
                const g = n[f];
                let h = pe(g);
                for (let d = 0; d < t.length; d++) h = Math.max(h, pe((u = t[d]) == null ? void 0 : u[f]));
                const C = h > 160 ? "xl" : h > 100 ? "lg" : h > 40 ? "md" : "sm";
                g.properties["data-col-size"] = C;
                for (let d = 0; d < t.length; d++)(p = t[d]) != null && p[f] && (t[d][f].properties["data-col-size"] = C)
            }
        })
    }
}

function k(e, r) {
    return e.type === "element" && e.tagName === r
}

function pe(e) {
    let r = 0;
    return e && N(e, "text", n => {
        r += n.value.length
    }), r
}
const Yt = new Set([nt, rt]),
    Fr = e => e.startsWith(tt) || Yt.has(e) || e.startsWith("tel:") || e.startsWith("sms:") ? e : dt(e);

function Me() {
    return e => {
        N(e, "list", r => {
            for (const n of r.children) n.spread = !0
        })
    }
}
const Jt = v().use(E).freeze();

function Qt(e) {
    const r = Jt.parse(e);
    return Array.isArray(r.children) ? r.children : []
}

function je(e) {
    var t, i;
    const r = [
        [e.lang, e.meta].filter(Boolean).join(" "), (t = e.meta) != null ? t : "", (i = e.lang) != null ? i : ""
    ];
    let n = null;
    for (const a of r)
        if (a && (n = lt(a), n)) break;
    return !n && r.some(a => a.includes("{")) && (n = {}), n
}

function Zt(e, r) {
    var s, o, l, c, u;
    const n = typeof r.value == "string" ? r.value : null;
    if (!n) return re(e);
    const t = (s = e.children) != null ? s : [];
    if (!t.length) return "";
    let i = null;
    for (const p of t) {
        const f = (l = (o = p.position) == null ? void 0 : o.start) == null ? void 0 : l.offset;
        if (f != null) {
            i = f;
            break
        }
    }
    let a = null;
    for (let p = t.length - 1; p >= 0; p--) {
        const f = (u = (c = t[p].position) == null ? void 0 : c.end) == null ? void 0 : u.offset;
        if (f != null) {
            a = f;
            break
        }
    }
    return i != null && a != null && i <= a ? n.slice(i, a) : re(e)
}

function en() {
    return (e, r) => {
        let n = 0;
        const t = (i, a, s) => {
            var c;
            const o = (c = i.data) != null ? c : i.data = {};
            o.hName = S;
            const l = n++;
            o.hProperties = A(y({}, a), {
                content: s,
                index: l
            })
        };
        N(e, (i, a, s) => {
            var o, l, c, u, p;
            if (ot(i)) {
                if (i.name !== S) return;
                const f = (l = (o = i.position) == null ? void 0 : o.start) == null ? void 0 : l.offset,
                    g = (u = (c = i.position) == null ? void 0 : c.end) == null ? void 0 : u.offset;
                if (f == null || g == null) return;
                const h = Zt(i, r),
                    C = nn(i.attributes);
                t(i, C, h);
                return
            }
            if (ct(i)) {
                if (a == null || s == null) return;
                const f = je(i);
                if (!f) return;
                const g = (p = i.value) != null ? p : "",
                    h = {
                        type: "containerDirective",
                        name: S,
                        attributes: f,
                        children: [],
                        position: i.position,
                        data: i.data ? y({}, i.data) : void 0
                    };
                t(h, f, g), s.children[a] = h
            }
        })
    }
}

function tn() {
    return e => {
        N(e, "code", (r, n, t) => {
            var s;
            if (n == null || t == null || !je(r)) return;
            const a = Qt((s = r.value) != null ? s : "");
            return t.children.splice(n, 1, ...a), [O, n + a.length]
        })
    }
}

function nn(e) {
    if (!e) return {};
    const r = {};
    for (const [n, t] of Object.entries(e)) typeof t == "string" && (r[n] = t);
    return r
}

function Wr(e) {
    return r => {
        N(r, n => {
            Object.defineProperties(n, {
                markdownSource: {
                    get() {
                        try {
                            return e.slice(this.position.start.offset, this.position.end.offset)
                        } catch (t) {
                            return ""
                        }
                    }
                }
            })
        })
    }
}
const $r = [
    [U, {
        singleTilde: !1
    }], Be, Me, [mt, {
        singleDollarTextMath: !1
    }], $, en, Ce, ke, ...I ? [I] : [], _e, Fe, We
];

function Fe() {
    return e => {
        N(e, "textDirective", r => {
            r.name !== j && (r.type = "text", r.value = ":".concat(r.name))
        })
    }
}
const rn = /\u200b/g;

function We() {
    return e => {
        N(e, "text", r => {
            r.value = r.value.replace(rn, "")
        })
    }
}

function sn() {
    return e => {
        var n;
        const r = (n = e.position) == null ? void 0 : n.end.offset;
        N(e, "element", (t, i) => {
            var u;
            const {
                position: a
            } = t;
            if (!a) return;
            const {
                start: s,
                end: o
            } = a, l = s.offset, c = o.offset;
            (u = t.properties) != null || (t.properties = {}), l != null && (t.properties["data-start"] = l), c != null && (t.properties["data-end"] = c, r === c && (t.properties["data-is-last-node"] = ""), i === e.children.length - 1 && (t.properties["data-is-only-node"] = ""))
        })
    }
}
const Ur = [Pe, sn, Xt, [at, {
        target: "_new",
        rel: "noopener noreferrer"
    }], we],
    an = [
        [Pe, {
            output: "mathml"
        }], we
    ],
    z = [
        [U, {
            singleTilde: !1
        }], Be, Me, $, tn, Ce, ke, ...I ? [I] : [], _e, Fe, We
    ],
    on = {
        blockquote: w,
        break: pn,
        code: b,
        definition: b,
        delete: w,
        emphasis: w,
        footnoteReference: b,
        footnoteDefinition: b,
        heading: fn,
        html: b,
        image: he,
        imageReference: he,
        inlineCode: ge,
        list: w,
        listItem: w,
        link: w,
        linkReference: w,
        strong: w,
        table: b,
        tableCell: b,
        text: ge,
        thematicBreak: b,
        toml: b,
        yaml: b
    },
    cn = {},
    me = [];

function ln(e) {
    const r = y({}, on),
        n = e || cn,
        t = n.keep || me,
        i = n.remove || me;
    let a = -1;
    for (; ++a < i.length;) {
        const c = i[a];
        typeof c == "string" ? r[c] = b : r[c[0]] = c[1]
    }
    let s = {};
    if (t.length === 0) s = r;
    else {
        let c;
        for (c in r) t.includes(c) || (s[c] = r[c]);
        for (a = -1; ++a < t.length;)
            if (c = t[a], !Object.hasOwn(r, c)) throw new Error("Unknown node type `" + c + "` in `keep`, use a replace tuple with a handle instead: `remove: [['" + c + "', handle]]`")
    }
    return function(c) {
        return o(c)
    };

    function o(c) {
        const u = c.type;
        let p = c;
        if (Object.hasOwn(s, u)) {
            const f = s[u];
            f && (p = f(p) || void 0)
        }
        return p = Array.isArray(p) ? l(p) : p, p && "children" in p && (p.children = l(p.children)), p
    }

    function l(c) {
        let u = -1;
        const p = [];
        for (; ++u < c.length;) {
            const f = o(c[u]);
            Array.isArray(f) ? p.push(...l(f)) : f && p.push(f)
        }
        return un(p)
    }
}

function un(e) {
    let r = -1;
    const n = [];
    let t;
    for (; ++r < e.length;) {
        const i = e[r];
        t && i.type === t.type && "value" in i && "value" in t ? t.value += i.value : (n.push(i), t = i)
    }
    return n
}

function he(e) {
    const r = "title" in e ? e.title : "",
        n = e.alt || r || "";
    return n ? {
        type: "text",
        value: n
    } : void 0
}

function ge(e) {
    return {
        type: "text",
        value: e.value
    }
}

function fn(e) {
    return {
        type: "paragraph",
        children: e.children
    }
}

function w(e) {
    return e.children
}

function pn() {
    return {
        type: "text",
        value: "\n"
    }
}

function b() {}

function mn(e, r, n) {
    const t = F(r);
    let i = !0;
    r && typeof r == "object" && "cascade" in r && typeof r.cascade == "boolean" && (i = r.cascade), a(e);

    function a(s, o, l) {
        if (s !== e && t(s, o, l)) return !1;
        if ("children" in s && Array.isArray(s.children)) {
            const c = s,
                u = c.children;
            let p = -1,
                f = 0;
            if (u.length > 0) {
                for (; ++p < u.length;) a(u[p], p, c) && (u[f++] = u[p]);
                if (s !== e && i && !f) return !1;
                u.length = f
            }
        }
        return !0
    }
}
const hn = new Set([S, j, ut, ht]),
    gn = () => e => {
        mn(e, r => xe(r) && hn.has(r.name))
    },
    dn = new RegExp("[\\u200B-\\u200D\\u2060\\uFEFF\\u00A0\\u202F\\u2000-\\u200A\\u3000\\u2028\\u2029]", "gu");

function yn(e) {
    const r = v().use(E).use(U, {
        singleTilde: !1
    }).use($).use(gn).use(ln, {
        keep: ["list", "listItem"]
    }).use(Ae, {
        bullet: "-",
        handlers: {
            text: n => (n.value = n.value.replace(dn, ""), n.value)
        }
    }).processSync(e);
    return String(r).trim()
}
const bn = x(function(e) {
        return e.tagName === "audio" || e.tagName === "canvas" || e.tagName === "embed" || e.tagName === "iframe" || e.tagName === "img" || e.tagName === "math" || e.tagName === "object" || e.tagName === "picture" || e.tagName === "svg" || e.tagName === "video"
    }),
    Nn = ["address", "article", "aside", "blockquote", "body", "br", "caption", "center", "col", "colgroup", "dd", "dialog", "dir", "div", "dl", "dt", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "legend", "li", "li", "listing", "main", "menu", "nav", "ol", "optgroup", "option", "p", "plaintext", "pre", "section", "summary", "table", "tbody", "td", "td", "tfoot", "th", "th", "thead", "tr", "ul", "wbr", "xmp"],
    wn = ["button", "input", "select", "textarea"],
    xn = ["area", "base", "basefont", "dialog", "datalist", "head", "link", "meta", "noembed", "noframes", "param", "rp", "script", "source", "style", "template", "track", "title"],
    Cn = {},
    G = F(["comment", "doctype"]);

function kn(e, r) {
    $e(e, {
        collapse: On((r || Cn).newlines ? En : Tn),
        whitespace: "normal"
    })
}

function $e(e, r) {
    if ("children" in e) {
        const n = y({}, r);
        return (e.type === "root" || ze(e)) && (n.before = !0, n.after = !0), n.whitespace = In(e, r), An(e, n)
    }
    if (e.type === "text") {
        if (r.whitespace === "normal") return _n(e, r);
        r.whitespace === "nowrap" && (e.value = r.collapse(e.value))
    }
    return {
        ignore: G(e),
        stripAtStart: !1,
        remove: !1
    }
}

function _n(e, r) {
    const n = r.collapse(e.value),
        t = {
            ignore: !1,
            stripAtStart: !1,
            remove: !1
        };
    let i = 0,
        a = n.length;
    return r.before && de(n.charAt(0)) && i++, i !== a && de(n.charAt(a - 1)) && (r.after ? a-- : t.stripAtStart = !0), i === a ? t.remove = !0 : e.value = n.slice(i, a), t
}

function An(e, r) {
    let n = r.before;
    const t = r.after,
        i = e.children;
    let a = i.length,
        s = -1;
    for (; ++s < a;) {
        const o = $e(i[s], A(y({}, r), {
            after: Ue(i, s, t),
            before: n
        }));
        o.remove ? (i.splice(s, 1), s--, a--) : o.ignore || (n = o.stripAtStart), qe(i[s]) && (n = !1)
    }
    return {
        ignore: !1,
        stripAtStart: !!(n || t),
        remove: !1
    }
}

function Ue(e, r, n) {
    for (; ++r < e.length;) {
        const t = e[r];
        let i = Sn(t);
        if (i === void 0 && "children" in t && !vn(t) && (i = Ue(t.children, -1)), typeof i == "boolean") return i
    }
    return n
}

function Sn(e) {
    if (e.type === "element") {
        if (qe(e)) return !1;
        if (ze(e)) return !0
    } else if (e.type === "text") {
        if (!R(e)) return !1
    } else if (!G(e)) return !1
}

function qe(e) {
    return bn(e) || W(e, wn)
}

function ze(e) {
    return W(e, Nn)
}

function vn(e) {
    return !!(e.type === "element" && e.properties.hidden) || G(e) || W(e, xn)
}

function de(e) {
    return e === " " || e === "\n"
}

function En(e) {
    const r = /\r?\n|\r/.exec(e);
    return r ? r[0] : " "
}

function Tn() {
    return " "
}

function On(e) {
    return r;

    function r(n) {
        return String(n).replace(/[\t\n\v\f\r ]+/g, e)
    }
}

function In(e, r) {
    if ("tagName" in e && e.properties) switch (e.tagName) {
        case "listing":
        case "plaintext":
        case "script":
        case "style":
        case "xmp":
            return "pre";
        case "nobr":
            return "nowrap";
        case "pre":
            return e.properties.wrap ? "pre-wrap" : "pre";
        case "td":
        case "th":
            return e.properties.noWrap ? "nowrap" : r.whitespace;
        case "textarea":
            return "pre-wrap"
    }
    return r.whitespace
}

function Rn(e) {
    return function(r) {
        kn(r, e)
    }
}
const Dn = ["area", "base", "basefont", "bgsound", "br", "col", "command", "embed", "frame", "hr", "image", "img", "input", "keygen", "link", "meta", "param", "source", "track", "wbr"],
    ye = {}.hasOwnProperty;

function Ln(e, r) {
    const n = r || {};

    function t(i, ...a) {
        let s = t.invalid;
        const o = t.handlers;
        if (i && ye.call(i, e)) {
            const l = String(i[e]);
            s = ye.call(o, l) ? o[l] : t.unknown
        }
        if (s) return s.call(this, i, ...a)
    }
    return t.handlers = n.handlers || {}, t.invalid = n.invalid, t.unknown = n.unknown, t
}
const Pn = /^>|^->|<!--|-->|--!>|<!-$/g,
    Bn = [">"],
    Mn = ["<", ">"];

function jn(e, r, n, t) {
    return t.settings.bogusComments ? "<?" + _(e.value, Object.assign({}, t.settings.characterReferences, {
        subset: Bn
    })) + ">" : "<!--" + e.value.replace(Pn, i) + "-->";

    function i(a) {
        return _(a, Object.assign({}, t.settings.characterReferences, {
            subset: Mn
        }))
    }
}

function Fn(e, r, n, t) {
    return "<!" + (t.settings.upperDoctype ? "DOCTYPE" : "doctype") + (t.settings.tightDoctype ? "" : " ") + "html>"
}
const m = He(1),
    Ge = He(-1),
    Wn = [];

function He(e) {
    return r;

    function r(n, t, i) {
        const a = n ? n.children : Wn;
        let s = (t || 0) + e,
            o = a[s];
        if (!i)
            for (; o && R(o);) s += e, o = a[s];
        return o
    }
}
const $n = {}.hasOwnProperty;

function Ke(e) {
    return r;

    function r(n, t, i) {
        return $n.call(e, n.tagName) && e[n.tagName](n, t, i)
    }
}
const H = Ke({
    body: qn,
    caption: L,
    colgroup: L,
    dd: Kn,
    dt: Hn,
    head: L,
    html: Un,
    li: Gn,
    optgroup: Vn,
    option: Xn,
    p: zn,
    rp: be,
    rt: be,
    tbody: Jn,
    td: Ne,
    tfoot: Qn,
    th: Ne,
    thead: Yn,
    tr: Zn
});

function L(e, r, n) {
    const t = m(n, r, !0);
    return !t || t.type !== "comment" && !(t.type === "text" && R(t.value.charAt(0)))
}

function Un(e, r, n) {
    const t = m(n, r);
    return !t || t.type !== "comment"
}

function qn(e, r, n) {
    const t = m(n, r);
    return !t || t.type !== "comment"
}

function zn(e, r, n) {
    const t = m(n, r);
    return t ? t.type === "element" && (t.tagName === "address" || t.tagName === "article" || t.tagName === "aside" || t.tagName === "blockquote" || t.tagName === "details" || t.tagName === "div" || t.tagName === "dl" || t.tagName === "fieldset" || t.tagName === "figcaption" || t.tagName === "figure" || t.tagName === "footer" || t.tagName === "form" || t.tagName === "h1" || t.tagName === "h2" || t.tagName === "h3" || t.tagName === "h4" || t.tagName === "h5" || t.tagName === "h6" || t.tagName === "header" || t.tagName === "hgroup" || t.tagName === "hr" || t.tagName === "main" || t.tagName === "menu" || t.tagName === "nav" || t.tagName === "ol" || t.tagName === "p" || t.tagName === "pre" || t.tagName === "section" || t.tagName === "table" || t.tagName === "ul") : !n || !(n.type === "element" && (n.tagName === "a" || n.tagName === "audio" || n.tagName === "del" || n.tagName === "ins" || n.tagName === "map" || n.tagName === "noscript" || n.tagName === "video"))
}

function Gn(e, r, n) {
    const t = m(n, r);
    return !t || t.type === "element" && t.tagName === "li"
}

function Hn(e, r, n) {
    const t = m(n, r);
    return !!(t && t.type === "element" && (t.tagName === "dt" || t.tagName === "dd"))
}

function Kn(e, r, n) {
    const t = m(n, r);
    return !t || t.type === "element" && (t.tagName === "dt" || t.tagName === "dd")
}

function be(e, r, n) {
    const t = m(n, r);
    return !t || t.type === "element" && (t.tagName === "rp" || t.tagName === "rt")
}

function Vn(e, r, n) {
    const t = m(n, r);
    return !t || t.type === "element" && t.tagName === "optgroup"
}

function Xn(e, r, n) {
    const t = m(n, r);
    return !t || t.type === "element" && (t.tagName === "option" || t.tagName === "optgroup")
}

function Yn(e, r, n) {
    const t = m(n, r);
    return !!(t && t.type === "element" && (t.tagName === "tbody" || t.tagName === "tfoot"))
}

function Jn(e, r, n) {
    const t = m(n, r);
    return !t || t.type === "element" && (t.tagName === "tbody" || t.tagName === "tfoot")
}

function Qn(e, r, n) {
    return !m(n, r)
}

function Zn(e, r, n) {
    const t = m(n, r);
    return !t || t.type === "element" && t.tagName === "tr"
}

function Ne(e, r, n) {
    const t = m(n, r);
    return !t || t.type === "element" && (t.tagName === "td" || t.tagName === "th")
}
const er = Ke({
    body: rr,
    colgroup: ir,
    head: nr,
    html: tr,
    tbody: sr
});

function tr(e) {
    const r = m(e, -1);
    return !r || r.type !== "comment"
}

function nr(e) {
    const r = new Set;
    for (const t of e.children)
        if (t.type === "element" && (t.tagName === "base" || t.tagName === "title")) {
            if (r.has(t.tagName)) return !1;
            r.add(t.tagName)
        }
    const n = e.children[0];
    return !n || n.type === "element"
}

function rr(e) {
    const r = m(e, -1, !0);
    return !r || r.type !== "comment" && !(r.type === "text" && R(r.value.charAt(0))) && !(r.type === "element" && (r.tagName === "meta" || r.tagName === "link" || r.tagName === "script" || r.tagName === "style" || r.tagName === "template"))
}

function ir(e, r, n) {
    const t = Ge(n, r),
        i = m(e, -1, !0);
    return n && t && t.type === "element" && t.tagName === "colgroup" && H(t, n.children.indexOf(t), n) ? !1 : !!(i && i.type === "element" && i.tagName === "col")
}

function sr(e, r, n) {
    const t = Ge(n, r),
        i = m(e, -1);
    return n && t && t.type === "element" && (t.tagName === "thead" || t.tagName === "tbody") && H(t, n.children.indexOf(t), n) ? !1 : !!(i && i.type === "element" && i.tagName === "tr")
}
const T = {
    name: [
        ["	\n\f\r &/=>".split(""), "	\n\f\r \"&'/=>`".split("")],
        ["\0	\n\f\r \"&'/<=>".split(""), "\0	\n\f\r \"&'/<=>`".split("")]
    ],
    unquoted: [
        ["	\n\f\r &>".split(""), "\0	\n\f\r \"&'<=>`".split("")],
        ["\0	\n\f\r \"&'<=>`".split(""), "\0	\n\f\r \"&'<=>`".split("")]
    ],
    single: [
        ["&'".split(""), "\"&'`".split("")],
        ["\0&'".split(""), "\0\"&'`".split("")]
    ],
    double: [
        ['"&'.split(""), "\"&'`".split("")],
        ['\0"&'.split(""), "\0\"&'`".split("")]
    ]
};

function ar(e, r, n, t) {
    const i = t.schema,
        a = i.space === "svg" ? !1 : t.settings.omitOptionalTags;
    let s = i.space === "svg" ? t.settings.closeEmptyElements : t.settings.voids.includes(e.tagName.toLowerCase());
    const o = [];
    let l;
    i.space === "html" && e.tagName === "svg" && (t.schema = q);
    const c = or(t, e.properties),
        u = t.all(i.space === "html" && e.tagName === "template" ? e.content : e);
    return t.schema = i, u && (s = !1), (c || !a || !er(e, r, n)) && (o.push("<", e.tagName, c ? " " + c : ""), s && (i.space === "svg" || t.settings.closeSelfClosing) && (l = c.charAt(c.length - 1), (!t.settings.tightSelfClosing || l === "/" || l && l !== '"' && l !== "'") && o.push(" "), o.push("/")), o.push(">")), o.push(u), !s && (!a || !H(e, r, n)) && o.push("</" + e.tagName + ">"), o.join("")
}

function or(e, r) {
    const n = [];
    let t = -1,
        i;
    if (r) {
        for (i in r)
            if (r[i] !== null && r[i] !== void 0) {
                const a = cr(e, i, r[i]);
                a && n.push(a)
            }
    }
    for (; ++t < n.length;) {
        const a = e.settings.tightAttributes ? n[t].charAt(n[t].length - 1) : void 0;
        t !== n.length - 1 && a !== '"' && a !== "'" && (n[t] += " ")
    }
    return n.join("")
}

function cr(e, r, n) {
    const t = Se(e.schema, r),
        i = e.settings.allowParseErrors && e.schema.space === "html" ? 0 : 1,
        a = e.settings.allowDangerousCharacters ? 0 : 1;
    let s = e.quote,
        o;
    if (t.overloadedBoolean && (n === t.attribute || n === "") ? n = !0 : (t.boolean || t.overloadedBoolean && typeof n != "string") && (n = !!n), n == null || n === !1 || typeof n == "number" && Number.isNaN(n)) return "";
    const l = _(t.attribute, Object.assign({}, e.settings.characterReferences, {
        subset: T.name[i][a]
    }));
    return n === !0 || (n = Array.isArray(n) ? (t.commaSeparated ? yt : ft)(n, {
        padLeft: !e.settings.tightCommaSeparatedLists
    }) : String(n), e.settings.collapseEmptyAttributes && !n) ? l : (e.settings.preferUnquoted && (o = _(n, Object.assign({}, e.settings.characterReferences, {
        attribute: !0,
        subset: T.unquoted[i][a]
    }))), o !== n && (e.settings.quoteSmart && Z(n, s) > Z(n, e.alternative) && (s = e.alternative), o = s + _(n, Object.assign({}, e.settings.characterReferences, {
        subset: (s === "'" ? T.single : T.double)[i][a],
        attribute: !0
    })) + s), l + (o && "=" + o))
}
const lr = ["<", "&"];

function Ve(e, r, n, t) {
    return n && n.type === "element" && (n.tagName === "script" || n.tagName === "style") ? e.value : _(e.value, Object.assign({}, t.settings.characterReferences, {
        subset: lr
    }))
}

function ur(e, r, n, t) {
    return t.settings.allowDangerousHtml ? e.value : Ve(e, r, n, t)
}

function fr(e, r, n, t) {
    return t.all(e)
}
const pr = Ln("type", {
    invalid: mr,
    unknown: hr,
    handlers: {
        comment: jn,
        doctype: Fn,
        element: ar,
        raw: ur,
        root: fr,
        text: Ve
    }
});

function mr(e) {
    throw new Error("Expected node, not `" + e + "`")
}

function hr(e) {
    const r = e;
    throw new Error("Cannot compile unknown node `" + r.type + "`")
}
const gr = {},
    dr = {},
    yr = [];

function br(e, r) {
    const n = r || gr,
        t = n.quote || '"',
        i = t === '"' ? "'" : '"';
    if (t !== '"' && t !== "'") throw new Error("Invalid quote `" + t + "`, expected `'` or `\"`");
    return {
        one: Nr,
        all: wr,
        settings: {
            omitOptionalTags: n.omitOptionalTags || !1,
            allowParseErrors: n.allowParseErrors || !1,
            allowDangerousCharacters: n.allowDangerousCharacters || !1,
            quoteSmart: n.quoteSmart || !1,
            preferUnquoted: n.preferUnquoted || !1,
            tightAttributes: n.tightAttributes || !1,
            upperDoctype: n.upperDoctype || !1,
            tightDoctype: n.tightDoctype || !1,
            bogusComments: n.bogusComments || !1,
            tightCommaSeparatedLists: n.tightCommaSeparatedLists || !1,
            tightSelfClosing: n.tightSelfClosing || !1,
            collapseEmptyAttributes: n.collapseEmptyAttributes || !1,
            allowDangerousHtml: n.allowDangerousHtml || !1,
            voids: n.voids || Dn,
            characterReferences: n.characterReferences || dr,
            closeSelfClosing: n.closeSelfClosing || !1,
            closeEmptyElements: n.closeEmptyElements || !1
        },
        schema: n.space === "svg" ? q : ve,
        quote: t,
        alternative: i
    }.one(Array.isArray(e) ? {
        type: "root",
        children: e
    } : e, void 0, void 0)
}

function Nr(e, r, n) {
    return pr(e, r, n, this)
}

function wr(e) {
    const r = [],
        n = e && e.children || yr;
    let t = -1;
    for (; ++t < n.length;) r[t] = this.one(n[t], t, e);
    return r.join("")
}

function xr(e) {
    const r = this,
        n = y(y({}, r.data("settings")), e);
    r.compiler = t;

    function t(i) {
        return br(i, n)
    }
}

function Cr(e, r) {
    const n = it(e, r);
    return yn(Xe(n, r))
}

function Xe(e, r) {
    return v().use(E).use(z).use([
        [K, r != null ? r : []]
    ]).use(Ae, {
        rule: "-",
        tightDefinitions: !0,
        handlers: {
            text: t => (t.value = t.value.replaceAll("\\[", "["), t.value),
            break: () => "\n",
            link: _r
        }
    }).processSync(e).toString()
}

function kr(e, r) {
    return v().use(E).use(z).use([
        [K, r != null ? r : []]
    ]).use(bt).use(an).use(xr).use(Rn).processSync(e).toString()
}
const _r = (e, r, n, t) => {
    const i = n.createTracker(t),
        a = n.enter("link"),
        s = n.enter("label");
    let o = i.move("[");
    return o += i.move(n.containerPhrasing(e, y({
        before: o,
        after: "]("
    }, i.current()))), o += i.move("]("), s(), o += i.move(e.url.replace(/[\x00-\x1F\x7F-\x9F()"]/g, Ar)), e.title && (o += i.move(" " + JSON.stringify(e.title))), o += i.move(")"), a(), o
};

function Ar(e) {
    return "%" + e.charCodeAt(0).toString(16).toUpperCase().padStart(2, "0")
}
const Sr = v().use(E).use(z).freeze();

function K(e) {
    return r => {
        const n = {},
            t = (i, a) => {
                var s;
                switch (a.type) {
                    case "grouped_webpages":
                        {
                            const o = [];
                            for (const l of a.items)
                                if (l.url && l.title) {
                                    let c = n[l.url];
                                    c || (c = n[l.url] = {
                                        type: "definition",
                                        identifier: String(Object.keys(n).length + 1),
                                        url: l.url,
                                        title: l.title
                                    }), o.push({
                                        type: "linkReference",
                                        referenceType: "shortcut",
                                        identifier: c.identifier,
                                        children: [{
                                            type: "text",
                                            value: (s = l.attribution) != null ? s : pt(l.url)
                                        }]
                                    })
                                }
                            return o.length === 0 ? [] : [{
                                type: "text",
                                value: "("
                            }, ...o.flatMap((l, c, u) => c < u.length - 1 ? [l, {
                                type: "text",
                                value: ", "
                            }] : [l]), {
                                type: "text",
                                value: ")"
                            }]
                        }
                    case "title_citation":
                    case "location_search":
                    case "time":
                    case "image_v2":
                    case "nav_list":
                    case "file_navlist":
                    case "file":
                    case "grouped_webpages_model_predicted_fallback":
                    case "map":
                    case "tldr":
                    case "navigation":
                    case "stock":
                    case "calculator":
                    case "python":
                    case "container":
                    case "code_execution":
                    case "forecast":
                    case "businesses_map":
                    case "entity_metadata":
                    case "video":
                    case "entity":
                    case "sources_footnote":
                    case "sports_standings":
                    case "sports_schedule":
                    case "attribution":
                    case "webpage_extended":
                    case "checkout_confirmation":
                    case "image_inline":
                    case "image_group":
                    case "product_entity":
                    case "products":
                    case "product":
                    case "alt_text":
                    case "product_reviews":
                    case "product_rationale":
                    case "dil":
                    case "link_title":
                    case "strix":
                        if (a.alt) {
                            const o = Sr.parse(a.alt);
                            if (i.type !== "textDirective") return o.children;
                            const l = o.children[0];
                            if (l.type === "paragraph") return l.children
                        }
                        return [];
                    case "hidden":
                    case "status":
                    case "optimistic_image_citation":
                    case "webpage":
                    case "optimistic_image_inline":
                    case "invalid":
                    case "attribution_footer":
                    case "sports":
                    case "grouped_webpages_v2":
                        return []
                }
            };
        N(r, xe, (i, a, s) => {
            var c;
            if (s == null || a == null) return;
            if (i.type === "containerDirective" && i.name === S) {
                const u = Array.isArray(i.children) ? i.children : [];
                return s.children.splice(a, 1, ...u), [O, a]
            }
            const o = vr(i, e),
                l = o ? (c = t(i, o)) != null ? c : [i] : [];
            return s.children.splice(a, 1, ...l), [O, a + l.length]
        }), r.children.push(...Object.values(n))
    }
}

function vr(e, r) {
    var n;
    if (e.name === j) {
        const t = (n = e.attributes) == null ? void 0 : n.index;
        if (t) return r[parseInt(t, 10)]
    }
}
const qr = Object.freeze(Object.defineProperty({
    __proto__: null,
    markdownWithContentReferenceDirectivesToHTML: kr,
    markdownWithContentReferenceDirectivesToMarkdown: Xe,
    messageTextToPlaintext: Cr,
    replaceContentReferenceDirectivesWithMarkdown: K
}, Symbol.toStringTag, {
    value: "Module"
}));
export {
    $r as R, kr as a, Ur as b, K as c, gn as d, We as e, yn as f, Wr as g, qr as h, Xe as m, Be as r, Fr as u
};
//# sourceMappingURL=bi6phpick816e345.js.map