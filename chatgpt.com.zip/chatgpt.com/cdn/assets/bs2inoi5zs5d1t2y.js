import {
    _ as o
} from "./fg33krlcm0qyi6yw.js";
import {
    c as a
} from "./nr0ly5umft9hqfl0.js";
import {
    ea as t
} from "./k15yxxoybkkir2ou.js";
const m = a({
    animationLoader: () => o(() =>
        import ("./ercf7kls8qesuuwa.js"), []),
    StaticIcon: t
});
export {
    m as D
};
//# sourceMappingURL=bs2inoi5zs5d1t2y.js.map