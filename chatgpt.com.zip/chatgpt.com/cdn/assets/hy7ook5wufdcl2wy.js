const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/l6t2bxf0p7vp3q72.js", "assets/fg33krlcm0qyi6yw.js"]))) => i.map(i => d[i]);
import {
    c as A,
    j as t,
    r as S,
    _ as be,
    M as I,
    ao as Ie,
    e as Se,
    u as Ee
} from "./fg33krlcm0qyi6yw.js";
import {
    bg as ke,
    l as ne,
    uY as De,
    T as Re,
    dB as Le,
    b as Ce,
    d as Ne,
    gF as $e,
    uZ as Me,
    td as Ae,
    bT as Be,
    u_ as He,
    u$ as Pe,
    iK as ze,
    bX as Oe,
    pc as Je,
    v0 as We,
    bo as Ze,
    ck as ye,
    aY as Fe
} from "./dykg4ktvbu3mhmdo.js";
import {
    L as ae
} from "./bx8o5u3qhj3ykfih.js";
import {
    cw as Ue,
    eq as Ve,
    dx as Ye,
    cM as Ke,
    im as Ge,
    Z as Xe
} from "./k15yxxoybkkir2ou.js";
import {
    g as _e,
    a as qe,
    p as Qe,
    b as et,
    c as tt
} from "./gry8j32h87k624fm.js";
const st = s => {
        "use forget";
        const e = A.c(17),
            {
                onDrag: r,
                onDragEnd: m,
                onDoubleClick: n,
                onDragStart: a,
                onPointerUp: l
            } = s;
        let i, o, c, p;
        e[0] === Symbol.for("react.memo_cache_sentinel") ? (i = {
            opacity: 1
        }, o = {
            opacity: 1
        }, c = {
            type: "tween",
            duration: .1
        }, p = {
            x: 0,
            y: 0,
            transform: "translateY(0px)"
        }, e[0] = i, e[1] = o, e[2] = c, e[3] = p) : (i = e[0], o = e[1], c = e[2], p = e[3]);
        let d;
        e[4] !== a ? (d = () => {
            a == null || a()
        }, e[4] = a, e[5] = d) : d = e[5];
        let h;
        e[6] === Symbol.for("react.memo_cache_sentinel") ? (h = {
            left: 0,
            right: 0,
            top: 0,
            bottom: 0
        }, e[6] = h) : h = e[6];
        let v;
        e[7] !== r ? (v = (j, f) => {
            r == null || r(f)
        }, e[7] = r, e[8] = v) : v = e[8];
        let u;
        e[9] !== m ? (u = (j, f) => m == null ? void 0 : m(f), e[9] = m, e[10] = u) : u = e[10];
        let x;
        return e[11] !== n || e[12] !== l || e[13] !== d || e[14] !== v || e[15] !== u ? (x = t.jsx(ke.div, {
            drag: "x",
            tabIndex: -1,
            className: "bg-token-border-default pointer-events-auto absolute top-0 bottom-0 z-20 w-[2px] cursor-ew-resize rounded-full opacity-0 after:absolute after:inset-y-0 after:start-1/2 after:top-[-18px] after:h-[calc(100%+36px)] after:w-[16px] after:-translate-x-1/2 after:transform after:bg-transparent after:content-['']",
            whileHover: i,
            whileDrag: o,
            transition: c,
            style: p,
            onPointerDown: d,
            dragMomentum: !1,
            dragSnapToOrigin: !1,
            dragElastic: !1,
            dragConstraints: h,
            onDrag: v,
            onPointerUp: l,
            onDragEnd: u,
            onDoubleClick: n
        }), e[11] = n, e[12] = l, e[13] = d, e[14] = v, e[15] = u, e[16] = x) : x = e[16], x
    },
    ot = s => {
        "use forget";
        const e = A.c(6),
            {
                content: r,
                tiktokenImport: m,
                o200kBaseImport: n
            } = s,
            {
                Tiktoken: a
            } = S.use(m),
            {
                default: l
            } = S.use(n);
        let i;
        e[0] !== a || e[1] !== r || e[2] !== l ? (i = new a(l).encode(r), e[0] = a, e[1] = r, e[2] = l, e[3] = i) : i = e[3];
        const o = i.length;
        let c;
        return e[4] !== o ? (c = t.jsx("div", {
            className: "text-token-text-secondary min-w-0 truncate font-mono text-xs",
            children: t.jsx(I, {
                id: "NUKG65",
                defaultMessage: "{tokenCount} tokens",
                values: {
                    tokenCount: t.jsx(Ie, {
                        value: o
                    })
                }
            })
        }), e[4] = o, e[5] = c) : c = e[5], c
    },
    re = ({
        content: s
    }) => {
        "use no forget";
        const e = S.useMemo(() => be(() =>
                import ("./l6t2bxf0p7vp3q72.js"), __vite__mapDeps([0, 1])), []),
            r = S.useMemo(() => be(() =>
                import ("./o5eltwebd0mkim81.js"), []), []);
        return s ? t.jsx(S.Suspense, {
            name: "dev-mode-token-count",
            fallback: t.jsx("div", {
                className: "loading-results-shimmer h-5 w-10 rounded-lg"
            }),
            children: t.jsx(ot, {
                content: s,
                tiktokenImport: e,
                o200kBaseImport: r
            })
        }) : null
    },
    Te = S.createContext(null),
    we = () => {
        const s = S.useContext(Te);
        if (!s) throw new Error("Section components must be used within a Section.Root");
        return s
    },
    nt = s => {
        "use forget";
        const e = A.c(10),
            {
                children: r,
                defaultExpanded: m
            } = s,
            n = m === void 0 ? !0 : m,
            [a, l] = S.useState(n),
            i = S.useId(),
            o = S.useId();
        let c;
        e[0] === Symbol.for("react.memo_cache_sentinel") ? (c = () => l(rt), e[0] = c) : c = e[0];
        let p;
        e[1] !== o || e[2] !== i || e[3] !== a ? (p = {
            isExpanded: a,
            toggle: c,
            headerId: i,
            contentId: o
        }, e[1] = o, e[2] = i, e[3] = a, e[4] = p) : p = e[4];
        let d;
        e[5] !== r ? (d = t.jsx("div", {
            className: "relative z-0 border-b",
            children: r
        }), e[5] = r, e[6] = d) : d = e[6];
        let h;
        return e[7] !== p || e[8] !== d ? (h = t.jsx(Te.Provider, {
            value: p,
            children: d
        }), e[7] = p, e[8] = d, e[9] = h) : h = e[9], h
    },
    lt = s => {
        "use forget";
        const e = A.c(8),
            {
                children: r
            } = s,
            {
                isExpanded: m,
                contentId: n,
                headerId: a
            } = we(),
            l = !m,
            i = m && "pb-3";
        let o;
        e[0] !== i ? (o = ne("z-0 px-3", i), e[0] = i, e[1] = o) : o = e[1];
        let c;
        return e[2] !== r || e[3] !== n || e[4] !== a || e[5] !== l || e[6] !== o ? (c = t.jsx("div", {
            id: n,
            role: "region",
            "aria-labelledby": a,
            hidden: l,
            className: o,
            children: r
        }), e[2] = r, e[3] = n, e[4] = a, e[5] = l, e[6] = o, e[7] = c) : c = e[7], c
    },
    at = s => {
        "use forget";
        const e = A.c(25),
            {
                children: r,
                tooltip: m,
                accessory: n
            } = s,
            {
                isExpanded: a,
                toggle: l,
                headerId: i,
                contentId: o
            } = we(),
            [c, p] = S.useState(!1),
            d = c ? "border-token-border-default" : "border-transparent";
        let h;
        e[0] !== d ? (h = ne("bg-token-bg-elevated-secondary sticky top-0 z-20 flex w-full min-w-0 items-center border-b", d), e[0] = d, e[1] = h) : h = e[1];
        const v = !a && "-rotate-90";
        let u;
        e[2] !== v ? (u = ne("icon-sm shrink-0 transition-transform", v), e[2] = v, e[3] = u) : u = e[3];
        let x;
        e[4] !== u ? (x = t.jsx(Ue, {
            className: u
        }), e[4] = u, e[5] = x) : x = e[5];
        let j;
        e[6] !== r ? (j = t.jsx("span", {
            className: "flex min-w-0 flex-1 items-center gap-2",
            children: r
        }), e[6] = r, e[7] = j) : j = e[7];
        let f;
        e[8] !== o || e[9] !== i || e[10] !== a || e[11] !== x || e[12] !== j || e[13] !== l ? (f = t.jsxs("button", {
            type: "button",
            id: i,
            "aria-controls": o,
            "aria-expanded": a,
            onClick: l,
            className: "text-token-text-secondary focus-visible:ring-token-border-strong flex min-w-0 flex-1 items-center gap-2 rounded-sm px-3 py-3 text-start text-sm focus-visible:ring-1 focus-visible:outline-none",
            children: [x, j]
        }), e[8] = o, e[9] = i, e[10] = a, e[11] = x, e[12] = j, e[13] = l, e[14] = f) : f = e[14];
        let C;
        e[15] !== n ? (C = n && t.jsx("div", {
            className: "ms-auto py-1 ps-2 pe-3",
            children: n
        }), e[15] = n, e[16] = C) : C = e[16];
        let g;
        e[17] !== h || e[18] !== f || e[19] !== C ? (g = t.jsxs("div", {
            className: h,
            children: [f, C]
        }), e[17] = h, e[18] = f, e[19] = C, e[20] = g) : g = e[20];
        const M = g;
        let N;
        e[21] === Symbol.for("react.memo_cache_sentinel") ? (N = t.jsx("span", {
            "aria-hidden": "true",
            className: "pointer-events-none absolute block h-[1px] bg-transparent",
            ref: De({
                options: {
                    threshold: 0
                },
                onChange(_, D) {
                    p(D.intersectionRatio === 0)
                }
            })
        }), e[21] = N) : N = e[21];
        let k;
        return e[22] !== M || e[23] !== m ? (k = t.jsxs(t.Fragment, {
            children: [N, m ? t.jsx(Re, {
                side: "left",
                triggerAs: null,
                labelTextAlign: "left",
                label: t.jsx(Ve, {
                    size: "small",
                    className: "text-sm leading-5 font-normal",
                    forceDarkMode: !0,
                    children: m
                }),
                children: M
            }) : M]
        }), e[22] = M, e[23] = m, e[24] = k) : k = e[24], k
    },
    y = {
        Content: lt,
        Header: at,
        Root: nt
    };

function rt(s) {
    return !s
}

function it(s, e) {
    var l, i;
    if (e != null) return e;
    const r = (l = s.metadata) == null ? void 0 : l.jit_plugin_data,
        m = r == null ? void 0 : r.from_server,
        n = m && "body" in m ? m.body : void 0;
    if (n && typeof n == "object") {
        const o = n;
        if (o.structuredContent !== void 0) return o.structuredContent;
        if (o.structured_content !== void 0) return o.structured_content;
        if (o.result !== void 0) return o.result;
        if (o.output !== void 0) return o.output
    }
    const a = (i = s.metadata) == null ? void 0 : i.chatgpt_sdk;
    if (a && typeof a == "object") {
        const o = a;
        if (o.tool_output !== void 0) return o.tool_output;
        if (o.structuredContent !== void 0) return o.structuredContent;
        if (o.structured_content !== void 0) return o.structured_content
    }
    return e != null ? e : null
}

function ct(s) {
    var a, l, i, o, c, p, d, h, v;
    const e = [],
        r = u => {
            var x, j;
            return u.author.role === "assistant" && !!((j = (x = u.recipient) == null ? void 0 : x.startsWith) != null && j.call(x, "api_tool"))
        },
        m = u => u.author.role === "tool" && typeof u.author.name == "string",
        n = (u, x) => m(u) && typeof x.recipient == "string" && u.author.name.startsWith(x.recipient);
    for (let u = 0; u < s.length; u++) {
        const x = s[u];
        if (!r(x)) continue;
        const j = (a = Qe(x)) != null ? a : null;
        let f = null;
        for (let T = u + 1; T < s.length; T++) {
            const w = s[T];
            if (r(w)) break;
            n(w, x) && (f = w)
        }
        const C = f != null ? et(f) : null,
            g = f != null ? it(f, C) : null;
        let M = (l = j == null ? void 0 : j.args) != null ? l : null;
        if (!M && f) {
            const T = (i = f.metadata) == null ? void 0 : i.jit_plugin_data,
                w = T == null ? void 0 : T.from_server,
                $ = w && "body" in w ? w.body : void 0;
            if ($ && typeof $ == "object") {
                const E = $;
                E.params !== void 0 && (M = E.params)
            }
            if (!M && g && typeof g == "object") {
                const E = g;
                E.toolInput != null && (M = E.toolInput)
            }
        }
        const N = (o = j == null ? void 0 : j.path) != null ? o : null,
            k = N ? N.split("/").filter(Boolean) : [],
            _ = k.length >= 2 ? k[1] : null,
            D = k.length > 0 ? k[k.length - 1] : null,
            b = f != null && (c = tt(f)) != null ? c : null,
            oe = ((p = f == null ? void 0 : f.metadata) == null ? void 0 : p.chatgpt_sdk) != null ? Ge(f.metadata.chatgpt_sdk) : null,
            L = (v = (h = (d = f == null ? void 0 : f.metadata) == null ? void 0 : d.chatgpt_sdk) == null ? void 0 : h.external_call_time_ms) != null ? v : null;
        e.push({
            toolCallMessage: x,
            toolResponseMessage: f,
            path: N,
            linkId: _,
            functionName: D,
            toolInput: M,
            toolOutput: g,
            toolResponseMetadata: b,
            widgetState: oe,
            externalCallTimeMs: L
        })
    }
    return e
}
const dt = ({
        call: s,
        index: e,
        totalCount: r,
        actions: m,
        intl: n,
        logLineClassName: a,
        isDescriptionExpanded: l,
        setIsDescriptionExpanded: i,
        showHeader: o = !0
    }) => {
        "use no forget";
        var x, j, f, C, g, M, N, k, _, D;
        const c = (C = (f = (j = s.functionName) != null ? j : (x = s.toolCallMessage.recipient) == null ? void 0 : x.split(".").pop()) != null ? f : s.toolCallMessage.recipient) != null ? C : "<unknown>",
            p = s.functionName != null ? m.find(b => b.name === s.functionName) : void 0,
            d = (g = p == null ? void 0 : p.templates) == null ? void 0 : g[0],
            h = d != null || s.widgetState != null || s.toolResponseMetadata != null || s.externalCallTimeMs != null,
            v = s.toolInput != null ? JSON.stringify(s.toolInput) : "{}",
            u = s.toolOutput != null ? JSON.stringify(s.toolOutput) : "{}";
        return t.jsxs(y.Root, {
            defaultExpanded: e === r - 1,
            children: [o && t.jsx(y.Header, {
                accessory: t.jsx(re, {
                    content: u
                }),
                children: t.jsx("span", {
                    className: "truncate font-mono text-sm",
                    children: t.jsx(I, {
                        id: "LCSWJ4",
                        defaultMessage: "Tool call {index}: {functionName}",
                        values: {
                            index: e + 1,
                            functionName: c
                        }
                    })
                })
            }), t.jsxs(y.Content, {
                children: [(p == null ? void 0 : p.description) && t.jsxs(y.Root, {
                    children: [t.jsx(y.Header, {
                        accessory: t.jsx(re, {
                            content: p.description
                        }),
                        children: t.jsx("span", {
                            className: "font-mono text-sm",
                            children: t.jsx(I, {
                                id: "cBVjg7",
                                defaultMessage: "Tool description"
                            })
                        })
                    }), t.jsx(y.Content, {
                        children: t.jsxs("div", {
                            className: "ps-6",
                            children: [t.jsx("span", {
                                className: ne("text-token-text-primary block text-sm whitespace-pre-wrap", l ? "line-clamp-none" : "line-clamp-4"),
                                children: p.description
                            }), t.jsx("button", {
                                className: "text-token-text-secondary mt-1 flex justify-start text-sm hover:underline",
                                onClick: () => i(!l),
                                children: l ? t.jsx(I, {
                                    id: "Mggt6n",
                                    defaultMessage: "See less"
                                }) : t.jsx(I, {
                                    id: "yhD38v",
                                    defaultMessage: "See all"
                                })
                            })]
                        })
                    })]
                }), h && t.jsxs(y.Root, {
                    children: [t.jsx(y.Header, {
                        accessory: t.jsx(ze, {
                            href: "https://developers.openai.com/apps-sdk",
                            children: t.jsx(Oe, {
                                className: "icon-sm opacity-60"
                            })
                        }),
                        children: t.jsx("span", {
                            className: "font-mono text-sm",
                            children: t.jsx(I, {
                                id: "j5ZJHT",
                                defaultMessage: "Widget"
                            })
                        })
                    }), t.jsx(y.Content, {
                        children: t.jsx(ae, {
                            isInitialLevelExpanded: !0,
                            unwrap: !0,
                            className: a,
                            value: {
                                template: (M = d == null ? void 0 : d.meta) != null ? M : null,
                                state: (N = s.widgetState) != null ? N : null,
                                responseMetadata: (k = s.toolResponseMetadata) != null ? k : null,
                                externalCallTimeMs: (_ = s.externalCallTimeMs) != null ? _ : null
                            }
                        })
                    })]
                }), t.jsxs(y.Root, {
                    children: [t.jsx(y.Header, {
                        tooltip: n.formatMessage({
                            id: "Jf3mMy",
                            defaultMessage: "Tool input is the model-written input to the tool call."
                        }),
                        accessory: t.jsx(re, {
                            content: v
                        }),
                        children: t.jsx("span", {
                            className: "font-mono text-sm",
                            children: t.jsx(I, {
                                id: "o6IX3y",
                                defaultMessage: "Tool input"
                            })
                        })
                    }), t.jsx(y.Content, {
                        children: t.jsx(ae, {
                            className: a,
                            isInitialLevelExpanded: !0,
                            unwrap: !0,
                            value: (D = s.toolInput) != null ? D : {}
                        })
                    })]
                }), t.jsxs(y.Root, {
                    children: [t.jsx(y.Header, {
                        tooltip: n.formatMessage({
                            id: "xa77YH",
                            defaultMessage: "Tool output is the structured tool output returned by the tool."
                        }),
                        accessory: t.jsxs("div", {
                            className: "flex items-end gap-1",
                            children: [s.externalCallTimeMs != null && t.jsx("span", {
                                className: "text-token-text-secondary font-mono text-xs",
                                children: n.formatMessage({
                                    id: "D5wi0Z",
                                    defaultMessage: "Timing: {ms}ms /"
                                }, {
                                    ms: s.externalCallTimeMs
                                })
                            }), t.jsx(re, {
                                content: u
                            })]
                        }),
                        children: t.jsx("span", {
                            className: "font-mono text-sm",
                            children: t.jsx(I, {
                                id: "2IVEZx",
                                defaultMessage: "Tool output"
                            })
                        })
                    }), t.jsx(y.Content, {
                        children: s.toolOutput != null ? t.jsx(ae, {
                            className: a,
                            isInitialLevelExpanded: !0,
                            unwrap: !0,
                            value: s.toolOutput
                        }) : t.jsx("span", {
                            className: "text-token-text-secondary text-sm",
                            children: t.jsx(I, {
                                id: "lpg5UJ",
                                defaultMessage: "No tool response"
                            })
                        })
                    })]
                }), s.toolResponseMetadata != null && t.jsxs(y.Root, {
                    children: [t.jsx(y.Header, {
                        tooltip: n.formatMessage({
                            id: "MAlg9H",
                            defaultMessage: "The tool response metadata is the `_meta` field of the tool response."
                        }),
                        children: t.jsx("span", {
                            className: "font-mono text-sm",
                            children: t.jsx(I, {
                                id: "4CjZ4d",
                                defaultMessage: "Tool response metadata"
                            })
                        })
                    }), t.jsx(y.Content, {
                        children: t.jsx(ae, {
                            className: a,
                            isInitialLevelExpanded: !0,
                            unwrap: !0,
                            value: s.toolResponseMetadata
                        })
                    })]
                })]
            })]
        })
    },
    ut = s => {
        "use forget";
        var ue, fe, me, xe, pe, ge, he;
        const e = A.c(88),
            {
                focusedMessages: r,
                conversation: m
            } = s,
            n = Ce(),
            a = Se(),
            l = Me(0),
            [i, o] = S.useState(!1),
            [c, p] = S.useState(!1),
            d = Me(400);
        let h;
        e[0] !== l || e[1] !== d ? (h = [d, l], e[0] = l, e[1] = d, e[2] = h) : h = e[2];
        const v = Ae(h, ft);
        let u;
        e[3] !== n ? (u = () => Je(n), e[3] = n, e[4] = u) : u = e[4];
        const x = Ne(u),
            {
                connectorLinks: j,
                refetch: f
            } = Be();
        let C;
        e[5] !== r ? (C = ct(r), e[5] = r, e[6] = C) : C = e[6];
        const g = C,
            M = g.length === 1 ? g[0] : null;
        let N;
        e[7] !== M ? (N = M && ((xe = (me = (fe = M.functionName) != null ? fe : (ue = M.toolCallMessage.recipient) == null ? void 0 : ue.split(".").pop()) != null ? me : M.toolCallMessage.recipient) != null ? xe : "<unknown>"), e[7] = M, e[8] = N) : N = e[8];
        const k = N;
        let _, D;
        if (e[9] !== j || e[10] !== x || e[11] !== g) {
            _ = (ge = (pe = [...g].reverse().find(mt)) == null ? void 0 : pe.linkId) != null ? ge : "";
            const R = qe(j, _);
            D = R ? x == null ? void 0 : x.get(R.connector_id) : null, e[9] = j, e[10] = x, e[11] = g, e[12] = _, e[13] = D
        } else _ = e[12], D = e[13];
        const b = D,
            {
                actions: oe
            } = He(b);
        let L;
        e[14] !== n || e[15] !== f ? (L = async R => {
            await We(R), await Promise.all([f(), Ze.refetch(n, void 0, void 0)])
        }, e[14] = n, e[15] = f, e[16] = L) : L = e[16];
        let T;
        e[17] !== n ? (T = R => {
            ye(n).danger({
                defaultMessage: "Error refreshing actions.",
                description: "Error message when refreshing actions fails"
            }, {
                error: R
            })
        }, e[17] = n, e[18] = T) : T = e[18];
        let w;
        e[19] !== n || e[20] !== a ? (w = () => {
            ye(n).success(a.formatMessage({
                id: "n9Ee37",
                defaultMessage: "Tool updated"
            }))
        }, e[19] = n, e[20] = a, e[21] = w) : w = e[21];
        let $;
        e[22] !== L || e[23] !== T || e[24] !== w ? ($ = {
            mutationFn: L,
            onError: T,
            onSuccess: w
        }, e[22] = L, e[23] = T, e[24] = w, e[25] = $) : $ = e[25];
        const E = Ee($);
        let B;
        e[26] !== i ? (B = i && t.jsx("div", {
            className: "fixed inset-0 z-0 bg-transparent"
        }), e[26] = i, e[27] = B) : B = e[27];
        let H;
        e[28] !== l ? (H = () => {
            o(!0), l.set(0)
        }, e[28] = l, e[29] = H) : H = e[29];
        let P;
        e[30] !== v || e[31] !== l || e[32] !== d ? (P = () => {
            o(!1), l.set(0), d.set(v.get())
        }, e[30] = v, e[31] = l, e[32] = d, e[33] = P) : P = e[33];
        let z;
        e[34] !== l ? (z = R => l.set(l.get() + R.delta.x), e[34] = l, e[35] = z) : z = e[35];
        let O;
        e[36] !== H || e[37] !== P || e[38] !== z ? (O = t.jsx(st, {
            onDragStart: H,
            onDragEnd: P,
            onDrag: z
        }), e[36] = H, e[37] = P, e[38] = z, e[39] = O) : O = e[39];
        let J;
        e[40] !== v ? (J = {
            width: v
        }, e[40] = v, e[41] = J) : J = e[41];
        let W;
        e[42] !== b ? (W = (b == null ? void 0 : b.logo_url) && t.jsx("img", {
            className: "h-4 w-4 rounded-md",
            src: b.logo_url,
            alt: b.name
        }), e[42] = b, e[43] = W) : W = e[43];
        let Z;
        e[44] !== (b == null ? void 0 : b.name) ? (Z = (he = b == null ? void 0 : b.name) != null ? he : t.jsx(I, {
            id: "lDDPYo",
            defaultMessage: "Unknown Connector"
        }), e[44] = b == null ? void 0 : b.name, e[45] = Z) : Z = e[45];
        let F;
        e[46] !== Z ? (F = t.jsx("span", {
            className: "text-token-text-primary text-lg",
            children: Z
        }), e[46] = Z, e[47] = F) : F = e[47];
        let U;
        e[48] !== W || e[49] !== F ? (U = t.jsxs("div", {
            className: "flex items-center gap-2",
            children: [W, F]
        }), e[48] = W, e[49] = F, e[50] = U) : U = e[50];
        let V;
        e[51] !== _ || e[52] !== E ? (V = () => {
            _ && E.mutate(_)
        }, e[51] = _, e[52] = E, e[53] = V) : V = e[53];
        const ie = E.isPending || !_,
            ce = E.isPending ? Pe : Ye,
            de = E.isPending && "motion-safe:animate-spin";
        let Y;
        e[54] !== de ? (Y = ne("icon", de), e[54] = de, e[55] = Y) : Y = e[55];
        let K;
        e[56] !== V || e[57] !== ie || e[58] !== ce || e[59] !== Y ? (K = t.jsx(Xe, {
            className: "ms-auto",
            onClick: V,
            disabled: ie,
            icon: ce,
            iconClassName: Y
        }), e[56] = V, e[57] = ie, e[58] = ce, e[59] = Y, e[60] = K) : K = e[60];
        let G;
        e[61] !== m ? (G = t.jsx(Fe, {
            onClick: () => _e(m).blur()
        }), e[61] = m, e[62] = G) : G = e[62];
        let X;
        e[63] !== U || e[64] !== K || e[65] !== G ? (X = t.jsxs("div", {
            className: "flex h-(--header-height) items-center gap-1 ps-3 pe-2",
            children: [U, K, G]
        }), e[63] = U, e[64] = K, e[65] = G, e[66] = X) : X = e[66];
        let q;
        e[67] !== k || e[68] !== g.length ? (q = g.length === 0 ? null : g.length === 1 ? t.jsx("div", {
            className: "border-b px-3 py-3",
            children: t.jsx("span", {
                className: "text-token-text-secondary font-mono text-sm",
                children: k
            })
        }) : t.jsx("div", {
            className: "border-b px-3 py-3",
            children: t.jsx("span", {
                className: "text-token-text-secondary font-mono text-sm",
                children: t.jsx(I, {
                    id: "5zemKr",
                    defaultMessage: "Tool call list"
                })
            })
        }), e[67] = k, e[68] = g.length, e[69] = q) : q = e[69];
        let Q;
        e[70] !== oe || e[71] !== a || e[72] !== c || e[73] !== g ? (Q = g.length === 0 ? t.jsx("div", {
            className: "text-token-text-secondary px-3 py-3 text-sm",
            children: t.jsx(I, {
                id: "UGPm+j",
                defaultMessage: "No tool calls found."
            })
        }) : g.map((R, je) => {
            var ve;
            return t.jsx(dt, {
                call: R,
                index: je,
                totalCount: g.length,
                actions: oe,
                intl: a,
                logLineClassName: "!text-xs !leading-5",
                isDescriptionExpanded: c,
                setIsDescriptionExpanded: p,
                showHeader: g.length > 1
            }, "".concat((ve = R.toolCallMessage.id) != null ? ve : "tool", "-").concat(je))
        }), e[70] = oe, e[71] = a, e[72] = c, e[73] = g, e[74] = Q) : Q = e[74];
        let ee;
        e[75] !== q || e[76] !== Q ? (ee = t.jsxs("div", {
            className: "flex h-full flex-col overflow-x-hidden overflow-y-auto",
            children: [q, Q]
        }), e[75] = q, e[76] = Q, e[77] = ee) : ee = e[77];
        let te;
        e[78] !== J || e[79] !== X || e[80] !== ee ? (te = t.jsxs(ke.div, {
            className: "relative flex h-full flex-col",
            style: J,
            children: [X, ee]
        }), e[78] = J, e[79] = X, e[80] = ee, e[81] = te) : te = e[81];
        let se;
        e[82] !== O || e[83] !== te ? (se = t.jsxs("div", {
            className: "border-token-border-default bg-token-bg-elevated-secondary z-10 h-full border-s",
            children: [O, te]
        }), e[82] = O, e[83] = te, e[84] = se) : se = e[84];
        let le;
        return e[85] !== B || e[86] !== se ? (le = t.jsxs(t.Fragment, {
            children: [B, se]
        }), e[85] = B, e[86] = se, e[87] = le) : le = e[87], le
    },
    vt = s => {
        "use forget";
        var p, d;
        const e = A.c(10),
            {
                clientThreadId: r
            } = s,
            m = Ce();
        let n, a;
        e[0] !== r || e[1] !== m ? (n = Le(m, r), a = _e(n), e[0] = r, e[1] = m, e[2] = n, e[3] = a) : (n = e[2], a = e[3]);
        const l = a;
        let i;
        e[4] !== l ? (i = () => l.focusedMessages$(), e[4] = l, e[5] = i) : i = e[5];
        const o = Ne(i);
        let c;
        return e[6] !== n || e[7] !== l || e[8] !== o ? (c = o.length > 0 && t.jsx($e, {
            name: "DevModeSidebar",
            onError: () => l.blur(),
            children: t.jsx(ut, {
                focusedMessages: o,
                conversation: n
            }, (d = (p = o[o.length - 1]) == null ? void 0 : p.id) != null ? d : "dev-mode-sidebar")
        }), e[6] = n, e[7] = l, e[8] = o, e[9] = c) : c = e[9], c
    };

function ft(s) {
    const [e, r] = s;
    return Ke(e - r, 200, 800)
}

function mt(s) {
    return !!s.linkId
}
export {
    vt as DevModeSidebar
};
//# sourceMappingURL=hy7ook5wufdcl2wy.js.map