import {
    k2 as q,
    fh as A,
    c_ as C,
    hh as E,
    rx as F,
    _ as T,
    ry as b
} from "./dykg4ktvbu3mhmdo.js";
import {
    dn as w,
    dp as x,
    dq as P
} from "./k15yxxoybkkir2ou.js";
import {
    r as y,
    b as Q
} from "./fg33krlcm0qyi6yw.js";
const h = 300 * 1e3,
    k = 30 * 1e3;

function R(m, f, p, r, s) {
    var l;
    const o = (l = y.useContext(q)) == null ? void 0 : l.serverSharedThreadId,
        t = w(p),
        I = y.useMemo(() => ({
            asset_pointer: t,
            content_type: A.ArbitraryAssetPointer
        }), [t]),
        n = x(),
        _ = !C(),
        d = E(f),
        a = P.makeQueryOptions({
            asset: I,
            sharedThreadId: o,
            postId: n,
            gizmoId: void 0,
            isUnauthenticated: _,
            conversationId: o ? void 0 : d
        }),
        i = F(),
        g = !!(m && (d || o || n) && t && a.enabled),
        u = a.queryFn;
    if (typeof u == "symbol") throw Error("Unexpected symbol query fn...");
    return Q({
        queryKey: a.queryKey,
        queryFn: async v => {
            try {
                const e = await u(v);
                return r == null || r(e.url), {
                    status: "success",
                    download_url: e.url
                }
            } catch (e) {
                T.addError(e);
                let c = i("default_download_link_error", {
                    fileName: t
                });
                throw e instanceof b && e.code != null && (c = i(e.code)), s == null || s(c), e
            }
        },
        enabled: g,
        staleTime: h,
        gcTime: k,
        refetchInterval: h,
        refetchOnWindowFocus: !0
    })
}
export {
    R as u
};
//# sourceMappingURL=fyk9tph6baj60t7u.js.map