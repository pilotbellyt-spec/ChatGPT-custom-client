const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/lutt3ofjb1y4t7ah.js", "assets/fg33krlcm0qyi6yw.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/k15yxxoybkkir2ou.js", "assets/conversation-small-332fs9rk.css", "assets/kwnt5gec5u9yguq4.js", "assets/huyvl5jhsuxofll4.js", "assets/kuvu1ok8vnzveb23.js", "assets/cbu1fjafb968gwfi.js", "assets/oxzaatrh4u5nlvw7.js", "assets/bz18jski55ynqbl1.js", "assets/bcsv6m4oh341rml5.js", "assets/lqog7ixiwnif6sbp.js", "assets/nzl91iujqafxz8y1.js", "assets/ebc4iyfg14nu1gw4.js", "assets/gy1lpvuoewmzh42c.js", "assets/jed1ux7qibe55pmj.js", "assets/h1em0bjkpkjv8ykw.js", "assets/nfccle6oyncifphl.js", "assets/hu1bt0oauegdhua6.js", "assets/b5s349mvbdzayaxi.js", "assets/dbshkzvpochy4889.js", "assets/zdzro29lk5w2w085.js", "assets/gjyisy9q1t8rz8p4.js", "assets/djfxxaryk37v3pj1.js", "assets/dcboyjh87ll7k264.js", "assets/l09h2qppleubii6l.js", "assets/c1lw0j14sexsyj33.js", "assets/jbh6ambg0gcrgcqd.js", "assets/b31u62knn5mcc1vg.js", "assets/product-variants-pcfu1bfm.css", "assets/i7egh70diihkdvnr.js", "assets/h3mm4dcmy7evm6n4.js", "assets/ou2xm3xmri21t4zm.js", "assets/omy347b79inqzbaj.js", "assets/o67bv4dtwt5l98l7.js", "assets/fj4bpqcms0mhjoda.js", "assets/eejiqzdptzp07q5y.js", "assets/ew68kf01y1h7e4uk.js", "assets/k2oaaf8ac9lafsub.js", "assets/lans8a2ikbh9ax9r.js", "assets/jttqqjx6qab96ezg.js", "assets/e3ddui4ro6nb7fig.js", "assets/i5kvudettvxsr7pw.js", "assets/hz9475nc5ndyfqsu.js", "assets/jlu292yvnhcpthaw.js", "assets/f78b2oufkmgyeo1t.js", "assets/ib78f9d5brp6znzf.js", "assets/gb3g89r4fqk97sov.js", "assets/h21g9slzr4ujv9kj.js", "assets/u9jpwxvw30u3h6nc.js"]))) => i.map(i => d[i]);
import {
    c as f,
    _ as m,
    j as i
} from "./fg33krlcm0qyi6yw.js";
import {
    d,
    bh as u,
    e as y,
    k as S,
    p7 as b
} from "./dykg4ktvbu3mhmdo.js";
import {
    P as E
} from "./omxv5qehu9kgsx7t.js";
import {
    bN as x
} from "./k15yxxoybkkir2ou.js";
import "./iw47v9tf328v3kli.js";
import "./jttqqjx6qab96ezg.js";
import "./e3ddui4ro6nb7fig.js";
import "./eejiqzdptzp07q5y.js";
import "./ew68kf01y1h7e4uk.js";
import "./k2oaaf8ac9lafsub.js";
import "./lans8a2ikbh9ax9r.js";
import "./ib78f9d5brp6znzf.js";
import "./ou2xm3xmri21t4zm.js";
import "./hz9475nc5ndyfqsu.js";
import "./omy347b79inqzbaj.js";
import "./o67bv4dtwt5l98l7.js";
import "./fj4bpqcms0mhjoda.js";
import "./i5kvudettvxsr7pw.js";
import "./jlu292yvnhcpthaw.js";
import "./f78b2oufkmgyeo1t.js";
const P = u(() => m(() =>
        import ("./lutt3ofjb1y4t7ah.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8])).then(s => s.SearchResultsModal)),
    A = u(() => m(() =>
        import ("./cbu1fjafb968gwfi.js"), __vite__mapDeps([9, 1, 2, 3, 4, 5, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31])).then(s => s.ChatScreenProductFlyout)),
    C = u(() => m(() =>
        import ("./cbu1fjafb968gwfi.js"), __vite__mapDeps([9, 1, 2, 3, 4, 5, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31])).then(s => s.ChatScreenAgentProductFlyout)),
    v = u(() => m(() =>
        import ("./i7egh70diihkdvnr.js"), __vite__mapDeps([32, 1, 2, 3, 4, 5, 33, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51])).then(s => s.ChatScreenEntityFlyout));

function J(s) {
    "use forget";
    const t = f.c(19),
        {
            conversation: r,
            allowAnyScreenSize: p
        } = s;
    let a;
    t[0] === Symbol.for("react.memo_cache_sentinel") ? (a = y(), t[0] = a) : a = t[0];
    const _ = a;
    let n;
    t[1] === Symbol.for("react.memo_cache_sentinel") ? (n = () => S(_), t[1] = n) : n = t[1];
    const h = d(n);
    let c;
    t[2] !== p || t[3] !== r ? (c = () => {
        if (p || !b()) return x(r)
    }, t[2] = p, t[3] = r, t[4] = c) : c = t[4];
    const o = d(c);
    if (!o) return null;
    switch (o.type) {
        case "searchSources":
            {
                let e;
                return t[5] !== o || t[6] !== r ? (e = i.jsx(P, {
                    conversation: r,
                    sidebar: o
                }), t[5] = o, t[6] = r, t[7] = e) : e = t[7],
                e
            }
        case "product":
            {
                let e;
                return t[8] !== o || t[9] !== r ? (e = i.jsx(A, {
                    conversation: r,
                    sidebar: o,
                    type: "modal"
                }), t[8] = o, t[9] = r, t[10] = e) : e = t[10],
                e
            }
        case "product_agent":
            {
                let e;
                return t[11] !== o || t[12] !== r ? (e = i.jsx(C, {
                    conversation: r,
                    sidebar: o,
                    type: "modal"
                }), t[11] = o, t[12] = r, t[13] = e) : e = t[13],
                e
            }
        case "entity":
            {
                const e = h ? "fullscreen" : "modal";
                let l;
                return t[14] !== o || t[15] !== r || t[16] !== e ? (l = i.jsx(v, {
                    conversation: r,
                    sidebar: o,
                    type: e
                }), t[14] = o, t[15] = r, t[16] = e, t[17] = l) : l = t[17],
                l
            }
        case "pulse":
            {
                let e;
                return t[18] === Symbol.for("react.memo_cache_sentinel") ? (e = i.jsx(E, {
                    type: "modal"
                }), t[18] = e) : e = t[18],
                e
            }
    }
    return null
}
export {
    J as ThreadModal
};
//# sourceMappingURL=b6zf7y7f0igpluq0.js.map