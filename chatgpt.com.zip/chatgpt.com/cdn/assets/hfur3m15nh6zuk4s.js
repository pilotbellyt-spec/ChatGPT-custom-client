import {
    f as it,
    j as a,
    e as G,
    a as Kt,
    r as x,
    u as Vt,
    M as Ce,
    c as St,
    b as ps,
    i as hs
} from "./fg33krlcm0qyi6yw.js";
import {
    o as xe,
    m as $t,
    a9 as yt,
    c0 as Xt,
    aW as gs,
    T as Tt,
    c2 as bs,
    b as ye,
    me as xs,
    mI as zt,
    d as kt,
    fV as Yt,
    t9 as Jt,
    bp as Zt,
    bt as es,
    g2 as J,
    l as ot,
    i9 as Cs,
    n9 as ws,
    na as vs,
    nb as ys,
    nd as ks,
    nh as Ms,
    fX as L,
    yo as Ss,
    yp as Ts,
    wY as be,
    wX as js,
    ci as Es,
    fW as Mt,
    gH as Is,
    yr as As,
    C as Ns,
    bv as Rs,
    bJ as Fs,
    lU as Bs,
    nR as _t,
    aX as Ps,
    lg as vt,
    oj as Ls,
    lo as tt,
    lf as Os,
    lj as _s,
    fZ as Ws,
    x9 as qs,
    m2 as Wt,
    p as st,
    yR as Ds,
    m_ as Hs,
    lk as Qs
} from "./dykg4ktvbu3mhmdo.js";
import {
    yu as Gs,
    yv as Us,
    j1 as Ks,
    rE as Vs,
    uE as $s,
    yw as Xs,
    jp as zs,
    bp as Ys,
    yx as qt,
    rF as Js,
    ao as Zs,
    gX as ts,
    q3 as ea,
    yy as ta,
    wP as sa,
    cr as aa,
    x5 as na,
    cD as at,
    cE as oa,
    yz as ia,
    xl as ra,
    xm as la,
    xn as ca,
    x8 as Dt,
    x9 as ua,
    xq as da,
    xa as ma,
    xs as fa,
    xr as pa
} from "./k15yxxoybkkir2ou.js";
import {
    W as we,
    B as ha,
    c as ga,
    d as ba,
    e as xa,
    g as Ca,
    f as wa,
    i as ss,
    b as va
} from "./n3mktr5m7sakg90x.js";
import {
    W as ve,
    c as ya,
    a as Ht,
    w as Qt
} from "./mvhcdm28zmc6uy2d.js";
import {
    g as ka,
    C as Ma,
    a as Sa,
    W as Ta
} from "./lz6fx1tx77vtpv95.js";
import {
    u as ja
} from "./cei3le5szo5glbj4.js";
import {
    h as I,
    M as Ea,
    x as jt,
    q as Ia,
    n as Aa,
    o as Na
} from "./jb9b7tatrnyq635u.js";
import {
    C as Ra
} from "./hnbtdromsi7xhy2m.js";
import {
    u as Fa
} from "./elwpnpvd3n8263yf.js";
import {
    u as Ba
} from "./jdbfnvyv9bb4osfa.js";
import {
    s as Pa
} from "./g8wlcyv24gz22o70.js";

function La(t) {
    return xe(t, "3651421897")
}
const he = it({
        codeLabel: {
            id: "wham.composer.tool.codeLabel",
            defaultMessage: "Code"
        },
        codeSubmitLabel: {
            id: "wham.composer.tool.codeSubmitLabel",
            defaultMessage: "Code"
        },
        codeDescription: {
            id: "wham.composer.tool.codeDescription",
            defaultMessage: "Generate and edit code with full environment setup."
        },
        planLabel: {
            id: "wham.composer.tool.planLabel",
            defaultMessage: "Plan"
        },
        planSubmitLabel: {
            id: "wham.composer.tool.askSubmitLabel",
            defaultMessage: "Plan"
        },
        planDescription: {
            id: "wham.composer.tool.planDescription",
            defaultMessage: "Get a quick answer without modifying the repository."
        }
    }),
    Oa = [{
        key: "code",
        environmentMode: "code",
        runEnvironmentInQaMode: !1,
        slashCommand: "code",
        icon: a.jsx(Gs, {
            className: "icon",
            "aria-hidden": !0
        }),
        analyticsAction: "code",
        messages: {
            label: he.codeLabel,
            submitLabel: he.codeSubmitLabel,
            description: he.codeDescription
        }
    }, {
        key: "plan",
        environmentMode: "ask",
        runEnvironmentInQaMode: !0,
        slashCommand: "plan",
        slashAliases: ["qa", "ask"],
        icon: a.jsx(Us, {
            className: "icon",
            "aria-hidden": !0
        }),
        analyticsAction: "ask",
        messages: {
            label: he.planLabel,
            submitLabel: he.planSubmitLabel,
            description: he.planDescription
        }
    }];

function _a({
    taskId: t,
    hasMultipleInProgressOrStreamingTurns: e
}) {
    const r = G(),
        o = $t(),
        l = Kt(),
        [h, s] = x.useState(!1),
        {
            mutate: v
        } = Vt({
            mutationFn: async () => {
                s(!0), await ve.cancelTask(t)
            },
            onError: () => {
                o.danger(r.formatMessage({
                    id: "wham.whamTaskRow.failedToCancelTask",
                    defaultMessage: "Failed to cancel task"
                }))
            },
            onSuccess: () => {
                l.refetchQueries({
                    queryKey: ["wham", "task", t]
                }), l.invalidateQueries({
                    queryKey: ["wham", "tasks"]
                })
            }
        });
    return a.jsx(yt, {
        color: "primary",
        type: "button",
        size: "small",
        className: e ? void 0 : "h-9 w-9",
        icon: h ? Xt : Ks,
        onClick: () => (we.recordCancel("task-details"), v()),
        disabled: h,
        "aria-label": r.formatMessage({
            id: "wham.composer.cancelTask",
            defaultMessage: "Cancel task"
        }),
        "data-testid": "stop-button",
        children: e && a.jsx(Ce, {
            id: "wham.composer.stopButton.multipleInProgressOrStreamingTurns",
            defaultMessage: "Stop all"
        })
    })
}

function Wa(t, e) {
    return {
        label: e,
        description: "",
        share_settings: "workspace",
        machine: "wham-public/wham-universal",
        repositoryId: t,
        workspaceDirectory: "/workspace",
        agentNetworkAccess: {
            mode: "off"
        },
        setupCommands: "",
        maintenanceSetupCommands: "",
        secrets: [],
        envVars: [],
        autoSetupSettings: null,
        cacheSettings: {
            post_setup_cache_enabled: !0
        }
    }
}

function qa() {
    "use forget";
    const t = St.c(21),
        e = I(Ka),
        r = I(Ua),
        o = I(Ga),
        l = I(Qa),
        h = I(Ha),
        s = I(Da),
        v = e != null ? e : "";
    let g;
    t[0] !== v ? (g = ["wham", "repository", v], t[0] = v, t[1] = g) : g = t[1];
    const u = !!e && s;
    let c;
    t[2] !== e ? (c = () => ve.getRepository(e != null ? e : ""), t[2] = e, t[3] = c) : c = t[3];
    let C;
    t[4] !== g || t[5] !== u || t[6] !== c ? (C = {
        queryKey: g,
        enabled: u,
        queryFn: c,
        staleTime: 3e5
    }, t[4] = g, t[5] = u, t[6] = c, t[7] = C) : C = t[7];
    const {
        data: b
    } = ps(C);
    let f;
    t[8] !== l || t[9] !== o || t[10] !== r || t[11] !== h ? (f = {
        onSuccess: T => {
            if (!T) return;
            if (r(T.id), !I.getState().branch) {
                const d = ka(T);
                o(d)
            }
            l(T.id), h(!1)
        }
    }, t[8] = l, t[9] = o, t[10] = r, t[11] = h, t[12] = f) : f = t[12];
    const {
        mutateAsync: S,
        isPending: k
    } = ja(f);
    let n;
    t[13] !== S || t[14] !== b || t[15] !== e ? (n = async () => {
        const T = I.getState().environmentId;
        if (T) return T;
        if (!e) throw new Error("Repository is required to create an environment");
        if (!I.getState().useRepositoryAsEnvironment) return T;
        const i = b != null ? b : await ve.getRepository(e != null ? e : "");
        return (await S(Wa(i.id, i.name))).id
    }, t[13] = S, t[14] = b, t[15] = e, t[16] = n) : n = t[16];
    const p = n,
        N = !!e && s;
    let R;
    return t[17] !== p || t[18] !== k || t[19] !== N ? (R = {
        isCreatingEnvironment: k,
        ensureEnvironment: p,
        hasRepository: N
    }, t[17] = p, t[18] = k, t[19] = N, t[20] = R) : R = t[20], R
}

function Da(t) {
    return t.useRepositoryAsEnvironment
}

function Ha(t) {
    return t.setUseRepositoryAsEnvironment
}

function Qa(t) {
    return t.setAutoCreatedEnvironment
}

function Ga(t) {
    return t.setBranch
}

function Ua(t) {
    return t.setEnvironmentId
}

function Ka(t) {
    return t.selectedRepositoryId
}

function Va({
    isSubmitDisabled: t,
    createTask: e,
    selectedTool: r,
    disabledReason: o,
    isFollowUp: l
}) {
    const h = G(),
        s = gs(),
        [v, g] = x.useState(!1),
        u = I(n => n.environmentId),
        {
            isCreatingEnvironment: c,
            ensureEnvironment: C,
            hasRepository: b
        } = qa(),
        f = !l && !u && b,
        S = x.useCallback(n => {
            we.recordComposerAction(n ? "ask" : "code"), e({
                runEnvironmentInQaMode: n
            })
        }, [e]),
        k = x.useCallback(async n => {
            if (t) {
                g(!0);
                return
            }
            if (!c) {
                if (f) {
                    try {
                        if (!await C()) return
                    } catch (p) {
                        return
                    }
                    S(n);
                    return
                }
                S(n)
            }
        }, [t, C, c, S, f]);
    return a.jsx("div", {
        className: "flex items-center gap-2 px-2",
        onClick: n => n.stopPropagation(),
        children: a.jsx(Tt, {
            label: o,
            open: s ? v : void 0,
            onOpenChange: g,
            children: a.jsx("button", {
                "aria-label": h.formatMessage($a.submitLabel),
                color: "primary",
                type: "button",
                className: "composer-submit-btn composer-submit-button-color h-9 w-9",
                disabled: (t || c) && !s,
                onClick: t ? () => g(!0) : () => k(r.runEnvironmentInQaMode),
                children: a.jsx(Vs, {
                    className: "icon"
                })
            })
        })
    })
}
const $a = it({
        submitLabel: {
            id: "gVT0DB",
            defaultMessage: "Submit"
        }
    }),
    Xa = 4,
    za = t => {
        switch (t) {
            case 1:
                return a.jsx(xa, {
                    "aria-hidden": !0,
                    className: "icon-sm"
                });
            case 2:
                return a.jsx(ba, {
                    "aria-hidden": !0,
                    className: "icon-sm"
                });
            case 3:
                return a.jsx(ga, {
                    "aria-hidden": !0,
                    className: "icon-sm"
                });
            default:
                return a.jsx(ha, {
                    "aria-hidden": !0,
                    className: "icon-sm"
                })
        }
    };

function Ya({
    attempts: t,
    setAttempts: e
}) {
    var u;
    const r = G(),
        [o, l] = x.useState(!1),
        h = x.useRef(null),
        s = () => l(!1),
        v = ye(),
        g = (u = bs(v, "2179180337").value.max_attempts) != null ? u : Xa;
    return a.jsx(Ja, {
        children: a.jsxs($s, {
            open: o,
            onOpenChange: l,
            children: [a.jsx(Ma, {
                triggerText: r.formatMessage({
                    id: "wham.attemptsSelector.trigger",
                    defaultMessage: "{count}x"
                }, {
                    count: t
                }),
                toolTip: r.formatMessage({
                    id: "wham.attemptsSelector.tooltip",
                    defaultMessage: "Number of simultaneous versions"
                }),
                ariaLabel: r.formatMessage({
                    id: "wham.attemptsSelector.ariaLabel",
                    defaultMessage: "Open versions number selector, currently set to {count}x"
                }, {
                    count: t
                }),
                Icon: za(t),
                truncate: !1
            }), a.jsx(Ra, {
                align: "start",
                isOpen: o,
                closePopover: s,
                popoverContentRef: h,
                children: a.jsx("div", {
                    className: "flex w-50 flex-col rounded-lg p-1.5",
                    children: [...Array(g)].map((c, C) => a.jsx(Sa, {
                        className: "w-full",
                        onClick: () => {
                            e(C + 1), s()
                        },
                        isSelected: t === C + 1,
                        label: r.formatMessage({
                            id: "wham.attemptsSelector.option",
                            defaultMessage: "{count, plural, one {# version} other {# versions}}"
                        }, {
                            count: C + 1
                        })
                    }, C + 1))
                })
            })]
        })
    })
}

function Ja({
    children: t
}) {
    const e = ye(),
        r = G(),
        o = Xs(),
        l = Ea(),
        h = o && !o.isLoading && o.eligible && !l.isLoading && !!l.data;
    return a.jsx(zs, {
        side: "bottom",
        theme: "bright",
        dismissOnOutsideClick: !0,
        badge: "new",
        show: h,
        sideOffset: 0,
        className: "w-60",
        announcementKey: qt,
        title: r.formatMessage({
            id: "wham.composerBon.nuxTooltip.title",
            defaultMessage: "Best-of-N"
        }),
        description: r.formatMessage({
            id: "wham.composerBon.nuxTooltip.description",
            defaultMessage: "Generate multiple solutions so you can pick the best approach."
        }),
        onDismiss: () => Ys(e, qt),
        children: t
    })
}

function as(t) {
    const e = G(),
        {
            data: r
        } = jt(),
        o = Ca(r);
    switch (t) {
        case "enabled":
            return;
        case "rate-limit":
            return e.formatMessage({
                id: "wham.whamComposer.hitRateLimit",
                defaultMessage: "You have reached your rate limit. It will reset at {resetsAfterText}"
            }, {
                resetsAfterText: o != null ? wa(e, o) : void 0
            });
        case "no-environment":
            return e.formatMessage({
                id: "wham.whamComposer.noEnvironment",
                defaultMessage: "No environment selected"
            });
        case "no-content":
            return e.formatMessage({
                id: "wham.whamComposer.noContent",
                defaultMessage: "Enter a prompt to continue"
            });
        case "no-github-connection":
            return e.formatMessage({
                id: "wham.whamComposer.noGitHubConnection",
                defaultMessage: "No GitHub connection"
            });
        case "no-repository":
            return e.formatMessage({
                id: "wham.whamComposer.noRepository",
                defaultMessage: "No repository selected"
            });
        case "connect-github-error":
            return e.formatMessage({
                id: "wham.whamComposer.connectGitHubError",
                defaultMessage: "Failed to load environments"
            });
        default:
            xs(t)
    }
}

function ns({
    isFollowUp: t,
    hasComments: e
}) {
    const {
        data: r
    } = jt(), o = ss(r), l = I(({
        environmentId: f
    }) => f), h = I(({
        selectedRepositoryId: f
    }) => f), s = I(f => f.useRepositoryAsEnvironment), v = I(({
        branch: f
    }) => f), g = zt(), c = !kt(() => Yt(g)) || e, {
        isConnected: C,
        error: b
    } = Jt(es.GITHUB_CONNECTOR, "github", "/codex", Zt.CODEX);
    if (o) return "rate-limit";
    if (!l && !v && !t) {
        if (!s) return "no-environment";
        if (!h) return "no-repository"
    }
    return !t && !C ? "no-github-connection" : !t && b ? "connect-github-error" : c ? "enabled" : "no-content"
}

function Za(t) {
    "use forget";
    const e = St.c(46),
        {
            selectableTools: r,
            selectedTool: o,
            onSelectTool: l,
            isGitHubConnected: h,
            isImageUploadEnabled: s,
            fileInputRef: v,
            onFileChange: g
        } = t,
        u = G();
    let c;
    e[0] !== u ? (c = u.formatMessage({
        id: "wham.whamComposer.plusMenu",
        defaultMessage: "Add files and more"
    }), e[0] = u, e[1] = c) : c = e[1];
    let C;
    e[2] === Symbol.for("react.memo_cache_sentinel") ? (C = a.jsx("kbd", {
        className: "bg-token-bg-tertiary -me-1 inline-grid aspect-square w-4 items-center justify-center rounded-sm text-[11px]",
        children: a.jsx("span", {
            children: "/"
        })
    }), e[2] = C) : C = e[2];
    let b;
    e[3] !== c ? (b = a.jsxs(a.Fragment, {
        children: [c, " ", C]
    }), e[3] = c, e[4] = b) : b = e[4];
    let f;
    e[5] !== u ? (f = u.formatMessage({
        id: "wham.whamComposer.plusMenu",
        defaultMessage: "Add files and more"
    }), e[5] = u, e[6] = f) : f = e[6];
    let S;
    e[7] === Symbol.for("react.memo_cache_sentinel") ? (S = a.jsx(Zs, {
        className: "icon"
    }), e[7] = S) : S = e[7];
    let k;
    e[8] !== f ? (k = a.jsx(J.BasicTrigger, {
        asChild: !0,
        children: a.jsx("button", {
            type: "button",
            className: "composer-btn",
            "aria-label": f,
            children: S
        })
    }), e[8] = f, e[9] = k) : k = e[9];
    let n;
    e[10] !== b || e[11] !== k ? (n = a.jsx("div", {
        onPointerDown: tn,
        onClick: en,
        children: a.jsx(Tt, {
            side: "bottom",
            label: b,
            children: k
        })
    }), e[10] = b, e[11] = k, e[12] = n) : n = e[12];
    let p;
    if (e[13] !== l || e[14] !== r || e[15] !== o.key) {
        let M;
        e[17] !== l || e[18] !== o.key ? (M = E => a.jsxs(J.Item, {
            disabled: !E.available,
            className: "hover:bg-token-bg-tertiary flex items-center gap-2 rounded-lg px-3 py-2 text-start text-sm",
            onSelect: B => {
                B.preventDefault(), E.available && l(E.key)
            },
            children: [a.jsx("span", {
                className: "text-token-text-secondary",
                children: E.icon
            }), a.jsx("span", {
                className: ot("flex-1", E.key === o.key && E.available ? "text-token-text-brand font-medium" : void 0),
                children: E.label
            })]
        }, E.key), e[17] = l, e[18] = o.key, e[19] = M) : M = e[19], p = r.map(M), e[13] = l, e[14] = r, e[15] = o.key, e[16] = p
    } else p = e[16];
    let N;
    e[20] !== v || e[21] !== u || e[22] !== h || e[23] !== s || e[24] !== r.length ? (N = h && s && a.jsxs(a.Fragment, {
        children: [r.length > 0 && a.jsx(J.Separator, {
            className: "my-1"
        }), a.jsx(J.Item, {
            className: "hover:bg-token-bg-tertiary rounded-lg px-3 py-2 text-start text-sm",
            onSelect: M => {
                var E;
                M.preventDefault(), (E = v.current) == null || E.click()
            },
            children: u.formatMessage({
                id: "wham.whamComposer.attachImage",
                defaultMessage: "Upload attachment"
            })
        })]
    }), e[20] = v, e[21] = u, e[22] = h, e[23] = s, e[24] = r.length, e[25] = N) : N = e[25];
    let R;
    e[26] !== p || e[27] !== N ? (R = a.jsx(J.Portal, {
        children: a.jsxs(J.Content, {
            align: "start",
            sideOffset: 8,
            className: "min-w-[16rem] p-1",
            children: [p, N]
        })
    }), e[26] = p, e[27] = N, e[28] = R) : R = e[28];
    let T;
    e[29] !== R || e[30] !== n ? (T = a.jsxs(J.Root, {
        modal: !1,
        children: [n, R]
    }), e[29] = R, e[30] = n, e[31] = T) : T = e[31];
    let i;
    e[32] !== l || e[33] !== o.icon || e[34] !== o.key || e[35] !== o.label ? (i = o.key !== "code" && a.jsx(Js, {
        icon: o.icon,
        label: o.label,
        content: o.label,
        removable: !0,
        onRemove: () => l("code")
    }), e[32] = l, e[33] = o.icon, e[34] = o.key, e[35] = o.label, e[36] = i) : i = e[36];
    let d;
    e[37] !== v || e[38] !== h || e[39] !== s || e[40] !== g ? (d = h && s && a.jsx("input", {
        ref: v,
        type: "file",
        accept: "image/*",
        multiple: !0,
        hidden: !0,
        onChange: g
    }), e[37] = v, e[38] = h, e[39] = s, e[40] = g, e[41] = d) : d = e[41];
    let j;
    return e[42] !== T || e[43] !== i || e[44] !== d ? (j = a.jsxs("div", {
        className: "flex items-center",
        children: [T, i, d]
    }), e[42] = T, e[43] = i, e[44] = d, e[45] = j) : j = e[45], j
}

function en(t) {
    return t.stopPropagation()
}

function tn(t) {
    return t.stopPropagation()
}

function sn({
    comments: t,
    onClearComments: e
}) {
    const r = G();
    return t.length === 0 ? null : a.jsxs("div", {
        className: "bg bg-token-bg-secondary mx-1 mt-1 flex items-center gap-2 rounded-t-3xl rounded-b-lg py-0.5 ps-3 pe-0.5 font-semibold text-blue-400",
        children: [a.jsx(ts, {
            className: "icon"
        }), a.jsx("div", {
            className: "flex-1 text-sm",
            children: a.jsx(Ce, {
                id: "wham.composer.commentCount",
                defaultMessage: "{count, plural, one {One code comment} other {# code comments}}",
                values: {
                    count: t.length
                }
            })
        }), a.jsx("button", {
            className: "text-token-text-secondary flex h-9 w-9 shrink-0 items-center justify-center",
            onClick: o => {
                o.preventDefault(), o.stopPropagation(), e()
            },
            "aria-label": r.formatMessage({
                id: "wham.composer.clearComments",
                defaultMessage: "Clear comments"
            }),
            children: a.jsx(Cs, {
                className: "icon"
            })
        })]
    })
}

function an({
    composerController: t,
    layoutMode: e,
    slashCommands: r
}) {
    const o = G(),
        {
            refs: l,
            floatingStyles: h
        } = ws({
            placement: "bottom-start",
            middleware: [vs({
                mainAxis: 10,
                alignmentAxis: -18
            }), ys({
                padding: 6
            }), ks({
                apply: ({
                    elements: i,
                    availableWidth: d,
                    availableHeight: j
                }) => {
                    i.floating.style.setProperty("--radix-popper-available-width", "".concat(d, "px")), i.floating.style.setProperty("--radix-popper-available-height", "".concat(j, "px"))
                }
            })],
            whileElementsMounted: Ms
        }),
        [s, v] = x.useState(void 0);
    x.useEffect(() => {
        const i = L(t);
        i.dispatch(Ss(i.state.tr, {
            setReferencePosition: l.setReference,
            onHintMatch(d) {
                v(j => Is(j, d) ? j : d)
            }
        }))
    }, [t, l.setReference]);
    const g = x.useMemo(() => !s || s.triggerSymbol !== "/" ? [] : r.length ? s.text ? [ea(r, s.text, i => ta(i), {
            locale: o.locale
        })] : [r.filter(i => !i.noMatchEmpty)] : [], [s, o.locale, r]),
        u = x.useMemo(() => e !== "bottom" ? g : g.slice().reverse().map(i => [...i].reverse()), [g, e]),
        c = x.useMemo(() => u.flat(), [u]),
        [C, b] = x.useState(e === "bottom" ? -1 : 0),
        f = C == null ? null : (C + c.length) % c.length,
        S = x.useCallback(i => {
            b(d => {
                if (d == null) return null;
                const j = c.length;
                for (let M = 0; M < j; M++) {
                    const E = (d + j + (M + 1) * i) % j;
                    if (!c[E].disabled) return E
                }
                return null
            })
        }, [c]),
        k = x.useRef(S);
    k.current = S;
    const n = c.length === 0;
    x.useEffect(() => {
        if (n) {
            b(null);
            return
        }
        e === "bottom" ? (b(0), k.current(-1)) : (b(-1), k.current(1))
    }, [e, n]);
    const p = f == null ? null : c[f],
        N = x.useCallback(() => {
            if (s != null && s.range) {
                const i = L(t);
                Ts(i, s.range.from, s.range.to)
            }
        }, [t, s]),
        R = x.useCallback(({
            commandToSave: i = p,
            expectPerfectMatch: d
        }) => {
            var B;
            if (!s || !i || i.disabled) return !1;
            const j = s.text.toLocaleLowerCase(),
                M = [i.command, ...(B = i.aliases) != null ? B : []].some(rt => rt.toLocaleLowerCase() === j);
            if (d && !M) return !1;
            N();
            const E = L(t);
            return be(E), i.onSelect(), !0
        }, [N, t, s, p]),
        T = x.useRef(R);
    return T.current = R, x.useEffect(() => {
        if (n) {
            const d = L(t);
            be(d);
            return
        }
        const i = L(t);
        return js(i, d => {
            if (d === "up") k.current(-1);
            else if (d === "down") k.current(1);
            else if (d === "cancel") be(i), As(i);
            else {
                if (d === "submit") return be(i), T.current({
                    expectPerfectMatch: !1
                });
                if (d === "checkMatch") return T.current({
                    expectPerfectMatch: !0
                })
            }
        }), () => be(i)
    }, [t, n]), n ? null : a.jsx(Es, {
        ref: l.setFloating,
        style: h,
        className: ot("max-w-[min(var(--radix-popper-available-width,100vw),--spacing(100))] overflow-y-auto [scrollbar-width:none]", c.length > 6 ? "max-h-[min(var(--radix-popper-available-height,50svh),--spacing(1.5)+5*var(--menu-item-height))]" : "max-h-[var(--radix-popper-available-height,50svh)]"),
        onPointerDown: i => {
            i.preventDefault()
        },
        children: u.map((i, d) => {
            let j = 0;
            for (let M = 0; M < d; M++) j += u[M].length;
            return a.jsx(J.Group, {
                children: i.map((M, E) => {
                    const B = j + E;
                    return a.jsx(sa, {
                        command: M,
                        isHighlighted: B === f,
                        onHighlight: () => b(B),
                        onClick: () => {
                            R({
                                commandToSave: M,
                                expectPerfectMatch: !1
                            }), Mt(L(t))
                        }
                    }, M.command)
                })
            }, d)
        })
    })
}

function nn() {
    const t = G(),
        e = hs(),
        {
            setupMfa: r
        } = Fa({
            redirectUrl: "/codex"
        });
    return a.jsx(Ns, {
        isOpen: !0,
        onClose: () => {},
        type: "warning",
        title: t.formatMessage({
            id: "wham.mfaRequiredModal.title",
            defaultMessage: "Enable multi-factor authentication to access Codex"
        }),
        description: t.formatMessage({
            id: "wham.mfaRequiredModal.description",
            defaultMessage: "To continue using Codex, please turn on multi-factor authentication for your account."
        }),
        testId: "modal-mfa-required",
        children: a.jsxs("div", {
            className: "flex w-full justify-end gap-2",
            children: [a.jsx(yt, {
                color: "secondary",
                onClick: () => {
                    e("/")
                },
                children: a.jsx(Ce, {
                    id: "wham.mfaRequiredModal.backToChatGPT",
                    defaultMessage: "Back to ChatGPT"
                })
            }), a.jsx(yt, {
                color: "primary",
                onClick: () => {
                    r()
                },
                children: a.jsx(Ce, {
                    id: "wham.mfaRequiredModal.enableMFA",
                    defaultMessage: "Enable MFA"
                })
            })]
        })
    })
}

function on({
    taskId: t,
    turnId: e,
    isComposerExpanded: r,
    followUpSuggestions: o,
    hasComments: l,
    isSubmitting: h,
    onSuggestionClick: s,
    children: v
}) {
    const g = ye(),
        u = ln(g, r),
        c = G(),
        [C, b] = x.useState(null),
        f = ns({
            isFollowUp: !0,
            hasComments: l
        });
    let S = as(f);
    f === "no-content" && (S = void 0);
    const k = !(u === "hidden" || !o.length) && t && e;
    return x.useEffect(() => {
        k && we.recordFollowUpsSeen(t, e, o.length)
    }, [k, t, e, o.length]), k ? a.jsxs("div", {
        className: "bg-token-bg-tertiary flex flex-col gap-1.5 rounded-2xl p-2",
        children: [a.jsx(Rs, {
            initial: !1,
            children: u === "visible" && a.jsx("div", {
                className: "flex flex-col",
                inert: h,
                children: o.map((n, p) => a.jsx(rn, {
                    index: p,
                    taskId: t,
                    turnId: e,
                    suggestion: n.suggestion,
                    disabledReason: S,
                    loading: C === p && h,
                    onClick: () => {
                        h || (b(p), s(n.suggestion))
                    }
                }, p))
            })
        }), u === "collapsed" && a.jsxs("button", {
            type: "button",
            className: "text-token-text-tertiary enabled:hover:text-token-text-secondary focus:bg-token-bg-secondary flex items-center gap-2 rounded-lg p-2 text-xs font-semibold focus:outline-none",
            "aria-label": c.formatMessage({
                id: "wham.followUpContainer.showSuggestions",
                defaultMessage: "Show follow up suggestions"
            }),
            onClick: () => {
                we.recordFollowUpsExpanded(t, e)
            },
            children: [a.jsx(aa, {
                className: "icon-sm"
            }), a.jsx(Ce, {
                id: "wham.composer.followup.show",
                defaultMessage: "Suggestions"
            }, "text")]
        }, "collapsed"), v({
            isWrappedByContainer: !0
        })]
    }) : v({
        isWrappedByContainer: !1
    })
}

function rn({
    taskId: t,
    turnId: e,
    index: r,
    suggestion: o,
    disabledReason: l,
    loading: h,
    onClick: s
}) {
    return a.jsx(Tt, {
        side: "right",
        sideOffset: 10,
        label: l,
        children: a.jsxs("button", {
            type: "button",
            disabled: !!l || h,
            className: "group hover:bg-token-bg-secondary focus:bg-token-bg-secondary -disabled:cursor-pointer flex w-full items-start gap-1.5 rounded-lg px-2 py-1 focus:outline-none disabled:cursor-not-allowed disabled:opacity-50",
            onClick: () => {
                s(), we.recordFollowUpsClicked(t, e, r, o.severity)
            },
            children: [a.jsx("span", {
                className: "pt-[0.125rem]",
                children: h ? a.jsx(Xt, {
                    className: "text-token-text-tertiary icon-sm"
                }) : a.jsx(ts, {
                    className: "text-token-text-tertiary icon-sm"
                })
            }), a.jsx("span", {
                className: "text-token-text-primary line-clamp-2 text-start text-sm leading-snug break-words",
                children: o.title
            })]
        })
    })
}

function ln(t, e) {
    return xe(t, "3485296344") || void 0 ? e ? "collapsed" : "visible" : "hidden"
}

function cn() {
    const t = ye(),
        e = I(o => o.bestOfN);
    return e != null ? e : Fs(t, "2398649844").get("default_attempts", 1)
}
const nt = it({
        describeTask: {
            id: "wham.whamComposer.describeACodingTask",
            defaultMessage: "Describe a task"
        },
        describeAnotherTask: {
            id: "wham.whamComposer.describeAnotherCodingTask",
            defaultMessage: "Describe another task"
        },
        askQuestionWithPlan: {
            id: "wham.whamComposer.askAQuestionWithPlan",
            defaultMessage: "Ask a question with /plan"
        },
        askQuestionWithPlanAnother: {
            id: "wham.whamComposer.askAQuestionWithPlanAnother",
            defaultMessage: "Ask a question with /plan"
        }
    }),
    Gt = [{
        firstTaskMessage: nt.describeTask,
        subsequentTaskMessage: nt.describeAnotherTask
    }, {
        firstTaskMessage: nt.askQuestionWithPlan,
        subsequentTaskMessage: nt.askQuestionWithPlanAnother
    }];

function An(t) {
    "use forget";
    var Nt, Rt, Ft, Bt, Pt, Lt;
    const e = St.c(143),
        {
            disableAutoFocus: r,
            isBigBoxMode: o,
            disableDuringSubmit: l,
            expanded: h,
            followUp: s,
            onClearComments: v,
            onSubmit: g,
            onSuccess: u,
            onCreateEnvironment: c,
            attemptIndex: C,
            ariaLabel: b
        } = t,
        f = r === void 0 ? !1 : r,
        S = o === void 0 ? !1 : o,
        k = l === void 0 ? !1 : l,
        n = G(),
        p = $t(),
        N = Kt(),
        [R, T] = x.useState("code"),
        {
            refetch: i
        } = Ia(),
        {
            refetch: d
        } = Aa(s == null ? void 0 : s.taskId),
        {
            refetch: j
        } = Na(s == null ? void 0 : s.taskId),
        M = I(bn),
        E = I(gn),
        [B, rt] = x.useState(!0),
        [$, Et] = x.useState(!1),
        W = Bs(),
        ke = _t(hn),
        os = _t(vt.hasUploadInProgress),
        is = cn(),
        rs = I(pn),
        [ls, cs] = x.useState(1),
        Z = s ? ls : is,
        lt = s ? cs : rs,
        q = ye();
    let Me;
    e[0] !== q ? (Me = xe(q, "3492040717"), e[0] = q, e[1] = Me) : Me = e[1];
    const ee = Me;
    let Se;
    e[2] !== q ? (Se = xe(q, "879591222") || void 0, e[2] = q, e[3] = Se) : Se = e[3];
    const us = Se;
    let Te;
    e[4] !== q ? (Te = xe(q, "3536244140"), e[4] = q, e[5] = Te) : Te = e[5];
    const je = Te;
    let Ee;
    e[6] !== q ? (Ee = La(q), e[6] = q, e[7] = Ee) : Ee = e[7];
    const H = Ee,
        [ct, It] = x.useState(!1),
        m = zt();
    let Ie;
    e[8] !== m ? (Ie = na(m), e[8] = m, e[9] = Ie) : Ie = e[9];
    const ne = kt(Ie.isWhisperActive$),
        ds = x.useRef(null),
        At = x.useRef(Gt[Math.floor(Math.random() * Gt.length)]),
        {
            data: ut
        } = jt();
    let Ae;
    e[10] !== ut ? (Ae = ss(ut), e[10] = ut, e[11] = Ae) : Ae = e[11];
    const Ne = Ae,
        oe = Ne && !!s,
        ge = oe ? !1 : ne ? !0 : h;
    let Re;
    e[12] !== m || e[13] !== ge ? (Re = () => ge != null ? ge : !Yt(m) || Ls(m), e[12] = m, e[13] = ge, e[14] = Re) : Re = e[14];
    const X = kt(Re),
        dt = k && $ || oe,
        D = !!s && ((Nt = s.comments.length) != null ? Nt : 0) > 0;
    let Fe;
    e[15] !== W || e[16] !== n || e[17] !== p ? (Fe = w => {
        for (const A of w) tt.uploadFile(W, Os(A), A, _s.Codex, [], n, p)
    }, e[15] = W, e[16] = n, e[17] = p, e[18] = Fe) : Fe = e[18];
    const te = Fe;
    let Be;
    e[19] !== te ? (Be = function(A) {
        const F = A.target.files;
        F && (te(F), A.target.value = "")
    }, e[19] = te, e[20] = Be) : Be = e[20];
    const mt = Be;
    let Pe, Le;
    e[21] !== m || e[22] !== H || e[23] !== te ? (Pe = () => {
        if (!H) return;
        const w = A => {
            var V;
            const F = (V = A.clipboardData) == null ? void 0 : V.items;
            if (!F) return;
            const P = [];
            for (const y of F)
                if (y.kind === "file") {
                    const z = y.getAsFile();
                    z && z.type.startsWith("image/") && P.push(z)
                }
            P.length > 0 && (A.preventDefault(), te(P))
        };
        return Ws(L(m).dom, {
            paste: w
        })
    }, Le = [m, H, te], e[21] = m, e[22] = H, e[23] = te, e[24] = Pe, e[25] = Le) : (Pe = e[24], Le = e[25]), x.useEffect(Pe, Le);
    let Oe;
    e[26] !== W ? (Oe = function() {
        return vt.getReadyFiles(W.getState()).flatMap(fn)
    }, e[26] = W, e[27] = Oe) : Oe = e[27];
    const ft = Oe;
    let ie;
    e[28] !== m ? (ie = () => Mt(L(m)), e[28] = m, e[29] = ie) : ie = e[29];
    let re;
    e[30] !== n ? (re = n.formatMessage({
        id: "wham.keyboardActions.focusComposer",
        defaultMessage: "Focus chat"
    }), e[30] = n, e[31] = re) : re = e[31];
    let _e;
    e[32] === Symbol.for("react.memo_cache_sentinel") ? (_e = [at.Shift, at.Escape], e[32] = _e) : _e = e[32];
    let le;
    e[33] !== s ? (le = s ? void 0 : [
        [at.Mod, at.Shift, "o"]
    ], e[33] = s, e[34] = le) : le = e[34];
    let We;
    e[35] !== ie || e[36] !== re || e[37] !== le ? (We = [{
        key: "focusComposer",
        action: ie,
        actionMessageDescriptor: re,
        group: oa.Chat,
        keyboardBinding: _e,
        altKeyboardBindings: le
    }], e[35] = ie, e[36] = re, e[37] = le, e[38] = We) : We = e[38], Ba(We);
    const pt = !!s;
    let qe;
    e[39] !== D || e[40] !== pt ? (qe = {
        isFollowUp: pt,
        hasComments: D
    }, e[39] = D, e[40] = pt, e[41] = qe) : qe = e[41];
    const ms = ns(qe),
        {
            isConnected: U
        } = Jt(es.GITHUB_CONNECTOR, "github", "/codex", Zt.CODEX),
        De = as(ms),
        ce = !!De || $ && k || os;
    let se, Q, He;
    if (e[42] !== n || e[43] !== U || e[44] !== R) {
        let w;
        e[48] !== n || e[49] !== U ? (w = y => {
            const z = !y.requiresGitHubConnection || U,
                O = !y.requiresReviewFeature,
                Y = z && O;
            return {
                key: y.key,
                label: n.formatMessage(y.messages.label),
                submitLabel: n.formatMessage(y.messages.submitLabel),
                description: n.formatMessage(y.messages.description),
                environmentMode: y.environmentMode,
                runEnvironmentInQaMode: y.runEnvironmentInQaMode,
                slashCommand: y.slashCommand,
                slashAliases: y.slashAliases,
                icon: y.icon,
                analyticsAction: y.analyticsAction,
                available: Y,
                disabledReason: !Y && y.messages.unavailable ? n.formatMessage(y.messages.unavailable) : void 0
            }
        }, e[48] = n, e[49] = U, e[50] = w) : w = e[50];
        const A = Oa.map(w),
            F = new Map(A.map(mn));
        se = A.filter(dn);
        const P = (Rt = F.get("code")) != null ? Rt : A[0];
        Q = (Ft = F.get(R)) != null ? Ft : P;
        let V;
        e[51] === Symbol.for("react.memo_cache_sentinel") ? (V = y => ({
            command: y.slashCommand,
            aliases: y.slashAliases,
            title: y.label,
            secondary: void 0,
            icon: y.icon,
            disabled: !y.available,
            onSelect: () => {
                y.available && T(y.key)
            }
        }), e[51] = V) : V = e[51], He = se.map(V), e[42] = n, e[43] = U, e[44] = R, e[45] = se, e[46] = Q, e[47] = He
    } else se = e[45], Q = e[46], He = e[47];
    const ht = He;
    let ue;
    e[52] !== Z || e[53] !== ee || e[54] !== m || e[55] !== W || e[56] !== s || e[57] !== ft || e[58] !== D || e[59] !== n || e[60] !== B || e[61] !== H || e[62] !== g || e[63] !== N || e[64] !== p ? (ue = async w => {
        const {
            runEnvironmentInQaMode: A,
            promptOverride: F
        } = w === void 0 ? {
            runEnvironmentInQaMode: !1
        } : w, P = F != null ? F : qs(L(m).state.doc).content, V = vt.getReadyFiles(W.getState());
        if (!(!!P.length || D)) throw new Error("No content to submit");
        const z = H ? ft() : [];
        if (g == null || g(), tt.reset(W), Et(!0), s) return await ve.createFollowUpTask(s.taskId, s.turnId, P, s.comments, A, ee ? Z : void 0, z).catch(O => {
            var Y;
            throw F || (Wt(L(m), P), tt.restoreFiles(W, V)), O instanceof st && O.status === 429 ? (N.invalidateQueries({
                queryKey: ["wham", "usage", "rate-limit-status"]
            }), p.danger(n.formatMessage(Ut.rateLimit), {
                id: s.turnId,
                duration: 5,
                hasCloseButton: !0
            })) : O instanceof Ht ? Qt(O, s.turnId, n, p) : O instanceof st && O.status === 403 && ((Y = O.detail) != null && Y.toLowerCase().includes("multi-factor authentication")) ? It(!0) : p.danger(n.formatMessage({
                id: "wham.whamComposer.failedToCreateFollowUpTask",
                defaultMessage: "Failed to create follow-up"
            }), {
                id: s.turnId,
                duration: 5,
                hasCloseButton: !0
            }), O
        }); {
            const {
                branch: O,
                environmentId: Y
            } = I.getState(), fs = B;
            if (O) {
                if (!Y) throw new Error("Environment is required for new tasks.")
            } else throw new Error("Branch is required");
            const ae = crypto.randomUUID();
            return I.getState().addPendingTaskId(ae), ve.createNewTask(Y, O, P, A, ee ? Z : void 0, z).catch(_ => {
                throw I.getState().removePendingTaskId(ae), F || (Ds(L(m).state.doc) ? (Wt(L(m), P), tt.restoreFiles(W, V)) : (p.danger(n.formatMessage({
                    id: "wham.whamComposer.failedToCreateTaskCopyToClipboard",
                    defaultMessage: "Failed to create task. Previous prompt copied to clipboard."
                }), {
                    id: ae,
                    duration: 5,
                    hasCloseButton: !0
                }), navigator.clipboard.writeText(P))), _
            }).catch(_ => {
                var Ot;
                throw _ instanceof st && _.status === 429 ? (N.invalidateQueries({
                    queryKey: ["wham", "usage", "rate-limit-status"]
                }), p.danger(n.formatMessage(Ut.rateLimit), {
                    id: ae,
                    duration: 5,
                    hasCloseButton: !0
                })) : _ instanceof Ht ? Qt(_, ae, n, p) : _ instanceof st && _.status === 403 && ((Ot = _.detail) != null && Ot.toLowerCase().includes("multi-factor authentication")) ? It(!0) : p.danger(n.formatMessage({
                    id: "wham.whamComposer.failedToCreateTask",
                    defaultMessage: "Failed to create task"
                }), {
                    id: ae,
                    duration: 5,
                    hasCloseButton: !0
                }), _
            }).then(_ => (I.getState().assignPendingTaskToFinalTask(ae, _.task.id), N.invalidateQueries({
                queryKey: ["wham", "usage", "rate-limit-status"]
            }), fs && rt(!1), _))
        }
    }, e[52] = Z, e[53] = ee, e[54] = m, e[55] = W, e[56] = s, e[57] = ft, e[58] = D, e[59] = n, e[60] = B, e[61] = H, e[62] = g, e[63] = N, e[64] = p, e[65] = ue) : ue = e[65];
    let de;
    e[66] !== M || e[67] !== m || e[68] !== s || e[69] !== u || e[70] !== d || e[71] !== i || e[72] !== j || e[73] !== E ? (de = w => {
        E(!0), M(w.task.id, w.turn), w.user_turn && M(w.task.id, w.user_turn), u == null || u(w), setTimeout(() => {
            Mt(L(m))
        }, 0), i(), s && (d(), j())
    }, e[66] = M, e[67] = m, e[68] = s, e[69] = u, e[70] = d, e[71] = i, e[72] = j, e[73] = E, e[74] = de) : de = e[74];
    let Qe;
    e[75] === Symbol.for("react.memo_cache_sentinel") ? (Qe = () => {
        Et(!1)
    }, e[75] = Qe) : Qe = e[75];
    let Ge;
    e[76] !== ue || e[77] !== de ? (Ge = {
        mutationFn: ue,
        onSuccess: de,
        onSettled: Qe
    }, e[76] = ue, e[77] = de, e[78] = Ge) : Ge = e[78];
    const {
        mutate: K,
        isPending: Ue
    } = Vt(Ge);
    let Ke;
    e[79] !== K || e[80] !== ce || e[81] !== Q ? (Ke = w => ce ? !1 : w.metaKey || w.altKey ? (K({
        runEnvironmentInQaMode: Q.runEnvironmentInQaMode
    }), !0) : !1, e[79] = K, e[80] = ce, e[81] = Q, e[82] = Ke) : Ke = e[82];
    const Ve = Ps(Ke);
    let $e, Xe;
    e[83] !== m || e[84] !== Ve ? ($e = () => Hs(L(m), {
        Enter: Ve
    }), Xe = [m, Ve], e[83] = m, e[84] = Ve, e[85] = $e, e[86] = Xe) : ($e = e[85], Xe = e[86]), x.useEffect($e, Xe);
    let ze;
    e[87] !== s ? (ze = Pa(s ? [{
        turn_status: s.turnStatus,
        cancellation_requested_at: s.cancellationRequestedAt
    }, ...s.siblingTurnStatuses.map((w, A) => {
        var F, P;
        return {
            turn_status: w,
            cancellation_requested_at: (P = (F = s.siblingCancellationRequestedAts) == null ? void 0 : F[A]) != null ? P : null
        }
    })] : [], un), e[87] = s, e[88] = ze) : ze = e[88];
    const Ye = ze,
        Je = !!s && us && Ye > 0,
        gt = !Je && (je ? !ne : !0),
        bt = ((Pt = (Bt = s == null ? void 0 : s.siblingTurnStatuses) == null ? void 0 : Bt.length) != null ? Pt : 0) > 1;
    let Ze;
    e[89] !== C || e[90] !== bt || e[91] !== n ? (Ze = bt && C ? n.formatMessage({
        id: "wham.whamComposer.followUpOnTurn",
        defaultMessage: "Follow-up on version {version}"
    }, {
        version: C
    }) : n.formatMessage({
        id: "wham.whamComposer.requestChangesOrAskAQuestion",
        defaultMessage: "Request changes or ask a question"
    }), e[89] = C, e[90] = bt, e[91] = n, e[92] = Ze) : Ze = e[92];
    const xt = Ze,
        Ct = s == null ? void 0 : s.taskId,
        wt = s == null ? void 0 : s.turnId;
    let me;
    e[93] !== (s == null ? void 0 : s.followUpSuggestions) ? (me = (Lt = s == null ? void 0 : s.followUpSuggestions) != null ? Lt : [], e[93] = s == null ? void 0 : s.followUpSuggestions, e[94] = me) : me = e[94];
    let fe;
    e[95] !== K ? (fe = w => {
        K({
            runEnvironmentInQaMode: !1,
            promptOverride: w.body
        })
    }, e[95] = K, e[96] = fe) : fe = e[96];
    let pe;
    e[97] !== b || e[98] !== Z || e[99] !== ee || e[100] !== m || e[101] !== dt || e[102] !== K || e[103] !== f || e[104] !== De || e[105] !== s || e[106] !== xt || e[107] !== D || e[108] !== Ne || e[109] !== Ye || e[110] !== n || e[111] !== S || e[112] !== Ue || e[113] !== X || e[114] !== B || e[115] !== U || e[116] !== H || e[117] !== ce || e[118] !== $ || e[119] !== ne || e[120] !== v || e[121] !== c || e[122] !== mt || e[123] !== ke || e[124] !== se || e[125] !== Q || e[126] !== lt || e[127] !== ct || e[128] !== oe || e[129] !== Je || e[130] !== gt || e[131] !== ht || e[132] !== je ? (pe = w => {
        const {
            isWrappedByContainer: A
        } = w;
        return a.jsxs("div", {
            className: "contents",
            inert: dt,
            children: [a.jsxs(ia, {
                expanded: X,
                canCollapseWithInput: !Ue && A,
                isTemporaryChat: !1,
                shouldUseTightRadius: A,
                onSubmit: () => {
                    Ue || K({
                        runEnvironmentInQaMode: Q.runEnvironmentInQaMode
                    })
                },
                composerController: m,
                ariaLabel: b != null ? b : n.formatMessage({
                    id: "wham.whamComposer.ariaLabel",
                    defaultMessage: "Codex composer"
                }),
                children: [a.jsx(ra, {
                    children: ne ? a.jsx("div", {
                        className: ot("flex max-w-full min-w-0 flex-1 items-center", S && X && "min-h-30"),
                        children: a.jsx(la, {
                            composerController: m,
                            className: "h-14"
                        })
                    }) : a.jsx(ca, {
                        composerController: m,
                        disableAutoFocus: f || Ne,
                        textareaMaxHeightClassName: ot(S && X && "min-h-30", s ? "max-h-[max(10rem,min(calc(100dvh-29rem),10rem))]" : "max-h-[max(10rem,min(calc(100dvh-29rem),50dvh))]"),
                        placeholder: s ? xt : n.formatMessage(B ? At.current.firstTaskMessage : At.current.subsequentTaskMessage)
                    })
                }), U && H && ke.length > 0 && a.jsx(Dt, {
                    children: a.jsx(ua, {
                        files: ke,
                        selectedApps: [],
                        activeSystemHintType: void 0,
                        disableEditButton: !0,
                        forceSmallView: !0,
                        className: "no-scrollbar horizontal-scroll-fade-mask flex flex-nowrap gap-2 overflow-x-auto px-2.5 pt-2.5 pb-1.5 [--edge-fade-distance:1rem]"
                    })
                }), a.jsx(da, {
                    children: a.jsx(Za, {
                        selectableTools: se,
                        selectedTool: Q,
                        onSelectTool: T,
                        isGitHubConnected: U,
                        isImageUploadEnabled: H,
                        fileInputRef: ds,
                        onFileChange: mt
                    })
                }), D && a.jsx(Dt, {
                    children: a.jsx(sn, {
                        comments: s.comments,
                        onClearComments: v
                    })
                }), !ne && a.jsx(ma, {
                    children: a.jsxs("div", {
                        className: "flex gap-2",
                        children: [!s && a.jsx(Ta, {
                            onCreateEnvironment: c
                        }), ee && U && a.jsx(Ya, {
                            attempts: Z,
                            setAttempts: lt
                        })]
                    })
                }), a.jsxs(fa, {
                    children: [!oe && a.jsxs("div", {
                        className: "flex",
                        children: [je && a.jsx("div", {
                            inert: $,
                            children: a.jsx(pa, {
                                composerController: m,
                                composerType: "codex"
                            })
                        }), gt && a.jsx(Va, {
                            isSubmitDisabled: ce,
                            createTask: K,
                            selectedTool: Q,
                            disabledReason: De,
                            isFollowUp: !!s
                        }), Je && a.jsx(_a, {
                            taskId: s.taskId,
                            hasMultipleInProgressOrStreamingTurns: Ye > 1
                        })]
                    }), oe && a.jsx(va, {})]
                })]
            }), a.jsx(an, {
                composerController: m,
                layoutMode: "bottom",
                slashCommands: ht
            }), ct && a.jsx(nn, {})]
        })
    }, e[97] = b, e[98] = Z, e[99] = ee, e[100] = m, e[101] = dt, e[102] = K, e[103] = f, e[104] = De, e[105] = s, e[106] = xt, e[107] = D, e[108] = Ne, e[109] = Ye, e[110] = n, e[111] = S, e[112] = Ue, e[113] = X, e[114] = B, e[115] = U, e[116] = H, e[117] = ce, e[118] = $, e[119] = ne, e[120] = v, e[121] = c, e[122] = mt, e[123] = ke, e[124] = se, e[125] = Q, e[126] = lt, e[127] = ct, e[128] = oe, e[129] = Je, e[130] = gt, e[131] = ht, e[132] = je, e[133] = pe) : pe = e[133];
    let et;
    return e[134] !== D || e[135] !== X || e[136] !== $ || e[137] !== Ct || e[138] !== wt || e[139] !== me || e[140] !== fe || e[141] !== pe ? (et = a.jsx(on, {
        taskId: Ct,
        turnId: wt,
        isComposerExpanded: X,
        followUpSuggestions: me,
        hasComments: D,
        isSubmitting: $,
        onSuggestionClick: fe,
        children: pe
    }), e[134] = D, e[135] = X, e[136] = $, e[137] = Ct, e[138] = wt, e[139] = me, e[140] = fe, e[141] = pe, e[142] = et) : et = e[142], et
}

function un(t) {
    return t.turn_status && ["pending", "in_progress"].includes(t.turn_status) && !ya(t) ? 1 : 0
}

function dn(t) {
    return t.key !== "code" && t.available
}

function mn(t) {
    return [t.key, t]
}

function fn(t) {
    const e = t.fileSpec;
    return e && "width" in e && "height" in e && t.fileId ? [{
        type: "image_asset_pointer",
        asset_pointer: Qs(t.fileId),
        width: e.width,
        height: e.height,
        size_bytes: e.size
    }] : []
}

function pn(t) {
    return t.setBestOfN
}

function hn(t) {
    return t.files
}

function gn(t) {
    return t.setHasSubmittedTaskInSession
}

function bn(t) {
    const {
        addTurnToTaskMap: e
    } = t;
    return e
}
const Ut = it({
    rateLimit: {
        id: "wham.whamComposer.failedToCreateTaskRateLimit",
        defaultMessage: "Rate limit reached"
    }
});
export {
    An as W, La as i, qa as u
};
//# sourceMappingURL=hfur3m15nh6zuk4s.js.map