import {
    rw as m
} from "./dykg4ktvbu3mhmdo.js";
import {
    m as e,
    a as n
} from "./bi6phpick816e345.js";
import "./fg33krlcm0qyi6yw.js";
import "./k15yxxoybkkir2ou.js";
import "./dv2e3o9gddnli9b5.js";
import "./k57uzqpnr7k7r909.js";
import "./nfccle6oyncifphl.js";
import "./hu1bt0oauegdhua6.js";
import "./h1em0bjkpkjv8ykw.js";
import "./b5s349mvbdzayaxi.js";
import "./gy1lpvuoewmzh42c.js";
import "./dbshkzvpochy4889.js";
import "./dqz86fcur874gotm.js";
import "./jed1ux7qibe55pmj.js";
import "./17v8usp0o68l1lsz.js";
import "./ebc4iyfg14nu1gw4.js";
import "./lep2wptoy14cfe2w.js";

function g(o, t) {
    const r = m(o, t);
    return p(r, t)
}

function p(o, t) {
    const r = e(o, t),
        i = n(o, t);
    return {
        "text/plain": r,
        "text/html": i
    }
}
export {
    p as markdownToClipboardContent, g as messageTextToClipboardContent
};
//# sourceMappingURL=nbd6wafppmcw1yix.js.map