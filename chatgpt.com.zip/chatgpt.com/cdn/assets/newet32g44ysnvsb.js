var Oe = Object.defineProperty,
    De = Object.defineProperties;
var Pe = Object.getOwnPropertyDescriptors;
var be = Object.getOwnPropertySymbols;
var Le = Object.prototype.hasOwnProperty,
    Re = Object.prototype.propertyIsEnumerable;
var Me = (s, e, a) => e in s ? Oe(s, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: a
    }) : s[e] = a,
    u = (s, e) => {
        for (var a in e || (e = {})) Le.call(e, a) && Me(s, a, e[a]);
        if (be)
            for (var a of be(e)) Re.call(e, a) && Me(s, a, e[a]);
        return s
    },
    S = (s, e) => De(s, Pe(e));
import {
    f as Ae,
    c as q,
    j as t,
    M as h,
    e as de,
    r as W
} from "./fg33krlcm0qyi6yw.js";
import {
    b as le,
    d as ke,
    o as ee,
    iK as Ce,
    lu as Be,
    c4 as Ue,
    gz as Fe,
    l as ce,
    T as We,
    bO as qe,
    H as Ge,
    m as ze,
    vC as He,
    bp as Ve,
    hs as Ye,
    c2 as Ke,
    C as $e,
    b4 as Q,
    nW as Je,
    a9 as Xe,
    bb as Qe,
    vD as Ze,
    p as et
} from "./dykg4ktvbu3mhmdo.js";
import {
    D as tt
} from "./djur71wanhd4j63t.js";
import {
    ds as te,
    z as st,
    d4 as at,
    y as ot,
    at as nt,
    p$ as Te,
    ao as rt
} from "./k15yxxoybkkir2ou.js";
import {
    u as it
} from "./ogty5pbz2ckq625a.js";
import {
    u as lt
} from "./e3ddui4ro6nb7fig.js";
const y = Ae({
        templates: {
            id: "iidSbJ",
            defaultMessage: "Templates"
        },
        adminConnectedDescription: {
            id: "PCSldL",
            defaultMessage: "This connector is managed by your ChatGPT administrator"
        },
        connectorDisabled: {
            id: "v6nWaS",
            defaultMessage: "This connector is not enabled for your account. Please contact your administrator to enable it."
        },
        backButton: {
            id: "2XH9oW",
            defaultMessage: "Back"
        },
        information: {
            id: "m6oyFG",
            defaultMessage: "Information"
        },
        blockItems: {
            id: "guxwme",
            defaultMessage: "Exclude items from sync"
        },
        connectButton: {
            id: "bQDuj2",
            defaultMessage: "Connect"
        },
        syncingButton: {
            id: "2ma+da",
            defaultMessage: "Syncing"
        },
        refreshActionsButton: {
            id: "lyYLo0",
            defaultMessage: "Refresh"
        },
        enableSync: {
            id: "FQFQxe",
            defaultMessage: "Enable sync"
        },
        disableSync: {
            id: "BNY6qe",
            defaultMessage: "Disable sync"
        },
        disableSyncModalTitle: {
            id: "DGZB7x",
            defaultMessage: "Disable sync for {connector}?"
        },
        disableSyncModalDescription: {
            id: "qJQyMJ",
            defaultMessage: "All synced data will be deleted. If you re-enable sync, it can take 8 hours or more to sync all content."
        },
        disableSyncModalCheckboxLabel: {
            id: "Dl8YNg",
            defaultMessage: "I understand all synced data will be deleted"
        },
        disconnectButton: {
            id: "eeZbkM",
            defaultMessage: "Disconnect"
        },
        settingsButton: {
            id: "Z24j9e",
            defaultMessage: "Settings"
        },
        publishButton: {
            id: "5vHo1z",
            defaultMessage: "Publish"
        },
        manageDropdown: {
            id: "q/O9f7",
            defaultMessage: "Manage"
        },
        reportButton: {
            id: "7YqRbf",
            defaultMessage: "Report an issue"
        },
        reportModalTitle: {
            id: "6oNeBk",
            defaultMessage: "Report"
        },
        connectedOn: {
            id: "b1ykGv",
            defaultMessage: "Connected on"
        },
        connected: {
            id: "9C9A8l",
            defaultMessage: "Connected"
        },
        createdAt: {
            id: "TACRvJ",
            defaultMessage: "Created at"
        },
        deleteButton: {
            id: "Gn89FJ",
            defaultMessage: "Delete"
        },
        actions: {
            id: "K1PvPz",
            defaultMessage: "Actions"
        },
        readAction: {
            id: "OUdavU",
            defaultMessage: "Read"
        },
        writeAction: {
            id: "hfCHYo",
            defaultMessage: "Write"
        },
        openWorldAction: {
            id: "cwPgDK",
            defaultMessage: "Open world"
        },
        disabledAction: {
            id: "Bn5roC",
            defaultMessage: "This action is disabled"
        },
        metadataHeading: {
            id: "qLsGc8",
            defaultMessage: "Metadata"
        },
        metadataOutputTemplate: {
            id: "KzJNSi",
            defaultMessage: "Output template"
        },
        metadataToolInvokingMessage: {
            id: "vNFHen",
            defaultMessage: "Invoking message"
        },
        metadataToolInvokedMessage: {
            id: "BQ6rYZ",
            defaultMessage: "Invoked message"
        },
        metadataWidgetAccessible: {
            id: "hdiMx2",
            defaultMessage: "Widget accessible"
        },
        metadataVisibility: {
            id: "smxZ/P",
            defaultMessage: "Visibility"
        },
        metadataWidgetCsp: {
            id: "zDrGb1",
            defaultMessage: "Widget CSP"
        },
        securitySchemes: {
            id: "xkLoDf",
            defaultMessage: "Security schemes"
        },
        allToolsHiddenWarning: {
            id: "EbNjTZ",
            defaultMessage: "All tools are hidden. Make at least one tool public to use it in ChatGPT."
        },
        hiddenTemplateToolsWarning: {
            id: "KIXphL",
            defaultMessage: "Tools associated with templates are hidden: {toolNames}. Templates tied to hidden tools won't be usable."
        },
        githubInstallationAlert: {
            id: "V4NUT5",
            defaultMessage: "ChatGPT needs access to your repositories to search them."
        },
        chooseRepos: {
            id: "VW7eJj",
            defaultMessage: "Choose repositories"
        },
        preferences: {
            id: "7kCnYS",
            defaultMessage: "Preferences"
        },
        recommendConnection: {
            id: "XpEYQL",
            defaultMessage: "Connection recommendations"
        },
        recommendConnectionDescription: {
            id: "CH3i+a",
            defaultMessage: "Let ChatGPT recommend connecting to {connectorName} when responding."
        },
        allowUsingAutomatically: {
            id: "VaMXaj",
            defaultMessage: "Use automatically in chat"
        },
        allowUsingAutomaticallyDescription: {
            id: "IHuWia",
            defaultMessage: "Let ChatGPT reference {connectorName} automatically when responding."
        },
        toolPersonalizationDebugHeading: {
            id: "lMPDuF",
            defaultMessage: "[DEBUG ONLY] Connector tool personalization"
        },
        toolPersonalizationLabel: {
            id: "C7MxYT",
            defaultMessage: "Reference memories and chats"
        },
        toolPersonalizationDescription: {
            id: "X7CngT",
            defaultMessage: "Allow ChatGPT to reference relevant chats and memories when sharing data with {connectorName} for more helpful responses."
        },
        toolPersonalizationUpdateError: {
            id: "C22IHV",
            defaultMessage: "Error updating tool personalization."
        },
        settingError: {
            id: "zcPmpl",
            defaultMessage: "Error updating setting."
        },
        editDescription: {
            id: "8KkNYS",
            defaultMessage: "Edit connector descriptions"
        },
        saveDescription: {
            id: "b728ms",
            defaultMessage: "Save"
        },
        descriptionFieldLabel: {
            id: "G4TQb4",
            defaultMessage: "Connector description"
        },
        descriptionPlaceholder: {
            id: "UDk3bR",
            defaultMessage: "Describe what this connector does for your team"
        },
        modelDescriptionFieldLabel: {
            id: "5YP4M7",
            defaultMessage: "Model description"
        },
        updateDescriptionSuccess: {
            id: "s/uJtK",
            defaultMessage: "Connector details updated"
        },
        updateDescriptionError: {
            id: "/zjnPq",
            defaultMessage: "Couldn't update connector details"
        },
        connectOnMobileTooltip: {
            id: "Mpw12y",
            defaultMessage: "Connect on your iPhone or iPad"
        }
    }),
    Se = "openai/outputTemplate",
    Ne = "openai/toolInvocation/invoking",
    Ee = "openai/toolInvocation/invoked",
    we = "openai/widgetAccessible",
    se = "openai/visibility",
    Ie = "openai/widgetCSP",
    ct = "openai/widgetDomain",
    dt = [se, Se, Ne, Ee, we],
    _e = s => {
        if (s) {
            if (typeof s == "string" || typeof s == "number" || typeof s == "boolean") return String(s);
            try {
                return JSON.stringify(s, null, 2)
            } catch (e) {
                return String(s)
            }
        }
    },
    ut = s => dt.reduce((e, a) => {
        const o = _e(s == null ? void 0 : s[a]);
        return o === void 0 || e.push({
            key: a,
            value: o
        }), e
    }, []),
    mt = s => {
        "use forget";
        const e = q.c(10),
            {
                entries: a,
                headingMessage: o,
                labels: n
            } = s;
        if (a.length === 0) return null;
        let c;
        e[0] !== o ? (c = t.jsx("div", {
            className: "text-token-text-tertiary text-[11px] font-semibold uppercase",
            children: t.jsx(h, u({}, o))
        }), e[0] = o, e[1] = c) : c = e[1];
        let d;
        if (e[2] !== a || e[3] !== n) {
            let m;
            e[5] !== n ? (m = g => {
                const {
                    key: p,
                    value: x
                } = g;
                return t.jsxs("div", {
                    className: "flex flex-col gap-1",
                    children: [t.jsx("div", {
                        className: "text-token-text-secondary",
                        children: t.jsx(h, u({}, n[p]))
                    }), t.jsx("pre", {
                        className: "bg-token-bg-tertiary text-token-text-tertiary rounded-md px-2 py-1 font-mono text-[11px] leading-[14px] whitespace-pre-wrap",
                        children: x
                    })]
                }, p)
            }, e[5] = n, e[6] = m) : m = e[6], d = a.map(m), e[2] = a, e[3] = n, e[4] = d
        } else d = e[4];
        let r;
        return e[7] !== c || e[8] !== d ? (r = t.jsxs("div", {
            className: "mt-1 flex flex-col gap-2 text-xs",
            children: [c, d]
        }), e[7] = c, e[8] = d, e[9] = r) : r = e[9], r
    },
    pt = s => !s || s.length === 0 ? [] : s.reduce((e, a) => {
        const o = _e(a);
        return o === void 0 || e.push({
            key: a.type,
            value: o
        }), e
    }, []),
    ft = s => {
        "use forget";
        const e = q.c(10),
            {
                entries: a,
                headingMessage: o
            } = s;
        if (a.length === 0) {
            let g;
            return e[0] === Symbol.for("react.memo_cache_sentinel") ? (g = t.jsx(t.Fragment, {}), e[0] = g) : g = e[0], g
        }
        let n;
        e[1] !== a ? (n = a.map(gt).join(",\n"), e[1] = a, e[2] = n) : n = e[2];
        const c = n;
        let d;
        e[3] !== o ? (d = t.jsx("div", {
            className: "text-token-text-tertiary text-[11px] font-semibold uppercase",
            children: t.jsx(h, u({}, o))
        }), e[3] = o, e[4] = d) : d = e[4];
        let r;
        e[5] !== c ? (r = t.jsx("pre", {
            className: "bg-token-bg-tertiary text-token-text-tertiary rounded-md px-2 py-1 font-mono text-[11px] leading-[14px] whitespace-pre-wrap",
            children: c
        }), e[5] = c, e[6] = r) : r = e[6];
        let m;
        return e[7] !== d || e[8] !== r ? (m = t.jsxs("div", {
            className: "mt-1 flex flex-col gap-2 text-xs",
            children: [d, r]
        }), e[7] = d, e[8] = r, e[9] = m) : m = e[9], m
    };

function gt(s) {
    return s.value
}
const ht = s => {
        const e = [];
        return s.is_consequential && e.push("write"), e
    },
    xt = ({
        badgeKeys: s,
        labels: e
    }) => s.length === 0 ? null : t.jsx("div", {
        className: "flex items-center gap-1 select-none",
        children: s.map(a => t.jsx("div", {
            className: "border-token-text-quartenary text-token-text-secondary dark:border-token-border-heavy dark:text-token-text-tertiary items-center rounded-full border px-1 py-0.5 text-[8px] leading-3 font-semibold uppercase",
            children: t.jsx(h, u({}, e[a]))
        }, a))
    }),
    bt = {
        read: y.readAction,
        write: y.writeAction,
        open_world: y.openWorldAction
    },
    Mt = {
        [Se]: y.metadataOutputTemplate,
        [Ne]: y.metadataToolInvokingMessage,
        [Ee]: y.metadataToolInvokedMessage,
        [we]: y.metadataWidgetAccessible,
        [se]: y.metadataVisibility
    },
    Ut = s => {
        "use forget";
        const e = q.c(39),
            {
                connector: a,
                actions: o,
                link: n,
                onToggleAction: c,
                isTogglingAction: d
            } = s,
            r = le();
        let m;
        e[0] !== r ? (m = () => Fe(r), e[0] = r, e[1] = m) : m = e[1];
        const g = ke(m),
            p = le();
        let x;
        e[2] !== p ? (x = ee(p, "156264210"), e[2] = p, e[3] = x) : x = e[3];
        const f = x;
        let b;
        e[4] !== p ? (b = ee(p, "3475796410"), e[4] = p, e[5] = b) : b = e[5];
        const M = b,
            A = ee(p, "1817078280"),
            I = a.connector_type !== "SERVICE" || M,
            v = de();
        if (!g && (!(A && a.supports_full_actions && a.status === "ENABLED") || a.connector_type === "FIRST_PARTY_ECOSYSTEM" || a.distribution_channel === "ECOSYSTEM_DIRECTORY")) return null;
        let k;
        if (e[6] !== o || e[7] !== I || e[8] !== a.connector_type || e[9] !== a.status || e[10] !== a.supports_full_actions || e[11] !== v || e[12] !== d || e[13] !== (n == null ? void 0 : n.actions) || e[14] !== c || e[15] !== f) {
            const ae = Object.fromEntries(o.map(vt).flat().map(jt));
            let D;
            e[17] !== o || e[18] !== v ? (D = Ct(v, o), e[17] = o, e[18] = v, e[19] = D) : D = e[19];
            const G = D;
            let P;
            e[20] !== a.connector_type ? (P = C => a.connector_type === "SERVICE" ? C.is_read_only : !0, e[20] = a.connector_type, e[21] = P) : P = e[21];
            const oe = o.filter(P).toSorted(At),
                N = Object.entries(ae);
            let L;
            e[22] === Symbol.for("react.memo_cache_sentinel") ? (L = t.jsx("span", {
                className: "bg-token-border-heavy h-px flex-1"
            }), e[22] = L) : L = e[22];
            let z;
            e[23] === Symbol.for("react.memo_cache_sentinel") ? (z = t.jsxs("div", {
                className: "flex items-center gap-2 pb-4",
                children: [L, t.jsx("span", {
                    className: "text-token-text-secondary text-xs",
                    children: t.jsx(h, {
                        id: "OeCYjC",
                        defaultMessage: "Developer mode"
                    })
                }), t.jsx("span", {
                    className: "bg-token-border-heavy h-px flex-1"
                })]
            }), e[23] = z) : z = e[23];
            let E;
            e[24] === Symbol.for("react.memo_cache_sentinel") ? (E = t.jsx("div", {
                className: "flex items-baseline justify-between pb-3 text-base font-medium",
                children: t.jsx(h, u({}, y.actions))
            }), e[24] = E) : E = e[24];
            let H;
            e[25] !== G ? (H = G.length > 0 && t.jsx("div", {
                className: "pb-3",
                children: t.jsx(re, {
                    warnings: G
                })
            }), e[25] = G, e[26] = H) : H = e[26];
            let R;
            e[27] !== I || e[28] !== a.connector_type || e[29] !== a.status || e[30] !== a.supports_full_actions || e[31] !== v || e[32] !== d || e[33] !== (n == null ? void 0 : n.actions) || e[34] !== c || e[35] !== f ? (R = C => {
                var _, F, O, X, i;
                const Y = ht(C),
                    B = (_ = C.meta) != null ? _ : {},
                    K = (O = (F = C.visibility) != null ? F : B[se]) != null ? O : "public",
                    $ = [...ut(S(u({}, B), {
                        [se]: K
                    }))],
                    U = !!(a.supports_full_actions && a.status === "ENABLED") || a.status === "ONLY_ME" || a.connector_type === "SERVICE" && C.is_read_only || ["search", "fetch"].includes(C.name);
                return t.jsxs("li", {
                    className: U ? void 0 : "opacity-50",
                    children: [t.jsxs("div", {
                        className: "flex items-center gap-2",
                        children: [t.jsxs("div", {
                            className: "flex items-center gap-1",
                            children: [t.jsx("div", {
                                className: ce(["font-mono font-medium", !C.is_enabled && "text-token-text-tertiary"]),
                                children: C.name
                            }), !C.is_enabled && t.jsx(We, {
                                label: v.formatMessage(y.disabledAction),
                                children: t.jsx(tt, {
                                    className: "icon text-token-text-tertiary h-4 w-4"
                                })
                            })]
                        }), xt({
                            badgeKeys: Y,
                            labels: bt
                        }), U && f && c && t.jsx(qe, {
                            "aria-hidden": !0,
                            checked: (X = n == null ? void 0 : n.actions) == null ? void 0 : X.includes(C.name),
                            size: "small",
                            onCheckedChange: T => c == null ? void 0 : c(C.name, T),
                            disabled: !!d || !I
                        })]
                    }), t.jsx("div", {
                        className: "text-token-text-tertiary line-clamp-3 text-xs",
                        children: C.description
                    }), t.jsx(ft, {
                        entries: pt((i = C.meta) == null ? void 0 : i.securitySchemes),
                        headingMessage: y.securitySchemes
                    }), t.jsx(mt, {
                        entries: $,
                        headingMessage: y.metadataHeading,
                        labels: Mt
                    })]
                }, C.name)
            }, e[27] = I, e[28] = a.connector_type, e[29] = a.status, e[30] = a.supports_full_actions, e[31] = v, e[32] = d, e[33] = n == null ? void 0 : n.actions, e[34] = c, e[35] = f, e[36] = R) : R = e[36];
            const V = oe.map(R);
            let w;
            e[37] !== V ? (w = t.jsx("ul", {
                className: "mb-4 flex flex-col gap-4",
                children: V
            }), e[37] = V, e[38] = w) : w = e[38], k = t.jsxs("div", {
                className: "px-2",
                children: [z, E, H, w, N.length > 0 && t.jsxs(t.Fragment, {
                    children: [t.jsx("div", {
                        className: "flex items-baseline justify-between pb-3 text-base font-medium",
                        children: t.jsx(h, u({}, y.templates))
                    }), t.jsx("ul", {
                        className: "mb-4 flex flex-col gap-4",
                        children: N.map(C => {
                            var J, $;
                            const [Y, B] = C, K = yt(v, (J = B.meta) != null ? J : {});
                            return t.jsxs("li", {
                                className: "flex flex-col gap-2",
                                children: [t.jsx("div", {
                                    className: "font-mono font-medium",
                                    children: Y
                                }), K.length > 0 && t.jsx(re, {
                                    warnings: K
                                }), t.jsx("ul", {
                                    className: "flex flex-col gap-2",
                                    children: Object.entries(($ = B.meta) != null ? $ : {}).map(U => {
                                        const [_, F] = U, O = Tt(v, _, F);
                                        return t.jsxs("li", {
                                            className: "flex flex-col gap-1",
                                            children: [t.jsx("span", {
                                                className: "text-token-text-secondary font-mono text-xs",
                                                children: _
                                            }), O.length > 0 && t.jsx(re, {
                                                warnings: O
                                            }), t.jsx("pre", {
                                                className: "bg-token-bg-tertiary text-token-text-tertiary rounded-md px-2 py-1 font-mono text-[11px] leading-[14px] whitespace-pre-wrap",
                                                children: JSON.stringify(F, null, 2)
                                            })]
                                        }, _)
                                    })
                                })]
                            }, Y)
                        })
                    })]
                })]
            }), e[6] = o, e[7] = I, e[8] = a.connector_type, e[9] = a.status, e[10] = a.supports_full_actions, e[11] = v, e[12] = d, e[13] = n == null ? void 0 : n.actions, e[14] = c, e[15] = f, e[16] = k
        } else k = e[16];
        return k
    },
    re = s => {
        "use forget";
        const e = q.c(4),
            {
                warnings: a
            } = s;
        let o;
        e[0] !== a ? (o = a.map(kt), e[0] = a, e[1] = o) : o = e[1];
        let n;
        return e[2] !== o ? (n = t.jsx("ul", {
            className: "bg-token-bg-status-warning border-token-border-status-warning flex flex-col gap-1 rounded-md border p-2",
            children: o
        }), e[2] = o, e[3] = n) : n = e[3], n
    },
    Ct = (s, e) => {
        const a = [];
        if (e.every(o => o.visibility === "private") && a.push(s.formatMessage(y.allToolsHiddenWarning)), e.some(o => {
                var n;
                return !!((n = o.templates) != null && n.length) && o.visibility === "private"
            })) {
            const o = e.filter(n => {
                var c;
                return !!((c = n.templates) != null && c.length) && n.visibility === "private"
            }).map(({
                name: n
            }) => n).sort().join(", ");
            a.push(s.formatMessage(y.hiddenTemplateToolsWarning, {
                toolNames: o
            }))
        }
        return a
    },
    Tt = (s, e, a) => {
        var n, c;
        const o = [];
        return e === Ie && (c = Be((n = Ue(a)) == null ? void 0 : n.frame_domains)) != null && c.length && o.push(s.formatMessage({
            id: "gpCGuS",
            defaultMessage: "Apps that embed external content via iframes require additional security review and will delay approval."
        })), o
    },
    yt = (s, e) => {
        const a = [];
        return e[Ie] || a.push(s.formatMessage({
            id: "bO7ISD",
            defaultMessage: "<docsLink>Widget CSP</docsLink> is not set for this template. A <docsLink>CSP</docsLink> is required for app submission."
        }, {
            docsLink: o => t.jsx(Ce, {
                className: "underline",
                href: "https://developers.openai.com/apps-sdk/build/mcp-server/#build-your-mcp-server",
                children: o
            })
        })), e[ct] || a.push(s.formatMessage({
            id: "sTHbxc",
            defaultMessage: "<docsLink>Widget domain</docsLink> is not set for this template. A unique <docsLink>domain</docsLink> is required for app submission."
        }, {
            docsLink: o => t.jsx(Ce, {
                className: "underline",
                href: "https://developers.openai.com/apps-sdk/build/mcp-server/#build-your-mcp-server",
                children: o
            })
        })), a
    };

function vt(s) {
    var e;
    return (e = s.templates) != null ? e : []
}

function jt(s) {
    return [s.resource_uri, s]
}

function At(s, e) {
    return Number(e.is_enabled) - Number(s.is_enabled) || s.name.localeCompare(e.name)
}

function kt(s, e) {
    return t.jsx("li", {
        className: "text-token-text-status-warning text-xs",
        children: s
    }, e)
}

function Ft(s) {
    "use forget";
    var a, o;
    const e = Ge();
    return !e || !s ? !1 : !!((a = s.owners) != null && a.some(n => n.type === "USER" && n.id === e.normalizedAccountUserId) || (e.isAdminOfAccount() || e.isOwnerOfAccount()) && ((o = s.owners) != null && o.some(n => n.type === "WORKSPACE" && n.id === e.getWorkspaceId())))
}

function ye(s) {
    "use forget";
    const e = q.c(19),
        {
            form: a,
            showErrors: o,
            setShowErrors: n,
            clientIdAriaLabel: c,
            clientIdPlaceholder: d,
            clientSecretAriaLabel: r,
            clientSecretPlaceholder: m
        } = s;
    let g;
    e[0] !== c || e[1] !== d || e[2] !== n || e[3] !== o ? (g = M => t.jsx(te, {
        name: "custom-connector-client-id",
        value: M.state.value,
        onChange: A => {
            M.handleChange(A.target.value), o && n(!1)
        },
        ariaLabel: c,
        placeholder: d,
        error: o ? M.state.meta.errors[0] : void 0,
        autoComplete: "off",
        inputClassName: "bg-token-bg-primary!"
    }), e[0] = c, e[1] = d, e[2] = n, e[3] = o, e[4] = g) : g = e[4];
    let p;
    e[5] !== a.Field || e[6] !== g ? (p = t.jsx(a.Field, {
        name: "oauthClientId",
        children: g
    }), e[5] = a.Field, e[6] = g, e[7] = p) : p = e[7];
    let x;
    e[8] !== r || e[9] !== m || e[10] !== n || e[11] !== o ? (x = M => t.jsx(te, {
        name: "custom-connector-client-secret",
        type: "password",
        value: M.state.value,
        onChange: A => {
            M.handleChange(A.target.value), o && n(!1)
        },
        ariaLabel: r,
        placeholder: m,
        error: o ? M.state.meta.errors[0] : void 0,
        autoComplete: "off",
        inputClassName: "bg-token-bg-primary!"
    }), e[8] = r, e[9] = m, e[10] = n, e[11] = o, e[12] = x) : x = e[12];
    let f;
    e[13] !== a.Field || e[14] !== x ? (f = t.jsx(a.Field, {
        name: "oauthClientSecret",
        children: x
    }), e[13] = a.Field, e[14] = x, e[15] = f) : f = e[15];
    let b;
    return e[16] !== p || e[17] !== f ? (b = t.jsxs("div", {
        className: "flex flex-col gap-3",
        children: [p, f]
    }), e[16] = p, e[17] = f, e[18] = b) : b = e[18], b
}
const St = s => {
        switch (s) {
            case "OAUTH":
                return "OAUTH";
            case "NONE":
                return "NONE";
            case "MIXED":
                return
        }
    },
    ie = s => s === "OAUTH" || s === "MIXED",
    ve = 1024 * 1024 * 4,
    Nt = s => {
        var e, a, o, n, c;
        return {
            name: (e = s == null ? void 0 : s.name) != null ? e : "",
            templateExampleUrl: (a = s == null ? void 0 : s.example_url) != null ? a : null,
            description: (o = s == null ? void 0 : s.description) != null ? o : "",
            logoUrl: (n = s == null ? void 0 : s.logo_url) != null ? n : null,
            supportedAuthTypes: (c = s == null ? void 0 : s.supported_auth_types) != null ? c : []
        }
    },
    Et = s => {
        var a;
        const e = (a = s == null ? void 0 : s.branding) == null ? void 0 : a.website;
        return (s == null ? void 0 : s.template_id) === "templated_apps_Databricks" && e ? S(u({}, l.databricksTemplateExplanation), {
            values: {
                link: o => t.jsx(Q, {
                    href: e,
                    openNewTab: !0,
                    className: "inline",
                    children: o
                })
            }
        }) : (s == null ? void 0 : s.template_id) === "templated_apps_Snowflake" && e ? S(u({}, l.snowflakeTemplateExplanation), {
            values: {
                link: o => t.jsx(Q, {
                    href: e,
                    openNewTab: !0,
                    className: "inline",
                    children: o
                })
            }
        }) : null
    },
    je = () => {
        "use forget";
        const s = q.c(1);
        let e;
        return s[0] === Symbol.for("react.memo_cache_sentinel") ? (e = t.jsx("span", {
            className: "text-token-text-tertiary font-normal",
            children: t.jsx(h, u({}, l.optionalText))
        }), s[0] = e) : e = s[0], e
    },
    wt = s => {
        "use forget";
        const e = q.c(15),
            {
                previewUrl: a,
                isDragActive: o
            } = s,
            n = de(),
            c = Qe();
        if (!a || o) {
            const x = o ? "border-green-600 bg-green-600/30 text-green-600" : "border-token-border-heavy text-token-text-tertiary";
            let f;
            e[0] !== x ? (f = ce("rounded-xl border border-dashed p-4", x), e[0] = x, e[1] = f) : f = e[1];
            let b;
            e[2] === Symbol.for("react.memo_cache_sentinel") ? (b = t.jsx(rt, {
                className: "h-6 w-6"
            }), e[2] = b) : b = e[2];
            let M;
            return e[3] !== f ? (M = t.jsx("span", {
                className: f,
                children: b
            }), e[3] = f, e[4] = M) : M = e[4], M
        }
        const d = c && "bg-white";
        let r;
        e[5] !== d ? (r = ce("bg-token-bg-tertiary overflow-hidden rounded-xl border", d), e[5] = d, e[6] = r) : r = e[6];
        let m;
        e[7] !== n ? (m = n.formatMessage(l.iconPreviewAlt), e[7] = n, e[8] = m) : m = e[8];
        let g;
        e[9] !== a || e[10] !== m ? (g = t.jsx("img", {
            src: a,
            alt: m,
            className: "h-14 w-14 object-cover"
        }), e[9] = a, e[10] = m, e[11] = g) : g = e[11];
        let p;
        return e[12] !== r || e[13] !== g ? (p = t.jsx("span", {
            className: r,
            children: g
        }), e[12] = r, e[13] = g, e[14] = p) : p = e[14], p
    },
    It = s => new Promise((e, a) => {
        const o = new FileReader;
        o.onloadend = () => e(o.result), o.onerror = () => a(), o.readAsDataURL(s)
    }),
    Wt = ({
        onClose: s,
        redirectAfter: e,
        template: a
    }) => {
        "use no forget";
        var X;
        const o = ze(),
            {
                mutateAsync: n,
                isPending: c
            } = He(Ve.CONNECTOR_SETTING),
            d = le(),
            r = de(),
            {
                name: m,
                description: g,
                logoUrl: p,
                templateExampleUrl: x,
                supportedAuthTypes: f
            } = Nt(a),
            [b, M] = W.useState(!1),
            A = !!f && f.length > 0,
            I = f.some(i => i.type === "OAUTH" && i.supports_dcr),
            v = (X = A ? f[0].type : void 0) != null ? X : "OAUTH",
            [k, ae] = W.useState(v),
            [D, G] = W.useState(!1),
            [P, oe] = W.useState(!1),
            N = it({
                defaultValues: {
                    name: m,
                    url: "",
                    description: g,
                    oauthClientId: "",
                    oauthClientSecret: ""
                },
                onSubmit: async ({
                    value: i
                }) => {
                    var me, pe, fe, ge;
                    const T = L ? await It(L) : p,
                        ne = [];
                    let ue = null;
                    if (ie(k)) {
                        k === "MIXED" && ne.push({
                            type: "NONE"
                        });
                        try {
                            let j = [];
                            if (!w) {
                                const xe = await Ze(i.url.trim());
                                ne.push(xe), j = (me = xe.base_scopes) != null ? me : []
                            }
                            const Z = i.oauthClientId.trim(),
                                he = i.oauthClientSecret.trim();
                            if (A && ie(k) && !I && Z.length === 0) {
                                o.danger(l.clientIdRequired);
                                return
                            }
                            if (he.length !== 0 && Z.length === 0) {
                                o.danger(l.clientIdRequired);
                                return
                            }
                            Z.length !== 0 && (ue = {
                                client_id: Z,
                                client_secret: he,
                                scopes: j
                            })
                        } catch (j) {
                            o.danger(l.oauthConfigError, {
                                error: j
                            });
                            return
                        }
                    }
                    try {
                        const j = await n({
                            name: i.name.trim(),
                            mcp_url: i.url.trim(),
                            description: i.description.trim(),
                            logo_url: T,
                            supported_auth: w ? void 0 : ne,
                            oauth_client_params: ue,
                            authTypeOverride: w ? void 0 : St(k),
                            redirectAfter: e,
                            template_id: (pe = a == null ? void 0 : a.template_id) != null ? pe : void 0
                        });
                        if (!j.implementsRetrievable && !((fe = j.connector) != null && fe.supports_full_actions)) {
                            V(!0);
                            return
                        }
                        s((ge = j.connector) == null ? void 0 : ge.id)
                    } catch (j) {
                        j instanceof et && j.status === 409 ? o.danger(l.duplicateName) : o.danger(l.createConnectorError, {
                            error: j
                        });
                        return
                    }
                },
                validators: {
                    onSubmit: ({
                        value: i
                    }) => {
                        const T = {};
                        return i.name.trim() || (T.name = r.formatMessage({
                            id: "vtyh9X",
                            defaultMessage: "Name is required"
                        })), i.url.trim() ? i.url.trim().match(/^https?:\/\//) || (T.url = r.formatMessage({
                            id: "7hn6Jq",
                            defaultMessage: "URL is invalid"
                        })) : T.url = r.formatMessage({
                            id: "7WV2q4",
                            defaultMessage: "URL is required"
                        }), {
                            fields: T
                        }
                    }
                }
            }),
            [L, z] = W.useState(null),
            [E, H] = W.useState(p),
            [R, V] = W.useState(!1),
            w = ee(d, "4145215199"),
            C = ke(() => Ye(d)),
            Y = i => {
                if (E != null && E.startsWith("blob:") && URL.revokeObjectURL(E), i.size > ve) {
                    o.danger(l.iconTooLarge);
                    return
                }
                z(i);
                const T = URL.createObjectURL(i);
                H(T)
            },
            {
                getRootProps: B,
                getInputProps: K,
                isDragActive: J
            } = lt({
                accept: {
                    "image/*": []
                },
                multiple: !1,
                noKeyboard: !0,
                noClick: !0,
                maxSize: ve,
                onDropAccepted: i => {
                    i.length > 0 && Y(i[0])
                },
                onDropRejected: () => {
                    o.danger(l.iconInvalid)
                }
            }),
            $ = i => {
                i.preventDefault(), D && (M(!0), N.handleSubmit())
            },
            U = Ke(d, "2281575548"),
            _ = U.get("docs_url", "https://platform.openai.com/docs/mcp"),
            F = U.get("safety_url", "https://platform.openai.com/docs/mcp#risks-and-safety"),
            O = Et(a);
        return t.jsx($e, {
            testId: "modal-create-custom-connector",
            title: t.jsx("span", {
                className: "flex items-center gap-1",
                children: t.jsx(h, u({}, a ? S(u({}, l.createTemplateAppModalTitle), {
                    values: {
                        templateName: a.name,
                        betaBadge: t.jsx(Te, {})
                    }
                }) : S(u({}, l.createCustomAppModalTitle), {
                    values: {
                        betaBadge: t.jsx(Te, {})
                    }
                })))
            }),
            type: "success",
            isOpen: !0,
            onClose: () => s(),
            showCloseButton: !0,
            size: "custom",
            className: "max-w-[448px]",
            children: t.jsxs("form", {
                onSubmit: $,
                className: "flex flex-col gap-4",
                children: [t.jsxs("label", S(u({}, B({
                    className: "flex cursor-pointer items-center gap-2.5"
                })), {
                    children: [t.jsx("input", u({}, K())), t.jsx(wt, {
                        previewUrl: E,
                        isDragActive: J
                    }), t.jsxs("span", {
                        className: "flex flex-col gap-1",
                        children: [t.jsx("span", {
                            className: "text-sm font-medium",
                            children: t.jsx(h, S(u({}, l.iconTitle), {
                                values: {
                                    optionalText: t.jsx(je, {})
                                }
                            }))
                        }), t.jsx("span", {
                            className: "text-token-text-tertiary text-xs",
                            children: t.jsx(h, u({}, l.iconDescription))
                        })]
                    })]
                })), O && t.jsx("span", {
                    className: "text-sm font-medium",
                    children: t.jsx(h, u({}, O))
                }), t.jsx(N.Field, {
                    name: "name",
                    children: i => t.jsxs("div", {
                        children: [t.jsx("label", {
                            htmlFor: "custom-connector-name",
                            className: "mb-1 block text-sm font-medium",
                            children: t.jsx(h, u({}, l.nameTitle))
                        }), t.jsx(te, {
                            name: "custom-connector-name",
                            value: i.state.value,
                            onChange: T => {
                                i.handleChange(T.target.value), b && M(!1)
                            },
                            ariaLabel: r.formatMessage(l.nameTitle),
                            placeholder: r.formatMessage(l.namePlaceholder),
                            error: b ? i.state.meta.errors[0] : void 0,
                            inputClassName: "bg-token-bg-primary!"
                        })]
                    })
                }), t.jsx(N.Field, {
                    name: "description",
                    children: i => t.jsxs("div", {
                        children: [t.jsx("label", {
                            htmlFor: "custom-connector-description",
                            className: "mb-1 block text-sm font-medium",
                            children: t.jsx(h, S(u({}, l.descriptionTitle), {
                                values: {
                                    optionalText: t.jsx(je, {})
                                }
                            }))
                        }), t.jsx(st, {
                            name: "custom-connector-description",
                            value: i.state.value,
                            onChange: T => i.handleChange(T.target.value),
                            ariaLabel: r.formatMessage(l.descriptionTitle, {
                                optionalText: r.formatMessage(l.optionalText)
                            }),
                            placeholder: r.formatMessage(l.descriptionPlaceholder),
                            inputClassName: "bg-token-bg-primary!"
                        })]
                    })
                }), t.jsx(N.Field, {
                    name: "url",
                    children: i => t.jsxs("div", {
                        children: [t.jsx("label", {
                            htmlFor: "custom-connector-url",
                            className: "mb-1 block text-sm font-medium",
                            children: t.jsx(h, u({}, l.urlTitle))
                        }), t.jsx(te, {
                            name: "custom-connector-url",
                            value: i.state.value,
                            onChange: T => {
                                i.handleChange(T.target.value), b && M(!1), R && V(!1)
                            },
                            ariaLabel: r.formatMessage(l.urlTitle),
                            placeholder: x != null ? x : r.formatMessage(l.urlPlaceholder),
                            inputClassName: "bg-token-bg-primary!",
                            error: R ? t.jsx("span", {
                                children: t.jsx(h, S(u({}, C ? l.developerModeConformanceError : l.conformanceError), {
                                    values: {
                                        link: T => t.jsx(Q, {
                                            href: _,
                                            openNewTab: !0,
                                            children: T
                                        })
                                    }
                                }))
                            }) : b ? i.state.meta.errors[0] : void 0
                        })]
                    })
                }), !w && t.jsxs("div", {
                    children: [t.jsx("label", {
                        htmlFor: "custom-connector-auth",
                        className: "mb-1 block text-sm font-medium",
                        children: t.jsx(h, u({}, l.authTypeTitle))
                    }), (!A || f.length > 1) && t.jsx(at, {
                        options: [{
                            label: r.formatMessage(l.oauthOption),
                            value: "OAUTH"
                        }, {
                            label: r.formatMessage(l.noAuthOption),
                            value: "NONE"
                        }, {
                            label: r.formatMessage(l.mixedAuthOption),
                            value: "MIXED"
                        }],
                        value: k,
                        onValueChange: i => ae(i),
                        triggerId: "custom-connector-auth",
                        triggerClassName: "w-full justify-between border-token-border-heavy"
                    })]
                }), w ? t.jsxs("div", {
                    className: "border-token-border-heavy rounded-xl border",
                    children: [t.jsx("button", {
                        type: "button",
                        className: "w-full px-4 py-3 text-start text-sm font-medium",
                        "aria-expanded": P,
                        "aria-controls": "advanced-auth-panel",
                        onClick: () => oe(i => !i),
                        children: t.jsx(h, u({}, l.advancedSettings))
                    }), P && t.jsx("div", {
                        id: "advanced-auth-panel",
                        className: "border-token-border-heavy border-t p-4",
                        children: t.jsx(ye, {
                            form: N,
                            showErrors: b,
                            setShowErrors: M,
                            clientIdAriaLabel: r.formatMessage(l.clientIdTitle),
                            clientIdPlaceholder: A && !I ? r.formatMessage(l.oauthClientIdRequiredPlaceholder) : r.formatMessage(l.oauthClientIdPlaceholder),
                            clientSecretAriaLabel: r.formatMessage(l.clientSecretTitle),
                            clientSecretPlaceholder: r.formatMessage(l.oauthClientSecretPlaceholder)
                        })
                    })]
                }) : ie(k) && t.jsx(ye, {
                    form: N,
                    showErrors: b,
                    setShowErrors: M,
                    clientIdAriaLabel: r.formatMessage(l.clientIdTitle),
                    clientIdPlaceholder: A && !I ? r.formatMessage(l.oauthClientIdRequiredPlaceholder) : r.formatMessage(l.oauthClientIdPlaceholder),
                    clientSecretAriaLabel: r.formatMessage(l.clientSecretTitle),
                    clientSecretPlaceholder: r.formatMessage(l.oauthClientSecretPlaceholder)
                }), t.jsxs("div", {
                    children: [t.jsxs("div", {
                        className: "border-token-border-status-warning bg-token-bg-status-warning text-token-text-status-warning flex items-center gap-2 rounded-t-2xl border border-b-0 px-4 py-3 text-sm font-medium",
                        children: [t.jsx(Je, {
                            className: "h-6 w-6"
                        }), t.jsx("span", {
                            children: t.jsx(h, S(u({}, l.customConnectorRiskBanner), {
                                values: {
                                    link: i => t.jsx(Q, {
                                        href: F,
                                        openNewTab: !0,
                                        className: "inline",
                                        children: i
                                    }, "custom-connector-banner-link")
                                }
                            }))
                        })]
                    }), t.jsxs("label", {
                        htmlFor: "trust-checkbox",
                        className: "flex items-center gap-3 rounded-b-2xl border border-gray-200 bg-white px-4 py-4 text-sm dark:border-gray-700 dark:bg-gray-800",
                        children: [t.jsx(ot, {
                            id: "trust-checkbox",
                            onChange: () => G(i => !i),
                            disabled: c
                        }), t.jsxs("div", {
                            children: [t.jsx("p", {
                                className: "text-sm font-medium",
                                children: t.jsx(h, u({}, l.acceptLabelTitle))
                            }), t.jsx("p", {
                                className: "text-token-text-tertiary text-sm",
                                children: t.jsx(h, u({}, l.customConnectorRiskSubtitle))
                            })]
                        })]
                    })]
                }), t.jsxs("div", {
                    className: "flex w-full items-center justify-between",
                    children: [t.jsxs(Q, {
                        href: _,
                        openNewTab: !0,
                        className: "text-token-text-tertiary text-sm",
                        children: [t.jsx(nt, {
                            className: "me-1.5 inline h-4.5 w-4.5"
                        }), t.jsx(h, u({}, l.readTheGuideLink))]
                    }), t.jsx(N.Subscribe, {
                        selector: i => [i.isSubmitting],
                        children: ([i]) => t.jsx(Xe, {
                            type: "submit",
                            loading: i,
                            disabled: !D,
                            children: t.jsx(h, u({}, l.createButton))
                        })
                    })]
                })]
            })
        })
    },
    l = Ae({
        createCustomAppModalTitle: {
            id: "createCustomConnectorModal.title",
            defaultMessage: "New App {betaBadge}"
        },
        createTemplateAppModalTitle: {
            id: "createCustomConnectorModal.createTemplateConnectorModalTitle",
            defaultMessage: "New {templateName} App {betaBadge}"
        },
        iconTitle: {
            id: "createCustomConnectorModal.iconTitle",
            defaultMessage: "Icon {optionalText}"
        },
        iconDescription: {
            id: "createCustomConnectorModal.iconDescription",
            defaultMessage: "Minimum size: 128 x 128 px"
        },
        nameTitle: {
            id: "createCustomConnectorModal.nameTitle",
            defaultMessage: "Name"
        },
        urlTitle: {
            id: "createCustomConnectorModal.urlTitle",
            defaultMessage: "MCP Server URL"
        },
        descriptionTitle: {
            id: "createCustomConnectorModal.descriptionTitle",
            defaultMessage: "Description {optionalText}"
        },
        optionalText: {
            id: "createCustomConnectorModal.optionalText",
            defaultMessage: "(optional)"
        },
        readTheGuideLink: {
            id: "createCustomConnectorModal.readTheGuideLink",
            defaultMessage: "Read the guide"
        },
        createButton: {
            id: "createCustomConnectorModal.createButton",
            defaultMessage: "Create"
        },
        iconPreviewAlt: {
            id: "createCustomConnectorModal.iconPreviewAlt",
            defaultMessage: "Icon preview"
        },
        namePlaceholder: {
            id: "createCustomConnectorModal.namePlaceholder",
            defaultMessage: "Custom Tool"
        },
        urlPlaceholder: {
            id: "createCustomConnectorModal.urlPlaceholder",
            defaultMessage: "https://example.com/sse"
        },
        descriptionPlaceholder: {
            id: "createCustomConnectorModal.descriptionPlaceholder",
            defaultMessage: "Explain what it does in a few words"
        },
        iconTooLarge: {
            id: "createCustomConnectorModal.iconTooLarge",
            defaultMessage: "Icon is too large"
        },
        iconInvalid: {
            id: "createCustomConnectorModal.iconInvalid",
            defaultMessage: "Invalid icon"
        },
        authTypeTitle: {
            id: "createCustomConnectorModal.authTypeTitle",
            defaultMessage: "Authentication"
        },
        oauthOption: {
            id: "createCustomConnectorModal.oauthOption",
            defaultMessage: "OAuth"
        },
        noAuthOption: {
            id: "createCustomConnectorModal.noAuthOption",
            defaultMessage: "No Auth"
        },
        mixedAuthOption: {
            id: "createCustomConnectorModal.mixedAuthOption",
            defaultMessage: "Mixed"
        },
        oauthConfigError: {
            id: "createCustomConnectorModal.oauthConfigError",
            defaultMessage: "Error fetching OAuth configuration"
        },
        customConnectorRiskBanner: {
            id: "createCustomConnectorModal.customConnectorRiskBanner",
            defaultMessage: "Custom MCP servers introduce risk. <link>Learn more</link>"
        },
        acceptLabelTitle: {
            id: "createCustomConnectorModal.acceptLabelTitle",
            defaultMessage: "I understand and want to continue"
        },
        customConnectorRiskSubtitle: {
            id: "createCustomConnectorModal.customConnectorRiskSubtitle",
            defaultMessage: "OpenAI hasn't reviewed this MCP server. Attackers may attempt to steal your data or trick the model into taking unintended actions, including destroying data."
        },
        conformanceError: {
            id: "createCustomConnectorModal.conformanceError",
            defaultMessage: "This MCP server doesn't implement <link>our specification</link>"
        },
        developerModeConformanceError: {
            id: "createCustomConnectorModal.developerModeConformanceError",
            defaultMessage: "This MCP server doesn't implement <link>our specification</link>. Enable Developer Mode in Advanced Connector Settings to create custom connectors that support arbitrary tool calls"
        },
        createConnectorError: {
            id: "createCustomConnectorModal.createConnectorError",
            defaultMessage: "Error creating connector"
        },
        duplicateName: {
            id: "createCustomConnectorModal.duplicateName",
            defaultMessage: "Connector name already exists"
        },
        clientIdTitle: {
            id: "createCustomConnectorModal.clientIdTitle",
            defaultMessage: "OAuth client ID"
        },
        oauthClientIdRequiredPlaceholder: {
            id: "createCustomConnectorModal.oauthClientIdRequiredPlaceholder",
            defaultMessage: "OAuth Client ID"
        },
        oauthClientIdPlaceholder: {
            id: "createCustomConnectorModal.oauthClientIdPlaceholder",
            defaultMessage: "OAuth Client ID (Optional)"
        },
        clientSecretTitle: {
            id: "createCustomConnectorModal.clientSecretTitle",
            defaultMessage: "OAuth client secret"
        },
        oauthClientSecretPlaceholder: {
            id: "createCustomConnectorModal.oauthClientSecretPlaceholder",
            defaultMessage: "OAuth Client Secret (Optional)"
        },
        advancedSettings: {
            id: "createCustomConnectorModal.advancedSettings",
            defaultMessage: "Advanced settings"
        },
        clientIdRequired: {
            id: "createCustomConnectorModal.clientIdRequired",
            defaultMessage: "Enter a client ID or remove the client secret"
        },
        databricksTemplateExplanation: {
            id: "createCustomConnectorModal.databricksTemplateExplanation",
            defaultMessage: "Databricks is a platform for data engineering and machine learning. Their MCP server is subdomain specific, so to connect to your own Databricks instance, you need to provide the MCP URL. <link>Learn more</link>"
        },
        snowflakeTemplateExplanation: {
            id: "createCustomConnectorModal.snowflakeTemplateExplanation",
            defaultMessage: "Snowflake is a platform for data warehousing and analytics. Their MCP server is subdomain specific, so to connect to your own Snowflake instance, you need to provide the MCP URL. Snowflake could also require you to update the requested scopes in the URL in some cases. <link>Learn more</link>"
        }
    });
export {
    bt as A, Wt as C, ve as M, Ut as a, ht as b, y as m, xt as r, Ft as u
};
//# sourceMappingURL=newet32g44ysnvsb.js.map