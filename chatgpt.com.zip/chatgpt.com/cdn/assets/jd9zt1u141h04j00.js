var q = Object.defineProperty,
    X = Object.defineProperties;
var Z = Object.getOwnPropertyDescriptors;
var T = Object.getOwnPropertySymbols;
var Y = Object.prototype.hasOwnProperty,
    B = Object.prototype.propertyIsEnumerable;
var A = (n, o, s) => o in n ? q(n, o, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : n[o] = s,
    N = (n, o) => {
        for (var s in o || (o = {})) Y.call(o, s) && A(n, s, o[s]);
        if (T)
            for (var s of T(o)) B.call(o, s) && A(n, s, o[s]);
        return n
    },
    w = (n, o) => X(n, Z(o));
var V = (n, o) => {
    var s = {};
    for (var u in n) Y.call(n, u) && o.indexOf(u) < 0 && (s[u] = n[u]);
    if (n != null && T)
        for (var u of T(n)) o.indexOf(u) < 0 && B.call(n, u) && (s[u] = n[u]);
    return s
};
import {
    uQ as v,
    uR as P,
    mw as M,
    u7 as S,
    u8 as I,
    uS as y,
    uT as x,
    uU as U,
    uV as O,
    uW as D,
    _ as L,
    L as a,
    qI as f,
    P as b,
    ad as k,
    V as Q,
    a9 as J,
    h8 as ee,
    b$ as G,
    im as te,
    sA as K
} from "./dykg4ktvbu3mhmdo.js";
import {
    mZ as r,
    is as e,
    kt as t,
    m_ as ne,
    ir as $,
    m$ as re,
    n0 as se,
    kq as H
} from "./k15yxxoybkkir2ou.js";
import {
    r as W,
    f as oe,
    j as ae
} from "./fg33krlcm0qyi6yw.js";
const C = "free",
    m = "go",
    _ = "plus",
    h = "pro",
    c = "team";
r(C, v, e.Month, "0.00", t.Inclusive), r(m, v, e.Month, "4.00", t.Inclusive), r(_, v, e.Month, "23.00", t.Inclusive), r(h, v, e.Month, "229.00", t.Inclusive), r(c, v, e.Month, "34.00", t.Inclusive), r(c, v, e.Year, "29.00", t.Inclusive), r(C, P, e.Month, "0.00", t.Inclusive), r(m, P, e.Month, "3.50", t.Inclusive), r(_, P, e.Month, "20.00", t.Inclusive), r(h, P, e.Month, "200.00", t.Inclusive), r(c, P, e.Month, "30.00", t.Inclusive), r(c, P, e.Year, "25.00", t.Inclusive), r(C, M, e.Month, "0.00", t.Exclusive), r(m, M, e.Month, "4.00", t.Exclusive), r(_, M, e.Month, "20.00", t.Exclusive), r(h, M, e.Month, "200.00", t.Exclusive), r(c, M, e.Month, "30.00", t.Exclusive), r(c, M, e.Year, "25.00", t.Exclusive), r(C, S, e.Month, "0.00", t.Inclusive), r(m, S, e.Month, "399.00", t.Inclusive), r(_, S, e.Month, "1999.00", t.Inclusive), r(h, S, e.Month, "19900.00", t.Inclusive), r(c, S, e.Month, "2599.00", t.Exclusive), r(c, S, e.Year, "2099.00", t.Exclusive), r(C, I, e.Month, "0.00", t.Inclusive), r(m, I, e.Month, "75000.00", t.Inclusive), r(_, I, e.Month, "349000.00", t.Inclusive), r(h, I, e.Month, "3499000.00", t.Inclusive), r(c, I, e.Month, "469000.00", t.Exclusive), r(c, I, e.Year, "389000.00", t.Exclusive), r(C, y, e.Month, "0.00", t.Inclusive), r(m, y, e.Month, "1400.00", t.Inclusive), r(_, y, e.Month, "5700.00", t.Inclusive), r(h, y, e.Month, "49900.00", t.Inclusive), r(c, y, e.Month, "8499.00", t.Exclusive), r(c, y, e.Year, "6999.00", t.Exclusive), r(C, x, e.Month, "0.00", t.Inclusive), r(m, x, e.Month, "259.00", t.Inclusive), r(_, x, e.Month, "699.00", t.Inclusive), r(h, x, e.Month, "6999.00", t.Inclusive), r(c, x, e.Month, "999.00", t.Exclusive), r(c, x, e.Year, "799.00", t.Exclusive), r(C, U, e.Month, "0.00", t.Inclusive), r(m, U, e.Month, "38.99", t.Inclusive), r(_, U, e.Month, "99.90", t.Inclusive), r(h, U, e.Month, "999.90", t.Inclusive), r(c, U, e.Month, "129.00", t.Exclusive), r(c, U, e.Year, "105.00", t.Exclusive), r(C, O, e.Month, "0.00", t.Inclusive), r(m, O, e.Month, "132000.00", t.Inclusive), r(_, O, e.Month, "522500.00", t.Inclusive), r(h, O, e.Month, "5225000.00", t.Inclusive), r(c, O, e.Month, "799000.00", t.Exclusive), r(c, O, e.Year, "649000.00", t.Exclusive), r(C, D, e.Month, "0.00", t.Inclusive), r(m, D, e.Month, "300.00", t.Inclusive), r(_, D, e.Month, "1100.00", t.Inclusive), r(h, D, e.Month, "9990.00", t.Inclusive), r(c, D, e.Month, "1699.00", t.Exclusive), r(c, D, e.Year, "1399.00", t.Exclusive);

function ue(n, o, s) {
    const u = re(n, s);
    if (!u) return null;
    const i = n,
        l = o.currency,
        {
            taxName: g,
            reverseChargeEligible: E,
            taxRatePercent: R
        } = u;
    return R == null ? {
        taxAmount: null,
        taxCurrency: l,
        taxCountry: i,
        taxName: g,
        reverseChargeEligible: E
    } : {
        taxAmount: se({
            amount: o.amount,
            taxPercent: R,
            inclusive: o.amountTaxBehavior === t.Inclusive
        }),
        taxCurrency: l,
        taxCountry: i,
        taxName: g,
        reverseChargeEligible: E
    }
}

function ie(n, o, s) {
    const u = $(n, o, s);
    if (u.amount == null || u.taxBehavior == null) {
        const i = new Error("Incomplete pricing details");
        throw L.addError(i, {
            planType: o,
            interval: s,
            countryCode: n.countryCode,
            currency: n.currencyConfig.symbol_code
        }), i
    }
    return {
        product: o,
        currency: n.currencyConfig.symbol_code,
        recurringInterval: s,
        amount: u.amount,
        amountTaxBehavior: u.taxBehavior === "inclusive" ? t.Inclusive : t.Exclusive
    }
}

function me(n, o, s) {
    const u = ne(o);
    if (!u) {
        const E = new Error("Unsupported plan type for pricing config");
        throw L.addError(E, {
            planType: o
        }), E
    }
    const i = u === "business" ? e.Year : e.Month,
        l = ie(n, u, i),
        g = s.country ? ue(s.country, l, n) : null;
    return {
        priceDetails: l,
        taxDetails: g
    }
}

function _e(n) {
    switch (n) {
        case a.GUEST:
            return f.GUEST;
        case a.FREE:
            return f.FREE;
        case a.GO:
            return f.GO;
        case a.PLUS:
            return f.PLUS;
        case a.PRO:
            return f.PRO;
        case a.SELF_SERVE_BUSINESS:
            return f.SELF_SERVE_BUSINESS;
        case a.ENTERPRISE_CBP:
            return f.ENTERPRISE_CBP_FLAT;
        case a.ENTERPRISE_HC:
            return f.ENTERPRISE_HC_FLAT;
        case a.EDUCATION_CBP:
            return f.EDUCATION_CBP_FLAT;
        case a.K12:
            return f.K12;
        case a.QUORUM:
            return f.QUORUM;
        case a.FREE_WORKSPACE:
            return f.FREE_WORKSPACE;
        case a.DEPRECATED_ENTERPRISE:
            return f.DEPRECATED_ENTERPRISE;
        case a.DEPRECATED_EDU:
            return f.DEPRECATED_EDU
    }
}

function he(n) {
    switch (n) {
        case a.GUEST:
            return 0;
        case a.FREE:
            return 1;
        case a.GO:
            return 2;
        case a.PLUS:
            return 3;
        case a.PRO:
            return 4;
        case a.SELF_SERVE_BUSINESS:
            return 5;
        case a.ENTERPRISE_CBP:
            return 6;
        case a.ENTERPRISE_HC:
            return 7;
        case a.FREE_WORKSPACE:
            return 5;
        default:
            return L.addError(new Error("Unsupported plan type", {
                cause: n
            })), -1
    }
}
const Re = () => {
    b.logEvent("Account Portal: Click Get Help")
};

function ce(n) {
    if (ee(n)) return "secondary";
    switch (n) {
        case a.GUEST:
        case a.FREE:
        case a.GO:
        case a.PLUS:
        case a.FREE_WORKSPACE:
            return "green";
        case a.SELF_SERVE_BUSINESS:
            return "primary";
        case a.PRO:
            return "primary";
        case a.QUORUM:
            return "primary";
        default:
            return "green"
    }
}

function pe(F) {
    var p = F,
        {
            isCurrentPlan: n = !1,
            planType: o,
            disabled: s,
            loading: u = !1,
            onClick: i,
            children: l,
            testId: g,
            activeColor: E
        } = p,
        R = V(p, ["isCurrentPlan", "planType", "disabled", "loading", "onClick", "children", "testId", "activeColor"]);
    return ae.jsx(J, w(N({
        fullWidth: !0,
        size: "large",
        color: n ? "secondary" : E || ce(o),
        disabled: s,
        loading: u,
        onClick: i,
        "data-testid": g,
        className: s ? "bg-token-sidebar-surface-tertiary text-token-text-primary hover:bg-token-sidebar-surface-tertiary dark:bg-token-text-tertiary border-none font-semibold" : "font-semibold"
    }, R), {
        children: l
    }))
}

function de(n, o) {
    const [s, u] = W.useState(!1);
    W.useEffect(() => {
        if (!s) {
            u(!0);
            return
        }
        n ? b.logEventWithStatsig("Email Verify Popup Shown", "chatgpt_email_verify_popup_shown", o) : b.logEventWithStatsig("Email Verify Popup Hidden", "chatgpt_email_verify_popup_hidden", o)
    }, [n])
}
const j = oe({
    claimFreeOffer: {
        id: "pricingColumn.freeTrial.claimFreeOffer",
        defaultMessage: "Claim free offer"
    },
    redeemFreeOffer: {
        id: "pricingColumn.freeTrial.redeemFreeOffer",
        defaultMessage: "Redeem free offer"
    }
});

function ve({
    ctx: n,
    isFreeTrialEligible: o
}) {
    if (!o) return null;
    const s = Q(n, "503993189").get("upgrade_cta_text", "");
    return s === "claim_free_offer" ? j.claimFreeOffer : s === "redeem_free_offer" ? j.redeemFreeOffer : null
}

function z({
    ctx: n,
    shouldLogExposure: o
}) {
    return Q(n, "2273762597", {
        disableExposureLog: !o
    })
}

function Pe({
    ctx: n,
    shouldLogExposure: o
}) {
    return z({
        ctx: n,
        shouldLogExposure: o
    }).get("web_plus_intro_offer_coupon", "none")
}

function Me({
    ctx: n,
    shouldLogExposure: o
}) {
    return z({
        ctx: n,
        shouldLogExposure: o
    }).get("is_plus_intro_offer_enabled", !1)
}

function Se({
    planType: n
}) {
    return n === a.PLUS ? k.getPlus : k.getPro
}

function le(n) {
    switch (n) {
        case a.PLUS:
            return "plus";
        case a.PRO:
            return "pro";
        case a.SELF_SERVE_BUSINESS:
            return "business";
        case a.FREE:
            return "free";
        case a.GO:
            return "go";
        case a.FREE_WORKSPACE:
            return "free_workspace";
        default:
            return "plus"
    }
}

function Ie(n, o, s, u, i, l) {
    const g = le(l);
    g === "plus" && l !== a.PLUS && G.error("Unsupported plan type for checkout pricing: ".concat(l));
    const R = $(i, g, e.Month).amount,
        F = te(u),
        p = R * o;
    let d;
    if ("percentage" in s) d = p * (1 - s.percentage / 100);
    else if ("value" in s) d = p - s.value;
    else throw new Error("Invalid discount type");
    return d < 0 && (G.warn("Discounted cost dropped below zero; clamping to zero.", {
        planType: l,
        regularCost: p,
        discount: s,
        discountedCost: d
    }), d = 0), {
        formattedDiscountedCost: n.formatNumber(d, {
            style: "currency",
            currency: u,
            minimumFractionDigits: 0,
            maximumFractionDigits: 2
        }),
        currencySymbol: F
    }
}

function ye(n, o, s, u) {
    const i = N({}, o);
    let l;
    if (u && (u.period === "year" ? u.num_periods === 1 ? l = n.formatMessage({
            id: "pricingPlanConstants.promoCostSubtitleForSingleYear",
            defaultMessage: "for the first year"
        }) : l = n.formatMessage({
            id: "pricingPlanConstants.promoCostSubtitleForPluralYears",
            defaultMessage: "for the first {num_years} years"
        }, {
            num_years: u.num_periods
        }) : u.num_periods === 1 ? l = n.formatMessage({
            id: "pricingPlanConstants.promoCostSubtitleForSingleMonth",
            defaultMessage: "for the first month"
        }) : l = n.formatMessage({
            id: "pricingPlanConstants.promoCostSubtitleForPluralMonths",
            defaultMessage: "for the first {num_months} months"
        }, {
            num_months: u.num_periods
        })), i.costDuration = {
            id: "promoCostDuration",
            defaultMessage: l,
            description: "Cost duration for promo plan"
        }, "percentage" in s || "discount_type" in s && s.discount_type === K.PERCENTAGE) {
        const E = (1 - ("percentage" in s ? s.percentage : s.amount) / 100) * i.costValue;
        i.costValue = E, i.costTitle = {
            id: "discountedCost",
            defaultMessage: H(E).toString()
        }
    } else if ("value" in s || s.discount_type === K.FIXED) {
        const g = "value" in s ? s.value : s.amount,
            E = Math.max(0, i.costValue - g);
        i.costValue = E, i.costTitle = {
            id: "discountedCost",
            defaultMessage: H(E).toString()
        }
    }
    return i
}
export {
    pe as S, he as a, _e as b, me as c, ye as d, Pe as e, ve as f, Ie as g, Re as h, Me as i, Se as j, de as u
};
//# sourceMappingURL=jd9zt1u141h04j00.js.map