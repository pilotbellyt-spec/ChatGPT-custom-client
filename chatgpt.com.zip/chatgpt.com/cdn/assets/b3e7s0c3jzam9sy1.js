var re = Object.freeze,
    ce = Object.defineProperty,
    Se = Object.defineProperties;
var Ce = Object.getOwnPropertyDescriptors;
var ne = Object.getOwnPropertySymbols;
var Ie = Object.prototype.hasOwnProperty,
    we = Object.prototype.propertyIsEnumerable;
var oe = (a, e, c) => e in a ? ce(a, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: c
    }) : a[e] = c,
    m = (a, e) => {
        for (var c in e || (e = {})) Ie.call(e, c) && oe(a, c, e[c]);
        if (ne)
            for (var c of ne(e)) we.call(e, c) && oe(a, c, e[c]);
        return a
    },
    J = (a, e) => Se(a, Ce(e));
var Z = (a, e) => re(ce(a, "raw", {
    value: re(e || a.slice())
}));
import {
    e as ae,
    j as t,
    M as h,
    f as ie,
    c as ye,
    i as Me,
    m as ve,
    r as U,
    L as ue,
    a0 as Ne
} from "./fg33krlcm0qyi6yw.js";
import {
    u as Be,
    L as Te
} from "./hvtbwt8zpnifppmo.js";
import {
    cg as me,
    ay as de,
    ch as fe,
    db as Ee,
    dc as Ae,
    e7 as Oe,
    hT as Le,
    ds as Fe,
    cH as Ge,
    V as Re,
    di as He
} from "./k15yxxoybkkir2ou.js";
import {
    E as We
} from "./jhvz2qkf3st8xisu.js";
import {
    C as Ue,
    M as ge,
    F as ke,
    a9 as Ve,
    o as qe,
    b as $e,
    V as ee,
    ac as ze,
    P as b,
    ck as De,
    b4 as he,
    cQ as Ke,
    l as Ye,
    R as Qe,
    A as Xe,
    cU as Je,
    B as K,
    t3 as Ze,
    c_ as et
} from "./dykg4ktvbu3mhmdo.js";
import {
    u as tt,
    T as st,
    t as te
} from "./n7nqkdn53j3o5j6k.js";
import {
    S as se
} from "./gbylonw1dsrig9gv.js";
import {
    i as at,
    C as it
} from "./nzsuppseubp10m1q.js";
import {
    A as xe
} from "./lfdsdf4it937c4a2.js";
const Q = ie({
        title: {
            id: "nonWorkEmailModal.title",
            defaultMessage: "Are you sure this is your work email?"
        },
        body: {
            id: "nonWorkEmailModal.body",
            defaultMessage: "You need to sign up with a work email to be eligible."
        },
        primaryCta: {
            id: "nonWorkEmailModal.primaryCta",
            defaultMessage: "Sign up with your work email"
        },
        secondaryCta: {
            id: "nonWorkEmailModal.secondaryCta",
            defaultMessage: "{email} is my work email"
        }
    }),
    lt = ({
        email: a,
        onUseWorkEmail: e,
        onContinue: c,
        onClose: s
    }) => {
        const o = ae();
        return t.jsx(Ue, {
            isOpen: !0,
            onClose: s,
            size: "custom",
            className: "max-w-sm",
            contentClassName: "p-0!",
            testId: "modal-non-work-email",
            children: t.jsxs("div", {
                className: "flex w-full flex-col gap-4 p-6 text-center",
                children: [t.jsx("div", {
                    className: "text-token-text-primary text-xl font-semibold",
                    children: t.jsx(h, m({}, Q.title))
                }), t.jsx("div", {
                    className: "text-token-text-secondary text-sm",
                    children: t.jsx(h, m({}, Q.body))
                }), t.jsx(ge.Button, {
                    title: o.formatMessage(Q.primaryCta),
                    color: "primary",
                    className: "w-full",
                    onClick: () => {
                        e(), s()
                    }
                }), t.jsx(ge.Button, {
                    title: o.formatMessage(Q.secondaryCta, {
                        email: a
                    }),
                    color: "ghost",
                    className: "w-full",
                    onClick: () => {
                        s(), c()
                    }
                })]
            })
        })
    },
    _ = ie({
        salesMarketingHeadline: {
            id: "businessPurchaseInterstitialPage.salesMarketingHeadline",
            defaultMessage: "From first touch to closed deal — powered by AI"
        },
        salesMarketingSubheadline: {
            id: "businessPurchaseInterstitialPage.salesMarketingSubheadline",
            defaultMessage: "Essential tools to win new customers"
        },
        salesMarketingBullet1: {
            id: "businessPurchaseInterstitialPage.salesMarketingBullet1",
            defaultMessage: "Unlimited creative for email, ads, & social"
        },
        salesMarketingBullet2: {
            id: "businessPurchaseInterstitialPage.salesMarketingBullet2",
            defaultMessage: "Connected CRM and Google Drive"
        },
        salesMarketingBullet3: {
            id: "businessPurchaseInterstitialPage.salesMarketingBullet3",
            defaultMessage: "Shared projects, campaigns, & pitches"
        },
        salesMarketingBullet4: {
            id: "businessPurchaseInterstitialPage.salesMarketingBullet4",
            defaultMessage: "Enterprise security — no training on your data"
        },
        valueTitleAlt4: {
            id: "businessPurchaseInterstitialPage.valueTitleAlt4",
            defaultMessage: "Help your team move faster with advanced AI"
        },
        valueSubtitleAlt: {
            id: "businessPurchaseInterstitialPage.valueSubtitleAlt",
            defaultMessage: "Top features"
        },
        altValue1_5: {
            id: "businessPurchaseInterstitialPage.altValue1_5",
            defaultMessage: "No training on your data; SAML security"
        },
        altValue2: {
            id: "businessPurchaseInterstitialPage.altValue2",
            defaultMessage: "Advanced access to our best model for work"
        },
        altValue3_5: {
            id: "businessPurchaseInterstitialPage.altValue3_5",
            defaultMessage: "Integrate with Google Drive & other tools"
        },
        altValue4_6: {
            id: "businessPurchaseInterstitialPage.altValue4_6",
            defaultMessage: "Easy member, role, & billing management"
        }
    });

function rt(a) {
    "use forget";
    const e = ye.c(70),
        {
            salesMarketingMessagingEnabled: c
        } = a,
        s = ae();
    if (c) {
        let A;
        e[0] !== s ? (A = s.formatMessage(_.salesMarketingHeadline), e[0] = s, e[1] = A) : A = e[1];
        let S;
        e[2] !== A ? (S = t.jsx("div", {
            className: "mb-10 max-w-[400px] text-start text-3xl font-semibold",
            children: A
        }), e[2] = A, e[3] = S) : S = e[3];
        let M;
        e[4] !== s ? (M = s.formatMessage(_.salesMarketingSubheadline), e[4] = s, e[5] = M) : M = e[5];
        let C;
        e[6] !== M ? (C = t.jsx("div", {
            className: "text-md mb-4 self-start font-medium",
            children: M
        }), e[6] = M, e[7] = C) : C = e[7];
        let I;
        e[8] === Symbol.for("react.memo_cache_sentinel") ? (I = t.jsx(me, {
            className: "mt-1 h-5 w-5 fill-[#5856D6]"
        }), e[8] = I) : I = e[8];
        let f;
        e[9] !== s ? (f = s.formatMessage(_.salesMarketingBullet1), e[9] = s, e[10] = f) : f = e[10];
        let g;
        e[11] !== f ? (g = t.jsxs("div", {
            className: "mb-3 flex items-start gap-3 self-start",
            children: [I, t.jsx("div", {
                className: "text-[16px] font-normal",
                children: f
            })]
        }), e[11] = f, e[12] = g) : g = e[12];
        let W;
        e[13] === Symbol.for("react.memo_cache_sentinel") ? (W = t.jsx(xe, {
            className: "mt-1 h-5 w-5 fill-[#5856D6]"
        }), e[13] = W) : W = e[13];
        let w;
        e[14] !== s ? (w = s.formatMessage(_.salesMarketingBullet2), e[14] = s, e[15] = w) : w = e[15];
        let O;
        e[16] !== w ? (O = t.jsxs("div", {
            className: "mb-3 flex items-start gap-3 self-start",
            children: [W, t.jsx("div", {
                className: "text-[16px] font-normal",
                children: w
            })]
        }), e[16] = w, e[17] = O) : O = e[17];
        let $;
        e[18] === Symbol.for("react.memo_cache_sentinel") ? ($ = t.jsx(de, {
            className: "mt-1 h-5 w-5 fill-[#5856D6]"
        }), e[18] = $) : $ = e[18];
        let p;
        e[19] !== s ? (p = s.formatMessage(_.salesMarketingBullet3), e[19] = s, e[20] = p) : p = e[20];
        let L;
        e[21] !== p ? (L = t.jsxs("div", {
            className: "mb-3 flex items-start gap-3 self-start",
            children: [$, t.jsx("div", {
                className: "text-[16px] font-normal",
                children: p
            })]
        }), e[21] = p, e[22] = L) : L = e[22];
        let z;
        e[23] === Symbol.for("react.memo_cache_sentinel") ? (z = t.jsx(fe, {
            className: "mt-1 h-5 w-5 fill-[#5856D6]"
        }), e[23] = z) : z = e[23];
        let F;
        e[24] !== s ? (F = s.formatMessage(_.salesMarketingBullet4), e[24] = s, e[25] = F) : F = e[25];
        let G;
        e[26] !== F ? (G = t.jsxs("div", {
            className: "mb-3 flex items-start gap-3 self-start",
            children: [z, t.jsx("div", {
                className: "text-[16px] font-normal",
                children: F
            })]
        }), e[26] = F, e[27] = G) : G = e[27];
        let D;
        return e[28] !== O || e[29] !== L || e[30] !== G || e[31] !== S || e[32] !== C || e[33] !== g ? (D = t.jsxs("div", {
            className: "relative z-10",
            children: [S, C, g, O, L, G]
        }), e[28] = O, e[29] = L, e[30] = G, e[31] = S, e[32] = C, e[33] = g, e[34] = D) : D = e[34], D
    }
    let o;
    e[35] !== s ? (o = s.formatMessage(_.valueTitleAlt4), e[35] = s, e[36] = o) : o = e[36];
    let P;
    e[37] !== o ? (P = t.jsx("div", {
        className: "mb-10 max-w-[400px] text-start text-3xl font-semibold",
        children: o
    }), e[37] = o, e[38] = P) : P = e[38];
    let v;
    e[39] !== s ? (v = s.formatMessage(_.valueSubtitleAlt), e[39] = s, e[40] = v) : v = e[40];
    let k;
    e[41] !== v ? (k = t.jsx("div", {
        className: "text-md mb-4 self-start font-medium",
        children: v
    }), e[41] = v, e[42] = k) : k = e[42];
    let H;
    e[43] === Symbol.for("react.memo_cache_sentinel") ? (H = t.jsx(fe, {
        className: "mt-1 h-5 w-5 fill-[#5856D6]"
    }), e[43] = H) : H = e[43];
    let N;
    e[44] !== s ? (N = s.formatMessage(_.altValue1_5), e[44] = s, e[45] = N) : N = e[45];
    let B;
    e[46] !== N ? (B = t.jsxs("div", {
        className: "mb-3 flex items-start gap-3 self-start",
        children: [H, t.jsx("div", {
            className: "text-[16px] font-normal",
            children: N
        })]
    }), e[46] = N, e[47] = B) : B = e[47];
    let y;
    e[48] === Symbol.for("react.memo_cache_sentinel") ? (y = t.jsx(me, {
        className: "mt-1 h-5 w-5 fill-[#5856D6]"
    }), e[48] = y) : y = e[48];
    let T;
    e[49] !== s ? (T = s.formatMessage(_.altValue2), e[49] = s, e[50] = T) : T = e[50];
    let E;
    e[51] !== T ? (E = t.jsxs("div", {
        className: "mb-3 flex items-start gap-3 self-start",
        children: [y, t.jsx("div", {
            className: "text-[16px] font-normal",
            children: T
        })]
    }), e[51] = T, e[52] = E) : E = e[52];
    let V;
    e[53] === Symbol.for("react.memo_cache_sentinel") ? (V = t.jsx(xe, {
        className: "mt-1 h-5 w-5 fill-[#5856D6]"
    }), e[53] = V) : V = e[53];
    let j;
    e[54] !== s ? (j = s.formatMessage(_.altValue3_5), e[54] = s, e[55] = j) : j = e[55];
    let d;
    e[56] !== j ? (d = t.jsxs("div", {
        className: "mb-3 flex items-start gap-3 self-start",
        children: [V, t.jsx("div", {
            className: "text-[16px] font-normal",
            children: j
        })]
    }), e[56] = j, e[57] = d) : d = e[57];
    let l;
    e[58] === Symbol.for("react.memo_cache_sentinel") ? (l = t.jsx(de, {
        className: "mt-1 h-5 w-5 fill-[#5856D6]"
    }), e[58] = l) : l = e[58];
    let x;
    e[59] !== s ? (x = s.formatMessage(_.altValue4_6), e[59] = s, e[60] = x) : x = e[60];
    let u;
    e[61] !== x ? (u = t.jsxs("div", {
        className: "mb-3 flex items-start gap-3 self-start",
        children: [l, t.jsx("div", {
            className: "text-[16px] font-normal",
            children: x
        })]
    }), e[61] = x, e[62] = u) : u = e[62];
    let q;
    return e[63] !== E || e[64] !== d || e[65] !== u || e[66] !== P || e[67] !== k || e[68] !== B ? (q = t.jsxs("div", {
        className: "relative z-10",
        children: [P, k, B, E, d, u]
    }), e[63] = E, e[64] = d, e[65] = u, e[66] = P, e[67] = k, e[68] = B, e[69] = q) : q = e[69], q
}
const n = ie({
        altTitle: {
            id: "businessPurchaseInterstitialPage.altTitle",
            defaultMessage: "ChatGPT Business"
        },
        altFreeTrialSubtitle: {
            id: "businessPurchaseInterstitialPage.altFreeTrialSubtitle",
            defaultMessage: "Free 30-day trial"
        },
        loginOrSignupHeading: {
            id: "businessPurchaseInterstitialPage.loginOrSignupHeading",
            defaultMessage: "Log in or sign up"
        },
        email: {
            id: "businessPurchaseInterstitialPage.email",
            defaultMessage: "Continue with Email"
        },
        alreadyHaveAccount: {
            id: "businessPurchaseInterstitialPage.alreadyHaveAccount",
            defaultMessage: "<content>Already have an account?</content> <login>Log in</login>"
        },
        createAccountCta: {
            id: "businessPurchaseInterstitialPage.createAccountCta",
            defaultMessage: "Create a personal account instead"
        },
        termsOfUse: {
            id: "businessPurchaseInterstitialPage.termsOfUse",
            defaultMessage: "Terms of Use"
        },
        privacyPolicy: {
            id: "businessPurchaseInterstitialPage.privacyPolicy",
            defaultMessage: "Privacy Policy"
        },
        placeholder: {
            id: "businessPurchaseInterstitialPage.emailInputPlaceholder",
            defaultMessage: "Email address"
        },
        logoGardenTitle: {
            id: "businessPurchaseInterstitialPage.logoGardenTitle",
            defaultMessage: "Trusted by thousands of teams like"
        },
        emailRequiredError: {
            id: "businessPurchaseInterstitialPage.errors.emailRequired",
            defaultMessage: "Email is required"
        },
        emailInvalidError: {
            id: "businessPurchaseInterstitialPage.errors.emailInvalid",
            defaultMessage: "Email is invalid."
        },
        getButton: {
            id: "businessPurchaseInterstitialPage.getButton",
            defaultMessage: "Get Business"
        },
        tryButton: {
            id: "businessPurchaseInterstitialPage.tryButton",
            defaultMessage: "Try it for free"
        },
        redeemOneDollarOfferButton: {
            id: "businessPurchaseInterstitialPage.redeemOneDollarOfferButton",
            defaultMessage: "Redeem {amount} offer"
        },
        claimOneDollarOfferButton: {
            id: "businessPurchaseInterstitialPage.claimOneDollarOfferButton",
            defaultMessage: "Claim {amount} offer"
        },
        redeemFreeOfferButton: {
            id: "businessPurchaseInterstitialPage.redeemFreeOfferButton",
            defaultMessage: "Redeem free offer"
        },
        claimFreeOfferButton: {
            id: "businessPurchaseInterstitialPage.claimFreeOfferButton",
            defaultMessage: "Claim free offer"
        },
        redeemOfferButton: {
            id: "businessPurchaseInterstitialPage.redeemOfferButton",
            defaultMessage: "Redeem offer"
        },
        claimOfferButton: {
            id: "businessPurchaseInterstitialPage.claimOfferButton",
            defaultMessage: "Claim offer"
        },
        tryOneDollarButton1: {
            id: "businessPurchaseInterstitialPage.tryOneDollarButton1",
            defaultMessage: "Try it for {amount}"
        },
        or: {
            id: "businessPurchaseInterstitialPage.or",
            defaultMessage: "OR"
        },
        altFreeTrialSubtitleOneDollar1: {
            id: "businessPurchaseInterstitialPage.altFreeTrialSubtitleOneDollar1",
            defaultMessage: "Get started for {amount}"
        },
        homeButtonAriaLabel: {
            id: "createAccount.businessHomeButtonAriaLabel",
            defaultMessage: "Click here to go to the home page"
        },
        logoGardenAlt: {
            id: "businessPurchaseInterstitialPage.logoGardenAlt",
            defaultMessage: "Logos of companies using ChatGPT Business"
        },
        claimSubtitle: {
            id: "businessPurchaseInterstitialPage.claimSubtitle",
            defaultMessage: "Enter your work email to claim your offer"
        },
        loggedOutToast: {
            id: "businessPurchaseInterstitialPage.logout_email_hint_toast",
            defaultMessage: "Logged out of {email}"
        },
        claimFreeTrial: {
            id: "businessPurchaseInterstitialPage.claimFreeTrial",
            defaultMessage: "Claim free trial"
        },
        emailClaimTrialPlaceholder: {
            id: "businessPurchaseInterstitialPage.emailClaimTrialPlaceholder",
            defaultMessage: "Work email"
        },
        useWorkEmailError: {
            id: "businessPurchaseInterstitialPage.useWorkEmailError",
            defaultMessage: "Use your work email"
        }
    }),
    nt = "https://openai.com/policies/terms-of-use",
    ot = "https://openai.com/policies/privacy-policy";
var _e;
const pe = ke(Ve)(_e || (_e = Z(["w-full p-3"])));
var Pe;
const ct = ke.div(Pe || (Pe = Z(["flex h-[1px] w-full border-b border-token-surface-tertiary"]))),
    ut = () => {
        const a = ae(),
            {
                country: e
            } = Ee(),
            c = Ae({
                country: e,
                currentAccount: null,
                location: "TeamPurchaseInterstitialPage"
            }),
            s = Me(),
            o = $e(),
            P = ve(),
            k = U.useMemo(() => {
                const R = new URLSearchParams(P.search).get("segment");
                return at(R) ? R : null
            }, [P.search]) != null,
            {
                data: H,
                isLoading: N,
                error: B
            } = Oe({
                ctx: o,
                countryCode: c == null ? void 0 : c.country,
                currency: c == null ? void 0 : c.currency,
                enabled: c != null
            }),
            y = qe(o, "2189411909"),
            T = k && ee(o, "3300867660").get("enable_sales_marketing_copy", !1),
            E = ze().isBusinessIp2 === !0,
            V = ee(o, "2667897829"),
            j = E && V.get("enabled_business_ip_targeting", !1),
            d = tt(),
            {
                data: l
            } = Le(d != null ? d : "", !!d);
        let x = !1;
        U.useEffect(() => {
            var r;
            if (!window || !document) return;
            const R = (r = new URLSearchParams(window.location.search).get("referrer")) != null ? r : document.referrer;
            b.logEventWithStatsig("ChatGPT Business: Interstitial Impression", "chatgpt_business_interstitial_impression", {
                referrer: R
            })
        }, []), U.useEffect(() => {
            y && b.logEventWithStatsig("ChatGPT Business: Interstitial Show Login Hint", "chatgpt_business_interstitial_show_login_hint", {
                promo_state: l == null ? void 0 : l.state
            }), x && b.logEventWithStatsig("ChatGPT Business: Interstitial Promo Banner Shown", "chatgpt_business_interstitial_promo_banner_shown", {
                promo_state: l == null ? void 0 : l.state
            })
        }, [y, l == null ? void 0 : l.state, x]);
        const [u, q] = U.useState(""), [A, S] = U.useState(void 0), M = "".concat(it).concat(P.search), C = De(o), I = Be(), f = !!I;
        if (U.useEffect(() => {
                I && C.info(a.formatMessage(n.loggedOutToast, {
                    email: I
                }), {
                    id: "businessPurchaseInterstitialPage.logout_email_hint_toast"
                })
            }, [a, I, C]), !c || N || B != null || !H) return null;
        const g = !!d && d === st && H.currencyConfig.promos.business_free_trial.enabled,
            W = g && (l == null ? void 0 : l.state) === "not_eligible",
            w = g && (l == null ? void 0 : l.state) === "temporary_disabled",
            O = g && (l == null ? void 0 : l.state) === "offline";
        x = g && (l == null ? void 0 : l.state) === "eligible";
        const $ = i => {
                if (!i || i.trim() === "") return a.formatMessage(n.emailRequiredError);
                if (!Re.test(i)) return a.formatMessage(n.emailInvalidError)
            },
            p = async i => {
                if (i === "password") {
                    b.logEventWithStatsig("ChatGPT Business: Interstitial Continue With Email Click", "chatgpt_business_interstitial_continue_with_email_click", {
                        promo_state: l == null ? void 0 : l.state
                    });
                    const R = $(u);
                    if (S(R), y && R) {
                        b.logEventWithStatsig("ChatGPT Business: Interstitial Email Validation Error", "chatgpt_business_interstitial_email_validation_error");
                        return
                    }
                    let r;
                    if (y && u && (r = {
                            screen_hint: "login_or_signup",
                            login_hint: u
                        }), f && u) try {
                        const Y = await Qe.safePost("/accounts/domain-type", {
                                requestBody: {
                                    email: u
                                },
                                authOption: Xe.SendIfAvailable
                            }),
                            le = Y == null ? void 0 : Y.domain_type;
                        if (le && le !== "professional") {
                            Je(o, lt, {
                                email: u,
                                onUseWorkEmail: () => S(a.formatMessage(n.useWorkEmailError)),
                                onContinue: () => {
                                    let X;
                                    y && u && (X = {
                                        screen_hint: "login_or_signup",
                                        login_hint: u
                                    }), K(o, J(m({
                                        fallbackScreenHint: "login_or_signup",
                                        useFallbackScreenHint: !0
                                    }, X ? {
                                        additionalAuthParams: X
                                    } : {}), {
                                        callbackUrl: M
                                    }))
                                }
                            });
                            return
                        }
                    } catch (Y) {}
                    b.logEventWithStatsig("ChatGPT Business: Interstitial Email Signup Navigated To Auth", "chatgpt_business_interstitial_email_signup_navigated_to_auth", {
                        promo_state: l == null ? void 0 : l.state
                    }), K(o, J(m({
                        fallbackScreenHint: "login_or_signup",
                        useFallbackScreenHint: !0
                    }, r ? {
                        additionalAuthParams: r
                    } : {}), {
                        callbackUrl: M
                    }));
                    return
                }
                b.logEventWithStatsig("ChatGPT Business: Interstitial Continue With Social Click", "chatgpt_business_interstitial_continue_with_social_click", {
                    connection: i
                }), K(o, {
                    fallbackScreenHint: "login",
                    useFallbackScreenHint: !0,
                    additionalAuthParams: {
                        connection: Ze[i]
                    },
                    callbackUrl: M
                })
            },
            L = () => {
                b.logEventWithStatsig("ChatGPT Business: Interstitial Already Have Account Click", "chatgpt_business_interstitial_already_have_account_click"), K(o, {
                    fallbackScreenHint: "login_or_signup",
                    callbackUrl: M,
                    skipLoginModal: !0
                })
            },
            z = () => {
                b.logEventWithStatsig("ChatGPT Business: Interstitial Create Personal Account Click", "chatgpt_business_interstitial_create_personal_account_click"), K(o, {
                    fallbackScreenHint: "signup",
                    useFallbackScreenHint: !0,
                    callbackUrl: "/"
                })
            },
            F = () => {
                "use forget";
                const i = ye.c(5);
                switch (ee(o, "3099523586").get("treatment", "control")) {
                    case "redeem_free_offer":
                        {
                            let r;
                            return i[0] === Symbol.for("react.memo_cache_sentinel") ? (r = t.jsx(h, m({}, n.redeemFreeOfferButton)), i[0] = r) : r = i[0],
                            r
                        }
                    case "claim_free_offer":
                        {
                            let r;
                            return i[1] === Symbol.for("react.memo_cache_sentinel") ? (r = t.jsx(h, m({}, n.claimFreeOfferButton)), i[1] = r) : r = i[1],
                            r
                        }
                    case "redeem_offer":
                        {
                            let r;
                            return i[2] === Symbol.for("react.memo_cache_sentinel") ? (r = t.jsx(h, m({}, n.redeemOfferButton)), i[2] = r) : r = i[2],
                            r
                        }
                    case "claim_offer":
                        {
                            let r;
                            return i[3] === Symbol.for("react.memo_cache_sentinel") ? (r = t.jsx(h, m({}, n.claimOfferButton)), i[3] = r) : r = i[3],
                            r
                        }
                    default:
                        {
                            let r;
                            return i[4] === Symbol.for("react.memo_cache_sentinel") ? (r = t.jsx(h, m({}, n.tryButton)), i[4] = r) : r = i[4],
                            r
                        }
                }
            },
            G = t.jsxs(t.Fragment, {
                children: [y ? t.jsxs("form", {
                    onSubmit: i => {
                        i.preventDefault(), p("password")
                    },
                    className: "flex w-full flex-col gap-3",
                    children: [t.jsx(Fe, {
                        name: "email",
                        value: u,
                        onChange: i => q(i.target.value),
                        inputClassName: "w-full rounded-full dark:bg-transparent! bg-gray-solid-75!  text-base! sm:text-base! py-3! px-5!",
                        error: A,
                        showErrorIcon: !0,
                        ariaLabel: a.formatMessage(f ? n.emailClaimTrialPlaceholder : n.placeholder),
                        placeholder: a.formatMessage(f ? n.emailClaimTrialPlaceholder : n.placeholder),
                        className: "rounded-full! border-[var(--border-heavy)] p-0! px-0! py-0! focus-within:ring-1"
                    }), t.jsx(pe, {
                        type: "submit",
                        children: x ? t.jsx(t.Fragment, {
                            children: g && t.jsx(F, {})
                        }) : t.jsx(h, m({}, f ? n.claimFreeTrial : n.getButton))
                    })]
                }) : t.jsx(pe, {
                    icon: We,
                    color: "secondary",
                    onClick: () => p("password"),
                    children: a.formatMessage(n.email)
                }), j ? t.jsx("div", {
                    className: "py-1.5",
                    children: t.jsx(he, {
                        onClick: z,
                        underline: !1,
                        className: "text-token-text-primary text-sm font-normal hover:underline",
                        children: t.jsx(h, m({}, n.createAccountCta))
                    })
                }) : t.jsx("div", {
                    className: "flex cursor-pointer items-center gap-1 py-1.5",
                    children: a.formatMessage(n.alreadyHaveAccount, {
                        content: i => t.jsx("span", {
                            className: "text-token-text-secondary",
                            children: i
                        }),
                        login: i => t.jsx(he, {
                            onClick: L,
                            className: "text-token-text-primary font-medium no-underline hover:underline",
                            children: i
                        })
                    })
                })]
            }),
            D = t.jsxs(t.Fragment, {
                children: [t.jsx(se, {
                    provider: "google",
                    className: "w-full p-3",
                    onClick: () => p("google")
                }), t.jsx(se, {
                    provider: "microsoft",
                    className: "w-full p-3",
                    onClick: () => p("microsoft")
                }), t.jsx(se, {
                    provider: "apple",
                    className: "w-full p-3",
                    onClick: () => p("apple")
                })]
            }),
            je = t.jsxs("div", {
                className: "relative my-6 w-full",
                children: [t.jsx(ct, {}), t.jsx("span", {
                    className: "bg-token-bg-primary text-token-text-secondary absolute start-1/2 -top-2 -translate-x-1/2 transform px-2 text-xs font-medium",
                    children: t.jsx(h, m({}, n.or))
                })]
            });
        return t.jsxs("div", {
            className: "flex h-full w-full gap-8",
            children: [t.jsxs("div", {
                className: "flex min-w-[320px] flex-1 flex-col items-center p-9 px-4",
                children: [t.jsxs("div", {
                    className: "flex w-full max-w-[360px] grow flex-col items-center justify-center gap-3",
                    children: [t.jsx("button", {
                        onClick: () => {
                            b.logEventWithStatsig("ChatGPT Business: Interstitial Logo Click", "chatgpt_business_interstitial_logo_click"), s("/")
                        },
                        className: "mb-6 cursor-pointer p-0 md:fixed md:start-4 md:top-4 md:h-6 md:w-6",
                        "aria-label": a.formatMessage(n.homeButtonAriaLabel),
                        children: t.jsx(Ke, {
                            className: "h-8 w-8"
                        })
                    }), t.jsx("div", {
                        className: "text-token-text-secondary text-center text-lg font-medium",
                        children: x && g && a.formatMessage(n.altFreeTrialSubtitle)
                    }), j && t.jsx("div", {
                        className: "text-token-text-secondary text-center font-sans text-base leading-snug font-medium tracking-tight",
                        children: t.jsx(h, m({}, n.loginOrSignupHeading))
                    }), t.jsx("div", {
                        className: Ye("text-center text-2xl font-semibold md:text-3xl", f ? "mb-1" : "mb-5"),
                        children: t.jsx(h, m({}, n.altTitle))
                    }), f && t.jsx("div", {
                        className: "text-token-text-secondary mb-5 text-center font-sans text-base leading-snug font-medium tracking-tight",
                        children: t.jsx(h, m({}, n.claimSubtitle))
                    }), G, je, D, (W || w || O) && (() => {
                        let i;
                        switch (!0) {
                            case W:
                                i = te.teamFreeTrialNotEligible;
                                break;
                            case w:
                                i = te.teamFreeTrialTemporarilyDisabled;
                                break;
                            default:
                                i = te.teamFreeTrialOffline
                        }
                        return t.jsx("div", {
                            className: "mb-4 w-full",
                            "data-testid": "promo-banner",
                            children: t.jsx(Ge, {
                                content: a.formatMessage(i),
                                type: "normal"
                            })
                        })
                    })()]
                }), t.jsxs("div", {
                    className: "text-token-text-secondary flex h-8 items-center gap-2 text-sm font-medium",
                    children: [t.jsx(ue, {
                        target: "_blank",
                        to: nt,
                        onClick: () => b.logEventWithStatsig("ChatGPT Business: Interstitial Terms of Use Click", "chatgpt_business_interstitial_terms_of_use_click"),
                        children: a.formatMessage(n.termsOfUse)
                    }), t.jsx("div", {
                        className: "border-token-text-primary mx-2 h-[18px] border-s"
                    }), t.jsx(ue, {
                        target: "_blank",
                        to: ot,
                        onClick: () => b.logEventWithStatsig("ChatGPT Business: Interstitial Privacy Policy Click", "chatgpt_business_interstitial_privacy_policy_click"),
                        children: a.formatMessage(n.privacyPolicy)
                    })]
                })]
            }), t.jsxs("div", {
                className: "hidden min-h-[560px] flex-col overflow-y-auto bg-white text-gray-950 md:relative md:flex md:h-full md:flex-1 md:items-center md:justify-between md:p-4 dark:bg-white",
                children: [t.jsxs("div", {
                    className: "flex w-full grow flex-col md:mt-16 md:items-center md:justify-center",
                    children: [t.jsx(rt, {
                        salesMarketingMessagingEnabled: T
                    }), t.jsx("img", {
                        alt: "",
                        src: "https://cdn.openai.com/chatgpt/team-interstitial-background.png",
                        className: "absolute inset-x-0 -top-[140px] z-0 h-full w-full object-fill object-top"
                    })]
                }), t.jsxs("div", {
                    className: "relative flex flex-col items-center",
                    children: [t.jsx("div", {
                        className: "relative top-[10px] text-center text-[12px] font-medium text-gray-600",
                        children: a.formatMessage(n.logoGardenTitle)
                    }), t.jsx("img", {
                        alt: a.formatMessage(n.logoGardenAlt),
                        src: Te.src,
                        className: "mt-1 h-auto w-7/8 max-w-[1040px] object-contain"
                    })]
                })]
            })]
        })
    },
    be = "/team-sign-up",
    yt = () => {
        const a = ve(),
            e = He(a),
            s = !et() && e,
            o = Me();
        U.useEffect(() => {
            if (s) {
                const v = new URLSearchParams(a.search).toString(),
                    k = v ? be + "?".concat(v) : be;
                o(k, {
                    replace: !0
                })
            }
        }, [a.search, o, s])
    },
    Mt = Ne(function() {
        return t.jsx(ut, {})
    });
export {
    Mt as t, yt as u
};
//# sourceMappingURL=b3e7s0c3jzam9sy1.js.map