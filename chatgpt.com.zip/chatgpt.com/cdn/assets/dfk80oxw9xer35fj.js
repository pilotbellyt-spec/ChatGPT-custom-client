var T = Object.defineProperty,
    D = Object.defineProperties;
var b = Object.getOwnPropertyDescriptors;
var y = Object.getOwnPropertySymbols;
var v = Object.prototype.hasOwnProperty,
    N = Object.prototype.propertyIsEnumerable;
var O = (s, e, t) => e in s ? T(s, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : s[e] = t,
    d = (s, e) => {
        for (var t in e || (e = {})) v.call(e, t) && O(s, t, e[t]);
        if (y)
            for (var t of y(e)) N.call(e, t) && O(s, t, e[t]);
        return s
    },
    p = (s, e) => D(s, b(e));
var w = (s, e) => {
    var t = {};
    for (var n in s) v.call(s, n) && e.indexOf(n) < 0 && (t[n] = s[n]);
    if (s != null && y)
        for (var n of y(s)) e.indexOf(n) < 0 && N.call(s, n) && (t[n] = s[n]);
    return t
};
import {
    m9 as U,
    rO as $,
    fX as L,
    m3 as l,
    m4 as j,
    hR as F,
    rP as B,
    R as G,
    rQ as M,
    rR as J,
    m5 as E,
    mf as z,
    rS as H,
    rT as k
} from "./dykg4ktvbu3mhmdo.js";
import {
    r as K
} from "./fg33krlcm0qyi6yw.js";
import {
    m as q
} from "./hlntli3lea5dl5vn.js";
import {
    dJ as g,
    dK as I
} from "./k15yxxoybkkir2ou.js";

function ve({
    composerController: s,
    parsedDocumentHandler: e
}) {
    const {
        connectorConfig: t
    } = U();
    return K.useEffect(() => {
        $(L(s), {
            transformPasted: (n, r) => {
                const {
                    allDocIds: o,
                    nextSlice: a
                } = Q(n, r, t);
                return requestAnimationFrame(() => {
                    e(o)
                }), a
            }
        })
    }, [s, t, e]), null
}

function Q(s, e, t) {
    const n = [],
        r = e.state.schema,
        o = i => {
            var h;
            if (i.isText) {
                let u = (h = i.text) != null ? h : "";
                const m = W(u, t);
                if (m.length === 0) return i;
                for (const f of m) n.push(f), f.isConnected && (u = u.replaceAll(f.url, ""));
                return u === "" ? null : r.text(u, i.marks)
            }
            if (i.isLeaf) return i;
            const c = [];
            return i.forEach(u => {
                const m = o(u);
                m && c.push(m)
            }), i.copy(k.fromArray(c))
        },
        a = [];
    return s.content.forEach(i => {
        const c = o(i);
        c && a.push(c)
    }), {
        allDocIds: n,
        nextSlice: new H(k.fromArray(a), s.openStart, s.openEnd)
    }
}

function W(s, e) {
    var n;
    const t = [];
    for (const r of e.values()) switch (r.type) {
        case l.GDRIVE:
            {
                if ((n = r.link_enabled) == null || n) {
                    const o = V(s, r);
                    t.push(...o)
                }
                break
            }
        case l.O365:
            break;
        case l.O365_BUSINESS:
            {
                const o = ue(s, r).filter(a => a != null);t.push(...o);
                break
            }
        case l.O365_PERSONAL:
            {
                const o = ne(s, r).filter(a => a != null);t.push(...o);
                break
            }
        case l.CONFLUENCE:
            {
                const o = oe(s, r).filter(a => a != null);t.push(...o);
                break
            }
        case l.JIRA:
            {
                const o = ce(s, r).filter(a => a != null);t.push(...o);
                break
            }
        case l.NOTION_OPEN_CONNECTOR:
            {
                const o = Ee(s, r).filter(a => a != null);t.push(...o);
                break
            }
        case l.SLACK_OPEN_CONNECTOR:
            {
                const o = me(s, r).filter(a => a != null);t.push(...o);
                break
            }
    }
    return t.length && j.linkPasted(q(F(t, r => r.type), r => r.length)), t
}
const X = /\bhttps:\/\/docs\.google\.com\/(document|spreadsheets|presentation)\/d\/([\w-]+)\/?(?:(?:edit|view)\/?)?(?:\?[\w\-.~%=]*)?(?:#[\w\-.~%=]*)?/gm,
    Y = /\bhttps:\/\/drive\.google\.com\/(file)\/d\/([\w-]+)\/?(?:(?:edit|view)\/?)?(?:\?[\w\-.~%=]*)?(?:#[\w\-.~%=]*)?/gm,
    Z = "https://www.googleapis.com/auth/drive.readonly";

function V(s, e) {
    return [...s.matchAll(X), ...s.matchAll(Y)].map(t => {
        const n = {
            url: t[0],
            id: t[2],
            type: l.GDRIVE,
            isConnected: e.access_token != null
        };
        return e.access_token && e.scopes && e.scopes.includes(Z) ? p(d({}, n), {
            handler: {
                type: "fetch",
                tryFetch: async () => {
                    I.logAttemptIfAccessTokenIsExpired(e, E.Link);
                    const o = "https://www.googleapis.com/drive/v3/files/".concat(n.id, "?fields=name,mimeType"),
                        a = await fetch(o, {
                            method: "GET",
                            headers: {
                                Authorization: "Bearer ".concat(e.access_token),
                                "Content-Type": "application/json"
                            }
                        });
                    if (!a.ok) return Promise.reject(new Error("HTTP ".concat(a.status)));
                    const {
                        name: i,
                        mimeType: c
                    } = await a.json(), h = z(c);
                    return {
                        connector: l.GDRIVE,
                        id: n.id,
                        title: i,
                        mimeType: c,
                        url: n.url,
                        syntheticExtension: h
                    }
                }
            }
        }) : p(d({}, n), {
            handler: {
                type: "prompt",
                message: "not-connected"
            }
        })
    })
}

function A(s) {
    let e;
    try {
        e = new URL(s).toString()
    } catch (t) {
        return null
    }
    return "u!".concat(btoa(e).replaceAll("=", "").replaceAll("/", "_").replaceAll("+", "-"))
}
const ee = /\bhttps:\/\/onedrive\.live\.com\/[\w\-_.~!*'();:@&=+$,\\/?%#[\]]*/gm,
    te = /\bhttps:\/\/photos\.onedrive\.com\/(?:share|photo)\/[\w\-_.~!*'();:@&=+$,\\/?%#[\]]*/gm,
    se = /\bhttps:\/\/1drv\.ms\/[\w\-_.~!*'();:@&=+$,\\/?%#[\]]*/gm;

function ne(s, e) {
    return [...s.matchAll(ee), ...s.matchAll(se), ...s.matchAll(te)].map(t => {
        const n = A(t[0]);
        if (!n) return null;
        const r = {
            url: t[0],
            id: n,
            type: l.O365_PERSONAL,
            isConnected: e.access_token != null
        };
        return e.access_token ? p(d({}, r), {
            handler: {
                type: "fetch",
                tryFetch: P(g.OneDrive_PERSONAL_SHARES, n, e.access_token, e)
            }
        }) : p(d({}, r), {
            handler: {
                type: "prompt",
                message: "not-connected"
            }
        })
    })
}
const re = /\bhttps:\/\/([^\s]+?\.atlassian\.net)\/wiki\/spaces\/[^\s]+\/pages\/(\d+)\/([^\s]+)?/gm;

function oe(s, e) {
    return [...s.matchAll(re)].map(t => {
        const n = t[1],
            r = t[2],
            o = t[3];
        if (!r) return null;
        const a = {
            url: t[0],
            id: r,
            type: l.CONFLUENCE,
            isConnected: e.access_token != null
        };
        return e.access_token ? p(d({}, a), {
            handler: {
                type: "fetch",
                tryFetch: async () => {
                    let i = o;
                    return !o && e.access_token && (i = await ge(e.access_token, "https://".concat(n), e, r)), {
                        connector: e.type,
                        id: r,
                        title: i,
                        mimeType: "text/html",
                        url: a.url,
                        syntheticExtension: null,
                        manifest: {
                            id: r,
                            domain: n,
                            type: J.PAGE,
                            manifest_type: l.CONFLUENCE
                        }
                    }
                }
            }
        }) : p(d({}, a), {
            handler: {
                type: "prompt",
                message: "not-connected"
            }
        })
    })
}
const ae = /\bhttps:\/\/([^\s]+?\.atlassian\.net)\/browse\/([^\s]+)\??/gm,
    ie = /\bhttps:\/\/([^\s]+?\.atlassian\.net)\/jira\/(?:[^\s]+\/)*projects\/(?:[^\s]+\/)+(?:[^\s]+\/?)\?selectedIssue=([^\s]+)&?/gm;

function ce(s, e) {
    return [...s.matchAll(ae), ...s.matchAll(ie)].map(t => {
        const n = t[1],
            r = t[2];
        if (!r || !n) return null;
        const o = {
            url: t[0],
            id: r,
            type: l.JIRA,
            isConnected: e.access_token != null
        };
        return e.access_token ? p(d({}, o), {
            handler: {
                type: "fetch",
                tryFetch: async () => {
                    const a = await ye(e.access_token, "https://".concat(n), e, r);
                    return Promise.resolve({
                        connector: e.type,
                        id: r,
                        title: a,
                        mimeType: "text/markdown",
                        url: o.url,
                        syntheticExtension: null,
                        manifest: {
                            id_or_key: r,
                            domain: n,
                            manifest_type: l.JIRA
                        }
                    })
                }
            }
        }) : p(d({}, o), {
            handler: {
                type: "prompt",
                message: "not-connected"
            }
        })
    })
}
const le = /\bhttps:\/\/[^\s]+?\.sharepoint\.com\/[^\s]*/gm;

function ue(s, e) {
    return [...s.matchAll(le)].map(t => {
        const n = A(t[0]),
            r = g.OneDrive_BUSINESS_SHARES;
        if (!n) return null;
        const o = {
            url: t[0],
            id: n,
            type: l.O365_BUSINESS,
            isConnected: e.access_token != null
        };
        return e.access_token ? p(d({}, o), {
            handler: {
                type: "fetch",
                tryFetch: P(r, n, e.access_token, e)
            }
        }) : p(d({}, o), {
            handler: {
                type: "prompt",
                message: "not-connected"
            }
        })
    })
}
const de = new RegExp("\\bhttps:\\/\\/(?<domain>[^\\s]+?\\.(?:enterprise\\.)?slack\\.com)\\/archives\\/(?<conversation_id>[^\\s/]+)\\/?\\??$", "gm"),
    pe = new RegExp("\\bhttps:\\/\\/(?<domain>[^\\s]+?\\.(?:enterprise\\.)?slack\\.com)\\/archives\\/(?<conversation_id>[^\\s/]+)\\/p(?<message_id>[^\\s?&]+)(?:\\?(?:.*thread_ts=(?<thread_id>[^\\s&]+)(?:&.*))?)?", "gm");

function me(s, e) {
    return [...s.matchAll(pe), ...s.matchAll(de)].map(t => {
        var m, f, C, R, S;
        const n = (m = t.groups) == null ? void 0 : m.domain;
        if (!n) throw new Error("No domain found in match ".concat(JSON.stringify(t)));
        const r = (f = t.groups) == null ? void 0 : f.conversation_id;
        if (!r) throw new Error("No conversation ID found in match ".concat(JSON.stringify(t)));
        const o = (C = t.groups) == null ? void 0 : C.message_id;
        let a = null;
        o && (a = "".concat(o.slice(0, 10), ".").concat(o.slice(10)));
        const i = (S = (R = t.groups) == null ? void 0 : R.thread_id) != null ? S : null;
        let c = "Conversation",
            h = "conversation-".concat(r);
        a ? (c = "Message", h = "message-".concat(a)) : i ? (c = "Thread", h = "thread-".concat(i)) : r[0] === "D" && (c = "Direct message");
        const u = {
            id: h,
            url: t[0],
            domain: n,
            conversationId: r,
            messageId: a,
            threadId: i,
            type: l.SLACK_OPEN_CONNECTOR,
            isConnected: e.access_token != null
        };
        return e.access_token ? p(d({}, u), {
            handler: {
                type: "fetch",
                tryFetch: async () => e.access_token ? Promise.resolve({
                    connector: e.type,
                    id: u.id,
                    title: c,
                    mimeType: "application/json",
                    url: u.url,
                    syntheticExtension: null,
                    manifest: {
                        conversation_id: u.conversationId,
                        domain: u.domain,
                        manifest_type: l.SLACK_OPEN_CONNECTOR,
                        message_id: u.messageId,
                        thread_id: i,
                        type: B.MESSAGE
                    }
                }) : Promise.reject(new Error("Not connected"))
            }
        }) : p(d({}, u), {
            handler: {
                type: "prompt",
                message: "not-connected"
            }
        })
    })
}

function P(s, e, t, n, r) {
    switch (s) {
        case g.OneDrive_BUSINESS_SHARES:
        case g.OneDrive_PERSONAL_SHARES:
            return () => _("".concat(s, "/").concat(encodeURIComponent(e), "/driveItem"), t, n);
        case g.OneDrive_BUSINESS_DRIVE_ITEMS:
            return () => _("".concat(s, "/").concat(encodeURIComponent(e)), t, n);
        case g.OneDrive_BUSINESS_DRIVE_ROOT:
            return async () => {
                const o = await he(t, e);
                if (!o) return Promise.reject(null);
                const a = "".concat(s, ":").concat(encodeURIComponent(o));
                return _(a, t, n)
            };
        case g.OneDrive_PERSONAL_DRIVE_ITEMS:
            return () => Promise.reject(null)
    }
}
async function he(s, e) {
    const n = await fetch("https://graph.microsoft.com/v1.0/me/drive/root", {
        method: "GET",
        headers: {
            Authorization: "Bearer ".concat(s),
            "Content-Type": "application/json"
        }
    });
    if (!n.ok) return null;
    const {
        webUrl: r
    } = await n.json(), a = new URL(r).pathname;
    return e.startsWith(a) ? e.substring(a.length) : e
}
async function _(s, e, t, n) {
    var m, f;
    I.logAttemptIfAccessTokenIsExpired(t, E.Link);
    const r = await fetch(s, {
        method: "GET",
        headers: {
            Authorization: "Bearer ".concat(e),
            "Content-Type": "application/json"
        }
    });
    if (!r.ok) return Promise.reject(new Error("HTTP ".concat(r.status)));
    const u = await r.json(),
        {
            id: o,
            name: a,
            file: i,
            webUrl: c
        } = u,
        h = w(u, ["id", "name", "file", "webUrl"]);
    return n || (n = (m = h.parentReference) == null ? void 0 : m.driveId), {
        connector: t.type,
        id: o,
        title: a != null ? a : "",
        mimeType: (f = i == null ? void 0 : i.mimeType) != null ? f : "",
        url: c != null ? c : "",
        syntheticExtension: null,
        o365DriveId: n
    }
}
const fe = "https://api.atlassian.com/oauth/token/accessible-resources";
async function x(s, e, t) {
    var o;
    I.logAttemptIfAccessTokenIsExpired(t, E.Link);
    const r = (o = (await fetch(fe, {
        headers: {
            Authorization: "Bearer ".concat(s)
        }
    }).then(a => a.json())).find(a => a.url === e)) == null ? void 0 : o.id;
    return r || Promise.reject(new Error("Cloud ID not found"))
}
async function ge(s, e, t, n) {
    var i;
    const r = await x(s, e, t);
    return (i = (await fetch("https://api.atlassian.com/ex/confluence/".concat(r, "/wiki/api/v2/pages/").concat(n, "?include-version=false"), {
        headers: {
            Authorization: "Bearer ".concat(s)
        }
    }).then(c => c.json())).title) != null ? i : "Confluence Page"
}
async function ye(s, e, t, n) {
    var i;
    const r = await x(s, e, t);
    return (i = (await fetch("https://api.atlassian.com/ex/jira/".concat(r, "/rest/api/2/issue/").concat(n, "?fields=summary"), {
        headers: {
            Authorization: "Bearer ".concat(s)
        }
    }).then(c => c.json())).fields.summary) != null ? i : "Jira Issue"
}
const _e = new RegExp("\\bhttps:\\/\\/www\\.notion\\.so\\/(?:.*?)?(?<page_id>[a-f0-9]{32})(?:\\?[\\x21-\\x7e]*)?", "gm");

function Ee(s, e) {
    return [...s.matchAll(_e)].map(t => {
        var o;
        const n = (o = t.groups) == null ? void 0 : o.page_id;
        if (!n) return null;
        const r = {
            url: t[0],
            id: n,
            type: l.NOTION_OPEN_CONNECTOR,
            isConnected: e.access_token != null
        };
        return e.access_token ? p(d({}, r), {
            handler: {
                type: "fetch",
                tryFetch: async () => {
                    var i;
                    const a = await G.safePost("/connectors/metadata", {
                        requestBody: {
                            manifest: {
                                id: n,
                                manifest_type: l.NOTION_OPEN_CONNECTOR
                            }
                        }
                    });
                    return Promise.resolve({
                        connector: e.type,
                        id: n,
                        title: (i = a.title) != null ? i : "Notion Page",
                        mimeType: "application/json",
                        url: r.url,
                        syntheticExtension: null,
                        manifest: {
                            id: n,
                            type: M.PAGE,
                            manifest_type: l.NOTION_OPEN_CONNECTOR
                        }
                    })
                }
            }
        }) : p(d({}, r), {
            handler: {
                type: "prompt",
                message: "not-connected"
            }
        })
    })
}
export {
    ve as ContextConnectorDocumentParser, A as encodeOneDriveShareUrl, X as gdocRegex, W as parseDocumentURLs
};
//# sourceMappingURL=dfk80oxw9xer35fj.js.map