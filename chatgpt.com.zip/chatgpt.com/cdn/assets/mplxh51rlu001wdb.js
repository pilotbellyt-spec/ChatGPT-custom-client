var B = Object.defineProperty;
var M = Object.getOwnPropertySymbols;
var N = Object.prototype.hasOwnProperty,
    O = Object.prototype.propertyIsEnumerable;
var w = (e, t, s) => t in e ? B(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : e[t] = s,
    I = (e, t) => {
        for (var s in t || (t = {})) N.call(t, s) && w(e, s, t[s]);
        if (M)
            for (var s of M(t)) O.call(t, s) && w(e, s, t[s]);
        return e
    };
import {
    c as T,
    al as $,
    e as A,
    j as S,
    M as U,
    o as P
} from "./fg33krlcm0qyi6yw.js";
import {
    eB as _,
    d9 as j
} from "./k15yxxoybkkir2ou.js";
import {
    nm as k,
    d as y,
    s9 as E,
    sa as R,
    sb as b
} from "./dykg4ktvbu3mhmdo.js";
import {
    D as z
} from "./cu0e6szsqsyduwov.js";
import "./ftef8970ba1zoykr.js";

function v(e) {
    return e === "/" ? "/" : e.replace(/\/+$/, "")
}

function Q(e, t) {
    if (e.search === t.search || v(e.pathname) !== v(t.pathname)) return !1;
    const s = new URLSearchParams(e.search),
        n = new URLSearchParams(t.search),
        r = s.has("model") || n.has("model");
    return s.delete("model"), n.delete("model"), r && s.toString() === n.toString()
}

function D({
    currentLocation: e,
    nextLocation: t,
    isIntegratedVoiceModeActive: s,
    voiceCompletionRequest: n,
    integratedVoiceModeState: r,
    isEndingVoiceSession: m
}) {
    var f;
    if (!s) return !1;
    const a = v(e.pathname),
        c = v(t.pathname);
    if (Q(e, t) || !(a === "/") && a === c || m) return !1;
    const d = n == null ? void 0 : n.responseThreadId;
    if (d) {
        const o = P("/c/:conversationId", c),
            i = P("/g/:gizmoId/c/:conversationId", c);
        if (((f = o == null ? void 0 : o.params.conversationId) != null ? f : i == null ? void 0 : i.params.conversationId) === d) return !1
    }
    return r != null
}
const q = () => {
        "use forget";
        const e = T.c(17),
            t = k(),
            s = y(F),
            n = y(G),
            r = y(H);
        let m;
        e[0] !== n || e[1] !== r || e[2] !== t || e[3] !== s ? (m = l => {
            const {
                nextLocation: C,
                currentLocation: x
            } = l;
            return D({
                currentLocation: x,
                nextLocation: C,
                isIntegratedVoiceModeActive: t,
                voiceCompletionRequest: s,
                integratedVoiceModeState: n,
                isEndingVoiceSession: r
            })
        }, e[0] = n, e[1] = r, e[2] = t, e[3] = s, e[4] = m) : m = e[4];
        const a = $(m),
            c = A(),
            p = a.state === "blocked";
        let h;
        e[5] !== a ? (h = () => {
            var l;
            (l = a.reset) == null || l.call(a)
        }, e[5] = a, e[6] = h) : h = e[6];
        const g = h;
        let d;
        e[7] !== a ? (d = async () => {
            var l;
            await _({
                type: "STOP",
                reason: z.UserNavigatedAway
            }), (l = a.proceed) == null || l.call(a)
        }, e[7] = a, e[8] = d) : d = e[8];
        const f = d;
        let o;
        e[9] !== c ? (o = c.formatMessage(V.title), e[9] = c, e[10] = o) : o = e[10];
        let i;
        e[11] === Symbol.for("react.memo_cache_sentinel") ? (i = S.jsx(U, I({}, V.description)), e[11] = i) : i = e[11];
        let u;
        return e[12] !== f || e[13] !== g || e[14] !== p || e[15] !== o ? (u = S.jsx(j, {
            title: o,
            isOpen: p,
            onClose: g,
            onConfirm: f,
            primaryButtonColor: "danger",
            children: i
        }), e[12] = f, e[13] = g, e[14] = p, e[15] = o, e[16] = u) : u = e[16], u
    },
    V = {
        title: {
            id: "voice-navigation-blocker.title",
            defaultMessage: "Voice Mode is still active",
            description: "Title of the modal that appears when the user tries to navigate away from the page while voice mode is active"
        },
        description: {
            id: "voice-navigation-blocker.description",
            defaultMessage: "Navigating away from this page will end your voice mode session.",
            description: "Message of the modal that appears when the user tries to navigate away from the page while voice mode is active"
        }
    };

function F() {
    return E()
}

function G() {
    return R()
}

function H() {
    return b()
}
export {
    q as VoiceNavigationBlocker
};
//# sourceMappingURL=mplxh51rlu001wdb.js.map