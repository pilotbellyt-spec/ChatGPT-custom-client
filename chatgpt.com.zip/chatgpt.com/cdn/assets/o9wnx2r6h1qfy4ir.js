var Cn = Object.defineProperty,
    _n = Object.defineProperties;
var kn = Object.getOwnPropertyDescriptors;
var Is = Object.getOwnPropertySymbols;
var Tn = Object.prototype.hasOwnProperty,
    Sn = Object.prototype.propertyIsEnumerable;
var is = (t, e, o) => e in t ? Cn(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: o
    }) : t[e] = o,
    ht = (t, e) => {
        for (var o in e || (e = {})) Tn.call(e, o) && is(t, o, e[o]);
        if (Is)
            for (var o of Is(e)) Sn.call(e, o) && is(t, o, e[o]);
        return t
    },
    as = (t, e) => _n(t, kn(e));
var Es = (t, e, o) => is(t, typeof e != "symbol" ? e + "" : e, o);
import {
    r as l,
    j as s,
    M as Ce,
    c as ws,
    f as Ks,
    e as _e,
    E as rs
} from "./fg33krlcm0qyi6yw.js";
import {
    bg as le,
    l as se,
    a9 as en,
    h7 as xs,
    xj as Se,
    gd as gs,
    bI as Nn,
    c2 as tn,
    b as Ft,
    kI as sn,
    bv as qe,
    id as nn,
    dN as An,
    b$ as In,
    da as En,
    uZ as Ms,
    td as Ls,
    n9 as Mn,
    na as Ln,
    nb as Rn,
    nh as On,
    xo as ls,
    _ as nt,
    hA as Pn,
    bb as $n,
    dI as on,
    d6 as Dn,
    o as an,
    kw as Hn,
    bX as Vn,
    kH as je,
    e4 as Be,
    fh as Rs,
    g$ as Wn,
    bH as Bn,
    d as Os,
    e2 as zn,
    fN as Ps,
    AG as cs,
    gm as $s,
    bc as rn,
    bd as ln,
    k as Un,
    eo as Gn,
    dF as Fn,
    pF as Zn,
    hH as qn,
    eW as Jn,
    P as us,
    gl as Qn
} from "./dykg4ktvbu3mhmdo.js";
import {
    rO as Xn,
    rQ as Yn,
    ej as Zt,
    iH as Kn,
    BX as cn,
    rI as Ut,
    iZ as eo,
    er as z,
    BY as js,
    BZ as to,
    bS as so,
    ib as no,
    kS as oo,
    ab as io,
    ac as ao,
    B_ as ro,
    B$ as lo,
    jS as co,
    C0 as uo,
    C1 as fo,
    C2 as mo,
    C3 as po,
    C4 as ho,
    j0 as xo,
    C5 as Ds,
    C6 as ds,
    C7 as Hs,
    j2 as un,
    b1 as go,
    aC as yo,
    jc as bo,
    C8 as wo,
    rN as jo,
    oU as vo,
    rU as Co,
    C9 as _o
} from "./k15yxxoybkkir2ou.js";
import {
    C as ko
} from "./bzqbnv68e5p19ax6.js";
import {
    g as To,
    c as So,
    d as No,
    a as Vs,
    e as fs,
    f as Ws,
    b as Ao,
    C as Io,
    S as Eo
} from "./d500l0l73692yic4.js";
import {
    M as Mo
} from "./ou2xm3xmri21t4zm.js";
import {
    L as Lo
} from "./jnh7gh80gtj0452q.js";
import {
    s as Ro
} from "./b31u62knn5mcc1vg.js";
import {
    p as Oo
} from "./msn8hpk3ivp7ibnw.js";
import {
    S as Po,
    C as $o,
    H as Do,
    t as Ze
} from "./c2wfb3iy9wkb85gs.js";
import {
    shell as Ho
} from "./pbl95wx6493wq92j.js";
import {
    E as ys,
    e as Vo,
    V as Wo,
    R as Bo,
    D as dn
} from "./ovpdmx71kjznjdh8.js";
import {
    a as zo
} from "./tjmll0bdtco26rsw.js";
import {
    C as Uo
} from "./gb3g89r4fqk97sov.js";
import {
    D as Go
} from "./bs2inoi5zs5d1t2y.js";
import {
    u as Fo
} from "./fyk9tph6baj60t7u.js";
import {
    A as Zo
} from "./cjybewlxcr1rdyw3.js";
import "./obmzp3ebe8x6w67a.js";
import "./gd2ozzf4upgi0amm.js";
import "./jbh6ambg0gcrgcqd.js";
import "./nr0ly5umft9hqfl0.js";
const qo = ({
    url: t,
    withBorder: e = !1
}) => {
    const {
        isSuccess: o,
        isError: i
    } = Xn(Yn(t, 32)), [n] = l.useState(o);
    return i ? null : s.jsx(le.div, {
        initial: {
            opacity: n ? 1 : 0
        },
        animate: {
            opacity: o ? 1 : 0
        },
        className: se("bg-primary -ms-3 box-content size-4 shrink-0 overflow-hidden rounded-full first:-ms-1", e && "border-token-main-surface-secondary group-hover:border-token-text-primary dark:group-hover:border-token-text-primary border"),
        children: s.jsx(Zt, {
            url: t,
            size: 32,
            className: "m-0"
        })
    })
};

function Jo({
    tabs: t,
    activeTab: e,
    setActiveTab: o,
    initializing: i = !1
}) {
    const n = s.jsx(Ce, {
        id: "odyssey.tabBar.newTab",
        defaultMessage: "New tab"
    });
    return i ? s.jsx("nav", {
        className: "bg-token-bg-tertiary flex flex-1 items-center gap-1 rounded-t-xl",
        children: s.jsx("div", {
            className: "flex flex-1 items-center gap-1",
            children: s.jsx(zs, {
                onClick: () => {},
                active: !0,
                children: n
            })
        })
    }) : s.jsx("nav", {
        className: "bg-token-bg-tertiary flex flex-1 items-center gap-1 rounded-t-xl",
        children: s.jsx("div", {
            className: "flex flex-1 items-center gap-1",
            children: t.map(c => s.jsx(zs, {
                active: e === c.label,
                icon: c.icon,
                onClick: () => o(c.label),
                children: c.label
            }, c.icon))
        })
    })
}

function Bs({
    side: t
}) {
    return s.jsx("span", {
        "aria-hidden": !0,
        className: se("pointer-events-none absolute bottom-0 h-3 w-3 bg-transparent z-10", t === "left" ? "end-full rounded-ee-[50%] shadow-[4px_0_0_0_var(--bg-primary)]" : "start-full rounded-es-[50%] shadow-[-4px_0_0_0_var(--bg-primary)]")
    })
}

function zs({
    active: t = !1,
    icon: e,
    children: o,
    onClick: i
}) {
    return s.jsxs("div", {
        className: se("relative rounded-t-xl py-2 ps-4 pe-4.5 text-[11px] leading-[13px] font-medium whitespace-nowrap", t ? "bg-token-bg-primary text-token-text-primary" : "text-token-text-secondary hover:bg-token-bg-primary/60 hover:text-token-text-primary"),
        onClick: i,
        children: [t && s.jsxs(s.Fragment, {
            children: [s.jsx(Bs, {
                side: "left"
            }), s.jsx(Bs, {
                side: "right"
            })]
        }), s.jsxs("div", {
            className: "flex flex-row items-center gap-1",
            children: [e ? s.jsx(qo, {
                url: e
            }) : s.jsx(Kn, {
                className: "size-4"
            }), o]
        })]
    })
}
const Qo = ({
        chunk: t,
        isFinalAssistantTurn: e,
        hidePowTombstone: o,
        isKAUR1BR5: i
    }) => {
        const n = t.screenshots.at(-1),
            {
                origin: c,
                domain: u
            } = l.useMemo(() => cn(n), [n]),
            a = Ut(n, void 0),
            {
                open: m,
                isVNCEnabled: f
            } = eo(),
            [h, x] = l.useState(null),
            [p, y] = l.useState(!1);
        return l.useEffect(() => {
            if (!a) return;
            let S = !1;
            y(!1);
            const N = new Image;
            return N.src = a, N.onload = () => !S && x(a), N.onerror = () => {
                S || (y(!0), x(null))
            }, () => {
                S = !0
            }
        }, [a]), e ? s.jsxs(le.div, {
            className: "group border-token-border-heavy relative flex max-w-md flex-1 cursor-default flex-col gap-2 overflow-hidden rounded-2xl border",
            initial: {
                opacity: 0
            },
            animate: {
                opacity: 1
            },
            exit: {
                opacity: 0
            },
            transition: {
                duration: .4,
                ease: "easeInOut"
            },
            children: [s.jsxs("div", {
                className: "bg-token-bg-tertiary flex flex-col",
                children: [s.jsx("div", {
                    className: "align-start flex flex-row gap-1 px-1 pt-1 text-sm",
                    children: s.jsx(Jo, {
                        tabs: [{
                            icon: c != null ? c : "",
                            label: u != null ? u : ""
                        }],
                        activeTab: u,
                        setActiveTab: () => {},
                        initializing: !1
                    })
                }), s.jsx("div", {
                    className: "group relative aspect-[1024/698] w-full",
                    children: h ? s.jsx("img", {
                        src: h,
                        alt: "Screenshot that shows the model used the computer",
                        className: "absolute inset-0 h-full w-full object-cover object-bottom"
                    }, h) : s.jsx("div", {
                        className: "absolute inset-0 flex items-center justify-center",
                        children: s.jsx("div", {
                            className: "border-token-border-heavy h-4 w-4 animate-spin rounded-full border-2 border-t-transparent"
                        })
                    })
                })]
            }), f && s.jsx("div", {
                className: "absolute inset-0 z-100 flex h-full w-full items-center justify-center bg-black/50 opacity-0 transition-opacity group-hover:opacity-100",
                children: s.jsx(en, {
                    color: "primary-inverse",
                    onClick: () => m(),
                    children: s.jsx("div", {
                        className: "flex items-center gap-1",
                        children: i ? s.jsx(Ce, {
                            id: "ahugQu",
                            defaultMessage: "Open tabs"
                        }) : s.jsx(Ce, {
                            id: "Kj2mXr",
                            defaultMessage: "Take over"
                        })
                    })
                })
            })]
        }, "proof-of-work") : o ? null : s.jsx(Xo, {})
    },
    Xo = () => s.jsxs(le.div, {
        className: "border-token-border-default group flex max-w-xs items-center gap-2 rounded-2xl border p-4 select-none",
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        transition: {
            duration: .25,
            ease: "easeInOut"
        },
        children: [s.jsx(Lo, {
            className: "icon"
        }), s.jsx("span", {
            className: "flex-1 truncate text-sm font-medium",
            children: s.jsx(Ce, {
                id: "cot.proofofwork.tombstone",
                defaultMessage: "Used the browser"
            })
        })]
    }, "tombstone"),
    Yo = t => {
        "use forget";
        const e = ws.c(8),
            {
                chunks: o,
                isExpanded: i,
                isFinalAssistantTurn: n,
                hidePowTombstone: c,
                isKAUR1BR5: u
            } = t;
        let a;
        e[0] !== o ? (a = ei(o), e[0] = o, e[1] = a) : a = e[1];
        const m = a;
        if (!m) return null;
        let f;
        return e[2] !== c || e[3] !== i || e[4] !== n || e[5] !== u || e[6] !== m ? (f = s.jsx(ti, {
            chunk: m,
            isExpanded: i,
            isFinalAssistantTurn: n,
            hidePowTombstone: c,
            isKAUR1BR5: u
        }), e[2] = c, e[3] = i, e[4] = n, e[5] = u, e[6] = m, e[7] = f) : f = e[7], f
    },
    Ko = l.memo(Yo),
    ei = t => xs(t, e => {
        var o;
        return e.type === z.ComputerOutput && !e.isBlank && ((o = e.screenshots) == null ? void 0 : o.length) > 0
    }),
    ti = t => {
        "use forget";
        const e = ws.c(6),
            {
                chunk: o,
                isExpanded: i,
                isFinalAssistantTurn: n,
                hidePowTombstone: c,
                isKAUR1BR5: u
            } = t;
        if (o.type !== z.ComputerOutput) return null;
        let a;
        return e[0] !== o || e[1] !== c || e[2] !== i || e[3] !== n || e[4] !== u ? (a = s.jsx(Qo, {
            chunk: o,
            isExpanded: i,
            isFinalAssistantTurn: n,
            hidePowTombstone: c,
            isKAUR1BR5: u
        }), e[0] = o, e[1] = c, e[2] = i, e[3] = n, e[4] = u, e[5] = a) : a = e[5], a
    };

function si(t, e, o, i, n) {
    const [c, u] = l.useState(Se.Setup), a = l.useMemo(() => t.every(f => f.type === z.N7jupdLoading) && e, [t, e]), m = l.useMemo(() => {
        const f = gs(t);
        return (f == null ? void 0 : f.type) !== z.N7jupdLoading ? !1 : f == null ? void 0 : f.needs_startup
    }, [t]);
    return l.useEffect(() => {
        const f = setTimeout(() => {
                u(Se.Random)
            }, 7e3),
            h = setTimeout(() => {
                u(Se.Animation)
            }, 15e3);
        return () => {
            clearTimeout(f), clearTimeout(h)
        }
    }, []), i && a ? Se.Autoswitch : o === Nn.Research && a ? Se.Research : a ? m ? c : n ? Se.KAUR1BR5 : Se.Thinking : Se.Done
}

function ni() {
    const t = Ft(),
        o = tn(t, "chatgpt_cot_config").get("shimmer_duration_ms", 2e3);
    l.useEffect(() => {
        document.documentElement.style.setProperty("--cot-shimmer-duration", "".concat(o, "ms"))
    }, [o])
}
const oi = ({
        radius: t = 8,
        className: e = ""
    }) => s.jsx("svg", {
        width: t,
        height: t,
        viewBox: "0 0 ".concat(t, " ").concat(t),
        className: e,
        xmlns: "http://www.w3.org/2000/svg",
        children: s.jsx("path", {
            d: "\n        M 0 0 H ".concat(t, " V ").concat(t, " H 0 Z\n        M ").concat(t, " 0\n          A ").concat(t, " ").concat(t, " 0 0 1 0 ").concat(t, "\n          L 0 0 Z\n      "),
            fill: "currentColor",
            fillRule: "evenodd"
        })
    }),
    ii = ({
        radius: t = 8,
        className: e = ""
    }) => s.jsx("svg", {
        width: t,
        height: t,
        viewBox: "0 0 ".concat(t, " ").concat(t),
        className: e,
        xmlns: "http://www.w3.org/2000/svg",
        children: s.jsx("path", {
            d: "\n        M 0 0 H ".concat(t, " V ").concat(t, " H 0 Z\n        M 0 0\n          A ").concat(t, " ").concat(t, " 0 0 0 ").concat(t, " ").concat(t, "\n          L ").concat(t, " 0 Z\n      "),
            fill: "currentColor",
            fillRule: "evenodd"
        })
    }),
    ai = t => l.createElement("svg", ht({
        width: 16,
        height: 16,
        viewBox: "0 0 16 16",
        fill: "currentColor",
        xmlns: "http://www.w3.org/2000/svg"
    }, t), l.createElement("path", {
        d: "M10.4143 3.78804C11.2308 3.06073 12.5437 3.20285 13.1298 4.19364L13.469 4.77827C14.2729 6.19616 15.151 8.02487 15.1871 9.82449L15.1968 10.0908C15.2024 10.7193 15.0819 11.3931 14.7678 11.971C14.4183 12.6138 13.8308 13.126 12.9833 13.2848L12.8108 13.3115C12.326 13.3724 11.5719 13.3799 11.0197 13.3343L10.7964 13.3115C9.72823 13.1772 8.85301 12.4163 8.56337 11.3935L8.51324 11.1858C8.4115 10.6741 8.38934 10.1051 8.49305 9.56017C8.1699 9.47939 7.82797 9.47883 7.50477 9.55952C7.59002 10.0069 7.59095 10.4704 7.53212 10.9052L7.48524 11.1858C7.2753 12.2418 6.45372 13.0609 5.41297 13.277L5.20204 13.3115C4.71723 13.3724 3.96318 13.3799 3.41102 13.3343L3.18771 13.3115C2.24691 13.1932 1.60336 12.6565 1.23068 11.971C0.877576 11.3214 0.770462 10.5505 0.810761 9.859H0.81011C0.839224 7.78961 1.99128 5.6781 2.86936 4.19364L2.92795 4.09989C3.53924 3.19422 4.79402 3.0843 5.5842 3.78804L5.66167 3.86095L5.70725 3.91173C5.92082 4.17352 5.90559 4.55955 5.66167 4.80366C5.41756 5.04777 5.03095 5.06354 4.76909 4.84989L4.71896 4.80366L4.67534 4.76525C4.46743 4.59925 4.18745 4.64454 4.04514 4.83035L4.01649 4.87202C3.54668 5.66627 3.06093 6.54731 2.70139 7.44624C2.83303 7.40655 2.96918 7.37694 3.10894 7.3577L3.34852 7.33035C3.94296 7.27665 4.76074 7.28612 5.28081 7.3577L5.46831 7.38895C6.13623 7.52414 6.63592 7.86838 6.97873 8.32384C7.64014 8.11335 8.35785 8.11455 9.01909 8.32515C9.3932 7.82749 9.9545 7.46279 10.7177 7.3577L10.9572 7.33035C11.5517 7.27666 12.3695 7.2861 12.8895 7.3577L13.0061 7.37593C13.105 7.39399 13.2018 7.41774 13.2964 7.44624C13.0224 6.76121 12.6758 6.08637 12.3179 5.45275L11.982 4.87202C11.8431 4.63734 11.5047 4.57945 11.2802 4.80366L11.2294 4.84989C10.9675 5.06347 10.5809 5.04774 10.3368 4.80366C10.0767 4.5433 10.0766 4.12122 10.3368 3.86095L10.4143 3.78804ZM5.09917 8.67801C4.68473 8.62096 3.97381 8.61439 3.48524 8.65718L3.29058 8.67801C2.70261 8.75906 2.24423 9.21765 2.15516 9.7952L2.14214 9.91173C2.10767 10.437 2.19594 10.9542 2.40256 11.3343C2.5955 11.6891 2.88945 11.9302 3.35438 11.9886L3.53537 12.0068C3.99075 12.0434 4.64767 12.0373 5.03602 11.9886L5.14149 11.971C5.66169 11.8629 6.07228 11.4538 6.1773 10.9261L6.2118 10.7197C6.27602 10.2392 6.2307 9.76471 6.07248 9.40197C5.91713 9.04599 5.6531 8.78438 5.19357 8.69429L5.09917 8.67801ZM12.7079 8.67801C12.2935 8.62095 11.5826 8.6144 11.094 8.65718L10.8993 8.67801C10.381 8.74939 10.0917 9.0223 9.926 9.40197C9.74517 9.81659 9.71209 10.3774 9.82118 10.9261L9.84592 11.0296C9.99067 11.541 10.4284 11.9214 10.9625 11.9886L11.1441 12.0068C11.5995 12.0434 12.2564 12.0373 12.6447 11.9886L12.8108 11.9586C13.1813 11.8685 13.4277 11.6449 13.5966 11.3343C13.7773 11.0018 13.8669 10.5643 13.8635 10.1083L13.8563 9.91173C13.8174 9.31963 13.3933 8.82966 12.8238 8.69949L12.7079 8.67801Z"
    })),
    Ne = Ks({
        live: {
            id: "odyssey.live",
            defaultMessage: "LIVE"
        },
        search: {
            id: "odyssey.search",
            defaultMessage: "Search"
        },
        restoringDesktop: {
            id: "odyssey.restoringDesktop",
            defaultMessage: "Restoring my virtual desktop..."
        },
        terminal: {
            id: "odyssey.terminal",
            defaultMessage: "Terminal"
        },
        newTab: {
            id: "odyssey.newTab",
            defaultMessage: "New tab"
        },
        libreoffice: {
            id: "odyssey.libreoffice",
            defaultMessage: "LibreOffice"
        },
        reader: {
            id: "odyssey.reader",
            defaultMessage: "Browser"
        },
        readingMode: {
            id: "odyssey.readingMode",
            defaultMessage: "Reading mode"
        },
        imageViewer: {
            id: "odyssey.imageViewer",
            defaultMessage: "Image Viewer"
        },
        stopAgent: {
            id: "odyssey.stopAgent",
            defaultMessage: "Stop agent"
        },
        generatingImage: {
            id: "odyssey.generatingImage",
            defaultMessage: "Generating image"
        }
    }),
    ri = ({
        lines: t = 10,
        speed: e = 5,
        width: o = "100%",
        height: i = 400,
        className: n = ""
    }) => {
        const u = sn() ? 4 : 3,
            a = l.useMemo(() => Array.from({
                length: t + u
            }, () => "".concat(60 + Math.random() * 40, "%")), [t, u]),
            m = "bg-token-bg-tertiary rounded-md h-6",
            f = () => s.jsxs("div", {
                className: "flex shrink-0 flex-col gap-4 pb-4",
                style: {
                    width: "100%",
                    height: i
                },
                children: [s.jsxs("div", {
                    className: "flex w-full flex-row items-start gap-4",
                    children: [s.jsx("div", {
                        style: {
                            width: "25%",
                            aspectRatio: "1 / 1",
                            position: "relative"
                        },
                        children: s.jsx("div", {
                            className: m,
                            style: {
                                position: "absolute",
                                inset: 0,
                                width: "100%",
                                height: "100%"
                            }
                        })
                    }), s.jsx("div", {
                        className: "flex h-full flex-1 flex-col gap-4",
                        style: {
                            height: "100%"
                        },
                        children: Array.from({
                            length: u
                        }).map((x, p) => s.jsx("div", {
                            className: m,
                            style: {
                                width: a[p],
                                flex: 1
                            }
                        }, p))
                    })]
                }), a.slice(u).map((x, p) => s.jsx("div", {
                    className: m,
                    style: {
                        width: x
                    }
                }, p + u))]
            }),
            h = typeof i == "number" ? "".concat(i, "px") : i;
        return l.useEffect(() => {
            const x = document.createElement("style");
            return x.innerHTML = "\n      @keyframes ws-scroll {\n        0% {\n          transform: translateY(calc(-1 * var(--ws-page-h)));\n        }\n        100% {\n          /* Move up exactly one page height */\n          transform: translateY(calc(-2* var(--ws-page-h)));\n        }\n      }\n      .animate-ws-scroll {\n        animation-name: ws-scroll;\n        animation-timing-function: ease-in-out;\n        animation-iteration-count: infinite;\n      }\n    ", document.head.appendChild(x), () => {
                document.head.removeChild(x)
            }
        }, []), s.jsx("div", {
            className: "relative ".concat(n),
            style: {
                width: o,
                height: h
            },
            children: s.jsxs("div", {
                className: "animate-ws-scroll absolute inset-0 flex flex-col",
                style: {
                    "--ws-page-h": h,
                    animationDuration: "".concat(e, "s")
                },
                children: [s.jsx(f, {}), s.jsx(f, {}), " ", s.jsx(f, {}), " "]
            })
        })
    },
    mt = ({
        children: t,
        isKAUR1BR5: e = !1
    }) => s.jsx("div", {
        className: se("bg-token-bg-tertiary flex h-7 w-full flex-row px-1", e ? "h-12 shrink-0" : "pt-1 text-[11px]"),
        children: t
    }),
    ze = ({
        children: t,
        className: e,
        isActive: o = !0,
        isKAUR1BR5: i = !1
    }) => {
        const [n, c] = l.useState(!1);
        l.useEffect(() => {
            c(!0)
        }, []);
        const u = n ? .5 : .8,
            a = i ? .9 : .8,
            m = i ? o ? [a, 1, 1] : a : [a, 1, 1];
        return s.jsx("div", {
            className: se("flex w-full shrink-0 flex-row p-4", e),
            children: s.jsx(le.div, {
                className: "text-token-text-secondary bg-token-bg-primary flex size-full shrink-0 flex-col overflow-hidden rounded-lg shadow-md",
                initial: {
                    opacity: 0,
                    scale: a,
                    y: 20
                },
                animate: {
                    opacity: [0, 1, 1],
                    scale: m,
                    y: [20, 0, 0]
                },
                transition: {
                    delay: u,
                    duration: .55,
                    times: [0, .75, 1],
                    ease: [.16, 1, .3, 1]
                },
                children: t
            })
        })
    };

function li({
    title: t,
    url: e,
    domain: o
}) {
    const {
        formatMessage: i
    } = _e();
    return s.jsxs(ze, {
        children: [s.jsx(mt, {
            children: s.jsx("div", {
                className: "flex w-full flex-row items-center justify-center text-center",
                children: i(Ne.reader)
            })
        }), s.jsx("div", {
            className: "flex flex-1 flex-col bg-black/10 px-16 pt-16",
            children: s.jsx(fn, {
                title: t
            })
        })]
    })
}

function fn({
    title: t
}) {
    const {
        formatMessage: e
    } = _e();
    return s.jsx("div", {
        className: "bg-token-bg-primary justify-top relative flex h-full w-full flex-col items-center rounded-t-xl",
        children: s.jsxs("div", {
            className: "w-full overflow-clip",
            children: [s.jsxs("div", {
                className: "bg-token-bg-primary relative z-2 flex flex-col items-center justify-start rounded-t-xl pt-0 pb-0",
                style: {
                    WebkitMaskImage: "linear-gradient(to top, transparent 0px, black 12px, black 12px, black 100%)",
                    maskImage: "linear-gradient(to top, transparent 0px, black 12px, black 12px, black 100%)"
                },
                children: [s.jsxs("div", {
                    className: "text-token-text-secondary z-2 flex flex-row items-center gap-2 py-2 text-xs font-medium",
                    children: [s.jsx(ai, {
                        className: "text-token-text-secondary size-4"
                    }), e(Ne.readingMode)]
                }), s.jsx("div", {
                    className: "text-token-text-primary z-1 mb-4 line-clamp-3 w-full px-4 text-start text-2xl font-semibold overflow-ellipsis lg:text-3xl",
                    children: t
                })]
            }), s.jsx("div", {
                className: "inset-0 z-0 w-full overflow-visible px-4",
                children: s.jsx(ri, {})
            })]
        })
    })
}

function ci({
    tabMetadata: t,
    signedScreenshotUrl: e,
    newTabTitle: o,
    isReaderMode: i,
    domain: n,
    title: c,
    tetherData: u,
    isKAUR1BR5: a,
    isActive: m,
    serverThreadId: f,
    isStreaming: h
}) {
    var S, N;
    const x = js(e),
        p = i ? n : (S = t == null ? void 0 : t.domain) != null ? S : o,
        y = i ? n : (N = t == null ? void 0 : t.origin) != null ? N : "";
    return s.jsxs(ze, {
        isActive: m,
        isKAUR1BR5: a,
        className: se(a && "p-0!"),
        children: [s.jsx(mt, {
            isKAUR1BR5: a,
            children: a ? s.jsx(di, {
                isReaderMode: i,
                windowBarDomain: p,
                windowBarFaviconUrl: y,
                tetherData: u,
                serverThreadId: f,
                showOpenTabButton: h
            }) : s.jsx(ui, {
                isReaderMode: i,
                windowBarDomain: p,
                windowBarFaviconUrl: y,
                tetherData: u
            })
        }), s.jsxs("div", {
            className: "bg-token-bg-primary dark:bg-token-bg-secondary relative aspect-[1024/697] w-full overflow-hidden rounded-b-lg",
            children: [x && s.jsx("img", {
                src: x,
                alt: "",
                className: "absolute inset-0 h-full w-full object-cover object-bottom"
            }, x), s.jsx(qe, {
                children: i && s.jsx(le.div, {
                    className: "absolute inset-0 flex items-center justify-center overflow-hidden rounded-b-md bg-black/20 backdrop-blur-[2px] dark:bg-black/50",
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    exit: {
                        opacity: 0
                    },
                    transition: {
                        duration: .4
                    },
                    children: s.jsx(le.div, {
                        className: "flex h-full w-full px-8 pt-4 lg:px-16 lg:pt-8",
                        initial: {
                            y: "100%",
                            opacity: 0
                        },
                        animate: {
                            y: 0,
                            opacity: 1
                        },
                        exit: {
                            y: "100%",
                            opacity: 0,
                            transition: {
                                y: {
                                    duration: .6
                                }
                            }
                        },
                        transition: {
                            type: "spring",
                            stiffness: 400,
                            damping: 32
                        },
                        children: s.jsx(fn, {
                            domain: n,
                            title: c
                        })
                    })
                })
            })]
        })]
    })
}

function ui({
    isReaderMode: t,
    windowBarDomain: e,
    windowBarFaviconUrl: o,
    tetherData: i
}) {
    var c;
    const {
        formatMessage: n
    } = _e();
    return s.jsxs("div", {
        className: "bg-token-bg-primary dark:bg-token-bg-secondary relative flex items-center rounded-t-[4px] px-2 shadow-md",
        children: [s.jsxs("div", {
            className: "flex items-center gap-1 text-[10px]",
            children: [s.jsx(Zt, {
                className: "size-3",
                url: t ? (c = i == null ? void 0 : i.url) != null ? c : "" : o != null ? o : "",
                size: 32
            }), s.jsx("span", {
                className: "max-w-16 truncate",
                children: t ? i == null ? void 0 : i.domain : e || n(mn.newTab)
            })]
        }), s.jsx(oi, {
            radius: 4,
            className: "text-token-bg-primary dark:text-token-bg-secondary absolute start-[-4px] bottom-0"
        }), s.jsx(ii, {
            radius: 4,
            className: "text-token-bg-primary dark:text-token-bg-secondary absolute end-[-4px] bottom-0"
        })]
    })
}

function di({
    isReaderMode: t,
    windowBarDomain: e,
    windowBarFaviconUrl: o,
    tetherData: i,
    serverThreadId: n,
    showOpenTabButton: c
}) {
    var m;
    const {
        formatMessage: u
    } = _e(), a = nn();
    return s.jsxs("div", {
        className: "relative flex w-full items-center justify-between px-1.5",
        children: [s.jsxs("div", {
            className: "flex items-center gap-1.5 text-sm",
            children: [s.jsx(Zt, {
                className: "size-5",
                url: t ? (m = i == null ? void 0 : i.url) != null ? m : "" : o != null ? o : "",
                size: 32
            }), s.jsx("span", {
                className: "max-w-32 truncate",
                children: t ? i == null ? void 0 : i.domain : e || u(mn.newTab)
            })]
        }), c && !a && s.jsxs(en, {
            color: "ghost",
            className: "text-token-text-secondary rounded-lg font-normal",
            contentWrapperClassName: "gap-1",
            onClick: () => {
                var f;
                try {
                    const h = An();
                    return (f = h == null ? void 0 : h.tryOpenAgentViewer(n)) != null ? f : !1
                } catch (h) {
                    In.error("Failed to open local agent viewer - error thrown")
                }
            },
            children: [s.jsx(Ce, {
                defaultMessage: "Open tab",
                id: "odyssey.browserWindow.openTab"
            }), s.jsx(to, {
                className: "icon-sm"
            })]
        })]
    })
}
const mn = Ks({
        newTab: {
            defaultMessage: "New tab",
            id: "odyssey.browserWindow.newTab"
        }
    }),
    fi = t => l.createElement("svg", ht({
        width: 48,
        height: 48,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
    }, t), l.createElement("g", {
        filter: "url(#filter0_d_7210_123625)"
    }, l.createElement("path", {
        d: "M10.3791 11.9027C9.5965 9.71137 11.7123 7.59552 13.9037 8.37814L38.9999 17.3411C41.53 18.2447 41.4129 21.862 38.8297 22.6001L29.2361 25.3411C28.3199 25.6029 27.6038 26.319 27.3421 27.2351L24.601 36.8287C23.863 39.4119 20.2457 39.529 19.3421 36.999L10.3791 11.9027Z",
        fill: "black"
    }), l.createElement("path", {
        d: "M8.9668 12.4072C7.7585 9.02399 11.025 5.75752 14.4082 6.96582L39.5049 15.9287C43.4078 17.323 43.2271 22.903 39.2422 24.042L29.6484 26.7832C29.2306 26.9026 28.9036 27.2296 28.7842 27.6475L26.043 37.2412C24.904 41.2261 19.324 41.4068 17.9297 37.5039L8.9668 12.4072Z",
        stroke: "white",
        strokeWidth: 3
    })), l.createElement("defs", null, l.createElement("filter", {
        id: "filter0_d_7210_123625",
        x: 3.31076,
        y: 3.25792,
        width: 44.4195,
        height: 44.4195,
        filterUnits: "userSpaceOnUse",
        colorInterpolationFilters: "sRGB"
    }, l.createElement("feFlood", {
        floodOpacity: 0,
        result: "BackgroundImageFix"
    }), l.createElement("feColorMatrix", { in: "SourceAlpha",
        type: "matrix",
        values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
        result: "hardAlpha"
    }), l.createElement("feOffset", {
        dy: 1.94814
    }), l.createElement("feGaussianBlur", {
        stdDeviation: 1.94814
    }), l.createElement("feComposite", {
        in2: "hardAlpha",
        operator: "out"
    }), l.createElement("feColorMatrix", {
        type: "matrix",
        values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0"
    }), l.createElement("feBlend", {
        mode: "normal",
        in2: "BackgroundImageFix",
        result: "effect1_dropShadow_7210_123625"
    }), l.createElement("feBlend", {
        mode: "normal",
        in: "SourceGraphic",
        in2: "effect1_dropShadow_7210_123625",
        result: "shape"
    })))),
    mi = ({
        text: t,
        cadence: e = .1,
        fadeDuration: o = .5,
        className: i = "",
        numLines: n = 4
    }) => {
        const c = l.useMemo(() => t.trim().split(/\s+/), [t]),
            u = l.useRef(null),
            a = l.useRef([]),
            [m, f] = l.useState(-1),
            [, h] = l.useState([]),
            x = l.useRef([]),
            [p, y] = l.useState(1),
            [S, N] = l.useState(0),
            [R, A] = l.useState(!1),
            [Q, r] = l.useState(0),
            ae = l.useRef(null),
            Z = l.useRef(null),
            b = l.useRef(1),
            me = l.useRef(p);
        l.useEffect(() => {
            me.current = p
        }, [p]);
        const ne = sn();
        l.useEffect(() => {
            f(-1), h([]), x.current = [], x.current[0] = 1, y(1), N(0), A(!1), a.current = [], r(M => M + 1), ae.current = null, Z.current = null, b.current = 1
        }, [t, ne]), l.useEffect(() => {
            if (c.length === 0) return;
            let M, te;
            const G = w => {
                var D, T;
                if (!x.current[w]) {
                    const H = a.current[w];
                    if (H) {
                        const K = H.offsetTop;
                        ae.current == null ? (ae.current = K, Z.current = K, b.current = 1) : K > ((D = Z.current) != null ? D : 0) && (b.current += 1, Z.current = K), x.current[w] = b.current, h([...x.current])
                    }
                }
                f(w);
                const k = (T = x.current[w]) != null ? T : b.current;
                k > me.current && (k <= n ? y(k) : N(k - n)), w < c.length - 1 ? M = window.setTimeout(() => G(w + 1), e * 1e3) : te = window.setTimeout(() => A(!0), (o + 1) * 1e3)
            };
            return G(0), () => {
                clearTimeout(M), clearTimeout(te)
            }
        }, [c, e, o, n, ne]);
        const [_, ce] = l.useState(null);
        En(() => {
            if (u.current && _ == null) {
                const M = parseFloat(getComputedStyle(u.current).lineHeight);
                ce(M)
            }
        }, [_]);
        const ee = _ ? -S * _ : 0,
            oe = S === 0 ? 0 : Math.min(100, e * 500),
            U = {
                lineHeight: "1.4em",
                height: "calc(1.4em * ".concat(Math.min(p, n), ")"),
                transition: "height 0.25s cubic-bezier(0.4, 0, 0.2, 1)"
            };
        return s.jsx("div", {
            className: "cursor-chat-bubble text-token-text-primary border-[hsba(0,0%,5%,0.2) bg-token-bg-elevated-primary w-full overflow-hidden rounded-lg border p-2 text-xs shadow-[0px_20px_25.000001907348633px_-5px_rgba(0,0,0,0.10)] lg:text-sm",
            style: {
                opacity: R || t.length === 0 ? 0 : 1,
                transition: "opacity ".concat(o, "s ease-in-out")
            },
            children: s.jsx("div", {
                ref: u,
                className: "teleprompter ".concat(i),
                style: U,
                children: s.jsx("div", {
                    className: "teleprompter-inner",
                    style: {
                        transform: "translateY(".concat(ee, "px)"),
                        transition: "transform ".concat(oe, "ms linear")
                    },
                    children: c.map((M, te) => {
                        var G;
                        return s.jsxs("span", {
                            ref: w => {
                                a.current[te] = w
                            },
                            style: {
                                opacity: te <= m && ((G = x.current[te]) != null ? G : 1 / 0) > S ? 1 : 0,
                                transition: "opacity ".concat(o, "s"),
                                animation: "none"
                            },
                            className: "teleprompter-word",
                            children: [M, " "]
                        }, te)
                    })
                }, Q)
            })
        })
    },
    pi = 768,
    hi = 1024;

function pn(t, e) {
    return {
        top: t / pi * 100,
        left: e / hi * 100
    }
}

function hn(t) {
    try {
        return new URL(t)
    } catch (e) {
        return null
    }
}

function xn(t) {
    return t ? t.replace(/^www\./, "") : null
}

function Us(t) {
    const e = hn(t),
        o = xn(e == null ? void 0 : e.hostname);
    return {
        domain: o != null ? o : null,
        name: null
    }
}

function xi(t) {
    return t.startsWith("http://localhost:8451/") ? t.replace(/^http:\/\/localhost:8451\//, "") : t
}

function gi(t) {
    const e = t.match(/([^\/]+\.pdf)(?:[?#].*)?$/i);
    return e ? e[1] : null
}

function Gs(t, e) {
    var m;
    let o = t != null ? t : "",
        i = e != null ? e : null;
    const n = /\.pdf(?:[?#].*)?$/i.test(t),
        c = t.startsWith("http://localhost:8451/");
    if (n || c) {
        const f = xi(t);
        o = f;
        const h = gi(f);
        h && (i = h)
    }
    const u = hn(o),
        a = (m = xn(u == null ? void 0 : u.hostname)) != null ? m : null;
    return {
        tetherUrl: o,
        tetherTitle: i,
        domain: a
    }
}
const yi = 120,
    bi = 1.2,
    wi = "right",
    ji = .2,
    vi = .75,
    Fs = .08,
    Ci = 100,
    _i = 80,
    ki = 1.2,
    zt = (t = 0) => new Promise(e => setTimeout(e, t));

function Ti(t, e = 120) {
    const [o, i] = rs.useState(t), [n, c] = rs.useState(!1);
    return rs.useEffect(() => {
        c(!0);
        const u = setTimeout(() => {
            i(t), c(!1)
        }, e);
        return () => clearTimeout(u)
    }, [t, e]), [o, n]
}
const Si = ({
        top: t,
        left: e,
        params: o = {},
        text: i,
        actions: n,
        isKAUR1BR5: c
    }) => {
        const {
            forearmLength: u = yi,
            speed: a = bi,
            handBias: m = wi,
            curveFactor: f = ji,
            shortMoveSlowdown: h = .8,
            slowDistance: x = 100,
            dragSlowdown: p = ki
        } = o, [y, S] = l.useState({
            x: e,
            y: t
        }), N = Ms(1), R = Ms(0), A = l.useRef(null), Q = l.useRef(y), r = l.useRef({
            p0: y,
            p1: y,
            p2: y
        }), ae = (w, k, D, T) => {
            const H = 1 - T;
            return {
                x: H * H * w.x + 2 * H * T * k.x + T * T * D.x,
                y: H * H * w.y + 2 * H * T * k.y + T * T * D.y
            }
        }, Z = l.useRef(1), b = l.useRef(!1), me = Ls(R, w => {
            const {
                p0: k,
                p1: D,
                p2: T
            } = r.current;
            return "".concat(ae(k, D, T, w).x, "%")
        }), ne = Ls(R, w => {
            const {
                p0: k,
                p1: D,
                p2: T
            } = r.current;
            return "".concat(ae(k, D, T, w).y, "%")
        }), [_, ce] = Ti(i, 150), ee = ce ? "" : _, {
            x: oe,
            y: U,
            refs: {
                setReference: M,
                setFloating: te
            },
            strategy: G
        } = Mn({
            placement: "right-start",
            whileElementsMounted: (w, k, D) => On(w, k, D, {
                animationFrame: !0
            }),
            middleware: [Ln({
                mainAxis: 4,
                crossAxis: 24
            }), Rn({
                padding: 8,
                crossAxis: !0
            })]
        });
        return l.useEffect(() => {
            var ye;
            const w = y,
                k = Q.current;
            if (w.x === k.x && w.y === k.y) {
                (ye = A.current) == null || ye.call(A), A.current = null;
                return
            }
            const D = w.x - k.x,
                T = w.y - k.y,
                H = Math.hypot(D, T),
                K = {
                    x: k.x + D / 2,
                    y: k.y + T / 2
                },
                F = (() => {
                    const pe = {
                            x: -T,
                            y: D
                        },
                        be = Math.hypot(pe.x, pe.y) || 1;
                    return {
                        x: pe.x / be,
                        y: pe.y / be
                    }
                })(),
                X = (D >= 0 ? 1 : -1) * (m === "right" ? 1 : -1),
                ue = Math.min(u, H / 1.5) * f * X,
                de = {
                    x: K.x + F.x * ue,
                    y: K.y + F.y * ue
                };
            r.current = {
                p0: k,
                p1: de,
                p2: w
            };
            const Ie = Math.max(_i / 1e3, H / (a * 120)) * Z.current,
                V = 1 + h * Math.max(0, 1 - H / x),
                Ee = Ie * V;
            R.stop(), R.set(0);
            const De = ls(R, 1, {
                duration: Ee,
                ease: b.current ? "linear" : [.42, 0, .58, 1],
                onComplete: () => {
                    var pe;
                    (pe = A.current) == null || pe.call(A), A.current = null
                }
            });
            return Q.current = w, () => De.stop()
        }, [y, u, a, m, f, h, x, R]), l.useEffect(() => {
            if (!n || n.length === 0) return;
            const w = n.filter(F => ["click", "move", "drag"].includes(F.action));
            if (w.length === 0) return;
            const k = (F, X) => {
                    const {
                        top: re,
                        left: ue
                    } = pn(X, F);
                    return new Promise(de => {
                        if (Q.current.x === ue && Q.current.y === re) {
                            zt().then(de);
                            return
                        }
                        A.current = de, S({
                            x: ue,
                            y: re
                        })
                    })
                },
                D = async () => {
                    await ls(N, vi, {
                        duration: Fs
                    }).finished
                },
                T = async () => {
                    await ls(N, 1, {
                        duration: Fs
                    }).finished
                },
                H = async () => {
                    await D(), await zt(Ci), await T()
                };
            let K = !1;
            return (async () => {
                try {
                    for (const F of w) {
                        if (b.current = !1, K) break;
                        switch (F.action) {
                            case "click":
                                {
                                    const X = F;await k(X.x, X.y),
                                    await zt(200),
                                    await H();
                                    break
                                }
                            case "move":
                                {
                                    const X = F;await k(X.x, X.y);
                                    break
                                }
                            case "drag":
                                {
                                    const X = F;
                                    if (X.path.length === 0) break;
                                    const [re, ...ue] = X.path;await k(re[0], re[1]),
                                    await zt(100),
                                    await D(),
                                    b.current = !0,
                                    Z.current = p;
                                    for (let de = 0; de < ue.length; de++) {
                                        const [Ie, V] = ue[de];
                                        de === ue.length - 1 && (Z.current = 1, b.current = !1), await k(Ie, V)
                                    }
                                    await T();
                                    break
                                }
                            default:
                                break
                        }
                    }
                } catch (F) {
                    nt.addError(F)
                }
            })(), () => {
                K = !0
            }
        }, [n, N, p]), s.jsx("div", {
            className: se("absolute inset-0", c ? "mt-2" : "m-4 mb-12"),
            children: s.jsx("div", {
                className: se("relative", c ? "aspect-[1024/777]" : "aspect-[1024/755]"),
                children: s.jsxs("div", {
                    className: "absolute inset-0",
                    children: [s.jsx(le.div, {
                        ref: M,
                        style: {
                            left: me,
                            top: ne,
                            scale: N
                        },
                        className: "pointer-events-none absolute z-10 -translate-x-[30%] -translate-y-[55%]",
                        children: s.jsx(fi, {
                            className: "size-6"
                        })
                    }), s.jsx("div", {
                        ref: te,
                        className: "pointer-events-none absolute z-9 flex w-[240px] items-center justify-center lg:w-[320px]",
                        style: {
                            position: G,
                            top: U != null ? U : 0,
                            left: oe != null ? oe : 0
                        },
                        children: s.jsx(mi, {
                            text: ee
                        })
                    })]
                })
            })
        })
    },
    Ni = ({
        searchQuery: t,
        searchResults: e
    }) => {
        const [i, n] = l.useState(""), [c, u] = l.useState(null), a = l.useRef(null);
        l.useEffect(() => {
            let f = !1;
            const h = p => new Promise(y => setTimeout(y, p));
            return (async () => {
                if (await h(1e3), f) return;
                n(""), u(null);
                const p = [...t],
                    y = p.length ? 1e3 / p.length : 1e3;
                for (let S = 1; S <= p.length; S++) {
                    if (f) return;
                    n(t.slice(0, S)), await h(y)
                }
                if (!f && (u(e), await h(3e3), !f && a.current)) {
                    const S = Math.floor(Math.random() * 90) + 10,
                        N = (a.current.scrollHeight - a.current.clientHeight) * (S / 100);
                    a.current.scrollBy({
                        top: N,
                        behavior: "smooth"
                    })
                }
            })(), () => {
                f = !0
            }
        }, [t, e]);
        const m = _e();
        return s.jsxs(ze, {
            className: "flex flex-col p-10",
            children: [s.jsx("div", {
                className: "border-token-border-default border-b p-2",
                children: s.jsxs("div", {
                    className: "relative",
                    children: [s.jsx(Pn, {
                        className: "icon text-token-text-primary absolute start-2 top-1/2 mt-[1px] size-4 -translate-y-1/2"
                    }), s.jsx("input", {
                        type: "text",
                        className: "text-token-text-primary text-s w-full border-none bg-transparent px-2 py-1 ps-7 outline-none focus:ring-0",
                        value: i,
                        placeholder: m.formatMessage(so.searchPlaceholder),
                        readOnly: !0,
                        tabIndex: -1
                    })]
                })
            }), s.jsx("div", {
                ref: a,
                className: "flex flex-1 flex-col gap-4 overflow-auto px-4 py-4",
                children: s.jsx(qe, {
                    initial: !1,
                    children: c == null ? void 0 : c.map((f, h) => {
                        var x;
                        return s.jsxs(le.div, {
                            layout: !0,
                            initial: {
                                opacity: 0,
                                y: 10
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            exit: {
                                opacity: 0
                            },
                            transition: {
                                delay: h * .06,
                                duration: .25
                            },
                            className: "mb-2 flex max-w-full flex-col",
                            children: [s.jsxs("a", {
                                className: "text-token-text-secondary flex max-w-full items-center gap-1 text-xs",
                                href: f.rawUrl,
                                target: "_blank",
                                rel: "noopener noreferrer",
                                children: [s.jsx("div", {
                                    className: "flex w-5 shrink-0 items-center justify-start",
                                    children: s.jsx(Zt, {
                                        className: "size-4",
                                        url: (x = f.rawUrl) != null ? x : "",
                                        size: 128
                                    })
                                }), s.jsx("div", {
                                    className: "flex min-w-0 flex-1 flex-row items-center gap-1",
                                    children: f.url
                                })]
                            }), s.jsx("span", {
                                className: "text-token-text-secondary text-s mt-1 truncate",
                                children: f.title
                            })]
                        }, h)
                    })
                })
            })]
        })
    },
    Ai = Do.define([{
        tag: Ze.keyword,
        color: "#C280DF"
    }, {
        tag: Ze.string,
        color: "#A1C281"
    }, {
        tag: Ze.number,
        color: "#C99C6E"
    }, {
        tag: Ze.bool,
        color: "#DFC184"
    }, {
        tag: Ze.comment,
        color: "#5C6370",
        fontStyle: "italic"
    }, {
        tag: Ze.variableName,
        color: "#D27378"
    }, {
        tag: Ze.operator,
        color: "#73ABE5"
    }, {
        tag: Ze.invalid,
        color: "#FFFFFF"
    }]),
    Gt = "chatgpt-agent % ",
    bs = "cm-input-line",
    gn = "cm-input-prefix",
    Ii = () => l.useMemo(() => ys.theme({
        "&": {
            color: "#B0B6C3",
            backgroundColor: "#292C33",
            fontSize: "10px",
            height: "100%",
            width: "100%"
        },
        ".cm-content": {
            caretColor: "#528BFF"
        },
        ".cm-cursor, .cm-dropCursor": {
            borderLeftColor: "#528BFF"
        },
        ".cm-selected": {
            backgroundColor: "#3E4451"
        },
        ".cm-gutters": {
            backgroundColor: "#21252B",
            display: "none"
        },
        ".cm-editor, .cm-scroller": {
            height: "100%"
        },
        ".cm-scroller": {
            overflow: "auto"
        },
        ".cm-line": {
            whiteSpace: "pre"
        },
        [".".concat(bs, " *")]: {
            color: "#B0B6C3 !important"
        },
        [".".concat(bs, " .").concat(gn)]: {
            color: "#73ABE5 !important"
        },
        ".cm-content, .cm-line": {
            fontWeight: 600,
            textRendering: "optimizeLegibility",
            WebkitFontSmoothing: "antialiased"
        }
    }, {
        dark: !0
    }), []),
    Ei = dn.line({
        class: bs
    }),
    Mi = dn.mark({
        class: gn
    }),
    Li = Wo.fromClass(class {
        constructor(t) {
            Es(this, "decorations");
            this.decorations = this.build(t)
        }
        update(t) {
            (t.docChanged || t.viewportChanged) && (this.decorations = this.build(t.view))
        }
        build(t) {
            const e = new Bo;
            for (const {
                    from: o,
                    to: i
                } of t.visibleRanges) {
                let n = o;
                for (; n <= i;) {
                    const c = t.state.doc.lineAt(n);
                    c.text.startsWith(Gt) && (e.add(c.from, c.from, Ei), e.add(c.from, c.from + Gt.length, Mi)), n = c.to + 1
                }
            }
            return e.finish()
        }
    }, {
        decorations: t => t.decorations
    });

function Ri({
    title: t,
    code: e
}) {
    const o = l.useRef(null),
        i = l.useRef(null),
        {
            docInstant: n,
            docDelayed: c,
            needsDelay: u
        } = l.useMemo(() => {
            const m = e.map(f => f.type === "input" ? "".concat(Gt).concat(f.content) : f.content).join("\n");
            return e.length > 0 && e[e.length - 1].type === "input" ? {
                docInstant: m,
                docDelayed: "".concat(m, "\n"),
                needsDelay: !0
            } : {
                docInstant: "".concat(m, "\n").concat(Gt),
                docDelayed: "",
                needsDelay: !1
            }
        }, [e]),
        a = Ii();
    return l.useEffect(() => {
        !o.current || i.current || (i.current = new ys({
            state: Vo.create({
                doc: n,
                extensions: [Po.define(Ho), $o(Ai), ys.editable.of(!1), a, Li]
            }),
            parent: o.current
        }))
    }, [n, a]), l.useEffect(() => {
        const m = i.current;
        if (m) {
            if (m.dispatch({
                    changes: {
                        from: 0,
                        to: m.state.doc.length,
                        insert: n
                    }
                }), u) {
                const f = setTimeout(() => {
                    m.dispatch({
                        changes: {
                            from: 0,
                            to: m.state.doc.length,
                            insert: c
                        }
                    }), m.scrollDOM.scrollTop = m.scrollDOM.scrollHeight
                }, 500);
                return () => clearTimeout(f)
            }
            requestAnimationFrame(() => {
                m.scrollDOM.scrollTop = m.scrollDOM.scrollHeight
            })
        }
    }, [n, c, u]), s.jsxs(ze, {
        children: [s.jsx(mt, {
            children: s.jsx("div", {
                className: "flex w-full flex-row items-center justify-center text-center",
                children: t
            })
        }), s.jsx("div", {
            className: "flex flex-1 bg-[#282C34]",
            style: {
                minHeight: 0
            },
            children: s.jsx("div", {
                ref: o,
                className: "h-full w-full flex-1",
                style: {
                    minHeight: 0
                }
            })
        })]
    })
}
const Oi = ({
        id: t,
        children: e,
        content: o,
        side: i = "bottom",
        sideOffset: n = 4,
        align: c = "center",
        className: u,
        triggerClassName: a,
        dismissOnOutsideClick: m = !0,
        allowReopen: f = !1
    }) => {
        const h = "only-once-tooltip-dismissed:".concat(t),
            [x, p] = l.useState(!1),
            y = l.useRef(!1);
        l.useEffect(() => {
            if (!y.current) {
                y.current = !0;
                try {
                    localStorage.getItem(h) === "true" || p(!0)
                } catch (N) {
                    p(!0)
                }
            }
        }, [h]);
        const S = N => {
            if (N) {
                if (!f) try {
                    if (localStorage.getItem(h) === "true") return
                } catch (R) {}
                p(!0);
                return
            }
            try {
                localStorage.setItem(h, "true")
            } catch (R) {}
            p(!1)
        };
        return s.jsxs(no, {
            open: x,
            onOpenChange: S,
            children: [s.jsx(oo, {
                asChild: !0,
                className: a,
                children: s.jsx("span", {
                    children: e
                })
            }), s.jsx(io, {
                children: s.jsxs(ao, {
                    side: i,
                    sideOffset: n,
                    align: c,
                    onPointerDownOutside: m ? void 0 : N => N.preventDefault(),
                    updatePositionStrategy: "always",
                    className: se("animate-slideLeftAndFade z-30 rounded-xl border bg-blue-400 p-4 text-white shadow-sm", u),
                    children: [o, s.jsx(ro, {
                        asChild: !0,
                        children: s.jsx("div", {
                            className: "relative top-[-6px] h-3 w-3 rotate-45 transform rounded-ee-sm bg-blue-400"
                        })
                    })]
                })
            })]
        })
    },
    Zs = "shadow-[0_5px_8px_3px_rgba(0,0,0,0.05),_0_0.5px_1px_0px_rgba(0,0,0,0.09)] outline outline-[0.5px] outline-black/5";

function Pi() {
    return s.jsx("div", {
        className: "flex items-center justify-center gap-1",
        children: [0, 1, 2].map(t => s.jsx("div", {
            className: "bg-token-border-heavy animate-dot-fade h-[6px] w-[6px] rounded-full opacity-50",
            style: {
                animationDelay: "".concat(t * .2, "s")
            }
        }, t))
    })
}
const yn = 52,
    $i = {
        hidden: {
            opacity: 0,
            scale: .8
        },
        visible: {
            opacity: 1,
            scale: 1,
            transition: {
                type: "spring",
                stiffness: 260,
                damping: 20
            }
        }
    },
    Di = {
        initial: () => ({
            x: 0
        }),
        animate: t => ({
            x: t ? yn : 0,
            transition: {
                type: "spring",
                stiffness: 260,
                damping: 20
            }
        })
    },
    Hi = {
        initial: {
            opacity: 0,
            scale: .8,
            x: 0
        },
        animate: {
            opacity: 1,
            scale: 1,
            x: -yn,
            transition: {
                type: "spring",
                stiffness: 260,
                damping: 20
            }
        },
        exit: {
            opacity: 0,
            scale: .8,
            x: 0
        }
    },
    Vi = ({
        connector: t,
        action: e,
        connectorFetchResult: o,
        connectorSearchResults: i
    }) => {
        const n = _e(),
            c = $n(),
            u = l.useMemo(() => e ? To({
                action: e,
                source: t != null ? t : void 0,
                intl: n
            }) : null, [e, t, n]);
        let a = c ? t == null ? void 0 : t.logo_url_dark : t == null ? void 0 : t.logo_url;
        return c && !a && (a = t == null ? void 0 : t.logo_url), s.jsxs(ze, {
            className: "p-12",
            children: [s.jsx(mt, {
                children: s.jsx("div", {
                    className: "flex w-full flex-row items-center justify-center gap-2 text-center",
                    children: s.jsx(Ce, {
                        id: "cua.cot.agent.connectors",
                        defaultMessage: "Connectors"
                    })
                })
            }), s.jsxs("div", {
                className: "flex w-full flex-1 flex-col items-center justify-center gap-4",
                children: [s.jsxs("div", {
                    className: "relative h-16 w-32",
                    children: [s.jsx(qe, {
                        children: a && s.jsx(le.div, {
                            className: "absolute inset-0 flex items-center justify-center",
                            variants: Hi,
                            initial: "initial",
                            animate: "animate",
                            exit: "exit",
                            children: s.jsx("div", {
                                className: se("bg-token-bg-elevated-primary rounded-lg p-2", Zs),
                                children: s.jsx("img", {
                                    src: a,
                                    alt: t == null ? void 0 : t.name,
                                    className: "h-8 w-8 select-none"
                                })
                            })
                        })
                    }), s.jsx(qe, {
                        children: a && s.jsx(le.div, {
                            className: "absolute inset-0 flex items-center justify-center",
                            variants: $i,
                            initial: "hidden",
                            animate: "visible",
                            exit: "hidden",
                            children: s.jsx(Pi, {})
                        })
                    }), s.jsx(le.div, {
                        className: "absolute inset-0 z-10 flex items-center justify-center",
                        variants: Di,
                        custom: a,
                        initial: "initial",
                        animate: "animate",
                        children: s.jsx("div", {
                            className: se("bg-token-bg-elevated-primary rounded-lg p-3", Zs),
                            children: s.jsx(zo, {
                                className: "text-token-text-primary h-6 w-6",
                                matchTextColor: !0
                            })
                        })
                    })]
                }), s.jsx("div", {
                    className: "relative z-10 h-6 w-full",
                    children: s.jsx(qe, {
                        mode: "sync",
                        children: s.jsx(le.div, {
                            className: "text-token-text-secondary pointer-events-none absolute inset-0 flex items-center justify-center text-center text-sm font-medium",
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            exit: {
                                opacity: 0
                            },
                            transition: {
                                duration: .25
                            },
                            children: u
                        }, u)
                    })
                }), t && (o || i) && s.jsx("div", {
                    className: "flex w-full flex-col items-center justify-center px-8",
                    children: s.jsx(Wi, {
                        connectorFetchResult: o,
                        connectorSearchResults: i,
                        action: e
                    })
                })]
            })]
        })
    },
    Wi = ({
        connectorFetchResult: t,
        connectorSearchResults: e,
        action: o
    }) => {
        const i = [];
        let n = [];
        if (o === "n7jupd_cs" && e) n = e.map(u => ({
            entries: [{
                url: u.url,
                title: u.title,
                snippet: "",
                attribution: u.title
            }]
        }));
        else if (o === "n7jupd_cf" && t) n = [{
            entries: [{
                url: t == null ? void 0 : t.url,
                title: t == null ? void 0 : t.title,
                snippet: "",
                attribution: t == null ? void 0 : t.title
            }]
        }];
        else return null;
        const c = {
            type: z.Search,
            queries: i,
            sources: n
        };
        return s.jsx(So, {
            chunk: c,
            isExpanded: !0,
            isComplete: !0,
            useCloudDocIcons: !0,
            isSmall: !1,
            isVisualCoT: !0
        })
    },
    Bi = "gxcrJW_blur",
    zi = "gxcrJW_blurStack",
    Ui = "gxcrJW_frostedContainer",
    Gi = "gxcrJW_layer0",
    Fi = "gxcrJW_layer1",
    Zi = "gxcrJW_layer2",
    qi = "gxcrJW_layer3",
    Ji = "gxcrJW_layer4",
    Qi = "gxcrJW_layer5",
    ge = {
        blur: Bi,
        blurStack: zi,
        frostedContainer: Ui,
        layer0: Gi,
        layer1: Fi,
        layer2: Zi,
        layer3: qi,
        layer4: Ji,
        layer5: Qi
    };

function Xi({
    file_id: t,
    title: e,
    clientThreadId: o
}) {
    const [i, n] = l.useState(!1), c = on(o), {
        data: u
    } = Fo(!0, c, t, void 0, () => {});
    return s.jsx("div", {
        className: "bg-token-bg-tertiary flex h-full w-full flex-col items-center justify-center",
        children: s.jsxs("div", {
            className: "".concat(ge.frostedContainer, " relative flex h-full w-full flex-row items-center justify-center text-center text-sm"),
            children: [s.jsx("div", {
                className: "text-token-text-secondary absolute top-0 z-10 flex w-full flex-row items-center justify-center py-2 text-xs font-medium",
                children: e
            }), !i && s.jsx("img", {
                src: u == null ? void 0 : u.download_url,
                alt: "",
                className: "h-full w-full object-cover",
                onError: () => n(!0)
            }), s.jsxs("div", {
                className: ge.blurStack,
                children: [s.jsx("div", {
                    className: "".concat(ge.blur, " ").concat(ge.layer0)
                }), s.jsx("div", {
                    className: "".concat(ge.blur, " ").concat(ge.layer1)
                }), s.jsx("div", {
                    className: "".concat(ge.blur, " ").concat(ge.layer2)
                }), s.jsx("div", {
                    className: "".concat(ge.blur, " ").concat(ge.layer3)
                }), s.jsx("div", {
                    className: "".concat(ge.blur, " ").concat(ge.layer4)
                }), s.jsx("div", {
                    className: "".concat(ge.blur, " ").concat(ge.layer5)
                })]
            })]
        })
    })
}
const Yi = ({
        file_id: t,
        title: e,
        clientThreadId: o,
        prompt: i
    }) => {
        const {
            formatMessage: n
        } = _e();
        return t ? s.jsx(ze, {
            children: s.jsx("div", {
                className: "flex min-h-0 w-full flex-1 flex-col items-center justify-center",
                children: s.jsx(Xi, {
                    file_id: t,
                    title: e,
                    clientThreadId: o
                })
            })
        }) : s.jsx(ze, {
            children: s.jsxs("div", {
                className: "bg-token-bg-tertiary flex h-full flex-col items-center justify-center",
                children: [s.jsx("div", {
                    className: "flex w-full flex-row items-center justify-center py-2 text-center text-xs",
                    children: n(Ne.generatingImage)
                }), s.jsxs("div", {
                    className: "flex min-h-0 w-full flex-1 flex-col items-center justify-center gap-4",
                    children: [s.jsx(Uo, {
                        children: s.jsx(Go, {
                            matchTextColor: !0
                        })
                    }), s.jsx("div", {
                        className: "text-token-text-secondary line-clamp-5 px-12 text-center text-xs italic",
                        children: i
                    })]
                })]
            })
        })
    },
    Ki = ({
        signedScreenshotUrl: t
    }) => {
        const {
            formatMessage: e
        } = _e(), o = js(t);
        return s.jsxs(ze, {
            children: [s.jsx(mt, {
                children: s.jsx("div", {
                    className: "flex w-full flex-row items-center justify-center text-center",
                    children: e(Ne.imageViewer)
                })
            }), s.jsx("div", {
                className: "flex min-h-0 w-full flex-1 flex-col items-center justify-center",
                children: o && s.jsx("img", {
                    src: o,
                    alt: "",
                    className: "max-h-full object-contain"
                })
            })]
        })
    };

function ea({
    signedScreenshotUrl: t
}) {
    const {
        formatMessage: e
    } = _e(), o = js(t);
    return s.jsxs(ze, {
        children: [s.jsx(mt, {
            children: s.jsx("div", {
                className: "flex w-full flex-row items-center justify-center text-center",
                children: e(Ne.libreoffice)
            })
        }), o && s.jsx("div", {
            className: "bg-primary relative aspect-[1024/768] w-full overflow-hidden rounded-b-lg",
            children: s.jsx("img", {
                src: o,
                alt: "",
                className: "absolute inset-0 h-full w-full object-cover object-bottom"
            }, o)
        })]
    })
}
const $e = t => typeof t == "object" && t != null,
    Ae = t => typeof t == "number",
    vs = t => typeof t == "string",
    ta = t => $e(t) && t.action === "drag" && Array.isArray(t.path) && t.path.every(e => Ae(e[0]) && Ae(e[1])),
    sa = t => $e(t) && t.action === "move" && Ae(t.x) && Ae(t.y),
    na = t => $e(t) && t.action === "scroll" && Ae(t.x) && Ae(t.y) && Ae(t.scroll_y) && Ae(t.scroll_x),
    oa = t => $e(t) && t.action === "click" && Ae(t.x) && Ae(t.y) && Ae(t.button),
    ia = t => $e(t) && t.action === "type" && vs(t.text),
    aa = t => $e(t) && t.action === "keypress" && Array.isArray(t.keys) && t.keys.every(vs),
    ra = t => $e(t) && t.action === "wait",
    la = t => na(t) || oa(t) || ia(t) || aa(t) || ra(t) || ta(t) || sa(t),
    ca = t => $e(t) && t.action === "search_with_snippets" && Array.isArray(t.queries) && t.queries.every(vs),
    ua = t => ca(t);

function da(t) {
    const e = t.indexOf("{");
    if (e < 0) return;
    let o;
    try {
        o = JSON.parse(t.slice(e))
    } catch (n) {
        nt.addError(n);
        return
    }
    if (!$e(o) || !Array.isArray(o.actions)) return;
    const i = o.actions.filter(la);
    return i.length > 0 ? {
        actions: i
    } : void 0
}

function qs(t) {
    let e;
    try {
        e = JSON.parse(t != null ? t : "{}")
    } catch (i) {
        nt.addError(i);
        return
    }
    if (!$e(e) || !Array.isArray(e.actions)) return;
    const o = e.actions.filter(ua);
    return o.length > 0 ? {
        actions: o
    } : void 0
}
const fa = ({
        value: t,
        max: e,
        isPlaying: o,
        onChange: i,
        onPlayPause: n,
        onRestart: c,
        onLive: u,
        isLive: a,
        isComplete: m,
        isKAUR1BR5: f
    }) => {
        const {
            formatMessage: h
        } = _e(), x = nn(), p = Dn();
        return x || p ? null : s.jsxs("div", {
            className: se("z-10 flex w-full items-center gap-2 px-4 py-0 pb-4 text-xs select-none", f ? "absolute bottom-0 opacity-0 transition-opacity duration-300 group-hover:opacity-100" : "relative"),
            children: [s.jsx("div", {
                className: se("absolute start-0 w-full bg-gradient-to-t from-gray-950/90 to-gray-500/0", f ? "-top-5 h-20" : "top-0 h-16")
            }), m && s.jsx("button", {
                className: "border-token-border-light hover:bg-token-surface-primary/20 relative z-10 rounded text-white",
                onClick: a ? c : n,
                children: o ? s.jsx(lo, {
                    className: "size-4"
                }) : a ? s.jsx(Zo, {
                    className: "size-4"
                }) : s.jsx(co, {
                    className: "size-4"
                })
            }), s.jsxs(uo, {
                className: "group relative flex flex-1 items-center",
                min: 0,
                max: e,
                step: 1,
                value: [t],
                onValueChange: ([y]) => i(y),
                children: [s.jsx(fo, {
                    className: "relative h-[4px] w-full grow cursor-pointer rounded-full bg-black/20",
                    children: s.jsx(mo, {
                        className: "absolute h-full rounded-full bg-white/90"
                    })
                }), s.jsx(po, {
                    className: "touch:h-3 touch:w-3 relative block h-1.5 w-1.5 scale-100 cursor-pointer rounded-full border bg-white shadow-md transition-transform group-hover:scale-200 before:pointer-events-auto before:absolute before:inset-[-12px] before:rounded-full before:bg-transparent before:content-[''] focus:outline-none"
                })]
            }), !m && s.jsx("span", {
                className: se("z-1 cursor-pointer font-medium text-white uppercase opacity-50", a && "text-gray-500 opacity-100"),
                onClick: u,
                children: h(Ne.live)
            })]
        })
    },
    Js = "file:///home/oai/redirect.html",
    ma = 0,
    Qs = 35,
    Xs = 20;

function ms(t, e) {
    const {
        cursorTop: o,
        cursorLeft: i
    } = t;
    return o < e.top || o > e.top + e.height || i < e.left || i > e.left + e.width ? (t.cursorTop = Math.random() * e.height + e.top, t.cursorLeft = Math.random() * e.width + e.left, !0) : !1
}
const ps = {
        image_viewer: {
            top: 80,
            left: 0,
            width: 100,
            height: 20
        },
        api_tool: {
            top: 0,
            left: 50,
            width: 50,
            height: 10
        }
    },
    pa = (t, e, o) => {
        var m, f, h, x, p, y, S, N, R, A, Q, r, ae, Z, b, me, ne, _, ce, ee, oe, U, M, te, G, w, k, D, T, H, K, F, X, re, ue, de, Ie, V, Ee, De, ye, pe, be, Ue, Je, L, He, Qe, Me, Xe, Ye, Ke, W, he, fe, O, I, ke, we, Ve, Le;
        let i = 0;
        const {
            message: n,
            groupType: c
        } = e;
        let u = !1;
        const a = d => {
            const g = t.openApps.indexOf(d);
            g !== -1 ? t.currentWindowIndex = g : (t.openApps.push(d), t.currentWindowIndex = t.openApps.length - 1)
        };
        switch (c) {
            case je.StructuredThoughts:
                break;
            case je.CodeInterpreter:
                if (a("terminal"), n.author.role === "tool" && n.author.name === "container.exec" && n.content.content_type === "text") {
                    const d = n.content.parts.map(g => ({
                        type: "output",
                        content: g
                    }));
                    t.code.push(...d)
                } else if (n.author.role === "assistant" && n.recipient === "python" && n.content.content_type === "code") {
                    const d = (m = n.content.text) != null ? m : "";
                    t.code.push({
                        type: "input",
                        content: "python <<EOF\n".concat(d, "\nEOF\n")
                    })
                } else if (n.author.role === "tool" && n.author.name === "python" && n.content.content_type === "execution_output") {
                    const d = (f = n.content.text) != null ? f : "";
                    t.code.push({
                        type: "output",
                        content: d
                    })
                } else if (n.author.role === "assistant" && n.recipient === "container.exec" && n.content.content_type === "code") try {
                    const d = JSON.parse(n.content.text).cmd;
                    t.code.push({
                        type: "input",
                        content: d.join(" ")
                    })
                } catch (d) {
                    nt.addError(d)
                }
                i = 2e3;
                break;
            case je.n7jupd:
                if (n.content.content_type === Be.ComputerOutput) {
                    const d = (x = (h = n.metadata) == null ? void 0 : h.n7jupd_v) == null ? void 0 : x.title,
                        g = (y = (p = n.metadata) == null ? void 0 : p.n7jupd_v) == null ? void 0 : y.application,
                        C = as(ht({}, n.content.screenshot), {
                            vmMetadata: (S = n.metadata) == null ? void 0 : S.n7jupd_v,
                            messageId: n.id
                        });
                    g === "Browser" ? (t.isReaderMode = !1, a("browser"), t.screenshots.push(C)) : g != null && g.startsWith("LibreOffice") || g != null && g.startsWith("Select a Template") ? (t.isReaderMode = !1, a("libreoffice"), t.libreOfficeScreenshots.push(C)) : (t.isReaderMode = !1, a("browser"), t.screenshots.push(C)), t.tabMetadata = cn(C), t.computerApplication = g != null ? g : null, t.computerTitle = d != null ? d : null, i = 2e3
                }
                if (n.content.content_type === Be.StructuredThoughts && (t.thought = n.content.thoughts.map(d => d.content).join(""), i = 1e3), n.recipient !== "computer.switch_app") {
                    if ((N = n.recipient) != null && N.includes("computer") && n.content.content_type === Be.Code) {
                        const d = n.content.text,
                            g = da(d);
                        t.actions = (R = g == null ? void 0 : g.actions) != null ? R : [], i = 1e3, g && (g.actions.forEach(C => {
                            switch (C.action) {
                                case "click":
                                    {
                                        u = !0;
                                        const {
                                            top: B,
                                            left: P
                                        } = pn(C.y, C.x);t.cursorTop = B,
                                        t.cursorLeft = P,
                                        t.isCursorInInitialPosition = !1,
                                        i += 1e3;
                                        break
                                    }
                                case "type":
                                    break;
                                case "scroll":
                                    break;
                                case "keypress":
                                    break;
                                case "wait":
                                    break;
                                case "move":
                                    break;
                                case "drag":
                                    i += 1e3;
                                    break
                            }
                        }), i = Math.min(i, 4e3))
                    }
                }
                break;
            case je.n7jupd_x:
                if (n.author.role === "assistant" && n.content.content_type === Be.Code) {
                    const d = qs(n.content.text),
                        g = d == null ? void 0 : d.actions.find(C => C.action === "search_with_snippets" && C.queries.length);
                    g && (a("search"), t.searchResults = null, t.searchQuery = g.queries.join(" || "), i = 1e3)
                } else if (n.author.name === "browser.search") {
                    a("search");
                    const d = (ae = (r = (Q = (A = n.metadata) == null ? void 0 : A.n7jupd_title) == null ? void 0 : Q.match(/`(.*)`/)) == null ? void 0 : r[1]) != null ? ae : "",
                        g = (b = (Z = n.metadata) == null ? void 0 : Z.n7jupd_titles) == null ? void 0 : b.map((C, B) => {
                            var $, xe, Te;
                            const P = (Te = (xe = ($ = n.metadata) == null ? void 0 : $.n7jupd_urls) == null ? void 0 : xe[B]) != null ? Te : "",
                                {
                                    domain: E
                                } = Us(P);
                            return {
                                title: C,
                                url: E != null ? E : void 0,
                                name: void 0,
                                rawUrl: P
                            }
                        });
                    t.searchResults = g != null ? g : null, t.searchQuery = d, i = 6e3
                } else if (n.author.name === "browser.open" && n.content.content_type === "tether_browsing_display") {
                    a("browser"), t.isReaderMode = !0;
                    const d = (ne = (me = n.metadata) == null ? void 0 : me.n7jupd_url) != null ? ne : "",
                        {
                            tetherUrl: g,
                            tetherTitle: C,
                            domain: B
                        } = Gs(d, (ce = (_ = n.metadata) == null ? void 0 : _.n7jupd_title) != null ? ce : null);
                    t.tetherData = {
                        summary: (ee = n.content.summary) != null ? ee : null,
                        result: (oe = n.content.result) != null ? oe : null,
                        domain: B,
                        title: C,
                        url: g
                    }, t.tetherData.title === Js && (t.isReaderMode = !1), i = 6e3
                } else if (n.author.name === "browser.run" && n.content.content_type === "tether_browsing_display") {
                    const d = (G = (te = (M = (U = n.metadata) == null ? void 0 : U.n7jupd_title) == null ? void 0 : M.match(/`(.*)`/)) == null ? void 0 : te[1]) != null ? G : "",
                        g = (k = (w = n.metadata) == null ? void 0 : w.n7jupd_titles) == null ? void 0 : k.map((C, B) => {
                            var $, xe, Te;
                            const P = (Te = (xe = ($ = n.metadata) == null ? void 0 : $.n7jupd_urls) == null ? void 0 : xe[B]) != null ? Te : "",
                                {
                                    domain: E
                                } = Us(P);
                            return {
                                title: C,
                                url: E != null ? E : void 0,
                                name: void 0,
                                rawUrl: P
                            }
                        });
                    if (g != null && g.length) a("search"), t.searchResults = g, t.searchQuery = d, i = 6e3;
                    else {
                        a("browser"), t.isReaderMode = !0;
                        const C = (T = (D = n.metadata) == null ? void 0 : D.n7jupd_url) != null ? T : "",
                            {
                                tetherUrl: B,
                                tetherTitle: P,
                                domain: E
                            } = Gs(C, (K = (H = n.metadata) == null ? void 0 : H.n7jupd_title) != null ? K : null);
                        t.tetherData = {
                            summary: (F = n.content.summary) != null ? F : null,
                            result: (X = n.content.result) != null ? X : null,
                            domain: E,
                            title: P,
                            url: B
                        }, t.tetherData.title === Js && (t.isReaderMode = !1), i = 6e3
                    }
                }
                break;
            case je.n7jupd_a:
                {
                    const d = (re = n.metadata) == null ? void 0 : re.n7jupd_subtool,
                        g = Ds();
                    (ue = d == null ? void 0 : d.subtool) != null && ue.includes("search") ? t.apiAction = "n7jupd_as" : (de = d == null ? void 0 : d.subtool) != null && de.includes("api_doc") && (t.apiAction = "n7jupd_ag");
                    const C = (V = (Ie = n.metadata) == null ? void 0 : Ie.n7jupd_subtool) == null ? void 0 : V.generic_api_func;
                    let B = (De = (Ee = C == null ? void 0 : C.match(ds)) == null ? void 0 : Ee[0]) != null ? De : void 0;B || (B = (Ue = (be = (pe = (ye = n.metadata) == null ? void 0 : ye.n7jupd_url) == null ? void 0 : pe.match(ds)) == null ? void 0 : be[0]) != null ? Ue : void 0);
                    const P = g == null ? void 0 : g.get(B != null ? B : "");
                    if (!B || !P) t.apiAction = "n7jupd_cf";
                    else if ((Je = n.metadata) != null && Je.connector_source && n.content.content_type === Be.TetherBrowsingDisplay) {
                        (L = n.metadata) != null && L.display_url && ((He = n.metadata) != null && He.display_title) && (t.apiAction = "n7jupd_cf", t.connector = P, t.connectorFetchResult = {
                            url: (Qe = n.metadata) == null ? void 0 : Qe.display_url,
                            title: (Me = n.metadata) == null ? void 0 : Me.display_title
                        });
                        const E = Hs(n.content.result);
                        E.length && (t.apiAction = "n7jupd_cs", t.connector = P, t.connectorSearchResults = E.map(([$, xe]) => ({
                            url: $,
                            title: xe
                        })))
                    }
                    a("api_tool"),
                    ms(t, ps.api_tool),
                    i = 1e3,
                    P && (t.connector = P);
                    break
                }
            case je.n7jupd_native_api_tool:
                {
                    const d = n.recipient;
                    if (d != null && d.includes("list_resources") || d != null && d.includes("search_tools") ? t.apiAction = "n7jupd_as" : (d != null && d.includes("read_resources") || d != null && d.includes("get_resource")) && (t.apiAction = "n7jupd_ag"), n.content.content_type !== Be.CitableCodeOutput) t.apiAction = "n7jupd_cf";
                    else {
                        const g = Ds();
                        t.apiAction = "n7jupd_cf";
                        let C = (Ye = (Xe = n.content.metadata) == null ? void 0 : Xe.connector_id) != null ? Ye : void 0;
                        C || (C = (W = (Ke = n.content.output_str.match(ds)) == null ? void 0 : Ke[0]) != null ? W : void 0);
                        const B = g == null ? void 0 : g.get(C != null ? C : "");
                        B && (t.connector = B), (he = n.content.metadata) != null && he.display_url && ((fe = n.content.metadata) != null && fe.display_title) && (t.connectorFetchResult = {
                            url: (O = n.content.metadata) == null ? void 0 : O.display_url,
                            title: (I = n.content.metadata) == null ? void 0 : I.display_title
                        });
                        const P = Hs(n.content.output_str);
                        P.length && (t.apiAction = "n7jupd_cs", t.connectorSearchResults = P.map(([E, $]) => ({
                            url: E,
                            title: $
                        })))
                    }
                    a("api_tool"),
                    ms(t, ps.api_tool),
                    i = 1e3;
                    break
                }
            case je.Container:
                n.content.content_type === Be.MultimodalText && (a("image_viewer"), ms(t, ps.image_viewer), n.content.parts.forEach(d => {
                    typeof d != "string" && d.content_type === Rs.ImageAssetPointer && t.imageViewerScreenshots.push(as(ht({}, d), {
                        messageId: n.id
                    }))
                }), i = 3e3);
                break;
            case je.t2uay3k:
                if (!o) break;
                if (n.author.name === "t2uay3k.sj1i4kz" && n.content.content_type === Be.MultimodalText) {
                    const d = n.content.parts.at(0);
                    if (typeof d == "string") break;
                    (d == null ? void 0 : d.content_type) === Rs.ImageAssetPointer ? (t.imageGenFileId = d.asset_pointer, i = 2e3) : nt.addError("Error parsing image gen file id", {
                        message: n
                    }), t.imageGenTitle = (we = (ke = n.metadata) == null ? void 0 : ke.image_gen_title) != null ? we : null, i = 2e3
                }
                break;
            case je.Debug:
                {
                    if (n.author.role === "assistant" && n.content.content_type === Be.Code) {
                        const d = qs(n.content.text),
                            g = d == null ? void 0 : d.actions.find(C => C.action === "search_with_snippets" && C.queries.length);
                        g && (a("search"), t.searchResults = null, t.searchQuery = g.queries.join(" || "), i = Math.max(i, 1e3))
                    }
                    if (!o) break;
                    if (n.recipient === "imagegen.make_image" && n.content.content_type === "code") {
                        a("image_gen"), t.imageGenFileId = null, i = 1e3, t.imageGenTitle = (Le = (Ve = n.metadata) == null ? void 0 : Ve.image_gen_title) != null ? Le : null;
                        try {
                            t.imageGenPrompt = JSON.parse(n.content.text).prompt
                        } catch (d) {
                            nt.addError("Error parsing image gen prompt", {
                                e: d,
                                text: n.content.text
                            })
                        }
                    }
                    break
                }
        }
        return !u && (t.isCursorInInitialPosition || Math.random() < ma) && t.openApps.length && (t.isCursorInInitialPosition = !1, t.cursorTop = Math.random() * 30 + 20, t.cursorLeft = Math.random() * 60 + 20), i
    },
    ha = ({
        messageGroups: t,
        isStreaming: e,
        isFinalAssistantTurn: o,
        isComplete: i,
        clientThreadId: n,
        enableVisualReaderMode: c = !1,
        isKAUR1BR5: u = !1
    }) => {
        var w, k, D, T, H, K, F, X, re, ue, de, Ie, V, Ee, De, ye, pe, be, Ue, Je, L, He, Qe, Me, Xe, Ye, Ke;
        const a = on(n),
            m = Ft(),
            f = an(m, "3639187874"),
            h = l.useMemo(() => t.flatMap(he => he.messages.map(fe => ({
                message: fe,
                groupType: he.type
            }))).map(he => ({
                message: he.message,
                messageType: Hn(he.message),
                groupType: he.groupType
            })), [t]),
            [x, p] = l.useState([]),
            [y, S] = l.useState(0),
            [N, R] = l.useState(e),
            [A, Q] = l.useState(!0),
            [r, ae] = l.useState(null),
            Z = ho(n),
            b = l.useRef(null),
            me = Ut(r == null ? void 0 : r.screenshot, a),
            ne = Ut(r == null ? void 0 : r.libreOfficeScreenshots.at(-1), a),
            _ = Ut(r == null ? void 0 : r.imageViewerScreenshots.at(-1), a),
            ce = l.useCallback((W, he) => {
                var ke, we, Ve, Le, d, g, C, B, P, E, $, xe, Te, We, et;
                const fe = [...W];
                let O = fe.length > 0 ? fe[fe.length - 1] : null,
                    I;
                O ? I = {
                    cursorTop: O.cursorTop,
                    cursorLeft: O.cursorLeft,
                    thought: O.thought,
                    openApps: [...O.openApps],
                    currentWindowIndex: O.currentWindowIndex,
                    screenshots: O.screenshot ? [O.screenshot] : [],
                    libreOfficeScreenshots: (ke = O.libreOfficeScreenshots) != null ? ke : [],
                    searchResults: (we = O.searchResults) != null ? we : null,
                    searchQuery: (Ve = O.searchQuery) != null ? Ve : null,
                    code: [...O.code],
                    tabMetadata: (Le = O.tabMetadata) != null ? Le : null,
                    isCursorInInitialPosition: !1,
                    tetherData: (d = O.tetherData) != null ? d : null,
                    lastVisualAppSwitch: (g = O.lastVisualAppSwitch) != null ? g : null,
                    imageViewerScreenshots: (C = O.imageViewerScreenshots) != null ? C : [],
                    connector: (B = O.connector) != null ? B : null,
                    computerApplication: (P = O.computerApplication) != null ? P : null,
                    computerTitle: (E = O.computerTitle) != null ? E : null,
                    isReaderMode: ($ = O.isReaderMode) != null ? $ : !1,
                    actions: null,
                    imageGenTitle: (xe = O.imageGenTitle) != null ? xe : null,
                    imageGenFileId: (Te = O.imageGenFileId) != null ? Te : null,
                    imageGenPrompt: null
                } : I = {
                    cursorTop: Qs,
                    cursorLeft: Xs,
                    thought: "",
                    openApps: [],
                    currentWindowIndex: 0,
                    screenshots: [],
                    searchResults: null,
                    searchQuery: null,
                    code: [],
                    tabMetadata: null,
                    isCursorInInitialPosition: !0,
                    isReaderMode: !1,
                    tetherData: null,
                    libreOfficeScreenshots: [],
                    lastVisualAppSwitch: null,
                    imageViewerScreenshots: [],
                    connector: null,
                    computerApplication: null,
                    computerTitle: null,
                    actions: null,
                    imageGenTitle: null,
                    imageGenFileId: null,
                    imageGenPrompt: null
                };
                for (let Ge = fe.length; Ge <= he; Ge++) {
                    const ot = pa(I, h[Ge], f),
                        Fe = {
                            cursorTop: I.cursorTop,
                            cursorLeft: I.cursorLeft,
                            thought: I.thought,
                            openApps: [...I.openApps],
                            currentWindowIndex: I.currentWindowIndex,
                            screenshot: (et = ((We = I.screenshots) != null ? We : []).at(-1)) != null ? et : null,
                            searchResults: I.searchResults,
                            searchQuery: I.searchQuery,
                            code: [...I.code],
                            tabMetadata: I.tabMetadata,
                            isReaderMode: I.isReaderMode,
                            tetherData: I.tetherData,
                            libreOfficeScreenshots: [...I.libreOfficeScreenshots],
                            lastVisualAppSwitch: I.lastVisualAppSwitch,
                            imageViewerScreenshots: [...I.imageViewerScreenshots],
                            connector: I.connector,
                            apiAction: I.apiAction,
                            connectorFetchResult: I.connectorFetchResult,
                            connectorSearchResults: I.connectorSearchResults,
                            delayMs: ot,
                            computerApplication: I.computerApplication,
                            computerTitle: I.computerTitle,
                            actions: I.actions,
                            imageGenTitle: I.imageGenTitle,
                            imageGenFileId: I.imageGenFileId,
                            imageGenPrompt: I.imageGenPrompt
                        };
                    O && (Fe.lastVisualAppSwitch = O.lastVisualAppSwitch), fe.push(Fe), O = Fe
                }
                return {
                    newFrames: fe
                }
            }, [h, f]);
        l.useEffect(() => {
            if (x.length < h.length) {
                const {
                    newFrames: W
                } = ce(x, h.length - 1);
                p(W)
            }
            A && S(h.length - 1)
        }, [h.length, ce, x, A]);
        const ee = l.useCallback(() => {
            if (y >= x.length - 1) {
                i && (R(!1), Q(!0));
                return
            }
            const W = x[y];
            b.current && clearTimeout(b.current), b.current = setTimeout(() => {
                S(he => he + 1)
            }, W.delayMs)
        }, [y, x, i]);
        l.useEffect(() => {
            if (!A) return N && ee(), () => {
                b.current && clearTimeout(b.current)
            }
        }, [N, y, x.length, ee, A]), l.useEffect(() => {
            const W = x[y];
            W && ae(W)
        }, [y, x]);
        const {
            formatMessage: oe
        } = _e(), U = (r == null ? void 0 : r.currentWindowIndex) === (r == null ? void 0 : r.openApps.findIndex(W => W === "browser")), M = {
            browser: s.jsx(ci, {
                tabMetadata: (w = r == null ? void 0 : r.tabMetadata) != null ? w : null,
                signedScreenshotUrl: me,
                newTabTitle: oe(Ne.newTab),
                isReaderMode: (k = r == null ? void 0 : r.isReaderMode) != null ? k : !1,
                url: (T = (D = r == null ? void 0 : r.tetherData) == null ? void 0 : D.url) != null ? T : "",
                domain: (K = (H = r == null ? void 0 : r.tetherData) == null ? void 0 : H.domain) != null ? K : "",
                title: (X = (F = r == null ? void 0 : r.tetherData) == null ? void 0 : F.title) != null ? X : "",
                tetherData: (re = r == null ? void 0 : r.tetherData) != null ? re : null,
                isKAUR1BR5: u,
                isActive: U,
                serverThreadId: a != null ? a : "",
                isStreaming: e
            }),
            terminal: s.jsx(Ri, {
                title: oe(Ne.terminal),
                code: (ue = r == null ? void 0 : r.code) != null ? ue : []
            }),
            search: s.jsx(Ni, {
                searchQuery: (de = r == null ? void 0 : r.searchQuery) != null ? de : "",
                searchResults: (Ie = r == null ? void 0 : r.searchResults) != null ? Ie : null
            }),
            libreoffice: s.jsx(ea, {
                title: oe(Ne.libreoffice),
                signedScreenshotUrl: ne
            }),
            tether_browser: c ? null : s.jsx(li, {
                url: (Ee = (V = r == null ? void 0 : r.tetherData) == null ? void 0 : V.url) != null ? Ee : "",
                domain: (ye = (De = r == null ? void 0 : r.tetherData) == null ? void 0 : De.domain) != null ? ye : "",
                title: (be = (pe = r == null ? void 0 : r.tetherData) == null ? void 0 : pe.title) != null ? be : ""
            }),
            image_viewer: s.jsx(Ki, {
                signedScreenshotUrl: _
            }),
            api_tool: s.jsx(Vi, {
                connector: (Ue = r == null ? void 0 : r.connector) != null ? Ue : null,
                connectorFetchResult: r == null ? void 0 : r.connectorFetchResult,
                connectorSearchResults: r == null ? void 0 : r.connectorSearchResults,
                action: r == null ? void 0 : r.apiAction
            }),
            image_gen: s.jsx(Yi, {
                file_id: (Je = r == null ? void 0 : r.imageGenFileId) != null ? Je : "",
                title: (L = r == null ? void 0 : r.imageGenTitle) != null ? L : "",
                clientThreadId: n,
                prompt: (He = r == null ? void 0 : r.imageGenPrompt) != null ? He : ""
            })
        }, te = r == null ? void 0 : r.openApps.map(W => M[W]), G = e && o && Z;
        return s.jsxs("div", {
            className: "group flex w-full flex-col gap-2",
            children: [s.jsx("div", {
                className: se("border-token-border-default bg-token-surface-primary relative flex w-full flex-col items-center overflow-hidden rounded-2xl border", G && "outline-2 outline-offset-1 outline-orange-500"),
                children: s.jsxs("div", {
                    className: "relative flex w-full flex-col overflow-hidden",
                    children: [s.jsx("div", {
                        className: "absolute start-0 end-0 top-0 bottom-0 dark:hue-rotate-180 dark:invert",
                        children: s.jsx("video", {
                            className: "h-full w-full object-cover",
                            autoPlay: !0,
                            loop: !0,
                            muted: !0,
                            playsInline: !0,
                            children: s.jsx("source", {
                                src: "https://persistent.oaistatic.com/deep-research/d9a42348470e-bg.mp4",
                                type: "video/mp4"
                            })
                        })
                    }), s.jsx(Si, {
                        top: (Qe = r == null ? void 0 : r.cursorTop) != null ? Qe : Qs,
                        left: (Me = r == null ? void 0 : r.cursorLeft) != null ? Me : Xs,
                        text: (Xe = r == null ? void 0 : r.thought) != null ? Xe : "",
                        actions: (Ye = r == null ? void 0 : r.actions) != null ? Ye : [],
                        isKAUR1BR5: u
                    }), s.jsx("div", {
                        className: "relative flex h-full w-full flex-row",
                        style: {
                            transform: "translateX(-".concat(((Ke = r == null ? void 0 : r.currentWindowIndex) != null ? Ke : 0) * 100, "%)"),
                            transition: "transform 0.5s cubic-bezier(0.4,0,0.2,1)",
                            width: "100%",
                            paddingTop: u ? "calc((714 / 1024 * 100%) + 38px)" : "calc((697 / 1024 * 100%) + 38px)"
                        },
                        children: s.jsx("div", {
                            className: "absolute inset-0 flex h-full flex-row",
                            children: te
                        })
                    }), s.jsx(fa, {
                        value: y,
                        max: Math.max(x.length - 1, 0),
                        isPlaying: N,
                        onChange: W => {
                            R(!1), S(W), W === x.length - 1 ? Q(!0) : Q(!1)
                        },
                        onPlayPause: () => R(W => !W),
                        onRestart: () => {
                            S(0), R(!0), Q(!1)
                        },
                        onLive: () => {
                            S(x.length - 1), R(!0), Q(!0)
                        },
                        isLive: A,
                        isComplete: i,
                        isKAUR1BR5: u
                    })]
                })
            }), G && s.jsxs("div", {
                className: "flex flex-row items-center justify-start gap-1",
                children: [s.jsx(Oi, {
                    id: "risky-domain-warning",
                    side: "top",
                    sideOffset: -8,
                    allowReopen: !0,
                    className: "max-w-sm",
                    content: s.jsxs("div", {
                        className: "flex flex-col gap-1 text-sm",
                        children: [s.jsx("div", {
                            className: "font-semibold",
                            children: s.jsx(Ce, {
                                id: "OZapq8",
                                defaultMessage: "Watch while ChatGPT works with sensitive data"
                            })
                        }), s.jsx("div", {
                            children: s.jsx(Ce, {
                                id: "1orBxj",
                                defaultMessage: "ChatGPT is working with {riskyDomain}, which contains sensitive data. If you notice anything bad happening, you can stop the task.",
                                values: {
                                    riskyDomain: s.jsx("span", {
                                        className: "font-medium",
                                        children: Z
                                    })
                                }
                            })
                        })]
                    }),
                    children: s.jsxs("div", {
                        className: "flex flex-row items-center gap-1 text-orange-500",
                        children: [s.jsx(Vn, {
                            className: "size-4 cursor-pointer"
                        }), s.jsx(Ce, {
                            id: "51tzX5",
                            defaultMessage: "Sensitive data · Something not right?"
                        })]
                    })
                }), s.jsx("button", {
                    className: "text-token-text-secondary underline",
                    "aria-label": oe(Ne.stopAgent),
                    onClick: async () => {
                        await xo(n, void 0, {
                            clientInitiated: !0,
                            reason: "watch_mode_stop",
                            isLastTurnAgent: !0
                        })
                    },
                    children: oe(Ne.stopAgent)
                })]
            })]
        })
    },
    xa = ({
        isAgentTurn: t,
        clientThreadId: e,
        children: o,
        messageGroups: i,
        isExpanded: n,
        visualMode: c,
        isStreaming: u,
        isComplete: a,
        isStopping: m,
        isFinalAssistantTurn: f,
        isKAUR1BR5: h,
        enableVisualReaderMode: x = !1
    }) => {
        if (!t) return o;
        if (!n && !u || m) return null;
        const p = c === "visual-cot",
            y = c === "list-cot";
        return s.jsxs("div", {
            className: "flex flex-col",
            children: [p && s.jsx(ha, {
                clientThreadId: e,
                messageGroups: i,
                isStreaming: u,
                isComplete: a,
                isFinalAssistantTurn: f,
                enableVisualReaderMode: x,
                isKAUR1BR5: h
            }), y && s.jsx(ga, {
                children: o
            })]
        })
    },
    ga = ({
        children: t
    }) => {
        const e = l.useRef(null),
            [o, i] = l.useState(!0);
        return l.useEffect(() => {
            const n = e.current;
            if (!n) return;
            const c = () => {
                const u = n.scrollHeight - n.scrollTop - n.clientHeight;
                i(u <= 1)
            };
            return n.addEventListener("scroll", c, {
                passive: !0
            }), () => n.removeEventListener("scroll", c)
        }, []), l.useEffect(() => {
            const n = e.current;
            !n || !o || requestAnimationFrame(() => {
                n.scrollTop = n.scrollHeight
            })
        }, [t, o]), s.jsx("div", {
            ref: e,
            className: "border-token-border-light flex aspect-[614/493] flex-col overflow-auto rounded-lg border p-4",
            children: s.jsx("div", {
                className: "flex flex-col",
                children: t
            })
        })
    },
    Ys = {
        duration: .3,
        ease: "easeInOut"
    },
    hs = .2,
    tr = ({
        isStreaming: t,
        isFinalAssistantTurn: e,
        messageGroups: o,
        nextMessageGroup: i,
        prevMessageGroup: n,
        isAutoswitchOptOutEnabled: c,
        handleSkipClick: u,
        isAgentTurn: a,
        isAsyncCorrectionTurn: m,
        isGlauxTurn: f,
        isKAUR1BR5: h,
        taskType: x,
        latestError: p,
        wasInterrupted: y,
        lastAgentMetadataNode: S,
        conversation: N,
        turnIndex: R,
        currentGroupedMessageIndex: A,
        activeTask: Q
    }) => {
        const r = Ft(),
            ae = un(r, !!a),
            Z = l.useMemo(() => o.some(w => w.type === je.n7jupd_a || w.type === je.n7jupd_native_api_tool), [o]),
            {
                platformConnectors: b
            } = Wn(Z),
            [me, ne] = l.useState(!1);
        ni();
        const {
            chunks: _,
            isAgentVisualCoT: ce,
            containsAuraComputerTool: ee
        } = l.useMemo(() => Oo(r, o, f), [r, o, f]), oe = i == null ? void 0 : i.messages.some(w => go(w)), {
            toggleThreadSidebar: U
        } = yo(), {
            resetSidebarHistory: M
        } = bo(), te = l.useCallback(() => {
            M(), U({
                type: "cot",
                turnIndex: R,
                reasoningGroupIndex: A
            })
        }, [U, R, A, M]), G = l.useCallback(() => {
            var w, k;
            U({
                type: "retrievalResults",
                turnIndex: R,
                messageId: (k = (w = o[0]) == null ? void 0 : w.messages[0]) == null ? void 0 : k.id
            })
        }, [U, R, o]);
        return p && !oe ? s.jsx(Mo, {
            errorState: p,
            nodeId: p.messageId,
            isFeedbackEnabled: !1,
            conversation: p.conversation,
            isUserTurn: !1
        }) : s.jsx(wo, {
            value: {
                platformConnectors: b
            },
            children: s.jsx(ba, {
                conversation: N,
                isStreaming: t,
                isFinalAssistantTurn: e,
                chunks: _,
                isAutoswitchOptOutEnabled: c,
                isAgentTurn: a,
                isAsyncCorrectionTurn: m,
                containsAuraComputerTool: ee,
                handleSkipClick: u,
                handleOpenCotSidebar: te,
                handleShowRetrievalResults: G,
                nextMessageGroup: i,
                prevMessageGroup: n,
                messageGroups: o,
                isAgentVisualCoT: ce,
                isKAUR1BR5: h,
                isGlauxTurn: f,
                taskType: x,
                wasInterrupted: y,
                lastAgentMetadataNode: S,
                isExpanded: !ae && me,
                setIsExpanded: ne,
                turnIndex: R,
                activeTask: Q
            })
        })
    },
    ya = t => {
        for (const {
                messages: e
            } of t)
            for (const {
                    metadata: o
                } of e)
                if (o != null && o.skip_reasoning_title) return o.skip_reasoning_title
    },
    ba = t => {
        "use forget";
        var Cs, _s, ks, Ts, Ss, Ns, As;
        const e = ws.c(175),
            {
                conversation: o,
                isStreaming: i,
                isFinalAssistantTurn: n,
                chunks: c,
                isAutoswitchOptOutEnabled: u,
                isAgentTurn: a,
                isAsyncCorrectionTurn: m,
                handleSkipClick: f,
                handleOpenCotSidebar: h,
                handleShowRetrievalResults: x,
                nextMessageGroup: p,
                prevMessageGroup: y,
                messageGroups: S,
                isAgentVisualCoT: N,
                containsAuraComputerTool: R,
                isKAUR1BR5: A,
                isGlauxTurn: Q,
                taskType: r,
                wasInterrupted: ae,
                lastAgentMetadataNode: Z,
                isExpanded: b,
                setIsExpanded: me,
                turnIndex: ne,
                activeTask: _
            } = t;
        let ce;
        e[0] !== S ? (ce = S === void 0 ? [] : S, e[0] = S, e[1] = ce) : ce = e[1];
        const ee = ce,
            oe = R === void 0 ? !1 : R,
            U = _e(),
            M = Ft(),
            te = ((Cs = Z == null ? void 0 : Z.metadata) == null ? void 0 : Cs.agent_entrypoint) === "autoswitcher",
            G = a ? te : u;
        let w;
        e[2] !== G || e[3] !== ee ? (w = G ? ya(ee) : void 0, e[2] = G, e[3] = ee, e[4] = w) : w = e[4];
        const k = w,
            D = Bn(),
            T = si(c, i, D, te, A != null ? A : !1),
            H = a ? T !== Se.Done : !1;
        let K;
        e[5] !== M ? (K = () => [Un(M), Gn(M)], e[5] = M, e[6] = K) : K = e[6];
        const [F, X] = Os(K);
        let re;
        e[7] !== M ? (re = an(M, "1668913216"), e[7] = M, e[8] = re) : re = e[8];
        const V = re && N && !(F || X && !oe);
        let Ee = "visual-cot";
        Z && (Ee = (ks = (_s = Z == null ? void 0 : Z.metadata) == null ? void 0 : _s.default_view) != null ? ks : "visual-cot");
        const De = Ee,
            [ye, pe] = l.useState(De);
        let be;
        e[9] === Symbol.for("react.memo_cache_sentinel") ? (be = [], e[9] = be) : be = e[9];
        const [Ue, Je] = l.useState(be), L = !i;
        let He;
        e: {
            if (!a) {
                He = !1;
                break e
            }
            let v;e[10] !== c ? (v = c.filter(ja).slice(-3).some(va), e[10] = c, e[11] = v) : v = e[11],
            He = v
        }
        const Qe = He;
        let Me;
        e[12] !== c || e[13] !== a ? (Me = a && c.some(Ca), e[12] = c, e[13] = a, e[14] = Me) : Me = e[14];
        const Xe = Me,
            Ye = _a,
            Ke = ka;
        let W;
        e[15] !== a || e[16] !== (p == null ? void 0 : p.messages) ? (W = a && (p == null ? void 0 : p.messages.some(v => Ye(v))), e[15] = a, e[16] = p == null ? void 0 : p.messages, e[17] = W) : W = e[17];
        const he = W;
        let fe;
        e[18] !== a || e[19] !== (p == null ? void 0 : p.messages) ? (fe = a && (p == null ? void 0 : p.messages.some(v => Ke(v))), e[18] = a, e[19] = p == null ? void 0 : p.messages, e[20] = fe) : fe = e[20];
        const I = (Qe || fe) && !Xe && L && !he && !F && !A,
            ke = ((y == null ? void 0 : y.type) === je.Text || (y == null ? void 0 : y.type) === je.MultiText) && (y == null ? void 0 : y.messages[0].author.role) === zn.Assistant,
            [we] = l.useState(i ? -1 : c.length),
            Ve = !!a;
        let Le;
        e[21] !== M || e[22] !== Ve ? (Le = un(M, Ve), e[21] = M, e[22] = Ve, e[23] = Le) : Le = e[23];
        const d = Le;
        let g, C;
        if (e[24] !== M) {
            const v = tn(M, "349489989");
            g = v.get("per_chunk_time_ms", 4e3), C = v.get("per_search_chunk_time_ms", 500), e[24] = M, e[25] = g, e[26] = C
        } else g = e[25], C = e[26];
        const B = C;
        let P;
        if (e[27] !== c || e[28] !== U || e[29] !== g || e[30] !== B) {
            P = [];
            for (const [v, j] of c.entries())
                if (j.type === z.Thought && j.thought.chunks)
                    for (const Y of j.thought.chunks) P.push({
                        chunk: j,
                        text: Y,
                        timeoutMs: g,
                        isStreamingAnimation: !0
                    });
                else if (j.type === z.Search)
                for (const Y of j.sources) P.push({
                    chunk: j,
                    text: Y.domain,
                    timeoutMs: B,
                    isStreamingAnimation: !1
                });
            else {
                const Y = No({
                    chunk: j,
                    intl: U,
                    isLast: c.length - 1 === v,
                    hasGlauxMessages: c.some(Ta)
                });
                P.push({
                    chunk: j,
                    text: Y,
                    timeoutMs: g,
                    isStreamingAnimation: !0
                })
            }
            e[27] = c, e[28] = U, e[29] = g, e[30] = B, e[31] = P
        } else P = e[31];
        const E = P,
            [$, xe] = l.useState(-1),
            Te = l.useRef(E),
            We = l.useRef(null);
        let et, Ge;
        e[32] !== $ || e[33] !== E ? (et = () => {
            Te.current = E, $ >= E.length && E.length > 0 && xe(E.length - 1)
        }, Ge = [E, $], e[32] = $, e[33] = E, e[34] = et, e[35] = Ge) : (et = e[34], Ge = e[35]), l.useEffect(et, Ge);
        let ot, Fe;
        e[36] !== $ || e[37] !== E.length ? (ot = () => {
            $ == -1 && E.length > 0 && xe(0)
        }, Fe = [E.length, $], e[36] = $, e[37] = E.length, e[38] = ot, e[39] = Fe) : (ot = e[38], Fe = e[39]), l.useEffect(ot, Fe);
        const q = i ? E[$] : null,
            tt = q == null ? void 0 : q.timeoutMs,
            qt = q == null ? void 0 : q.text;
        let xt;
        e[40] !== $ || e[41] !== tt ? (xt = () => {
            if (tt != null && !We.current) return We.current = setTimeout(() => {
                We.current = null;
                const v = Te.current;
                v.length !== 0 && $ < v.length - 1 && xe(Sa)
            }, tt), () => {
                We.current && (clearTimeout(We.current), We.current = null)
            }
        }, e[40] = $, e[41] = tt, e[42] = xt) : xt = e[42];
        let gt;
        e[43] !== $ || e[44] !== qt || e[45] !== tt || e[46] !== E.length ? (gt = [tt, qt, $, E.length], e[43] = $, e[44] = qt, e[45] = tt, e[46] = E.length, e[47] = gt) : gt = e[47], l.useEffect(xt, gt);
        const J = c,
            Re = Ps(o.id, Na);
        let yt;
        e[48] !== ne ? (yt = v => Fn.getConversationTurnAtIndex(v, ne).modelSlug, e[48] = ne, e[49] = yt) : yt = e[49];
        const bt = Ps(o.id, yt);
        let wt;
        e[50] !== o || e[51] !== bt ? (wt = () => {
            var v, j, Y;
            if (bt) {
                const Pe = (v = Zn(qn(o), bt)) == null ? void 0 : v.reasoningType;
                if (Pe != null) return Pe
            }
            return (Y = (j = Jn(o)) == null ? void 0 : j.reasoningType) != null ? Y : null
        }, e[50] = o, e[51] = bt, e[52] = wt) : wt = e[52];
        let Jt = Os(wt);
        m && (Jt = cs.ON);
        const pt = Jt === cs.AUTO || Jt === cs.OFF;
        let Qt;
        e: {
            if (!d) {
                Qt = !0;
                break e
            }
            Qt = !pt
        }
        const ve = Qt;
        let st;
        e: {
            let v;e[53] !== J ? (v = gs(J), e[53] = J, e[54] = v) : v = e[54];
            let j = v;
            if (L) {
                st = (j == null ? void 0 : j.type) === z.Recap ? j : void 0;
                break e
            }
            if (d && (j = (Ts = E[$]) == null ? void 0 : Ts.chunk), (j == null ? void 0 : j.type) === z.Thought) {
                if (j.thought.summary != null && j.thought.summary.length > 0) {
                    st = j;
                    break e
                }
                let Y;
                e[55] !== J ? (Y = xs(J, Aa), e[55] = J, e[56] = Y) : Y = e[56], st = Y;
                break e
            }
            if (Q && (j == null ? void 0 : j.type) === z.Recap && ((Ss = J[J.length - 2]) == null ? void 0 : Ss.type) !== z.Thought) {
                st = void 0;
                break e
            }
            if ((j == null ? void 0 : j.type) === z.CodeAnalysis && a) {
                let Y;
                e[57] !== J ? (Y = xs(J.slice(0, -1), Ia), e[57] = J, e[58] = Y) : Y = e[58];
                const Pe = Y;
                if (Pe) {
                    st = Pe;
                    break e
                }
            }
            st = j
        }
        const ie = st;
        let jt;
        e[59] !== J ? (jt = [...J.entries()], e[59] = J, e[60] = jt) : jt = e[60];
        const vt = jt;
        let Ct;
        e[61] !== vt || e[62] !== b || e[63] !== V ? (Ct = b || V ? vt : vt.slice(-1), e[61] = vt, e[62] = b, e[63] = V, e[64] = Ct) : Ct = e[64];
        const _t = Ct;
        wa(we, L);
        let kt;
        e[65] !== J ? (kt = J.some(Ea), e[65] = J, e[66] = kt) : kt = e[66];
        const Tt = kt,
            St = J.length > 0 && (c[0].type !== z.Recap || c[0].type === z.Recap && r || c[0].didFailReasoning || Tt || m);
        let Nt;
        e[67] !== J ? (Nt = gs(J), e[67] = J, e[68] = Nt) : Nt = e[68];
        const it = Nt,
            bn = (it == null ? void 0 : it.type) === z.Browsing && !b || (it == null ? void 0 : it.type) === z.N7jupdAPI && !b,
            Xt = jo(),
            wn = (Xt == null ? void 0 : Xt.type) === "cot",
            At = St && (!L && (a || d) || b) && !wn && !bn && !H && (a ? !Re : !0),
            jn = Ro(Ue) + (Ue.length - 1) * Vs + 2 * fs,
            Yt = L || V ? "auto" : b ? jn : "auto";
        let It;
        e[69] !== ie || e[70] !== Re || e[71] !== U || e[72] !== L || e[73] !== T ? (It = ie && Ws(U, ie, L, Re, !0, T), e[69] = ie, e[70] = Re, e[71] = U, e[72] = L, e[73] = T, e[74] = It) : It = e[74];
        const Et = It;
        let Mt;
        e[75] !== d || e[76] !== h || e[77] !== ve || e[78] !== i || e[79] !== me ? (Mt = (v, j) => {
            me(v), d && ve && (h == null || h()), rn.count(ln.COT_SUMMARIZER, v ? "expand" : "collapse", [{
                key: "is_streaming",
                value: String(i)
            }, {
                key: "source",
                value: j
            }]), us.logEventWithStatsig(v ? "CoT Expanded" : "CoT Collapsed", v ? "chatgpt_cot_expanded" : "chatgpt_cot_collapsed", {
                is_streaming: String(i),
                source: j
            })
        }, e[75] = d, e[76] = h, e[77] = ve, e[78] = i, e[79] = me, e[80] = Mt) : Mt = e[80];
        const Oe = Mt;
        let Lt;
        e[81] !== Oe ? (Lt = () => {
            Oe(!0, "chunk")
        }, e[81] = Oe, e[82] = Lt) : Lt = e[82];
        const Kt = Lt;
        let Rt;
        e[83] === Symbol.for("react.memo_cache_sentinel") ? (Rt = (v, j) => {
            Je(Y => {
                const Pe = [...Y];
                return Pe[v] = j, Pe
            })
        }, e[83] = Rt) : Rt = e[83];
        const vn = Rt;
        let Ot;
        e[84] !== we || e[85] !== L || e[86] !== b ? (Ot = () => {
            L || we < 0 || us.logEventWithStatsig(b ? "Streamed CoT Chunk Viewed" : "Streamed CoT Chunk Ignored", b ? "chatgpt_streamed_cot_chunk_viewed" : "chatgpt_streamed_cot_chunk_ignored")
        }, e[84] = we, e[85] = L, e[86] = b, e[87] = Ot) : Ot = e[87];
        let Pt;
        e[88] !== we || e[89] !== L || e[90] !== b || e[91] !== i ? (Pt = [we, L, b, i], e[88] = we, e[89] = L, e[90] = b, e[91] = i, e[92] = Pt) : Pt = e[92], l.useEffect(Ot, Pt);
        const $t = L && pt || L && !St,
            es = i && !St && !G || a && T === Se.Thinking,
            at = (St || G) && (!a || T !== Se.Thinking),
            ts = a && !(a && Re) && !V;
        let Dt;
        e[93] !== _ || e[94] !== o.id ? (Dt = v => {
            const j = {
                content: v.content,
                conversationId: o.id,
                taskId: _ == null ? void 0 : _.taskId,
                taskType: _ ? Qn(_) : void 0,
                taskConversationId: _ == null ? void 0 : _.conversationId,
                taskOriginalConversationId: _ == null ? void 0 : _.originalConversationId,
                taskCreatedAt: _ == null ? void 0 : _.createdAt,
                taskUpdatedAt: _ == null ? void 0 : _.updatedAt,
                taskStatus: _ == null ? void 0 : _.status
            };
            nt.addAction("thinking.failed", j), us.logEventWithStatsig("chatgpt_web_thinking_failed", "chatgpt_web_thinking_failed", j)
        }, e[93] = _, e[94] = o.id, e[95] = Dt) : Dt = e[95];
        const ss = l.useEffectEvent(Dt);
        let Ht;
        e[96] !== ie || e[97] !== ss ? (Ht = () => {
            ie != null && ie.type === z.Recap && ie.didFailReasoning && ss(ie)
        }, e[96] = ie, e[97] = ss, e[98] = Ht) : Ht = e[98];
        let Vt;
        e[99] !== ie ? (Vt = [ie], e[99] = ie, e[100] = Vt) : Vt = e[100], l.useEffect(Ht, Vt);
        let rt;
        e[101] !== X || e[102] !== ke ? (rt = !ke && !X && s.jsx(_o, {}), e[101] = X, e[102] = ke, e[103] = rt) : rt = e[103];
        const ns = ke && "mt-3",
            os = ke && at && "mt-6";
        let lt;
        e[104] !== ns || e[105] !== os ? (lt = se("relative my-1 min-h-6", ns, os), e[104] = ns, e[105] = os, e[106] = lt) : lt = e[106];
        let ct;
        e[107] !== Oe || e[108] !== pt || e[109] !== b || e[110] !== ve || e[111] !== i || e[112] !== es || e[113] !== r ? (ct = es && s.jsx(le.div, {
            className: se("loading-shimmer text-token-text-secondary absolute start-2 top-0 mx-[calc(--spacing(-2)-1px)] select-none", r === $s.PRO_MODE && "font-medium"),
            initial: i && {
                translateX: -8,
                opacity: 0
            },
            animate: {
                translateX: 0,
                opacity: 1
            },
            transition: {
                ease: "easeInOut",
                duration: hs
            },
            onClick: ve ? () => {
                Oe(!b, "header")
            } : void 0,
            role: ve ? "button" : void 0,
            children: r === $s.PRO_MODE ? s.jsx(Ce, {
                id: "wOEgCa",
                defaultMessage: "Pro thinking"
            }) : pt ? s.jsx(Ce, {
                id: "oxTgUZ",
                defaultMessage: "Working"
            }) : s.jsx(Ce, {
                id: "hgnsat",
                defaultMessage: "Thinking"
            })
        }), e[107] = Oe, e[108] = pt, e[109] = b, e[110] = ve, e[111] = i, e[112] = es, e[113] = r, e[114] = ct) : ct = e[114];
        let ut;
        e[115] !== o.id || e[116] !== m || e[117] !== ee || e[118] !== at ? (ut = null, e[115] = o.id, e[116] = m, e[117] = ee, e[118] = at, e[119] = ut) : ut = e[119];
        let dt;
        e[120] !== (q == null ? void 0 : q.isStreamingAnimation) || e[121] !== (q == null ? void 0 : q.text) || e[122] !== _ || e[123] !== ye || e[124] !== o || e[125] !== Yt || e[126] !== d || e[127] !== Kt || e[128] !== Oe || e[129] !== x || e[130] !== f || e[131] !== Tt || e[132] !== ie || e[133] !== Re || e[134] !== U || e[135] !== a || e[136] !== N || e[137] !== F || e[138] !== G || e[139] !== L || e[140] !== b || e[141] !== n || e[142] !== Q || e[143] !== A || e[144] !== H || e[145] !== ve || e[146] !== i || e[147] !== ee || e[148] !== Et || e[149] !== T || e[150] !== _t || e[151] !== V || e[152] !== ts || e[153] !== at || e[154] !== At || e[155] !== I || e[156] !== k || e[157] !== r || e[158] !== ne || e[159] !== J || e[160] !== ae ? (dt = at && s.jsxs(le.div, {
            className: se("relative flex origin-top-left flex-col gap-2 overflow-x-clip rtl:origin-top-right", H && "mx-[calc(--spacing(-2)-1px)]", a && "overflow-x-visible"),
            initial: i && a && {
                opacity: 0,
                scale: .85
            },
            animate: {
                opacity: 1,
                scale: 1
            },
            transition: {
                ease: "easeOut",
                duration: hs
            },
            children: [H && !G ? s.jsx(le.div, {
                className: "loading-shimmer text-token-text-secondary absolute start-2 top-0 select-none",
                initial: i && {
                    translateX: -8,
                    opacity: 0
                },
                animate: {
                    translateX: 0,
                    opacity: 1
                },
                transition: {
                    ease: "easeInOut",
                    duration: hs
                },
                children: Et
            }, Et) : s.jsx(ko, {
                conversation: o,
                isAgentVisualCoT: N,
                isAgentTurn: a,
                latestHeadline: ie && Ws(U, ie, L, Re, a, a ? T : void 0, !d),
                latestChunk: ie,
                onToggleExpanded: () => Oe(!b, "header"),
                isExpandDisabled: !ve,
                showChunkIcon: ts,
                isExpanded: b,
                isComplete: L,
                onSkip: G ? f : void 0,
                skipTitle: k,
                shouldDisplayVisualCoT: V,
                agentVisualMode: ye,
                setAgentVisualMode: pe,
                isStreaming: i,
                interruptionInProgress: Re,
                isKAUR1BR5: A,
                wasInterrupted: ae,
                isGlauxTurn: Q,
                taskType: r,
                activeTask: _
            }), Q && d && x && s.jsx(vo, {
                className: "my-2",
                handleShowRetrievalResults: x,
                turnIndex: ne,
                clientThreadId: o.id,
                responseComplete: !i
            }), s.jsxs("div", {
                className: se(F ? "max-w-[var(--thread-content-max-width,40rem)]" : "max-w-[calc(0.8*var(--thread-content-max-width,40rem))]"),
                children: [s.jsx(xa, {
                    clientThreadId: o.id,
                    isAgentTurn: !!V,
                    isFinalAssistantTurn: n,
                    messageGroups: ee,
                    isExpanded: b,
                    visualMode: ye,
                    isStreaming: i,
                    isComplete: L,
                    isStopping: !!Re,
                    isKAUR1BR5: !!A,
                    children: d && !V ? At && n && s.jsx("div", {
                        className: "relative flex h-full flex-col",
                        style: {
                            margin: "".concat(fs, "px 0")
                        },
                        children: s.jsx(Ao, {
                            isInteractive: ve,
                            text: (Ns = q == null ? void 0 : q.text) != null ? Ns : "",
                            isStreamingAnimation: (As = q == null ? void 0 : q.isStreamingAnimation) != null ? As : !0,
                            onClick: ve ? () => Oe(!b, "chunk") : void 0
                        })
                    }) : s.jsx(qe, {
                        children: (At || V) && s.jsx(le.div, {
                            className: "relative z-0",
                            initial: L ? {
                                opacity: 0,
                                height: V ? "auto" : 0,
                                overflowY: "hidden"
                            } : !1,
                            animate: {
                                opacity: 1,
                                height: Yt
                            },
                            exit: {
                                height: V ? "auto" : 0,
                                opacity: 0,
                                pointerEvents: "none",
                                overflowY: "hidden",
                                filter: L ? "blur(8px)" : void 0,
                                translateY: -Eo
                            },
                            transition: Ys,
                            children: s.jsx("div", {
                                className: "relative flex h-full flex-col",
                                style: {
                                    margin: "".concat(fs, "px 0")
                                },
                                children: s.jsx(qe, {
                                    children: _t.map((v, j) => {
                                        const [Y, Pe] = v;
                                        return s.jsx(Io, {
                                            index: Y,
                                            chunk: Pe,
                                            gap: Vs,
                                            isLast: _t.length - 1 === j,
                                            onClick: Kt,
                                            onAnimationComplete: Ma,
                                            onMeasure: vn,
                                            isAnimationComplete: L,
                                            isExpanded: b || V,
                                            showBullet: b || V,
                                            isKAUR1BR5: A,
                                            hasGlauxMessages: Tt,
                                            disableAnimation: d,
                                            isAgentTurn: a
                                        }, Y)
                                    })
                                })
                            })
                        })
                    })
                }), I && s.jsx(Ko, {
                    chunks: J,
                    isExpanded: b,
                    isFinalAssistantTurn: n,
                    hidePowTombstone: !!V,
                    isKAUR1BR5: !!A
                })]
            })]
        }), e[120] = q == null ? void 0 : q.isStreamingAnimation, e[121] = q == null ? void 0 : q.text, e[122] = _, e[123] = ye, e[124] = o, e[125] = Yt, e[126] = d, e[127] = Kt, e[128] = Oe, e[129] = x, e[130] = f, e[131] = Tt, e[132] = ie, e[133] = Re, e[134] = U, e[135] = a, e[136] = N, e[137] = F, e[138] = G, e[139] = L, e[140] = b, e[141] = n, e[142] = Q, e[143] = A, e[144] = H, e[145] = ve, e[146] = i, e[147] = ee, e[148] = Et, e[149] = T, e[150] = _t, e[151] = V, e[152] = ts, e[153] = at, e[154] = At, e[155] = I, e[156] = k, e[157] = r, e[158] = ne, e[159] = J, e[160] = ae, e[161] = dt) : dt = e[161];
        let ft;
        e[162] !== lt || e[163] !== ct || e[164] !== ut || e[165] !== dt ? (ft = s.jsxs("div", {
            className: lt,
            children: [ct, ut, dt]
        }), e[162] = lt, e[163] = ct, e[164] = ut, e[165] = dt, e[166] = ft) : ft = e[166];
        let Wt;
        e[167] !== rt || e[168] !== ft ? (Wt = s.jsxs(s.Fragment, {
            children: [rt, ft]
        }), e[167] = rt, e[168] = ft, e[169] = Wt) : Wt = e[169];
        const Bt = Wt;
        if (a) {
            let v;
            e[170] !== Bt || e[171] !== $t ? (v = !$t && s.jsx(le.div, {
                initial: !1,
                animate: {
                    height: "auto",
                    opacity: 1,
                    scale: 1
                },
                exit: {
                    height: 0,
                    opacity: 0,
                    scale: .9,
                    filter: "blur(6px)"
                },
                transition: {
                    height: Ys,
                    opacity: {
                        duration: 0,
                        ease: "linear"
                    }
                },
                children: Bt
            }, "cot-wrapper"), e[170] = Bt, e[171] = $t, e[172] = v) : v = e[172];
            let j;
            return e[173] !== v ? (j = s.jsx(qe, {
                mode: "wait",
                children: v
            }), e[173] = v, e[174] = j) : j = e[174], j
        }
        return $t ? null : Bt
    };

function wa(t, e) {
    const o = l.useRef(null),
        i = Co(t),
        n = l.useCallback(() => {
            if (o.current != null) {
                const c = performance.now() - o.current;
                rn.hist(ln.COT_SUMMARIZER, "cot_chunk_display_time", void 0, c)
            }
        }, [i]);
    l.useEffect(() => {
        if (e) {
            n();
            return
        }
        t !== -1 && (n(), o.current = performance.now())
    }, [t, e, n])
}

function ja(t) {
    return t.type !== z.Recap && t.type !== z.Thought
}

function va(t) {
    return t.type === z.ComputerOutput
}

function Ca(t) {
    return t.type === z.Recap && t.content.includes("Stopped")
}

function _a(t) {
    var e, o, i, n, c, u, a, m;
    return (o = (e = t.metadata) == null ? void 0 : e.content_references) != null && o.length ? ((n = (i = t.metadata) == null ? void 0 : i.content_references) == null ? void 0 : n.length) > 0 : (u = (c = t.metadata) == null ? void 0 : c.n7jupd_crefs) != null && u.length ? ((m = (a = t.metadata) == null ? void 0 : a.n7jupd_crefs) == null ? void 0 : m.length) > 0 : !1
}

function ka(t) {
    var e;
    return ((e = t.metadata) == null ? void 0 : e.n7jupd_button_type) !== void 0
}

function Ta(t) {
    return t.type === z.Glaux
}

function Sa(t) {
    return t + 1
}

function Na(t) {
    return t == null ? void 0 : t.interruptionInProgress
}

function Aa(t) {
    return t.type === z.Thought && t.thought.summary != null && t.thought.summary.length > 0
}

function Ia(t) {
    return t.type === z.Thought ? t.thought.summary != null && t.thought.summary.length > 0 : t.type !== z.CodeAnalysis
}

function Ea(t) {
    return t.type === z.Glaux
}

function Ma() {}
export {
    tr as CoT, ba as CoTChunks
};
//# sourceMappingURL=o9wnx2r6h1qfy4ir.js.map