import {
    de as U,
    mz as T,
    ck as w,
    _ as s,
    sT as B,
    R as M
} from "./dykg4ktvbu3mhmdo.js";
import {
    hS as O,
    g7 as q
} from "./k15yxxoybkkir2ou.js";
import {
    T as m
} from "./3jqmuecsvur0aphg.js";
const x = U(e => ({
    abortController: null,
    setAbortController: t => e({
        abortController: t
    }),
    isRunningServerUpdate: !1,
    setIsRunningServerUpdate: t => e({
        isRunningServerUpdate: t
    }),
    subscribeButtonContainer: null,
    setSubscribeButtonContainer: t => e({
        subscribeButtonContainer: t
    }),
    celebrationBannerText: null,
    setCelebrationBannerText: t => e({
        celebrationBannerText: t
    }),
    checkoutSessionUpdateError: null,
    setCheckoutSessionUpdateError: t => e({
        checkoutSessionUpdateError: t
    })
}));
var D = {};

function N({
    amountMinorUnits: e,
    currency: t
}) {
    const n = B(t),
        r = e / Math.pow(10, n);
    return new Intl.NumberFormat(void 0, {
        style: "currency",
        currency: t
    }).format(r)
}
var h = (e => (e.SORA = "oiw216z", e.OPERATOR = "vza493q", e.STUDENTS = "students", e))(h || {}),
    f;
const j = {
    oiw216z: "".concat((f = D.VITE_OIW216Z_SERVICE_URL) != null ? f : "https://sora.com", "/subscription"),
    vza493q: T,
    students: O(!0)
};

function F(e) {
    return typeof e != "string" ? !1 : Object.values(h).includes(e)
}
async function V({
    checkout: e,
    processorEntity: t,
    planName: n,
    priceInterval: r,
    seatQuantity: o,
    promoCode: _,
    promoCampaign: l,
    annualBillingPlan: y,
    intl: a,
    currency: b
}) {
    if (!e) return;
    const {
        setIsRunningServerUpdate: d,
        abortController: c,
        setAbortController: C,
        setCelebrationBannerText: v,
        setCheckoutSessionUpdateError: g
    } = x.getState();
    g(null), s.addAction("update-business-checkout-session.initiated"), c == null || c.abort();
    const i = new AbortController;
    C(i);
    try {
        await e.runServerUpdate(async () => {
            d(!0), await M.safePost("/payments/checkout/update", {
                requestBody: {
                    checkout_session_id: e.id,
                    processor_entity: t,
                    plan_name: n,
                    price_interval: r,
                    seat_quantity: o,
                    promo_code: _,
                    promo_campaign: l ? {
                        promo_campaign_id: l,
                        is_coupon_from_query_param: !1
                    } : void 0
                },
                signal: i.signal
            })
        });
        const u = R => a.formatNumber(R, {
                style: "currency",
                currency: b,
                currencyDisplay: "narrowSymbol",
                trailingZeroDisplay: "stripIfInteger"
            }),
            {
                monthlyCost: S,
                discountedMonthlyCost: E,
                currencySign: k,
                currencyCode: A
            } = y,
            p = (S - E) * o;
        v(r === "year" ? a.formatMessage(q.businessAnnualPlanSavingsAmount, {
            currencyCode: a.formatMessage(A),
            currencySign: a.formatMessage(k),
            savingsAmountMonthly: u(p),
            savingsAmountYearly: u(p * 12)
        }) : null), s.addAction("update-business-checkout-session.success")
    } catch (u) {
        i.signal.aborted || (s.addAction("update-business-checkout-session.error"), g(!0), s.addError("[Checkout] could not update checkout session", {
            error: u
        }))
    } finally {
        i.signal.aborted || d(!1)
    }
}
const I = (e, t) => {
    var o;
    const n = w(e),
        r = t == null ? void 0 : t[0];
    if (!((o = r == null ? void 0 : r.recurring) != null && o.interval)) {
        s.addError(new Error("CheckoutDisclaimer: missing first line item recurring interval"), {
            feature: "checkout",
            component: "CheckoutDisclaimer",
            message: "Expected first Stripe line item with a recurring interval but none was found.",
            checkout_has_line_items: !!(t != null && t.length),
            checkout_line_item_keys: r ? Object.keys(r) : void 0
        }), n.danger("We’re having trouble initializing your checkout right now. Please refresh the page and try again, or contact support if the problem persists.", {
            toastId: "checkout_disclaimer_missing_interval"
        });
        return
    }
    return {
        interval: r.recurring.interval === "month" ? m.FLEXIBLE : m.ANNUAL,
        quantity: r.quantity
    }
};
export {
    j as C, h as a, x as b, N as f, I as g, F as i, V as u
};
//# sourceMappingURL=gogo7bs85ip5x228.js.map