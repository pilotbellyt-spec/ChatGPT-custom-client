import {
    c as me,
    j as ce,
    m as pe,
    n as Ce,
    r as i,
    a as Te
} from "./fg33krlcm0qyi6yw.js";
import {
    b as Ee,
    d as ue,
    o as Se,
    fG as be,
    fK as ge,
    ig as ve,
    r7 as Pe,
    P as ye,
    c_ as Ie,
    ql as Ae,
    dH as Le,
    eh as _e,
    r8 as je,
    dZ as we,
    B as Me,
    af as Re
} from "./dykg4ktvbu3mhmdo.js";
import {
    b3 as ze,
    b4 as xe,
    b5 as Fe,
    b6 as Oe,
    b7 as Ge,
    b8 as Be,
    b9 as Ue,
    ba as We,
    bb as Ke,
    bc as Ne,
    bd as He,
    be as Qe,
    bf as Ye,
    bg as $e,
    bh as qe,
    bi as De,
    bj as Ve,
    bk as Ze,
    bl as Je,
    bm as Xe,
    bn as ke,
    bo as et,
    bp as h,
    bq as m,
    br as tt,
    bs as he,
    bt as st
} from "./k15yxxoybkkir2ou.js";
import {
    C as at
} from "./f4hwlnbelkgfnokn.js";
import {
    C as it
} from "./f2t8zq7263afexpy.js";
var rt = {};

function gt(f) {
    "use forget";
    const e = me.c(8),
        {
            gizmoId: r,
            urlThreadId: d,
            clientThreadId: E,
            children: t
        } = f,
        b = ze(),
        o = Ee(),
        n = d != null ? d : E,
        s = xe(o, n, r, b);
    let a;
    e[0] !== t || e[1] !== s || e[2] !== d ? (a = ce.jsx(it, {
        urlThreadId: d,
        conversation: s,
        children: t
    }), e[0] = t, e[1] = s, e[2] = d, e[3] = a) : a = e[3];
    let c;
    return e[4] !== s || e[5] !== a || e[6] !== n ? (c = ce.jsx(ct, {
        conversation: s,
        threadId: n,
        children: a
    }), e[4] = s, e[5] = a, e[6] = n, e[7] = c) : c = e[7], c
}

function ot(f) {
    ke(!0).then(e => {
        e.force_login && Me(f, {
            fallbackScreenHint: "login"
        }), he.initializeAndGatherData(e), Re(f).checkGate("4178431533") && he.precomputeEnforcementToken(e), st.initializeAndGatherData(e)
    })
}

function nt(f) {
    "use no forget";
    const e = i.useRef(!1);
    e.current || !Se(f, "3837765068") || (e.current = !0, ke(!0))
}

function ct(f) {
    "use forget";
    var de;
    const e = me.c(70),
        {
            conversation: r,
            threadId: d,
            children: E
        } = f,
        t = Ee();
    let b;
    e[0] !== t ? (b = () => be(t), e[0] = t, e[1] = b) : b = e[1];
    const o = ue(b);
    let n;
    e[2] !== t ? (n = () => ge(t), e[2] = t, e[3] = n) : n = e[3];
    const k = ue(n),
        s = pe(),
        [a] = Ce();
    let c;
    e[4] !== s.pathname ? (c = Fe(s.pathname), e[4] = s.pathname, e[5] = c) : c = e[5];
    const le = !!c,
        {
            eligible: C,
            isLoading: T
        } = Oe(),
        S = Ge(),
        {
            eligible: v,
            isLoading: P
        } = Be(),
        y = Ue(),
        {
            eligible: I,
            isLoading: A
        } = We(),
        L = Ke(),
        {
            eligible: _,
            isLoading: j
        } = Ne(),
        w = He(),
        {
            eligible: M,
            isLoading: R
        } = Qe(),
        z = Ye(),
        {
            eligible: x,
            isLoading: F
        } = $e(),
        O = qe();
    nt(t);
    let G, B;
    e[6] !== t ? (G = () => {
        ot(t)
    }, B = [t], e[6] = t, e[7] = G, e[8] = B) : (G = e[7], B = e[8]), i.useEffect(G, B);
    let U, W;
    e[9] !== t || e[10] !== k || e[11] !== o || e[12] !== a ? (U = () => {
        const l = a.get(ve) === "true",
            p = a.get(Pe) === "true";
        p !== k && ge.set(t, p), o !== l && (be.set(t, l), l && ye.logEvent("Enable Temporary Chat"))
    }, W = [t, o, k, a], e[9] = t, e[10] = k, e[11] = o, e[12] = a, e[13] = U, e[14] = W) : (U = e[13], W = e[14]), i.useEffect(U, W);
    let K;
    e[15] !== s.state ? (K = () => {
        var l;
        (l = s.state) != null && l.focusObject && et.setFocusedObject(s.state.focusObject)
    }, e[15] = s.state, e[16] = K) : K = e[16];
    const fe = (de = s.state) == null ? void 0 : de.focusObject;
    let N;
    e[17] !== fe ? (N = [fe], e[17] = fe, e[18] = N) : N = e[18], i.useEffect(K, N);
    let H, Q;
    e[19] !== t || e[20] !== C || e[21] !== T || e[22] !== S ? (H = () => {
        !T && C && (h(t, m.hasSeenPioneer), S())
    }, Q = [t, C, T, S], e[19] = t, e[20] = C, e[21] = T, e[22] = S, e[23] = H, e[24] = Q) : (H = e[23], Q = e[24]), i.useEffect(H, Q);
    let Y, $;
    e[25] !== t || e[26] !== v || e[27] !== P || e[28] !== y ? (Y = () => {
        !P && v && (h(t, m.hasSeenSeeker), y())
    }, $ = [t, v, P, y], e[25] = t, e[26] = v, e[27] = P, e[28] = y, e[29] = Y, e[30] = $) : (Y = e[29], $ = e[30]), i.useEffect(Y, $);
    let q, D;
    e[31] !== t || e[32] !== I || e[33] !== A || e[34] !== L ? (q = () => {
        !A && I && (h(t, m.hasSeenMaverick), L())
    }, D = [t, I, A, L], e[31] = t, e[32] = I, e[33] = A, e[34] = L, e[35] = q, e[36] = D) : (q = e[35], D = e[36]), i.useEffect(q, D);
    let V, Z;
    e[37] !== t || e[38] !== _ || e[39] !== j || e[40] !== w ? (V = () => {
        !j && _ && (h(t, m.hasSeenTrailBlazer), w())
    }, Z = [t, _, j, w], e[37] = t, e[38] = _, e[39] = j, e[40] = w, e[41] = V, e[42] = Z) : (V = e[41], Z = e[42]), i.useEffect(V, Z);
    let J, X;
    e[43] !== t || e[44] !== M || e[45] !== R || e[46] !== z ? (J = () => {
        !R && M && (h(t, m.hasSeenStratos), z())
    }, X = [t, M, R, z], e[43] = t, e[44] = M, e[45] = R, e[46] = z, e[47] = J, e[48] = X) : (J = e[47], X = e[48]), i.useEffect(J, X);
    let ee, te;
    e[49] !== t || e[50] !== x || e[51] !== F || e[52] !== O ? (ee = () => {
        !F && x && (h(t, m.hasSeenWayfinder), O())
    }, te = [t, x, F, O], e[49] = t, e[50] = x, e[51] = F, e[52] = O, e[53] = ee, e[54] = te) : (ee = e[53], te = e[54]), i.useEffect(ee, te), De(r.id);
    const u = Te();
    let se, ae;
    e[55] !== t || e[56] !== u ? (se = () => {
        Ie() && tt(u)
    }, ae = [u, t], e[55] = t, e[56] = u, e[57] = se, e[58] = ae) : (se = e[57], ae = e[58]), i.useEffect(se, ae), Ve(d);
    let ie, re;
    e[59] !== o || e[60] !== u ? (ie = () => Ae(we, {
        completionFinished: l => {
            var p;
            if (l.serverThreadId != null && !o) {
                const ne = (p = Le(l.serverThreadId)) == null ? void 0 : p.mode;
                (ne == null ? void 0 : ne.kind) === _e.GizmoInteraction && je.handleGizmoInteracted(u, ne.gizmo_id)
            }
        }
    }), re = [o, u], e[59] = o, e[60] = u, e[61] = ie, e[62] = re) : (ie = e[61], re = e[62]), i.useEffect(ie, re), Ze(), Je();
    let g;
    e[63] !== r.id || e[64] !== le ? (g = le && ce.jsx(Xe, {
        clientThreadId: r.id
    }), e[63] = r.id, e[64] = le, e[65] = g) : g = e[65];
    let oe;
    return e[66] !== E || e[67] !== r || e[68] !== g ? (oe = ce.jsx(at, {
        conversation: r,
        redirects: g,
        children: E
    }), e[66] = E, e[67] = r, e[68] = g, e[69] = oe) : oe = e[69], oe
}
typeof window < "u" && (window._g = rt.GOKU_SERVICE);
export {
    gt as C
};
//# sourceMappingURL=o1t7tjco4vvz2yct.js.map