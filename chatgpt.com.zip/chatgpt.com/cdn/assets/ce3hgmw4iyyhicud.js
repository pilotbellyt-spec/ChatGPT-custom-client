const e = "py-[0.108em]",
    t = "selection-highlight",
    o = {
        code: "".concat(e, " bg-[Highlight]"),
        document: "".concat(t, " bg-[Highlight]")
    },
    a = {
        code: "flex justify-start h-full",
        document: "flex h-full justify-center"
    },
    s = "shadow-[0_8px_12px_0_rgba(0,0,0,0.16),0_0_1px_0_rgba(0,0,0,0.60)] dark:shadow-[0_8px_16px_0_rgba(0,0,0,0.40),inset_0_0_1px_0_rgba(255,255,255,0.25),0_0_1px_0_rgba(0,0,0,0.60)]",
    r = {
        blockCommentHover: "z-[-1]",
        collapsedComment: "z-0",
        composer: "z-10",
        expandedComment: "z-10",
        chatOverlay: "z-20",
        commentGutter: "z-20",
        expandedCommentHovered: "z-30",
        expandedCommentFocused: "z-40",
        toolbar: "z-50",
        commentComposer: "z-50",
        textdocDiffLoadingOverlay: "z-60",
        acceleratorsOverlay: "z-60",
        accelerators: "z-70"
    },
    c = "text-token-text-primary disabled:text-token-text-tertiary bg-token-main-surface-secondary-selected hover:bg-token-surface-hover focus-visible:bg-token-surface-hover disabled:opacity-40";
export {
    a as C, t as D, o as H, c as N, s as T, r as Z, e as a
};
//# sourceMappingURL=ce3hgmw4iyyhicud.js.map