import {
    r as e
} from "./fg33krlcm0qyi6yw.js";

function C(i, r, f, s) {
    var d = this,
        c = e.useRef(null),
        a = e.useRef(0),
        o = e.useRef(0),
        t = e.useRef(null),
        l = e.useRef([]),
        m = e.useRef(),
        v = e.useRef(),
        F = e.useRef(i),
        R = e.useRef(!0);
    F.current = i;
    var y = typeof window < "u",
        w = !r && r !== 0 && y;
    if (typeof i != "function") throw new TypeError("Expected a function");
    r = +r || 0;
    var T = !!(f = f || {}).leading,
        b = !("trailing" in f) || !!f.trailing,
        p = "maxWait" in f,
        M = "debounceOnServer" in f && !!f.debounceOnServer,
        A = p ? Math.max(+f.maxWait || 0, r) : null;
    e.useEffect(function() {
        return R.current = !0,
            function() {
                R.current = !1
            }
    }, []);
    var O = e.useMemo(function() {
        var D = function(n) {
                var u = l.current,
                    h = m.current;
                return l.current = m.current = null, a.current = n, o.current = o.current || n, v.current = F.current.apply(h, u)
            },
            x = function(n, u) {
                w && cancelAnimationFrame(t.current), t.current = w ? requestAnimationFrame(n) : setTimeout(n, u)
            },
            S = function(n) {
                if (!R.current) return !1;
                var u = n - c.current;
                return !c.current || u >= r || u < 0 || p && n - a.current >= A
            },
            W = function(n) {
                return t.current = null, b && l.current ? D(n) : (l.current = m.current = null, v.current)
            },
            E = function n() {
                var u = Date.now();
                if (T && o.current === a.current && k(), S(u)) return W(u);
                if (R.current) {
                    var h = r - (u - c.current),
                        q = p ? Math.min(h, A - (u - a.current)) : h;
                    x(n, q)
                }
            },
            k = function() {
                s && s({})
            },
            g = function() {
                if (y || M) {
                    var n = Date.now(),
                        u = S(n);
                    if (l.current = [].slice.call(arguments), m.current = d, c.current = n, u) {
                        if (!t.current && R.current) return a.current = c.current, x(E, r), T ? D(c.current) : v.current;
                        if (p) return x(E, r), D(c.current)
                    }
                    return t.current || x(E, r), v.current
                }
            };
        return g.cancel = function() {
            t.current && (w ? cancelAnimationFrame(t.current) : clearTimeout(t.current)), a.current = 0, l.current = c.current = m.current = t.current = null
        }, g.isPending = function() {
            return !!t.current
        }, g.flush = function() {
            return t.current ? W(Date.now()) : v.current
        }, g
    }, [T, p, r, A, b, w, y, M, s]);
    return O
}

function P(i, r) {
    return i === r
}

function z(i, r, f) {
    var s = P,
        d = e.useRef(i),
        c = e.useState({})[1],
        a = C(e.useCallback(function(t) {
            d.current = t, c({})
        }, [c]), r, f, c),
        o = e.useRef(i);
    return s(o.current, i) || (a(i), o.current = i), [d.current, a]
}
export {
    z as a, C as c
};
//# sourceMappingURL=jdzosouyvpzu0tpb.js.map