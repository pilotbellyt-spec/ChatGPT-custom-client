import {
    c as e,
    s as r
} from "./dykg4ktvbu3mhmdo.js";
const o = e(r, "deeed5", 20, 20);
export {
    o as C
};
//# sourceMappingURL=gmop4abenl57iboh.js.map