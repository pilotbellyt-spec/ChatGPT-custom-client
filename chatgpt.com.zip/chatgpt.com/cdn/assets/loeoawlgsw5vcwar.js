import {
    hm as l
} from "./k15yxxoybkkir2ou.js";
import {
    de as g,
    o as S,
    dD as p,
    dF as u
} from "./dykg4ktvbu3mhmdo.js";
const v = g(t => ({
        currentTime: 0,
        setCurrentTime: e => t(() => ({
            currentTime: e
        })),
        isOpen: !1,
        openSidebar: () => t({
            isOpen: !0
        }),
        closeSidebar: () => t({
            isOpen: !1
        }),
        hoveringSpeakerId: null,
        setHoveringSpeakerId: e => t({
            hoveringSpeakerId: e
        }),
        editingSpeaker: null,
        setEditingSpeaker: e => t({
            editingSpeaker: e
        }),
        speakers: new Map,
        setSpeakers: e => t({
            speakers: e
        }),
        enableDebugger: !1,
        setEnableDebugger: e => t(() => ({
            enableDebugger: e
        })),
        selectedFilters: ["default", "revive"],
        setSelectedFilters: e => t(() => ({
            selectedFilters: e
        }))
    })),
    k = t => e => {
        var n, r, o;
        return (o = (r = (n = u.findNode(e, ({
            message: i
        }) => {
            var c;
            const a = (c = i.metadata) == null ? void 0 : c.canvas;
            return (a == null ? void 0 : a.create_source) === l.HIVE && a.textdoc_id === t && !!a.hive_id
        })) == null ? void 0 : n.message.metadata) == null ? void 0 : r.canvas) == null ? void 0 : o.hive_id
    },
    _ = t => {
        const e = Math.floor(t / 3600),
            n = Math.floor(t % 3600 / 60),
            r = t % 60,
            o = e.toString().padStart(2, "0"),
            i = n.toString().padStart(2, "0"),
            a = r.toString().padStart(2, "0");
        return e > 0 ? "".concat(o, ":").concat(i, ":").concat(a) : "".concat(i, ":").concat(a)
    },
    b = t => {
        var c, d, m;
        const {
            setSpeakers: e
        } = v.getState(), n = t.compact_transcript, r = Object.values((d = (c = t.compact_transcript) == null ? void 0 : c.speakers) != null ? d : {}), o = new Map(r == null ? void 0 : r.map(s => [s.id, {
            name: void 0,
            storedName: s.updated_name,
            placeholderName: s.name,
            isEdited: !1
        }]));
        return e(o), ((m = n == null ? void 0 : n.segments) != null ? m : []).map(s => ({
            speakerId: s.speaker_id,
            range: {
                min: s.start_seconds,
                max: s.end_seconds
            },
            content: s.content,
            filterDecision: s.filter_decision
        }))
    },
    C = () => S(p(), "1804926979");
export {
    C as c, _ as f, k as g, b as n, v as u
};
//# sourceMappingURL=loeoawlgsw5vcwar.js.map