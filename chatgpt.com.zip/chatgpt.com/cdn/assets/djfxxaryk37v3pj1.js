import {
    c as e,
    s as o
} from "./dykg4ktvbu3mhmdo.js";
const s = e(o, "f5c817", 19, 19),
    t = e(o, "c1e6c4", 20, 20);
export {
    s as S, t as T
};
//# sourceMappingURL=djfxxaryk37v3pj1.js.map