import {
    F as l
} from "./o4n6pqcoqgw7owdr.js";
import {
    P as t,
    _ as r,
    $ as y,
    bc as d,
    bd as g,
    I as F,
    b as P,
    to as v,
    o as h,
    hu as b,
    tp as u
} from "./dykg4ktvbu3mhmdo.js";
import {
    du as S,
    cD as A,
    cE as m
} from "./k15yxxoybkkir2ou.js";
import {
    r as p,
    d as I,
    v as f
} from "./fg33krlcm0qyi6yw.js";
let s = "",
    o = "";
const k = new Set,
    _ = {
        setSessionId(n) {
            s = n
        },
        setQuerySessionId(n) {
            k.clear(), o = n
        },
        logClick(n, a, e, c) {
            if (c != null) {
                const i = Math.max(0, Date.now() / 1e3 - c);
                d.hist(g.DEFAULT, "conversation_search.click.update_time_delta_seconds", [{
                    key: "source",
                    value: e
                }], i), y.logEvent("chatgpt_fannypack_click_update_time_delta_seconds", i, {
                    source: e
                })
            }
            r.addAction("fannypack.web.click", {
                index: a,
                source: e
            }), t.logEvent("FannyPack: Click result", {
                fanny_pack_session_id: s,
                fanny_pack_query_session_id: o,
                conversationId: n,
                index: a,
                source: e
            }), y.logEvent("chatgpt_fannypack_click", a, {
                index: String(a),
                source: e
            })
        },
        logClose(n) {
            t.logEvent("FannyPack: Close", {
                fanny_pack_session_id: s,
                source: n
            })
        },
        logOpen(n) {
            d.count(g.DEFAULT, "conversation_search.open", [{
                key: "source",
                value: n
            }]), r.addAction("fannypack.web.open", {
                source: n
            }), t.logEvent("FannyPack: Open", {
                fanny_pack_session_id: s,
                source: n
            }), y.logEvent("chatgpt_fannypack_open", n)
        },
        logQuery() {
            r.addAction("fannypack.web.query"), t.logEvent("FannyPack: Query", {
                fanny_pack_session_id: s,
                fanny_pack_query_session_id: o
            }), y.logEvent("chatgpt_fannypack_query")
        },
        logQueryError() {
            r.addError("fannypack.web.query_error"), t.logEvent("FannyPack: Query Error", {
                fanny_pack_session_id: s,
                fanny_pack_query_session_id: o
            })
        },
        logQueryMore() {
            r.addAction("fannypack.web.queryMore"), t.logEvent("FannyPack: Query Fetch More", {
                fanny_pack_session_id: s,
                fanny_pack_query_session_id: o
            }), y.logEvent("chatgpt_fannypack_query_more")
        },
        logNoResults() {
            t.logEvent("FannyPack: No results", {
                fanny_pack_session_id: s,
                fanny_pack_query_session_id: o
            })
        },
        logImpression(n, a, e) {
            k.has(e) || (k.add(e), t.logEvent("FannyPack: Impression", {
                fanny_pack_session_id: s,
                fanny_pack_query_session_id: o,
                source: n,
                index: a,
                conversation_id: e
            }))
        }
    };

function q() {
    const n = P(),
        a = F(n),
        {
            isFannyPackEnabled: e
        } = S(n),
        c = v(E => E.isActive),
        i = h(n, "1422501431");
    p.useEffect(() => {
        e && a && (i ? l.setCurrentAccountV2(a) : l.setCurrentAccount(a), l.init())
    }, [a, i, e]), p.useEffect(() => b(n).addAction({
        key: "toggleChatSearch",
        action: () => {
            c ? _.logClose("shortcut") : (_.setSessionId(f()), _.logOpen("shortcut")), u.setIsActive(!c)
        },
        actionMessageDescriptor: I({
            id: "oqatXV",
            defaultMessage: "Search chats"
        }),
        group: m.Core,
        keyboardBinding: [A.Mod, "k"]
    }), [n, c])
}

function C() {
    u.setIsActive(!0), _.setSessionId(f()), _.logOpen("button")
}
const L = Object.freeze(Object.defineProperty({
    __proto__: null,
    openFannyPackSearch: C,
    useInitializeFannyPackHandler: q
}, Symbol.toStringTag, {
    value: "Module"
}));
export {
    _ as F, L as a, q as u
};
//# sourceMappingURL=bo2v113kbgrh2zlp.js.map