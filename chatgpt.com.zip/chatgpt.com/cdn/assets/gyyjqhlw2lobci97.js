import {
    a0 as Y,
    c as A,
    a9 as F,
    a1 as B,
    r as M,
    l as H,
    a as N,
    j as e,
    a2 as U
} from "./fg33krlcm0qyi6yw.js";
import {
    C as V
} from "./o1t7tjco4vvz2yct.js";
import {
    mH as Q,
    b as w,
    CC as d,
    fM as b,
    fa as G,
    dh as Z,
    pZ as $,
    _ as D
} from "./dykg4ktvbu3mhmdo.js";
import {
    r as k,
    pe as z,
    F4 as J,
    F5 as I,
    t0 as W,
    ix as X
} from "./k15yxxoybkkir2ou.js";
import {
    P as tt
} from "./ib78f9d5brp6znzf.js";
import "./f4hwlnbelkgfnokn.js";
import "./ii1vbrsyheft91cc.js";
import "./hpmzcrnchtp2pgs4.js";
import "./k2oaaf8ac9lafsub.js";
import "./lans8a2ikbh9ax9r.js";
import "./j63amn1eooyu8ua6.js";
import "./k7bax4ffse9ora8u.js";
import "./jkejdo8v5ynnt9ff.js";
import "./o67bv4dtwt5l98l7.js";
import "./fj4bpqcms0mhjoda.js";
import "./eejiqzdptzp07q5y.js";
import "./ew68kf01y1h7e4uk.js";
import "./jttqqjx6qab96ezg.js";
import "./e3ddui4ro6nb7fig.js";
import "./iw47v9tf328v3kli.js";
import "./hz9475nc5ndyfqsu.js";
import "./ou2xm3xmri21t4zm.js";
import "./omy347b79inqzbaj.js";
import "./i5kvudettvxsr7pw.js";
import "./jlu292yvnhcpthaw.js";
import "./f78b2oufkmgyeo1t.js";
import "./f2t8zq7263afexpy.js";
import "./cw1lyo20zi7916n8.js";
import "./f0qxu1nkng007y6r.js";
import "./pau1yzg54moerxhg.js";
import "./omxv5qehu9kgsx7t.js";
import "./mstnrsa4h2hq1kxz.js";
import "./l13qvsuc1mktoblg.js";
import "./b6zf7y7f0igpluq0.js";
const K = {
        IIM: !1
    },
    et = {
        IIM: !0
    },
    Ft = () => (k(), {
        prefetchSearch: null
    }),
    Bt = ({
        currentUrl: r,
        nextUrl: t
    }) => {
        const s = r.searchParams,
            o = t.searchParams;
        return s.get(Q) !== o.get(Q) || s.get("q") !== o.get("q")
    },
    Ht = Y(function() {
        "use forget";
        const t = A.c(32),
            {
                conversationId: s
            } = F(),
            {
                prefetchSearchPromises: o,
                shouldPrefetchModels: S,
                shouldPrefetchInternalModels: E,
                shouldPrefetchStarterPrompts: R,
                shouldPrefetchHistory: _,
                shouldPrefetchStarredConversations: j
            } = B(),
            f = w(),
            h = z();
        let y, P;
        t[0] !== f || t[1] !== h ? (y = () => {
            if (h) return J(f)
        }, P = [h, f], t[0] = f, t[1] = h, t[2] = y, t[3] = P) : (y = t[2], P = t[3]), M.useEffect(y, P);
        const q = H();
        let x;
        t[4] !== q ? (x = q.some(ot), t[4] = q, t[5] = x) : x = t[5];
        const v = x,
            c = N();
        let C, O;
        t[6] !== c ? (C = () => {
            const L = [I(c, G(K), st), I(c, Z.queryKey, rt)];
            return () => {
                for (const T of L) T()
            }
        }, O = [c], t[6] = c, t[7] = C, t[8] = O) : (C = t[7], O = t[8]), M.useEffect(C, O);
        let i;
        t[9] !== v ? (i = v ? e.jsx(U, {}) : void 0, t[9] = v, t[10] = i) : i = t[10];
        let a;
        t[11] !== s || t[12] !== i ? (a = e.jsx(V, {
            urlThreadId: s,
            children: i
        }), t[11] = s, t[12] = i, t[13] = a) : a = t[13];
        let n;
        t[14] !== S ? (n = S && e.jsx(d, {
            queryOptions: b(K)
        }), t[14] = S, t[15] = n) : n = t[15];
        let u;
        t[16] !== E ? (u = E && e.jsx(d, {
            queryOptions: b(et)
        }), t[16] = E, t[17] = u) : u = t[17];
        let l;
        t[18] !== R ? (l = R && e.jsx(d, {
            queryOptions: W()
        }), t[18] = R, t[19] = l) : l = t[19];
        let p;
        t[20] !== _ ? (p = _ && e.jsx(d, {
            queryOptions: $()
        }), t[20] = _, t[21] = p) : p = t[21];
        let m;
        t[22] !== j ? (m = j && e.jsx(d, {
            queryOptions: X()
        }), t[22] = j, t[23] = m) : m = t[23];
        let g;
        return t[24] !== o || t[25] !== p || t[26] !== m || t[27] !== a || t[28] !== n || t[29] !== u || t[30] !== l ? (g = e.jsxs(tt.Provider, {
            value: o,
            children: [a, n, u, l, p, m]
        }), t[24] = o, t[25] = p, t[26] = m, t[27] = a, t[28] = n, t[29] = u, t[30] = l, t[31] = g) : g = t[31], g
    });

function rt() {
    D.addFirstTiming("load.user-query")
}

function st() {
    D.addFirstTiming("load.models")
}

function ot(r) {
    return r.loaderData && typeof r.loaderData == "object" && "isOutletBasedRoute" in r.loaderData && r.loaderData.isOutletBasedRoute
}
export {
    Ft as clientLoader, Ht as
    default, Bt as shouldRevalidate
};
//# sourceMappingURL=gyyjqhlw2lobci97.js.map