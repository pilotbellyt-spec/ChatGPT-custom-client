function d(e) {
    for (var f = 0, x, a = 0, c = e.length; c >= 4; ++a, c -= 4) x = e.charCodeAt(a) & 255 | (e.charCodeAt(++a) & 255) << 8 | (e.charCodeAt(++a) & 255) << 16 | (e.charCodeAt(++a) & 255) << 24, x = (x & 65535) * 1540483477 + ((x >>> 16) * 59797 << 16), x ^= x >>> 24, f = (x & 65535) * 1540483477 + ((x >>> 16) * 59797 << 16) ^ (f & 65535) * 1540483477 + ((f >>> 16) * 59797 << 16);
    switch (c) {
        case 3:
            f ^= (e.charCodeAt(a + 2) & 255) << 16;
        case 2:
            f ^= (e.charCodeAt(a + 1) & 255) << 8;
        case 1:
            f ^= e.charCodeAt(a) & 255, f = (f & 65535) * 1540483477 + ((f >>> 16) * 59797 << 16)
    }
    return f ^= f >>> 13, f = (f & 65535) * 1540483477 + ((f >>> 16) * 59797 << 16), ((f ^ f >>> 15) >>> 0).toString(36)
}
export {
    d as m
};
//# sourceMappingURL=ol9d5wxhynx9q2is.js.map