const s = "/cdn/assets/sprites-wham-n3wclldf.svg";
export {
    s
};
//# sourceMappingURL=cmaobpdpreyiep8p.js.map