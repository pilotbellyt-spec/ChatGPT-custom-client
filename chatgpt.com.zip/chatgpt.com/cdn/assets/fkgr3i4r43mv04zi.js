var m = Object.freeze,
    x = Object.defineProperty;
var d = Object.getOwnPropertySymbols;
var g = Object.prototype.hasOwnProperty,
    h = Object.prototype.propertyIsEnumerable;
var p = (e, t, a) => t in e ? x(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: a
    }) : e[t] = a,
    r = (e, t) => {
        for (var a in t || (t = {})) g.call(t, a) && p(e, a, t[a]);
        if (d)
            for (var a of d(t)) h.call(t, a) && p(e, a, t[a]);
        return e
    };
var y = (e, t) => {
    var a = {};
    for (var l in e) g.call(e, l) && t.indexOf(l) < 0 && (a[l] = e[l]);
    if (e != null && d)
        for (var l of d(e)) t.indexOf(l) < 0 && h.call(e, l) && (a[l] = e[l]);
    return a
};
var u = (e, t) => m(x(e, "raw", {
    value: m(t || e.slice())
}));
import {
    f as N,
    j as s,
    M as L,
    r as B,
    e as P
} from "./fg33krlcm0qyi6yw.js";
import {
    F as c,
    l as F,
    a9 as k
} from "./dykg4ktvbu3mhmdo.js";
import {
    C as A
} from "./bgu63yibe22v7x29.js";
import {
    d4 as D
} from "./k15yxxoybkkir2ou.js";
const w = N({
        optionalField: {
            id: "UgRDQq",
            defaultMessage: "(optional)"
        },
        teamSignUpPageTitle: {
            id: "Q4AUMN",
            defaultMessage: "Sign up for a Business plan"
        },
        tellUsAboutWorkStepTitle: {
            id: "9TW5Ss",
            defaultMessage: "Tell us about your work"
        },
        tellUsAboutWorkStepSubtitle: {
            id: "9BRmB/",
            defaultMessage: "We'll use these details to suggest ideas that might be useful in your role."
        },
        workspaceNameStepTitle: {
            id: "dxmw1u",
            defaultMessage: "Set up your workspace"
        },
        workspaceNameStepSubtitle: {
            id: "z5NAj9",
            defaultMessage: "You'll use this secure space to manage and collaborate with your team."
        },
        workspaceNameLabel: {
            id: "ZCGF0W",
            defaultMessage: "Workspace name"
        },
        workspaceNamePlaceholder: {
            id: "/MmHRi",
            defaultMessage: "Enter your workspace name"
        },
        roleLabel: {
            id: "ATtnlf",
            defaultMessage: "Role"
        },
        rolePlaceholder: {
            id: "lxHk5i",
            defaultMessage: "Select your role"
        },
        workspaceDepartmentLabel: {
            id: "CC7rYc",
            defaultMessage: "Area of work"
        },
        workspaceDepartmentPlaceholder: {
            id: "V/v9DL",
            defaultMessage: "Select your area of work"
        },
        workspaceCompanySizeLabel: {
            id: "5usFs1",
            defaultMessage: "Company size"
        },
        workspaceCompanySizePlaceholder: {
            id: "drld/V",
            defaultMessage: "Select your company size"
        },
        seatsCountLabel: {
            id: "MNbf/N",
            defaultMessage: "Seats"
        },
        purchaseStepTitle: {
            id: "cx09AW",
            defaultMessage: "Set up your Business plan"
        },
        purchaseStepSubtitle: {
            id: "sJErhK",
            defaultMessage: "Minimum 2 seats. Add and reassign seats at anytime"
        },
        oneDollarPromoTitle: {
            id: "AlEIaa",
            defaultMessage: "Start your trial"
        },
        freeTrialPromoTitle: {
            id: "BrbO2n",
            defaultMessage: "Start your free trial"
        },
        oneDollarPromoSubtitle: {
            id: "woJKaK",
            defaultMessage: "Try ChatGPT Business for $1 for up to 5 seats. After the first month, it’s $30 per seat."
        },
        freeTrialPromoSubtitle: {
            id: "HFQvZ/",
            defaultMessage: "Try ChatGPT Business for free, up to 5 seats. After the first month, it's $30 per seat."
        },
        salesMarketingPromoSubtitleOneDollar: {
            id: "vrk97i",
            defaultMessage: "Drive more leads & growth — activate your ChatGPT Business trial for $1 (up to 5 seats)."
        },
        salesMarketingPromoSubtitleFree: {
            id: "SB66jJ",
            defaultMessage: "Drive more leads & growth — activate your ChatGPT Business trial for free (up to 5 seats)."
        },
        planTypeLabel: {
            id: "RZFV+2",
            defaultMessage: "Plan type"
        },
        annualPlanLabel: {
            id: "0Y3Keg",
            defaultMessage: "Annually <span>({percent}% off)</span>"
        },
        monthlyPlanLabel: {
            id: "y5L8+O",
            defaultMessage: "Monthly"
        },
        planSummaryTitle: {
            id: "9UIAWd",
            defaultMessage: "Plan Summary"
        },
        allPlansTodayTotal: {
            id: "CNJp97",
            defaultMessage: "Today's total"
        },
        today: {
            id: "QM0nNf",
            defaultMessage: "Today"
        },
        fieldRequired: {
            id: "txrvew",
            defaultMessage: "{fieldName} is required"
        },
        continueButton: {
            id: "CYZ25s",
            defaultMessage: "Continue"
        }
    }),
    V = ({
        content: e,
        onPrevious: t,
        headerPaddingClassName: a,
        forceLightTheme: l
    }) => s.jsxs("div", {
        className: F("relative flex min-h-[100dvh] w-screen justify-center overflow-y-auto", l && "light bg-white text-gray-950", a != null ? a : "pt-16 [@media(min-width:450px)]:pt-[12vh]"),
        children: [t && s.jsx("div", {
            className: "absolute start-4 top-4",
            children: s.jsx(k, {
                onClick: t,
                icon: A,
                color: "ghost"
            })
        }), s.jsx("div", {
            className: "flex max-w-full flex-none items-center justify-center [@media(min-width:450px)]:w-[380px]",
            children: e
        })]
    }),
    Y = ({
        title: e,
        subTitle: t,
        children: a
    }) => s.jsxs("div", {
        className: "box-content flex w-full flex-col gap-6 px-4",
        children: [s.jsxs("div", {
            className: "flex flex-col gap-4 text-center",
            children: [s.jsx("div", {
                className: "text-3xl font-normal",
                children: e
            }), t && s.jsx("div", {
                className: "text-token-text-secondary",
                children: t
            })]
        }), a]
    }),
    Z = ({
        onClick: e,
        disabled: t
    }) => {
        const [a, l] = B.useState(!1), o = P();
        return s.jsx(k, {
            size: "large",
            loading: a,
            disabled: t,
            onClick: async () => {
                l(!0), await e(), l(!1)
            },
            children: o.formatMessage(w.continueButton)
        })
    };
var M;
const I = c.label(M || (M = u(["font-medium"])));
var b;
const j = c.div(b || (b = u(["text-red-500 text-sm mb-2"])));
var S;
const W = c.input(S || (S = u(["rounded-full border border-token-border-default bg-token-bg-primary placeholder:text-token-text-tertiary px-5 py-3 focus:border-token-icon-accent focus:ring-token-icon-accent focus:ring-0"]))),
    $ = e => {
        switch (e.formType) {
            case "input":
                return s.jsx(z, r({}, e));
            case "select":
                return s.jsx(R, r({}, e))
        }
        return null
    },
    T = ({
        children: e,
        required: t
    }) => s.jsxs(I, {
        children: [e, !t && s.jsxs("span", {
            className: "text-token-text-secondary text-xs",
            children: [" ", s.jsx(L, r({}, w.optionalField))]
        })]
    }),
    z = E => {
        var f = E,
            {
                label: e,
                name: t,
                placeholder: a,
                value: l,
                onChange: o,
                required: i,
                error: n
            } = f,
            v = y(f, ["label", "name", "placeholder", "value", "onChange", "required", "error"]);
        return s.jsxs("div", {
            className: "flex flex-col gap-1.5",
            children: [s.jsx(T, {
                required: i,
                children: e
            }), s.jsx(W, r({
                name: t,
                placeholder: a,
                value: l,
                onChange: C => o(C.target.value),
                required: i
            }, v)), n && s.jsx(j, {
                children: n
            })]
        })
    },
    R = ({
        label: e,
        value: t,
        onChange: a,
        placeholder: l,
        error: o,
        options: i,
        required: n
    }) => s.jsxs("div", {
        className: "flex flex-col gap-1.5",
        children: [s.jsx(T, {
            required: n,
            children: e
        }), s.jsx(D, {
            triggerClassName: "w-full flex justify-between rounded-full border border-token-border-default bg-token-bg-primary data-placeholder:text-token-text-tertiary px-5 py-3 text-md h-12",
            contentClassName: "max-h-80 w-full",
            options: i,
            value: t,
            onValueChange: a,
            placeholder: l
        }), o && s.jsx(j, {
            children: o
        })]
    });
export {
    Z as C, Y as F, W as I, T as L, V as S, $ as a, w as c
};
//# sourceMappingURL=fkgr3i4r43mv04zi.js.map