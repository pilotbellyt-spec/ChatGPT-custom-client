var x = Object.defineProperty,
    P = Object.defineProperties;
var M = Object.getOwnPropertyDescriptors;
var v = Object.getOwnPropertySymbols;
var E = Object.prototype.hasOwnProperty,
    B = Object.prototype.propertyIsEnumerable;
var w = (a, e, t) => e in a ? x(a, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : a[e] = t,
    _ = (a, e) => {
        for (var t in e || (e = {})) E.call(e, t) && w(a, t, e[t]);
        if (v)
            for (var t of v(e)) B.call(e, t) && w(a, t, e[t]);
        return a
    },
    g = (a, e) => P(a, M(e));
var f = (a, e, t) => w(a, typeof e != "symbol" ? e + "" : e, t);
import {
    p as T,
    R as r,
    _ as k,
    me as I,
    sB as l
} from "./dykg4ktvbu3mhmdo.js";
import {
    gl as y,
    gm as q
} from "./k15yxxoybkkir2ou.js";
import "./fg33krlcm0qyi6yw.js";
import {
    W as C,
    a as b,
    b as W
} from "./dqz86fcur874gotm.js";

function Q(a, e, t, s) {
    switch (a.type) {
        case "repo_not_accessible":
            s.danger(t.formatMessage({
                id: "wham.whamComposer.repoNotAccessible",
                defaultMessage: "Can’t access GitHub repository. Verify your repository access on GitHub, or reconnect your GitHub account in Codex Settings."
            }), {
                id: e,
                duration: 10,
                hasCloseButton: !0,
                loggingTitle: "Can't access GitHub repository. Verify your repository access on GitHub, or reconnect your GitHub account in Codex Settings."
            });
            return;
        case "missing_github_connector_link":
            s.danger(t.formatMessage({
                id: "wham.whamComposer.missingGithubConnectorLink",
                defaultMessage: "No GitHub connection. Please reconnect your GitHub account in Codex Settings."
            }), {
                id: e,
                duration: 10,
                hasCloseButton: !0,
                loggingTitle: "No GitHub connection. Please reconnect your GitHub account in Codex Settings."
            });
            return;
        case "non_terminal_turn":
            s.danger(t.formatMessage({
                id: "wham.whamComposer.nonTerminalTurn",
                defaultMessage: "Task already has a running turn"
            }), {
                id: e,
                duration: 10,
                hasCloseButton: !0,
                loggingTitle: "Task already has a running turn"
            });
            return;
        case "repo_not_initialized":
            s.danger(t.formatMessage({
                id: "wham.whamComposer.repoNotInitialized",
                defaultMessage: "GitHub Repository must be initialized to be used within Codex"
            }), {
                id: e,
                duration: 10,
                hasCloseButton: !0,
                loggingTitle: "GitHub Repository must be initialized to be used within Codex"
            });
            return;
        case "environment_invalid_email":
            {
                const i = (Array.isArray(a.payload.invalid_emails) ? a.payload.invalid_emails : []).join(", "),
                    d = i ? t.formatMessage({
                        id: "wham.whamRequests.environmentInvalidEmailWithList",
                        defaultMessage: "Some share target emails aren't part of this workspace: {emails}"
                    }, {
                        emails: i
                    }) : t.formatMessage({
                        id: "wham.whamRequests.environmentInvalidEmailBase",
                        defaultMessage: "Some share target emails aren't part of this workspace. Update the list and try again."
                    });s.danger(d, {
                    id: e,
                    duration: 8,
                    hasCloseButton: !0,
                    loggingTitle: i ? "Invalid workspace emails: ".concat(i) : "Stale environment update"
                });
                return
            }
        case "environment_stale_update":
            s.danger(t.formatMessage({
                id: "wham.whamRequests.environmentStaleUpdate",
                defaultMessage: "This environment changed while you were editing. Refresh and try again."
            }), {
                id: e,
                duration: 8,
                hasCloseButton: !0,
                loggingTitle: "This environment changed while you were editing. Refresh and try again."
            });
            return;
        case "environment_repo_access_failed":
            s.danger(t.formatMessage({
                id: "wham.whamRequests.environmentRepoAccessFailed",
                defaultMessage: "Codex can’t access this GitHub repository. Check the repository’s Codex installation and permissions, then try again."
            }), {
                id: e,
                duration: 8,
                hasCloseButton: !0,
                loggingTitle: "Codex can’t access this GitHub repository. Check the repository’s Codex installation and permissions, then try again."
            });
            return;
        case "branch_creation_not_allowed":
            s.danger(t.formatMessage({
                id: "wham.whamComposer.branchCreationNotAllowed",
                defaultMessage: "Branch creation unauthorized for this repository. Please check your GitHub permissions."
            }), {
                loggingTitle: "Branch creation unauthorized for this repository. Please check your GitHub permissions."
            });
            return;
        case "pull_request_not_allowed":
            s.danger(t.formatMessage({
                id: "wham.whamComposer.pullRequestNotAllowed",
                defaultMessage: "Repository does not allow pull requests from Codex. Please check your GitHub permissions."
            }), {
                loggingTitle: "Repository does not allow pull requests from Codex. Please check your GitHub permissions."
            });
            return;
        case "verified_commits_required":
            s.danger(t.formatMessage({
                id: "wham.whamComposer.verifiedCommitsRequired",
                defaultMessage: "Codex does not currently support PRs in repositories that require verified commits"
            }), {
                loggingTitle: "Codex does not currently support PRs in repositories that require verified commits"
            });
            return;
        case "binary_files_not_supported":
            s.danger(t.formatMessage({
                id: "wham.whamComposer.binaryFilesNotSupported",
                defaultMessage: "Binary files are not supported"
            }), {
                id: e,
                duration: 10,
                hasCloseButton: !0
            });
            return;
        case "commit_pattern_required":
            s.danger(t.formatMessage({
                id: "wham.whamComposer.commitPatternRequired",
                defaultMessage: "Commit message must match a given regex pattern"
            }), {
                id: e,
                duration: 10,
                hasCloseButton: !0
            });
            return;
        case "pull_request_updated_outside_of_codex":
            s.danger(t.formatMessage({
                id: "wham.whamComposer.pullRequestUpdatedOutsideOfCodex",
                defaultMessage: "Codex does not currently support updating PRs that are updated outside of Codex. For now, please create a new PR."
            }), {
                id: e,
                duration: 10,
                hasCloseButton: !0
            });
            return;
        case "pull_request_not_open":
            s.danger(t.formatMessage({
                id: "wham.whamComposer.pullRequestNotOpen",
                defaultMessage: "Pull request is no longer open. Refreshing status…"
            }), {
                id: e,
                duration: 10,
                hasCloseButton: !0
            });
            return;
        case "branch_no_longer_exists":
            s.danger(t.formatMessage({
                id: "wham.whamComposer.branchNoLongerExists",
                defaultMessage: "Existing PR branch appears to no longer exist. Please create a new PR."
            }), {
                id: e,
                duration: 10,
                hasCloseButton: !0
            });
            return;
        case "pull_request_not_found_on_task":
            s.danger(t.formatMessage({
                id: "wham.whamComposer.pullRequestNotFoundOnTask",
                defaultMessage: "Pull request not found for task"
            }), {
                id: e,
                duration: 10,
                hasCloseButton: !0,
                loggingTitle: "Binary files are not supported"
            });
            return;
        default:
            return s.danger(a.payload.message, {
                id: e,
                duration: 5,
                hasCloseButton: !0
            }), null
    }
}
class $ extends T {
    constructor(t, s, n, i, d) {
        super(t.message, s, n, i, d);
        f(this, "type");
        f(this, "payload");
        this.type = t.type, this.payload = t
    }
}

function A(a) {
    const e = a.detail;
    if (e && typeof e.type == "string" && typeof e.message == "string") {
        const t = {
            type: e.type,
            message: e.message
        };
        throw Object.entries(e).forEach(([s, n]) => {
            s === "type" || s === "message" || (t[s] = n)
        }), new $(t, a.status, {}, a.requestId, a.rawError)
    }
    throw a
}
class R {
    static async _wrapWhamRequest(e) {
        try {
            return await e()
        } catch (t) {
            throw t instanceof T && A(t), t
        }
    }
    static getTasks(e = 10, t = null, s = "current") {
        return this._wrapWhamRequest(() => r.safeGet("/wham/tasks", {
            parameters: {
                query: {
                    limit: e,
                    cursor: t,
                    task_filter: s
                }
            }
        }))
    }
    static getTasksForList(e = 10, t = null, s = "current") {
        return this._wrapWhamRequest(() => r.safeGet("/wham/tasks/list", {
            parameters: {
                query: {
                    limit: e,
                    cursor: t,
                    task_filter: s
                }
            }
        }))
    }
    static getTaskDetails(e) {
        return this._wrapWhamRequest(() => r.safeGet("/wham/tasks/{task_id}", {
            parameters: {
                path: {
                    task_id: e
                }
            }
        }))
    }
    static getTaskTurnPR(e, t) {
        return this._wrapWhamRequest(() => r.safeGet("/wham/tasks/{task_id}/turns/{task_turn_id}/pr", {
            parameters: {
                path: {
                    task_id: e,
                    task_turn_id: t
                }
            }
        }))
    }
    static getUserHandle() {
        return this._wrapWhamRequest(() => r.safeGet("/wham/task_suggestions/github/user_handle", {}))
    }
    static getTaskTurn(e, t) {
        return this._wrapWhamRequest(() => r.safeGet("/wham/tasks/{task_id}/turns/{task_turn_id}", {
            parameters: {
                path: {
                    task_id: e,
                    task_turn_id: t
                }
            }
        }))
    }
    static getRateLimitStatus() {
        return this._wrapWhamRequest(() => r.safeGet("/wham/usage", {}))
    }
    static getDailyTokenUsageBreakdown() {
        return this._wrapWhamRequest(() => r.safeGet("/wham/usage/daily-token-usage-breakdown", {}))
    }
    static getDailyEnterpriseTokenUsageBreakdown() {
        return this._wrapWhamRequest(() => r.safeGet("/wham/usage/daily-enterprise-token-usage-breakdown", {}))
    }
    static getCreditUsageEvents() {
        return this._wrapWhamRequest(() => r.safeGet("/wham/usage/credit-usage-events", {}))
    }
    static getLatestTaskTurns(e, t) {
        return this._wrapWhamRequest(() => r.safeGet("/wham/tasks/{task_id}/turns/{task_turn_id}/latest_turn", {
            parameters: {
                path: {
                    task_id: e,
                    task_turn_id: t
                }
            }
        }))
    }
    static getGithubInstallations() {
        return this._wrapWhamRequest(() => r.safeGet("/wham/github/installations", {}))
    }
    static getGithubInstallationsV2() {
        return this._wrapWhamRequest(() => r.safeGet("/wham/github/installations/v2", {}))
    }
    static getGithubInstallationEvents() {
        return this._wrapWhamRequest(() => r.safeGet("/wham/github/installations/events", {}))
    }
    static getGithubInstallationEventsV2() {
        return this._wrapWhamRequest(() => r.safeGet("/wham/github/installations/events/v2", {}))
    }
    static feedback({
        thumbRating: e,
        text: t,
        taskId: s,
        turnId: n,
        shareUrl: i,
        pullRequestUrl: d,
        category: c
    }) {
        return this._wrapWhamRequest(() => r.safePost("/wham/feedback", {
            requestBody: {
                thumb_rating: e,
                text: t,
                conversation_id: null,
                message_id: null,
                task_id: s,
                turn_id: n,
                share_url: i,
                pull_request_url: d,
                category: c
            }
        }))
    }
    static archiveTask(e) {
        return this._wrapWhamRequest(() => r.safePost("/wham/tasks/{task_id}/archive", {
            parameters: {
                path: {
                    task_id: e
                }
            }
        }))
    }
    static recoverTask(e) {
        return this._wrapWhamRequest(() => r.safePost("/wham/tasks/{task_id}/recover", {
            parameters: {
                path: {
                    task_id: e
                }
            }
        }))
    }
    static updatePr(e, t, s) {
        return this._wrapWhamRequest(() => r.safePatch("/wham/tasks/{task_id}/turns/{task_turn_id}/pr/{pr_id}", {
            parameters: {
                path: {
                    task_id: e,
                    task_turn_id: t,
                    pr_id: s
                }
            }
        }))
    }
    static createPr(e, t, s, n) {
        return this._wrapWhamRequest(() => r.safePost("/wham/tasks/{task_id}/turns/{task_turn_id}/pr", {
            parameters: {
                path: {
                    task_id: e,
                    task_turn_id: t
                }
            },
            requestBody: {
                mode: s,
                add_codex_tag: n
            }
        }))
    }
    static getRepositoriesByInstallationId(e, t, s) {
        return this._wrapWhamRequest(() => r.safeGet("/wham/github/repositories/v2/{installation_id}", {
            parameters: {
                path: {
                    installation_id: e
                },
                query: {
                    page: t,
                    per_page: s
                }
            }
        }))
    }
    static searchRepositories(e) {
        var s, n;
        const t = g(_({}, e), {
            per_page: (s = e.per_page) != null ? s : 20,
            page: (n = e.page) != null ? n : 1
        });
        return this._wrapWhamRequest(() => r.safeGet("/wham/github/repositories/search", {
            parameters: {
                query: t
            }
        }))
    }
    static searchRepositoriesAllInstallations(e) {
        return this._wrapWhamRequest(() => {
            var t;
            return r.safeGet("/wham/github/repositories/search/all-installations", {
                parameters: {
                    query: g(_({}, e), {
                        page: (t = e.page) != null ? t : 1
                    })
                }
            })
        })
    }
    static listRepositories(e) {
        return this._wrapWhamRequest(() => r.safeGet("/wham/github/list-repositories", {
            parameters: {
                query: e
            }
        }))
    }
    static getSampleTasks(e = 20, t = null) {
        return this._wrapWhamRequest(() => r.safeGet("/share/codex/task_samples", {
            parameters: {
                query: {
                    limit: e,
                    cursor: t
                }
            }
        }))
    }
    static getRepository(e) {
        return this._wrapWhamRequest(() => r.safeGet("/wham/github/repositories/{repo_id}", {
            parameters: {
                path: {
                    repo_id: e
                }
            }
        }))
    }
    static getUserPullRequests(e, {
        limit: t = 20,
        state: s = "open",
        includeDiff: n = !1,
        includeComments: i = !1
    } = {}) {
        return this._wrapWhamRequest(() => r.safeGet("/wham/github/repositories/{repo_id}/pull-requests", {
            parameters: {
                path: {
                    repo_id: e
                },
                query: {
                    limit: t,
                    state: s,
                    include_diff: n,
                    include_comments: i
                }
            }
        }))
    }
    static searchBranchesByRepository(e, t, s = 10, n = null) {
        return this._wrapWhamRequest(() => r.safeGet("/wham/github/branches/{repo_id}/search", {
            parameters: {
                path: {
                    repo_id: e
                },
                query: {
                    query: t,
                    page_size: s,
                    cursor: n
                }
            }
        }))
    }
    static getEnvironmentWithCreatorAndMachine(e) {
        return this._wrapWhamRequest(() => r.safeGet("/wham/environments/{environment_id}/with-creator-and-machine", {
            parameters: {
                path: {
                    environment_id: e
                }
            }
        }))
    }
    static getEnvironmentWithCreators(e = 10, t = null, s = !1) {
        return this._wrapWhamRequest(() => r.safeGet("/wham/environments/with-creators", {
            parameters: {
                query: {
                    limit: e,
                    cursor: t,
                    enforce_repo_access: s
                }
            }
        }))
    }
    static updateEnvironment(e, t) {
        return this._wrapWhamRequest(() => r.safePatch("/wham/environments/{environment_id}", {
            parameters: {
                path: {
                    environment_id: e
                }
            },
            requestBody: t
        }))
    }
    static deleteEnvironment(e) {
        return this._wrapWhamRequest(() => r.safeDelete("/wham/environments/{environment_id}", {
            parameters: {
                path: {
                    environment_id: e
                }
            }
        }))
    }
    static getEnvironments() {
        return this._wrapWhamRequest(() => r.safeGet("/wham/environments", {}))
    }
    static getRecentEnvironments() {
        return this._wrapWhamRequest(() => r.safeGet("/wham/environments/recent", {}))
    }
    static getMachines() {
        return this._wrapWhamRequest(() => r.safeGet("/wham/machines", {}))
    }
    static createEnvironment(e) {
        var o, m;
        const t = e.envVars.reduce((u, h) => (u[h.key] = h.value, u), {}),
            s = e.secrets.some(u => u.domain !== void 0 && u.domain !== null && u.domain !== ""),
            n = s ? void 0 : e.secrets.reduce((u, h) => (u[h.key] = h.value, u), {}),
            i = s ? e.secrets.map(u => ({
                name: u.key,
                domain: u.domain || null,
                value: u.value
            })) : void 0,
            d = (m = (o = e.share_targets) == null ? void 0 : o.map(u => u.trim())) == null ? void 0 : m.filter(Boolean),
            c = e.share_settings === "private" ? [] : d == null ? void 0 : d.map(u => ({
                email: u,
                permission: "editor",
                type: "user"
            })),
            p = e.enableAuthtranslator;
        return this._wrapWhamRequest(() => r.safePost("/wham/environments", {
            requestBody: g(_(_({
                label: e.label,
                machine_id: e.machine,
                repos: [e.repositoryId],
                description: e.description,
                setup: e.setupCommands,
                maintenance_setup: e.maintenanceSetupCommands,
                workspace_dir: e.workspaceDirectory,
                agent_network_access: e.agentNetworkAccess,
                share_settings: e.share_settings,
                share_targets: c,
                env_vars: t
            }, i ? {
                secrets_with_domains: i
            } : n ? {
                secrets: n
            } : {}), p !== void 0 ? {
                enable_authtranslator: p
            } : {}), {
                auto_setup_settings: e.autoSetupSettings,
                cache_settings: e.cacheSettings
            })
        }))
    }
    static runEnvironmentTestCommand(e) {
        return this._wrapWhamRequest(() => r.safePost("/wham/environments/test/{test_session_id}/command", {
            parameters: {
                path: {
                    test_session_id: e.testSessionId
                }
            },
            requestBody: {
                command: e.command
            }
        }))
    }
    static getUserPreferences() {
        return this._wrapWhamRequest(() => r.safeGet("/wham/settings/user", {}))
    }
    static getUserPreferencesConfig() {
        return this._wrapWhamRequest(() => r.safeGet("/wham/settings/configs/user-preferences", {}))
    }
    static getCodeReviewRepositories({
        page: e = 1,
        perPage: t = 100,
        search: s,
        nextToken: n
    }) {
        return this._wrapWhamRequest(() => r.safeGet("/wham/settings/code_review", {
            parameters: {
                query: {
                    page: e,
                    per_page: t,
                    search: s,
                    next_token: n
                }
            }
        }))
    }
    static searchCodeReviewRepositories({
        query: e,
        limit: t,
        installationIds: s,
        page: n
    }) {
        return this._wrapWhamRequest(async () => await r.safeGet("/wham/settings/code_review_search", {
            parameters: {
                query: {
                    query: e,
                    limit: t,
                    installation_ids: s,
                    page: n != null ? n : 1
                }
            }
        }))
    }
    static getCodeReviewRepository(e, t) {
        return this._wrapWhamRequest(() => r.safeGet("/wham/settings/code_review/{repo_id}", {
            parameters: {
                path: {
                    repo_id: "".concat(e, "-").concat(t)
                }
            }
        }))
    }
    static updateCodeReviewRepositories(e) {
        return this._wrapWhamRequest(() => r.safePatch("/wham/settings/code_review", {
            requestBody: e
        }))
    }
    static updateUserPreferences(e) {
        return this._wrapWhamRequest(() => r.safePatch("/wham/settings/user", {
            requestBody: {
                branch_format: e.branchFormat,
                git_diff_mode: e.diffView,
                custom_instructions: e.customInstructions,
                code_review_preference: e.codeReviewPreference,
                alpha_opt_in: e.alphaOptIn,
                allow_credits_for_code_reviews: e.allowCreditsForCodeReviews
            }
        }))
    }
    static getTurns(e) {
        return this._wrapWhamRequest(() => r.safeGet("/wham/tasks/{task_id}/turns", {
            parameters: {
                path: {
                    task_id: e
                }
            }
        }))
    }
    static getTurnLogs(e, t) {
        return this._wrapWhamRequest(() => r.safeGet("/wham/tasks/{task_id}/turns/{task_turn_id}/logs", {
            parameters: {
                path: {
                    task_id: e,
                    task_turn_id: t
                }
            }
        }))
    }
    static async createNewTask(e, t, s, n = !1, i, d = [], c = []) {
        const o = [{
                type: "message",
                role: "user",
                content: [{
                    content_type: "text",
                    text: s
                }]
            }, ...d, ...c],
            m = await y("codex_create_task_turn").catch(h => {
                k.addError(h)
            }),
            u = q(null, null, null, m);
        return this._wrapWhamRequest(() => r.safePost("/wham/tasks", {
            requestBody: g(_({
                new_task: {
                    environment_id: e,
                    branch: t,
                    run_environment_in_qa_mode: n
                }
            }, i ? {
                metadata: {
                    best_of_n: i
                }
            } : {}), {
                input_items: o
            }),
            additionalHeaders: u
        }))
    }
    static async createFixReviewTask(e, t) {
        const s = await y("codex_create_task_turn").catch(i => {
                k.addError(i)
            }),
            n = q(null, null, null, s);
        return this._wrapWhamRequest(async () => {
            const i = {
                review_fix: {
                    task_id: e,
                    turn_id: t
                },
                input_items: []
            };
            return await r.safePost("/wham/tasks", {
                requestBody: i,
                additionalHeaders: n
            })
        })
    }
    static async createNewTaskWithEditedPrompt(e, t, s, n, i = !1) {
        const d = await R.createNewTask(t, s, n, i);
        return R.archiveTask(e).catch(() => {}), d
    }
    static createCodeReviewTask({
        installationId: e,
        repoId: t,
        prNumber: s
    }) {
        return this._wrapWhamRequest(() => r.safePost("/wham/github/installations/{installation_id}/repositories/{repo_id}/pull-request/{pr_number}/task", {
            parameters: {
                path: {
                    installation_id: e,
                    repo_id: t,
                    pr_number: s
                }
            },
            requestBody: {
                action: "review"
            }
        }))
    }
    static createCodeReviewTasksForOpenPullRequests({
        installationId: e,
        repoId: t,
        limit: s = 10
    }) {
        const n = Math.min(Math.max(s != null ? s : 10, 1), 10);
        return this._wrapWhamRequest(() => r.safePost("/wham/github/installations/{installation_id}/repositories/{repo_id}/pull-requests/review", {
            parameters: {
                path: {
                    installation_id: e,
                    repo_id: t
                }
            },
            requestBody: {
                action: "review",
                limit: n
            }
        }))
    }
    static async createFollowUpTask(e, t, s, n, i = !1, d = 1, c = []) {
        const o = [{
            type: "message",
            role: "user",
            content: [{
                content_type: "text",
                text: s
            }]
        }, ...c];
        n.forEach(h => {
            o.push({
                type: "comment",
                position: h.position,
                content: h.content
            })
        });
        const m = await y("codex_create_task_turn").catch(h => {
                k.addError(h)
            }),
            u = q(null, null, null, m);
        return this._wrapWhamRequest(() => r.safePost("/wham/tasks", {
            requestBody: {
                follow_up: {
                    task_id: e,
                    turn_id: t,
                    run_environment_in_qa_mode: i
                },
                metadata: {
                    best_of_n: d
                },
                input_items: o
            },
            additionalHeaders: u
        }))
    }
    static cancelTurnDeprecated(e, t) {
        return this._wrapWhamRequest(() => r.safePost("/wham/tasks/{task_id}/turns/{task_turn_id}/cancel", {
            parameters: {
                path: {
                    task_id: e,
                    task_turn_id: t
                }
            }
        }))
    }
    static cancelTask(e) {
        return this._wrapWhamRequest(() => r.safePost("/wham/tasks/{task_id}/cancel", {
            parameters: {
                path: {
                    task_id: e
                }
            }
        }))
    }
    static markTurnAsRead(e) {
        return this._wrapWhamRequest(() => r.safePost("/wham/tasks/{task_id}/mark_read", {
            parameters: {
                path: {
                    task_id: e
                }
            }
        }))
    }
    static markTurnViewed(e, t) {
        return this._wrapWhamRequest(() => r.safePost("/wham/tasks/{task_id}/turns/{task_turn_id}/viewed", {
            parameters: {
                path: {
                    task_id: e,
                    task_turn_id: t
                }
            }
        }))
    }
    static discardTurn(e, t) {
        return this._wrapWhamRequest(() => r.safePost("/wham/tasks/{task_id}/turns/{task_turn_id}/discard", {
            parameters: {
                path: {
                    task_id: e,
                    task_turn_id: t
                }
            }
        }))
    }
    static undoDiscardedTurns(e, t) {
        return this._wrapWhamRequest(() => r.safePost("/wham/tasks/{task_id}/turns/{task_turn_id}/undo_all_discards_for_siblings", {
            parameters: {
                path: {
                    task_id: e,
                    task_turn_id: t
                }
            }
        }))
    }
    static copyGitApply(e, t, s) {
        return this._wrapWhamRequest(() => r.safePost("/wham/tasks/{task_id}/turns/{task_turn_id}/copy_git_apply", {
            parameters: {
                path: {
                    task_id: e,
                    task_turn_id: t
                }
            },
            requestBody: {
                includes_apply_command: s
            }
        }))
    }
    static forkSharedTask(e) {
        return this._wrapWhamRequest(() => r.safePost("/wham/tasks/{task_id}/fork", {
            parameters: {
                path: {
                    task_id: e
                }
            }
        }))
    }
    static invalidateEnvironmentCache(e) {
        return this._wrapWhamRequest(() => r.safePost("/wham/environments/{environment_id}/reset-cache", {
            parameters: {
                path: {
                    environment_id: e
                }
            }
        }))
    }
    static getDailyCodeReviewMetrics() {
        return this._wrapWhamRequest(() => r.safeGet("/wham/analytics/daily-code-review-metrics", {}))
    }
    static getDailyWorkspaceUsageCounts() {
        return this._wrapWhamRequest(() => r.safeGet("/wham/analytics/daily-workspace-usage-counts", {}))
    }
    static getDailySessionsMessagesCounts({
        includeEmails: e = !1
    } = {}) {
        return this._wrapWhamRequest(() => r.safeGet("/wham/analytics/daily-sessions-messages-counts", {
            parameters: {
                query: {
                    include_emails: e
                }
            }
        }))
    }
    static getAnalyticsApiReference() {
        return this._wrapWhamRequest(() => r.safeGet("/wham/analytics/api-reference", {}))
    }
    static getApproximateCreditUsage(e) {
        return this._wrapWhamRequest(() => r.safeGet("/wham/usage/approximate-credit-usage", {
            parameters: {
                query: {
                    credit_amount: e
                }
            }
        }))
    }
}

function X(a, e = !1) {
    var t, s, n;
    return (n = (s = (t = a == null ? void 0 : a.output_items) == null ? void 0 : t.map(i => !e && i.type === "output_diff" ? i.diff : e && i.type === "follow_up_diff" || !e && i.type === "pr" ? i.output_diff.diff : !e && i.type === "cr" ? i.reviewed_diff.diff : null)) == null ? void 0 : s.filter(i => !!i)) != null ? n : []
}

function H(a) {
    var i, d, c, p;
    if (a == null) return "";
    const e = (d = (i = a == null ? void 0 : a.environment) == null ? void 0 : i.repos) == null ? void 0 : d[0],
        t = e ? (p = (c = a == null ? void 0 : a.environment) == null ? void 0 : c.repo_map) == null ? void 0 : p[e] : null,
        s = t && N(t) ? S(t.git_url) : null,
        n = a == null ? void 0 : a.branch;
    return a.output_items.filter(o => o.type === "message").flatMap(o => o.content).map(o => {
        switch (o.content_type) {
            case "text":
                return o.text;
            case "terminal_chunk_citation":
                return "".concat(l, ":").concat(W, "[").concat(W, "]{line_range_start=").concat(o.line_range_start, " line_range_end=").concat(o.line_range_end, " terminal_chunk_id=").concat(o.terminal_chunk_id, "}").concat(l);
            case "repo_file_citation":
                {
                    const u = s ? "".concat(s, "/blob/").concat(n, "/").concat(o.path, "#L").concat(o.line_range_start, "-L").concat(o.line_range_end) : null;
                    return "".concat(l, ":").concat(b, "[").concat(b, "]{line_range_start=").concat(o.line_range_start, " line_range_end=").concat(o.line_range_end, " path=").concat(o.path).concat(u ? ' git_url="'.concat(u, '"') : "", "}").concat(l)
                }
            case "image_asset_pointer":
                return "";
            case "image_asset_pointer_citation":
                return "".concat(l, ":").concat(C, "[").concat(C, "]{asset_pointer=").concat(o.asset_pointer, "}").concat(l);
            case void 0:
                return ""
        }
        return ""
    }).join("")
}

function S(a) {
    return a.replace(/\.git$/, "").replace("git://", "https://")
}

function N(a) {
    var e, t, s;
    return ((e = a == null ? void 0 : a.id) == null ? void 0 : e.startsWith("github")) || ((s = (t = a == null ? void 0 : a.git_url) == null ? void 0 : t.indexOf("github.com")) != null ? s : -1) >= 0
}

function G(a) {
    return "output_items" in a
}

function D(a) {
    return "input_items" in a
}

function U(a) {
    var e, t, s, n;
    return a && (n = (s = (t = (e = a.input_items) == null ? void 0 : e.flatMap(i => "content" in i ? i == null ? void 0 : i.content : [])) == null ? void 0 : t.map(i => i.content_type === "text" ? i.text : "")) == null ? void 0 : s.join("")) != null ? n : ""
}

function Y(a) {
    return a ? G(a) ? H(a) : U(a) : ""
}

function F(a) {
    return a.type === "cr"
}

function V(a) {
    if (!a || !G(a) || !a.output_items) return [];
    const e = [];
    for (const t of a.output_items) F(t) && e.push(...t.comments);
    return e
}

function ee(a, e) {
    return a ? e.filter(t => D(t) && t.previous_turn_id === a.id).flatMap(t => {
        var s;
        return ((s = t.input_items) != null ? s : []).filter(n => n.type === "comment")
    }) : []
}

function te(a) {
    return (a == null ? void 0 : a.turn) != null
}

function ae(a) {
    return a.type === "assistant" && a.pull_request_status !== "not_created" && a.pull_request_status !== "failed"
}

function se(a) {
    var t;
    const e = (t = a.task_status_display) == null ? void 0 : t.latest_turn_status_display;
    return e ? O(e) : !0
}

function L(a) {
    switch (a) {
        case null:
        case void 0:
        case "completed":
        case "failed":
        case "cancelled":
            return !0;
        case "pending":
        case "in_progress":
            return !1;
        default:
            I(a)
    }
}

function O(a) {
    return a ? L(a.turn_status) ? !0 : !!a.cancellation_requested_at : !1
}
export {
    R as W, $ as a, V as b, O as c, Y as d, ee as e, se as f, X as g, D as h, L as i, G as j, F as k, te as l, ae as m, Q as w
};
//# sourceMappingURL=mvhcdm28zmc6uy2d.js.map