import {
    c as e,
    s as o
} from "./dykg4ktvbu3mhmdo.js";
const s = e(o, "0a0a1b", 20, 20);
export {
    s as U
};
//# sourceMappingURL=k78yzov06lrhyte9.js.map