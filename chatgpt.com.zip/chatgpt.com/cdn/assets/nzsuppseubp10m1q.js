var fe = Object.defineProperty,
    pe = Object.defineProperties;
var de = Object.getOwnPropertyDescriptors;
var W = Object.getOwnPropertySymbols;
var ye = Object.prototype.hasOwnProperty,
    Se = Object.prototype.propertyIsEnumerable;
var ee = (e, s, a) => s in e ? fe(e, s, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: a
    }) : e[s] = a,
    y = (e, s) => {
        for (var a in s || (s = {})) ye.call(s, a) && ee(e, a, s[a]);
        if (W)
            for (var a of W(s)) Se.call(s, a) && ee(e, a, s[a]);
        return e
    },
    T = (e, s) => pe(e, de(s));
import {
    e as L,
    r as h,
    j as l,
    i as X,
    m as z,
    M as ae,
    S as he,
    a0 as ge
} from "./fg33krlcm0qyi6yw.js";
import {
    R as _e,
    V as Pe,
    b as be,
    a9 as we,
    gi as Te,
    H as se,
    P as oe,
    m as Ee,
    L as Me,
    _ as V
} from "./dykg4ktvbu3mhmdo.js";
import {
    c as f,
    S as k,
    F as Y,
    a as ne,
    C as $,
    L as xe
} from "./fkgr3i4r43mv04zi.js";
import {
    lm as Ce,
    lo as Ne,
    e7 as ve,
    hZ as Le,
    g4 as je,
    cM as Ae,
    gp as Re,
    g9 as Fe,
    ga as Ue,
    g5 as O,
    F3 as qe,
    hT as Oe,
    db as Ie,
    dc as ke,
    e6 as ze,
    g7 as Qe
} from "./k15yxxoybkkir2ou.js";
import {
    P as ce
} from "./n7nqkdn53j3o5j6k.js";
import {
    u as Ve,
    B as Be
} from "./3jqmuecsvur0aphg.js";
import {
    S as Xe
} from "./mcy89srphizz0hls.js";
const te = "country_code",
    I = "step",
    B = e => _e.safePost("/accounts/pending_team_workspace", {
        requestBody: e
    }),
    Ye = ({
        formData: e,
        onNext: s
    }) => {
        var d, P;
        const a = L(),
            [t, u] = h.useState({
                role: (d = e.role) != null ? d : "",
                department: (P = e.department) != null ? P : ""
            }),
            [m, i] = h.useState({}),
            g = (r, o) => {
                u(_ => T(y({}, _), {
                    [r]: o
                })), i(_ => T(y({}, _), {
                    [r]: ""
                }))
            },
            S = h.useMemo(() => {
                const r = Ce.map(o => ({
                    label: a.formatMessage(o.displayValue),
                    value: o.id
                }));
                return r.sort((o, _) => o.label.localeCompare(_.label)), r
            }, [a]),
            n = h.useMemo(() => {
                const r = Ne.map(o => ({
                    label: a.formatMessage(o.displayValue),
                    value: o.id
                }));
                return r.sort((o, _) => o.label.localeCompare(_.label)), r
            }, [a]),
            c = h.useMemo(() => [{
                formType: "select",
                label: a.formatMessage(f.roleLabel),
                name: "role",
                placeholder: a.formatMessage(f.rolePlaceholder),
                value: t.role,
                onChange: r => g("role", r),
                error: m.role,
                required: !0,
                options: n
            }, {
                formType: "select",
                label: a.formatMessage(f.workspaceDepartmentLabel),
                name: "department",
                placeholder: a.formatMessage(f.workspaceDepartmentPlaceholder),
                value: t.department,
                onChange: r => g("department", r),
                error: m.department,
                required: !0,
                options: S
            }], [S, m.department, m.role, t.department, t.role, a, n]),
            p = () => {
                const r = {};
                return c.forEach(o => {
                    o.required && !t[o.name] && (r[o.name] = a.formatMessage(f.fieldRequired, {
                        fieldName: o.label
                    }))
                }), i(r), Object.values(r).every(o => !o)
            };
        return l.jsx(k, {
            content: l.jsxs(Y, {
                title: a.formatMessage(f.tellUsAboutWorkStepTitle),
                subTitle: a.formatMessage(f.tellUsAboutWorkStepSubtitle),
                children: [l.jsx("div", {
                    className: "flex flex-col gap-6",
                    children: c.map(r => h.createElement(ne, T(y({}, r), {
                        key: r.name
                    })))
                }), l.jsx($, {
                    onClick: async () => {
                        p() && await s(t)
                    }
                })]
            })
        })
    },
    $e = e => e === "sales_marketing",
    Ke = {
        input: "rounded-full!",
        button: "rounded-full! h-8! w-8! border-none!",
        buttons: "absolute end-2! gap-0!"
    };

function Ze({
    isFreeTrialPromoEligible: e,
    salesMarketingCopyEnabled: s
}) {
    return e ? {
        titleMessage: f.freeTrialPromoTitle,
        subTitleMessage: s ? f.salesMarketingPromoSubtitleFree : f.freeTrialPromoSubtitle
    } : {
        titleMessage: f.purchaseStepTitle,
        subTitleMessage: void 0
    }
}
const He = ({
        onNext: e,
        onPrevious: s,
        pendingWorkspace: a,
        initialBillingDetails: t,
        formData: u
    }) => {
        var H, G;
        const m = L(),
            i = be(),
            g = Re(),
            {
                data: S,
                isLoading: n,
                error: c
            } = ve({
                ctx: i,
                countryCode: t == null ? void 0 : t.country,
                currency: t == null ? void 0 : t.currency,
                enabled: t != null
            }),
            p = X(),
            d = z(),
            r = h.useMemo(() => {
                const D = new URLSearchParams(d.search).get("segment");
                return $e(D) ? D : null
            }, [d.search]) != null && Pe(i, "3300867660").get("enable_sales_marketing_copy", !1),
            o = (G = new URLSearchParams((H = a == null ? void 0 : a.query_params) != null ? H : "").get(ce)) != null ? G : void 0,
            _ = o != null,
            {
                selectedPlan: M,
                setSelectedPlan: j,
                numSeats: x,
                setNumSeats: A,
                promoData: C,
                promoDataIsFromQueryParam: R,
                TEAM_FREE_TRIAL_COUPON_IsEligible: N
            } = Ve({
                initialSeats: u == null ? void 0 : u.numSeats,
                initialPromoCoupon: o,
                initialPromoCouponFromQueryParam: _
            }),
            {
                eligible: F,
                campaignId: U
            } = Le(),
            w = !o && F,
            b = C != null ? C : w ? {
                coupon: U,
                state: "eligible",
                redemption: null
            } : void 0,
            Q = C ? R : w ? !1 : void 0;
        if (!t || n || c != null || !S) return l.jsx(k, {
            forceLightTheme: !0,
            content: null
        });
        const {
            annualBillingPlan: v
        } = je(t.currency, S), q = Math.floor(100 - v.discountedMonthlyCost / v.monthlyCost * 100), K = {
            priceInterval: M,
            billingDetails: t,
            numSeats: x,
            promoData: b,
            promoDataIsFromQueryParam: Q
        }, me = N, {
            titleMessage: ue,
            subTitleMessage: Z
        } = Ze({
            isFreeTrialPromoEligible: !!N,
            salesMarketingCopyEnabled: r
        }), ie = Ae(isNaN(x) ? 0 : x, g, Fe);
        return l.jsx(k, {
            forceLightTheme: !0,
            onPrevious: s ? () => s(y({}, K)) : void 0,
            content: l.jsxs(Y, {
                title: m.formatMessage(ue),
                subTitle: Z && m.formatMessage(Z),
                children: [l.jsxs("div", {
                    className: "flex flex-col gap-6",
                    children: [l.jsx(Ue, {
                        numSeats: x,
                        minSeats: g,
                        setNumSeats: A,
                        classNames: Ke,
                        label: l.jsx(ae, y({}, f.seatsCountLabel))
                    }), l.jsxs("div", {
                        className: "flex flex-col gap-1.5",
                        children: [l.jsx(xe, {
                            required: !0,
                            children: m.formatMessage(f.planSummaryTitle)
                        }), l.jsxs("div", {
                            className: "border-token-border-default flex flex-col gap-6 rounded-3xl border p-5",
                            children: [!(me && M === O.FLEXIBLE) && l.jsx(Xe, {
                                ariaLabel: m.formatMessage(f.planTypeLabel),
                                leftItem: {
                                    label: l.jsx("div", {
                                        className: "flex flex-wrap justify-center gap-1 text-center",
                                        children: m.formatMessage(f.annualPlanLabel, {
                                            percent: q,
                                            span: J => l.jsx("span", {
                                                className: "text-[#10A37F]",
                                                children: J
                                            })
                                        })
                                    }),
                                    value: O.ANNUAL
                                },
                                rightItem: {
                                    label: m.formatMessage(f.monthlyPlanLabel),
                                    value: O.FLEXIBLE
                                },
                                value: M,
                                onChange: j
                            }), l.jsx(Be, {
                                numSeats: ie,
                                selectedPlan: M,
                                billingDetails: t,
                                totalLabel: f.allPlansTodayTotal,
                                billDate: m.formatMessage(f.today),
                                promoData: b
                            })]
                        })]
                    })]
                }), l.jsx($, {
                    onClick: () => e(y({}, K))
                }), l.jsx(we, {
                    color: "ghost",
                    onClick: () => p("/"),
                    children: l.jsx(ae, {
                        id: "TjfExQ",
                        defaultMessage: "Cancel"
                    })
                })]
            })
        })
    },
    Ge = ({
        formData: e,
        onNext: s,
        onPrevious: a
    }) => {
        var d, P;
        const t = L(),
            [u, m] = h.useState({
                workspaceName: (d = e.workspaceName) != null ? d : "",
                companySize: (P = e.companySize) != null ? P : ""
            }),
            [i, g] = h.useState({}),
            S = (r, o) => {
                m(_ => T(y({}, _), {
                    [r]: o
                })), g(_ => T(y({}, _), {
                    [r]: ""
                }))
            },
            n = qe.map(r => ({
                label: typeof r.displayValue == "string" ? r.displayValue : t.formatMessage(r.displayValue),
                value: r.id
            })),
            c = h.useMemo(() => [{
                formType: "input",
                label: t.formatMessage(f.workspaceNameLabel),
                name: "workspaceName",
                placeholder: t.formatMessage(f.workspaceNamePlaceholder),
                value: u.workspaceName,
                onChange: r => S("workspaceName", r),
                error: i.workspaceName,
                required: !0,
                autoFocus: !0
            }, {
                formType: "select",
                label: t.formatMessage(f.workspaceCompanySizeLabel),
                name: "companySize",
                placeholder: t.formatMessage(f.workspaceCompanySizePlaceholder),
                value: u.companySize,
                onChange: r => S("companySize", r),
                error: i.companySize,
                required: !1,
                options: n
            }], [i.companySize, i.workspaceName, u.companySize, u.workspaceName, t, n]),
            p = () => {
                const r = {};
                return c.forEach(o => {
                    o.required && !u[o.name] && (r[o.name] = t.formatMessage(f.fieldRequired, {
                        fieldName: o.label
                    }))
                }), g(r), Object.values(r).every(o => !o)
            };
        return l.jsx(k, {
            onPrevious: a ? () => a(y({}, u)) : void 0,
            content: l.jsxs(Y, {
                title: t.formatMessage(f.workspaceNameStepTitle),
                subTitle: t.formatMessage(f.workspaceNameStepSubtitle),
                children: [l.jsx("div", {
                    className: "flex flex-col gap-6",
                    children: c.map(r => h.createElement(ne, T(y({}, r), {
                        key: r.name
                    })))
                }), l.jsx($, {
                    disabled: !u.workspaceName,
                    onClick: async () => {
                        p() && await s(y({}, u))
                    }
                })]
            })
        })
    };
var le = (e => (e.AboutWork = "about-work", e.WorkspaceInfo = "workspace-info", e.ConfigurePlan = "configure-plan", e))(le || {});
const Je = Te(Object.values(le), void 0),
    De = ({
        pendingWorkspace: e
    }) => {
        var M, j, x, A, C, R, N, F, U;
        const s = L(),
            [a, t] = h.useState({
                workspaceName: (M = e == null ? void 0 : e.workspace_name) != null ? M : void 0,
                role: (j = e == null ? void 0 : e.role) != null ? j : void 0,
                department: (x = e == null ? void 0 : e.department) != null ? x : void 0,
                companySize: (A = e == null ? void 0 : e.company_size) != null ? A : void 0,
                numSeats: (C = e == null ? void 0 : e.seat_quantity) != null ? C : void 0
            }),
            u = new URLSearchParams((R = e == null ? void 0 : e.query_params) != null ? R : "").get(ce);
        Oe(u != null ? u : "", !!u);
        const m = We({
                data: a
            }),
            i = se(),
            g = z(),
            S = (U = (F = new URLSearchParams(g.search).get(te)) != null ? F : new URLSearchParams((N = e == null ? void 0 : e.query_params) != null ? N : "").get(te)) != null ? U : void 0,
            n = he(),
            {
                country: c,
                userCountry: p
            } = Ie({
                initialCountryCode: S
            }),
            d = ke({
                country: c,
                currentAccount: i,
                location: "TeamDirectSignUpFlow"
            }),
            P = Je(e == null ? void 0 : e.step_name),
            {
                step: r,
                nextStep: o
            } = ea({
                initialStep: P && E.includes(P) ? P : void 0
            });
        h.useEffect(() => {
            e || (() => {
                var b;
                B({
                    step_name: (b = e == null ? void 0 : e.step_name) != null ? b : E[0],
                    query_params: g.search,
                    user_segment: "v1"
                })
            })()
        }, []), h.useEffect(() => {
            var v, q;
            const w = g.key,
                Q = new URLSearchParams(window.location.search).get("referrer") || document.referrer;
            oe.logEventWithStatsig("Account Pay: Team Direct Sign Up Flow", "chatgpt_account_payment_team_direct_sign_up_flow", T(y({}, i == null ? void 0 : i.subscriptionAnalyticsParams), {
                referrer: Q,
                initialTab: e == null ? void 0 : e.step_name,
                currentTab: r,
                locationKey: w,
                navigationType: n,
                initialCountrySelectorCountry: S != null ? S : c,
                selectedCountry: (v = d == null ? void 0 : d.country) != null ? v : "",
                selectedCurrency: (q = d == null ? void 0 : d.currency) != null ? q : "",
                userCountry: p != null ? p : ""
            }))
        }, [r]);
        const _ = () => {
            switch (r) {
                case "about-work":
                    return l.jsx(Ye, {
                        formData: a,
                        onNext: async w => {
                            const b = y(y({}, a), w);
                            t(b), await o(b)
                        }
                    });
                case "workspace-info":
                    return l.jsx(Ge, {
                        formData: a,
                        onNext: async w => {
                            const b = y(y({}, a), w);
                            t(b), await o(b)
                        }
                    });
                case "configure-plan":
                    return l.jsx(He, {
                        formData: a,
                        initialBillingDetails: d != null ? d : void 0,
                        onNext: async w => {
                            await m(y(y({}, a), w))
                        },
                        pendingWorkspace: e
                    });
                default:
                    return null
            }
        };
        return l.jsxs(l.Fragment, {
            children: [l.jsx("title", {
                children: s.formatMessage(f.teamSignUpPageTitle)
            }), _()]
        })
    },
    We = ({
        data: e,
        isCustomCheckout: s = !1
    }) => {
        const {
            prepareCheckoutSession: a,
            navigateToCheckout: t
        } = ze(), u = Ee(), m = L(), i = se();
        return h.useCallback(async ({
            priceInterval: S,
            billingDetails: n,
            numSeats: c,
            promoData: p,
            promoDataIsFromQueryParam: d
        }) => {
            var P;
            try {
                oe.logEvent("Account Pay: Payment Checkout Clicked", T(y({
                    planType: Me.SELF_SERVE_BUSINESS
                }, i == null ? void 0 : i.subscriptionAnalyticsParams), {
                    referrer: document.referrer
                }));
                const r = T(y(y({
                        plan_name: "chatgptteamplan",
                        team_plan_data: {
                            workspace_name: (P = e.workspaceName) != null ? P : "",
                            price_interval: S,
                            seat_quantity: c
                        },
                        billing_details: n
                    }, s ? {} : {
                        checkout_ui_mode: "redirect"
                    }), S === O.FLEXIBLE && (p != null && p.coupon) ? {
                        promo_campaign: {
                            promo_campaign_id: p == null ? void 0 : p.coupon,
                            is_coupon_from_query_param: !!d
                        }
                    } : {}), {
                        cancel_url: window.location.href
                    }),
                    o = await a(r);
                await t(o, {
                    checkoutPayload: r
                })
            } catch (r) {
                V.addError(r), u.warning(m.formatMessage(Qe.paymentErrorWarning), {
                    hasCloseButton: !0
                })
            }
        }, [s, i == null ? void 0 : i.subscriptionAnalyticsParams, e.workspaceName, m, t, a, u])
    },
    re = (e, s) => {
        const a = new URLSearchParams(window.location.search);
        Object.entries(e).forEach(([u, m]) => {
            a.set(u, m)
        });
        const t = "".concat(window.location.pathname, "?").concat(a.toString());
        s ? s(t, {
            replace: !1
        }) : window.history.replaceState(null, "", t)
    },
    E = ["configure-plan"],
    ea = ({
        initialStep: e
    }) => {
        const s = X(),
            a = z(),
            [t, u] = h.useState(() => {
                const n = e != null ? e : E[0];
                return re({
                    [I]: n
                }), n
            }),
            m = h.useCallback(n => {
                u(n), re({
                    [I]: n
                }, s)
            }, [s]),
            i = h.useRef(null);
        h.useEffect(() => {
            const c = new URLSearchParams(a.search).get(I);
            c !== i.current && c && E.includes(c) && c !== t && m(c), i.current = c
        }, [a.search, m, t]);
        const g = async n => {
                let c = t;
                const p = E.indexOf(t);
                p >= 0 && p < E.length - 1 && (c = E[p + 1], m(c));
                try {
                    await B({
                        workspace_name: n.workspaceName,
                        company_size: n.companySize,
                        department: n.department,
                        role: n.role,
                        step_name: c,
                        query_params: a.search,
                        user_segment: "v1"
                    })
                } catch (d) {
                    V.addError(d)
                }
            },
            S = h.useCallback(async n => {
                let c = t;
                const p = E.indexOf(t);
                p > 0 && (c = E[p - 1], m(c));
                try {
                    await B({
                        workspace_name: n.workspaceName,
                        company_size: n.companySize,
                        department: n.department,
                        role: n.role,
                        step_name: c,
                        query_params: a.search,
                        user_segment: "v1"
                    })
                } catch (d) {
                    V.addError(d)
                }
            }, [a.search, m, t]);
        return {
            step: t,
            nextStep: g,
            previousStep: S
        }
    },
    ma = "/create-workspace",
    ua = ge(function({
        loaderData: s
    }) {
        var u;
        const a = z(),
            t = X();
        return h.useEffect(() => {
            var n;
            const m = (n = s.pendingWorkspace) == null ? void 0 : n.query_params;
            if (!m) return;
            const i = new URLSearchParams(a.search),
                g = new URLSearchParams(m);
            let S = !1;
            for (const [c, p] of g) !i.get(c) && c !== I && (i.set(c, p), S = !0);
            S && t("".concat(a.pathname, "?").concat(i.toString()), {
                replace: !0
            })
        }, [(u = s.pendingWorkspace) == null ? void 0 : u.query_params, a.pathname, a.search, t]), l.jsx(De, {
            pendingWorkspace: s.pendingWorkspace
        })
    });
export {
    ma as C, ua as c, $e as i
};
//# sourceMappingURL=nzsuppseubp10m1q.js.map