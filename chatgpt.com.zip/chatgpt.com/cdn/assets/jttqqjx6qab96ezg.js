var ee = Object.freeze,
    oe = Object.defineProperty,
    ve = Object.defineProperties;
var ye = Object.getOwnPropertyDescriptors;
var te = Object.getOwnPropertySymbols;
var Pe = Object.prototype.hasOwnProperty,
    je = Object.prototype.propertyIsEnumerable;
var se = (s, e, o) => e in s ? oe(s, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: o
    }) : s[e] = o,
    L = (s, e) => {
        for (var o in e || (e = {})) Pe.call(e, o) && se(s, o, e[o]);
        if (te)
            for (var o of te(e)) je.call(e, o) && se(s, o, e[o]);
        return s
    },
    ae = (s, e) => ve(s, ye(e));
var ie = (s, e) => ee(oe(s, "raw", {
    value: ee(e || s.slice())
}));
import {
    f as ge,
    e as pe,
    j as l,
    M as Z,
    c as me
} from "./fg33krlcm0qyi6yw.js";
import {
    P as J,
    nL as he,
    b as V,
    g2 as H,
    T as Ae,
    F as ke,
    ac as Fe,
    m as xe,
    lU as Le,
    c_ as be,
    k1 as Me,
    sI as Ue,
    sJ as Te,
    bH as Ee,
    lh as Ce,
    lj as _e,
    nR as Re,
    sK as Ie,
    mg as Ne,
    d as De,
    li as le,
    ln as ze,
    sL as Se,
    sM as Oe,
    sN as Be,
    aA as $e,
    sO as we,
    sP as He,
    j$ as Ge,
    V as We,
    B as Ye,
    sQ as Ke,
    lf as re,
    lo as Q,
    sR as Qe
} from "./dykg4ktvbu3mhmdo.js";
import {
    hG as ne,
    hH as Ze,
    hI as Je,
    hJ as Ve,
    hK as ce,
    hL as Xe,
    hM as qe,
    hN as et,
    hO as tt,
    hP as st,
    hQ as ot
} from "./k15yxxoybkkir2ou.js";
import {
    u as at
} from "./e3ddui4ro6nb7fig.js";

function yt({
    clientThreadId: s,
    openFileDialog: e,
    icon: o,
    isDisabled: r = !1,
    isSmall: c = !1,
    showLabel: a = !1,
    showUpsell: n = !1,
    hideBorder: t = !1,
    highlightTooltip: g = !1,
    disabledReason: d,
    currentModelName: p,
    visualTreatment: m,
    showMenuForNoAuth: u,
    modelSupportsImages: A
}) {
    const i = pe(),
        h = he(),
        F = V();
    r = (r || !!h) && !n;
    const f = l.jsxs(Ze, {
            disabled: r,
            $showLabel: a,
            $hideBorder: t,
            $isSmall: c,
            $visualTreatment: m,
            onClick: b => {
                if (b.preventDefault(), u || n) {
                    J.logNoAuthAttachButtonClicked({
                        location: u ? "No auth file upload" : "No auth upsell"
                    });
                    return
                }
                e()
            },
            "aria-label": Je(F, i, r, d, p),
            children: [o, a && l.jsx(Ve, {})]
        }),
        y = l.jsx("div", {
            className: "flex",
            children: f
        });
    if (u || n) {
        const b = u ? l.jsx(Xe, {
                openFileDialog: e,
                showMenuForNoAuth: !0,
                modelSupportsImages: A,
                clientThreadId: s
            }) : l.jsx(qe, {
                location: "attach",
                statsig_login_event: "chatgpt_composer_upsell_login_button_clicked",
                statsig_signup_event: "chatgpt_composer_upsell_signup_button_clicked"
            }),
            P = l.jsx(H.BasicTrigger, {
                asChild: !0,
                children: y
            });
        return l.jsxs(H.Root, {
            children: [u ? l.jsx(ce, {
                clientThreadId: s,
                rateLimitPopup: h,
                highlightTooltip: g,
                disabled: r,
                children: P
            }) : l.jsx(Ae, {
                label: l.jsx(Z, {
                    id: "wkpQmi",
                    defaultMessage: "Upload files and more"
                }),
                side: "bottom",
                open: g || void 0,
                children: P
            }), l.jsx(H.Portal, {
                children: l.jsx(H.Content, {
                    alignOffset: -8,
                    side: "bottom",
                    size: "small",
                    className: "radix-side-bottom:flex-col-reverse flex flex-col",
                    children: b
                })
            })]
        })
    }
    return l.jsx(ce, {
        disabled: r,
        clientThreadId: s,
        rateLimitPopup: h,
        highlightTooltip: g,
        children: y
    })
}

function it({
    code: s,
    message: e
}) {
    switch (s) {
        case ne.FileTooLarge:
            return de.errorFileTooLarge;
        case ne.TooManyFiles:
            return J.logEvent("Uploaded Max Files Error"), de.errorTooManyFiles;
        default:
            return e
    }
}
const de = ge({
        attachImages: {
            id: "PromptFilePicker.attachImages",
            defaultMessage: "Attach images"
        },
        attachFiles: {
            id: "PromptFilePicker.attachFiles",
            defaultMessage: "Upload files and more"
        },
        errorFileTooLarge: {
            id: "PromptFilePicker.errorFileTooLarge",
            defaultMessage: "Your file is too large. The maximum file size is {size}MB."
        },
        errorTooManyFiles: {
            id: "PromptFilePicker.errorTooManyFiles",
            defaultMessage: "You may only upload {maxNum} files at a time."
        },
        defaultFileUploadRateLimited: {
            id: "U5qAWP",
            defaultMessage: "You've reached your daily upload limit. Get ChatGPT Plus to unlock more."
        }
    }),
    ue = ge({
        dragInstructions: {
            id: "FileDropZone.dragInstructions",
            defaultMessage: "Add anything"
        },
        dragAllAccepted: {
            id: "FileDropZone.dragAllAccepted",
            defaultMessage: "Drop any file here to add it to the conversation"
        }
    });

function lt(s) {
    if (!s.accept || Object.keys(s.accept).length === 0) return [];
    const e = [];
    return Object.values(s.accept).forEach(o => e.push(...o)), e.sort()
}

function Pt(s) {
    "use forget";
    var q;
    const e = me.c(50),
        {
            className: o,
            children: r,
            clientThreadId: c,
            currentModelConfig: a,
            noKeyboard: n
        } = s,
        t = pe(),
        g = xe(),
        d = V();
    let p;
    e[0] !== d ? (p = be(), e[0] = d, e[1] = p) : p = e[1];
    const m = p,
        u = Fe().flags,
        A = u == null ? void 0 : u.includes(Me.NoAuthEnableFileUploads),
        i = tt(c),
        h = Ee();
    let F;
    e[2] !== h || e[3] !== i || e[4] !== a ? (F = Ce(a, i, h), e[2] = h, e[3] = i, e[4] = a, e[5] = F) : F = e[5];
    const f = F,
        y = f !== _e.None,
        b = Re(rt),
        P = Ie(f),
        M = Math.max(0, P - b.length),
        G = M <= 0,
        {
            getGizmoId: X
        } = Ne();
    let U;
    e[6] !== c || e[7] !== d ? (U = we(d, c), e[6] = c, e[7] = d, e[8] = U) : U = e[8];
    const T = De(U),
        W = Array.isArray(T) && T.length > 0;
    let k;
    e[9] !== i || e[10] !== a ? (k = le(a, i), e[9] = i, e[10] = a, e[11] = k) : k = e[11];
    let x;
    e[12] !== i || e[13] !== a ? (x = (q = ze(a, i)) == null ? void 0 : q.attachments, e[12] = i, e[13] = a, e[14] = x) : x = e[14];
    const {
        handleFileAccepted: E
    } = dt(t, f, k, "drag", X, x, W ? T : void 0), B = he(), {
        file_uploads: D,
        image_uploads: z
    } = st();
    let S;
    e: {
        if (z === "allowed" && D !== "allowed") {
            S = He;
            break e
        } else if (z === "blocked" && D === "blocked") {
            let v;
            e[15] === Symbol.for("react.memo_cache_sentinel") ? (v = [], e[15] = v) : v = e[15], S = v;
            break e
        } else if (!m && A) {
            let v;
            e[16] !== i || e[17] !== a ? (v = le(a, i), e[16] = i, e[17] = a, e[18] = v) : v = e[18], S = v;
            break e
        }
        let _;e[19] !== i || e[20] !== a ? (_ = Se(a, i), e[19] = i, e[20] = a, e[21] = _) : _ = e[21],
        S = _
    }
    const C = Oe(S),
        Y = !y || G || B != null;
    let R;
    e[22] !== d || e[23] !== t || e[24] !== m || e[25] !== g || e[26] !== f ? (R = _ => nt(_, t, g, f, m, d), e[22] = d, e[23] = t, e[24] = m, e[25] = g, e[26] = f, e[27] = R) : R = e[27];
    let $;
    e[28] !== C || e[29] !== E || e[30] !== n || e[31] !== M || e[32] !== Y || e[33] !== R ? ($ = L({
        maxFiles: M,
        disabled: Y,
        noClick: !0,
        noKeyboard: n,
        onDropAccepted: E,
        onDropRejected: R,
        multiple: !0,
        maxSize: Be
    }, C), e[28] = C, e[29] = E, e[30] = n, e[31] = M, e[32] = Y, e[33] = R, e[34] = $) : $ = e[34];
    const {
        getRootProps: O,
        isDragActive: K
    } = at($);
    let I, N, j;
    if (e[35] !== r || e[36] !== o || e[37] !== C || e[38] !== O || e[39] !== K) {
        const _ = lt(C);
        e[43] !== o || e[44] !== O ? (j = O({
            className: o
        }), e[43] = o, e[44] = O, e[45] = j) : j = e[45], I = r, N = K && l.jsx($e, {
            asChild: !0,
            children: l.jsxs(ht, {
                className: "fixed inset-0",
                inert: !0,
                children: [l.jsx(ot, {}), l.jsx("h3", {
                    children: l.jsx(Z, L({}, ue.dragInstructions))
                }), l.jsx("h4", {
                    className: "w-2/3 text-center",
                    children: _.length > 0 ? _.join(", ") : l.jsx(Z, L({}, ue.dragAllAccepted))
                })]
            })
        }), e[35] = r, e[36] = o, e[37] = C, e[38] = O, e[39] = K, e[40] = I, e[41] = N, e[42] = j
    } else I = e[40], N = e[41], j = e[42];
    let w;
    return e[46] !== I || e[47] !== N || e[48] !== j ? (w = l.jsxs("div", ae(L({}, j), {
        children: [I, N]
    })), e[46] = I, e[47] = N, e[48] = j, e[49] = w) : w = e[49], w
}

function rt(s) {
    return s.files
}

function nt(s, e, o, r, c, a) {
    const {
        file: n
    } = s[0];
    if (!c && n && !(n.type.startsWith("image/") || Ge(n.name)) && We(a, "2118136551").get("show_login_modal_on_noauth_file_drop", !1)) {
        Ye(a, {
            fallbackScreenHint: "login",
            skipLoginModal: !1
        });
        return
    }
    ct(s, e, o, r)
}

function ct(s, e, o, r) {
    const {
        errors: c
    } = s[0], a = Ue(r);
    c.forEach(n => {
        const t = it(n);
        typeof t == "string" ? o.danger(t, {
            hasCloseButton: !0,
            loggingTitle: "File upload error",
            loggingDescription: t,
            toastId: "file_upload_error"
        }) : o.danger(e.formatMessage(t, {
            size: Te,
            maxNum: a
        }), {
            hasCloseButton: !0,
            loggingTitle: t.defaultMessage || "File upload error",
            loggingDescription: t.defaultMessage || "File upload error",
            toastId: "file_upload_error"
        })
    })
}

function dt(s, e, o, r, c, a, n) {
    "use forget";
    const t = me.c(20),
        g = V(),
        d = Fe().flags,
        p = xe(),
        m = Le();
    let u;
    t[0] !== g ? (u = be(), t[0] = g, t[1] = u) : u = t[1];
    const A = !u,
        i = n != null ? n : void 0,
        h = d == null ? void 0 : d.includes(Me.NoAuthEnableFileUploads);
    let F;
    t[2] !== g ? (F = et(g, !0), t[2] = g, t[3] = F) : F = t[3];
    const {
        persistFilesToLibrary: f,
        doubleWriteFilesToLibrary: y
    } = F;
    let b;
    t[4] !== a || t[5] !== i || t[6] !== c || t[7] !== s || t[8] !== y || t[9] !== f || t[10] !== A || t[11] !== o || t[12] !== h || t[13] !== m || t[14] !== p || t[15] !== r || t[16] !== e ? (b = async (G, X) => {
        J.logEvent("Upload File", {
            client: "web",
            eventSource: r,
            intent: e.toString()
        });
        const U = c != null ? await c() : void 0,
            T = await Promise.all(G.map(mt)),
            W = new Set(T.map(pt).filter(gt)),
            k = T.map(ft).filter(ut);
        W.forEach(x => Ke(x, s, p)), k.length > 0 && k.forEach(x => {
            const E = L(L({
                    gizmoId: U
                }, h && {
                    isUnauthenticated: A
                }), i && i.length > 0 ? {
                    contextScopes: i
                } : {}),
                B = [m, re(x), x, e, o, s, p, E, a];
            if (e === _e.Retrieval) {
                let D = Promise.resolve(),
                    z = Promise.resolve();
                f && (z = Q.uploadFile(m, "".concat(re(x), ":lib"), x, e, o, s, p, E, a, void 0, !0, !0)), (y || !f) && (D = Q.uploadFile(...B, void 0, !1, f)), Promise.all([D, z])
            } else Q.uploadFile(...B)
        })
    }, t[4] = a, t[5] = i, t[6] = c, t[7] = s, t[8] = y, t[9] = f, t[10] = A, t[11] = o, t[12] = h, t[13] = m, t[14] = p, t[15] = r, t[16] = e, t[17] = b) : b = t[17];
    const P = b;
    let M;
    return t[18] !== P ? (M = {
        handleFileAccepted: P
    }, t[18] = P, t[19] = M) : M = t[19], M
}

function ut(s) {
    return s !== void 0
}

function ft(s) {
    const {
        file: e
    } = s;
    return e
}

function gt(s) {
    return s !== void 0
}

function pt(s) {
    return "failureReason" in s ? s.failureReason : void 0
}

function mt(s) {
    return Qe(s)
}
var fe;
const ht = ke.div(fe || (fe = ie(['pointer-events-none absolute z-50 inset-0 flex gap-2 flex-col justify-center items-center after:contents-[""] after:absolute after:opacity-80 after:z-[-1] after:bg-token-main-surface-primary after:inset-0'])));
export {
    ht as D, Pt as F, yt as P, lt as g, ct as h, dt as u
};
//# sourceMappingURL=jttqqjx6qab96ezg.js.map