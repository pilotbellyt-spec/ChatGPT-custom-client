const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/k7bax4ffse9ora8u.js", "assets/fg33krlcm0qyi6yw.js", "assets/k15yxxoybkkir2ou.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/conversation-small-332fs9rk.css", "assets/jkejdo8v5ynnt9ff.js", "assets/k2oaaf8ac9lafsub.js", "assets/lans8a2ikbh9ax9r.js", "assets/o4dswldtisdnypf0.js", "assets/f9njdfff9vl67oeu.js", "assets/imcx75080pls4bkf.js", "assets/nxteivgso0c74ef2.js", "assets/llchdum9phggchvs.js", "assets/bitvwqxtj1froytm.js", "assets/eiz8m6b2n93cr92l.js", "assets/lcm07h4hrgbddd47.js", "assets/k488bo5tj9qgdrgq.js", "assets/e9kbgh7j5o6g3dr6.js", "assets/cu0e6szsqsyduwov.js", "assets/ftef8970ba1zoykr.js", "assets/fz8xw1971c2kf2eb.js", "assets/ebc4iyfg14nu1gw4.js", "assets/gy1lpvuoewmzh42c.js", "assets/jed1ux7qibe55pmj.js", "assets/h1em0bjkpkjv8ykw.js", "assets/nfccle6oyncifphl.js", "assets/hu1bt0oauegdhua6.js"]))) => i.map(i => d[i]);
var Mp = Object.defineProperty,
    vp = Object.defineProperties;
var Tp = Object.getOwnPropertyDescriptors;
var md = Object.getOwnPropertySymbols;
var Ap = Object.prototype.hasOwnProperty,
    Ip = Object.prototype.propertyIsEnumerable;
var fd = (t, e, o) => e in t ? Mp(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: o
    }) : t[e] = o,
    Rt = (t, e) => {
        for (var o in e || (e = {})) Ap.call(e, o) && fd(t, o, e[o]);
        if (md)
            for (var o of md(e)) Ip.call(e, o) && fd(t, o, e[o]);
        return t
    },
    Bs = (t, e) => vp(t, Tp(e));
import {
    c as Et,
    r as F,
    j as n,
    M as Ls,
    f as eo,
    e as Gt,
    _ as vs,
    i as Xd,
    l as Pp,
    n as Ep,
    m as jp,
    a9 as Rp
} from "./fg33krlcm0qyi6yw.js";
import {
    iP as Bp,
    h as Np,
    b as Ke,
    l as Ct,
    fN as Ht,
    d as fe,
    dF as wt,
    P as Ze,
    bc as Yn,
    bd as Xn,
    a9 as bc,
    bI as ue,
    Q as Ac,
    oH as ko,
    aY as Dp,
    bh as Ts,
    c_ as Zs,
    eX as Zd,
    ag as Ic,
    w as Lp,
    V as Us,
    Z as wr,
    S as Cr,
    c2 as eu,
    o as Lt,
    cU as Zn,
    bH as Mo,
    I as tu,
    hj as Up,
    mI as Pc,
    yd as Op,
    hh as Ir,
    i9 as Fp,
    bv as su,
    bg as to,
    e as zp,
    ye as Hp,
    oG as Gp,
    k as As,
    mJ as Wp,
    eW as nu,
    dB as Ec,
    ba as jc,
    nm as vo,
    yf as $p,
    hg as fr,
    mP as ou,
    bX as Vp,
    d3 as qp,
    ck as Kp,
    fb as au,
    yg as Jp,
    b6 as iu,
    da as xc,
    d9 as Qp,
    eh as ru,
    yh as Yp,
    f3 as Sc,
    e2 as lu,
    fw as Xp,
    gS as Zp,
    gP as em,
    lF as cu,
    yi as tm,
    b7 as Mr,
    va as du,
    yj as sm,
    gz as Rc,
    dL as Ns,
    b1 as nm,
    b3 as uu,
    hH as Bc,
    hQ as om,
    g3 as am,
    yk as im,
    yl as rm,
    ym as lm,
    ik as Nc,
    lL as cm,
    iU as dm,
    lM as um,
    nu as Dc,
    fX as dt,
    mk as pm,
    mK as pu,
    j0 as mu,
    yn as wc,
    h1 as Ms,
    na as mm,
    nb as fm,
    nd as gm,
    n9 as hm,
    ls as _m,
    g2 as Pt,
    fW as Ds,
    io as ym,
    T as vr,
    nh as bm,
    yo as xm,
    gH as fu,
    yp as gd,
    wY as gr,
    ny as uc,
    lC as Sm,
    yq as wm,
    wX as Cm,
    yr as km,
    ci as Mm,
    K as vm,
    n6 as Tm,
    ns as Lc,
    bT as gu,
    cH as hu,
    h0 as $t,
    ys as _u,
    dz as So,
    bm as Am,
    bn as wo,
    dH as Cc,
    bt as nt,
    bb as yu,
    bL as bu,
    bp as kc,
    gO as Uc,
    yt as Pr,
    H as xu,
    yu as Oc,
    bq as ks,
    bZ as hd,
    bN as Su,
    yv as _d,
    n_ as Im,
    si as wu,
    yw as Fc,
    mN as zc,
    nW as Pm,
    m as Cu,
    yx as Em,
    sj as jm,
    c1 as Rm,
    yy as Bm,
    pf as Hc,
    dv as Nm,
    b_ as Dm,
    c0 as Lm,
    yz as Um,
    yA as Om,
    yB as Fm,
    nX as zm,
    bE as Hm,
    f8 as ku,
    bS as Gm,
    yC as Wm,
    bl as $m,
    gZ as Vm,
    yD as qm,
    lW as Mu,
    nQ as vu,
    hM as Tu,
    yE as Km,
    pd as Jm,
    fF as Au,
    ea as Qm,
    fV as Iu,
    lU as Ym,
    gs as yd,
    gn as pc,
    mg as Xm,
    aJ as Zm,
    gy as ef,
    yF as tf,
    mU as sf,
    eF as nf,
    i as of ,
    n5 as af,
    eG as Mc,
    cy as rf,
    tN as lf,
    lH as Pu,
    yG as cf,
    g$ as df,
    iF as uf,
    yH as pf,
    lh as bd,
    nL as mf,
    ac as ff,
    k1 as gf,
    mG as xd,
    nU as Sd,
    lj as mc,
    li as hf,
    sL as _f,
    nR as wd,
    lg as yf,
    yI as bf,
    dI as fc,
    dJ as gc,
    o9 as xf,
    g_ as Cd,
    ln as Sf,
    sO as wf,
    sM as Cf,
    sN as kf,
    kb as Mf,
    bM as vf,
    om as Tf,
    aX as hc,
    yJ as Af,
    yK as If,
    lP as Pf,
    gC as Ef,
    yL as jf,
    yM as Rf,
    fL as _c,
    lJ as Eu,
    gl as Bf,
    gm as Nf,
    h_ as Df,
    yN as Lf,
    et as Uf,
    hL as Of,
    hN as Ff,
    mn as zf,
    m2 as hr,
    yO as Hf,
    yP as kd,
    q7 as Gf,
    fZ as Md,
    lo as _r,
    l3 as vd,
    on as Wf,
    dq as $f,
    x9 as Td,
    yQ as Ad,
    en as Vf,
    aK as Id,
    lq as qf,
    od as Kf,
    m_ as Jf,
    iW as Pd,
    hu as Qf,
    fe as Yf,
    yR as Xf,
    yS as Zf,
    yT as eg,
    eL as tg,
    xB as sg,
    g9 as Ed,
    _ as ng,
    yU as og,
    uD as ag,
    lN as jd,
    nN as ig,
    mx as rg,
    hG as lg,
    id as cg,
    hF as dg,
    hX as ug,
    pF as pg,
    pA as mg
} from "./dykg4ktvbu3mhmdo.js";
import {
    vi as fg,
    vj as gg,
    vk as hg,
    tM as _g,
    vl as yg,
    vm as bg,
    ml as xg,
    vn as Sg,
    mo as wg,
    cH as ju,
    oE as Xe,
    vo as Ru,
    s_ as Cg,
    vp as kg,
    t8 as Bu,
    dr as bo,
    bq as en,
    vq as Mg,
    m as vg,
    bp as Gc,
    ko as Tg,
    vr as Ag,
    pf as Ft,
    ph as tn,
    vs as Ig,
    vt as Wc,
    vu as Pg,
    vv as Nu,
    vw as Du,
    vx as W,
    sY as Lu,
    pL as vc,
    rl as Eg,
    vy as jg,
    tI as Rg,
    tG as Bg,
    kN as Uu,
    vz as Ng,
    vA as Dg,
    vB as Lg,
    vC as Ug,
    vD as Og,
    aA as Fg,
    vE as zg,
    vF as Rd,
    vG as Ou,
    vH as Hg,
    vI as Gg,
    vJ as Wg,
    vK as $g,
    vL as Bd,
    vM as Vg,
    vN as qg,
    vO as Kg,
    vP as Jg,
    vQ as Qg,
    vR as Yg,
    vS as Xg,
    vT as Zg,
    vU as eh,
    vV as th,
    vW as sh,
    vX as nh,
    vY as Nd,
    vZ as oh,
    v_ as ah,
    v$ as ih,
    w0 as rh,
    w1 as lh,
    w2 as ch,
    w3 as dh,
    w4 as uh,
    w5 as ph,
    w6 as mh,
    w7 as fh,
    rh as gh,
    w8 as hh,
    w9 as _h,
    wa as yh,
    wb as bh,
    ik as xh,
    wc as Sh,
    wd as wh,
    k$ as Ch,
    lS as kh,
    we as Mh,
    wf as vh,
    wg as Th,
    wh as Ah,
    wi as Ih,
    wj as Ph,
    wk as Eh,
    wl as jh,
    wm as Rh,
    wn as Bh,
    wo as Nh,
    wp as Dh,
    wq as Lh,
    wr as Uh,
    ws as Oh,
    wt as Fh,
    wu as zh,
    wv as Hh,
    ww as Gh,
    wx as Wh,
    wy as $h,
    hO as Vh,
    wz as Fu,
    sU as qh,
    wA as Kh,
    wB as Jh,
    wC as Qh,
    wD as Yh,
    wE as Xh,
    wF as Zh,
    wG as e1,
    hI as zu,
    pW as Hu,
    cX as t1,
    wH as s1,
    wI as Dd,
    wJ as Tr,
    jD as Gu,
    da as Wu,
    wK as n1,
    wL as o1,
    wM as a1,
    q3 as i1,
    wN as Ld,
    jX as xo,
    wO as Qn,
    wP as r1,
    wQ as $u,
    ao as l1,
    wR as c1,
    wS as d1,
    wT as u1,
    wU as p1,
    iH as Vu,
    pN as m1,
    wV as qu,
    fn as Co,
    sT as Ku,
    cw as f1,
    dG as g1,
    wW as h1,
    eo as Ar,
    wX as _1,
    wY as y1,
    wZ as b1,
    p$ as x1,
    w_ as S1,
    w$ as Ud,
    x0 as Ju,
    x1 as w1,
    x2 as C1,
    ek as Qu,
    x3 as k1,
    x4 as Yu,
    x5 as Xu,
    bv as M1,
    tD as Zu,
    x6 as ep,
    x7 as v1,
    x8 as yc,
    rA as T1,
    x9 as A1,
    xa as yr,
    xb as I1,
    xc as P1,
    xd as E1,
    xe as Tc,
    nt as j1,
    xf as kr,
    xg as R1,
    xh as B1,
    xi as N1,
    xj as D1,
    tH as L1,
    xk as tp,
    xl as U1,
    xm as O1,
    xn as F1,
    xo as Od,
    xp as z1,
    xq as H1,
    rF as G1,
    ce as W1,
    xr as $1,
    xs as V1,
    P as Fd,
    xt as q1,
    tB as K1,
    xu as J1,
    xv as Q1,
    iK as Y1,
    xw as X1,
    xx as Z1,
    iM as e_,
    no as t_,
    xy as s_,
    xz as n_,
    xA as o_,
    xB as a_,
    xC as i_,
    xD as r_,
    xE as zd,
    xF as l_,
    xG as c_,
    el as d_,
    lc as u_,
    j3 as p_,
    l5 as m_,
    xH as f_,
    xI as g_,
    xJ as Jn,
    xK as h_,
    xL as __,
    xM as y_,
    xN as b_,
    bS as It,
    xO as x_,
    xP as S_,
    xQ as w_,
    xR as C_,
    xS as br,
    hK as k_,
    xT as M_,
    xU as v_,
    xV as fo,
    xW as T_,
    xX as A_,
    xY as I_,
    xZ as P_,
    x_ as E_,
    x$ as j_,
    y0 as R_,
    y1 as B_,
    y2 as N_,
    y3 as D_,
    y4 as L_,
    y5 as U_,
    e0 as O_,
    e3 as Hd,
    y6 as Gd,
    jB as go,
    y7 as Wd,
    qF as F_,
    tS as $d,
    y8 as z_,
    y9 as H_,
    ya as G_,
    yb as Vd,
    yc as W_,
    j0 as $_,
    yd as V_,
    bn as q_,
    ye as K_,
    yf as J_,
    t2 as Q_,
    yg as Y_,
    bB as X_,
    yh as Z_,
    cE as e2,
    yi as t2,
    yj as s2,
    yk as n2,
    yl as o2,
    ym as a2,
    bs as i2,
    bt as r2,
    yn as l2,
    yo as c2,
    yp as d2,
    jn as u2,
    lD as p2,
    fd as m2,
    yq as f2,
    yr as g2,
    ys as h2,
    yt as _2,
    m1 as y2
} from "./k15yxxoybkkir2ou.js";
import {
    o as b2
} from "./ew68kf01y1h7e4uk.js";
import {
    b as x2
} from "./k2oaaf8ac9lafsub.js";
import {
    P as S2,
    u as w2,
    h as C2
} from "./jttqqjx6qab96ezg.js";
import {
    u as k2
} from "./e3ddui4ro6nb7fig.js";
const qd = Bp((t, e) => Np(!1), t => t != null ? t : "default");

function M2(t) {
    "use forget";
    const e = Et.c(9),
        o = Ke(),
        a = t != null ? t : "default";
    let l;
    e[0] !== o || e[1] !== a ? (l = () => qd(o, a), e[0] = o, e[1] = a, e[2] = l) : l = e[2];
    const i = fe(l);
    let d;
    e[3] !== o || e[4] !== a ? (d = () => qd.set(o, a, !0), e[3] = o, e[4] = a, e[5] = d) : d = e[5];
    const b = d;
    let s;
    return e[6] !== b || e[7] !== i ? (s = {
        isDismissed: i,
        dismiss: b
    }, e[6] = b, e[7] = i, e[8] = s) : s = e[8], s
}

function v2(t) {
    "use forget";
    return sp(t).shouldShow
}

function sp(t) {
    "use forget";
    const e = Et.c(6),
        {
            clientThreadId: o,
            entrypointData: a,
            isNewThread: l
        } = t,
        i = Ke(),
        {
            isDismissed: d,
            dismiss: b
        } = M2(o),
        [s, m] = Ht(o, T2),
        x = fg("(max-height: 660px)");
    let C;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (C = gg(), e[0] = C) : C = e[0];
    const u = C;
    let c;
    e[1] !== i ? (c = i != null && hg(i), e[1] = i, e[2] = c) : c = e[2];
    const y = !!a && !!o && !!l && !d && !u && !c && !x && !s && !m;
    let S;
    return e[3] !== b || e[4] !== y ? (S = {
        shouldShow: y,
        dismiss: b
    }, e[3] = b, e[4] = y, e[5] = S) : S = e[5], S
}

function T2(t) {
    var e;
    return [wt.hasUserMessage(t), (e = t == null ? void 0 : t.isLoading) != null ? e : !1]
}
const A2 = t => {
        "use forget";
        var q, V, re, K;
        const e = Et.c(38),
            {
                entrypointData: o,
                clientThreadId: a,
                className: l,
                isNewThread: i
            } = t,
            d = Ke();
        let b;
        e[0] !== a || e[1] !== o || e[2] !== i ? (b = {
            clientThreadId: a,
            entrypointData: o,
            isNewThread: i
        }, e[0] = a, e[1] = o, e[2] = i, e[3] = b) : b = e[3];
        const {
            dismiss: s,
            shouldShow: m
        } = sp(b);
        let x;
        e[4] !== ((q = o.onboarding_config) == null ? void 0 : q.onboarding_preview_items) ? (x = ((re = (V = o.onboarding_config) == null ? void 0 : V.onboarding_preview_items) != null ? re : []).map(P2).filter(E2).map(j2).slice(0, 2), e[4] = (K = o.onboarding_config) == null ? void 0 : K.onboarding_preview_items, e[5] = x) : x = e[5];
        const C = x;
        let u, c;
        e[6] !== C.length || e[7] !== m ? (u = () => {
            m && (yg(), Ze.logEventWithStatsig("ChatGPT Web Pulse Announcement Banner Shown", "chatgpt_web_pulse_announcement_banner_shown", {
                preview_image_count: C.length
            }), Yn.count(Xn.PULSE, "chatgpt_web_pulse_announcement_banner_shown"))
        }, c = [m, C.length], e[6] = C.length, e[7] = m, e[8] = u, e[9] = c) : (u = e[8], c = e[9]), F.useEffect(u, c);
        let g;
        e[10] !== s ? (g = () => {
            s(), bg(), Ze.logEventWithStatsig("ChatGPT Web Pulse Announcement Banner Dismissed", "chatgpt_web_pulse_announcement_banner_dismissed"), Yn.count(Xn.PULSE, "chatgpt_web_pulse_announcement_banner_dismissed")
        }, e[10] = s, e[11] = g) : g = e[11];
        const y = g;
        let S;
        e[12] !== d || e[13] !== o ? (S = () => {
            Ze.logEventWithStatsig("ChatGPT Web Pulse Announcement Banner CTA Clicked", "chatgpt_web_pulse_announcement_banner_cta_clicked"), Yn.count(Xn.PULSE, "chatgpt_web_pulse_announcement_banner_cta_clicked"), b2(d, {
                source: xg.AnnouncementBanner,
                entrypointData: o
            })
        }, e[12] = d, e[13] = o, e[14] = S) : S = e[14];
        const v = S;
        if (!m) return null;
        let j;
        e[15] !== C ? (j = n.jsx(Sg, {
            previewImages: C,
            size: "lg",
            className: "flex-shrink-0"
        }), e[15] = C, e[16] = j) : j = e[16];
        let M;
        e[17] === Symbol.for("react.memo_cache_sentinel") ? (M = n.jsx(wg, {
            "aria-hidden": "true",
            className: "text-token-text-primary h-5 w-5 flex-shrink-0"
        }), e[17] = M) : M = e[17];
        let h;
        e[18] !== o.cta_text ? (h = n.jsxs("div", {
            className: "flex items-center gap-1",
            children: [M, n.jsx("p", {
                className: "text-token-text-primary text-base font-semibold",
                children: o.cta_text
            })]
        }), e[18] = o.cta_text, e[19] = h) : h = e[19];
        let w;
        e[20] !== o.caption ? (w = n.jsx("p", {
            className: "text-token-text-primary text-sm",
            children: o.caption
        }), e[20] = o.caption, e[21] = w) : w = e[21];
        let P;
        e[22] !== w || e[23] !== h ? (P = n.jsxs("div", {
            className: "min-w-0 space-y-[2px] ps-2",
            children: [h, w]
        }), e[22] = w, e[23] = h, e[24] = P) : P = e[24];
        let R;
        e[25] !== P || e[26] !== j ? (R = n.jsx("div", {
            className: "flex w-full flex-wrap items-center gap-6 md:flex-nowrap",
            children: n.jsxs("div", {
                className: "flex min-w-0 flex-1 items-center gap-6",
                children: [j, P]
            })
        }), e[25] = P, e[26] = j, e[27] = R) : R = e[27];
        const D = R;
        let E;
        e[28] === Symbol.for("react.memo_cache_sentinel") ? (E = n.jsx(Ls, Rt({}, I2.cta)), e[28] = E) : E = e[28];
        let A;
        e[29] !== v ? (A = n.jsx(bc, {
            size: "large",
            color: "primary",
            onClick: v,
            children: E
        }), e[29] = v, e[30] = A) : A = e[30];
        const G = A;
        let k;
        e[31] !== l ? (k = Ct("w-full", l), e[31] = l, e[32] = k) : k = e[32];
        let N;
        return e[33] !== D || e[34] !== G || e[35] !== y || e[36] !== k ? (N = n.jsx(n.Fragment, {
            children: n.jsx(ju, {
                className: k,
                contentClassName: "flex-row items-center justify-between gap-4 md:gap-8",
                content: D,
                customCtas: G,
                onDismiss: y,
                verticalCta: !1
            })
        }), e[33] = D, e[34] = G, e[35] = y, e[36] = k, e[37] = N) : N = e[37], N
    },
    I2 = eo({
        title: {
            defaultMessage: "Your plan now comes with Pulse",
            id: "pulse.announcement.banner.title"
        },
        body: {
            defaultMessage: "Proactive updates, reminders, and research made for you.",
            id: "pulse.announcement.banner.body"
        },
        cta: {
            defaultMessage: "Try it",
            id: "pulse.announcement.banner.cta"
        }
    });

function P2(t) {
    return t.image_url
}

function E2(t) {
    return !!t
}

function j2(t) {
    return _g(t)
}
const O = eo({
    personal_trainer_title: {
        id: "curated-starter-prompts.personal_trainer.title-2",
        defaultMessage: "Be my personal trainer"
    },
    personal_trainer_body: {
        id: "curated-starter-prompts.personal_trainer.body-3",
        defaultMessage: "Create a strength training plan"
    },
    personal_trainer_prompt: {
        id: "curated-starter-prompts.personal_trainer.prompt",
        defaultMessage: "Create a strength training plan with daily check-ins and guidance on exercises, sets, and progression."
    },
    upgrade_skin_care_title: {
        id: "curated-starter-prompts.upgrade_skin_care.title",
        defaultMessage: "Upgrade my skin care"
    },
    upgrade_skin_care_body: {
        id: "curated-starter-prompts.upgrade_skin_care.body",
        defaultMessage: "Use my selfie for skincare tips"
    },
    upgrade_skin_care_prompt: {
        id: "curated-starter-prompts.upgrade_skin_care.prompt",
        defaultMessage: "I want good advice with skin care and makeup. Based on a selfie, get me advice for skin and hair, along with any products. Ask for a selfie if not provided."
    },
    is_this_scam_title: {
        id: "curated-starter-prompts.is_this_scam.title",
        defaultMessage: "Is this text a scam?"
    },
    is_this_scam_body: {
        id: "curated-starter-prompts.is_this_scam.body",
        defaultMessage: "Tell me if this text is a scam"
    },
    is_this_scam_prompt: {
        id: "curated-starter-prompts.is_this_scam.prompt",
        defaultMessage: "I just got this weird text message. Here's a screenshot. Do you think it’s a scam or some kind of phishing attempt?"
    },
    motivate_me_title: {
        id: "curated-starter-prompts.motivate_me.title",
        defaultMessage: "Motivate me"
    },
    motivate_me_body: {
        id: "curated-starter-prompts.motivate_me.body-2",
        defaultMessage: "Help with procrastination"
    },
    motivate_me_prompt: {
        id: "curated-starter-prompts.motivate_me.prompt",
        defaultMessage: "I'm struggling to get started. Motivate me. Break things down into the very small tasks to make it easy. Ask me questions for context."
    },
    meal_prep_title: {
        id: "curated-starter-prompts.meal_prep.title",
        defaultMessage: "Simplify meal prep"
    },
    meal_prep_body: {
        id: "curated-starter-prompts.meal_prep.body-2",
        defaultMessage: "Create a protein-packed meal plan"
    },
    meal_prep_prompt: {
        id: "curated-starter-prompts.meal_prep.prompt",
        defaultMessage: "Create a plan for meal prep with a grocery list. I want more protein and less carbs. I have a limited budget. Keep it simple."
    },
    morning_routine_title: {
        id: "curated-starter-prompts.morning_routine.title",
        defaultMessage: "Build my morning routine"
    },
    morning_routine_body: {
        id: "curated-starter-prompts.morning_routine.body-2",
        defaultMessage: "Build a morning routine for focus"
    },
    morning_routine_prompt: {
        id: "curated-starter-prompts.morning_routine.prompt",
        defaultMessage: "Help me build a better morning routine. I want to start my days with more focus. Be my coach and keep me honest."
    },
    budget_title: {
        id: "curated-starter-prompts.budget.title",
        defaultMessage: "Make my budget"
    },
    budget_body: {
        id: "curated-starter-prompts.budget.body",
        defaultMessage: "Make my weekly budget"
    },
    budget_prompt: {
        id: "curated-starter-prompts.budget.prompt",
        defaultMessage: "I want to get control of my bills. Here's what is due, my monthly paycheck, other expenses. I'd like help getting on top of this and then trying to save some money."
    },
    color_theory_title: {
        id: "curated-starter-prompts.color_theory.title",
        defaultMessage: "Do my color theory analysis"
    },
    color_theory_body: {
        id: "curated-starter-prompts.color_theory.body",
        defaultMessage: "Do my color theory analysis"
    },
    color_theory_prompt: {
        id: "curated-starter-prompts.color_theory.prompt",
        defaultMessage: "Take a look at this picture of me. Using color theory, tell me my season and suggest my best colors for clothing and makeup. Ask for a picture if not provided."
    },
    fix_procrastination_title: {
        id: "curated-starter-prompts.fix_procrastination.title-2",
        defaultMessage: "Help with procrastination"
    },
    fix_procrastination_body: {
        id: "curated-starter-prompts.fix_procrastination.body",
        defaultMessage: "Help me start a project I put off"
    },
    fix_procrastination_prompt: {
        id: "curated-starter-prompts.fix_procrastination.prompt",
        defaultMessage: "I'm struggling to get started. Motivate me. Break things down into the very small tasks to make it easy. Ask me questions for context."
    },
    decode_this_text_message_title: {
        id: "curated-starter-prompts.decode_this_text_message.title",
        defaultMessage: "Decode this text message"
    },
    decode_this_text_message_body: {
        id: "curated-starter-prompts.decode_this_text_message.body",
        defaultMessage: "Decode this text message"
    },
    decode_this_text_message_prompt: {
        id: "curated-starter-prompts.decode_this_text_message.prompt",
        defaultMessage: "Decode this text and explain possible intentions behind it. I want to understand what the person might really mean."
    },
    help_me_get_recognized_title: {
        id: "curated-starter-prompts.help_me_get_recognized.title",
        defaultMessage: "Help me get recognized"
    },
    help_me_get_recognized_body: {
        id: "curated-starter-prompts.help_me_get_recognized.body",
        defaultMessage: "Help me get recognition for my work"
    },
    help_me_get_recognized_prompt: {
        id: "curated-starter-prompts.help_me_get_recognized.prompt",
        defaultMessage: "I'm not getting recognized for everything I'm doing. Be my personal coach. Ask me questions and help me advocate for myself."
    },
    anime_style_portrait_title: {
        id: "curated-starter-prompts.anime_style_portrait.title",
        defaultMessage: "Anime-style portrait"
    },
    anime_style_portrait_body: {
        id: "curated-starter-prompts.anime_style_portrait.body",
        defaultMessage: "Make an anime-style portrait of me"
    },
    anime_style_portrait_prompt: {
        id: "curated-starter-prompts.anime_style_portrait.prompt-2",
        defaultMessage: "Recreate this photo in a playful anime style. Ask for a photo if not provided."
    },
    action_figure_portrait_title: {
        id: "curated-starter-prompts.action_figure_portrait.title",
        defaultMessage: "Action figure portrait"
    },
    action_figure_portrait_body: {
        id: "curated-starter-prompts.action_figure_portrait.body",
        defaultMessage: "Turn me into an action figure"
    },
    action_figure_portrait_prompt: {
        id: "curated-starter-prompts.action_figure_portrait.prompt",
        defaultMessage: "Use my photo to create a 3D superhero action figure of me. Label the box and include my pet as a sidekick. Ask for my name and picture if not provided."
    },
    b_w_raindrop_portrait_title: {
        id: "curated-starter-prompts.b_w_raindrop_portrait.title-2",
        defaultMessage: "Cinematic raindrop portrait"
    },
    b_w_raindrop_portrait_body: {
        id: "curated-starter-prompts.b_w_raindrop_portrait.body-2",
        defaultMessage: "Make a cinematic raindrop portrait"
    },
    b_w_raindrop_portrait_prompt: {
        id: "curated-starter-prompts.b_w_raindrop_portrait.prompt-2",
        defaultMessage: "Make this photo a black and white portrait of the subject emerging from water. Make it feel cinematic. Ask for a photo if not provided."
    },
    b_w_studio_portrait_title: {
        id: "curated-starter-prompts.b_w_studio_portrait.title",
        defaultMessage: "Studio Portrait in B&W"
    },
    b_w_studio_portrait_body: {
        id: "curated-starter-prompts.b_w_studio_portrait.body",
        defaultMessage: "Make a studio portrait in B&W"
    },
    b_w_studio_portrait_prompt: {
        id: "curated-starter-prompts.b_w_studio_portrait.prompt",
        defaultMessage: "Fashion photography portrait, black and white. high fashion, editorial lighting, cinematic."
    },
    create_a_puppet_title: {
        id: "curated-starter-prompts.create_a_puppet.title",
        defaultMessage: "Create a puppet"
    },
    create_a_puppet_body: {
        id: "curated-starter-prompts.create_a_puppet.body",
        defaultMessage: "Create a puppet"
    },
    create_a_puppet_prompt: {
        id: "curated-starter-prompts.create_a_puppet.prompt",
        defaultMessage: "Make a puppet from this photo. Ask for a photo if not provided."
    },
    document_summary_title: {
        id: "curated-starter-prompts.document_summary.title",
        defaultMessage: "Read this document"
    },
    document_summary_body: {
        id: "curated-starter-prompts.document_summary.body",
        defaultMessage: "Read this document"
    },
    document_summary_prompt: {
        id: "curated-starter-prompts.document_summary.prompt",
        defaultMessage: "Give me the key points from this document. Start simple, and I'll ask follow-up questions. Ask for a document if not provided."
    },
    recommend_a_movie_title: {
        id: "curated-starter-prompts.recommend_a_movie.title",
        defaultMessage: "Recommend a movie"
    },
    recommend_a_movie_body: {
        id: "curated-starter-prompts.recommend_a_movie.body",
        defaultMessage: "Recommend a movie"
    },
    recommend_a_movie_prompt: {
        id: "curated-starter-prompts.recommend_a_movie.prompt",
        defaultMessage: "What are well-reviewed movies I should watch tonight? I love action and comedies."
    },
    create_a_quiz_title: {
        id: "curated-starter-prompts.create_a_quiz.title",
        defaultMessage: "Create a quiz"
    },
    create_a_quiz_body: {
        id: "curated-starter-prompts.create_a_quiz.body",
        defaultMessage: "Create a quiz"
    },
    create_a_quiz_prompt: {
        id: "curated-starter-prompts.create_a_quiz.prompt",
        defaultMessage: "I have an exam this week. Create a quiz based on my notes and ask questions one at a time."
    },
    language_coach_spanish_title: {
        id: "curated-starter-prompts.language_coach_spanish.title",
        defaultMessage: "Be my language coach"
    },
    language_coach_spanish_body: {
        id: "curated-starter-prompts.language_coach_spanish.body",
        defaultMessage: "Help me practice Spanish vocabulary and gently correct my mistakes."
    },
    language_coach_spanish_prompt: {
        id: "curated-starter-prompts.language_coach_spanish.prompt",
        defaultMessage: "I'm trying to master some Spanish vocabulary before traveling to Mexico. Can you practice with me and gently correct my mistakes when I get something wrong?"
    },
    friendly_text_roommate_title: {
        id: "curated-starter-prompts.friendly_text_roommate.title",
        defaultMessage: "Make this text sound friendlier"
    },
    friendly_text_roommate_body: {
        id: "curated-starter-prompts.friendly_text_roommate.body",
        defaultMessage: "Make this text to my roommate kinder, please"
    },
    friendly_text_roommate_prompt: {
        id: "curated-starter-prompts.friendly_text_roommate.prompt",
        defaultMessage: "My roommate plays heavy metal music really loud late at night. Can you draft a friendly text that asks him to turn it down after 10 PM?"
    },
    packing_list_camping_title: {
        id: "curated-starter-prompts.packing_list_camping.title",
        defaultMessage: "Make a packing list"
    },
    packing_list_camping_body: {
        id: "curated-starter-prompts.packing_list_camping.body",
        defaultMessage: "Create a minimal packing list for a camping trip"
    },
    packing_list_camping_prompt: {
        id: "curated-starter-prompts.packing_list_camping.prompt",
        defaultMessage: "I'm planning on going camping for the first time with friends this weekend and don't have much room to bring stuff with me. Can you create a packing list with just the bare essentials?"
    },
    gift_under_20_title: {
        id: "curated-starter-prompts.gift_under_20.title",
        defaultMessage: "Find a great gift under $20"
    },
    gift_under_20_body: {
        id: "curated-starter-prompts.gift_under_20.body",
        defaultMessage: "Give me gift ideas under $20 for a friend"
    },
    gift_under_20_prompt: {
        id: "curated-starter-prompts.gift_under_20.prompt",
        defaultMessage: "My friend loves kpop music and they have a birthday coming up. Can you recommend a gift for them that's under $20?"
    },
    plan_game_night_mystery_title: {
        id: "curated-starter-prompts.plan_game_night_mystery.title",
        defaultMessage: "Plan a game night"
    },
    plan_game_night_mystery_body: {
        id: "curated-starter-prompts.plan_game_night_mystery.body",
        defaultMessage: "Plan a themed game night with six friends"
    },
    plan_game_night_mystery_prompt: {
        id: "curated-starter-prompts.plan_game_night_mystery.prompt",
        defaultMessage: "I want to host a murder mystery party with my friends. Can you help plan the mystery and suggest fun food and drinks to serve?"
    },
    decluttering_plan_4_weeks_title: {
        id: "curated-starter-prompts.decluttering_plan_4_weeks.title",
        defaultMessage: "Make a decluttering plan"
    },
    decluttering_plan_4_weeks_body: {
        id: "curated-starter-prompts.decluttering_plan_4_weeks.body",
        defaultMessage: "Create a 4 week, 10 mins-per-day decluttering plan"
    },
    decluttering_plan_4_weeks_prompt: {
        id: "curated-starter-prompts.decluttering_plan_4_weeks.prompt",
        defaultMessage: "I want to have more kitchen countertop space. Can you help me create a decluttering plan so I can make more space? I only want to spend 10 minutes per day on it over the next 4 weeks."
    },
    fridge_recipes_three_title: {
        id: "curated-starter-prompts.fridge_recipes_three.title",
        defaultMessage: "Recipes for what's in my fridge"
    },
    fridge_recipes_three_body: {
        id: "curated-starter-prompts.fridge_recipes_three.body",
        defaultMessage: "Give me 3 quick recipes with chicken, lettuce, and salsa"
    },
    fridge_recipes_three_prompt: {
        id: "curated-starter-prompts.fridge_recipes_three.prompt",
        defaultMessage: "I'm stumped on what to make for dinner. Can you create three easy recipes for me based on the leftover chicken, lettuce, and cheese I have in my fridge?"
    },
    desk_stretch_routine_title: {
        id: "curated-starter-prompts.desk_stretch_routine.title",
        defaultMessage: "Make a daily desk stretch routine"
    },
    desk_stretch_routine_body: {
        id: "curated-starter-prompts.desk_stretch_routine.body",
        defaultMessage: "Draft a desk-friendly, 5-minute stretch routine"
    },
    desk_stretch_routine_prompt: {
        id: "curated-starter-prompts.desk_stretch_routine.prompt",
        defaultMessage: "I have a lot of back pain at my desk job. Can you suggest some 5-minute stretches that I can do discreetly at the office?"
    },
    prep_for_appointment_title: {
        id: "curated-starter-prompts.prep_for_appointment.title",
        defaultMessage: "Prep for an appointment"
    },
    prep_for_appointment_body: {
        id: "curated-starter-prompts.prep_for_appointment.body",
        defaultMessage: "Write questions + checklist for my PT visit"
    },
    prep_for_appointment_prompt: {
        id: "curated-starter-prompts.prep_for_appointment.prompt",
        defaultMessage: "I have a mild cough and a runny nose. Help me prep for my doctor's visit with a checklist."
    },
    decode_bill_title: {
        id: "curated-starter-prompts.decode_bill.title",
        defaultMessage: "Decode this bill"
    },
    decode_bill_body: {
        id: "curated-starter-prompts.decode_bill.body",
        defaultMessage: "Explain this charge and what I owe, simply."
    },
    decode_bill_prompt: {
        id: "curated-starter-prompts.decode_bill.prompt",
        defaultMessage: "I'll upload my bill. Help me understand why I was charged this amount and how much I owe in plain language."
    },
    decision_pros_cons_title: {
        id: "curated-starter-prompts.decision_pros_cons.title",
        defaultMessage: "Help me make a decision"
    },
    decision_pros_cons_body: {
        id: "curated-starter-prompts.decision_pros_cons.body",
        defaultMessage: "Compare A vs B: give me pros, cons, and a recommendation"
    },
    decision_pros_cons_prompt: {
        id: "curated-starter-prompts.decision_pros_cons.prompt",
        defaultMessage: "I'm trying to decide what to buy. Can you give me pros, cons and a recommendation?"
    },
    organize_notes_title: {
        id: "curated-starter-prompts.organize_notes.title",
        defaultMessage: "Organize my notes"
    },
    organize_notes_body: {
        id: "curated-starter-prompts.organize_notes.body",
        defaultMessage: "Turn these notes into an outline + actions."
    },
    organize_notes_prompt: {
        id: "curated-starter-prompts.organize_notes.prompt",
        defaultMessage: "Summarize this document and give me a list of key points and action items"
    },
    excel_shortcuts_cheatsheet_title: {
        id: "curated-starter-prompts.excel_shortcuts_cheatsheet.title",
        defaultMessage: "Write an Excel cheat sheet"
    },
    excel_shortcuts_cheatsheet_body: {
        id: "curated-starter-prompts.excel_shortcuts_cheatsheet.body",
        defaultMessage: "Write a one-page Excel shortcuts cheat sheet."
    },
    excel_shortcuts_cheatsheet_prompt: {
        id: "curated-starter-prompts.excel_shortcuts_cheatsheet.prompt",
        defaultMessage: "I'm trying to get better at making spreadsheets. Can you make me a one-page cheat sheet to help me be more productive?"
    },
    presentation_outline_title: {
        id: "curated-starter-prompts.presentation_outline.title",
        defaultMessage: "Start a presentation outline"
    },
    presentation_outline_body: {
        id: "curated-starter-prompts.presentation_outline.body",
        defaultMessage: "Outline a 6-slide deck with key points"
    },
    presentation_outline_prompt: {
        id: "curated-starter-prompts.presentation_outline.prompt",
        defaultMessage: "I'm putting together a presentation on the digestive system for school. Outline a 6-slide deck with key points to help me get started."
    },
    social_media_captions_title: {
        id: "curated-starter-prompts.social_media_captions.title",
        defaultMessage: "Draft social media captions"
    },
    social_media_captions_body: {
        id: "curated-starter-prompts.social_media_captions.body",
        defaultMessage: "Write 5 short captions for a summer trip Instagram post"
    },
    social_media_captions_prompt: {
        id: "curated-starter-prompts.social_media_captions.prompt",
        defaultMessage: "Here's an Instagram campaign I'm running. Write short captions for each of the images."
    },
    true_crime_watch_list_title: {
        id: "curated-starter-prompts.true_crime_watch_list.title",
        defaultMessage: "Make a true crime watch list"
    },
    true_crime_watch_list_body: {
        id: "curated-starter-prompts.true_crime_watch_list.body",
        defaultMessage: "Recommend true crime books, videos, and podcasts"
    },
    true_crime_watch_list_prompt: {
        id: "curated-starter-prompts.true_crime_watch_list.prompt",
        defaultMessage: "Recommend books, videos, and podcasts about true crime that I might like."
    },
    help_me_translate_title: {
        id: "curated-starter-prompts.help_me_translate.title",
        defaultMessage: "Help me translate"
    },
    help_me_translate_body: {
        id: "curated-starter-prompts.help_me_translate.body",
        defaultMessage: "Help me translate"
    },
    help_me_translate_prompt: {
        id: "curated-starter-prompts.help_me_translate.prompt",
        defaultMessage: "Help me translate between English and another language. Explain tone and nuance where helpful."
    },
    professional_email_boss_title: {
        id: "curated-starter-prompts.professional_email_boss.title",
        defaultMessage: "Write a professional email"
    },
    professional_email_boss_body: {
        id: "curated-starter-prompts.professional_email_boss.body",
        defaultMessage: "Draft a clear email to my boss about a project that I want to kick off."
    },
    professional_email_boss_prompt: {
        id: "curated-starter-prompts.professional_email_boss.prompt",
        defaultMessage: "Draft a clear email to my boss about a project that I want to kick off."
    },
    summarize_financial_news_title: {
        id: "curated-starter-prompts.summarize_financial_news.title",
        defaultMessage: "Summarize this"
    },
    summarize_financial_news_body: {
        id: "curated-starter-prompts.summarize_financial_news.body",
        defaultMessage: "Summarize the latest financial news with three takeaways that are relevant for me."
    },
    summarize_financial_news_prompt: {
        id: "curated-starter-prompts.summarize_financial_news.prompt",
        defaultMessage: "Summarize the latest financial news with three takeaways that are relevant for me."
    },
    breathing_meditation_title: {
        id: "curated-starter-prompts.breathing_meditation.title",
        defaultMessage: "Lead a breathing meditation"
    },
    breathing_meditation_body: {
        id: "curated-starter-prompts.breathing_meditation.body",
        defaultMessage: "Lead a 5-minute breathing meditation"
    },
    breathing_meditation_prompt: {
        id: "curated-starter-prompts.breathing_meditation.prompt",
        defaultMessage: "Lead a 5-minute breathing meditation."
    },
    voice_mock_interview_title: {
        id: "curated-starter-prompts.voice_mock_interview.title",
        defaultMessage: "Mock interview coach"
    },
    voice_mock_interview_body: {
        id: "curated-starter-prompts.voice_mock_interview.body",
        defaultMessage: "Do a voice mock interview for [role] and give feedback"
    },
    voice_mock_interview_prompt: {
        id: "curated-starter-prompts.voice_mock_interview.prompt",
        defaultMessage: "Do a voice mock interview for [role] and give feedback."
    },
    toast_speech_coach_title: {
        id: "curated-starter-prompts.toast_speech_coach.title",
        defaultMessage: "Toast coach"
    },
    toast_speech_coach_body: {
        id: "curated-starter-prompts.toast_speech_coach.body",
        defaultMessage: "Listen to my toast; coach pacing, pauses, and tone"
    },
    toast_speech_coach_prompt: {
        id: "curated-starter-prompts.toast_speech_coach.prompt",
        defaultMessage: "Listen to my toast; coach my pacing, pauses, and tone."
    },
    logo_ideas_simple_title: {
        id: "curated-starter-prompts.logo_ideas_simple.title",
        defaultMessage: "Create simple logo ideas"
    },
    logo_ideas_simple_body: {
        id: "curated-starter-prompts.logo_ideas_simple.body",
        defaultMessage: "Create simple logo ideas for my business, they should be clean and modern"
    },
    logo_ideas_simple_prompt: {
        id: "curated-starter-prompts.logo_ideas_simple.prompt",
        defaultMessage: "Create simple logo ideas for my business, they should be clean and modern"
    },
    translation_generic_title: {
        id: "curated-starter-prompts.translation_generic.title",
        defaultMessage: "Translation"
    },
    translation_generic_body: {
        id: "curated-starter-prompts.translation_generic.body",
        defaultMessage: "Translate text between languages"
    },
    translation_generic_prompt: {
        id: "curated-starter-prompts.translation_generic.prompt",
        defaultMessage: "Translate the following text to [language]. Keep it natural and explain any tricky phrases."
    },
    professional_profile_picture_title: {
        id: "curated-starter-prompts.professional_profile_picture.title",
        defaultMessage: "Make a professional profile picture"
    },
    professional_profile_picture_body: {
        id: "curated-starter-prompts.professional_profile_picture.body",
        defaultMessage: "Create a professional headshot of me using this photo"
    },
    professional_profile_picture_prompt: {
        id: "curated-starter-prompts.professional_profile_picture.prompt",
        defaultMessage: "Create a professional headshot of me using this photo. I'll upload the photo."
    },
    visualize_concept_benzene_title: {
        id: "curated-starter-prompts.visualize_concept_benzene.title",
        defaultMessage: "Visualize a concept"
    },
    visualize_concept_benzene_body: {
        id: "curated-starter-prompts.visualize_concept_benzene.body",
        defaultMessage: "Create an image to help me visualize the 3D molecular structure for benzene."
    },
    visualize_concept_benzene_prompt: {
        id: "curated-starter-prompts.visualize_concept_benzene.prompt",
        defaultMessage: "Please create an image to help me visualize the 3D molecular structure for benzene."
    },
    redesign_this_room_title: {
        id: "curated-starter-prompts.redesign_this_room.title",
        defaultMessage: "Redesign this room"
    },
    redesign_this_room_body: {
        id: "curated-starter-prompts.redesign_this_room.body",
        defaultMessage: "Make this room a mid-century modern style with new paint and furniture."
    },
    redesign_this_room_prompt: {
        id: "curated-starter-prompts.redesign_this_room.prompt",
        defaultMessage: "Redesign this room with new paint and furniture. I'll upload a photo of the room."
    },
    make_me_an_action_figure_title: {
        id: "curated-starter-prompts.make_me_an_action_figure.title",
        defaultMessage: "Make me an action figure"
    },
    make_me_an_action_figure_body: {
        id: "curated-starter-prompts.make_me_an_action_figure.body",
        defaultMessage: "Draw a picture of me as a real-life action figure. Include my interests, like gardening and baking, in the packaging."
    },
    make_me_an_action_figure_prompt: {
        id: "curated-starter-prompts.make_me_an_action_figure.prompt",
        defaultMessage: "Draw a picture of me as a real-life action figure. Include my interests, like gardening and baking, in the packaging. I'll upload my photo."
    },
    promo_code_title: {
        id: "curated-starter-prompts.promo_code.title",
        defaultMessage: "Find shopping promo codes"
    },
    promo_code_body: {
        id: "curated-starter-prompts.promo_code.body",
        defaultMessage: "Find shopping promo codes"
    },
    promo_code_prompt: {
        id: "curated-starter-prompts.promo_code.prompt",
        defaultMessage: "Find promo codes or coupons for my favorite sites. Confirm they're active."
    },
    tailor_lesson_plan_title: {
        id: "curated-starter-prompts.tailor_lesson_plan.title",
        defaultMessage: "Tailor a lesson plan"
    },
    tailor_lesson_plan_body: {
        id: "curated-starter-prompts.tailor_lesson_plan.body",
        defaultMessage: "Tailor a lesson plan"
    },
    tailor_lesson_plan_prompt: {
        id: "curated-starter-prompts.tailor_lesson_plan.prompt",
        defaultMessage: "Draft a first-pass lesson plan for my class that I can refine. Use anything you already know about my grade level, subject, and teaching context — and if you're missing key details, please ask me before you begin. The plan should include: 1) A clear, student-friendly learning objective 2) A timed schedule (warm-up, direct instruction, guided practice, independent work, closure) 3) Materials needed 4) 2 to 3 quick formative check-for-understanding strategies. Keep this as a helpful starting draft that I can adjust to my teaching style."
    },
    questions_on_different_levels_title: {
        id: "curated-starter-prompts.questions_on_different_levels.title",
        defaultMessage: "Questions on different levels"
    },
    questions_on_different_levels_body: {
        id: "curated-starter-prompts.questions_on_different_levels.body",
        defaultMessage: "Generate practice problems"
    },
    questions_on_different_levels_prompt: {
        id: "curated-starter-prompts.questions_on_different_levels.prompt",
        defaultMessage: "Generate practice problems on a topic (ask me to specify the topic). Include a mix of easy, medium, and challenging problems and label the difficulty. Provide a fully worked solution for each problem that shows each step clearly so I can confirm accuracy or share with students who need support. If you already know my grade level, subject, or class details, use that — otherwise, just ask me to confirm what you need."
    },
    create_quiz_title: {
        id: "curated-starter-prompts.create_quiz.title",
        defaultMessage: "Create a quiz"
    },
    create_quiz_body: {
        id: "curated-starter-prompts.create_quiz.body",
        defaultMessage: "Draft instructions for assignments"
    },
    create_quiz_prompt: {
        id: "curated-starter-prompts.create_quiz.prompt",
        defaultMessage: "Help me write clear, student-facing instructions for an assignment in my class on a topic (ask me to specify the topic). Include: 1) Step-by-step directions for what students need to do 2) A short summary of how it will be graded (criteria or rubric overview) 3) A clear due date format 4) Any formatting or submission requirements. Use friendly, concise language that students will easily understand. If you already know my grade level, subject, or class details, use that — otherwise, just ask me to confirm what you need."
    },
    design_activity_title: {
        id: "curated-starter-prompts.design_activity.title",
        defaultMessage: "Design an activity"
    },
    design_activity_body: {
        id: "curated-starter-prompts.design_activity.body",
        defaultMessage: "Design a first-week activity"
    },
    design_activity_prompt: {
        id: "curated-starter-prompts.design_activity.prompt",
        defaultMessage: "Design a first-week classroom community-building activity for my class that helps students get to know each other and teaches basic routines. Provide: a catchy activity name, a brief script I can use to introduce it, step-by-step directions, estimated time, and any printable or question prompts I could put on a handout or slide.If you already know my grade level, subject, or class details, use that — otherwise, just ask me to confirm what you need."
    },
    create_worksheet_title: {
        id: "curated-starter-prompts.create_worksheet.title",
        defaultMessage: "Create a worksheet"
    },
    create_worksheet_body: {
        id: "curated-starter-prompts.create_worksheet.body",
        defaultMessage: "Brainstorm unique worksheet ideas"
    },
    create_worksheet_prompt: {
        id: "curated-starter-prompts.create_worksheet.prompt",
        defaultMessage: "Brainstorm 8 to 10 creative worksheet ideas to help my students practice on a topic (ask me to specify the topic). For each idea, briefly describe the activity format (e.g., puzzle, matching, error correction, mini-scenarios) and what skills it targets, so I can quickly turn them into printable worksheets. If you already know my grade level, subject, or class details, use that — otherwise, just ask me to confirm what you need."
    },
    create_slide_deck_title: {
        id: "curated-starter-prompts.create_slide_deck.title",
        defaultMessage: "Create a slide"
    },
    create_slide_deck_body: {
        id: "curated-starter-prompts.create_slide_deck.body",
        defaultMessage: "Create a slide for your lesson"
    },
    create_slide_deck_prompt: {
        id: "curated-starter-prompts.create_slide_deck.prompt",
        defaultMessage: "Outline a slide-by-slide presentation. Ask me to specify the topic. For each slide, specify: the title, bullet-point content, any visuals or diagrams I should include, and 1 to 2 questions I can ask students. Aim for about 6 slides and keep the language accessible for this grade level. If you already know my grade level, subject, or class details, use that — otherwise, just ask me to confirm what you need."
    },
    create_resource_title: {
        id: "curated-starter-prompts.create_resource.title",
        defaultMessage: "Create reading materials"
    },
    create_resource_body: {
        id: "curated-starter-prompts.create_resource.body",
        defaultMessage: "Write an article about"
    },
    create_resource_prompt: {
        id: "curated-starter-prompts.create_resource.prompt",
        defaultMessage: "Write a 600-word informational article about a topic (ask me to specify the topic). Use clear headings, bold 6 to 8 key vocabulary words with simple definitions in parentheses, and end with 4 comprehension questions (2 literal, 2 inferential) plus 2 discussion questions. If you already know my grade level, subject, or class details, use that — otherwise, just ask me to confirm what you need to complete this!"
    },
    make_topic_more_engaging_title: {
        id: "curated-starter-prompts.make_topic_more_engaging.title",
        defaultMessage: "Make a topic more engaging"
    },
    make_topic_more_engaging_body: {
        id: "curated-starter-prompts.make_topic_more_engaging.body",
        defaultMessage: "Make a topic more engaging"
    },
    make_topic_more_engaging_prompt: {
        id: "curated-starter-prompts.make_topic_more_engaging.prompt",
        defaultMessage: "Help me make a topic more engaging for my students. Ask me to specify the topic. Suggest: 1 strong analogy or metaphor, 1 quick demo or hands-on activity, 1 short story or scenario I could tell, and 1 game or interactive activity—each with simple, concrete steps I can use in class. If you already know my grade level, subject, or class details, use that — otherwise, just ask me to confirm what you need"
    },
    image_gen_prompt_title: {
        id: "curated-starter-prompts.image_gen_prompt.title",
        defaultMessage: "Generate an image"
    },
    image_gen_prompt_body: {
        id: "curated-starter-prompts.image_gen_prompt.body",
        defaultMessage: "Generate an image to help teach a topic"
    },
    image_gen_prompt_prompt: {
        id: "curated-starter-prompts.image_gen_prompt.prompt",
        defaultMessage: "Generate a simple, colorful visual of a topic for my class. Ask me to specify the topic. Use a familiar metaphor or example (e.g., pizza slices, building blocks, animals). If you already know my grade level, subject, or class details, use that — otherwise, just ask me to confirm what you need."
    },
    create_learning_objectives_title: {
        id: "curated-starter-prompts.create_learning_objectives.title",
        defaultMessage: "Create learning objectives"
    },
    create_learning_objectives_body: {
        id: "curated-starter-prompts.create_learning_objectives.body",
        defaultMessage: "Create learning objectives"
    },
    create_learning_objectives_prompt: {
        id: "curated-starter-prompts.create_learning_objectives.prompt",
        defaultMessage: "Draft 5 to 8 clear, student-friendly learning objectives for my next unit on a topic (ask me to specify the topic). Organize them from foundational to advanced, and include the relevant standard code next to each one. Use any information you already know about my grade level, subject, or teaching context — if anything's missing, just ask me to confirm it. Ask me to upload curriculum or standards document, it is optional but will help align everything accurately."
    },
    plan_project_activity_title: {
        id: "curated-starter-prompts.plan_project_activity.title",
        defaultMessage: "Plan a project activity"
    },
    plan_project_activity_body: {
        id: "curated-starter-prompts.plan_project_activity.body",
        defaultMessage: "Plan a project-based activity"
    },
    plan_project_activity_prompt: {
        id: "curated-starter-prompts.plan_project_activity.prompt",
        defaultMessage: "Design a project-based learning activity on a topic (ask me to specify the topic) for my students. Include: 1) an engaging project overview 2) driving question 3) step-by-step timeline (with checkpoints) 4) suggested group roles 5) a simple rubric outline with 3 to 4 criteria (e.g., content understanding, collaboration, creativity, presentation). If you already know my grade level, subject, or class details, use that — otherwise, just ask me to confirm what you need."
    }
});

function np() {
    const t = Gt();
    return [{
        type: Xe.Starter,
        id: "morning_routine",
        title: t.formatMessage(O.morning_routine_title),
        body: t.formatMessage(O.morning_routine_body),
        prompt: t.formatMessage(O.morning_routine_prompt),
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-sun-xl@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/64/wc-icon-sun-sm@2x.png",
        accentColor: "#F9C00D",
        isFeatured: !0,
        source: "CURATED"
    }, {
        type: Xe.Starter,
        id: "be_my_personal_trainer",
        title: t.formatMessage(O.personal_trainer_title),
        body: t.formatMessage(O.personal_trainer_body),
        prompt: t.formatMessage(O.personal_trainer_prompt),
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-fitness-xl@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/64/wc-icon-fitness-sm@2x.png",
        accentColor: "#000000",
        isFeatured: !0,
        source: "CURATED"
    }, {
        type: Xe.Starter,
        id: "fix_procrastination",
        title: t.formatMessage(O.fix_procrastination_title),
        body: t.formatMessage(O.fix_procrastination_body),
        prompt: t.formatMessage(O.fix_procrastination_prompt),
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-bulb-xl@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/64/wc-icon-bulb-sm@2x.png",
        accentColor: "#F9C00D",
        isFeatured: !0,
        source: "CURATED"
    }, {
        type: Xe.Starter,
        id: "upgrade_skin_care",
        title: t.formatMessage(O.upgrade_skin_care_title),
        body: t.formatMessage(O.upgrade_skin_care_body),
        prompt: t.formatMessage(O.upgrade_skin_care_prompt),
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-skincare-xl@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/64/wc-icon-skincare-sm@2x.png",
        accentColor: "#F3A38C",
        requires_file_upload: !0,
        isFeatured: !0,
        source: "CURATED"
    }, {
        type: Xe.Starter,
        id: "meal_prep",
        title: t.formatMessage(O.meal_prep_title),
        body: t.formatMessage(O.meal_prep_body),
        prompt: t.formatMessage(O.meal_prep_prompt),
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-food@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/40/wc-icon-food-40@2x.png",
        accentColor: "#E66E04",
        isFeatured: !0,
        source: "CURATED"
    }, {
        type: Xe.Starter,
        id: "budget",
        title: t.formatMessage(O.budget_title),
        body: t.formatMessage(O.budget_body),
        prompt: t.formatMessage(O.budget_prompt),
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-preadsheet@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/40/wc-icon-preadsheet-40@2x.png",
        accentColor: "#F8907F",
        source: "CURATED"
    }, {
        type: Xe.Starter,
        id: "color_theory",
        title: t.formatMessage(O.color_theory_title),
        body: t.formatMessage(O.color_theory_body),
        prompt: t.formatMessage(O.color_theory_prompt),
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-color-xl@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/64/wc-icon-color-sm@2x.png",
        accentColor: "#EABD7E",
        requires_file_upload: !0,
        source: "CURATED"
    }, {
        type: Xe.Starter,
        id: "help_me_get_recognized",
        title: t.formatMessage(O.help_me_get_recognized_title),
        body: t.formatMessage(O.help_me_get_recognized_body),
        prompt: t.formatMessage(O.help_me_get_recognized_prompt),
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-award@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/40/wc-icon-award-40@2x.png",
        source: "CURATED"
    }, {
        type: Xe.Starter,
        id: "anime_style_portrait",
        title: t.formatMessage(O.anime_style_portrait_title),
        body: t.formatMessage(O.anime_style_portrait_body),
        prompt: t.formatMessage(O.anime_style_portrait_prompt),
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-anime@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/40/wc-icon-anime-40@2x.png",
        coverImageUrl: "https://persistent.oaistatic.com/chatgpt/trending/image-gen/anime@2x.png",
        coverThumbnailImageUrl: "https://persistent.oaistatic.com/chatgpt/trending/image-gen/anime.png",
        requires_file_upload: !0,
        systemHints: [ue.PictureV2],
        source: "CURATED"
    }, {
        type: Xe.Starter,
        id: "action_figure_portrait",
        title: t.formatMessage(O.action_figure_portrait_title),
        body: t.formatMessage(O.action_figure_portrait_body),
        prompt: t.formatMessage(O.action_figure_portrait_prompt),
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-actionfigure@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/40/wc-icon-actionfigure-40@2x.png",
        coverImageUrl: "https://persistent.oaistatic.com/chatgpt/trending/image-gen/action-figure@2x.png",
        coverThumbnailImageUrl: "https://persistent.oaistatic.com/chatgpt/trending/image-gen/action-figure.png",
        requires_file_upload: !0,
        systemHints: [ue.PictureV2],
        source: "CURATED"
    }, {
        type: Xe.Starter,
        id: "b_w_raindrop_portrait",
        title: t.formatMessage(O.b_w_raindrop_portrait_title),
        body: t.formatMessage(O.b_w_raindrop_portrait_body),
        prompt: t.formatMessage(O.b_w_raindrop_portrait_prompt),
        coverImageUrl: "https://persistent.oaistatic.com/chatgpt/trending/image-gen/raindrop-bnw@2x.png",
        coverThumbnailImageUrl: "https://persistent.oaistatic.com/chatgpt/trending/image-gen/raindrop-bnw.png",
        requires_file_upload: !0,
        source: "CURATED"
    }, {
        type: Xe.Starter,
        id: "b_w_studio_portrait",
        title: t.formatMessage(O.b_w_studio_portrait_title),
        body: t.formatMessage(O.b_w_studio_portrait_body),
        prompt: t.formatMessage(O.b_w_studio_portrait_prompt),
        coverImageUrl: "https://persistent.oaistatic.com/chatgpt/trending/image-gen/studio-bnw@2x.png",
        coverThumbnailImageUrl: "https://persistent.oaistatic.com/chatgpt/trending/image-gen/studio-bnw.png",
        requires_file_upload: !0,
        source: "CURATED"
    }, {
        type: Xe.Starter,
        id: "create_a_puppet",
        title: t.formatMessage(O.create_a_puppet_title),
        body: t.formatMessage(O.create_a_puppet_body),
        prompt: t.formatMessage(O.create_a_puppet_prompt),
        coverImageUrl: "https://persistent.oaistatic.com/chatgpt/trending/image-gen/create-puppet@2x.png",
        coverThumbnailImageUrl: "https://persistent.oaistatic.com/chatgpt/trending/image-gen/create-puppet.png",
        requires_file_upload: !0,
        systemHints: [ue.PictureV2],
        source: "CURATED"
    }, {
        type: Xe.Starter,
        id: "document_summary",
        title: t.formatMessage(O.document_summary_title),
        body: t.formatMessage(O.document_summary_body),
        prompt: t.formatMessage(O.document_summary_prompt),
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-paper-pen@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/40/wc-icon-paper-pen-40@2x.png",
        requires_file_upload: !0,
        source: "CURATED"
    }, {
        type: Xe.Starter,
        id: "recommend_a_movie",
        title: t.formatMessage(O.recommend_a_movie_title),
        body: t.formatMessage(O.recommend_a_movie_body),
        prompt: t.formatMessage(O.recommend_a_movie_prompt),
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-movies@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/40/wc-icon-movies-40@2x.png",
        source: "CURATED"
    }, {
        type: Xe.Starter,
        id: "create_a_quiz",
        title: t.formatMessage(O.create_a_quiz_title),
        body: t.formatMessage(O.create_a_quiz_body),
        prompt: t.formatMessage(O.create_a_quiz_prompt),
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-pencil-paper@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/40/wc-icon-pencil-paper-40@2x.png",
        requires_file_upload: !0,
        source: "CURATED"
    }, {
        type: Xe.Starter,
        id: "promo_code",
        title: t.formatMessage(O.promo_code_title),
        body: t.formatMessage(O.promo_code_body),
        prompt: t.formatMessage(O.promo_code_prompt),
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-pencil-paper@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/40/wc-icon-pencil-paper-40@2x.png",
        source: "CURATED"
    }]
}

function R2() {
    "use forget";
    const t = Et.c(123),
        e = Gt();
    let o;
    t[0] !== e ? (o = e.formatMessage(O.tailor_lesson_plan_title), t[0] = e, t[1] = o) : o = t[1];
    let a;
    t[2] !== e ? (a = e.formatMessage(O.tailor_lesson_plan_body), t[2] = e, t[3] = a) : a = t[3];
    let l;
    t[4] !== e ? (l = e.formatMessage(O.tailor_lesson_plan_prompt), t[4] = e, t[5] = l) : l = t[5];
    let i;
    t[6] !== o || t[7] !== a || t[8] !== l ? (i = {
        type: Xe.Starter,
        id: "tailor_lesson_plan",
        title: o,
        body: a,
        prompt: l,
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-bulb-xl@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/64/wc-icon-bulb-sm@2x.png",
        accentColor: "#F9C00D",
        source: "CURATED"
    }, t[6] = o, t[7] = a, t[8] = l, t[9] = i) : i = t[9];
    let d;
    t[10] !== e ? (d = e.formatMessage(O.questions_on_different_levels_title), t[10] = e, t[11] = d) : d = t[11];
    let b;
    t[12] !== e ? (b = e.formatMessage(O.questions_on_different_levels_body), t[12] = e, t[13] = b) : b = t[13];
    let s;
    t[14] !== e ? (s = e.formatMessage(O.questions_on_different_levels_prompt), t[14] = e, t[15] = s) : s = t[15];
    let m;
    t[16] !== d || t[17] !== b || t[18] !== s ? (m = {
        type: Xe.Starter,
        id: "questions_on_different_levels",
        title: d,
        body: b,
        prompt: s,
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-pencil-paper@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/40/wc-icon-pencil-paper-40@2x.png",
        accentColor: "#F9C00D",
        source: "CURATED"
    }, t[16] = d, t[17] = b, t[18] = s, t[19] = m) : m = t[19];
    let x;
    t[20] !== e ? (x = e.formatMessage(O.create_quiz_title), t[20] = e, t[21] = x) : x = t[21];
    let C;
    t[22] !== e ? (C = e.formatMessage(O.create_quiz_body), t[22] = e, t[23] = C) : C = t[23];
    let u;
    t[24] !== e ? (u = e.formatMessage(O.create_quiz_prompt), t[24] = e, t[25] = u) : u = t[25];
    let c;
    t[26] !== u || t[27] !== x || t[28] !== C ? (c = {
        type: Xe.Starter,
        id: "create_quiz_k12",
        title: x,
        body: C,
        prompt: u,
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-pencil-paper@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/40/wc-icon-pencil-paper-40@2x.png",
        accentColor: "#F9C00D",
        source: "CURATED"
    }, t[26] = u, t[27] = x, t[28] = C, t[29] = c) : c = t[29];
    let g;
    t[30] !== e ? (g = e.formatMessage(O.design_activity_title), t[30] = e, t[31] = g) : g = t[31];
    let y;
    t[32] !== e ? (y = e.formatMessage(O.design_activity_body), t[32] = e, t[33] = y) : y = t[33];
    let S;
    t[34] !== e ? (S = e.formatMessage(O.design_activity_prompt), t[34] = e, t[35] = S) : S = t[35];
    let v;
    t[36] !== g || t[37] !== y || t[38] !== S ? (v = {
        type: Xe.Starter,
        id: "design_activity",
        title: g,
        body: y,
        prompt: S,
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-color-xl@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/64/wc-icon-color-sm@2x.png",
        accentColor: "#F9C00D",
        source: "CURATED"
    }, t[36] = g, t[37] = y, t[38] = S, t[39] = v) : v = t[39];
    let j;
    t[40] !== e ? (j = e.formatMessage(O.create_worksheet_title), t[40] = e, t[41] = j) : j = t[41];
    let M;
    t[42] !== e ? (M = e.formatMessage(O.create_worksheet_body), t[42] = e, t[43] = M) : M = t[43];
    let h;
    t[44] !== e ? (h = e.formatMessage(O.create_worksheet_prompt), t[44] = e, t[45] = h) : h = t[45];
    let w;
    t[46] !== j || t[47] !== M || t[48] !== h ? (w = {
        type: Xe.Starter,
        id: "create_worksheet",
        title: j,
        body: M,
        prompt: h,
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-preadsheet@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/40/wc-icon-preadsheet-40@2x.png",
        accentColor: "#F9C00D",
        source: "CURATED"
    }, t[46] = j, t[47] = M, t[48] = h, t[49] = w) : w = t[49];
    let P;
    t[50] !== e ? (P = e.formatMessage(O.create_resource_title), t[50] = e, t[51] = P) : P = t[51];
    let R;
    t[52] !== e ? (R = e.formatMessage(O.create_resource_body), t[52] = e, t[53] = R) : R = t[53];
    let D;
    t[54] !== e ? (D = e.formatMessage(O.create_resource_prompt), t[54] = e, t[55] = D) : D = t[55];
    let E;
    t[56] !== P || t[57] !== R || t[58] !== D ? (E = {
        type: Xe.Starter,
        id: "create_resource",
        title: P,
        body: R,
        prompt: D,
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-bulb-xl@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/64/wc-icon-bulb-sm@2x.png",
        accentColor: "#F9C00D",
        source: "CURATED"
    }, t[56] = P, t[57] = R, t[58] = D, t[59] = E) : E = t[59];
    let A;
    t[60] !== e ? (A = e.formatMessage(O.create_slide_deck_title), t[60] = e, t[61] = A) : A = t[61];
    let G;
    t[62] !== e ? (G = e.formatMessage(O.create_slide_deck_body), t[62] = e, t[63] = G) : G = t[63];
    let k;
    t[64] !== e ? (k = e.formatMessage(O.create_slide_deck_prompt), t[64] = e, t[65] = k) : k = t[65];
    let N;
    t[66] !== A || t[67] !== G || t[68] !== k ? (N = {
        type: Xe.Starter,
        id: "create_slide_deck",
        title: A,
        body: G,
        prompt: k,
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-bulb-xl@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/64/wc-icon-bulb-sm@2x.png",
        accentColor: "#F9C00D",
        source: "CURATED"
    }, t[66] = A, t[67] = G, t[68] = k, t[69] = N) : N = t[69];
    let q;
    t[70] !== e ? (q = e.formatMessage(O.make_topic_more_engaging_title), t[70] = e, t[71] = q) : q = t[71];
    let V;
    t[72] !== e ? (V = e.formatMessage(O.make_topic_more_engaging_body), t[72] = e, t[73] = V) : V = t[73];
    let re;
    t[74] !== e ? (re = e.formatMessage(O.make_topic_more_engaging_prompt), t[74] = e, t[75] = re) : re = t[75];
    let K;
    t[76] !== q || t[77] !== V || t[78] !== re ? (K = {
        type: Xe.Starter,
        id: "make_topic_more_engaging",
        title: q,
        body: V,
        prompt: re,
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-sun-xl@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/64/wc-icon-sun-sm@2x.png",
        accentColor: "#F9C00D",
        source: "CURATED"
    }, t[76] = q, t[77] = V, t[78] = re, t[79] = K) : K = t[79];
    let I;
    t[80] !== e ? (I = e.formatMessage(O.image_gen_prompt_title), t[80] = e, t[81] = I) : I = t[81];
    let r;
    t[82] !== e ? (r = e.formatMessage(O.image_gen_prompt_body), t[82] = e, t[83] = r) : r = t[83];
    let oe;
    t[84] !== e ? (oe = e.formatMessage(O.image_gen_prompt_prompt), t[84] = e, t[85] = oe) : oe = t[85];
    let T;
    t[86] === Symbol.for("react.memo_cache_sentinel") ? (T = [ue.PictureV2], t[86] = T) : T = t[86];
    let ge;
    t[87] !== I || t[88] !== r || t[89] !== oe ? (ge = {
        type: Xe.Starter,
        id: "image_gen_prompt",
        title: I,
        body: r,
        prompt: oe,
        category: "dalle",
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-painting.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/40/wc-icon-painting-sm.png",
        accentColor: "#F9C00D",
        systemHints: T,
        source: "CURATED"
    }, t[87] = I, t[88] = r, t[89] = oe, t[90] = ge) : ge = t[90];
    let Ce;
    t[91] !== e ? (Ce = e.formatMessage(O.plan_project_activity_title), t[91] = e, t[92] = Ce) : Ce = t[92];
    let X;
    t[93] !== e ? (X = e.formatMessage(O.plan_project_activity_body), t[93] = e, t[94] = X) : X = t[94];
    let B;
    t[95] !== e ? (B = e.formatMessage(O.plan_project_activity_prompt), t[95] = e, t[96] = B) : B = t[96];
    let Z;
    t[97] !== Ce || t[98] !== X || t[99] !== B ? (Z = {
        type: Xe.Starter,
        id: "plan_project_activity",
        title: Ce,
        body: X,
        prompt: B,
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-paper-pen@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/40/wc-icon-paper-pen-40@2x.png",
        accentColor: "#F9C00D",
        source: "CURATED"
    }, t[97] = Ce, t[98] = X, t[99] = B, t[100] = Z) : Z = t[100];
    let L;
    t[101] !== e ? (L = e.formatMessage(O.create_learning_objectives_title), t[101] = e, t[102] = L) : L = t[102];
    let p;
    t[103] !== e ? (p = e.formatMessage(O.create_learning_objectives_body), t[103] = e, t[104] = p) : p = t[104];
    let se;
    t[105] !== e ? (se = e.formatMessage(O.create_learning_objectives_prompt), t[105] = e, t[106] = se) : se = t[106];
    let Me;
    t[107] !== L || t[108] !== p || t[109] !== se ? (Me = {
        type: Xe.Starter,
        id: "create_learning_objectives",
        title: L,
        body: p,
        prompt: se,
        iconImageUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/228/wc-icon-checklist@2x.png",
        iconThumbnailUrl: "https://persistent.oaistatic.com/chatgpt/icons/wc-icons/40/wc-icon-checklist-40@2x.png",
        accentColor: "#F9C00D",
        source: "CURATED",
        requires_file_upload: !0
    }, t[107] = L, t[108] = p, t[109] = se, t[110] = Me) : Me = t[110];
    let Be;
    return t[111] !== c || t[112] !== v || t[113] !== w || t[114] !== E || t[115] !== N || t[116] !== i || t[117] !== K || t[118] !== ge || t[119] !== Z || t[120] !== Me || t[121] !== m ? (Be = [i, m, c, v, w, E, N, K, ge, Z, Me], t[111] = c, t[112] = v, t[113] = w, t[114] = E, t[115] = N, t[116] = i, t[117] = K, t[118] = ge, t[119] = Z, t[120] = Me, t[121] = m, t[122] = Be) : Be = t[122], Be
}

function B2(t, e = [], o = 4, a = 2) {
    if (!t || t.length === 0) return [];
    const l = c => c.category === "dalle" || !!c.coverImageUrl,
        i = (c, g) => c.id != null && g.id != null ? c.id === g.id : c === g,
        d = (c, g) => e.some(y => g && !g(y) ? !1 : i(y, c)),
        b = t.filter(c => c.category === "dalle" && !d(c, l));
    let s = b.length > 0 ? b[Math.floor(Math.random() * b.length)] : void 0;
    if (!s) {
        const c = t.filter(g => !!g.coverImageUrl).filter(g => !d(g, l));
        s = c.length > 0 ? c[Math.floor(Math.random() * c.length)] : void 0
    }
    const x = [...t.filter(c => !(c === s || l(c) || d(c, g => !l(g))))].sort(() => Math.random() - .5);
    if (s) {
        const c = Math.max(0, o - 1),
            g = [],
            y = new Set;
        for (const j of x) {
            const M = j.iconImageUrl;
            if (!y.has(M) && (y.add(M), g.push(j), g.length === c)) break
        }
        if (g.length < c) {
            for (const j of x)
                if (!g.includes(j) && (g.push(j), g.length === c)) break
        }
        const S = [...g],
            v = Math.min(Math.max(a, 0), Math.max(o - 1, 0));
        return S.splice(v, 0, s), S.slice(0, o)
    }
    const C = [],
        u = new Set;
    for (const c of x) {
        const g = c.iconImageUrl;
        if (!u.has(g) && (u.add(g), C.push(c), C.length === o)) break
    }
    if (C.length < o) {
        for (const c of x)
            if (!C.includes(c) && (C.push(c), C.length === o)) break
    }
    return C.slice(0, o)
}
const N2 = eo({
    subtitle: {
        id: "starter-prompt-banner.subtitle",
        defaultMessage: "Just add a picture — ChatGPT will do the rest. <tryNow>Try now</tryNow>"
    }
});

function D2() {
    "use forget";
    const [t] = Ac("oai/apps/hasDismissedStarterPromptBanner", !1, L2);
    return !t
}

function L2(t) {
    return typeof t == "boolean"
}

function U2(t) {
    "use forget";
    var oe;
    const e = Et.c(35),
        {
            className: o
        } = t,
        a = Ru(),
        l = Cg(),
        [i, d] = Ac("oai/apps/hasDismissedStarterPromptBanner", !1, z2),
        b = np(),
        s = kg(),
        m = Ke(),
        u = Bu(m, !1).get("image_gen_prompts_type", "evergreen") === "trending" ? s : b;
    let c;
    e[0] !== u ? (c = u.filter(F2), e[0] = u, e[1] = c) : c = e[1];
    const g = c,
        y = g[Math.floor(Math.random() * g.length)];
    let S, v;
    e[2] !== y ? (S = () => {
        var T;
        y && Ze.logEventWithStatsig("Show Image Gen Prompt", "chatgpt_prompt_show_suggestion", {
            type: y.type,
            id: y.id,
            index: 0,
            theme: (T = y.theme) != null ? T : ""
        })
    }, v = [y], e[2] = y, e[3] = S, e[4] = v) : (S = e[3], v = e[4]), F.useEffect(S, v);
    const j = ko();
    if (!y) return null;
    let M;
    e[5] !== y ? (M = [y], e[5] = y, e[6] = M) : M = e[6];
    const h = M,
        w = j,
        P = y.title,
        R = (oe = y.coverImageUrl) != null ? oe : y.coverThumbnailImageUrl;
    let D;
    e[7] !== h || e[8] !== a || e[9] !== w || e[10] !== l || e[11] !== y ? (D = T => {
        var Ce;
        if (w) {
            T.preventDefault();
            return
        }
        if (T.stopPropagation(), y.requires_file_upload === !0 && ((Ce = y.systemHints) == null ? void 0 : Ce.includes(ue.PictureV2))) {
            l(T, y, h, 0);
            return
        }
        a(T, y, h, 0)
    }, e[7] = h, e[8] = a, e[9] = w, e[10] = l, e[11] = y, e[12] = D) : D = e[12];
    const E = D;
    if (i) return null;
    let A;
    e[13] !== o ? (A = Ct("relative", o), e[13] = o, e[14] = A) : A = e[14];
    const G = w ? "opacity-60" : "";
    let k;
    e[15] !== G ? (k = Ct("border-token-border-default bg-tertiary flex w-full items-center gap-3 rounded-2xl border shadow-[0px_4px_16px_0px_rgba(0,0,0,0.05)]", G), e[15] = G, e[16] = k) : k = e[16];
    let N;
    e[17] !== R ? (N = R ? n.jsx("div", {
        className: "py-3 ps-3",
        children: n.jsx("div", {
            className: "border-token-border-default borde h-14 w-14 -rotate-2 overflow-hidden rounded-xl p-0.5 shadow-lg",
            children: n.jsx("img", {
                src: R,
                alt: "",
                "aria-hidden": "true",
                className: "h-full w-full rounded-lg object-cover"
            })
        })
    }) : null, e[17] = R, e[18] = N) : N = e[18];
    let q;
    e[19] !== P ? (q = n.jsx("div", {
        className: "text-token-text-primary truncate text-sm leading-5 font-medium sm:text-base",
        children: P
    }), e[19] = P, e[20] = q) : q = e[20];
    let V;
    e[21] === Symbol.for("react.memo_cache_sentinel") ? (V = n.jsx("div", {
        className: "text-token-text-secondary mt-1 text-xs leading-5 sm:text-sm",
        children: n.jsx(Ls, Bs(Rt({}, N2.subtitle), {
            values: {
                tryNow: O2
            }
        }))
    }), e[21] = V) : V = e[21];
    let re;
    e[22] !== q ? (re = n.jsxs("div", {
        className: "min-w-0 flex-1 py-3 text-start",
        children: [q, V]
    }), e[22] = q, e[23] = re) : re = e[23];
    let K;
    e[24] !== d ? (K = n.jsx(Dp, {
        className: "me-1 mt-1 self-start",
        iconSize: "md",
        onClick: T => {
            T.stopPropagation(), d(!0)
        }
    }), e[24] = d, e[25] = K) : K = e[25];
    let I;
    e[26] !== E || e[27] !== re || e[28] !== K || e[29] !== k || e[30] !== N ? (I = n.jsxs("div", {
        role: "button",
        tabIndex: 0,
        className: k,
        onClick: E,
        children: [N, re, K]
    }), e[26] = E, e[27] = re, e[28] = K, e[29] = k, e[30] = N, e[31] = I) : I = e[31];
    let r;
    return e[32] !== I || e[33] !== A ? (r = n.jsx("div", {
        className: A,
        children: I
    }), e[32] = I, e[33] = A, e[34] = r) : r = e[34], r
}

function O2(t) {
    return n.jsx("span", {
        className: "inline-flex items-center gap-1 text-xs font-medium text-blue-500 sm:text-sm dark:text-blue-400",
        children: n.jsx("span", {
            children: t
        })
    })
}

function F2(t) {
    var e;
    return (e = t.systemHints) == null ? void 0 : e.includes(ue.PictureV2)
}

function z2(t) {
    return typeof t == "boolean"
}
const H2 = Ts(() => vs(() =>
        import ("./k7bax4ffse9ora8u.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8])).then(t => t.default)),
    Kd = eo({
        bannerBody: {
            id: "gqtTeH",
            defaultMessage: "Work smarter and better with coworkers in your organization"
        },
        dismissBanner: {
            id: "hbc/Bs",
            defaultMessage: "Dismiss banner"
        }
    });

function G2(t) {
    "use forget";
    const e = Et.c(17),
        {
            clientThreadId: o,
            canShowBanner: a
        } = t,
        l = a === void 0 ? !1 : a,
        i = Ke();
    let d;
    e[0] !== i ? (d = Zs(), e[0] = i, e[1] = d) : d = e[1];
    const b = d;
    let s;
    e[2] !== o ? (s = Zd(o), e[2] = o, e[3] = s) : s = e[3];
    const m = s,
        x = Ht(o, V2),
        {
            eligible: C
        } = bo(en.hasSeenJoinWorkspaceBanner),
        u = m && !x,
        c = Ic(),
        g = (c == null ? void 0 : c.email_domain_type) === "professional",
        y = b && g && l && u && m && !x && C,
        {
            data: S,
            isLoading: v
        } = Lp();
    let j;
    e[4] !== (S == null ? void 0 : S.accountItems) ? (j = S == null ? void 0 : S.accountItems.some($2), e[4] = S == null ? void 0 : S.accountItems, e[5] = j) : j = e[5];
    const M = !!j;
    let h;
    e[6] !== i ? (h = Us(i, "3217430380", {
        disableExposureLog: !0
    }).get("enable_workspace_discovery", !1), e[6] = i, e[7] = h) : h = e[7];
    const P = !v && !M && h && y;
    let R;
    if (e[8] !== i) {
        const T = wr.getItem(Cr.WorkspaceDiscoveryInfo),
            ge = eu(i, "2801792036").get("cache_ttl_ms", 6048e5);
        R = Mg(T, ge), e[8] = i, e[9] = R
    } else R = e[9];
    const {
        isFresh: D,
        hasWorkspacesToJoin: E
    } = R;
    let A;
    e[10] !== i ? (A = Lt(i, "69563813"), e[10] = i, e[11] = A) : A = e[11];
    const k = !D && A && P,
        {
            data: N,
            isFetching: q
        } = vg(k),
        V = N == null ? void 0 : N.workspaces.some(W2);
    if (!(!q && (D ? !!E : !!V) && P)) {
        let T;
        return e[12] === Symbol.for("react.memo_cache_sentinel") ? (T = {
            shouldShow: !1
        }, e[12] = T) : T = e[12], T
    }
    let I;
    e[13] !== i ? (I = Us(i, "1200251816").get("enable-join-workspaces-banner", !1), e[13] = i, e[14] = I) : I = e[14];
    const r = I;
    let oe;
    return e[15] !== r ? (oe = {
        shouldShow: r
    }, e[15] = r, e[16] = oe) : oe = e[16], oe
}

function W2(t) {
    return !t.requested
}

function $2(t) {
    return t.isEnterprisey()
}

function V2(t) {
    return wt.hasUserMessage(t)
}

function C3() {
    "use forget";
    const t = Et.c(24),
        e = Ke();
    let o;
    t[0] !== e ? (o = () => {
        Gc(e, en.hasSeenJoinWorkspaceBanner)
    }, t[0] = e, t[1] = o) : o = t[1];
    const a = o;
    let l;
    t[2] !== a ? (l = () => {
        Ze.logEventWithStatsig("Thread Join Workspace Banner Button Dismissed", "chatgpt_thread_join_workspace_banner_button_dismissed"), a()
    }, t[2] = a, t[3] = l) : l = t[3];
    const i = l;
    let d;
    t[4] === Symbol.for("react.memo_cache_sentinel") ? (d = [], t[4] = d) : d = t[4], F.useEffect(q2, d);
    let b;
    t[5] !== e || t[6] !== a ? (b = () => {
        Ze.logEventWithStatsig("Thread Join Workspace Banner Button Clicked", "chatgpt_thread_join_workspace_banner_button_clicked"), a(), Zn(e, H2, {
            mode: "dismissible",
            section: "both",
            source: "join_workspace_banner"
        })
    }, t[5] = e, t[6] = a, t[7] = b) : b = t[7];
    const s = b;
    let m;
    t[8] === Symbol.for("react.memo_cache_sentinel") ? (m = Ct("group flex w-full items-center justify-center gap-1.5 rounded-full py-2 ps-3 sm:justify-start sm:gap-2", "bg-primary shadow-short", "hover:bg-token-surface-hover motion-safe:transition-colors motion-safe:duration-150 motion-safe:ease-out", "focus-visible:ring-token-text-tertiary focus-visible:ring-2 focus-visible:ring-offset-1 focus-visible:ring-offset-transparent focus-visible:outline-hidden", "pe-7"), t[8] = m) : m = t[8];
    let x;
    t[9] === Symbol.for("react.memo_cache_sentinel") ? (x = n.jsx("span", {
        className: "hidden text-[#5856D6] sm:inline",
        children: n.jsx(Tg, {
            className: "icon-sm",
            "aria-hidden": "true"
        })
    }), t[9] = x) : x = t[9];
    let C, u;
    t[10] === Symbol.for("react.memo_cache_sentinel") ? (C = n.jsxs("span", {
        className: "flex items-center gap-1.5",
        children: [x, n.jsx("span", {
            className: "text-token-text-primary text-[13px] leading-[18px] sm:text-sm sm:leading-5",
            children: n.jsx(Ls, Rt({}, Kd.bannerBody))
        })]
    }), u = n.jsx("span", {
        className: Ct("inline-flex items-center gap-1 text-sm font-medium", "text-[#5856D6]"),
        children: n.jsx("span", {
            children: n.jsx(Ls, {
                id: "V/M/bo",
                defaultMessage: "Find Workspaces"
            })
        })
    }), t[10] = C, t[11] = u) : (C = t[10], u = t[11]);
    let c;
    t[12] !== s ? (c = n.jsxs("button", {
        type: "button",
        onClick: s,
        className: m,
        children: [C, u]
    }), t[12] = s, t[13] = c) : c = t[13];
    let g;
    t[14] !== i ? (g = h => {
        h.stopPropagation(), i()
    }, t[14] = i, t[15] = g) : g = t[15];
    let y, S;
    t[16] === Symbol.for("react.memo_cache_sentinel") ? (y = Ct("mt-0.15 absolute end-1.5 top-1/2 -translate-y-1/2 rounded-full p-1", "text-token-text-secondary hover:bg-token-main-surface-tertiary", "focus-visible:ring-token-text-tertiary focus-visible:ring-2 focus-visible:ring-offset-1 focus-visible:ring-offset-transparent focus-visible:outline-hidden"), S = n.jsx(Ag, {
        className: "icon-xs",
        "aria-hidden": "true"
    }), t[16] = y, t[17] = S) : (y = t[16], S = t[17]);
    let v;
    t[18] === Symbol.for("react.memo_cache_sentinel") ? (v = n.jsx("span", {
        className: "sr-only",
        children: n.jsx(Ls, Rt({}, Kd.dismissBanner))
    }), t[18] = v) : v = t[18];
    let j;
    t[19] !== g ? (j = n.jsxs("button", {
        type: "button",
        onClick: g,
        className: y,
        children: [S, v]
    }), t[19] = g, t[20] = j) : j = t[20];
    let M;
    return t[21] !== j || t[22] !== c ? (M = n.jsxs("div", {
        className: "relative",
        children: [c, j]
    }), t[21] = j, t[22] = c, t[23] = M) : M = t[23], M
}

function q2() {
    Ze.logEventWithStatsig("Thread Join Workspace Banner Button Shown", "chatgpt_thread_join_workspace_banner_button_shown")
}
const Jd = t => typeof t == "boolean";

function Qd({
    clientThreadId: t,
    onClick: e
}) {
    F.useEffect(() => {
        Ng(t)
    }, [t]);
    const o = Gt();
    return n.jsx(to.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        transition: {
            duration: .3,
            ease: "easeOut"
        },
        className: "inline-block",
        children: n.jsx(Uu, {
            onClick: () => {
                Dg(t), e()
            },
            label: o.formatMessage(yo.moreStarterPrompts)
        })
    })
}

function K2({
    starterPrompt: t,
    starterPrompts: e,
    index: o,
    disabled: a,
    onSelectStarterPrompt: l
}) {
    var m;
    const i = Ke(),
        d = (m = t.theme) != null ? m : t.title,
        b = Ru(),
        s = t.category === "onboarding" ? x => {
            Gc(i, en.hasUsedConversationalOnboardingStarterPrompt), b(x, t, e, o)
        } : x => l == null ? void 0 : l(x, t, e, o);
    return n.jsx(Uu, {
        disabled: a,
        onClick: s,
        icon: n.jsx(Gp, {
            category: t.category,
            useV2Colors: !0
        }),
        label: d
    })
}
const J2 = 5,
    Q2 = 3;

function op({
    starterPrompts: t,
    onSelectStarterPrompt: e,
    disabled: o,
    clientThreadId: a,
    onExpand: l,
    mobileLayout: i = !1
}) {
    const d = i ? Q2 : J2,
        [b, s] = F.useState(d),
        [m, x] = F.useState(!1),
        C = F.useRef(null),
        u = t.length <= b;
    F.useEffect(() => {
        vc(t.slice(0, d), a)
    }, [a]), F.useEffect(() => {
        if (!m && !u && C.current) {
            const g = C.current,
                y = g.getBoundingClientRect(),
                S = y.width,
                v = Array.from(g.children);
            let j = 0;
            for (let M = 0; M < v.length && v[M].getBoundingClientRect().right - y.left <= S; M++) j++;
            s(j), x(!0)
        }
    }, [t, u, m]);
    const c = () => {
        const g = t.slice(b, t.length).map(y => Bs(Rt({}, y), {
            isAdditional: !0
        }));
        g.length > 0 && vc(g, a), s(t.length), l()
    };
    return n.jsxs("div", {
        "data-testid": "starter-prompt-chips",
        className: Ct("mt-5 flex items-center justify-center gap-x-2 transition-opacity xl:gap-x-2.5", m && t.length > 0 ? "opacity-100" : "opacity-[0.01]", i ? "flex-wrap" : "flex-nowrap"),
        children: [n.jsxs("ul", {
            className: Ct("relative flex items-stretch gap-x-2 gap-y-4 overflow-hidden py-2 sm:gap-y-2 xl:gap-x-2.5 xl:gap-y-2.5", u || i ? "flex-wrap justify-center" : "flex-nowrap justify-start"),
            ref: C,
            children: [t.slice(0, b).map((g, y) => {
                var S;
                return n.jsx(to.li, {
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    exit: {
                        opacity: 0
                    },
                    transition: {
                        duration: .3,
                        ease: "easeOut"
                    },
                    children: n.jsx(K2, {
                        starterPrompt: g,
                        starterPrompts: t,
                        index: y,
                        disabled: o,
                        onSelectStarterPrompt: e
                    })
                }, (S = g.id) != null ? S : y)
            }), i && t.length > b && n.jsx(Qd, {
                clientThreadId: a,
                onClick: c
            })]
        }), !i && t.length > b && n.jsx(Qd, {
            clientThreadId: a,
            onClick: c
        })]
    })
}
const k3 = t => {
        "use forget";
        const e = Et.c(17),
            {
                clientThreadId: o,
                currentModelId: a
            } = t,
            [l, i] = F.useState(!1),
            d = ko();
        let b;
        e[0] !== o || e[1] !== a ? (b = {
            shouldBeEnabledForDefaultAssistant: !0,
            clientThreadId: o,
            limit: 8,
            modelSlug: a
        }, e[0] = o, e[1] = a, e[2] = b) : b = e[2];
        const {
            promptStarters: s,
            shouldShowStarterPrompts: m,
            onSelectStarterPrompt: x
        } = Wc(b);
        let C, u, c;
        e[3] === Symbol.for("react.memo_cache_sentinel") ? (C = {
            opacity: 0
        }, u = {
            opacity: 1
        }, c = {
            duration: .3
        }, e[3] = C, e[4] = u, e[5] = c) : (C = e[3], u = e[4], c = e[5]);
        const g = m && !l && "h-[116px]";
        let y;
        e[6] !== g ? (y = Ct(g), e[6] = g, e[7] = y) : y = e[7];
        let S;
        e[8] !== o || e[9] !== d || e[10] !== x || e[11] !== s || e[12] !== m ? (S = m && s && n.jsx(op, {
            starterPrompts: s,
            onSelectStarterPrompt: x,
            disabled: d,
            clientThreadId: o,
            onExpand: () => i(!0),
            mobileLayout: !0
        }), e[8] = o, e[9] = d, e[10] = x, e[11] = s, e[12] = m, e[13] = S) : S = e[13];
        let v;
        return e[14] !== y || e[15] !== S ? (v = n.jsx(to.div, {
            initial: C,
            animate: u,
            transition: c,
            className: y,
            children: S
        }), e[14] = y, e[15] = S, e[16] = v) : v = e[16], v
    },
    M3 = t => {
        "use forget";
        const e = Et.c(24),
            {
                currentModelId: o,
                clientThreadId: a
            } = t,
            l = Ke();
        let i;
        e[0] !== l ? (i = Zs(), e[0] = l, e[1] = i) : i = e[1];
        const d = !i,
            b = Rg(),
            [s, m] = F.useState(!1),
            x = ko();
        let C;
        e[2] !== a || e[3] !== o ? (C = {
            shouldBeEnabledForDefaultAssistant: !0,
            clientThreadId: a,
            limit: 8,
            modelSlug: o
        }, e[2] = a, e[3] = o, e[4] = C) : C = e[4];
        const {
            promptStarters: u,
            shouldShowStarterPrompts: c,
            onSelectStarterPrompt: g
        } = Wc(C);
        let y;
        e[5] !== a ? (y = {
            clientThreadId: a,
            canShowBanner: !0
        }, e[5] = a, e[6] = y) : y = e[6];
        const {
            shouldShow: S
        } = G2(y);
        let v;
        e[7] !== d ? (v = () => d && Bg(), e[7] = d, e[8] = v) : v = e[8];
        const j = fe(v),
            M = S || j,
            h = c && u;
        if (M && !h) return null;
        let w, P, R;
        e[9] === Symbol.for("react.memo_cache_sentinel") ? (w = {
            opacity: 0
        }, P = {
            opacity: 1
        }, R = {
            duration: .3
        }, e[9] = w, e[10] = P, e[11] = R) : (w = e[9], P = e[10], R = e[11]);
        const D = !b && "min-h-[108px]",
            E = d && s || b ? "" : "h-[70px]";
        let A;
        e[12] !== D || e[13] !== E ? (A = Ct("max-w-full max-sm:hidden", D, E), e[12] = D, e[13] = E, e[14] = A) : A = e[14];
        let G;
        e[15] !== a || e[16] !== x || e[17] !== g || e[18] !== u || e[19] !== h ? (G = h && n.jsx(op, {
            starterPrompts: u,
            onSelectStarterPrompt: g,
            disabled: x,
            clientThreadId: a,
            onExpand: () => m(!0)
        }), e[15] = a, e[16] = x, e[17] = g, e[18] = u, e[19] = h, e[20] = G) : G = e[20];
        let k;
        return e[21] !== A || e[22] !== G ? (k = n.jsx(to.div, {
            initial: w,
            animate: P,
            transition: R,
            className: A,
            children: G
        }), e[21] = A, e[22] = G, e[23] = k) : k = e[23], k
    };

function Y2({
    className: t,
    layout: e = "grid",
    hideShuffleButton: o,
    clientThreadId: a,
    currentModelId: l
}) {
    var tt;
    const i = Gt(),
        d = ko(),
        b = Ke(),
        {
            store: s
        } = Ft(),
        m = s.useSharedProps(de => de == null ? void 0 : de.openFileDialog),
        x = s.useContentAreaId(tn.HeaderTop),
        C = Mo(),
        u = tu(b);
    Up();
    let c = (tt = u == null ? void 0 : u.isK12()) != null ? tt : !1;
    Lt(b, "4233029563");
    const g = !1,
        y = g,
        S = Lt(b, "4100765009");
    c = c || S;
    const [v, j] = Ac("starter_prompt_tiles_dismissed", !1, Jd), [M, h] = F.useState(null), w = np(), P = R2(), R = y, D = Bu(zp(), !1), E = D.get("prompt_source", "library"), A = E === "features", G = Pc(), k = (c || y || D.get("personalized_prompts_enabled", !1)) && !A, {
        featureTiles: N,
        featureTileClickOverrides: q
    } = Ig({
        intl: i,
        clientThreadId: a,
        composerController: G,
        openFileDialog: m,
        shouldUseFeatureTiles: A,
        messages: yo
    });
    F.useEffect(() => {
        if (!k) {
            h(!1);
            return
        }
        typeof window > "u" || h(Op("starter_prompt_tiles_dismissed", !1, Jd))
    }, [c, k]);
    const V = c && P.length > 0 ? P : w,
        {
            promptStarters: re
        } = Wc({
            shouldBeEnabledForDefaultAssistant: !0,
            clientThreadId: a,
            limit: 12,
            modelSlug: l != null ? l : void 0,
            surface: "tiles"
        }),
        K = !c && !g && (E === "curated" || E === "personalized"),
        I = F.useMemo(() => A ? N : K ? re != null ? re : [] : V != null ? V : [], [V, N, re, A, K]),
        r = k && (v || M === !0),
        oe = k && M == null,
        T = g,
        ge = Pg(),
        Ce = Nu(a),
        X = Ir(a),
        B = Du({
            serverThreadId: X
        }),
        Z = x === W.CocoonAnnouncementBanner,
        L = !ge || Z || Ce || (B == null ? void 0 : B.ui_info.type) != null,
        p = fe(Lu(G).shouldShowAutocomplete$),
        se = e === "carousel" ? 1 : 2,
        Me = F.useCallback(() => {}, [V.length, R, e]),
        [Be, Ie] = F.useState(0),
        be = F.useRef([]),
        ve = F.useRef(!1),
        ce = F.useMemo(() => {
            if (A) return N;
            if (!I.length) return [];
            if (K && E === "personalized") {
                const Ge = Be * 4 % I.length;
                return I.slice(Ge, Ge + 4).concat(I.slice(0, Math.max(0, Ge + 4 - I.length)))
            }
            return B2(I, be.current, 4, se)
        }, [N, I, se, E, A, K, Be]);
    F.useEffect(() => {
        be.current = ce
    }, [ce]);
    const Ne = F.useCallback(() => {
        A || (Me(), Ie(de => de + 1))
    }, [A, Me]);
    if (F.useEffect(() => {
            A || ve.current || T || L || r || oe || I.length === 0 || ce.length === 0 || (ve.current = !0, vc(ce, a))
        }, [a, oe, I.length, T, r, A, ce, L]), I.length === 0 && !T || A && C != null || T || !I || I.length === 0 || r || oe || L) return null;
    const et = () => {
        Ze.logStructuredEvent(Hp, {
            layout: e != null ? e : "grid"
        }), j(!0)
    };
    return n.jsxs("div", {
        className: Ct("flex w-full flex-col transition-opacity", !A && "gap-y-2", t, p ? "pointer-events-none opacity-0" : "opacity-100"),
        children: [!A && n.jsxs("div", {
            className: "flex items-center justify-between px-1",
            children: [n.jsx("div", {
                className: "text-token-text-secondary text-base leading-7 sm:text-sm",
                children: i.formatMessage(yo.trySomethingNew)
            }), n.jsxs("div", {
                className: "flex items-center gap-1",
                children: [!o && n.jsx(bc, {
                    type: "button",
                    onClick: Ne,
                    label: i.formatMessage(yo.shuffleTiles),
                    color: "secondary",
                    size: "medium",
                    icon: Eg,
                    iconClassName: "text-token-text-secondary",
                    style: {
                        borderStyle: "none"
                    }
                }), k && n.jsx(bc, {
                    type: "button",
                    onClick: et,
                    label: i.formatMessage(yo.dismissStarterPrompts),
                    color: "secondary",
                    size: "medium",
                    icon: Fp,
                    iconClassName: "text-token-text-secondary",
                    style: {
                        borderStyle: "none"
                    }
                })]
            })]
        }), n.jsx("div", {
            "data-testid": "starter-prompt-tiles",
            className: Ct(e === "grid" ? ["grid grid-cols-2 gap-4", !A && "sm:flex sm:flex-row"] : "-mx-(--thread-content-margin) flex flex-row items-stretch gap-3 overflow-x-auto px-(--thread-content-margin) pb-4 sm:gap-4"),
            children: Array.from({
                length: 4
            }).map((de, Ge) => {
                var te;
                const De = ce[Ge];
                return De ? n.jsx("div", {
                    className: Ct(A ? "max-sm:short:min-h-[88px] relative h-auto max-h-[90px] min-h-[88px] sm:h-auto sm:min-h-[88px]" : "max-sm:short:min-h-[116px] relative h-auto min-h-[112px] sm:h-auto sm:min-h-[112px]", e === "carousel" ? "flex-1 max-sm:w-[164px] max-sm:flex-none" : "w-full flex-1 sm:basis-0"),
                    children: n.jsx(su, {
                        initial: !1,
                        mode: "wait",
                        children: n.jsx(to.div, {
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            exit: {
                                opacity: 0
                            },
                            transition: {
                                duration: .25,
                                ease: "easeOut"
                            },
                            className: "h-full w-full",
                            children: n.jsx(jg, {
                                source: E,
                                starterPrompt: De,
                                allPrompts: I,
                                index: Ge,
                                disabled: d,
                                disableDefaultOnClick: A,
                                onClickOverride: q[(te = De.id) != null ? te : ""],
                                className: "flex h-full w-full flex-col"
                            })
                        }, De.id)
                    })
                }, Ge) : n.jsx("div", {}, Ge)
            })
        })]
    })
}
const yo = eo({
        moreStarterPrompts: {
            id: "SplashScreenV2.moreStarterPrompts",
            defaultMessage: "More"
        },
        trySomethingNew: {
            id: "StarterPromptTiles.trySomethingNew",
            defaultMessage: "Try something new"
        },
        shuffleTiles: {
            id: "StarterPromptTiles.shuffle",
            defaultMessage: "Shuffle"
        },
        dismissStarterPrompts: {
            id: "StarterPromptTiles.dismiss",
            defaultMessage: "Close"
        },
        featureUploadFile: {
            id: "StarterPromptTiles.featureUploadFile",
            defaultMessage: "Upload file"
        },
        featureCreateImage: {
            id: "StarterPromptTiles.featureCreateImage",
            defaultMessage: "Create image"
        },
        featureWebSearch: {
            id: "StarterPromptTiles.featureWebSearch",
            defaultMessage: "Web search"
        },
        featureStartVoiceChat: {
            id: "StarterPromptTiles.featureStartVoiceChat",
            defaultMessage: "Start voice chat"
        }
    }),
    X2 = Ts(() => vs(() =>
        import ("./o4dswldtisdnypf0.js"), __vite__mapDeps([9, 1, 2, 3, 4, 5, 10])).then(t => t.JawboneNotificationsBanner)),
    Z2 = F.memo(function({
        className: e,
        suggestedContent: o
    }) {
        const a = Ke(),
            l = fe(() => As(a)),
            {
                store: i
            } = Ft(),
            d = i.useIsHeaderContentAreaPopulated() || !!o,
            b = i.useContentAreaId(tn.HeaderTop),
            s = Lg();
        let m = b === W.AgentModeAnnouncementBanner ? "z-0" : Ug.PromptTextareaHeader;
        const x = Us(a, "2206338824"),
            C = b === W.BannersRateLimit && x.get("web_design_style", "control") === "composer_banner",
            u = b === W.BannersBeaconUI && (s == null ? void 0 : s.ui_info.type) === "beacon_banner_info" && (s == null ? void 0 : s.ui_info.web_design) === Wp.COMPOSER;
        return (C || u) && (m = "-z-1"), n.jsx("div", {
            className: Ct(e != null ? e : "absolute start-0 end-0 bottom-full", m, l && "start-2 end-2"),
            children: n.jsx(Og, {
                shouldRender: d,
                contentArea: tn.Header,
                children: n.jsxs("div", {
                    className: "mb-2 flex flex-col gap-3.5 pt-2",
                    children: [n.jsx(ey, {
                        suggestedContent: o
                    }), n.jsx(ty, {})]
                })
            })
        })
    });

function ey({
    suggestedContent: t
}) {
    const e = Ke(),
        {
            store: o
        } = Ft(),
        a = o.useSharedProps(g => g == null ? void 0 : g.clientThreadId),
        l = o.useSharedProps(g => g == null ? void 0 : g.isNewThread),
        i = o.useSharedProps(g => g == null ? void 0 : g.pulseOnboardingEntrypoint),
        d = o.useSharedProps(g => g == null ? void 0 : g.cocoonEntrypointResponse),
        b = o.useContentAreaId(tn.HeaderTop),
        s = Fg(e),
        m = fe(() => a && nu(Ec(e, a)).id),
        x = jc(As),
        C = vo();
    let u;
    switch (b) {
        case W.IntegratedVoiceModeNuxBanner:
            u = n.jsx(ch, {});
            break;
        case W.ProjectConversationTaskNoFileAccess:
            u = n.jsx(ay, {});
            break;
        case W.AdvancedVoiceOnMobileAnnouncement:
            u = n.jsx(lh, {
                clientThreadId: a
            });
            break;
        case W.BannerSignup:
            u = n.jsx(oy, {});
            break;
        case W.BannerTermsDisclaimer:
            u = n.jsx(iy, {});
            break;
        case W.NewUserBannerTermsDisclaimer:
            u = n.jsx(ry, {});
            break;
        case W.PromptTextareaAction:
            u = n.jsx(ly, {});
            break;
        case W.EnablePreciseLocation:
            u = n.jsx(cy, {});
            break;
        case W.BannersRateLimit:
            u = n.jsx(dy, {});
            break;
        case W.BannersBeaconUI:
            u = n.jsx(uy, {});
            break;
        case W.BannerSidekickAnnouncement:
            u = n.jsx(rh, {});
            break;
        case W.SearchBrowserExtensionAnnouncement:
            u = n.jsx(ih, {});
            break;
        case W.MoonshineAnnouncement:
            u = n.jsx(ah, {});
            break;
        case W.GoldenHourAnnouncementBanner:
            u = !1;
            break;
        case W.SearchBrowserExtensionReactiveAnnouncement:
            u = n.jsx(oh, {});
            break;
        case W.BannerMemoryAlmostFull:
            u = n.jsx(Nd, {
                memoryAlmostFullVariant: !0
            });
            break;
        case W.BannerMemoryFull:
            u = n.jsx(Nd, {});
            break;
        case W.Box:
            u = n.jsxs("div", {
                id: "Box",
                className: "flex h-20 w-full items-center justify-center gap-2 bg-red-500 p-2",
                children: ["box", n.jsxs("div", {
                    className: "flex h-full w-full items-center justify-center gap-2 bg-blue-500 p-2",
                    children: ["inner", n.jsx("div", {
                        className: "flex h-full w-full items-center justify-center bg-yellow-400 text-center",
                        children: "actual content"
                    })]
                })]
            });
            break;
        case W.JawboneAnnouncement:
            s ? u = n.jsx(X2, {}) : u = null;
            break;
        case W.JawboneMaxActiveAnnouncement:
            s ? u = n.jsx(nh, {}) : u = null;
            break;
        case W.PromoRedemptionAnnouncement:
            u = n.jsx(sh, {});
            break;
        case W.OperatorAnnouncement:
            u = n.jsx(th, {});
            break;
        case W.BannerPlusUpsell:
            u = n.jsx(eh, {});
            break;
        case W.BannerNoAuthTrials:
            u = n.jsx(Zg, {});
            break;
        case W.ReferrerRedemptionAvailableAnnouncement:
            u = n.jsx(Xg, {});
            break;
        case W.RefereeRedemptionAvailableAnnouncement:
            u = n.jsx(Yg, {});
            break;
        case W.ReferralProgramUpsellAnnouncement:
            u = n.jsx(Qg, {});
            break;
        case W.TatertotIntakeFormAnnouncement:
            u = !1;
            break;
        case W.StudentsUpsellAnnouncement:
            u = n.jsx(Jg, {});
            break;
        case W.ModelDeprecationBanner:
            u = Kg(m);
            break;
        case W.TeamSeatsPromoAnnouncement:
            u = n.jsx(qg, {});
            break;
        case W.TeamsContextualAnswersUpsell:
            u = n.jsx(Vg, {});
            break;
        case W.AgentModeAnnouncementBanner:
            u = $p(e) && !x && n.jsx(zg, {});
            break;
        case W.LanguageUpsellBanner:
            u = n.jsx($g, {
                onDismissSideEffect: () => {
                    Ze.logEventWithStatsig("Language Upsell Banner Dismissed", "chatgpt_web_language_upsell_banner_dismissed"), Bd.set(e, !0)
                },
                onPrimaryCtaClickSideEffect: () => {
                    Ze.logEventWithStatsig("Language Upsell Banner Primary CTA Clicked", "chatgpt_web_language_upsell_banner_primary_cta_clicked"), Bd.set(e, !0)
                }
            });
            break;
        case W.PulseTasksAnnouncementBanner:
            u = a && l ? n.jsx(fr, {
                children: n.jsx(Wg, {
                    clientThreadId: a,
                    isNewThread: l
                })
            }) : null;
            break;
        case W.CocoonAnnouncementBanner:
            u = a && l && d ? n.jsx(fr, {
                children: n.jsx(Gg, {
                    clientThreadId: a,
                    isNewThread: l,
                    entrypointData: d
                })
            }) : null;
            break;
        case W.PulseAnnouncementBanner:
            u = a && l && i ? n.jsx(fr, {
                children: n.jsx(A2, {
                    clientThreadId: a,
                    entrypointData: i,
                    isNewThread: l
                })
            }) : null;
            break;
        case W.StarterPrompts:
            u = a != null ? n.jsx(Y2, {
                clientThreadId: a,
                currentModelId: m,
                hideShuffleButton: !0,
                layout: "carousel"
            }) : null;
            break;
        case W.ImageGenBanner:
            u = n.jsx(U2, {
                className: "mb-3"
            });
            break;
        case W.ImageGenV2Banner:
            u = n.jsx(fr, {
                children: n.jsx(Hg, {
                    clientThreadId: a
                })
            });
            break;
        default:
            u = t != null ? t : null;
            break
    }
    C && b !== W.IntegratedVoiceModeNuxBanner && (u = null);
    const c = !!u;
    return F.useEffect(() => {
        Rd.set(e, c)
    }, [e, c]), F.useEffect(() => () => {
        Rd.set(e, !1)
    }, [e]), u
}

function ty() {
    const {
        store: t
    } = Ft(), e = t.useContentAreaId(tn.HeaderBottom);
    let o;
    switch (e) {
        case Ou.DallePromptControls:
            o = n.jsx(ny, {});
            break;
        default:
            o = null;
            break
    }
    return o
}
const sy = Ts(() => vs(() =>
    import ("./imcx75080pls4bkf.js"), __vite__mapDeps([11, 1, 3, 4, 2, 5])).then(t => t.default));

function ny() {
    const {
        store: t
    } = Ft(), e = t.useSharedProps(o => o == null ? void 0 : o.composerController);
    return e ? n.jsx(sy, {
        composerController: e
    }) : null
}

function oy() {
    const t = Ke(),
        {
            store: e
        } = Ft(),
        o = e.useSharedProps(i => i == null ? void 0 : i.clientThreadId),
        a = gh(t),
        l = hh(t);
    return o ? a ? n.jsx(_h, {
        threadId: o,
        showSignUp: l
    }) : n.jsx(yh, {
        threadId: o,
        showLogin: l
    }) : null
}

function ay() {
    return F.useEffect(() => () => {
        wr.getItem(Cr.TasksHasSeenProjectDisclaimerBanner) || wr.setItem(Cr.TasksHasSeenProjectDisclaimerBanner, !0)
    }, []), n.jsx(ju, {
        icon: n.jsx(Vp, {}),
        title: n.jsx(Ls, {
            id: "ibX3g7",
            defaultMessage: "Tasks can’t access project files"
        }),
        content: n.jsx(Ls, {
            id: "fm94Tm",
            defaultMessage: "There’s a task in this conversation — just FYI, it won’t be able to access project files."
        }),
        onDismiss: () => {
            wr.setItem(Cr.TasksHasSeenProjectDisclaimerBanner, !0)
        }
    })
}

function iy() {
    const {
        store: t
    } = Ft(), e = t.useSharedProps(o => o == null ? void 0 : o.clientThreadId);
    return e ? n.jsx(fh, {
        threadId: e
    }) : null
}

function ry() {
    const {
        store: t
    } = Ft(), e = t.useSharedProps(o => o == null ? void 0 : o.clientThreadId);
    return e ? n.jsx(mh, {
        threadId: e
    }) : null
}

function ly() {
    const {
        store: t
    } = Ft(), e = t.useSharedProps();
    return e ? n.jsx(ph, Rt({}, e)) : null
}

function cy() {
    const {
        store: t
    } = Ft(), e = t.useSharedProps(l => l == null ? void 0 : l.clientThreadId), o = t.useSharedProps(l => l == null ? void 0 : l.conversationMode), a = ou();
    return !e || !a || a.name !== "precise-location-banner" ? null : n.jsx(py, {
        bannerInfo: a,
        clientThreadId: e,
        conversationMode: o
    })
}

function dy() {
    const {
        store: t
    } = Ft(), e = t.useSharedProps(a => a == null ? void 0 : a.clientThreadId), o = t.useSharedProps(a => a == null ? void 0 : a.composerController);
    return !e || !o ? null : n.jsx(uh, {
        clientThreadId: e,
        composerController: o
    })
}

function uy() {
    const {
        store: t
    } = Ft(), e = t.useSharedProps(l => l == null ? void 0 : l.openFileDialog), o = t.useSharedProps(l => l == null ? void 0 : l.clientThreadId), a = t.useSharedProps(l => l == null ? void 0 : l.composerController);
    return !o || !a || !e ? null : n.jsx(dh, {
        clientThreadId: o,
        openFileDialog: e
    })
}

function py(t) {
    "use forget";
    var q;
    const e = Et.c(36),
        {
            bannerInfo: o,
            clientThreadId: a,
            conversationMode: l
        } = t,
        i = Ke(),
        d = Gt(),
        b = qp();
    let s;
    e[0] !== i ? (s = Kp(i), e[0] = i, e[1] = s) : s = e[1];
    const m = s,
        [x, C] = F.useState(!1);
    let u;
    e[2] !== i ? (u = Lt(i, "1781180744"), e[2] = i, e[3] = u) : u = e[3];
    const c = u;
    let g;
    e[4] === Symbol.for("react.memo_cache_sentinel") ? (g = new Event("click"), e[4] = g) : g = e[4];
    let y;
    e[5] !== a || e[6] !== l ? (y = {
        clientThreadId: a,
        conversationMode: l,
        retryOption: "regenerate_with_precise_location",
        sourceEvent: g
    }, e[5] = a, e[6] = l, e[7] = y) : y = e[7];
    const S = bh(y);
    let v;
    if (e[8] !== o.name ? (v = () => {
            o.name === "precise-location-banner" && Ze.logEventWithStatsig("Precise Location Banner Shown", "chatgpt_precise_location_banner_shown")
        }, e[8] = o.name, e[9] = v) : v = e[9], xh(v), o.name !== "precise-location-banner") return null;
    const j = o.is_dismissible ? my : void 0;
    let M;
    e[10] !== d || e[11] !== c || e[12] !== S || e[13] !== m ? (M = () => {
        Ze.logEventWithStatsig("Precise Location Banner Location Sharing Success", "chatgpt_precise_location_banner_location_sharing_success"), m.success(d.formatMessage({
            id: "iMh1mN",
            defaultMessage: "Precise location sharing enabled"
        })), c && (S(), Ze.logEventWithStatsig("Precise Location Banner Last Turn Regenerated", "chatgpt_precise_location_banner_last_turn_regenerated"))
    }, e[10] = d, e[11] = c, e[12] = S, e[13] = m, e[14] = M) : M = e[14];
    const h = M;
    let w;
    e[15] !== d || e[16] !== m ? (w = () => {
        m.danger(d.formatMessage({
            id: "+qUF+G",
            defaultMessage: "Browser denied location sharing. Location sharing not enabled."
        })), Ze.logEventWithStatsig("Precise Location Banner Location Sharing Failed", "chatgpt_precise_location_banner_location_sharing_failed")
    }, e[15] = d, e[16] = m, e[17] = w) : w = e[17];
    const P = w;
    let R;
    e[18] !== d ? (R = d.formatMessage({
        id: "1Hhdyv",
        defaultMessage: "Turn On"
    }), e[18] = d, e[19] = R) : R = e[19];
    let D;
    e[20] !== P || e[21] !== h || e[22] !== x || e[23] !== b ? (D = () => {
        Ze.logEventWithStatsig("Precise Location Banner Button Clicked", "chatgpt_precise_location_banner_button_clicked"), !(x || b.isPending) && (C(!0), (async () => {
            try {
                await Jp(V => {
                    b.mutate({
                        setting: iu.PreciseLocationEnabledForDevice,
                        value: V
                    }, {
                        onSettled: () => {
                            V ? (h(), au.dismissBanner()) : P(), C(!1)
                        }
                    })
                })
            } catch (V) {
                P()
            }
        })())
    }, e[20] = P, e[21] = h, e[22] = x, e[23] = b, e[24] = D) : D = e[24];
    let E;
    e[25] !== R || e[26] !== D ? (E = {
        text: R,
        onClick: D
    }, e[25] = R, e[26] = D, e[27] = E) : E = e[27];
    const A = E;
    let G;
    e[28] !== A ? (G = {
        primaryAction: A
    }, e[28] = A, e[29] = G) : G = e[29];
    const k = (q = o.icon_image_url) != null ? q : void 0;
    let N;
    return e[30] !== o.description || e[31] !== o.title || e[32] !== j || e[33] !== G || e[34] !== k ? (N = n.jsx(Sh, {
        onDismiss: j,
        title: o.title,
        description: o.description,
        actions: G,
        bannerIconImageUrl: k
    }), e[30] = o.description, e[31] = o.title, e[32] = j, e[33] = G, e[34] = k, e[35] = N) : N = e[35], N
}

function my() {
    Ze.logEventWithStatsig("Precise Location Banner Dismissed", "chatgpt_precise_location_banner_dismissed"), au.dismissBanner()
}
const fy = 5,
    gy = F.memo(function(e) {
        return hy(e), _y(e), wh({
            clientThreadId: e.clientThreadId,
            composerController: e.composerController,
            openFileDialog: e.openFileDialog
        }), yy(), null
    });

function hy(t) {
    "use no forget";
    const {
        store: e
    } = Ft(), o = e.useSetSharedProps();
    xc(() => {
        o(t)
    }, [t, o])
}

function _y(t) {
    "use no forget";
    const {
        clientThreadId: e,
        canContinue: o
    } = t, {
        store: a
    } = Ft(), l = Ke(), i = F.useRef({
        top: a.useContentAreaApi(tn.HeaderTop),
        bottom: a.useContentAreaApi(tn.HeaderBottom)
    }).current, d = Ir(e), b = Ht(e, wt.getCurrentLeafId), s = Ch(e), {
        shouldShowBannerSignup: m,
        shouldShowBannerTermsDisclaimer: x
    } = by(e), {
        isOpen: C
    } = kh(), u = ou(), c = (u == null ? void 0 : u.name) === "precise-location-banner", g = Mh(e), y = Nu(e), S = vh(t);
    Th(t);
    const v = Ah(),
        j = Ih(t),
        {
            shouldShowMemoryFull: M
        } = Ph(e),
        {
            shouldShowMemoryAlmostFull: h
        } = Eh(e),
        w = jh(t),
        P = Rh(e),
        R = Bh(e),
        D = Nh(),
        {
            eligible: E
        } = bo(Dh),
        A = Lh(),
        G = Uh(),
        k = Oh(),
        N = Fh(),
        {
            eligible: q
        } = bo(en.hasSeenTeamSeatsPromoAnnouncement),
        V = zh(e),
        re = Hh(e),
        K = Gh(),
        I = Wh(),
        r = $h(e),
        oe = fe(() => nu(Ec(l, e)).id),
        T = Vh(e),
        ge = Mo(),
        Ce = Fu(l),
        {
            eligible: X
        } = bo(en.hasSeenAgentModeAnnouncementBanner),
        B = X && Ce && ge !== Sc,
        Z = Qp(),
        L = Zd(e),
        p = qh({
            shouldBeEnabledForDefaultAssistant: L && !Z,
            clientThreadId: e
        }),
        se = D2(),
        Me = p === "hscroll",
        Be = p === "image_gen_banner" && se,
        Ie = vo() && Kh(),
        be = v2({
            clientThreadId: e,
            entrypointData: t.pulseOnboardingEntrypoint,
            isNewThread: t.isNewThread
        }),
        ve = Jh({
            clientThreadId: e,
            isNewThread: t.isNewThread,
            entrypointData: t.cocoonEntrypointResponse
        }),
        ce = Qh({
            clientThreadId: e,
            isNewThread: t.isNewThread
        }),
        Ne = Du({
            serverThreadId: d,
            leafId: b
        }),
        et = (Ne == null ? void 0 : Ne.beacon_id) === Yh;
    xc(() => {
        x ? i.top.set(W.BannerTermsDisclaimer) : C ? i.top.set(W.NewUserBannerTermsDisclaimer) : Ie ? i.top.set(W.IntegratedVoiceModeNuxBanner) : oe && (T == null ? void 0 : T.kind) === ru.GizmoInteraction && T.gizmo && Yp(oe, T.gizmo) ? i.top.set(W.ProjectConversationTaskNoFileAccess) : w.eligible ? i.top.set(W.AdvancedVoiceOnMobileAnnouncement) : c ? i.top.set(W.EnablePreciseLocation) : g ? i.top.set(W.BannersRateLimit) : y ? i.top.set(W.BannersBeaconUI) : K ? i.top.set(W.BannerPlusUpsell) : I ? i.top.set(W.BannerNoAuthTrials) : P ? i.top.set(W.JawboneAnnouncement) : R ? i.top.set(W.JawboneMaxActiveAnnouncement) : S.eligible ? i.top.set(W.BannerSidekickAnnouncement) : v ? i.top.set(W.MoonshineAnnouncement) : j ? i.top.set(W.SearchBrowserExtensionReactiveAnnouncement) : D ? i.top.set(W.PromoRedemptionAnnouncement) : E ? i.top.set(W.OperatorAnnouncement) : k ? i.top.set(W.ReferralProgramUpsellAnnouncement) : o ? i.top.set(W.PromptTextareaAction) : m ? i.top.set(W.BannerSignup) : M ? i.top.set(W.BannerMemoryFull) : h ? i.top.set(W.BannerMemoryAlmostFull) : A ? i.top.set(W.ReferrerRedemptionAvailableAnnouncement) : G ? i.top.set(W.RefereeRedemptionAvailableAnnouncement) : N ? i.top.set(W.StudentsUpsellAnnouncement) : q ? i.top.set(W.TeamSeatsPromoAnnouncement) : V ? i.top.set(W.ModelDeprecationBanner) : re ? i.top.set(W.TeamsContextualAnswersUpsell) : r ? i.top.set(W.LanguageUpsellBanner) : B ? i.top.set(W.AgentModeAnnouncementBanner) : ve ? i.top.set(W.CocoonAnnouncementBanner) : be ? i.top.set(W.PulseAnnouncementBanner) : ce ? i.top.set(W.PulseTasksAnnouncementBanner) : Me ? i.top.set(W.StarterPrompts) : Be ? i.top.set(W.ImageGenBanner) : et ? i.top.set(W.ImageGenV2Banner) : i.top.set(null)
    }, [i, ge, o, x, C, m, c, g, S, M, h, w, B, q, Me, Be, Ie, et, be, ce]), xc(() => {
        s && i.bottom.set(Ou.DallePromptControls)
    }, [i, s])
}

function yy() {
    const {
        store: t
    } = Ft();
    F.useEffect(() => () => {
        t.reset()
    }, [t])
}

function by(t) {
    const e = Ke(),
        o = !Zs(),
        a = Us(e, "3637408529", {
            disableExposureLog: !0
        }),
        i = Us(e, "3637408529").get("no_auth_banner_signup_rate_limit", fy),
        d = a.get("should_show_no_auth_signup_banner", !0),
        b = Xh(u => u.bannerDisclaimerClientThreadId),
        s = Zh(),
        m = {
            shouldShowBannerTermsDisclaimer: !1,
            shouldShowBannerSignup: !1
        },
        [x, C] = Ht(t, u => {
            var c;
            return [wt.getConversationTurns(u).filter(g => g.role === lu.User).length, xy((c = wt.getCurrentNode(u)) == null ? void 0 : c.message)]
        });
    return t && (m.shouldShowBannerTermsDisclaimer = C && o && x === 1 && !s && (b == null || b === t), m.shouldShowBannerSignup = d && C && o && x > 0 && x % i === 0), m
}

function xy(t) {
    return (t == null ? void 0 : t.author.role) === lu.Assistant && Xp(t)
}
const ap = "manage-prompts",
    Sy = Ts(() => vs(() =>
        import ("./k15yxxoybkkir2ou.js").then(t => t.Fc), __vite__mapDeps([2, 1, 3, 4, 5])).then(t => t.AgentNuxModal));

function wy({
    hint: t,
    isHighlighted: e,
    onHighlight: o,
    onClick: a
}) {
    "use no forget";
    const l = $u(t.systemHint),
        i = n.jsx(ym, {
            as: "div",
            hasManagedFocus: !0,
            disabled: l.isBlocked,
            highlighted: e,
            icon: n.jsx(Gu, {
                hint: t,
                isNextToLabel: !0
            }),
            secondary: l.blockedLabel,
            onPointerMove: o,
            onClick: a,
            children: n.jsx("span", {
                className: "break-all",
                children: t.name
            })
        });
    return l.remainingLabel ? n.jsx(vr, {
        side: "right",
        labelTextAlign: l.isBlocked ? "left" : "center",
        label: l.remainingLabel,
        secondaryLabel: l.remainingLabelSecondary,
        contentClassName: "cant-hover:hidden",
        triggerAs: null,
        children: i
    }) : i
}
const Cy = _m(t => {
    var e, o, a, l;
    return Qn(t) ? {
        targets: [t.command, ...(e = t.aliases) != null ? e : [], ...(o = t.regexMatches) != null ? o : [], t.secondary ? "".concat(t.title, " ").concat(t.secondary) : t.title],
        weight: t.matchWeight
    } : {
        targets: [t.systemHint, ...(a = t.aliases) != null ? a : [], ...(l = t.regexMatches) != null ? l : [], t.name]
    }
});

function ky(t) {
    "use forget";
    const e = Et.c(141),
        {
            gptsAndAppsSlashCommands$: o,
            modelSlashCommands$: a,
            hazelnutSlashCommands: l,
            libraryPromptSlashCommands: i,
            slashCommands: d,
            systemHints: b,
            composerController: s,
            clientThreadId: m,
            layoutMode: x,
            isFirstPartyProject: C
        } = t,
        u = Ke(),
        c = n1(),
        g = Xd(),
        y = Gt(),
        S = x === "center" ? "bottom-start" : "top-start";
    let v;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (v = [mm({
        mainAxis: 10,
        alignmentAxis: -18
    }), fm({
        padding: 6
    }), gm({
        apply: jy
    })], e[0] = v) : v = e[0];
    let j;
    e[1] !== S ? (j = {
        placement: S,
        middleware: v,
        whileElementsMounted: bm
    }, e[1] = S, e[2] = j) : j = e[2];
    const {
        refs: M,
        floatingStyles: h
    } = hm(j), [w, P] = F.useState(void 0);
    let R;
    e[3] !== s || e[4] !== M.setReference ? (R = () => {
        const z = dt(s);
        z.dispatch(xm(z.state.tr, {
            setReferencePosition: M.setReference,
            onHintMatch($) {
                P(le => fu(le, $) ? le : $)
            }
        }))
    }, e[3] = s, e[4] = M.setReference, e[5] = R) : R = e[5];
    let D;
    e[6] !== s || e[7] !== M ? (D = [s, M], e[6] = s, e[7] = M, e[8] = D) : D = e[8], F.useEffect(R, D);
    const E = o1(),
        A = Ir(m),
        {
            setThreadSystemHintMode: G,
            clearAllSystemHintModeTriggers: k
        } = a1(),
        N = jc(As);
    let q;
    e[9] !== o || e[10] !== w ? (q = () => w && (o == null ? void 0 : o()), e[9] = o, e[10] = w, e[11] = q) : q = e[11];
    const V = fe(q);
    let re;
    e[12] !== a ? (re = () => {
        var z;
        return (z = a == null ? void 0 : a()) != null ? z : []
    }, e[12] = a, e[13] = re) : re = e[13];
    const K = fe(re),
        I = (w == null ? void 0 : w.triggerSymbol) === "@",
        r = (w == null ? void 0 : w.triggerSymbol) === "/";
    let oe;
    e[14] !== u || e[15] !== C ? (oe = du(u) && !C, e[14] = u, e[15] = C, e[16] = oe) : oe = e[16];
    const T = oe;
    let ge;
    e[17] !== u ? (ge = () => {}, e[17] = u, e[18] = ge) : ge = e[18];
    const Ce = ge;
    let X;
    e: {
        if (N && I) {
            let Ee;
            e[19] === Symbol.for("react.memo_cache_sentinel") ? (Ee = [], e[19] = Ee) : Ee = e[19], X = Ee;
            break e
        }
        let z;e[20] !== V || e[21] !== I ? (z = I ? V : V == null ? void 0 : V.filter(Ey), e[20] = V, e[21] = I, e[22] = z) : z = e[22];
        const $ = z;
        let le;e[23] !== $ ? (le = $ != null ? $ : [], e[23] = $, e[24] = le) : le = e[24];
        let Q;e[25] !== le ? (Q = le.some(Py), e[25] = le, e[26] = Q) : Q = e[26];
        const _e = Q;
        let Ae;e[27] !== _e || e[28] !== r || e[29] !== b ? (Ae = r && _e ? b.filter(Iy) : b, e[27] = _e, e[28] = r, e[29] = b, e[30] = Ae) : Ae = e[30];
        const yt = Ae;
        let ze;
        if (e[31] !== y || e[32] !== r || e[33] !== i || e[34] !== g || e[35] !== Ce || e[36] !== T) {
            if (ze = [], r && T)
                if (i && i.length > 0) {
                    let Ee;
                    e[38] !== i ? (Ee = [...i], e[38] = i, e[39] = Ee) : Ee = e[39], ze.push(Ee);
                    let $e;
                    e[40] !== y ? ($e = y.formatMessage({
                        id: "composer.library.managePrompts",
                        defaultMessage: "Manage prompts"
                    }), e[40] = y, e[41] = $e) : $e = e[41];
                    let lt;
                    e[42] !== g ? (lt = () => g("/library?tab=prompts&referer=at_cmd"), e[42] = g, e[43] = lt) : lt = e[43];
                    let He;
                    e[44] !== $e || e[45] !== lt ? (He = [{
                        command: ap,
                        title: $e,
                        icon: void 0,
                        onSelect: lt
                    }], e[44] = $e, e[45] = lt, e[46] = He) : He = e[46], ze.push(He)
                } else {
                    let Ee;
                    e[47] !== y ? (Ee = y.formatMessage({
                        id: "composer.library.createPrompt",
                        defaultMessage: "Create new prompt"
                    }), e[47] = y, e[48] = Ee) : Ee = e[48];
                    let $e;
                    e[49] !== y ? ($e = y.formatMessage({
                        id: "composer.library.createPromptDescription",
                        defaultMessage: "Prompts are saved sequences of text that you can quickly add to your messages."
                    }), e[49] = y, e[50] = $e) : $e = e[50];
                    let lt;
                    e[51] !== Ce || e[52] !== Ee || e[53] !== $e ? (lt = [{
                        command: "create-prompt",
                        title: Ee,
                        secondary: $e,
                        icon: void 0,
                        onSelect: Ce
                    }], e[51] = Ce, e[52] = Ee, e[53] = $e, e[54] = lt) : lt = e[54], ze.push(lt)
                }
            e[31] = y, e[32] = r, e[33] = i, e[34] = g, e[35] = Ce, e[36] = T, e[37] = ze
        } else ze = e[37];
        let ot;e[55] !== $ ? (ot = $ != null ? $ : [], e[55] = $, e[56] = ot) : ot = e[56];
        let rt;e[57] !== ot ? (rt = [ot], e[57] = ot, e[58] = rt) : rt = e[58];
        const st = rt;
        let Y;e[59] !== l ? (Y = l && (l == null ? void 0 : l.length) > 0 ? [l] : [], e[59] = l, e[60] = Y) : Y = e[60];
        const bt = Y;
        let Ut;e[61] !== st || e[62] !== bt || e[63] !== x || e[64] !== ze ? (Ut = x === "bottom" ? [...st, ...ze, ...bt] : [...ze, ...st, ...bt], e[61] = st, e[62] = bt, e[63] = x, e[64] = ze, e[65] = Ut) : Ut = e[65];
        const Bt = Ut;
        if (I) X = Bt;
        else {
            let Ee;
            e[66] !== d || e[67] !== K || e[68] !== Bt || e[69] !== yt ? (Ee = [d, yt, K, ...Bt], e[66] = d, e[67] = K, e[68] = Bt, e[69] = yt, e[70] = Ee) : Ee = e[70], X = Ee
        }
    }
    const B = X;
    let Z;
    e: {
        if (!w) {
            let Q;
            e[71] === Symbol.for("react.memo_cache_sentinel") ? (Q = [], e[71] = Q) : Q = e[71];
            let _e;
            e[72] === Symbol.for("react.memo_cache_sentinel") ? (_e = [], e[72] = _e) : _e = e[72];
            let Ae;
            e[73] === Symbol.for("react.memo_cache_sentinel") ? (Ae = {
                displayGroups: Q,
                suggestions: _e
            }, e[73] = Ae) : Ae = e[73], Z = Ae;
            break e
        }
        let z, $;
        if (e[74] !== B || e[75] !== w.text || e[76] !== y || e[77] !== x) {
            const Q = w.text ? [i1(Ld(B), w.text, Cy, {
                    locale: y.locale
                })] : B.map(Ty),
                _e = x === "bottom" ? Q.reverse().map(vy) : Q;
            z = _e, $ = Ld(_e), e[74] = B, e[75] = w.text, e[76] = y, e[77] = x, e[78] = z, e[79] = $
        } else z = e[78],
        $ = e[79];
        let le;e[80] !== z || e[81] !== $ ? (le = {
            displayGroups: z,
            suggestions: $
        }, e[80] = z, e[81] = $, e[82] = le) : le = e[82],
        Z = le
    }
    const {
        displayGroups: L,
        suggestions: p
    } = Z, [se, Me] = F.useState(x === "bottom" ? -1 : 0), Be = se == null ? null : (se + p.length) % p.length;
    let Ie;
    e[83] !== E || e[84] !== p ? (Ie = z => {
        Me($ => {
            if ($ == null) return null;
            const le = p.length;
            for (let Q = 0; Q < le; Q++) {
                const _e = ($ + le + (Q + 1) * z) % le,
                    Ae = p[_e];
                if (!("systemHint" in Ae ? E.includes(Ae.systemHint) : Ae.disabled)) return _e
            }
            return null
        })
    }, e[83] = E, e[84] = p, e[85] = Ie) : Ie = e[85];
    const ve = xo(Ie),
        ce = p.length,
        Ne = ce === 0;
    let et;
    e[86] !== x || e[87] !== ve ? (et = () => {
        x === "bottom" ? (Me(0), ve.current(-1)) : (Me(-1), ve.current(1))
    }, e[86] = x, e[87] = ve, e[88] = et) : et = e[88];
    let tt;
    e[89] !== x || e[90] !== ce || e[91] !== ve ? (tt = [ce, x, ve], e[89] = x, e[90] = ce, e[91] = ve, e[92] = tt) : tt = e[92], F.useEffect(et, tt);
    const de = Be == null ? null : p[Be];
    let Ge;
    e[93] !== s || e[94] !== w ? (Ge = () => {
        if (w != null && w.range) {
            const z = dt(s);
            gd(z, w.range.from, w.range.to)
        }
    }, e[93] = s, e[94] = w, e[95] = Ge) : Ge = e[95];
    const De = Ge;
    let te;
    e[96] !== s || e[97] !== w ? (te = z => {
        if (!(w != null && w.range)) return;
        const $ = dt(s);
        gd($, w.range.from, w.range.to), mu($, z)
    }, e[96] = s, e[97] = w, e[98] = te) : te = e[98];
    const Pe = te;
    let Re;
    e[99] !== c || e[100] !== k || e[101] !== De || e[102] !== m || e[103] !== s || e[104] !== u || e[105] !== w || e[106] !== Pe || e[107] !== de || e[108] !== A || e[109] !== G ? (Re = z => {
        var rt;
        const {
            hintToSave: $,
            expectPerfectMatch: le
        } = z, Q = $ === void 0 ? de : $;
        if (!w || !Q) return !1;
        const _e = w.text.toLocaleLowerCase(),
            yt = (Qn(Q) ? Q.command : Q.name).toLocaleLowerCase() === _e || ((rt = Q.aliases) == null ? void 0 : rt.some(st => st.toLocaleLowerCase() === _e));
        if (le && !yt) return !1;
        if (Qn(Q) && Q.insertText && w.triggerSymbol === "@" ? Pe(Q.insertText) : De(), gr(dt(s)), Qn(Q)) return Q.onSelect(), !0;
        Ze.logEvent("System Hint Selected", {
            system_hint: Q.systemHint,
            conversation_id: A != null ? A : uc
        });
        const ze = {
            clientThreadId: m
        };
        k();
        const ot = Q.systemHint === ue.Search;
        return G(Q.systemHint, !0, ze, ot ? Sm.CONVERSATION_COMPOSER_SLASH_SEARCH : wm.SLASH_COMMAND), Q.systemHint === ue.Agent && c === "show" && Zn(u, Sy, {
            clientThreadId: m != null ? m : uc,
            source: "slash_agent"
        }), !0
    }, e[99] = c, e[100] = k, e[101] = De, e[102] = m, e[103] = s, e[104] = u, e[105] = w, e[106] = Pe, e[107] = de, e[108] = A, e[109] = G, e[110] = Re) : Re = e[110];
    const We = Re,
        ee = xo(We);
    let Se;
    e[111] !== s || e[112] !== ve || e[113] !== ee || e[114] !== Ne ? (Se = () => {
        const z = dt(s);
        return Ne || Cm(z, $ => {
            if ($ === "up") ve.current(-1);
            else if ($ === "down") ve.current(1);
            else if ($ === "cancel") gr(z), km(z);
            else {
                if ($ === "submit") return gr(z), ee.current({
                    expectPerfectMatch: !1
                });
                if ($ === "checkMatch") return ee.current({
                    expectPerfectMatch: !0
                })
            }
        }), () => gr(z)
    }, e[111] = s, e[112] = ve, e[113] = ee, e[114] = Ne, e[115] = Se) : Se = e[115];
    let J;
    e[116] !== De || e[117] !== s || e[118] !== ve || e[119] !== ee || e[120] !== de || e[121] !== Ne ? (J = [s, Ne, de, De, ve, ee], e[116] = De, e[117] = s, e[118] = ve, e[119] = ee, e[120] = de, e[121] = Ne, e[122] = J) : J = e[122], F.useEffect(Se, J);
    const pe = xo(A);
    let he, ye;
    if (e[123] !== Ne || e[124] !== pe ? (he = () => {
            var z;
            Ne || Ze.logEvent("System Hint List Opened", {
                conversation_id: (z = pe.current) != null ? z : uc
            })
        }, ye = [pe, Ne], e[123] = Ne, e[124] = pe, e[125] = he, e[126] = ye) : (he = e[125], ye = e[126]), F.useEffect(he, ye), Ne) return null;
    let ke;
    e[127] !== M ? (ke = z => M.setFloating(z), e[127] = M, e[128] = ke) : ke = e[128];
    const Le = p.length > 6 ? "max-h-[min(var(--radix-popper-available-height,50svh),--spacing(1.5)+5*var(--menu-item-height))]" : "max-h-[var(--radix-popper-available-height,50svh)]";
    let ne;
    e[129] !== Le ? (ne = Ct("max-w-[min(var(--radix-popper-available-width,100vw),--spacing(100))] overflow-y-auto [scrollbar-width:none]", Le), e[129] = Le, e[130] = ne) : ne = e[130];
    let Te;
    e[131] !== s || e[132] !== L || e[133] !== We || e[134] !== Be ? (Te = L.map((z, $) => {
        let le = 0;
        for (let Q = 0; Q < $; Q++) le = le + L[Q].length;
        return n.jsx(Pt.Group, {
            children: z.map((Q, _e) => {
                const Ae = le + _e;
                return Qn(Q) ? n.jsx(r1, {
                    command: Q,
                    isHighlighted: Ae === Be,
                    onHighlight: () => Me(Ae),
                    onClick: () => {
                        We({
                            hintToSave: Q,
                            expectPerfectMatch: !1
                        }), Ds(dt(s))
                    }
                }, Q.command) : n.jsx(wy, {
                    hint: Q,
                    isHighlighted: Ae === Be,
                    onHighlight: () => Me(Ae),
                    onClick: () => {
                        We({
                            hintToSave: Q,
                            expectPerfectMatch: !1
                        }), Ds(dt(s))
                    }
                }, Q.systemHint)
            })
        }, $)
    }), e[131] = s, e[132] = L, e[133] = We, e[134] = Be, e[135] = Te) : Te = e[135];
    let it;
    return e[136] !== h || e[137] !== ke || e[138] !== ne || e[139] !== Te ? (it = n.jsx(Mm, {
        ref: ke,
        style: h,
        className: ne,
        onPointerDown: My,
        children: Te
    }), e[136] = h, e[137] = ke, e[138] = ne, e[139] = Te, e[140] = it) : it = e[140], it
}

function My(t) {
    t.preventDefault()
}

function vy(t) {
    return t.reverse()
}

function Ty(t) {
    return t.filter(Ay)
}

function Ay(t) {
    return !Qn(t) || !t.noMatchEmpty
}

function Iy(t) {
    return !t.isConnector
}

function Py(t) {
    return t.type === Tr.App
}

function Ey(t) {
    return t.type === Tr.App
}

function jy(t) {
    const {
        elements: e,
        availableWidth: o,
        availableHeight: a
    } = t;
    e.floating.style.setProperty("--radix-popper-available-width", "".concat(o, "px")), e.floating.style.setProperty("--radix-popper-available-height", "".concat(a, "px"))
}

function Ry(t) {
    "use forget";
    var Re, We;
    const e = Et.c(107),
        {
            systemHints: o,
            availableSystemHints: a,
            composerController: l,
            clientThreadId: i,
            layoutMode: d,
            composerLayer: b,
            canUseInlineTagging: s,
            isFileUploadEnabled: m,
            fileUploadDisabledReason: x,
            currentModelConfig: C,
            openFileDialog: u,
            connectionInstanceData: c,
            setActiveSystemHintType: g,
            selectModelId: y,
            gizmoId: S,
            hasGizmoFeatureRateLimit: v,
            setSelectedGizmoTag: j,
            isFirstPartyProject: M
        } = t,
        h = Ke();
    let w;
    e[0] !== i || e[1] !== h ? (w = Ec(h, i), e[0] = i, e[1] = h, e[2] = w) : w = e[2];
    const P = w,
        R = Gt(),
        D = Xd(),
        {
            connectedTypes: E
        } = Zp(),
        A = Ic();
    let G;
    e[3] !== A ? (G = A != null && em(A), e[3] = A, e[4] = G) : G = e[4];
    const k = G;
    let N;
    e[5] !== h ? (N = () => Rc(h), e[5] = h, e[6] = N) : N = e[6];
    const q = fe(N),
        {
            isSingleLine: V,
            showModelSlashCommands: re
        } = b,
        K = cu();
    let I;
    e[7] === Symbol.for("react.memo_cache_sentinel") ? (I = {
        onError: Wy
    }, e[7] = I) : I = e[7];
    const {
        mutate: r
    } = tm(I), oe = e1(i);
    c == null || c.connection_statuses;
    let T;
    if (e[8] !== i || e[9] !== E || e[10] !== (c == null ? void 0 : c.connection_statuses) || e[11] !== h || e[12] !== (C == null ? void 0 : C.title) || e[13] !== x || e[14] !== R || e[15] !== q || e[16] !== m || e[17] !== k || e[18] !== V || e[19] !== D || e[20] !== u || e[21] !== g || e[22] !== o) {
        if (T = [], V) {
            let pe;
            e[24] === Symbol.for("react.memo_cache_sentinel") ? (pe = ["file", "attach", "photo"], e[24] = pe) : pe = e[24];
            const he = !m,
                ye = C == null ? void 0 : C.title;
            let ke;
            e[25] !== h || e[26] !== x || e[27] !== R || e[28] !== he || e[29] !== ye ? (ke = zu(h, R, he, x, ye), e[25] = h, e[26] = x, e[27] = R, e[28] = he, e[29] = ye, e[30] = ke) : ke = e[30];
            let Le;
            e[31] === Symbol.for("react.memo_cache_sentinel") ? (Le = n.jsx(Hu, {
                "aria-label": "",
                className: "icon"
            }), e[31] = Le) : Le = e[31];
            const ne = !m;
            let Te;
            e[32] !== u || e[33] !== ne || e[34] !== ke ? (Te = {
                command: "upload",
                aliases: pe,
                title: ke,
                icon: Le,
                onSelect: u,
                disabled: ne
            }, e[32] = u, e[33] = ne, e[34] = ke, e[35] = Te) : Te = e[35], T.push(Te)
        }
        let ee;
        e[36] !== (c == null ? void 0 : c.connection_statuses) ? (ee = (Re = c == null ? void 0 : c.connection_statuses.filter(Gy).map(Hy)) != null ? Re : [], e[36] = c == null ? void 0 : c.connection_statuses, e[37] = ee) : ee = e[37];
        const Se = ee,
            J = o == null ? void 0 : o.some(zy);
        if (k && (E.size > 0 || Se.length > 0) && J) {
            let pe;
            e[38] !== R ? (pe = R.formatMessage({
                id: "6YT2cp",
                defaultMessage: "Use all connectors"
            }), e[38] = R, e[39] = pe) : pe = e[39];
            let he;
            e[40] === Symbol.for("react.memo_cache_sentinel") ? (he = n.jsx(t1, {}), e[40] = he) : he = e[40];
            let ye;
            e[41] !== i || e[42] !== Se || e[43] !== E || e[44] !== g ? (ye = () => {
                g(ue.Slurm, {
                    analyticsMetadata: {
                        clientThreadId: i
                    }
                }), Ns(i, Le => {
                    var Te, it;
                    const ne = (it = (Te = Le.selectedSources) == null ? void 0 : Te.get(ue.Slurm)) != null ? it : new Set;
                    Le.selectedSources == null && (Le.selectedSources = new Map), Le.selectedSources.set(ue.Slurm, new Set([...ne, ...E, ...Se]))
                })
            }, e[41] = i, e[42] = Se, e[43] = E, e[44] = g, e[45] = ye) : ye = e[45];
            let ke;
            e[46] !== pe || e[47] !== ye ? (ke = {
                command: "all-connectors",
                title: pe,
                icon: he,
                noMatchEmpty: !0,
                onSelect: ye
            }, e[46] = pe, e[47] = ye, e[48] = ke) : ke = e[48], T.push(ke)
        }
        if (q) {
            let pe;
            e[49] === Symbol.for("react.memo_cache_sentinel") ? (pe = ["mcp"], e[49] = pe) : pe = e[49];
            let he;
            e[50] === Symbol.for("react.memo_cache_sentinel") ? (he = n.jsx(s1, {}), e[50] = he) : he = e[50];
            let ye;
            e[51] !== D ? (ye = {
                command: "add-mcp",
                aliases: pe,
                title: "Add MCP",
                icon: he,
                noMatchEmpty: !0,
                onSelect: () => {
                    D(nm(uu.Connectors))
                }
            }, e[51] = D, e[52] = ye) : ye = e[52], T.push(ye)
        }
        e[8] = i, e[9] = E, e[10] = c == null ? void 0 : c.connection_statuses, e[11] = h, e[12] = C == null ? void 0 : C.title, e[13] = x, e[14] = R, e[15] = q, e[16] = m, e[17] = k, e[18] = V, e[19] = D, e[20] = u, e[21] = g, e[22] = o, e[23] = T
    } else T = e[23];
    const ge = T;
    let Ce;
    e[53] !== P || e[54] !== y || e[55] !== re ? (Ce = Mr(() => {
        if (!re) return [];
        const ee = Bc(P),
            Se = [];
        for (const J of ee.categories) J.defaultModel !== ee.defaultModelSlug && Se.push({
            command: J.defaultModel,
            title: J.label,
            disabled: !1,
            icon: n.jsx(Dd, {
                className: "icon"
            }),
            onSelect: () => {
                y(J.defaultModel, "slash menu")
            }
        });
        for (const J of ee.groups)
            for (const pe of J.modelIds) {
                const he = ee.models.get(pe);
                if (he && !he.tags.includes(om.HIDDEN)) {
                    let ye = he.title;
                    Se.push({
                        command: he.id,
                        title: ye,
                        secondary: void 0,
                        trailing: n.jsx(am, {
                            children: J.label
                        }),
                        noMatchEmpty: !0,
                        matchWeight: .1,
                        disabled: !1,
                        icon: n.jsx(Dd, {
                            className: "icon"
                        }),
                        onSelect: () => {
                            y(he.id, "slash menu")
                        }
                    })
                }
            }
        return Se
    }), e[53] = P, e[54] = y, e[55] = re, e[56] = Ce) : Ce = e[56];
    const X = Ce;
    let B;
    e[57] !== a ? (B = a != null ? a : [], e[57] = a, e[58] = B) : B = e[58];
    let Z;
    e[59] !== B ? (Z = B.filter(Fy), e[59] = B, e[60] = Z) : Z = e[60];
    const L = Z;
    let p;
    e[61] !== a ? (p = a != null ? a : [], e[61] = a, e[62] = p) : p = e[62];
    let se;
    e[63] !== p ? (se = p.filter(Oy), e[63] = p, e[64] = se) : se = e[64];
    const Me = se;
    let Be;
    e[65] !== K || e[66] !== Me || e[67] !== s || e[68] !== i || e[69] !== h || e[70] !== S || e[71] !== v || e[72] !== M || e[73] !== j ? (Be = Mr(() => {
        var Le, ne, Te, it, z;
        if (!s) return [];
        const {
            data: ee
        } = im(h), {
            data: Se
        } = rm(h), {
            data: J
        } = lm(h), pe = Nc([...(Le = ee == null ? void 0 : ee.items) != null ? Le : [], ...(Te = (ne = Se == null ? void 0 : Se.list.items) == null ? void 0 : ne.map(Uy)) != null ? Te : [], ...Lt(h, "773249106") ? (z = (it = J == null ? void 0 : J.items) == null ? void 0 : it.map(Ly)) != null ? z : [] : []], Dy), he = S ? pe.filter($ => $.gizmo.id !== S) : pe, ye = Me.map($ => {
            var le, Q;
            return {
                command: (le = $.actionLabel) != null ? le : $.name,
                title: (Q = $.actionLabel) != null ? Q : $.name,
                type: Tr.App,
                icon: n.jsx(Gu, {
                    hint: $,
                    isNextToLabel: !0
                }),
                insertText: "@".concat($.name, " "),
                onSelect: () => {
                    K($.systemHint), cm($.systemHint, um.AtMention, dm({
                        clientThreadId: i
                    }))
                }
            }
        }), ke = M ? [] : he.map($ => {
            var le;
            return {
                command: $.gizmo.display.name,
                title: $.gizmo.display.name,
                type: Tr.Gizmo,
                disabled: v,
                icon: n.jsx(Wu, {
                    simple: !0,
                    isFirstParty: ((le = $.gizmo.tags) == null ? void 0 : le.includes(Dc.FirstParty)) === !0,
                    src: $.gizmo.display.profile_picture_url,
                    className: "icon",
                    alt: ""
                }),
                onSelect: () => {
                    Ze.logEventWithStatsig("Composer GPT Selected", "chatgpt_web_composer_gpt_selected", {
                        gizmo: $.gizmo.id
                    }), j($)
                }
            }
        }).filter($ => !ye.some(le => le.command === $.command));
        return [...ye, ...ke]
    }), e[65] = K, e[66] = Me, e[67] = s, e[68] = i, e[69] = h, e[70] = S, e[71] = v, e[72] = M, e[73] = j, e[74] = Be) : Be = e[74];
    const Ie = Be;
    let be;
    e[75] !== h ? (be = du(h), e[75] = h, e[76] = be) : be = e[76];
    const ve = be;
    let ce;
    e[77] !== ve ? (ce = {
        enabled: ve
    }, e[77] = ve, e[78] = ce) : ce = e[78];
    const {
        data: Ne,
        isLoading: et
    } = sm(ce);
    let tt;
    e[79] !== i || e[80] !== l || e[81] !== P || e[82] !== r || e[83] !== D || e[84] !== g ? (tt = ee => {
        var J, pe, he;
        const Se = dt(l);
        if (pm(Se, "@"), ee === ap) {
            D("/library?tab=prompts");
            return
        }
        if (ee.id && !ee.created_by_openai && r(String(ee.id)), pu.set(P, !0), Ze.logEventWithStatsig("chatgpt_web_prompt_used", "chatgpt_web_prompt_used", {
                referer: "at_cmd",
                hint: (J = ee.system_hint) != null ? J : "none",
                sources: ((pe = ee.sources) != null ? pe : []).join(",")
            }), mu(Se, ee.prompt), ee.system_hint && (g(ee.system_hint), (he = ee.sources) != null && he.length)) {
            const ye = ee.sources.map(Ny).filter(wc),
                ke = ee.system_hint,
                Le = new Set(ye.filter(By)),
                ne = new Set(ye.filter(Ms));
            Ns(i, Te => {
                Te.selectedSources = new Map([
                    [ke, Le]
                ]), Te.selectedMCPSources = new Map([
                    [ke, ne]
                ]), Te.hasModifiedSources = !0
            })
        }
    }, e[79] = i, e[80] = l, e[81] = P, e[82] = r, e[83] = D, e[84] = g, e[85] = tt) : tt = e[85];
    const de = tt;
    let Ge;
    e: {
        if (et || Ne == null || !ve) {
            let J;
            e[86] === Symbol.for("react.memo_cache_sentinel") ? (J = [], e[86] = J) : J = e[86], Ge = J;
            break e
        }
        let ee;e[87] !== Ne.pages[0].prompts ? (ee = (We = Ne.pages[0].prompts) != null ? We : [], e[87] = Ne.pages[0].prompts, e[88] = ee) : ee = e[88];
        let Se;
        if (e[89] !== de || e[90] !== ee) {
            let J;
            e[92] !== de ? (J = pe => ({
                command: pe.name,
                title: pe.name,
                icon: void 0,
                onSelect: () => {
                    de(pe)
                }
            }), e[92] = de, e[93] = J) : J = e[93], Se = ee.map(J), e[89] = de, e[90] = ee, e[91] = Se
        } else Se = e[91];Ge = Se
    }
    const De = Ge;
    let te;
    e[94] !== L ? (te = L != null ? L : [], e[94] = L, e[95] = te) : te = e[95];
    let Pe;
    return e[96] !== i || e[97] !== l || e[98] !== Ie || e[99] !== oe || e[100] !== M || e[101] !== d || e[102] !== De || e[103] !== X || e[104] !== ge || e[105] !== te ? (Pe = n.jsx(ky, {
        gptsAndAppsSlashCommands$: Ie,
        modelSlashCommands$: X,
        hazelnutSlashCommands: oe,
        libraryPromptSlashCommands: De,
        slashCommands: ge,
        systemHints: te,
        composerController: l,
        clientThreadId: i,
        layoutMode: d,
        isFirstPartyProject: M
    }), e[96] = i, e[97] = l, e[98] = Ie, e[99] = oe, e[100] = M, e[101] = d, e[102] = De, e[103] = X, e[104] = ge, e[105] = te, e[106] = Pe) : Pe = e[106], Pe
}

function By(t) {
    return !Ms(t)
}

function Ny(t) {
    return t.trim()
}

function Dy(t) {
    return t.gizmo.id
}

function Ly(t) {
    return t.gizmo
}

function Uy(t) {
    return t.resource
}

function Oy(t) {
    return t.isConnector
}

function Fy(t) {
    return !(t.isConnector && t.hideFromInitialSelection && !t.canConnect)
}

function zy(t) {
    return t.systemHint === ue.Slurm
}

function Hy(t) {
    return t.user_connection_details.connection_type
}

function Gy(t) {
    return t.user_connection_details.activation_status === "activated" && ["google_drive_oauth", "google_drive_dwd"].includes(t.user_connection_details.knowledge_connector_type)
}

function Wy() {}

function $y(t) {
    "use forget";
    const e = Et.c(35),
        {
            clientThreadId: o,
            modelSupportedImageMimeTypes: a,
            openFileDialog: l,
            historyDisabled: i,
            isDisabled: d,
            highlightTooltip: b,
            disabledReason: s,
            currentModelName: m,
            isLoadingConnectors: x,
            connectorConfig: C,
            onSelectConnector: u,
            showLabel: c,
            showUpsell: g,
            hideBorder: y,
            isSmall: S,
            showMenuForNoAuth: v,
            visualTreatment: j
        } = t,
        M = Ke(),
        h = vm();
    let w;
    e[0] !== M ? (w = Tm(M), e[0] = M, e[1] = w) : w = e[1];
    const {
        gdriveStatus: P,
        o365Status: R
    } = w;
    let D;
    e[2] !== M ? (D = Zs(), e[2] = M, e[3] = D) : D = e[3];
    const E = !D,
        A = i ? "text-white" : b ? "text-brand-blue-800" : "",
        G = !g && (P !== "false" || R !== "false" || h);
    let k;
    e[4] !== M ? (k = () => Lc(M), e[4] = M, e[5] = k) : k = e[5];
    const {
        loggedOutAttachPlusIcon: N
    } = fe(k), q = E && !N ? Hu : l1;
    let V;
    e[6] !== A ? (V = Ct("icon", A), e[6] = A, e[7] = V) : V = e[7];
    let re;
    e[8] !== q || e[9] !== V ? (re = n.jsx(q, {
        "aria-label": "",
        className: V
    }), e[8] = q, e[9] = V, e[10] = re) : re = e[10];
    const K = re,
        I = a.length > 0;
    let r;
    e[11] !== o || e[12] !== C || e[13] !== m || e[14] !== s || e[15] !== y || e[16] !== b || e[17] !== K || e[18] !== d || e[19] !== x || e[20] !== S || e[21] !== E || e[22] !== a || e[23] !== I || e[24] !== u || e[25] !== l || e[26] !== G || e[27] !== c || e[28] !== v || e[29] !== g || e[30] !== j ? (r = G ? n.jsx(c1, {
        clientThreadId: o,
        icon: K,
        showLabel: E && c,
        modelSupportedImageMimeTypes: a,
        isLoadingConnectors: x,
        connectorConfig: C,
        onSelectConnector: u,
        openFileDialog: l,
        isDisabled: d,
        highlightTooltip: b,
        disabledReason: s,
        currentModelName: m
    }) : n.jsx(S2, {
        isSmall: S,
        hideBorder: y,
        clientThreadId: o,
        openFileDialog: l,
        showLabel: c,
        showUpsell: g,
        icon: K,
        isDisabled: d,
        highlightTooltip: b,
        disabledReason: s,
        currentModelName: m,
        visualTreatment: j,
        showMenuForNoAuth: v,
        modelSupportsImages: I
    }), e[11] = o, e[12] = C, e[13] = m, e[14] = s, e[15] = y, e[16] = b, e[17] = K, e[18] = d, e[19] = x, e[20] = S, e[21] = E, e[22] = a, e[23] = I, e[24] = u, e[25] = l, e[26] = G, e[27] = c, e[28] = v, e[29] = g, e[30] = j, e[31] = r) : r = e[31];
    const oe = r;
    let T;
    return e[32] !== oe || e[33] !== b ? (T = n.jsx(d1, {
        showBackground: b,
        className: "bg-brand-blue-800/20",
        children: oe
    }), e[32] = oe, e[33] = b, e[34] = T) : T = e[34], T
}
const Yd = Ts(() => vs(() =>
        import ("./nxteivgso0c74ef2.js"), __vite__mapDeps([12, 1, 3, 4, 2, 5, 13, 14])).then(t => t.ConnectorsOnboardingModal)),
    xr = 6,
    Vy = new Date("2025-11-24T00:00:00.000Z"),
    qy = (t, e = !1, {
        systemHintType: o
    } = {}) => {
        const a = t.some(s => !s.disabled),
            l = e ? [...t] : a ? t.filter(s => !s.disabled) : [...t],
            i = $t(o),
            d = i ? new Set(wu()) : null,
            b = s => !d || !s.connectorType ? 0 : d.has(s.connectorType) ? 1 : 0;
        return l.sort((s, m) => {
            if (s.connected && !m.connected) return -1;
            if (!s.connected && m.connected) return 1;
            if (s != null && s.isAutoConnected && !(m != null && m.isAutoConnected) || s.type === "cloud" && m.type !== "cloud") return -1;
            if (s.type !== "cloud" && m.type === "cloud") return 1;
            if (s.type === "web" && m.type !== "web") return -1;
            if (s.type !== "web" && m.type === "web" || e && s.disabled && !m.disabled) return 1;
            if (e && !s.disabled && m.disabled || s.isEcosystemConnector && !m.isEcosystemConnector) return -1;
            if (!s.isEcosystemConnector && m.isEcosystemConnector) return 1;
            if (i && !s.connected && !m.connected) {
                const x = b(s),
                    C = b(m);
                if (x !== C) return C - x
            }
            return s.name.localeCompare(m.name)
        }), l
    },
    Er = t => {
        window.open(t, "", "noopener,noreferrer")
    };

function Os(t) {
    switch (t.user_connection_details.activation_status) {
        case "activated":
        case "partially_activated":
            return !0;
        case "activating":
        case "inactive":
            return !1
    }
}

function Ky(t) {
    return t.user_connection_details.auth_status === "admin_connected" || t.user_connection_details.auth_status === "user_connected"
}
const Jy = new Set(["slack_sync_connector", "github_sync_connector", "notion_sync_connector", "sharepoint_admin_sync_connector", "teams_admin_sync_connector", "confluence_sync_connector", "jira_sync_connector", "jira_servicemanagement_sync_connector"]),
    Qy = t => {
        "use forget";
        var Bt, Ee, $e, lt, He, jt;
        const e = Et.c(182),
            {
                isLoading: o,
                clientThreadId: a,
                enabledConnectors: l,
                enabledEcosystemConnectors: i,
                includeWebSearch: d,
                includeCloudBrowser: b,
                includeSyncConnectors: s,
                connectorFilterFn: m,
                connectorConfigMap: x,
                fetchValidLinksOnly: C,
                systemHintType: u,
                selectedSources: c,
                selectedMCPSources: g,
                showConnectMore: y,
                toggleSource: S,
                contentRef: v,
                isDeveloperMode: j,
                defaultAutoConnectors: M
            } = t,
            h = o === void 0 ? !1 : o,
            w = d === void 0 ? !0 : d,
            P = b === void 0 ? !1 : b,
            R = s === void 0 ? !1 : s,
            D = y === void 0 ? !0 : y,
            E = Ke();
        let A;
        e[0] !== c ? (A = c == null ? void 0 : c.has("cloud"), e[0] = c, e[1] = A) : A = e[1];
        const G = !!A;
        let k;
        e[2] === Symbol.for("react.memo_cache_sentinel") ? (k = So(), e[2] = k) : k = e[2];
        const N = k;
        let q;
        e[3] !== E ? (q = () => As(E), e[3] = E, e[4] = q) : q = e[4];
        const V = fe(q),
            re = u === ue.Agent,
            K = P && re && N && !G,
            I = Gt(),
            r = xu(),
            {
                openSettings: oe
            } = g1(),
            T = Ht(a, Zy);
        let ge;
        e[5] !== r || e[6] !== j ? (ge = (r == null ? void 0 : r.isWorkspacePlan()) && j, e[5] = r, e[6] = j, e[7] = ge) : ge = e[7];
        const Ce = ge,
            X = !j || T === !1 && !Ce,
            B = T === !0 && !Ce;
        let Z;
        e[8] !== C ? (Z = {
            fetchValidLinksOnly: C
        }, e[8] = C, e[9] = Z) : Z = e[9];
        const {
            connectorLinks: L,
            isLoading: p
        } = gu(Z);
        let se;
        e[10] !== E ? (se = Oc(E), e[10] = E, e[11] = se) : se = e[11];
        const Me = se;
        let Be;
        e[12] !== E || e[13] !== R ? (Be = () => Uc.if$(E, R), e[12] = E, e[13] = R, e[14] = Be) : Be = e[14];
        const {
            data: Ie,
            isLoading: be
        } = fe(Be);
        let ve;
        if (e[15] !== (Ie == null ? void 0 : Ie.connection_statuses) || e[16] !== m) {
            e: {
                const je = Nc((Bt = Ie == null ? void 0 : Ie.connection_statuses) != null ? Bt : [], eb);
                if (m) {
                    ve = (Ee = je == null ? void 0 : je.filter(Ye => m(Ye.user_connection_details.connection_type))) != null ? Ee : [];
                    break e
                }
                ve = je != null ? je : []
            }
            e[15] = Ie == null ? void 0 : Ie.connection_statuses,
            e[16] = m,
            e[17] = ve
        }
        else ve = e[17];
        const ce = ve;
        let Ne;
        e[18] !== ce ? (Ne = new Set(ce.map(tb).filter(sb)), e[18] = ce, e[19] = Ne) : Ne = e[19];
        const et = Ne;
        let tt;
        e[20] !== ce ? (tt = ce.some(nb), e[20] = ce, e[21] = tt) : tt = e[21];
        const de = tt;
        let Ge;
        e[22] !== ce ? (Ge = ce.some(ob), e[22] = ce, e[23] = Ge) : Ge = e[23];
        const De = Ge;
        let te;
        e[24] !== i ? (te = new Set((i != null ? i : []).map(ab)), e[24] = i, e[25] = te) : te = e[25];
        const Pe = te;
        let Re;
        if (e[26] !== l || e[27] !== Pe) {
            let je;
            e[29] !== Pe ? (je = Ye => {
                var _;
                return !((_ = Ye.branding) != null && _.is_discoverable_app) || Ye.conformance.implements_retrievable || typeof Ye.type == "string" && Pe.has(Ye.type)
            }, e[29] = Pe, e[30] = je) : je = e[30], Re = l.filter(je), e[26] = l, e[27] = Pe, e[28] = Re
        } else Re = e[28];
        const We = Re;
        let ee;
        e: {
            if (!R) {
                let we;
                e[31] !== x || e[32] !== L || e[33] !== We ? (we = {
                    enabledConnectors: We,
                    connectorConfigMap: x,
                    connectorLinks: L
                }, e[31] = x, e[32] = L, e[33] = We, e[34] = we) : we = e[34], ee = we;
                break e
            }
            const je = ks[nt.GDRIVE_ACTION_CONNECTOR];
            let Ye;e[35] !== L ? (Ye = L.has(je), e[35] = L, e[36] = Ye) : Ye = e[36];
            const _ = Ye;
            let xe;e[37] !== ce ? (xe = ce.some(ib), e[37] = ce, e[38] = xe) : xe = e[38];
            const U = xe;
            let ae;e[39] !== ce ? (ae = ce.some(rb), e[39] = ce, e[40] = ae) : ae = e[40];
            const ut = ae;
            let Je, me, Ve;
            if (e[41] !== x || e[42] !== L || e[43] !== We || e[44] !== ut || e[45] !== _ || e[46] !== U || e[47] !== de || e[48] !== De || e[49] !== I || e[50] !== ce) {
                if (Ve = [...We], Je = new Map(x), me = new Map(L), _ && !Ve.some(lb) && !U) {
                    Ve.push({
                        id: ks[nt.GDRIVE_ACTION_CONNECTOR],
                        type: nt.GDRIVE_ACTION_CONNECTOR,
                        name: "Google Drive",
                        description: "",
                        logo_url: h1,
                        connector_type: "SERVICE",
                        service: "",
                        base_url: null,
                        actions: [],
                        supported_auth: [],
                        owners: [],
                        access_list: [],
                        conformance: {
                            implements_retrievable: !0
                        }
                    });
                    let we;
                    e[54] !== I ? (we = I.formatMessage(Jt.contactAdmin), e[54] = I, e[55] = we) : we = e[55];
                    let qe;
                    e[56] !== we ? (qe = {
                        disabled: !0,
                        disabledText: we,
                        hasBetaTag: !1
                    }, e[56] = we, e[57] = qe) : qe = e[57], Je.set(nt.GDRIVE_ACTION_CONNECTOR, qe), me.delete(je)
                } else ut && (Ve = Ve.filter(we => {
                    var qe;
                    if (we.type === nt.GDRIVE_ACTION_CONNECTOR) {
                        const Qe = (qe = me.get(we.id)) == null ? void 0 : qe[0];
                        if (ce.some(Fe => Fe.user_connection_details.backing_link_id === (Qe == null ? void 0 : Qe.id)) || we.type === nt.GDRIVE_ACTION_CONNECTOR) return !1
                    }
                    return !0
                }));
                ce.forEach(we => {
                    Os(we) && we.user_connection_details.backing_link_id ? me.forEach((qe, Qe) => {
                        qe.some(Fe => Fe.id === we.user_connection_details.backing_link_id) && (Ve = Ve.filter(Fe => Fe.id !== Qe))
                    }) : de ? Ve = Ve.filter(cb) : De && (Ve = Ve.filter(db))
                }), e[41] = x, e[42] = L, e[43] = We, e[44] = ut, e[45] = _, e[46] = U, e[47] = de, e[48] = De, e[49] = I, e[50] = ce, e[51] = Je, e[52] = me, e[53] = Ve
            } else Je = e[51],
            me = e[52],
            Ve = e[53];
            let ct;e[58] !== Je || e[59] !== me || e[60] !== Ve ? (ct = {
                enabledConnectors: Ve,
                connectorConfigMap: Je,
                connectorLinks: me
            }, e[58] = Je, e[59] = me, e[60] = Ve, e[61] = ct) : ct = e[61],
            ee = ct
        }
        const {
            enabledConnectors: Se,
            connectorConfigMap: J,
            connectorLinks: pe
        } = ee;
        let he;
        e[62] !== Se ? (he = Se.some(ub), e[62] = Se, e[63] = he) : he = e[63];
        const ye = he;
        let ke;
        e[64] !== E || e[65] !== ye ? (ke = () => ({
            data: void 0,
            isLoading: !1,
            isSuccess: !1,
            error: void 0
        }), e[64] = E, e[65] = ye, e[66] = ke) : ke = e[66];
        const Le = fe(ke);
        let ne;
        if (e[67] !== L || e[68] !== We || e[69] !== Me || e[70] !== Pe || e[71] !== a || e[72] !== J || e[73] !== m || e[74] !== pe || e[75] !== v || e[76] !== E || e[77] !== M || e[78] !== B || e[79] !== X || e[80] !== Se || e[81] !== de || e[82] !== De || e[83] !== K || e[84] !== P || e[85] !== R || e[86] !== w || e[87] !== I || e[88] !== G || e[89] !== g || e[90] !== c || e[91] !== Le || e[92] !== ce || e[93] !== et || e[94] !== u || e[95] !== S) {
            const je = [];
            if (w && !K) {
                let _;
                e[97] !== c ? (_ = c == null ? void 0 : c.has("web"), e[97] = c, e[98] = _) : _ = e[98];
                let xe;
                e[99] !== S ? (xe = () => {
                    S("web")
                }, e[99] = S, e[100] = xe) : xe = e[100];
                let U;
                e[101] !== I ? (U = I.formatMessage(Jt.webSearch), e[101] = I, e[102] = U) : U = e[102];
                let ae;
                e[103] !== B || e[104] !== _ || e[105] !== xe || e[106] !== U ? (ae = n.jsx(Pt.CheckboxItem, {
                    icon: Vu,
                    disabled: B,
                    checked: _,
                    onCheckedChange: xe,
                    children: U
                }), e[103] = B, e[104] = _, e[105] = xe, e[106] = U, e[107] = ae) : ae = e[107], je.push({
                    connected: !0,
                    type: "web",
                    name: "web",
                    element: ae
                })
            }
            if (P) {
                let _;
                e[108] !== S ? (_ = () => {
                    S("cloud")
                }, e[108] = S, e[109] = _) : _ = e[109];
                let xe;
                e[110] !== I ? (xe = I.formatMessage(Jt.cloudBrowser), e[110] = I, e[111] = xe) : xe = e[111];
                let U;
                e[112] !== B || e[113] !== G || e[114] !== _ || e[115] !== xe ? (U = n.jsx(Pt.CheckboxItem, {
                    icon: qu,
                    disabled: B,
                    checked: G,
                    onCheckedChange: _,
                    children: xe
                }), e[112] = B, e[113] = G, e[114] = _, e[115] = xe, e[116] = U) : U = e[116], je.push({
                    connected: !0,
                    type: "cloud",
                    name: "cloud",
                    element: U
                })
            }
            if (R && !K && ce.forEach(_ => {
                    var Ve, ct, we, qe, Qe;
                    if (m && !m(_.user_connection_details.connection_type)) return;
                    const xe = (Ve = J == null ? void 0 : J.get("sync_connector")) == null ? void 0 : Ve.disabled,
                        U = _.user_connection_details.backing_link_id,
                        ae = U ? [...pe.keys()].find(Fe => {
                            var xt;
                            return (xt = pe.get(Fe)) == null ? void 0 : xt.some(vt => vt.id === U)
                        }) : null,
                        ut = ae ? (ct = pe.get(ae)) == null ? void 0 : ct.find(Fe => Fe.id === U) : void 0,
                        Je = ae ? (we = We.find(Fe => Fe.id === ae)) == null ? void 0 : we.type : null;
                    if (_.user_connection_details.connection_type === "gdrive_sync_connector" && !Os(_)) return;
                    if (!Os(_) && _.user_connection_details.backing_link_id && Je) return;
                    if (_.user_connection_details.connection_type === "github_sync_connector") return;
                    if (!Ky(_) && !Jy.has(_.user_connection_details.connection_type)) return;
                    if (de && _.user_connection_details.connection_type === "sharepoint_sync_connector") return;
                    if (De && _.user_connection_details.connection_type === "teams_sync_connector" || _.user_connection_details.auth_status === "admin_managed_disconnected") return;
                    const me = _.user_connection_details.auth_status === "admin_connected" ? _.user_connection_details.activation_status !== "inactive" : _.user_connection_details.auth_status !== "not_connected";
                    je.push({
                        connected: me,
                        type: "sync",
                        name: Pr(_),
                        connectorType: _.user_connection_details.connection_type,
                        element: n.jsx(rp, {
                            connection: _,
                            disabled: xe,
                            disabledText: xe ? (qe = J == null ? void 0 : J.get("sync_connector")) == null ? void 0 : qe.disabledText : void 0,
                            backingLinkCreatedAt: ut == null ? void 0 : ut.created_at,
                            isSelectedInSource: (Qe = c == null ? void 0 : c.has(_.user_connection_details.connection_type)) != null ? Qe : !1,
                            location: "user_dropdown",
                            refetch: () => hd(E),
                            showDetails: et.has(_.user_connection_details.connection_type),
                            toggleSource: Fe => {
                                Je && c.has(Je) && S(Je), S(Fe)
                            }
                        }, _.user_connection_details.connection_instance_id)
                    })
                }), c && !K && Se.forEach(_ => {
                    var ae, ut, Je, me, Ve, ct, we, qe;
                    const U = !!((ae = pe.get(_.id)) == null ? void 0 : ae[0]);
                    if (_.type === Su.MCP_CONNECTOR) je.push({
                        connected: U,
                        type: "access",
                        name: _.name,
                        connectorType: _.type,
                        element: n.jsx(Yy, {
                            connector: _,
                            connectorLinks: pe,
                            selectedMCPSources: g,
                            toggleSource: S,
                            systemHintType: u,
                            disabled: _.status === "ONLY_ME" && X || _.status !== "ONLY_ME" && B
                        })
                    });
                    else {
                        let Qe = B || ((Je = (ut = J == null ? void 0 : J.get(_.type)) == null ? void 0 : ut.disabled) != null ? Je : !1),
                            Fe = Qe ? (me = J == null ? void 0 : J.get(_.type)) == null ? void 0 : me.disabledText : void 0;
                        if (_.status === "DISABLED_BY_ADMIN" && (Qe = !0, Fe = I.formatMessage(_d.disabledByAdmin)), _.type === nt.GITHUB_CONNECTOR) return;
                        const xt = Me.includes(_.type) && u === ue.Slurm,
                            vt = M == null ? void 0 : M.includes(_.type),
                            Wt = typeof _.type == "string" && Pe.has(_.type) && !!((Ve = _.branding) != null && Ve.is_discoverable_app) && !_.conformance.implements_retrievable;
                        je.push({
                            connected: U,
                            disabled: Qe,
                            type: "access",
                            name: _.name,
                            isAutoConnected: xt || vt,
                            connectorType: _.type,
                            isEcosystemConnector: Wt,
                            element: n.jsx(ip, {
                                connector: _,
                                connectorLink: (ct = pe.get(_.id)) == null ? void 0 : ct[0],
                                disabled: Qe,
                                disabledText: Fe,
                                hasBetaTag: (we = J == null ? void 0 : J.get(_.type)) == null ? void 0 : we.hasBetaTag,
                                isSelectedInSource: (qe = c.has(_.type)) != null ? qe : !1,
                                systemHintType: u,
                                toggleSource: S,
                                isDefaultAutoConnected: vt
                            })
                        })
                    }
                }), !K) {
                let _;
                e[117] !== We || e[118] !== c ? (_ = c && We.find(pb), e[117] = We, e[118] = c, e[119] = _) : _ = e[119];
                let xe = _;
                m && !m(nt.GITHUB_CONNECTOR) && (xe = void 0);
                let U;
                e[120] !== R || e[121] !== ce ? (U = R ? ce.find(mb) : void 0, e[120] = R, e[121] = ce, e[122] = U) : U = e[122];
                const ae = U;
                if (xe || ae) {
                    const ut = ae && ae.user_connection_details.auth_status !== "not_connected" && ae.user_connection_details.activation_status !== "inactive";
                    let Je;
                    e[123] !== L ? (Je = ($e = L.get(Im)) == null ? void 0 : $e[0], e[123] = L, e[124] = Je) : Je = e[124];
                    const me = Je,
                        Ve = xe && !!me;
                    let ct;
                    e[125] !== J || e[126] !== B ? (ct = B || ((He = (lt = J == null ? void 0 : J.get(nt.GITHUB_CONNECTOR)) == null ? void 0 : lt.disabled) != null ? He : !1), e[125] = J, e[126] = B, e[127] = ct) : ct = e[127];
                    let we = ct,
                        qe;
                    e[128] !== J || e[129] !== we ? (qe = we ? (jt = J == null ? void 0 : J.get(nt.GITHUB_CONNECTOR)) == null ? void 0 : jt.disabledText : void 0, e[128] = J, e[129] = we, e[130] = qe) : qe = e[130];
                    let Qe = qe;
                    if ((xe == null ? void 0 : xe.status) === "DISABLED_BY_ADMIN") {
                        we = !0;
                        let vt;
                        e[131] !== I ? (vt = I.formatMessage(_d.disabledByAdmin), e[131] = I, e[132] = vt) : vt = e[132], Qe = vt
                    }
                    let Fe;
                    e[133] !== E ? (Fe = () => hd(E), e[133] = E, e[134] = Fe) : Fe = e[134];
                    let xt;
                    e[135] !== a || e[136] !== me || e[137] !== v || e[138] !== Qe || e[139] !== we || e[140] !== xe || e[141] !== ae || e[142] !== c || e[143] !== u || e[144] !== Fe || e[145] !== S ? (xt = n.jsx(Xy, {
                        clientThreadId: a,
                        githubSyncConnection: ae,
                        githubAccessConnector: xe,
                        connectorLink: me,
                        selectedSources: c,
                        toggleSource: S,
                        systemHintType: u,
                        refetch: Fe,
                        contentRef: v,
                        disabled: we,
                        disabledText: Qe
                    }), e[135] = a, e[136] = me, e[137] = v, e[138] = Qe, e[139] = we, e[140] = xe, e[141] = ae, e[142] = c, e[143] = u, e[144] = Fe, e[145] = S, e[146] = xt) : xt = e[146], je.push({
                        disabled: we,
                        connected: !!ut || !!Ve,
                        type: ut ? "sync" : "access",
                        name: "GitHub",
                        connectorType: nt.GITHUB_CONNECTOR,
                        element: xt
                    })
                }
            }
            ne = qy(je, B || X, {
                systemHintType: u
            }).reduce(fb, [
                [],
                []
            ]), e[67] = L, e[68] = We, e[69] = Me, e[70] = Pe, e[71] = a, e[72] = J, e[73] = m, e[74] = pe, e[75] = v, e[76] = E, e[77] = M, e[78] = B, e[79] = X, e[80] = Se, e[81] = de, e[82] = De, e[83] = K, e[84] = P, e[85] = R, e[86] = w, e[87] = I, e[88] = G, e[89] = g, e[90] = c, e[91] = Le, e[92] = ce, e[93] = et, e[94] = u, e[95] = S, e[96] = ne
        } else ne = e[96];
        const [Te, it] = ne;
        let z;
        e[147] !== Te || e[148] !== it ? (z = {
            connectedRows: Te,
            disconnectedRows: it
        }, e[147] = Te, e[148] = it, e[149] = z) : z = e[149];
        const {
            connectedRows: $,
            disconnectedRows: le
        } = z;
        let Q;
        e: {
            if ($t(u)) {
                let je;
                e[150] === Symbol.for("react.memo_cache_sentinel") ? (je = new Set(wu()), e[150] = je) : je = e[150];
                const Ye = je;
                let _;
                if (e[151] !== le || e[152] !== Ye) {
                    let xe;
                    e[154] !== Ye ? (xe = U => {
                        var ae;
                        return Ye.has((ae = U.connectorType) != null ? ae : "")
                    }, e[154] = Ye, e[155] = xe) : xe = e[155], _ = le.filter(xe), e[151] = le, e[152] = Ye, e[153] = _
                } else _ = e[153];
                Q = Math.max(xr - $.length, _.length);
                break e
            }
            Q = xr - $.length
        }
        const _e = Q;
        if (!a || !c) return null;
        if (be || p || h) {
            let je;
            return e[156] === Symbol.for("react.memo_cache_sentinel") ? (je = n.jsx("div", {
                className: "w-50 px-4",
                children: n.jsx(Nm, {
                    lines: 5,
                    size: "lg",
                    widthVariance: 0,
                    width: 100
                })
            }), e[156] = je) : je = e[156], je
        }
        const Ae = $.length > xr,
            yt = Ae && "border-token-border-secondary mb-1.5 border-b";
        let ze;
        e[157] !== yt ? (ze = Ct(yt, "overflow-y-auto"), e[157] = yt, e[158] = ze) : ze = e[158];
        let ot;
        e[159] !== Ae ? (ot = Ae ? {
            maxHeight: "calc(2.25rem * ".concat(xr + .5, ")")
        } : void 0, e[159] = Ae, e[160] = ot) : ot = e[160];
        let rt;
        e[161] !== $ ? (rt = $.map(gb), e[161] = $, e[162] = rt) : rt = e[162];
        let st;
        e[163] !== ze || e[164] !== ot || e[165] !== rt ? (st = n.jsx("div", {
            className: ze,
            style: ot,
            children: rt
        }), e[163] = ze, e[164] = ot, e[165] = rt, e[166] = st) : st = e[166];
        let Y;
        e[167] !== _e || e[168] !== le ? (Y = le.length > 0 && _e > 0 && n.jsx(n.Fragment, {
            children: le.slice(0, _e).map(hb)
        }), e[167] = _e, e[168] = le, e[169] = Y) : Y = e[169];
        let bt;
        e[170] !== E || e[171] !== K || e[172] !== I || e[173] !== V || e[174] !== oe || e[175] !== D || e[176] !== u ? (bt = D && !K && n.jsx(Pt.Item, {
            icon: Ku,
            onPointerOver: () => {
                $t(u) && Yd.prefetch()
            },
            onSelect: () => {
                Ze.logEventWithStatsig("chatgpt_connectors_dropdown_connect_more_clicked", "chatgpt_connectors_dropdown_connect_more_clicked"), V ? Er(Dm) : $t(u) ? Zn(E, Yd, {}) : oe(uu.Connectors)
            },
            children: I.formatMessage(Jt.connectApps)
        }), e[170] = E, e[171] = K, e[172] = I, e[173] = V, e[174] = oe, e[175] = D, e[176] = u, e[177] = bt) : bt = e[177];
        let Ut;
        return e[178] !== st || e[179] !== Y || e[180] !== bt ? (Ut = n.jsxs("div", {
            className: "w-70",
            children: [st, Y, bt]
        }), e[178] = st, e[179] = Y, e[180] = bt, e[181] = Ut) : Ut = e[181], Ut
    },
    ho = ({
        isLoading: t = !1,
        clientThreadId: e,
        enabledConnectors: o,
        enabledEcosystemConnectors: a,
        trigger: l,
        includeWebSearch: i,
        includeCloudBrowser: d,
        selectedSources: b,
        selectedMCPSources: s,
        addSource: m,
        deleteSource: x,
        toggleSource: C,
        includeSyncConnectors: u = !1,
        connectorFilterFn: c,
        connectorConfigMap: g,
        fetchValidLinksOnly: y,
        systemHintType: S,
        showConnectMore: v = !0,
        isDeveloperMode: j,
        defaultAutoConnectors: M
    }) => {
        const h = Ke(),
            {
                refetch: w
            } = gu({
                fetchValidLinksOnly: y
            }),
            P = hu(),
            R = $t(S) ? _u(h) : !0,
            E = Ht(e, K => K == null ? void 0 : K.startedWithByoMcp) === !0,
            A = So(),
            G = b == null ? void 0 : b.has("cloud"),
            k = S === ue.Agent && A && !G,
            N = F.useRef(null),
            q = F.useMemo(() => {
                const K = a != null ? a : [],
                    I = new Set(K.map(oe => oe.id)),
                    r = o.filter(oe => !I.has(oe.id));
                return [...K, ...r]
            }, [o, a]),
            V = F.useRef(!1),
            re = F.useRef(!1);
        return F.useEffect(() => {
            var I, r;
            const K = ((I = b == null ? void 0 : b.size) != null ? I : 0) + ((r = s == null ? void 0 : s.size) != null ? r : 0);
            i && !V.current && K === 0 && !E && (m("web"), V.current = !0)
        }, [b, s, m, E, i]), F.useEffect(() => {
            k && !(b != null && b.has("web")) && m("web")
        }, [m, b, k]), n.jsxs(Pt.Root, {
            "data-testid": "sources-pill",
            onOpenChange: K => {
                var I, r;
                if (K) re.current || (Am.logEntryPointShown({
                    referrer: wo.SourcesDropdown
                }), re.current = !0), w();
                else {
                    !u1(p1(Cc(e), Ar)) && R && (x(nt.GITHUB_CONNECTOR), P && x("github_sync_connector"));
                    const T = ((I = b == null ? void 0 : b.size) != null ? I : 0) + ((r = s == null ? void 0 : s.size) != null ? r : 0) === 0;
                    i && T && !E && m("web")
                }
            },
            children: [l, n.jsx(Pt.Portal, {
                children: n.jsx(Pt.Content, {
                    alignOffset: -7,
                    size: "auto",
                    ref: N,
                    children: n.jsx(Qy, {
                        isLoading: t,
                        clientThreadId: e,
                        enabledConnectors: q,
                        enabledEcosystemConnectors: a,
                        includeWebSearch: i,
                        includeCloudBrowser: d,
                        includeSyncConnectors: u,
                        connectorFilterFn: c,
                        connectorConfigMap: g,
                        fetchValidLinksOnly: y,
                        systemHintType: S,
                        selectedSources: b,
                        selectedMCPSources: s,
                        showConnectMore: v,
                        toggleSource: C,
                        contentRef: N,
                        isDeveloperMode: j,
                        defaultAutoConnectors: M
                    })
                })
            })]
        })
    },
    Sr = 3,
    _o = ({
        includeSyncConnectors: t,
        includeWebSearch: e,
        connectorFilterFn: o,
        selectedSources: a,
        selectedMCPSources: l,
        isDeveloperMode: i
    }) => {
        var G;
        const d = Ke(),
            b = Gt(),
            s = yu(),
            m = fe(() => bu(d, {
                productSku: kc.PROMPT_TEXT_AREA
            })),
            x = m === void 0,
            {
                data: C,
                isLoading: u
            } = fe(() => Uc.if$(d, t)),
            c = x || u,
            g = e ? a != null && a.has("web") ? n.jsx(Vu, {
                className: "icon"
            }) : n.jsx(m1, {
                className: "icon"
            }) : void 0,
            y = a != null && a.has("cloud") ? n.jsx(qu, {
                className: "icon"
            }) : void 0,
            S = [...a != null ? a : []].filter(k => k !== "web" && k !== "cloud").filter(k => o ? o(k) : !0).map(k => {
                const N = m == null ? void 0 : m.find(q => q.type === k);
                return N ? {
                    name: N.name,
                    icon: n.jsx(Co, {
                        connector: N,
                        size: "xsmall"
                    })
                } : null
            }).filter(k => !!k),
            v = t ? Array.from(new Map(((G = C == null ? void 0 : C.connection_statuses) != null ? G : []).filter(k => Os(k) && (o ? o(k.user_connection_details.connection_type) : !0) && (a == null ? void 0 : a.has(k.user_connection_details.connection_type))).map(k => {
                var N;
                return [k.user_connection_details.connection_type, {
                    name: Pr(k),
                    icon: n.jsx("img", {
                        src: s && k.connection_display_info.icon_dark_url ? k.connection_display_info.icon_dark_url : (N = k.connection_display_info.icon_url) != null ? N : "",
                        alt: k.connection_display_info.display_name,
                        className: "icon"
                    })
                }]
            })).values()) : [],
            j = Array.from(l != null ? l : []).map(k => {
                const N = m == null ? void 0 : m.find(q => q.id === k);
                return N ? {
                    name: N.name,
                    icon: n.jsx(Co, {
                        connector: N,
                        size: "xsmall"
                    })
                } : null
            }).filter(k => !!k),
            M = Nc([...j, ...S, ...v].reverse(), k => k.name).reverse();
        M.sort((k, N) => k.name.localeCompare(N.name));
        const h = [...g ? [{
                name: "web",
                icon: g
            }] : [], ...y ? [{
                name: "cloud",
                icon: y
            }] : [], ...M],
            w = h.length > Sr ? [...h.slice(0, Sr - 1), {
                name: "__plus_overflow",
                icon: n.jsx("span", {
                    className: "text-token-text-secondary bg-token-bg-secondary text-caption-regular flex h-4.5 w-4.5 items-center justify-center rounded-full",
                    children: h.length - Sr + 1
                }, "more")
            }] : h,
            R = F.useMemo(() => eu(d, "3282868491"), [d]).get("short_text", "Connectors"),
            D = R === "Sources" ? b.formatMessage({
                id: "hocZEX",
                defaultMessage: "Add"
            }) : b.formatMessage({
                id: "UjEzZf",
                defaultMessage: "Add sources"
            }),
            E = R === "Sources" ? null : b.formatMessage({
                id: "DhW8Wx",
                defaultMessage: "Sources"
            }),
            A = w.length === 0 && !c ? D : E;
        return n.jsx(Pt.BasicTrigger, {
            asChild: !0,
            children: n.jsxs("button", {
                type: "button",
                className: Ct("composer-btn px-2", i && w.length > 0 && "rounded-full bg-orange-400/10 hover:bg-orange-400/20"),
                children: [w.length > 0 && !c ? n.jsx("div", {
                    className: "flex items-center gap-1",
                    children: w.map(k => n.jsx("div", {
                        className: "icon flex items-center justify-center",
                        children: k.icon
                    }, k.name))
                }) : n.jsx(Ku, {
                    className: "icon"
                }), i && w.length > 0 ? n.jsx("span", {
                    className: "ms-1.5 text-orange-400 [[data-collapse-labels]_&]:sr-only",
                    children: w.length === 1 ? w[0].name : n.jsx(Ls, {
                        id: "+Fsfxz",
                        defaultMessage: "Multiple Connectors"
                    })
                }) : (w.length < Sr || c) && A && n.jsx("span", {
                    className: "ms-1.5 [[data-collapse-labels]_&]:sr-only",
                    children: A
                }), n.jsx(f1, {
                    className: "icon-sm xs:ms-1.5 ms-1"
                })]
            })
        })
    },
    ip = ({
        connector: t,
        connectorLink: e,
        disabled: o = !1,
        disabledText: a = "",
        hasBetaTag: l = !1,
        isSelectedInSource: i,
        systemHintType: d,
        toggleSource: b,
        isDefaultAutoConnected: s = !1
    }) => {
        var G;
        const m = Ke(),
            x = Gt(),
            C = zc(),
            u = Oc(m),
            c = Fc(m),
            g = fe(() => As(m)),
            y = k => {
                g ? Er(Hc(k)) : C(k)
            },
            S = !!e,
            v = i && S,
            j = u.includes(t.type) && d === ue.Slurm || !c && $t(d) || s;
        if (t.type === Su.MCP_CONNECTOR) return null;
        const M = (G = Bm[t.type]) == null ? void 0 : G.title,
            h = M ? x.formatMessage(M) : t.name,
            w = n.jsx(Co, {
                connector: t,
                size: "xsmall"
            }),
            P = n.jsxs("div", {
                className: "flex items-center gap-2",
                children: [n.jsx("span", {
                    className: "truncate",
                    children: h
                }), l && n.jsx(x1, {})]
            }),
            R = !1,
            D = o;
        let E;
        S ? j ? E = n.jsx(Pt.Item, {
            disabled: D,
            label: P,
            onSelect: () => {
                window.location.href = y1(t.type)
            },
            icon: w,
            trailing: n.jsx("div", {
                className: "border-token-text-quartenary text-token-text-secondary dark:border-token-border-heavy dark:text-token-text-tertiary items-center rounded-full border px-1 py-0.5 text-[8px] leading-3 font-semibold uppercase",
                children: x.formatMessage(Jt.auto)
            })
        }) : E = n.jsx(Pt.CheckboxItem, {
            disabled: o,
            label: P,
            icon: w,
            checked: v,
            onCheckedChange: () => {
                b(t.type)
            }
        }) : E = n.jsx(Pt.Item, {
            disabled: o || R,
            onSelect: () => {
                y({
                    connectorId: t.id,
                    redirectAfter: $t(d) ? "/?system_hints=".concat(d, "&select_connector_id=").concat(t.id) : d ? "/?system_hints=".concat(d) : void 0,
                    systemHintType: d,
                    referrer: wo.SourcesDropdown
                })
            },
            label: P,
            icon: w,
            trailing: o || R ? void 0 : n.jsx("div", {
                className: "text-token-text-tertiary",
                children: x.formatMessage(Jt.connect)
            })
        });
        let A = null;
        return j ? S || !o ? A = x.formatMessage(Jt.autoConnected) : A = a || x.formatMessage(Jt.autoConnectorDisabled) : o && (A = a), n.jsx(n.Fragment, {
            children: (o || j && S) && A ? n.jsx(vr, {
                label: A,
                side: "right",
                align: "center",
                contentClassName: "w-50",
                children: E
            }) : E
        })
    },
    Yy = ({
        connector: t,
        connectorLinks: e,
        selectedMCPSources: o,
        toggleSource: a,
        systemHintType: l,
        disabled: i = !1
    }) => {
        var v;
        const d = Ke(),
            b = Gt(),
            s = zc(),
            m = fe(() => As(d));
        if (!t.conformance.implements_retrievable && (l === ue.Research || l === ue.Slurm)) return null;
        const C = !!((v = e.get(t.id)) == null ? void 0 : v[0]),
            u = o.has(t.id) && C,
            c = t.name,
            g = n.jsxs("div", {
                className: "flex items-center gap-2",
                children: [n.jsx("span", {
                    className: "truncate",
                    children: c
                }), n.jsx(b1, {
                    connector: t
                })]
            }),
            y = n.jsx(Co, {
                connector: t,
                size: "xsmall"
            }),
            S = j => {
                m ? Er(Hc(j)) : s(j)
            };
        return n.jsx(n.Fragment, {
            children: C ? n.jsx(Pt.CheckboxItem, {
                icon: y,
                checked: u,
                label: g,
                disabled: i,
                onCheckedChange: () => {
                    a(t.id)
                }
            }) : n.jsx(Pt.Item, {
                onSelect: () => {
                    i || S({
                        connectorId: t.id,
                        redirectAfter: $t(l) ? "/?system_hints=".concat(l, "&select_connector_id=").concat(t.id) : l ? "/?system_hints=".concat(l) : void 0,
                        systemHintType: l,
                        referrer: wo.SourcesDropdown
                    })
                },
                icon: y,
                label: g,
                trailing: n.jsx("div", {
                    className: "text-token-text-tertiary",
                    children: b.formatMessage(Jt.connect)
                }),
                disabled: i
            })
        })
    },
    rp = ({
        connection: t,
        refetch: e,
        location: o,
        isSelectedInSource: a,
        toggleSource: l,
        showDetails: i,
        disabled: d = !1,
        disabledText: b = "",
        backingLinkCreatedAt: s
    }) => {
        var p;
        const m = Ke(),
            x = Fc(m),
            C = Gt(),
            u = yu(),
            [c, g] = F.useState(!1),
            [y, S] = F.useState(),
            v = Mo(),
            j = zc(),
            M = fe(() => As(m)),
            h = se => {
                M ? Er(Hc(se)) : j(se)
            },
            w = () => {
                l(t.user_connection_details.connection_type)
            },
            P = s === void 0 ? null : new Date(s),
            R = t.user_connection_details.connection_type === "asana_sync_connector" && P !== null && !Number.isNaN(P.getTime()) && P < Vy,
            D = C.formatMessage(Jt.asanaRelinkTooltip),
            E = n.jsxs("div", {
                className: "flex items-center gap-1.5",
                children: [n.jsx("span", {
                    className: "truncate",
                    children: Pr(t)
                }), R ? n.jsx(vr, {
                    align: "center",
                    label: D,
                    side: "right",
                    contentClassName: "w-50",
                    children: n.jsx(Pm, {
                        "aria-label": D,
                        className: "icon-sm text-token-icon-status-warning shrink-0"
                    })
                }) : null]
            }),
            A = t.user_connection_details.connection_instance_id,
            G = Cu(),
            k = Em(m),
            N = t.user_connection_details.knowledge_connector_type,
            q = N === "google_drive_oauth",
            V = t.user_connection_details.connection_type === "notion_sync_connector" && t.user_connection_details.connection_instance_id.startsWith("ks--merge"),
            re = $t(v) ? !x && ["activated", "partially_activated"].includes(t.user_connection_details.activation_status) : !1,
            K = F.useCallback(async () => {
                try {
                    g(!0), await jm({
                        connectorType: N,
                        connectionId: A,
                        location: o,
                        intl: C
                    })
                } catch (se) {
                    se instanceof Error ? G.danger(se.message, {
                        toastId: "sources_dropdown_oauth_error"
                    }) : G.danger({
                        defaultMessage: "Encountered an error connecting your account. Please try again later.",
                        description: "Error message shown when a user tries to link their account but it fails."
                    }, {
                        toastId: "sources_dropdown_oauth_error"
                    })
                } finally {
                    g(!1), e == null || e()
                }
            }, [A, N, C, o, e, G]),
            [I, r] = F.useState(!1),
            oe = () => {
                q ? $t(v) ? h({
                    connectorId: ks[nt.GDRIVE_ACTION_CONNECTOR],
                    redirectAfter: $t(v) ? "/?system_hints=".concat(v, "&select_connector_id=").concat(ks[nt.GDRIVE_ACTION_CONNECTOR]) : v ? "/?system_hints=".concat(v) : void 0,
                    systemHintType: v != null ? v : void 0,
                    referrer: wo.SourcesDropdown,
                    syncOnly: !0
                }) : r(!0) : V ? h({
                    connectorId: ks[nt.NOTION_CONNECTOR],
                    redirectAfter: $t(v) ? "/?system_hints=".concat(v, "&select_connector_id=").concat(ks[nt.NOTION_CONNECTOR]) : v ? "/?system_hints=".concat(v) : void 0,
                    systemHintType: v != null ? v : void 0,
                    referrer: wo.SourcesDropdown,
                    syncOnly: !0
                }) : K()
            },
            T = t.user_connection_details.activation_status === "inactive" && t.user_connection_details.auth_status === "not_connected",
            ge = ["activating", "partially_activated"].includes(t.user_connection_details.activation_status),
            Ce = T && !k || ge,
            X = n.jsx("img", {
                src: u && t.connection_display_info.icon_dark_url ? t.connection_display_info.icon_dark_url : (p = t.connection_display_info.icon_url) != null ? p : "",
                alt: t.connection_display_info.display_name,
                className: "icon"
            }),
            B = se => {
                if (se.stopPropagation(), se.preventDefault(), T) {
                    oe();
                    return
                }
                if (ge) {
                    S(t);
                    return
                }
            },
            Z = {
                key: t.connection_display_info.display_name,
                disabled: d,
                icon: X,
                label: E,
                secondary: i ? n.jsx("div", {
                    className: "truncate",
                    children: t.connection_display_info.display_name
                }) : void 0
            };
        re && (Z.trailing = n.jsx("div", {
            className: "border-token-text-quartenary text-token-text-secondary dark:border-token-border-heavy dark:text-token-text-tertiary items-center rounded-full border px-1 py-0.5 text-[8px] leading-3 font-semibold uppercase",
            children: C.formatMessage(Jt.auto)
        }));
        let L = null;
        switch (t.user_connection_details.activation_status) {
            case "activated":
                L = n.jsx(Pt.CheckboxItem, Bs(Rt({}, Z), {
                    checked: a,
                    onCheckedChange: w
                }));
                break;
            case "partially_activated":
                L = n.jsx(Pt.CheckboxItem, Bs(Rt({}, Z), {
                    checked: a,
                    onCheckedChange: w,
                    secondary: n.jsx("div", {
                        className: "group-radix-disabled:opacity-50 flex items-center gap-1.5",
                        children: n.jsx(Fm, {
                            className: "flex-row-reverse",
                            connection: t
                        })
                    })
                }));
                break;
            case "activating":
                L = n.jsx(Pt.Item, Bs(Rt({}, Z), {
                    style: {
                        cursor: Ce ? void 0 : "default"
                    },
                    onSelect: B,
                    trailing: n.jsx("div", {
                        className: "group-radix-disabled:opacity-50",
                        children: n.jsx(Om, {
                            connection: t
                        })
                    })
                }));
                break;
            case "inactive":
                L = n.jsx(Pt.Item, Bs(Rt({}, Z), {
                    style: {
                        cursor: Ce ? void 0 : "default"
                    },
                    onSelect: B,
                    trailing: n.jsx("div", {
                        className: "group-radix-disabled:opacity-50",
                        children: c ? n.jsx(Lm, {
                            className: "icon"
                        }) : n.jsx(Um, {
                            connection: t,
                            refetch: e,
                            location: "user_dropdown"
                        })
                    })
                }));
                break
        }
        return n.jsxs(n.Fragment, {
            children: [y && n.jsx(_1, {
                connection: y,
                onClose: () => S(void 0)
            }), I && n.jsx(Rm, {
                isAdminFlow: !1,
                onClose: () => r(!1),
                connectionId: A,
                location: o,
                onSuccess: e
            }), d && b ? n.jsx(vr, {
                label: b,
                side: "right",
                align: "center",
                contentClassName: "w-50",
                children: L
            }) : L]
        })
    },
    Xy = ({
        clientThreadId: t,
        githubSyncConnection: e,
        githubAccessConnector: o,
        connectorLink: a,
        selectedSources: l,
        toggleSource: i,
        systemHintType: d,
        refetch: b,
        contentRef: s,
        disabled: m,
        disabledText: x
    }) => {
        var A, G;
        const C = Ke(),
            u = Gt(),
            c = zm("installations/select_target"),
            g = hu(),
            y = $t(d) ? _u(C) : !0,
            v = Ht(t, k => k == null ? void 0 : k.startedWithByoMcp) === !0,
            {
                data: j,
                isLoading: M
            } = S1({
                linkId: (A = a == null ? void 0 : a.id) != null ? A : ""
            }),
            h = !!j,
            w = a == null ? void 0 : a.id,
            P = !!w && !h;
        if (!o && !e) return null;
        const R = k => {
                const N = k === "github_sync_connector",
                    q = k === nt.GITHUB_CONNECTOR;
                if ((N || q) && o && e) {
                    const V = l == null ? void 0 : l.has("github_sync_connector"),
                        re = l == null ? void 0 : l.has(nt.GITHUB_CONNECTOR);
                    V === re && i(N ? nt.GITHUB_CONNECTOR : "github_sync_connector")
                }
                i(k)
            },
            D = o ? n.jsx(Co, {
                connector: o,
                size: "xsmall"
            }) : e ? n.jsx("img", {
                src: (G = e.connection_display_info.icon_url) != null ? G : "",
                alt: e.connection_display_info.display_name,
                className: "icon"
            }) : null,
            E = o ? o.name : e ? Pr(e) : "";
        if (P && !M && y) return n.jsx(Pt.Item, {
            label: E,
            icon: D,
            onSelect: () => {
                window.open(c, "_blank")
            },
            trailing: n.jsx("div", {
                className: "text-token-text-tertiary",
                children: u.formatMessage(Jt.finishSetup)
            })
        });
        if (e && (Os(e) || !o)) {
            const k = l.has("github_sync_connector");
            return n.jsxs(n.Fragment, {
                children: [n.jsx(rp, {
                    connection: e,
                    refetch: b,
                    location: "user_dropdown",
                    isSelectedInSource: k,
                    toggleSource: R,
                    showDetails: !1,
                    disabled: M || m,
                    disabledText: x
                }, e.user_connection_details.connection_instance_id), k && g && y && n.jsx(Ud, {
                    clientThreadId: t,
                    allowSelectAllRepos: !1,
                    githubSyncEnabled: !0,
                    linkId: w,
                    syncConnectionId: e.user_connection_details.connection_instance_id,
                    contentRef: s,
                    selectionScope: Ar
                })]
            })
        } else if (o) {
            const k = l.has(nt.GITHUB_CONNECTOR);
            return n.jsxs(n.Fragment, {
                children: [n.jsx(ip, {
                    connector: o,
                    connectorLink: a,
                    disabled: v || m,
                    disabledText: x,
                    hasBetaTag: !1,
                    isSelectedInSource: k,
                    systemHintType: d,
                    toggleSource: R
                }), k && y && n.jsx(Ud, {
                    clientThreadId: t,
                    linkId: a == null ? void 0 : a.id,
                    allowSelectAllRepos: !1,
                    githubSyncEnabled: !1,
                    contentRef: s,
                    selectionScope: Ar
                })]
            })
        }
        return null
    },
    Jt = eo({
        contactAdmin: {
            id: "JGCH/x",
            defaultMessage: "Contact your admin to enable Google Drive for chat"
        },
        allRepositories: {
            id: "EzHFPp",
            defaultMessage: "All Repositories"
        },
        connect: {
            id: "OODbh3",
            defaultMessage: "Connect"
        },
        syncing: {
            id: "EQFkZV",
            defaultMessage: "Syncing"
        },
        connectOnMobileTooltip: {
            id: "Ey/eYm",
            defaultMessage: "Connect on your iPhone or iPad"
        },
        fetchingSyncStatus: {
            id: "mm1SP4",
            defaultMessage: "Fetching sync progress, please wait"
        },
        finishSetup: {
            id: "j12ad3",
            defaultMessage: "Finish Setup"
        },
        sourcesEnabled: {
            id: "aEIPI+",
            defaultMessage: "On"
        },
        webSearch: {
            id: "XoUbAe",
            defaultMessage: "Web search"
        },
        cloudBrowser: {
            id: "RA2J7e",
            defaultMessage: "Use cloud browser"
        },
        connectorsNeedCloudBrowserDisabledText: {
            id: "lm1ZXj",
            defaultMessage: "Connectors can only be enabled for cloud browser"
        },
        sourcesDisabled: {
            id: "j32+iI",
            defaultMessage: "Off"
        },
        connectApps: {
            id: "wwlf43",
            defaultMessage: "Connect more"
        },
        autoConnected: {
            id: "7IJBNd",
            defaultMessage: "This connector is searched automatically"
        },
        autoConnectorDisabled: {
            id: "KJQcAS",
            defaultMessage: "To enable this connector, toggle off all custom connectors"
        },
        auto: {
            id: "uW03xX",
            defaultMessage: "Auto"
        },
        asanaRelinkTooltip: {
            id: "q3vS7u",
            defaultMessage: "Reconnect your Asana account to refresh consent. Disconnect and reconnect to continue syncing."
        }
    });

function Zy(t) {
    return t == null ? void 0 : t.startedWithByoMcp
}

function eb(t) {
    return t.user_connection_details.connection_instance_id
}

function tb(t) {
    return t.user_connection_details.connection_type
}

function sb(t, e, o) {
    return o.indexOf(t) !== e
}

function nb(t) {
    return Os(t) && t.user_connection_details.connection_type === "sharepoint_admin_sync_connector"
}

function ob(t) {
    return Os(t) && t.user_connection_details.connection_type === "teams_admin_sync_connector"
}

function ab(t) {
    return t.type
}

function ib(t) {
    return t.user_connection_details.connection_type === "gdrive_sync_connector"
}

function rb(t) {
    return t.user_connection_details.connection_type === "gdrive_sync_connector" && Os(t)
}

function lb(t) {
    return t.type === nt.GDRIVE_ACTION_CONNECTOR
}

function cb(t) {
    return t.id !== ks[nt.SHAREPOINT_CONNECTOR]
}

function db(t) {
    return t.id !== ks[nt.TEAMS_CONNECTOR]
}

function ub(t) {
    return !1
}

function pb(t) {
    return t.type === nt.GITHUB_CONNECTOR
}

function mb(t) {
    return t.user_connection_details.connection_type === "github_sync_connector"
}

function fb(t, e) {
    const [o, a] = t;
    return e.connected ? [
        [...o, e], a
    ] : [o, [...a, e]]
}

function gb(t) {
    const {
        element: e,
        name: o
    } = t;
    return n.jsx(F.Fragment, {
        children: e
    }, o)
}

function hb(t) {
    const {
        element: e
    } = t;
    return n.jsx(n.Fragment, {
        children: e
    })
}

function _b({
    clientThreadId: t,
    activeSystemHint: e,
    selectedSources: o,
    selectedMCPSources: a,
    addSource: l,
    deleteSource: i,
    toggleSource: d,
    currentModelConfigId: b,
    connectionStatuses: s,
    connectedOnly: m = !1,
    hiddenTypes: x,
    hideMcpConnectors: C = !1,
    isDeepResearchAppActive: u = !1
}) {
    var B, Z;
    const c = Ke(),
        g = Hm(),
        y = xu(),
        S = fe(() => Rc(c)),
        v = u || (e == null ? void 0 : e.systemHint) === ue.Research,
        j = (e == null ? void 0 : e.systemHint) === ue.ApiTool,
        M = b != null && ku({
            id: b
        }, c),
        h = (e == null ? void 0 : e.systemHint) === ue.Glaux || M,
        w = h ? ue.Glaux : e == null ? void 0 : e.systemHint,
        P = (e == null ? void 0 : e.systemHint) === ue.Slurm,
        R = Ju(b, e == null ? void 0 : e.systemHint),
        {
            availableConnectors: D,
            isLoading: E,
            enabled: A
        } = Gm(),
        G = Wm(c),
        k = fe(() => $m(c, {
            includeDisabledByAdmin: !0,
            includeAutoConnectors: P,
            filterDisabledAutoConnectors: P
        })),
        N = !k,
        q = fe(() => Vm(c)),
        {
            availableConnectors: V,
            enabled: re,
            isLoading: K
        } = w1({
            includeDisabledByAdmin: !0
        }),
        I = fe(() => qm(c)),
        {
            connectorConfigMap: r
        } = C1({
            clientThreadId: t
        }),
        oe = fe(() => bu(c)),
        T = L => {
            const p = o.size + a.size;
            h && (Ms(L) && a.has(L) && p <= 1 || !Ms(L) && o.has(L) && p <= 1) || d(L)
        },
        ge = P && (((B = s == null ? void 0 : s.length) != null ? B : 0) > 0 || G && k && k.length > 0),
        Ce = L => L ? C != null && C ? L.filter(p => !Ms(p.type) && !(x != null && x.has(p.type))) : x ? L.filter(p => !x.has(p.type)) : L : [],
        X = L => x ? !x.has(L) : !0;
    if (A && v) return n.jsx(ho, {
        clientThreadId: t,
        selectedSources: o,
        selectedMCPSources: a,
        addSource: l,
        deleteSource: i,
        toggleSource: T,
        isLoading: E,
        enabledConnectors: Ce(D),
        fetchValidLinksOnly: !0,
        systemHintType: w,
        isDeveloperMode: S,
        connectorFilterFn: X,
        includeWebSearch: !0,
        trigger: n.jsx(_o, {
            selectedSources: o,
            selectedMCPSources: a,
            includeSyncConnectors: !1,
            includeWebSearch: !0,
            connectorFilterFn: X
        })
    });
    if (ge) {
        const L = y != null && y.isPersonalAccount() ? g : !0;
        return n.jsx(ho, {
            clientThreadId: t,
            selectedSources: o,
            selectedMCPSources: a,
            addSource: l,
            deleteSource: i,
            toggleSource: T,
            isLoading: N,
            enabledConnectors: Ce(k),
            includeWebSearch: !1,
            includeSyncConnectors: L,
            isDeveloperMode: S,
            connectorConfigMap: r,
            systemHintType: w,
            connectorFilterFn: X,
            trigger: n.jsx(_o, {
                selectedSources: o,
                selectedMCPSources: a,
                includeSyncConnectors: L,
                includeWebSearch: !1,
                isDeveloperMode: S,
                connectorFilterFn: X
            })
        })
    }
    if (j) {
        const L = (Z = oe == null ? void 0 : oe.filter(p => p.connector_type === "MCP")) != null ? Z : [];
        return n.jsx(ho, {
            clientThreadId: t,
            selectedSources: o,
            selectedMCPSources: a,
            addSource: l,
            deleteSource: i,
            toggleSource: T,
            isLoading: !oe,
            enabledConnectors: L,
            includeWebSearch: !1,
            includeSyncConnectors: !1,
            connectorConfigMap: r,
            systemHintType: w,
            isDeveloperMode: !0,
            connectorFilterFn: X,
            trigger: n.jsx(_o, {
                selectedSources: o,
                selectedMCPSources: a,
                includeSyncConnectors: !1,
                includeWebSearch: !1,
                isDeveloperMode: !0,
                connectorFilterFn: X
            })
        })
    }
    if (re && R) {
        const L = So();
        return n.jsx(ho, {
            clientThreadId: t,
            selectedSources: o,
            selectedMCPSources: a,
            addSource: l,
            deleteSource: i,
            toggleSource: T,
            isLoading: K,
            enabledConnectors: V,
            fetchValidLinksOnly: !0,
            systemHintType: w,
            includeCloudBrowser: L,
            isDeveloperMode: S,
            connectorFilterFn: X,
            trigger: n.jsx(_o, {
                selectedSources: o,
                selectedMCPSources: a,
                includeSyncConnectors: !1,
                includeWebSearch: !0,
                connectorFilterFn: X
            })
        })
    }
    return h ? n.jsx(ho, {
        clientThreadId: t,
        selectedSources: o,
        selectedMCPSources: a,
        addSource: l,
        deleteSource: i,
        toggleSource: T,
        isLoading: !I,
        enabledConnectors: I != null ? I : [],
        includeWebSearch: !1,
        includeSyncConnectors: !0,
        systemHintType: w,
        isDeveloperMode: S,
        connectorFilterFn: L => {
            var p;
            return (L.endsWith("_sync_connector") ? (p = q != null ? q : []) == null ? void 0 : p.some(se => se.user_connection_details.connection_type === L) : !0) && X(L)
        },
        trigger: n.jsx(_o, {
            selectedSources: o,
            selectedMCPSources: a,
            includeSyncConnectors: !0,
            connectorFilterFn: L => {
                var p;
                return (L.endsWith("_sync_connector") ? (p = q != null ? q : []) == null ? void 0 : p.some(se => se.user_connection_details.connection_type === L) : !0) && X(L)
            },
            includeWebSearch: !1
        })
    }) : null
}

function yb({
    activeSystemHint: t,
    clientThreadId: e,
    connectionStatuses: o,
    currentModelConfig: a,
    isDeepResearchAppActive: l = !1
}) {
    const {
        selectedSources: i = new Set,
        selectedMCPSources: d = new Set,
        addSource: b,
        deleteSource: s,
        toggleSource: m
    } = Qu(e);
    return n.jsx(_b, {
        clientThreadId: e,
        activeSystemHint: t,
        selectedSources: i,
        selectedMCPSources: d,
        addSource: b,
        deleteSource: s,
        toggleSource: m,
        currentModelConfigId: a == null ? void 0 : a.id,
        connectionStatuses: o,
        isDeepResearchAppActive: l
    })
}
const bb = () => null,
    xb = () => !0,
    Sb = t => {
        "use forget";
        var Fs, sn;
        const e = Et.c(163),
            {
                conversation: o,
                composerController: a,
                pendingFiles: l,
                hasFiles: i,
                placeholder: d,
                isTemporaryChat: b,
                state: s,
                inputState: m,
                disableReason: x,
                excessFileCount: C,
                remainingFileUploads: u,
                currentModelConfig: c,
                gizmoId: g,
                replyRegions: y,
                includeSidebarContextTray: S,
                onSubmit: v,
                leadingAction: j,
                legacyFooterActions: M,
                activeSystemHint: h,
                activeConnectorSystemHints: w,
                isDeepResearchAppActive: P,
                deepResearchModelVariant: R,
                onChangeDeepResearchModelVariant: D,
                hideSystemHint: E,
                isSystemHintLocked: A,
                onRemoveSystemHint: G,
                onRemoveModel: k,
                contextualAnswerUserConnectionData: N,
                fileInput: q,
                expanded: V,
                expandOnMultilineInput: re,
                layoutMode: K,
                shouldShowAgentSessionModeDropdown: I,
                agentSessionModeNuxModal: r,
                isAgentSessionModeDropdownDisabled: oe,
                forceStopButton: T,
                selectedHazelnutIds: ge,
                disableAdvancedVoiceMode: Ce
            } = t,
            X = P === void 0 ? !1 : P,
            B = R === void 0 ? Tc : R,
            Z = E === void 0 ? !1 : E,
            L = I === void 0 ? !1 : I,
            p = oe === void 0 ? !1 : oe,
            se = T === void 0 ? !1 : T;
        let Me;
        e[0] !== ge ? (Me = ge === void 0 ? [] : ge, e[0] = ge, e[1] = Me) : Me = e[1];
        const Be = Me,
            Ie = Ce === void 0 ? !1 : Ce,
            be = Ke(),
            ve = jc(As);
        let ce;
        e[2] !== o.id || e[3] !== be ? (ce = () => xb(be, o.id), e[2] = o.id, e[3] = be, e[4] = ce) : ce = e[4];
        const Ne = fe(ce);
        let et;
        e[5] !== be ? (et = () => Rc(be), e[5] = be, e[6] = et) : et = e[6];
        const de = fe(et) && Ne,
            Ge = Ht(o.id, wt.getIsNewConversation),
            De = Mo();
        let te;
        e[7] !== be ? (te = () => Lc(be), e[7] = be, e[8] = te) : te = e[8];
        const {
            showSelectedModelInComposer: Pe,
            showThinkingEffortPicker: Re,
            fontSize: We,
            disableMotion: ee
        } = fe(te);
        let Se;
        e[9] !== a ? (Se = Mu(a), e[9] = a, e[10] = Se) : Se = e[10];
        const {
            composerThinkingEffort$: J,
            setThinkingEffort: pe
        } = Se, he = fe(J);
        let ye;
        e[11] !== be || e[12] !== c ? (ye = c && k1(be, c.id, c), e[11] = be, e[12] = c, e[13] = ye) : ye = e[13];
        const ke = ye;
        let Le;
        e[14] === Symbol.for("react.memo_cache_sentinel") ? (Le = Jm("connector_openai_shopping"), e[14] = Le) : Le = e[14];
        const ne = Le;
        let Te;
        e[15] !== w ? (Te = w == null ? void 0 : w.some(Nt => Nt.systemHint === ne), e[15] = w, e[16] = Te) : Te = e[16];
        const it = Te === !0,
            z = (!!(c != null && c.configurableThinkingEffort) || (c == null ? void 0 : c.id) === Yu) && he && ((Fs = ke == null ? void 0 : ke.length) != null ? Fs : 0) > 0 && Re && !it && (h == null ? void 0 : h.systemHint) !== ue.Agent && (h == null ? void 0 : h.systemHint) !== ue.Research && !X;
        let $;
        e[17] !== o || e[18] !== be || e[19] !== c || e[20] !== z || e[21] !== Pe ? ($ = () => {
            var gt;
            if (!c || !Pe && !z) return [null];
            if (Au(be).id === c.id) return [null];
            const Nt = Bc(o),
                is = Nt.categories.find(Is => {
                    var ht;
                    return Is.defaultModel === c.id || ((ht = Is.supportedModels) == null ? void 0 : ht.includes(c.id))
                });
            if (is) return [(gt = is.actionPillShortName) != null ? gt : is.label];
            const zs = Nt.groups.find(Is => Is.modelIds.includes(c.id));
            return zs ? [zs.label, c.title] : [c.title || c.id]
        }, e[17] = o, e[18] = be, e[19] = c, e[20] = z, e[21] = Pe, e[22] = $) : $ = e[22];
        const [le, Q] = fe($);
        let _e;
        e[23] !== a ? (_e = Xu(a), e[23] = a, e[24] = _e) : _e = e[24];
        const Ae = fe(_e.isWhisperActive$),
            yt = Pp(),
            ze = M1(yt, "images-app"),
            ot = Zu();
        let rt;
        e[25] !== be || e[26] !== ot ? (rt = () => L1(be) && ot.visible$(), e[25] = be, e[26] = ot, e[27] = rt) : rt = e[27];
        const st = fe(rt),
            Y = ep(wb);
        let bt;
        e[28] !== Y ? (bt = tp(), e[28] = Y, e[29] = bt) : bt = e[29];
        const Bt = i || bt,
            Ee = ((sn = y == null ? void 0 : y.length) != null ? sn : 0) > 0,
            [$e, lt] = F.useState(Ee),
            He = xo(Ee);
        let jt;
        e[30] !== a || e[31] !== ve ? (jt = () => (Qm() || ve) && !Iu(a), e[30] = a, e[31] = ve, e[32] = jt) : jt = e[32];
        const je = fe(jt);
        let Ye;
        e[33] !== Ee || e[34] !== lt ? (Ye = () => {
            Ee && F.startTransition(() => {
                lt(!0)
            })
        }, e[33] = Ee, e[34] = lt, e[35] = Ye) : Ye = e[35];
        let _;
        e[36] !== Ee ? (_ = [Ee], e[36] = Ee, e[37] = _) : _ = e[37], F.useEffect(Ye, _);
        let xe;
        e[38] !== o.id || e[39] !== Be ? (xe = {
            selectedHazelnutIds: Be,
            conversationId: o.id
        }, e[38] = o.id, e[39] = Be, e[40] = xe) : xe = e[40];
        const {
            hasSelectedHazelnuts: U,
            hazelnutPillLabel: ae,
            clearSelectedHazelnuts: ut
        } = v1(xe), Je = vo(), me = Ie ? !1 : Je, Ve = D1, ct = Ct(ve && "text-sm shadow-none! dark:border-token-border-heavy border-t border-gray-100 rounded-none", ze && "p-2!");
        let we;
        e[41] !== a || e[42] !== We || e[43] !== Ae || e[44] !== d ? (we = n.jsx(U1, {
            children: Ae ? n.jsx("div", {
                className: "max-w-full min-w-0 flex-1",
                children: n.jsx(O1, {
                    composerController: a,
                    className: "h-14"
                })
            }) : n.jsx(F1, {
                composerController: a,
                placeholder: d,
                fontSize: We
            })
        }), e[41] = a, e[42] = We, e[43] = Ae, e[44] = d, e[45] = we) : we = e[45];
        let qe;
        e[46] !== q ? (qe = q && n.jsx(Od, {
            children: q
        }), e[46] = q, e[47] = qe) : qe = e[47];
        let Qe;
        e[48] !== Ee || e[49] !== He || e[50] !== y || e[51] !== lt || e[52] !== $e ? (Qe = $e && n.jsx(yc, {
            children: n.jsx(su, {
                initial: !1,
                onExitComplete: () => {
                    He.current || lt(!1)
                },
                children: Ee && n.jsx(to.div, {
                    initial: {
                        height: 0,
                        opacity: 0,
                        y: 12
                    },
                    animate: {
                        height: "auto",
                        opacity: 1,
                        y: 0
                    },
                    exit: {
                        height: 0,
                        opacity: 0,
                        y: 12
                    },
                    transition: {
                        duration: .2,
                        ease: "easeOut"
                    },
                    className: "overflow-hidden",
                    children: n.jsx(T1, {
                        replyRegions: y != null ? y : []
                    })
                }, "reply-regions")
            })
        }), e[48] = Ee, e[49] = He, e[50] = y, e[51] = lt, e[52] = $e, e[53] = Qe) : Qe = e[53];
        let Fe;
        e[54] !== (h == null ? void 0 : h.systemHint) || e[55] !== Bt || e[56] !== l || e[57] !== Y ? (Fe = Bt && n.jsx(yc, {
            children: n.jsx(A1, {
                files: l,
                selectedApps: Y,
                activeSystemHintType: h == null ? void 0 : h.systemHint,
                className: "no-scrollbar horizontal-scroll-fade-mask flex flex-nowrap gap-2 overflow-x-auto px-2.5 pt-2.5 pb-1.5 [--edge-fade-distance:1rem]"
            })
        }), e[54] = h == null ? void 0 : h.systemHint, e[55] = Bt, e[56] = l, e[57] = Y, e[58] = Fe) : Fe = e[58];
        let xt;
        e[59] !== S ? (xt = S && n.jsx(yc, {
            children: n.jsx(z1, {})
        }), e[59] = S, e[60] = xt) : xt = e[60];
        let vt;
        e[61] !== j ? (vt = j && n.jsx(H1, {
            children: j
        }), e[61] = j, e[62] = vt) : vt = e[62];
        let Wt;
        e[63] !== M || e[64] !== me ? (Wt = !me && (M == null ? void 0 : M.map(Cb)), e[63] = M, e[64] = me, e[65] = Wt) : Wt = e[65];
        let ft;
        e[66] !== a || e[67] !== be || e[68] !== c || e[69] !== z || e[70] !== he || e[71] !== le || e[72] !== Q || e[73] !== k || e[74] !== pe || e[75] !== me || e[76] !== Pe ? (ft = !me && z && le ? n.jsx(yr, {
            children: n.jsx(I1, {
                thinkingEffort: he,
                onChangeThinkingEffort: Nt => {
                    pe(Nt), Tu(be).mutate({
                        modelSlug: c.id,
                        thinkingEffort: Nt
                    })
                },
                modelLabel: le,
                modelSlug: c.id,
                modelConfig: c,
                onRemoveModel: k,
                onCloseAutoFocus: Nt => {
                    vu(be).composer.autofocusDisabled$() || (Nt.preventDefault(), Ds(dt(a)))
                }
            })
        }, "effort-selector") : !me && Pe && le ? n.jsx(yr, {
            children: n.jsx(P1, {
                label: le,
                tooltipLabel: Q,
                onRemoveModel: k
            })
        }, "active-model-pill") : null, e[66] = a, e[67] = be, e[68] = c, e[69] = z, e[70] = he, e[71] = le, e[72] = Q, e[73] = k, e[74] = pe, e[75] = me, e[76] = Pe, e[77] = ft) : ft = e[77];
        let Qt;
        e[78] !== ut || e[79] !== U || e[80] !== ae || e[81] !== me ? (Qt = U && !me && n.jsx(yr, {
            children: n.jsx(G1, {
                icon: n.jsx(W1, {
                    className: "icon",
                    "aria-label": ""
                }),
                label: ae,
                removable: !0,
                onRemove: Nt => {
                    Nt.preventDefault(), ut()
                }
            })
        }, "selected-skills-pill"), e[78] = ut, e[79] = U, e[80] = ae, e[81] = me, e[82] = Qt) : Qt = e[82];
        let zt;
        e[83] !== w || e[84] !== h || e[85] !== De || e[86] !== o.id || e[87] !== B || e[88] !== Z || e[89] !== p || e[90] !== A || e[91] !== D || e[92] !== G || e[93] !== L || e[94] !== me ? (zt = !me && (h != null ? h : De) && !Z && n.jsx(yr, {
            children: n.jsxs("div", {
                className: "flex items-center gap-1.5",
                children: [n.jsx(E1, {
                    clientThreadId: o.id,
                    activeSystemHint: h,
                    activeSystemHintType: De,
                    activeConnectorSystemHints: w != null ? w : [],
                    locked: A,
                    deepResearchModelVariant: B,
                    onChangeDeepResearchModelVariant: D,
                    onRemoveSystemHint: G
                }), L && n.jsx(j1, {
                    disabled: p
                })]
            })
        }, "active-hint-tag"), e[83] = w, e[84] = h, e[85] = De, e[86] = o.id, e[87] = B, e[88] = Z, e[89] = p, e[90] = A, e[91] = D, e[92] = G, e[93] = L, e[94] = me, e[95] = zt) : zt = e[95];
        let as;
        e[96] !== r ? (as = r && n.jsx(Od, {
            children: r
        }), e[96] = r, e[97] = as) : as = e[97];
        let Yt;
        e[98] !== h || e[99] !== (N == null ? void 0 : N.connection_statuses) || e[100] !== o.id || e[101] !== be || e[102] !== c || e[103] !== X || e[104] !== K || e[105] !== me ? (Yt = !me && (h != null || X || c != null && ku(c, be)) && c && n.jsxs(kr, {
            children: [n.jsx(yb, {
                activeSystemHint: h != null ? h : void 0,
                clientThreadId: o.id,
                connectionStatuses: N == null ? void 0 : N.connection_statuses,
                currentModelConfig: c,
                isDeepResearchAppActive: X
            }), (h == null ? void 0 : h.systemHint) === ue.Agent && Km(be) && n.jsx(R1, {
                clientThreadId: o.id,
                activeSystemHintType: h.systemHint,
                layoutMode: K
            })]
        }, "sources-tag"), e[98] = h, e[99] = N == null ? void 0 : N.connection_statuses, e[100] = o.id, e[101] = be, e[102] = c, e[103] = X, e[104] = K, e[105] = me, e[106] = Yt) : Yt = e[106];
        let Xt;
        e[107] !== X || e[108] !== Ae || e[109] !== me ? (Xt = !me && X && n.jsx(kr, {
            children: n.jsx(bb, {
                disabled: Ae
            })
        }, "preferred-websites"), e[107] = X, e[108] = Ae, e[109] = me, e[110] = Xt) : Xt = e[110];
        let Zt;
        e[111] !== (h == null ? void 0 : h.systemHint) || e[112] !== a || e[113] !== me || e[114] !== st ? (Zt = !me && (h == null ? void 0 : h.systemHint) === ue.PictureV2 && !st && n.jsx(kr, {
            children: n.jsx(B1, {
                composerController: a
            })
        }, "image-style-picker"), e[111] = h == null ? void 0 : h.systemHint, e[112] = a, e[113] = me, e[114] = st, e[115] = Zt) : Zt = e[115];
        let es;
        e[116] !== a || e[117] !== je || e[118] !== me ? (es = !je && !me && n.jsx($1, {
            composerController: a,
            composerType: "composer-btn"
        }), e[116] = a, e[117] = je, e[118] = me, e[119] = es) : es = e[119];
        let ts;
        e[120] !== a || e[121] !== o.id || e[122] !== Ie || e[123] !== x || e[124] !== C || e[125] !== se || e[126] !== g || e[127] !== m || e[128] !== Ae || e[129] !== v || e[130] !== u || e[131] !== s ? (ts = !Ae && n.jsx(N1, {
            forceStopButton: se,
            inputState: m,
            state: s,
            onSubmit: v,
            composerController: a,
            clientThreadId: o.id,
            gizmoId: g,
            disableReason: x,
            excessFileCount: C,
            remainingFileUploads: u,
            disableAdvancedVoiceMode: Ie
        }), e[120] = a, e[121] = o.id, e[122] = Ie, e[123] = x, e[124] = C, e[125] = se, e[126] = g, e[127] = m, e[128] = Ae, e[129] = v, e[130] = u, e[131] = s, e[132] = ts) : ts = e[132];
        let ss;
        e[133] !== es || e[134] !== ts ? (ss = n.jsxs(V1, {
            children: [es, ts]
        }), e[133] = es, e[134] = ts, e[135] = ss) : ss = e[135];
        let ds;
        return e[136] !== a || e[137] !== ee || e[138] !== re || e[139] !== V || e[140] !== de || e[141] !== ze || e[142] !== Ge || e[143] !== b || e[144] !== v || e[145] !== Ve.Composer || e[146] !== ct || e[147] !== we || e[148] !== qe || e[149] !== Qe || e[150] !== Fe || e[151] !== xt || e[152] !== vt || e[153] !== Wt || e[154] !== ft || e[155] !== Qt || e[156] !== zt || e[157] !== as || e[158] !== Yt || e[159] !== Xt || e[160] !== Zt || e[161] !== ss ? (ds = n.jsxs(Ve.Composer, {
            isTemporaryChat: b,
            isDeveloperMode: de,
            isNewConversation: Ge,
            composerController: a,
            expanded: V,
            expandOnMultilineInput: re,
            onSubmit: v,
            backgroundClassName: ct,
            shouldUseRelaxedRadius: ze,
            disableMotion: ee,
            children: [we, qe, Qe, Fe, xt, vt, Wt, ft, Qt, zt, as, Yt, Xt, Zt, ss]
        }), e[136] = a, e[137] = ee, e[138] = re, e[139] = V, e[140] = de, e[141] = ze, e[142] = Ge, e[143] = b, e[144] = v, e[145] = Ve.Composer, e[146] = ct, e[147] = we, e[148] = qe, e[149] = Qe, e[150] = Fe, e[151] = xt, e[152] = vt, e[153] = Wt, e[154] = ft, e[155] = Qt, e[156] = zt, e[157] = as, e[158] = Yt, e[159] = Xt, e[160] = Zt, e[161] = ss, e[162] = ds) : ds = e[162], ds
    };

function wb(t) {
    return t.selectedApps
}

function Cb(t, e) {
    return n.jsx(kr, {
        children: t
    }, "legacy-footer-action-".concat(e))
}
const kb = Ts(() => vs(() =>
        import ("./nxteivgso0c74ef2.js"), __vite__mapDeps([12, 1, 3, 4, 2, 5, 13, 14])).then(t => t.ConnectorsOnboardingModal)),
    Mb = Ts(() => vs(() =>
        import ("./k15yxxoybkkir2ou.js").then(t => t.F8), __vite__mapDeps([2, 1, 3, 4, 5])).then(t => t.TatertotNuxModal)),
    vb = Ts(() => vs(() =>
        import ("./eiz8m6b2n93cr92l.js"), __vite__mapDeps([15, 1, 3, 4, 2, 5, 16])).then(t => t.GithubOnboardingModal)),
    Tb = () => null,
    Ab = () => null;

function Ib(t) {
    "use forget";
    var Qc, Yc, Xc, Zc, ed, td, sd, nd, od, ad, id, rd, ld, cd, dd;
    const e = Et.c(849),
        {
            onCreateNewCompletion: o,
            onContinueGenerating: a,
            account: l,
            currentModelId: i,
            currentModelConfig: d,
            disableDraftPersistence: b,
            conversation: s,
            isNewThread: m,
            isCompletionInProgress: x,
            disabled: C,
            disabledReason: u,
            canPause: c,
            canContinue: g,
            isInteractableSharedThread: y,
            headerClassName: S,
            hideHeader: v,
            onlyAllowImageUploads: j,
            layoutMode: M,
            availableSystemHints: h,
            isSnorlaxEnabledForGizmo: w,
            gizmoId: P,
            pulseOnboardingEntrypoint: R,
            cocoonEntrypointResponse: D,
            disableAdvancedVoiceMode: E,
            plusButtonAddsFiles: A,
            plusButtonIcon: G,
            hideLoggedOutToolButtons: k,
            placeholder: N
        } = t,
        q = b === void 0 ? !1 : b,
        V = C === void 0 ? !1 : C,
        re = c === void 0 ? !1 : c,
        K = g === void 0 ? !1 : g,
        I = E === void 0 ? !1 : E;
    Fd.markStart("PromptTextarea"), Fd.markRendered("PromptTextarea", void 0, "pageLoad");
    const r = Ke();
    let oe;
    e[0] !== s ? (oe = () => U_(s), e[0] = s, e[1] = oe) : oe = e[1];
    const T = fe(oe),
        ge = T && q1(T);
    let Ce;
    e[2] !== s ? (Ce = () => fo(s), e[2] = s, e[3] = Ce) : Ce = e[3];
    const X = fe(Ce),
        [B, Z] = Ep(),
        L = K1(),
        p = Pc();
    J1(p), Q1();
    const se = Ic();
    let Me;
    e[4] !== l ? (Me = l == null ? void 0 : l.isSelfServeBusiness(), e[4] = l, e[5] = Me) : Me = e[5];
    const Be = Me;
    let Ie;
    e[6] !== l ? (Ie = l == null ? void 0 : l.isEnterprisey(), e[6] = l, e[7] = Ie) : Ie = e[7];
    const be = Ie;
    let ve;
    e[8] !== l ? (ve = l == null ? void 0 : l.isEnterpriseCBP(), e[8] = l, e[9] = ve) : ve = e[9];
    const ce = ve;
    let Ne;
    e[10] !== l ? (Ne = l == null ? void 0 : l.isEdu(), e[10] = l, e[11] = Ne) : Ne = e[11];
    const et = Ne;
    let tt;
    e[12] !== r ? (tt = Zs(), e[12] = r, e[13] = tt) : tt = e[13];
    const de = tt;
    let Ge;
    e[14] === Symbol.for("react.memo_cache_sentinel") ? (Ge = So(), e[14] = Ge) : Ge = e[14];
    const De = Ge,
        te = Gt(),
        Pe = Cu(),
        Re = Ym(),
        We = Y1.useStore(),
        ee = uf(),
        Se = (Qc = Be || be || ce || et) != null ? Qc : !1,
        [J, pe, he, ye, ke, Le, ne] = Ht(s.id, a3),
        Te = (Yc = he == null ? void 0 : he.message.metadata) == null ? void 0 : Yc.async_task_id;
    let it;
    e[15] !== Te ? (it = f => Te ? f.tasks[Te] : null, e[15] = Te, e[16] = it) : it = e[16];
    const z = yd(it);
    let $;
    e[17] !== ne ? ($ = f => {
        var H, ie;
        return (H = ne == null ? void 0 : ne.metadata) != null && H.async_completion_id && (ne == null ? void 0 : ne.status) === "in_progress" ? f.tasks[(ie = ne.metadata.async_task_id) != null ? ie : ""] : null
    }, e[17] = ne, e[18] = $) : $ = e[18];
    const le = yd($),
        Q = !!((Xc = ne == null ? void 0 : ne.metadata) != null && Xc.async_completion_id && (ne == null ? void 0 : ne.status) === "in_progress" && (le == null ? void 0 : le.status) !== pc.CANCELLED),
        _e = Ht(s.id, wt.getSteeringAsyncTaskId);
    let Ae, yt;
    e[19] !== s.id || e[20] !== _e || e[21] !== z ? (Ae = () => {
        const f = z && Bf(z) === Nf.THINKING,
            H = f && Df(z) && z.status !== pc.FINALIZING ? z : null;
        !_e && H ? Ns(s.id, ie => {
            ie.steeringAsyncTaskId = H.taskId
        }) : _e && !H && f && _c(s.id)
    }, yt = [_e, z, s.id], e[19] = s.id, e[20] = _e, e[21] = z, e[22] = Ae, e[23] = yt) : (Ae = e[22], yt = e[23]), F.useEffect(Ae, yt);
    const ze = !!_e;
    let ot;
    e[24] !== s.id ? (ot = {
        clientThreadId: s.id,
        isKaur1br5Client: De
    }, e[24] = s.id, e[25] = ot) : ot = e[25];
    const rt = X1(ot);
    let st;
    if (e[26] !== h || e[27] !== ze) {
        e: {
            if (ze) {
                let ie;
                e[29] === Symbol.for("react.memo_cache_sentinel") ? (ie = [], e[29] = ie) : ie = e[29], st = ie;
                break e
            }
            if (!(h != null && h.length)) {
                st = h;
                break e
            }
            const f = h.findIndex(o3),
                H = h.findIndex(n3);
            if (f === -1 || H === -1 || H < f) {
                st = h;
                break e
            }
            st = Z1(h, H, f + 1)
        }
        e[26] = h,
        e[27] = ze,
        e[28] = st
    }
    else st = e[28];
    const Y = st,
        {
            gizmoEditorData: bt,
            mode: Ut,
            getGizmoId: Bt
        } = Xm(),
        Ee = Zm(),
        $e = ef(),
        lt = e_(),
        He = Ir(s.id),
        jt = !!tf(),
        je = sf.useIsEnabled(s.id),
        Ye = !!ko(),
        _ = Mo();
    let xe;
    e[30] !== _ || e[31] !== Y ? (xe = (Zc = _ && (Y == null ? void 0 : Y.find(f => f.systemHint === _))) != null ? Zc : null, e[30] = _, e[31] = Y, e[32] = xe) : xe = e[32];
    const U = xe,
        ae = nf();
    let ut;
    e[33] !== r ? (ut = () => Lf(r), e[33] = r, e[34] = ut) : ut = e[34];
    const Je = fe(ut),
        me = cu(),
        Ve = _ === ue.Agent || (U == null ? void 0 : U.systemHint) === ue.Agent,
        ct = De && Ve;
    let we;
    e[35] !== Ve ? (we = {
        isAgentHintActive: Ve
    }, e[35] = Ve, e[36] = we) : we = e[36];
    const {
        agentSessionModeNuxModal: qe,
        ensureAgentSessionModeNux: Qe
    } = t_(we);
    s_(p);
    let Fe;
    e[37] !== r ? (Fe = Fu(r), e[37] = r, e[38] = Fe) : Fe = e[38];
    const xt = Fe,
        vt = of (r);
    let Wt;
    e[39] !== r ? (Wt = () => As(r), e[39] = r, e[40] = Wt) : Wt = e[40];
    const ft = fe(Wt);
    let Qt;
    e[41] !== r ? (Qt = af(r), e[41] = r, e[42] = Qt) : Qt = e[42];
    const zt = Qt,
        as = F.useRef(!1);
    let Yt;
    e[43] !== r ? (Yt = Lt(r, "3457598265"), e[43] = r, e[44] = Yt) : Yt = e[44];
    const Xt = Yt;
    let Zt;
    e[45] !== r ? (Zt = () => Uf(r, iu.BrowserReferenceWebHistoryInChat) === !0, e[45] = r, e[46] = Zt) : Zt = e[46];
    const es = fe(Zt);
    let ts, ss;
    e[47] !== U || e[48] !== zt || e[49] !== p || e[50] !== s.id || e[51] !== ft || e[52] !== Xt || e[53] !== es ? (ts = () => {
        if (!Xt || !zt || !ft || !es || as.current) return;
        const f = dt(p),
            H = f == null ? void 0 : f.dom;
        if (!H) return;
        const ie = () => {
            if (as.current) return;
            as.current = !0;
            const Oe = [];
            U && Oe.push(U.systemHint), sg(void 0, $d, Oe, s.id).catch(s3)
        };
        return H.addEventListener("input", ie, {
            once: !0
        }), () => {
            H.removeEventListener("input", ie)
        }
    }, ss = [zt, p, ft, Xt, es, U, s.id], e[47] = U, e[48] = zt, e[49] = p, e[50] = s.id, e[51] = ft, e[52] = Xt, e[53] = es, e[54] = ts, e[55] = ss) : (ts = e[54], ss = e[55]), F.useEffect(ts, ss);
    const ds = Mc.useStore(),
        Fs = Mc.useState(t3),
        sn = rf();
    let Nt;
    e[56] !== r ? (Nt = lf(r), e[56] = r, e[57] = Nt) : Nt = e[57];
    const is = Nt;
    let zs;
    e[58] !== r || e[59] !== sn ? (zs = () => Uc.if$(r, sn), e[58] = r, e[59] = sn, e[60] = zs) : zs = e[60];
    const {
        data: gt,
        isLoading: Is
    } = fe(zs), {
        selectedSources: ht,
        selectedMCPSources: Ot,
        addSource: Hs
    } = Qu(s.id), St = Pu();
    let To;
    e[61] !== St ? (To = !1, e[61] = St, e[62] = To) : To = e[62];
    const Gs = To,
        [nn, on] = F.useState(Tc);
    let Ao;
    e[63] !== on ? (Ao = () => {
        on(Tc)
    }, e[63] = on, e[64] = Ao) : Ao = e[64];
    let Io;
    e[65] !== s.id ? (Io = [s.id], e[65] = s.id, e[66] = Io) : Io = e[66], F.useEffect(Ao, Io);
    const jr = !!Gs;
    let Po;
    e[67] !== jr ? (Po = {
        enabled: jr
    }, e[67] = jr, e[68] = Po) : Po = e[68];
    const Rr = n_(Po);
    let Eo, jo;
    e[69] !== _ || e[70] !== Hs || e[71] !== B || e[72] !== Z ? (Eo = () => {
        const f = B.get("add_source");
        f && _ && (Hs(f), B.delete("add_source"), Z(B))
    }, jo = [_, Hs, B, Z], e[69] = _, e[70] = Hs, e[71] = B, e[72] = Z, e[73] = Eo, e[74] = jo) : (Eo = e[73], jo = e[74]), F.useEffect(Eo, jo);
    let Ro, Bo;
    e[75] !== Y || e[76] !== s.id || e[77] !== r || e[78] !== B || e[79] !== ae || e[80] !== Z ? (Ro = () => {
        Y != null && Y.some(e3) && B.get("company-knowledge") != null && (Zn(r, kb, {
            onContinue: () => {
                ae(ue.Glaux, {
                    analyticsMetadata: {
                        clientThreadId: s.id
                    }
                })
            }
        }), B.delete("company-knowledge"), Z(B))
    }, Bo = [B, Y, r, s.id, ae, Z], e[75] = Y, e[76] = s.id, e[77] = r, e[78] = B, e[79] = ae, e[80] = Z, e[81] = Ro, e[82] = Bo) : (Ro = e[81], Bo = e[82]), F.useEffect(Ro, Bo);
    const {
        eligible: No,
        isLoading: Do
    } = bo(en.hasSeenTatertotNux);
    let Lo, Uo;
    e[83] !== _ || e[84] !== r || e[85] !== No || e[86] !== Do ? (Lo = () => {
        _ === ue.Tatertot && Lt(r, "1586944302") && No && !Do && Zn(r, Mb)
    }, Uo = [_, No, Do, r], e[83] = _, e[84] = r, e[85] = No, e[86] = Do, e[87] = Lo, e[88] = Uo) : (Lo = e[87], Uo = e[88]), F.useEffect(Lo, Uo);
    let Oo;
    e[89] !== r ? (Oo = o_(r), e[89] = r, e[90] = Oo) : Oo = e[90];
    const $c = Oo,
        lp = $c && (((ed = Ot == null ? void 0 : Ot.size) != null ? ed : 0) > 0 || ee || St.size > 0),
        Br = !$c;
    let Fo;
    e[91] !== Br ? (Fo = {
        skip: Br,
        productSku: kc.PROMPT_TEXT_AREA
    }, e[91] = Br, e[92] = Fo) : Fo = e[92], cf(Fo);
    const {
        platformConnectors: Vt
    } = df(lp, kc.PROMPT_TEXT_AREA);
    let zo;
    e[93] !== r ? (zo = Fc(r), e[93] = r, e[94] = zo) : zo = e[94];
    const Nr = zo;
    let Ho;
    e[95] !== r ? (Ho = Oc(r), e[95] = r, e[96] = Ho) : Ho = e[96];
    const Dr = Ho.length > 0 && Se;
    let Go;
    e[97] !== Vt || e[98] !== Dr ? (Go = {
        platformConnectors: Vt,
        enabled: Dr
    }, e[97] = Vt, e[98] = Dr, e[99] = Go) : Go = e[99], pf(Go);
    let Wo;
    e[100] !== Vt || e[101] !== Ot ? (Wo = Array.from(Ot != null ? Ot : []).map(f => Vt.get(f)).filter(Zb), e[100] = Vt, e[101] = Ot, e[102] = Wo) : Wo = e[102];
    const $o = Wo;
    let an;
    e[103] !== (gt == null ? void 0 : gt.connection_statuses) || e[104] !== Nr || e[105] !== ht ? (an = () => {
        var ie;
        if (!Nr) return {
            selectedConnectorIds: void 0,
            selectedSyncKnowledgeStoreIds: void 0
        };
        const f = new Set,
            H = new Set;
        for (const Oe of ht != null ? ht : []) {
            const mt = ks[Oe];
            mt && f.add(mt);
            const _t = (ie = gt == null ? void 0 : gt.connection_statuses) == null ? void 0 : ie.find(Rs => Rs.user_connection_details.connection_type === Oe);
            _t && H.add(_t.user_connection_details.connection_instance_id)
        }
        return {
            selectedConnectorIds: f,
            selectedSyncKnowledgeStoreIds: H
        }
    }, e[103] = gt == null ? void 0 : gt.connection_statuses, e[104] = Nr, e[105] = ht, e[106] = an) : an = e[106], gt == null || gt.connection_statuses;
    let Vo;
    e[107] !== an ? (Vo = an(), e[107] = an, e[108] = Vo) : Vo = e[108];
    const {
        selectedConnectorIds: Lr,
        selectedSyncKnowledgeStoreIds: Ur
    } = Vo, us = Ht(s.id, Xb), Or = F.useRef(0);
    let qo;
    e[109] !== r ? (qo = Us(r, "3396794266").get("restore_prompt_on_stop", !1), e[109] = r, e[110] = qo) : qo = e[110];
    const rn = qo,
        Ko = F.useRef(null),
        Fr = a_(),
        zr = i_(),
        cp = vo(),
        so = I ? !1 : cp,
        no = (r_(s.id) || so) && !Q;
    let Jo;
    e[111] !== r ? (Jo = () => {
        var H;
        const f = O_(r);
        f.isFeedbackViewOpen$() && ((H = f.feedbackViewState$()) == null ? void 0 : H.type) !== Hd.Conversation && f.openFeedbackView({
            type: Hd.Conversation
        })
    }, e[111] = r, e[112] = Jo) : Jo = e[112];
    const Hr = Jo;
    let Qo;
    e[113] !== _ || e[114] !== T || e[115] !== d ? (Qo = bd(d, T, _), e[113] = _, e[114] = T, e[115] = d, e[116] = Qo) : Qo = e[116];
    const ps = Qo,
        oo = mf();
    let ms, Yo;
    e[117] !== r ? (ms = ff().flags, Yo = ms == null ? void 0 : ms.includes(gf.NoAuthEnableFileUploads), e[117] = r, e[118] = ms, e[119] = Yo) : (ms = e[118], Yo = e[119]);
    const ln = Yo,
        Gr = Y == null || Y.length > 0;
    let Xo;
    e[120] !== St || e[121] !== Y ? (Xo = (td = Y == null ? void 0 : Y.filter(f => St.has(f.systemHint))) != null ? td : [], e[120] = St, e[121] = Y, e[122] = Xo) : Xo = e[122];
    const Wr = Xo;
    let ao;
    if (e[123] !== St || e[124] !== Vt) {
        e: {
            const f = Array.from(St).filter(xd).map(Sd);
            if (f.length === 0) {
                let Oe;
                e[126] === Symbol.for("react.memo_cache_sentinel") ? (Oe = [], e[126] = Oe) : Oe = e[126], ao = Oe;
                break e
            }
            const H = f.filter(Oe => {
                var mt, _t;
                return zd(Oe) ? !0 : (_t = (mt = Vt.get(Oe)) == null ? void 0 : mt.conformance) == null ? void 0 : _t.implements_retrievable
            });
            let ie;e[127] !== H ? (ie = Array.from(new Set(H)), e[127] = H, e[128] = ie) : ie = e[128],
            ao = ie
        }
        e[123] = St,
        e[124] = Vt,
        e[125] = ao
    }
    else ao = e[125];
    const $r = ao;
    let Zo;
    e[129] !== St || e[130] !== Vt ? (Zo = Array.from(St).filter(xd).map(Sd).filter(f => {
        var H, ie;
        return !((ie = (H = Vt.get(f)) == null ? void 0 : H.supports_full_actions) != null && ie) && !zd(f)
    }), e[129] = St, e[130] = Vt, e[131] = Zo) : Zo = e[131];
    const Vr = Zo;
    let ea;
    e[132] !== s.id || e[133] !== ae ? (ea = () => {
        ae(null, {
            analyticsMetadata: {
                clientThreadId: s.id
            }
        })
    }, e[132] = s.id, e[133] = ae, e[134] = ea) : ea = e[134];
    const fs = ea;
    let ta;
    e[135] !== r ? (ta = () => Au(r).id, e[135] = r, e[136] = ta) : ta = e[136];
    const cn = fe(ta);
    let sa;
    e[137] !== s || e[138] !== r || e[139] !== i ? (sa = (f, H) => {
        Ze.logEventWithStatsig("Model Switcher Model Changed", "chatgpt_model_switcher_model_changed", {
            from: i,
            to: f,
            location: H
        }), f && !Of(r, f) && Tu(r).mutate({
            modelSlug: f
        }), Ff(s, f), _c(s.id)
    }, e[137] = s, e[138] = r, e[139] = i, e[140] = sa) : sa = e[140];
    const gs = sa;
    let na;
    e[141] !== cn || e[142] !== gs ? (na = f => {
        zf() && (f == null || f.preventDefault()), gs(cn, "remove non-default model")
    }, e[141] = cn, e[142] = gs, e[143] = na) : na = e[143];
    const dn = na,
        qr = (sd = U == null ? void 0 : U.systemHint) != null ? sd : null;
    let oa;
    e[144] !== i || e[145] !== qr ? (oa = Ju(i, qr), e[144] = i, e[145] = qr, e[146] = oa) : oa = e[146];
    const Ws = oa,
        dp = !V && ps !== mc.None && (de || ln);
    let aa;
    e[147] !== T || e[148] !== d ? (aa = hf(d, T), e[147] = T, e[148] = d, e[149] = aa) : aa = e[149];
    const at = aa;
    let ia;
    e[150] !== T || e[151] !== d ? (ia = _f(d, T), e[150] = T, e[151] = d, e[152] = ia) : ia = e[152];
    const rs = ia;
    let ra;
    e[153] !== Ut ? (ra = f => Ut === "magic" ? f.files.filter(Yb) : f.files.filter(Qb), e[153] = Ut, e[154] = ra) : ra = e[154];
    const Dt = wd(ra, fu),
        [io] = F.useState(Jb),
        up = l_(),
        la = Dt.length > 0 || up,
        ca = wd(yf.hasUploadInProgress),
        ro = ep(Kb);
    let da;
    e[155] !== ro ? (da = tp(), e[155] = ro, e[156] = da) : da = e[156];
    const Kr = da,
        Jr = c_(s.id);
    let ua;
    e[157] !== p || e[158] !== d ? (ua = Mr(() => l2(d, og(p))), e[157] = p, e[158] = d, e[159] = ua) : ua = e[159];
    const $s = fe(ua);
    let pa;
    e[160] !== p ? (pa = () => Iu(p), e[160] = p, e[161] = pa) : pa = e[161];
    const Ps = fe(pa),
        ma = !Ps,
        fa = !$s && !ca && (ma || la);
    let ga;
    e[162] !== p ? (ga = Mu(p), e[162] = p, e[163] = ga) : ga = e[163];
    const {
        composerThinkingEffort$: Qr
    } = ga, {
        maxUploads: pp,
        remaining: Vs,
        baseLimit: mp
    } = bf(ps), ha = Vs != null ? Math.max(0, Dt.length - Vs) : 0, _a = ha > 0, ya = Math.max(0, pp - Dt.length), Yr = ya <= 0, fp = Vs != null && Vs < mp, gp = (U == null ? void 0 : U.systemHint) === ue.Research;
    let ba;
    e[164] !== r ? (ba = Lt(r, "3544641259"), e[164] = r, e[165] = ba) : ba = e[165];
    const hp = ba,
        {
            selectedRepos: lo
        } = d_(s.id, Ar),
        Vc = (gp || Ws) && hp && (ht == null ? void 0 : ht.size) === 0 && (Ot == null ? void 0 : Ot.size) === 0,
        Xr = le == null ? void 0 : le.taskId;
    let xa;
    e[166] !== te || e[167] !== Xr || e[168] !== Pe ? (xa = {
        taskId: Xr,
        intl: te,
        toaster: Pe
    }, e[166] = te, e[167] = Xr, e[168] = Pe, e[169] = xa) : xa = e[169];
    const Zr = u_(xa),
        hs = (z == null ? void 0 : z.status) === pc.RUNNING && !no,
        el = (od = p_((nd = fc(s.id)) != null ? nd : s.id)) == null ? void 0 : od.value,
        Sa = el === gc.STREAMING,
        tl = el === gc.REALTIME,
        sl = el === gc.REALTIME_BUSY,
        un = x && re || Sa || tl || sl || hs || Q,
        nl = (Q || tl || sl || hs) && !ye,
        _p = xf(He).length > 0,
        Es = fa && !V && !_a && !Ye && (!un || no || _p) && !Vc,
        {
            targetedContent: wa,
            setTargetedContent: _s
        } = m_(),
        Ue = wa != null && wa.isFocusedViewContent && !lt ? void 0 : wa;
    let Ca;
    e[170] !== r ? (Ca = vu(r), e[170] = r, e[171] = Ca) : Ca = e[171];
    const js = Ca;
    let ka, Ma;
    e[172] !== p || e[173] !== Ue || e[174] !== js ? (ka = () => {
        !Ue || js.composer.autofocusDisabled$() || requestAnimationFrame(() => requestAnimationFrame(() => {
            Ds(dt(p))
        }))
    }, Ma = [Ue, js, p], e[172] = p, e[173] = Ue, e[174] = js, e[175] = ka, e[176] = Ma) : (ka = e[175], Ma = e[176]), F.useEffect(ka, Ma);
    const {
        getUpsellLabelType: ol,
        getUpsellShowsAttach: al
    } = f_();
    let va;
    e[177] !== r ? (va = () => Lc(r), e[177] = r, e[178] = va) : va = e[178];
    const pn = fe(va),
        Ta = A != null ? A : pn.plusButtonAddsFiles,
        {
            isSingleLine: kt,
            loggedOutAttachLabel: il,
            showSelectedModelInComposer: rl
        } = pn,
        ys = k != null ? k : pn.loggedOutHideToolButtons;
    let Aa;
    e[179] !== _ || e[180] !== Gr || e[181] !== Is || e[182] !== de || e[183] !== Be || e[184] !== kt ? (Aa = Gr && de && (!Be || !Is) && !Cd(_) && !kt, e[179] = _, e[180] = Gr, e[181] = Is, e[182] = de, e[183] = Be, e[184] = kt, e[185] = Aa) : Aa = e[185];
    const ll = Aa;
    let Ia;
    e[186] !== p ? (Ia = Xu(p), e[186] = p, e[187] = Ia) : Ia = e[187];
    const bs = fe(Ia.isWhisperActive$);
    let Pa;
    e[188] !== Z ? (Pa = () => {
        Z(qb)
    }, e[188] = Z, e[189] = Pa) : Pa = e[189];
    const yp = Pa;
    let Ea;
    e[190] !== p || e[191] !== s || e[192] !== ae ? (Ea = f => {
        if (pu.set(s, !0), hr(dt(p), f.prompt), f.system_hint) {
            const H = f.system_hint;
            if (ae(H), f.sources) {
                const ie = f.sources.map(Vb).filter(wc),
                    Oe = new Set(ie.filter($b)),
                    mt = new Set(ie.filter(Ms));
                Ns(s.id, _t => {
                    _t.selectedSources = new Map([
                        [H, Oe]
                    ]), _t.selectedMCPSources = new Map([
                        [H, mt]
                    ]), _t.hasModifiedSources = !0
                })
            }
        }
    }, e[190] = p, e[191] = s, e[192] = ae, e[193] = Ea) : Ea = e[193];
    const co = Ea;
    let ja;
    e[194] !== B ? (ja = B.get("share_prompt"), e[194] = B, e[195] = ja) : ja = e[195], g_(r, ja, yp, co);
    let Ra, Ba;
    e[196] !== p || e[197] !== s.id || e[198] !== r || e[199] !== co || e[200] !== Je ? (Ra = () => {
        !Je || Je.skipConversationId === s.id || (Hf(r), kd(dt(p)), co(Je.prompt))
    }, Ba = [p, s.id, r, co, Je], e[196] = p, e[197] = s.id, e[198] = r, e[199] = co, e[200] = Je, e[201] = Ra, e[202] = Ba) : (Ra = e[201], Ba = e[202]), F.useEffect(Ra, Ba);
    let Na;
    e[203] !== p || e[204] !== He || e[205] !== se ? (Na = () => {
        if (!(se != null && se.id)) return;
        const f = Gd.getAndReset(se.id, He);
        f && hr(dt(p), f.inputText)
    }, e[203] = p, e[204] = He, e[205] = se, e[206] = Na) : Na = e[206];
    const cl = se == null ? void 0 : se.id;
    let Da;
    e[207] !== p || e[208] !== He || e[209] !== cl ? (Da = [cl, He, p], e[207] = p, e[208] = He, e[209] = cl, e[210] = Da) : Da = e[210], F.useEffect(Na, Da);
    let La, Ua;
    e[211] !== p || e[212] !== B ? (La = () => {
        var H;
        const f = (H = B.get("prompt")) != null ? H : "";
        f.length > 0 && hr(dt(p), f)
    }, Ua = [p, B], e[211] = p, e[212] = B, e[213] = La, e[214] = Ua) : (La = e[213], Ua = e[214]), F.useEffect(La, Ua);
    let Oa;
    e[215] !== U || e[216] !== _ || e[217] !== Y || e[218] !== s.id || e[219] !== ae ? (Oa = () => {
        _ !== ue.Slurm && _ != null && !(Y != null && Y.some(Wb)) || (U == null && ae(ue.Slurm), Ns(s.id, Gb))
    }, e[215] = U, e[216] = _, e[217] = Y, e[218] = s.id, e[219] = ae, e[220] = Oa) : Oa = e[220];
    const qs = Oa;
    let Fa;
    e[221] !== r || e[222] !== is || e[223] !== B || e[224] !== qs || e[225] !== Z ? (Fa = () => {
        if (B.has("github_onboarding")) {
            const f = B.get("github_onboarding");
            let H = go.ConfigureRepos;
            f && [go.ConfigureRepos, go.SyncRepos, go.IndexRepos].includes(f) && (H = f), is && H !== go.ConfigureRepos ? qs() : Zn(r, vb, {
                initialState: H,
                onFinishFlow: qs
            }), Z(Hb)
        }
    }, e[221] = r, e[222] = is, e[223] = B, e[224] = qs, e[225] = Z, e[226] = Fa) : Fa = e[226];
    let za;
    e[227] !== U || e[228] !== _ || e[229] !== Y || e[230] !== s.id || e[231] !== r || e[232] !== is || e[233] !== B || e[234] !== qs || e[235] !== ae || e[236] !== Z ? (za = [B, Z, r, _, U, s.id, ae, Y, qs, is], e[227] = U, e[228] = _, e[229] = Y, e[230] = s.id, e[231] = r, e[232] = is, e[233] = B, e[234] = qs, e[235] = ae, e[236] = Z, e[237] = za) : za = e[237], F.useEffect(Fa, za);
    let Ha;
    e[238] !== _ || e[239] !== me || e[240] !== Y || e[241] !== s.id || e[242] !== B || e[243] !== Z ? (Ha = () => {
        const f = Gf(B, {
                availableHints: Y
            }),
            H = _ != null ? _ : f[0],
            ie = H === ue.Slurm,
            Oe = H === ue.Research,
            mt = H === ue.ApiTool;
        if (!ie && !Oe && !mt) return;
        const _t = B.getAll("sources");
        if (!_t.length) return;
        const Rs = B.get("redirect_source");
        if (mt)
            for (const Cs of _t) me(Cs.trim());
        else {
            const Cs = _t.map(zb).filter(wc),
                ns = new Set(Cs.filter(Fb)),
                Kn = new Set(Cs.filter(Ms));
            Ns(s.id, Xs => {
                Xs.selectedSources = new Map([
                    [H, ns]
                ]), Xs.selectedMCPSources = new Map([
                    [H, Kn]
                ]), Xs.hasModifiedSources = !0
            })
        }
        Z(Ob), Rs === "suggested_ca_prompts" && Ze.logEventWithStatsig("chatgpt_contextual_answers_connector_activated", "chatgpt_contextual_answers_connector_activated", {
            source: "suggested_ca_prompts"
        })
    }, e[238] = _, e[239] = me, e[240] = Y, e[241] = s.id, e[242] = B, e[243] = Z, e[244] = Ha) : Ha = e[244];
    let Ga;
    e[245] !== _ || e[246] !== me || e[247] !== Hs || e[248] !== Y || e[249] !== s.id || e[250] !== B || e[251] !== ae || e[252] !== Z ? (Ga = [s.id, Hs, B, ae, Z, _, me, Y], e[245] = _, e[246] = me, e[247] = Hs, e[248] = Y, e[249] = s.id, e[250] = B, e[251] = ae, e[252] = Z, e[253] = Ga) : Ga = e[253], F.useEffect(Ha, Ga);
    let Wa;
    e[254] !== T || e[255] !== d ? (Wa = Sf(d, T), e[254] = T, e[255] = d, e[256] = Wa) : Wa = e[256];
    const qt = Wa;
    let $a;
    e[257] !== s.id || e[258] !== r ? ($a = wf(r, s.id), e[257] = s.id, e[258] = r, e[259] = $a) : $a = e[259];
    const Ks = fe($a);
    let Va;
    e[260] !== _ || e[261] !== T || e[262] !== d ? (Va = bd(d, T, _), e[260] = _, e[261] = T, e[262] = d, e[263] = Va) : Va = e[263];
    const {
        handleFileAccepted: dl
    } = w2(te, Va, at, "mouse", Bt, qt == null ? void 0 : qt.attachments, Ks);
    let qa;
    e[264] !== p || e[265] !== r || e[266] !== dl ? (qa = (f, H) => {
        const ie = Jn(r);
        return ie.keepSheetOpen$.set(!1), ie.isSheetOpen$.set(!1), requestAnimationFrame(() => {
            requestAnimationFrame(() => {
                Ds(dt(p))
            })
        }), dl(f, H)
    }, e[264] = p, e[265] = r, e[266] = dl, e[267] = qa) : qa = e[267];
    const mn = qa;
    let Ka;
    e[268] !== mn ? (Ka = f => {
        mn([f], {})
    }, e[268] = mn, e[269] = Ka) : Ka = e[269];
    const ul = Ka;
    let Ja;
    e[270] !== r ? (Ja = Jn(r), e[270] = r, e[271] = Ja) : Ja = e[271];
    const Qa = fe(Ja.keepSheetOpen$);
    let Ya, Xa;
    e[272] !== r || e[273] !== Qa ? (Ya = () => {
        if (!Qa) return;
        const f = new AbortController,
            H = document.getElementById("upload-camera"),
            ie = [],
            Oe = function() {
                for (const ns of ie) ns();
                f.abort(), ie.length = 0
            },
            mt = function(ns) {
                var Xs;
                if (ns.target instanceof HTMLInputElement && ((Xs = ns.target.files) == null ? void 0 : Xs.length) === 0) return;
                const Kn = Jn(r);
                Ed(() => {
                    Kn.keepSheetOpen$.set(!1), Kn.isSheetOpen$.set(!1), Oe()
                })
            },
            _t = function() {
                const ns = Jn(r);
                Ed(() => {
                    ns.keepSheetOpen$.set(!1), ns.isSheetOpen$.set(!1), Oe()
                })
            };
        H && ie.push(Md(H, {
            change: mt,
            cancel: _t
        }));
        const Rs = document.getElementById("upload-photos");
        return Rs && ie.push(Md(Rs, {
            change: mt,
            cancel: _t
        })), Oe
    }, Xa = [Qa, r], e[272] = r, e[273] = Qa, e[274] = Ya, e[275] = Xa) : (Ya = e[274], Xa = e[275]), F.useEffect(Ya, Xa);
    const Tt = !V && !Yr && dp && oo == null && !ze,
        pl = !Tt;
    let fn;
    e[276] !== r ? (fn = () => {
        Jn(r).keepSheetOpen$.set(!1)
    }, e[276] = r, e[277] = fn) : fn = e[277];
    let gn;
    e[278] !== r || e[279] !== te || e[280] !== Pe || e[281] !== ps ? (gn = f => {
        C2(f, te, Pe, ps), Jn(r).keepSheetOpen$.set(!1)
    }, e[278] = r, e[279] = te, e[280] = Pe, e[281] = ps, e[282] = gn) : gn = e[282];
    const ml = Cf(!de || j ? at : rs);
    let Za;
    e[283] !== ya || e[284] !== mn || e[285] !== pl || e[286] !== fn || e[287] !== gn || e[288] !== ml ? (Za = Rt({
        disabled: pl,
        noClick: !0,
        onFileDialogCancel: fn,
        onDropAccepted: mn,
        onDropRejected: gn,
        multiple: !0,
        maxSize: kf,
        maxFiles: ya
    }, ml), e[283] = ya, e[284] = mn, e[285] = pl, e[286] = fn, e[287] = gn, e[288] = ml, e[289] = Za) : Za = e[289];
    const {
        getInputProps: fl,
        open: gl
    } = k2(Za);
    let ei;
    e[290] !== Tt || e[291] !== gl || e[292] !== ps ? (ei = () => {
        Tt && (Ze.logEventWithStatsig("Open File Viewer", "chatgpt_web_file_viewer_opened", {
            intent: ps.toString()
        }), gl())
    }, e[290] = Tt, e[291] = gl, e[292] = ps, e[293] = ei) : ei = e[293];
    const Mt = ei,
        hl = Mf(io);
    let ti;
    e[294] !== St || e[295] !== (U == null ? void 0 : U.persistBetweenMessages) || e[296] !== p || e[297] !== hl || e[298] !== r || e[299] !== Re || e[300] !== ((ad = ne == null ? void 0 : ne.author) == null ? void 0 : ad.role) || e[301] !== (ne == null ? void 0 : ne.channel) || e[302] !== Dt || e[303] !== ae ? (ti = () => {
        var f;
        kd(dt(p)), hl.clearMessages(), Wd(p).resetData();
        for (const H of Dt) _r.remove(Re, H.tempId, "none");
        F_.markAllAsSent(), Lt(r, "2857215914") && (U != null && U.persistBetweenMessages || ((St == null ? void 0 : St.has("connector:connector_openai_shopping")) === !0 ? ((f = ne == null ? void 0 : ne.author) == null ? void 0 : f.role) === "assistant" && (ne == null ? void 0 : ne.channel) === "final" && ae(null) : ae(null)))
    }, e[294] = St, e[295] = U == null ? void 0 : U.persistBetweenMessages, e[296] = p, e[297] = hl, e[298] = r, e[299] = Re, e[300] = (id = ne == null ? void 0 : ne.author) == null ? void 0 : id.role, e[301] = ne == null ? void 0 : ne.channel, e[302] = Dt, e[303] = ae, e[304] = ti) : ti = e[304];
    const Js = ti;
    let uo;
    e: {
        if (ft) {
            uo = $d;
            break e
        } else if (vt) {
            uo = z_;
            break e
        } else if (So()) {
            uo = H_;
            break e
        }
        uo = void 0
    }
    const _l = uo;
    let si;
    e[305] !== zt || e[306] !== ft ? (si = () => ft && zt && vd.sidebarUrlTrayOpen$(), e[305] = zt, e[306] = ft, e[307] = si) : si = e[307];
    const hn = fe(si);
    h_();
    let ni;
    e[308] !== r ? (ni = vf(r), e[308] = r, e[309] = ni) : ni = e[309];
    const yl = ni;
    let oi;
    e[310] !== P ? (oi = P && P.trim().length > 0 ? P.trim() : void 0, e[310] = P, e[311] = oi) : oi = e[311];
    const bl = oi;
    let ai;
    e[312] !== r ? (ai = Tf(r), e[312] = r, e[313] = ai) : ai = e[313];
    const xl = ai;
    let ii;
    e[314] !== r || e[315] !== bl || e[316] !== xl ? (ii = () => xl ? Wf(r, bl) : $f(r), e[314] = r, e[315] = bl, e[316] = xl, e[317] = ii) : ii = e[317];
    const po = fe(ii),
        xs = un ? "streaming" : !Es ? "disabled" : "idle",
        ri = F.useRef(null);
    let li;
    e[318] !== _ || e[319] !== zr || e[320] !== Fr || e[321] !== V || e[322] !== p || e[323] !== xs || e[324] !== Qr || e[325] !== s.id || e[326] !== T || e[327] !== r || e[328] !== J || e[329] !== d || e[330] !== Rr || e[331] !== nn || e[332] !== _l || e[333] !== Qe || e[334] !== Re || e[335] !== Js || e[336] !== Kr || e[337] !== ke || e[338] !== xt || e[339] !== Gs || e[340] !== yl || e[341] !== fa || e[342] !== je || e[343] !== Ws || e[344] !== Vr || e[345] !== o || e[346] !== Dt || e[347] !== We || e[348] !== ds || e[349] !== $r || e[350] !== ro || e[351] !== Lr || e[352] !== X || e[353] !== us || e[354] !== $o || e[355] !== Ot || e[356] !== lo || e[357] !== ht || e[358] !== Ur || e[359] !== He || e[360] !== _s || e[361] !== hn || e[362] !== rn || e[363] !== Le || e[364] !== Hr || e[365] !== po || e[366] !== Ue ? (li = (f, H, ie) => {
        var ud;
        if (f.preventDefault(), V || !fa && !H || !T || ke) return;
        if (!(ie != null && ie.bypassAgentSessionModeGate)) {
            const os = Bs(Rt({}, ie != null ? ie : {}), {
                bypassAgentSessionModeGate: !0
            });
            if (Qe(() => {
                    var pd;
                    return (pd = ri.current) == null ? void 0 : pd.call(ri, f, H, os)
                })) {
                "persist" in f && typeof f.persist == "function" && f.persist();
                return
            }
        }
        const Oe = Td(dt(p).state.doc),
            mt = Oe.content;
        if (Or.current > 0) {
            const os = performance.now() - Or.current;
            Yn.hist(Xn.DEFAULT, "final_user_input_to_submit_ms", [], os)
        }
        xs === "streaming" && (Ze.logEventWithStatsig("chatgpt_web_conversation_stream_interrupted", "chatgpt_web_conversation_stream_interrupted", {
            interrupted_message_length: mt.length
        }), Yn.count(Xn.DEFAULT, "chatgpt_web_conversation_stream_interrupted", [])), Yn.count(Xn.DEFAULT, "chatgpt_web_conversation_completion_sent", []);
        const {
            content: _t,
            attachments: Rs
        } = G_(Re, mt, d, T, _), Cs = Ad(ds).some(Ub);
        Ns(s.id, os => {
            os.hasModifiedSources = !1, os.hasModifiedGithubRepos = !1, os.startedWithByoMcp === void 0 && Cs && (os.startedWithByoMcp = $o.some(Lb))
        }), Fr(), zr(), Hr();
        const ns = Vd.getState().attachedTempTextdocs;
        rn ? Ko.current = {
            content: Oe.content,
            files: Dt.map(Db),
            attachedTempTextdocs: Object.fromEntries(Object.entries(ns).map(Nb)),
            systemHintType: _ != null ? _ : null,
            selectedSources: ht ? [...ht] : void 0,
            selectedMCPSources: Ot ? [...Ot] : void 0
        } : Ko.current = null;
        const Kn = d != null && d.configurableThinkingEffort || (d == null ? void 0 : d.id) === Yu ? Vf(Qr) : void 0;
        o(Rt({
            clientThreadId: s.id,
            ctx: r,
            sourceEvent: f,
            attachments: Rs,
            content: _t,
            contentToSend: Oe,
            conversationMode: T,
            hasSelectedApps: Kr,
            isMessageFollowupsEnabled: je,
            selectedApps: ro,
            desktopOrigin: _l,
            shouldCollectSidebarContext: hn,
            desktopSidebarContext: vd.context$(),
            selectedGizmoTag: X,
            selectedRepos: {
                selectedAllRepos: lo.selectedAllRepos,
                selectedRepos: lo.selectedRepos ? [...lo.selectedRepos] : null
            },
            selectedSources: ht,
            selectedMCPConnectors: $o,
            selectedConnectorIds: Lr,
            selectedSyncKnowledgeStoreIds: Ur,
            searchConnectorIds: $r,
            noFullActionConnectorIds: Vr,
            startedWithByoMcp: Le === !0,
            systemHints: Ad(ds),
            allSystemHints: po != null ? po : [],
            isN7jupdActive: Ws,
            customSourceList: Rr,
            isForceAllowCustomMcpModeEnabled: yl,
            selectedHazelnuts: us,
            thinkingEffort: Kn,
            deepResearchVersion: Gs ? nn : void 0
        }, Wd(p).getData(Oe.content))), (ud = Ue == null ? void 0 : Ue.onCreateCompletion) == null || ud.call(Ue, {
            serverThreadId: He,
            currentLeafId: J
        }), (Ue == null ? void 0 : Ue.shouldPersistAcrossMessages) !== !0 && _s(void 0), Id.hideThreadHeader();
        for (const os of Dt) os.status === qf.Ready && We.addFile(os);
        Us(r, "1925940714").get("reset_state_after_submit", !1) ? Kf.postTask(Js) : Js(), xt && _ === Sc && Gc(r, en.hasSeenAgentModeAnnouncementBanner)
    }, e[318] = _, e[319] = zr, e[320] = Fr, e[321] = V, e[322] = p, e[323] = xs, e[324] = Qr, e[325] = s.id, e[326] = T, e[327] = r, e[328] = J, e[329] = d, e[330] = Rr, e[331] = nn, e[332] = _l, e[333] = Qe, e[334] = Re, e[335] = Js, e[336] = Kr, e[337] = ke, e[338] = xt, e[339] = Gs, e[340] = yl, e[341] = fa, e[342] = je, e[343] = Ws, e[344] = Vr, e[345] = o, e[346] = Dt, e[347] = We, e[348] = ds, e[349] = $r, e[350] = ro, e[351] = Lr, e[352] = X, e[353] = us, e[354] = $o, e[355] = Ot, e[356] = lo, e[357] = ht, e[358] = Ur, e[359] = He, e[360] = _s, e[361] = hn, e[362] = rn, e[363] = Le, e[364] = Hr, e[365] = po, e[366] = Ue, e[367] = li) : li = e[367];
    const ls = hc(li);
    let ci, di;
    e[368] !== ls ? (ci = () => {
        ri.current = ls
    }, di = [ls], e[368] = ls, e[369] = ci, e[370] = di) : (ci = e[369], di = e[370]), F.useEffect(ci, di);
    let ui;
    e[371] !== Es || e[372] !== ls || e[373] !== $s || e[374] !== Pe ? (ui = f => W_(f, {
        toaster: Pe,
        canSubmit: Es,
        isTextContentTooLong: $s,
        requestCompletion: ls
    }), e[371] = Es, e[372] = ls, e[373] = $s, e[374] = Pe, e[375] = ui) : ui = e[375];
    const pi = hc(ui);
    let mi;
    e[376] !== He || e[377] !== _s ? (mi = f => {
        _s(f.targetedReply), f.targetedReply && Ze.logEventWithStatsig("Targeted Reply Button Clicked", "chatgpt_targeted_reply_button_clicked", {
            conversationId: He,
            sourceMessageId: f.messageId
        })
    }, e[376] = He, e[377] = _s, e[378] = mi) : mi = e[378];
    const Sl = mi,
        {
            maybeSetWaitingForRealtimeOnAbort: wl,
            isWatingForRealtimeStatusChange: bp
        } = __(s.id);
    let fi;
    e[379] !== _ || e[380] !== ye || e[381] !== wl ? (fi = (f, H) => {
        const ie = H === void 0 ? "other" : H;
        wl(), $_(f, void 0, {
            clientInitiated: !0,
            reason: ie,
            isLastTurnAgent: ye,
            hasAgentSystemHint: _ === Sc
        })
    }, e[379] = _, e[380] = ye, e[381] = wl, e[382] = fi) : fi = e[382];
    const _n = fi;
    let gi;
    e[383] !== p || e[384] !== J || e[385] !== He || e[386] !== _s || e[387] !== Ue ? (gi = () => {
        var f;
        (f = Ue == null ? void 0 : Ue.onCleared) == null || f.call(Ue, {
            serverThreadId: He,
            currentLeafId: J
        }), _s(void 0), Ds(dt(p))
    }, e[383] = p, e[384] = J, e[385] = He, e[386] = _s, e[387] = Ue, e[388] = gi) : gi = e[388];
    const yn = gi,
        Cl = d == null ? void 0 : d.tags,
        kl = T == null ? void 0 : T.kind;
    let hi;
    e[389] !== r || e[390] !== Cl || e[391] !== kl ? (hi = Af(r, Cl, kl), e[389] = r, e[390] = Cl, e[391] = kl, e[392] = hi) : hi = e[392];
    const Kt = hi;
    let _i;
    e[393] !== p ? (_i = Lu(p), e[393] = p, e[394] = _i) : _i = e[394];
    const {
        autocompletions$: Ml,
        shouldShowAutocomplete$: bn
    } = _i;
    let yi;
    e[395] !== m || e[396] !== bn ? (yi = () => bn() && m, e[395] = m, e[396] = bn, e[397] = yi) : yi = e[397];
    const vl = yi,
        xn = hs || tl || sl;
    let bi;
    e[398] !== _n || e[399] !== U || e[400] !== Ml || e[401] !== re || e[402] !== s || e[403] !== i || e[404] !== cn || e[405] !== yn || e[406] !== vl || e[407] !== x || e[408] !== Ps || e[409] !== xn || e[410] !== dn || e[411] !== fs || e[412] !== X || e[413] !== rl || e[414] !== Ue ? (bi = f => V_(f, {
        canAbortCompletion: re && x && !xn,
        clientThreadId: s.id,
        isAutocompletionActive: vl,
        clearAutocompletions: () => Ml.set([]),
        abortCompletion: () => _n(s.id, "escape_key"),
        isEmpty: Ps,
        hasTargetedContent: Ue != null,
        clearTargetedContent: yn,
        hasSystemHint: U != null,
        removeSystemHint: fs,
        hasSelectedTarget: X != null,
        removeSelectedTarget: () => fo.set(s, null),
        hasNonDefaultModel: rl && i !== cn,
        removeNonDefaultModel: dn
    }), e[398] = _n, e[399] = U, e[400] = Ml, e[401] = re, e[402] = s, e[403] = i, e[404] = cn, e[405] = yn, e[406] = vl, e[407] = x, e[408] = Ps, e[409] = xn, e[410] = dn, e[411] = fs, e[412] = X, e[413] = rl, e[414] = Ue, e[415] = bi) : bi = e[415];
    const xi = hc(bi);
    let Si, wi;
    e[416] !== Es || e[417] !== r ? (Si = () => {
        if (!Es) return;
        Lt(r, "4178431533") || q_(!0).then(Bb)
    }, wi = [Es, r], e[416] = Es, e[417] = r, e[418] = Si, e[419] = wi) : (Si = e[418], wi = e[419]), F.useEffect(Si, wi);
    let Ci, ki;
    e[420] !== p || e[421] !== pi || e[422] !== xi ? (Ci = () => Jf(dt(p), {
        Enter: pi,
        Escape: xi
    }), ki = [p, pi, xi], e[420] = p, e[421] = pi, e[422] = xi, e[423] = Ci, e[424] = ki) : (Ci = e[423], ki = e[424]), F.useEffect(Ci, ki);
    let Mi;
    e[425] !== _ || e[426] !== Ks || e[427] !== s.id || e[428] !== T || e[429] !== r || e[430] !== d || e[431] !== ze || e[432] !== Re || e[433] !== Bt || e[434] !== te || e[435] !== at || e[436] !== Pe ? (Mi = f => {
        ze || K_({
            filePickerStore: Re,
            event: f.nativeEvent,
            intl: te,
            toaster: Pe,
            clientThreadId: s.id,
            conversationMode: T,
            currentModelConfig: d,
            getEditorGizmoId: Bt,
            modelSupportedImageMimeTypes: at,
            activeSystemHintType: _,
            ctx: r,
            contextScopes: Ks
        })
    }, e[425] = _, e[426] = Ks, e[427] = s.id, e[428] = T, e[429] = r, e[430] = d, e[431] = ze, e[432] = Re, e[433] = Bt, e[434] = te, e[435] = at, e[436] = Pe, e[437] = Mi) : Mi = e[437];
    const Tl = Mi,
        Al = If(s.id, io, at, qt == null ? void 0 : qt.attachments);
    let vi;
    e[438] !== _n || e[439] !== Zr || e[440] !== p || e[441] !== s.id || e[442] !== Re || e[443] !== Q || e[444] !== ae || e[445] !== rn ? (vi = (f, H) => {
        if (f.preventDefault(), Q) {
            Zr.mutate();
            return
        }
        _n(s.id, H), Ze.logEventWithStatsig("Pause Completion", "chatgpt_pause_completion", {
            threadId: fc(s.id),
            currentLeafId: wt.getCurrentNode(Cc(s.id)).message.id,
            eventSource: "mouse"
        });
        const ie = Ko.current;
        rn && ie && (hr(dt(p), ie.content), _r.restoreFiles(Re, ie.files), Vd.setState({
            attachedTempTextdocs: ie.attachedTempTextdocs
        }), ie.systemHintType && (ae(ie.systemHintType), Ns(s.id, Oe => {
            var mt, _t;
            ie.selectedSources && (Oe.selectedSources = (mt = Oe.selectedSources) != null ? mt : new Map, Oe.selectedSources.set(ie.systemHintType, new Set(ie.selectedSources))), ie.selectedMCPSources && (Oe.selectedMCPSources = (_t = Oe.selectedMCPSources) != null ? _t : new Map, Oe.selectedMCPSources.set(ie.systemHintType, new Set(ie.selectedMCPSources)))
        })), Ko.current = null), J_()
    }, e[438] = _n, e[439] = Zr, e[440] = p, e[441] = s.id, e[442] = Re, e[443] = Q, e[444] = ae, e[445] = rn, e[446] = vi) : vi = e[446];
    const Il = vi;
    let Ti;
    e[447] !== p || e[448] !== He || e[449] !== (se == null ? void 0 : se.id) ? (Ti = () => {
        Gd.set(se == null ? void 0 : se.id, He, Q_(p))
    }, e[447] = p, e[448] = He, e[449] = se == null ? void 0 : se.id, e[450] = Ti) : Ti = e[450], se == null || se.id;
    const Sn = Ti,
        Ai = bt != null;
    let Ii, Pi;
    e[451] !== p || e[452] !== Ai || e[453] !== js ? (Ii = () => {
        Ai || js.composer.autofocusDisabled$() || Ds(dt(p))
    }, Pi = [p, Ai, js], e[451] = p, e[452] = Ai, e[453] = js, e[454] = Ii, e[455] = Pi) : (Ii = e[454], Pi = e[455]), F.useEffect(Ii, Pi);
    const wn = xo(Dt);
    let Ei;
    e[456] !== Re || e[457] !== rs || e[458] !== at.length || e[459] !== wn ? (Ei = () => {
        if (at.length > 0)
            for (const H of wn.current) Y_(H.file.type, rs) || _r.remove(Re, H.tempId, "none");
        else _r.reset(Re)
    }, e[456] = Re, e[457] = rs, e[458] = at.length, e[459] = wn, e[460] = Ei) : Ei = e[460];
    let ji;
    e[461] !== i || e[462] !== Re || e[463] !== rs || e[464] !== at.length || e[465] !== wn ? (ji = [i, Re, rs, at.length, wn], e[461] = i, e[462] = Re, e[463] = rs, e[464] = at.length, e[465] = wn, e[466] = ji) : ji = e[466], F.useEffect(Ei, ji);
    let Ri;
    e[467] !== s ? (Ri = () => {
        fo.set(s, null)
    }, e[467] = s, e[468] = Ri) : Ri = e[468];
    const Pl = F.useEffectEvent(Ri);
    let Bi;
    e[469] !== Kt || e[470] !== Pl || e[471] !== jt || e[472] !== X ? (Bi = () => {
        (!Kt && X || jt) && Pl()
    }, e[469] = Kt, e[470] = Pl, e[471] = jt, e[472] = X, e[473] = Bi) : Bi = e[473];
    let Ni;
    e[474] !== Kt || e[475] !== jt || e[476] !== X ? (Ni = [Kt, X, jt], e[474] = Kt, e[475] = jt, e[476] = X, e[477] = Ni) : Ni = e[477], F.useEffect(Bi, Ni);
    let Di;
    e[478] !== s || e[479] !== te ? (Di = () => X_(s).fullscreenWidgetPlaceholder$(te), e[478] = s, e[479] = te, e[480] = Di) : Di = e[480];
    const qc = fe(Di),
        xp = x2(),
        El = jp();
    let pt;
    e: {
        const f = u ? y_(u) : void 0;
        if (f) {
            pt = [f.placeholder, f.isLastingDisabledStyle];
            break e
        }
        if (El.pathname === "/shopping" || El.pathname === "/shopping/preview") {
            pt = [b_.promptPlaceholder, !1];
            break e
        }
        if (El.pathname.startsWith("/images")) {
            if (Dt.length > 0) {
                pt = [It.imagesAppEditPlaceholder, !1];
                break e
            }
            pt = [It.imagesAppPlaceholder, !1];
            break e
        }
        if (y) {
            pt = [It.placeholderWithName, !1];
            break e
        }
        if ((Ue == null ? void 0 : Ue.placeholderTextOverride) != null) {
            pt = [Ue.placeholderTextOverride, !1];
            break e
        }
        if ((d == null ? void 0 : d.id) === Pf) {
            pt = [It.n7jupdSystemHintPlaceholder, !1];
            break e
        }
        if (_e && (z != null && z.taskId.startsWith("thinking"))) {
            pt = [It.placeholderAsyncSteering, !1];
            break e
        }
        if (U) {
            if (Cd(U.systemHint))
                if (un) {
                    pt = [It.n7jupdActivePlaceholder, !1];
                    break e
                } else {
                    pt = [It.n7jupdSystemHintPlaceholder, !1];
                    break e
                }
            switch (U.systemHint) {
                case ue.Search:
                    {
                        pt = [It.searchPlaceholder, !1];
                        break e
                    }
                case ue.Think:
                    {
                        pt = [It.thinkPlaceholder, !1];
                        break e
                    }
                case ue.Slurm:
                    {
                        pt = [It.connectorPlaceholder, !1];
                        break e
                    }
                case ue.ApiTool:
                    {
                        pt = [It.apiToolPlaceholder, !1];
                        break e
                    }
                case ue.Research:
                    {
                        pt = [It.researchPlaceholder, !1];
                        break e
                    }
                case ue.Canvas:
                    {
                        pt = [It.canvasPlaceholder, !1];
                        break e
                    }
                case ue.Picture:
                    {
                        pt = [It.picturePlaceholder, !1];
                        break e
                    }
                case ue.PictureV2:
                    {
                        pt = [It.pictureV2Placeholder, !1];
                        break e
                    }
                case ue.Tatertot:
                    {
                        pt = [It.tatertotPlaceholder, !1];
                        break e
                    }
                case ue.Glaux:
                    {
                        pt = [It.internalSearchPlaceholder, !1];
                        break e
                    }
            }
        }
        pt = [It.placeholderAskAnythingVariant, !1]
    }
    const [Li, Sp] = pt;
    let Ss;
    e: {
        if (N) {
            let f;
            e[481] !== te || e[482] !== N ? (f = te.formatMessage(N), e[481] = te, e[482] = N, e[483] = f) : f = e[483], Ss = f;
            break e
        }
        if (so) {
            let f;
            e[484] !== te ? (f = te.formatMessage(x_), e[484] = te, e[485] = f) : f = e[485], Ss = f;
            break e
        }
        if (w)
            if (m) {
                Ss = te.formatMessage(Ef.newChatInProject, {
                    projectName: (rd = ge == null ? void 0 : ge.gizmo.display.name) != null ? rd : "this project"
                });
                break e
            } else {
                if (!Li) {
                    Ss = "​";
                    break e
                }
                Ss = te.formatMessage(Li, {
                    name: "ChatGPT"
                });
                break e
            }
        if (qc) {
            Ss = qc;
            break e
        }
        if (!Li) {
            Ss = "​";
            break e
        }
        Ss = te.formatMessage(Li, {
            name: bt != null ? Ut === "magic" ? jf : bt.name || "GPT" : (ld = ge == null ? void 0 : ge.gizmo.display.name) != null ? ld : "ChatGPT",
            workspaceName: xp,
            attachmentCount: Dt.length
        })
    }
    const jl = Ss;
    let Ui;
    e[490] !== p || e[491] !== s.id || e[492] !== r ? (Ui = () => Pd(() => jd(p), () => {
        Or.current = performance.now(), ag(r).getState().isThreadHeaderVisible && Id.hideThreadHeader(), c2(s.id) && d2(s.id)
    }), e[490] = p, e[491] = s.id, e[492] = r, e[493] = Ui) : Ui = e[493], F.useEffect(Ui);
    let Oi;
    e[494] !== p ? (Oi = S_(p), e[494] = p, e[495] = Oi) : Oi = e[495];
    const {
        shouldHighlight$: Rl
    } = Oi;
    let Fi;
    e[496] !== Rl ? (Fi = () => Rl(), e[496] = Rl, e[497] = Fi) : Fi = e[497];
    const ws = fe(Fi),
        {
            connectorConfig: cs,
            isLoading: Bl
        } = Rf(),
        Nl = qt == null ? void 0 : qt.attachments;
    let zi;
    e[498] !== cs || e[499] !== rs || e[500] !== at || e[501] !== Sn || e[502] !== Nl ? (zi = {
        connectorConfig: cs,
        modelSupportedImageMimeTypes: at,
        modelAcceptedMimeTypes: rs,
        attachmentsProductFeature: Nl,
        onOauthRedirect: Sn
    }, e[498] = cs, e[499] = rs, e[500] = at, e[501] = Sn, e[502] = Nl, e[503] = zi) : zi = e[503];
    const {
        onSelectConnector: Qs
    } = w_(zi);
    C_(cs, Qs);
    let Hi = null,
        Gi;
    e[504] !== al ? (Gi = al(), e[504] = al, e[505] = Gi) : Gi = e[505];
    const Kc = Gi,
        wp = de || Kc || ln,
        At = ps === mc.None ? br.ModelNotSupported : Yr && fp ? br.RateLimitReached : Yr ? br.HasReachedMaxFiles : oo != null ? br.RateLimitReached : void 0;
    let Wi;
    e[506] === Symbol.for("react.memo_cache_sentinel") ? (Wi = {
        viewTransitionName: "var(--vt-composer-attach-file-action)"
    }, e[506] = Wi) : Wi = e[506];
    let Cn;
    e[507] !== r || e[508] !== ol || e[509] !== il ? (Cn = ol() === "all" && (Zs() || il), e[507] = r, e[508] = ol, e[509] = il, e[510] = Cn) : Cn = e[510];
    const Dl = Kc && !ln,
        Ll = !Tt || bs,
        Ul = (cd = d == null ? void 0 : d.title) != null ? cd : "",
        Ol = de ? "composer-btn" : "legacy";
    let $i;
    e[511] !== cs || e[512] !== s.id || e[513] !== At || e[514] !== Bl || e[515] !== $e || e[516] !== at || e[517] !== Qs || e[518] !== Mt || e[519] !== ln || e[520] !== ws || e[521] !== Cn || e[522] !== Dl || e[523] !== Ll || e[524] !== Ul || e[525] !== Ol ? ($i = n.jsx("div", {
        "data-testid": "composer-action-file-upload",
        style: Wi,
        children: n.jsx($y, {
            clientThreadId: s.id,
            modelSupportedImageMimeTypes: at,
            openFileDialog: Mt,
            historyDisabled: $e,
            highlightTooltip: ws,
            isLoadingConnectors: Bl,
            connectorConfig: cs,
            onSelectConnector: Qs,
            showLabel: Cn,
            showUpsell: Dl,
            showMenuForNoAuth: ln,
            isDisabled: Ll,
            disabledReason: At,
            currentModelName: Ul,
            visualTreatment: Ol
        })
    }, "file-upload-button"), e[511] = cs, e[512] = s.id, e[513] = At, e[514] = Bl, e[515] = $e, e[516] = at, e[517] = Qs, e[518] = Mt, e[519] = ln, e[520] = ws, e[521] = Cn, e[522] = Dl, e[523] = Ll, e[524] = Ul, e[525] = Ol, e[526] = $i) : $i = e[526];
    const Cp = $i;
    let Vi;
    e[527] !== r || e[528] !== (d == null ? void 0 : d.title) || e[529] !== At || e[530] !== te || e[531] !== Tt || e[532] !== Mt ? (Vi = () => Qf(r).addAction({
        key: "uploadFile",
        action: Mt,
        actionMessageDescriptor: zu(r, te, !Tt, At, d == null ? void 0 : d.title),
        group: e2.Chat,
        keyboardBinding: Z_
    }), e[527] = r, e[528] = d == null ? void 0 : d.title, e[529] = At, e[530] = te, e[531] = Tt, e[532] = Mt, e[533] = Vi) : Vi = e[533];
    let qi;
    e[534] !== r || e[535] !== d || e[536] !== At || e[537] !== te || e[538] !== Tt || e[539] !== Mt ? (qi = [r, d, At, te, Tt, Mt], e[534] = r, e[535] = d, e[536] = At, e[537] = te, e[538] = Tt, e[539] = Mt, e[540] = qi) : qi = e[540], F.useEffect(Vi, qi);
    let Ki;
    if (e[541] !== r || e[542] !== P || e[543] !== de || e[544] !== w) {
        const f = Us(r, "853191128");
        let H;
        e[546] !== P ? (H = P != null && P.trim().length > 0, e[546] = P, e[547] = H) : H = e[547], Ki = !de && (!H || w) && Lt(r, "3259514411") && f.get("is_tatertot_enabled", !1), e[541] = r, e[542] = P, e[543] = de, e[544] = w, e[545] = Ki
    } else Ki = e[545];
    const Fl = Ki;
    let Ji;
    e[548] !== te ? (Ji = te.formatMessage({
        id: "composer.plusMenu.label",
        defaultMessage: "Add files and more"
    }), e[548] = te, e[549] = Ji) : Ji = e[549];
    let mo = Ji;
    if (de) {
        if (Ta) {
            let f;
            e[552] !== te ? (f = te.formatMessage({
                id: "composer.plusMenu.label.loggedIn.filesAndMore",
                defaultMessage: "Add photos"
            }), e[552] = te, e[553] = f) : f = e[553], mo = f
        }
    } else {
        let f;
        e[550] !== te ? (f = te.formatMessage({
            id: "composer.plusMenu.label.loggedOut.photosOnly",
            defaultMessage: "Add photos"
        }), e[550] = te, e[551] = f) : f = e[551], mo = f
    }
    if (kt && !ze) {
        let f;
        e[554] !== St || e[555] !== _ || e[556] !== Y || e[557] !== V || e[558] !== p || e[559] !== cs || e[560] !== s || e[561] !== d || e[562] !== i || e[563] !== At || e[564] !== ul || e[565] !== Tt || e[566] !== ee || e[567] !== bs || e[568] !== mo || e[569] !== M || e[570] !== at || e[571] !== Qs || e[572] !== Mt || e[573] !== G || e[574] !== oo || e[575] !== gs || e[576] !== ws || e[577] !== Ta ? (f = Ta ? n.jsx(k_, {
            disabled: V,
            clientThreadId: s.id,
            rateLimitPopup: oo,
            highlightTooltip: ws,
            label: mo,
            children: n.jsx(M_, {
                onClick: Mt,
                disabled: bs,
                plusButtonIcon: G
            })
        }) : n.jsx(v_, {
            conversation: s,
            composerController: p,
            composerDisabled: bs,
            layoutMode: M,
            openFileDialog: Mt,
            modelSupportedImageMimeTypes: at,
            isFileUploadEnabled: Tt,
            fileUploadDisabledReason: At,
            currentModelId: i,
            currentModelConfig: d,
            selectModelId: gs,
            connectorConfig: cs,
            onSelectConnector: Qs,
            availableSystemHints: Y,
            activeConnectorSystemHintTypes: St,
            activeSystemHintType: _,
            isFirstPartyProject: ee,
            onTakePhotoSave: ul
        }), e[554] = St, e[555] = _, e[556] = Y, e[557] = V, e[558] = p, e[559] = cs, e[560] = s, e[561] = d, e[562] = i, e[563] = At, e[564] = ul, e[565] = Tt, e[566] = ee, e[567] = bs, e[568] = mo, e[569] = M, e[570] = at, e[571] = Qs, e[572] = Mt, e[573] = G, e[574] = oo, e[575] = gs, e[576] = ws, e[577] = Ta, e[578] = f) : f = e[578], Hi = f
    }
    const [zl, Jc] = F.useState(!1), Hl = Sp || bp ? "disabled" : "default", Gl = !Vc;
    let Qi;
    e[579] !== u || e[580] !== Jr || e[581] !== _a || e[582] !== ca || e[583] !== ma || e[584] !== hs || e[585] !== $s || e[586] !== Ye || e[587] !== Gl ? (Qi = t2({
        promptDisabledReason: u,
        hasExceededFileUploadLimit: _a,
        hasPendingFiles: ca,
        hasTextContent: ma,
        isTextContentTooLong: $s,
        hasAsyncTaskPending: Jr,
        noSourceSelectedDr: Gl,
        isDeepResearchTaskStreaming: hs,
        isThreadHardBlocked: Ye
    }), e[579] = u, e[580] = Jr, e[581] = _a, e[582] = ca, e[583] = ma, e[584] = hs, e[585] = $s, e[586] = Ye, e[587] = Gl, e[588] = Qi) : Qi = e[588];
    const Wl = Qi;
    let Yi;
    e[589] !== r ? (Yi = Lt(r, "222560275"), e[589] = r, e[590] = Yi) : Yi = e[590];
    const $l = Yi;
    let Xi;
    e[591] !== i || e[592] !== $l ? (Xi = $l || i && !i.startsWith("o1") && !i.startsWith("o3"), e[591] = i, e[592] = $l, e[593] = Xi) : Xi = e[593];
    const Vl = Xi;
    let kn;
    e[594] !== yn || e[595] !== Ue ? (kn = Ue != null && Ue.label ? {
        type: Ue.type,
        value: Ue.label,
        onRemoveRegion: yn,
        onLabelClick: Ue.onLabelClick
    } : null, e[594] = yn, e[595] = Ue, e[596] = kn) : kn = e[596];
    let Mn;
    e[597] !== p || e[598] !== s || e[599] !== X ? (Mn = X != null ? {
        type: "mention",
        value: X.gizmo.display.name,
        icon: n.jsx(Wu, {
            isFirstParty: !!((dd = X.gizmo.tags) != null && dd.includes(Dc.FirstParty)),
            src: X.gizmo.display.profile_picture_url,
            className: "icon"
        }),
        onRemoveRegion: () => {
            fo.set(s, null), Ds(dt(p))
        }
    } : null, e[597] = p, e[598] = s, e[599] = X, e[600] = Mn) : Mn = e[600];
    let Ys;
    if (e[601] !== s.id || e[602] !== _e || e[603] !== kn || e[604] !== Mn || e[605] !== z) {
        if (Ys = [kn, Mn].filter(Rb), _e && z && z.taskId === _e) {
            let f;
            e[607] !== s.id || e[608] !== _e ? (f = _e.startsWith("thinking") ? void 0 : () => _c(s.id), e[607] = s.id, e[608] = _e, e[609] = f) : f = e[609];
            let H;
            e[610] !== f || e[611] !== z.title ? (H = {
                type: "text",
                value: z.title,
                hideQuotes: !0,
                onRemoveRegion: f
            }, e[610] = f, e[611] = z.title, e[612] = H) : H = e[612], Ys.push(H)
        }
        e[601] = s.id, e[602] = _e, e[603] = kn, e[604] = Mn, e[605] = z, e[606] = Ys
    } else Ys = e[606];
    const ql = Zu();
    let Zi;
    e[613] !== (U == null ? void 0 : U.systemHint) || e[614] !== ql || e[615] !== L || e[616] !== m || e[617] !== Ws || e[618] !== bn ? (Zi = Mr(() => m && !L && (U == null ? void 0 : U.systemHint) !== ue.Research && (U == null ? void 0 : U.systemHint) !== ue.ApiTool && !Ws && !ql.visible$() && bn()), e[613] = U == null ? void 0 : U.systemHint, e[614] = ql, e[615] = L, e[616] = m, e[617] = Ws, e[618] = bn, e[619] = Zi) : Zi = e[619];
    const Kl = Zi;
    let er;
    e[620] !== xs || e[621] !== ls || e[622] !== Q || e[623] !== Sa || e[624] !== hs || e[625] !== Ps || e[626] !== no || e[627] !== xn || e[628] !== Il ? (er = f => {
        f.preventDefault(), f.stopPropagation(), xs === "streaming" && (!no || Ps || xn || Sa) || Q ? hs ? Jc(!0) : Il(f, Ps ? "stop_button" : "stop_button_with_prompt") : ls(f)
    }, e[620] = xs, e[621] = ls, e[622] = Q, e[623] = Sa, e[624] = hs, e[625] = Ps, e[626] = no, e[627] = xn, e[628] = Il, e[629] = er) : er = e[629];
    const Jl = er;
    let tr;
    e[630] !== (l == null ? void 0 : l.normalizedAccountUserId) || e[631] !== p || e[632] !== s.id || e[633] !== q || e[634] !== ft || e[635] !== $e ? (tr = () => {
        const f = fc(s.id),
            H = l == null ? void 0 : l.normalizedAccountUserId;
        if (!H || q || ft || $e) return;
        const ie = Yf(Oe => {
            if (Xf(Oe.doc)) Zf(f);
            else {
                const mt = Td(Oe.doc).content;
                eg(f, mt, H)
            }
        }, 1e3);
        return Pd(() => jd(p), ie)
    }, e[630] = l == null ? void 0 : l.normalizedAccountUserId, e[631] = p, e[632] = s.id, e[633] = q, e[634] = ft, e[635] = $e, e[636] = tr) : tr = e[636];
    let sr;
    e[637] !== l || e[638] !== p || e[639] !== s.id || e[640] !== q || e[641] !== ft || e[642] !== $e || e[643] !== He ? (sr = [l, s.id, p, q, ft, $e, He], e[637] = l, e[638] = p, e[639] = s.id, e[640] = q, e[641] = ft, e[642] = $e, e[643] = He, e[644] = sr) : sr = e[644], F.useEffect(tr, sr);
    let nr;
    e[645] === Symbol.for("react.memo_cache_sentinel") ? (nr = [], e[645] = nr) : nr = e[645], F.useEffect(Eb, nr);
    let vn;
    e[646] !== _ || e[647] !== s.id || e[648] !== a ? (vn = f => {
        var H;
        return a({
            event: f,
            conversationMode: (H = Cc(s.id)) == null ? void 0 : H.mode,
            systemHints: _ ? [_] : []
        })
    }, e[646] = _, e[647] = s.id, e[648] = a, e[649] = vn) : vn = e[649];
    let or;
    e[650] !== K || e[651] !== Kt || e[652] !== D || e[653] !== V || e[654] !== p || e[655] !== s.id || e[656] !== T || e[657] !== J || e[658] !== pe || e[659] !== Js || e[660] !== m || e[661] !== Mt || e[662] !== R || e[663] !== vn ? (or = n.jsx(gy, {
        canUseInlineTagging: Kt,
        isDisabled: V,
        clientThreadId: s.id,
        currentLeafId: J,
        currentRequestId: pe,
        canContinue: K,
        composerController: p,
        isNewThread: m,
        onContinueGenerating: vn,
        onResetState: Js,
        openFileDialog: Mt,
        conversationMode: T,
        pulseOnboardingEntrypoint: R,
        cocoonEntrypointResponse: D
    }), e[650] = K, e[651] = Kt, e[652] = D, e[653] = V, e[654] = p, e[655] = s.id, e[656] = T, e[657] = J, e[658] = pe, e[659] = Js, e[660] = m, e[661] = Mt, e[662] = R, e[663] = vn, e[664] = or) : or = e[664];
    const Ql = or;
    let ar;
    e[665] !== s || e[666] !== T || e[667] !== Sl || e[668] !== un || e[669] !== Vl ? (ar = !un && T != null && Vl && T_.includes(T.kind) && n.jsx(A_, {
        conversation: s,
        onTargetedReply: Sl
    }), e[665] = s, e[666] = T, e[667] = Sl, e[668] = un, e[669] = Vl, e[670] = ar) : ar = e[670];
    const Yl = ar;
    let ir;
    e[671] !== p || e[672] !== Al ? (ir = n.jsx(s2, {
        composerController: p,
        parsedDocumentHandler: Al
    }), e[671] = p, e[672] = Al, e[673] = ir) : ir = e[673];
    const Xl = ir;
    let rr;
    e[674] !== S || e[675] !== v ? (rr = !v && n.jsx(Z2, {
        className: S
    }), e[674] = S, e[675] = v, e[676] = rr) : rr = e[676];
    const Zl = rr,
        ec = qt == null ? void 0 : qt.attachments;
    let lr;
    e[677] !== Ks || e[678] !== at || e[679] !== ec ? (lr = n.jsx(I_, {
        modelSupportedImageMimeTypes: at,
        uploadType: mc.Multimodal,
        attachmentsProductFeature: ec,
        contextScopes: Ks
    }), e[677] = Ks, e[678] = at, e[679] = ec, e[680] = lr) : lr = e[680];
    const tc = lr;
    let cr;
    e[681] !== r ? (cr = Lt(r, "3127600850"), e[681] = r, e[682] = cr) : cr = e[682];
    const sc = cr;
    let dr;
    e[683] !== r ? (dr = Lt(r, "278871159"), e[683] = r, e[684] = dr) : dr = e[684];
    const nc = dr,
        oc = !kt && wp ? Cp : null;
    let Tn;
    e[685] !== l || e[686] !== _ || e[687] !== Y || e[688] !== ms || e[689] !== p || e[690] !== s.id || e[691] !== d || e[692] !== Ee || e[693] !== P || e[694] !== de || e[695] !== kt || e[696] !== bs || e[697] !== ys || e[698] !== ll ? (Tn = !de && !kt && !ys ? n.jsx(P_, {
        account: l,
        clientBootstrapFlags: ms,
        features: Ee,
        currentModelConfig: d,
        isDisabled: bs,
        clientThreadId: s.id,
        composerController: p,
        gizmoId: P
    }) : ll ? n.jsx(E_, {
        activeSystemHintType: _,
        systemHints: Y,
        composerController: p,
        clientThreadId: s.id,
        disabled: bs
    }) : null, e[685] = l, e[686] = _, e[687] = Y, e[688] = ms, e[689] = p, e[690] = s.id, e[691] = d, e[692] = Ee, e[693] = P, e[694] = de, e[695] = kt, e[696] = bs, e[697] = ys, e[698] = ll, e[699] = Tn) : Tn = e[699];
    let An;
    e[700] !== p || e[701] !== s.id || e[702] !== Fl || e[703] !== ee || e[704] !== de || e[705] !== kt || e[706] !== ys ? (An = !de && !kt && !ys && Fl && !ee ? n.jsx(j_, {
        composerController: p,
        clientThreadId: s.id
    }) : null, e[700] = p, e[701] = s.id, e[702] = Fl, e[703] = ee, e[704] = de, e[705] = kt, e[706] = ys, e[707] = An) : An = e[707];
    let In;
    e[708] !== ee || e[709] !== de || e[710] !== kt || e[711] !== ys ? (In = !de && !kt && !ys && !ee ? n.jsx(n2, {}) : null, e[708] = ee, e[709] = de, e[710] = kt, e[711] = ys, e[712] = In) : In = e[712];
    let ur;
    e[713] !== oc || e[714] !== Tn || e[715] !== An || e[716] !== In ? (ur = [oc, Tn, An, In].filter(Pb), e[713] = oc, e[714] = Tn, e[715] = An, e[716] = In, e[717] = ur) : ur = e[717];
    const ac = ur;
    let pr;
    e[718] === Symbol.for("react.memo_cache_sentinel") ? (pr = Ct("pointer-events-auto relative z-1 flex h-(--composer-container-height,100%) max-w-full flex-(--composer-container-flex,1) flex-col"), e[718] = pr) : pr = e[718];
    let Pn;
    e[719] !== Sn ? (Pn = n.jsx(o2, {
        onOauthRedirect: Sn
    }), e[719] = Sn, e[720] = Pn) : Pn = e[720];
    let En;
    e[721] !== sc ? (En = sc && n.jsx(Tb, {}), e[721] = sc, e[722] = En) : En = e[722];
    let jn;
    e[723] !== p || e[724] !== s.id || e[725] !== so || e[726] !== nc ? (jn = nc && so && n.jsx(Ab, {
        conversationId: s.id,
        composerController: p
    }), e[723] = p, e[724] = s.id, e[725] = so, e[726] = nc, e[727] = jn) : jn = e[727];
    let Rn;
    e[728] !== zl || e[729] !== s.id || e[730] !== z ? (Rn = z && zl && n.jsx(R_, {
        taskId: z.taskId,
        clientThreadId: s.id,
        onClose: () => Jc(!1)
    }), e[728] = zl, e[729] = s.id, e[730] = z, e[731] = Rn) : Rn = e[731];
    const ic = !Tt,
        kp = Hi,
        rc = Fs || !de && !kt;
    let Bn;
    e[732] !== fl ? (Bn = fl(), e[732] = fl, e[733] = Bn) : Bn = e[733];
    let Nn;
    e[734] !== Bn ? (Nn = n.jsx("input", Rt({}, Bn)), e[734] = Bn, e[735] = Nn) : Nn = e[735];
    const lc = kt ? void 0 : !0;
    let Dn;
    e[736] !== rt || e[737] !== ht ? (Dn = rt || (ht == null ? void 0 : ht.has("cloud")), e[736] = rt, e[737] = ht, e[738] = Dn) : Dn = e[738];
    let Ln;
    e[739] !== Wr || e[740] !== U || e[741] !== qe || e[742] !== p || e[743] !== Hi || e[744] !== ac || e[745] !== xs || e[746] !== gt || e[747] !== s || e[748] !== T || e[749] !== d || e[750] !== nn || e[751] !== I || e[752] !== Wl || e[753] !== ha || e[754] !== At || e[755] !== P || e[756] !== la || e[757] !== Hl || e[758] !== Gs || e[759] !== kt || e[760] !== $e || e[761] !== M || e[762] !== Jl || e[763] !== Dt || e[764] !== jl || e[765] !== Vs || e[766] !== dn || e[767] !== fs || e[768] !== Ys || e[769] !== us || e[770] !== on || e[771] !== hn || e[772] !== nl || e[773] !== ws || e[774] !== ct || e[775] !== Fs || e[776] !== ic || e[777] !== rc || e[778] !== Nn || e[779] !== lc || e[780] !== Dn ? (Ln = n.jsx(Sb, {
        hasFiles: la,
        pendingFiles: Dt,
        isUploadDisabled: ic,
        conversation: s,
        highlightUploadTooltip: ws,
        disableReason: Wl,
        excessFileCount: ha,
        remainingFileUploads: Vs,
        uploadButtonDisabledReason: At,
        currentModelConfig: d,
        conversationMode: T,
        state: xs,
        inputState: Hl,
        gizmoId: P,
        includeSidebarContextTray: hn,
        isTemporaryChat: $e,
        placeholder: jl,
        composerController: p,
        onSubmit: Jl,
        replyRegions: Ys,
        leadingAction: kp,
        legacyFooterActions: ac,
        activeSystemHint: U,
        activeConnectorSystemHints: Wr,
        isDeepResearchAppActive: Gs,
        deepResearchModelVariant: nn,
        onChangeDeepResearchModelVariant: on,
        selectedHazelnutIds: us,
        shouldShowAgentSessionModeDropdown: ct,
        hideSystemHint: rc,
        isSystemHintLocked: Fs,
        onRemoveSystemHint: fs,
        forceStopButton: nl,
        onRemoveModel: dn,
        contextualAnswerUserConnectionData: gt,
        fileInput: Nn,
        expanded: lc,
        expandOnMultilineInput: kt,
        layoutMode: M,
        agentSessionModeNuxModal: qe,
        isAgentSessionModeDropdownDisabled: Dn,
        disableAdvancedVoiceMode: I
    }), e[739] = Wr, e[740] = U, e[741] = qe, e[742] = p, e[743] = Hi, e[744] = ac, e[745] = xs, e[746] = gt, e[747] = s, e[748] = T, e[749] = d, e[750] = nn, e[751] = I, e[752] = Wl, e[753] = ha, e[754] = At, e[755] = P, e[756] = la, e[757] = Hl, e[758] = Gs, e[759] = kt, e[760] = $e, e[761] = M, e[762] = Jl, e[763] = Dt, e[764] = jl, e[765] = Vs, e[766] = dn, e[767] = fs, e[768] = Ys, e[769] = us, e[770] = on, e[771] = hn, e[772] = nl, e[773] = ws, e[774] = ct, e[775] = Fs, e[776] = ic, e[777] = rc, e[778] = Nn, e[779] = lc, e[780] = Dn, e[781] = Ln) : Ln = e[781];
    let Un;
    e[782] !== Y ? (Un = Y != null ? Y : [], e[782] = Y, e[783] = Un) : Un = e[783];
    let On;
    e[784] !== Y ? (On = Y != null ? Y : [], e[784] = Y, e[785] = On) : On = e[785];
    const cc = d != null ? d : null,
        dc = P != null ? P : null;
    let Fn;
    e[786] !== s ? (Fn = f => fo.set(s, f), e[786] = s, e[787] = Fn) : Fn = e[787];
    let zn;
    e[788] !== Kt || e[789] !== p || e[790] !== pn || e[791] !== gt || e[792] !== s.id || e[793] !== At || e[794] !== jt || e[795] !== Tt || e[796] !== ee || e[797] !== M || e[798] !== Mt || e[799] !== gs || e[800] !== ae || e[801] !== Un || e[802] !== On || e[803] !== cc || e[804] !== dc || e[805] !== Fn ? (zn = n.jsx(Ry, {
        systemHints: Un,
        availableSystemHints: On,
        composerController: p,
        clientThreadId: s.id,
        layoutMode: M,
        composerLayer: pn,
        canUseInlineTagging: Kt,
        isFileUploadEnabled: Tt,
        fileUploadDisabledReason: At,
        currentModelConfig: cc,
        openFileDialog: Mt,
        connectionInstanceData: gt,
        setActiveSystemHintType: ae,
        selectModelId: gs,
        gizmoId: dc,
        hasGizmoFeatureRateLimit: jt,
        setSelectedGizmoTag: Fn,
        isFirstPartyProject: ee
    }), e[788] = Kt, e[789] = p, e[790] = pn, e[791] = gt, e[792] = s.id, e[793] = At, e[794] = jt, e[795] = Tt, e[796] = ee, e[797] = M, e[798] = Mt, e[799] = gs, e[800] = ae, e[801] = Un, e[802] = On, e[803] = cc, e[804] = dc, e[805] = Fn, e[806] = zn) : zn = e[806];
    let Hn;
    e[807] !== s.id || e[808] !== us ? (Hn = n.jsx(B_, {
        selectedHazelnutIds: us,
        conversationId: s.id
    }), e[807] = s.id, e[808] = us, e[809] = Hn) : Hn = e[809];
    let Gn;
    e[810] !== s.id ? (Gn = !1, e[810] = s.id, e[811] = Gn) : Gn = e[811];
    let Wn;
    e[812] !== s.id || e[813] !== r || e[814] !== B || e[815] !== Z ? (Wn = n.jsx(N_, {
        ctx: r,
        searchParams: B,
        setSearchParams: Z,
        conversationId: s.id
    }), e[812] = s.id, e[813] = r, e[814] = B, e[815] = Z, e[816] = Wn) : Wn = e[816];
    let $n;
    e[817] !== _ || e[818] !== Kl || e[819] !== p || e[820] !== s.id || e[821] !== M ? ($n = !Eu(_) && n.jsx(D_, {
        canShowAutocomplete$: Kl,
        layoutMode: M,
        composerController: p,
        clientThreadId: s.id
    }), e[817] = _, e[818] = Kl, e[819] = p, e[820] = s.id, e[821] = M, e[822] = $n) : $n = e[822];
    let Vn;
    e[823] !== Tl || e[824] !== Zl || e[825] !== Pn || e[826] !== En || e[827] !== jn || e[828] !== Rn || e[829] !== Ln || e[830] !== zn || e[831] !== Hn || e[832] !== Gn || e[833] !== Wn || e[834] !== $n ? (Vn = n.jsxs("div", {
        className: pr,
        onPaste: Tl,
        children: [Pn, En, jn, Zl, Rn, Ln, zn, Hn, Gn, Wn, $n]
    }), e[823] = Tl, e[824] = Zl, e[825] = Pn, e[826] = En, e[827] = jn, e[828] = Rn, e[829] = Ln, e[830] = zn, e[831] = Hn, e[832] = Gn, e[833] = Wn, e[834] = $n, e[835] = Vn) : Vn = e[835];
    let qn;
    e[836] !== _ || e[837] !== Y || e[838] !== s || e[839] !== fs ? (qn = _ && Y && n.jsx(i3, {
        conversation: s,
        availableSystemHints: Y,
        systemHintType: _,
        onRemoveSystemHint: fs
    }), e[836] = _, e[837] = Y, e[838] = s, e[839] = fs, e[840] = qn) : qn = e[840];
    let mr;
    return e[841] !== io || e[842] !== Xl || e[843] !== tc || e[844] !== Ql || e[845] !== Vn || e[846] !== qn || e[847] !== Yl ? (mr = n.jsxs(L_.Provider, {
        value: io,
        children: [Vn, Xl, Ql, Yl, tc, qn]
    }), e[841] = io, e[842] = Xl, e[843] = tc, e[844] = Ql, e[845] = Vn, e[846] = qn, e[847] = Yl, e[848] = mr) : mr = e[848], mr
}

function Pb(t) {
    return t != null
}

function Eb() {
    setTimeout(jb, 0)
}

function jb() {
    const t = ng.addFirstTiming("composer.ttfi", {
        serialTimingGroup: "pageLoad"
    });
    t && Ze.logEventWithStatsig("chatgpt_page_load_ttfi", "chatgpt_page_load_ttfi", {
        time: t
    })
}

function Rb(t) {
    return t != null
}

function Bb(t) {
    i2.startEnforcement(t), r2.startEnforcement(t)
}

function Nb(t) {
    const [e, o] = t;
    return [e, Rt({}, o)]
}

function Db(t) {
    return Rt({}, t)
}

function Lb(t) {
    return t.status === "ONLY_ME"
}

function Ub(t) {
    return t === ue.Slurm || t === ue.Research
}

function Ob(t) {
    return t.delete("sources"), t
}

function Fb(t) {
    return !Ms(t)
}

function zb(t) {
    return t.trim()
}

function Hb(t) {
    return t.delete("github_onboarding"), t
}

function Gb(t) {
    var o, a;
    const e = (a = (o = t.selectedSources) == null ? void 0 : o.get(ue.Slurm)) != null ? a : new Set;
    t.selectedSources == null && (t.selectedSources = new Map), t.selectedSources.set(ue.Slurm, new Set([...e, nt.GITHUB_CONNECTOR]))
}

function Wb(t) {
    return t.systemHint === ue.Slurm
}

function $b(t) {
    return !Ms(t)
}

function Vb(t) {
    return t.trim()
}

function qb(t) {
    return t.delete("share_prompt"), t
}

function Kb(t) {
    return t.selectedApps
}

function Jb() {
    return a2()
}

function Qb(t) {
    return t.gizmoId == null
}

function Yb(t) {
    return t.gizmoId != null
}

function Xb(t) {
    return t && t.selectedHazelnuts && t.selectedHazelnuts.length > 0 ? [...t.selectedHazelnuts] : []
}

function Zb(t) {
    return t !== void 0
}

function e3(t) {
    return t.systemHint === ue.Glaux
}

function t3(t) {
    const {
        locked: e
    } = t;
    return e
}

function s3() {}

function n3(t) {
    return tg(4122927380, t.systemHint)
}

function o3(t) {
    return t.systemHint === ue.Research
}

function a3(t) {
    var e, o, a, l, i, d;
    return [wt.getCurrentLeafId(t), wt.getRequestId(t), wt.findAsyncTaskMetadataNode(t, wt.getSteeringAsyncTaskId(t)), (a = (o = (e = wt.lastUserMessage(t)) == null ? void 0 : e.metadata) == null ? void 0 : o.system_hints) == null ? void 0 : a.includes(ue.Agent), !!(t != null && t.interruptionInProgress) && !!((i = (l = wt.getCurrentNode(t)) == null ? void 0 : l.message.metadata) != null && i.n7jupd_message), t == null ? void 0 : t.startedWithByoMcp, (d = wt.getCurrentNode(t)) == null ? void 0 : d.message]
}
const i3 = t => {
        "use forget";
        const e = Et.c(28),
            {
                conversation: o,
                availableSystemHints: a,
                systemHintType: l,
                onRemoveSystemHint: i
            } = t;
        let d;
        e[0] !== a || e[1] !== l ? (d = a != null && !Eu(l) && a.every(P => P.systemHint !== l), e[0] = a, e[1] = l, e[2] = d) : d = e[2];
        const b = d;
        let s;
        e[3] !== o ? (s = () => ig(o), e[3] = o, e[4] = s) : s = e[4];
        const m = fe(s),
            {
                isBlocked: x
            } = $u(l),
            C = Ke();
        let u;
        e[5] !== C ? (u = Zs(), e[5] = C, e[6] = u) : u = e[6];
        const c = !u;
        let g;
        e[7] !== m || e[8] !== x || e[9] !== c || e[10] !== b || e[11] !== i ? (g = () => {
            m && (b || x) && !c && i()
        }, e[7] = m, e[8] = x, e[9] = c, e[10] = b, e[11] = i, e[12] = g) : g = e[12];
        let y;
        e[13] !== m || e[14] !== x || e[15] !== c || e[16] !== b || e[17] !== i || e[18] !== l ? (y = [b, x, c, i, l, m], e[13] = m, e[14] = x, e[15] = c, e[16] = b, e[17] = i, e[18] = l, e[19] = y) : y = e[19], F.useEffect(g, y);
        const S = Ht(o.id, wt.getLastAssistantMessage),
            v = Pu();
        let j;
        e[20] !== C ? (j = Lt(C, "2857215914"), e[20] = C, e[21] = j) : j = e[21];
        const M = j;
        let h, w;
        return e[22] !== v || e[23] !== S || e[24] !== i || e[25] !== M ? (h = () => {
            var P;
            if (M) {
                const R = (v == null ? void 0 : v.has("connector:connector_openai_shopping")) === !0,
                    D = (S == null ? void 0 : S.channel) === "final" && ((P = S == null ? void 0 : S.metadata) == null ? void 0 : P.mercury_message) === !0 && S.status === "in_progress";
                R && D && i()
            }
        }, w = [v, S, i, M], e[22] = v, e[23] = S, e[24] = i, e[25] = M, e[26] = h, e[27] = w) : (h = e[26], w = e[27]), F.useEffect(h, w), null
    },
    r3 = Ts(() => vs(() =>
        import ("./k488bo5tj9qgdrgq.js").then(t => t.v), __vite__mapDeps([17, 1, 3, 4, 18, 2, 5, 19, 20, 21, 22, 23, 24, 25, 26, 27])).then(t => t.VoiceHintContainer));

function v3(t) {
    "use forget";
    var Ae, yt;
    const e = Et.c(76),
        {
            conversation: o,
            currentModelId: a,
            disableDraftPersistence: l,
            isNewThread: i,
            isProjectThread: d,
            onRequestCompletion: b,
            onContinueGenerating: s,
            headerClassName: m,
            hideHeader: x,
            onlyAllowImageUploads: C,
            layoutMode: u,
            pulseOnboardingEntrypoint: c,
            cocoonEntrypointResponse: g,
            disableAdvancedVoiceMode: y,
            plusButtonAddsFiles: S,
            plusButtonIcon: v,
            hideLoggedOutToolButtons: j,
            placeholder: M
        } = t,
        h = l === void 0 ? !1 : l,
        w = d === void 0 ? !1 : d,
        P = u === void 0 ? "bottom" : u,
        R = y === void 0 ? !1 : y,
        D = Ke();
    let E;
    e[0] !== o ? (E = () => Bc(o), e[0] = o, e[1] = E) : E = e[1];
    const A = fe(E),
        [G, k, N, q, V, re] = Ht(o.id, c3);
    let K;
    e[2] !== D ? (K = tu(D), e[2] = D, e[3] = K) : K = e[3];
    const I = K,
        r = Pc();
    let oe;
    e[4] !== o.id ? (oe = {
        clientThreadId: o.id
    }, e[4] = o.id, e[5] = oe) : oe = e[5];
    const T = u2(oe);
    let ge;
    e[6] === Symbol.for("react.memo_cache_sentinel") ? (ge = {
        type: "just-hit-rate-limit"
    }, e[6] = ge) : ge = e[6];
    const {
        isOpen: Ce,
        onClose: X
    } = p2(ge);
    let B;
    e: {
        if (!T) {
            B = !G && k;
            break e
        }
        B = !1
    }
    const Z = B,
        L = T,
        p = rg(o.id),
        se = Ht(o.id, wt.hasRecentPIMWarning),
        Me = lg(p).data,
        Be = m2();
    let Ie;
    e: {
        if (se) {
            Ie = "pimBlock";
            break e
        }
        if (q) {
            Ie = "readOnlyConversation";
            break e
        }
        if (((Ae = Me == null ? void 0 : Me.gizmo.tags) == null ? void 0 : Ae.includes(Dc.WorkspaceDisabled)) && !Be) {
            Ie = "workspaceDisallowsGizmo";
            break e
        }
        if (A.models.size === 0) {
            Ie = "noModelsAvailable";
            break e
        }
        if ((N == null ? void 0 : N.kind) === ru.GizmoTest && N.gizmo_id == null) {
            Ie = "noTestGizmoId";
            break e
        }
        Ie = null
    }
    const be = Ie,
        ve = Rp(),
        ce = cg(),
        Ne = ve.action === "moderate";
    let et;
    e[7] !== D ? (et = Lt(D, "1860647109"), e[7] = D, e[8] = et) : et = e[8];
    const tt = et,
        de = Mc.useState(l3),
        Ge = dg(),
        De = (yt = Me == null ? void 0 : Me.gizmo.id) != null ? yt : Ge;
    let te;
    e[9] !== D || e[10] !== De ? (te = ug(D, De), e[9] = D, e[10] = De, e[11] = te) : te = e[11];
    const Pe = te;
    let Re;
    e[12] !== a || e[13] !== A ? (Re = pg(A, a), e[12] = a, e[13] = A, e[14] = Re) : Re = e[14];
    const We = Re;
    let ee;
    e[15] !== o || e[16] !== de ? (ee = () => de ? [] : h2(o), e[15] = o, e[16] = de, e[17] = ee) : ee = e[17];
    const Se = fe(ee),
        J = vo(),
        pe = R ? !1 : J;
    let he;
    e[18] !== Se || e[19] !== r || e[20] !== o.id || e[21] !== a || e[22] !== T ? (he = n.jsx(f2, {
        availableSystemHints: Se,
        composerController: r,
        clientThreadId: o.id,
        currentModelId: a,
        isCompletionInProgress: T
    }), e[18] = Se, e[19] = r, e[20] = o.id, e[21] = a, e[22] = T, e[23] = he) : he = e[23];
    let ye;
    e[24] !== Ne || e[25] !== tt || e[26] !== ce ? (ye = ce && Ne && tt ? n.jsx(_2, {}) : null, e[24] = Ne, e[25] = tt, e[26] = ce, e[27] = ye) : ye = e[27];
    let ke;
    e[28] !== ye ? (ke = n.jsx("div", {
        className: "flex justify-center empty:hidden",
        children: ye
    }), e[28] = ye, e[29] = ke) : ke = e[29];
    let Le;
    e[30] !== Ce || e[31] !== X ? (Le = Ce ? n.jsx(y2, {
        onClose: X
    }) : null, e[30] = Ce, e[31] = X, e[32] = Le) : Le = e[32];
    let ne;
    e[33] !== (I == null ? void 0 : I.normalizedAccountUserId) || e[34] !== o.id || e[35] !== w ? (ne = w && n.jsx(g2, {
        clientThreadId: o.id,
        accountUserId: I == null ? void 0 : I.normalizedAccountUserId
    }), e[33] = I == null ? void 0 : I.normalizedAccountUserId, e[34] = o.id, e[35] = w, e[36] = ne) : ne = e[36];
    let Te;
    e[37] !== o.id || e[38] !== pe ? (Te = pe ? n.jsx("div", {
        className: "relative flex items-center justify-center",
        children: n.jsx(r3, {
            conversationId: o.id
        })
    }) : null, e[37] = o.id, e[38] = pe, e[39] = Te) : Te = e[39];
    const it = o.id,
        z = !!be,
        $ = be != null ? be : void 0,
        le = ce || V || re;
    let Q;
    e[40] !== I || e[41] !== Se || e[42] !== Z || e[43] !== L || e[44] !== g || e[45] !== o || e[46] !== We || e[47] !== a || e[48] !== R || e[49] !== h || e[50] !== De || e[51] !== m || e[52] !== x || e[53] !== j || e[54] !== T || e[55] !== i || e[56] !== Pe || e[57] !== P || e[58] !== s || e[59] !== b || e[60] !== C || e[61] !== M || e[62] !== S || e[63] !== v || e[64] !== c || e[65] !== z || e[66] !== $ || e[67] !== le ? (Q = n.jsx(Ib, {
        conversation: o,
        disableDraftPersistence: h,
        onCreateNewCompletion: b,
        onContinueGenerating: s,
        currentModelId: a,
        account: I,
        currentModelConfig: We,
        isNewThread: i,
        isCompletionInProgress: T,
        className: "w-full",
        canContinue: Z,
        disabled: z,
        disabledReason: $,
        canPause: L,
        isInteractableSharedThread: le,
        headerClassName: m,
        hideHeader: x,
        onlyAllowImageUploads: C,
        layoutMode: P,
        availableSystemHints: Se,
        isSnorlaxEnabledForGizmo: Pe,
        gizmoId: De,
        pulseOnboardingEntrypoint: c,
        cocoonEntrypointResponse: g,
        disableAdvancedVoiceMode: R,
        plusButtonAddsFiles: S,
        plusButtonIcon: v,
        hideLoggedOutToolButtons: j,
        placeholder: M
    }, it), e[40] = I, e[41] = Se, e[42] = Z, e[43] = L, e[44] = g, e[45] = o, e[46] = We, e[47] = a, e[48] = R, e[49] = h, e[50] = De, e[51] = m, e[52] = x, e[53] = j, e[54] = T, e[55] = i, e[56] = Pe, e[57] = P, e[58] = s, e[59] = b, e[60] = C, e[61] = M, e[62] = S, e[63] = v, e[64] = c, e[65] = z, e[66] = $, e[67] = le, e[68] = Q) : Q = e[68];
    let _e;
    return e[69] !== he || e[70] !== ke || e[71] !== Le || e[72] !== ne || e[73] !== Te || e[74] !== Q ? (_e = n.jsxs(n.Fragment, {
        children: [he, ke, Le, ne, Te, Q]
    }), e[69] = he, e[70] = ke, e[71] = Le, e[72] = ne, e[73] = Te, e[74] = Q, e[75] = _e) : _e = e[75], _e
}

function l3(t) {
    const {
        locked: e
    } = t;
    return e
}

function c3(t) {
    var o;
    const e = wt.getCurrentNode(t);
    return [((o = e.message.clientMetadata) == null ? void 0 : o.errType) != null && e.message.clientMetadata.errType !== "info", mg(wt.getCurrentNode(t).message), t == null ? void 0 : t.mode, wt.getIsReadOnly(t), !!(t != null && t.continuingFromSharedPostId), (t == null ? void 0 : t.continuingFromSharedProjectConversationId) != null]
}
export {
    _b as C, M3 as D, k3 as M, v3 as P, Y2 as S, C3 as T, Z2 as a, D2 as b, G2 as c, U2 as d, B2 as p, np as u
};
//# sourceMappingURL=eejiqzdptzp07q5y.js.map