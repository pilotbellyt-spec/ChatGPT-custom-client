import {
    r as T,
    j as l,
    i as C
} from "./fg33krlcm0qyi6yw.js";
import {
    k_ as p,
    tI as I,
    hh as _,
    nm as k,
    dF as S,
    dH as g,
    _ as h,
    o2 as V,
    M as x,
    C as A
} from "./dykg4ktvbu3mhmdo.js";
import {
    cV as y,
    jf as v,
    jg as f,
    eB as m,
    bM as N,
    df as b
} from "./k15yxxoybkkir2ou.js";
import {
    D as w
} from "./cu0e6szsqsyduwov.js";
import {
    u as j,
    g as M
} from "./fz8xw1971c2kf2eb.js";
import {
    M as B
} from "./ebc4iyfg14nu1gw4.js";

function E(d) {
    const {
        button: r,
        conversationId: t,
        onClick: s
    } = d, a = _(t), {
        startVoiceMode: n
    } = j(), o = C(), e = k(), u = T.useCallback(async () => {
        switch (r.action) {
            case "new_chat":
                {
                    v(f.ModalNewChat);
                    const i = M({
                        serverThreadId: void 0,
                        isAdvancedMode: !0,
                        eventSource: "modal_".concat(r.action),
                        parentMessageId: void 0,
                        clientThreadId: V(),
                        gizmoId: void 0,
                        skipCacheReason: "modal-new-chat-button"
                    });
                    if (e) try {
                        await m({
                            type: "STOP",
                            reason: w.UserNavigatedAway
                        });
                        const c = g(t);
                        c != null && c.disableConversationNavigation || N(o, {
                            replace: !0
                        }), await m({
                            type: "START",
                            args: i,
                            oldConversationId: a != null ? a : t
                        })
                    } catch (c) {
                        h.addError(c, {
                            message: "New chat button in IUX failed"
                        })
                    } else b("/"), n(i);
                    break
                }
            case "switch_to_standard":
                if (v(f.ModalSwitchToStandard), a) {
                    const i = M({
                        serverThreadId: a,
                        isAdvancedMode: !1,
                        eventSource: "modal_".concat(r.action),
                        parentMessageId: void 0,
                        clientThreadId: a,
                        gizmoId: S.getGizmoId(g(t)),
                        skipCacheReason: "modal-switch-to-standard-button"
                    });
                    if (e) try {
                        await m({
                            type: "STOP",
                            reason: w.UserSwitchedToStandard
                        }), await m({
                            type: "START",
                            args: i
                        })
                    } catch (c) {
                        h.addError(c, {
                            message: "Switch to standard button in IUX failed"
                        })
                    } else n(i)
                }
                break;
            case "upgrade_to_plus":
                y(o, "Voice Mode Upgrade To Plus Modal");
                break;
            case "upgrade_to_pro":
                y(o, "Voice Mode Upgrade To Pro Modal");
                break
        }
        s == null || s()
    }, [r.action, t, e, o, s, a, n]);
    return l.jsx(x.Button, {
        onClick: u,
        title: r.title,
        color: d.color
    })
}
const R = {
    primary: "primary",
    secondary: "secondary",
    tertiary: "ghost"
};

function O({
    buttons: d,
    conversationId: r,
    onClick: t
}) {
    let s, a, n;
    const o = T.useCallback(e => () => {
        e === "upgrade_to_plus" ? p.upsell.upgradeToPlus() : e === "upgrade_to_pro" && p.upsell.upgradeToPro(), t()
    }, [t]);
    return !d || d.length === 0 ? {
        primary: void 0,
        secondary: void 0,
        tertiary: void 0
    } : (d.forEach(e => {
        if (!I.includes(e.action)) return;
        const i = l.jsx(E, {
            button: e,
            conversationId: r,
            onClick: o(e.action),
            color: R[e.style]
        });
        switch (e.style) {
            case "primary":
                s = i;
                break;
            case "secondary":
                a = i;
                break;
            case "tertiary":
                n = i;
                break
        }
    }), {
        primary: s,
        secondary: a,
        tertiary: n
    })
}

function $({
    conversationId: d,
    isOpen: r,
    onClose: t,
    buttons: s,
    title: a,
    description_markdown: n
}) {
    const o = O({
            buttons: s,
            conversationId: d,
            onClick: t
        }),
        e = l.jsx(B, {
            className: "markdown text-token-text-secondary mb-6",
            urlTransform: u => u,
            children: n
        });
    return l.jsx(A, {
        testId: "modal-voice-rate-limit",
        title: a,
        isOpen: r,
        onClose: t,
        size: "custom",
        className: "max-w-[550px]",
        type: "warning",
        showCloseButton: !0,
        children: l.jsxs("div", {
            className: "w-full",
            children: [e, l.jsxs("div", {
                className: "flex flex-row justify-end gap-6",
                children: [o.primary, o.secondary, o.tertiary]
            })]
        })
    })
}
export {
    $ as V, O as u
};
//# sourceMappingURL=e9kbgh7j5o6g3dr6.js.map