var _ = Object.defineProperty,
    A = Object.defineProperties;
var F = Object.getOwnPropertyDescriptors;
var v = Object.getOwnPropertySymbols;
var O = Object.prototype.hasOwnProperty,
    C = Object.prototype.propertyIsEnumerable;
var w = (s, e, n) => e in s ? _(s, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : s[e] = n,
    y = (s, e) => {
        for (var n in e || (e = {})) O.call(e, n) && w(s, n, e[n]);
        if (v)
            for (var n of v(e)) C.call(e, n) && w(s, n, e[n]);
        return s
    },
    j = (s, e) => A(s, F(e));
import {
    e as E,
    r as g,
    j as t,
    M as f,
    ad as Q
} from "./fg33krlcm0qyi6yw.js";
import {
    e2 as N,
    e4 as M,
    f8 as W,
    iK as P,
    hA as q,
    b as R
} from "./dykg4ktvbu3mhmdo.js";
import {
    eb as b,
    ec as I,
    ed as J,
    ee as k,
    cX as G,
    ef as T
} from "./k15yxxoybkkir2ou.js";

function K(s) {
    var n, c, o;
    const e = [];
    for (const l of s) {
        const u = e.length ? e[e.length - 1] : null;
        if (l.status !== "in_progress") {
            if (l.author.role === N.Tool && l.author.name === "api_tool.call_tool" && l.content.content_type === M.MultimodalText) {
                const a = (n = l.metadata) == null ? void 0 : n.citation_metadata,
                    r = a == null ? void 0 : a.id;
                if (!a || !r) continue;
                const i = {
                    id: a.id,
                    name: a.title,
                    url: a.url,
                    messageId: l.id
                };
                u ? u.results.push(i) : e.push({
                    call: "unhandled",
                    results: [i]
                })
            } else if (l.author.role === N.Assistant && l.recipient === "api_tool.call_tool" && l.content.content_type === M.Code && l.content.language === "json") {
                let a = {};
                try {
                    if (a = JSON.parse(l.content.text), typeof a.args == "string") try {
                        a.args = JSON.parse(a.args)
                    } catch (r) {
                        continue
                    }
                } catch (r) {
                    continue
                }
                if (!a.path) continue;
                if (a.path === "mixer://search" && typeof((c = a.args) == null ? void 0 : c.sources) == "object") {
                    const r = [],
                        i = a.args.sources;
                    for (const x in i) {
                        const d = i[x],
                            m = b(x);
                        if (m) {
                            const h = new Set;
                            d.forEach(p => {
                                p.query && !h.has(p.query) && (r.push(j(y({
                                    isMixer: !1,
                                    path: x
                                }, m), {
                                    query: p.query
                                })), h.add(p.query))
                            })
                        }
                    }
                    e.push({
                        call: {
                            isMixer: !0,
                            messageId: l.id,
                            path: "mixer://search",
                            queries: r
                        },
                        results: []
                    })
                } else if ((o = a.args) != null && o.query) {
                    const r = b(a.path);
                    r && e.push({
                        call: j(y({
                            isMixer: !1,
                            messageId: l.id,
                            path: a.path
                        }, r), {
                            query: a.args.query
                        }),
                        results: []
                    })
                }
            }
        }
    }
    return e
}

function S(s) {
    return s ? s.replace(/\s*--[^\s=]+(?:=[^\s]+)?/g, "").replace(/\s+/g, " ").trim() : ""
}

function V({
    messages: s,
    isLastMessage: e
}) {
    const n = E(),
        c = R(),
        o = s.some(r => {
            var i, x;
            return W({
                id: (x = (i = r.metadata) == null ? void 0 : i.model_slug) != null ? x : ""
            }, c)
        }),
        l = g.useMemo(() => e ? I.Running : I.Finished, [e]),
        u = g.useMemo(() => e ? n.formatMessage({
            id: "SrnzPW",
            defaultMessage: "Searching internal knowledge"
        }) : n.formatMessage({
            id: "rI4m7i",
            defaultMessage: "Searched internal knowledge"
        }), [n, e]),
        a = g.useMemo(() => K(s), [s]);
    return o ? t.jsx(J, {
        highlightedCommand: u,
        showWorkUserSetting: !1,
        status: l,
        children: a.map((r, i) => {
            if (r.call === "unhandled") return null; {
                const x = (r.call.isMixer ? r.call.queries : [r.call]).map((d, m) => {
                    const h = S(d.query);
                    return t.jsx(D, {
                        query: h
                    }, m)
                });
                return t.jsxs("div", {
                    className: "relative flex w-full items-stretch gap-2 overflow-clip",
                    children: [t.jsxs("div", {
                        className: "flex w-4 flex-none flex-col items-center",
                        children: [t.jsx("div", {
                            className: "flex h-5 flex-none items-center justify-center",
                            children: r.call.isMixer ? t.jsx("div", {
                                className: "bg-token-interactive-icon-tertiary-default h-[6px] w-[6px] rounded-full"
                            }) : t.jsx(r.call.Icon, {
                                className: "icon-sm"
                            })
                        }), i < a.length - 1 && t.jsx("div", {
                            className: "bg-token-border-heavy h-1 w-[1px] flex-auto rounded-full"
                        })]
                    }), t.jsxs("div", {
                        className: "mb-3 flex w-1 flex-auto flex-col gap-3",
                        children: [t.jsx("p", {
                            className: "text-token-text-secondary flex flex-auto flex-row flex-wrap gap-1",
                            children: r.call.isMixer ? x.length === 1 ? t.jsx(f, {
                                id: "olKix8",
                                defaultMessage: 'Searched for "{query}"',
                                values: {
                                    query: x[0]
                                }
                            }) : t.jsx(f, {
                                id: "5CdONM",
                                defaultMessage: "Searched for {queries}",
                                values: {
                                    queries: t.jsx(Q, {
                                        value: x
                                    })
                                }
                            }) : t.jsx(f, {
                                id: "olKix8",
                                defaultMessage: 'Searched for "{query}"',
                                values: {
                                    query: S(r.call.query)
                                }
                            })
                        }), !!r.results.length && t.jsx("div", {
                            className: "overflow-x-auto",
                            children: t.jsx("div", {
                                className: "flex flex-row gap-2",
                                children: r.results.map(d => t.jsx(z, {
                                    url: d.url,
                                    name: d.name
                                }, d.id))
                            })
                        })]
                    })]
                }, r.call.messageId)
            }
        })
    }) : null
}

function z({
    url: s,
    name: e
}) {
    var o;
    const n = k(s != null ? s : ""),
        c = (o = n == null ? void 0 : n.Icon) != null ? o : s ? G : T;
    return t.jsxs(P, {
        className: "bg-token-bg-tertiary hover:bg-token-interactive-bg-tertiary-hover flex h-[25px] max-w-64 flex-row items-center gap-1 rounded-xl px-2 text-[10px] leading-[13px]",
        href: s,
        children: [t.jsx(c, {
            className: "icon-sm"
        }), t.jsx("p", {
            className: "text-token-text-secondary truncate overflow-ellipsis",
            children: e
        })]
    })
}

function Z({
    maxResults: s,
    results: e
}) {
    const n = g.useMemo(() => {
        const c = new Set;
        return e.slice(0, s - 1).forEach(o => {
            var u, a;
            const l = k((u = o.url) != null ? u : "");
            c.add((a = l == null ? void 0 : l.Icon) != null ? a : o.url ? G : T)
        }), Array.from(c)
    }, [e, s]);
    return t.jsxs("div", {
        className: "bg-token-bg-tertiary flex h-[25px] max-w-64 flex-row items-center gap-1 rounded-xl px-2 text-[10px] leading-[13px]",
        children: [n.map((c, o) => t.jsx(c, {
            className: "icon-sm"
        }, o)), t.jsx("p", {
            className: "text-token-text-secondary truncate overflow-ellipsis",
            children: t.jsx(f, {
                id: "Wj+XrO",
                defaultMessage: "{number} more",
                values: {
                    number: e.length - (s - 1)
                }
            })
        })]
    })
}

function D({
    query: s
}) {
    return t.jsx(U, {
        Icon: q,
        label: s
    })
}

function U({
    label: s,
    Icon: e
}) {
    return t.jsxs("div", {
        className: "bg-token-bg-tertiary flex h-[25px] max-w-64 flex-row items-center gap-1 rounded-xl px-2 text-[10px] leading-[13px]",
        children: [t.jsx(e, {
            className: "icon-xs"
        }), t.jsx("p", {
            className: "text-token-text-secondary truncate overflow-ellipsis",
            children: s
        })]
    })
}

function $({
    maxResults: s,
    queries: e
}) {
    return t.jsxs("div", {
        className: "bg-token-bg-tertiary flex h-[25px] max-w-64 flex-row items-center gap-1 rounded-xl px-2 text-[10px] leading-[13px]",
        children: [t.jsx(q, {
            className: "icon-xs"
        }), t.jsx("p", {
            className: "text-token-text-secondary truncate overflow-ellipsis",
            children: t.jsx(f, {
                id: "axYnJ7",
                defaultMessage: "{number} more searches",
                values: {
                    number: e.length - (s - 1)
                }
            })
        })]
    })
}
export {
    U as GlauxCoTChipWithIcon, V as GlauxMessage, $ as GlauxSearchQueryOverflow, D as GlauxSearchQueryWithIcon, z as GlauxSearchResultItem, Z as GlauxSearchResultOverflow, S as cleanQuery, K as groupGlauxMessages
};
//# sourceMappingURL=obmzp3ebe8x6w67a.js.map