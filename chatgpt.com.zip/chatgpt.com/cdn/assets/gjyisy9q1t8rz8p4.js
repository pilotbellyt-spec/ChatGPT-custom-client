var E = Object.defineProperty,
    w = Object.defineProperties;
var M = Object.getOwnPropertyDescriptors;
var g = Object.getOwnPropertySymbols;
var k = Object.prototype.hasOwnProperty,
    v = Object.prototype.propertyIsEnumerable;
var _ = (e, t, a) => t in e ? E(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: a
    }) : e[t] = a,
    s = (e, t) => {
        for (var a in t || (t = {})) k.call(t, a) && _(e, a, t[a]);
        if (g)
            for (var a of g(t)) v.call(t, a) && _(e, a, t[a]);
        return e
    },
    l = (e, t) => w(e, M(t));
import {
    i as b
} from "./k15yxxoybkkir2ou.js";
import {
    P as p,
    iU as u,
    _ as m
} from "./dykg4ktvbu3mhmdo.js";
import {
    u as S,
    s as I
} from "./lqog7ixiwnif6sbp.js";
const C = {
        cartUpdateShippingAddressErrorMessage: {
            id: "cart.updateShippingAddressError",
            defaultMessage: "Failed to update shipping address. Please try again.",
            description: "Error message shown when failed to update shipping address"
        },
        cartUpdateGeneralErrorMessage: {
            id: "cart.updateGeneralError",
            defaultMessage: "Failed to update the cart. Please try again.",
            description: "Error message shown when failed to update the cart"
        },
        cartUpdateGeneralErrorRetryMessage: {
            id: "cart.updateGeneralErrorRetry",
            defaultMessage: "Failed to update the cart. Please close the cart and try again.",
            description: "Error message shown when failed to update the cart"
        },
        cartUpdateQuantityErrorMessage: {
            id: "cart.updateQuantityError",
            defaultMessage: "Failed to update cart quantity. Please try again.",
            description: "Error message shown when failed to update cart quantity"
        },
        stripeLoadingPaymentMethodError: {
            id: "cart.stripeLoadingPaymentMethodError",
            defaultMessage: "Failed to load previous payment method. Please add a new payment method.",
            description: "Error message for failed to load payment method"
        },
        stripeLoadingShippingAddressError: {
            id: "cart.stripeLoadingShippingAddressError",
            defaultMessage: "Failed to load previous shipping address. Please enter a new shipping address.",
            description: "Error message for failed to load shipping address"
        },
        stripeLoadingBillingAddressError: {
            id: "cart.stripeLoadingBillingAddressError",
            defaultMessage: "Failed to load previous billing address. Please enter a new billing address.",
            description: "Error message for failed to load billing address"
        },
        cartAgreementsRequiredErrorMessage: {
            id: "cart.updateAgreementsError",
            defaultMessage: "Please check the {count, plural, one {box} other {boxes}} to agree before continuing.",
            description: "Message to show when the user has not accepted all required agreements"
        }
    },
    L = (e, t, a, r, n) => {
        var c;
        if (!r) return;
        const i = a.find(o => o.id === r);
        p.logEventWithStatsig("product_checkout", "product_checkout", l(s({}, u((c = e.cartMetadata) != null ? c : {})), {
            checkout_id: t,
            prefill: n === "prefill",
            action: e.shippingMethodId ? "shipping_method_updated" : "shipping_method_added",
            shipping_method_name: i == null ? void 0 : i.title,
            shipping_method_price: i == null ? void 0 : i.subtotal,
            shipping_method_index: a.findIndex(o => o.id === r)
        }))
    },
    P = (e, t, a, r) => {
        var n;
        p.logEventWithStatsig("product_checkout", "product_checkout", l(s({}, u((n = e.cartMetadata) != null ? n : {})), {
            checkout_id: t,
            prefill: r === "prefill",
            action: e.shippingAddress ? "shipping_address_updated" : "shipping_address_added",
            shipping_city: a == null ? void 0 : a.city,
            shipping_state: a == null ? void 0 : a.state,
            shipping_postal_code: a == null ? void 0 : a.postalCode,
            shipping_country: a == null ? void 0 : a.country
        }))
    },
    W = (e, t, a) => {
        var r, n;
        p.logEventWithStatsig("product_checkout", "product_checkout", l(s({}, u((r = e.cartMetadata) != null ? r : {})), {
            checkout_id: e.cartId,
            credit_card_type: t,
            prefill: a === "prefill",
            action: (n = e.paymentDetails) != null && n.paymentMethodId ? "payment_method_updated" : "payment_method_added"
        }))
    },
    O = (e, t) => {
        var a;
        p.logEventWithStatsig("product_checkout", "product_checkout", l(s({}, u((a = e.cartMetadata) != null ? a : {})), {
            checkout_id: e.cartId,
            credit_card_type: t,
            action: "payment_method_removed"
        }))
    };

function B(e, t, a) {
    return {
        name: t,
        addressLine1: e.line1,
        addressLine2: e.line2,
        city: e.city,
        state: e.state,
        postalCode: e.postal_code,
        country: e.country,
        phoneNumber: a != null ? a : void 0
    }
}

function G(e, t) {
    var a;
    return {
        name: e.name,
        address: {
            line1: e.addressLine1,
            line2: e.addressLine2,
            city: e.city,
            state: e.state,
            postal_code: e.postalCode,
            country: (a = e.country) != null ? a : ""
        },
        phone: t ? e.phoneNumber : void 0
    }
}

function V(e) {
    var t;
    return {
        name: e.name,
        line_one: e.addressLine1,
        line_two: e.addressLine2,
        city: e.city,
        state: e.state,
        postal_code: e.postalCode,
        country: (t = e.country) != null ? t : "",
        phone_number: e.phoneNumber
    }
}

function j(e) {
    var t, a, r, n, i, c, o, d;
    return {
        name: (t = e.name) != null ? t : null,
        addressLine1: (a = e.line_one) != null ? a : null,
        addressLine2: (r = e.line_two) != null ? r : null,
        city: (n = e.city) != null ? n : null,
        state: (i = e.state) != null ? i : null,
        postalCode: (c = e.postal_code) != null ? c : null,
        country: (o = e.country) != null ? o : null,
        phoneNumber: (d = e.phone_number) != null ? d : void 0
    }
}
const A = e => e.every(t => {
        var a;
        return "metadata" in t ? (a = t.metadata) == null ? void 0 : a.isDigital : !0
    }),
    H = e => {
        var a, r, n, i, c, o, d, h;
        const t = e;
        return {
            paymentMethodId: (a = t.value.payment_method) == null ? void 0 : a.id,
            paymentMethodType: (r = t.value.payment_method) == null ? void 0 : r.type,
            label: (i = (n = t.preview) == null ? void 0 : n.label) != null ? i : "",
            sublabel: (o = (c = t.preview) == null ? void 0 : c.sublabel) != null ? o : "",
            icon: (h = (d = t.preview) == null ? void 0 : d.icon) != null ? h : null
        }
    },
    Q = async ({
        store: e,
        fields: t,
        errorMessage: a,
        onLocalMutationComplete: r,
        source: n,
        skipLogging: i
    }) => {
        var c, o;
        try {
            e.setCartStatus("updating"), t.shippingAddress && (i || P(e, e.cartId, t.shippingAddress, n), e.setShippingAddress(t.shippingAddress)), t.shippingMethodId && (i || L(e, e.cartId, e.shippingOptions, t.shippingMethodId, n), e.setShippingMethodId(t.shippingMethodId)), r == null || r();
            const d = await S(e.cartId, t);
            d.cart.errors.length > 0 && p.logEventWithStatsig("product_checkout", "product_checkout", l(s({}, u((c = e.cartMetadata) != null ? c : {})), {
                action: "cart_update_failed",
                reason: "bad_response_from_endpoint",
                error_message: JSON.stringify(d.cart.errors)
            })), e.updateCart(d)
        } catch (d) {
            p.logEventWithStatsig("product_checkout", "product_checkout", l(s({}, u((o = e.cartMetadata) != null ? o : {})), {
                action: "cart_update_failed",
                reason: "error_response_from_endpoint",
                error_message: d
            })), e.setErrors([{
                group: "general",
                message: a
            }]), e.setCartStatus("idle")
        }
    },
    J = (e, t) => {
        var a, r, n;
        e.cartStatus !== "submitting" && (e.closeCheckout(!0), p.logEventWithStatsig("product_checkout", "product_checkout", l(s({}, u((a = e.cartMetadata) != null ? a : {})), {
            checkout_id: e.cartId,
            reason: t,
            action: "abandoned"
        })), m.addAction("shopping_checkout.abandoned", {
            merchant_id: (r = e.merchant) == null ? void 0 : r.externalId,
            merchant_network_id: (n = e.merchant) == null ? void 0 : n.networkId,
            cart_total: e.grandTotal.value,
            reason: t
        }))
    },
    T = (e, t) => {
        const r = (n = 3, i = 1) => {
            const c = y(e);
            if (c) {
                const o = R(c);
                if (o) {
                    const d = c.getBoundingClientRect(),
                        h = o.getBoundingClientRect();
                    o.scrollTo({
                        top: d.top - h.top + o.scrollTop,
                        behavior: "smooth"
                    })
                } else c.scrollIntoView({
                    behavior: "smooth"
                });
                t == null || t()
            } else n > 1 && setTimeout(() => r(n - 1, i + 1), 200 * i)
        };
        setTimeout(() => r(), 50)
    },
    y = e => document.querySelector('[data-order-id="'.concat(e, '"]')),
    R = e => {
        let t = e.parentElement;
        for (; t;) {
            const {
                overflowY: a
            } = window.getComputedStyle(t);
            if (a === "auto" || a === "scroll") return t;
            t = t.parentElement
        }
        return null
    },
    K = (e, t, a) => A(e) ? [{
        id: "na",
        amount: 0,
        displayName: a.formatMessage({
            id: "tLRVwj",
            defaultMessage: "Digital delivery"
        })
    }] : t.map(r => ({
        id: r.id,
        amount: r.subtotal_minor,
        displayName: r.title
    })),
    f = 1e3,
    Y = async ({
        store: e,
        order: t,
        navigate: a
    }) => {
        var i, c;
        let r = !1;
        e.setCartStatus("complete");
        const n = performance.now();
        t.conversation_id && await b(t.conversation_id), performance.now() - n < f && (y(e.cartId) && (r = !0, m.addAction("shopping_checkout.receipt", {
            durationMs: performance.now() - n,
            merchant_id: (i = e.merchant) == null ? void 0 : i.externalId,
            merchant_network_id: (c = e.merchant) == null ? void 0 : c.networkId
        })), await new Promise(o => setTimeout(o, f - (performance.now() - n)))), t.conversation_id ? T(e.cartId, () => {
            var o, d;
            r || m.addAction("shopping_checkout.receipt", {
                durationMs: performance.now() - n,
                merchant_id: (o = e.merchant) == null ? void 0 : o.externalId,
                merchant_network_id: (d = e.merchant) == null ? void 0 : d.networkId
            })
        }) : I(a, t.id)
    },
    $ = (e, t) => {
        var r;
        const a = (r = e.additionalFields) != null && r.includes("shipping_address_phone_number") ? !!(t != null && t.phoneNumber) : !0;
        return !!(t != null && t.complete) && !!(t != null && t.addressLine1) && a
    },
    F = e => e ? !e.some(t => t.is_required && !t.is_checked) : !0,
    z = (e, t) => F(e.agreements) ? !0 : (N(e, t), !1),
    N = (e, t) => {
        var a;
        e.setErrors([{
            group: "general",
            message: t.formatMessage(C.cartAgreementsRequiredErrorMessage, {
                count: (a = e.agreements) == null ? void 0 : a.filter(r => r.is_required).length
            })
        }])
    };
export {
    A as a, H as b, C as c, P as d, V as e, Y as f, K as g, F as h, $ as i, J as j, O as k, L as l, j as m, B as n, W as o, G as p, N as s, Q as u, z as v
};
//# sourceMappingURL=gjyisy9q1t8rz8p4.js.map