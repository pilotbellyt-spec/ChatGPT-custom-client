var N = Object.freeze,
    k = Object.defineProperty,
    U = Object.defineProperties;
var H = Object.getOwnPropertyDescriptors;
var b = Object.getOwnPropertySymbols;
var S = Object.prototype.hasOwnProperty,
    O = Object.prototype.propertyIsEnumerable;
var R = (o, r, e) => r in o ? k(o, r, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : o[r] = e,
    l = (o, r) => {
        for (var e in r || (r = {})) S.call(r, e) && R(o, e, r[e]);
        if (b)
            for (var e of b(r)) O.call(r, e) && R(o, e, r[e]);
        return o
    },
    c = (o, r) => U(o, H(r));
var d = (o, r) => {
    var e = {};
    for (var a in o) S.call(o, a) && r.indexOf(a) < 0 && (e[a] = o[a]);
    if (o != null && b)
        for (var a of b(o)) r.indexOf(a) < 0 && O.call(o, a) && (e[a] = o[a]);
    return e
};
var h = (o, r) => N(k(o, "raw", {
    value: N(r || o.slice())
}));
import {
    r as u,
    j as t
} from "./fg33krlcm0qyi6yw.js";
import {
    T as W,
    Z
} from "./ce3hgmw4iyyhicud.js";
import {
    kR as I,
    R as V,
    I as X,
    ib as q,
    kS as J,
    ab as Q,
    ac as Y
} from "./k15yxxoybkkir2ou.js";
import {
    a2 as m,
    a5 as P,
    a7 as oo,
    a4 as ro,
    a8 as eo,
    a6 as w,
    a3 as ao,
    l as T,
    F as C
} from "./dykg4ktvbu3mhmdo.js";
var to = "Separator",
    y = "horizontal",
    no = ["horizontal", "vertical"],
    A = u.forwardRef((o, r) => {
        const p = o,
            {
                decorative: e,
                orientation: a = y
            } = p,
            s = d(p, ["decorative", "orientation"]),
            n = so(a) ? a : y,
            v = e ? {
                role: "none"
            } : {
                "aria-orientation": n === "vertical" ? n : void 0,
                role: "separator"
            };
        return t.jsx(m.div, c(l(l({
            "data-orientation": n
        }, v), s), {
            ref: r
        }))
    });
A.displayName = to;

function so(o) {
    return no.includes(o)
}
var io = A,
    _ = "Toolbar",
    [lo] = ro(_, [P, I]),
    j = P(),
    F = I(),
    [co, M] = lo(_),
    B = u.forwardRef((o, r) => {
        const x = o,
            {
                __scopeToolbar: e,
                orientation: a = "horizontal",
                dir: s,
                loop: n = !0
            } = x,
            i = d(x, ["__scopeToolbar", "orientation", "dir", "loop"]),
            v = j(e),
            p = oo(s);
        return t.jsx(co, {
            scope: e,
            orientation: a,
            dir: p,
            children: t.jsx(eo, c(l({
                asChild: !0
            }, v), {
                orientation: a,
                dir: p,
                loop: n,
                children: t.jsx(m.div, c(l({
                    role: "toolbar",
                    "aria-orientation": a,
                    dir: p
                }, i), {
                    ref: r
                }))
            }))
        })
    });
B.displayName = _;
var D = "ToolbarSeparator",
    z = u.forwardRef((o, r) => {
        const n = o,
            {
                __scopeToolbar: e
            } = n,
            a = d(n, ["__scopeToolbar"]),
            s = M(D, e);
        return t.jsx(io, c(l({
            orientation: s.orientation === "horizontal" ? "vertical" : "horizontal"
        }, a), {
            ref: r
        }))
    });
z.displayName = D;
var po = "ToolbarButton",
    f = u.forwardRef((o, r) => {
        const n = o,
            {
                __scopeToolbar: e
            } = n,
            a = d(n, ["__scopeToolbar"]),
            s = j(e);
        return t.jsx(w, c(l({
            asChild: !0
        }, s), {
            focusable: !o.disabled,
            children: t.jsx(m.button, c(l({
                type: "button"
            }, a), {
                ref: r
            }))
        }))
    });
f.displayName = po;
var uo = "ToolbarLink",
    vo = u.forwardRef((o, r) => {
        const n = o,
            {
                __scopeToolbar: e
            } = n,
            a = d(n, ["__scopeToolbar"]),
            s = j(e);
        return t.jsx(w, c(l({
            asChild: !0
        }, s), {
            focusable: !0,
            children: t.jsx(m.a, c(l({}, a), {
                ref: r,
                onKeyDown: ao(o.onKeyDown, i => {
                    i.key === " " && i.currentTarget.click()
                })
            }))
        }))
    });
vo.displayName = uo;
var $ = "ToolbarToggleGroup",
    xo = u.forwardRef((o, r) => {
        const i = o,
            {
                __scopeToolbar: e
            } = i,
            a = d(i, ["__scopeToolbar"]),
            s = M($, e),
            n = F(e);
        return t.jsx(V, c(l(l({
            "data-orientation": s.orientation,
            dir: s.dir
        }, n), a), {
            ref: r,
            rovingFocus: !1
        }))
    });
xo.displayName = $;
var bo = "ToolbarToggleItem",
    To = u.forwardRef((o, r) => {
        const i = o,
            {
                __scopeToolbar: e
            } = i,
            a = d(i, ["__scopeToolbar"]),
            s = F(e),
            n = {
                __scopeToolbar: o.__scopeToolbar
            };
        return t.jsx(f, c(l({
            asChild: !0
        }, n), {
            children: t.jsx(X, c(l(l({}, s), a), {
                ref: r
            }))
        }))
    });
To.displayName = bo;
var mo = B,
    fo = z,
    go = (o => (o.CODE = "code", o.WRITING = "writing", o))(go || {});
const g = ({
        children: o,
        toolbarType: r
    }) => t.jsx(mo, {
        className: T("bg-token-main-surface-primary m-0 flex h-9 w-fit min-w-0 shrink items-center overflow-hidden rounded-xl px-1 dark:bg-[#353535]", W, r === "code" ? "py-0" : "py-1"),
        children: o
    }),
    K = ({
        icon: o,
        hideLabel: r,
        isActive: e,
        label: a,
        subLabel: s,
        iconClassName: n,
        labelClassName: i
    }) => t.jsxs(t.Fragment, {
        children: [o && t.jsx(o, {
            className: T("icon-sm", {
                "me-0.5": !r,
                "text-token-text-tertiary": !r && !e,
                "text-token-text-primary": r && !e,
                "text-token-interactive-label-accent-default hover:text-token-interactive-label-accent-hover": e
            }, n)
        }), !r && t.jsx("span", {
            className: T("truncate text-sm", {
                "text-token-text-primary": !e,
                "text-token-interactive-label-accent-default hover:text-token-interactive-label-accent-hover": e
            }, i),
            children: a
        }), s]
    });
var E;
const L = C(f)(E || (E = h(["flex h-full items-center rounded-lg gap-1 px-2 hover:bg-black/5 dark:hover:bg-token-interactive-bg-secondary-hover disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-transparent"]))),
    ho = ({
        label: o,
        subLabel: r,
        icon: e,
        isDisabled: a = !1,
        isActive: s = !1,
        hideLabel: n = !1,
        onClick: i,
        onMouseDown: v,
        iconClassName: p,
        labelClassName: x
    }) => t.jsx(L, {
        onClick: i,
        "aria-label": n ? o : void 0,
        onMouseDown: v,
        disabled: a,
        "aria-pressed": s || void 0,
        "data-state": s ? "on" : void 0,
        children: t.jsx(K, {
            icon: e,
            hideLabel: n,
            label: o,
            subLabel: r,
            isActive: s,
            iconClassName: p,
            labelClassName: x
        })
    }),
    _o = ({
        icon: o,
        hideLabel: r,
        label: e,
        children: a,
        align: s = "end"
    }) => t.jsxs(q, {
        children: [t.jsx(J, {
            asChild: !0,
            children: t.jsx(L, {
                "aria-label": r ? e : void 0,
                children: t.jsx(K, {
                    icon: o,
                    hideLabel: r,
                    label: e
                })
            })
        }), t.jsx(Q, {
            children: t.jsx(Y, {
                align: s,
                className: T(Z.toolbar, "popover"),
                sideOffset: 8,
                children: a
            })
        })]
    });
var G;
g.Separator = C(fo)(G || (G = h(["mx-1 p-0 list-none h-3 w-[1px] bg-token-border-default"])));
g.Action = ho;
g.Button = f;
g.Popover = _o;
export {
    mo as R, fo as S, go as T, g as a, f as b
};
//# sourceMappingURL=gbmggnydp7mcsebl.js.map