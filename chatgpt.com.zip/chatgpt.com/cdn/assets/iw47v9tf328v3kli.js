const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/ey3f7egvimr39bq4.js", "assets/fg33krlcm0qyi6yw.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/k15yxxoybkkir2ou.js", "assets/conversation-small-332fs9rk.css", "assets/v9p9lvhz45nq9ivc.js", "assets/b2m9mckkhp8ohmop.js", "assets/b0vb0n8384gswaby.js", "assets/h21g9slzr4ujv9kj.js", "assets/euq7ybw4dhrsufo2.js", "assets/l09h2qppleubii6l.js", "assets/bwfoshdjwp2i6opj.js", "assets/jed1ux7qibe55pmj.js", "assets/h1em0bjkpkjv8ykw.js", "assets/nfccle6oyncifphl.js", "assets/hu1bt0oauegdhua6.js"]))) => i.map(i => d[i]);
var En = Object.defineProperty,
    kn = Object.defineProperties;
var Nn = Object.getOwnPropertyDescriptors;
var bo = Object.getOwnPropertySymbols;
var Rn = Object.prototype.hasOwnProperty,
    Fn = Object.prototype.propertyIsEnumerable;
var Co = (a, e, t) => e in a ? En(a, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : a[e] = t,
    Ie = (a, e) => {
        for (var t in e || (e = {})) Rn.call(e, t) && Co(a, t, e[t]);
        if (bo)
            for (var t of bo(e)) Fn.call(e, t) && Co(a, t, e[t]);
        return a
    },
    St = (a, e) => kn(a, Nn(e));
import {
    f as On,
    c as Pe,
    j as s,
    r as v,
    M as _t,
    e as ns,
    i as ao,
    n as Do,
    b as Ln,
    v as Hn,
    _ as Ps,
    m as $o,
    a1 as Wn,
    E as Dn
} from "./fg33krlcm0qyi6yw.js";
import {
    c_ as jt,
    b as ot,
    d as O,
    V as ut,
    bH as js,
    g_ as $n,
    bI as kt,
    fK as Bn,
    cQ as Bo,
    gy as Gn,
    da as Un,
    H as Go,
    l as We,
    b4 as zn,
    b3 as Uo,
    gz as Vn,
    mI as ds,
    aF as es,
    aG as ts,
    T as qn,
    aK as io,
    lw as zo,
    oT as Yn,
    xt as Kn,
    xu as Qn,
    bc as vo,
    bd as To,
    nR as Jn,
    lY as Vo,
    fZ as _o,
    fX as Ts,
    bs as Xn,
    jT as Zn,
    jS as ea,
    br as ta,
    bT as sa,
    bl as oa,
    S as na,
    P as is,
    iW as Ys,
    fV as wo,
    fe as aa,
    lN as ia,
    aP as ro,
    R as rs,
    A as Ks,
    o as xt,
    ag as ra,
    aU as la,
    qv as ca,
    xv as da,
    sP as ua,
    e as us,
    qw as qo,
    C as ma,
    a9 as Ds,
    lU as Yo,
    ka as ha,
    ll as pa,
    en as Qs,
    lg as ga,
    ok as fa,
    cU as _s,
    hd as Cs,
    lk as Sa,
    eg as xa,
    xw as ya,
    dF as wt,
    h as ba,
    e2 as Ca,
    fN as ss,
    kh as va,
    dQ as Ta,
    aX as Ot,
    bg as ws,
    i9 as _a,
    dB as wa,
    uZ as Mo,
    td as Ao,
    xo as $s,
    ql as Ma,
    dZ as Aa,
    oh as Ia,
    xx as Pa,
    bv as Ko,
    bh as Es,
    ba as Io,
    k as ls,
    xy as ja,
    fO as Qo,
    m as Ea,
    I as lo,
    n5 as ka,
    l3 as Po,
    f8 as Na,
    g$ as Ra,
    id as co,
    d6 as uo,
    nm as Fa,
    vc as Oa,
    xz as La,
    oO as Ms,
    mV as mo,
    hg as ks,
    xA as Ha,
    xB as Wa,
    dH as Da,
    f3 as Js,
    bq as $a,
    dL as Ba,
    h2 as Ga,
    b$ as Ua,
    nI as za,
    c2 as Va,
    sJ as qa,
    xC as Ya,
    hF as Jo,
    i as Xo,
    eX as Xs,
    eh as Zo,
    hX as en,
    lH as tn,
    d9 as sn,
    dz as Bs,
    j7 as Ka,
    eW as on,
    mW as nn,
    oU as an,
    bJ as rn,
    ns as ln,
    h0 as cn,
    es as Qa,
    aJ as Ja,
    hh as Xa,
    xD as Za,
    eG as ei,
    xE as ti,
    qx as si,
    qu as jo,
    uE as oi,
    _ as Eo,
    j as ni,
    dq as ai,
    lP as ii,
    g as ri,
    e_ as li,
    gb as ci
} from "./dykg4ktvbu3mhmdo.js";
import {
    sU as dn,
    sV as di,
    dG as ui,
    sW as mi,
    sX as hi,
    pe as pi,
    sY as ho,
    sZ as gi,
    jo as fi,
    s_ as Si,
    s$ as xi,
    t0 as yi,
    t1 as Zs,
    oE as He,
    q6 as bi,
    t2 as vs,
    t3 as Ci,
    t4 as vi,
    t5 as te,
    t6 as Ti,
    t7 as _i,
    t8 as wi,
    t9 as Mi,
    ta as Ai,
    tb as Ii,
    pL as Pi,
    tc as ko,
    dg as ji,
    td as po,
    te as Ei,
    tf as ki,
    tg as Ni,
    th as Ri,
    ti as Fi,
    tj as Oi,
    iK as Li,
    tk as Hi,
    tl as Wi,
    tm as Di,
    tn as No,
    to as $i,
    tp as Bi,
    tq as Gi,
    tr as Ro,
    ts as Ui,
    tt as un,
    ag as os,
    po as mn,
    tu as zi,
    bB as Ns,
    pd as Vi,
    g1 as Ft,
    tv as ms,
    nJ as qi,
    tw as Yi,
    hl as Ki,
    tx as As,
    ty as Qi,
    tz as Ji,
    jr as hn,
    tA as Xi,
    tB as go,
    dr as Zi,
    bq as Fo,
    tC as er,
    on as tr,
    tD as fo,
    tE as sr,
    tF as or,
    af as eo,
    eE as to,
    tG as pn,
    tH as Is,
    tI as gn,
    tJ as nr,
    o1 as fn,
    mj as Sn,
    mi as xn,
    tK as ar,
    tL as ir,
    tM as rr,
    tN as lr,
    tO as yn,
    tP as cr,
    tQ as dr,
    tR as ur,
    kG as Oo,
    e0 as cs,
    tS as mr,
    bU as hr,
    pM as pr,
    eB as gr,
    bp as fr,
    bT as Sr,
    tT as xr,
    tU as yr,
    tV as bn,
    hO as Cn,
    eJ as vn,
    tW as so,
    hP as br,
    tX as Cr,
    tY as vr,
    tZ as Tr,
    t_ as _r,
    t$ as wr,
    u0 as Mr,
    u1 as Ar,
    u2 as Ir,
    pS as Pr,
    u3 as jr,
    u4 as Er,
    u5 as kr,
    i5 as Nr,
    mg as oo,
    e3 as Tn,
    jb as _n,
    mU as Rr,
    u6 as Fr,
    u7 as Or,
    u8 as Lr,
    u9 as Hr,
    ua as Wr,
    ub as Dr,
    uc as $r,
    ud as Br,
    ue as Gr,
    mK as Ur,
    l5 as zr,
    uf as Vr,
    iM as qr,
    ug as Yr,
    uh as Kr,
    ui as Qr,
    uj as Jr,
    uk as Xr,
    ul as Zr,
    dX as el,
    um as tl,
    pa as sl,
    un as ol,
    uo as nl,
    up as al,
    bR as il,
    uq as rl,
    ur as ll,
    ok as cl,
    us as dl,
    ut as ul,
    uu as ml,
    uv as hl,
    uw as pl,
    e2 as gl,
    ux as fl,
    cI as Sl,
    uy as xl,
    uz as yl,
    uA as bl,
    uB as Cl,
    uC as vl,
    uD as Tl
} from "./k15yxxoybkkir2ou.js";
import {
    F as _l
} from "./jttqqjx6qab96ezg.js";
import {
    M as wl,
    S as wn,
    u as Ml,
    p as Al,
    P as Il,
    a as Pl,
    b as jl,
    c as El,
    d as kl,
    D as Nl,
    T as Rl
} from "./eejiqzdptzp07q5y.js";
import {
    P as Mn
} from "./ib78f9d5brp6znzf.js";
import {
    u as Fl
} from "./e3ddui4ro6nb7fig.js";
import {
    T as Ol
} from "./hz9475nc5ndyfqsu.js";
import {
    a as Ll,
    T as Hl
} from "./omy347b79inqzbaj.js";

function Wl(a) {
    "use forget";
    const e = Pe.c(20),
        {
            clientThreadId: t,
            headlineOption: i,
            starterPromptStyle: h,
            currentModelId: r,
            overrideMessage: u
        } = a,
        c = pi(),
        f = ds();
    let m;
    e[0] !== f ? (m = ho(f), e[0] = f, e[1] = m) : m = e[1];
    const n = O(m.shouldShowAutocomplete$);
    let o;
    e[2] !== t ? (o = {
        shouldBeEnabledForDefaultAssistant: !0,
        clientThreadId: t
    }, e[2] = t, e[3] = o) : o = e[3];
    const d = gi(o),
        x = c ? "keyboard-open:h-[calc(100%-var(--screen-keyboard-height,0px)-var(--composer-height,100px))] h-full motion-safe:[transition:height_0.3s_var(--easing-common)]" : "h-full",
        p = n ? "pointer-events-none opacity-0" : "opacity-100";
    let g;
    e[4] !== x || e[5] !== p ? (g = We("text-token-text-primary mt-[var(--screen-optical-compact-offset-amount)] [display:var(--display-hidden-until-loaded,flex)] w-full shrink flex-col items-center justify-center px-4 transition-opacity sm:hidden", x, p), e[4] = x, e[5] = p, e[6] = g) : g = e[6];
    let S;
    e[7] !== i || e[8] !== u || e[9] !== h ? (S = i === "CHATGPT_LOGO" ? s.jsx(Bo, {
        className: "inline-block h-12 w-12"
    }) : h !== "tiles" ? s.jsx(An, {
        headlineOption: i,
        overrideMessage: u
    }) : null, e[7] = i, e[8] = u, e[9] = h, e[10] = S) : S = e[10];
    let l;
    e[11] !== t || e[12] !== r || e[13] !== d || e[14] !== h ? (l = h === "chips" || !d ? r && s.jsx(wl, {
        currentModelId: r,
        clientThreadId: t
    }) : h === "tiles" && r && t ? s.jsx(wn, {
        clientThreadId: t,
        currentModelId: r
    }) : null, e[11] = t, e[12] = r, e[13] = d, e[14] = h, e[15] = l) : l = e[15];
    let y;
    return e[16] !== g || e[17] !== S || e[18] !== l ? (y = s.jsxs("div", {
        className: g,
        children: [S, l]
    }), e[16] = g, e[17] = S, e[18] = l, e[19] = y) : y = e[19], y
}

function Dl({
    activeSystemHintType: a,
    isAnonModeEnabled: e,
    currentModelId: t
}) {
    if (a === kt.Research) return V.deepResearchPlaceholder;
    const h = $n(a);
    if (t === "n7jupd" || h) return V.whatCanIDo
}

function $l(a) {
    "use forget";
    const e = Pe.c(26),
        {
            clientThreadId: t,
            currentModelId: i
        } = a,
        h = ot();
    let r;
    e[0] !== h ? (r = jt(), e[0] = h, e[1] = r) : r = e[1];
    const u = !r;
    let c;
    e[2] !== h ? (c = () => Bn(h), e[2] = h, e[3] = c) : c = e[3];
    const f = O(c);
    let m;
    if (e[4] !== h || e[5] !== u) {
        const M = ut(h, "4031588851"),
            A = ut(h, "3533083032", {
                disableExposureLog: !0
            });
        m = (u ? A : M).get("headline_option", "HELP_WITH"), e[4] = h, e[5] = u, e[6] = m
    } else m = e[6];
    const n = m;
    let o;
    e[7] !== t ? (o = {
        shouldBeEnabledForDefaultAssistant: !0,
        clientThreadId: t
    }, e[7] = t, e[8] = o) : o = e[8];
    const d = dn(o),
        x = di(),
        p = js();
    let g;
    e[9] !== p || e[10] !== i || e[11] !== f ? (g = Dl({
        activeSystemHintType: p,
        isAnonModeEnabled: f,
        currentModelId: i
    }), e[9] = p, e[10] = i, e[11] = f, e[12] = g) : g = e[12];
    const S = g;
    let l;
    e[13] !== n || e[14] !== S || e[15] !== x ? (l = s.jsx("div", {
        className: "mb-7 hidden text-center sm:block",
        children: n === "CHATGPT_LOGO" ? s.jsx(Bo, {
            className: "inline-block h-12 w-12"
        }) : s.jsx(An, {
            headlineOption: n,
            overrideMessage: x || S
        })
    }), e[13] = n, e[14] = S, e[15] = x, e[16] = l) : l = e[16];
    const y = d;
    let I;
    e[17] !== t || e[18] !== i || e[19] !== n || e[20] !== S || e[21] !== y ? (I = s.jsx(Wl, {
        headlineOption: n,
        starterPromptStyle: y,
        clientThreadId: t,
        currentModelId: i,
        overrideMessage: S
    }), e[17] = t, e[18] = i, e[19] = n, e[20] = S, e[21] = y, e[22] = I) : I = e[22];
    let T;
    return e[23] !== l || e[24] !== I ? (T = s.jsxs("div", {
        className: "flex justify-center",
        children: [l, I]
    }), e[23] = l, e[24] = I, e[25] = T) : T = e[25], T
}

function Bl(a) {
    "use forget";
    var k, j;
    const e = Pe.c(15),
        {
            headlineOption: t,
            overrideMessage: i
        } = a,
        h = function(C) {
            const {
                name: w
            } = C;
            return s.jsx(qn, {
                label: f.formatMessage(V.editNicknameTooltip),
                delayDuration: 300,
                side: "top",
                children: s.jsx("button", {
                    onClick: () => {
                        io.setAutoHighlightNicknameInput(!0), l("#settings/".concat(Uo.Personalization))
                    },
                    style: {
                        textDecoration: "none",
                        transition: "color 0.2s"
                    },
                    onMouseEnter: Ul,
                    onMouseLeave: Gl,
                    children: w
                })
            })
        };
    let r;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (r = function() {
        const C = [],
            w = [];
        C.push("READY_WHEN_YOU_ARE", "ON_YOUR_MIND", "WHAT_ARE_YOU_WORKING_ON", "AGENDA_TODAY", "SHOULD_WE_BEGIN"), w.push("GOOD_TO_SEE_YOU", "DIVE_IN", "HOW_CAN_I_HELP", ...C);
        const D = w[Math.floor(Math.random() * w.length)],
            J = C[Math.floor(Math.random() * C.length)],
            q = "".concat(J, " | ").concat(D);
        es.setCookie(ts.headlineMessage, q)
    }, e[0] = r) : r = e[0];
    const u = r,
        c = function() {
            var ne, E;
            const C = es.getCookie(ts.GreetingName),
                w = es.getCookie(ts.headlineMessage),
                D = w == null ? void 0 : w.split("|"),
                J = (ne = D == null ? void 0 : D[0]) == null ? void 0 : ne.trim(),
                q = (E = D == null ? void 0 : D[1]) == null ? void 0 : E.trim();
            return {
                cookieName: C,
                isReadyForPersonalized: !!C && C.length <= o,
                headline: J,
                namedHeadline: q
            }
        },
        f = ns(),
        m = ot(),
        n = ut(m, "1704793646"),
        o = n.get("name_char_limit", 20),
        [d, x] = v.useState(c),
        p = fi(),
        g = n.get("greeting_web", !1),
        S = n.get("full_name_llm", !1),
        l = ao();
    let y, I;
    e[1] !== m || e[2] !== S || e[3] !== p || e[4] !== g ? (y = () => zo(() => {
        if (g && p) {
            const P = Yn(m).data,
                C = Kn(m).data;
            if (P && C) {
                const w = Qn(C, P, S);
                es.setCookie(ts.GreetingName, w), vo.count(To.MOONSHINE, "splashScreenV2.greeting_cookie_name_set_web")
            }
            u()
        } else es.deleteCookie(ts.GreetingName), es.deleteCookie(ts.headlineMessage)
    }), I = [m, g, S, p], e[1] = m, e[2] = S, e[3] = p, e[4] = g, e[5] = y, e[6] = I) : (y = e[5], I = e[6]), v.useEffect(y, I);
    let T;
    e[7] !== c || e[8] !== p || e[9] !== g ? (T = () => {
        const P = () => {
            if (g && p) {
                const {
                    cookieName: C,
                    isReadyForPersonalized: w
                } = c();
                x(D => St(Ie({}, D), {
                    cookieName: C,
                    isReadyForPersonalized: w
                }))
            }
        };
        return window.addEventListener("refreshGreeting", P), () => window.removeEventListener("refreshGreeting", P)
    }, e[7] = c, e[8] = p, e[9] = g, e[10] = T) : T = e[10], v.useEffect(T);
    let M, A;
    e[11] !== p || e[12] !== g ? (M = () => {
        g && p && vo.count(To.MOONSHINE, "splashScreenV2.greeting_shown_web")
    }, A = [g, p], e[11] = p, e[12] = g, e[13] = M, e[14] = A) : (M = e[13], A = e[14]), v.useEffect(M, A);
    let b;
    return i ? b = f.formatMessage(i) : d.isReadyForPersonalized && g ? b = s.jsx(s.Fragment, {
        children: s.jsx(_t, St(Ie({}, Gs[(k = d.namedHeadline) != null ? k : t].withName), {
            values: {
                name: s.jsx(h, {
                    name: (j = d.cookieName) != null ? j : ""
                }, "name")
            }
        }))
    }) : g && d.headline ? b = f.formatMessage(Gs[d.headline].original) : b = f.formatMessage(Gs[t].original), b
}

function Gl(a) {
    a.currentTarget.className = "text-inherit"
}

function Ul(a) {
    a.currentTarget.className = "text-token-text-secondary"
}

function An(a) {
    "use forget";
    var j;
    const e = Pe.c(27),
        {
            headlineOption: t,
            overrideMessage: i
        } = a,
        h = ot(),
        r = Gn();
    let u;
    e[0] !== r ? (u = {
        isTempChatVisible: r
    }, e[0] = r, e[1] = u) : u = e[1];
    const [c, f] = v.useState(u);
    let m, n;
    e[2] !== r ? (m = () => {
        f({
            isTempChatVisible: r
        })
    }, n = [r], e[2] = r, e[3] = m, e[4] = n) : (m = e[3], n = e[4]), Un(m, n);
    let o;
    e[5] !== h ? (o = () => Vn(h), e[5] = h, e[6] = o) : o = e[6];
    const d = O(o),
        {
            openSettings: x
        } = ui(),
        p = js(),
        g = ((j = Go()) == null ? void 0 : j.isHipaaCompliantWorkspace) && p === kt.Agent;
    let S;
    e[7] === Symbol.for("react.memo_cache_sentinel") ? (S = {
        viewTransitionName: "var(--vt-splash-screen-headline)"
    }, e[7] = S) : S = e[7];
    let l;
    e[8] !== t || e[9] !== d || e[10] !== r || e[11] !== x || e[12] !== i || e[13] !== c.isTempChatVisible ? (l = d ? s.jsxs("div", {
        className: We("text-page-header flex flex-col items-center gap-2", c.isTempChatVisible && "invisible"),
        children: [s.jsx("h1", {
            className: "text-[28px] leading-[34px] font-normal tracking-[0.38px]",
            children: s.jsx(_t, Ie({}, V.developerModeTitle))
        }), s.jsx("p", {
            className: "text-token-text-secondary dark:text-token-text-tertiary max-w-md text-center text-base leading-[24px] font-normal tracking-[-0.32px] text-balance",
            children: s.jsx(_t, St(Ie({}, V.developerModeSubtitle), {
                values: {
                    settings: s.jsx(zn, {
                        onClick: () => x(Uo.ConnectorsAdvanced),
                        children: s.jsx(_t, Ie({}, V.settingsLink))
                    })
                }
            }))
        })]
    }) : s.jsx("h1", {
        className: We("text-page-header inline-flex min-h-10.5 items-baseline whitespace-pre-wrap", c.isTempChatVisible && "invisible"),
        "aria-hidden": r,
        children: s.jsx("div", {
            className: "px-1 text-pretty whitespace-pre-wrap",
            children: s.jsx(Bl, {
                headlineOption: t,
                overrideMessage: i
            })
        })
    }), e[8] = t, e[9] = d, e[10] = r, e[11] = x, e[12] = i, e[13] = c.isTempChatVisible, e[14] = l) : l = e[14];
    let y;
    e[15] !== g ? (y = g ? s.jsx(mi, {
        className: "mt-4 max-w-3xl",
        message: s.jsx(_t, Ie({}, V.hipaaAgentWarning))
    }) : null, e[15] = g, e[16] = y) : y = e[16];
    const I = !c.isTempChatVisible && "hidden";
    let T;
    e[17] !== I ? (T = We("bottom-0", I), e[17] = I, e[18] = T) : T = e[18];
    const M = !r;
    let A;
    e[19] === Symbol.for("react.memo_cache_sentinel") ? (A = s.jsx(hi, {}), e[19] = A) : A = e[19];
    let b;
    e[20] !== M || e[21] !== T ? (b = s.jsx("div", {
        className: T,
        "aria-hidden": M,
        children: A
    }), e[20] = M, e[21] = T, e[22] = b) : b = e[22];
    let k;
    return e[23] !== b || e[24] !== l || e[25] !== y ? (k = s.jsx("div", {
        className: "relative inline-flex justify-center text-center text-2xl leading-9 font-semibold",
        children: s.jsx("div", {
            children: s.jsxs("div", {
                className: "grid-cols-1 items-center justify-end",
                style: S,
                children: [l, y, b]
            })
        })
    }), e[23] = b, e[24] = l, e[25] = y, e[26] = k) : k = e[26], k
}
const V = On({
        developerModeTitle: {
            id: "SplashScreenV2.developerModeTitle",
            defaultMessage: "Developer mode"
        },
        developerModeSubtitle: {
            id: "SplashScreenV2.developerModeSubtitle",
            defaultMessage: "Memory is not used for this chat. {settings}"
        },
        settingsLink: {
            id: "SplashScreenV2.settingsLink",
            defaultMessage: "Settings"
        },
        hipaaAgentWarning: {
            id: "SplashScreenV2.hipaaAgentWarning",
            defaultMessage: "Do not enter Protected Health Information (PHI) into Agent."
        },
        whatCanIHelpWith: {
            id: "SplashScreenV2.whatCanIHelpWith",
            defaultMessage: "What can I help with?"
        },
        whatCanIHelpWithWithName: {
            id: "SplashScreenV2.whatCanIHelpWith.withName",
            defaultMessage: "What can I help with, {name}?"
        },
        whereShouldWeStart: {
            id: "SplashScreenV2.whereShouldWeStart",
            defaultMessage: "Where should we start?"
        },
        whereShouldWeStartWithName: {
            id: "SplashScreenV2.whereShouldWeStart.withName",
            defaultMessage: "Where should we start, {name}?"
        },
        askChatgptAnything: {
            id: "SplashScreenV2.askChatgptAnything",
            defaultMessage: "Ask ChatGPT anything"
        },
        askChatgptAnythingWithName: {
            id: "SplashScreenV2.askChatgptAnything.withName",
            defaultMessage: "Ask ChatGPT anything, {name}"
        },
        shouldWeBegin: {
            id: "SplashScreenV2.shouldWeBegin",
            defaultMessage: "Where should we begin?"
        },
        goodToSeeYouWithName: {
            id: "SplashScreenV2.goodToSeeYou.withName",
            defaultMessage: "Good to see you, {name}."
        },
        diveInWithName: {
            id: "SplashScreenV2.diveInWithName",
            defaultMessage: "Hey, {name}. Ready to dive in?"
        },
        readyWhenYouAre: {
            id: "SplashScreenV2.readyWhenYouAre",
            defaultMessage: "Ready when you are."
        },
        onYourMind: {
            id: "SplashScreenV2.onYourMind",
            defaultMessage: "What’s on your mind today?"
        },
        whatAreYouWorkingOn: {
            id: "SplashScreenV2.whatAreYouWorkingOn",
            defaultMessage: "What are you working on?"
        },
        agendaToday: {
            id: "SplashScreenV2.agendaToday",
            defaultMessage: "What’s on the agenda today?"
        },
        deepResearchPlaceholder: {
            id: "G1v9do",
            defaultMessage: "What are you researching?"
        },
        editNicknameTooltip: {
            id: "SplashScreenV2.editNicknameTooltip",
            defaultMessage: "Edit nickname"
        },
        howCanIHelp: {
            id: "SplashScreenV2.howCanIHelp",
            defaultMessage: "How can I help?"
        },
        howCanIHelpWithName: {
            id: "SplashScreenV2.howCanIHelp.withName",
            defaultMessage: "How can I help, {name}?"
        },
        chatgpt: {
            id: "SplashScreenV2.chatgpt",
            defaultMessage: "ChatGPT"
        },
        whatCanIDo: {
            id: "SplashScreenV2.whatCanIDo",
            defaultMessage: "What can I do for you?"
        }
    }),
    Gs = {
        HELP_WITH: {
            original: V.whatCanIHelpWith,
            withName: V.whatCanIHelpWithWithName
        },
        WHERE_TO_START: {
            original: V.whereShouldWeStart,
            withName: V.whereShouldWeStartWithName
        },
        ASK_CHATGPT: {
            original: V.askChatgptAnything,
            withName: V.askChatgptAnythingWithName
        },
        HOW_CAN_I_HELP: {
            original: V.howCanIHelp,
            withName: V.howCanIHelpWithName
        },
        GOOD_TO_SEE_YOU: {
            original: V.goodToSeeYouWithName,
            withName: V.goodToSeeYouWithName
        },
        DIVE_IN: {
            original: V.diveInWithName,
            withName: V.diveInWithName
        },
        READY_WHEN_YOU_ARE: {
            original: V.readyWhenYouAre,
            withName: V.readyWhenYouAre
        },
        ON_YOUR_MIND: {
            original: V.onYourMind,
            withName: V.onYourMind
        },
        WHAT_ARE_YOU_WORKING_ON: {
            original: V.whatAreYouWorkingOn,
            withName: V.whatAreYouWorkingOn
        },
        AGENDA_TODAY: {
            original: V.agendaToday,
            withName: V.agendaToday
        },
        SHOULD_WE_BEGIN: {
            original: V.shouldWeBegin,
            withName: V.shouldWeBegin
        },
        WHAT_CAN_I_DO: {
            original: V.whatCanIDo,
            withName: V.whatCanIDo
        }
    },
    zl = 7,
    Vl = 5,
    ql = 3600 * 1e3,
    Yl = async ({
        text: a,
        numCompletions: e,
        isUnauthenticated: t,
        isThreadUsingSearchMode: i = !1,
        autocompleteMode: h,
        activeSystemHintType: r
    }) => {
        try {
            return (t ? await rs.safePost("/conversation/experimental/generate_autocompletions_anon", {
                requestBody: {
                    input_text: a,
                    num_completions: e,
                    in_search_mode: i,
                    system_hint: r != null ? r : void 0
                },
                authOption: Ks.Anonymous
            }) : await rs.safePost("/conversation/experimental/generate_autocompletions", {
                requestBody: {
                    input_text: a,
                    num_completions: e,
                    in_search_mode: i,
                    system_hint: r != null ? r : void 0
                }
            })).completions.map(c => ({
                id: Hn(),
                type: He.Autocomplete,
                title: c.slice(0, a.length),
                body: c.slice(a.length),
                oneliner: c,
                prompt: c,
                source: h
            }))
        } catch (u) {
            return []
        }
    },
    no = (a, e = !1) => ut(a, jt() ? "4093727931" : "312855442", {
        disableExposureLog: !e
    }),
    Kl = ({
        clientThreadId: a,
        composerController: e,
        isGizmoThread: t,
        isNewThread: i,
        isProjectThread: h
    }) => {
        const [r, u] = Do(), c = r.get("forceShowNuxCASuggestion") === "true", f = ot(), m = !jt(), n = js(), {
            autocompletions$: o,
            personalizedAutocompletePool$: d
        } = ho(e), x = Si(), p = 3, g = n === kt.Search, {
            bingTrendingSuggestions: S,
            chatgptTrendingSuggestions: l,
            imageGenTrendingSuggestions: y,
            fetchBingTrendingSuggestions: I,
            fetchChatgptTrendingSuggestions: T
        } = Jl(), M = v.useRef({
            bing: 0,
            chatgpt: {
                time: 0,
                imageGen: !1
            }
        }), A = v.useRef(!1), [b, k] = v.useState(!1), j = Jn(H => H.files), P = j.length > 0, C = v.useMemo(() => j.some(H => {
            var F, R, xe, _e;
            return ((_e = (xe = (F = H.fileSpec) == null ? void 0 : F.mimeType) != null ? xe : (R = H.file) == null ? void 0 : R.type) != null ? _e : "").toLowerCase().startsWith("image/")
        }), [j]), w = xi(), D = O(() => Vo(e)), J = i && !t && !h && w() && ut(f, "4031588851", {
            disableExposureLog: !0
        }).get("personalized_prompts_enabled", !1), {
            data: q
        } = Ln(St(Ie({}, yi(Zs * 3, null)), {
            enabled: J
        })), ne = v.useMemo(() => {
            var F;
            return ((F = q == null ? void 0 : q.items) != null ? F : []).filter(R => R.category === "personalized").map(R => ({
                type: He.Starter,
                id: R.id,
                title: R.title,
                body: R.description,
                prompt: R.prompt,
                oneliner: R.oneliner,
                category: R.category,
                theme: R.theme,
                emoji: R.emoji
            }))
        }, [q]), E = v.useMemo(() => bi(ne), [ne]);
        v.useEffect(() => {
            d.set(E)
        }, [E, d]), v.useEffect(() => _o(Ts(e).dom, {
            click: () => k(!0)
        }), [e]);
        const L = v.useCallback(H => {
                const B = vs(e);
                return B && Us(H).startsWith(B.toLocaleLowerCase())
            }, [e]),
            re = v.useCallback(H => {
                const B = vs(e),
                    F = H.title + H.body;
                return L(H) ? St(Ie({}, H), {
                    title: B,
                    body: F.slice(B.length)
                }) : St(Ie({}, H), {
                    title: F,
                    body: ""
                })
            }, [e, L]),
            _ = v.useCallback((H = !1) => {
                o.set(B => !B.some(L) && B.length > 0 ? [] : H ? B : B.map(re))
            }, [L, re, o]),
            N = ns(),
            K = Ci(),
            {
                data: Z
            } = vi(4, K),
            de = v.useMemo(() => ({
                [te.Canvas]: [{
                    type: He.Starter,
                    title: N.formatMessage({
                        id: "GMvniX",
                        defaultMessage: "Help me write a birthday message for a friend"
                    }),
                    prompt: N.formatMessage({
                        id: "JInqHw",
                        defaultMessage: "Help me write a birthday message for a friend"
                    }),
                    body: "",
                    theme: te.Canvas
                }, {
                    type: He.Starter,
                    title: N.formatMessage({
                        id: "Xwp6O+",
                        defaultMessage: "Help me write a short story"
                    }),
                    prompt: N.formatMessage({
                        id: "e2j3PL",
                        defaultMessage: "Help me write a short story set in a post-apocalyptic Tokyo, focused on a character who’s discovering a long-lost secret"
                    }),
                    body: "",
                    theme: te.Canvas
                }, {
                    type: He.Starter,
                    title: N.formatMessage({
                        id: "ARQf7p",
                        defaultMessage: "Help me write a basic outline for an essay"
                    }),
                    prompt: N.formatMessage({
                        id: "K0WcGA",
                        defaultMessage: "Help me write a basic outline for an essay"
                    }),
                    body: "",
                    theme: te.Canvas
                }, {
                    type: He.Starter,
                    title: N.formatMessage({
                        id: "z+JwEj",
                        defaultMessage: "Create a business plan outline"
                    }),
                    prompt: N.formatMessage({
                        id: "4c/Ux5",
                        defaultMessage: "Create a detailed outline for a business plan for a new app that connects local artists with buyers. Include sections for market analysis, monetization, and user acquisition"
                    }),
                    body: "",
                    theme: te.Canvas
                }],
                [te.Image]: [{
                    type: He.Starter,
                    title: N.formatMessage({
                        id: "noA7wB",
                        defaultMessage: "Design a modern logo"
                    }),
                    prompt: N.formatMessage({
                        id: "k53BuX",
                        defaultMessage: "Create a modern, minimalist logo for a tech startup called ‘Nexora’. It should use bold typography and a sleek geometric icon, suitable for both light and dark backgrounds"
                    }),
                    body: "",
                    theme: te.Image
                }, {
                    type: He.Starter,
                    title: N.formatMessage({
                        id: "akHy6z",
                        defaultMessage: "Create an invite for my birthday"
                    }),
                    prompt: N.formatMessage({
                        id: "BXf15G",
                        defaultMessage: "Please create an invite for my birthday to send to my friends. It’ll be an outdoor barbeque with music and delicious food with my closest friends and family"
                    }),
                    body: "",
                    theme: te.Image
                }, {
                    type: He.Starter,
                    title: N.formatMessage({
                        id: "57SKj2",
                        defaultMessage: "Create a cartoon illustration of my pet"
                    }),
                    prompt: N.formatMessage({
                        id: "EtCE7V",
                        defaultMessage: "Please create an illustration of my pet in 2D animation style. It’s taking a nap in its favorite spot by the fire"
                    }),
                    body: "",
                    theme: te.Image
                }, {
                    type: He.Starter,
                    title: N.formatMessage({
                        id: "s5iqKS",
                        defaultMessage: "Create a Renaissance-style painting"
                    }),
                    prompt: N.formatMessage({
                        id: "mEPKGA",
                        defaultMessage: "Please create a Renaissance-style painting of a Mars rover. Use techniques like chiaroscuro and a warm color palette"
                    }),
                    body: "",
                    theme: te.Image
                }],
                [te.ContextualAnswers]: [{
                    type: He.Starter,
                    title: N.formatMessage({
                        id: "VJy602",
                        defaultMessage: "Summarize my top projects this quarter and key outcomes across all of them."
                    }),
                    prompt: N.formatMessage({
                        id: "BADBWZ",
                        defaultMessage: "Summarize my top projects this quarter and key outcomes across all of them."
                    }),
                    icon: s.jsx(Xn, {
                        className: "h-full w-full"
                    }),
                    body: "",
                    theme: te.ContextualAnswers
                }, {
                    type: He.Starter,
                    title: N.formatMessage({
                        id: "CXhrsc",
                        defaultMessage: "Get me up to speed on the past 2 weeks of project updates."
                    }),
                    prompt: N.formatMessage({
                        id: "WPQR3a",
                        defaultMessage: "Get me up to speed on the past 2 weeks of project updates."
                    }),
                    icon: s.jsx(Zn, {
                        className: "h-full w-full"
                    }),
                    body: "",
                    theme: te.ContextualAnswers
                }, {
                    type: He.Starter,
                    title: N.formatMessage({
                        id: "7QVCTa",
                        defaultMessage: "Find the revenue projection for Q3 and the most profitable projects."
                    }),
                    prompt: N.formatMessage({
                        id: "tvB7JD",
                        defaultMessage: "Find the revenue projection for Q3 and the most profitable projects."
                    }),
                    icon: s.jsx(ea, {
                        className: "h-full w-full"
                    }),
                    body: "",
                    theme: te.ContextualAnswers
                }, {
                    type: He.Starter,
                    title: N.formatMessage({
                        id: "Rny+bg",
                        defaultMessage: "What is our company's current policy on work from home?"
                    }),
                    prompt: N.formatMessage({
                        id: "P0W1ks",
                        defaultMessage: "What is our company's current policy on work from home?"
                    }),
                    icon: s.jsx(ta, {
                        className: "h-full w-full"
                    }),
                    body: "",
                    theme: te.ContextualAnswers
                }]
            }), [N]),
            pe = Go(),
            ye = sa().connectorLinks.size > 0,
            Q = O(() => oa(f)),
            U = !Q,
            {
                prompts: ae,
                isLoading: ee
            } = Ti(),
            le = Q && Q.length > 0 && !ye,
            G = jt(),
            be = le ? ut(f, "1704943789").get("onboarding_state", "control") === "suggested_prompts" : !1,
            $ = v.useMemo(() => new _i({
                localStorageKey: na.CARecommendedPromptsUpsell,
                schedule: {
                    intervalMs: 1440 * 60 * 1e3,
                    maxShowsPerInterval: 3
                },
                termination: {
                    maxShows: 9
                }
            }), []);
        v.useEffect(() => {
            if ((!le || !be || n != null || !$.shouldShow()) && !c || U || ee || pe == null) return;
            const H = [...ae];
            o.set(B => B.length > 0 ? B : (A.current || ($.recordShown(), is.logEventWithStatsig("chatgpt_contextual_answers_recommended_prompt_shown", "chatgpt_contextual_answers_recommended_prompt_shown", {
                prompts: H.map(F => {
                    var R;
                    return (R = F.data) == null ? void 0 : R.id
                }).join(","),
                shown_times: $.getShownTimes().toString()
            }), A.current = !0), H))
        }, [ae, U, ee, le, be, n, $, c, pe, o]);
        const ke = no(f, !1),
            Ce = no(f, !0),
            Ne = wi(f, !0),
            ze = Ml();
        v.useEffect(() => Ys(() => wo(e), H => {
            const B = () => {
                o.set(F => F.filter(R => R.theme !== te.Search && R.theme !== te.ChatGPTTrending && R.theme !== te.ImageGenTrending && R.theme !== te.Image && R.theme !== te.Slurm && R.theme !== te.Tatertot && R.theme !== te.ContextualAnswersNUX && R.theme !== te.Glaux))
            };
            if (H && i && !t && !h || c)
                if (g) o.set(S.length > 0 ? S : []), M.current.bing === 0 && (M.current.bing = Date.now(), I());
                else if (!n && (D || b) && w() && Ne.get("homepage_prompt_style", "chips") === "autocomplete") {
                if (Ne.get("personalized_prompts_enabled", !1) && ne.length > 0) {
                    const F = E.slice(0, Zs).map(R => Mi(R, e, f, x)).filter(Boolean);
                    o.set(F)
                } else if (b && !J) {
                    const F = Al(ze, o(), 4, 3);
                    o.set(F.map(R => St(Ie({}, R), {
                        body: ""
                    })))
                }
            } else if (!n && ke.get("enable_data", !1)) {
                o.set(() => b && C && y.length > 0 && Ce.get("enable_image_gen_trending", !1) ? y : b && !C && l.length > 0 && Ce.get("enable_chatgpt_trending", !1) ? l : []);
                const F = Date.now(),
                    R = M.current.chatgpt;
                (R.time === 0 || F - R.time > ql || R.imageGen !== C) && (M.current.chatgpt = {
                    time: F,
                    imageGen: C
                }, T(C))
            } else if (K && Z && Z.length > 0) o.set(Z);
            else if (n === kt.PictureV2) {
                const F = Ai(N);
                o.set(F)
            } else if (n === kt.Tatertot) o.set(Ii(N, G));
            else if (n === kt.Slurm) ut(f, "1704943789").get("post_connection_connector_button", !1) && ae.length > 0 && !ee && o.set(ae);
            else {
                if (o().length > 0 && o()[0].theme === te.ContextualAnswersNUX) return;
                if (o().length === 0) return;
                B()
            } else B()
        }, {
            fireImmediately: !0
        }), [e, I, T, ke, Ce, g, o, S, l, y, n, b, N, a, i, t, h, de, r, u, c, P, C, G, ze, ne, Ne, ae, ee, f, w, D, pe, J, Z, K, x, E]), v.useEffect(() => zo(() => {
            if (wo(e)) {
                const H = o().filter(B => B.type !== He.Autocomplete);
                H.length > 0 && Pi(H, a)
            }
        }), [e, o, a]);
        const ue = Zl(g),
            ge = ut(f, "4031588851"),
            fe = ge.get("autocomplete_min_char", 4),
            De = ge.get("autocomplete_fetch_interval", 200),
            Ve = v.useRef(null),
            qe = v.useCallback(aa(async H => {
                if (!Ql(e, fe)) {
                    o.set([]);
                    return
                }
                const B = vs(e);
                if (!(Ve.current && Ve.current.length > fe && B.startsWith(Ve.current))) try {
                    const F = (await Yl({
                        text: B,
                        numCompletions: H,
                        isUnauthenticated: m,
                        isThreadUsingSearchMode: g,
                        autocompleteMode: ue,
                        activeSystemHintType: n
                    })).filter(L).map(re);
                    o.set(R => {
                        const xe = R.filter(L),
                            _e = F.filter(Ze => {
                                const Re = Us(Ze);
                                return !xe.some(W => {
                                    const Fe = Us(W);
                                    if (Re === Fe) return !0;
                                    const Qe = new RegExp("[\\p{P}\\p{S}]$", "u"),
                                        yt = Re.replace(Qe, ""),
                                        we = Fe.replace(Qe, "");
                                    return yt === Fe || Re === we || yt === we
                                })
                            }).slice(0, p - xe.length);
                        return [...xe, ..._e]
                    })
                } catch (F) {}
            }, ue === "BING" ? 150 : De), [e, ue, re, De, n]),
            Se = v.useCallback(() => {
                _();
                const H = p - o().filter(L).length;
                H > 0 && qe(H)
            }, [qe, _, o, L]),
            $e = v.useMemo(() => ue === "HARDCODED" ? _ : Se, [ue, Se, _]),
            ie = v.useCallback(() => {
                $e()
            }, [$e]),
            Ye = v.useCallback(() => {
                _(!0), vs(e).indexOf("\n") > 0 && o.set([])
            }, [e, o, _]);
        v.useEffect(() => _o(Ts(e).dom, {
            input: ie
        }), [e, ie]), v.useEffect(() => Ys(() => ia(e), Ye), [e, Ye])
    };

function Ql(a, e) {
    var i;
    const t = Ts(a).state.doc;
    return t.childCount === 1 && ((i = t.firstChild) == null ? void 0 : i.isTextblock) === !0 && t.content.size >= e && t.content.size <= 80
}
const Jl = () => {
    const [a, e] = v.useState([]), [t, i] = v.useState([]), [h, r] = v.useState([]), u = ro(), c = ot(), f = no(c, !1), m = f.get("num_mobile_results", Vl), n = f.get("num_desktop_results", zl), o = f.get("item_label", "PROMPT"), d = v.useCallback(async () => {
        const g = (await rs.safePost("/conversation/experimental/generate_trending_suggestions", {
            requestBody: {
                num_items: Zs
            },
            authOption: Ks.SendIfAvailable
        })).suggestions.map((S, l) => ({
            type: He.Trending,
            title: Lo(S),
            body: "",
            icon: s.jsx(ko, {
                className: "h-full w-full"
            }),
            prompt: Lo(S),
            id: "search-trending-".concat(l),
            theme: te.Search
        }));
        return e(g), g
    }, []), x = v.useCallback(async p => {
        const S = ((await rs.safeGet("/trending/chatgpt", {
            parameters: {
                query: Ie({
                    num_items: u ? n : m
                }, p ? {
                    tags: ["image_gen"]
                } : {})
            },
            authOption: Ks.SendIfAvailable
        })).topics || []).map((l, y) => {
            var k, j, P, C, w;
            const I = (k = l.suggested_prompts) != null ? k : [],
                T = I.length > 0 ? I[Math.floor(Math.random() * I.length)] : void 0,
                M = (j = T == null ? void 0 : T.short_prompt) != null ? j : "",
                A = (C = (P = l.short_title) != null ? P : l.title) != null ? C : "",
                b = (w = T == null ? void 0 : T.prompt) != null ? w : Array.isArray(l.prompts) && l.prompts.length > 0 ? l.prompts[Math.floor(Math.random() * l.prompts.length)] : A;
            return {
                type: He.Trending,
                title: o === "TITLE" ? A : M,
                body: "",
                icon: s.jsx(ko, {
                    className: "h-full w-full"
                }),
                prompt: b,
                id: "chatgpt-trending-".concat(y),
                theme: p ? te.ImageGenTrending : te.ChatGPTTrending
            }
        });
        return p ? r(S) : i(S), S
    }, [u, m, n, o]);
    return {
        bingTrendingSuggestions: a,
        chatgptTrendingSuggestions: t,
        imageGenTrendingSuggestions: h,
        fetchBingTrendingSuggestions: d,
        fetchChatgptTrendingSuggestions: x
    }
};

function Lo(a) {
    return a.split(" ").map(ji).join(" ")
}
const Us = a => "".concat(a.title).concat(a.body).toLocaleLowerCase();

function Xl() {
    const a = ot(),
        t = ut(a, "4031588851", {
            disableExposureLog: !0
        }).get("autocomplete_qualified_start_date", "2099-09-13T00:00:00Z"),
        i = ra();
    return !!i && i.created * 1e3 >= new Date(t).getTime()
}

function Zl(a) {
    const e = ot(),
        t = !jt(),
        i = xt(e, "1468311859"),
        h = xt(e, "2053937752"),
        r = xt(e, "3664702598"),
        u = xt(e, "471233253"),
        c = ut(e, "4031588851"),
        f = ut(e, "3533083032"),
        m = Xl(),
        n = !t && i || t && h,
        o = (!t && r || t && u) && m;
    let d = "HARDCODED"; {
        const x = t ? f : c;
        if (a) {
            const p = x.get("search_autocomplete_mode", "");
            n && p && (d = p)
        } else o && (d = x.get("autocomplete_mode", "HARDCODED"))
    }
    return d
}
const ec = ({
    clientThreadId: a,
    isGizmoThread: e,
    isNewThread: t,
    isProjectThread: i
}) => {
    const h = ds();
    return Kl({
        clientThreadId: a,
        composerController: h,
        isGizmoThread: e,
        isNewThread: t,
        isProjectThread: i
    }), null
};

function tc(a) {
    "use forget";
    const e = Pe.c(27),
        {
            children: t,
            className: i,
            conversation: h,
            inline: r,
            onDropAccepted: u
        } = a,
        c = ns(),
        f = h != null ? h : la(v.use(ca));
    let m;
    e[0] !== f || e[1] !== u ? (m = k => {
        v.startTransition(() => {
            const {
                tempIds: j
            } = po(us())({
                files: k,
                type: "drag",
                conversation: f
            });
            u == null || u(j)
        })
    }, e[0] = f, e[1] = u, e[2] = m) : m = e[2];
    let n;
    e[3] === Symbol.for("react.memo_cache_sentinel") ? (n = da(ua), e[3] = n) : n = e[3];
    let o;
    e[4] !== m ? (o = {
        disabled: !1,
        noClick: !0,
        noKeyboard: !0,
        onDropAccepted: m,
        multiple: !0,
        accept: n
    }, e[4] = m, e[5] = o) : o = e[5];
    const {
        getRootProps: d,
        getInputProps: x,
        isDragActive: p,
        isDragReject: g
    } = Fl(o);
    let S;
    e[6] !== d ? (S = d(), e[6] = d, e[7] = S) : S = e[7];
    const l = p ? "visible" : "hidden";
    let y;
    e[8] !== r || e[9] !== g ? (y = s.jsx(Ei, {
        isRejected: g,
        inline: r
    }), e[8] = r, e[9] = g, e[10] = y) : y = e[10];
    let I;
    e[11] !== l || e[12] !== y ? (I = s.jsx(v.Activity, {
        mode: l,
        children: y
    }), e[11] = l, e[12] = y, e[13] = I) : I = e[13];
    let T;
    e[14] !== c ? (T = c.formatMessage({
        id: "imagesApp.dropTarget.fileInputLabel",
        defaultMessage: "Attach images"
    }), e[14] = c, e[15] = T) : T = e[15];
    let M;
    e[16] !== x ? (M = x(), e[16] = x, e[17] = M) : M = e[17];
    let A;
    e[18] !== T || e[19] !== M ? (A = s.jsx("input", Ie({
        name: "images-app-drop-container-input",
        "arial-label": T
    }, M)), e[18] = T, e[19] = M, e[20] = A) : A = e[20];
    let b;
    return e[21] !== t || e[22] !== i || e[23] !== A || e[24] !== S || e[25] !== I ? (b = s.jsxs("div", St(Ie({
        className: i
    }, S), {
        children: [I, A, t]
    })), e[21] = t, e[22] = i, e[23] = A, e[24] = S, e[25] = I, e[26] = b) : b = e[26], b
}

function sc(a) {
    return a.download_url
}

function oc(a) {
    "use forget";
    var r;
    const e = Pe.c(2),
        {
            prompt: t
        } = a,
        i = (r = t.title) != null ? r : "";
    let h;
    return e[0] !== i ? (h = s.jsx("div", {
        className: "text-heading-app box-trim-0.5 mb-3 tracking-tight text-balance",
        children: i
    }), e[0] = i, e[1] = h) : h = e[1], h
}

function nc(a) {
    "use forget";
    const e = Pe.c(2),
        {
            title: t
        } = a;
    let i;
    return e[0] !== t ? (i = s.jsx("div", {
        className: "text-token-text-secondary text-body-regular box-trim-0.5",
        children: t
    }), e[0] = t, e[1] = i) : i = e[1], i
}

function ac(a) {
    "use forget";
    const e = Pe.c(18),
        {
            onChooseNewPhoto: t,
            onTakePhoto: i,
            onClose: h,
            showTakePhoto: r
        } = a,
        u = r === void 0 ? !0 : r;
    let c;
    e[0] !== i || e[1] !== u ? (c = u && s.jsx(Ds, {
        color: "primary",
        size: "large",
        fullWidth: !0,
        className: "rounded-full",
        onClick: i,
        children: s.jsx(_t, {
            id: "53bkCD",
            defaultMessage: "Take a photo"
        })
    }), e[0] = i, e[1] = u, e[2] = c) : c = e[2];
    const f = u ? "secondary" : "primary";
    let m;
    e[3] !== t ? (m = () => t == null ? void 0 : t(), e[3] = t, e[4] = m) : m = e[4];
    let n;
    e[5] !== u ? (n = u ? s.jsx(_t, {
        id: "eFyfxp",
        defaultMessage: "Upload a photo"
    }) : s.jsx(_t, {
        id: "RNN2hq",
        defaultMessage: "Choose a new photo"
    }), e[5] = u, e[6] = n) : n = e[6];
    let o;
    e[7] !== f || e[8] !== m || e[9] !== n ? (o = s.jsx(Ds, {
        color: f,
        size: "large",
        fullWidth: !0,
        className: "rounded-full",
        onClick: m,
        children: n
    }), e[7] = f, e[8] = m, e[9] = n, e[10] = o) : o = e[10];
    let d;
    e[11] === Symbol.for("react.memo_cache_sentinel") ? (d = s.jsx(_t, {
        id: "pUi2k3",
        defaultMessage: "Cancel"
    }), e[11] = d) : d = e[11];
    let x;
    e[12] !== h ? (x = s.jsx(Ds, {
        type: "button",
        color: "ghost",
        size: "large",
        className: "text-token-text-secondary text-sm font-semibold underline decoration-solid underline-offset-2",
        onClick: h,
        children: d
    }), e[12] = h, e[13] = x) : x = e[13];
    let p;
    return e[14] !== c || e[15] !== o || e[16] !== x ? (p = s.jsxs("div", {
        className: "mt-6 flex flex-col gap-3",
        children: [c, o, x]
    }), e[14] = c, e[15] = o, e[16] = x, e[17] = p) : p = e[17], p
}

function ic(a) {
    "use forget";
    const e = Pe.c(5),
        {
            recents: t,
            onSelectRecent: i
        } = a;
    let h;
    e[0] !== i || e[1] !== t ? (h = t.length > 0 && s.jsxs("section", {
        className: "mt-5 flex flex-col gap-3",
        children: [s.jsx("h3", {
            className: "text-token-text-tertiary text-body-regular text-trim font-medium",
            children: s.jsx(_t, {
                id: "ZT3BhG",
                defaultMessage: "Recents"
            })
        }), s.jsx("div", {
            className: "flex w-full justify-between gap-2 max-sm:[&>*:nth-child(4)]:hidden",
            children: t.map(u => s.jsx("button", {
                type: "button",
                onClick: () => i == null ? void 0 : i(u),
                className: We("corner-superellipse/1.1 rounded-xl ring-offset-2 transition outline-none", "focus-visible:ring-token-focus focus-visible:ring", "h-[72px] w-[72px] overflow-hidden", "ease-spring-elegant motion-safe:transition-[scale,filter] motion-safe:hover:brightness-120 motion-safe:active:scale-98"),
                children: s.jsx("img", {
                    src: sc(u),
                    alt: "",
                    className: "h-full w-full object-cover",
                    loading: "lazy"
                })
            }, u.file_id))
        })]
    }), e[0] = i, e[1] = t, e[2] = h) : h = e[2];
    let r;
    return e[3] !== h ? (r = s.jsx(s.Fragment, {
        children: h
    }), e[3] = h, e[4] = r) : r = e[4], r
}

function as(a) {
    "use forget";
    const e = Pe.c(30),
        {
            conversation: t,
            group: i,
            onClose: h,
            onSelectFiles: r,
            onSelectRecent: u,
            onChooseNewPhoto: c,
            onTakePhoto: f,
            prompt: m,
            recents: n
        } = a;
    let o;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (o = us(), e[0] = o) : o = e[0];
    const d = o;
    let x;
    e[1] === Symbol.for("react.memo_cache_sentinel") ? (x = () => xt(d, "416156854") && Ni(d), e[1] = x) : x = e[1];
    const p = O(x);
    let g;
    e[2] === Symbol.for("react.memo_cache_sentinel") ? (g = () => {
        var D, J;
        return (J = (D = Ri(d).data) == null ? void 0 : D.slice(0, 4)) != null ? J : []
    }, e[2] = g) : g = e[2];
    const S = O(g);
    let l, y;
    e[3] !== t || e[4] !== r ? (l = () => Fi({
        conversation: t,
        onFilesUploaded: r,
        isFocusTarget: lc
    }), y = [t, r], e[3] = t, e[4] = r, e[5] = l, e[6] = y) : (l = e[5], y = e[6]), v.useEffect(l, y);
    const I = n != null ? n : S;
    let T;
    e[7] === Symbol.for("react.memo_cache_sentinel") ? (T = ki(d), e[7] = T) : T = e[7];
    const M = T,
        A = h != null ? h : rc;
    let b;
    e[8] !== m ? (b = s.jsx(oc, {
        prompt: m
    }), e[8] = m, e[9] = b) : b = e[9];
    let k;
    e[10] !== i.title ? (k = s.jsx(nc, {
        title: i.title
    }), e[10] = i.title, e[11] = k) : k = e[11];
    let j;
    e[12] !== u || e[13] !== I ? (j = s.jsx(ic, {
        recents: I,
        onSelectRecent: u
    }), e[12] = u, e[13] = I, e[14] = j) : j = e[14];
    let P;
    e[15] !== p || e[16] !== c || e[17] !== h || e[18] !== f ? (P = s.jsx(ac, {
        onChooseNewPhoto: c,
        onTakePhoto: f,
        onClose: h,
        showTakePhoto: p
    }), e[15] = p, e[16] = c, e[17] = h, e[18] = f, e[19] = P) : P = e[19];
    let C;
    e[20] !== t || e[21] !== r || e[22] !== j || e[23] !== P ? (C = s.jsx(qo, {
        store: M,
        children: s.jsxs(tc, {
            inline: !0,
            conversation: t,
            onDropAccepted: r,
            children: [j, P]
        })
    }), e[20] = t, e[21] = r, e[22] = j, e[23] = P, e[24] = C) : C = e[24];
    let w;
    return e[25] !== C || e[26] !== A || e[27] !== b || e[28] !== k ? (w = s.jsx(ma, {
        testId: "modal-style-recents",
        isOpen: !0,
        onClose: A,
        title: b,
        description: k,
        headerClassName: "p-0! min-h-0!",
        textCenter: !0,
        className: "@container/style-recents-modal p-10",
        modalActionsClassName: "w-full",
        size: "normal",
        children: C
    }), e[25] = C, e[26] = A, e[27] = b, e[28] = k, e[29] = w) : w = e[29], w
}

function rc() {}

function lc(a) {
    return a !== document.body
}

function In(a) {
    "use forget";
    const e = Pe.c(11),
        {
            conversation: t
        } = a,
        i = ds(),
        h = Yo(),
        [r] = v.useState(cc);
    let u;
    e[0] !== t || e[1] !== r ? (u = s.jsx(Oi, {
        onUploadFiles: m => {
            const {
                files: n,
                type: o
            } = m, d = us();
            t && po(d)({
                files: n,
                type: o,
                conversation: t,
                filePickerStore: r
            })
        }
    }), e[0] = t, e[1] = r, e[2] = u) : u = e[2];
    let c;
    e[3] !== i || e[4] !== h || e[5] !== t ? (c = s.jsx(uc, {
        conversation: t,
        composerController: i,
        composerFilePickerStore: h
    }), e[3] = i, e[4] = h, e[5] = t, e[6] = c) : c = e[6];
    let f;
    return e[7] !== r || e[8] !== u || e[9] !== c ? (f = s.jsxs(qo, {
        store: r,
        children: [u, c]
    }), e[7] = r, e[8] = u, e[9] = c, e[10] = f) : f = e[10], f
}

function cc() {
    return ha(dc)
}

function dc() {
    return pa
}

function uc(a) {
    "use forget";
    const e = Pe.c(21),
        {
            conversation: t,
            composerController: i,
            composerFilePickerStore: h
        } = a;
    let r;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (r = us(), e[0] = r) : r = e[0];
    const u = r,
        c = Yo();
    let f;
    e[1] === Symbol.for("react.memo_cache_sentinel") ? (f = () => No(u), e[1] = f) : f = e[1];
    const {
        items: m
    } = O(f), n = Li.useStore();
    let o;
    e[2] === Symbol.for("react.memo_cache_sentinel") ? (o = Hi(u), e[2] = o) : o = e[2];
    const d = o;
    let x;
    e[3] === Symbol.for("react.memo_cache_sentinel") ? (x = Wi(u), e[3] = x) : x = e[3];
    const p = x;
    let g;
    e[4] === Symbol.for("react.memo_cache_sentinel") ? (g = Di(u), e[4] = g) : g = e[4];
    const S = g;
    let l;
    e[5] !== t || e[6] !== c ? (l = b => {
        po(u)({
            files: [b],
            type: "camera",
            conversation: t,
            filePickerStore: c
        })
    }, e[5] = t, e[6] = c, e[7] = l) : l = e[7];
    const y = l;
    let I, T;
    e[8] !== t || e[9] !== c || e[10] !== n ? (I = () => Ys(() => $i(t)(), k => S({
        conversation: t,
        tempIds: k,
        filePickerStore: c,
        persistedFileStore: n
    }), {
        fireImmediately: !0
    }), T = [t, S, n, c], e[8] = t, e[9] = c, e[10] = n, e[11] = I, e[12] = T) : (I = e[11], T = e[12]), v.useEffect(I, T);
    let M;
    e[13] !== i || e[14] !== h || e[15] !== t || e[16] !== y ? (M = b => {
        const k = Qs(() => No(u).itemToGroup);
        if (ga.getFilesCount(h.getState()) > 0) {
            const P = Bi(b);
            Gi(i).setImageStyle$({
                ctx: u,
                style: P
            });
            const C = fa(i);
            C.current && C.current.requestSubmit();
            return
        }
        Ro.set(t, {
            promptItem: b,
            group: k[b.id]
        }), _s(u, as, {
            conversation: t,
            prompt: b,
            group: k[b.id],
            onClose: () => {
                Cs(u, as)
            },
            onSelectRecent: P => {
                const C = Sa(P.file_id);
                C && (p({
                    conversation: t,
                    prompt: b.prompt_text,
                    images: [{
                        asset_pointer: C,
                        width: 1,
                        height: 1
                    }]
                }), Cs(u, as))
            },
            onChooseNewPhoto: () => {
                Qs(() => d({
                    source: "photos"
                })), Cs(u, as)
            },
            onTakePhoto: () => {
                Ro.set(t, {
                    promptItem: b,
                    group: k[b.id]
                }), Cs(u, as), _s(u, Ui, {
                    onPhotoSave: y
                })
            }
        })
    }, e[13] = i, e[14] = h, e[15] = t, e[16] = y, e[17] = M) : M = e[17];
    let A;
    return e[18] !== m || e[19] !== M ? (A = s.jsx(un, {
        items: m,
        onSelectPromptItem: M,
        onEditPhoto: mc,
        hideControls: !1
    }), e[18] = m, e[19] = M, e[20] = A) : A = e[20], A
}

function mc() {
    const a = document.getElementById("upload-photos");
    a && a.click()
}
const Pn = a => {
        var e, t;
        return (t = (e = wt.getBranch(a)) == null ? void 0 : e.findLast(({
            message: i
        }) => i.author.role === Ca.Assistant && i.recipient === "all")) == null ? void 0 : t.message
    },
    zs = xa(a => {
        const e = Qs(() => ya(a)),
            t = e ? Pn(e) : null;
        return ba(new Set(t ? [t.id] : []))
    }),
    hc = a => {
        "use forget";
        const e = Pe.c(37),
            {
                conversation: t,
                zIndex: i,
                onClick: h,
                onReveal: r
            } = a,
            u = ns();
        let c;
        e[0] !== t ? (c = () => zs(t), e[0] = t, e[1] = c) : c = e[1];
        const f = O(c),
            [m, n] = ss(t.id, pc),
            o = va(n);
        let d;
        e[2] !== m ? (d = m && !!Ta(m), e[2] = m, e[3] = d) : d = e[3];
        const x = d,
            p = m == null ? void 0 : m.id;
        let g;
        e[4] !== f || e[5] !== p ? (g = p && f.has(p), e[4] = f, e[5] = p, e[6] = g) : g = e[6];
        const S = g;
        let l;
        e[7] !== t || e[8] !== p ? (l = () => {
            p && zs.set(t, new Set(zs(t).add(p)))
        }, e[7] = t, e[8] = p, e[9] = l) : l = e[9];
        const y = Ot(l);
        let I;
        e[10] !== h || e[11] !== y ? (I = () => {
            y(), h()
        }, e[10] = h, e[11] = y, e[12] = I) : I = e[12];
        const T = Ot(I),
            M = Ot(r);
        let A, b;
        e[13] !== S || e[14] !== x || e[15] !== M ? (A = () => {
            x && !S && M()
        }, b = [x, S, M], e[13] = S, e[14] = x, e[15] = M, e[16] = A, e[17] = b) : (A = e[16], b = e[17]), v.useEffect(A, b);
        let k, j;
        e[18] !== S || e[19] !== o || e[20] !== x || e[21] !== y ? (k = () => {
            if (x && !S && !o) {
                const D = setTimeout(() => y(), 5e3);
                return () => {
                    clearTimeout(D), y()
                }
            }
        }, j = [x, S, o, y], e[18] = S, e[19] = o, e[20] = x, e[21] = y, e[22] = k, e[23] = j) : (k = e[22], j = e[23]), v.useEffect(k, j);
        let P, C;
        e[24] !== y ? (P = () => () => y(), C = [y], e[24] = y, e[25] = P, e[26] = C) : (P = e[25], C = e[26]), v.useEffect(P, C);
        let w;
        return e[27] !== t || e[28] !== T || e[29] !== S || e[30] !== u || e[31] !== o || e[32] !== x || e[33] !== m || e[34] !== y || e[35] !== i ? (w = x && !S && s.jsx(os, {
            className: "relative",
            style: {
                zIndex: i
            },
            children: s.jsxs(ws.div, {
                className: We(zi.main, "group bg-token-bg-primary/80 shadow-long pointer-events-auto absolute -top-2 mx-0 mb-4 h-32 w-full cursor-pointer overflow-hidden rounded-3xl px-5 py-3 backdrop-blur-2xl select-none"),
                initial: {
                    opacity: 0,
                    translateY: "-50%"
                },
                animate: {
                    opacity: 1,
                    translateY: "-100%"
                },
                exit: {
                    opacity: 0,
                    scale: .925,
                    filter: "blur(12px)"
                },
                transition: {
                    duration: .6,
                    type: "spring",
                    bounce: .12
                },
                onClick: T,
                children: [s.jsx("button", {
                    "aria-label": u.formatMessage({
                        id: "rbCAqY",
                        defaultMessage: "Dismiss"
                    }),
                    className: "dark:bg-token-bg-secondary dark:hover:bg-token-bg-tertiary text-token-text-primary absolute end-2.5 top-2.5 z-50 flex h-6 w-6 items-center justify-center rounded-full bg-black/5 opacity-0 transition-opacity group-hover:opacity-100 hover:bg-black/10",
                    onClick: D => {
                        D.stopPropagation(), y()
                    },
                    type: "button",
                    children: s.jsx(_a, {
                        className: "icon icon-sm"
                    })
                }), m && s.jsx(mn, {
                    maxHeight: 128,
                    renderExtent: "preview",
                    surface: "tooltip",
                    children: s.jsx(Ol, {
                        message: m,
                        conversation: t,
                        isFeedbackEnabled: !1,
                        isCompletionInProgress: o,
                        hasActiveRequest: o,
                        isUserTurn: !1,
                        isFinalUserTurn: !1,
                        turnIndex: 0
                    })
                })]
            })
        }), e[27] = t, e[28] = T, e[29] = S, e[30] = u, e[31] = o, e[32] = x, e[33] = m, e[34] = y, e[35] = i, e[36] = w) : w = e[36], w
    };

function pc(a) {
    return [Pn(a), wt.getRequestId(a)]
}
const Vs = {
        duration: .4,
        type: "spring",
        bounce: .1
    },
    gc = 50,
    Ho = .5,
    qs = ms["fullscreen-widget-composer-transition"],
    fc = ms["fullscreen-popover-thread-opening-transition"],
    Wo = ms["fullscreen-popover-thread-closing-transition"],
    Sc = a => {
        "use forget";
        const e = Pe.c(75),
            {
                clientThreadId: t,
                onRequestCompletion: i,
                composerController: h
            } = a,
            r = ot();
        let u;
        e[0] !== t || e[1] !== r ? (u = wa(r, t), e[0] = t, e[1] = r, e[2] = u) : u = e[2];
        const c = u,
            f = v.useRef(null),
            [m, n] = v.useState(!1),
            [o, d] = v.useState(!1);
        let x;
        e[3] !== r ? (x = () => Ki(r).height, e[3] = r, e[4] = x) : x = e[4];
        const p = O(x);
        let g;
        e[5] !== c ? (g = () => As(c).height$(), e[5] = c, e[6] = g) : g = e[6];
        const S = O(g);
        let l;
        e[7] !== c ? (l = () => As(c).marginBottom$(), e[7] = c, e[8] = l) : l = e[8];
        const y = O(l);
        let I;
        e[9] !== c ? (I = Ns(c), e[9] = c, e[10] = I) : I = e[10];
        const T = I;
        let M;
        e[11] !== T ? (M = () => T.pinnedWidgetType$(), e[11] = T, e[12] = M) : M = e[12];
        const A = O(M);
        let b;
        e[13] !== T ? (b = () => T.showLoadingBar$(), e[13] = T, e[14] = b) : b = e[14];
        const k = O(b),
            j = p * Ho,
            P = p - gc - (y != null ? y : 0),
            C = Mo(0),
            w = Mo(Ho);
        let D;
        e[15] !== C || e[16] !== w ? (D = [w, C], e[15] = C, e[16] = w, e[17] = D) : D = e[17];
        let J;
        e[18] !== P || e[19] !== j || e[20] !== p ? (J = be => {
            const [$, ke] = be;
            return Math.min(Math.max($ * p - ke, j), P)
        }, e[18] = P, e[19] = j, e[20] = p, e[21] = J) : J = e[21];
        const q = Ao(D, J),
            ne = Vi(c.id);
        let E;
        e[22] !== T.showLoadingBar$ ? (E = () => Ma(Aa, {
            requestCompletion: () => {
                Ft({
                    forceFlushSync: !0,
                    className: [qs, Wo],
                    update: () => {
                        n(!1), T.showLoadingBar$.set(!0)
                    }
                })
            },
            completionFinished: () => {
                Ft({
                    forceFlushSync: !0,
                    className: qs,
                    update: () => {
                        T.showLoadingBar$.set(!1)
                    }
                })
            }
        }), e[22] = T.showLoadingBar$, e[23] = E) : E = e[23];
        let L;
        e[24] !== T ? (L = [T], e[24] = T, e[25] = L) : L = e[25], v.useEffect(E, L);
        let re;
        e[26] !== h ? (re = () => {
            Ft({
                forceFlushSync: !0,
                className: fc,
                update: () => n(!0)
            });
            try {
                Ts(h).focus()
            } catch (be) {
                requestAnimationFrame(() => {
                    var $;
                    ($ = f.current) == null || $.focus()
                })
            }
        }, e[26] = h, e[27] = re) : re = e[27];
        const _ = re;
        let N;
        e[28] !== h || e[29] !== m ? (N = () => !m && (Ia() && Vo(h) || Pa(h)), e[28] = h, e[29] = m, e[30] = N) : N = e[30];
        const K = O(N);
        let Z;
        e[31] !== P || e[32] !== j ? (Z = [j, P], e[31] = P, e[32] = j, e[33] = Z) : Z = e[33];
        let de;
        e[34] === Symbol.for("react.memo_cache_sentinel") ? (de = [0, 1], e[34] = de) : de = e[34];
        const pe = Ao(q, Z, de);
        let Y;
        e[35] === Symbol.for("react.memo_cache_sentinel") ? (Y = s.jsx(Qi, {}, "blur"), e[35] = Y) : Y = e[35];
        let ye;
        e[36] !== t || e[37] !== y || e[38] !== _ || e[39] !== A || e[40] !== k ? (ye = k && s.jsx(Ji, {
            clientThreadId: t,
            bottom: y != null ? y : 0,
            onClick: _,
            pinnedWidgetType: A
        }, "loading-bar"), e[36] = t, e[37] = y, e[38] = _, e[39] = A, e[40] = k, e[41] = ye) : ye = e[41];
        let Q;
        e[42] !== pe || e[43] !== m ? (Q = m && s.jsx(ws.div, {
            initial: {
                opacity: 0
            },
            animate: {
                opacity: pe.get()
            },
            style: {
                opacity: pe
            },
            exit: {
                opacity: 0
            },
            className: "bg-token-bg-primary/50 pointer-events-auto fixed inset-0 top-(--header-height) opacity-0 backdrop-blur-xs",
            onClick: () => {
                Ft({
                    forceFlushSync: !0,
                    className: Wo,
                    update: () => {
                        d(!0), n(!1)
                    }
                }).finished.then(() => {
                    d(!1)
                })
            }
        }, "drag-overlay"), e[42] = pe, e[43] = m, e[44] = Q) : Q = e[44];
        let U;
        e[45] !== c || e[46] !== _ || e[47] !== m || e[48] !== T.showLoadingBar$ ? (U = !m && s.jsx(hc, {
            zIndex: 1,
            conversation: c,
            onClick: _,
            onReveal: () => {
                Ft({
                    forceFlushSync: !0,
                    className: qs,
                    update: () => {
                        T.showLoadingBar$.set(!1)
                    }
                })
            }
        }, "last-message-banner"), e[45] = c, e[46] = _, e[47] = m, e[48] = T.showLoadingBar$, e[49] = U) : U = e[49];
        let ae;
        e[50] !== Q || e[51] !== U ? (ae = s.jsxs(Ko, {
            children: [Q, U]
        }), e[50] = Q, e[51] = U, e[52] = ae) : ae = e[52];
        let ee;
        e[53] !== _ || e[54] !== m || e[55] !== K ? (ee = !m && s.jsx(os, {
            className: We("pointer-events-auto absolute start-0 end-0 top-0 z-[100] flex -translate-y-full justify-center pb-2 opacity-0 transition-opacity hover:opacity-100", K && "opacity-100"),
            children: s.jsx("button", {
                onClick: _,
                className: "text-token-text-secondary border-token-border-default bg-token-bg-primary/50 relative z-30 flex h-6 w-6 cursor-pointer items-center justify-center rounded-full border bg-clip-padding backdrop-blur-md after:absolute after:-inset-2 after:content-['']",
                children: s.jsx(qi, {
                    className: "icon-sm text-token-text-primary"
                })
            })
        }, "open-button"), e[53] = _, e[54] = m, e[55] = K, e[56] = ee) : ee = e[56];
        let le;
        e[57] !== q || e[58] !== S || e[59] !== c || e[60] !== C || e[61] !== ne || e[62] !== o || e[63] !== m || e[64] !== P || e[65] !== j || e[66] !== i || e[67] !== w || e[68] !== p ? (le = (m || o) && s.jsx("div", {
            tabIndex: -1,
            ref: f,
            className: We(o ? "invisible" : "[view-transition-name:fullscreen-popover-thread]", "pointer-events-none absolute inset-x-0 bottom-0 mx-auto flex items-center justify-center rounded-3xl focus:ring-0 focus:outline-hidden focus-visible:ring-0 focus-visible:outline-hidden md:bottom-6"),
            role: "dialog",
            "aria-modal": "true",
            onClick: bc,
            children: s.jsx(os, {
                children: s.jsxs("div", {
                    className: "relative overflow-visible",
                    children: [s.jsx(xc, {
                        onDoubleClick: () => {
                            $s(w, (q.get() === P ? j : P) / p, Vs)
                        },
                        onDragStart: () => C.set(0),
                        onDragEnd: be => {
                            const {
                                velocity: $
                            } = be, {
                                y: ke
                            } = $, Ce = yc(-ke, j, P, q.get());
                            $s(w, (Ce === P ? P : j) / p, Vs), $s(C, 0, Vs)
                        },
                        onDrag: be => {
                            const {
                                delta: $
                            } = be, {
                                y: ke
                            } = $;
                            return C.set(C.get() + ke)
                        }
                    }), s.jsx("div", {
                        className: "bg-token-bg-primary shadow-long pointer-events-auto mx-0 flex overflow-hidden rounded-t-3xl backdrop-blur-2xl md:-mx-2! md:rounded-[34px]",
                        children: s.jsx(ws.div, {
                            className: "relative flex w-full flex-col-reverse overflow-y-auto",
                            style: {
                                height: q,
                                paddingBottom: S != null ? S : 0,
                                WebkitMaskImage: "linear-gradient(to bottom, black 0, black calc(100% - 64px), transparent calc(100% - 40px), transparent 100%)",
                                maskImage: "linear-gradient(to bottom, black 0, black calc(100% - 64px), transparent calc(100% - 40px), transparent 100%)"
                            },
                            children: s.jsx("div", {
                                onCopy: ne,
                                className: "flex flex-col px-7 text-sm",
                                children: s.jsx(Yi, {
                                    children: s.jsx(mn, {
                                        surface: "popover",
                                        children: s.jsx(Ll, {
                                            conversation: c,
                                            onRequestCompletion: i,
                                            disableScrollToMessage: !0,
                                            hideUserActions: !0,
                                            disableHorizontalPadding: !0
                                        })
                                    })
                                })
                            })
                        })
                    })]
                })
            })
        }, "popover-thread"), e[57] = q, e[58] = S, e[59] = c, e[60] = C, e[61] = ne, e[62] = o, e[63] = m, e[64] = P, e[65] = j, e[66] = i, e[67] = w, e[68] = p, e[69] = le) : le = e[69];
        let G;
        return e[70] !== ye || e[71] !== ae || e[72] !== ee || e[73] !== le ? (G = s.jsxs(s.Fragment, {
            children: [Y, ye, ae, ee, le]
        }), e[70] = ye, e[71] = ae, e[72] = ee, e[73] = le, e[74] = G) : G = e[74], G
    },
    xc = a => {
        "use forget";
        const e = Pe.c(17),
            {
                onDrag: t,
                onDragEnd: i,
                onDoubleClick: h,
                onDragStart: r,
                onPointerUp: u
            } = a;
        let c, f, m, n;
        e[0] === Symbol.for("react.memo_cache_sentinel") ? (c = {
            opacity: 1
        }, f = {
            opacity: 1
        }, m = {
            type: "tween",
            duration: .1
        }, n = {
            x: 0,
            y: 0,
            transform: "translateY(0px)"
        }, e[0] = c, e[1] = f, e[2] = m, e[3] = n) : (c = e[0], f = e[1], m = e[2], n = e[3]);
        let o;
        e[4] !== r ? (o = () => {
            r == null || r()
        }, e[4] = r, e[5] = o) : o = e[5];
        let d;
        e[6] === Symbol.for("react.memo_cache_sentinel") ? (d = {
            left: 0,
            right: 0,
            top: 0,
            bottom: 0
        }, e[6] = d) : d = e[6];
        let x;
        e[7] !== t ? (x = (S, l) => {
            t == null || t(l)
        }, e[7] = t, e[8] = x) : x = e[8];
        let p;
        e[9] !== i ? (p = (S, l) => i == null ? void 0 : i(l), e[9] = i, e[10] = p) : p = e[10];
        let g;
        return e[11] !== h || e[12] !== u || e[13] !== o || e[14] !== x || e[15] !== p ? (g = s.jsx(ws.div, {
            drag: "y",
            tabIndex: -1,
            className: "bg-token-border-default pointer-events-auto absolute start-10 end-10 top-0 z-10 h-[4px] cursor-ns-resize rounded-b-full opacity-0 after:absolute after:inset-0 after:top-[-18px] after:h-[28px] after:bg-transparent after:content-['']",
            whileHover: c,
            whileDrag: f,
            transition: m,
            style: n,
            onPointerDown: o,
            dragMomentum: !1,
            dragSnapToOrigin: !1,
            dragElastic: !1,
            dragConstraints: d,
            onDrag: x,
            onPointerUp: u,
            onDragEnd: p,
            onDoubleClick: h
        }), e[11] = h, e[12] = u, e[13] = o, e[14] = x, e[15] = p, e[16] = g) : g = e[16], g
    };

function yc(a, e, t, i) {
    if (!(e <= t)) throw new Error("min must be <= max");
    const h = .25,
        r = 8,
        u = 24,
        c = 1200,
        f = Math.abs(i - e) <= Math.abs(i - t) ? e : t,
        m = i + a * h,
        n = Math.abs(m - e) <= Math.abs(m - t) ? e : t;
    if (n === f) return f;
    const o = (f + n) / 2,
        d = Math.sign(n - f) || 1,
        x = o + d * r;
    if (!(d > 0 ? m >= x : m <= x)) return f;
    const g = Math.abs(a),
        S = Math.min(g / c, 1),
        l = u * (1 - S * S);
    return Math.abs(m - f) - Math.abs(m - n) < l ? f : n
}

function bc(a) {
    return a.stopPropagation()
}
const Cc = Es(() => Ps(() =>
        import ("./ey3f7egvimr39bq4.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5])).then(a => a.AgentConnectorsSafetyModal)),
    vc = a => {
        "use forget";
        const e = Pe.c(139),
            {
                conversation: t,
                isNewThread: i,
                isGizmoThread: h,
                isProjectThread: r,
                currentModelId: u,
                onRequestCompletion: c,
                shouldUseUnifiedComposer: f,
                onlyAllowImageUploads: m,
                isWidgetFullScreen: n,
                layoutMode: o,
                shouldShowDeepResearchDesktopContent: d,
                pulseOnboardingEntrypoint: x,
                cocoonEntrypointResponse: p
            } = a,
            g = n === void 0 ? !1 : n,
            S = d === void 0 ? !1 : d,
            l = ot();
        let y;
        e[0] !== l ? (y = () => Oo(l), e[0] = l, e[1] = y) : y = e[1];
        const I = O(y),
            {
                height$: T
            } = As(t),
            M = Io(ls),
            A = ds(),
            b = $o().pathname,
            k = b != null ? b : void 0;
        let j;
        e[2] !== k ? (j = ja(k), e[2] = k, e[3] = j) : j = e[3];
        const P = j,
            C = hn(t.id).isOdysseyMode,
            w = Qo(),
            D = ro(),
            J = Ea(),
            q = ns();
        let ne;
        e[4] !== l ? (ne = lo(l), e[4] = l, e[5] = ne) : ne = e[5];
        const E = ne;
        Xi(A);
        const L = Io(ls);
        let re;
        e[6] !== l ? (re = ka(l), e[6] = l, e[7] = re) : re = e[7];
        const _ = re,
            N = O(Po.sidebarUrlTrayOpen$),
            K = O(Po.context$),
            Z = js();
        let de;
        e[8] !== l || e[9] !== u ? (de = u != null && Na({
            id: u
        }, l), e[8] = l, e[9] = u, e[10] = de) : de = e[10];
        const pe = de,
            Y = L && _ && N,
            ye = go();
        let Q;
        e[11] !== l ? (Q = ut(l, "1925940714"), e[11] = l, e[12] = Q) : Q = e[12];
        const U = Q;
        let ae;
        e[13] !== l ? (ae = () => {
            if (Oo(l) === !0) return cs(l).selectedTaskReplyId$()
        }, e[13] = l, e[14] = ae) : ae = e[14];
        const ee = O(ae),
            {
                platformConnectors: le
            } = Ra(),
            G = Zi(Fo.hasSeenOdysseyConnectorsModal),
            be = ss(t.id, Mc);
        let $;
        e[15] !== t ? ($ = () => Ha(t), e[15] = t, e[16] = $) : $ = e[16];
        const ke = O($),
            Ce = co(),
            Ne = uo();
        let ze;
        e[17] !== t ? (ze = () => Ns(t).showLoadingBar$(), e[17] = t, e[18] = ze) : ze = e[18];
        const ue = O(ze);
        let ge;
        e[19] !== l || e[20] !== be || e[21] !== ke || e[22] !== Ne || e[23] !== Ce || e[24] !== g || e[25] !== ue ? (ge = (Ce || Ne) && be || g && ue || !jt() && ke, e[19] = l, e[20] = be, e[21] = ke, e[22] = Ne, e[23] = Ce, e[24] = g, e[25] = ue, e[26] = ge) : ge = e[26];
        const fe = ge;
        let De;
        e[27] !== Z || e[28] !== t.id || e[29] !== K || e[30] !== Y ? (De = async () => {
            if (!Y) return;
            const se = Z ? [Z] : [];
            if (se.includes(kt.Agent)) return;
            const ce = typeof performance < "u" ? Ac : Ic,
                me = ce();
            try {
                const oe = await Wa(K, mr, se, t.id),
                    X = Math.round(ce() - me);
                if (oe != null) {
                    let Le = 1;
                    Array.isArray(oe) && (Le = oe.length), is.logEventWithStatsig("kaur1br5: Sidebar context collected", "chatgpt_sidebar_context_collected", {
                        duration_ms: X,
                        count: Le
                    })
                } else is.logEventWithStatsig("kaur1br5: Sidebar context collection failure", "chatgpt_sidebar_context_collection_failure", {
                    duration_ms: X,
                    failure_reason: "null"
                });
                return oe
            } catch (oe) {
                const X = oe,
                    Le = Math.round(ce() - me),
                    mt = X instanceof Ya;
                is.logEventWithStatsig("kaur1br5: Sidebar context collection failure", "chatgpt_sidebar_context_collection_failure", Ie({
                    duration_ms: Le,
                    failure_reason: mt ? "timeout" : "error"
                }, X instanceof Error ? {
                    error_message: X.message
                } : X ? {
                    error_message: String(X)
                } : {}));
                return
            }
        }, e[27] = Z, e[28] = t.id, e[29] = K, e[30] = Y, e[31] = De) : De = e[31];
        let Ve;
        e[32] !== U || e[33] !== Y ? (Ve = () => Y || !U.get("completion_request_blocking_promise_optimization", !1), e[32] = U, e[33] = Y, e[34] = Ve) : Ve = e[34], er(De, Ve);
        const qe = Fa();
        let Se;
        if (e[35] !== (E == null ? void 0 : E.authUserId) || e[36] !== (E == null ? void 0 : E.id) || e[37] !== Z || e[38] !== G || e[39] !== _ || e[40] !== t.id || e[41] !== l || e[42] !== K || e[43] !== pe || e[44] !== q || e[45] !== L || e[46] !== qe || e[47] !== C || e[48] !== c || e[49] !== N || e[50] !== le || e[51] !== Y || e[52] !== J) {
            Se = async me => {
                var bt, dt, Mt, At, Ct, ht, pt, gt;
                if (((bt = Da(t.id)) == null ? void 0 : bt.isLoading) !== !1) return;
                const oe = new Set(me.systemHints);
                pe && oe.add(kt.Glaux);
                const X = await hr(St(Ie({}, me), {
                        systemHints: [...oe]
                    })),
                    Le = ce((Mt = (dt = X.promptMessage.metadata) == null ? void 0 : dt.attachments) != null ? Mt : []);
                if (qe && Le) {
                    const {
                        promptMessage: Xe,
                        parentMessageId: Ee
                    } = X;
                    return pr.debug("Relaying message to voice participant"), gr({
                        type: "RELAY",
                        message: Xe,
                        parentMessageId: Ee
                    })
                }
                const mt = (Ct = (At = X.completionMetadata) == null ? void 0 : At.systemHints) == null ? void 0 : Ct.includes(Js),
                    ct = Array.from((ht = me.selectedSources) != null ? ht : []).filter(Pc)[0];
                if (mt && ct && G.eligible) {
                    const Xe = (pt = $a[ct]) != null ? pt : ct,
                        Ee = le.get(Xe);
                    if (Ee) {
                        _s(l, Cc, {
                            connector: Ee,
                            onConfirm: () => {
                                fr(l, Fo.hasSeenOdysseyConnectorsModal), c(X)
                            },
                            onTurnOffConnectors: () => {
                                Ba(t.id, Te => {
                                    Te.selectedSources == null && (Te.selectedSources = new Map), Te.selectedSources.set(Z, new Set(["web"])), Te.selectedMCPSources == null && (Te.selectedMCPSources = new Map), Te.selectedMCPSources.set(Z, new Set), Te.mentionedSources = new Set, Ga({
                                        selectedSourcesMap: Te.selectedSources,
                                        selectedMCPSourcesMap: Te.selectedMCPSources,
                                        scope: {
                                            userId: E == null ? void 0 : E.authUserId,
                                            workspaceId: E == null ? void 0 : E.id
                                        }
                                    })
                                })
                            }
                        });
                        return
                    }
                }
                if (L) {
                    const Xe = !!K,
                        Ee = N === !0;
                    _ && (!Xe || !Ee) && Ua.error("Missing context chip on message send", {
                        clientThreadId: t.id,
                        hasSidebarContext: Xe,
                        isContextChipOpen: Ee,
                        contextEnabled: _,
                        isBridgedDesktopSidebar: L,
                        shouldCollectSidebarContext: Y
                    }), (gt = za()) == null || gt.triggerProductEvent("messageSent")
                }
                Le && c(X)
            };
            let se;
            e[54] !== l || e[55] !== q || e[56] !== C || e[57] !== J ? (se = me => {
                let oe = qa;
                const X = me.reduce(jc, 0);
                C && (oe = Va(l, "1504865540").get("max_file_size_mb", 25));
                const Le = X <= oe * 1024 * 1024;
                return Le || J.danger(q.formatMessage({
                    id: "odyssey.fileTooLarge",
                    defaultMessage: "The attached files are too large. The maximum size is {maxFileSizeMB}MB."
                }, {
                    maxFileSizeMB: oe
                })), Le
            }, e[54] = l, e[55] = q, e[56] = C, e[57] = J, e[58] = se) : se = e[58];
            const ce = se;
            e[35] = E == null ? void 0 : E.authUserId, e[36] = E == null ? void 0 : E.id, e[37] = Z, e[38] = G, e[39] = _, e[40] = t.id, e[41] = l, e[42] = K, e[43] = pe, e[44] = q, e[45] = L, e[46] = qe, e[47] = C, e[48] = c, e[49] = N, e[50] = le, e[51] = Y, e[52] = J, e[53] = Se
        } else Se = e[53];
        let $e;
        e[59] !== c ? ($e = se => {
            is.logEvent("Continue Completion"), c(Sr(se))
        }, e[59] = c, e[60] = $e) : $e = e[60];
        const ie = $e,
            Ye = tr.useState(Ec);
        let H;
        e[61] !== t.id ? (H = {
            clientThreadId: t.id
        }, e[61] = t.id, e[62] = H) : H = e[62];
        const B = Oa(H);
        let F;
        e[63] !== t.id ? (F = {
            clientThreadId: t.id
        }, e[63] = t.id, e[64] = F) : F = e[64];
        const R = La(F),
            xe = fo();
        let _e;
        e[65] !== l || e[66] !== xe || e[67] !== i ? (_e = () => Is(l) && xe.visible$() && !Ms() && i, e[65] = l, e[66] = xe, e[67] = i, e[68] = _e) : _e = e[68];
        const Ze = O(_e),
            Re = O(kc);
        if (B) {
            let se;
            return e[69] !== R ? (se = s.jsx(xr, {
                safetyLimited: R
            }), e[69] = R, e[70] = se) : se = e[70], se
        }
        const W = i && !h,
            Fe = S ? "70px" : void 0;
        let Qe;
        e[71] !== Fe ? (Qe = {
            "--deep-research-composer-extra-height": Fe
        }, e[71] = Fe, e[72] = Qe) : Qe = e[72];
        const yt = Qe;
        let we;
        e[73] !== t.id ? (we = s.jsx(sr, {
            clientThreadId: t.id
        }), e[73] = t.id, e[74] = we) : we = e[74];
        const nt = eo,
            et = to({
                axis: "height",
                onChange: se => {
                    const {
                        height: ce
                    } = se;
                    return T.set(ce)
                }
            }),
            Me = w ? "last-standard" : "none",
            Ae = L ? "none" : "standard";
        let Ke;
        e[75] !== A || e[76] !== t.id || e[77] !== g || e[78] !== c ? (Ke = g && s.jsx(Sc, {
            clientThreadId: t.id,
            composerController: A,
            onRequestCompletion: c
        }), e[75] = A, e[76] = t.id, e[77] = g, e[78] = c, e[79] = Ke) : Ke = e[79];
        const tt = M ? "w-full max-w-full" : "mb-4";
        let Oe;
        e[80] !== tt ? (Oe = We(tt), e[80] = tt, e[81] = Oe) : Oe = e[81];
        let Je;
        e[82] !== I || e[83] !== ee ? (Je = I && s.jsx(Ko, {
            mode: "popLayout",
            children: ee && s.jsx(yr, {
                taskId: ee
            }, ee)
        }), e[82] = I, e[83] = ee, e[84] = Je) : Je = e[84];
        let ve;
        e[85] !== Re ? (ve = Re && s.jsx(ks, {
            children: s.jsx("div", {
                className: "mb-4 sm:hidden",
                children: s.jsx(yn, {})
            })
        }), e[85] = Re, e[86] = ve) : ve = e[86];
        let Be;
        e[87] !== p || e[88] !== t || e[89] !== u || e[90] !== ie || e[91] !== Se || e[92] !== i || e[93] !== r || e[94] !== Ye || e[95] !== o || e[96] !== m || e[97] !== x || e[98] !== fe || e[99] !== W ? (Be = Ye ? s.jsx(or, {
            clientThreadId: t.id
        }, t.id) : fe ? s.jsx("div", {
            className: "pointer-events-none h-14"
        }) : s.jsx(Il, {
            conversation: t,
            currentModelId: u,
            isNewThread: i,
            isProjectThread: r,
            hideHeader: W,
            onRequestCompletion: Se,
            onContinueGenerating: ie,
            onlyAllowImageUploads: m,
            layoutMode: o,
            pulseOnboardingEntrypoint: x,
            cocoonEntrypointResponse: p
        }), e[87] = p, e[88] = t, e[89] = u, e[90] = ie, e[91] = Se, e[92] = i, e[93] = r, e[94] = Ye, e[95] = o, e[96] = m, e[97] = x, e[98] = fe, e[99] = W, e[100] = Be) : Be = e[100];
        let at;
        e[101] !== yt || e[102] !== Oe || e[103] !== Je || e[104] !== ve || e[105] !== Be ? (at = s.jsxs(os, {
            className: Oe,
            style: yt,
            children: [Je, ve, Be]
        }), e[101] = yt, e[102] = Oe, e[103] = Je, e[104] = ve, e[105] = Be, e[106] = at) : at = e[106];
        let Ge;
        e[107] !== nt || e[108] !== et || e[109] !== Me || e[110] !== Ae || e[111] !== Ke || e[112] !== at ? (Ge = s.jsxs(nt, {
            ref: et,
            verticalMargin: "none",
            verticalPadding: Me,
            horizontalPadding: Ae,
            children: [Ke, at]
        }), e[107] = nt, e[108] = et, e[109] = Me, e[110] = Ae, e[111] = Ke, e[112] = at, e[113] = Ge) : Ge = e[113];
        let je;
        e[114] !== we || e[115] !== Ge ? (je = s.jsxs(s.Fragment, {
            children: [we, Ge]
        }), e[114] = we, e[115] = Ge, e[116] = je) : je = e[116];
        const it = je;
        let rt;
        e[117] !== t || e[118] !== M || e[119] !== W || e[120] !== Ze ? (rt = W && s.jsx("div", {
            className: We("[display:var(--display-hidden-until-loaded,block)] md:absolute md:start-0 md:bottom-8 md:w-full"),
            children: s.jsx(eo, {
                verticalMargin: "none",
                verticalPadding: "none",
                horizontalPadding: "standard",
                children: s.jsx(os, {
                    className: We(M && "w-full max-w-full"),
                    children: s.jsx(Pl, {
                        className: "block flex-1",
                        suggestedContent: Ze ? s.jsx(In, {
                            conversation: t
                        }) : void 0
                    })
                })
            })
        }), e[117] = t, e[118] = M, e[119] = W, e[120] = Ze, e[121] = rt) : rt = e[121];
        const lt = rt;
        if (f) {
            const se = !D && lt;
            let ce;
            e[122] !== it ? (ce = s.jsx("div", {
                id: "thread-bottom",
                children: it
            }), e[122] = it, e[123] = ce) : ce = e[123];
            let me;
            e[124] !== t || e[125] !== u || e[126] !== ye || e[127] !== h || e[128] !== i || e[129] !== C || e[130] !== P || e[131] !== r || e[132] !== S ? (me = i && !h && !P && !C && !ye && !r && !S && s.jsx(Tc, {
                conversation: t,
                clientThreadId: t.id,
                currentModelId: u
            }), e[124] = t, e[125] = u, e[126] = ye, e[127] = h, e[128] = i, e[129] = C, e[130] = P, e[131] = r, e[132] = S, e[133] = me) : me = e[133];
            const oe = D && lt;
            let X;
            return e[134] !== se || e[135] !== ce || e[136] !== me || e[137] !== oe ? (X = s.jsxs(s.Fragment, {
                children: [se, ce, me, oe]
            }), e[134] = se, e[135] = ce, e[136] = me, e[137] = oe, e[138] = X) : X = e[138], X
        }
        return it
    },
    Tc = ({
        clientThreadId: a,
        currentModelId: e,
        conversation: t
    }) => {
        const i = ot(),
            h = ds(),
            r = fo(),
            u = O(() => Is(i) && r.visible$() && Ms()),
            c = O(() => ho(h).shouldShowAutocomplete$() && !r.visible$()),
            f = gn(),
            m = dn({
                shouldBeEnabledForDefaultAssistant: !0,
                clientThreadId: a
            }),
            n = jl();
        v.useEffect(() => {
            Is(i) && un.prefetch()
        }, [i]);
        const {
            shouldShow: o
        } = El({
            clientThreadId: a,
            canShowBanner: !1
        }), {
            shouldShow: d
        } = nr({
            canShowBanner: !o
        }), x = O(() => !o && !d && pn()), p = xt(i, "4087025484"), g = O(() => {
            if (mo(i) || !fn(i)) return;
            const {
                data: l
            } = Sn(i, {
                useCache: !p
            });
            if (l && l.is_fresh) return p && l.onboarding_status !== xn.FINISHED_WITH_FEED ? void 0 : l
        }), S = ao();
        return s.jsxs("div", {
            className: We(c && "hidden"),
            children: [s.jsx(eo, {
                verticalMargin: "none",
                verticalPadding: "none",
                horizontalPadding: "standard",
                children: s.jsxs(os, {
                    children: [!f && s.jsxs(s.Fragment, {
                        children: [s.jsx(ar, {
                            clientThreadId: a
                        }), g && s.jsx(ir, {
                            pulseId: g.id,
                            caption: g.caption,
                            previewImages: g.preview_items.map(l => rr(l.image_url)),
                            onClick: () => S("/pulse")
                        })]
                    }), u && s.jsx(In, {
                        conversation: t
                    }), m === "tiles" || m === "hscroll" ? e && a ? s.jsx(wn, {
                        className: "mt-[24.5px] max-sm:hidden",
                        layout: "carousel",
                        clientThreadId: a,
                        currentModelId: e
                    }) : null : m === "image_gen_banner" && n ? s.jsx("div", {
                        className: "mt-16 flex justify-center max-sm:hidden",
                        children: s.jsx(kl, {})
                    }) : m === "chips" ? e && s.jsx(Nl, {
                        clientThreadId: a,
                        currentModelId: e
                    }) : null, o && s.jsx("div", {
                        className: "hidden justify-center pt-8 sm:flex",
                        children: s.jsx(Rl, {})
                    }), !o && d && s.jsx("div", {
                        className: "hidden justify-center pt-8 sm:flex",
                        children: s.jsx(lr, {})
                    }), x && s.jsx(ks, {
                        children: s.jsx("div", {
                            className: "hidden sm:block",
                            children: s.jsx(yn, {})
                        })
                    })]
                })
            }), f && s.jsxs("div", {
                className: "@w-sm/main:flex mt-5 hidden flex-col gap-2",
                children: [s.jsx(cr, {}), s.jsx(dr, {}), s.jsx(ur, {})]
            })]
        })
    };

function _c(a) {
    var e;
    return (e = a.metadata) == null ? void 0 : e.n7jupd_message
}

function wc(a) {
    return a.messages.some(_c)
}

function Mc(a) {
    return wt.getConversationTurns(a).some(wc)
}

function Ac() {
    return performance.now()
}

function Ic() {
    return Date.now()
}

function Pc(a) {
    return a !== "web"
}

function jc(a, e) {
    var t;
    return a + ((t = e.size) != null ? t : 0)
}

function Ec(a) {
    return a.isReplayEnabled
}

function kc() {
    return pn()
}

function Nc(a) {
    "use forget";
    var It, Lt, Ht, Pt;
    const e = Pe.c(171),
        {
            conversation: t,
            withCustomCompletionParams: i,
            hideDisclaimer: h,
            renderEmptyState: r,
            renderEmptyFooter: u,
            scrollContainerRef: c,
            isScrolledFromBottom$: f,
            footerRootContainerElementRef: m,
            onDeepResearchLandingPageContentHeightChange: n
        } = a,
        o = ot(),
        d = Wn(),
        x = bn(o),
        p = go(),
        g = ro(),
        S = Jo(),
        l = Cn(t.id);
    let y;
    e[0] !== S ? (y = z => [wt.hasUserMessage(z), wt.getConversationTurns(z).length, wt.isArchived(z), z ? wt.getGizmoId(z) : S], e[0] = S, e[1] = y) : y = e[1];
    const [I, T, M, A] = ss(t.id, y), b = v.use(Mn);
    let k;
    e[2] !== o ? (k = () => {
        var z;
        return oo(o) && cs(o).isFeedbackViewOpen$() && ((z = cs(o).feedbackViewState$()) == null ? void 0 : z.type) !== Tn.Conversation
    }, e[2] = o, e[3] = k) : k = e[3];
    const j = O(k),
        P = T >= 2;
    let C;
    e[4] !== o ? (C = Xo(o), e[4] = o, e[5] = C) : C = e[5];
    const w = C;
    let D;
    e[6] !== o ? (D = () => ls(o), e[6] = o, e[7] = D) : D = e[7];
    const J = O(D),
        q = co(),
        ne = uo(),
        {
            isOpen: E
        } = vn(),
        L = !!A;
    let re;
    e[8] !== t.id || e[9] !== P || e[10] !== l || e[11] !== ne || e[12] !== w || e[13] !== L || e[14] !== q || e[15] !== b ? (re = Xs(t.id) && !P && (so(l) || (l == null ? void 0 : l.kind) === Zo.GizmoTest) && !q && !ne && b == null && (!w || L), e[8] = t.id, e[9] = P, e[10] = l, e[11] = ne, e[12] = w, e[13] = L, e[14] = q, e[15] = b, e[16] = re) : re = e[16];
    const _ = re;
    let N;
    e[17] !== _ || e[18] !== ((It = d == null ? void 0 : d.homepageCmsPageData) == null ? void 0 : It.sections) || e[19] !== (d == null ? void 0 : d.homepageFooterNavData) ? (N = () => {
        var Ue;
        if (!((Ue = d == null ? void 0 : d.homepageCmsPageData) != null && Ue.sections) && !(d != null && d.homepageFooterNavData)) return;
        const z = document.querySelector("main");
        !_ && z && z.classList.add("no-scrollbar")
    }, e[17] = _, e[18] = (Lt = d == null ? void 0 : d.homepageCmsPageData) == null ? void 0 : Lt.sections, e[19] = d == null ? void 0 : d.homepageFooterNavData, e[20] = N) : N = e[20];
    const K = (Ht = d == null ? void 0 : d.homepageCmsPageData) == null ? void 0 : Ht.sections,
        Z = d == null ? void 0 : d.homepageFooterNavData;
    let de;
    e[21] !== _ || e[22] !== K || e[23] !== Z ? (de = [_, K, Z], e[21] = _, e[22] = K, e[23] = Z, e[24] = de) : de = e[24], v.useEffect(N, de);
    const pe = _ && !I && b == null && (!w || L || p);
    let Y;
    e[25] !== t ? (Y = () => on(t), e[25] = t, e[26] = Y) : Y = e[26];
    const Q = O(Y).id;
    let U;
    e[27] !== t || e[28] !== o || e[29] !== Q || e[30] !== i ? (U = z => {
        var Wt, Dt, hs;
        const Ue = Ie({
            conversation: t
        }, i ? i(z) : z);
        if ((Dt = (Wt = Ue.completionMetadata) == null ? void 0 : Wt.systemHints) != null && Dt.some(Fc) && mo(o)) {
            const ps = nn(o, (hs = Ue.requestedModelId) != null ? hs : Q);
            ps && (Ue.requestedModelId = ps)
        }
        _n(Ue)
    }, e[27] = t, e[28] = o, e[29] = Q, e[30] = i, e[31] = U) : U = e[31];
    const ae = Ot(U);
    let ee;
    e[32] !== o || e[33] !== w || e[34] !== _ || e[35] !== ae ? (ee = z => {
        _ && !an() && !w && rn(o, "3253785454").get("should_animate_composer", !1) ? Ft({
            className: ms["composer-slide"],
            update: () => ae(z)
        }) : ae(z)
    }, e[32] = o, e[33] = w, e[34] = _, e[35] = ae, e[36] = ee) : ee = e[36];
    const le = Ot(ee),
        G = en(o, A),
        be = pe && !r && G;
    let $;
    e[37] !== o ? ($ = Qo(), e[37] = o, e[38] = $) : $ = e[38];
    const ke = $,
        Ce = lo(o),
        Ne = ss(t.id, Rc),
        ze = G && (Ne == null ? void 0 : Ne.id) != null && Ne.id !== (Ce == null ? void 0 : Ce.normalizedAccountUserId),
        ue = Ce && !Ce.isSelfServeBusiness() && !Ce.isEnterprisey(),
        ge = !h && !ke && !J && !be && !(w && !g) && !(_ && ue) && so(l),
        fe = hn(t.id).isOdysseyMode;
    tn();
    const De = !1,
        Ve = v.useRef(null),
        qe = m != null ? m : Ve,
        Se = !G,
        $e = _;
    let ie;
    e[39] !== o ? (ie = () => ln(o), e[39] = o, e[40] = ie) : ie = e[40];
    const {
        isSingleLine: Ye
    } = O(ie), {
        file_uploads: H,
        image_uploads: B
    } = br(), F = !sn();
    let R;
    e[41] !== o ? (R = xt(o, "739972392"), e[41] = o, e[42] = R) : R = e[42];
    const xe = _ && De;
    let _e;
    e[43] !== n ? (_e = to({
        axis: "height",
        onChange: z => {
            const {
                height: Ue
            } = z;
            return n == null ? void 0 : n(Ue)
        }
    }), e[43] = n, e[44] = _e) : _e = e[44];
    const Ze = _e;
    let Re;
    e[45] !== t ? (Re = () => Rr(t), e[45] = t, e[46] = Re) : Re = e[46];
    const W = O(Re);
    let Fe;
    e[47] !== t ? (Fe = () => Ns(t).pinnedWidgetType$(), e[47] = t, e[48] = Fe) : Fe = e[48];
    const Qe = O(Fe),
        yt = W && (Qe === "deep-research" || De),
        we = _ && !L && !p && !F ? "center" : "bottom",
        nt = !_ || p;
    let et;
    e[49] !== nt ? (et = {
        skip: nt
    }, e[49] = nt, e[50] = et) : et = e[50];
    const {
        shouldShow: Me,
        isLoading: Ae
    } = Cr(et), Ke = Me && !Ae;
    let tt;
    e[51] !== o || e[52] !== w || e[53] !== p || e[54] !== L || e[55] !== Ae || e[56] !== _ || e[57] !== fe || e[58] !== E || e[59] !== F || e[60] !== W || e[61] !== Me ? (tt = jt() && _ && !p && !W && !E && !F && !L && !w && !Bs() && !Ae && !Me && !fe, e[51] = o, e[52] = w, e[53] = p, e[54] = L, e[55] = Ae, e[56] = _, e[57] = fe, e[58] = E, e[59] = F, e[60] = W, e[61] = Me, e[62] = tt) : tt = e[62];
    const Oe = tt;
    let Je;
    e[63] !== Oe || e[64] !== o ? (Je = Oe && vr(o, "is_atlas_launch_announcement_banner_migrated"), e[63] = Oe, e[64] = o, e[65] = Je) : Je = e[65];
    const ve = Je;
    let Be;
    e[66] !== o ? (Be = Tr(o), e[66] = o, e[67] = Be) : Be = e[67];
    const [at] = v.useState(Be);
    let Ge;
    e[68] !== Oe || e[69] !== ve || e[70] !== o || e[71] !== at ? (Ge = !ve && _r(o) && !wr() && !at && Oe, e[68] = Oe, e[69] = ve, e[70] = o, e[71] = at, e[72] = Ge) : Ge = e[72];
    const je = Ge;
    let it;
    e[73] !== o ? (it = xt(o, "4087025484"), e[73] = o, e[74] = it) : it = e[74];
    const rt = it;
    let lt;
    e[75] !== je || e[76] !== o || e[77] !== rt || e[78] !== w || e[79] !== p || e[80] !== L || e[81] !== Ae || e[82] !== _ || e[83] !== fe || e[84] !== E || e[85] !== F || e[86] !== W || e[87] !== Me ? (lt = () => {
        if (!rt || je || !(jt() && _ && !p && !W && !E && !F && !L && !w && !Bs() && !Ae && !Me && !fe) || !fn(o)) return;
        const {
            data: z
        } = Sn(o, {
            useCache: !rt
        });
        if ((z == null ? void 0 : z.onboarding_status) === xn.NOT_STARTED) return z
    }, e[75] = je, e[76] = o, e[77] = rt, e[78] = w, e[79] = p, e[80] = L, e[81] = Ae, e[82] = _, e[83] = fe, e[84] = E, e[85] = F, e[86] = W, e[87] = Me, e[88] = lt) : lt = e[88];
    const se = O(lt),
        ce = Ka("cocoon");
    let me;
    e[89] !== o || e[90] !== ce || e[91] !== w || e[92] !== p || e[93] !== L || e[94] !== Ae || e[95] !== _ || e[96] !== fe || e[97] !== E || e[98] !== F || e[99] !== W || e[100] !== Me ? (me = () => {
        var z, Ue;
        if (!(!jt() || !ce || !_ || p || W || E || F || L || w || Bs() || Ae || Me || fe)) return (Ue = (z = Fr(o)) == null ? void 0 : z.data) != null ? Ue : void 0
    }, e[89] = o, e[90] = ce, e[91] = w, e[92] = p, e[93] = L, e[94] = Ae, e[95] = _, e[96] = fe, e[97] = E, e[98] = F, e[99] = W, e[100] = Me, e[101] = me) : me = e[101];
    const oe = O(me);
    let X;
    e[102] !== o ? (X = Mr(o), e[102] = o, e[103] = X) : X = e[103];
    const {
        auraAnnouncementBannerState$: Le,
        setAuraAnnouncementBannerState: mt
    } = X;
    let ct;
    e[104] !== Le ? (ct = () => Le(), e[104] = Le, e[105] = ct) : ct = e[105];
    const bt = O(ct);
    let dt, Mt;
    e[106] !== ve || e[107] !== je || e[108] !== mt ? (dt = () => {
        !je && !ve && mt("not-shown")
    }, Mt = [ve, je, mt], e[106] = ve, e[107] = je, e[108] = mt, e[109] = dt, e[110] = Mt) : (dt = e[109], Mt = e[110]), v.useEffect(dt, Mt);
    const At = "thread-bottom-container",
        Ct = We("sticky bottom-0", "group/thread-bottom-container relative isolate z-10 w-full basis-auto has-data-has-thread-error:pt-2 has-data-has-thread-error:[box-shadow:var(--sharp-edge-bottom-shadow)] md:border-transparent md:pt-0 dark:border-white/20 md:dark:border-transparent print:hidden", W && "pointer-events-none", !_ && !W && "content-fade", Ye && "single-line", ze && "[--content-fade-height:110px]", ze && "[--content-fade-top:-110px]", _ && "min-h-0", pe && u && "grow", L || G || !_ ? "" : Se && _ && !p && "sm:grow", Se && "flex flex-col", W && "z-60", yt && "hidden", x);
    let ht;
    e[111] !== J || e[112] !== _ || e[113] !== j || e[114] !== f || e[115] !== W || e[116] !== c ? (ht = !_ && !J && !j && !W && s.jsx(Oc, {
        isScrolledFromBottom$: f,
        scrollContainerRef: c
    }), e[111] = J, e[112] = _, e[113] = j, e[114] = f, e[115] = W, e[116] = c, e[117] = ht) : ht = e[117];
    let pt;
    e[118] !== oe || e[119] !== we || e[120] !== t || e[121] !== o || e[122] !== Q || e[123] !== Ze || e[124] !== H || e[125] !== B || e[126] !== M || e[127] !== L || e[128] !== _ || e[129] !== E || e[130] !== G || e[131] !== g || e[132] !== W || e[133] !== le || e[134] !== se || e[135] !== xe || e[136] !== Se || e[137] !== $e ? (pt = M ? s.jsx(Ar, {
        clientThreadId: t.id
    }) : s.jsxs(s.Fragment, {
        children: [(!_ || Se) && !E && s.jsxs(s.Fragment, {
            children: [s.jsx(vc, {
                isGizmoThread: L,
                isProjectThread: G,
                conversation: t,
                isNewThread: _,
                currentModelId: Q,
                onRequestCompletion: le,
                shouldUseUnifiedComposer: Se,
                layoutMode: we,
                isWidgetFullScreen: W,
                onlyAllowImageUploads: B === "allowed" && H !== "allowed",
                shouldShowDeepResearchDesktopContent: xe,
                pulseOnboardingEntrypoint: se,
                cocoonEntrypointResponse: oe
            }), g && _ && xt(o, "537200474") && s.jsx(Ir, {
                clientThreadId: t.id
            }), !1]
        }), $e && s.jsx(ec, {
            clientThreadId: t.id,
            isGizmoThread: L,
            isNewThread: _,
            isProjectThread: G
        })]
    }), e[118] = oe, e[119] = we, e[120] = t, e[121] = o, e[122] = Q, e[123] = Ze, e[124] = H, e[125] = B, e[126] = M, e[127] = L, e[128] = _, e[129] = E, e[130] = G, e[131] = g, e[132] = W, e[133] = le, e[134] = se, e[135] = xe, e[136] = Se, e[137] = $e, e[138] = pt) : pt = e[138];
    let gt;
    e[139] !== bt || e[140] !== t || e[141] !== _ || e[142] !== ge ? (gt = ge && s.jsx("div", {
        ref: to({
            axis: "height",
            onChange: z => {
                const {
                    height: Ue
                } = z;
                return As(t).marginBottom$.set(Ue)
            }
        }),
        className: We(_ ? "mt-auto" : "-mt-4", "text-token-text-secondary relative flex min-h-8 w-full items-center justify-center p-2 text-center text-xs [view-transition-name:var(--vt-disclaimer)] md:px-[60px]", bt !== "not-shown" && "md:opacity-0"),
        children: s.jsx(Pr, {
            clientThreadId: t.id
        })
    }), e[139] = bt, e[140] = t, e[141] = _, e[142] = ge, e[143] = gt) : gt = e[143];
    const Xe = pe && u;
    let Ee;
    e[144] !== Ke ? (Ee = Ke && s.jsx(Or, {}), e[144] = Ke, e[145] = Ee) : Ee = e[145];
    let Te;
    e[146] !== ve || e[147] !== je || e[148] !== oe || e[149] !== t.id || e[150] !== ge ? (Te = oe === void 0 && s.jsxs(s.Fragment, {
        children: [je && s.jsx(jr, {
            shouldShowDisclaimer: ge,
            clientThreadId: t.id
        }), ve && s.jsx(Er, {
            shouldShowDisclaimer: ge,
            clientThreadId: t.id
        })]
    }), e[146] = ve, e[147] = je, e[148] = oe, e[149] = t.id, e[150] = ge, e[151] = Te) : Te = e[151];
    let vt;
    e[152] !== Te ? (vt = s.jsx(ks, {
        children: Te
    }), e[152] = Te, e[153] = vt) : vt = e[153];
    let Et;
    e[154] !== qe || e[155] !== Ct || e[156] !== ht || e[157] !== pt || e[158] !== gt || e[159] !== Xe || e[160] !== Ee || e[161] !== vt ? (Et = s.jsxs("div", {
        id: At,
        className: Ct,
        ref: qe,
        children: [ht, pt, gt, Xe, Ee, vt]
    }), e[154] = qe, e[155] = Ct, e[156] = ht, e[157] = pt, e[158] = gt, e[159] = Xe, e[160] = Ee, e[161] = vt, e[162] = Et) : Et = e[162];
    let Tt;
    e[163] !== d ? (Tt = ((Pt = d == null ? void 0 : d.homepageCmsPageData) == null ? void 0 : Pt.sections) && s.jsx(kr, {
        sections: d.homepageCmsPageData.sections
    }), e[163] = d, e[164] = Tt) : Tt = e[164];
    let st;
    e[165] !== d ? (st = (d == null ? void 0 : d.homepageFooterNavData) && s.jsx(Nr, {
        footer: d.homepageFooterNavData,
        disableHugeChatLogo: !0
    }), e[165] = d, e[166] = st) : st = e[166];
    let ft;
    return e[167] !== Et || e[168] !== Tt || e[169] !== st ? (ft = s.jsxs(s.Fragment, {
        children: [Et, Tt, st]
    }), e[167] = Et, e[168] = Tt, e[169] = st, e[170] = ft) : ft = e[170], ft
}

function Rc(a) {
    return a == null ? void 0 : a.sharedProjectConversationOwner
}

function Fc(a) {
    return cn(a)
}

function Oc(a) {
    "use forget";
    const e = Pe.c(5),
        {
            isScrolledFromBottom$: t,
            scrollContainerRef: i
        } = a,
        h = O(t);
    let r;
    e[0] !== i ? (r = () => {
        var c;
        Qa(us(), "chatgpt_thread_scroll_to_bottom"), (c = i.current) == null || c.scrollTo({
            behavior: "smooth",
            top: i.current.scrollHeight
        })
    }, e[0] = i, e[1] = r) : r = e[1];
    let u;
    return e[2] !== h || e[3] !== r ? (u = s.jsx("div", {
        className: "relative h-0",
        children: s.jsx(Lr, {
            show: h,
            className: "bottom-[calc(100%+6*var(--spacing))]",
            onClick: r
        })
    }), e[2] = h, e[3] = r, e[4] = u) : u = e[4], u
}
const Lc = Es(() => Ps(() =>
        import ("./v9p9lvhz45nq9ivc.js"), __vite__mapDeps([6, 1, 2, 3, 4, 5])).then(a => a.ThreadReportConversationModal)),
    Hc = Es(() => Ps(() =>
        import ("./b2m9mckkhp8ohmop.js"), __vite__mapDeps([7, 1, 2, 3, 8, 9, 4, 5, 10, 11]))),
    Wc = Es(() => Ps(() =>
        import ("./bwfoshdjwp2i6opj.js"), __vite__mapDeps([12, 1, 2, 3, 4, 5, 13, 14, 15, 16])).then(a => a.TableOfContentsSidebar));

function Dc({
    conversation: a,
    isNewScrollEnabled: e,
    pageLoadSearchQuery: t,
    footerRootContainerElementRef: i,
    threadRootRef: h,
    isScrolledFromBottom$: r,
    scrollContainerRef: u,
    children: c
}) {
    "use no forget";
    const f = ot(),
        [m] = Do(),
        n = !!m.get("message"),
        o = O(() => ls(f)),
        d = ss(a.id, p => (p == null ? void 0 : p.conversationOrigin) === oi.APPLE);
    if (e) return s.jsx(ml, {
        allowScrollToEnd: !o,
        allowScrollToTop: !o && d,
        clientThreadId: a.id,
        initScrolledToEnd: t == null && !n,
        threadFooterRef: i,
        threadRootRef: h,
        children: c
    });
    const x = s.jsxs(s.Fragment, {
        children: [s.jsx(jo, {
            className: "absolute top-0",
            setIsScrolledToEdge: p => {
                io.setIsConversationScrolledFromTop(p)
            },
            options: {
                root: u == null ? void 0 : u.current
            }
        }), c, s.jsx(jo, {
            className: "absolute bottom-0",
            setIsScrolledToEdge: p => {
                r.set(p)
            },
            options: {
                root: u == null ? void 0 : u.current
            }
        })]
    });
    return t != null ? x : s.jsx(ks, {
        children: s.jsxs(v.Suspense, {
            fallback: null,
            children: [s.jsx(hl, {}), x]
        })
    })
}
const sd = function(a) {
    "use forget";
    var So;
    const e = Pe.c(187),
        {
            conversation: t,
            withCustomCompletionParams: i,
            hideDisclaimer: h,
            renderEmptyState: r,
            renderEmptyFooter: u,
            className: c
        } = a,
        f = ns(),
        m = Ja(),
        n = ot(),
        o = bn(n),
        d = gn(),
        x = go(),
        p = Ur(n),
        g = Jo(),
        S = Cn(t.id);
    let l;
    e[0] !== g ? (l = he => [he == null ? void 0 : he.isLoading, wt.hasUserMessage(he), wt.getConversationTurns(he).length, he ? wt.getGizmoId(he) : g], e[0] = g, e[1] = l) : l = e[1];
    const [y, I, T, M] = ss(t.id, l), A = Xa(t.id), b = v.use(Mn);
    let k;
    e[2] !== n ? (k = () => {
        var he;
        return oo(n) && cs(n).isFeedbackViewOpen$() && ((he = cs(n).feedbackViewState$()) == null ? void 0 : he.type) !== Tn.Conversation
    }, e[2] = n, e[3] = k) : k = e[3];
    const j = O(k);
    let P, C;
    e[4] !== t.id || e[5] !== n ? (P = () => pl(n, t.id), C = [n, t.id], e[4] = t.id, e[5] = n, e[6] = P, e[7] = C) : (P = e[6], C = e[7]), v.useEffect(P, C);
    const [w] = v.useState(b == null ? void 0 : b.query), [D, J] = v.useState(b == null ? void 0 : b.navlink);
    let q, ne;
    e[8] !== t.id || e[9] !== y ? (q = () => {
        y || (Xs(t.id) ? Eo.addTiming("chatgpt.web.chatPage.renderNewConversation") : Eo.addTiming("chatgpt.web.chatPage.renderExistingConversation"))
    }, ne = [t.id, y], e[8] = t.id, e[9] = y, e[10] = q, e[11] = ne) : (q = e[10], ne = e[11]), v.useEffect(q, ne);
    const {
        setTargetedContent: E
    } = zr();
    let L;
    e[12] !== m ? (L = m == null ? void 0 : m.includes(Za), e[12] = m, e[13] = L) : L = e[13];
    const re = L,
        _ = T >= 2;
    let N;
    e[14] !== n ? (N = Xo(n), e[14] = n, e[15] = N) : N = e[15];
    const K = N;
    let Z;
    e[16] !== n ? (Z = () => [ls(n), ni(n)], e[16] = n, e[17] = Z) : Z = e[17];
    const [de, pe] = O(Z), Y = co(), {
        hash: ye
    } = $o(), Q = ao(), U = uo(), {
        isOpen: ae
    } = vn();
    let ee;
    e[18] !== t.id || e[19] !== t.sharedConversationId || e[20] !== n || e[21] !== ye || e[22] !== Y || e[23] !== Q ? (ee = () => {
        ye === "#report" && (_s(n, Lc, St(Ie({
            clientThreadId: t.id
        }, Y && (t != null && t.sharedConversationId) ? {
            serverThreadId: t.sharedConversationId,
            isSharedConversation: !0
        } : {}), {
            isStaticSharedThread: !1
        })), Q({
            hash: ""
        }, {
            replace: !0
        }))
    }, e[18] = t.id, e[19] = t.sharedConversationId, e[20] = n, e[21] = ye, e[22] = Y, e[23] = Q, e[24] = ee) : ee = e[24];
    let le;
    e[25] !== t || e[26] !== n || e[27] !== ye || e[28] !== Y || e[29] !== Q ? (le = [t, n, ye, Y, Q], e[25] = t, e[26] = n, e[27] = ye, e[28] = Y, e[29] = Q, e[30] = le) : le = e[30], v.useEffect(ee, le);
    const G = !!M;
    let be;
    e[31] !== t.id || e[32] !== _ || e[33] !== S || e[34] !== U || e[35] !== K || e[36] !== G || e[37] !== Y || e[38] !== b ? (be = Xs(t.id) && !_ && (so(S) || (S == null ? void 0 : S.kind) === Zo.GizmoTest) && !Y && !U && b == null && (!K || G), e[31] = t.id, e[32] = _, e[33] = S, e[34] = U, e[35] = K, e[36] = G, e[37] = Y, e[38] = b, e[39] = be) : be = e[39];
    const $ = be,
        ke = $ && !I && b == null && (!K || G || x),
        Ce = de && !I && !G;
    let Ne;
    e[40] !== t ? (Ne = () => on(t), e[40] = t, e[41] = Ne) : Ne = e[41];
    const ze = O(Ne),
        ue = ze.id,
        ge = ei.useStore();
    let fe;
    e[42] !== n ? (fe = () => ai(n), e[42] = n, e[43] = fe) : fe = e[43];
    const De = O(fe);
    let Ve;
    e[44] !== n ? (Ve = (So = lo(n)) == null ? void 0 : So.isWorkspaceAccount(), e[44] = n, e[45] = Ve) : Ve = e[45];
    const qe = Ve;
    let Se, $e;
    e[46] !== t.id || e[47] !== ue || e[48] !== qe || e[49] !== ge || e[50] !== De ? (Se = () => {
        if (ue === ii) return ge.setActiveSystemHint(Js, De, {
            locked: !0,
            analyticsMetadata: {
                clientThreadId: t.id
            }
        }), () => {
            ge.setActiveSystemHint(null, De, {
                locked: !1,
                ifPrevSystemHint: Js,
                analyticsMetadata: {
                    clientThreadId: t.id
                }
            }, qe)
        }
    }, $e = [ue, ge, t.id, De, qe], e[46] = t.id, e[47] = ue, e[48] = qe, e[49] = ge, e[50] = De, e[51] = Se, e[52] = $e) : (Se = e[51], $e = e[52]), v.useEffect(Se, $e);
    const ie = Vr(t.id, S),
        Ye = qr();
    let H;
    e[53] !== Ye || e[54] !== E ? (H = () => {
        Ye || E(void 0)
    }, e[53] = Ye, e[54] = E, e[55] = H) : H = e[55];
    let B;
    e[56] !== t.id || e[57] !== Ye || e[58] !== E ? (B = [t.id, E, Ye], e[56] = t.id, e[57] = Ye, e[58] = E, e[59] = B) : B = e[59], v.useEffect(H, B);
    let F;
    e[60] !== t.id ? (F = [t.id], e[60] = t.id, e[61] = F) : F = e[61], v.useEffect(Gc, F);
    let R, xe;
    e[62] !== n || e[63] !== M || e[64] !== A ? (R = () => {
        const he = new URLSearchParams(window.location.search),
            Nt = he.get("src");
        if (Nt === "history_search") {
            he.delete("src");
            const Rt = he.toString(),
                bs = "".concat(window.location.pathname).concat(Rt ? "?".concat(Rt) : "").concat(window.location.hash);
            window.history.replaceState({}, document.title, bs)
        }
        A && Nt === "history_search" && rs.safePatch("/conversation/{conversation_id}", {
            parameters: {
                path: {
                    conversation_id: A
                }
            },
            requestBody: {
                touch: !0
            }
        }).then(() => {
            const Rt = ri(n);
            li(Rt, M)
        })
    }, xe = [n, A, M], e[62] = n, e[63] = M, e[64] = A, e[65] = R, e[66] = xe) : (R = e[65], xe = e[66]), v.useEffect(R, xe);
    let _e;
    e[67] !== t || e[68] !== n || e[69] !== ue || e[70] !== i ? (_e = he => {
        var Rt, bs, xo;
        const Nt = Ie({
            conversation: t
        }, i ? i(he) : he);
        if ((bs = (Rt = Nt.completionMetadata) == null ? void 0 : Rt.systemHints) != null && bs.some(Uc) && mo(n)) {
            const yo = nn(n, (xo = Nt.requestedModelId) != null ? xo : ue);
            yo && (Nt.requestedModelId = yo)
        }
        _n(Nt)
    }, e[67] = t, e[68] = n, e[69] = ue, e[70] = i, e[71] = _e) : _e = e[71];
    const Ze = Ot(_e);
    let Re;
    e[72] !== n || e[73] !== K || e[74] !== $ || e[75] !== Ze ? (Re = he => {
        $ && !an() && !K && rn(n, "3253785454").get("should_animate_composer", !1) ? Ft({
            className: ms["composer-slide"],
            update: () => Ze(he)
        }) : Ze(he)
    }, e[72] = n, e[73] = K, e[74] = $, e[75] = Ze, e[76] = Re) : Re = e[76];
    const W = Ot(Re);
    Yr(t.id, W), Kr(), Qr(t.id), Jr(W);
    let Fe, Qe;
    e[77] !== n ? (Fe = () => ci(() => oo(n), () => {
        gl(n).logEventWithStatsig("Web: FYP: Eligible Feed User", "chatgpt_web_fyp_dau_with_fyp_available")
    }), Qe = [n], e[77] = n, e[78] = Fe, e[79] = Qe) : (Fe = e[78], Qe = e[79]), v.useEffect(Fe, Qe), Xr($);
    const yt = Zr({
            clientThreadId: t.id,
            handleRequestCompletion: W,
            prefetchSearchThreadIdPromise: b == null ? void 0 : b.threadId
        }) && w == null,
        we = v.useRef(null),
        nt = el(!1);
    let et, Me;
    e[80] === Symbol.for("react.memo_cache_sentinel") ? (et = () => {
        we.current = Ge.current && fl(Ge.current)
    }, Me = [], e[80] = et, e[81] = Me) : (et = e[80], Me = e[81]), v.useEffect(et, Me);
    let Ae;
    e[82] !== U || e[83] !== d || e[84] !== ie ? (Ae = () => {
        !U && !d && (document.title = ie != null ? ie : "ChatGPT")
    }, e[82] = U, e[83] = d, e[84] = ie, e[85] = Ae) : Ae = e[85];
    let Ke;
    e[86] !== U || e[87] !== f || e[88] !== d || e[89] !== ie ? (Ke = [ie, U, d, f], e[86] = U, e[87] = f, e[88] = d, e[89] = ie, e[90] = Ke) : Ke = e[90], v.useEffect(Ae, Ke);
    let tt;
    e[91] !== n || e[92] !== M ? (tt = en(n, M), e[91] = n, e[92] = M, e[93] = tt) : tt = e[93];
    const Oe = tt,
        Je = ke && !r && Oe,
        ve = tn();
    let Be;
    e[94] !== ve ? (Be = !1, e[94] = ve, e[95] = Be) : Be = e[95];
    const at = Be,
        Ge = v.useRef(null),
        je = v.useRef(null),
        it = tl(zc),
        rt = !$ && !ae && !de;
    let lt;
    e[96] === Symbol.for("react.memo_cache_sentinel") ? (lt = () => J(void 0), e[96] = lt) : lt = e[96];
    const se = lt;
    let ce;
    e[97] !== n ? (ce = () => ln(n), e[97] = n, e[98] = ce) : ce = e[98];
    const {
        isSingleLine: me
    } = O(ce);
    sn();
    const oe = O(Ms),
        X = xt(n, "739972392"),
        Le = $ && at && oe && X,
        [mt, ct] = v.useState(null),
        bt = fo();
    let dt;
    e[99] !== n || e[100] !== bt ? (dt = () => Is(n) && bt.visible$() && Ms(), e[99] = n, e[100] = bt, e[101] = dt) : dt = e[101];
    const Mt = O(dt);
    let At;
    e[102] !== t ? (At = () => Ns(t).pinnedWidgetHeight$(), e[102] = t, e[103] = At) : At = e[103];
    const Ct = O(At),
        ht = sl(),
        pt = function() {
            return s.jsx(Wc, {
                clientThreadId: t.id,
                scrollContainerRef: we
            })
        },
        gt = function() {
            return y || yt ? null : ke ? Je ? s.jsx(dl, {
                clientThreadId: t.id,
                gizmoId: M,
                currentModelId: ue,
                onRequestCompletion: W
            }) : r != null ? r : s.jsx(s.Fragment, {
                children: G ? s.jsx(ul, {
                    conversation: t,
                    gizmoId: M,
                    onRequestCompletion: W,
                    currentModelId: ue
                }) : s.jsx($l, {
                    clientThreadId: t.id,
                    currentModelId: ue
                })
            }) : _ || w != null ? s.jsx(Dc, {
                conversation: t,
                isNewScrollEnabled: p,
                pageLoadSearchQuery: w,
                footerRootContainerElementRef: je,
                threadRootRef: Ge,
                isScrolledFromBottom$: nt,
                scrollContainerRef: we,
                children: s.jsx(Hl, {
                    onRequestCompletion: W,
                    conversation: t,
                    scrollContainerRef: we,
                    pageLoadSearchQuery: w,
                    prefetchNavlink: D,
                    clearPrefetchNavlink: se
                }, t.id)
            }) : null
        },
        Xe = cl,
        Ee = D ? "user-query-with-navlink" : w ? "user-query" : null,
        Te = ll,
        vt = rl,
        Et = t.id,
        Tt = si;
    let st;
    e[104] !== t ? (st = s.jsx(Bc, {
        conversation: t
    }), e[104] = t, e[105] = st) : st = e[105];
    let ft;
    e[106] !== re ? (ft = re && s.jsx(Hc, {}), e[106] = re, e[107] = ft) : ft = e[107];
    let It;
    e[108] !== U || e[109] !== d || e[110] !== ie ? (It = !U && !d && s.jsx(Sl, {
        children: ie != null && s.jsx("title", {
            children: ie
        })
    }), e[108] = U, e[109] = d, e[110] = ie, e[111] = It) : It = e[111];
    const Lt = ti,
        Ht = il;
    let Pt;
    e[112] !== t ? (Pt = s.jsx(xl, {
        conversation: t
    }), e[112] = t, e[113] = Pt) : Pt = e[113];
    const z = "thread",
        Ue = Ge,
        Wt = We("group/thread flex flex-col", "min-h-full", p && ol.threadRoot, pe && "opacity-0", c),
        Dt = _l,
        hs = !0,
        ps = t.id,
        jn = "composer-parent flex flex-1 flex-col focus-visible:outline-0";
    let $t;
    e[114] !== t.id || e[115] !== n ? ($t = xt(n, "1909635392") && s.jsx(nl, {
        clientThreadId: t.id
    }), e[114] = t.id, e[115] = n, e[116] = $t) : $t = e[116];
    const Rs = We("relative basis-auto flex-col", rt && "-mb-(--composer-overlap-px)", rt && (me ? "[--composer-overlap-px:28px]" : "[--composer-overlap-px:55px]"), Oe || G || !$ || x ? "grow" : "shrink", Je ? "grid" : "flex", $ && d && !x && "sm:min-h-[21svh]!", $ && !x && !Oe && !G && (Le ? "justify-start pt-[clamp(4rem,calc(30svh-(var(--deep-research-landing-page-content-height,0px)*0.40)),16rem)]" : We("flex-col justify-end max-sm:grow max-sm:justify-center", Mt ? "sm:min-h-[calc(38svh-var(--header-height))]" : "sm:min-h-[calc(42svh-var(--header-height))]")), o, j && "hidden"),
        Fs = it ? "".concat(it, "px") : void 0,
        Os = Le && mt != null ? "".concat(mt, "px") : void 0;
    let gs;
    e[117] !== Ct || e[118] !== Fs || e[119] !== Os ? (gs = {
        "--composer-height": Fs,
        "--deep-research-landing-page-content-height": Os,
        marginTop: Ct
    }, e[117] = Ct, e[118] = Fs, e[119] = Os, e[120] = gs) : gs = e[120];
    const Ls = gs,
        Hs = ht && pt(),
        Ws = gt();
    let Bt;
    e[121] !== K || e[122] !== de || e[123] !== G || e[124] !== Ce ? (Bt = K && de && !G && s.jsx(yl, {
        showEmptyState: Ce
    }), e[121] = K, e[122] = de, e[123] = G, e[124] = Ce, e[125] = Bt) : Bt = e[125];
    let Gt;
    e[126] !== Rs || e[127] !== Ls || e[128] !== Hs || e[129] !== Ws || e[130] !== Bt ? (Gt = s.jsxs("div", {
        className: Rs,
        style: Ls,
        children: [Hs, Ws, Bt]
    }), e[126] = Rs, e[127] = Ls, e[128] = Hs, e[129] = Ws, e[130] = Bt, e[131] = Gt) : Gt = e[131];
    let Ut;
    e[132] !== j ? (Ut = j && s.jsx(bl, {}), e[132] = j, e[133] = Ut) : Ut = e[133];
    let zt;
    e[134] !== t || e[135] !== h || e[136] !== nt || e[137] !== u || e[138] !== r || e[139] !== ct || e[140] !== i ? (zt = s.jsx(Nc, {
        conversation: t,
        withCustomCompletionParams: i,
        hideDisclaimer: h,
        renderEmptyState: r,
        renderEmptyFooter: u,
        scrollContainerRef: we,
        isScrolledFromBottom$: nt,
        footerRootContainerElementRef: je,
        onDeepResearchLandingPageContentHeightChange: ct
    }), e[134] = t, e[135] = h, e[136] = nt, e[137] = u, e[138] = r, e[139] = ct, e[140] = i, e[141] = zt) : zt = e[141];
    let Vt;
    e[142] !== Dt || e[143] !== t.id || e[144] !== ze || e[145] !== $t || e[146] !== Gt || e[147] !== Ut || e[148] !== zt ? (Vt = s.jsxs(Dt, {
        noKeyboard: hs,
        clientThreadId: ps,
        currentModelConfig: ze,
        className: jn,
        children: [$t, Gt, Ut, zt]
    }), e[142] = Dt, e[143] = t.id, e[144] = ze, e[145] = $t, e[146] = Gt, e[147] = Ut, e[148] = zt, e[149] = Vt) : Vt = e[149];
    let qt;
    e[150] !== pe || e[151] !== Wt || e[152] !== Vt ? (qt = s.jsx("div", {
        id: z,
        ref: Ue,
        className: Wt,
        inert: pe,
        children: Vt
    }), e[150] = pe, e[151] = Wt, e[152] = Vt, e[153] = qt) : qt = e[153];
    let fs;
    e[154] === Symbol.for("react.memo_cache_sentinel") ? (fs = s.jsx(Cl, {}), e[154] = fs) : fs = e[154];
    let Yt;
    e[155] !== t.id ? (Yt = s.jsx(al, {
        conversationId: t.id
    }), e[155] = t.id, e[156] = Yt) : Yt = e[156];
    let Ss, xs;
    e[157] === Symbol.for("react.memo_cache_sentinel") ? (Ss = s.jsx(vl, {}), xs = s.jsx(Tl, {}), e[157] = Ss, e[158] = xs) : (Ss = e[157], xs = e[158]);
    let Kt;
    e[159] !== Ht || e[160] !== Pt || e[161] !== qt || e[162] !== Yt ? (Kt = s.jsxs(Ht, {
        children: [Pt, qt, fs, Yt, Ss, xs]
    }), e[159] = Ht, e[160] = Pt, e[161] = qt, e[162] = Yt, e[163] = Kt) : Kt = e[163];
    let Qt;
    e[164] !== W || e[165] !== Lt.Provider || e[166] !== Kt ? (Qt = s.jsx(Lt.Provider, {
        value: W,
        children: Kt
    }), e[164] = W, e[165] = Lt.Provider, e[166] = Kt, e[167] = Qt) : Qt = e[167];
    let Jt;
    e[168] !== Tt || e[169] !== t || e[170] !== st || e[171] !== ft || e[172] !== It || e[173] !== Qt ? (Jt = s.jsxs(Tt, {
        conversation: t,
        children: [st, ft, It, Qt]
    }), e[168] = Tt, e[169] = t, e[170] = st, e[171] = ft, e[172] = It, e[173] = Qt, e[174] = Jt) : Jt = e[174];
    let Xt;
    e[175] !== vt || e[176] !== t.id || e[177] !== Jt ? (Xt = s.jsx(vt, {
        clientThreadId: Et,
        children: Jt
    }), e[175] = vt, e[176] = t.id, e[177] = Jt, e[178] = Xt) : Xt = e[178];
    let Zt;
    e[179] !== Te || e[180] !== A || e[181] !== Xt ? (Zt = s.jsx(Te, {
        serverThreadId: A,
        children: Xt
    }), e[179] = Te, e[180] = A, e[181] = Xt, e[182] = Zt) : Zt = e[182];
    let ys;
    return e[183] !== Xe.Provider || e[184] !== Ee || e[185] !== Zt ? (ys = s.jsx(Xe.Provider, {
        value: Ee,
        children: Zt
    }), e[183] = Xe.Provider, e[184] = Ee, e[185] = Zt, e[186] = ys) : ys = e[186], ys
};

function $c({
    conversation: a
}) {
    return Hr(a), Wr(), Dr(), $r(a), Br(), Gr(a), null
}
const Bc = Dn.memo($c);

function Gc() {
    io.setIsConversationScrolledFromTop(!1)
}

function Uc(a) {
    return cn(a)
}

function zc(a) {
    return a.composerHeight
}
export {
    tc as I, as as S, sd as T
};
//# sourceMappingURL=iw47v9tf328v3kli.js.map