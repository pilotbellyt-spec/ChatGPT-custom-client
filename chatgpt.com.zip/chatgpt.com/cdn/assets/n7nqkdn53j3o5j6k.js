var n = Object.defineProperty,
    u = Object.defineProperties;
var f = Object.getOwnPropertyDescriptors;
var i = Object.getOwnPropertySymbols;
var p = Object.prototype.hasOwnProperty,
    c = Object.prototype.propertyIsEnumerable;
var o = (e, r, a) => r in e ? n(e, r, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: a
    }) : e[r] = a,
    s = (e, r) => {
        for (var a in r || (r = {})) p.call(r, a) && o(e, a, r[a]);
        if (i)
            for (var a of i(r)) c.call(r, a) && o(e, a, r[a]);
        return e
    },
    l = (e, r) => u(e, f(r));
import {
    f as d,
    n as m
} from "./fg33krlcm0qyi6yw.js";
import "./dykg4ktvbu3mhmdo.js";
const E = "team-1-month-free",
    R = 5;

function C(e) {
    return 0
}
const D = d({
        teamFreeTrialCost: {
            id: "promo.teamFreeTrial.teamFreeTrialCost",
            defaultMessage: "for the first month"
        },
        teamFreeTrialPerSeat: {
            id: "promo.teamFreeTrial.teamFreeTrialPerSeat",
            defaultMessage: "/seat"
        },
        teamFreeTrialCostFollowUp: {
            id: "promo.teamFreeTrial.teamFreeTrialCostFollowUp",
            defaultMessage: "up to 5 users if eligible"
        },
        teamFreeTrialCostNormalPricing: {
            id: "promo.teamFreeTrial.teamFreeTrialCostNormalPricing",
            defaultMessage: "After promotion, you will be charged the regular price"
        },
        asterisk: {
            id: "promo.teamFreeTrial.astrix",
            defaultMessage: "*"
        },
        teamFreeTrialLoginToVerify: {
            id: "promo.teamFreeTrial.loginToVerify",
            defaultMessage: "Log in or create a free account to verify your eligibility for the promotion."
        },
        teamFreeTrialMonthlyCost: {
            id: "promo.teamFreeTrial.monthlyCostZero",
            defaultMessage: "1 month free <s>{currencySign}{monthlyCost}</s>"
        },
        teamFreeTrialMonthlyStructure: {
            id: "promo.teamFreeTrial.monthlyStructure",
            defaultMessage: "Up to 5 users for {currencySign}1 flat-fee for the first month, then standard pricing applies."
        },
        teamFreeTrialOverSeatsDisclaimer: {
            id: "promo.teamFreeTrial.overSeatsDisclaimer",
            defaultMessage: "You have more than 5 users. The promo will only apply to the first 5 users for the first month."
        },
        teamFreeTrialBelowDiscount: {
            id: "promo.teamFreeTrial.belowDiscount",
            defaultMessage: "1 month free up to 5 seats"
        },
        promoCost: {
            id: "promo.teamFreeTrial.cost",
            defaultMessage: "0*"
        },
        teamFreeTrialPromoDisclaimer: {
            id: "promo.teamFreeTrial.disclaimer",
            defaultMessage: "*Billed as a {currencySign}0 flat fee up to 5 seats for the first month, after which regular pricing applies. Restrictions apply."
        },
        teamFreeTrialPromoDisclaimerWithPerSeatMonthlyPrice: {
            id: "promo.teamFreeTrial.disclaimerWithPerSeatMonthlyPrice",
            defaultMessage: "*Maximum 5 seats. Billed at {postTrialSeatPrice} seat/mo after 1 month. Limits apply."
        },
        teamFreeTrialPromoDisclaimerINR: {
            id: "promo.teamFreeTrial.teamFreeTrialPromoDisclaimerINR",
            defaultMessage: "*Billed as a ₹0 flat fee up to 5 seats for the first month, after which regular pricing applies. Restrictions apply."
        },
        teamFreeTrialPromoDisclaimerIDR: {
            id: "promo.teamFreeTrial.teamFreeTrialPromoDisclaimerIDR",
            defaultMessage: "*Billed as a Rp0 flat fee up to 5 seats for the first month, after which regular pricing applies. Restrictions apply."
        },
        teamFreeTrialPromoDisclaimerWithAmount: {
            id: "promo.teamFreeTrial.teamFreeTrialPromoDisclaimerWithAmount",
            defaultMessage: "*Billed as a {amount} flat fee up to 5 seats for the first month, after which regular pricing applies. Restrictions apply."
        },
        promoCostDuration: {
            id: "promo.teamFreeTrial.costDuration",
            defaultMessage: "for the first month"
        },
        teamFreeTrialNotEligible: {
            id: "promo.teamFreeTrial.notEligibleMessage",
            defaultMessage: "Sorry, you're not eligible for this promotional discount."
        },
        teamFreeTrialTemporarilyDisabled: {
            id: "promo.teamFreeTrial.temporarilyDisabled",
            defaultMessage: "This promotion is currently temporarily disabled. Please check back later."
        },
        teamFreeTrialOffline: {
            id: "promo.teamFreeTrial.offline",
            defaultMessage: "This promotion you are trying to use is offline or expired."
        },
        teamFreeTrialWelcomeOffer: {
            id: "promo.teamFreeTrial.welcomeOffer",
            defaultMessage: "WELCOME OFFER"
        }
    }),
    T = "promo_campaign";

function S() {
    const [e] = m();
    return e.get(T)
}
const g = ["WEB-team_try_for_1"],
    h = ["openai_business"],
    F = ["true"];

function M() {
    const [e] = m();
    return {
        utmInternalSource: e.get("utm_internal_source"),
        openAIReferred: e.get("openaicom_referred"),
        utmCampaign: e.get("utm_campaign")
    }
}

function y(e) {
    const {
        utmCampaign: r,
        utmInternalSource: a,
        openAIReferred: t
    } = e;
    return !!r && !!a && !!t && g.includes(r) && h.includes(a) && F.includes(t)
}

function A() {
    const e = M(),
        r = y(e);
    return l(s({}, e), {
        shouldHide: r
    })
}
export {
    T as P, E as T, R as a, A as b, C as g, D as t, S as u
};
//# sourceMappingURL=n7nqkdn53j3o5j6k.js.map