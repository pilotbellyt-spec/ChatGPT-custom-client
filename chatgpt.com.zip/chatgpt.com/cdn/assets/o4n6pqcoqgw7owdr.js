var ko = Object.defineProperty;
var Ar = Object.getOwnPropertySymbols;
var Oo = Object.prototype.hasOwnProperty,
    Po = Object.prototype.propertyIsEnumerable;
var Ir = (C, N, F) => N in C ? ko(C, N, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: F
    }) : C[N] = F,
    Sr = (C, N) => {
        for (var F in N || (N = {})) Oo.call(N, F) && Ir(C, F, N[F]);
        if (Ar)
            for (var F of Ar(N)) Po.call(N, F) && Ir(C, F, N[F]);
        return C
    };
import {
    de as Eo,
    _ as be,
    dZ as Qn,
    $ as Ao,
    dI as Io,
    dH as So,
    dF as Bt,
    kw as Co,
    kx as Ko,
    dQ as Do,
    bc as jr,
    bd as Rr,
    I as To,
    b as jo
} from "./dykg4ktvbu3mhmdo.js";
import {
    z as Ro,
    h as qo,
    E as mn,
    r as Cr
} from "./fg33krlcm0qyi6yw.js";
var Gn = {
        exports: {}
    },
    Bo = Gn.exports,
    Kr;

function Fo() {
    return Kr || (Kr = 1, (function(C, N) {
        (function(F, I) {
            C.exports = I()
        })(Bo, function() {
            var F = function(e, n) {
                    return (F = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(t, r) {
                            t.__proto__ = r
                        } || function(t, r) {
                            for (var o in r) Object.prototype.hasOwnProperty.call(r, o) && (t[o] = r[o])
                        })(e, n)
                },
                I = function() {
                    return (I = Object.assign || function(e) {
                        for (var n, t = 1, r = arguments.length; t < r; t++)
                            for (var o in n = arguments[t]) Object.prototype.hasOwnProperty.call(n, o) && (e[o] = n[o]);
                        return e
                    }).apply(this, arguments)
                };

            function ee(e, n, t) {
                for (var r, o = 0, i = n.length; o < i; o++) !r && o in n || ((r = r || Array.prototype.slice.call(n, 0, o))[o] = n[o]);
                return e.concat(r || Array.prototype.slice.call(n))
            }
            var R = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : Ro,
                W = Object.keys,
                D = Array.isArray;

            function U(e, n) {
                return typeof n != "object" || W(n).forEach(function(t) {
                    e[t] = n[t]
                }), e
            }
            typeof Promise > "u" || R.Promise || (R.Promise = Promise);
            var z = Object.getPrototypeOf,
                re = {}.hasOwnProperty;

            function Y(e, n) {
                return re.call(e, n)
            }

            function Ue(e, n) {
                typeof n == "function" && (n = n(z(e))), (typeof Reflect > "u" ? W : Reflect.ownKeys)(n).forEach(function(t) {
                    xe(e, t, n[t])
                })
            }
            var Nt = Object.defineProperty;

            function xe(e, n, t, r) {
                Nt(e, n, U(t && Y(t, "get") && typeof t.get == "function" ? {
                    get: t.get,
                    set: t.set,
                    configurable: !0
                } : {
                    value: t,
                    configurable: !0,
                    writable: !0
                }, r))
            }

            function Le(e) {
                return {
                    from: function(n) {
                        return e.prototype = Object.create(n.prototype), xe(e.prototype, "constructor", e), {
                            extend: Ue.bind(null, e.prototype)
                        }
                    }
                }
            }
            var Mr = Object.getOwnPropertyDescriptor,
                Nr = [].slice;

            function bn(e, n, t) {
                return Nr.call(e, n, t)
            }

            function Ut(e, n) {
                return n(e)
            }

            function Ze(e) {
                if (!e) throw new Error("Assertion Failed")
            }

            function Lt(e) {
                R.setImmediate ? setImmediate(e) : setTimeout(e, 0)
            }

            function pe(e, n) {
                if (typeof n == "string" && Y(e, n)) return e[n];
                if (!n) return e;
                if (typeof n != "string") {
                    for (var t = [], r = 0, o = n.length; r < o; ++r) {
                        var i = pe(e, n[r]);
                        t.push(i)
                    }
                    return t
                }
                var a = n.indexOf(".");
                if (a !== -1) {
                    var u = e[n.substr(0, a)];
                    return u == null ? void 0 : pe(u, n.substr(a + 1))
                }
            }

            function ae(e, n, t) {
                if (e && n !== void 0 && !("isFrozen" in Object && Object.isFrozen(e)))
                    if (typeof n != "string" && "length" in n) {
                        Ze(typeof t != "string" && "length" in t);
                        for (var r = 0, o = n.length; r < o; ++r) ae(e, n[r], t[r])
                    } else {
                        var i, a, u = n.indexOf(".");
                        u !== -1 ? (i = n.substr(0, u), (a = n.substr(u + 1)) === "" ? t === void 0 ? D(e) && !isNaN(parseInt(i)) ? e.splice(i, 1) : delete e[i] : e[i] = t : ae(u = !(u = e[i]) || !Y(e, i) ? e[i] = {} : u, a, t)) : t === void 0 ? D(e) && !isNaN(parseInt(n)) ? e.splice(n, 1) : delete e[n] : e[n] = t
                    }
            }

            function Vt(e) {
                var n, t = {};
                for (n in e) Y(e, n) && (t[n] = e[n]);
                return t
            }
            var Ur = [].concat;

            function zt(e) {
                return Ur.apply([], e)
            }
            var me = "BigUint64Array,BigInt64Array,Array,Boolean,String,Date,RegExp,Blob,File,FileList,FileSystemFileHandle,FileSystemDirectoryHandle,ArrayBuffer,DataView,Uint8ClampedArray,ImageBitmap,ImageData,Map,Set,CryptoKey".split(",").concat(zt([8, 16, 32, 64].map(function(e) {
                    return ["Int", "Uint", "Float"].map(function(n) {
                        return n + e + "Array"
                    })
                }))).filter(function(e) {
                    return R[e]
                }),
                $t = new Set(me.map(function(e) {
                    return R[e]
                })),
                en = null;

            function Ce(e) {
                return en = new WeakMap, e = (function n(t) {
                    if (!t || typeof t != "object") return t;
                    var r = en.get(t);
                    if (r) return r;
                    if (D(t)) {
                        r = [], en.set(t, r);
                        for (var o = 0, i = t.length; o < i; ++o) r.push(n(t[o]))
                    } else if ($t.has(t.constructor)) r = t;
                    else {
                        var a, u = z(t);
                        for (a in r = u === Object.prototype ? {} : Object.create(u), en.set(t, r), t) Y(t, a) && (r[a] = n(t[a]))
                    }
                    return r
                })(e), en = null, e
            }
            var Lr = {}.toString;

            function Xn(e) {
                return Lr.call(e).slice(8, -1)
            }
            var Jn = typeof Symbol < "u" ? Symbol.iterator : "@@iterator",
                Vr = typeof Jn == "symbol" ? function(e) {
                    var n;
                    return e != null && (n = e[Jn]) && n.apply(e)
                } : function() {
                    return null
                };

            function Ke(e, n) {
                return n = e.indexOf(n), 0 <= n && e.splice(n, 1), 0 <= n
            }
            var Ve = {};

            function ye(e) {
                var n, t, r, o;
                if (arguments.length === 1) {
                    if (D(e)) return e.slice();
                    if (this === Ve && typeof e == "string") return [e];
                    if (o = Vr(e)) {
                        for (t = []; !(r = o.next()).done;) t.push(r.value);
                        return t
                    }
                    if (e == null) return [e];
                    if (typeof(n = e.length) != "number") return [e];
                    for (t = new Array(n); n--;) t[n] = e[n];
                    return t
                }
                for (n = arguments.length, t = new Array(n); n--;) t[n] = arguments[n];
                return t
            }
            var Zn = typeof Symbol < "u" ? function(e) {
                    return e[Symbol.toStringTag] === "AsyncFunction"
                } : function() {
                    return !1
                },
                rn = ["Unknown", "Constraint", "Data", "TransactionInactive", "ReadOnly", "Version", "NotFound", "InvalidState", "InvalidAccess", "Abort", "Timeout", "QuotaExceeded", "Syntax", "DataClone"],
                se = ["Modify", "Bulk", "OpenFailed", "VersionChange", "Schema", "Upgrade", "InvalidTable", "MissingAPI", "NoSuchDatabase", "InvalidArgument", "SubTransaction", "Unsupported", "Internal", "DatabaseClosed", "PrematureCommit", "ForeignAwait"].concat(rn),
                zr = {
                    VersionChanged: "Database version changed by other database connection",
                    DatabaseClosed: "Database has been closed",
                    Abort: "Transaction aborted",
                    TransactionInactive: "Transaction has already completed or failed",
                    MissingAPI: "IndexedDB API missing. Please visit https://tinyurl.com/y2uuvskb"
                };

            function ze(e, n) {
                this.name = e, this.message = n
            }

            function Wt(e, n) {
                return e + ". Errors: " + Object.keys(n).map(function(t) {
                    return n[t].toString()
                }).filter(function(t, r, o) {
                    return o.indexOf(t) === r
                }).join("\n")
            }

            function wn(e, n, t, r) {
                this.failures = n, this.failedKeys = r, this.successCount = t, this.message = Wt(e, n)
            }

            function $e(e, n) {
                this.name = "BulkError", this.failures = Object.keys(n).map(function(t) {
                    return n[t]
                }), this.failuresByPos = n, this.message = Wt(e, this.failures)
            }
            Le(ze).from(Error).extend({
                toString: function() {
                    return this.name + ": " + this.message
                }
            }), Le(wn).from(ze), Le($e).from(ze);
            var et = se.reduce(function(e, n) {
                    return e[n] = n + "Error", e
                }, {}),
                $r = ze,
                K = se.reduce(function(e, n) {
                    var t = n + "Error";

                    function r(o, i) {
                        this.name = t, o ? typeof o == "string" ? (this.message = "".concat(o).concat(i ? "\n " + i : ""), this.inner = i || null) : typeof o == "object" && (this.message = "".concat(o.name, " ").concat(o.message), this.inner = o) : (this.message = zr[n] || t, this.inner = null)
                    }
                    return Le(r).from($r), e[n] = r, e
                }, {});
            K.Syntax = SyntaxError, K.Type = TypeError, K.Range = RangeError;
            var Yt = rn.reduce(function(e, n) {
                    return e[n + "Error"] = K[n], e
                }, {}),
                _n = se.reduce(function(e, n) {
                    return ["Syntax", "Type", "Range"].indexOf(n) === -1 && (e[n + "Error"] = K[n]), e
                }, {});

            function $() {}

            function nn(e) {
                return e
            }

            function Wr(e, n) {
                return e == null || e === nn ? n : function(t) {
                    return n(e(t))
                }
            }

            function De(e, n) {
                return function() {
                    e.apply(this, arguments), n.apply(this, arguments)
                }
            }

            function Yr(e, n) {
                return e === $ ? n : function() {
                    var t = e.apply(this, arguments);
                    t !== void 0 && (arguments[0] = t);
                    var r = this.onsuccess,
                        o = this.onerror;
                    this.onsuccess = null, this.onerror = null;
                    var i = n.apply(this, arguments);
                    return r && (this.onsuccess = this.onsuccess ? De(r, this.onsuccess) : r), o && (this.onerror = this.onerror ? De(o, this.onerror) : o), i !== void 0 ? i : t
                }
            }

            function Qr(e, n) {
                return e === $ ? n : function() {
                    e.apply(this, arguments);
                    var t = this.onsuccess,
                        r = this.onerror;
                    this.onsuccess = this.onerror = null, n.apply(this, arguments), t && (this.onsuccess = this.onsuccess ? De(t, this.onsuccess) : t), r && (this.onerror = this.onerror ? De(r, this.onerror) : r)
                }
            }

            function Gr(e, n) {
                return e === $ ? n : function(t) {
                    var r = e.apply(this, arguments);
                    U(t, r);
                    var o = this.onsuccess,
                        i = this.onerror;
                    return this.onsuccess = null, this.onerror = null, t = n.apply(this, arguments), o && (this.onsuccess = this.onsuccess ? De(o, this.onsuccess) : o), i && (this.onerror = this.onerror ? De(i, this.onerror) : i), r === void 0 ? t === void 0 ? void 0 : t : U(r, t)
                }
            }

            function Hr(e, n) {
                return e === $ ? n : function() {
                    return n.apply(this, arguments) !== !1 && e.apply(this, arguments)
                }
            }

            function nt(e, n) {
                return e === $ ? n : function() {
                    var t = e.apply(this, arguments);
                    if (t && typeof t.then == "function") {
                        for (var r = this, o = arguments.length, i = new Array(o); o--;) i[o] = arguments[o];
                        return t.then(function() {
                            return n.apply(r, i)
                        })
                    }
                    return n.apply(this, arguments)
                }
            }
            _n.ModifyError = wn, _n.DexieError = ze, _n.BulkError = $e;
            var le = typeof location < "u" && /^(http|https):\/\/(localhost|127\.0\.0\.1)/.test(location.href);

            function Qt(e) {
                le = e
            }
            var tn = {},
                Gt = 100,
                me = typeof Promise > "u" ? [] : (function() {
                    var e = Promise.resolve();
                    if (typeof crypto > "u" || !crypto.subtle) return [e, z(e), e];
                    var n = crypto.subtle.digest("SHA-512", new Uint8Array([0]));
                    return [n, z(n), e]
                })(),
                rn = me[0],
                se = me[1],
                me = me[2],
                se = se && se.then,
                on = rn && rn.constructor,
                tt = !!me,
                an = function(e, n) {
                    un.push([e, n]), xn && (queueMicrotask(Jr), xn = !1)
                },
                rt = !0,
                xn = !0,
                Te = [],
                kn = [],
                ot = nn,
                ke = {
                    id: "global",
                    global: !0,
                    ref: 0,
                    unhandleds: [],
                    onunhandled: $,
                    pgp: !1,
                    env: {},
                    finalize: $
                },
                S = ke,
                un = [],
                je = 0,
                On = [];

            function A(e) {
                if (typeof this != "object") throw new TypeError("Promises must be constructed via new");
                this._listeners = [], this._lib = !1;
                var n = this._PSD = S;
                if (typeof e != "function") {
                    if (e !== tn) throw new TypeError("Not a function");
                    return this._state = arguments[1], this._value = arguments[2], void(this._state === !1 && at(this, this._value))
                }
                this._state = null, this._value = null, ++n.ref, (function t(r, o) {
                    try {
                        o(function(i) {
                            if (r._state === null) {
                                if (i === r) throw new TypeError("A promise cannot be resolved with itself.");
                                var a = r._lib && We();
                                i && typeof i.then == "function" ? t(r, function(u, f) {
                                    i instanceof A ? i._then(u, f) : i.then(u, f)
                                }) : (r._state = !0, r._value = i, Xt(r)), a && Ye()
                            }
                        }, at.bind(null, r))
                    } catch (i) {
                        at(r, i)
                    }
                })(this, e)
            }
            var it = {
                get: function() {
                    var e = S,
                        n = In;

                    function t(r, o) {
                        var i = this,
                            a = !e.global && (e !== S || n !== In),
                            u = a && !Pe(),
                            f = new A(function(c, p) {
                                ut(i, new Ht(Zt(r, e, a, u), Zt(o, e, a, u), c, p, e))
                            });
                        return this._consoleTask && (f._consoleTask = this._consoleTask), f
                    }
                    return t.prototype = tn, t
                },
                set: function(e) {
                    xe(this, "then", e && e.prototype === tn ? it : {
                        get: function() {
                            return e
                        },
                        set: it.set
                    })
                }
            };

            function Ht(e, n, t, r, o) {
                this.onFulfilled = typeof e == "function" ? e : null, this.onRejected = typeof n == "function" ? n : null, this.resolve = t, this.reject = r, this.psd = o
            }

            function at(e, n) {
                var t, r;
                kn.push(n), e._state === null && (t = e._lib && We(), n = ot(n), e._state = !1, e._value = n, r = e, Te.some(function(o) {
                    return o._value === r._value
                }) || Te.push(r), Xt(e), t && Ye())
            }

            function Xt(e) {
                var n = e._listeners;
                e._listeners = [];
                for (var t = 0, r = n.length; t < r; ++t) ut(e, n[t]);
                var o = e._PSD;
                --o.ref || o.finalize(), je === 0 && (++je, an(function() {
                    --je == 0 && st()
                }, []))
            }

            function ut(e, n) {
                if (e._state !== null) {
                    var t = e._state ? n.onFulfilled : n.onRejected;
                    if (t === null) return (e._state ? n.resolve : n.reject)(e._value);
                    ++n.psd.ref, ++je, an(Xr, [t, e, n])
                } else e._listeners.push(n)
            }

            function Xr(e, n, t) {
                try {
                    var r, o = n._value;
                    !n._state && kn.length && (kn = []), r = le && n._consoleTask ? n._consoleTask.run(function() {
                        return e(o)
                    }) : e(o), n._state || kn.indexOf(o) !== -1 || (function(i) {
                        for (var a = Te.length; a;)
                            if (Te[--a]._value === i._value) return Te.splice(a, 1)
                    })(n), t.resolve(r)
                } catch (i) {
                    t.reject(i)
                } finally {
                    --je == 0 && st(), --t.psd.ref || t.psd.finalize()
                }
            }

            function Jr() {
                Re(ke, function() {
                    We() && Ye()
                })
            }

            function We() {
                var e = rt;
                return xn = rt = !1, e
            }

            function Ye() {
                var e, n, t;
                do
                    for (; 0 < un.length;)
                        for (e = un, un = [], t = e.length, n = 0; n < t; ++n) {
                            var r = e[n];
                            r[0].apply(null, r[1])
                        }
                while (0 < un.length);
                xn = rt = !0
            }

            function st() {
                var e = Te;
                Te = [], e.forEach(function(r) {
                    r._PSD.onunhandled.call(null, r._value, r)
                });
                for (var n = On.slice(0), t = n.length; t;) n[--t]()
            }

            function Pn(e) {
                return new A(tn, !1, e)
            }

            function G(e, n) {
                var t = S;
                return function() {
                    var r = We(),
                        o = S;
                    try {
                        return Ee(t, !0), e.apply(this, arguments)
                    } catch (i) {
                        n && n(i)
                    } finally {
                        Ee(o, !1), r && Ye()
                    }
                }
            }
            Ue(A.prototype, {
                then: it,
                _then: function(e, n) {
                    ut(this, new Ht(null, null, e, n, S))
                },
                catch: function(e) {
                    if (arguments.length === 1) return this.then(null, e);
                    var n = e,
                        t = arguments[1];
                    return typeof n == "function" ? this.then(null, function(r) {
                        return (r instanceof n ? t : Pn)(r)
                    }) : this.then(null, function(r) {
                        return (r && r.name === n ? t : Pn)(r)
                    })
                },
                finally: function(e) {
                    return this.then(function(n) {
                        return A.resolve(e()).then(function() {
                            return n
                        })
                    }, function(n) {
                        return A.resolve(e()).then(function() {
                            return Pn(n)
                        })
                    })
                },
                timeout: function(e, n) {
                    var t = this;
                    return e < 1 / 0 ? new A(function(r, o) {
                        var i = setTimeout(function() {
                            return o(new K.Timeout(n))
                        }, e);
                        t.then(r, o).finally(clearTimeout.bind(null, i))
                    }) : this
                }
            }), typeof Symbol < "u" && Symbol.toStringTag && xe(A.prototype, Symbol.toStringTag, "Dexie.Promise"), ke.env = Jt(), Ue(A, {
                all: function() {
                    var e = ye.apply(null, arguments).map(Sn);
                    return new A(function(n, t) {
                        e.length === 0 && n([]);
                        var r = e.length;
                        e.forEach(function(o, i) {
                            return A.resolve(o).then(function(a) {
                                e[i] = a, --r || n(e)
                            }, t)
                        })
                    })
                },
                resolve: function(e) {
                    return e instanceof A ? e : e && typeof e.then == "function" ? new A(function(n, t) {
                        e.then(n, t)
                    }) : new A(tn, !0, e)
                },
                reject: Pn,
                race: function() {
                    var e = ye.apply(null, arguments).map(Sn);
                    return new A(function(n, t) {
                        e.map(function(r) {
                            return A.resolve(r).then(n, t)
                        })
                    })
                },
                PSD: {
                    get: function() {
                        return S
                    },
                    set: function(e) {
                        return S = e
                    }
                },
                totalEchoes: {
                    get: function() {
                        return In
                    }
                },
                newPSD: Oe,
                usePSD: Re,
                scheduler: {
                    get: function() {
                        return an
                    },
                    set: function(e) {
                        an = e
                    }
                },
                rejectionMapper: {
                    get: function() {
                        return ot
                    },
                    set: function(e) {
                        ot = e
                    }
                },
                follow: function(e, n) {
                    return new A(function(t, r) {
                        return Oe(function(o, i) {
                            var a = S;
                            a.unhandleds = [], a.onunhandled = i, a.finalize = De(function() {
                                var u, f = this;
                                u = function() {
                                    f.unhandleds.length === 0 ? o() : i(f.unhandleds[0])
                                }, On.push(function c() {
                                    u(), On.splice(On.indexOf(c), 1)
                                }), ++je, an(function() {
                                    --je == 0 && st()
                                }, [])
                            }, a.finalize), e()
                        }, n, t, r)
                    })
                }
            }), on && (on.allSettled && xe(A, "allSettled", function() {
                var e = ye.apply(null, arguments).map(Sn);
                return new A(function(n) {
                    e.length === 0 && n([]);
                    var t = e.length,
                        r = new Array(t);
                    e.forEach(function(o, i) {
                        return A.resolve(o).then(function(a) {
                            return r[i] = {
                                status: "fulfilled",
                                value: a
                            }
                        }, function(a) {
                            return r[i] = {
                                status: "rejected",
                                reason: a
                            }
                        }).then(function() {
                            return --t || n(r)
                        })
                    })
                })
            }), on.any && typeof AggregateError < "u" && xe(A, "any", function() {
                var e = ye.apply(null, arguments).map(Sn);
                return new A(function(n, t) {
                    e.length === 0 && t(new AggregateError([]));
                    var r = e.length,
                        o = new Array(r);
                    e.forEach(function(i, a) {
                        return A.resolve(i).then(function(u) {
                            return n(u)
                        }, function(u) {
                            o[a] = u, --r || t(new AggregateError(o))
                        })
                    })
                })
            }));
            var J = {
                    awaits: 0,
                    echoes: 0,
                    id: 0
                },
                Zr = 0,
                En = [],
                An = 0,
                In = 0,
                eo = 0;

            function Oe(e, n, t, r) {
                var o = S,
                    i = Object.create(o);
                return i.parent = o, i.ref = 0, i.global = !1, i.id = ++eo, ke.env, i.env = tt ? {
                    Promise: A,
                    PromiseProp: {
                        value: A,
                        configurable: !0,
                        writable: !0
                    },
                    all: A.all,
                    race: A.race,
                    allSettled: A.allSettled,
                    any: A.any,
                    resolve: A.resolve,
                    reject: A.reject
                } : {}, n && U(i, n), ++o.ref, i.finalize = function() {
                    --this.parent.ref || this.parent.finalize()
                }, r = Re(i, e, t, r), i.ref === 0 && i.finalize(), r
            }

            function Qe() {
                return J.id || (J.id = ++Zr), ++J.awaits, J.echoes += Gt, J.id
            }

            function Pe() {
                return !!J.awaits && (--J.awaits == 0 && (J.id = 0), J.echoes = J.awaits * Gt, !0)
            }

            function Sn(e) {
                return J.echoes && e && e.constructor === on ? (Qe(), e.then(function(n) {
                    return Pe(), n
                }, function(n) {
                    return Pe(), H(n)
                })) : e
            }

            function no() {
                var e = En[En.length - 1];
                En.pop(), Ee(e, !1)
            }

            function Ee(e, n) {
                var t, r = S;
                (n ? !J.echoes || An++ && e === S : !An || --An && e === S) || queueMicrotask(n ? function(o) {
                    ++In, J.echoes && --J.echoes != 0 || (J.echoes = J.awaits = J.id = 0), En.push(S), Ee(o, !0)
                }.bind(null, e) : no), e !== S && (S = e, r === ke && (ke.env = Jt()), tt && (t = ke.env.Promise, n = e.env, (r.global || e.global) && (Object.defineProperty(R, "Promise", n.PromiseProp), t.all = n.all, t.race = n.race, t.resolve = n.resolve, t.reject = n.reject, n.allSettled && (t.allSettled = n.allSettled), n.any && (t.any = n.any))))
            }

            function Jt() {
                var e = R.Promise;
                return tt ? {
                    Promise: e,
                    PromiseProp: Object.getOwnPropertyDescriptor(R, "Promise"),
                    all: e.all,
                    race: e.race,
                    allSettled: e.allSettled,
                    any: e.any,
                    resolve: e.resolve,
                    reject: e.reject
                } : {}
            }

            function Re(e, n, t, r, o) {
                var i = S;
                try {
                    return Ee(e, !0), n(t, r, o)
                } finally {
                    Ee(i, !1)
                }
            }

            function Zt(e, n, t, r) {
                return typeof e != "function" ? e : function() {
                    var o = S;
                    t && Qe(), Ee(n, !0);
                    try {
                        return e.apply(this, arguments)
                    } finally {
                        Ee(o, !1), r && queueMicrotask(Pe)
                    }
                }
            }

            function ct(e) {
                Promise === on && J.echoes === 0 ? An === 0 ? e() : enqueueNativeMicroTask(e) : setTimeout(e, 0)
            }("" + se).indexOf("[native code]") === -1 && (Qe = Pe = $);
            var H = A.reject,
                qe = "￿",
                ve = "Invalid key provided. Keys must be of type string, number, Date or Array<string | number | Date>.",
                er = "String expected.",
                Ge = [],
                Cn = "__dbnames",
                lt = "readonly",
                ft = "readwrite";

            function Be(e, n) {
                return e ? n ? function() {
                    return e.apply(this, arguments) && n.apply(this, arguments)
                } : e : n
            }
            var nr = {
                type: 3,
                lower: -1 / 0,
                lowerOpen: !1,
                upper: [
                    []
                ],
                upperOpen: !1
            };

            function Kn(e) {
                return typeof e != "string" || /\./.test(e) ? function(n) {
                    return n
                } : function(n) {
                    return n[e] === void 0 && e in n && delete(n = Ce(n))[e], n
                }
            }

            function tr() {
                throw K.Type()
            }

            function L(e, n) {
                try {
                    var t = rr(e),
                        r = rr(n);
                    if (t !== r) return t === "Array" ? 1 : r === "Array" ? -1 : t === "binary" ? 1 : r === "binary" ? -1 : t === "string" ? 1 : r === "string" ? -1 : t === "Date" ? 1 : r !== "Date" ? NaN : -1;
                    switch (t) {
                        case "number":
                        case "Date":
                        case "string":
                            return n < e ? 1 : e < n ? -1 : 0;
                        case "binary":
                            return (function(o, i) {
                                for (var a = o.length, u = i.length, f = a < u ? a : u, c = 0; c < f; ++c)
                                    if (o[c] !== i[c]) return o[c] < i[c] ? -1 : 1;
                                return a === u ? 0 : a < u ? -1 : 1
                            })(or(e), or(n));
                        case "Array":
                            return (function(o, i) {
                                for (var a = o.length, u = i.length, f = a < u ? a : u, c = 0; c < f; ++c) {
                                    var p = L(o[c], i[c]);
                                    if (p !== 0) return p
                                }
                                return a === u ? 0 : a < u ? -1 : 1
                            })(e, n)
                    }
                } catch (o) {}
                return NaN
            }

            function rr(e) {
                var n = typeof e;
                return n != "object" ? n : ArrayBuffer.isView(e) ? "binary" : (e = Xn(e), e === "ArrayBuffer" ? "binary" : e)
            }

            function or(e) {
                return e instanceof Uint8Array ? e : ArrayBuffer.isView(e) ? new Uint8Array(e.buffer, e.byteOffset, e.byteLength) : new Uint8Array(e)
            }
            var ir = (Q.prototype._trans = function(e, n, t) {
                var r = this._tx || S.trans,
                    o = this.name,
                    i = le && typeof console < "u" && console.createTask && console.createTask("Dexie: ".concat(e === "readonly" ? "read" : "write", " ").concat(this.name));

                function a(c, p, s) {
                    if (!s.schema[o]) throw new K.NotFound("Table " + o + " not part of transaction");
                    return n(s.idbtrans, s)
                }
                var u = We();
                try {
                    var f = r && r.db._novip === this.db._novip ? r === S.trans ? r._promise(e, a, t) : Oe(function() {
                        return r._promise(e, a, t)
                    }, {
                        trans: r,
                        transless: S.transless || S
                    }) : (function c(p, s, y, l) {
                        if (p.idbdb && (p._state.openComplete || S.letThrough || p._vip)) {
                            var d = p._createTransaction(s, y, p._dbSchema);
                            try {
                                d.create(), p._state.PR1398_maxLoop = 3
                            } catch (v) {
                                return v.name === et.InvalidState && p.isOpen() && 0 < --p._state.PR1398_maxLoop ? (console.warn("Dexie: Need to reopen db"), p.close({
                                    disableAutoOpen: !1
                                }), p.open().then(function() {
                                    return c(p, s, y, l)
                                })) : H(v)
                            }
                            return d._promise(s, function(v, h) {
                                return Oe(function() {
                                    return S.trans = d, l(v, h, d)
                                })
                            }).then(function(v) {
                                if (s === "readwrite") try {
                                    d.idbtrans.commit()
                                } catch (h) {}
                                return s === "readonly" ? v : d._completion.then(function() {
                                    return v
                                })
                            })
                        }
                        if (p._state.openComplete) return H(new K.DatabaseClosed(p._state.dbOpenError));
                        if (!p._state.isBeingOpened) {
                            if (!p._state.autoOpen) return H(new K.DatabaseClosed);
                            p.open().catch($)
                        }
                        return p._state.dbReadyPromise.then(function() {
                            return c(p, s, y, l)
                        })
                    })(this.db, e, [this.name], a);
                    return i && (f._consoleTask = i, f = f.catch(function(c) {
                        return console.trace(c), H(c)
                    })), f
                } finally {
                    u && Ye()
                }
            }, Q.prototype.get = function(e, n) {
                var t = this;
                return e && e.constructor === Object ? this.where(e).first(n) : e == null ? H(new K.Type("Invalid argument to Table.get()")) : this._trans("readonly", function(r) {
                    return t.core.get({
                        trans: r,
                        key: e
                    }).then(function(o) {
                        return t.hook.reading.fire(o)
                    })
                }).then(n)
            }, Q.prototype.where = function(e) {
                if (typeof e == "string") return new this.db.WhereClause(this, e);
                if (D(e)) return new this.db.WhereClause(this, "[".concat(e.join("+"), "]"));
                var n = W(e);
                if (n.length === 1) return this.where(n[0]).equals(e[n[0]]);
                var t = this.schema.indexes.concat(this.schema.primKey).filter(function(f) {
                    if (f.compound && n.every(function(p) {
                            return 0 <= f.keyPath.indexOf(p)
                        })) {
                        for (var c = 0; c < n.length; ++c)
                            if (n.indexOf(f.keyPath[c]) === -1) return !1;
                        return !0
                    }
                    return !1
                }).sort(function(f, c) {
                    return f.keyPath.length - c.keyPath.length
                })[0];
                if (t && this.db._maxKey !== qe) {
                    var a = t.keyPath.slice(0, n.length);
                    return this.where(a).equals(a.map(function(c) {
                        return e[c]
                    }))
                }!t && le && console.warn("The query ".concat(JSON.stringify(e), " on ").concat(this.name, " would benefit from a ") + "compound index [".concat(n.join("+"), "]"));
                var r = this.schema.idxByName,
                    o = this.db._deps.indexedDB;

                function i(f, c) {
                    return o.cmp(f, c) === 0
                }
                var u = n.reduce(function(y, c) {
                        var p = y[0],
                            s = y[1],
                            y = r[c],
                            l = e[c];
                        return [p || y, p || !y ? Be(s, y && y.multi ? function(d) {
                            return d = pe(d, c), D(d) && d.some(function(v) {
                                return i(l, v)
                            })
                        } : function(d) {
                            return i(l, pe(d, c))
                        }) : s]
                    }, [null, null]),
                    a = u[0],
                    u = u[1];
                return a ? this.where(a.name).equals(e[a.keyPath]).filter(u) : t ? this.filter(u) : this.where(n).equals("")
            }, Q.prototype.filter = function(e) {
                return this.toCollection().and(e)
            }, Q.prototype.count = function(e) {
                return this.toCollection().count(e)
            }, Q.prototype.offset = function(e) {
                return this.toCollection().offset(e)
            }, Q.prototype.limit = function(e) {
                return this.toCollection().limit(e)
            }, Q.prototype.each = function(e) {
                return this.toCollection().each(e)
            }, Q.prototype.toArray = function(e) {
                return this.toCollection().toArray(e)
            }, Q.prototype.toCollection = function() {
                return new this.db.Collection(new this.db.WhereClause(this))
            }, Q.prototype.orderBy = function(e) {
                return new this.db.Collection(new this.db.WhereClause(this, D(e) ? "[".concat(e.join("+"), "]") : e))
            }, Q.prototype.reverse = function() {
                return this.toCollection().reverse()
            }, Q.prototype.mapToClass = function(e) {
                var n, t = this.db,
                    r = this.name;

                function o() {
                    return n !== null && n.apply(this, arguments) || this
                }(this.schema.mappedClass = e).prototype instanceof tr && ((function(f, c) {
                    if (typeof c != "function" && c !== null) throw new TypeError("Class extends value " + String(c) + " is not a constructor or null");

                    function p() {
                        this.constructor = f
                    }
                    F(f, c), f.prototype = c === null ? Object.create(c) : (p.prototype = c.prototype, new p)
                })(o, n = e), Object.defineProperty(o.prototype, "db", {
                    get: function() {
                        return t
                    },
                    enumerable: !1,
                    configurable: !0
                }), o.prototype.table = function() {
                    return r
                }, e = o);
                for (var i = new Set, a = e.prototype; a; a = z(a)) Object.getOwnPropertyNames(a).forEach(function(f) {
                    return i.add(f)
                });

                function u(f) {
                    if (!f) return f;
                    var c, p = Object.create(e.prototype);
                    for (c in f)
                        if (!i.has(c)) try {
                            p[c] = f[c]
                        } catch (s) {}
                    return p
                }
                return this.schema.readHook && this.hook.reading.unsubscribe(this.schema.readHook), this.schema.readHook = u, this.hook("reading", u), e
            }, Q.prototype.defineClass = function() {
                return this.mapToClass(function(e) {
                    U(this, e)
                })
            }, Q.prototype.add = function(e, n) {
                var t = this,
                    r = this.schema.primKey,
                    o = r.auto,
                    i = r.keyPath,
                    a = e;
                return i && o && (a = Kn(i)(e)), this._trans("readwrite", function(u) {
                    return t.core.mutate({
                        trans: u,
                        type: "add",
                        keys: n != null ? [n] : null,
                        values: [a]
                    })
                }).then(function(u) {
                    return u.numFailures ? A.reject(u.failures[0]) : u.lastResult
                }).then(function(u) {
                    if (i) try {
                        ae(e, i, u)
                    } catch (f) {}
                    return u
                })
            }, Q.prototype.update = function(e, n) {
                return typeof e != "object" || D(e) ? this.where(":id").equals(e).modify(n) : (e = pe(e, this.schema.primKey.keyPath), e === void 0 ? H(new K.InvalidArgument("Given object does not contain its primary key")) : this.where(":id").equals(e).modify(n))
            }, Q.prototype.put = function(e, n) {
                var t = this,
                    r = this.schema.primKey,
                    o = r.auto,
                    i = r.keyPath,
                    a = e;
                return i && o && (a = Kn(i)(e)), this._trans("readwrite", function(u) {
                    return t.core.mutate({
                        trans: u,
                        type: "put",
                        values: [a],
                        keys: n != null ? [n] : null
                    })
                }).then(function(u) {
                    return u.numFailures ? A.reject(u.failures[0]) : u.lastResult
                }).then(function(u) {
                    if (i) try {
                        ae(e, i, u)
                    } catch (f) {}
                    return u
                })
            }, Q.prototype.delete = function(e) {
                var n = this;
                return this._trans("readwrite", function(t) {
                    return n.core.mutate({
                        trans: t,
                        type: "delete",
                        keys: [e]
                    })
                }).then(function(t) {
                    return t.numFailures ? A.reject(t.failures[0]) : void 0
                })
            }, Q.prototype.clear = function() {
                var e = this;
                return this._trans("readwrite", function(n) {
                    return e.core.mutate({
                        trans: n,
                        type: "deleteRange",
                        range: nr
                    })
                }).then(function(n) {
                    return n.numFailures ? A.reject(n.failures[0]) : void 0
                })
            }, Q.prototype.bulkGet = function(e) {
                var n = this;
                return this._trans("readonly", function(t) {
                    return n.core.getMany({
                        keys: e,
                        trans: t
                    }).then(function(r) {
                        return r.map(function(o) {
                            return n.hook.reading.fire(o)
                        })
                    })
                })
            }, Q.prototype.bulkAdd = function(e, n, t) {
                var r = this,
                    o = Array.isArray(n) ? n : void 0,
                    i = (t = t || (o ? void 0 : n)) ? t.allKeys : void 0;
                return this._trans("readwrite", function(a) {
                    var c = r.schema.primKey,
                        u = c.auto,
                        c = c.keyPath;
                    if (c && o) throw new K.InvalidArgument("bulkAdd(): keys argument invalid on tables with inbound keys");
                    if (o && o.length !== e.length) throw new K.InvalidArgument("Arguments objects and keys must have the same length");
                    var f = e.length,
                        c = c && u ? e.map(Kn(c)) : e;
                    return r.core.mutate({
                        trans: a,
                        type: "add",
                        keys: o,
                        values: c,
                        wantResults: i
                    }).then(function(d) {
                        var s = d.numFailures,
                            y = d.results,
                            l = d.lastResult,
                            d = d.failures;
                        if (s === 0) return i ? y : l;
                        throw new $e("".concat(r.name, ".bulkAdd(): ").concat(s, " of ").concat(f, " operations failed"), d)
                    })
                })
            }, Q.prototype.bulkPut = function(e, n, t) {
                var r = this,
                    o = Array.isArray(n) ? n : void 0,
                    i = (t = t || (o ? void 0 : n)) ? t.allKeys : void 0;
                return this._trans("readwrite", function(a) {
                    var c = r.schema.primKey,
                        u = c.auto,
                        c = c.keyPath;
                    if (c && o) throw new K.InvalidArgument("bulkPut(): keys argument invalid on tables with inbound keys");
                    if (o && o.length !== e.length) throw new K.InvalidArgument("Arguments objects and keys must have the same length");
                    var f = e.length,
                        c = c && u ? e.map(Kn(c)) : e;
                    return r.core.mutate({
                        trans: a,
                        type: "put",
                        keys: o,
                        values: c,
                        wantResults: i
                    }).then(function(d) {
                        var s = d.numFailures,
                            y = d.results,
                            l = d.lastResult,
                            d = d.failures;
                        if (s === 0) return i ? y : l;
                        throw new $e("".concat(r.name, ".bulkPut(): ").concat(s, " of ").concat(f, " operations failed"), d)
                    })
                })
            }, Q.prototype.bulkUpdate = function(e) {
                var n = this,
                    t = this.core,
                    r = e.map(function(a) {
                        return a.key
                    }),
                    o = e.map(function(a) {
                        return a.changes
                    }),
                    i = [];
                return this._trans("readwrite", function(a) {
                    return t.getMany({
                        trans: a,
                        keys: r,
                        cache: "clone"
                    }).then(function(u) {
                        var f = [],
                            c = [];
                        e.forEach(function(s, y) {
                            var l = s.key,
                                d = s.changes,
                                v = u[y];
                            if (v) {
                                for (var h = 0, m = Object.keys(d); h < m.length; h++) {
                                    var g = m[h],
                                        b = d[g];
                                    if (g === n.schema.primKey.keyPath) {
                                        if (L(b, l) !== 0) throw new K.Constraint("Cannot update primary key in bulkUpdate()")
                                    } else ae(v, g, b)
                                }
                                i.push(y), f.push(l), c.push(v)
                            }
                        });
                        var p = f.length;
                        return t.mutate({
                            trans: a,
                            type: "put",
                            keys: f,
                            values: c,
                            updates: {
                                keys: r,
                                changeSpecs: o
                            }
                        }).then(function(s) {
                            var y = s.numFailures,
                                l = s.failures;
                            if (y === 0) return p;
                            for (var d = 0, v = Object.keys(l); d < v.length; d++) {
                                var h, m = v[d],
                                    g = i[Number(m)];
                                g != null && (h = l[m], delete l[m], l[g] = h)
                            }
                            throw new $e("".concat(n.name, ".bulkUpdate(): ").concat(y, " of ").concat(p, " operations failed"), l)
                        })
                    })
                })
            }, Q.prototype.bulkDelete = function(e) {
                var n = this,
                    t = e.length;
                return this._trans("readwrite", function(r) {
                    return n.core.mutate({
                        trans: r,
                        type: "delete",
                        keys: e
                    })
                }).then(function(a) {
                    var o = a.numFailures,
                        i = a.lastResult,
                        a = a.failures;
                    if (o === 0) return i;
                    throw new $e("".concat(n.name, ".bulkDelete(): ").concat(o, " of ").concat(t, " operations failed"), a)
                })
            }, Q);

            function Q() {}

            function sn(e) {
                function n(a, u) {
                    if (u) {
                        for (var f = arguments.length, c = new Array(f - 1); --f;) c[f - 1] = arguments[f];
                        return t[a].subscribe.apply(null, c), e
                    }
                    if (typeof a == "string") return t[a]
                }
                var t = {};
                n.addEventType = i;
                for (var r = 1, o = arguments.length; r < o; ++r) i(arguments[r]);
                return n;

                function i(a, u, f) {
                    if (typeof a != "object") {
                        var c;
                        u = u || Hr;
                        var p = {
                            subscribers: [],
                            fire: f = f || $,
                            subscribe: function(s) {
                                p.subscribers.indexOf(s) === -1 && (p.subscribers.push(s), p.fire = u(p.fire, s))
                            },
                            unsubscribe: function(s) {
                                p.subscribers = p.subscribers.filter(function(y) {
                                    return y !== s
                                }), p.fire = p.subscribers.reduce(u, f)
                            }
                        };
                        return t[a] = n[a] = p
                    }
                    W(c = a).forEach(function(s) {
                        var y = c[s];
                        if (D(y)) i(s, c[s][0], c[s][1]);
                        else {
                            if (y !== "asap") throw new K.InvalidArgument("Invalid event config");
                            var l = i(s, nn, function() {
                                for (var d = arguments.length, v = new Array(d); d--;) v[d] = arguments[d];
                                l.subscribers.forEach(function(h) {
                                    Lt(function() {
                                        h.apply(null, v)
                                    })
                                })
                            })
                        }
                    })
                }
            }

            function cn(e, n) {
                return Le(n).from({
                    prototype: e
                }), n
            }

            function He(e, n) {
                return !(e.filter || e.algorithm || e.or) && (n ? e.justLimit : !e.replayFilter)
            }

            function ht(e, n) {
                e.filter = Be(e.filter, n)
            }

            function dt(e, n, t) {
                var r = e.replayFilter;
                e.replayFilter = r ? function() {
                    return Be(r(), n())
                } : n, e.justLimit = t && !r
            }

            function Dn(e, n) {
                if (e.isPrimKey) return n.primaryKey;
                var t = n.getIndexByKeyPath(e.index);
                if (!t) throw new K.Schema("KeyPath " + e.index + " on object store " + n.name + " is not indexed");
                return t
            }

            function ar(e, n, t) {
                var r = Dn(e, n.schema);
                return n.openCursor({
                    trans: t,
                    values: !e.keysOnly,
                    reverse: e.dir === "prev",
                    unique: !!e.unique,
                    query: {
                        index: r,
                        range: e.range
                    }
                })
            }

            function Tn(e, n, t, r) {
                var o = e.replayFilter ? Be(e.filter, e.replayFilter()) : e.filter;
                if (e.or) {
                    var i = {},
                        a = function(u, f, c) {
                            var p, s;
                            o && !o(f, c, function(y) {
                                return f.stop(y)
                            }, function(y) {
                                return f.fail(y)
                            }) || ((s = "" + (p = f.primaryKey)) == "[object ArrayBuffer]" && (s = "" + new Uint8Array(p)), Y(i, s) || (i[s] = !0, n(u, f, c)))
                        };
                    return Promise.all([e.or._iterate(a, t), ur(ar(e, r, t), e.algorithm, a, !e.keysOnly && e.valueMapper)])
                }
                return ur(ar(e, r, t), Be(e.algorithm, o), n, !e.keysOnly && e.valueMapper)
            }

            function ur(e, n, t, r) {
                var o = G(r ? function(i, a, u) {
                    return t(r(i), a, u)
                } : t);
                return e.then(function(i) {
                    if (i) return i.start(function() {
                        var a = function() {
                            return i.continue()
                        };
                        n && !n(i, function(u) {
                            return a = u
                        }, function(u) {
                            i.stop(u), a = $
                        }, function(u) {
                            i.fail(u), a = $
                        }) || o(i.value, i, function(u) {
                            return a = u
                        }), a()
                    })
                })
            }
            var me = Symbol(),
                ln = (sr.prototype.execute = function(e) {
                    if (this.add !== void 0) {
                        var n = this.add;
                        if (D(n)) return ee(ee([], D(e) ? e : [], !0), n).sort();
                        if (typeof n == "number") return (Number(e) || 0) + n;
                        if (typeof n == "bigint") try {
                            return BigInt(e) + n
                        } catch (r) {
                            return BigInt(0) + n
                        }
                        throw new TypeError("Invalid term ".concat(n))
                    }
                    if (this.remove !== void 0) {
                        var t = this.remove;
                        if (D(t)) return D(e) ? e.filter(function(r) {
                            return !t.includes(r)
                        }).sort() : [];
                        if (typeof t == "number") return Number(e) - t;
                        if (typeof t == "bigint") try {
                            return BigInt(e) - t
                        } catch (r) {
                            return BigInt(0) - t
                        }
                        throw new TypeError("Invalid subtrahend ".concat(t))
                    }
                    return n = (n = this.replacePrefix) === null || n === void 0 ? void 0 : n[0], n && typeof e == "string" && e.startsWith(n) ? this.replacePrefix[1] + e.substring(n.length) : e
                }, sr);

            function sr(e) {
                Object.assign(this, e)
            }
            var to = (V.prototype._read = function(e, n) {
                var t = this._ctx;
                return t.error ? t.table._trans(null, H.bind(null, t.error)) : t.table._trans("readonly", e).then(n)
            }, V.prototype._write = function(e) {
                var n = this._ctx;
                return n.error ? n.table._trans(null, H.bind(null, n.error)) : n.table._trans("readwrite", e, "locked")
            }, V.prototype._addAlgorithm = function(e) {
                var n = this._ctx;
                n.algorithm = Be(n.algorithm, e)
            }, V.prototype._iterate = function(e, n) {
                return Tn(this._ctx, e, n, this._ctx.table.core)
            }, V.prototype.clone = function(e) {
                var n = Object.create(this.constructor.prototype),
                    t = Object.create(this._ctx);
                return e && U(t, e), n._ctx = t, n
            }, V.prototype.raw = function() {
                return this._ctx.valueMapper = null, this
            }, V.prototype.each = function(e) {
                var n = this._ctx;
                return this._read(function(t) {
                    return Tn(n, e, t, n.table.core)
                })
            }, V.prototype.count = function(e) {
                var n = this;
                return this._read(function(t) {
                    var r = n._ctx,
                        o = r.table.core;
                    if (He(r, !0)) return o.count({
                        trans: t,
                        query: {
                            index: Dn(r, o.schema),
                            range: r.range
                        }
                    }).then(function(a) {
                        return Math.min(a, r.limit)
                    });
                    var i = 0;
                    return Tn(r, function() {
                        return ++i, !1
                    }, t, o).then(function() {
                        return i
                    })
                }).then(e)
            }, V.prototype.sortBy = function(e, n) {
                var t = e.split(".").reverse(),
                    r = t[0],
                    o = t.length - 1;

                function i(f, c) {
                    return c ? i(f[t[c]], c - 1) : f[r]
                }
                var a = this._ctx.dir === "next" ? 1 : -1;

                function u(f, c) {
                    return f = i(f, o), c = i(c, o), f < c ? -a : c < f ? a : 0
                }
                return this.toArray(function(f) {
                    return f.sort(u)
                }).then(n)
            }, V.prototype.toArray = function(e) {
                var n = this;
                return this._read(function(t) {
                    var r = n._ctx;
                    if (r.dir === "next" && He(r, !0) && 0 < r.limit) {
                        var o = r.valueMapper,
                            i = Dn(r, r.table.core.schema);
                        return r.table.core.query({
                            trans: t,
                            limit: r.limit,
                            values: !0,
                            query: {
                                index: i,
                                range: r.range
                            }
                        }).then(function(u) {
                            return u = u.result, o ? u.map(o) : u
                        })
                    }
                    var a = [];
                    return Tn(r, function(u) {
                        return a.push(u)
                    }, t, r.table.core).then(function() {
                        return a
                    })
                }, e)
            }, V.prototype.offset = function(e) {
                var n = this._ctx;
                return e <= 0 || (n.offset += e, He(n) ? dt(n, function() {
                    var t = e;
                    return function(r, o) {
                        return t === 0 || (t === 1 ? --t : o(function() {
                            r.advance(t), t = 0
                        }), !1)
                    }
                }) : dt(n, function() {
                    var t = e;
                    return function() {
                        return --t < 0
                    }
                })), this
            }, V.prototype.limit = function(e) {
                return this._ctx.limit = Math.min(this._ctx.limit, e), dt(this._ctx, function() {
                    var n = e;
                    return function(t, r, o) {
                        return --n <= 0 && r(o), 0 <= n
                    }
                }, !0), this
            }, V.prototype.until = function(e, n) {
                return ht(this._ctx, function(t, r, o) {
                    return !e(t.value) || (r(o), n)
                }), this
            }, V.prototype.first = function(e) {
                return this.limit(1).toArray(function(n) {
                    return n[0]
                }).then(e)
            }, V.prototype.last = function(e) {
                return this.reverse().first(e)
            }, V.prototype.filter = function(e) {
                var n;
                return ht(this._ctx, function(t) {
                    return e(t.value)
                }), (n = this._ctx).isMatch = Be(n.isMatch, e), this
            }, V.prototype.and = function(e) {
                return this.filter(e)
            }, V.prototype.or = function(e) {
                return new this.db.WhereClause(this._ctx.table, e, this)
            }, V.prototype.reverse = function() {
                return this._ctx.dir = this._ctx.dir === "prev" ? "next" : "prev", this._ondirectionchange && this._ondirectionchange(this._ctx.dir), this
            }, V.prototype.desc = function() {
                return this.reverse()
            }, V.prototype.eachKey = function(e) {
                var n = this._ctx;
                return n.keysOnly = !n.isMatch, this.each(function(t, r) {
                    e(r.key, r)
                })
            }, V.prototype.eachUniqueKey = function(e) {
                return this._ctx.unique = "unique", this.eachKey(e)
            }, V.prototype.eachPrimaryKey = function(e) {
                var n = this._ctx;
                return n.keysOnly = !n.isMatch, this.each(function(t, r) {
                    e(r.primaryKey, r)
                })
            }, V.prototype.keys = function(e) {
                var n = this._ctx;
                n.keysOnly = !n.isMatch;
                var t = [];
                return this.each(function(r, o) {
                    t.push(o.key)
                }).then(function() {
                    return t
                }).then(e)
            }, V.prototype.primaryKeys = function(e) {
                var n = this._ctx;
                if (n.dir === "next" && He(n, !0) && 0 < n.limit) return this._read(function(r) {
                    var o = Dn(n, n.table.core.schema);
                    return n.table.core.query({
                        trans: r,
                        values: !1,
                        limit: n.limit,
                        query: {
                            index: o,
                            range: n.range
                        }
                    })
                }).then(function(r) {
                    return r.result
                }).then(e);
                n.keysOnly = !n.isMatch;
                var t = [];
                return this.each(function(r, o) {
                    t.push(o.primaryKey)
                }).then(function() {
                    return t
                }).then(e)
            }, V.prototype.uniqueKeys = function(e) {
                return this._ctx.unique = "unique", this.keys(e)
            }, V.prototype.firstKey = function(e) {
                return this.limit(1).keys(function(n) {
                    return n[0]
                }).then(e)
            }, V.prototype.lastKey = function(e) {
                return this.reverse().firstKey(e)
            }, V.prototype.distinct = function() {
                var e = this._ctx,
                    e = e.index && e.table.schema.idxByName[e.index];
                if (!e || !e.multi) return this;
                var n = {};
                return ht(this._ctx, function(o) {
                    var r = o.primaryKey.toString(),
                        o = Y(n, r);
                    return n[r] = !0, !o
                }), this
            }, V.prototype.modify = function(e) {
                var n = this,
                    t = this._ctx;
                return this._write(function(r) {
                    var o, i, a;
                    a = typeof e == "function" ? e : (o = W(e), i = o.length, function(h) {
                        for (var m = !1, g = 0; g < i; ++g) {
                            var b = o[g],
                                w = e[b],
                                x = pe(h, b);
                            w instanceof ln ? (ae(h, b, w.execute(x)), m = !0) : x !== w && (ae(h, b, w), m = !0)
                        }
                        return m
                    });

                    function u(h, b) {
                        var g = b.failures,
                            b = b.numFailures;
                        d += h - b;
                        for (var w = 0, x = W(g); w < x.length; w++) {
                            var P = x[w];
                            l.push(g[P])
                        }
                    }
                    var f = t.table.core,
                        c = f.schema.primaryKey,
                        p = c.outbound,
                        s = c.extractKey,
                        y = n.db._options.modifyChunkSize || 200,
                        l = [],
                        d = 0,
                        v = [];
                    return n.clone().primaryKeys().then(function(h) {
                        function m(b) {
                            var w = Math.min(y, h.length - b);
                            return f.getMany({
                                trans: r,
                                keys: h.slice(b, b + w),
                                cache: "immutable"
                            }).then(function(x) {
                                for (var P = [], k = [], O = p ? [] : null, E = [], _ = 0; _ < w; ++_) {
                                    var T = x[_],
                                        j = {
                                            value: Ce(T),
                                            primKey: h[b + _]
                                        };
                                    a.call(j, j.value, j) !== !1 && (j.value == null ? E.push(h[b + _]) : p || L(s(T), s(j.value)) === 0 ? (k.push(j.value), p && O.push(h[b + _])) : (E.push(h[b + _]), P.push(j.value)))
                                }
                                return Promise.resolve(0 < P.length && f.mutate({
                                    trans: r,
                                    type: "add",
                                    values: P
                                }).then(function(M) {
                                    for (var q in M.failures) E.splice(parseInt(q), 1);
                                    u(P.length, M)
                                })).then(function() {
                                    return (0 < k.length || g && typeof e == "object") && f.mutate({
                                        trans: r,
                                        type: "put",
                                        keys: O,
                                        values: k,
                                        criteria: g,
                                        changeSpec: typeof e != "function" && e,
                                        isAdditionalChunk: 0 < b
                                    }).then(function(M) {
                                        return u(k.length, M)
                                    })
                                }).then(function() {
                                    return (0 < E.length || g && e === pt) && f.mutate({
                                        trans: r,
                                        type: "delete",
                                        keys: E,
                                        criteria: g,
                                        isAdditionalChunk: 0 < b
                                    }).then(function(M) {
                                        return u(E.length, M)
                                    })
                                }).then(function() {
                                    return h.length > b + w && m(b + y)
                                })
                            })
                        }
                        var g = He(t) && t.limit === 1 / 0 && (typeof e != "function" || e === pt) && {
                            index: t.index,
                            range: t.range
                        };
                        return m(0).then(function() {
                            if (0 < l.length) throw new wn("Error modifying one or more objects", l, d, v);
                            return h.length
                        })
                    })
                })
            }, V.prototype.delete = function() {
                var e = this._ctx,
                    n = e.range;
                return He(e) && (e.isPrimKey || n.type === 3) ? this._write(function(t) {
                    var r = e.table.core.schema.primaryKey,
                        o = n;
                    return e.table.core.count({
                        trans: t,
                        query: {
                            index: r,
                            range: o
                        }
                    }).then(function(i) {
                        return e.table.core.mutate({
                            trans: t,
                            type: "deleteRange",
                            range: o
                        }).then(function(a) {
                            var u = a.failures;
                            if (a.lastResult, a.results, a = a.numFailures, a) throw new wn("Could not delete some values", Object.keys(u).map(function(f) {
                                return u[f]
                            }), i - a);
                            return i - a
                        })
                    })
                }) : this.modify(pt)
            }, V);

            function V() {}
            var pt = function(e, n) {
                return n.value = null
            };

            function ro(e, n) {
                return e < n ? -1 : e === n ? 0 : 1
            }

            function oo(e, n) {
                return n < e ? -1 : e === n ? 0 : 1
            }

            function ue(e, n, t) {
                return e = e instanceof lr ? new e.Collection(e) : e, e._ctx.error = new(t || TypeError)(n), e
            }

            function Xe(e) {
                return new e.Collection(e, function() {
                    return cr("")
                }).limit(0)
            }

            function jn(e, n, t, r) {
                var o, i, a, u, f, c, p, s = t.length;
                if (!t.every(function(d) {
                        return typeof d == "string"
                    })) return ue(e, er);

                function y(d) {
                    o = d === "next" ? function(h) {
                        return h.toUpperCase()
                    } : function(h) {
                        return h.toLowerCase()
                    }, i = d === "next" ? function(h) {
                        return h.toLowerCase()
                    } : function(h) {
                        return h.toUpperCase()
                    }, a = d === "next" ? ro : oo;
                    var v = t.map(function(h) {
                        return {
                            lower: i(h),
                            upper: o(h)
                        }
                    }).sort(function(h, m) {
                        return a(h.lower, m.lower)
                    });
                    u = v.map(function(h) {
                        return h.upper
                    }), f = v.map(function(h) {
                        return h.lower
                    }), p = (c = d) === "next" ? "" : r
                }
                y("next"), e = new e.Collection(e, function() {
                    return Ae(u[0], f[s - 1] + r)
                }), e._ondirectionchange = function(d) {
                    y(d)
                };
                var l = 0;
                return e._addAlgorithm(function(d, v, h) {
                    var m = d.key;
                    if (typeof m != "string") return !1;
                    var g = i(m);
                    if (n(g, f, l)) return !0;
                    for (var b = null, w = l; w < s; ++w) {
                        var x = (function(P, k, O, E, _, T) {
                            for (var j = Math.min(P.length, E.length), M = -1, q = 0; q < j; ++q) {
                                var ce = k[q];
                                if (ce !== E[q]) return _(P[q], O[q]) < 0 ? P.substr(0, q) + O[q] + O.substr(q + 1) : _(P[q], E[q]) < 0 ? P.substr(0, q) + E[q] + O.substr(q + 1) : 0 <= M ? P.substr(0, M) + k[M] + O.substr(M + 1) : null;
                                _(P[q], ce) < 0 && (M = q)
                            }
                            return j < E.length && T === "next" ? P + O.substr(P.length) : j < P.length && T === "prev" ? P.substr(0, O.length) : M < 0 ? null : P.substr(0, M) + E[M] + O.substr(M + 1)
                        })(m, g, u[w], f[w], a, c);
                        x === null && b === null ? l = w + 1 : (b === null || 0 < a(b, x)) && (b = x)
                    }
                    return v(b !== null ? function() {
                        d.continue(b + p)
                    } : h), !1
                }), e
            }

            function Ae(e, n, t, r) {
                return {
                    type: 2,
                    lower: e,
                    upper: n,
                    lowerOpen: t,
                    upperOpen: r
                }
            }

            function cr(e) {
                return {
                    type: 1,
                    lower: e,
                    upper: e
                }
            }
            var lr = (Object.defineProperty(Z.prototype, "Collection", {
                get: function() {
                    return this._ctx.table.db.Collection
                },
                enumerable: !1,
                configurable: !0
            }), Z.prototype.between = function(e, n, t, r) {
                t = t !== !1, r = r === !0;
                try {
                    return 0 < this._cmp(e, n) || this._cmp(e, n) === 0 && (t || r) && (!t || !r) ? Xe(this) : new this.Collection(this, function() {
                        return Ae(e, n, !t, !r)
                    })
                } catch (o) {
                    return ue(this, ve)
                }
            }, Z.prototype.equals = function(e) {
                return e == null ? ue(this, ve) : new this.Collection(this, function() {
                    return cr(e)
                })
            }, Z.prototype.above = function(e) {
                return e == null ? ue(this, ve) : new this.Collection(this, function() {
                    return Ae(e, void 0, !0)
                })
            }, Z.prototype.aboveOrEqual = function(e) {
                return e == null ? ue(this, ve) : new this.Collection(this, function() {
                    return Ae(e, void 0, !1)
                })
            }, Z.prototype.below = function(e) {
                return e == null ? ue(this, ve) : new this.Collection(this, function() {
                    return Ae(void 0, e, !1, !0)
                })
            }, Z.prototype.belowOrEqual = function(e) {
                return e == null ? ue(this, ve) : new this.Collection(this, function() {
                    return Ae(void 0, e)
                })
            }, Z.prototype.startsWith = function(e) {
                return typeof e != "string" ? ue(this, er) : this.between(e, e + qe, !0, !0)
            }, Z.prototype.startsWithIgnoreCase = function(e) {
                return e === "" ? this.startsWith(e) : jn(this, function(n, t) {
                    return n.indexOf(t[0]) === 0
                }, [e], qe)
            }, Z.prototype.equalsIgnoreCase = function(e) {
                return jn(this, function(n, t) {
                    return n === t[0]
                }, [e], "")
            }, Z.prototype.anyOfIgnoreCase = function() {
                var e = ye.apply(Ve, arguments);
                return e.length === 0 ? Xe(this) : jn(this, function(n, t) {
                    return t.indexOf(n) !== -1
                }, e, "")
            }, Z.prototype.startsWithAnyOfIgnoreCase = function() {
                var e = ye.apply(Ve, arguments);
                return e.length === 0 ? Xe(this) : jn(this, function(n, t) {
                    return t.some(function(r) {
                        return n.indexOf(r) === 0
                    })
                }, e, qe)
            }, Z.prototype.anyOf = function() {
                var e = this,
                    n = ye.apply(Ve, arguments),
                    t = this._cmp;
                try {
                    n.sort(t)
                } catch (i) {
                    return ue(this, ve)
                }
                if (n.length === 0) return Xe(this);
                var r = new this.Collection(this, function() {
                    return Ae(n[0], n[n.length - 1])
                });
                r._ondirectionchange = function(i) {
                    t = i === "next" ? e._ascending : e._descending, n.sort(t)
                };
                var o = 0;
                return r._addAlgorithm(function(i, a, u) {
                    for (var f = i.key; 0 < t(f, n[o]);)
                        if (++o === n.length) return a(u), !1;
                    return t(f, n[o]) === 0 || (a(function() {
                        i.continue(n[o])
                    }), !1)
                }), r
            }, Z.prototype.notEqual = function(e) {
                return this.inAnyRange([
                    [-1 / 0, e],
                    [e, this.db._maxKey]
                ], {
                    includeLowers: !1,
                    includeUppers: !1
                })
            }, Z.prototype.noneOf = function() {
                var e = ye.apply(Ve, arguments);
                if (e.length === 0) return new this.Collection(this);
                try {
                    e.sort(this._ascending)
                } catch (t) {
                    return ue(this, ve)
                }
                var n = e.reduce(function(t, r) {
                    return t ? t.concat([
                        [t[t.length - 1][1], r]
                    ]) : [
                        [-1 / 0, r]
                    ]
                }, null);
                return n.push([e[e.length - 1], this.db._maxKey]), this.inAnyRange(n, {
                    includeLowers: !1,
                    includeUppers: !1
                })
            }, Z.prototype.inAnyRange = function(m, n) {
                var t = this,
                    r = this._cmp,
                    o = this._ascending,
                    i = this._descending,
                    a = this._min,
                    u = this._max;
                if (m.length === 0) return Xe(this);
                if (!m.every(function(g) {
                        return g[0] !== void 0 && g[1] !== void 0 && o(g[0], g[1]) <= 0
                    })) return ue(this, "First argument to inAnyRange() must be an Array of two-value Arrays [lower,upper] where upper must not be lower than lower", K.InvalidArgument);
                var f = !n || n.includeLowers !== !1,
                    c = n && n.includeUppers === !0,
                    p, s = o;

                function y(g, b) {
                    return s(g[0], b[0])
                }
                try {
                    (p = m.reduce(function(g, b) {
                        for (var w = 0, x = g.length; w < x; ++w) {
                            var P = g[w];
                            if (r(b[0], P[1]) < 0 && 0 < r(b[1], P[0])) {
                                P[0] = a(P[0], b[0]), P[1] = u(P[1], b[1]);
                                break
                            }
                        }
                        return w === x && g.push(b), g
                    }, [])).sort(y)
                } catch (g) {
                    return ue(this, ve)
                }
                var l = 0,
                    d = c ? function(g) {
                        return 0 < o(g, p[l][1])
                    } : function(g) {
                        return 0 <= o(g, p[l][1])
                    },
                    v = f ? function(g) {
                        return 0 < i(g, p[l][0])
                    } : function(g) {
                        return 0 <= i(g, p[l][0])
                    },
                    h = d,
                    m = new this.Collection(this, function() {
                        return Ae(p[0][0], p[p.length - 1][1], !f, !c)
                    });
                return m._ondirectionchange = function(g) {
                    s = g === "next" ? (h = d, o) : (h = v, i), p.sort(y)
                }, m._addAlgorithm(function(g, b, w) {
                    for (var x, P = g.key; h(P);)
                        if (++l === p.length) return b(w), !1;
                    return !d(x = P) && !v(x) || (t._cmp(P, p[l][1]) === 0 || t._cmp(P, p[l][0]) === 0 || b(function() {
                        s === o ? g.continue(p[l][0]) : g.continue(p[l][1])
                    }), !1)
                }), m
            }, Z.prototype.startsWithAnyOf = function() {
                var e = ye.apply(Ve, arguments);
                return e.every(function(n) {
                    return typeof n == "string"
                }) ? e.length === 0 ? Xe(this) : this.inAnyRange(e.map(function(n) {
                    return [n, n + qe]
                })) : ue(this, "startsWithAnyOf() only works with strings")
            }, Z);

            function Z() {}

            function fe(e) {
                return G(function(n) {
                    return fn(n), e(n.target.error), !1
                })
            }

            function fn(e) {
                e.stopPropagation && e.stopPropagation(), e.preventDefault && e.preventDefault()
            }
            var hn = "storagemutated",
                yt = "x-storagemutated-1",
                Ie = sn(null, hn),
                io = (he.prototype._lock = function() {
                    return Ze(!S.global), ++this._reculock, this._reculock !== 1 || S.global || (S.lockOwnerFor = this), this
                }, he.prototype._unlock = function() {
                    if (Ze(!S.global), --this._reculock == 0)
                        for (S.global || (S.lockOwnerFor = null); 0 < this._blockedFuncs.length && !this._locked();) {
                            var e = this._blockedFuncs.shift();
                            try {
                                Re(e[1], e[0])
                            } catch (n) {}
                        }
                    return this
                }, he.prototype._locked = function() {
                    return this._reculock && S.lockOwnerFor !== this
                }, he.prototype.create = function(e) {
                    var n = this;
                    if (!this.mode) return this;
                    var t = this.db.idbdb,
                        r = this.db._state.dbOpenError;
                    if (Ze(!this.idbtrans), !e && !t) switch (r && r.name) {
                        case "DatabaseClosedError":
                            throw new K.DatabaseClosed(r);
                        case "MissingAPIError":
                            throw new K.MissingAPI(r.message, r);
                        default:
                            throw new K.OpenFailed(r)
                    }
                    if (!this.active) throw new K.TransactionInactive;
                    return Ze(this._completion._state === null), (e = this.idbtrans = e || (this.db.core || t).transaction(this.storeNames, this.mode, {
                        durability: this.chromeTransactionDurability
                    })).onerror = G(function(o) {
                        fn(o), n._reject(e.error)
                    }), e.onabort = G(function(o) {
                        fn(o), n.active && n._reject(new K.Abort(e.error)), n.active = !1, n.on("abort").fire(o)
                    }), e.oncomplete = G(function() {
                        n.active = !1, n._resolve(), "mutatedParts" in e && Ie.storagemutated.fire(e.mutatedParts)
                    }), this
                }, he.prototype._promise = function(e, n, t) {
                    var r = this;
                    if (e === "readwrite" && this.mode !== "readwrite") return H(new K.ReadOnly("Transaction is readonly"));
                    if (!this.active) return H(new K.TransactionInactive);
                    if (this._locked()) return new A(function(i, a) {
                        r._blockedFuncs.push([function() {
                            r._promise(e, n, t).then(i, a)
                        }, S])
                    });
                    if (t) return Oe(function() {
                        var i = new A(function(a, u) {
                            r._lock();
                            var f = n(a, u, r);
                            f && f.then && f.then(a, u)
                        });
                        return i.finally(function() {
                            return r._unlock()
                        }), i._lib = !0, i
                    });
                    var o = new A(function(i, a) {
                        var u = n(i, a, r);
                        u && u.then && u.then(i, a)
                    });
                    return o._lib = !0, o
                }, he.prototype._root = function() {
                    return this.parent ? this.parent._root() : this
                }, he.prototype.waitFor = function(e) {
                    var n, t = this._root(),
                        r = A.resolve(e);
                    t._waitingFor ? t._waitingFor = t._waitingFor.then(function() {
                        return r
                    }) : (t._waitingFor = r, t._waitingQueue = [], n = t.idbtrans.objectStore(t.storeNames[0]), (function i() {
                        for (++t._spinCount; t._waitingQueue.length;) t._waitingQueue.shift()();
                        t._waitingFor && (n.get(-1 / 0).onsuccess = i)
                    })());
                    var o = t._waitingFor;
                    return new A(function(i, a) {
                        r.then(function(u) {
                            return t._waitingQueue.push(G(i.bind(null, u)))
                        }, function(u) {
                            return t._waitingQueue.push(G(a.bind(null, u)))
                        }).finally(function() {
                            t._waitingFor === o && (t._waitingFor = null)
                        })
                    })
                }, he.prototype.abort = function() {
                    this.active && (this.active = !1, this.idbtrans && this.idbtrans.abort(), this._reject(new K.Abort))
                }, he.prototype.table = function(e) {
                    var n = this._memoizedTables || (this._memoizedTables = {});
                    if (Y(n, e)) return n[e];
                    var t = this.schema[e];
                    if (!t) throw new K.NotFound("Table " + e + " not part of transaction");
                    return t = new this.db.Table(e, t, this), t.core = this.db.core.table(e), n[e] = t
                }, he);

            function he() {}

            function vt(e, n, t, r, o, i, a) {
                return {
                    name: e,
                    keyPath: n,
                    unique: t,
                    multi: r,
                    auto: o,
                    compound: i,
                    src: (t && !a ? "&" : "") + (r ? "*" : "") + (o ? "++" : "") + fr(n)
                }
            }

            function fr(e) {
                return typeof e == "string" ? e : e ? "[" + [].join.call(e, "+") + "]" : ""
            }

            function mt(e, n, t) {
                return {
                    name: e,
                    primKey: n,
                    indexes: t,
                    mappedClass: null,
                    idxByName: (r = function(o) {
                        return [o.name, o]
                    }, t.reduce(function(o, i, a) {
                        return a = r(i, a), a && (o[a[0]] = a[1]), o
                    }, {}))
                };
                var r
            }
            var dn = function(e) {
                try {
                    return e.only([
                        []
                    ]), dn = function() {
                        return [
                            []
                        ]
                    }, [
                        []
                    ]
                } catch (n) {
                    return dn = function() {
                        return qe
                    }, qe
                }
            };

            function gt(e) {
                return e == null ? function() {} : typeof e == "string" ? (n = e).split(".").length === 1 ? function(t) {
                    return t[n]
                } : function(t) {
                    return pe(t, n)
                } : function(t) {
                    return pe(t, e)
                };
                var n
            }

            function hr(e) {
                return [].slice.call(e)
            }
            var ao = 0;

            function pn(e) {
                return e == null ? ":id" : typeof e == "string" ? e : "[".concat(e.join("+"), "]")
            }

            function uo(e, n, f) {
                function r(h) {
                    if (h.type === 3) return null;
                    if (h.type === 4) throw new Error("Cannot convert never type to IDBKeyRange");
                    var l = h.lower,
                        d = h.upper,
                        v = h.lowerOpen,
                        h = h.upperOpen;
                    return l === void 0 ? d === void 0 ? null : n.upperBound(d, !!h) : d === void 0 ? n.lowerBound(l, !!v) : n.bound(l, d, !!v, !!h)
                }

                function o(y) {
                    var l, d = y.name;
                    return {
                        name: d,
                        schema: y,
                        mutate: function(v) {
                            var h = v.trans,
                                m = v.type,
                                g = v.keys,
                                b = v.values,
                                w = v.range;
                            return new Promise(function(x, P) {
                                x = G(x);
                                var k = h.objectStore(d),
                                    O = k.keyPath == null,
                                    E = m === "put" || m === "add";
                                if (!E && m !== "delete" && m !== "deleteRange") throw new Error("Invalid operation type: " + m);
                                var _, T = (g || b || {
                                    length: 1
                                }).length;
                                if (g && b && g.length !== b.length) throw new Error("Given keys array must have same length as given values array.");
                                if (T === 0) return x({
                                    numFailures: 0,
                                    failures: {},
                                    results: [],
                                    lastResult: void 0
                                });

                                function j(ie) {
                                    ++ce, fn(ie)
                                }
                                var M = [],
                                    q = [],
                                    ce = 0;
                                if (m === "deleteRange") {
                                    if (w.type === 4) return x({
                                        numFailures: ce,
                                        failures: q,
                                        results: [],
                                        lastResult: void 0
                                    });
                                    w.type === 3 ? M.push(_ = k.clear()) : M.push(_ = k.delete(r(w)))
                                } else {
                                    var O = E ? O ? [b, g] : [b, null] : [g, null],
                                        B = O[0],
                                        ne = O[1];
                                    if (E)
                                        for (var te = 0; te < T; ++te) M.push(_ = ne && ne[te] !== void 0 ? k[m](B[te], ne[te]) : k[m](B[te])), _.onerror = j;
                                    else
                                        for (te = 0; te < T; ++te) M.push(_ = k[m](B[te])), _.onerror = j
                                }

                                function Yn(ie) {
                                    ie = ie.target.result, M.forEach(function(Ne, qt) {
                                        return Ne.error != null && (q[qt] = Ne.error)
                                    }), x({
                                        numFailures: ce,
                                        failures: q,
                                        results: m === "delete" ? g : M.map(function(Ne) {
                                            return Ne.result
                                        }),
                                        lastResult: ie
                                    })
                                }
                                _.onerror = function(ie) {
                                    j(ie), Yn(ie)
                                }, _.onsuccess = Yn
                            })
                        },
                        getMany: function(v) {
                            var h = v.trans,
                                m = v.keys;
                            return new Promise(function(g, b) {
                                g = G(g);
                                for (var w, x = h.objectStore(d), P = m.length, k = new Array(P), O = 0, E = 0, _ = function(M) {
                                        M = M.target, k[M._pos] = M.result, ++E === O && g(k)
                                    }, T = fe(b), j = 0; j < P; ++j) m[j] != null && ((w = x.get(m[j]))._pos = j, w.onsuccess = _, w.onerror = T, ++O);
                                O === 0 && g(k)
                            })
                        },
                        get: function(v) {
                            var h = v.trans,
                                m = v.key;
                            return new Promise(function(g, b) {
                                g = G(g);
                                var w = h.objectStore(d).get(m);
                                w.onsuccess = function(x) {
                                    return g(x.target.result)
                                }, w.onerror = fe(b)
                            })
                        },
                        query: (l = c, function(v) {
                            return new Promise(function(h, m) {
                                h = G(h);
                                var g, b, w, O = v.trans,
                                    x = v.values,
                                    P = v.limit,
                                    _ = v.query,
                                    k = P === 1 / 0 ? void 0 : P,
                                    E = _.index,
                                    _ = _.range,
                                    O = O.objectStore(d),
                                    E = E.isPrimaryKey ? O : O.index(E.name),
                                    _ = r(_);
                                if (P === 0) return h({
                                    result: []
                                });
                                l ? ((k = x ? E.getAll(_, k) : E.getAllKeys(_, k)).onsuccess = function(T) {
                                    return h({
                                        result: T.target.result
                                    })
                                }, k.onerror = fe(m)) : (g = 0, b = !x && "openKeyCursor" in E ? E.openKeyCursor(_) : E.openCursor(_), w = [], b.onsuccess = function(T) {
                                    var j = b.result;
                                    return j ? (w.push(x ? j.value : j.primaryKey), ++g === P ? h({
                                        result: w
                                    }) : void j.continue()) : h({
                                        result: w
                                    })
                                }, b.onerror = fe(m))
                            })
                        }),
                        openCursor: function(v) {
                            var h = v.trans,
                                m = v.values,
                                g = v.query,
                                b = v.reverse,
                                w = v.unique;
                            return new Promise(function(x, P) {
                                x = G(x);
                                var E = g.index,
                                    k = g.range,
                                    O = h.objectStore(d),
                                    O = E.isPrimaryKey ? O : O.index(E.name),
                                    E = b ? w ? "prevunique" : "prev" : w ? "nextunique" : "next",
                                    _ = !m && "openKeyCursor" in O ? O.openKeyCursor(r(k), E) : O.openCursor(r(k), E);
                                _.onerror = fe(P), _.onsuccess = G(function(T) {
                                    var j, M, q, ce, B = _.result;
                                    B ? (B.___id = ++ao, B.done = !1, j = B.continue.bind(B), M = (M = B.continuePrimaryKey) && M.bind(B), q = B.advance.bind(B), ce = function() {
                                        throw new Error("Cursor not stopped")
                                    }, B.trans = h, B.stop = B.continue = B.continuePrimaryKey = B.advance = function() {
                                        throw new Error("Cursor not started")
                                    }, B.fail = G(P), B.next = function() {
                                        var ne = this,
                                            te = 1;
                                        return this.start(function() {
                                            return te-- ? ne.continue() : ne.stop()
                                        }).then(function() {
                                            return ne
                                        })
                                    }, B.start = function(ne) {
                                        function te() {
                                            if (_.result) try {
                                                ne()
                                            } catch (ie) {
                                                B.fail(ie)
                                            } else B.done = !0, B.start = function() {
                                                throw new Error("Cursor behind last entry")
                                            }, B.stop()
                                        }
                                        var Yn = new Promise(function(ie, Ne) {
                                            ie = G(ie), _.onerror = fe(Ne), B.fail = Ne, B.stop = function(qt) {
                                                B.stop = B.continue = B.continuePrimaryKey = B.advance = ce, ie(qt)
                                            }
                                        });
                                        return _.onsuccess = G(function(ie) {
                                            _.onsuccess = te, te()
                                        }), B.continue = j, B.continuePrimaryKey = M, B.advance = q, te(), Yn
                                    }, x(B)) : x(null)
                                }, P)
                            })
                        },
                        count: function(v) {
                            var h = v.query,
                                m = v.trans,
                                g = h.index,
                                b = h.range;
                            return new Promise(function(w, x) {
                                var P = m.objectStore(d),
                                    k = g.isPrimaryKey ? P : P.index(g.name),
                                    P = r(b),
                                    k = P ? k.count(P) : k.count();
                                k.onsuccess = G(function(O) {
                                    return w(O.target.result)
                                }), k.onerror = fe(x)
                            })
                        }
                    }
                }
                var i, a, u, p = (a = f, u = hr((i = e).objectStoreNames), {
                        schema: {
                            name: i.name,
                            tables: u.map(function(y) {
                                return a.objectStore(y)
                            }).map(function(y) {
                                var l = y.keyPath,
                                    h = y.autoIncrement,
                                    d = D(l),
                                    v = {},
                                    h = {
                                        name: y.name,
                                        primaryKey: {
                                            name: null,
                                            isPrimaryKey: !0,
                                            outbound: l == null,
                                            compound: d,
                                            keyPath: l,
                                            autoIncrement: h,
                                            unique: !0,
                                            extractKey: gt(l)
                                        },
                                        indexes: hr(y.indexNames).map(function(m) {
                                            return y.index(m)
                                        }).map(function(w) {
                                            var g = w.name,
                                                b = w.unique,
                                                x = w.multiEntry,
                                                w = w.keyPath,
                                                x = {
                                                    name: g,
                                                    compound: D(w),
                                                    keyPath: w,
                                                    unique: b,
                                                    multiEntry: x,
                                                    extractKey: gt(w)
                                                };
                                            return v[pn(w)] = x
                                        }),
                                        getIndexByKeyPath: function(m) {
                                            return v[pn(m)]
                                        }
                                    };
                                return v[":id"] = h.primaryKey, l != null && (v[pn(l)] = h.primaryKey), h
                            })
                        },
                        hasGetAll: 0 < u.length && "getAll" in a.objectStore(u[0]) && !(typeof navigator < "u" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604)
                    }),
                    f = p.schema,
                    c = p.hasGetAll,
                    p = f.tables.map(o),
                    s = {};
                return p.forEach(function(y) {
                    return s[y.name] = y
                }), {
                    stack: "dbcore",
                    transaction: e.transaction.bind(e),
                    table: function(y) {
                        if (!s[y]) throw new Error("Table '".concat(y, "' not found"));
                        return s[y]
                    },
                    MIN_KEY: -1 / 0,
                    MAX_KEY: dn(n),
                    schema: f
                }
            }

            function so(e, n, t, r) {
                var o = t.IDBKeyRange;
                return t.indexedDB, {
                    dbcore: (r = uo(n, o, r), e.dbcore.reduce(function(i, a) {
                        return a = a.create, I(I({}, i), a(i))
                    }, r))
                }
            }

            function Rn(e, r) {
                var t = r.db,
                    r = so(e._middlewares, t, e._deps, r);
                e.core = r.dbcore, e.tables.forEach(function(o) {
                    var i = o.name;
                    e.core.schema.tables.some(function(a) {
                        return a.name === i
                    }) && (o.core = e.core.table(i), e[i] instanceof e.Table && (e[i].core = o.core))
                })
            }

            function qn(e, n, t, r) {
                t.forEach(function(o) {
                    var i = r[o];
                    n.forEach(function(a) {
                        var u = (function f(c, p) {
                            return Mr(c, p) || (c = z(c)) && f(c, p)
                        })(a, o);
                        (!u || "value" in u && u.value === void 0) && (a === e.Transaction.prototype || a instanceof e.Transaction ? xe(a, o, {
                            get: function() {
                                return this.table(o)
                            },
                            set: function(f) {
                                Nt(this, o, {
                                    value: f,
                                    writable: !0,
                                    configurable: !0,
                                    enumerable: !0
                                })
                            }
                        }) : a[o] = new e.Table(o, i))
                    })
                })
            }

            function bt(e, n) {
                n.forEach(function(t) {
                    for (var r in t) t[r] instanceof e.Table && delete t[r]
                })
            }

            function co(e, n) {
                return e._cfg.version - n._cfg.version
            }

            function lo(e, n, t, r) {
                var o = e._dbSchema;
                t.objectStoreNames.contains("$meta") && !o.$meta && (o.$meta = mt("$meta", pr("")[0], []), e._storeNames.push("$meta"));
                var i = e._createTransaction("readwrite", e._storeNames, o);
                i.create(t), i._completion.catch(r);
                var a = i._reject.bind(i),
                    u = S.transless || S;
                Oe(function() {
                    return S.trans = i, S.transless = u, n !== 0 ? (Rn(e, t), c = n, ((f = i).storeNames.includes("$meta") ? f.table("$meta").get("version").then(function(p) {
                        return p != null ? p : c
                    }) : A.resolve(c)).then(function(p) {
                        return y = p, l = i, d = t, v = [], p = (s = e)._versions, h = s._dbSchema = Fn(0, s.idbdb, d), (p = p.filter(function(m) {
                            return m._cfg.version >= y
                        })).length !== 0 ? (p.forEach(function(m) {
                            v.push(function() {
                                var g = h,
                                    b = m._cfg.dbschema;
                                Mn(s, g, d), Mn(s, b, d), h = s._dbSchema = b;
                                var w = wt(g, b);
                                w.add.forEach(function(E) {
                                    _t(d, E[0], E[1].primKey, E[1].indexes)
                                }), w.change.forEach(function(E) {
                                    if (E.recreate) throw new K.Upgrade("Not yet support for changing primary key");
                                    var _ = d.objectStore(E.name);
                                    E.add.forEach(function(T) {
                                        return Bn(_, T)
                                    }), E.change.forEach(function(T) {
                                        _.deleteIndex(T.name), Bn(_, T)
                                    }), E.del.forEach(function(T) {
                                        return _.deleteIndex(T)
                                    })
                                });
                                var x = m._cfg.contentUpgrade;
                                if (x && m._cfg.version > y) {
                                    Rn(s, d), l._memoizedTables = {};
                                    var P = Vt(b);
                                    w.del.forEach(function(E) {
                                        P[E] = g[E]
                                    }), bt(s, [s.Transaction.prototype]), qn(s, [s.Transaction.prototype], W(P), P), l.schema = P;
                                    var k, O = Zn(x);
                                    return O && Qe(), w = A.follow(function() {
                                        var E;
                                        (k = x(l)) && O && (E = Pe.bind(null, null), k.then(E, E))
                                    }), k && typeof k.then == "function" ? A.resolve(k) : w.then(function() {
                                        return k
                                    })
                                }
                            }), v.push(function(g) {
                                var b, w, x = m._cfg.dbschema;
                                b = x, w = g, [].slice.call(w.db.objectStoreNames).forEach(function(P) {
                                    return b[P] == null && w.db.deleteObjectStore(P)
                                }), bt(s, [s.Transaction.prototype]), qn(s, [s.Transaction.prototype], s._storeNames, s._dbSchema), l.schema = s._dbSchema
                            }), v.push(function(g) {
                                s.idbdb.objectStoreNames.contains("$meta") && (Math.ceil(s.idbdb.version / 10) === m._cfg.version ? (s.idbdb.deleteObjectStore("$meta"), delete s._dbSchema.$meta, s._storeNames = s._storeNames.filter(function(b) {
                                    return b !== "$meta"
                                })) : g.objectStore("$meta").put(m._cfg.version, "version"))
                            })
                        }), (function m() {
                            return v.length ? A.resolve(v.shift()(l.idbtrans)).then(m) : A.resolve()
                        })().then(function() {
                            dr(h, d)
                        })) : A.resolve();
                        var s, y, l, d, v, h
                    }).catch(a)) : (W(o).forEach(function(p) {
                        _t(t, p, o[p].primKey, o[p].indexes)
                    }), Rn(e, t), void A.follow(function() {
                        return e.on.populate.fire(i)
                    }).catch(a));
                    var f, c
                })
            }

            function fo(e, n) {
                dr(e._dbSchema, n), n.db.version % 10 != 0 || n.objectStoreNames.contains("$meta") || n.db.createObjectStore("$meta").add(Math.ceil(n.db.version / 10 - 1), "version");
                var t = Fn(0, e.idbdb, n);
                Mn(e, e._dbSchema, n);
                for (var r = 0, o = wt(t, e._dbSchema).change; r < o.length; r++) {
                    var i = (function(a) {
                        if (a.change.length || a.recreate) return console.warn("Unable to patch indexes of table ".concat(a.name, " because it has changes on the type of index or primary key.")), {
                            value: void 0
                        };
                        var u = n.objectStore(a.name);
                        a.add.forEach(function(f) {
                            le && console.debug("Dexie upgrade patch: Creating missing index ".concat(a.name, ".").concat(f.src)), Bn(u, f)
                        })
                    })(o[r]);
                    if (typeof i == "object") return i.value
                }
            }

            function wt(e, n) {
                var t, r = {
                    del: [],
                    add: [],
                    change: []
                };
                for (t in e) n[t] || r.del.push(t);
                for (t in n) {
                    var o = e[t],
                        i = n[t];
                    if (o) {
                        var a = {
                            name: t,
                            def: i,
                            recreate: !1,
                            del: [],
                            add: [],
                            change: []
                        };
                        if ("" + (o.primKey.keyPath || "") != "" + (i.primKey.keyPath || "") || o.primKey.auto !== i.primKey.auto) a.recreate = !0, r.change.push(a);
                        else {
                            var u = o.idxByName,
                                f = i.idxByName,
                                c = void 0;
                            for (c in u) f[c] || a.del.push(c);
                            for (c in f) {
                                var p = u[c],
                                    s = f[c];
                                p ? p.src !== s.src && a.change.push(s) : a.add.push(s)
                            }(0 < a.del.length || 0 < a.add.length || 0 < a.change.length) && r.change.push(a)
                        }
                    } else r.add.push([t, i])
                }
                return r
            }

            function _t(e, n, t, r) {
                var o = e.db.createObjectStore(n, t.keyPath ? {
                    keyPath: t.keyPath,
                    autoIncrement: t.auto
                } : {
                    autoIncrement: t.auto
                });
                return r.forEach(function(i) {
                    return Bn(o, i)
                }), o
            }

            function dr(e, n) {
                W(e).forEach(function(t) {
                    n.db.objectStoreNames.contains(t) || (le && console.debug("Dexie: Creating missing table", t), _t(n, t, e[t].primKey, e[t].indexes))
                })
            }

            function Bn(e, n) {
                e.createIndex(n.name, n.keyPath, {
                    unique: n.unique,
                    multiEntry: n.multi
                })
            }

            function Fn(e, n, t) {
                var r = {};
                return bn(n.objectStoreNames, 0).forEach(function(o) {
                    for (var i = t.objectStore(o), a = vt(fr(c = i.keyPath), c || "", !0, !1, !!i.autoIncrement, c && typeof c != "string", !0), u = [], f = 0; f < i.indexNames.length; ++f) {
                        var p = i.index(i.indexNames[f]),
                            c = p.keyPath,
                            p = vt(p.name, c, !!p.unique, !!p.multiEntry, !1, c && typeof c != "string", !1);
                        u.push(p)
                    }
                    r[o] = mt(o, a, u)
                }), r
            }

            function Mn(e, n, t) {
                for (var r = t.db.objectStoreNames, o = 0; o < r.length; ++o) {
                    var i = r[o],
                        a = t.objectStore(i);
                    e._hasGetAll = "getAll" in a;
                    for (var u = 0; u < a.indexNames.length; ++u) {
                        var f = a.indexNames[u],
                            c = a.index(f).keyPath,
                            p = typeof c == "string" ? c : "[" + bn(c).join("+") + "]";
                        !n[i] || (c = n[i].idxByName[p]) && (c.name = f, delete n[i].idxByName[p], n[i].idxByName[f] = c)
                    }
                }
                typeof navigator < "u" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && R.WorkerGlobalScope && R instanceof R.WorkerGlobalScope && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604 && (e._hasGetAll = !1)
            }

            function pr(e) {
                return e.split(",").map(function(n, t) {
                    var r = (n = n.trim()).replace(/([&*]|\+\+)/g, ""),
                        o = /^\[/.test(r) ? r.match(/^\[(.*)\]$/)[1].split("+") : r;
                    return vt(r, o || null, /\&/.test(n), /\*/.test(n), /\+\+/.test(n), D(o), t === 0)
                })
            }
            var ho = (Nn.prototype._parseStoresSpec = function(e, n) {
                W(e).forEach(function(t) {
                    if (e[t] !== null) {
                        var r = pr(e[t]),
                            o = r.shift();
                        if (o.unique = !0, o.multi) throw new K.Schema("Primary key cannot be multi-valued");
                        r.forEach(function(i) {
                            if (i.auto) throw new K.Schema("Only primary key can be marked as autoIncrement (++)");
                            if (!i.keyPath) throw new K.Schema("Index must have a name and cannot be an empty string")
                        }), n[t] = mt(t, o, r)
                    }
                })
            }, Nn.prototype.stores = function(t) {
                var n = this.db;
                this._cfg.storesSource = this._cfg.storesSource ? U(this._cfg.storesSource, t) : t;
                var t = n._versions,
                    r = {},
                    o = {};
                return t.forEach(function(i) {
                    U(r, i._cfg.storesSource), o = i._cfg.dbschema = {}, i._parseStoresSpec(r, o)
                }), n._dbSchema = o, bt(n, [n._allTables, n, n.Transaction.prototype]), qn(n, [n._allTables, n, n.Transaction.prototype, this._cfg.tables], W(o), o), n._storeNames = W(o), this
            }, Nn.prototype.upgrade = function(e) {
                return this._cfg.contentUpgrade = nt(this._cfg.contentUpgrade || $, e), this
            }, Nn);

            function Nn() {}

            function xt(e, n) {
                var t = e._dbNamesDB;
                return t || (t = e._dbNamesDB = new ge(Cn, {
                    addons: [],
                    indexedDB: e,
                    IDBKeyRange: n
                })).version(1).stores({
                    dbnames: "name"
                }), t.table("dbnames")
            }

            function kt(e) {
                return e && typeof e.databases == "function"
            }

            function Ot(e) {
                return Oe(function() {
                    return S.letThrough = !0, e()
                })
            }

            function Pt(e) {
                return !("from" in e)
            }
            var oe = function(e, n) {
                if (!this) {
                    var t = new oe;
                    return e && "d" in e && U(t, e), t
                }
                U(this, arguments.length ? {
                    d: 1,
                    from: e,
                    to: 1 < arguments.length ? n : e
                } : {
                    d: 0
                })
            };

            function yn(e, n, t) {
                var r = L(n, t);
                if (!isNaN(r)) {
                    if (0 < r) throw RangeError();
                    if (Pt(e)) return U(e, {
                        from: n,
                        to: t,
                        d: 1
                    });
                    var o = e.l,
                        r = e.r;
                    if (L(t, e.from) < 0) return o ? yn(o, n, t) : e.l = {
                        from: n,
                        to: t,
                        d: 1,
                        l: null,
                        r: null
                    }, vr(e);
                    if (0 < L(n, e.to)) return r ? yn(r, n, t) : e.r = {
                        from: n,
                        to: t,
                        d: 1,
                        l: null,
                        r: null
                    }, vr(e);
                    L(n, e.from) < 0 && (e.from = n, e.l = null, e.d = r ? r.d + 1 : 1), 0 < L(t, e.to) && (e.to = t, e.r = null, e.d = e.l ? e.l.d + 1 : 1), t = !e.r, o && !e.l && vn(e, o), r && t && vn(e, r)
                }
            }

            function vn(e, n) {
                Pt(n) || (function t(r, f) {
                    var i = f.from,
                        a = f.to,
                        u = f.l,
                        f = f.r;
                    yn(r, i, a), u && t(r, u), f && t(r, f)
                })(e, n)
            }

            function yr(e, n) {
                var t = Un(n),
                    r = t.next();
                if (r.done) return !1;
                for (var o = r.value, i = Un(e), a = i.next(o.from), u = a.value; !r.done && !a.done;) {
                    if (L(u.from, o.to) <= 0 && 0 <= L(u.to, o.from)) return !0;
                    L(o.from, u.from) < 0 ? o = (r = t.next(u.from)).value : u = (a = i.next(o.from)).value
                }
                return !1
            }

            function Un(e) {
                var n = Pt(e) ? null : {
                    s: 0,
                    n: e
                };
                return {
                    next: function(t) {
                        for (var r = 0 < arguments.length; n;) switch (n.s) {
                            case 0:
                                if (n.s = 1, r)
                                    for (; n.n.l && L(t, n.n.from) < 0;) n = {
                                        up: n,
                                        n: n.n.l,
                                        s: 1
                                    };
                                else
                                    for (; n.n.l;) n = {
                                        up: n,
                                        n: n.n.l,
                                        s: 1
                                    };
                            case 1:
                                if (n.s = 2, !r || L(t, n.n.to) <= 0) return {
                                    value: n.n,
                                    done: !1
                                };
                            case 2:
                                if (n.n.r) {
                                    n.s = 3, n = {
                                        up: n,
                                        n: n.n.r,
                                        s: 0
                                    };
                                    continue
                                }
                            case 3:
                                n = n.up
                        }
                        return {
                            done: !0
                        }
                    }
                }
            }

            function vr(e) {
                var n, t, r = (((n = e.r) === null || n === void 0 ? void 0 : n.d) || 0) - (((t = e.l) === null || t === void 0 ? void 0 : t.d) || 0),
                    o = 1 < r ? "r" : r < -1 ? "l" : "";
                o && (n = o == "r" ? "l" : "r", t = I({}, e), r = e[o], e.from = r.from, e.to = r.to, e[o] = r[o], t[o] = r[n], (e[n] = t).d = mr(t)), e.d = mr(e)
            }

            function mr(t) {
                var n = t.r,
                    t = t.l;
                return (n ? t ? Math.max(n.d, t.d) : n.d : t ? t.d : 0) + 1
            }

            function Ln(e, n) {
                return W(n).forEach(function(t) {
                    e[t] ? vn(e[t], n[t]) : e[t] = (function r(o) {
                        var i, a, u = {};
                        for (i in o) Y(o, i) && (a = o[i], u[i] = !a || typeof a != "object" || $t.has(a.constructor) ? a : r(a));
                        return u
                    })(n[t])
                }), e
            }

            function Et(e, n) {
                return e.all || n.all || Object.keys(e).some(function(t) {
                    return n[t] && yr(n[t], e[t])
                })
            }
            Ue(oe.prototype, ((se = {
                add: function(e) {
                    return vn(this, e), this
                },
                addKey: function(e) {
                    return yn(this, e, e), this
                },
                addKeys: function(e) {
                    var n = this;
                    return e.forEach(function(t) {
                        return yn(n, t, t)
                    }), this
                },
                hasKey: function(e) {
                    var n = Un(this).next(e).value;
                    return n && L(n.from, e) <= 0 && 0 <= L(n.to, e)
                }
            })[Jn] = function() {
                return Un(this)
            }, se));
            var Fe = {},
                At = {},
                It = !1;

            function Vn(e) {
                Ln(At, e), It || (It = !0, setTimeout(function() {
                    It = !1, St(At, !(At = {}))
                }, 0))
            }

            function St(e, n) {
                n === void 0 && (n = !1);
                var t = new Set;
                if (e.all)
                    for (var r = 0, o = Object.values(Fe); r < o.length; r++) gr(a = o[r], e, t, n);
                else
                    for (var i in e) {
                        var a, u = /^idb\:\/\/(.*)\/(.*)\//.exec(i);
                        u && (i = u[1], u = u[2], (a = Fe["idb://".concat(i, "/").concat(u)]) && gr(a, e, t, n))
                    }
                t.forEach(function(f) {
                    return f()
                })
            }

            function gr(e, n, t, r) {
                for (var o = [], i = 0, a = Object.entries(e.queries.query); i < a.length; i++) {
                    for (var u = a[i], f = u[0], c = [], p = 0, s = u[1]; p < s.length; p++) {
                        var y = s[p];
                        Et(n, y.obsSet) ? y.subscribers.forEach(function(h) {
                            return t.add(h)
                        }) : r && c.push(y)
                    }
                    r && o.push([f, c])
                }
                if (r)
                    for (var l = 0, d = o; l < d.length; l++) {
                        var v = d[l],
                            f = v[0],
                            c = v[1];
                        e.queries.query[f] = c
                    }
            }

            function po(e) {
                var n = e._state,
                    t = e._deps.indexedDB;
                if (n.isBeingOpened || e.idbdb) return n.dbReadyPromise.then(function() {
                    return n.dbOpenError ? H(n.dbOpenError) : e
                });
                n.isBeingOpened = !0, n.dbOpenError = null, n.openComplete = !1;
                var r = n.openCanceller,
                    o = Math.round(10 * e.verno),
                    i = !1;

                function a() {
                    if (n.openCanceller !== r) throw new K.DatabaseClosed("db.open() was cancelled")
                }

                function u() {
                    return new A(function(y, l) {
                        if (a(), !t) throw new K.MissingAPI;
                        var d = e.name,
                            v = n.autoSchema || !o ? t.open(d) : t.open(d, o);
                        if (!v) throw new K.MissingAPI;
                        v.onerror = fe(l), v.onblocked = G(e._fireOnBlocked), v.onupgradeneeded = G(function(h) {
                            var m;
                            p = v.transaction, n.autoSchema && !e._options.allowEmptyDB ? (v.onerror = fn, p.abort(), v.result.close(), (m = t.deleteDatabase(d)).onsuccess = m.onerror = G(function() {
                                l(new K.NoSuchDatabase("Database ".concat(d, " doesnt exist")))
                            })) : (p.onerror = fe(l), h = h.oldVersion > Math.pow(2, 62) ? 0 : h.oldVersion, s = h < 1, e.idbdb = v.result, i && fo(e, p), lo(e, h / 10, p, l))
                        }, l), v.onsuccess = G(function() {
                            p = null;
                            var h, m, g, b, w, x = e.idbdb = v.result,
                                P = bn(x.objectStoreNames);
                            if (0 < P.length) try {
                                var k = x.transaction((b = P).length === 1 ? b[0] : b, "readonly");
                                if (n.autoSchema) m = x, g = k, (h = e).verno = m.version / 10, g = h._dbSchema = Fn(0, m, g), h._storeNames = bn(m.objectStoreNames, 0), qn(h, [h._allTables], W(g), g);
                                else if (Mn(e, e._dbSchema, k), ((w = wt(Fn(0, (w = e).idbdb, k), w._dbSchema)).add.length || w.change.some(function(O) {
                                        return O.add.length || O.change.length
                                    })) && !i) return console.warn("Dexie SchemaDiff: Schema was extended without increasing the number passed to db.version(). Dexie will add missing parts and increment native version number to workaround this."), x.close(), o = x.version + 1, i = !0, y(u());
                                Rn(e, k)
                            } catch (O) {}
                            Ge.push(e), x.onversionchange = G(function(O) {
                                n.vcFired = !0, e.on("versionchange").fire(O)
                            }), x.onclose = G(function(O) {
                                e.on("close").fire(O)
                            }), s && (w = e._deps, k = d, x = w.indexedDB, w = w.IDBKeyRange, kt(x) || k === Cn || xt(x, w).put({
                                name: k
                            }).catch($)), y()
                        }, l)
                    }).catch(function(y) {
                        switch (y == null ? void 0 : y.name) {
                            case "UnknownError":
                                if (0 < n.PR1398_maxLoop) return n.PR1398_maxLoop--, console.warn("Dexie: Workaround for Chrome UnknownError on open()"), u();
                                break;
                            case "VersionError":
                                if (0 < o) return o = 0, u()
                        }
                        return A.reject(y)
                    })
                }
                var f, c = n.dbReadyResolve,
                    p = null,
                    s = !1;
                return A.race([r, (typeof navigator > "u" ? A.resolve() : !navigator.userAgentData && /Safari\//.test(navigator.userAgent) && !/Chrom(e|ium)\//.test(navigator.userAgent) && indexedDB.databases ? new Promise(function(y) {
                    function l() {
                        return indexedDB.databases().finally(y)
                    }
                    f = setInterval(l, 100), l()
                }).finally(function() {
                    return clearInterval(f)
                }) : Promise.resolve()).then(u)]).then(function() {
                    return a(), n.onReadyBeingFired = [], A.resolve(Ot(function() {
                        return e.on.ready.fire(e.vip)
                    })).then(function y() {
                        if (0 < n.onReadyBeingFired.length) {
                            var l = n.onReadyBeingFired.reduce(nt, $);
                            return n.onReadyBeingFired = [], A.resolve(Ot(function() {
                                return l(e.vip)
                            })).then(y)
                        }
                    })
                }).finally(function() {
                    n.openCanceller === r && (n.onReadyBeingFired = null, n.isBeingOpened = !1)
                }).catch(function(y) {
                    n.dbOpenError = y;
                    try {
                        p && p.abort()
                    } catch (l) {}
                    return r === n.openCanceller && e._close(), H(y)
                }).finally(function() {
                    n.openComplete = !0, c()
                }).then(function() {
                    var y;
                    return s && (y = {}, e.tables.forEach(function(l) {
                        l.schema.indexes.forEach(function(d) {
                            d.name && (y["idb://".concat(e.name, "/").concat(l.name, "/").concat(d.name)] = new oe(-1 / 0, [
                                [
                                    []
                                ]
                            ]))
                        }), y["idb://".concat(e.name, "/").concat(l.name, "/")] = y["idb://".concat(e.name, "/").concat(l.name, "/:dels")] = new oe(-1 / 0, [
                            [
                                []
                            ]
                        ])
                    }), Ie(hn).fire(y), St(y, !0)), e
                })
            }

            function Ct(e) {
                function n(i) {
                    return e.next(i)
                }
                var t = o(n),
                    r = o(function(i) {
                        return e.throw(i)
                    });

                function o(i) {
                    return function(f) {
                        var u = i(f),
                            f = u.value;
                        return u.done ? f : f && typeof f.then == "function" ? f.then(t, r) : D(f) ? Promise.all(f).then(t, r) : t(f)
                    }
                }
                return o(n)()
            }

            function zn(e, n, t) {
                for (var r = D(e) ? e.slice() : [e], o = 0; o < t; ++o) r.push(n);
                return r
            }
            var yo = {
                stack: "dbcore",
                name: "VirtualIndexMiddleware",
                level: 1,
                create: function(e) {
                    return I(I({}, e), {
                        table: function(n) {
                            var t = e.table(n),
                                r = t.schema,
                                o = {},
                                i = [];

                            function a(s, y, l) {
                                var d = pn(s),
                                    v = o[d] = o[d] || [],
                                    h = s == null ? 0 : typeof s == "string" ? 1 : s.length,
                                    m = 0 < y,
                                    m = I(I({}, l), {
                                        name: m ? "".concat(d, "(virtual-from:").concat(l.name, ")") : l.name,
                                        lowLevelIndex: l,
                                        isVirtual: m,
                                        keyTail: y,
                                        keyLength: h,
                                        extractKey: gt(s),
                                        unique: !m && l.unique
                                    });
                                return v.push(m), m.isPrimaryKey || i.push(m), 1 < h && a(h === 2 ? s[0] : s.slice(0, h - 1), y + 1, l), v.sort(function(g, b) {
                                    return g.keyTail - b.keyTail
                                }), m
                            }
                            n = a(r.primaryKey.keyPath, 0, r.primaryKey), o[":id"] = [n];
                            for (var u = 0, f = r.indexes; u < f.length; u++) {
                                var c = f[u];
                                a(c.keyPath, 0, c)
                            }

                            function p(s) {
                                var y, l = s.query.index;
                                return l.isVirtual ? I(I({}, s), {
                                    query: {
                                        index: l.lowLevelIndex,
                                        range: (y = s.query.range, l = l.keyTail, {
                                            type: y.type === 1 ? 2 : y.type,
                                            lower: zn(y.lower, y.lowerOpen ? e.MAX_KEY : e.MIN_KEY, l),
                                            lowerOpen: !0,
                                            upper: zn(y.upper, y.upperOpen ? e.MIN_KEY : e.MAX_KEY, l),
                                            upperOpen: !0
                                        })
                                    }
                                }) : s
                            }
                            return I(I({}, t), {
                                schema: I(I({}, r), {
                                    primaryKey: n,
                                    indexes: i,
                                    getIndexByKeyPath: function(s) {
                                        return (s = o[pn(s)]) && s[0]
                                    }
                                }),
                                count: function(s) {
                                    return t.count(p(s))
                                },
                                query: function(s) {
                                    return t.query(p(s))
                                },
                                openCursor: function(s) {
                                    var y = s.query.index,
                                        l = y.keyTail,
                                        d = y.isVirtual,
                                        v = y.keyLength;
                                    return d ? t.openCursor(p(s)).then(function(m) {
                                        return m && h(m)
                                    }) : t.openCursor(s);

                                    function h(m) {
                                        return Object.create(m, {
                                            continue: {
                                                value: function(g) {
                                                    g != null ? m.continue(zn(g, s.reverse ? e.MAX_KEY : e.MIN_KEY, l)) : s.unique ? m.continue(m.key.slice(0, v).concat(s.reverse ? e.MIN_KEY : e.MAX_KEY, l)) : m.continue()
                                                }
                                            },
                                            continuePrimaryKey: {
                                                value: function(g, b) {
                                                    m.continuePrimaryKey(zn(g, e.MAX_KEY, l), b)
                                                }
                                            },
                                            primaryKey: {
                                                get: function() {
                                                    return m.primaryKey
                                                }
                                            },
                                            key: {
                                                get: function() {
                                                    var g = m.key;
                                                    return v === 1 ? g[0] : g.slice(0, v)
                                                }
                                            },
                                            value: {
                                                get: function() {
                                                    return m.value
                                                }
                                            }
                                        })
                                    }
                                }
                            })
                        }
                    })
                }
            };

            function Kt(e, n, t, r) {
                return t = t || {}, r = r || "", W(e).forEach(function(o) {
                    var i, a, u;
                    Y(n, o) ? (i = e[o], a = n[o], typeof i == "object" && typeof a == "object" && i && a ? (u = Xn(i)) !== Xn(a) ? t[r + o] = n[o] : u === "Object" ? Kt(i, a, t, r + o + ".") : i !== a && (t[r + o] = n[o]) : i !== a && (t[r + o] = n[o])) : t[r + o] = void 0
                }), W(n).forEach(function(o) {
                    Y(e, o) || (t[r + o] = n[o])
                }), t
            }

            function Dt(e, n) {
                return n.type === "delete" ? n.keys : n.keys || n.values.map(e.extractKey)
            }
            var vo = {
                stack: "dbcore",
                name: "HooksMiddleware",
                level: 2,
                create: function(e) {
                    return I(I({}, e), {
                        table: function(n) {
                            var t = e.table(n),
                                r = t.schema.primaryKey;
                            return I(I({}, t), {
                                mutate: function(o) {
                                    var i = S.trans,
                                        a = i.table(n).hook,
                                        u = a.deleting,
                                        f = a.creating,
                                        c = a.updating;
                                    switch (o.type) {
                                        case "add":
                                            if (f.fire === $) break;
                                            return i._promise("readwrite", function() {
                                                return p(o)
                                            }, !0);
                                        case "put":
                                            if (f.fire === $ && c.fire === $) break;
                                            return i._promise("readwrite", function() {
                                                return p(o)
                                            }, !0);
                                        case "delete":
                                            if (u.fire === $) break;
                                            return i._promise("readwrite", function() {
                                                return p(o)
                                            }, !0);
                                        case "deleteRange":
                                            if (u.fire === $) break;
                                            return i._promise("readwrite", function() {
                                                return (function s(y, l, d) {
                                                    return t.query({
                                                        trans: y,
                                                        values: !1,
                                                        query: {
                                                            index: r,
                                                            range: l
                                                        },
                                                        limit: d
                                                    }).then(function(v) {
                                                        var h = v.result;
                                                        return p({
                                                            type: "delete",
                                                            keys: h,
                                                            trans: y
                                                        }).then(function(m) {
                                                            return 0 < m.numFailures ? Promise.reject(m.failures[0]) : h.length < d ? {
                                                                failures: [],
                                                                numFailures: 0,
                                                                lastResult: void 0
                                                            } : s(y, I(I({}, l), {
                                                                lower: h[h.length - 1],
                                                                lowerOpen: !0
                                                            }), d)
                                                        })
                                                    })
                                                })(o.trans, o.range, 1e4)
                                            }, !0)
                                    }
                                    return t.mutate(o);

                                    function p(s) {
                                        var y, l, d, v = S.trans,
                                            h = s.keys || Dt(r, s);
                                        if (!h) throw new Error("Keys missing");
                                        return (s = s.type === "add" || s.type === "put" ? I(I({}, s), {
                                            keys: h
                                        }) : I({}, s)).type !== "delete" && (s.values = ee([], s.values)), s.keys && (s.keys = ee([], s.keys)), y = t, d = h, ((l = s).type === "add" ? Promise.resolve([]) : y.getMany({
                                            trans: l.trans,
                                            keys: d,
                                            cache: "immutable"
                                        })).then(function(m) {
                                            var g = h.map(function(b, w) {
                                                var x, P, k, O = m[w],
                                                    E = {
                                                        onerror: null,
                                                        onsuccess: null
                                                    };
                                                return s.type === "delete" ? u.fire.call(E, b, O, v) : s.type === "add" || O === void 0 ? (x = f.fire.call(E, b, s.values[w], v), b == null && x != null && (s.keys[w] = b = x, r.outbound || ae(s.values[w], r.keyPath, b))) : (x = Kt(O, s.values[w]), (P = c.fire.call(E, x, b, O, v)) && (k = s.values[w], Object.keys(P).forEach(function(_) {
                                                    Y(k, _) ? k[_] = P[_] : ae(k, _, P[_])
                                                }))), E
                                            });
                                            return t.mutate(s).then(function(b) {
                                                for (var w = b.failures, x = b.results, P = b.numFailures, b = b.lastResult, k = 0; k < h.length; ++k) {
                                                    var O = (x || h)[k],
                                                        E = g[k];
                                                    O == null ? E.onerror && E.onerror(w[k]) : E.onsuccess && E.onsuccess(s.type === "put" && m[k] ? s.values[k] : O)
                                                }
                                                return {
                                                    failures: w,
                                                    results: x,
                                                    numFailures: P,
                                                    lastResult: b
                                                }
                                            }).catch(function(b) {
                                                return g.forEach(function(w) {
                                                    return w.onerror && w.onerror(b)
                                                }), Promise.reject(b)
                                            })
                                        })
                                    }
                                }
                            })
                        }
                    })
                }
            };

            function br(e, n, t) {
                try {
                    if (!n || n.keys.length < e.length) return null;
                    for (var r = [], o = 0, i = 0; o < n.keys.length && i < e.length; ++o) L(n.keys[o], e[i]) === 0 && (r.push(t ? Ce(n.values[o]) : n.values[o]), ++i);
                    return r.length === e.length ? r : null
                } catch (a) {
                    return null
                }
            }
            var mo = {
                stack: "dbcore",
                level: -1,
                create: function(e) {
                    return {
                        table: function(n) {
                            var t = e.table(n);
                            return I(I({}, t), {
                                getMany: function(r) {
                                    if (!r.cache) return t.getMany(r);
                                    var o = br(r.keys, r.trans._cache, r.cache === "clone");
                                    return o ? A.resolve(o) : t.getMany(r).then(function(i) {
                                        return r.trans._cache = {
                                            keys: r.keys,
                                            values: r.cache === "clone" ? Ce(i) : i
                                        }, i
                                    })
                                },
                                mutate: function(r) {
                                    return r.type !== "add" && (r.trans._cache = null), t.mutate(r)
                                }
                            })
                        }
                    }
                }
            };

            function wr(e, n) {
                return e.trans.mode === "readonly" && !!e.subscr && !e.trans.explicit && e.trans.db._options.cache !== "disabled" && !n.schema.primaryKey.outbound
            }

            function _r(e, n) {
                switch (e) {
                    case "query":
                        return n.values && !n.unique;
                    case "get":
                    case "getMany":
                    case "count":
                    case "openCursor":
                        return !1
                }
            }
            var go = {
                stack: "dbcore",
                level: 0,
                name: "Observability",
                create: function(e) {
                    var n = e.schema.name,
                        t = new oe(e.MIN_KEY, e.MAX_KEY);
                    return I(I({}, e), {
                        transaction: function(r, o, i) {
                            if (S.subscr && o !== "readonly") throw new K.ReadOnly("Readwrite transaction in liveQuery context. Querier source: ".concat(S.querier));
                            return e.transaction(r, o, i)
                        },
                        table: function(r) {
                            var o = e.table(r),
                                i = o.schema,
                                a = i.primaryKey,
                                s = i.indexes,
                                u = a.extractKey,
                                f = a.outbound,
                                c = a.autoIncrement && s.filter(function(l) {
                                    return l.compound && l.keyPath.includes(a.keyPath)
                                }),
                                p = I(I({}, o), {
                                    mutate: function(l) {
                                        function d(_) {
                                            return _ = "idb://".concat(n, "/").concat(r, "/").concat(_), b[_] || (b[_] = new oe)
                                        }
                                        var v, h, m, g = l.trans,
                                            b = l.mutatedParts || (l.mutatedParts = {}),
                                            w = d(""),
                                            x = d(":dels"),
                                            P = l.type,
                                            E = l.type === "deleteRange" ? [l.range] : l.type === "delete" ? [l.keys] : l.values.length < 50 ? [Dt(a, l).filter(function(_) {
                                                return _
                                            }), l.values] : [],
                                            k = E[0],
                                            O = E[1],
                                            E = l.trans._cache;
                                        return D(k) ? (w.addKeys(k), (E = P === "delete" || k.length === O.length ? br(k, E) : null) || x.addKeys(k), (E || O) && (v = d, h = E, m = O, i.indexes.forEach(function(_) {
                                            var T = v(_.name || "");

                                            function j(q) {
                                                return q != null ? _.extractKey(q) : null
                                            }

                                            function M(q) {
                                                return _.multiEntry && D(q) ? q.forEach(function(ce) {
                                                    return T.addKey(ce)
                                                }) : T.addKey(q)
                                            }(h || m).forEach(function(q, ne) {
                                                var B = h && j(h[ne]),
                                                    ne = m && j(m[ne]);
                                                L(B, ne) !== 0 && (B != null && M(B), ne != null && M(ne))
                                            })
                                        }))) : k ? (O = {
                                            from: k.lower,
                                            to: k.upper
                                        }, x.add(O), w.add(O)) : (w.add(t), x.add(t), i.indexes.forEach(function(_) {
                                            return d(_.name).add(t)
                                        })), o.mutate(l).then(function(_) {
                                            return !k || l.type !== "add" && l.type !== "put" || (w.addKeys(_.results), c && c.forEach(function(T) {
                                                var j = l.values.map(function(q) {
                                                        return T.extractKey(q)
                                                    }),
                                                    M = T.keyPath.findIndex(function(q) {
                                                        return q === a.keyPath
                                                    });
                                                _.results.forEach(function(q) {
                                                    return j[M] = q
                                                }), d(T.name).addKeys(j)
                                            })), g.mutatedParts = Ln(g.mutatedParts || {}, b), _
                                        })
                                    }
                                }),
                                s = function(d) {
                                    var v = d.query,
                                        d = v.index,
                                        v = v.range;
                                    return [d, new oe((d = v.lower) !== null && d !== void 0 ? d : e.MIN_KEY, (v = v.upper) !== null && v !== void 0 ? v : e.MAX_KEY)]
                                },
                                y = {
                                    get: function(l) {
                                        return [a, new oe(l.key)]
                                    },
                                    getMany: function(l) {
                                        return [a, new oe().addKeys(l.keys)]
                                    },
                                    count: s,
                                    query: s,
                                    openCursor: s
                                };
                            return W(y).forEach(function(l) {
                                p[l] = function(d) {
                                    var v = S.subscr,
                                        h = !!v,
                                        m = wr(S, o) && _r(l, d) ? d.obsSet = {} : v;
                                    if (h) {
                                        var g = function(O) {
                                                return O = "idb://".concat(n, "/").concat(r, "/").concat(O), m[O] || (m[O] = new oe)
                                            },
                                            b = g(""),
                                            w = g(":dels"),
                                            v = y[l](d),
                                            h = v[0],
                                            v = v[1];
                                        if ((l === "query" && h.isPrimaryKey && !d.values ? w : g(h.name || "")).add(v), !h.isPrimaryKey) {
                                            if (l !== "count") {
                                                var x = l === "query" && f && d.values && o.query(I(I({}, d), {
                                                    values: !1
                                                }));
                                                return o[l].apply(this, arguments).then(function(O) {
                                                    if (l === "query") {
                                                        if (f && d.values) return x.then(function(j) {
                                                            return j = j.result, b.addKeys(j), O
                                                        });
                                                        var E = d.values ? O.result.map(u) : O.result;
                                                        (d.values ? b : w).addKeys(E)
                                                    } else if (l === "openCursor") {
                                                        var _ = O,
                                                            T = d.values;
                                                        return _ && Object.create(_, {
                                                            key: {
                                                                get: function() {
                                                                    return w.addKey(_.primaryKey), _.key
                                                                }
                                                            },
                                                            primaryKey: {
                                                                get: function() {
                                                                    var j = _.primaryKey;
                                                                    return w.addKey(j), j
                                                                }
                                                            },
                                                            value: {
                                                                get: function() {
                                                                    return T && b.addKey(_.primaryKey), _.value
                                                                }
                                                            }
                                                        })
                                                    }
                                                    return O
                                                })
                                            }
                                            w.add(t)
                                        }
                                    }
                                    return o[l].apply(this, arguments)
                                }
                            }), p
                        }
                    })
                }
            };

            function xr(e, n, t) {
                if (t.numFailures === 0) return n;
                if (n.type === "deleteRange") return null;
                var r = n.keys ? n.keys.length : "values" in n && n.values ? n.values.length : 1;
                return t.numFailures === r ? null : (n = I({}, n), D(n.keys) && (n.keys = n.keys.filter(function(o, i) {
                    return !(i in t.failures)
                })), "values" in n && D(n.values) && (n.values = n.values.filter(function(o, i) {
                    return !(i in t.failures)
                })), n)
            }

            function Tt(e, n) {
                return t = e, ((r = n).lower === void 0 || (r.lowerOpen ? 0 < L(t, r.lower) : 0 <= L(t, r.lower))) && (e = e, (n = n).upper === void 0 || (n.upperOpen ? L(e, n.upper) < 0 : L(e, n.upper) <= 0));
                var t, r
            }

            function kr(e, n, y, r, o, i) {
                if (!y || y.length === 0) return e;
                var a = n.query.index,
                    u = a.multiEntry,
                    f = n.query.range,
                    c = r.schema.primaryKey.extractKey,
                    p = a.extractKey,
                    s = (a.lowLevelIndex || a).extractKey,
                    y = y.reduce(function(l, d) {
                        var v = l,
                            h = [];
                        if (d.type === "add" || d.type === "put")
                            for (var m = new oe, g = d.values.length - 1; 0 <= g; --g) {
                                var b, w = d.values[g],
                                    x = c(w);
                                m.hasKey(x) || (b = p(w), (u && D(b) ? b.some(function(E) {
                                    return Tt(E, f)
                                }) : Tt(b, f)) && (m.addKey(x), h.push(w)))
                            }
                        switch (d.type) {
                            case "add":
                                v = l.concat(n.values ? h : h.map(function(_) {
                                    return c(_)
                                }));
                                break;
                            case "put":
                                var P = new oe().addKeys(d.values.map(function(_) {
                                        return c(_)
                                    })),
                                    v = l.filter(function(_) {
                                        return !P.hasKey(n.values ? c(_) : _)
                                    }).concat(n.values ? h : h.map(function(_) {
                                        return c(_)
                                    }));
                                break;
                            case "delete":
                                var k = new oe().addKeys(d.keys);
                                v = l.filter(function(_) {
                                    return !k.hasKey(n.values ? c(_) : _)
                                });
                                break;
                            case "deleteRange":
                                var O = d.range;
                                v = l.filter(function(_) {
                                    return !Tt(c(_), O)
                                })
                        }
                        return v
                    }, e);
                return y === e ? e : (y.sort(function(l, d) {
                    return L(s(l), s(d)) || L(c(l), c(d))
                }), n.limit && n.limit < 1 / 0 && (y.length > n.limit ? y.length = n.limit : e.length === n.limit && y.length < n.limit && (o.dirty = !0)), i ? Object.freeze(y) : y)
            }

            function Or(e, n) {
                return L(e.lower, n.lower) === 0 && L(e.upper, n.upper) === 0 && !!e.lowerOpen == !!n.lowerOpen && !!e.upperOpen == !!n.upperOpen
            }

            function bo(e, n) {
                return (function(t, r, o, i) {
                    if (t === void 0) return r !== void 0 ? -1 : 0;
                    if (r === void 0) return 1;
                    if ((r = L(t, r)) === 0) {
                        if (o && i) return 0;
                        if (o) return 1;
                        if (i) return -1
                    }
                    return r
                })(e.lower, n.lower, e.lowerOpen, n.lowerOpen) <= 0 && 0 <= (function(t, r, o, i) {
                    if (t === void 0) return r !== void 0 ? 1 : 0;
                    if (r === void 0) return -1;
                    if ((r = L(t, r)) === 0) {
                        if (o && i) return 0;
                        if (o) return -1;
                        if (i) return 1
                    }
                    return r
                })(e.upper, n.upper, e.upperOpen, n.upperOpen)
            }

            function wo(e, n, t, r) {
                e.subscribers.add(t), r.addEventListener("abort", function() {
                    var o, i;
                    e.subscribers.delete(t), e.subscribers.size === 0 && (o = e, i = n, setTimeout(function() {
                        o.subscribers.size === 0 && Ke(i, o)
                    }, 3e3))
                })
            }
            var _o = {
                stack: "dbcore",
                level: 0,
                name: "Cache",
                create: function(e) {
                    var n = e.schema.name;
                    return I(I({}, e), {
                        transaction: function(t, r, o) {
                            var i, a, u = e.transaction(t, r, o);
                            return r === "readwrite" && (a = (i = new AbortController).signal, o = function(f) {
                                return function() {
                                    if (i.abort(), r === "readwrite") {
                                        for (var c = new Set, p = 0, s = t; p < s.length; p++) {
                                            var y = s[p],
                                                l = Fe["idb://".concat(n, "/").concat(y)];
                                            if (l) {
                                                var d = e.table(y),
                                                    v = l.optimisticOps.filter(function(T) {
                                                        return T.trans === u
                                                    });
                                                if (u._explicit && f && u.mutatedParts)
                                                    for (var h = 0, m = Object.values(l.queries.query); h < m.length; h++)
                                                        for (var g = 0, b = (P = m[h]).slice(); g < b.length; g++) Et((k = b[g]).obsSet, u.mutatedParts) && (Ke(P, k), k.subscribers.forEach(function(T) {
                                                            return c.add(T)
                                                        }));
                                                else if (0 < v.length) {
                                                    l.optimisticOps = l.optimisticOps.filter(function(T) {
                                                        return T.trans !== u
                                                    });
                                                    for (var w = 0, x = Object.values(l.queries.query); w < x.length; w++)
                                                        for (var P, k, O, E = 0, _ = (P = x[w]).slice(); E < _.length; E++)(k = _[E]).res != null && u.mutatedParts && (f && !k.dirty ? (O = Object.isFrozen(k.res), O = kr(k.res, k.req, v, d, k, O), k.dirty ? (Ke(P, k), k.subscribers.forEach(function(T) {
                                                            return c.add(T)
                                                        })) : O !== k.res && (k.res = O, k.promise = A.resolve({
                                                            result: O
                                                        }))) : (k.dirty && Ke(P, k), k.subscribers.forEach(function(T) {
                                                            return c.add(T)
                                                        })))
                                                }
                                            }
                                        }
                                        c.forEach(function(T) {
                                            return T()
                                        })
                                    }
                                }
                            }, u.addEventListener("abort", o(!1), {
                                signal: a
                            }), u.addEventListener("error", o(!1), {
                                signal: a
                            }), u.addEventListener("complete", o(!0), {
                                signal: a
                            })), u
                        },
                        table: function(t) {
                            var r = e.table(t),
                                o = r.schema.primaryKey;
                            return I(I({}, r), {
                                mutate: function(i) {
                                    var a = S.trans;
                                    if (o.outbound || a.db._options.cache === "disabled" || a.explicit) return r.mutate(i);
                                    var u = Fe["idb://".concat(n, "/").concat(t)];
                                    return u ? (a = r.mutate(i), i.type !== "add" && i.type !== "put" || !(50 <= i.values.length || Dt(o, i).some(function(f) {
                                        return f == null
                                    })) ? (u.optimisticOps.push(i), i.mutatedParts && Vn(i.mutatedParts), a.then(function(f) {
                                        0 < f.numFailures && (Ke(u.optimisticOps, i), (f = xr(0, i, f)) && u.optimisticOps.push(f), i.mutatedParts && Vn(i.mutatedParts))
                                    }), a.catch(function() {
                                        Ke(u.optimisticOps, i), i.mutatedParts && Vn(i.mutatedParts)
                                    })) : a.then(function(f) {
                                        var c = xr(0, I(I({}, i), {
                                            values: i.values.map(function(l, s) {
                                                var y, l = (y = o.keyPath) !== null && y !== void 0 && y.includes(".") ? Ce(l) : I({}, l);
                                                return ae(l, o.keyPath, f.results[s]), l
                                            })
                                        }), f);
                                        u.optimisticOps.push(c), queueMicrotask(function() {
                                            return i.mutatedParts && Vn(i.mutatedParts)
                                        })
                                    }), a) : r.mutate(i)
                                },
                                query: function(i) {
                                    if (!wr(S, r) || !_r("query", i)) return r.query(i);
                                    var a = ((c = S.trans) === null || c === void 0 ? void 0 : c.db._options.cache) === "immutable",
                                        s = S,
                                        u = s.requery,
                                        f = s.signal,
                                        c = (function(d, v, h, m) {
                                            var g = Fe["idb://".concat(d, "/").concat(v)];
                                            if (!g) return [];
                                            if (!(v = g.queries[h])) return [null, !1, g, null];
                                            var b = v[(m.query ? m.query.index.name : null) || ""];
                                            if (!b) return [null, !1, g, null];
                                            switch (h) {
                                                case "query":
                                                    var w = b.find(function(x) {
                                                        return x.req.limit === m.limit && x.req.values === m.values && Or(x.req.query.range, m.query.range)
                                                    });
                                                    return w ? [w, !0, g, b] : [b.find(function(x) {
                                                        return ("limit" in x.req ? x.req.limit : 1 / 0) >= m.limit && (!m.values || x.req.values) && bo(x.req.query.range, m.query.range)
                                                    }), !1, g, b];
                                                case "count":
                                                    return w = b.find(function(x) {
                                                        return Or(x.req.query.range, m.query.range)
                                                    }), [w, !!w, g, b]
                                            }
                                        })(n, t, "query", i),
                                        p = c[0],
                                        s = c[1],
                                        y = c[2],
                                        l = c[3];
                                    return p && s ? p.obsSet = i.obsSet : (s = r.query(i).then(function(d) {
                                        var v = d.result;
                                        if (p && (p.res = v), a) {
                                            for (var h = 0, m = v.length; h < m; ++h) Object.freeze(v[h]);
                                            Object.freeze(v)
                                        } else d.result = Ce(v);
                                        return d
                                    }).catch(function(d) {
                                        return l && p && Ke(l, p), Promise.reject(d)
                                    }), p = {
                                        obsSet: i.obsSet,
                                        promise: s,
                                        subscribers: new Set,
                                        type: "query",
                                        req: i,
                                        dirty: !1
                                    }, l ? l.push(p) : (l = [p], (y = y || (Fe["idb://".concat(n, "/").concat(t)] = {
                                        queries: {
                                            query: {},
                                            count: {}
                                        },
                                        objs: new Map,
                                        optimisticOps: [],
                                        unsignaledParts: {}
                                    })).queries.query[i.query.index.name || ""] = l)), wo(p, l, u, f), p.promise.then(function(d) {
                                        return {
                                            result: kr(d.result, i, y == null ? void 0 : y.optimisticOps, r, p, a)
                                        }
                                    })
                                }
                            })
                        }
                    })
                }
            };

            function $n(e, n) {
                return new Proxy(e, {
                    get: function(t, r, o) {
                        return r === "db" ? n : Reflect.get(t, r, o)
                    }
                })
            }
            var ge = (X.prototype.version = function(e) {
                if (isNaN(e) || e < .1) throw new K.Type("Given version is not a positive number");
                if (e = Math.round(10 * e) / 10, this.idbdb || this._state.isBeingOpened) throw new K.Schema("Cannot add version when database is open");
                this.verno = Math.max(this.verno, e);
                var n = this._versions,
                    t = n.filter(function(r) {
                        return r._cfg.version === e
                    })[0];
                return t || (t = new this.Version(e), n.push(t), n.sort(co), t.stores({}), this._state.autoSchema = !1, t)
            }, X.prototype._whenReady = function(e) {
                var n = this;
                return this.idbdb && (this._state.openComplete || S.letThrough || this._vip) ? e() : new A(function(t, r) {
                    if (n._state.openComplete) return r(new K.DatabaseClosed(n._state.dbOpenError));
                    if (!n._state.isBeingOpened) {
                        if (!n._state.autoOpen) return void r(new K.DatabaseClosed);
                        n.open().catch($)
                    }
                    n._state.dbReadyPromise.then(t, r)
                }).then(e)
            }, X.prototype.use = function(e) {
                var n = e.stack,
                    t = e.create,
                    r = e.level,
                    o = e.name;
                return o && this.unuse({
                    stack: n,
                    name: o
                }), e = this._middlewares[n] || (this._middlewares[n] = []), e.push({
                    stack: n,
                    create: t,
                    level: r == null ? 10 : r,
                    name: o
                }), e.sort(function(i, a) {
                    return i.level - a.level
                }), this
            }, X.prototype.unuse = function(e) {
                var n = e.stack,
                    t = e.name,
                    r = e.create;
                return n && this._middlewares[n] && (this._middlewares[n] = this._middlewares[n].filter(function(o) {
                    return r ? o.create !== r : !!t && o.name !== t
                })), this
            }, X.prototype.open = function() {
                var e = this;
                return Re(ke, function() {
                    return po(e)
                })
            }, X.prototype._close = function() {
                var e = this._state,
                    n = Ge.indexOf(this);
                if (0 <= n && Ge.splice(n, 1), this.idbdb) {
                    try {
                        this.idbdb.close()
                    } catch (t) {}
                    this.idbdb = null
                }
                e.isBeingOpened || (e.dbReadyPromise = new A(function(t) {
                    e.dbReadyResolve = t
                }), e.openCanceller = new A(function(t, r) {
                    e.cancelOpen = r
                }))
            }, X.prototype.close = function(t) {
                var n = (t === void 0 ? {
                        disableAutoOpen: !0
                    } : t).disableAutoOpen,
                    t = this._state;
                n ? (t.isBeingOpened && t.cancelOpen(new K.DatabaseClosed), this._close(), t.autoOpen = !1, t.dbOpenError = new K.DatabaseClosed) : (this._close(), t.autoOpen = this._options.autoOpen || t.isBeingOpened, t.openComplete = !1, t.dbOpenError = null)
            }, X.prototype.delete = function(e) {
                var n = this;
                e === void 0 && (e = {
                    disableAutoOpen: !0
                });
                var t = 0 < arguments.length && typeof arguments[0] != "object",
                    r = this._state;
                return new A(function(o, i) {
                    function a() {
                        n.close(e);
                        var u = n._deps.indexedDB.deleteDatabase(n.name);
                        u.onsuccess = G(function() {
                            var f, c, p;
                            f = n._deps, c = n.name, p = f.indexedDB, f = f.IDBKeyRange, kt(p) || c === Cn || xt(p, f).delete(c).catch($), o()
                        }), u.onerror = fe(i), u.onblocked = n._fireOnBlocked
                    }
                    if (t) throw new K.InvalidArgument("Invalid closeOptions argument to db.delete()");
                    r.isBeingOpened ? r.dbReadyPromise.then(a) : a()
                })
            }, X.prototype.backendDB = function() {
                return this.idbdb
            }, X.prototype.isOpen = function() {
                return this.idbdb !== null
            }, X.prototype.hasBeenClosed = function() {
                var e = this._state.dbOpenError;
                return e && e.name === "DatabaseClosed"
            }, X.prototype.hasFailed = function() {
                return this._state.dbOpenError !== null
            }, X.prototype.dynamicallyOpened = function() {
                return this._state.autoSchema
            }, Object.defineProperty(X.prototype, "tables", {
                get: function() {
                    var e = this;
                    return W(this._allTables).map(function(n) {
                        return e._allTables[n]
                    })
                },
                enumerable: !1,
                configurable: !0
            }), X.prototype.transaction = function() {
                var e = function(n, t, r) {
                    var o = arguments.length;
                    if (o < 2) throw new K.InvalidArgument("Too few arguments");
                    for (var i = new Array(o - 1); --o;) i[o - 1] = arguments[o];
                    return r = i.pop(), [n, zt(i), r]
                }.apply(this, arguments);
                return this._transaction.apply(this, e)
            }, X.prototype._transaction = function(e, n, t) {
                var r = this,
                    o = S.trans;
                o && o.db === this && e.indexOf("!") === -1 || (o = null);
                var i, a, u = e.indexOf("?") !== -1;
                e = e.replace("!", "").replace("?", "");
                try {
                    if (a = n.map(function(c) {
                            if (c = c instanceof r.Table ? c.name : c, typeof c != "string") throw new TypeError("Invalid table argument to Dexie.transaction(). Only Table or String are allowed");
                            return c
                        }), e == "r" || e === lt) i = lt;
                    else {
                        if (e != "rw" && e != ft) throw new K.InvalidArgument("Invalid transaction mode: " + e);
                        i = ft
                    }
                    if (o) {
                        if (o.mode === lt && i === ft) {
                            if (!u) throw new K.SubTransaction("Cannot enter a sub-transaction with READWRITE mode when parent transaction is READONLY");
                            o = null
                        }
                        o && a.forEach(function(c) {
                            if (o && o.storeNames.indexOf(c) === -1) {
                                if (!u) throw new K.SubTransaction("Table " + c + " not included in parent transaction.");
                                o = null
                            }
                        }), u && o && !o.active && (o = null)
                    }
                } catch (c) {
                    return o ? o._promise(null, function(p, s) {
                        s(c)
                    }) : H(c)
                }
                var f = function c(p, s, y, l, d) {
                    return A.resolve().then(function() {
                        var v = S.transless || S,
                            h = p._createTransaction(s, y, p._dbSchema, l);
                        if (h.explicit = !0, v = {
                                trans: h,
                                transless: v
                            }, l) h.idbtrans = l.idbtrans;
                        else try {
                            h.create(), h.idbtrans._explicit = !0, p._state.PR1398_maxLoop = 3
                        } catch (b) {
                            return b.name === et.InvalidState && p.isOpen() && 0 < --p._state.PR1398_maxLoop ? (console.warn("Dexie: Need to reopen db"), p.close({
                                disableAutoOpen: !1
                            }), p.open().then(function() {
                                return c(p, s, y, null, d)
                            })) : H(b)
                        }
                        var m, g = Zn(d);
                        return g && Qe(), v = A.follow(function() {
                            var b;
                            (m = d.call(h, h)) && (g ? (b = Pe.bind(null, null), m.then(b, b)) : typeof m.next == "function" && typeof m.throw == "function" && (m = Ct(m)))
                        }, v), (m && typeof m.then == "function" ? A.resolve(m).then(function(b) {
                            return h.active ? b : H(new K.PrematureCommit("Transaction committed too early. See http://bit.ly/2kdckMn"))
                        }) : v.then(function() {
                            return m
                        })).then(function(b) {
                            return l && h._resolve(), h._completion.then(function() {
                                return b
                            })
                        }).catch(function(b) {
                            return h._reject(b), H(b)
                        })
                    })
                }.bind(null, this, i, a, o, t);
                return o ? o._promise(i, f, "lock") : S.trans ? Re(S.transless, function() {
                    return r._whenReady(f)
                }) : this._whenReady(f)
            }, X.prototype.table = function(e) {
                if (!Y(this._allTables, e)) throw new K.InvalidTable("Table ".concat(e, " does not exist"));
                return this._allTables[e]
            }, X);

            function X(e, n) {
                var t = this;
                this._middlewares = {}, this.verno = 0;
                var r = X.dependencies;
                this._options = n = I({
                    addons: X.addons,
                    autoOpen: !0,
                    indexedDB: r.indexedDB,
                    IDBKeyRange: r.IDBKeyRange,
                    cache: "cloned"
                }, n), this._deps = {
                    indexedDB: n.indexedDB,
                    IDBKeyRange: n.IDBKeyRange
                }, r = n.addons, this._dbSchema = {}, this._versions = [], this._storeNames = [], this._allTables = {}, this.idbdb = null, this._novip = this;
                var o, i, a, u, f, c = {
                    dbOpenError: null,
                    isBeingOpened: !1,
                    onReadyBeingFired: null,
                    openComplete: !1,
                    dbReadyResolve: $,
                    dbReadyPromise: null,
                    cancelOpen: $,
                    openCanceller: null,
                    autoSchema: !0,
                    PR1398_maxLoop: 3,
                    autoOpen: n.autoOpen
                };
                c.dbReadyPromise = new A(function(s) {
                    c.dbReadyResolve = s
                }), c.openCanceller = new A(function(s, y) {
                    c.cancelOpen = y
                }), this._state = c, this.name = e, this.on = sn(this, "populate", "blocked", "versionchange", "close", {
                    ready: [nt, $]
                }), this.on.ready.subscribe = Ut(this.on.ready.subscribe, function(s) {
                    return function(y, l) {
                        X.vip(function() {
                            var d, v = t._state;
                            v.openComplete ? (v.dbOpenError || A.resolve().then(y), l && s(y)) : v.onReadyBeingFired ? (v.onReadyBeingFired.push(y), l && s(y)) : (s(y), d = t, l || s(function h() {
                                d.on.ready.unsubscribe(y), d.on.ready.unsubscribe(h)
                            }))
                        })
                    }
                }), this.Collection = (o = this, cn(to.prototype, function(m, h) {
                    this.db = o;
                    var l = nr,
                        d = null;
                    if (h) try {
                        l = h()
                    } catch (g) {
                        d = g
                    }
                    var v = m._ctx,
                        h = v.table,
                        m = h.hook.reading.fire;
                    this._ctx = {
                        table: h,
                        index: v.index,
                        isPrimKey: !v.index || h.schema.primKey.keyPath && v.index === h.schema.primKey.name,
                        range: l,
                        keysOnly: !1,
                        dir: "next",
                        unique: "",
                        algorithm: null,
                        filter: null,
                        replayFilter: null,
                        justLimit: !0,
                        isMatch: null,
                        offset: 0,
                        limit: 1 / 0,
                        error: d,
                        or: v.or,
                        valueMapper: m !== nn ? m : null
                    }
                })), this.Table = (i = this, cn(ir.prototype, function(s, y, l) {
                    this.db = i, this._tx = l, this.name = s, this.schema = y, this.hook = i._allTables[s] ? i._allTables[s].hook : sn(null, {
                        creating: [Yr, $],
                        reading: [Wr, nn],
                        updating: [Gr, $],
                        deleting: [Qr, $]
                    })
                })), this.Transaction = (a = this, cn(io.prototype, function(s, y, l, d, v) {
                    var h = this;
                    this.db = a, this.mode = s, this.storeNames = y, this.schema = l, this.chromeTransactionDurability = d, this.idbtrans = null, this.on = sn(this, "complete", "error", "abort"), this.parent = v || null, this.active = !0, this._reculock = 0, this._blockedFuncs = [], this._resolve = null, this._reject = null, this._waitingFor = null, this._waitingQueue = null, this._spinCount = 0, this._completion = new A(function(m, g) {
                        h._resolve = m, h._reject = g
                    }), this._completion.then(function() {
                        h.active = !1, h.on.complete.fire()
                    }, function(m) {
                        var g = h.active;
                        return h.active = !1, h.on.error.fire(m), h.parent ? h.parent._reject(m) : g && h.idbtrans && h.idbtrans.abort(), H(m)
                    })
                })), this.Version = (u = this, cn(ho.prototype, function(s) {
                    this.db = u, this._cfg = {
                        version: s,
                        storesSource: null,
                        dbschema: {},
                        tables: {},
                        contentUpgrade: null
                    }
                })), this.WhereClause = (f = this, cn(lr.prototype, function(s, y, l) {
                    if (this.db = f, this._ctx = {
                            table: s,
                            index: y === ":id" ? null : y,
                            or: l
                        }, this._cmp = this._ascending = L, this._descending = function(d, v) {
                            return L(v, d)
                        }, this._max = function(d, v) {
                            return 0 < L(d, v) ? d : v
                        }, this._min = function(d, v) {
                            return L(d, v) < 0 ? d : v
                        }, this._IDBKeyRange = f._deps.IDBKeyRange, !this._IDBKeyRange) throw new K.MissingAPI
                })), this.on("versionchange", function(s) {
                    0 < s.newVersion ? console.warn("Another connection wants to upgrade database '".concat(t.name, "'. Closing db now to resume the upgrade.")) : console.warn("Another connection wants to delete database '".concat(t.name, "'. Closing db now to resume the delete request.")), t.close({
                        disableAutoOpen: !1
                    })
                }), this.on("blocked", function(s) {
                    !s.newVersion || s.newVersion < s.oldVersion ? console.warn("Dexie.delete('".concat(t.name, "') was blocked")) : console.warn("Upgrade '".concat(t.name, "' blocked by other connection holding version ").concat(s.oldVersion / 10))
                }), this._maxKey = dn(n.IDBKeyRange), this._createTransaction = function(s, y, l, d) {
                    return new t.Transaction(s, y, l, t._options.chromeTransactionDurability, d)
                }, this._fireOnBlocked = function(s) {
                    t.on("blocked").fire(s), Ge.filter(function(y) {
                        return y.name === t.name && y !== t && !y._state.vcFired
                    }).map(function(y) {
                        return y.on("versionchange").fire(s)
                    })
                }, this.use(mo), this.use(_o), this.use(go), this.use(yo), this.use(vo);
                var p = new Proxy(this, {
                    get: function(s, y, l) {
                        if (y === "_vip") return !0;
                        if (y === "table") return function(v) {
                            return $n(t.table(v), p)
                        };
                        var d = Reflect.get(s, y, l);
                        return d instanceof ir ? $n(d, p) : y === "tables" ? d.map(function(v) {
                            return $n(v, p)
                        }) : y === "_createTransaction" ? function() {
                            return $n(d.apply(this, arguments), p)
                        } : d
                    }
                });
                this.vip = p, r.forEach(function(s) {
                    return s(t)
                })
            }
            var Wn, se = typeof Symbol < "u" && "observable" in Symbol ? Symbol.observable : "@@observable",
                xo = (jt.prototype.subscribe = function(e, n, t) {
                    return this._subscribe(e && typeof e != "function" ? e : {
                        next: e,
                        error: n,
                        complete: t
                    })
                }, jt.prototype[se] = function() {
                    return this
                }, jt);

            function jt(e) {
                this._subscribe = e
            }
            try {
                Wn = {
                    indexedDB: R.indexedDB || R.mozIndexedDB || R.webkitIndexedDB || R.msIndexedDB,
                    IDBKeyRange: R.IDBKeyRange || R.webkitIDBKeyRange
                }
            } catch (e) {
                Wn = {
                    indexedDB: null,
                    IDBKeyRange: null
                }
            }

            function Pr(e) {
                var n, t = !1,
                    r = new xo(function(o) {
                        var i = Zn(e),
                            a, u = !1,
                            f = {},
                            c = {},
                            p = {
                                get closed() {
                                    return u
                                },
                                unsubscribe: function() {
                                    u || (u = !0, a && a.abort(), s && Ie.storagemutated.unsubscribe(l))
                                }
                            };
                        o.start && o.start(p);
                        var s = !1,
                            y = function() {
                                return ct(d)
                            },
                            l = function(v) {
                                Ln(f, v), Et(c, f) && y()
                            },
                            d = function() {
                                var v, h, m;
                                !u && Wn.indexedDB && (f = {}, v = {}, a && a.abort(), a = new AbortController, m = (function(g) {
                                    var b = We();
                                    try {
                                        i && Qe();
                                        var w = Oe(e, g);
                                        return w = i ? w.finally(Pe) : w
                                    } finally {
                                        b && Ye()
                                    }
                                })(h = {
                                    subscr: v,
                                    signal: a.signal,
                                    requery: y,
                                    querier: e,
                                    trans: null
                                }), Promise.resolve(m).then(function(g) {
                                    t = !0, n = g, u || h.signal.aborted || (f = {}, (function(b) {
                                        for (var w in b)
                                            if (Y(b, w)) return;
                                        return 1
                                    })(c = v) || s || (Ie(hn, l), s = !0), ct(function() {
                                        return !u && o.next && o.next(g)
                                    }))
                                }, function(g) {
                                    t = !1, ["DatabaseClosedError", "AbortError"].includes(g == null ? void 0 : g.name) || u || ct(function() {
                                        u || o.error && o.error(g)
                                    })
                                }))
                            };
                        return setTimeout(y, 0), p
                    });
                return r.hasValue = function() {
                    return t
                }, r.getValue = function() {
                    return n
                }, r
            }
            var Me = ge;

            function Rt(e) {
                var n = Se;
                try {
                    Se = !0, Ie.storagemutated.fire(e), St(e, !0)
                } finally {
                    Se = n
                }
            }
            Ue(Me, I(I({}, _n), {
                delete: function(e) {
                    return new Me(e, {
                        addons: []
                    }).delete()
                },
                exists: function(e) {
                    return new Me(e, {
                        addons: []
                    }).open().then(function(n) {
                        return n.close(), !0
                    }).catch("NoSuchDatabaseError", function() {
                        return !1
                    })
                },
                getDatabaseNames: function(e) {
                    try {
                        return n = Me.dependencies, t = n.indexedDB, n = n.IDBKeyRange, (kt(t) ? Promise.resolve(t.databases()).then(function(r) {
                            return r.map(function(o) {
                                return o.name
                            }).filter(function(o) {
                                return o !== Cn
                            })
                        }) : xt(t, n).toCollection().primaryKeys()).then(e)
                    } catch (r) {
                        return H(new K.MissingAPI)
                    }
                    var n, t
                },
                defineClass: function() {
                    return function(e) {
                        U(this, e)
                    }
                },
                ignoreTransaction: function(e) {
                    return S.trans ? Re(S.transless, e) : e()
                },
                vip: Ot,
                async: function(e) {
                    return function() {
                        try {
                            var n = Ct(e.apply(this, arguments));
                            return n && typeof n.then == "function" ? n : A.resolve(n)
                        } catch (t) {
                            return H(t)
                        }
                    }
                },
                spawn: function(e, n, t) {
                    try {
                        var r = Ct(e.apply(t, n || []));
                        return r && typeof r.then == "function" ? r : A.resolve(r)
                    } catch (o) {
                        return H(o)
                    }
                },
                currentTransaction: {
                    get: function() {
                        return S.trans || null
                    }
                },
                waitFor: function(e, n) {
                    return n = A.resolve(typeof e == "function" ? Me.ignoreTransaction(e) : e).timeout(n || 6e4), S.trans ? S.trans.waitFor(n) : n
                },
                Promise: A,
                debug: {
                    get: function() {
                        return le
                    },
                    set: function(e) {
                        Qt(e)
                    }
                },
                derive: Le,
                extend: U,
                props: Ue,
                override: Ut,
                Events: sn,
                on: Ie,
                liveQuery: Pr,
                extendObservabilitySet: Ln,
                getByKeyPath: pe,
                setByKeyPath: ae,
                delByKeyPath: function(e, n) {
                    typeof n == "string" ? ae(e, n, void 0) : "length" in n && [].map.call(n, function(t) {
                        ae(e, t, void 0)
                    })
                },
                shallowClone: Vt,
                deepClone: Ce,
                getObjectDiff: Kt,
                cmp: L,
                asap: Lt,
                minKey: -1 / 0,
                addons: [],
                connections: Ge,
                errnames: et,
                dependencies: Wn,
                cache: Fe,
                semVer: "4.0.8",
                version: "4.0.8".split(".").map(function(e) {
                    return parseInt(e)
                }).reduce(function(e, n, t) {
                    return e + n / Math.pow(10, 2 * t)
                })
            })), Me.maxKey = dn(Me.dependencies.IDBKeyRange), typeof dispatchEvent < "u" && typeof addEventListener < "u" && (Ie(hn, function(e) {
                Se || (e = new CustomEvent(yt, {
                    detail: e
                }), Se = !0, dispatchEvent(e), Se = !1)
            }), addEventListener(yt, function(e) {
                e = e.detail, Se || Rt(e)
            }));
            var Je, Se = !1,
                Er = function() {};
            return typeof BroadcastChannel < "u" && ((Er = function() {
                (Je = new BroadcastChannel(yt)).onmessage = function(e) {
                    return e.data && Rt(e.data)
                }
            })(), typeof Je.unref == "function" && Je.unref(), Ie(hn, function(e) {
                Se || Je.postMessage(e)
            })), typeof addEventListener < "u" && (addEventListener("pagehide", function(e) {
                if (!ge.disableBfCache && e.persisted) {
                    le && console.debug("Dexie: handling persisted pagehide"), Je != null && Je.close();
                    for (var n = 0, t = Ge; n < t.length; n++) t[n].close({
                        disableAutoOpen: !1
                    })
                }
            }), addEventListener("pageshow", function(e) {
                !ge.disableBfCache && e.persisted && (le && console.debug("Dexie: handling persisted pageshow"), Er(), Rt({
                    all: new oe(-1 / 0, [
                        []
                    ])
                }))
            })), A.rejectionMapper = function(e, n) {
                return !e || e instanceof ze || e instanceof TypeError || e instanceof SyntaxError || !e.name || !Yt[e.name] ? e : (n = new Yt[e.name](n || e.message, e), "stack" in e && xe(n, "stack", {
                    get: function() {
                        return this.inner.stack
                    }
                }), n)
            }, Qt(le), I(ge, Object.freeze({
                __proto__: null,
                Dexie: ge,
                liveQuery: Pr,
                Entity: tr,
                cmp: L,
                PropModSymbol: me,
                PropModification: ln,
                replacePrefix: function(e, n) {
                    return new ln({
                        replacePrefix: [e, n]
                    })
                },
                add: function(e) {
                    return new ln({
                        add: e
                    })
                },
                remove: function(e) {
                    return new ln({
                        remove: e
                    })
                },
                default: ge,
                RangeSet: oe,
                mergeRanges: vn,
                rangesOverlap: yr
            }), {
                default: ge
            }), ge
        })
    })(Gn)), Gn.exports
}
var Mo = Fo();
const Ft = qo(Mo),
    Dr = Symbol.for("Dexie"),
    Hn = globalThis[Dr] || (globalThis[Dr] = Ft);
if (Ft.semVer !== Hn.semVer) throw new Error("Two different versions of Dexie loaded in the same app: ".concat(Ft.semVer, " and ").concat(Hn.semVer));
const {
    liveQuery: No,
    mergeRanges: Qo,
    rangesOverlap: Go,
    RangeSet: Ho,
    cmp: Xo,
    Entity: Jo,
    PropModSymbol: Zo,
    PropModification: ei,
    replacePrefix: ni,
    add: ti,
    remove: ri
} = Hn;

function Uo(C, N, F) {
    var I, ee;
    typeof C == "function" ? (I = N || [], ee = F) : (I = [], ee = N);
    var R = mn.useRef({
            hasResult: !1,
            result: ee,
            error: null
        }),
        W = mn.useReducer(function(z) {
            return z + 1
        }, 0);
    W[0];
    var D = W[1],
        U = mn.useMemo(function() {
            var z = typeof C == "function" ? C() : C;
            if (!z || typeof z.subscribe != "function") throw C === z ? new TypeError("Given argument to useObservable() was neither a valid observable nor a function.") : new TypeError("Observable factory given to useObservable() did not return a valid observable.");
            if (!R.current.hasResult && typeof window < "u" && (typeof z.hasValue != "function" || z.hasValue()))
                if (typeof z.getValue == "function") R.current.result = z.getValue(), R.current.hasResult = !0;
                else {
                    var re = z.subscribe(function(Y) {
                        R.current.result = Y, R.current.hasResult = !0
                    });
                    typeof re == "function" ? re() : re.unsubscribe()
                }
            return z
        }, I);
    if (mn.useDebugValue(R.current.result), mn.useEffect(function() {
            var z = U.subscribe(function(re) {
                var Y = R.current;
                (Y.error !== null || Y.result !== re) && (Y.error = null, Y.result = re, Y.hasResult = !0, D())
            }, function(re) {
                var Y = R.current;
                Y.error !== re && (Y.error = re, D())
            });
            return typeof z == "function" ? z : z.unsubscribe.bind(z)
        }, I), R.current.error) throw R.current.error;
    return R.current.result
}

function Lo(C, N, F) {
    return Uo(function() {
        return No(C)
    }, N || [], F)
}

function qr(C) {
    C.version(1).stores({
        conversations: "id, accountUserId, authUserId"
    })
}
const Mt = new Hn("ConversationsDatabase");
qr(Mt);
const Br = {
        db: Mt,
        currentAccountData: void 0,
        conversationIds: [],
        initialized: !1
    },
    Fr = Eo()(() => Sr({}, Br)),
    de = Fr.getState,
    we = Fr.setState,
    gn = {
        init: (C = de()) => {
            C.initialized || (we({
                initialized: !0
            }), Qn.on("createConversation", N => {
                Tr(N.clientThreadId)
            }), Qn.on("deleteConversation", N => {
                Vo(N.serverThreadId)
            }), Qn.on("refreshHistory", N => {
                gn.setCurrentConversationIds(N.conversations.map(F => F.id))
            }), Qn.on("updateThreadTitle", N => {
                Tr(N.conversationId)
            }))
        },
        reset: () => we(Br),
        getDatabase: () => de().db,
        setDatabase: C => {
            qr(C), we({
                db: C
            })
        },
        getCurrentAccountData: () => {
            const C = de().currentAccountData;
            return C || be.addError("FannyPack: Unavailable current account data"), C
        },
        setCurrentAccountV2: async C => {
            if (!C.accountUserId || !C.authUserId) {
                try {
                    await de().db.conversations.clear(), be.addError("FannyPack: Invalid user. Cleared conversations")
                } catch (I) {
                    be.addError("FannyPack: Invalid user. Failed to clear conversations")
                }
                we({
                    currentAccountData: void 0
                });
                return
            }
            const N = de().currentAccountData,
                F = {
                    accountUserId: _e(C.accountUserId),
                    authUserId: _e(C.authUserId)
                };
            if (N && N.authUserId !== F.authUserId) try {
                await de().db.conversations.where("accountUserId").notEqual(_e(F == null ? void 0 : F.accountUserId)).delete(), we({
                    currentAccountData: F
                }), be.addAction("fannypack.web.swap_user")
            } catch (I) {
                be.addError("FannyPack: Failed to delete conversations for new user: ".concat(I))
            }
            we({
                currentAccountData: F
            })
        },
        setCurrentAccount: C => {
            if (!C.accountUserId || !C.authUserId) {
                de().db.conversations.clear().then(() => {
                    be.addError("FannyPack: Invalid user. Cleared conversations")
                }).catch(I => {
                    be.addError("FannyPack: Invalid user. Failed to clear conversations: ".concat(I))
                }), we({
                    currentAccountData: void 0
                });
                return
            }
            const N = de().currentAccountData,
                F = {
                    accountUserId: _e(C.accountUserId),
                    authUserId: _e(C.authUserId)
                };
            N && N.authUserId !== F.authUserId && de().db.conversations.where("accountUserId").notEqual(_e(F == null ? void 0 : F.accountUserId)).delete().then(() => {
                be.addAction("fannypack.web.swap_user")
            }).catch(I => {
                be.addError("FannyPack: Failed to delete conversations for new user: ".concat(I))
            }), we({
                currentAccountData: F
            })
        },
        setCurrentConversationIds: C => {
            we({
                conversationIds: C
            })
        }
    };

function _e(C) {
    return C != null ? C : ""
}

function Tr(C) {
    if (!Ao.getLayerValue({
            layerName: "3436367576",
            key: "enable_local_indexing",
            defaultValue: !1,
            shouldLogExposure: !1
        })) return;
    const I = gn.getCurrentAccountData();
    if (!I) return;
    const ee = Io(C);
    if (!ee) return;
    const R = So(ee),
        D = Bt.getBranch(R).flatMap(U => {
            const z = U.message;
            return Co(z) === Ko.Text ? {
                id: U.id,
                text: Do(U.message, {
                    shouldGetTextFromContentReferences: !0,
                    shouldGetVisibleText: !1
                })
            } : []
        });
    gn.getDatabase().conversations.put({
        id: ee,
        accountUserId: _e(I.accountUserId),
        authUserId: _e(I.authUserId),
        title: _e(R == null ? void 0 : R.title),
        isArchived: Bt.isArchived(R),
        updateTime: Bt.getUpdateTime(R),
        messages: D
    }).then(() => {
        jr.count(Rr.DEFAULT, "fannypack.web.add_conversation")
    })
}

function Vo(C) {
    gn.getCurrentAccountData() && Mt.conversations.where({
        id: C
    }).delete().then(() => {
        jr.count(Rr.DEFAULT, "fannypack.web.delete_conversation")
    })
}

function zo(C, N, F = 0) {
    const I = C.toLowerCase(),
        ee = de().conversationIds,
        R = N.sort((D, U) => {
            var z, re;
            return D.updateTime === U.updateTime ? U.id.localeCompare(D.id) : ((z = U.updateTime) != null ? z : 0) - ((re = D.updateTime) != null ? re : 0)
        }).filter(D => ee.includes(D.id)),
        W = [];
    for (const D of R) {
        if (W.length >= F) break;
        const U = D.messages.toReversed().find(z => z.text.toLowerCase().includes(I));
        (U || D.title.toLowerCase().includes(I)) && W.push({
            conversationId: D.id,
            nodeId: U == null ? void 0 : U.id,
            title: D.title,
            isArchived: D.isArchived,
            updateTime: D.updateTime,
            snippet: U == null ? void 0 : U.text,
            source: "local"
        })
    }
    return W.reduce((D, U) => (D.set(U.conversationId, U), D), new Map)
}

function oi(C, N = 0) {
    var D;
    const F = jo(),
        I = To(F),
        ee = Cr.useRef([]),
        R = (D = Lo(() => I ? gn.getDatabase().conversations.where({
            accountUserId: I.normalizedAccountUserId
        }).toArray().catch(() => []) : [], [C, I == null ? void 0 : I.accountUserId])) != null ? D : ee.current;
    return Cr.useMemo(() => zo(C, R, N), [C, R, N])
}
export {
    gn as F, oi as u
};
//# sourceMappingURL=o4n6pqcoqgw7owdr.js.map