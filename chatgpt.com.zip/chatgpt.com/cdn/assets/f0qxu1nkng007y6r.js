var ee = Object.defineProperty,
    te = Object.defineProperties;
var se = Object.getOwnPropertyDescriptors;
var q = Object.getOwnPropertySymbols;
var oe = Object.prototype.hasOwnProperty,
    ne = Object.prototype.propertyIsEnumerable;
var B = (a, e, t) => e in a ? ee(a, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : a[e] = t,
    F = (a, e) => {
        for (var t in e || (e = {})) oe.call(e, t) && B(a, t, e[t]);
        if (q)
            for (var t of q(e)) ne.call(e, t) && B(a, t, e[t]);
        return a
    },
    Q = (a, e) => te(a, se(e));
import {
    c as T,
    e as X,
    r as _,
    j as i,
    i as ie,
    M as K,
    L as re
} from "./fg33krlcm0qyi6yw.js";
import {
    ra as Y,
    d as A,
    he as H,
    cU as L,
    hd as U,
    b as k,
    gC as W,
    fN as ae,
    I as le,
    e1 as ce,
    l as O,
    rb as de,
    qz as me,
    hi as ue,
    fO as fe,
    ba as he,
    k as ge,
    ib as ve,
    ql as xe,
    rc as pe,
    P as Z,
    c0 as je,
    o as be,
    ed as V
} from "./dykg4ktvbu3mhmdo.js";
import {
    bV as Ce,
    bW as $,
    bX as ye,
    bY as Se,
    bZ as Ne,
    b_ as we,
    b$ as ze,
    c0 as De,
    c1 as Pe,
    c2 as Ie,
    bU as Me,
    bT as Te,
    c3 as Ee,
    ag as _e,
    af as $e,
    c4 as ke
} from "./k15yxxoybkkir2ou.js";
import {
    D as Ge
} from "./jttqqjx6qab96ezg.js";
import {
    P as Oe
} from "./eejiqzdptzp07q5y.js";
import "./e3ddui4ro6nb7fig.js";
import "./ew68kf01y1h7e4uk.js";
import "./k2oaaf8ac9lafsub.js";
import "./lans8a2ikbh9ax9r.js";
const Fe = () => {
    "use forget";
    const a = T.c(1);
    let e;
    return a[0] === Symbol.for("react.memo_cache_sentinel") ? (e = i.jsx("div", {
        className: "ms-1 mt-3 h-10",
        children: i.jsx("div", {
            className: "bg-token-tertiary my-[15px] h-[10px] w-48 rounded-full"
        })
    }), a[0] = e) : e = a[0], e
};

function Ae(a) {
    "use forget";
    const e = T.c(19),
        {
            gizmo: t
        } = a,
        s = X(),
        u = k(),
        o = _.use(Y);
    let v;
    e[0] !== t || e[1] !== o ? (v = () => t ? o.theme$() : null, e[0] = t, e[1] = o, e[2] = v) : v = e[2];
    const n = A(v);
    let x;
    e[3] !== t || e[4] !== o ? (x = () => t ? o.emoji$() : null, e[3] = t, e[4] = o, e[5] = x) : x = e[5];
    const j = A(x);
    let b;
    e[6] !== t || e[7] !== o ? (b = () => t ? o.title$() : null, e[6] = t, e[7] = o, e[8] = b) : b = e[8];
    const r = A(b);
    let c;
    e[9] !== t ? (c = t ? H(t) : !1, e[9] = t, e[10] = c) : c = e[10];
    const f = c;
    let d;
    return e[11] !== u || e[12] !== j || e[13] !== n || e[14] !== r || e[15] !== t || e[16] !== s || e[17] !== f ? (d = i.jsx("div", {
        className: "mb-8 inline-flex w-full justify-center gap-2",
        children: t ? i.jsx("div", {
            className: "text-page-header mt-0.5 inline-block px-4",
            children: i.jsx("h1", {
                className: "contents",
                children: i.jsxs("a", {
                    href: "#edit-title",
                    role: "button",
                    "aria-label": s.formatMessage({
                        id: "edit-title",
                        defaultMessage: "Edit the title of {projectName}"
                    }, {
                        projectName: t.gizmo.display.name
                    }),
                    className: "text-page-header group hover:text-token-text-secondary ms-2 flex items-center gap-1.5 text-balance",
                    onClick: g => {
                        g.preventDefault(), L(u, $, {
                            submitButtonTitle: s.formatMessage(W.projectSettingsSubmitButton),
                            gizmo: t,
                            onClose: () => U(u, $)
                        })
                    },
                    children: [i.jsx(Ce, {
                        size: "lg",
                        color: n,
                        emoji: j,
                        isSharedProject: f,
                        strict: !0
                    }), r]
                })
            })
        }) : i.jsx(Fe, {})
    }), e[11] = u, e[12] = j, e[13] = n, e[14] = r, e[15] = t, e[16] = s, e[17] = f, e[18] = d) : d = e[18], d
}

function Le(a) {
    "use forget";
    const e = T.c(2),
        {
            children: t
        } = a;
    let s;
    return e[0] !== t ? (s = i.jsx("div", {
        className: "group relative flex flex-col gap-1 p-3",
        children: i.jsx("div", {
            className: "flex items-center gap-4",
            children: t
        })
    }), e[0] = t, e[1] = s) : s = e[1], s
}
const Ue = a => {
        "use forget";
        var I, M;
        const e = T.c(36),
            {
                conversation: t,
                project: s,
                showAvatar: u
            } = a,
            o = (I = ae(t.id, Qe)) != null ? I : t.title,
            [v, n] = _.useState(!1);
        let x, j;
        e[0] !== t.id ? (x = () => xe(De, {
            editTitleInMainScreen: P => {
                const {
                    serverThreadId: E
                } = P;
                E === t.id && n(!0)
            }
        }), j = [t.id], e[0] = t.id, e[1] = x, e[2] = j) : (x = e[1], j = e[2]), _.useEffect(x, j);
        const b = k(),
            {
                snippet: r
            } = t;
        let c, f, d, g, l;
        if (e[3] !== t || e[4] !== b || e[5] !== s.gizmo) {
            const P = (M = le(b)) == null ? void 0 : M.normalizedAccountUserId;
            c = "owner" in t ? t.owner : null, g = c == null ? void 0 : c.user_id, f = c == null ? void 0 : c.name, d = c == null ? void 0 : c.user_email, l = ce(t.id, {
                project: s.gizmo,
                ownerUserId: g,
                accountUserId: P
            }), e[3] = t, e[4] = b, e[5] = s.gizmo, e[6] = c, e[7] = f, e[8] = d, e[9] = g, e[10] = l
        } else c = e[6], f = e[7], d = e[8], g = e[9], l = e[10];
        const h = l;
        let m;
        e[11] !== c || e[12] !== f || e[13] !== d || e[14] !== g || e[15] !== u ? (m = u && i.jsx(pe, {
            monogram: c && f && g ? {
                label: f,
                id: g,
                sublabel: d
            } : null
        }), e[11] = c, e[12] = f, e[13] = d, e[14] = g, e[15] = u, e[16] = m) : m = e[16];
        let p;
        e[17] !== t || e[18] !== o || e[19] !== v ? (p = v ? i.jsx(ye, {
            conversationId: t.id,
            historyConversationResponse: t,
            onClose: () => {
                n(!1)
            }
        }) : i.jsx("div", {
            className: "text-sm font-medium",
            children: o
        }), e[17] = t, e[18] = o, e[19] = v, e[20] = p) : p = e[20];
        let C;
        e[21] !== r ? (C = r && i.jsx("div", {
            className: "text-token-text-secondary truncate text-sm",
            children: r
        }), e[21] = r, e[22] = C) : C = e[22];
        let S;
        e[23] !== p || e[24] !== C ? (S = i.jsxs("div", {
            className: "grow overflow-hidden group-hover:me-5",
            children: [p, C]
        }), e[23] = p, e[24] = C, e[25] = S) : S = e[25];
        let y;
        e[26] !== t || e[27] !== v ? (y = !v && i.jsx(We, {
            conversation: t
        }), e[26] = t, e[27] = v, e[28] = y) : y = e[28];
        let N;
        e[29] !== m || e[30] !== S || e[31] !== y ? (N = i.jsxs(Le, {
            children: [m, S, y]
        }), e[29] = m, e[30] = S, e[31] = y, e[32] = N) : N = e[32];
        const w = N;
        if (v) return w;
        let z;
        return e[33] !== w || e[34] !== h ? (z = i.jsx(re, {
            to: h,
            draggable: !1,
            children: w
        }), e[33] = w, e[34] = h, e[35] = z) : z = e[35], z
    },
    We = a => {
        "use forget";
        const e = T.c(22),
            {
                conversation: t,
                isNewProjectPage: s
            } = a,
            u = s === void 0 ? !1 : s,
            [o, v] = _.useState(!1),
            n = X();
        let x;
        e[0] !== t.update_time || e[1] !== n ? (x = t.update_time && Intl.DateTimeFormat(n.locale, {
            month: "short",
            day: "numeric"
        }).format(new Date(t.update_time)), e[0] = t.update_time, e[1] = n, e[2] = x) : x = e[2];
        const j = x;
        let b;
        e[3] === Symbol.for("react.memo_cache_sentinel") ? (b = O("text-token-text-tertiary relative flex min-h-10 min-w-10 items-center justify-between text-sm"), e[3] = b) : b = e[3];
        let r;
        e[4] !== j || e[5] !== o || e[6] !== u ? (r = !!j && i.jsx("span", {
            className: O("whitespace-nowrap", !u && "transition-opacity duration-100 ease-out", o ? "opacity-0" : "opacity-100 group-hover/project-item:opacity-0"),
            children: j
        }), e[4] = j, e[5] = o, e[6] = u, e[7] = r) : r = e[7];
        const c = !u && "transition-all duration-100 ease-out",
            f = o && "pointer-events-auto translate-y-0 scale-100 opacity-100";
        let d;
        e[8] !== c || e[9] !== f ? (d = O("absolute inset-0 flex items-center gap-1.5", c, "translate-y-0 scale-95 opacity-0", "group-hover/project-item:translate-y-0 group-hover/project-item:scale-100 group-hover/project-item:opacity-100", f), e[8] = c, e[9] = f, e[10] = d) : d = e[10];
        let g;
        e[11] !== t.id ? (g = p => {
            v(p), p && Z.logEvent("Conversation History Item Open Menu", {
                conversationId: t.id
            })
        }, e[11] = t.id, e[12] = g) : g = e[12];
        let l;
        e[13] !== t || e[14] !== g ? (l = i.jsx(Pe, {
            conversation: t,
            onOpenChange: g,
            inMainScreen: !0,
            isActiveConversation: !1
        }), e[13] = t, e[14] = g, e[15] = l) : l = e[15];
        let h;
        e[16] !== d || e[17] !== l ? (h = i.jsx("div", {
            className: d,
            "data-prevent-default": !0,
            children: l
        }), e[16] = d, e[17] = l, e[18] = h) : h = e[18];
        let m;
        return e[19] !== h || e[20] !== r ? (m = i.jsxs("div", {
            className: b,
            children: [r, h]
        }), e[19] = h, e[20] = r, e[21] = m) : m = e[21], m
    };

function He(a) {
    "use forget";
    const e = T.c(24),
        {
            project: t,
            hasConversations$: s,
            className: u
        } = a;
    de(t.gizmo.id);
    const {
        items: o,
        hasNextPage: v,
        fetchNextPage: n,
        isLoading: x,
        isFetching: j,
        isFetchingNextPage: b
    } = me(t.gizmo.id);
    let r, c;
    e[0] !== s || e[1] !== o.length ? (r = () => {
        s && s.set(o.length > 0)
    }, c = [o.length, s], e[0] = s, e[1] = o.length, e[2] = r, e[3] = c) : (r = e[2], c = e[3]), _.useEffect(r, c);
    let f;
    e[4] !== v || e[5] !== j || e[6] !== x || e[7] !== n ? (f = C => {
        if (x || C == null) return;
        const S = new IntersectionObserver(y => {
            y[0].isIntersecting && v && !j && n()
        });
        return S.observe(C), () => {
            S.disconnect()
        }
    }, e[4] = v, e[5] = j, e[6] = x, e[7] = n, e[8] = f) : f = e[8];
    const d = f,
        g = o.length;
    let l;
    e[9] !== u ? (l = O("mt-8 mb-14 contain-inline-size", u), e[9] = u, e[10] = l) : l = e[10];
    let h;
    e[11] !== g || e[12] !== v || e[13] !== d || e[14] !== x || e[15] !== o || e[16] !== t ? (h = (g || x) && i.jsx(Re, {
        project: t,
        items: o != null ? o : [],
        hasNextPage: v,
        infiniteScrollTriggerElementRef: d
    }), e[11] = g, e[12] = v, e[13] = d, e[14] = x, e[15] = o, e[16] = t, e[17] = h) : h = e[17];
    let m;
    e[18] !== b ? (m = b && i.jsx("div", {
        className: "m-4 mb-5 flex justify-center",
        children: i.jsx(je, {})
    }), e[18] = b, e[19] = m) : m = e[19];
    let p;
    return e[20] !== l || e[21] !== h || e[22] !== m ? (p = i.jsxs("div", {
        className: l,
        children: [h, m]
    }), e[20] = l, e[21] = h, e[22] = m, e[23] = p) : p = e[23], p
}

function Re(a) {
    "use forget";
    const e = T.c(23),
        {
            project: t,
            items: s,
            hasNextPage: u,
            infiniteScrollTriggerElementRef: o
        } = a,
        v = k();
    let n;
    e[0] !== v ? (n = be(v, "773249106"), e[0] = v, e[1] = n) : n = e[1];
    const x = n;
    let j;
    e[2] !== t ? (j = t ? H(t) : !1, e[2] = t, e[3] = j) : j = e[3];
    const b = j;
    let r;
    if (e[4] !== s || e[5] !== t) {
        let l;
        e[7] !== t ? (l = h => {
            var m, p;
            return "owner" in h && ((m = h.owner) == null ? void 0 : m.user_id) !== ((p = t.gizmo) == null ? void 0 : p.author.user_id)
        }, e[7] = t, e[8] = l) : l = e[8], r = s.some(l), e[4] = s, e[5] = t, e[6] = r
    } else r = e[6];
    const f = x && (b || r);
    let d;
    if (e[9] !== u || e[10] !== o || e[11] !== s || e[12] !== t || e[13] !== f) {
        let l;
        e[15] !== u || e[16] !== o || e[17] !== s.length || e[18] !== t || e[19] !== f ? (l = (h, m) => {
            const p = u && m === s.length - 3 ? o : void 0;
            return i.jsx("li", {
                ref: p,
                className: "border-token-border-light border-t first:border-t-0 last:border-b-0",
                children: i.jsx("div", {
                    className: "hover:bg-token-interactive-bg-tertiary-hover",
                    children: i.jsx(Ue, {
                        conversation: h,
                        project: t,
                        showAvatar: f
                    })
                })
            }, h.id)
        }, e[15] = u, e[16] = o, e[17] = s.length, e[18] = t, e[19] = f, e[20] = l) : l = e[20], d = s.map(l), e[9] = u, e[10] = o, e[11] = s, e[12] = t, e[13] = f, e[14] = d
    } else d = e[14];
    let g;
    return e[21] !== d ? (g = i.jsx("ol", {
        children: d
    }), e[21] = d, e[22] = g) : g = e[22], g
}

function J(a, e, t) {
    "use forget";
    const s = T.c(16),
        u = Se(),
        o = k(),
        v = ie(),
        n = Ne(),
        x = (u == null ? void 0 : u.kind) === "conversation" && u.gizmoId !== e;
    let j;
    s[0] === Symbol.for("react.memo_cache_sentinel") ? (j = [], s[0] = j) : j = s[0], _.useEffect(qe, j);
    let b;
    s[1] !== o || s[2] !== v || s[3] !== t || s[4] !== n ? (b = async function(l) {
        const {
            conversation: h,
            newGizmoId: m,
            previousGizmoId: p
        } = l, C = async () => {
            ke(o, m, !0), await n({
                newGizmoId: m,
                conversation: h,
                previousGizmoId: p
            }), v("/g/".concat(m, "/project"))
        };
        if (V(p) && V(m) && p !== m && (t == null ? void 0 : t.gizmo.id) === m && H(t)) {
            L(o, Ie, {
                onConfirmMove: C
            });
            return
        }
        await C()
    }, s[1] = o, s[2] = v, s[3] = t, s[4] = n, s[5] = b) : b = s[5];
    const r = b;
    let c;
    s[6] !== r || s[7] !== x || s[8] !== o || s[9] !== u || s[10] !== e || s[11] !== a ? (c = () => {
        if (!x) return;
        const {
            conversation: g,
            gizmoId: l
        } = u;
        if (e) return r({
            conversation: g,
            newGizmoId: e,
            previousGizmoId: l
        });
        L(o, $, {
            onClose: () => U(o, $),
            onSuccess: h => {
                h && (U(o, $), r({
                    conversation: g,
                    newGizmoId: h,
                    previousGizmoId: l
                }), Z.logEventWithStatsig("Projects: Create Open", "chatgpt_web_projects_create_open", {
                    source: a
                }))
            }
        })
    }, s[6] = r, s[7] = x, s[8] = o, s[9] = u, s[10] = e, s[11] = a, s[12] = c) : c = s[12];
    const f = c;
    let d;
    return s[13] !== x || s[14] !== f ? (d = {
        canDropConversation: x,
        onDropConversation: f
    }, s[13] = x, s[14] = f, s[15] = d) : d = s[15], d
}

function qe() {
    return ze()
}

function Be(a, e) {
    "use forget";
    return J(a, e == null ? void 0 : e.gizmo.id, e)
}

function nt(a) {
    "use forget";
    return J(a)
}

function it(a) {
    "use forget";
    var R;
    const e = T.c(43),
        {
            conversation: t,
            gizmoId: s,
            currentModelId: u,
            onRequestCompletion: o
        } = a,
        v = k(),
        {
            data: n
        } = ue(s),
        x = fe(),
        j = he(ge),
        {
            onDropConversation: b,
            canDropConversation: r
        } = Be(void 0, n),
        [c, f] = _.useState(!1);
    let d;
    e[0] !== v || e[1] !== s ? (d = ve(v, s), e[0] = v, e[1] = s, e[2] = d) : d = e[2];
    const g = d;
    let l;
    e[3] !== r ? (l = D => {
        D.preventDefault(), r && f(!0)
    }, e[3] = r, e[4] = l) : l = e[4];
    let h;
    e[5] !== r || e[6] !== b ? (h = D => {
        D.preventDefault(), r && (f(!1), b())
    }, e[5] = r, e[6] = b, e[7] = h) : h = e[7];
    let m, p;
    e[8] !== r ? (m = D => {
        D.preventDefault(), r && f(!0)
    }, p = D => {
        D.preventDefault(), r && f(!1)
    }, e[8] = r, e[9] = m, e[10] = p) : (m = e[9], p = e[10]);
    const C = x ? "last-standard" : "none",
        S = j ? "none" : "standard";
    let y;
    e[11] !== n ? (y = i.jsx(Ae, {
        gizmo: n
    }), e[11] = n, e[12] = y) : y = e[12];
    let N;
    e[13] !== t || e[14] !== u || e[15] !== o || e[16] !== n ? (N = n ? i.jsx(Oe, {
        conversation: t,
        isNewThread: !0,
        isProjectThread: !0,
        currentModelId: u,
        layoutMode: "center",
        onContinueGenerating: D => o(Te(D)),
        onRequestCompletion: async D => o(await Me(D)),
        hideHeader: !0
    }) : i.jsx("div", {
        className: "bg-token-tertiary h-24 w-full rounded-3xl"
    }), e[13] = t, e[14] = u, e[15] = o, e[16] = n, e[17] = N) : N = e[17];
    let w, z;
    e[18] !== n ? (w = i.jsx(Ee, {
        gizmo: n
    }), z = n && i.jsx(He, {
        project: n
    }), e[18] = n, e[19] = w, e[20] = z) : (w = e[19], z = e[20]);
    let I;
    e[21] !== c || e[22] !== (n == null ? void 0 : n.gizmo) ? (I = c && i.jsxs(Ge, {
        children: [i.jsx(we, {
            className: "h-12 w-12",
            style: {
                color: "#3C46FF"
            }
        }), i.jsx("h3", {
            className: "text-center",
            children: i.jsx(K, Q(F({}, W.moveConversationToNamedProject), {
                values: {
                    projectName: (R = n == null ? void 0 : n.gizmo.display.name) != null ? R : "project"
                }
            }))
        }), i.jsx("h4", {
            className: "text-center",
            children: i.jsx(K, F({}, W.moveConversation))
        })]
    }), e[21] = c, e[22] = n == null ? void 0 : n.gizmo, e[23] = I) : I = e[23];
    let M;
    e[24] !== w || e[25] !== z || e[26] !== I || e[27] !== y || e[28] !== N ? (M = i.jsxs(_e, {
        className: "[width:min(90cqw,var(--thread-content-max-width))]",
        children: [y, N, w, z, I]
    }), e[24] = w, e[25] = z, e[26] = I, e[27] = y, e[28] = N, e[29] = M) : M = e[29];
    let P;
    e[30] !== M || e[31] !== C || e[32] !== S ? (P = i.jsx($e, {
        verticalMargin: "none",
        verticalPadding: C,
        horizontalPadding: S,
        children: M
    }), e[30] = M, e[31] = C, e[32] = S, e[33] = P) : P = e[33];
    let E;
    e[34] !== P || e[35] !== l || e[36] !== h || e[37] !== m || e[38] !== p ? (E = i.jsx("div", {
        onDragOver: l,
        onDrop: h,
        onDragEnter: m,
        onDragLeave: p,
        className: "flex max-h-full min-h-full flex-col pt-(--header-height)",
        children: P
    }), e[34] = P, e[35] = l, e[36] = h, e[37] = m, e[38] = p, e[39] = E) : E = e[39];
    let G;
    return e[40] !== g || e[41] !== E ? (G = i.jsx(Y, {
        value: g,
        children: E
    }), e[40] = g, e[41] = E, e[42] = G) : G = e[42], G
}

function Qe(a) {
    return a == null ? void 0 : a.title
}
export {
    Ue as SnorlaxConversationItem, We as SnorlaxConversationItemOverflowMenu, He as SnorlaxConversationList, Ae as SnorlaxHeader, it as SnorlaxSplashScreen, J as useProjectsDragDrop, Be as useProjectsDragDropWithTargetProject, nt as useProjectsDragDropWithoutTargetProject
};
//# sourceMappingURL=f0qxu1nkng007y6r.js.map