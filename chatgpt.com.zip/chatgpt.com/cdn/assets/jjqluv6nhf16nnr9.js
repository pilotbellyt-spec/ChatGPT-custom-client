import {
    iZ as H
} from "./dykg4ktvbu3mhmdo.js";
import {
    a as A,
    u as I,
    C as l,
    c as y
} from "./iwhq2rihp0137gzf.js";
import {
    H as P
} from "./ce3hgmw4iyyhicud.js";
import {
    S as u,
    b as f,
    E as c,
    D as i
} from "./ovpdmx71kjznjdh8.js";

function D(t, e) {
    const n = L(t);
    if (n.length === 0) return e;
    let s = e;
    return n.forEach(o => {
        s = F(o, s)
    }), s
}

function F(t, e) {
    return A(e, {
        start: t.fromA,
        end: t.toA
    }, w(t))
}

function w(t) {
    const {
        fromA: e,
        toA: n,
        fromB: s,
        toB: o
    } = t;
    return o - s - (n - e)
}

function L(t) {
    const e = [],
        n = (s, o, r, a) => {
            e.push({
                fromA: s,
                toA: o,
                fromB: r,
                toB: a
            })
        };
    return t.changes.iterChangedRanges(n, !0), e
}

function R(t, e) {
    const n = Array.from(t.keys()),
        s = Array.from(e.keys());
    if (n.length !== s.length) return !1;
    n.sort(), s.sort();
    for (let o = 0; o < n.length; o++)
        if (n[o] !== s[o]) return !1;
    for (const o of n) {
        const r = t.get(o),
            a = e.get(o);
        if (!r || !a || r.start !== a.start || r.end !== a.end) return !1
    }
    return !0
}
const S = u.define(),
    b = u.define(),
    B = u.define(),
    T = u.define();

function j(t) {
    return new Map(t.map(e => [e.id, e.at]))
}
const d = f.define({
        create() {
            return null
        },
        update(t, e) {
            for (const n of e.effects)
                if (n.is(S)) return n.value;
            return t
        }
    }),
    m = f.define({
        create() {
            return []
        },
        update(t, e) {
            for (const a of e.effects)
                if (a.is(b)) return a.value;
            const n = t,
                s = j(n),
                o = D(e, s);
            return R(s, o) ? n : I(n, o)
        }
    }),
    g = f.define({
        create() {
            return null
        },
        update(t, e) {
            for (const n of e.effects)
                if (n.is(B)) return n.value;
            return t
        }
    }),
    C = f.define({
        create() {
            return null
        },
        update(t, e) {
            for (const n of e.effects)
                if (n.is(T)) return n.value;
            return t
        }
    });

function p(t) {
    if (!t || t.to - t.from === 0) return i.none;
    const e = i.mark({
        class: P.code
    });
    return i.set([e.range(t.from, t.to)])
}

function h(t, e, n) {
    if (t.length === 0) return i.none;
    const o = [...t].sort((r, a) => r.at.start - a.at.start).map(r => {
        if (r.at.end - r.at.start === 0) return null;
        const a = r.id === e,
            v = r.id === n,
            k = y({
                isHovered: a,
                isFocused: v,
                isCode: !0,
                diffStatus: r.diffStatus
            });
        return i.mark({
            class: k,
            attributes: {
                "data-comment-id": r.id
            }
        }).range(r.at.start, r.at.end)
    }).filter(H);
    return i.set(o)
}
const x = f.define({
        create(t) {
            const e = t.field(d, !1);
            return p(e != null ? e : null)
        },
        update(t, e) {
            const n = e.state.field(d, !1);
            return p(n != null ? n : null)
        },
        provide: t => c.decorations.from(t)
    }),
    G = f.define({
        create(t) {
            const e = t.field(m, !1),
                n = t.field(g, !1),
                s = t.field(C, !1);
            return h(e != null ? e : [], n != null ? n : null, s != null ? s : null)
        },
        update(t, e) {
            const n = e.state.field(m, !1),
                s = e.state.field(g, !1),
                o = e.state.field(C, !1);
            return h(n != null ? n : [], s != null ? s : null, o != null ? o : null)
        },
        provide: t => c.decorations.from(t)
    });

function M(t) {
    t.state.selection.main.empty && t.dispatch({
        effects: S.of(null)
    })
}

function E(t) {
    let e = t.dataset.commentId;
    for (let n = 0; n < 10 && !e && t.parentElement; n++) t = t.parentElement, e = t.dataset.commentId;
    return e
}

function N(t) {
    const e = t.target,
        n = E(e);
    n && l.focusComment(n)
}

function _(t) {
    const e = t.target,
        n = E(e);
    n ? l.mouseEnterComment(n) : l.mouseLeaveComment()
}

function Z(t, e = null, n = null) {
    return [m.init(() => t), d, g.init(() => e), C.init(() => n), x, G, c.updateListener.of(s => {
        s.selectionSet && M(s.view)
    }), c.domEventHandlers({
        click: N,
        mouseover: _
    })]
}
export {
    S as a, B as b, Z as c, T as d, m as e, b as s
};
//# sourceMappingURL=jjqluv6nhf16nnr9.js.map