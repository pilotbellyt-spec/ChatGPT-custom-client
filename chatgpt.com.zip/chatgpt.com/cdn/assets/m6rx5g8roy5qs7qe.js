var gt = Object.defineProperty,
    pt = Object.defineProperties;
var yt = Object.getOwnPropertyDescriptors;
var Me = Object.getOwnPropertySymbols;
var et = Object.prototype.hasOwnProperty,
    tt = Object.prototype.propertyIsEnumerable;
var Ze = (t, e, s) => e in t ? gt(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : t[e] = s,
    Ve = (t, e) => {
        for (var s in e || (e = {})) et.call(e, s) && Ze(t, s, e[s]);
        if (Me)
            for (var s of Me(e)) tt.call(e, s) && Ze(t, s, e[s]);
        return t
    },
    qe = (t, e) => pt(t, yt(e));
var ze = (t, e) => {
    var s = {};
    for (var i in t) et.call(t, i) && e.indexOf(i) < 0 && (s[i] = t[i]);
    if (t != null && Me)
        for (var i of Me(t)) e.indexOf(i) < 0 && tt.call(t, i) && (s[i] = t[i]);
    return s
};
import {
    _ as xt,
    r as x,
    c as V,
    j as o,
    M as we,
    e as ot
} from "./fg33krlcm0qyi6yw.js";
import {
    bh as ht,
    _ as He,
    cU as bt,
    hd as Ye,
    y4 as vt,
    ck as St,
    mE as wt,
    l as B,
    d as D,
    a9 as at,
    n0 as jt,
    g9 as rt,
    a7 as kt,
    aX as Ee,
    oO as ct,
    aY as Ct,
    rJ as Y,
    C as $t,
    f as _t,
    h as Pt,
    mI as Mt,
    b as Et,
    dB as Nt,
    dC as At,
    dJ as Tt,
    fV as Rt,
    P as It
} from "./dykg4ktvbu3mhmdo.js";
import {
    uU as Ot,
    bp as Ft,
    bq as ut,
    uV as Je,
    uW as st,
    ca as Lt,
    dX as Dt,
    dr as Bt,
    n as Ut
} from "./k15yxxoybkkir2ou.js";
import {
    b as Gt
} from "./d500l0l73692yic4.js";
import "./obmzp3ebe8x6w67a.js";
import "./gd2ozzf4upgi0amm.js";
import "./tjmll0bdtco26rsw.js";
import "./nr0ly5umft9hqfl0.js";
import "./jnh7gh80gtj0452q.js";
import "./jbh6ambg0gcrgcqd.js";
const We = ht(() => xt(() => Promise.resolve().then(() => rs), void 0).then(t => t.PersonalityOnboardingModal)),
    Vt = async ({
        ctx: t,
        mode: e,
        intl: s,
        flow: i,
        selectedPersonality: l,
        selectedTraits: n,
        conversationId: a,
        messageId: r = null,
        onClose: d,
        onSubmit: u
    }) => {
        var h, m;
        const y = Ot(t, i, e, {
                selectedPersonality$: l,
                selectedTraits$: n
            }),
            {
                logging: p
            } = y;
        let c = !0;
        try {
            const g = await y.serverDataPromise;
            if (((h = g.personalities) == null ? void 0 : h.length) === 0) return;
            c = (m = g.can_close_onboarding) != null ? m : !0, Ft(t, ut.hasSeenExistingUserPersonalityOnboarding)
        } catch (g) {
            He.addError(g, {
                ctx: t,
                mode: e,
                flow: i,
                selectedPersonality: l,
                selectedTraits: n,
                conversationId: a
            });
            return
        }
        bt(t, We, {
            canClose: c,
            isOpen: !0,
            onboarding: y,
            onClose: () => {
                Ye(t, We), Je(p, !1, p.finalSelection), st(p), d == null || d(p)
            },
            onSubmit$: g => {
                if (Ye(t, We), Je(p, !0, p.finalSelection), st(p), u == null || u(g, p), e === "personality" && "key" in g) {
                    if (vt({
                            ctx: t,
                            personalityType: g.key,
                            conversationId: a,
                            messageId: r,
                            opts: {
                                optimistic: !0
                            }
                        }), g.key === "default") return;
                    requestAnimationFrame(() => {
                        requestAnimationFrame(() => {
                            const f = St(t),
                                k = g.key !== "default" ? s.formatMessage({
                                    id: "+CiZn7",
                                    defaultMessage: "Base style and tone updated"
                                }) : s.formatMessage({
                                    id: "gqHlYp",
                                    defaultMessage: "Base style and tone preserved"
                                });
                            f.success(k, {
                                duration: 4,
                                hasCloseButton: !0
                            })
                        })
                    })
                } else if (e === "traits" && Array.isArray(g)) {
                    const f = new Map;
                    g.forEach(k => {
                        f.set(k.key, "more")
                    }), wt(t, f, a, r)
                }
            }
        })
    };

function qt(t, e, s, i) {
    return t.current && (clearInterval(t.current), t.current = null), x.startTransition(() => {
        s(), t.current = window.setInterval(() => {
            x.startTransition(() => {
                i()
            })
        }, e)
    }), () => {
        t.current && (clearInterval(t.current), t.current = null)
    }
}

function zt(t) {
    "use forget";
    var F;
    const e = V.c(33),
        {
            personality: s,
            active: i,
            intervalSec: l,
            prefersReducedMotion: n,
            className: a
        } = t,
        r = l === void 0 ? 4 : l,
        d = n === void 0 ? !1 : n,
        [u, y] = x.useState(-1),
        p = x.useRef(null),
        [c, h] = x.useState(!1),
        [m, g] = x.useState(0),
        f = x.useDeferredValue(i);
    let k, v;
    e[0] !== f ? (k = () => {
        if (f) return () => {
            x.startTransition(() => {
                y(-1), h(!1)
            })
        }
    }, v = [f], e[0] = f, e[1] = k, e[2] = v) : (k = e[1], v = e[2]), x.useEffect(k, v);
    let w, S;
    e[3] !== c ? (w = () => {
        if (c) return;
        const _ = window.setTimeout(() => {
            h(!0), g(Wt)
        }, 1300);
        return () => window.clearTimeout(_)
    }, S = [c], e[3] = c, e[4] = w, e[5] = S) : (w = e[4], S = e[5]), x.useEffect(w, S);
    let $;
    e[6] !== s.example_messages ? ($ = (F = s.example_messages) != null ? F : [], e[6] = s.example_messages, e[7] = $) : $ = e[7];
    const j = $;
    let T;
    e[8] !== r || e[9] !== j.length || e[10] !== c ? (T = () => {
        if (c) return qt(p, r * 1e3, () => y(0), () => y(_ => (_ + 1) % Math.max(1, j.length)))
    }, e[8] = r, e[9] = j.length, e[10] = c, e[11] = T) : T = e[11];
    let R;
    e[12] !== r || e[13] !== j || e[14] !== c ? (R = [c, j, r], e[12] = r, e[13] = j, e[14] = c, e[15] = R) : R = e[15], x.useEffect(T, R);
    let E;
    e[16] !== a ? (E = B("relative col-span-full row-span-full grid overflow-clip", a), e[16] = a, e[17] = E) : E = e[17];
    let P;
    e[18] !== c ? (P = !c && o.jsx(Ht, {}), e[18] = c, e[19] = P) : P = e[19];
    let M;
    if (e[20] !== u || e[21] !== j || e[22] !== d || e[23] !== m) {
        let _;
        e[25] !== u || e[26] !== d || e[27] !== m ? (_ = (N, A) => o.jsx(x.Activity, {
            mode: A === u ? "visible" : "hidden",
            children: o.jsxs("div", {
                className: B("ease-spring-fast col-span-full row-span-full h-full transition-[opacity,display] transition-discrete contain-strict motion-reduce:transition-none! starting:opacity-0", A === u ? "opacity-100 duration-2000" : "opacity-0 duration-0"),
                "aria-label": N,
                children: [o.jsx("div", {
                    className: "invisible",
                    children: N
                }), o.jsx("div", {
                    className: "absolute inset-0",
                    "aria-hidden": !0,
                    children: o.jsx(Gt, {
                        className: "text-token-text-primary! text-heading-2! line-clamp-none cursor-default! font-medium",
                        text: N,
                        isStreamingAnimation: !d
                    }, m)
                })]
            })
        }, A), e[25] = u, e[26] = d, e[27] = m, e[28] = _) : _ = e[28], M = j.map(_), e[20] = u, e[21] = j, e[22] = d, e[23] = m, e[24] = M
    } else M = e[24];
    let I;
    return e[29] !== E || e[30] !== P || e[31] !== M ? (I = o.jsxs("div", {
        className: E,
        "aria-live": "polite",
        children: [P, M]
    }), e[29] = E, e[30] = P, e[31] = M, e[32] = I) : I = e[32], I
}

function Wt(t) {
    return t + 1
}

function Ht() {
    "use forget";
    const t = V.c(1);
    let e;
    return t[0] === Symbol.for("react.memo_cache_sentinel") ? (e = o.jsx("span", {
        className: "pulsing-dot absolute start-0 top-0 ms-3 mt-3 inline-block size-4 rounded-full bg-black motion-reduce:animate-none dark:bg-white"
    }), t[0] = e) : e = t[0], e
}

function dt(t) {
    "use forget";
    const e = V.c(16),
        {
            id: s,
            selected$: i,
            children: l,
            className: n,
            onSelect: a,
            selectedColor: r
        } = t,
        d = r === void 0 ? "custom" : r,
        u = D(i),
        y = u ? d : "custom",
        p = !u || d === "custom" ? "hover:bg-token-bg-tertiary/70" : "",
        c = u && d === "custom" ? "bg-token-bg-tertiary/75 text-token-text-secondary/75 hover:bg-token-bg-tertiary hover:text-token-text-primary!" : "";
    let h;
    e[0] !== n || e[1] !== p || e[2] !== c ? (h = B("focus-visible:focus-ring px-4 py-3", "font-normal", p, c, n), e[0] = n, e[1] = p, e[2] = c, e[3] = h) : h = e[3];
    let m;
    e[4] !== s || e[5] !== a || e[6] !== u || e[7] !== i ? (m = () => {
        a || i.set(!u), a == null || a(s)
    }, e[4] = s, e[5] = a, e[6] = u, e[7] = i, e[8] = m) : m = e[8];
    let g;
    return e[9] !== l || e[10] !== s || e[11] !== u || e[12] !== y || e[13] !== h || e[14] !== m ? (g = o.jsx(at, {
        color: y,
        className: h,
        contentWrapperClassName: "w-full",
        id: s,
        fullWidth: !0,
        "data-personality-id": s,
        role: "checkbox",
        "aria-checked": u,
        type: "button",
        onClick: m,
        children: l
    }), e[9] = l, e[10] = s, e[11] = u, e[12] = y, e[13] = h, e[14] = m, e[15] = g) : g = e[15], g
}

function Yt(t) {
    "use forget";
    var j;
    const e = V.c(26);
    let s, i;
    e[0] !== t ? (j = t, {
        personality: i
    } = j, s = ze(j, ["personality"]), e[0] = t, e[1] = s, e[2] = i) : (s = e[1], i = e[2]);
    const {
        selected$: l
    } = s, {
        badge: n,
        key: a,
        label: r,
        description: d,
        icon_src: u
    } = i, y = D(l);
    let p;
    e[3] === Symbol.for("react.memo_cache_sentinel") ? (p = B("group/pill hover:border-token-border-light border-1 border-transparent py-1! hover:text-white/90", "text-token-text-primary! justify-start"), e[3] = p) : p = e[3];
    let c;
    e[4] === Symbol.for("react.memo_cache_sentinel") ? (c = B("justify-start", "flex w-full items-center gap-3"), e[4] = c) : c = e[4];
    let h;
    e[5] !== u ? (h = u && o.jsx("div", {
        "aria-hidden": !0,
        children: o.jsx(jt, {
            svgString: u,
            className: "size-[1lh]"
        })
    }), e[5] = u, e[6] = h) : h = e[6];
    let m;
    e[7] !== n ? (m = T => o.jsxs("div", {
        className: "flex items-center gap-1",
        children: [o.jsx("span", {
            className: "text-[17px] text-inherit",
            children: T
        }), n && o.jsx("div", {
            className: "badge-base bg-token-interactive-bg-accent-default text-token-interactive-label-accent-default",
            children: n
        })]
    }), e[7] = n, e[8] = m) : m = e[8];
    let g;
    e[9] !== d || e[10] !== r || e[11] !== m ? (g = o.jsx("div", {
        className: "flex flex-1 flex-col items-start",
        children: o.jsx(we, {
            id: "tzFELg",
            defaultMessage: "<titleSpan>{title}</titleSpan><subtitleSpan>{subtitle}</subtitleSpan>",
            values: {
                title: r,
                subtitle: d,
                titleSpan: m,
                subtitleSpan: Jt
            }
        })
    }), e[9] = d, e[10] = r, e[11] = m, e[12] = g) : g = e[12];
    const f = y ? "opacity-100" : "opacity-0";
    let k;
    e[13] !== f ? (k = B("text-token-interactive-icon-accent-default self-center duration-75 ease-linear motion-safe:transition-opacity", f), e[13] = f, e[14] = k) : k = e[14];
    let v;
    e[15] === Symbol.for("react.memo_cache_sentinel") ? (v = o.jsx(Lt, {}), e[15] = v) : v = e[15];
    let w;
    e[16] !== k ? (w = o.jsx("div", {
        "aria-hidden": !0,
        className: k,
        children: v
    }), e[16] = k, e[17] = w) : w = e[17];
    let S;
    e[18] !== h || e[19] !== g || e[20] !== w ? (S = o.jsxs("div", {
        className: c,
        children: [h, g, w]
    }), e[18] = h, e[19] = g, e[20] = w, e[21] = S) : S = e[21];
    let $;
    return e[22] !== s || e[23] !== a || e[24] !== S ? ($ = o.jsx(dt, qe(Ve({
        id: a,
        className: p
    }, s), {
        children: S
    })), e[22] = s, e[23] = a, e[24] = S, e[25] = $) : $ = e[25], $
}

function Jt(t) {
    return o.jsx("span", {
        className: "text-token-text-tertiary text-start",
        children: t
    })
}

function Kt(t) {
    "use forget";
    const e = V.c(13),
        {
            personalities: s,
            isFullScreen: i,
            onSelect: l
        } = t;
    let n;
    e[0] !== l || e[1] !== s ? (n = p => {
        rt(() => {
            for (const c of s) c.selected$.set(c.key === p);
            l == null || l(p)
        })
    }, e[0] = l, e[1] = s, e[2] = n) : n = e[2];
    const a = n,
        r = i ? "max-md:gap-1" : "pt-1";
    let d;
    e[3] !== r ? (d = B("flex flex-col gap-2", r), e[3] = r, e[4] = d) : d = e[4];
    let u;
    if (e[5] !== a || e[6] !== s) {
        let p;
        e[8] !== a ? (p = c => o.jsx("li", {
            children: o.jsx(Yt, {
                personality: c,
                selected$: c.selected$,
                onSelect: a
            })
        }, c.key), e[8] = a, e[9] = p) : p = e[9], u = s.map(p), e[5] = a, e[6] = s, e[7] = u
    } else u = e[7];
    let y;
    return e[10] !== d || e[11] !== u ? (y = o.jsx("ul", {
        className: d,
        "aria-labelledby": "personality-onboarding-personality-list",
        children: u
    }), e[10] = d, e[11] = u, e[12] = y) : y = e[12], y
}

function Xt(t) {
    "use forget";
    var n;
    const e = V.c(8);
    let s, i;
    e[0] !== t ? (n = t, {
        trait: i
    } = n, s = ze(n, ["trait"]), e[0] = t, e[1] = s, e[2] = i) : (s = e[1], i = e[2]);
    let l;
    return e[3] !== s || e[4] !== i.key || e[5] !== i.label || e[6] !== i.selected$ ? (l = o.jsx(dt, qe(Ve({
        id: i.key,
        selected$: i.selected$,
        selectedColor: "accent"
    }, s), {
        children: i.label
    })), e[3] = s, e[4] = i.key, e[5] = i.label, e[6] = i.selected$, e[7] = l) : l = e[7], l
}

function Qt(t) {
    "use forget";
    const e = V.c(10),
        {
            traits: s,
            maxSelected: i
        } = t,
        l = i === void 0 ? 3 : i;
    let n;
    e[0] !== l || e[1] !== s ? (n = u => {
        rt(() => {
            var h;
            const y = s.find(m => m.key === u);
            if (!y) return;
            if (y.selected$()) {
                y.selected$.set(!1);
                return
            }
            const c = s.filter(m => m !== y && m.selected$());
            c.length >= l && ((h = c.shift()) == null || h.selected$.set(!1)), y.selected$.set(!0)
        })
    }, e[0] = l, e[1] = s, e[2] = n) : n = e[2];
    const a = n;
    let r;
    if (e[3] !== a || e[4] !== s) {
        let u;
        e[6] !== a ? (u = y => o.jsx("li", {
            children: o.jsx(Xt, {
                trait: y,
                onSelect: a
            })
        }, y.key), e[6] = a, e[7] = u) : u = e[7], r = s.map(u), e[3] = a, e[4] = s, e[5] = r
    } else r = e[5];
    let d;
    return e[8] !== r ? (d = o.jsx("ul", {
        className: "flex flex-wrap gap-2",
        children: r
    }), e[8] = r, e[9] = d) : d = e[9], d
}

function Zt(t) {
    "use forget";
    const e = V.c(3),
        {
            count: s,
            max: i,
            mode: l
        } = t;
    if (s === 0 && l === "traits") {
        let a;
        return e[0] !== i ? (a = o.jsx(we, {
            id: "personality-onboarding.title.select",
            defaultMessage: "Choose up to {max}",
            values: {
                max: i
            }
        }), e[0] = i, e[1] = a) : a = e[1], a
    }
    let n;
    return e[2] === Symbol.for("react.memo_cache_sentinel") ? (n = o.jsx(we, {
        id: "personality-onboarding.title.continue",
        defaultMessage: "Continue"
    }), e[2] = n) : n = e[2], n
}

function es(t) {
    "use forget";
    const e = V.c(3);
    let s, i;
    e[0] !== t ? (s = () => {
        if (t) {
            let l = null,
                n = null;
            return n = requestAnimationFrame(() => {
                l = requestAnimationFrame(() => {
                    x.startTransition(() => {
                        t.focus({
                            preventScroll: !0
                        })
                    })
                })
            }), () => {
                l && cancelAnimationFrame(l), n && cancelAnimationFrame(n)
            }
        }
    }, i = [t], e[0] = t, e[1] = s, e[2] = i) : (s = e[1], i = e[2]), x.useEffect(s, i)
}

function nt(t) {
    "use forget";
    const e = V.c(124),
        {
            canClose: s,
            onClose: i,
            onboarding: l
        } = t,
        {
            logging: n,
            mode: a,
            flow: r
        } = l,
        d = x.useId(),
        u = x.useId(),
        p = kt() === "rtl",
        c = ot(),
        h = Dt(!1),
        m = D(h);
    let g;
    e[0] !== l ? (g = () => l.personalities$(), e[0] = l, e[1] = g) : g = e[1];
    const f = D(g);
    let k;
    e[2] !== l ? (k = () => l.traits$(), e[2] = l, e[3] = k) : k = e[3];
    const v = D(k);
    let w;
    e[4] !== l ? (w = () => l.intervalSec$(), e[4] = l, e[5] = w) : w = e[5];
    const S = D(w);
    let $;
    e[6] !== h ? ($ = () => {
        const C = function(q) {
                x.startTransition(() => {
                    h.set(q)
                })
            },
            b = function(q) {
                C(q.matches)
            },
            G = matchMedia("(prefers-reduced-motion: reduce)");
        return G.addEventListener("change", b), C(G.matches), () => {
            G.removeEventListener("change", b)
        }
    }, e[6] = h, e[7] = $) : $ = e[7];
    let j;
    e[8] !== l || e[9] !== h ? (j = [h, l], e[8] = l, e[9] = h, e[10] = j) : j = e[10], x.useEffect($, j);
    const T = x.useRef(null),
        [R, E] = x.useState(null),
        P = a === "personality" ? 1 : 3;
    es(s ? null : R);
    let M;
    e[11] !== f ? (M = () => f.filter(as).length, e[11] = f, e[12] = M) : M = e[12];
    const I = D(M);
    let F;
    e[13] !== v ? (F = () => v.filter(os).length, e[13] = v, e[14] = F) : F = e[14];
    const _ = D(F),
        N = a === "personality" ? I : _;
    let A;
    e[15] !== f ? (A = () => f.some(is), e[15] = f, e[16] = A) : A = e[16];
    const L = D(A),
        [U, W] = x.useState(!1);
    let z;
    e[17] !== v ? (z = () => v.some(ls), e[17] = v, e[18] = z) : z = e[18];
    const mt = D(z);
    let je;
    e[19] !== f ? (je = () => {
        const C = {};
        for (const b of f) C[b.key] = b.selected$();
        return C
    }, e[19] = f, e[20] = je) : je = e[20];
    const J = D(je);
    let ke;
    e[21] !== f || e[22] !== R ? (ke = () => {
        const C = document.activeElement;
        if (!C || !(C instanceof HTMLButtonElement)) return;
        const b = C.getAttribute("data-personality-id"),
            G = f.find(O => O.key === b);
        return {
            id: b,
            focusedElement: C === R ? "primary-action" : C === T.current ? "close" : "personality",
            index: G ? f.indexOf(G) : -1
        }
    }, e[21] = f, e[22] = R, e[23] = ke) : ke = e[23];
    const Ne = Ee(ke);
    let Ce;
    e[24] !== Ne || e[25] !== f ? (Ce = C => {
        const b = Ne();
        if (!b) return !1;
        const G = f.length;
        if (!G) return !1;
        const O = b.focusedElement === "personality" && b.index >= 0 ? b.index : -1;
        let q;
        e: switch (C) {
            case "home":
                {
                    q = 0;
                    break e
                }
            case "end":
                {
                    q = G - 1;
                    break e
                }
            case "forward":
                {
                    q = O === -1 ? 0 : Math.min(G - 1, O + 1);
                    break e
                }
            case "backward":
                q = O === -1 ? G - 1 : Math.max(0, O - 1)
        }
        if (q === void 0) return !1;
        const Xe = f[q];
        if (!Xe) return !1;
        const Qe = document.querySelector('[data-personality-id="'.concat(Xe.key, '"]'));
        return Qe ? (Qe.focus(), !0) : !1
    }, e[24] = Ne, e[25] = f, e[26] = Ce) : Ce = e[26];
    const Ae = Ee(Ce),
        Ke = D(ct),
        H = Ke ? r === "new-user-flow-personality" || r === "new-user-flow-traits" : !0,
        K = H && s,
        Te = H && "m-auto w-[min(420px,95dvw)]";
    let X;
    e[27] !== Te ? (X = B(Te), e[27] = Te, e[28] = X) : X = e[28];
    let Q;
    e[29] !== n || e[30] !== a || e[31] !== f || e[32] !== t || e[33] !== v ? (Q = C => {
        C.preventDefault();
        let b;
        const {
            onSubmit$: G
        } = t, O = a === "personality" ? f.filter(ns).at(0) : v.filter(ss);
        !O || Array.isArray(O) && O.length === 0 || (b = "key" in O ? O.key : O.map(ts).join(","), Je(n, !0, b), G(O))
    }, e[29] = n, e[30] = a, e[31] = f, e[32] = t, e[33] = v, e[34] = Q) : Q = e[34];
    let Z;
    e[35] !== Ae || e[36] !== p ? (Z = C => {
        if (C.nativeEvent.isComposing) return;
        let b;
        e: switch (C.key) {
            case "ArrowUp":
                {
                    b = "backward";
                    break e
                }
            case "ArrowDown":
                {
                    b = "forward";
                    break e
                }
            case "ArrowLeft":
                {
                    b = p ? "forward" : "backward";
                    break e
                }
            case "ArrowRight":
                {
                    b = p ? "backward" : "forward";
                    break e
                }
            case "Home":
                {
                    b = p ? "end" : "home";
                    break e
                }
            case "End":
                b = p ? "home" : "end"
        }
        b && (C.preventDefault(), Ae(b))
    }, e[35] = Ae, e[36] = p, e[37] = Z) : Z = e[37];
    let ee;
    e[38] !== K ? (ee = o.jsx(lt, {
        canShrink: K
    }), e[38] = K, e[39] = ee) : ee = e[39];
    const Re = !Ke && "flex-1 px-6!";
    let te;
    e[40] !== Re ? (te = B("text-token-text-primary grid min-h-[200px] px-10 [font-weight:500] contain-size", Re), e[40] = Re, e[41] = te) : te = e[41];
    let se;
    e[42] !== s || e[43] !== i ? (se = s && o.jsx(Ct, {
        onClick: i,
        ref: T,
        className: "not-keyboard-focused:outline-none absolute end-2 top-0 aspect-square md:top-2"
    }), e[42] = s, e[43] = i, e[44] = se) : se = e[44];
    const Ie = U ? "hidden" : "visible",
        Oe = U ? "opacity-0 duration-0" : "opacity-100 duration-300";
    let ne;
    e[45] !== Oe ? (ne = B("col-span-full row-span-full flex flex-col gap-2 transition-[opacity,display] transition-discrete ease-linear motion-reduce:transition-none! starting:opacity-100", Oe), e[45] = Oe, e[46] = ne) : ne = e[46];
    let $e;
    e[47] === Symbol.for("react.memo_cache_sentinel") ? ($e = o.jsx(we, {
        id: "personality-onboarding.modal.title.try-new",
        defaultMessage: "Try a new personality for ChatGPT"
    }), e[47] = $e) : $e = e[47];
    let le;
    e[48] !== d ? (le = o.jsx("div", {
        className: "flex justify-between",
        children: o.jsx("h1", {
            className: "text-heading-2 font-medium text-balance",
            id: d,
            children: $e
        })
    }), e[48] = d, e[49] = le) : le = e[49];
    let _e;
    e[50] === Symbol.for("react.memo_cache_sentinel") ? (_e = o.jsx(we, {
        id: "personality-onboarding.modal.subtitle.try-new",
        defaultMessage: "Adjust the style and tone of how ChatGPT responds to you. This doesn't impact ChatGPT's capabilities. You can change this anytime in Settings."
    }), e[50] = _e) : _e = e[50];
    let ie;
    e[51] !== u ? (ie = o.jsx("p", {
        id: u,
        className: "text-token-text-tertiary text-body-regular text-pretty",
        children: _e
    }), e[51] = u, e[52] = ie) : ie = e[52];
    let oe;
    e[53] !== ne || e[54] !== le || e[55] !== ie ? (oe = o.jsxs("div", {
        className: ne,
        children: [le, ie]
    }), e[53] = ne, e[54] = le, e[55] = ie, e[56] = oe) : oe = e[56];
    let ae;
    e[57] !== Ie || e[58] !== oe ? (ae = o.jsx(x.Activity, {
        mode: Ie,
        children: oe
    }), e[57] = Ie, e[58] = oe, e[59] = ae) : ae = e[59];
    const Fe = U ? "visible" : "hidden";
    let re;
    if (e[60] !== S || e[61] !== c || e[62] !== f || e[63] !== m || e[64] !== J) {
        let C;
        e[66] !== S || e[67] !== c || e[68] !== m || e[69] !== J ? (C = b => o.jsx(x.Activity, {
            mode: J[b.key] ? "visible" : "hidden",
            children: o.jsx("div", {
                className: "col-span-full row-span-full grid transition-none!",
                "aria-label": c.formatMessage({
                    id: "personality-onboarding.intro.aria-label",
                    defaultMessage: "Examples of the {personality} personality"
                }, {
                    personality: b.label
                }),
                children: o.jsx(zt, {
                    personality: b,
                    active: !!J[b.key],
                    intervalSec: S,
                    prefersReducedMotion: m
                })
            })
        }, b.key), e[66] = S, e[67] = c, e[68] = m, e[69] = J, e[70] = C) : C = e[70], re = f.map(C), e[60] = S, e[61] = c, e[62] = f, e[63] = m, e[64] = J, e[65] = re
    } else re = e[65];
    let ce;
    e[71] !== Fe || e[72] !== re ? (ce = o.jsx(x.Activity, {
        mode: Fe,
        children: re
    }), e[71] = Fe, e[72] = re, e[73] = ce) : ce = e[73];
    let ue;
    e[74] !== te || e[75] !== se || e[76] !== ae || e[77] !== ce ? (ue = o.jsxs("header", {
        className: te,
        children: [se, ae, ce]
    }), e[74] = te, e[75] = se, e[76] = ae, e[77] = ce, e[78] = ue) : ue = e[78];
    const Le = H ? "py-4 max-md:px-6 min-md:p-8" : "min-h-0 flex-1 px-10 pt-1";
    let de;
    e[79] !== Le ? (de = B("space-y-6 overflow-y-auto", Le), e[79] = Le, e[80] = de) : de = e[80];
    let fe;
    e[81] !== c ? (fe = c.formatMessage({
        id: "personality-onboarding.modal.aria-label",
        defaultMessage: "Choose a personality"
    }), e[81] = c, e[82] = fe) : fe = e[82];
    let me;
    e[83] !== H || e[84] !== P || e[85] !== a || e[86] !== l.logging || e[87] !== f || e[88] !== v ? (me = a === "personality" ? o.jsx(Kt, {
        isFullScreen: H,
        personalities: f,
        onSelect: C => {
            W(!0), l.logging.increment("personality", C)
        }
    }) : o.jsx(Qt, {
        traits: v,
        maxSelected: P
    }), e[83] = H, e[84] = P, e[85] = a, e[86] = l.logging, e[87] = f, e[88] = v, e[89] = me) : me = e[89];
    let ge;
    e[90] !== de || e[91] !== fe || e[92] !== me ? (ge = o.jsx("section", {
        className: de,
        "aria-label": fe,
        id: "personality-onboarding-personality-list",
        children: me
    }), e[90] = de, e[91] = fe, e[92] = me, e[93] = ge) : ge = e[93];
    const De = H ? "min-md:pt-3" : "pt-6";
    let pe;
    e[94] !== De ? (pe = B("flex flex-col items-center justify-center px-10 max-md:px-6 min-md:gap-3", De), e[94] = De, e[95] = pe) : pe = e[95];
    const Be = "primary",
        Ue = a === "personality" ? !L : !mt,
        Ge = !L && "[--btn-background-color:var(--bg-tertiary)] [--btn-text-color:var(--text-secondary)]";
    let ye;
    e[96] !== Ge ? (ye = B("focus-visible:focus-ring w-full px-4.5 py-4 select-none", Ge), e[96] = Ge, e[97] = ye) : ye = e[97];
    let xe;
    e[98] !== P || e[99] !== a || e[100] !== N ? (xe = o.jsx(Zt, {
        count: N,
        max: P,
        mode: a
    }), e[98] = P, e[99] = a, e[100] = N, e[101] = xe) : xe = e[101];
    let he;
    e[102] !== Be || e[103] !== Ue || e[104] !== ye || e[105] !== xe ? (he = o.jsx(at, {
        color: Be,
        visuallyDisabled: Ue,
        fullWidth: !0,
        className: ye,
        ref: E,
        type: "submit",
        children: xe
    }), e[102] = Be, e[103] = Ue, e[104] = ye, e[105] = xe, e[106] = he) : he = e[106];
    let be;
    e[107] !== pe || e[108] !== he ? (be = o.jsx("footer", {
        className: pe,
        children: he
    }), e[107] = pe, e[108] = he, e[109] = be) : be = e[109];
    let ve;
    e[110] !== K ? (ve = o.jsx(lt, {
        canShrink: K
    }), e[110] = K, e[111] = ve) : ve = e[111];
    let Se;
    e[112] !== ee || e[113] !== ue || e[114] !== ge || e[115] !== be || e[116] !== ve ? (Se = o.jsxs("div", {
        className: "tall:h-[680px] grid h-[95dvh] w-full grid-rows-[minmax(10px,auto)_minmax(200px,1fr)_minmax(0,auto)_minmax(min-content,86px)_minmax(10px,auto)] p-0 max-md:h-[98dvh]",
        children: [ee, ue, ge, be, ve]
    }), e[112] = ee, e[113] = ue, e[114] = ge, e[115] = be, e[116] = ve, e[117] = Se) : Se = e[117];
    let Pe;
    return e[118] !== d || e[119] !== X || e[120] !== Q || e[121] !== Z || e[122] !== Se ? (Pe = o.jsx("form", {
        className: X,
        "aria-labelledby": d,
        onSubmit: Q,
        onKeyUp: Z,
        children: Se
    }), e[118] = d, e[119] = X, e[120] = Q, e[121] = Z, e[122] = Se, e[123] = Pe) : Pe = e[123], Pe
}

function ts(t) {
    return t.key
}

function ss(t) {
    return t.selected$()
}

function ns(t) {
    return t.selected$()
}

function ls(t) {
    return t.selected$()
}

function is(t) {
    return t.selected$()
}

function os(t) {
    return t.selected$()
}

function as(t) {
    return t.selected$()
}

function lt(t) {
    "use forget";
    const e = V.c(4),
        {
            canShrink: s
        } = t,
        i = s && "max-md:h-6";
    let l;
    e[0] !== i ? (l = B("h-10 min-h-0", i), e[0] = i, e[1] = l) : l = e[1];
    let n;
    return e[2] !== l ? (n = o.jsx("div", {
        className: l
    }), e[2] = l, e[3] = n) : n = e[3], n
}

function ft(t) {
    "use forget";
    var F;
    const e = V.c(47),
        {
            canClose: s,
            className: i,
            onClose: l,
            onboarding: n,
            testId: a
        } = t,
        {
            flow: r
        } = n,
        [d, u] = x.useState((F = t.isOpen) != null ? F : !0),
        y = x.useId(),
        p = x.useId(),
        c = D(ct),
        h = c ? r === "new-user-flow-personality" || r === "new-user-flow-traits" : !0,
        m = x.useRef(null),
        g = x.useRef(null);
    let f;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (f = _ => {
        m.current = _, g.current = "submit", u(!1)
    }, e[0] = f) : f = e[0];
    const k = Ee(f);
    let v;
    e[1] !== l || e[2] !== n.logging ? (v = () => {
        g.current = "close", u(!1), n.logging.log("skip"), l()
    }, e[1] = l, e[2] = n.logging, e[3] = v) : v = e[3];
    const w = Ee(v);
    let S;
    e[4] !== n.logging ? (S = () => {
        n.logging.log("impression")
    }, e[4] = n.logging, e[5] = S) : S = e[5];
    let $;
    if (e[6] !== n ? ($ = [n], e[6] = n, e[7] = $) : $ = e[7], x.useEffect(S, $), !c) {
        const _ = s ? "history" : "default";
        let N;
        e[8] !== l || e[9] !== n.logging || e[10] !== t ? (N = () => {
            m.current && g.current === "submit" ? t.onSubmit$(m.current) : g.current === "close" && (n.logging.log("skip"), l())
        }, e[8] = l, e[9] = n.logging, e[10] = t, e[11] = N) : N = e[11];
        let A;
        e[12] === Symbol.for("react.memo_cache_sentinel") ? (A = o.jsx(Y.Backdrop, {}), e[12] = A) : A = e[12];
        let L;
        e[13] !== s || e[14] !== w || e[15] !== k || e[16] !== n ? (L = o.jsx(Y.ScrollRoot, {
            children: o.jsx(Y.ContentSection, {
                children: o.jsx(nt, {
                    canClose: s,
                    onClose: w,
                    onboarding: n,
                    onSubmit$: k
                })
            })
        }), e[13] = s, e[14] = w, e[15] = k, e[16] = n, e[17] = L) : L = e[17];
        let U;
        e[18] !== s || e[19] !== L ? (U = o.jsx(Y.Content, {
            handle: s,
            children: L
        }), e[18] = s, e[19] = L, e[20] = U) : U = e[20];
        let W;
        e[21] !== s || e[22] !== N || e[23] !== U ? (W = o.jsx(Y.Portal, {
            children: o.jsxs(Y.View, {
                "data-testid": "personality-onboarding-sheet",
                onCloseComplete: N,
                swipeDismissal: s,
                swipeOvershoot: !0,
                children: [A, U]
            })
        }), e[21] = s, e[22] = N, e[23] = U, e[24] = W) : W = e[24];
        let z;
        return e[25] !== d || e[26] !== _ || e[27] !== W ? (z = o.jsx(Y.Root, {
            defaultPresented: d,
            sheetRole: "dialog",
            behavior: _,
            sheetName: "personality-onboarding-sheet",
            presented: d,
            children: W
        }), e[25] = d, e[26] = _, e[27] = W, e[28] = z) : z = e[28], z
    }
    const j = a != null ? a : "modal-personality-onboarding",
        T = !s,
        R = h ? "grid place-content-center" : "max-w-[min(420px,95dvw)] py-0";
    let E;
    e[29] !== i || e[30] !== R ? (E = B(i, R), e[29] = i, e[30] = R, e[31] = E) : E = e[31];
    const P = h ? "fullscreen" : "custom";
    let M;
    e[32] !== s || e[33] !== w || e[34] !== n || e[35] !== t.onSubmit$ ? (M = o.jsx(nt, {
        canClose: s,
        onClose: w,
        onboarding: n,
        onSubmit$: t.onSubmit$
    }), e[32] = s, e[33] = w, e[34] = n, e[35] = t.onSubmit$, e[36] = M) : M = e[36];
    let I;
    return e[37] !== y || e[38] !== d || e[39] !== w || e[40] !== p || e[41] !== j || e[42] !== T || e[43] !== E || e[44] !== P || e[45] !== M ? (I = o.jsx($t, {
        ariaLabelledBy: y,
        ariaDescribedBy: p,
        testId: j,
        isOpen: d,
        onClose: w,
        shouldIgnoreClickOutside: T,
        isScrollable: !1,
        allowVerticalContentToOverflow: !1,
        className: E,
        noPadding: !0,
        size: P,
        footerContent: null,
        children: M
    }), e[37] = y, e[38] = d, e[39] = w, e[40] = p, e[41] = j, e[42] = T, e[43] = E, e[44] = P, e[45] = M, e[46] = I) : I = e[46], I
}
const rs = Object.freeze(Object.defineProperty({
        __proto__: null,
        PersonalityOnboardingModal: ft
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    it = _t(() => Pt(!1));

function vs(t) {
    "use forget";
    const e = V.c(31),
        {
            conversationId: s,
            messageId: i,
            isPersonalityOnboardingRoute: l,
            onClose: n,
            onSubmit: a
        } = t,
        r = Et(),
        d = ot(),
        u = Mt(),
        {
            eligible: y,
            isLoading: p
        } = Bt(ut.hasSeenExistingUserPersonalityOnboarding);
    let c;
    e[0] !== r ? (c = () => it(r), e[0] = r, e[1] = c) : c = e[1];
    const h = D(c);
    let m;
    e[2] !== u || e[3] !== s || e[4] !== r ? (m = () => {
        var A;
        const _ = s ? Nt(r, s) : null,
            N = _ && ((A = At(_)) == null ? void 0 : A.value) === Tt.STREAMING;
        return Rt(u) && !N
    }, e[2] = u, e[3] = s, e[4] = r, e[5] = m) : m = e[5];
    const g = D(m),
        [f, k] = x.useState(g),
        v = x.useRef(!g),
        S = f && (h || y && !p || l);
    let $;
    e[6] !== y ? ($ = () => {
        y && (He.addAction("chatgpt_personality_upsell_available"), It.logEventWithStatsig("Web: Personality Upsell Eligibility Checked", "chatgpt_personality_upsell_eligibility_checked"))
    }, e[6] = y, e[7] = $) : $ = e[7];
    let j;
    e[8] !== r || e[9] !== y ? (j = [y, r], e[8] = r, e[9] = y, e[10] = j) : j = e[10], x.useEffect($, j);
    let T, R;
    e[11] === Symbol.for("react.memo_cache_sentinel") ? (T = () => () => {
        v.current && He.addAction("chatgpt_personality_upsell_triggering_action_cancelled")
    }, R = [], e[11] = T, e[12] = R) : (T = e[11], R = e[12]), x.useEffect(T, R);
    let E;
    e[13] !== g ? (E = () => {
        if (!g) return;
        const _ = window.setTimeout(() => {
            k(!0), v.current = !1
        }, 3e3);
        return () => clearTimeout(_)
    }, e[13] = g, e[14] = E) : E = e[14], x.useEffect(E);
    let P;
    e[15] !== s || e[16] !== r || e[17] !== d || e[18] !== i || e[19] !== n || e[20] !== a ? (P = _ => {
        const N = _ === "traits" ? "new-user-flow-traits" : "existing-user-flow-personality",
            A = function() {
                it.set(r, !1)
            };
        Vt({
            ctx: r,
            intl: d,
            conversationId: s,
            messageId: i,
            mode: _,
            selectedPersonality: N === "existing-user-flow-personality" ? "default" : null,
            flow: N,
            onClose: (...L) => {
                const U = L;
                n == null || n(...U), A()
            },
            onSubmit: (...L) => {
                const U = L;
                a == null || a(...U), A()
            }
        })
    }, e[15] = s, e[16] = r, e[17] = d, e[18] = i, e[19] = n, e[20] = a, e[21] = P) : P = e[21];
    const M = x.useEffectEvent(P);
    let I;
    e[22] !== r || e[23] !== M || e[24] !== l || e[25] !== S ? (I = () => {
        if (S) return M("personality"), () => {
            Ye(r, ft), l && Ut("/")
        }
    }, e[22] = r, e[23] = M, e[24] = l, e[25] = S, e[26] = I) : I = e[26];
    let F;
    return e[27] !== r || e[28] !== l || e[29] !== S ? (F = [r, S, l], e[27] = r, e[28] = l, e[29] = S, e[30] = F) : F = e[30], x.useEffect(I, F), null
}
export {
    vs as NewUserPersonalityOnboarding, it as existingUserPersonalityFlowOpen$
};
//# sourceMappingURL=m6rx5g8roy5qs7qe.js.map