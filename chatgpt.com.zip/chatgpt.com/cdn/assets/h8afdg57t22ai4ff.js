var oe = Object.defineProperty,
    ne = Object.defineProperties;
var ae = Object.getOwnPropertyDescriptors;
var Y = Object.getOwnPropertySymbols;
var le = Object.prototype.hasOwnProperty,
    re = Object.prototype.propertyIsEnumerable;
var Z = (o, e, i) => e in o ? oe(o, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: i
    }) : o[e] = i,
    ee = (o, e) => {
        for (var i in e || (e = {})) le.call(e, i) && Z(o, i, e[i]);
        if (Y)
            for (var i of Y(e)) re.call(e, i) && Z(o, i, e[i]);
        return o
    },
    ie = (o, e) => ne(o, ae(e));
import {
    c as se,
    b as ce,
    r as te
} from "./fg33krlcm0qyi6yw.js";
import {
    cl as de,
    cm as ke,
    cn as fe,
    co as ge,
    cp as me,
    cq as ue
} from "./k15yxxoybkkir2ou.js";
import {
    aG as n,
    aO as ye,
    ag as be,
    o as we,
    b as Ee,
    ac as Te,
    aF as pe
} from "./dykg4ktvbu3mhmdo.js";
const ve = {
        [n.Gclid]: "isUserEligibleForPioneer",
        [n.Fbclid]: "isUserEligibleForMaverick",
        [n.Rdtcid]: "isUserEligibleForTrailBlazer",
        [n.Tiktokclid]: "isUserEligibleForStratos",
        [n.Liclid]: "isUserEligibleForSeeker",
        [n.Msclkid]: "isUserEligibleForWayfinder"
    },
    Ke = {
        [n.Fbclid]: "maverick",
        [n.Rdtcid]: "trailblazer",
        [n.Tiktokclid]: "stratos",
        [n.Liclid]: "seeker",
        [n.Msclkid]: "wayfinder",
        [n.Gclid]: "pioneer"
    };

function Ae({
    cookieKey: o,
    baseEventKey: e,
    currentUser: i,
    ctx: k
}) {
    var d;
    const t = Te().eligibleNoCookieBusinessMarketing[ve[o]],
        s = i != null && i.id ? "_".concat(i.id) : ":anon",
        c = "pixels_".concat(s, "_").concat(o, "_").concat(e);
    let r = !1;
    try {
        const a = pe.getMarketingCookie(o),
            l = (d = window.sessionStorage) == null ? void 0 : d.getItem(c);
        r = (!!a || t) && !l
    } catch (a) {
        r = !1
    }
    return {
        eligible: r,
        isLoading: !1,
        markAsViewed: () => {
            var a;
            try {
                (a = window.sessionStorage) == null || a.setItem(c, "true")
            } catch (l) {}
        }
    }
}

function E(o) {
    "use forget";
    const e = se.c(6),
        {
            cookieKey: i,
            baseEventKey: k,
            isTestMode: u
        } = o,
        t = Ee(),
        s = be(),
        c = Ke[i],
        r = ue({
            ctx: t,
            consumer: c,
            type: "non_signup"
        });
    if (u && !we(t, "3782704232") || !i || typeof window > "u" || !r) {
        let l;
        return e[0] === Symbol.for("react.memo_cache_sentinel") ? (l = {
            eligible: !1,
            isLoading: !1,
            markAsViewed: Ve
        }, e[0] = l) : l = e[0], l
    }
    let a;
    return e[1] !== k || e[2] !== i || e[3] !== t || e[4] !== s ? (a = Ae({
        cookieKey: i,
        baseEventKey: k,
        currentUser: s,
        ctx: t
    }), e[1] = k, e[2] = i, e[3] = t, e[4] = s, e[5] = a) : a = e[5], a
}

function Ve() {}

function Be(o) {
    "use forget";
    var j, D, H, J, X;
    const e = se.c(58),
        {
            key: i,
            isTestMode: k,
            allowUnauthenticatedTracking: u
        } = o,
        t = k === void 0 ? !1 : k,
        s = u === void 0 ? !1 : u;
    let c;
    e[0] !== t || e[1] !== i ? (c = {
        cookieKey: n.Gclid,
        baseEventKey: i,
        isTestMode: t
    }, e[0] = t, e[1] = i, e[2] = c) : c = e[2];
    const r = E(c);
    let d;
    e[3] !== t || e[4] !== i ? (d = {
        cookieKey: n.Fbclid,
        baseEventKey: i,
        isTestMode: t
    }, e[3] = t, e[4] = i, e[5] = d) : d = e[5];
    const a = E(d);
    let l;
    e[6] !== t || e[7] !== i ? (l = {
        cookieKey: n.Rdtcid,
        baseEventKey: i,
        isTestMode: t
    }, e[6] = t, e[7] = i, e[8] = l) : l = e[8];
    const y = E(l);
    let T;
    e[9] !== t || e[10] !== i ? (T = {
        cookieKey: n.Liclid,
        baseEventKey: i,
        isTestMode: t
    }, e[9] = t, e[10] = i, e[11] = T) : T = e[11];
    const b = E(T);
    let p;
    e[12] !== t || e[13] !== i ? (p = {
        cookieKey: n.Msclkid,
        baseEventKey: i,
        isTestMode: t
    }, e[12] = t, e[13] = i, e[14] = p) : p = e[14];
    const w = E(p);
    let v;
    e[15] !== s || e[16] !== i || e[17] !== r.markAsViewed ? (v = {
        key: i,
        onTracked: r.markAsViewed,
        allowUnauthenticatedTracking: s
    }, e[15] = s, e[16] = i, e[17] = r.markAsViewed, e[18] = v) : v = e[18];
    const F = de(v);
    let K;
    e[19] !== s || e[20] !== i || e[21] !== a.markAsViewed ? (K = {
        key: i,
        onTracked: a.markAsViewed,
        allowUnauthenticatedTracking: s
    }, e[19] = s, e[20] = i, e[21] = a.markAsViewed, e[22] = K) : K = e[22];
    const W = ke(K);
    let A;
    e[23] !== s || e[24] !== i || e[25] !== y.markAsViewed ? (A = {
        key: i,
        onTracked: y.markAsViewed,
        allowUnauthenticatedTracking: s
    }, e[23] = s, e[24] = i, e[25] = y.markAsViewed, e[26] = A) : A = e[26];
    const R = fe(A);
    let V;
    e[27] !== s || e[28] !== i || e[29] !== b.markAsViewed ? (V = {
        key: i,
        onTracked: b.markAsViewed,
        allowUnauthenticatedTracking: s
    }, e[27] = s, e[28] = i, e[29] = b.markAsViewed, e[30] = V) : V = e[30];
    const z = ge(V);
    let h;
    e[31] !== s || e[32] !== i || e[33] !== w.markAsViewed ? (h = {
        key: i,
        onTracked: w.markAsViewed,
        allowUnauthenticatedTracking: s
    }, e[31] = s, e[32] = i, e[33] = w.markAsViewed, e[34] = h) : h = e[34];
    const I = me(h),
        P = ((j = r.isLoading) != null ? j : !1) || ((D = a.isLoading) != null ? D : !1) || ((H = y.isLoading) != null ? H : !1) || ((J = b.isLoading) != null ? J : !1) || ((X = w.isLoading) != null ? X : !1);
    let M;
    e[35] === Symbol.for("react.memo_cache_sentinel") ? (M = ie(ee({}, ye), {
        staleTime: 144e5,
        refetchOnMount: !1,
        refetchOnWindowFocus: !1,
        refetchOnReconnect: !1
    }), e[35] = M) : M = e[35];
    const {
        data: U,
        isLoading: f
    } = ce(M), $ = U ? U.is_consent_required ? !!U.consent_marketing : !0 : !1, G = !!r.eligible, O = !!a.eligible, q = !!y.eligible, N = !!b.eligible, Q = !!w.eligible;
    let S;
    e[36] !== G || e[37] !== O || e[38] !== q || e[39] !== N || e[40] !== Q ? (S = {
        pioneer: G,
        maverick: O,
        trailBlazer: q,
        seeker: N,
        wayfinder: Q
    }, e[36] = G, e[37] = O, e[38] = q, e[39] = N, e[40] = Q, e[41] = S) : S = e[41];
    const g = S,
        L = te.useRef(!1);
    let B;
    e[42] !== f || e[43] !== g || e[44] !== $ || e[45] !== W || e[46] !== F || e[47] !== z || e[48] !== R || e[49] !== I ? (B = () => {
        if (f) {
            L.current = !0;
            return
        }
        if (!$) {
            L.current = !1;
            return
        }
        L.current = !1, g.pioneer && F(), g.maverick && W(), g.trailBlazer && R(), g.seeker && z(), g.wayfinder && I()
    }, e[42] = f, e[43] = g, e[44] = $, e[45] = W, e[46] = F, e[47] = z, e[48] = R, e[49] = I, e[50] = B) : B = e[50];
    const m = B;
    let _, C;
    e[51] !== f || e[52] !== m ? (_ = () => {
        !f && L.current && m()
    }, C = [f, m], e[51] = f, e[52] = m, e[53] = _, e[54] = C) : (_ = e[53], C = e[54]), te.useEffect(_, C);
    let x;
    return e[55] !== P || e[56] !== m ? (x = {
        trackSelectedPixels: m,
        pixelsLoading: P
    }, e[55] = P, e[56] = m, e[57] = x) : x = e[57], x
}
export {
    Be as u
};
//# sourceMappingURL=h8afdg57t22ai4ff.js.map