import {
    c as e,
    s as o
} from "./dykg4ktvbu3mhmdo.js";
const t = e(o, "a5db9a", 21, 20);
export {
    t as G
};
//# sourceMappingURL=m4js9idemp5c8b87.js.map