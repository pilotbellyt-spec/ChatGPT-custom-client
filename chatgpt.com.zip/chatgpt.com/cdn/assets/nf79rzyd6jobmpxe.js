import {
    c as e,
    s as o
} from "./dykg4ktvbu3mhmdo.js";
const t = e(o, "00f12a", 20, 20);
export {
    t as M
};
//# sourceMappingURL=nf79rzyd6jobmpxe.js.map