import {
    c as ee,
    r as V,
    j as g,
    e as se,
    f as ae
} from "./fg33krlcm0qyi6yw.js";
import {
    d as $,
    mR as te,
    l as v,
    bv as ie,
    bg as ne,
    P as le
} from "./dykg4ktvbu3mhmdo.js";
import {
    dX as Z
} from "./k15yxxoybkkir2ou.js";
const oe = 2800;

function re(t) {
    "use forget";
    const e = ee.c(60),
        {
            primaryText: u,
            secondaryTexts: y,
            icon: l,
            rotationIntervalMs: d,
            className: r,
            primaryTextClassName: c,
            secondaryTextClassName: f
        } = t,
        i = d === void 0 ? oe : d,
        M = !$(te);
    let o;
    e[0] !== y ? (o = () => y.filter(fe), e[0] = y, e[1] = o) : o = e[1];
    const n = Z(o),
        s = Z(0);
    let x;
    e[2] !== n ? (x = () => n(), e[2] = n, e[3] = x) : x = e[3];
    const a = $(x);
    let m;
    e[4] !== s ? (m = () => {
        s.set(0)
    }, e[4] = s, e[5] = m) : m = e[5];
    let G;
    e[6] !== s || e[7] !== a ? (G = [s, a], e[6] = s, e[7] = a, e[8] = G) : G = e[8], V.useEffect(m, G);
    let R;
    e[9] !== s || e[10] !== i || e[11] !== a.length ? (R = () => {
        if (a.length <= 1) {
            s.set(0);
            return
        }
        const h = window.setInterval(() => {
            s.set(H => {
                const P = H + 1;
                return P >= a.length ? 0 : P
            })
        }, i);
        return () => {
            window.clearInterval(h)
        }
    }, e[9] = s, e[10] = i, e[11] = a.length, e[12] = R) : R = e[12];
    let z;
    e[13] !== s || e[14] !== i || e[15] !== a ? (z = [s, i, a], e[13] = s, e[14] = i, e[15] = a, e[16] = z) : z = e[16], V.useEffect(R, z);
    let F;
    e[17] !== s || e[18] !== n ? (F = () => {
        var P, Y;
        const h = n(),
            H = s();
        return (Y = (P = h[H]) != null ? P : h[0]) != null ? Y : ""
    }, e[17] = s, e[18] = n, e[19] = F) : F = e[19];
    const O = $(F);
    let B;
    e[20] !== n ? (B = () => {
        const h = n();
        return h.length === 0 ? " " : h.reduce(ce, "") || " "
    }, e[20] = n, e[21] = B) : B = e[21];
    const J = $(B);
    let w;
    e[22] !== r ? (w = v("flex h-full w-full items-center justify-center", r), e[22] = r, e[23] = w) : w = e[23];
    const K = M ? "text-center" : "text-start";
    let S;
    e[24] !== K ? (S = v("flex flex-col items-start gap-1", K), e[24] = K, e[25] = S) : S = e[25];
    let b;
    e[26] !== c ? (b = v("loading-shimmer-pure-text text-token-text-secondary flex items-center gap-2 text-center text-base font-medium", c), e[26] = c, e[27] = b) : b = e[27];
    const Q = M && "w-full";
    let _;
    e[28] !== Q ? (_ = v(Q), e[28] = Q, e[29] = _) : _ = e[29];
    let E;
    e[30] !== u || e[31] !== _ ? (E = g.jsx("span", {
        className: _,
        children: u
    }), e[30] = u, e[31] = _, e[32] = E) : E = e[32];
    let N;
    e[33] !== l ? (N = V.isValidElement(l) ? V.cloneElement(l) : l, e[33] = l, e[34] = N) : N = e[34];
    let T;
    e[35] !== b || e[36] !== E || e[37] !== N ? (T = g.jsxs("div", {
        className: b,
        children: [E, N]
    }), e[35] = b, e[36] = E, e[37] = N, e[38] = T) : T = e[38];
    let I;
    e[39] !== f ? (I = v("text-token-text-tertiary relative grid h-5 items-center overflow-hidden text-sm", f), e[39] = f, e[40] = I) : I = e[40];
    let k;
    e[41] !== J ? (k = g.jsx("span", {
        "aria-hidden": "true",
        className: "invisible col-start-1 row-start-1 whitespace-pre-wrap",
        children: J
    }), e[41] = J, e[42] = k) : k = e[42];
    let D, U, W, X;
    e[43] === Symbol.for("react.memo_cache_sentinel") ? (D = {
        opacity: 0,
        y: 8
    }, U = {
        opacity: 1,
        y: 0
    }, W = {
        opacity: 0,
        y: -8
    }, X = {
        duration: .35,
        ease: "easeInOut"
    }, e[43] = D, e[44] = U, e[45] = W, e[46] = X) : (D = e[43], U = e[44], W = e[45], X = e[46]);
    let j;
    e[47] !== O ? (j = g.jsx(ie, {
        mode: "wait",
        children: g.jsx(ne.span, {
            initial: D,
            animate: U,
            exit: W,
            transition: X,
            className: "col-start-1 row-start-1",
            children: O
        }, O)
    }), e[47] = O, e[48] = j) : j = e[48];
    let L;
    e[49] !== I || e[50] !== k || e[51] !== j ? (L = g.jsxs("div", {
        className: I,
        "aria-live": "polite",
        children: [k, j]
    }), e[49] = I, e[50] = k, e[51] = j, e[52] = L) : L = e[52];
    let A;
    e[53] !== S || e[54] !== T || e[55] !== L ? (A = g.jsxs("div", {
        className: S,
        children: [T, L]
    }), e[53] = S, e[54] = T, e[55] = L, e[56] = A) : A = e[56];
    let q;
    return e[57] !== w || e[58] !== A ? (q = g.jsx("div", {
        className: w,
        children: A
    }), e[57] = w, e[58] = A, e[59] = q) : q = e[59], q
}

function ce(t, e) {
    return e.length > t.length ? e : t
}

function fe(t) {
    return t.trim().length > 0
}

function xe() {
    "use forget";
    const t = ee.c(31),
        e = se();
    let u;
    t[0] === Symbol.for("react.memo_cache_sentinel") ? (u = [], t[0] = u) : u = t[0], V.useEffect(de, u);
    const y = $(te);
    let l;
    t[1] !== e ? (l = e.formatMessage(p.turboBoost), t[1] = e, t[2] = l) : l = t[2];
    let d;
    t[3] !== e ? (d = e.formatMessage(p.advancedVoice), t[3] = e, t[4] = d) : d = t[4];
    let r;
    t[5] !== e ? (r = e.formatMessage(p.imageGenerators), t[5] = e, t[6] = r) : r = t[6];
    let c;
    t[7] !== e ? (c = e.formatMessage(p.reasoningEngines), t[7] = e, t[8] = c) : c = t[8];
    let f;
    t[9] !== e ? (f = e.formatMessage(p.moreFiles), t[9] = e, t[10] = f) : f = t[10];
    let i;
    t[11] !== e ? (i = e.formatMessage(p.bigIdeas), t[11] = e, t[12] = i) : i = t[12];
    let C;
    t[13] !== l || t[14] !== d || t[15] !== r || t[16] !== c || t[17] !== f || t[18] !== i ? (C = [l, d, r, c, f, i], t[13] = l, t[14] = d, t[15] = r, t[16] = c, t[17] = f, t[18] = i, t[19] = C) : C = t[19];
    const M = C;
    let o;
    t[20] !== e ? (o = e.formatMessage(p.loadingPrimary), t[20] = e, t[21] = o) : o = t[21];
    const n = y ? "min-w-[360px]" : "w-full";
    let s;
    t[22] !== n ? (s = v(n), t[22] = n, t[23] = s) : s = t[23];
    const x = y ? "min-w-[360px]" : "w-full";
    let a;
    t[24] !== x ? (a = v(x), t[24] = x, t[25] = a) : a = t[25];
    let m;
    return t[26] !== M || t[27] !== s || t[28] !== a || t[29] !== o ? (m = g.jsx(re, {
        className: "min-h-[320px]",
        primaryText: o,
        secondaryTexts: M,
        primaryTextClassName: s,
        secondaryTextClassName: a,
        rotationIntervalMs: 2600
    }), t[26] = M, t[27] = s, t[28] = a, t[29] = o, t[30] = m) : m = t[30], m
}

function de() {
    const t = performance.now();
    return () => {
        if (t) {
            const e = performance.now() - t;
            le.logValueEventWithStatsig({
                segmentEventName: "Checkout Page Loading Time Spent MS",
                statsigEventName: "chatgpt_web_checkout_loading_page_time_spent_ms",
                value: Math.round(e)
            })
        }
    }
}
const p = ae({
    loadingPrimary: {
        id: "checkout.loading.primary",
        defaultMessage: "Getting your plan ready"
    },
    turboBoost: {
        id: "checkout.loading.turboBoost",
        defaultMessage: "Giving your chat a little turbo boost"
    },
    advancedVoice: {
        id: "checkout.loading.advancedVoice",
        defaultMessage: "Unlocking access to advanced voice"
    },
    imageGenerators: {
        id: "checkout.loading.imageGenerators",
        defaultMessage: "Warming up the image generators"
    },
    reasoningEngines: {
        id: "checkout.loading.reasoningEngines",
        defaultMessage: "Dusting off the reasoning engines"
    },
    moreFiles: {
        id: "checkout.loading.moreFiles",
        defaultMessage: "Making room for even more files"
    },
    bigIdeas: {
        id: "checkout.loading.bigIdeas",
        defaultMessage: "Setting the stage for your big ideas"
    }
});
export {
    xe as C
};
//# sourceMappingURL=lfxtpzw52mtvoale.js.map