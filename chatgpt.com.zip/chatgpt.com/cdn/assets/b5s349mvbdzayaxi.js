var dt = Object.defineProperty,
    Ct = Object.defineProperties;
var Dt = Object.getOwnPropertyDescriptors;
var tt = Object.getOwnPropertySymbols;
var At = Object.prototype.hasOwnProperty,
    Ft = Object.prototype.propertyIsEnumerable;
var et = (t, n, e) => n in t ? dt(t, n, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : t[n] = e,
    L = (t, n) => {
        for (var e in n || (n = {})) At.call(n, e) && et(t, e, n[e]);
        if (tt)
            for (var e of tt(n)) Ft.call(n, e) && et(t, e, n[e]);
        return t
    },
    O = (t, n) => Ct(t, Dt(n));
import {
    u as E,
    a as Z,
    n as v,
    b as Q,
    c as _,
    m as C,
    d as St,
    e as zt,
    f as z,
    s as V,
    g as Lt,
    h as nt,
    i as j,
    j as M,
    k as Tt
} from "./nfccle6oyncifphl.js";
import {
    o as I
} from "./gy1lpvuoewmzh42c.js";
import {
    zr as Mt,
    zs as Rt
} from "./k15yxxoybkkir2ou.js";
import {
    h as ut
} from "./dbshkzvpochy4889.js";

function it(t, n) {
    const e = String(t);
    if (typeof n != "string") throw new TypeError("Expected character");
    let r = 0,
        l = e.indexOf(n);
    for (; l !== -1;) r++, l = e.indexOf(n, l + n.length);
    return r
}

function Et(t) {
    if (typeof t != "string") throw new TypeError("Expected a string");
    return t.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&").replace(/-/g, "\\x2d")
}

function It(t, n, e) {
    const l = Mt((e || {}).ignore || []),
        a = Pt(n);
    let i = -1;
    for (; ++i < a.length;) Rt(t, "text", u);

    function u(c, g) {
        let o = -1,
            m;
        for (; ++o < g.length;) {
            const k = g[o],
                h = m ? m.children : void 0;
            if (l(k, h ? h.indexOf(k) : void 0, m)) return;
            m = k
        }
        if (m) return f(c, g)
    }

    function f(c, g) {
        const o = g[g.length - 1],
            m = a[i][0],
            k = a[i][1];
        let h = 0;
        const p = o.children.indexOf(c);
        let w = !1,
            x = [];
        m.lastIndex = 0;
        let y = m.exec(c.value);
        for (; y;) {
            const d = y.index,
                A = {
                    index: y.index,
                    input: y.input,
                    stack: [...g, c]
                };
            let D = k(...y, A);
            if (typeof D == "string" && (D = D.length > 0 ? {
                    type: "text",
                    value: D
                } : void 0), D === !1 ? m.lastIndex = d + 1 : (h !== d && x.push({
                    type: "text",
                    value: c.value.slice(h, d)
                }), Array.isArray(D) ? x.push(...D) : D && x.push(D), h = d + y[0].length, w = !0), !m.global) break;
            y = m.exec(c.value)
        }
        return w ? (h < c.value.length && x.push({
            type: "text",
            value: c.value.slice(h)
        }), o.children.splice(p, 1, ...x)) : x = [c], p + x.length
    }
}

function Pt(t) {
    const n = [];
    if (!Array.isArray(t)) throw new TypeError("Expected find and replace tuple or list of tuples");
    const e = !t[0] || Array.isArray(t[0]) ? t : [t];
    let r = -1;
    for (; ++r < e.length;) {
        const l = e[r];
        n.push([Ot(l[0]), jt(l[1])])
    }
    return n
}

function Ot(t) {
    return typeof t == "string" ? new RegExp(Et(t), "g") : t
}

function jt(t) {
    return typeof t == "function" ? t : function() {
        return t
    }
}
const q = "phrasing",
    U = ["autolink", "link", "image", "label"];

function _t() {
    return {
        transforms: [Ut],
        enter: {
            literalAutolink: Wt,
            literalAutolinkEmail: G,
            literalAutolinkHttp: G,
            literalAutolinkWww: G
        },
        exit: {
            literalAutolink: qt,
            literalAutolinkEmail: Vt,
            literalAutolinkHttp: Bt,
            literalAutolinkWww: Ht
        }
    }
}

function vt() {
    return {
        unsafe: [{
            character: "@",
            before: "[+\\-.\\w]",
            after: "[\\-.\\w]",
            inConstruct: q,
            notInConstruct: U
        }, {
            character: ".",
            before: "[Ww]",
            after: "[\\-.\\w]",
            inConstruct: q,
            notInConstruct: U
        }, {
            character: ":",
            before: "[ps]",
            after: "\\/",
            inConstruct: q,
            notInConstruct: U
        }]
    }
}

function Wt(t) {
    this.enter({
        type: "link",
        title: null,
        url: "",
        children: []
    }, t)
}

function G(t) {
    this.config.enter.autolinkProtocol.call(this, t)
}

function Bt(t) {
    this.config.exit.autolinkProtocol.call(this, t)
}

function Ht(t) {
    this.config.exit.data.call(this, t);
    const n = this.stack[this.stack.length - 1];
    I(n.type === "link"), n.url = "http://" + this.sliceSerialize(t)
}

function Vt(t) {
    this.config.exit.autolinkEmail.call(this, t)
}

function qt(t) {
    this.exit(t)
}

function Ut(t) {
    It(t, [
        [/(https?:\/\/|www(?=\.))([-.\w]+)([^ \t\r\n]*)/gi, Gt],
        [/([-.\w+]+)@([-\w]+(?:\.[-\w]+)+)/g, $t]
    ], {
        ignore: ["link", "linkReference"]
    })
}

function Gt(t, n, e, r, l) {
    let a = "";
    if (!st(l) || (/^w/i.test(n) && (e = n + e, n = "", a = "http://"), !Nt(e))) return !1;
    const i = Zt(e + r);
    if (!i[0]) return !1;
    const u = {
        type: "link",
        title: null,
        url: a + n + i[0],
        children: [{
            type: "text",
            value: n + i[0]
        }]
    };
    return i[1] ? [u, {
        type: "text",
        value: i[1]
    }] : u
}

function $t(t, n, e, r) {
    return !st(r, !0) || /[-\d_]$/.test(e) ? !1 : {
        type: "link",
        title: null,
        url: "mailto:" + n + "@" + e,
        children: [{
            type: "text",
            value: n + "@" + e
        }]
    }
}

function Nt(t) {
    const n = t.split(".");
    return !(n.length < 2 || n[n.length - 1] && (/_/.test(n[n.length - 1]) || !/[a-zA-Z\d]/.test(n[n.length - 1])) || n[n.length - 2] && (/_/.test(n[n.length - 2]) || !/[a-zA-Z\d]/.test(n[n.length - 2])))
}

function Zt(t) {
    const n = /[!"&'),.:;<>?\]}]+$/.exec(t);
    if (!n) return [t, void 0];
    t = t.slice(0, n.index);
    let e = n[0],
        r = e.indexOf(")");
    const l = it(t, "(");
    let a = it(t, ")");
    for (; r !== -1 && l > a;) t += e.slice(0, r + 1), e = e.slice(r + 1), r = e.indexOf(")"), a++;
    return [t, e]
}

function st(t, n) {
    const e = t.input.charCodeAt(t.index - 1);
    return (t.index === 0 || E(e) || Z(e)) && (!n || e !== 47)
}
ft.peek = le;

function Qt() {
    return {
        enter: {
            gfmFootnoteDefinition: Xt,
            gfmFootnoteDefinitionLabelString: Yt,
            gfmFootnoteCall: ee,
            gfmFootnoteCallString: ne
        },
        exit: {
            gfmFootnoteDefinition: te,
            gfmFootnoteDefinitionLabelString: Kt,
            gfmFootnoteCall: re,
            gfmFootnoteCallString: ie
        }
    }
}

function Jt() {
    return {
        unsafe: [{
            character: "[",
            inConstruct: ["phrasing", "label", "reference"]
        }],
        handlers: {
            footnoteDefinition: ae,
            footnoteReference: ft
        }
    }
}

function Xt(t) {
    this.enter({
        type: "footnoteDefinition",
        identifier: "",
        label: "",
        children: []
    }, t)
}

function Yt() {
    this.buffer()
}

function Kt(t) {
    const n = this.resume(),
        e = this.stack[this.stack.length - 1];
    I(e.type === "footnoteDefinition"), e.label = n, e.identifier = v(this.sliceSerialize(t)).toLowerCase()
}

function te(t) {
    this.exit(t)
}

function ee(t) {
    this.enter({
        type: "footnoteReference",
        identifier: "",
        label: ""
    }, t)
}

function ne() {
    this.buffer()
}

function ie(t) {
    const n = this.resume(),
        e = this.stack[this.stack.length - 1];
    I(e.type === "footnoteReference"), e.label = n, e.identifier = v(this.sliceSerialize(t)).toLowerCase()
}

function re(t) {
    this.exit(t)
}

function ft(t, n, e, r) {
    const l = e.createTracker(r);
    let a = l.move("[^");
    const i = e.enter("footnoteReference"),
        u = e.enter("reference");
    return a += l.move(e.safe(e.associationId(t), O(L({}, l.current()), {
        before: a,
        after: "]"
    }))), u(), i(), a += l.move("]"), a
}

function le() {
    return "["
}

function ae(t, n, e, r) {
    const l = e.createTracker(r);
    let a = l.move("[^");
    const i = e.enter("footnoteDefinition"),
        u = e.enter("label");
    return a += l.move(e.safe(e.associationId(t), O(L({}, l.current()), {
        before: a,
        after: "]"
    }))), u(), a += l.move("]:" + (t.children && t.children.length > 0 ? " " : "")), l.shift(4), a += l.move(e.indentLines(e.containerFlow(t, l.current()), oe)), i(), a
}

function oe(t, n, e) {
    return n === 0 ? t : (e ? "" : "    ") + t
}
const ue = ["autolink", "destinationLiteral", "destinationRaw", "reference", "titleQuote", "titleApostrophe"];
ht.peek = ge;

function se() {
    return {
        canContainEols: ["delete"],
        enter: {
            strikethrough: he
        },
        exit: {
            strikethrough: ce
        }
    }
}

function fe() {
    return {
        unsafe: [{
            character: "~",
            inConstruct: "phrasing",
            notInConstruct: ue
        }],
        handlers: {
            delete: ht
        }
    }
}

function he(t) {
    this.enter({
        type: "delete",
        children: []
    }, t)
}

function ce(t) {
    this.exit(t)
}

function ht(t, n, e, r) {
    const l = e.createTracker(r),
        a = e.enter("strikethrough");
    let i = l.move("~~");
    return i += e.containerPhrasing(t, O(L({}, l.current()), {
        before: i,
        after: "~"
    })), i += l.move("~~"), a(), i
}

function ge() {
    return "~"
}

function me(t, n = {}) {
    const e = (n.align || []).concat(),
        r = n.stringLength || ke,
        l = [],
        a = [],
        i = [],
        u = [];
    let f = 0,
        c = -1;
    for (; ++c < t.length;) {
        const h = [],
            b = [];
        let p = -1;
        for (t[c].length > f && (f = t[c].length); ++p < t[c].length;) {
            const w = pe(t[c][p]);
            if (n.alignDelimiters !== !1) {
                const x = r(w);
                b[p] = x, (u[p] === void 0 || x > u[p]) && (u[p] = x)
            }
            h.push(w)
        }
        a[c] = h, i[c] = b
    }
    let g = -1;
    if (typeof e == "object" && "length" in e)
        for (; ++g < f;) l[g] = rt(e[g]);
    else {
        const h = rt(e);
        for (; ++g < f;) l[g] = h
    }
    g = -1;
    const o = [],
        m = [];
    for (; ++g < f;) {
        const h = l[g];
        let b = "",
            p = "";
        h === 99 ? (b = ":", p = ":") : h === 108 ? b = ":" : h === 114 && (p = ":");
        let w = n.alignDelimiters === !1 ? 1 : Math.max(1, u[g] - b.length - p.length);
        const x = b + "-".repeat(w) + p;
        n.alignDelimiters !== !1 && (w = b.length + w + p.length, w > u[g] && (u[g] = w), m[g] = w), o[g] = x
    }
    a.splice(1, 0, o), i.splice(1, 0, m), c = -1;
    const k = [];
    for (; ++c < a.length;) {
        const h = a[c],
            b = i[c];
        g = -1;
        const p = [];
        for (; ++g < f;) {
            const w = h[g] || "";
            let x = "",
                y = "";
            if (n.alignDelimiters !== !1) {
                const d = u[g] - (b[g] || 0),
                    A = l[g];
                A === 114 ? x = " ".repeat(d) : A === 99 ? d % 2 ? (x = " ".repeat(d / 2 + .5), y = " ".repeat(d / 2 - .5)) : (x = " ".repeat(d / 2), y = x) : y = " ".repeat(d)
            }
            n.delimiterStart !== !1 && !g && p.push("|"), n.padding !== !1 && !(n.alignDelimiters === !1 && w === "") && (n.delimiterStart !== !1 || g) && p.push(" "), n.alignDelimiters !== !1 && p.push(x), p.push(w), n.alignDelimiters !== !1 && p.push(y), n.padding !== !1 && p.push(" "), (n.delimiterEnd !== !1 || g !== f - 1) && p.push("|")
        }
        k.push(n.delimiterEnd === !1 ? p.join("").replace(/ +$/, "") : p.join(""))
    }
    return k.join("\n")
}

function pe(t) {
    return t == null ? "" : String(t)
}

function ke(t) {
    return t.length
}

function rt(t) {
    const n = typeof t == "string" ? t.codePointAt(0) : 0;
    return n === 67 || n === 99 ? 99 : n === 76 || n === 108 ? 108 : n === 82 || n === 114 ? 114 : 0
}

function be() {
    return {
        enter: {
            table: we,
            tableData: lt,
            tableHeader: lt,
            tableRow: ye
        },
        exit: {
            codeText: de,
            table: xe,
            tableData: $,
            tableHeader: $,
            tableRow: $
        }
    }
}

function we(t) {
    const n = t._align;
    this.enter({
        type: "table",
        align: n.map(function(e) {
            return e === "none" ? null : e
        }),
        children: []
    }, t), this.data.inTable = !0
}

function xe(t) {
    this.exit(t), this.data.inTable = void 0
}

function ye(t) {
    this.enter({
        type: "tableRow",
        children: []
    }, t)
}

function $(t) {
    this.exit(t)
}

function lt(t) {
    this.enter({
        type: "tableCell",
        children: []
    }, t)
}

function de(t) {
    let n = this.resume();
    this.data.inTable && (n = n.replace(/\\([\\|])/g, Ce));
    const e = this.stack[this.stack.length - 1];
    I(e.type === "inlineCode"), e.value = n, this.exit(t)
}

function Ce(t, n) {
    return n === "|" ? n : t
}

function De(t) {
    const n = t || {},
        e = n.tableCellPadding,
        r = n.tablePipeAlign,
        l = n.stringLength,
        a = e ? " " : "|";
    return {
        unsafe: [{
            character: "\r",
            inConstruct: "tableCell"
        }, {
            character: "\n",
            inConstruct: "tableCell"
        }, {
            atBreak: !0,
            character: "|",
            after: "[	 :-]"
        }, {
            character: "|",
            inConstruct: "tableCell"
        }, {
            atBreak: !0,
            character: ":",
            after: "-"
        }, {
            atBreak: !0,
            character: "-",
            after: "[:|-]"
        }],
        handlers: {
            inlineCode: m,
            table: i,
            tableCell: f,
            tableRow: u
        }
    };

    function i(k, h, b, p) {
        return c(g(k, b, p), k.align)
    }

    function u(k, h, b, p) {
        const w = o(k, b, p),
            x = c([w]);
        return x.slice(0, x.indexOf("\n"))
    }

    function f(k, h, b, p) {
        const w = b.enter("tableCell"),
            x = b.enter("phrasing"),
            y = b.containerPhrasing(k, O(L({}, p), {
                before: a,
                after: a
            }));
        return x(), w(), y
    }

    function c(k, h) {
        return me(k, {
            align: h,
            alignDelimiters: r,
            padding: e,
            stringLength: l
        })
    }

    function g(k, h, b) {
        const p = k.children;
        let w = -1;
        const x = [],
            y = h.enter("table");
        for (; ++w < p.length;) x[w] = o(p[w], h, b);
        return y(), x
    }

    function o(k, h, b) {
        const p = k.children;
        let w = -1;
        const x = [],
            y = h.enter("tableRow");
        for (; ++w < p.length;) x[w] = f(p[w], k, h, b);
        return y(), x
    }

    function m(k, h, b) {
        let p = ut.inlineCode(k, h, b);
        return b.stack.includes("tableCell") && (p = p.replace(/\|/g, "\\$&")), p
    }
}

function Ae() {
    return {
        exit: {
            taskListCheckValueChecked: at,
            taskListCheckValueUnchecked: at,
            paragraph: Se
        }
    }
}

function Fe() {
    return {
        unsafe: [{
            atBreak: !0,
            character: "-",
            after: "[:|-]"
        }],
        handlers: {
            listItem: ze
        }
    }
}

function at(t) {
    const n = this.stack[this.stack.length - 2];
    I(n.type === "listItem"), n.checked = t.type === "taskListCheckValueChecked"
}

function Se(t) {
    const n = this.stack[this.stack.length - 2];
    if (n && n.type === "listItem" && typeof n.checked == "boolean") {
        const e = this.stack[this.stack.length - 1];
        I(e.type === "paragraph");
        const r = e.children[0];
        if (r && r.type === "text") {
            const l = n.children;
            let a = -1,
                i;
            for (; ++a < l.length;) {
                const u = l[a];
                if (u.type === "paragraph") {
                    i = u;
                    break
                }
            }
            i === e && (r.value = r.value.slice(1), r.value.length === 0 ? e.children.shift() : e.position && r.position && typeof r.position.start.offset == "number" && (r.position.start.column++, r.position.start.offset++, e.position.start = Object.assign({}, r.position.start)))
        }
    }
    this.exit(t)
}

function ze(t, n, e, r) {
    const l = t.children[0],
        a = typeof t.checked == "boolean" && l && l.type === "paragraph",
        i = "[" + (t.checked ? "x" : " ") + "] ",
        u = e.createTracker(r);
    a && u.move(i);
    let f = ut.listItem(t, n, e, L(L({}, r), u.current()));
    return a && (f = f.replace(/^(?:[*+-]|\d+\.)([\r\n]| {1,3})/, c)), f;

    function c(g) {
        return g + i
    }
}

function Le() {
    return [_t(), Qt(), se(), be(), Ae()]
}

function Te(t) {
    return {
        extensions: [vt(), Jt(), fe(), De(t), Fe()]
    }
}
const Me = {
        tokenize: je,
        partial: !0
    },
    ct = {
        tokenize: _e,
        partial: !0
    },
    gt = {
        tokenize: ve,
        partial: !0
    },
    mt = {
        tokenize: We,
        partial: !0
    },
    Re = {
        tokenize: Be,
        partial: !0
    },
    pt = {
        tokenize: Pe,
        previous: bt
    },
    kt = {
        tokenize: Oe,
        previous: wt
    },
    S = {
        tokenize: Ie,
        previous: xt
    },
    F = {};

function Ee() {
    return {
        text: F
    }
}
let T = 48;
for (; T < 123;) F[T] = S, T++, T === 58 ? T = 65 : T === 91 && (T = 97);
F[43] = S;
F[45] = S;
F[46] = S;
F[95] = S;
F[72] = [S, kt];
F[104] = [S, kt];
F[87] = [S, pt];
F[119] = [S, pt];

function Ie(t, n, e) {
    const r = this;
    let l, a;
    return i;

    function i(o) {
        return !N(o) || !xt.call(r, r.previous) || J(r.events) ? e(o) : (t.enter("literalAutolink"), t.enter("literalAutolinkEmail"), u(o))
    }

    function u(o) {
        return N(o) ? (t.consume(o), u) : o === 64 ? (t.consume(o), f) : e(o)
    }

    function f(o) {
        return o === 46 ? t.check(Re, g, c)(o) : o === 45 || o === 95 || Q(o) ? (a = !0, t.consume(o), f) : g(o)
    }

    function c(o) {
        return t.consume(o), l = !0, f
    }

    function g(o) {
        return a && l && _(r.previous) ? (t.exit("literalAutolinkEmail"), t.exit("literalAutolink"), n(o)) : e(o)
    }
}

function Pe(t, n, e) {
    const r = this;
    return l;

    function l(i) {
        return i !== 87 && i !== 119 || !bt.call(r, r.previous) || J(r.events) ? e(i) : (t.enter("literalAutolink"), t.enter("literalAutolinkWww"), t.check(Me, t.attempt(ct, t.attempt(gt, a), e), e)(i))
    }

    function a(i) {
        return t.exit("literalAutolinkWww"), t.exit("literalAutolink"), n(i)
    }
}

function Oe(t, n, e) {
    const r = this;
    let l = "",
        a = !1;
    return i;

    function i(o) {
        return (o === 72 || o === 104) && wt.call(r, r.previous) && !J(r.events) ? (t.enter("literalAutolink"), t.enter("literalAutolinkHttp"), l += String.fromCodePoint(o), t.consume(o), u) : e(o)
    }

    function u(o) {
        if (_(o) && l.length < 5) return l += String.fromCodePoint(o), t.consume(o), u;
        if (o === 58) {
            const m = l.toLowerCase();
            if (m === "http" || m === "https") return t.consume(o), f
        }
        return e(o)
    }

    function f(o) {
        return o === 47 ? (t.consume(o), a ? c : (a = !0, f)) : e(o)
    }

    function c(o) {
        return o === null || St(o) || C(o) || E(o) || Z(o) ? e(o) : t.attempt(ct, t.attempt(gt, g), e)(o)
    }

    function g(o) {
        return t.exit("literalAutolinkHttp"), t.exit("literalAutolink"), n(o)
    }
}

function je(t, n, e) {
    let r = 0;
    return l;

    function l(i) {
        return (i === 87 || i === 119) && r < 3 ? (r++, t.consume(i), l) : i === 46 && r === 3 ? (t.consume(i), a) : e(i)
    }

    function a(i) {
        return i === null ? e(i) : n(i)
    }
}

function _e(t, n, e) {
    let r, l, a;
    return i;

    function i(c) {
        return c === 46 || c === 95 ? t.check(mt, f, u)(c) : c === null || C(c) || E(c) || c !== 45 && Z(c) ? f(c) : (a = !0, t.consume(c), i)
    }

    function u(c) {
        return c === 95 ? r = !0 : (l = r, r = void 0), t.consume(c), i
    }

    function f(c) {
        return l || r || !a ? e(c) : n(c)
    }
}

function ve(t, n) {
    let e = 0,
        r = 0;
    return l;

    function l(i) {
        return i === 40 ? (e++, t.consume(i), l) : i === 41 && r < e ? a(i) : i === 33 || i === 34 || i === 38 || i === 39 || i === 41 || i === 42 || i === 44 || i === 46 || i === 58 || i === 59 || i === 60 || i === 63 || i === 93 || i === 95 || i === 126 ? t.check(mt, n, a)(i) : i === null || C(i) || E(i) ? n(i) : (t.consume(i), l)
    }

    function a(i) {
        return i === 41 && r++, t.consume(i), l
    }
}

function We(t, n, e) {
    return r;

    function r(u) {
        return u === 33 || u === 34 || u === 39 || u === 41 || u === 42 || u === 44 || u === 46 || u === 58 || u === 59 || u === 63 || u === 95 || u === 126 ? (t.consume(u), r) : u === 38 ? (t.consume(u), a) : u === 93 ? (t.consume(u), l) : u === 60 || u === null || C(u) || E(u) ? n(u) : e(u)
    }

    function l(u) {
        return u === null || u === 40 || u === 91 || C(u) || E(u) ? n(u) : r(u)
    }

    function a(u) {
        return _(u) ? i(u) : e(u)
    }

    function i(u) {
        return u === 59 ? (t.consume(u), r) : _(u) ? (t.consume(u), i) : e(u)
    }
}

function Be(t, n, e) {
    return r;

    function r(a) {
        return t.consume(a), l
    }

    function l(a) {
        return Q(a) ? e(a) : n(a)
    }
}

function bt(t) {
    return t === null || t === 40 || t === 42 || t === 95 || t === 91 || t === 93 || t === 126 || C(t)
}

function wt(t) {
    return !_(t)
}

function xt(t) {
    return !(t === 47 || N(t))
}

function N(t) {
    return t === 43 || t === 45 || t === 46 || t === 95 || Q(t)
}

function J(t) {
    let n = t.length,
        e = !1;
    for (; n--;) {
        const r = t[n][1];
        if ((r.type === "labelLink" || r.type === "labelImage") && !r._balanced) {
            e = !0;
            break
        }
        if (r._gfmAutolinkLiteralWalkedInto) {
            e = !1;
            break
        }
    }
    return t.length > 0 && !e && (t[t.length - 1][1]._gfmAutolinkLiteralWalkedInto = !0), e
}
const He = {
    tokenize: Qe,
    partial: !0
};

function Ve() {
    return {
        document: {
            91: {
                tokenize: $e,
                continuation: {
                    tokenize: Ne
                },
                exit: Ze
            }
        },
        text: {
            91: {
                tokenize: Ge
            },
            93: {
                add: "after",
                tokenize: qe,
                resolveTo: Ue
            }
        }
    }
}

function qe(t, n, e) {
    const r = this;
    let l = r.events.length;
    const a = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
    let i;
    for (; l--;) {
        const f = r.events[l][1];
        if (f.type === "labelImage") {
            i = f;
            break
        }
        if (f.type === "gfmFootnoteCall" || f.type === "labelLink" || f.type === "label" || f.type === "image" || f.type === "link") break
    }
    return u;

    function u(f) {
        if (!i || !i._balanced) return e(f);
        const c = v(r.sliceSerialize({
            start: i.end,
            end: r.now()
        }));
        return c.codePointAt(0) !== 94 || !a.includes(c.slice(1)) ? e(f) : (t.enter("gfmFootnoteCallLabelMarker"), t.consume(f), t.exit("gfmFootnoteCallLabelMarker"), n(f))
    }
}

function Ue(t, n) {
    let e = t.length;
    for (; e--;)
        if (t[e][1].type === "labelImage" && t[e][0] === "enter") {
            t[e][1];
            break
        }
    t[e + 1][1].type = "data", t[e + 3][1].type = "gfmFootnoteCallLabelMarker";
    const r = {
            type: "gfmFootnoteCall",
            start: Object.assign({}, t[e + 3][1].start),
            end: Object.assign({}, t[t.length - 1][1].end)
        },
        l = {
            type: "gfmFootnoteCallMarker",
            start: Object.assign({}, t[e + 3][1].end),
            end: Object.assign({}, t[e + 3][1].end)
        };
    l.end.column++, l.end.offset++, l.end._bufferIndex++;
    const a = {
            type: "gfmFootnoteCallString",
            start: Object.assign({}, l.end),
            end: Object.assign({}, t[t.length - 1][1].start)
        },
        i = {
            type: "chunkString",
            contentType: "string",
            start: Object.assign({}, a.start),
            end: Object.assign({}, a.end)
        },
        u = [t[e + 1], t[e + 2],
            ["enter", r, n], t[e + 3], t[e + 4],
            ["enter", l, n],
            ["exit", l, n],
            ["enter", a, n],
            ["enter", i, n],
            ["exit", i, n],
            ["exit", a, n], t[t.length - 2], t[t.length - 1],
            ["exit", r, n]
        ];
    return t.splice(e, t.length - e + 1, ...u), t
}

function Ge(t, n, e) {
    const r = this,
        l = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
    let a = 0,
        i;
    return u;

    function u(o) {
        return t.enter("gfmFootnoteCall"), t.enter("gfmFootnoteCallLabelMarker"), t.consume(o), t.exit("gfmFootnoteCallLabelMarker"), f
    }

    function f(o) {
        return o !== 94 ? e(o) : (t.enter("gfmFootnoteCallMarker"), t.consume(o), t.exit("gfmFootnoteCallMarker"), t.enter("gfmFootnoteCallString"), t.enter("chunkString").contentType = "string", c)
    }

    function c(o) {
        if (a > 999 || o === 93 && !i || o === null || o === 91 || C(o)) return e(o);
        if (o === 93) {
            t.exit("chunkString");
            const m = t.exit("gfmFootnoteCallString");
            return l.includes(v(r.sliceSerialize(m))) ? (t.enter("gfmFootnoteCallLabelMarker"), t.consume(o), t.exit("gfmFootnoteCallLabelMarker"), t.exit("gfmFootnoteCall"), n) : e(o)
        }
        return C(o) || (i = !0), a++, t.consume(o), o === 92 ? g : c
    }

    function g(o) {
        return o === 91 || o === 92 || o === 93 ? (t.consume(o), a++, c) : c(o)
    }
}

function $e(t, n, e) {
    const r = this,
        l = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
    let a, i = 0,
        u;
    return f;

    function f(h) {
        return t.enter("gfmFootnoteDefinition")._container = !0, t.enter("gfmFootnoteDefinitionLabel"), t.enter("gfmFootnoteDefinitionLabelMarker"), t.consume(h), t.exit("gfmFootnoteDefinitionLabelMarker"), c
    }

    function c(h) {
        return h === 94 ? (t.enter("gfmFootnoteDefinitionMarker"), t.consume(h), t.exit("gfmFootnoteDefinitionMarker"), t.enter("gfmFootnoteDefinitionLabelString"), t.enter("chunkString").contentType = "string", g) : e(h)
    }

    function g(h) {
        if (i > 999 || h === 93 && !u || h === null || h === 91 || C(h)) return e(h);
        if (h === 93) {
            t.exit("chunkString");
            const b = t.exit("gfmFootnoteDefinitionLabelString");
            return a = v(r.sliceSerialize(b)), t.enter("gfmFootnoteDefinitionLabelMarker"), t.consume(h), t.exit("gfmFootnoteDefinitionLabelMarker"), t.exit("gfmFootnoteDefinitionLabel"), m
        }
        return C(h) || (u = !0), i++, t.consume(h), h === 92 ? o : g
    }

    function o(h) {
        return h === 91 || h === 92 || h === 93 ? (t.consume(h), i++, g) : g(h)
    }

    function m(h) {
        return h === 58 ? (t.enter("definitionMarker"), t.consume(h), t.exit("definitionMarker"), l.includes(a) || l.push(a), z(t, k, "gfmFootnoteDefinitionWhitespace")) : e(h)
    }

    function k(h) {
        return n(h)
    }
}

function Ne(t, n, e) {
    return t.check(zt, n, t.attempt(He, n, e))
}

function Ze(t) {
    t.exit("gfmFootnoteDefinition")
}

function Qe(t, n, e) {
    const r = this;
    return z(t, l, "gfmFootnoteDefinitionIndent", 5);

    function l(a) {
        const i = r.events[r.events.length - 1];
        return i && i[1].type === "gfmFootnoteDefinitionIndent" && i[2].sliceSerialize(i[1], !0).length === 4 ? n(a) : e(a)
    }
}

function Je(t) {
    let e = (t || {}).singleTilde;
    const r = {
        name: "strikethrough",
        tokenize: a,
        resolveAll: l
    };
    return e == null && (e = !0), {
        text: {
            126: r
        },
        insideSpan: {
            null: [r]
        },
        attentionMarkers: {
            null: [126]
        }
    };

    function l(i, u) {
        let f = -1;
        for (; ++f < i.length;)
            if (i[f][0] === "enter" && i[f][1].type === "strikethroughSequenceTemporary" && i[f][1]._close) {
                let c = f;
                for (; c--;)
                    if (i[c][0] === "exit" && i[c][1].type === "strikethroughSequenceTemporary" && i[c][1]._open && i[f][1].end.offset - i[f][1].start.offset === i[c][1].end.offset - i[c][1].start.offset) {
                        i[f][1].type = "strikethroughSequence", i[c][1].type = "strikethroughSequence";
                        const g = {
                                type: "strikethrough",
                                start: Object.assign({}, i[c][1].start),
                                end: Object.assign({}, i[f][1].end)
                            },
                            o = {
                                type: "strikethroughText",
                                start: Object.assign({}, i[c][1].end),
                                end: Object.assign({}, i[f][1].start)
                            },
                            m = [
                                ["enter", g, u],
                                ["enter", i[c][1], u],
                                ["exit", i[c][1], u],
                                ["enter", o, u]
                            ],
                            k = u.parser.constructs.insideSpan.null;
                        k && V(m, m.length, 0, Lt(k, i.slice(c + 1, f), u)), V(m, m.length, 0, [
                            ["exit", o, u],
                            ["enter", i[f][1], u],
                            ["exit", i[f][1], u],
                            ["exit", g, u]
                        ]), V(i, c - 1, f - c + 3, m), f = c + m.length - 2;
                        break
                    }
            }
        for (f = -1; ++f < i.length;) i[f][1].type === "strikethroughSequenceTemporary" && (i[f][1].type = "data");
        return i
    }

    function a(i, u, f) {
        const c = this.previous,
            g = this.events;
        let o = 0;
        return m;

        function m(h) {
            return c === 126 && g[g.length - 1][1].type !== "characterEscape" ? f(h) : (i.enter("strikethroughSequenceTemporary"), k(h))
        }

        function k(h) {
            const b = nt(c);
            if (h === 126) return o > 1 ? f(h) : (i.consume(h), o++, k);
            if (o < 2 && !e) return f(h);
            const p = i.exit("strikethroughSequenceTemporary"),
                w = nt(h);
            return p._open = !w || w === 2 && !!b, p._close = !b || b === 2 && !!w, u(h)
        }
    }
}
class Xe {
    constructor() {
        this.map = []
    }
    add(n, e, r) {
        Ye(this, n, e, r)
    }
    consume(n) {
        if (this.map.sort(function(a, i) {
                return a[0] - i[0]
            }), this.map.length === 0) return;
        let e = this.map.length;
        const r = [];
        for (; e > 0;) e -= 1, r.push(n.slice(this.map[e][0] + this.map[e][1]), this.map[e][2]), n.length = this.map[e][0];
        r.push([...n]), n.length = 0;
        let l = r.pop();
        for (; l;) n.push(...l), l = r.pop();
        this.map.length = 0
    }
}

function Ye(t, n, e, r) {
    let l = 0;
    if (!(e === 0 && r.length === 0)) {
        for (; l < t.map.length;) {
            if (t.map[l][0] === n) {
                t.map[l][1] += e, t.map[l][2].push(...r);
                return
            }
            l += 1
        }
        t.map.push([n, e, r])
    }
}

function Ke(t, n) {
    let e = !1;
    const r = [];
    for (; n < t.length;) {
        const l = t[n];
        if (e) {
            if (l[0] === "enter") l[1].type === "tableContent" && r.push(t[n + 1][1].type === "tableDelimiterMarker" ? "left" : "none");
            else if (l[1].type === "tableContent") {
                if (t[n - 1][1].type === "tableDelimiterMarker") {
                    const a = r.length - 1;
                    r[a] = r[a] === "left" ? "center" : "right"
                }
            } else if (l[1].type === "tableDelimiterRow") break
        } else l[0] === "enter" && l[1].type === "tableDelimiterRow" && (e = !0);
        n += 1
    }
    return r
}

function tn() {
    return {
        flow: {
            null: {
                tokenize: en,
                resolveAll: nn
            }
        }
    }
}

function en(t, n, e) {
    const r = this;
    let l = 0,
        a = 0,
        i;
    return u;

    function u(s) {
        let P = r.events.length - 1;
        for (; P > -1;) {
            const K = r.events[P][1].type;
            if (K === "lineEnding" || K === "linePrefix") P--;
            else break
        }
        const X = P > -1 ? r.events[P][1].type : null,
            Y = X === "tableHead" || X === "tableRow" ? D : f;
        return Y === D && r.parser.lazy[r.now().line] ? e(s) : Y(s)
    }

    function f(s) {
        return t.enter("tableHead"), t.enter("tableRow"), c(s)
    }

    function c(s) {
        return s === 124 || (i = !0, a += 1), g(s)
    }

    function g(s) {
        return s === null ? e(s) : j(s) ? a > 1 ? (a = 0, r.interrupt = !0, t.exit("tableRow"), t.enter("lineEnding"), t.consume(s), t.exit("lineEnding"), k) : e(s) : M(s) ? z(t, g, "whitespace")(s) : (a += 1, i && (i = !1, l += 1), s === 124 ? (t.enter("tableCellDivider"), t.consume(s), t.exit("tableCellDivider"), i = !0, g) : (t.enter("data"), o(s)))
    }

    function o(s) {
        return s === null || s === 124 || C(s) ? (t.exit("data"), g(s)) : (t.consume(s), s === 92 ? m : o)
    }

    function m(s) {
        return s === 92 || s === 124 ? (t.consume(s), o) : o(s)
    }

    function k(s) {
        return r.interrupt = !1, r.parser.lazy[r.now().line] ? e(s) : (t.enter("tableDelimiterRow"), i = !1, M(s) ? z(t, h, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(s) : h(s))
    }

    function h(s) {
        return s === 45 || s === 58 ? p(s) : s === 124 ? (i = !0, t.enter("tableCellDivider"), t.consume(s), t.exit("tableCellDivider"), b) : A(s)
    }

    function b(s) {
        return M(s) ? z(t, p, "whitespace")(s) : p(s)
    }

    function p(s) {
        return s === 58 ? (a += 1, i = !0, t.enter("tableDelimiterMarker"), t.consume(s), t.exit("tableDelimiterMarker"), w) : s === 45 ? (a += 1, w(s)) : s === null || j(s) ? d(s) : A(s)
    }

    function w(s) {
        return s === 45 ? (t.enter("tableDelimiterFiller"), x(s)) : A(s)
    }

    function x(s) {
        return s === 45 ? (t.consume(s), x) : s === 58 ? (i = !0, t.exit("tableDelimiterFiller"), t.enter("tableDelimiterMarker"), t.consume(s), t.exit("tableDelimiterMarker"), y) : (t.exit("tableDelimiterFiller"), y(s))
    }

    function y(s) {
        return M(s) ? z(t, d, "whitespace")(s) : d(s)
    }

    function d(s) {
        return s === 124 ? h(s) : s === null || j(s) ? !i || l !== a ? A(s) : (t.exit("tableDelimiterRow"), t.exit("tableHead"), n(s)) : A(s)
    }

    function A(s) {
        return e(s)
    }

    function D(s) {
        return t.enter("tableRow"), W(s)
    }

    function W(s) {
        return s === 124 ? (t.enter("tableCellDivider"), t.consume(s), t.exit("tableCellDivider"), W) : s === null || j(s) ? (t.exit("tableRow"), n(s)) : M(s) ? z(t, W, "whitespace")(s) : (t.enter("data"), B(s))
    }

    function B(s) {
        return s === null || s === 124 || C(s) ? (t.exit("data"), W(s)) : (t.consume(s), s === 92 ? yt : B)
    }

    function yt(s) {
        return s === 92 || s === 124 ? (t.consume(s), B) : B(s)
    }
}

function nn(t, n) {
    let e = -1,
        r = !0,
        l = 0,
        a = [0, 0, 0, 0],
        i = [0, 0, 0, 0],
        u = !1,
        f = 0,
        c, g, o;
    const m = new Xe;
    for (; ++e < t.length;) {
        const k = t[e],
            h = k[1];
        k[0] === "enter" ? h.type === "tableHead" ? (u = !1, f !== 0 && (ot(m, n, f, c, g), g = void 0, f = 0), c = {
            type: "table",
            start: Object.assign({}, h.start),
            end: Object.assign({}, h.end)
        }, m.add(e, 0, [
            ["enter", c, n]
        ])) : h.type === "tableRow" || h.type === "tableDelimiterRow" ? (r = !0, o = void 0, a = [0, 0, 0, 0], i = [0, e + 1, 0, 0], u && (u = !1, g = {
            type: "tableBody",
            start: Object.assign({}, h.start),
            end: Object.assign({}, h.end)
        }, m.add(e, 0, [
            ["enter", g, n]
        ])), l = h.type === "tableDelimiterRow" ? 2 : g ? 3 : 1) : l && (h.type === "data" || h.type === "tableDelimiterMarker" || h.type === "tableDelimiterFiller") ? (r = !1, i[2] === 0 && (a[1] !== 0 && (i[0] = i[1], o = H(m, n, a, l, void 0, o), a = [0, 0, 0, 0]), i[2] = e)) : h.type === "tableCellDivider" && (r ? r = !1 : (a[1] !== 0 && (i[0] = i[1], o = H(m, n, a, l, void 0, o)), a = i, i = [a[1], e, 0, 0])) : h.type === "tableHead" ? (u = !0, f = e) : h.type === "tableRow" || h.type === "tableDelimiterRow" ? (f = e, a[1] !== 0 ? (i[0] = i[1], o = H(m, n, a, l, e, o)) : i[1] !== 0 && (o = H(m, n, i, l, e, o)), l = 0) : l && (h.type === "data" || h.type === "tableDelimiterMarker" || h.type === "tableDelimiterFiller") && (i[3] = e)
    }
    for (f !== 0 && ot(m, n, f, c, g), m.consume(n.events), e = -1; ++e < n.events.length;) {
        const k = n.events[e];
        k[0] === "enter" && k[1].type === "table" && (k[1]._align = Ke(n.events, e))
    }
    return t
}

function H(t, n, e, r, l, a) {
    const i = r === 1 ? "tableHeader" : r === 2 ? "tableDelimiter" : "tableData",
        u = "tableContent";
    e[0] !== 0 && (a.end = Object.assign({}, R(n.events, e[0])), t.add(e[0], 0, [
        ["exit", a, n]
    ]));
    const f = R(n.events, e[1]);
    if (a = {
            type: i,
            start: Object.assign({}, f),
            end: Object.assign({}, f)
        }, t.add(e[1], 0, [
            ["enter", a, n]
        ]), e[2] !== 0) {
        const c = R(n.events, e[2]),
            g = R(n.events, e[3]),
            o = {
                type: u,
                start: Object.assign({}, c),
                end: Object.assign({}, g)
            };
        if (t.add(e[2], 0, [
                ["enter", o, n]
            ]), r !== 2) {
            const m = n.events[e[2]],
                k = n.events[e[3]];
            if (m[1].end = Object.assign({}, k[1].end), m[1].type = "chunkText", m[1].contentType = "text", e[3] > e[2] + 1) {
                const h = e[2] + 1,
                    b = e[3] - e[2] - 1;
                t.add(h, b, [])
            }
        }
        t.add(e[3] + 1, 0, [
            ["exit", o, n]
        ])
    }
    return l !== void 0 && (a.end = Object.assign({}, R(n.events, l)), t.add(l, 0, [
        ["exit", a, n]
    ]), a = void 0), a
}

function ot(t, n, e, r, l) {
    const a = [],
        i = R(n.events, e);
    l && (l.end = Object.assign({}, i), a.push(["exit", l, n])), r.end = Object.assign({}, i), a.push(["exit", r, n]), t.add(e + 1, 0, a)
}

function R(t, n) {
    const e = t[n],
        r = e[0] === "enter" ? "start" : "end";
    return e[1][r]
}
const rn = {
    tokenize: an
};

function ln() {
    return {
        text: {
            91: rn
        }
    }
}

function an(t, n, e) {
    const r = this;
    return l;

    function l(f) {
        return r.previous !== null || !r._gfmTasklistFirstContentOfListItem ? e(f) : (t.enter("taskListCheck"), t.enter("taskListCheckMarker"), t.consume(f), t.exit("taskListCheckMarker"), a)
    }

    function a(f) {
        return C(f) ? (t.enter("taskListCheckValueUnchecked"), t.consume(f), t.exit("taskListCheckValueUnchecked"), i) : f === 88 || f === 120 ? (t.enter("taskListCheckValueChecked"), t.consume(f), t.exit("taskListCheckValueChecked"), i) : e(f)
    }

    function i(f) {
        return f === 93 ? (t.enter("taskListCheckMarker"), t.consume(f), t.exit("taskListCheckMarker"), t.exit("taskListCheck"), u) : e(f)
    }

    function u(f) {
        return j(f) ? n(f) : M(f) ? t.check({
            tokenize: on
        }, n, e)(f) : e(f)
    }
}

function on(t, n, e) {
    return z(t, r, "whitespace");

    function r(l) {
        return l === null ? e(l) : n(l)
    }
}

function un(t) {
    return Tt([Ee(), Ve(), Je(t), tn(), ln()])
}
const sn = {};

function pn(t) {
    const n = this,
        e = t || sn,
        r = n.data(),
        l = r.micromarkExtensions || (r.micromarkExtensions = []),
        a = r.fromMarkdownExtensions || (r.fromMarkdownExtensions = []),
        i = r.toMarkdownExtensions || (r.toMarkdownExtensions = []);
    l.push(un(e)), a.push(Le()), i.push(Te(e))
}
export {
    it as c, It as f, pn as r
};
//# sourceMappingURL=b5s349mvbdzayaxi.js.map