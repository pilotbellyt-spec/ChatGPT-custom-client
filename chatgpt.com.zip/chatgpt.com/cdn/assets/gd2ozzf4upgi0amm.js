var I = Object.defineProperty,
    S = Object.defineProperties;
var D = Object.getOwnPropertyDescriptors;
var j = Object.getOwnPropertySymbols;
var L = Object.prototype.hasOwnProperty,
    R = Object.prototype.propertyIsEnumerable;
var w = (e, t, n) => t in e ? I(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : e[t] = n,
    C = (e, t) => {
        for (var n in t || (t = {})) L.call(t, n) && w(e, n, t[n]);
        if (j)
            for (var n of j(t)) R.call(t, n) && w(e, n, t[n]);
        return e
    },
    T = (e, t) => S(e, D(t));
import {
    e as y,
    j as a,
    f as U,
    b as A,
    r as h,
    q as P
} from "./fg33krlcm0qyi6yw.js";
import {
    go as q,
    c_ as J,
    gq as m,
    gc as $,
    gp as G,
    tG as H,
    e4 as f,
    _ as g,
    e2 as K,
    eL as X,
    bb as O,
    l as p
} from "./dykg4ktvbu3mhmdo.js";
import {
    iF as Q,
    iG as V
} from "./k15yxxoybkkir2ou.js";

function v({
    jupyterMessage: e
}) {
    const t = y(),
        {
            width: n,
            height: s
        } = e;
    if (e.image_payload != null) return a.jsx("img", {
        className: "my-1 max-h-full max-w-full object-contain",
        src: "data:image/png;base64,".concat(e.image_payload),
        alt: t.formatMessage(N.altText),
        width: n,
        height: s
    });
    if (e.image_url != null) {
        const o = q(e.image_url);
        return a.jsx(Z, {
            fileId: o,
            width: n,
            height: s
        })
    }
    return null
}
const W = 30 * 1e3,
    k = 100,
    _ = 1.5,
    z = Math.log(1 - W * (1 - _) / k) / Math.log(_);

function Y(e, t) {
    return P({
        queryKey: ["getFileDownloadLink", e],
        queryFn: () => G(e, void 0, t),
        staleTime: $,
        refetchInterval: n => {
            var r;
            const s = n.state.dataUpdateCount;
            return ((r = n.state.data) == null ? void 0 : r.status) === m.Success || s > z || n.state.status === m.Error ? !1 : Math.pow(_, s) * k
        }
    })
}

function Z({
    fileId: e,
    width: t,
    height: n
}) {
    const s = y(),
        o = !J(),
        {
            data: r,
            isLoading: u,
            refetch: l
        } = A(Y(e, o));
    return h.useEffect(() => {
        if ((r == null ? void 0 : r.status) === m.Success) {
            const c = new URL(r.download_url, location.toString()).searchParams.get("se");
            c != null && !u && new Date > new Date(c) && l()
        }
    }, [r, u, l]), (r == null ? void 0 : r.status) !== m.Success ? null : a.jsx("img", {
        src: r.download_url,
        className: "my-1 max-h-64 max-w-full object-contain sm:max-h-80",
        alt: s.formatMessage(N.altText),
        width: t,
        height: n
    })
}
const N = U({
    altText: {
        id: "CodeExecutionOutputImage.altText",
        defaultMessage: "Output image"
    }
});

function oe({
    FormattedText: e,
    message: t,
    codeRendererClassName: n,
    forceDarkMode: s,
    removeTopBorderRadius: o,
    showActionBar: r,
    codeContainerClassName: u
}) {
    const l = O() || s,
        d = B(t),
        c = h.useCallback(x => a.jsx(Q, T(C({}, x), {
            wrapperClassName: n,
            codeContainerClassName: u,
            removeTopBorderRadius: o,
            showActionBar: r
        })), [n, u, o, r]),
        i = h.useMemo(() => ({
            code: c
        }), [c]);
    return d == null ? null : a.jsx(V.Provider, {
        value: {
            isWithinDataAnalysisToolMessage: !0
        },
        children: a.jsx(e, {
            className: p("markdown prose dark:prose-invert w-full break-words", l ? "dark" : "light"),
            forceDarkMode: s,
            componentOverrides: i,
            children: d
        })
    })
}

function B(e) {
    var n, s, o, r, u, l, d, c;

    function t(i, x) {
        return "```".concat(x, "\n").concat(i, "\n```")
    }
    if (e.author.name === "python" && e.content.content_type === f.ExecutionOutput) return (s = (n = e.metadata) == null ? void 0 : n.aggregate_result) != null && s.code ? t((r = (o = e.metadata) == null ? void 0 : o.aggregate_result) == null ? void 0 : r.code, "python") : null;
    if (e.author.name === "container.exec" && e.author.role === K.Tool) return (l = (u = e.metadata) == null ? void 0 : u.container_citation) != null && l.source_cmd ? t((c = (d = e.metadata) == null ? void 0 : d.container_citation) == null ? void 0 : c.source_cmd, "bash") : null;
    if (e.content.content_type === "code") return t(e.content.text, "python");
    if (e.recipient === "python") {
        if (e.content.content_type !== "text") return g.addError("Unexpected content type for code message"), null;
        const i = e.content.parts;
        return i.length !== 1 || typeof i[0] != "string" ? (g.addError("Unexpected parts for code message"), null) : t(i[0], "python")
    }
    return X(3179801956, e.author.name) && e.content.content_type === f.ExecutionOutput ? t(e.content.text, "python") : (g.addAction("Unexpected code message format"), null)
}

function ue({
    message: e,
    showLabel: t = !0,
    wrapperClassName: n,
    codeContainerClassName: s,
    forceDarkMode: o
}) {
    var x;
    const r = y();
    if (e.content.content_type !== f.ExecutionOutput) return null;
    const u = (x = e.metadata) == null ? void 0 : x.aggregate_result;
    if (!u) return g.addError("Corrupt code execution result message"), null;
    const l = u.messages.filter(te),
        d = l.length > 0,
        c = u.final_expression_output != null,
        i = u.in_kernel_exception != null;
    return a.jsxs(a.Fragment, {
        children: [d && a.jsx(M, {
            forceDarkMode: o,
            label: t ? "STDOUT/STDERR" : null,
            wrapperClassName: n,
            output: l.map((b, F) => a.jsx("span", {
                className: b.stream_name === "stderr" ? "text-red-500" : "",
                children: b.text
            }, "".concat(F)))
        }), c && a.jsx(M, {
            forceDarkMode: o,
            wrapperClassName: n,
            codeContainerClassName: s,
            label: t ? r.formatMessage({
                id: "codeInterpreterMessage.resultLabel",
                defaultMessage: "Result"
            }) : null,
            output: u.final_expression_output
        }), i && a.jsx(ee, {
            traceback: u.in_kernel_exception.traceback.join("")
        })]
    })
}

function M({
    wrapperClassName: e,
    label: t,
    output: n,
    codeContainerClassName: s,
    forceDarkMode: o
}) {
    const r = O() || o;
    return a.jsxs("div", {
        className: p("bg-token-sidebar-surface-primary p-4 text-xs", "overflow-x-auto", e),
        children: [t && a.jsx("div", {
            className: "mb-1 text-gray-400",
            children: t
        }), a.jsx("div", {
            className: p("prose flex flex-col-reverse", r ? "text-white" : "text-black"),
            children: a.jsx("pre", {
                className: p("shrink-0 overflow-auto", s),
                children: n
            })
        })]
    })
}

function ee({
    traceback: e
}) {
    return a.jsx("div", {
        className: "overflow-auto border-t border-gray-500 bg-black text-white",
        children: a.jsx("div", {
            className: "border-s-4 border-red-500 p-2 text-xs",
            children: a.jsx("div", {
                className: "scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-700 flex max-h-64 flex-col-reverse",
                children: a.jsx("pre", {
                    className: "shrink-0",
                    children: e
                })
            })
        })
    })
}

function le({
    message: e,
    isCoT: t = !1
}) {
    var s;
    if (e.content.content_type !== f.ExecutionOutput) return null;
    const n = (s = e.metadata) == null ? void 0 : s.aggregate_result;
    return n ? t ? n.messages.filter(E).map((o, r) => a.jsx(v, {
        jupyterMessage: o
    }, r)) : a.jsx("div", {
        className: "flex flex-wrap gap-2",
        children: n.messages.filter(E).map((o, r) => a.jsx("div", {
            className: "max-h-64 items-start justify-start sm:max-h-80",
            children: a.jsx(v, {
                jupyterMessage: o
            })
        }, r))
    }) : (g.addError("Corrupt code execution result message"), null)
}

function te(e) {
    return e.message_type === "stream"
}

function E(e) {
    return e.message_type === "image" || "image_url" in e && H(e.image_url + "")
}

function ce(e) {
    var t, n, s;
    return (s = (n = (t = e.metadata) == null ? void 0 : t.aggregate_result) == null ? void 0 : n.messages.some(E)) != null ? s : !1
}
export {
    le as C, oe as a, ue as b, M as c, Z as d, Y as e, v as f, B as g, ce as h, E as i
};
//# sourceMappingURL=gd2ozzf4upgi0amm.js.map