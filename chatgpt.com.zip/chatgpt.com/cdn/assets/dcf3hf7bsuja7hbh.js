const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/h1actw4u04fjw3sy.js", "assets/fg33krlcm0qyi6yw.js", "assets/k15yxxoybkkir2ou.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/conversation-small-332fs9rk.css", "assets/ia7x8vymukd9wnos.js", "assets/s8d7t6m9lmrag91y.js", "assets/fz8xw1971c2kf2eb.js", "assets/ftef8970ba1zoykr.js", "assets/iiok29s29bpdre61.js", "assets/k253gzle9qy7mdll.js", "assets/nm0so544a95lw6u3.js", "assets/cu0e6szsqsyduwov.js", "assets/enojslb0kkkm419z.js", "assets/e9kbgh7j5o6g3dr6.js", "assets/ebc4iyfg14nu1gw4.js", "assets/gy1lpvuoewmzh42c.js", "assets/jed1ux7qibe55pmj.js", "assets/h1em0bjkpkjv8ykw.js", "assets/nfccle6oyncifphl.js", "assets/hu1bt0oauegdhua6.js"]))) => i.map(i => d[i]);
import {
    h as kA,
    n as fA,
    i as SA,
    r as a,
    j as s,
    e as sA,
    _ as VA
} from "./fg33krlcm0qyi6yw.js";
import {
    D as MA
} from "./cu0e6szsqsyduwov.js";
import {
    c_ as bA,
    o7 as wA,
    mv as RA,
    B as xA,
    b as nA,
    oe as P,
    o4 as ZA,
    bv as v,
    bg as M,
    l as DA,
    bb as TA,
    o as vA,
    k_ as YA,
    T as jA,
    y3 as GA,
    bh as JA
} from "./dykg4ktvbu3mhmdo.js";
import {
    S as iA,
    i as OA,
    m as XA,
    u as yA,
    C as FA,
    a as WA,
    V as qA,
    b as LA,
    c as UA
} from "./s8d7t6m9lmrag91y.js";
import {
    jN as NA,
    nE as b,
    jf as KA,
    jg as HA,
    eB as zA,
    uQ as L,
    uR as U,
    uS as w,
    uT as PA,
    sH as k,
    rj as cA,
    jE as _A
} from "./k15yxxoybkkir2ou.js";
import {
    a as O,
    A as N,
    b as D
} from "./fz8xw1971c2kf2eb.js";
import {
    u as $A,
    s as Ae,
    a as ee,
    b as te,
    c as oe,
    d as ae,
    v as se,
    B as ne,
    n as ie,
    e as ce,
    f as re,
    V as le
} from "./kdyw5bvpba4cf5f0.js";
import {
    B as rA,
    G as de,
    u as _
} from "./dapgo43htqk76ir6.js";
import {
    C as Z
} from "./ftef8970ba1zoykr.js";
import "./iiok29s29bpdre61.js";
import "./k253gzle9qy7mdll.js";
import "./nm0so544a95lw6u3.js";
import "./enojslb0kkkm419z.js";
import "./e9kbgh7j5o6g3dr6.js";
import "./ebc4iyfg14nu1gw4.js";
import "./gy1lpvuoewmzh42c.js";
import "./jed1ux7qibe55pmj.js";
import "./h1em0bjkpkjv8ykw.js";
import "./nfccle6oyncifphl.js";
import "./hu1bt0oauegdhua6.js";
var F, $;

function me() {
    return $ || ($ = 1, F = {
        webm: "data:video/webm;base64,GkXfowEAAAAAAAAfQoaBAUL3gQFC8oEEQvOBCEKChHdlYm1Ch4EEQoWBAhhTgGcBAAAAAAAVkhFNm3RALE27i1OrhBVJqWZTrIHfTbuMU6uEFlSua1OsggEwTbuMU6uEHFO7a1OsghV17AEAAAAAAACkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVSalmAQAAAAAAAEUq17GDD0JATYCNTGF2ZjU1LjMzLjEwMFdBjUxhdmY1NS4zMy4xMDBzpJBlrrXf3DCDVB8KcgbMpcr+RImIQJBgAAAAAAAWVK5rAQAAAAAAD++uAQAAAAAAADLXgQFzxYEBnIEAIrWcg3VuZIaFVl9WUDiDgQEj44OEAmJaAOABAAAAAAAABrCBsLqBkK4BAAAAAAAPq9eBAnPFgQKcgQAitZyDdW5khohBX1ZPUkJJU4OBAuEBAAAAAAAAEZ+BArWIQOdwAAAAAABiZIEgY6JPbwIeVgF2b3JiaXMAAAAAAoC7AAAAAAAAgLUBAAAAAAC4AQN2b3JiaXMtAAAAWGlwaC5PcmcgbGliVm9yYmlzIEkgMjAxMDExMDEgKFNjaGF1ZmVudWdnZXQpAQAAABUAAABlbmNvZGVyPUxhdmM1NS41Mi4xMDIBBXZvcmJpcyVCQ1YBAEAAACRzGCpGpXMWhBAaQlAZ4xxCzmvsGUJMEYIcMkxbyyVzkCGkoEKIWyiB0JBVAABAAACHQXgUhIpBCCGEJT1YkoMnPQghhIg5eBSEaUEIIYQQQgghhBBCCCGERTlokoMnQQgdhOMwOAyD5Tj4HIRFOVgQgydB6CCED0K4moOsOQghhCQ1SFCDBjnoHITCLCiKgsQwuBaEBDUojILkMMjUgwtCiJqDSTX4GoRnQXgWhGlBCCGEJEFIkIMGQcgYhEZBWJKDBjm4FITLQagahCo5CB+EIDRkFQCQAACgoiiKoigKEBqyCgDIAAAQQFEUx3EcyZEcybEcCwgNWQUAAAEACAAAoEiKpEiO5EiSJFmSJVmSJVmS5omqLMuyLMuyLMsyEBqyCgBIAABQUQxFcRQHCA1ZBQBkAAAIoDiKpViKpWiK54iOCISGrAIAgAAABAAAEDRDUzxHlETPVFXXtm3btm3btm3btm3btm1blmUZCA1ZBQBAAAAQ0mlmqQaIMAMZBkJDVgEACAAAgBGKMMSA0JBVAABAAACAGEoOogmtOd+c46BZDppKsTkdnEi1eZKbirk555xzzsnmnDHOOeecopxZDJoJrTnnnMSgWQqaCa0555wnsXnQmiqtOeeccc7pYJwRxjnnnCateZCajbU555wFrWmOmkuxOeecSLl5UptLtTnnnHPOOeecc84555zqxekcnBPOOeecqL25lpvQxTnnnE/G6d6cEM4555xzzjnnnHPOOeecIDRkFQAABABAEIaNYdwpCNLnaCBGEWIaMulB9+gwCRqDnELq0ehopJQ6CCWVcVJKJwgNWQUAAAIAQAghhRRSSCGFFFJIIYUUYoghhhhyyimnoIJKKqmooowyyyyzzDLLLLPMOuyssw47DDHEEEMrrcRSU2011lhr7jnnmoO0VlprrbVSSimllFIKQkNWAQAgAAAEQgYZZJBRSCGFFGKIKaeccgoqqIDQkFUAACAAgAAAAABP8hzRER3RER3RER3RER3R8RzPESVREiVREi3TMjXTU0VVdWXXlnVZt31b2IVd933d933d+HVhWJZlWZZlWZZlWZZlWZZlWZYgNGQVAAACAAAghBBCSCGFFFJIKcYYc8w56CSUEAgNWQUAAAIACAAAAHAUR3EcyZEcSbIkS9IkzdIsT/M0TxM9URRF0zRV0RVdUTdtUTZl0zVdUzZdVVZtV5ZtW7Z125dl2/d93/d93/d93/d93/d9XQdCQ1YBABIAADqSIymSIimS4ziOJElAaMgqAEAGAEAAAIriKI7jOJIkSZIlaZJneZaomZrpmZ4qqkBoyCoAABAAQAAAAAAAAIqmeIqpeIqoeI7oiJJomZaoqZoryqbsuq7ruq7ruq7ruq7ruq7ruq7ruq7ruq7ruq7ruq7ruq7ruq4LhIasAgAkAAB0JEdyJEdSJEVSJEdygNCQVQCADACAAAAcwzEkRXIsy9I0T/M0TxM90RM901NFV3SB0JBVAAAgAIAAAAAAAAAMybAUy9EcTRIl1VItVVMt1VJF1VNVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVN0zRNEwgNWQkAkAEAkBBTLS3GmgmLJGLSaqugYwxS7KWxSCpntbfKMYUYtV4ah5RREHupJGOKQcwtpNApJq3WVEKFFKSYYyoVUg5SIDRkhQAQmgHgcBxAsixAsiwAAAAAAAAAkDQN0DwPsDQPAAAAAAAAACRNAyxPAzTPAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABA0jRA8zxA8zwAAAAAAAAA0DwP8DwR8EQRAAAAAAAAACzPAzTRAzxRBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABA0jRA8zxA8zwAAAAAAAAAsDwP8EQR0DwRAAAAAAAAACzPAzxRBDzRAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAEOAAABBgIRQasiIAiBMAcEgSJAmSBM0DSJYFTYOmwTQBkmVB06BpME0AAAAAAAAAAAAAJE2DpkHTIIoASdOgadA0iCIAAAAAAAAAAAAAkqZB06BpEEWApGnQNGgaRBEAAAAAAAAAAAAAzzQhihBFmCbAM02IIkQRpgkAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAGHAAAAgwoQwUGrIiAIgTAHA4imUBAIDjOJYFAACO41gWAABYliWKAABgWZooAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAYcAAACDChDBQashIAiAIAcCiKZQHHsSzgOJYFJMmyAJYF0DyApgFEEQAIAAAocAAACLBBU2JxgEJDVgIAUQAABsWxLE0TRZKkaZoniiRJ0zxPFGma53meacLzPM80IYqiaJoQRVE0TZimaaoqME1VFQAAUOAAABBgg6bE4gCFhqwEAEICAByKYlma5nmeJ4qmqZokSdM8TxRF0TRNU1VJkqZ5niiKommapqqyLE3zPFEURdNUVVWFpnmeKIqiaaqq6sLzPE8URdE0VdV14XmeJ4qiaJqq6roQRVE0TdNUTVV1XSCKpmmaqqqqrgtETxRNU1Vd13WB54miaaqqq7ouEE3TVFVVdV1ZBpimaaqq68oyQFVV1XVdV5YBqqqqruu6sgxQVdd1XVmWZQCu67qyLMsCAAAOHAAAAoygk4wqi7DRhAsPQKEhKwKAKAAAwBimFFPKMCYhpBAaxiSEFEImJaXSUqogpFJSKRWEVEoqJaOUUmopVRBSKamUCkIqJZVSAADYgQMA2IGFUGjISgAgDwCAMEYpxhhzTiKkFGPOOScRUoox55yTSjHmnHPOSSkZc8w556SUzjnnnHNSSuacc845KaVzzjnnnJRSSuecc05KKSWEzkEnpZTSOeecEwAAVOAAABBgo8jmBCNBhYasBABSAQAMjmNZmuZ5omialiRpmud5niiapiZJmuZ5nieKqsnzPE8URdE0VZXneZ4oiqJpqirXFUXTNE1VVV2yLIqmaZqq6rowTdNUVdd1XZimaaqq67oubFtVVdV1ZRm2raqq6rqyDFzXdWXZloEsu67s2rIAAPAEBwCgAhtWRzgpGgssNGQlAJABAEAYg5BCCCFlEEIKIYSUUggJAAAYcAAACDChDBQashIASAUAAIyx1lprrbXWQGettdZaa62AzFprrbXWWmuttdZaa6211lJrrbXWWmuttdZaa6211lprrbXWWmuttdZaa6211lprrbXWWmuttdZaa6211lprrbXWWmstpZRSSimllFJKKaWUUkoppZRSSgUA+lU4APg/2LA6wknRWGChISsBgHAAAMAYpRhzDEIppVQIMeacdFRai7FCiDHnJKTUWmzFc85BKCGV1mIsnnMOQikpxVZjUSmEUlJKLbZYi0qho5JSSq3VWIwxqaTWWoutxmKMSSm01FqLMRYjbE2ptdhqq7EYY2sqLbQYY4zFCF9kbC2m2moNxggjWywt1VprMMYY3VuLpbaaizE++NpSLDHWXAAAd4MDAESCjTOsJJ0VjgYXGrISAAgJACAQUooxxhhzzjnnpFKMOeaccw5CCKFUijHGnHMOQgghlIwx5pxzEEIIIYRSSsaccxBCCCGEkFLqnHMQQgghhBBKKZ1zDkIIIYQQQimlgxBCCCGEEEoopaQUQgghhBBCCKmklEIIIYRSQighlZRSCCGEEEIpJaSUUgohhFJCCKGElFJKKYUQQgillJJSSimlEkoJJYQSUikppRRKCCGUUkpKKaVUSgmhhBJKKSWllFJKIYQQSikFAAAcOAAABBhBJxlVFmGjCRcegEJDVgIAZAAAkKKUUiktRYIipRikGEtGFXNQWoqocgxSzalSziDmJJaIMYSUk1Qy5hRCDELqHHVMKQYtlRhCxhik2HJLoXMOAAAAQQCAgJAAAAMEBTMAwOAA4XMQdAIERxsAgCBEZohEw0JweFAJEBFTAUBigkIuAFRYXKRdXECXAS7o4q4DIQQhCEEsDqCABByccMMTb3jCDU7QKSp1IAAAAAAADADwAACQXAAREdHMYWRobHB0eHyAhIiMkAgAAAAAABcAfAAAJCVAREQ0cxgZGhscHR4fICEiIyQBAIAAAgAAAAAggAAEBAQAAAAAAAIAAAAEBB9DtnUBAAAAAAAEPueBAKOFggAAgACjzoEAA4BwBwCdASqwAJAAAEcIhYWIhYSIAgIABhwJ7kPfbJyHvtk5D32ych77ZOQ99snIe+2TkPfbJyHvtk5D32ych77ZOQ99YAD+/6tQgKOFggADgAqjhYIAD4AOo4WCACSADqOZgQArADECAAEQEAAYABhYL/QACIBDmAYAAKOFggA6gA6jhYIAT4AOo5mBAFMAMQIAARAQABgAGFgv9AAIgEOYBgAAo4WCAGSADqOFggB6gA6jmYEAewAxAgABEBAAGAAYWC/0AAiAQ5gGAACjhYIAj4AOo5mBAKMAMQIAARAQABgAGFgv9AAIgEOYBgAAo4WCAKSADqOFggC6gA6jmYEAywAxAgABEBAAGAAYWC/0AAiAQ5gGAACjhYIAz4AOo4WCAOSADqOZgQDzADECAAEQEAAYABhYL/QACIBDmAYAAKOFggD6gA6jhYIBD4AOo5iBARsAEQIAARAQFGAAYWC/0AAiAQ5gGACjhYIBJIAOo4WCATqADqOZgQFDADECAAEQEAAYABhYL/QACIBDmAYAAKOFggFPgA6jhYIBZIAOo5mBAWsAMQIAARAQABgAGFgv9AAIgEOYBgAAo4WCAXqADqOFggGPgA6jmYEBkwAxAgABEBAAGAAYWC/0AAiAQ5gGAACjhYIBpIAOo4WCAbqADqOZgQG7ADECAAEQEAAYABhYL/QACIBDmAYAAKOFggHPgA6jmYEB4wAxAgABEBAAGAAYWC/0AAiAQ5gGAACjhYIB5IAOo4WCAfqADqOZgQILADECAAEQEAAYABhYL/QACIBDmAYAAKOFggIPgA6jhYICJIAOo5mBAjMAMQIAARAQABgAGFgv9AAIgEOYBgAAo4WCAjqADqOFggJPgA6jmYECWwAxAgABEBAAGAAYWC/0AAiAQ5gGAACjhYICZIAOo4WCAnqADqOZgQKDADECAAEQEAAYABhYL/QACIBDmAYAAKOFggKPgA6jhYICpIAOo5mBAqsAMQIAARAQABgAGFgv9AAIgEOYBgAAo4WCArqADqOFggLPgA6jmIEC0wARAgABEBAUYABhYL/QACIBDmAYAKOFggLkgA6jhYIC+oAOo5mBAvsAMQIAARAQABgAGFgv9AAIgEOYBgAAo4WCAw+ADqOZgQMjADECAAEQEAAYABhYL/QACIBDmAYAAKOFggMkgA6jhYIDOoAOo5mBA0sAMQIAARAQABgAGFgv9AAIgEOYBgAAo4WCA0+ADqOFggNkgA6jmYEDcwAxAgABEBAAGAAYWC/0AAiAQ5gGAACjhYIDeoAOo4WCA4+ADqOZgQObADECAAEQEAAYABhYL/QACIBDmAYAAKOFggOkgA6jhYIDuoAOo5mBA8MAMQIAARAQABgAGFgv9AAIgEOYBgAAo4WCA8+ADqOFggPkgA6jhYID+oAOo4WCBA+ADhxTu2sBAAAAAAAAEbuPs4EDt4r3gQHxghEr8IEK",
        mp4: "data:video/mp4;base64,AAAAHGZ0eXBNNFYgAAACAGlzb21pc28yYXZjMQAAAAhmcmVlAAAGF21kYXTeBAAAbGliZmFhYyAxLjI4AABCAJMgBDIARwAAArEGBf//rdxF6b3m2Ui3lizYINkj7u94MjY0IC0gY29yZSAxNDIgcjIgOTU2YzhkOCAtIEguMjY0L01QRUctNCBBVkMgY29kZWMgLSBDb3B5bGVmdCAyMDAzLTIwMTQgLSBodHRwOi8vd3d3LnZpZGVvbGFuLm9yZy94MjY0Lmh0bWwgLSBvcHRpb25zOiBjYWJhYz0wIHJlZj0zIGRlYmxvY2s9MTowOjAgYW5hbHlzZT0weDE6MHgxMTEgbWU9aGV4IHN1Ym1lPTcgcHN5PTEgcHN5X3JkPTEuMDA6MC4wMCBtaXhlZF9yZWY9MSBtZV9yYW5nZT0xNiBjaHJvbWFfbWU9MSB0cmVsbGlzPTEgOHg4ZGN0PTAgY3FtPTAgZGVhZHpvbmU9MjEsMTEgZmFzdF9wc2tpcD0xIGNocm9tYV9xcF9vZmZzZXQ9LTIgdGhyZWFkcz02IGxvb2thaGVhZF90aHJlYWRzPTEgc2xpY2VkX3RocmVhZHM9MCBucj0wIGRlY2ltYXRlPTEgaW50ZXJsYWNlZD0wIGJsdXJheV9jb21wYXQ9MCBjb25zdHJhaW5lZF9pbnRyYT0wIGJmcmFtZXM9MCB3ZWlnaHRwPTAga2V5aW50PTI1MCBrZXlpbnRfbWluPTI1IHNjZW5lY3V0PTQwIGludHJhX3JlZnJlc2g9MCByY19sb29rYWhlYWQ9NDAgcmM9Y3JmIG1idHJlZT0xIGNyZj0yMy4wIHFjb21wPTAuNjAgcXBtaW49MCBxcG1heD02OSBxcHN0ZXA9NCB2YnZfbWF4cmF0ZT03NjggdmJ2X2J1ZnNpemU9MzAwMCBjcmZfbWF4PTAuMCBuYWxfaHJkPW5vbmUgZmlsbGVyPTAgaXBfcmF0aW89MS40MCBhcT0xOjEuMDAAgAAAAFZliIQL8mKAAKvMnJycnJycnJycnXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXiEASZACGQAjgCEASZACGQAjgAAAAAdBmjgX4GSAIQBJkAIZACOAAAAAB0GaVAX4GSAhAEmQAhkAI4AhAEmQAhkAI4AAAAAGQZpgL8DJIQBJkAIZACOAIQBJkAIZACOAAAAABkGagC/AySEASZACGQAjgAAAAAZBmqAvwMkhAEmQAhkAI4AhAEmQAhkAI4AAAAAGQZrAL8DJIQBJkAIZACOAAAAABkGa4C/AySEASZACGQAjgCEASZACGQAjgAAAAAZBmwAvwMkhAEmQAhkAI4AAAAAGQZsgL8DJIQBJkAIZACOAIQBJkAIZACOAAAAABkGbQC/AySEASZACGQAjgCEASZACGQAjgAAAAAZBm2AvwMkhAEmQAhkAI4AAAAAGQZuAL8DJIQBJkAIZACOAIQBJkAIZACOAAAAABkGboC/AySEASZACGQAjgAAAAAZBm8AvwMkhAEmQAhkAI4AhAEmQAhkAI4AAAAAGQZvgL8DJIQBJkAIZACOAAAAABkGaAC/AySEASZACGQAjgCEASZACGQAjgAAAAAZBmiAvwMkhAEmQAhkAI4AhAEmQAhkAI4AAAAAGQZpAL8DJIQBJkAIZACOAAAAABkGaYC/AySEASZACGQAjgCEASZACGQAjgAAAAAZBmoAvwMkhAEmQAhkAI4AAAAAGQZqgL8DJIQBJkAIZACOAIQBJkAIZACOAAAAABkGawC/AySEASZACGQAjgAAAAAZBmuAvwMkhAEmQAhkAI4AhAEmQAhkAI4AAAAAGQZsAL8DJIQBJkAIZACOAAAAABkGbIC/AySEASZACGQAjgCEASZACGQAjgAAAAAZBm0AvwMkhAEmQAhkAI4AhAEmQAhkAI4AAAAAGQZtgL8DJIQBJkAIZACOAAAAABkGbgCvAySEASZACGQAjgCEASZACGQAjgAAAAAZBm6AnwMkhAEmQAhkAI4AhAEmQAhkAI4AhAEmQAhkAI4AhAEmQAhkAI4AAAAhubW9vdgAAAGxtdmhkAAAAAAAAAAAAAAAAAAAD6AAABDcAAQAAAQAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwAAAzB0cmFrAAAAXHRraGQAAAADAAAAAAAAAAAAAAABAAAAAAAAA+kAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAABAAAAAALAAAACQAAAAAAAkZWR0cwAAABxlbHN0AAAAAAAAAAEAAAPpAAAAAAABAAAAAAKobWRpYQAAACBtZGhkAAAAAAAAAAAAAAAAAAB1MAAAdU5VxAAAAAAALWhkbHIAAAAAAAAAAHZpZGUAAAAAAAAAAAAAAABWaWRlb0hhbmRsZXIAAAACU21pbmYAAAAUdm1oZAAAAAEAAAAAAAAAAAAAACRkaW5mAAAAHGRyZWYAAAAAAAAAAQAAAAx1cmwgAAAAAQAAAhNzdGJsAAAAr3N0c2QAAAAAAAAAAQAAAJ9hdmMxAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAALAAkABIAAAASAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGP//AAAALWF2Y0MBQsAN/+EAFWdCwA3ZAsTsBEAAAPpAADqYA8UKkgEABWjLg8sgAAAAHHV1aWRraEDyXyRPxbo5pRvPAyPzAAAAAAAAABhzdHRzAAAAAAAAAAEAAAAeAAAD6QAAABRzdHNzAAAAAAAAAAEAAAABAAAAHHN0c2MAAAAAAAAAAQAAAAEAAAABAAAAAQAAAIxzdHN6AAAAAAAAAAAAAAAeAAADDwAAAAsAAAALAAAACgAAAAoAAAAKAAAACgAAAAoAAAAKAAAACgAAAAoAAAAKAAAACgAAAAoAAAAKAAAACgAAAAoAAAAKAAAACgAAAAoAAAAKAAAACgAAAAoAAAAKAAAACgAAAAoAAAAKAAAACgAAAAoAAAAKAAAAiHN0Y28AAAAAAAAAHgAAAEYAAANnAAADewAAA5gAAAO0AAADxwAAA+MAAAP2AAAEEgAABCUAAARBAAAEXQAABHAAAASMAAAEnwAABLsAAATOAAAE6gAABQYAAAUZAAAFNQAABUgAAAVkAAAFdwAABZMAAAWmAAAFwgAABd4AAAXxAAAGDQAABGh0cmFrAAAAXHRraGQAAAADAAAAAAAAAAAAAAACAAAAAAAABDcAAAAAAAAAAAAAAAEBAAAAAAEAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAkZWR0cwAAABxlbHN0AAAAAAAAAAEAAAQkAAADcAABAAAAAAPgbWRpYQAAACBtZGhkAAAAAAAAAAAAAAAAAAC7gAAAykBVxAAAAAAALWhkbHIAAAAAAAAAAHNvdW4AAAAAAAAAAAAAAABTb3VuZEhhbmRsZXIAAAADi21pbmYAAAAQc21oZAAAAAAAAAAAAAAAJGRpbmYAAAAcZHJlZgAAAAAAAAABAAAADHVybCAAAAABAAADT3N0YmwAAABnc3RzZAAAAAAAAAABAAAAV21wNGEAAAAAAAAAAQAAAAAAAAAAAAIAEAAAAAC7gAAAAAAAM2VzZHMAAAAAA4CAgCIAAgAEgICAFEAVBbjYAAu4AAAADcoFgICAAhGQBoCAgAECAAAAIHN0dHMAAAAAAAAAAgAAADIAAAQAAAAAAQAAAkAAAAFUc3RzYwAAAAAAAAAbAAAAAQAAAAEAAAABAAAAAgAAAAIAAAABAAAAAwAAAAEAAAABAAAABAAAAAIAAAABAAAABgAAAAEAAAABAAAABwAAAAIAAAABAAAACAAAAAEAAAABAAAACQAAAAIAAAABAAAACgAAAAEAAAABAAAACwAAAAIAAAABAAAADQAAAAEAAAABAAAADgAAAAIAAAABAAAADwAAAAEAAAABAAAAEAAAAAIAAAABAAAAEQAAAAEAAAABAAAAEgAAAAIAAAABAAAAFAAAAAEAAAABAAAAFQAAAAIAAAABAAAAFgAAAAEAAAABAAAAFwAAAAIAAAABAAAAGAAAAAEAAAABAAAAGQAAAAIAAAABAAAAGgAAAAEAAAABAAAAGwAAAAIAAAABAAAAHQAAAAEAAAABAAAAHgAAAAIAAAABAAAAHwAAAAQAAAABAAAA4HN0c3oAAAAAAAAAAAAAADMAAAAaAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAACMc3RjbwAAAAAAAAAfAAAALAAAA1UAAANyAAADhgAAA6IAAAO+AAAD0QAAA+0AAAQAAAAEHAAABC8AAARLAAAEZwAABHoAAASWAAAEqQAABMUAAATYAAAE9AAABRAAAAUjAAAFPwAABVIAAAVuAAAFgQAABZ0AAAWwAAAFzAAABegAAAX7AAAGFwAAAGJ1ZHRhAAAAWm1ldGEAAAAAAAAAIWhkbHIAAAAAAAAAAG1kaXJhcHBsAAAAAAAAAAAAAAAALWlsc3QAAAAlqXRvbwAAAB1kYXRhAAAAAQAAAABMYXZmNTUuMzMuMTAw"
    }), F
}
var W, AA;

function ge() {
    if (AA) return W;
    AA = 1;
    const {
        webm: o,
        mp4: A
    } = me(), n = () => typeof navigator < "u" && parseFloat(("" + (/CPU.*OS ([0-9_]{3,4})[0-9_]{0,1}|(CPU like).*AppleWebKit.*Mobile/i.exec(navigator.userAgent) || [0, ""])[1]).replace("undefined", "3_2").replace("_", ".").replace("_", "")) < 10 && !window.MSStream, i = () => "wakeLock" in navigator;
    class e {
        constructor() {
            if (this.enabled = !1, i()) {
                this._wakeLock = null;
                const c = () => {
                    this._wakeLock !== null && document.visibilityState === "visible" && this.enable()
                };
                document.addEventListener("visibilitychange", c), document.addEventListener("fullscreenchange", c)
            } else n() ? this.noSleepTimer = null : (this.noSleepVideo = document.createElement("video"), this.noSleepVideo.setAttribute("title", "No Sleep"), this.noSleepVideo.setAttribute("playsinline", ""), this._addSourceToVideo(this.noSleepVideo, "webm", o), this._addSourceToVideo(this.noSleepVideo, "mp4", A), this.noSleepVideo.addEventListener("loadedmetadata", () => {
                this.noSleepVideo.duration <= 1 ? this.noSleepVideo.setAttribute("loop", "") : this.noSleepVideo.addEventListener("timeupdate", () => {
                    this.noSleepVideo.currentTime > .5 && (this.noSleepVideo.currentTime = Math.random())
                })
            }))
        }
        _addSourceToVideo(c, t, g) {
            var d = document.createElement("source");
            d.src = g, d.type = "video/".concat(t), c.appendChild(d)
        }
        get isEnabled() {
            return this.enabled
        }
        enable() {
            return i() ? navigator.wakeLock.request("screen").then(c => {
                this._wakeLock = c, this.enabled = !0, console.log("Wake Lock active."), this._wakeLock.addEventListener("release", () => {
                    console.log("Wake Lock released.")
                })
            }).catch(c => {
                throw this.enabled = !1, console.error("".concat(c.name, ", ").concat(c.message)), c
            }) : n() ? (this.disable(), console.warn("\n        NoSleep enabled for older iOS devices. This can interrupt\n        active or long-running network requests from completing successfully.\n        See https://github.com/richtr/NoSleep.js/issues/15 for more details.\n      "), this.noSleepTimer = window.setInterval(() => {
                document.hidden || (window.location.href = window.location.href.split("#")[0], window.setTimeout(window.stop, 0))
            }, 15e3), this.enabled = !0, Promise.resolve()) : this.noSleepVideo.play().then(t => (this.enabled = !0, t)).catch(t => {
                throw this.enabled = !1, t
            })
        }
        disable() {
            i() ? (this._wakeLock && this._wakeLock.release(), this._wakeLock = null) : n() ? this.noSleepTimer && (console.warn("\n          NoSleep now disabled for older iOS devices.\n        "), window.clearInterval(this.noSleepTimer), this.noSleepTimer = null) : this.noSleepVideo.pause(), this.enabled = !1
        }
    }
    return W = e, W
}
var ue = ge();
const Be = kA(ue),
    eA = "mode",
    Ee = "voice",
    he = () => {
        const [o, A] = fA(), n = o.get(eA), i = NA(), e = b(u => u.isVoiceModeActive), r = nA(), c = !bA(), t = wA(r), g = RA(), d = !c, m = SA();
        a.useEffect(() => {
            n === Ee && !e && (A(u => (u.delete(eA), u)), g ? m("/update-app") : d ? (KA(HA.DeepLink), t ? zA({
                type: "START"
            }) : i.setState({
                isVoiceModeActive: !0
            })) : xA(r, {
                fallbackScreenHint: "login",
                callbackUrl: window.location.href
            }))
        }, [r, t, d, g, n, m, A, e, i])
    };

function lA(o, A) {
    if (A.srcObject instanceof MediaStream) {
        const n = A.srcObject;
        n.removeTrack(o), n.getTracks().length > 0 ? A.srcObject = n : A.srcObject = null
    }
}

function dA(o, A) {
    let n;
    A.srcObject instanceof MediaStream ? n = A.srcObject : n = new MediaStream;
    let i;
    o.kind === "audio" ? i = n.getAudioTracks() : i = n.getVideoTracks(), i.includes(o) || (i.forEach(e => {
        n.removeTrack(e)
    }), n.addTrack(o)), (!P() || !(A instanceof HTMLVideoElement)) && (A.autoplay = !0), A.muted = n.getAudioTracks().length === 0, A instanceof HTMLVideoElement && (A.playsInline = !0), A.srcObject !== n && (A.srcObject = n, (P() || ZA()) && A instanceof HTMLVideoElement && setTimeout(() => {
        A.srcObject = n, A.play().catch(() => {})
    }, 0))
}

function Ce({
    children: o
}) {
    const {
        cameraTrackState: A
    } = L(), {
        screenshareTrackState: n
    } = U(), i = A === w.Started || n === w.Started, e = A === w.Started;
    return s.jsx(v, {
        mode: "wait",
        children: i ? s.jsx("div", {
            className: "flex h-full w-full flex-nowrap items-center",
            children: e ? s.jsx(pe, {}) : s.jsx(Ie, {})
        }) : s.jsx(M.div, {
            className: "relative flex h-full w-full items-center justify-center",
            initial: {
                opacity: 0
            },
            animate: {
                opacity: 1
            },
            exit: {
                opacity: 0
            },
            children: o
        }, "children")
    })
}

function pe() {
    const {
        cameraTrackState: o,
        toggleCamera: A
    } = L(), {
        getTracks: n
    } = O(), e = n([N.Camera]).find(t => t.origin === D.Local), r = a.useRef(null), c = o === w.Started && e;
    return a.useEffect(() => {
        if (e) {
            const t = () => {
                A("Browser Video Controls")
            };
            return e.onEnded(t), () => {
                e.offEnded(t)
            }
        }
    }, [e, A]), a.useEffect(() => {
        const t = r.current;
        return t && e && dA(e.track, t), () => {
            t && e && lA(e.track, t)
        }
    }, [e]), s.jsx(v, {
        children: c && s.jsx(mA, {
            children: s.jsxs("div", {
                className: "aspect-w-16 aspect-h-9 group relative max-h-[95%] w-fit max-w-[60%] overflow-hidden rounded-3xl shadow-md",
                children: [s.jsx("div", {
                    className: "absolute end-2 top-2 z-10 opacity-0 transition-opacity group-hover:opacity-90",
                    children: s.jsx(iA, {
                        onClick: () => A("StopButton"),
                        className: "bg-gray-900/20 backdrop-blur-lg hover:bg-gray-900/30 dark:backdrop-blur-lg"
                    })
                }), s.jsx("video", {
                    ref: r,
                    className: "h-full w-full object-contain",
                    muted: !0
                })]
            })
        }, "camera-renderer")
    })
}

function Ie() {
    const {
        screenshareTrackState: o,
        toggleScreenShare: A
    } = U(), {
        getTracks: n
    } = O(), e = n([N.ScreenShare]).find(t => t.origin === D.Local), r = a.useRef(null), c = o === w.Started && e;
    return a.useEffect(() => {
        if (e) {
            const t = () => {
                A("Browser ScreenShare Controls")
            };
            return e.onEnded(t), () => {
                e.offEnded(t)
            }
        }
    }, [e, A]), a.useEffect(() => {
        const t = r.current;
        return t && e && c && dA(e.track, t), () => {
            t && e && lA(e.track, t)
        }
    }, [e, c]), s.jsx(v, {
        children: c && s.jsx(mA, {
            children: s.jsxs("div", {
                className: "aspect-w-16 aspect-h-9 group relative max-h-[95%] w-fit max-w-[60%] overflow-hidden rounded-3xl shadow-md",
                children: [s.jsx("div", {
                    className: "absolute end-2 top-2 z-10 opacity-0 transition-opacity group-hover:opacity-90",
                    children: s.jsx(iA, {
                        onClick: () => A("StopButton"),
                        className: "bg-gray-900/20 backdrop-blur-lg hover:bg-gray-900/30 dark:backdrop-blur-lg"
                    })
                }), s.jsx("video", {
                    ref: r,
                    className: "h-full w-full object-contain",
                    muted: !0
                })]
            })
        }, "screenshare-renderer")
    })
}

function mA({
    children: o,
    key: A
}) {
    return s.jsx(M.div, {
        className: "bg-token-main-surface-primary flex h-full w-full flex-col items-center justify-center gap-2",
        initial: {
            opacity: 0,
            transform: "blur(12px)",
            scale: .75
        },
        animate: {
            opacity: 1,
            transform: "blur(0px)",
            scale: 1
        },
        exit: {
            opacity: 0,
            transform: "blur(12px)",
            scale: .75
        },
        transition: {
            duration: .2
        },
        children: o
    }, A)
}
const G = (o, A) => {
        const [n, i] = a.useState(o === A ? performance.now() : 0), e = a.useRef(A);
        a.useEffect(() => {
            e.current !== A && o === A && i(performance.now()), e.current = A
        }, [A, o]);
        const r = a.useCallback(() => {
            i(0)
        }, []);
        return [o === A ? 1 : 0, n, r]
    },
    J = ([o, A, n], i = 500) => {
        const [e, r] = a.useState(o), c = a.useRef(o), t = a.useRef(void 0), g = a.useCallback((d, m, u) => {
            const h = p => {
                const E = Math.min((p - d) / i, 1),
                    C = m + E * (u - m);
                r(C), E < 1 && (t.current = requestAnimationFrame(h))
            };
            t.current = requestAnimationFrame(h)
        }, [i]);
        return a.useEffect(() => {
            if (c.current !== o) {
                c.current = o, t.current && cancelAnimationFrame(t.current);
                const d = e,
                    m = o;
                g(performance.now(), d, m)
            }
        }, [g, e, o]), [e, A / 1e3, n]
    },
    tA = o => {
        const [A, n] = a.useState({
            audioData: [0, 0, 0, 0],
            cumulativeAudioData: [0, 0, 0, 0]
        }), i = a.useRef([0, 0, 0, 0]), e = a.useRef(void 0), r = a.useRef(performance.now()), {
            bandMagnitudes: c,
            cumulativeMagnitude: t
        } = $A(o, {
            bands: 3,
            bins: 1,
            gainMultipliers: [10, 1, 1]
        });
        i.current = [...c, t].flat();
        const g = a.useCallback(() => {
            const d = performance.now(),
                m = (d - r.current) / 1e3;
            r.current = d;
            const u = i.current,
                {
                    audioData: h,
                    cumulativeAudioData: p
                } = A,
                E = Ae({
                    deltaTimeS: m,
                    audioDataRaw: u,
                    prevAudioData: h,
                    prevCumulativeAudioData: p
                });
            n(E)
        }, [A]);
        return a.useEffect(() => (e.current || (e.current = window.setInterval(g, rA)), () => {
            clearInterval(e.current), e.current = void 0
        }), [g]), A
    };

function oA({
    className: o
}) {
    return s.jsx(we, {
        className: o
    })
}
const Qe = 1.55,
    ke = 1.4,
    fe = "audio",
    Se = "shout",
    Ve = "User",
    Me = {
        bands: 4,
        loPass: 0,
        hiPass: 400
    },
    aA = [300, 300];

function be() {
    var Y;
    const o = TA(),
        A = b(l => l.voiceMode === "advanced"),
        n = yA(),
        i = nA(),
        e = vA(i, "2624610486"),
        {
            getTracks: r
        } = O(),
        c = r([N.Microphone]),
        t = c.find(l => l.name === fe),
        g = c.find(l => l.name === Se);
    let d = _(g == null ? void 0 : g.track, Me);
    d.length === 0 && (d = [0, 0, 0, 0]), d.map(l => l * ke);
    const m = tA(g == null ? void 0 : g.track),
        u = tA(t == null ? void 0 : t.track),
        h = m.audioData.map((l, S) => {
            const Q = u.audioData[S];
            return l > 0 && Q > 0 ? (l + Q) / 2 : l > 0 ? l : Q
        }),
        p = m.cumulativeAudioData.map((l, S) => {
            const Q = u.cumulativeAudioData[S];
            return l > 0 && Q > 0 ? (l + Q) / 2 : l > 0 ? l : Q
        }),
        E = b(l => l.server.remoteState),
        C = b(l => l.server.connectionState),
        T = b(l => l.hasConnectedOnce),
        I = a.useMemo(() => {
            switch (C) {
                case Z.Connected:
                    return E;
                case Z.Connecting:
                case Z.Reconnecting:
                case Z.SignalReconnecting:
                case null:
                    return null;
                case Z.Disconnected:
                    return k.Halted
            }
        }, [C, E]),
        B = a.useMemo(() => {
            var l;
            return (l = c.find(S => S.userName === Ve)) == null ? void 0 : l.track
        }, [c]),
        R = ((Y = _(B, {
            bands: 1,
            loPass: 0,
            hiPass: 400
        })[0]) != null ? Y : 0) * Qe,
        {
            voiceName: X
        } = cA();
    let f;
    return n && e ? f = "HELLO_TIBOR" : X === "shade" && (f = "ANGSTY_BLACK"), {
        hasConnectedOnce: T,
        connectionState: C,
        remoteState: I,
        userVolume: R,
        isAdvanced: A,
        avgMag: h,
        cumulativeAudio: p,
        isDarkMode: o,
        standardBloopVolumes: d,
        overrideColor: f
    }
}

function we({
    className: o
}) {
    const {
        hasConnectedOnce: A,
        connectionState: n,
        remoteState: i,
        userVolume: e,
        isAdvanced: r,
        avgMag: c,
        cumulativeAudio: t,
        isDarkMode: g,
        standardBloopVolumes: d,
        overrideColor: m
    } = be(), [u, h] = a.useState(aA), {
        canvasSizeRef: p,
        handleCanvasSizeUpdate: E
    } = PA(aA), C = a.useRef(void 0), T = a.useCallback(V => {
        h([V.width, V.height])
    }, []), I = a.useRef([0, 0, 0, 0]);
    a.useEffect(() => {
        i === k.Connecting && (I.current = [0, 0, 0, 0])
    }, [i]);
    const B = a.useRef(performance.now());
    a.useEffect(() => {
        const V = performance.now();
        i === k.Speaking && V - B.current > 50 && (B.current = V, I.current = I.current.map((IA, QA) => IA + c[QA]))
    }, [i, c]);
    const [R, X] = J(G(k.Listening, i)), [f, Y] = J(G(k.Speaking, i)), [l, S] = J(G(k.Thinking, i)), [Q, gA] = J(G(k.Halted, i));
    a.useEffect(() => {
        !OA() && (f > 0 || R > 0) && XA()
    }, [f, R]);
    const [y, uA] = a.useState(performance.now() / 1e3);
    a.useEffect(() => {
        const V = setInterval(() => {
            uA(performance.now() / 1e3)
        }, rA);
        return () => clearInterval(V)
    }, []);
    const x = a.useMemo(() => performance.now() / 1e3, []),
        [BA, K] = a.useState(1e5),
        H = a.useRef(i);
    a.useEffect(() => {
        i === k.Connecting ? K(1e5) : H.current === k.Connecting && K(y), H.current = i
    }, [i, y]);
    const j = ee({
            isAdvanced: r,
            overrideColor: m
        }),
        EA = r ? c : d,
        z = R === 1 || f === 1,
        hA = te({
            viewport: u,
            canvasSize: p.current,
            shouldMeasurePerf: z,
            source: "VoiceMode"
        }),
        CA = oe({
            shouldCalibrate: z,
            viewport: u,
            initialScale: 1
        }),
        pA = a.useMemo(() => n !== Z.Connected && A, [n, A]);
    return C.current = {
        time: y - x,
        micLevel: e,
        stateListen: R,
        listenTimestamp: Math.max(X - x, 0),
        stateThink: l,
        thinkTimestamp: Math.max(S - x, 0),
        stateSpeak: f,
        speakTimestamp: Math.max(Y - x, 0),
        readyTimestamp: BA - x,
        stateHalt: Q,
        haltTimestamp: Math.max(gA - x, 0),
        touchDownTimestamp: 0,
        touchUpTimestamp: 0,
        stateFailedToConnect: pA ? 1 : 0,
        failedToConnectTimestamp: 0,
        avgMag: EA,
        cumulativeAudio: t != null ? t : I.current,
        isNewBloop: !0,
        isAdvancedBloop: r,
        bloopColorMain: Array.from(j.bloopColorMain),
        bloopColorLow: Array.from(j.bloopColorLow),
        bloopColorMid: Array.from(j.bloopColorMid),
        bloopColorHigh: Array.from(j.bloopColorHigh),
        isDarkMode: g,
        screenScaleFactor: window.devicePixelRatio,
        viewport: u,
        silenceAmount: 0,
        silenceTimestamp: 0,
        fadeBloopWhileListening: !1
    }, s.jsx(de, {
        className: DA("flex items-center justify-center", o),
        variablesRef: C,
        onViewportUpdate: T,
        textureImage: ie,
        textureName: "uTextureNoise",
        onGlAvailable: hA,
        onCanvasSizeUpdate: E,
        scale: CA,
        GLUniformsSetter: ne,
        vert: se,
        frag: ae
    })
}
const Re = ({
        conversationId: o
    }) => {
        const {
            getTracks: A
        } = O(), n = A(), [i, e] = a.useState(!1), [r, c] = a.useState(!1), {
            voiceName: t
        } = cA(), g = sA(), d = a.useCallback(() => {
            for (const B of n) B.origin === D.Local ? (c(B.isMuted), B.setMuted(!0)) : B.origin === D.Remote && B.setMuted(!0)
        }, [n]), m = a.useCallback(() => {
            for (const B of n) B.origin === D.Local ? r || B.setMuted(!1) : B.origin === D.Remote && B.setMuted(!1)
        }, [n, r]), u = a.useCallback(() => {
            YA.voiceSelectionShown.click({
                voice: t
            }), d(), e(!0)
        }, [t, d]), h = () => {
            m(), e(!1)
        }, p = ce(), E = t === "shade", {
            alreadyTriggered: C
        } = re(), T = p && !E && !C, I = a.useMemo(() => s.jsx(FA, {
            onClick: u,
            icon: _A,
            iconColor: "text-token-text-secondary",
            className: "h-[40px] w-[40px] bg-transparent hover:bg-black/10 active:bg-black/20 dark:bg-transparent dark:hover:bg-white/5 dark:active:bg-white/10",
            iconSize: "icon"
        }), [u]);
        return s.jsxs("div", {
            className: "relative h-[40px] w-[40px]",
            children: [T ? s.jsx(jA, {
                label: g.formatMessage({
                    id: "SxYG4e",
                    defaultMessage: "Talk to Monday (ugh)"
                }),
                children: I
            }) : I, i && s.jsx(le, {
                conversationId: o,
                onClose: h
            })]
        })
    },
    xe = JA(() => VA(() =>
        import ("./h1actw4u04fjw3sy.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21])).then(o => o.VoiceModeDevPanel));

function Pe({
    conversationId: o
}) {
    const [A, n] = a.useState(!1), {
        screenshareTrackState: i
    } = U(), {
        cameraTrackState: e
    } = L(), r = i === w.Started || e === w.Started, c = b(m => m.isVoiceModeActive), t = b(m => m.server.voiceConnectionQuality), g = sA();
    he();
    const d = WA({
        conversationId: o
    });
    return GA(() => {
        c && d(MA.ElectronAppMinimized)
    }), a.useEffect(() => {
        const m = new Be;
        return c ? m.enable() : m.disable(), () => {
            m.disable()
        }
    }, [c]), s.jsxs(qA, {
        conversationId: o,
        children: [s.jsx(v, {
            children: c ? s.jsx(M.div, {
                className: "bg-token-main-surface-primary fixed start-0 top-0 z-50 flex h-full w-full flex-col",
                initial: "hidden",
                animate: "visible",
                exit: "hidden",
                variants: q,
                children: s.jsx(M.div, {
                    className: "relative h-full w-full",
                    variants: q,
                    children: s.jsxs(M.div, {
                        variants: q,
                        className: "flex h-full w-full flex-col justify-between gap-6",
                        children: [s.jsxs(M.div, {
                            className: "relative mt-6 flex w-full justify-center",
                            children: [s.jsx("div", {
                                className: "flex w-full items-center justify-center",
                                children: (r || !1) && s.jsx(oA, {
                                    className: "h-16 w-16"
                                })
                            }), s.jsxs("div", {
                                className: "me-4 flex flex-row gap-2",
                                children: [!1, s.jsx(Re, {
                                    conversationId: o
                                })]
                            })]
                        }), s.jsxs("div", {
                            className: "flex h-full min-h-0 items-center justify-center",
                            children: [s.jsx(Ce, {
                                children: s.jsxs("div", {
                                    className: "relative",
                                    children: [s.jsx(oA, {
                                        className: "min-h-bloop min-w-bloop h-max w-max"
                                    }), !1]
                                })
                            }), s.jsx(v, {
                                children: A ? s.jsx(xe, {
                                    conversationId: o
                                }) : null
                            })]
                        }), s.jsx(M.div, {
                            className: "mb-6 flex justify-center",
                            children: s.jsx(LA, {
                                conversationId: o
                            })
                        })]
                    })
                })
            }) : null
        }), t === UA.POOR && s.jsx("div", {
            className: "absolute start-1/2 top-6 z-50 -translate-x-1/2 transform",
            children: s.jsx("div", {
                className: "border-token-border-default bg-token-main-surface-primary inline-flex flex-col items-center rounded-full border px-6 py-3",
                children: s.jsx("span", {
                    className: "text-token-text-secondary",
                    children: g.formatMessage({
                        id: "YE2Eng",
                        defaultMessage: "Poor connection"
                    })
                })
            })
        }), !1, !1]
    })
}
const q = {
    hidden: {
        opacity: 0,
        transform: "blur(4px)"
    },
    visible: {
        transform: "blur(0px)",
        opacity: 1
    },
    exit: {
        opacity: 0,
        transform: "blur(4px)"
    }
};
export {
    Pe as VoiceModeLayout
};
//# sourceMappingURL=dcf3hf7bsuja7hbh.js.map