var Ce = Object.freeze,
    _e = Object.defineProperty,
    as = Object.defineProperties;
var ls = Object.getOwnPropertyDescriptors;
var be = Object.getOwnPropertySymbols;
var os = Object.prototype.hasOwnProperty,
    is = Object.prototype.propertyIsEnumerable;
var Se = (t, n, i) => n in t ? _e(t, n, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: i
    }) : t[n] = i,
    c = (t, n) => {
        for (var i in n || (n = {})) os.call(n, i) && Se(t, i, n[i]);
        if (be)
            for (var i of be(n)) is.call(n, i) && Se(t, i, n[i]);
        return t
    },
    f = (t, n) => as(t, ls(n));
var pe = (t, n) => Ce(_e(t, "raw", {
    value: Ce(n || t.slice())
}));
import {
    r as F,
    m as Fe,
    E as rs,
    j as e,
    e as de,
    n as cs,
    M as P,
    f as us
} from "./fg33krlcm0qyi6yw.js";
import {
    h as ds
} from "./k2oaaf8ac9lafsub.js";
import {
    go as ms,
    hT as Ie,
    hU as ie,
    hV as re,
    g5 as Re,
    hW as fs,
    gp as Ue,
    hX as Oe,
    hY as ce,
    db as gs,
    dc as hs,
    e6 as xs,
    hZ as ys,
    e7 as He,
    g4 as We,
    cM as Ts,
    g9 as Ps,
    h_ as le,
    g7 as O,
    cH as ve,
    fO as je,
    gb as se,
    ga as Ee,
    h$ as Cs,
    i0 as bs,
    i1 as Ss
} from "./k15yxxoybkkir2ou.js";
import {
    H as ne,
    aK as Ne,
    m as _s,
    ag as ps,
    L as vs,
    fP as js,
    P as Z,
    bJ as Es,
    b as me,
    C as we,
    cQ as Ns,
    l as ue,
    Y as oe,
    c_ as ws,
    B as Ms,
    _ as Ve,
    sX as Me,
    F as ks
} from "./dykg4ktvbu3mhmdo.js";
import {
    c as $e
} from "./iej0cupg2dqkmejt.js";
import {
    u as Ye,
    T as te,
    t as X,
    a as Qe,
    g as Xe
} from "./n7nqkdn53j3o5j6k.js";
import {
    u as ke
} from "./h8afdg57t22ai4ff.js";
const Bs = $e(Re),
    As = ({
        promoData: t,
        promoDataIsFromQueryParam: n = !1,
        initialPromoCoupon: i,
        initialPromoCouponFromQueryParam: w = !1,
        initialSeats: C
    } = {}) => {
        const l = ne(),
            s = !!(l != null && l.isFreeWorkspace()),
            {
                count: d,
                isLoading: g
            } = ms(l == null ? void 0 : l.id),
            r = !g && d > 0 ? d : void 0;
        let a = Ue(),
            y = fs();
        s ? (a = r != null ? r : a, y = r != null ? r : y) : (a = Math.max(r != null ? r : 0, a), y = Math.max(r != null ? r : 0, y));
        const x = Ye(),
            o = x != null ? x : i,
            S = x ? !0 : !!(w && i),
            {
                data: _
            } = Ie(o != null ? o : "", S);
        let M = t,
            H = n;
        !t && _ && (M = _, H = S);
        const $ = (M == null ? void 0 : M.coupon) === te && M.state === "eligible",
            m = typeof window < "u" ? new URLSearchParams(window == null ? void 0 : window.location.search) : new URLSearchParams,
            T = m.get(ie),
            B = m.get(re),
            h = B && Bs(B) ? B : Re.FLEXIBLE,
            [p, E] = F.useState(h),
            [b, N] = F.useState(() => {
                if (C != null) return C;
                const v = T && !isNaN(parseInt(T, 10)) ? parseInt(T, 10) : void 0;
                return v != null ? v : Math.max(y, a)
            });
        return {
            promoData: M,
            promoDataIsFromQueryParam: H,
            selectedPlan: p,
            setSelectedPlan: E,
            numSeats: b,
            setNumSeats: v => N(W => {
                const j = typeof v == "function" ? v(W) : v;
                return Math.max(j, a)
            }),
            minTeamSeats: a,
            TEAM_FREE_TRIAL_COUPON_IsEligible: $
        }
    };
var qe = (t => (t.FLEXIBLE = "month", t.ANNUAL = "year", t))(qe || {});
const Be = $e(qe),
    Ks = t => {
        const n = F.useRef(!1),
            i = Fe(),
            w = i.hash.split("#")[1] === Oe || i.hash.split("#")[1] === ce,
            C = ne(),
            l = !n.current && w && C && !t,
            {
                country: s
            } = gs(),
            d = hs({
                country: s,
                currentAccount: C,
                location: "team-workspace-purchase-modal"
            }),
            g = Ye(),
            r = !!g,
            {
                data: a,
                isLoading: y
            } = Ie(g != null ? g : "", r),
            x = Ue(),
            o = rs.useRef(void 0);
        F.useEffect(() => {
            !l || !d || (Ne.setPurchaseWorkspaceData({
                minimumSeats: x,
                billingDetails: d,
                promoData: a,
                promoDataIsFromQueryParam: a && r ? !0 : void 0
            }), n.current = !0)
        }, [C, d, x, w, t, g, a, r, l]), F.useEffect(() => {
            const S = o.current;
            o.current = y, !(y || !n.current) && S && d && Ne.setPurchaseWorkspaceData({
                minimumSeats: x,
                billingDetails: d,
                promoData: a,
                promoDataIsFromQueryParam: a && r ? !0 : void 0
            })
        }, [a, y, x, d, r])
    };
var Le;
const Ae = ks.p(Le || (Le = pe(["text-base font-medium mb-3"]))),
    K = us({
        preDiscountTotal: {
            id: "teamBilling.nativeCurrency.preDiscountTotal",
            defaultMessage: "{amount}"
        },
        breakdownAmount: {
            id: "teamBilling.nativeCurrency.breakdownAmount",
            defaultMessage: "{amount}/seat"
        },
        temporaryCardHoldAmount: {
            id: "promo.teamFreeTrial.temporaryCardHoldAmountWithFormattedCurrency",
            defaultMessage: "{amount}"
        },
        discountAmount: {
            id: "teamBilling.nativeCurrency.discountAmount",
            defaultMessage: "{amount}"
        },
        promoCodeApplied: {
            id: "teamBilling.nativeCurrency.promoCodeApplied",
            defaultMessage: "Promo code {promoCode} applied"
        },
        totalAmount: {
            id: "teamBilling.nativeCurrency.totalAmount",
            defaultMessage: "{currencyCode} {totalAmount}"
        },
        afterPromoAmount: {
            id: "promo.teamFreeTrial.afterPromoAmountWithFormattedCurrency",
            defaultMessage: "After promotional period {amount} per month"
        }
    }),
    Ls = ({
        isOpen: t,
        onClose: n,
        onSubmit: i,
        minimumSeats: w,
        billingDetails: C,
        isDirectFlow: l = !1,
        promoData: s = void 0,
        promoDataIsFromQueryParam: d = void 0,
        promoMetadata: g = void 0,
        promoCode: r = void 0
    }) => {
        const a = ne(),
            {
                trackSelectedPixels: y
            } = ke({
                key: vs.SELF_SERVE_BUSINESS
            }),
            {
                trackSelectedPixels: x
            } = ke({
                key: "team-secondary"
            }),
            {
                selectedPlan: o,
                setSelectedPlan: S,
                numSeats: _,
                setNumSeats: M,
                minTeamSeats: H,
                TEAM_FREE_TRIAL_COUPON_IsEligible: $
            } = As({
                promoData: s,
                promoDataIsFromQueryParam: d
            }),
            [m, T] = F.useState(!1),
            B = me(),
            h = de(),
            {
                data: p,
                isLoading: E,
                error: b
            } = He({
                ctx: B,
                countryCode: C.country,
                currency: C.currency
            }),
            N = C.currency,
            I = F.useMemo(() => p ? We(N, p) : null, [p, N]),
            v = Math.max(w, H),
            W = (s == null ? void 0 : s.coupon) === te,
            j = (s == null ? void 0 : s.state) === "not_eligible" && W,
            R = (s == null ? void 0 : s.state) === "temporary_disabled" && W,
            G = (s == null ? void 0 : s.state) === "offline" && W,
            k = Ts(isNaN(_) ? 0 : _, v, Ps),
            V = F.useMemo(() => a == null ? void 0 : a.subscriptionAnalyticsParams, [a]),
            A = js(u => u.purchaseWorkspaceData);
        F.useEffect(() => {
            var L;
            const u = (L = A == null ? void 0 : A.referrer) != null ? L : document.referrer;
            Z.logEvent("Account Pay: Select Team Plan Modal Show", f(c({}, V), {
                referrer: u
            }))
        }, [V, A == null ? void 0 : A.referrer]);
        const fe = u => {
                switch (u) {
                    case "month":
                        Z.logEvent("Account Pay: Team Plan Selection Clicked", f(c({}, V), {
                            buttonType: "Continue",
                            numberOfSeats: _,
                            planLength: Me.MONTHLY
                        }));
                        break;
                    case "year":
                        Z.logEvent("Account Pay: Select Team Plan Modal Clicked", f(c({}, V), {
                            buttonType: "Continue",
                            numberOfSeats: _,
                            planLength: Me.ANNUAL
                        }));
                        break
                }
            },
            Ke = (u, L) => {
                Z.logEventWithStatsig("Account Pay: Select Team Plan Modal Clicked", "chatgpt_select_team_plan_modal_continue_to_billing_clicked", f(c({}, V), {
                    buttonType: "Continue",
                    numberOfSeats: L,
                    planLength: u
                })), Ve.addAction("chatgpt_funnel.team_plan_modal_checkout_initiated", {
                    planLength: u,
                    numberOfSeats: L.toString(),
                    accountId: a == null ? void 0 : a.id
                }), (s == null ? void 0 : s.state) === "eligible" && W && Ss.logCouponApplied(s.coupon)
            },
            Ge = () => {
                Z.logEvent("Account Pay: Select Team Plan Modal Dismiss", V)
            },
            Y = Fe(),
            J = F.useMemo(() => Y.hash.split("#")[1] === ce, [Y.hash]);
        F.useEffect(() => {
            var Pe;
            const u = new URLSearchParams;
            u.set(ie, k.toString()), u.set(re, o), u.set("referrer", (Pe = A == null ? void 0 : A.referrer) != null ? Pe : document.referrer);
            const L = d && (s != null && s.coupon) ? s.coupon : null;
            L && u.set(le, L);
            const Te = l || J ? "#".concat(ce) : "#".concat(Oe),
                De = "".concat(Y.pathname, "?").concat(u.toString()).concat(Te),
                ee = new URL(window.location.href).searchParams,
                es = ee.get(ie) === k.toString(),
                ss = ee.get(re) === o,
                ts = L == null && !ee.has(le) || ee.get(le) === L,
                ns = window.location.hash === Te;
            (!es || !ss || !ts || !ns) && window.history.pushState({
                from: Y.pathname + Y.search
            }, "", De)
        }, [k, l, J, Y.pathname, Y.search, Y.hash, o, s == null ? void 0 : s.coupon, d, A == null ? void 0 : A.referrer]);
        const U = !!g && o === "month";
        if (E || b != null || p == null || I == null) return null;
        const {
            flexibleBillingPlan: ze,
            annualBillingPlan: ge
        } = I;
        let Q = ze,
            D = null;
        if ($ && p.currencyConfig.promos.business_free_trial.enabled && !U) {
            D = Xe();
            const u = c({}, X.teamFreeTrialMonthlyCost),
                L = f(c({}, X.teamFreeTrialMonthlyStructure), {
                    defaultMessage: "Then ".concat(h.formatMessage(Q.currencySign)).concat(Q.monthlyCost, " seat/mo after 1 month"),
                    id: "promo.teamFreeTrial.monthlyPlanStructure",
                    description: "Subsequent pricing description for teamFreeTrial promo. Describing the monthly then the annual price after."
                });
            Q = f(c({}, Q), {
                cost: u,
                costStructure: L,
                discountedMonthlyCost: D != null ? D : Q.discountedMonthlyCost
            })
        }
        let z;
        j ? z = X.teamFreeTrialNotEligible : R ? z = X.teamFreeTrialTemporarilyDisabled : z = X.teamFreeTrialOffline;
        const he = j || R || G,
            xe = async () => {
                T(!0), Ke(o, k), y(), x(), await i(o, k), T(!1)
            },
            Ze = () => {
                n(), Ge()
            },
            ae = !(l || J) && Es(B, "2307162844").get("enabled", !1),
            ye = e.jsx(Fs, {
                numSeats: k,
                selectedPlan: o,
                billingDetails: C,
                totalLabel: O.allPlansTodayTotal,
                billDate: e.jsx(P, c({}, O.today)),
                promoData: s,
                shouldApplyPromoMetadata: U,
                promoMetadata: U ? g : void 0,
                promoCode: U ? r : void 0
            }),
            q = $;
        if (l || J || ae) return e.jsx(we, {
            testId: "modal-workspace-purchase",
            type: "success",
            isOpen: t,
            onClose: n,
            size: "fullscreen",
            noPadding: !0,
            removePopoverStyling: !0,
            showCloseButton: !0,
            children: e.jsxs("div", {
                className: "grid grid-flow-row grid-cols-1 md:h-full md:grid-cols-2",
                children: [e.jsx("div", {
                    className: "flex-column col-span-1 flex justify-center p-5 md:grid-cols-2",
                    children: e.jsxs("div", {
                        className: "flex w-full max-w-[400px] flex-col items-center md:max-w-[600px]",
                        children: [e.jsx(Ns, {
                            className: "mt-8 mb-6 h-8 w-8 md:fixed md:start-4 md:top-4 md:mt-0 md:h-6 md:w-6"
                        }), he && e.jsx("div", {
                            className: "mb-4 w-full",
                            "data-testid": "team-promo-banner",
                            children: e.jsx(ve, {
                                content: h.formatMessage(z),
                                type: "info"
                            })
                        }), e.jsx("div", {
                            className: "mb-8 text-3xl font-medium md:mt-[120px]",
                            children: e.jsx(P, {
                                id: "selectTeamPlanModal.title",
                                defaultMessage: "Pick your plan"
                            })
                        }), e.jsxs(je, {
                            className: ue("col-span-3 mb-6 grid w-full gap-4 md:col-span-2 md:grid-cols-2"),
                            defaultValue: o,
                            onValueChange: u => {
                                Be(u) && (S(u), fe(u))
                            },
                            children: [e.jsx(se, f(c({
                                billingType: "year"
                            }, ge), {
                                selectedValue: o,
                                hideSavingsMessage: q || U,
                                hideDetails: !ae
                            })), e.jsx(se, f(c({
                                billingType: "month"
                            }, Q), {
                                selectedValue: o,
                                hideDetails: !ae,
                                hideSavingsMessage: q || U,
                                showWelcomeOfferLabel: q && !U
                            }))]
                        }), e.jsx(Ee, {
                            numSeats: _,
                            minSeats: v,
                            setNumSeats: M
                        }), e.jsx("div", {
                            className: "text-token-text-secondary self-start text-xs",
                            children: h.formatMessage({
                                id: "selectTeamPlanModal.seatsDescription",
                                defaultMessage: "Add more seats at any time. Minimum of {minSeats} seats."
                            }, {
                                minSeats: H
                            })
                        })]
                    })
                }), e.jsx("div", {
                    className: "col-span-3 flex h-full flex-col items-center overflow-hidden p-6 md:col-span-1 md:shadow-lg",
                    children: e.jsxs("div", {
                        className: "flex w-full max-w-[400px] flex-col md:mt-[120px]",
                        children: [e.jsx(Ae, {
                            className: "mb-8 text-xl font-medium",
                            children: e.jsx(P, c({}, O.summaryTitle))
                        }), ye, e.jsx(oe, {
                            title: h.formatMessage(O.continueToBillingButton),
                            onClick: xe,
                            loading: m,
                            color: "green",
                            className: "mt-8 w-full rounded-xl"
                        }), e.jsx(oe, {
                            title: h.formatMessage(O.cancel),
                            onClick: Ze,
                            color: "ghost",
                            className: "mt-4 w-full rounded-xl"
                        })]
                    })
                })]
            })
        });
        const Je = Qe;
        return e.jsxs(we, {
            testId: "modal-select-team-plan",
            type: "success",
            isOpen: t,
            onClose: n,
            size: "custom",
            noPadding: !0,
            removePopoverStyling: !0,
            className: "max-w-4xl",
            showCloseButton: !0,
            hasSeparator: !0,
            title: h.formatMessage(O.selectTeamPlanModalTitle),
            children: [he && e.jsx("div", {
                className: "px-5 pt-4",
                "data-testid": "team-promo-banner",
                children: e.jsx(ve, {
                    content: h.formatMessage(z),
                    type: "info"
                })
            }), e.jsxs("div", {
                className: "grid grid-flow-row grid-cols-3",
                children: [e.jsxs("div", {
                    className: "flex-column col-span-3 p-5 md:col-span-2 md:grid-cols-2",
                    children: [e.jsx(Ee, {
                        numSeats: _,
                        minSeats: v,
                        setNumSeats: M
                    }), W && (s == null ? void 0 : s.state) === "eligible" && o === "month" && _ > Je && e.jsx("div", {
                        className: "text-token-text-secondary mt-1 self-start text-xs",
                        "data-testid": "team-promo-overseats-disclaimer",
                        children: e.jsx(P, c({}, X.teamFreeTrialOverSeatsDisclaimer))
                    }), e.jsxs(je, {
                        className: ue("col-span-3 mt-5 grid gap-4 md:col-span-2 md:grid-cols-2"),
                        defaultValue: o,
                        onValueChange: u => {
                            Be(u) && (S(u), fe(u))
                        },
                        children: [e.jsx(se, f(c({
                            billingType: "year"
                        }, ge), {
                            selectedValue: o,
                            hideSavingsMessage: q || U
                        })), e.jsx(se, f(c({
                            billingType: "month"
                        }, Q), {
                            selectedValue: o,
                            hideSavingsMessage: q || U,
                            showWelcomeOfferLabel: q && !U
                        }))]
                    })]
                }), e.jsxs("div", {
                    className: "border-token-main-surface-tertiary bg-token-bg-elevated-secondary col-span-3 flex h-full flex-col overflow-hidden border-s p-6 md:col-span-1",
                    children: [e.jsx(Ae, {
                        children: e.jsx(P, c({}, O.summaryTitle))
                    }), ye, e.jsx(oe, {
                        title: h.formatMessage(O.continueToBillingButton),
                        onClick: xe,
                        loading: m,
                        color: "primary",
                        className: "mt-8 w-full rounded-xl"
                    })]
                })]
            })]
        })
    },
    Fs = ({
        numSeats: t,
        selectedPlan: n,
        billingDetails: i,
        totalLabel: w,
        billDate: C,
        promoData: l,
        extraDiscountAmount: s,
        nonZeroDiscountClassName: d = "text-[#10A37F]",
        footerNote: g,
        shouldApplyPromoMetadata: r,
        promoMetadata: a,
        promoCode: y
    }) => {
        const x = me(),
            o = de(),
            S = F.useCallback(j => o.formatNumber(j, {
                style: "currency",
                currency: i.currency,
                currencyDisplay: "narrowSymbol",
                trailingZeroDisplay: "stripIfInteger"
            }), [i.currency, o]),
            {
                data: _,
                isLoading: M,
                error: H
            } = He({
                ctx: x,
                countryCode: i.country,
                currency: i.currency
            });
        if (M || H != null || !_) return null;
        const {
            flexibleBillingPlan: $,
            annualBillingPlan: m
        } = We(i.currency, _), T = $, B = n === "month" ? T : m, h = Cs[n], p = (t || 0) * (n === "year" ? m.monthlyCost * 12 : T.monthlyCost);
        let E = (t || 0) * B.unitCost,
            b = p - E,
            N = 0,
            I = p,
            v = !1;
        const W = (l == null ? void 0 : l.coupon) === te && _.currencyConfig.promos.business_free_trial.enabled;
        if (r && a) {
            const j = a.discount;
            let R = null,
                G = null;
            if ("percentage" in j && typeof j.percentage == "number" ? R = T.monthlyCost * (1 - j.percentage / 100) : "value" in j && j.currency_code === i.currency && (G = j.value), R != null && !Number.isNaN(R)) {
                const k = R * (t || 0);
                b = p - k, E = k, N = k
            } else if (G != null) {
                const k = Math.min(p, G),
                    V = p - k;
                b = k, E = V, N = V
            }
            I = t * T.monthlyCost, v = a.duration != null
        }
        if (l != null && W && l.state === "eligible" && n === "month" && !r) {
            v = !0;
            const j = Xe(),
                R = Qe;
            t <= R ? (N = j, I = t * T.monthlyCost, b = I - N, E = N) : (N = j + (t - R) * T.monthlyCost, I = t * T.monthlyCost, b = I - N, E = N)
        }
        return s && s > 0 && (b += s, E = Math.max(E - s, 0)), e.jsxs("div", {
            className: "flex grow flex-col text-sm",
            children: [e.jsxs("div", {
                className: "text-token-text-secondary flex w-full justify-between text-sm",
                children: [e.jsx("div", {
                    className: "flex",
                    children: e.jsx(P, c({}, h.name))
                }), e.jsx("div", {
                    className: "flex",
                    children: e.jsx(P, f(c({}, K.preDiscountTotal), {
                        values: {
                            amount: S(p)
                        }
                    }))
                })]
            }), e.jsxs("div", {
                className: "text-token-text-tertiary flex w-full justify-between text-xs",
                children: [e.jsx("div", {
                    className: "flex",
                    children: e.jsx(P, f(c({}, h.breakdown), {
                        values: {
                            numSeats: t
                        }
                    }))
                }), e.jsx("div", {
                    className: "flex",
                    children: e.jsx(P, f(c({}, K.breakdownAmount), {
                        values: {
                            amount: S(B.monthlyCost)
                        }
                    }))
                })]
            }), e.jsxs("div", {
                className: "text-token-text-secondary mt-3 flex w-full justify-between text-sm",
                children: [e.jsx("div", {
                    className: "flex",
                    children: e.jsx(P, c({}, O.planDiscountLabel))
                }), e.jsx("div", {
                    className: ue("flex", b > 0 && "font-medium", b > 0 && d),
                    children: e.jsx(P, f(c({}, K.discountAmount), {
                        values: {
                            amount: S(-b)
                        }
                    }))
                })]
            }), (l == null ? void 0 : l.coupon) === te && l.state === "eligible" && n === "month" && !r && e.jsx("div", {
                className: "text-token-text-tertiary text-xs",
                children: e.jsx(P, c({}, X.teamFreeTrialBelowDiscount))
            }), r && (a == null ? void 0 : a.summary) && e.jsx("div", {
                className: "text-token-text-tertiary text-xs",
                children: a.summary
            }), r && y && e.jsx("div", {
                className: "text-token-text-tertiary text-xs",
                children: e.jsx(P, f(c({}, K.promoCodeApplied), {
                    values: {
                        promoCode: y
                    }
                }))
            }), h.discountDescription && m.discountedMonthlyCost < m.monthlyCost && n === "year" && e.jsx("div", {
                className: "text-token-text-tertiary text-xs",
                children: e.jsx(P, f(c({}, h.discountDescription), {
                    values: {
                        discountPercentage: bs(m.monthlyCost, m.discountedMonthlyCost)
                    }
                }))
            }), e.jsx("hr", {
                className: "border-token-border-default my-3"
            }), e.jsxs("div", {
                className: "flex w-full justify-between text-base font-medium",
                "data-testid": "team-billing-total-row",
                children: [e.jsx("div", {
                    className: "flex",
                    children: e.jsx(P, c({}, w))
                }), e.jsx("div", {
                    className: "flex",
                    children: v ? e.jsxs(e.Fragment, {
                        children: [o.formatMessage(B.currencyCode), " ", S(E)]
                    }) : e.jsx(P, f(c({}, K.totalAmount), {
                        values: {
                            currencyCode: o.formatMessage(B.currencyCode),
                            totalAmount: S(E)
                        }
                    }))
                })]
            }), e.jsxs("div", {
                className: "text-token-text-tertiary mt-2 text-xs",
                children: [v ? e.jsx(P, f(c({}, K.afterPromoAmount), {
                    values: {
                        amount: S(I)
                    }
                })) : e.jsx(P, f(c({}, h.billed), {
                    values: {
                        billDate: C
                    }
                })), g && e.jsx("div", {
                    className: "mt-1",
                    children: g
                })]
            })]
        })
    },
    Is = ({
        billingDetails: t,
        existingAccount: n,
        promoData: i,
        promoDataIsFromQueryParam: w,
        promoMetadata: C,
        promoCode: l
    }) => {
        const s = de(),
            d = _s(),
            g = ps(),
            {
                prepareCheckoutSession: r,
                navigateToCheckout: a
            } = xs(),
            y = me(),
            x = ne(),
            o = n != null ? n : x && x.isFreeWorkspace() ? x : void 0,
            [S] = cs(),
            _ = S.get("from_webview") === "ios",
            M = ds(s, o, g),
            {
                eligible: H,
                campaignId: $
            } = ys();
        let m, T = !1;
        return i ? (m = i, T = !!w) : H && !C && !l && (m = {
            coupon: $,
            state: "eligible",
            redemption: null
        }, T = !1), {
            effectivePromoData: m,
            handleBusinessCheckoutRedirect: async (h, p, E = !1) => {
                if (!ws()) {
                    Ms(y, {
                        fallbackScreenHint: "login",
                        callbackUrl: window.location.href
                    });
                    return
                }
                try {
                    const b = f(c({
                            plan_name: "chatgptteamplan",
                            team_plan_data: {
                                workspace_name: M,
                                price_interval: h,
                                seat_quantity: p,
                                existing_workspace_id: o == null ? void 0 : o.id
                            },
                            billing_details: t,
                            cancel_url: window.location.href,
                            promo_campaign: m != null && m.coupon && h === "month" ? {
                                promo_campaign_id: m == null ? void 0 : m.coupon,
                                is_coupon_from_query_param: T
                            } : void 0
                        }, E ? {} : {
                            checkout_ui_mode: "redirect"
                        }), {
                            promo_code: l && h === "month" ? l : void 0
                        }),
                        N = await r(b, {
                            fromiOSWebview: _
                        });
                    await a(N, {
                        checkoutPayload: b
                    })
                } catch (b) {
                    Ve.addError(b), d.warning(s.formatMessage(O.paymentErrorWarning), {
                        hasCloseButton: !0
                    })
                }
            }
        }
    },
    Gs = ({
        isOpen: t,
        onClose: n,
        minimumSeats: i,
        billingDetails: w,
        existingAccount: C = void 0,
        promoData: l = void 0,
        promoDataIsFromQueryParam: s = void 0,
        promoMetadata: d = void 0,
        promoCode: g = void 0
    }) => {
        const {
            handleBusinessCheckoutRedirect: r,
            effectivePromoData: a
        } = Is({
            billingDetails: w,
            existingAccount: C,
            promoData: l,
            promoDataIsFromQueryParam: s,
            promoMetadata: d,
            promoCode: g
        });
        return e.jsx(Ls, {
            isOpen: t,
            onClose: n,
            onSubmit: (y, x) => r(y, x),
            minimumSeats: i,
            billingDetails: w,
            promoData: a,
            promoDataIsFromQueryParam: a && l ? !!s : !1,
            promoMetadata: d != null ? d : void 0,
            promoCode: g != null ? g : void 0
        })
    };
export {
    Fs as B, qe as T, Is as a, Ks as b, Gs as c, Be as i, As as u
};
//# sourceMappingURL=3jqmuecsvur0aphg.js.map