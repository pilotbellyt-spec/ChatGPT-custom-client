const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/jzqwyo1dv0uuby2z.js", "assets/fg33krlcm0qyi6yw.js", "assets/kx34yg3blv92o8xp.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/fqdux96o99o6e1bu.js", "assets/f96c6fguu1kcw0go.js", "assets/cn8eg48nrtfdn3hv.js", "assets/hwa6pbq6i57ntwuh.js", "assets/k15yxxoybkkir2ou.js", "assets/conversation-small-332fs9rk.css", "assets/jdzosouyvpzu0tpb.js", "assets/hkq4ft1vs44iddnx.js", "assets/tm7b14kn4qjlarhq.js", "assets/nb22pb07i8ebbv0i.js", "assets/nbx32m643479bjub.js", "assets/jr50j1lqn6fa60e9.js", "assets/cehclh0a60ppuuvu.js", "assets/l0j9g4jqkm56icbn.js", "assets/nzjsohh941f1fuvy.js", "assets/c82q89wfy6odbwlp.js"]))) => i.map(i => d[i]);
var W = Object.defineProperty;
var M = Object.getOwnPropertySymbols;
var L = Object.prototype.hasOwnProperty,
    V = Object.prototype.propertyIsEnumerable;
var P = (s, t, o) => t in s ? W(s, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: o
    }) : s[t] = o,
    C = (s, t) => {
        for (var o in t || (t = {})) L.call(t, o) && P(s, o, t[o]);
        if (M)
            for (var o of M(t)) V.call(t, o) && P(s, o, t[o]);
        return s
    };
import {
    e as F,
    f as A,
    j as e,
    M as T,
    r as v,
    _ as E
} from "./fg33krlcm0qyi6yw.js";
import {
    m as D,
    l as O,
    i9 as H,
    T as Q,
    bX as G,
    a9 as B,
    C as X,
    bh as I,
    gF as q,
    _ as J,
    o as K,
    b as U,
    bv as Y
} from "./dykg4ktvbu3mhmdo.js";
import {
    u as S,
    r as Z
} from "./nzjsohh941f1fuvy.js";
import {
    hC as $,
    fu as ee,
    jS as se
} from "./k15yxxoybkkir2ou.js";
import {
    u as te
} from "./fyk9tph6baj60t7u.js";
import {
    d as oe
} from "./kl7c6054usfnqmd4.js";
import {
    F as R
} from "./jzwivbl10of3y0cy.js";
const b = A({
        downloadFileError: {
            id: "postSharingModal.downloadFileError",
            defaultMessage: "Failed to download file. Please try again later."
        },
        title: {
            id: "walnut.title",
            defaultMessage: "Preview"
        },
        tooltip: {
            id: "walnut.tooltip",
            defaultMessage: "This is a web preview and may not reflect exact formatting. Download to open in your preferred software for best results."
        }
    }),
    ae = ({
        onClose: s,
        onPlay: t,
        extension: o,
        contentType: a,
        clientThreadId: n,
        editHandlers: h
    }) => {
        var N;
        const l = F(),
            g = D(),
            w = a === "presentation",
            {
                formatMessage: u
            } = F(),
            r = u(b.title),
            m = u(b.tooltip),
            {
                focusedWalnutId: i,
                presentationMap: f
            } = S(),
            d = i ? f[i] : void 0,
            c = (N = d == null ? void 0 : d.fileName) != null ? N : a === "presentation" ? "presentation.pptx" : "spreadsheet.xlsx",
            x = !1,
            j = a === "spreadsheet",
            y = d == null ? void 0 : d.fileBlob,
            _ = l.formatMessage(b.downloadFileError),
            z = te(!1, n, i != null ? i : "", () => {}, () => {
                g.danger(_, {
                    toastId: "post_sharing_modal_download_error",
                    loggingTitle: _,
                    loggingDescription: "Error message when a file download fails"
                })
            });
        return e.jsxs("div", {
            className: O("text-token-text-secondary relative flex w-full items-center justify-between border-b px-3 py-1", x, j ? "border-token-border-heavy" : "border-token-border-light"),
            children: [e.jsxs("div", {
                className: "z-10 flex flex-row gap-2",
                children: [e.jsx($, {
                    onClick: s,
                    children: e.jsx(H, {})
                }), !1]
            }), e.jsxs("div", {
                className: "absolute start-1/2 top-1/2 flex -translate-x-1/2 -translate-y-1/2 items-center gap-1",
                children: [e.jsx(R, {
                    fileName: r != null ? r : null
                }), e.jsx("div", {
                    className: "text-token-text-primary flex flex-row items-center truncate text-sm font-medium",
                    children: e.jsx(Q, {
                        label: m,
                        theme: "white",
                        defaultOpen: !0,
                        customBackgroundColorClassName: "bg-[#6B91F1]",
                        labelClassName: "text-white font-light",
                        side: "bottom",
                        disabled: x,
                        children: e.jsxs("div", {
                            className: "flex flex-row items-center",
                            children: [e.jsxs("div", {
                                className: "flex flex-row items-center gap-2",
                                children: [e.jsx(R, {
                                    fileName: c
                                }), c]
                            }), e.jsx(G, {
                                className: "ms-1 size-4"
                            })]
                        })
                    })
                }), o && e.jsx("div", {
                    className: "text-token-text-tertiary ms-2 text-sm",
                    children: o
                })]
            }), e.jsxs("div", {
                className: "z-10 flex items-center gap-1",
                children: [!1, e.jsx(B, {
                    color: "ghost",
                    size: "small",
                    onClick: async () => {
                        if (y) oe(y, c);
                        else {
                            const {
                                data: p
                            } = await z.refetch();
                            if (p === void 0 || (p == null ? void 0 : p.status) !== "success") {
                                g.danger(_, {
                                    toastId: "post_sharing_modal_download_error",
                                    loggingTitle: _,
                                    loggingDescription: "Error message when a file download fails"
                                });
                                return
                            }
                            const k = document.createElement("a");
                            k.href = p.download_url, k.click()
                        }
                    },
                    children: e.jsx(ee, {})
                }), w && e.jsx(B, {
                    color: "primary",
                    onClick: t,
                    size: "small",
                    children: e.jsxs("div", {
                        className: "flex items-center gap-1",
                        children: [e.jsx(se, {}), e.jsx("span", {
                            className: "hidden sm:block",
                            children: e.jsx(T, {
                                id: "walnut.play",
                                defaultMessage: "Play Slideshow"
                            })
                        })]
                    })
                })]
            })]
        })
    },
    re = I(() => E(() =>
        import ("./jzqwyo1dv0uuby2z.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14])).then(s => s.CanvasRenderer)),
    ne = I(() => E(() =>
        import ("./nbx32m643479bjub.js"), __vite__mapDeps([15, 1, 3, 4, 13, 6, 7, 8, 9, 10, 14, 16, 17, 18, 19])).then(s => s.SpreadsheetRenderer)),
    le = I(() => E(() =>
        import ("./c82q89wfy6odbwlp.js"), __vite__mapDeps([20, 1, 3, 4, 19, 5, 6, 7, 8, 9, 10])).then(s => s.Slideshow));

function ie({
    isOpen: s,
    onClose: t,
    clientThreadId: o
}) {
    const [a, n] = v.useState(!1), {
        presentationMap: h,
        focusedWalnutId: l,
        setSelectedSlideIdx: g
    } = S(), [w, u] = v.useState(!1), r = l ? h[l] : null, {
        presentation: m,
        fileName: i,
        workbook: f,
        document: d
    } = r != null ? r : {};
    if (!l || !r) return null;
    const c = m ? "presentation" : f ? "spreadsheet" : "none",
        x = c === "presentation" && m && !a,
        j = c === "spreadsheet" && f && !a;
    return e.jsx(X, {
        testId: "modal-walnut-content",
        type: "success",
        size: "fullscreen",
        isOpen: s,
        onClose: t,
        visuallyHiddenHeader: !0,
        children: e.jsxs("div", {
            className: "flex h-full flex-col overflow-hidden",
            children: [e.jsx(ae, {
                onClose: t,
                onPlay: () => n(!a),
                title: i,
                contentType: c,
                clientThreadId: o,
                canEdit: !1
            }), x && e.jsx(re, {
                presentation: m,
                selectedSlideIdx: r.selectedSlideIdx,
                setSelectedSlideIdx: y => g(l, y),
                isEditing: w,
                setIsEditing: u
            }), j && e.jsx(ne, {
                workbook: f,
                selectedSheetIdx: r.selectedSheetIdx,
                isEditing: w,
                setIsEditing: u
            }), !1, a && e.jsx(le, {
                startIndex: 0,
                onExit: t,
                walnutId: l
            }), !x && !j && !0 && !a && e.jsx("div", {
                className: "flex h-full w-full items-center justify-center",
                children: e.jsx(T, {
                    id: "walnut.noFile",
                    defaultMessage: "No file selected."
                })
            })]
        })
    })
}
const de = ({
        clientThreadId: s
    }) => {
        const {
            isOpen: t,
            close: o
        } = S(), a = U(), n = K(a, "2400755524"), h = t ? e.jsx(ie, {
            isOpen: t,
            onClose: o,
            clientThreadId: s,
            trailmixEnabled: n
        }) : null;
        return e.jsx(Y, {
            children: h
        }, s)
    },
    we = s => {
        const t = v.useRef(null);
        return e.jsx(q, {
            ref: t,
            onError: (o, a) => {
                Z(), setTimeout(() => {
                    var n;
                    (n = t.current) == null || n.resetErrorBoundary()
                }), J.addError(o, {
                    componentStack: a
                })
            },
            name: "walnut-focused-view",
            children: e.jsx(de, C({}, s))
        })
    };
export {
    we as WalnutFocusedViewManager
};
//# sourceMappingURL=mzj1f1z14g1kybwx.js.map