import {
    c as e,
    s
} from "./dykg4ktvbu3mhmdo.js";
const o = e(s, "0546e0", 20, 20);
export {
    o as D
};
//# sourceMappingURL=djur71wanhd4j63t.js.map