var N = Object.defineProperty;
var T = Object.getOwnPropertySymbols;
var _ = Object.prototype.hasOwnProperty,
    M = Object.prototype.propertyIsEnumerable;
var S = (e, t, s) => t in e ? N(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : e[t] = s,
    c = (e, t) => {
        for (var s in t || (t = {})) _.call(t, s) && S(e, s, t[s]);
        if (T)
            for (var s of T(t)) M.call(t, s) && S(e, s, t[s]);
        return e
    };
import {
    mS as w,
    bg as d,
    l as C,
    T as b,
    P as A,
    dI as O
} from "./dykg4ktvbu3mhmdo.js";
import {
    g as P
} from "./coi95al0vrqe13ds.js";
import {
    hk as r,
    j1 as I,
    jY as D,
    jZ as L
} from "./k15yxxoybkkir2ou.js";
import {
    i as V
} from "./ns51nblw8ziscsgd.js";
import {
    f as F,
    r as y,
    j as a,
    M as p
} from "./fg33krlcm0qyi6yw.js";
import {
    N as H
} from "./ce3hgmw4iyyhicud.js";
import {
    u as B
} from "./l09h2qppleubii6l.js";

function v(e) {
    return e.includes("'react'") || e.includes('"react"')
}

function W(e, t) {
    switch (e) {
        case r.CODE_HTML:
        case r.CODE_REACT:
            return !0;
        case r.CODE_JAVASCRIPT:
        case r.CODE_TYPESCRIPT:
            return v(t);
        default:
            return !1
    }
}

function Z(e) {
    return w([r.CODE_PYTHON], e)
}

function X(e, t) {
    var n;
    let s = (n = P(e)) != null ? n : null;
    return (v(t) || e === r.CODE_REACT) && (s = "react"), s && V(s) ? s : null
}

function $({
    isDisabled: e = !1,
    isCodePreviewable: t = !1,
    isCodeRunning: s,
    disabledTooltip: n,
    clientThreadId: l,
    onClick: u
}) {
    const [m, g] = y.useState(s), [{
        width: i
    }, E] = B();
    y.useEffect(() => {
        let h = null;
        return !s || t ? g(s) : (h = setTimeout(() => {
            g(s)
        }, 200), () => clearTimeout(h))
    }, [s, t]);
    const j = () => ({
            conversation_id: l ? O(l) : void 0
        }),
        R = () => {
            A.logEventWithStatsig("Canvas Run Code Button Clicked", "chatgpt_canvas_run_code_button_clicked", j()), setTimeout(() => u == null ? void 0 : u())
        },
        f = a.jsx(d.button, {
            disabled: e || s && !m,
            onClick: R,
            className: C("btn btn-primary ms-1 rounded-full sm:min-w-28", m ? C(H, "border-transparent") : "hover:bg-opacity-90"),
            animate: {
                width: i != null ? i : 0
            },
            initial: {
                width: i != null ? i : 0
            },
            transition: {
                type: "spring",
                bounce: .24,
                duration: .4
            },
            children: a.jsx("div", {
                ref: E,
                children: m ? a.jsxs(d.div, {
                    className: "flex items-center gap-1.5 ps-1 pe-1 sm:ps-2 sm:pe-2",
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    exit: {
                        opacity: 0
                    },
                    transition: {
                        duration: .3
                    },
                    children: [a.jsx(I, {
                        className: "icon"
                    }), a.jsx("span", {
                        className: "hidden sm:inline",
                        children: a.jsx(p, c({}, o.stopCode))
                    })]
                }) : a.jsxs(d.div, {
                    className: "flex items-center gap-1.5 ps-1 pe-1 sm:ps-2 sm:pe-2",
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    exit: {
                        opacity: 0
                    },
                    transition: {
                        duration: .3
                    },
                    children: [a.jsx(D, {
                        className: "icon"
                    }), a.jsx("span", {
                        className: "hidden whitespace-nowrap sm:inline",
                        children: a.jsx(p, c({}, t ? o.previewCode : o.runCode))
                    })]
                })
            })
        }),
        x = e && n ? n : s ? null : a.jsx(p, c({}, t ? o.previewCodeTooltip : o.runCodeTooltip));
    return x ? a.jsx(b, {
        label: x,
        children: f
    }) : f
}
const o = F({
    previewCode: {
        id: "M1TBxe",
        defaultMessage: "Preview"
    },
    runCode: {
        id: "LiKr5n",
        defaultMessage: "Run code"
    },
    stopCode: {
        id: "nCwG4+",
        defaultMessage: "Stop"
    },
    runCodeTooltip: {
        id: "UeNB/S",
        defaultMessage: "See output and debug"
    },
    previewCodeTooltip: {
        id: "/qJKMH",
        defaultMessage: "Preview in canvas"
    }
});
class Y {
    constructor(t) {
        this.params = t
    }
    get isReadonly() {
        return Object.values(this.params).some(t => !!t)
    }
    get isHistoricalVersion() {
        return !!this.params.isHistoricalVersion
    }
    get isStreaming() {
        return !!this.params.isTextdocStreaming || !!this.params.isRequestActive
    }
    get isTextdocStreaming() {
        return !!this.params.isTextdocStreaming
    }
    get isStreamingFromNative() {
        return this.isStreaming && this.params.streamingSource === L.NATIVE
    }
    get isRestoring() {
        return !!this.params.isRestoring
    }
    get isShowingChanges() {
        return !!this.params.isShowingChanges
    }
    get isReadonlyFromQueryParam() {
        return !!this.params.isReadonlyFromQueryParam
    }
}
const ee = e => new Y(e);
export {
    $ as T, ee as a, Z as b, X as g, W as i, o as m
};
//# sourceMappingURL=eo73z75xc7fd61fn.js.map