var E = Object.defineProperty,
    h = Object.defineProperties;
var T = Object.getOwnPropertyDescriptors;
var c = Object.getOwnPropertySymbols;
var x = Object.prototype.hasOwnProperty,
    O = Object.prototype.propertyIsEnumerable;
var o = (a, t, r) => t in a ? E(a, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : a[t] = r,
    A = (a, t) => {
        for (var r in t || (t = {})) x.call(t, r) && o(a, r, t[r]);
        if (c)
            for (var r of c(t)) O.call(t, r) && o(a, r, t[r]);
        return a
    },
    v = (a, t) => h(a, T(t));
import {
    A as U
} from "./lfdsdf4it937c4a2.js";
import {
    o as V,
    p as S,
    m as y,
    l as I,
    j as g
} from "./mvl4u7g4pep6uysr.js";
import {
    S as F,
    a as k,
    A as f
} from "./ma6fexe1cysk08ib.js";
import {
    cg as n,
    az as m,
    ck as _,
    c8 as b
} from "./k15yxxoybkkir2ou.js";
import {
    S as P
} from "./mh2edg92ng3qntdf.js";
import {
    g as R,
    a as B,
    b as N,
    c as G,
    p as e,
    d as L,
    e as D,
    f as j,
    h as z,
    i as H,
    j as K,
    k as M,
    l as q,
    m as w,
    n as J,
    o as Q
} from "./by32wbrf3h6krwuu.js";
import {
    V as u
} from "./dykg4ktvbu3mhmdo.js";

function se(a) {
    const t = a == null ? void 0 : a.shouldUseOutcomeValueProps,
        r = t ? J() : Q(),
        s = t ? e.freeOutcome.headline : e.freeRedesign.headline;
    return {
        name: e.free.freeName,
        callToAction: {
            active: a != null && a.shouldUseOnboardingFeatures ? e.free.freeCTA_UnifiedAccountCreation_Experiment : e.free.freeCTA,
            create: a != null && a.shouldUseOnboardingFeatures ? e.free.freeCTA_UnifiedAccountCreation_Experiment : e.free.freeCTA,
            inactive: a != null && a.shouldUseOnboardingFeatures ? e.free.freeCTA_UnifiedAccountCreation_Experiment : e.free.freeCTA
        },
        summary: s,
        cost: {
            costValue: 0,
            costTitle: e.free.freeCost
        },
        advertisedFeatures: r
    }
}

function W({
    isCheckoutRedesign: a,
    ctx: t,
    isFreeTrial: r
}) {
    const s = !a && u(t, "1656913255").get("outcome_value_props_enabled", !1),
        i = R(),
        l = B(),
        C = N(),
        p = G();
    let d;
    return r ? d = p : a ? d = l : s ? d = C : d = i, {
        name: e.plus.plusName,
        callToAction: {
            active: e.plus.plusActive,
            create: e.plus.plusActive,
            inactive: e.plus.plusInactive,
            inactiveUnauthenticated: e.plus.plusInactiveUnauthenticated
        },
        summary: s ? e.plusOutcome.headline : e.plusRedesign.headline,
        advertisedFeatures: d
    }
}

function ie(a) {
    const t = a == null ? void 0 : a.isCheckoutRedesign,
        r = a == null ? void 0 : a.isOutcomeValuePropsEnabled,
        s = a == null ? void 0 : a.isFreeTrial;
    let i;
    s ? i = M() : t ? i = q() : r ? i = w() : i = [{
        label: e.team.teamAdvertisedFeatures0,
        icon: n
    }, {
        label: e.team.teamAdvertisedFeatures1,
        icon: F
    }, {
        label: e.team.teamAdvertisedFeatures2,
        icon: m
    }, {
        label: e.team.teamAdvertisedFeatures3,
        icon: V
    }, {
        label: e.team.teamAdvertisedFeatures4,
        icon: _
    }, {
        label: e.team.teamAdvertisedFeatures5,
        icon: S
    }, {
        label: e.team.teamAdvertisedFeatures6,
        icon: b
    }], !r && !t && (a != null && a.isBusinessUpgradeV2CopyEnabled) && (i = [{
        label: e.team.teamAdvertisedFeatures0_ComparisonV2_Experiment,
        icon: n
    }, {
        label: e.team.teamAdvertisedFeatures1_ComparisonV2_Experiment,
        icon: y
    }, {
        label: e.team.teamAdvertisedFeatures2_ComparisonV2_Experiment,
        icon: m
    }, {
        label: e.team.teamAdvertisedFeatures3_ComparisonV2_Experiment,
        icon: P
    }, {
        label: e.team.teamAdvertisedFeatures4_ComparisonV2_Experiment,
        icon: U
    }, {
        label: e.team.teamAdvertisedFeatures5_ComparisonV2_Experiment,
        icon: I
    }, {
        label: e.team.teamAdvertisedFeatures6_ComparisonV2_Experiment,
        icon: g
    }, {
        label: e.team.teamAdvertisedFeatures7_ComparisonV2_Experiment,
        icon: k
    }, {
        label: e.team.teamAdvertisedFeatures8_ComparisonV2_Experiment,
        icon: f
    }, {
        label: e.team.teamAdvertisedFeatures9_ComparisonV2_Experiment,
        icon: b
    }]), !r && !t && (a != null && a.shouldUseOnboardingFeatures) && (i = [{
        label: e.team.teamAdvertisedFeatures0_UnifiedAccountCreation_Experiment,
        icon: n
    }, {
        label: e.team.teamAdvertisedFeatures1_UnifiedAccountCreation_Experiment,
        icon: P
    }, {
        label: e.team.teamAdvertisedFeatures2_UnifiedAccountCreation_Experiment,
        icon: _
    }, {
        label: e.team.teamAdvertisedFeatures3_UnifiedAccountCreation_Experiment,
        icon: F
    }, {
        label: e.team.teamAdvertisedFeatures4_UnifiedAccountCreation_Experiment,
        icon: f
    }, {
        label: e.team.teamAdvertisedFeatures5_UnifiedAccountCreation_Experiment,
        icon: g
    }, {
        label: e.team.teamAdvertisedFeatures6_UnifiedAccountCreation_Experiment,
        icon: m
    }]);
    let l = e.team.teamPlanSummary;
    return r ? l = e.teamOutcome.headline : a != null && a.isBusinessUpgradeV2CopyEnabled ? l = e.team.teamPlanSummary_V2 : a != null && a.shouldUseOnboardingFeatures && (l = e.team.teamPlanSummary_UnifiedAccountCreation_Experiment), {
        name: e.team.teamPlanName,
        summary: l,
        disclaimer: e.team.teamPricingDisclaimer,
        disclaimer2: e.team.teamPricingDisclaimer2,
        advertisedFeatures: i,
        callToAction: {
            active: e.team.teamPlanActive,
            create: e.team.teamPlanCreate,
            inactive: a != null && a.shouldUseOnboardingFeatures && (a != null && a.isTrialEnabled) ? e.team.teamPlanInactive_UnifiedAccountCreation_Experiment : e.team.teamPlanInactive
        }
    }
}

function le({
    isCheckoutRedesign: a,
    ctx: t
}) {
    const r = !a && u(t, "1656913255").get("outcome_value_props_enabled", !1),
        s = a ? L() : r ? D() : j();
    return {
        name: e.pro.proName,
        callToAction: {
            active: e.pro.proActive,
            create: e.pro.proActive,
            inactive: e.pro.proInactive
        },
        summary: r ? e.proOutcome.headline : e.proRedesign.headline,
        advertisedFeatures: s,
        disclaimer: e.pro.proPricingDisclaimer
    }
}
const de = ({
    ctx: a
}) => {
    const t = W({
        ctx: a
    });
    return v(A({}, t), {
        advertisedFeatures: [{
            label: e.plus.studentAdvertisedFeatures1
        }, {
            label: e.plus.studentAdvertisedFeatures2
        }, {
            label: e.plus.studentAdvertisedFeatures3
        }, {
            label: e.plus.studentAdvertisedFeatures4
        }]
    })
};

function ne({
    isCheckoutRedesign: a,
    ctx: t
}) {
    const r = !a && u(t, "1656913255").get("outcome_value_props_enabled", !1),
        s = a ? z() : r ? H() : K();
    return {
        name: e.go.goName,
        callToAction: {
            active: e.go.goCTAActive,
            create: e.go.goCTAActive,
            inactive: e.go.goCTA,
            promo: e.go.goCTAPromo
        },
        summary: r ? e.goOutcome.headline : e.goRedesign.headline,
        advertisedFeatures: s
    }
}
export {
    W as a, le as b, ne as c, se as d, de as e, ie as g
};
//# sourceMappingURL=hfibvokhkz8skuqw.js.map