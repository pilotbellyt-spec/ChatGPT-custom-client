var Ws = Object.defineProperty,
    Hs = Object.defineProperties;
var Ys = Object.getOwnPropertyDescriptors;
var ss = Object.getOwnPropertySymbols;
var $s = Object.prototype.hasOwnProperty,
    Vs = Object.prototype.propertyIsEnumerable;
var os = (t, e, s) => e in t ? Ws(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : t[e] = s,
    O = (t, e) => {
        for (var s in e || (e = {})) $s.call(e, s) && os(t, s, e[s]);
        if (ss)
            for (var s of ss(e)) Vs.call(e, s) && os(t, s, e[s]);
        return t
    },
    $ = (t, e) => Hs(t, Ys(e));
import {
    e as mt,
    j as a,
    f as qe,
    c as Re,
    M as X,
    L as Ae,
    d as Ks,
    m as vs,
    r as V,
    b as Yt,
    n as Ms,
    i as Ts,
    E as xs,
    S as qs
} from "./fg33krlcm0qyi6yw.js";
import {
    V as Se,
    b as pt,
    a9 as Ve,
    L as w,
    sA as Lt,
    N as ks,
    v2 as Qs,
    v3 as Zs,
    c_ as Js,
    T as Gt,
    qI as Ke,
    ad as kt,
    P as pe,
    m as Xs,
    o as Es,
    es as Pt,
    l as Ft,
    c0 as zt,
    C as $t,
    Z as eo,
    S as to,
    R as so,
    dh as Is,
    I as oo,
    _ as Fs,
    aK as ao,
    aP as no,
    i9 as io,
    ag as ro,
    ck as lo,
    v$ as co,
    bc as uo,
    bd as mo
} from "./dykg4ktvbu3mhmdo.js";
import {
    C as po
} from "./lfxtpzw52mtvoale.js";
import {
    G as go
} from "./m4js9idemp5c8b87.js";
import {
    S as fo
} from "./mcy89srphizz0hls.js";
import {
    d as ho,
    a as yo,
    b as Po,
    g as _o,
    c as So
} from "./hfibvokhkz8skuqw.js";
import {
    zQ as Vt,
    cg as Co,
    ch as bo,
    gC as vo,
    dg as ws,
    e7 as wt,
    ir as _t,
    is as St,
    iu as as,
    iw as Ct,
    hT as As,
    zR as Mo,
    iB as To,
    fU as dt,
    zS as xo,
    zT as Os,
    zU as Ls,
    zV as ko,
    e6 as Eo,
    iv as ns,
    hZ as Ns,
    kp as Mt,
    zH as Rs,
    zW as Io,
    gp as Fo,
    zX as wo,
    zY as js,
    it as is,
    zZ as Ao,
    zx as Oo,
    z_ as Ds,
    z$ as Lo,
    A0 as No,
    A1 as Ro,
    A2 as jo,
    an as Ne,
    qj as Do,
    db as Uo,
    jj as Go,
    dc as zo,
    ik as Bo,
    A3 as Wo,
    A4 as Ho,
    A5 as Yo,
    zv as $o,
    A6 as rs,
    A7 as ls,
    A8 as Vo
} from "./k15yxxoybkkir2ou.js";
import {
    a as gt,
    b as ye,
    g as Ko
} from "./kk75394dp7aj1ofk.js";
import {
    h as At,
    d as Us,
    g as cs,
    e as qo,
    i as Qo,
    f as Kt,
    j as xt,
    u as Gs,
    S as us,
    a as ds
} from "./jd9zt1u141h04j00.js";
import {
    A as Zo
} from "./lfdsdf4it937c4a2.js";
import {
    e as Jo,
    l as Xo
} from "./mvl4u7g4pep6uysr.js";
import {
    s as Et,
    t as ea,
    r as Bt
} from "./by32wbrf3h6krwuu.js";
import {
    g as ta
} from "./knmv36ayr157033d.js";
import {
    P as zs,
    g as sa,
    f as oa,
    M as aa,
    m as ut
} from "./hldjsmhvi0vrgsw0.js";
import {
    u as It
} from "./h8afdg57t22ai4ff.js";
import {
    E as Bs
} from "./9xukfjm3wk4gydlw.js";
import {
    u as na,
    a as ia
} from "./oi0jufgbruu7yg53.js";
import {
    u as ra,
    a as la
} from "./3jqmuecsvur0aphg.js";
import {
    u as ca,
    T as ua,
    t as Nt
} from "./n7nqkdn53j3o5j6k.js";

function da({
    value: t,
    onChange: e
}) {
    const s = mt();
    return a.jsx(fo, {
        value: t,
        onChange: e,
        ariaLabel: s.formatMessage(yt.toggleArialabel),
        leftItem: {
            ariaLabel: s.formatMessage(yt.togglePersonalArialabel),
            label: s.formatMessage(yt.togglePersonalLabel),
            value: "personal"
        },
        rightItem: {
            ariaLabel: s.formatMessage(yt.toggleBusinessArialabel),
            label: s.formatMessage(yt.toggleBusinessLabel),
            value: "business"
        }
    })
}
const yt = qe({
        toggleArialabel: {
            id: "U4v2Gf",
            defaultMessage: "Toggle for switching between Personal and Business plans"
        },
        togglePersonalArialabel: {
            id: "6Wikht",
            defaultMessage: "Toggle for switching to Personal plans"
        },
        toggleBusinessArialabel: {
            id: "uzlEV0",
            defaultMessage: "Toggle for switching to Business plans"
        },
        togglePersonalLabel: {
            id: "cGDsaD",
            defaultMessage: "Personal"
        },
        toggleBusinessLabel: {
            id: "sgisa2",
            defaultMessage: "Business"
        }
    }),
    ma = t => {
        "use forget";
        const e = Re.c(13),
            {
                billingDetails: s,
                shouldUseComparisonSpacing: o,
                shouldUseOnboardingFeatures: i,
                className: u,
                cta: c
            } = t,
            r = pt();
        let g;
        if (e[0] !== r || e[1] !== i) {
            const h = Se(r, "1656913255").get("outcome_value_props_enabled", !1);
            g = ho({
                shouldUseOnboardingFeatures: i,
                shouldUseOutcomeValueProps: h
            }), e[0] = r, e[1] = i, e[2] = g
        } else g = e[2];
        const _ = g;
        let f;
        e[3] !== c || e[4] !== _ ? (f = c != null ? c : a.jsx(Ve, {
            color: "secondary",
            disabled: !0,
            size: "large",
            className: "btn-secondary disabled:bg-token-bg-primary w-[100%]",
            children: a.jsx(X, O({}, _.callToAction.inactive))
        }), e[3] = c, e[4] = _, e[5] = f) : f = e[5];
        let m;
        e[6] === Symbol.for("react.memo_cache_sentinel") ? (m = [a.jsx(X, $(O({}, pa.haveExistingPlan), {
            values: {
                link: ga
            }
        }), "existing-plan-help")], e[6] = m) : m = e[6];
        let S;
        return e[7] !== s || e[8] !== u || e[9] !== _ || e[10] !== o || e[11] !== f ? (S = a.jsx(gt, {
            className: u,
            planType: w.FREE,
            pricingPlan: _,
            shouldUseComparisonSpacing: o,
            callToActionButton: f,
            additionalLinks: m,
            billingDetails: s,
            isCheckoutPricingConfigLoading: !1,
            checkoutPricingConfigError: null
        }), e[7] = s, e[8] = u, e[9] = _, e[10] = o, e[11] = f, e[12] = S) : S = e[12], S
    },
    pa = qe({
        haveExistingPlan: {
            id: "FreeColumn.haveExistingPlan",
            defaultMessage: "Have an existing plan? <link>See billing help</link>"
        }
    });

function ga(t) {
    return a.jsx(Ae, {
        target: "_blank",
        to: Vt,
        onClick: At,
        className: "font-medium underline",
        children: t
    }, "row-plus-plan-help-link")
}
const he = qe({
    planName: {
        id: "FreeWorkspaceColumn.planName",
        defaultMessage: "Business Free"
    },
    planSummary: {
        id: "FreeWorkspaceColumn.planSummary",
        defaultMessage: "A secure way to try ChatGPT at work"
    },
    planCost: {
        id: "FreeWorkspaceColumn.planCost",
        defaultMessage: "0"
    },
    currentPlanCta: {
        id: "FreeWorkspaceColumn.currentPlanCta",
        defaultMessage: "Your current plan"
    },
    badgeLabel: {
        id: "FreeWorkspaceColumn.badgeLabel",
        defaultMessage: "EARLY ACCESS"
    },
    limitedModelAccess: {
        id: "FreeWorkspaceColumn.limitedModelAccess",
        defaultMessage: "Limited access to our best model for work"
    },
    privacyBuiltIn: {
        id: "FreeWorkspaceColumn.privacyBuiltIn",
        defaultMessage: "Privacy built in; data never used for training"
    },
    limitedVideoAndImages: {
        id: "FreeWorkspaceColumn.limitedVideoAndImages",
        defaultMessage: "Limited video and image creation"
    },
    teamTools: {
        id: "FreeWorkspaceColumn.teamTools",
        defaultMessage: "Tools for teams like projects & custom GPTs"
    },
    unlimitedCollaboratorInvites: {
        id: "FreeWorkspaceColumn.unlimitedCollaboratorInvites",
        defaultMessage: "Unlimited collaborator invites"
    },
    businessIntegrations: {
        id: "FreeWorkspaceColumn.businessIntegrations",
        defaultMessage: "Integration with select business apps"
    }
});

function fa(t) {
    "use forget";
    const e = Re.c(7),
        {
            billingDetails: s,
            shouldUseComparisonSpacing: o,
            className: i,
            type: u
        } = t,
        c = u === void 0 ? ye.standard : u;
    let r;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (r = {
        name: he.planName,
        summary: he.planSummary,
        cost: {
            costValue: 0,
            costTitle: he.planCost
        },
        callToAction: {
            active: he.currentPlanCta,
            create: he.currentPlanCta,
            inactive: he.currentPlanCta
        },
        advertisedFeatures: [{
            label: he.limitedModelAccess,
            icon: Co
        }, {
            label: he.privacyBuiltIn,
            icon: bo
        }, {
            label: he.limitedVideoAndImages,
            icon: Jo
        }, {
            label: he.teamTools,
            icon: Xo
        }, {
            label: he.unlimitedCollaboratorInvites,
            icon: vo
        }, {
            label: he.businessIntegrations,
            icon: Zo
        }]
    }, e[0] = r) : r = e[0];
    const g = r;
    let _;
    e[1] === Symbol.for("react.memo_cache_sentinel") ? (_ = a.jsx(Ve, {
        color: "secondary",
        disabled: !0,
        fullWidth: !0,
        size: "large",
        className: "font-semibold",
        children: a.jsx(X, O({}, he.currentPlanCta))
    }), e[1] = _) : _ = e[1];
    let f;
    return e[2] !== s || e[3] !== i || e[4] !== o || e[5] !== c ? (f = a.jsx(gt, {
        className: i,
        planType: w.FREE_WORKSPACE,
        pricingPlan: g,
        shouldUseComparisonSpacing: o,
        badgeLabel: he.badgeLabel,
        callToActionButton: _,
        billingDetails: s,
        type: c,
        isCheckoutPricingConfigLoading: !1,
        checkoutPricingConfigError: null
    }), e[2] = s, e[3] = i, e[4] = o, e[5] = c, e[6] = f) : f = e[6], f
}

function ms(t, e) {
    const s = ks(new Date, t);
    return new Intl.DateTimeFormat(e, {
        year: "numeric",
        month: "short",
        day: "numeric"
    }).format(s)
}

function qt({
    currentAccount: t,
    intl: e,
    billingDetails: s,
    pricingPlan: o,
    promoMetadata: i,
    columnPlanType: u
}) {
    var P;
    if (i || !t.data.subscriptionStatus.discount) return {
        activeDiscountMetadata: null,
        scheduledAdditionalLink: null
    };
    const c = t.getDaysUntilPlanDiscountExpires(),
        r = t.data.subscriptionStatus.discount,
        g = t.planType,
        _ = t.getNextPlanType(),
        f = (P = r.discount_start_in_num_periods) != null ? P : 0,
        m = f > 0 && g === u && !_,
        S = f > 0 && _ === u,
        h = e.formatNumber(r.amount, {
            style: "currency",
            currency: s.currency,
            minimumFractionDigits: 0,
            maximumFractionDigits: 2
        });
    return m || S ? {
        activeDiscountMetadata: null,
        scheduledAdditionalLink: a.jsx("div", {
            className: "mb-3 w-full",
            children: a.jsx("div", {
                className: "px-1 text-sm font-medium text-[#615EEB]",
                children: r.discount_type === Lt.PERCENTAGE ? a.jsx(X, {
                    id: "PlusColumn.scheduledPercentDiscount",
                    defaultMessage: "Your {discountPercent}% discount will apply in {numPeriods, plural, one {the next billing period} other {# billing periods}}.",
                    values: {
                        discountPercent: r.amount,
                        numPeriods: f
                    }
                }) : a.jsx(X, {
                    id: "PlusColumn.scheduledFixedDiscount",
                    defaultMessage: "Your {discountFixed} discount will apply in {numPeriods, plural, one {the next billing period} other {# billing periods}}.",
                    values: {
                        discountFixed: h,
                        numPeriods: f
                    }
                })
            })
        })
    } : f > 0 || u !== t.data.subscriptionStatus.planType ? {
        activeDiscountMetadata: null,
        scheduledAdditionalLink: null
    } : o.cost ? (o.cost = Us(e, o.cost, r), r.discount_type === Lt.PERCENTAGE ? {
        activeDiscountMetadata: {
            discount: {
                percentage: r.amount,
                expires_at: c ? ms(c, e.locale) : void 0
            }
        },
        scheduledAdditionalLink: null
    } : r.discount_type === Lt.FIXED ? {
        activeDiscountMetadata: {
            discount: {
                value: r.amount,
                expires_at: c ? ms(c, e.locale) : void 0
            }
        },
        scheduledAdditionalLink: null
    } : {
        activeDiscountMetadata: null,
        scheduledAdditionalLink: null
    }) : {
        activeDiscountMetadata: null,
        scheduledAdditionalLink: null
    }
}

function ps(t, e, s, o) {
    let i;
    switch (t) {
        case "month":
            i = Zs(new Date, e);
            break;
        case "year":
            i = Qs(new Date, e);
            break
    }
    return o && i && (i = ks(i, o)), new Intl.DateTimeFormat(s, {
        year: "numeric",
        month: "short",
        day: "numeric"
    }).format(i)
}

function Qt({
    intl: t,
    pricingPlan: e,
    planName: s,
    promoMetadata: o,
    currency: i,
    currentAccount: u,
    checkoutPricingConfig: c
}) {
    var L, U, K, ce, G, R, B, ie, ae, j, W, q;
    if (!e.cost) return e;
    const {
        costTitle: r,
        currencySymbol: g
    } = Ko(e, i), _ = (U = (L = r == null ? void 0 : r.defaultMessage) == null ? void 0 : L.toString()) != null ? U : "20", f = ws(s.toLowerCase()), {
        schedule: m
    } = o, S = (ce = (K = o.duration) == null ? void 0 : K.period) != null ? ce : "month", h = (R = (G = o.duration) == null ? void 0 : G.num_periods) != null ? R : 1, P = (B = m == null ? void 0 : m.start_after_num_periods) != null ? B : 0, n = (ie = m == null ? void 0 : m.period) != null ? ie : S, d = P > 0 ? ps(n, P, t.locale) : void 0, l = ps(S, h + (P > 0 ? P : 0), t.locale, u == null ? void 0 : u.getDaysUntilPlanRenews()), v = Us(t, e.cost, o.discount, (ae = o.duration) != null ? ae : {
        num_periods: 1,
        period: "month"
    }), C = (W = (j = g.code.defaultMessage) == null ? void 0 : j.toString()) != null ? W : "USD", M = t.formatNumber(parseFloat(_) || 0, {
        style: "currency",
        currency: C,
        minimumFractionDigits: 0,
        maximumFractionDigits: 2
    }), p = (o == null ? void 0 : o.no_auto_renewal_at_discount_end) === !0, b = (q = u.getEligiblePromoCampaignId(s)) != null ? q : null;
    let k;
    switch (S) {
        case "month":
            P > 0 ? h === 1 ? k = t.formatMessage(te.promoPlanDisclaimerScheduledForSingleMonth, {
                start_date: d,
                end_date: l,
                cost: M,
                plan_name: f
            }) : k = t.formatMessage(te.promoPlanDisclaimerScheduledForPluralMonths, {
                num_months: h,
                start_date: d,
                end_date: l,
                cost: M,
                plan_name: f
            }) : h === 1 ? k = p ? t.formatMessage(te.promoPlanDisclaimerNoRenewForSingleMonth, {}) : t.formatMessage(te.promoPlanDisclaimerForSingleMonth, {
                date: l,
                cost: M,
                plan_name: f
            }) : k = p ? t.formatMessage(te.promoPlanDisclaimerNoRenewForPluralMonths, {
                num_months: h
            }) : t.formatMessage(te.promoPlanDisclaimerForPluralMonths, {
                num_months: h,
                date: l,
                cost: M,
                plan_name: f
            });
            break;
        case "year":
            P > 0 ? h === 1 ? k = t.formatMessage(te.promoPlanDisclaimerScheduledForSingleYear, {
                start_date: d,
                end_date: l,
                cost: M,
                plan_name: f
            }) : k = t.formatMessage(te.promoPlanDisclaimerScheduledForPluralYears, {
                num_years: h,
                start_date: d,
                end_date: l,
                cost: M,
                plan_name: f
            }) : h === 1 ? k = p ? t.formatMessage(te.promoPlanDisclaimerNoRenewForSingleYear, {}) : t.formatMessage(te.promoPlanDisclaimerForSingleYear, {
                date: l,
                cost: M,
                plan_name: f
            }) : k = p ? t.formatMessage(te.promoPlanDisclaimerNoRenewForPluralYears, {
                num_years: h
            }) : t.formatMessage(te.promoPlanDisclaimerForPluralYears, {
                num_years: h,
                date: l,
                cost: M,
                plan_name: f
            });
            break;
        case "hour":
            throw new Error("Period 'hour' is not supported")
    }
    const y = "<article>" + t.formatMessage(te.termsApply) + "</article> " + k,
        x = ta(s, b);
    let A = o.summary;
    if (P > 0) {
        const {
            formattedDiscountedCost: T
        } = cs(t, 1, o.discount, i, c, s), E = T;
        switch (S) {
            case "month":
                h === 1 ? A = t.formatMessage(te.promoSummaryScheduledForSingleMonth, {
                    discounted_cost: E
                }) : A = t.formatMessage(te.promoSummaryScheduledForPluralMonths, {
                    discounted_cost: E,
                    num_months: h
                });
                break;
            case "year":
                h === 1 ? A = t.formatMessage(te.promoSummaryScheduledForSingleYear, {
                    discounted_cost: E
                }) : A = t.formatMessage(te.promoSummaryScheduledForPluralYears, {
                    discounted_cost: E,
                    num_years: h
                });
                break
        }
    }
    let D = v;
    if (P > 0) {
        const {
            formattedDiscountedCost: T
        } = cs(t, 1, o.discount, i, c, s);
        let E;
        switch (S) {
            case "month":
                h === 1 ? E = t.formatMessage(te.promoCostSubtitleScheduledForSingleMonth, {
                    start_date: d,
                    discounted_cost: T
                }) : E = t.formatMessage(te.promoCostSubtitleScheduledForPluralMonths, {
                    start_date: d,
                    discounted_cost: T,
                    num_months: h
                });
                break;
            case "year":
                h === 1 ? E = t.formatMessage(te.promoCostSubtitleScheduledForSingleYear, {
                    start_date: d,
                    discounted_cost: T
                }) : E = t.formatMessage(te.promoCostSubtitleScheduledForPluralYears, {
                    start_date: d,
                    discounted_cost: T,
                    num_years: h
                });
                break
        }
        D = $(O({}, e.cost), {
            costDuration: {
                id: "promoCostDurationScheduled",
                defaultMessage: E,
                description: "Cost duration subtitle for scheduled promo indicating when discount starts and for how long"
            }
        })
    }
    return e = $(O({}, e), {
        summary: {
            id: "promoSummary",
            defaultMessage: A
        },
        disclaimer: {
            id: "promoDisclaimer",
            defaultMessage: y,
            article: x
        },
        fullPriceResumeDateString: l,
        cost: D,
        callToAction: $(O({}, e.callToAction), {
            promo: Ks({
                id: "pricingPlanConstants.promo.callToAction",
                defaultMessage: "Apply to My Subscription"
            })
        })
    }), e
}
const te = qe({
        promoPlanDisclaimerForPluralMonths: {
            id: "pricingPlanConstants.promoPlanDisclaimerForPluralMonths",
            defaultMessage: "Promo pricing applies for {num_months} months. Starting {date}, ChatGPT {plan_name} will continue at {cost}/month. Cancel anytime."
        },
        promoPlanDisclaimerScheduledForPluralMonths: {
            id: "pricingPlanConstants.promoPlanDisclaimerScheduledForPluralMonths",
            defaultMessage: "Promo pricing applies for {num_months} months starting {start_date}. Starting {end_date}, ChatGPT {plan_name} will continue at {cost}/month. Cancel anytime."
        },
        promoPlanDisclaimerScheduledForSingleMonth: {
            id: "pricingPlanConstants.promoPlanDisclaimerScheduledForSingleMonth",
            defaultMessage: "Promo pricing applies for 1 month starting {start_date}. Starting {end_date}, ChatGPT {plan_name} will continue at {cost}/month. Cancel anytime."
        },
        promoPlanDisclaimerScheduledForPluralYears: {
            id: "pricingPlanConstants.promoPlanDisclaimerScheduledForPluralYears",
            defaultMessage: "Promo pricing applies for {num_years} years starting {start_date}. Starting {end_date}, ChatGPT {plan_name} will continue at {cost}/year. Cancel anytime."
        },
        promoPlanDisclaimerScheduledForSingleYear: {
            id: "pricingPlanConstants.promoPlanDisclaimerScheduledForSingleYear",
            defaultMessage: "Promo pricing applies for 1 year starting {start_date}. Starting {end_date}, ChatGPT {plan_name} will continue at {cost}/year. Cancel anytime."
        },
        promoPlanDisclaimerForSingleMonth: {
            id: "pricingPlanConstants.promoPlanDisclaimerForSingleMonth",
            defaultMessage: "Promo pricing applies for 1 month. Starting {date}, ChatGPT {plan_name} will continue at {cost}/month. Cancel anytime."
        },
        promoPlanDisclaimerNoRenewForPluralMonths: {
            id: "pricingPlanConstants.promoPlanDisclaimerNoRenewForPluralMonths",
            defaultMessage: "Promo pricing applies for {num_months} months."
        },
        promoPlanDisclaimerNoRenewForSingleMonth: {
            id: "pricingPlanConstants.promoPlanDisclaimerNoRenewForSingleMonth",
            defaultMessage: "Promo pricing applies for 1 month."
        },
        promoCostSubtitleScheduledForPluralMonths: {
            id: "pricingPlanConstants.promoCostSubtitleScheduledForPluralMonths",
            defaultMessage: "Starting {start_date}: {discounted_cost}/month for {num_months} months"
        },
        promoCostSubtitleScheduledForSingleMonth: {
            id: "pricingPlanConstants.promoCostSubtitleScheduledForSingleMonth",
            defaultMessage: "Starting {start_date}: {discounted_cost}/month for 1 month"
        },
        promoCostSubtitleScheduledForPluralYears: {
            id: "pricingPlanConstants.promoCostSubtitleScheduledForPluralYears",
            defaultMessage: "Starting {start_date}: {discounted_cost}/year for {num_years} years"
        },
        promoCostSubtitleScheduledForSingleYear: {
            id: "pricingPlanConstants.promoCostSubtitleScheduledForSingleYear",
            defaultMessage: "Starting {start_date}: {discounted_cost}/year for 1 year"
        },
        promoPlanDisclaimerForPluralYears: {
            id: "pricingPlanConstants.promoPlanDisclaimerForPluralYears",
            defaultMessage: "Promo pricing applies for {num_years} years. Starting {date}, ChatGPT {plan_name} will continue at {cost}/year. Cancel anytime."
        },
        promoPlanDisclaimerForSingleYear: {
            id: "pricingPlanConstants.promoPlanDisclaimerForSingleYear",
            defaultMessage: "Promo pricing applies for 1 year. Starting {date}, ChatGPT {plan_name} will continue at {cost}/year. Cancel anytime."
        },
        promoPlanDisclaimerNoRenewForPluralYears: {
            id: "pricingPlanConstants.promoPlanDisclaimerNoRenewForPluralYears",
            defaultMessage: "Promo pricing applies for {num_years} years."
        },
        promoPlanDisclaimerNoRenewForSingleYear: {
            id: "pricingPlanConstants.promoPlanDisclaimerNoRenewForSingleYear",
            defaultMessage: "Promo pricing applies for 1 year."
        },
        termsApply: {
            id: "pricingPlanConstants.termsApply",
            defaultMessage: "Promo terms apply."
        },
        promoSummaryScheduledForPluralMonths: {
            id: "pricingPlanConstants.promoSummaryScheduledForPluralMonths",
            defaultMessage: "Pay for the first month, then the next {num_months} months are {discounted_cost}."
        },
        promoSummaryScheduledForSingleMonth: {
            id: "pricingPlanConstants.promoSummaryScheduledForSingleMonth",
            defaultMessage: "Pay for the first month, then the next month is {discounted_cost}."
        },
        promoSummaryScheduledForPluralYears: {
            id: "pricingPlanConstants.promoSummaryScheduledForPluralYears",
            defaultMessage: "Pay for the first year, then the next {num_years} years are {discounted_cost}."
        },
        promoSummaryScheduledForSingleYear: {
            id: "pricingPlanConstants.promoSummaryScheduledForSingleYear",
            defaultMessage: "Pay for the first year, then the next year is {discounted_cost}."
        }
    }),
    Rt = w.PLUS;

function ha(t, e, s) {
    let o = null,
        i = null,
        u = null;
    if (t === "plus-10-for-3-months" ? (o = s.currencyConfig.promos.plus_intro_offer_3m.amount, i = s.currencyConfig.promos.plus_intro_offer_3m.type, u = 3) : t === "plus-10-for-12-mos" && (o = s.currencyConfig.promos.plus_intro_offer_12m.amount, i = s.currencyConfig.promos.plus_intro_offer_12m.type, u = 12), o == null || i == null || u == null) return null;
    let c = null;
    return i === "value" ? c = {
        value: o,
        currency_code: s.currencyConfig.symbol_code
    } : c = {
        percentage: o
    }, {
        plan_name: Ke.PLUS,
        title: "",
        summary: e.formatMessage(Bt.headline),
        discount: c,
        duration: {
            num_periods: u,
            period: "month"
        },
        price_period: "recurring",
        promotion_type: "discount",
        promotion_type_label: null
    }
}
const ya = ({
        analyticsParams: t,
        className: e,
        currentAccount: s,
        planLoading: o,
        isPromoLoading: i,
        onUpgradeButtonClick: u,
        setPlanLoading: c,
        plusPricingPlan: r = null,
        billingDetails: g,
        promoCode: _ = null,
        referralCode: f = null,
        promoMetadata: m = null,
        onClose: S,
        disableForMobile: h = !1,
        type: P,
        shouldUseComparisonSpacing: n,
        autoUpgrade: d = !1,
        fromiOSWebview: l = !1,
        setShouldShowCheckoutLoadingOverlay: v,
        enableComposerLoadPricingLayer: C
    }) => {
        "use no forget";
        const M = pt(),
            p = !Js(),
            b = mt(),
            k = vs();
        let y = r || yo({
            ctx: M
        });
        const {
            data: x,
            isLoading: A,
            error: D
        } = wt({
            countryCode: g.country,
            currency: g.currency,
            ctx: M
        });
        if (!A && !D && x) {
            const z = _t(x, as, St.Month);
            y = $(O({}, y), {
                cost: {
                    costValue: z.amount,
                    costTitle: Ct(z.amount, as, g.currency)
                }
            })
        }
        const L = qo({
                ctx: M,
                shouldLogExposure: !1
            }),
            {
                data: U
            } = As(L);
        m == null && (U == null ? void 0 : U.coupon) === L && (U == null ? void 0 : U.state) === "eligible" && Qo({
            ctx: M,
            shouldLogExposure: !0
        }) && x && (x.currencyConfig.promos.plus_intro_offer_3m.enabled || x.currencyConfig.promos.plus_intro_offer_12m.enabled) && (m = ha(L, b, x), _ = L);
        const {
            eligible: K,
            campaignId: ce
        } = Mo();
        let G;
        const R = new URLSearchParams(k.search).get(To);

        function B(z) {
            return z === "plus-1-month-free" ? {
                plan_name: Ke.PLUS,
                title: "",
                summary: b.formatMessage(Bt.headline),
                discount: {
                    percentage: 100
                },
                duration: {
                    num_periods: 1,
                    period: "month"
                },
                price_period: "recurring",
                promotion_type: "discount",
                promotion_type_label: b.formatMessage(kt.specialOffer)
            } : z === "plus-10-for-1-month" ? {
                plan_name: Ke.PLUS,
                title: "",
                summary: b.formatMessage(Bt.headline),
                discount: {
                    percentage: 50
                },
                duration: {
                    num_periods: 1,
                    period: "month"
                },
                price_period: "recurring",
                promotion_type: "discount",
                promotion_type_label: b.formatMessage(kt.specialOffer)
            } : null
        }
        if (m == null) {
            const z = R || (K ? ce : void 0);
            if (z) {
                const le = B(z);
                le && (_ || (G = z), m = le)
            }
        }
        const ie = s.isOrWasPaidCustomer(),
            ae = s.hasPaidSubscription(),
            j = ae && s.isPlus(),
            W = ae && s.isPro(),
            q = s.getLastActiveSubscription(),
            T = s.features.includes("disable_plus_upgrade_ui") && !ie,
            E = V.useMemo(() => $(O({}, t), {
                promoCode: _,
                promoCampaign: G,
                planType: Rt,
                isUpgradeUiDisabled: T,
                referrer: document.referrer
            }), [t, _, G, T]),
            N = [],
            ge = () => {
                pe.logEvent("Account Portal: Click iOS Manage Subscription", E)
            },
            Q = () => {
                pe.logEvent("Account Portal: Click Android Manage Subscription", E)
            },
            re = j && [dt.CHATGPT_IOS, dt.SORA_IOS].includes(q.purchase_origin_platform),
            H = j && q.purchase_origin_platform === dt.MOBILE_ANDROID;
        N.push(a.jsx(Ae, {
            to: xo,
            target: "_blank",
            className: "px-1 font-medium underline",
            children: a.jsx(X, O({}, Tt.limitsApply))
        }, "row-plus-plan-usage-limits")), re && N.push(a.jsx(Ae, {
            to: Os,
            target: "_blank",
            onClick: ge,
            className: "px-1 font-medium underline",
            children: b.formatMessage(Et.manageSubscriptionIos.callToAction)
        }, "row-plus-plan-manage-ios")), H && N.push(a.jsx(Ae, {
            to: Ls,
            target: "_blank",
            onClick: Q,
            className: "px-1 font-medium underline",
            children: b.formatMessage(Et.manageSubscriptionAndroid.callToAction)
        }, "row-plus-plan-manage-android")), j && ie && N.push(a.jsx(Ae, {
            target: "_blank",
            to: Vt,
            onClick: At,
            className: "px-1 font-medium underline",
            children: a.jsx(X, O({}, Tt.billingHelp))
        }, "row-plus-plan-help-link"));
        const I = m != null,
            se = (m == null ? void 0 : m.promotion_type) === "student_discount",
            ee = m != null && "referrer_name" in m,
            F = m != null && "percentage" in m.discount && m.discount.percentage === 100,
            de = (!j || I) && o == null,
            ue = Kt({
                ctx: M,
                isFreeTrialEligible: F
            }),
            {
                activeDiscountMetadata: oe,
                scheduledAdditionalLink: Pe
            } = qt({
                currentAccount: s,
                intl: b,
                billingDetails: g,
                pricingPlan: y,
                promoMetadata: m,
                columnPlanType: w.PLUS
            });
        if (Pe && N.unshift(Pe), oe && (y.summary = ea.plusSummaryWithDiscount), m && x && !A && !D && (y = Qt({
                intl: b,
                pricingPlan: y,
                promoMetadata: m,
                currency: g.currency,
                planName: w.PLUS,
                currentAccount: s,
                checkoutPricingConfig: x
            })), i != null && i) return null;
        let ne;
        I && j && y.callToAction.promo ? ne = b.formatMessage(y.callToAction.promo) : j ? ne = b.formatMessage(y.callToAction.active) : ue ? ne = b.formatMessage(ue) : ee && p && y.callToAction.inactiveUnauthenticated ? ne = b.formatMessage(y.callToAction.inactiveUnauthenticated) : ne = b.formatMessage(xt({
            planType: w.PLUS
        }));
        let Z;
        j && !I || W ? Z = "secondary" : P === "highlight" || P === "promo" ? Z = "purple" : (P === "standard" || se) && (Z = "primary");
        const me = c != null ? c : (() => {}),
            J = typeof u == "function" ? (z, le) => u(z, le) : void 0,
            fe = a.jsx(zs, {
                analyticsParams: E,
                billingDetails: g,
                currentAccount: s,
                planType: Rt,
                planLoading: o,
                setPlanLoading: me,
                testId: "select-plan-button-plus-upgrade",
                onPromoClose: S,
                activeColor: Z,
                disableForMobile: h,
                disabled: T || !de,
                promoMetadata: m,
                promoCode: _ != null ? _ : void 0,
                referralCode: f != null ? f : void 0,
                promoCampaign: G,
                pricingPlan: y,
                setShouldShowCheckoutLoadingOverlay: v,
                autoUpgrade: d,
                fromiOSWebview: l,
                overrideOnClick: J,
                children: ne
            });
        return a.jsx(gt, {
            planType: Rt,
            elementId: ko,
            pricingPlan: y,
            shouldUseComparisonSpacing: n,
            isCheckoutPricingConfigLoading: A,
            checkoutPricingConfigError: D,
            callToActionButton: T ? a.jsx("div", {
                className: "relative w-full",
                children: a.jsx(Gt, {
                    side: "bottom",
                    sideOffset: 20,
                    label: b.formatMessage(Tt.highDemandDisabledText),
                    children: fe
                })
            }) : fe,
            secondaryCallToActionButton: P === "promo" ? a.jsx(Ve, {
                size: "large",
                color: "secondary",
                onClick: S,
                children: a.jsx(X, O({}, Tt.notNow))
            }) : null,
            additionalLinks: N,
            type: P,
            promoMetadata: m,
            activeDiscountMetadata: oe,
            billingDetails: g,
            className: e,
            enableComposerLoadPricingLayer: C
        })
    },
    Tt = qe({
        billingHelp: {
            id: "AccountPaymentModel.billingHelp",
            defaultMessage: "I need help with a billing issue"
        },
        limitsApply: {
            id: "xda4i3",
            defaultMessage: "Limits apply"
        },
        notNow: {
            id: "AccountPaymentModal.notNow",
            defaultMessage: "Not Now"
        },
        highDemandDisabledText: {
            id: "AccountPaymentModal.highDemandDisabledText",
            defaultMessage: "Due to high demand, we've temporarily paused upgrades."
        }
    }),
    rt = w.PRO,
    Pa = () => {
        "use forget";
        const t = Re.c(1);
        let e;
        return t[0] === Symbol.for("react.memo_cache_sentinel") ? (e = {
            queryKey: ["has-app-store-subscription-in-billing-retry"],
            queryFn: Sa
        }, t[0] = e) : e = t[0], Yt(e)
    },
    _a = ({
        analyticsParams: t,
        currentAccount: e,
        planLoading: s,
        className: o,
        onSubmit: i,
        setPlanLoading: u,
        billingDetails: c,
        autoUpgrade: r = !1,
        shouldUseComparisonSpacing: g = !1,
        fromiOSWebview: _ = !1,
        setShouldShowCheckoutLoadingOverlay: f,
        enableComposerLoadPricingLayer: m
    }) => {
        var J, fe;
        const {
            data: S,
            isError: h
        } = Pa(), P = pt(), {
            data: n,
            refetch: d
        } = Yt(Is), l = mt(), v = Xs(), [C] = Ms(), {
            trackSelectedPixels: M
        } = It({
            key: w.PRO
        }), {
            trackSelectedPixels: p
        } = It({
            key: "pro-secondary"
        }), b = C.get("checkout_from"), [k, y] = V.useState(!1), [x, A] = V.useState(!1), [D, L] = V.useState(!1), U = V.useRef(!1), K = e.getLastActiveSubscription(), ce = e.isOrWasPaidCustomer(), G = e.hasPaidSubscription(), R = G && e.isPro(), B = !!(n != null && n.email), {
            prepareCheckoutSession: ie,
            navigateToCheckout: ae
        } = Eo(), {
            recentlyDowngraded: j
        } = na(), {
            daysUntilPlanChanges: W,
            isDowngradeScheduled: q
        } = sa(e, j);
        let T = Po({
            ctx: P
        });
        const {
            data: E,
            isLoading: N,
            error: ge
        } = wt({
            countryCode: c.country,
            currency: c.currency,
            ctx: P
        });
        if (!N && !ge && E) {
            const z = _t(E, ns, St.Month);
            T = $(O({}, T), {
                cost: {
                    costValue: z.amount,
                    costTitle: Ct(z.amount, ns, c.currency)
                }
            })
        }
        const Q = [],
            {
                activeDiscountMetadata: re,
                scheduledAdditionalLink: H
            } = qt({
                currentAccount: e,
                intl: l,
                billingDetails: c,
                pricingPlan: T,
                promoMetadata: null,
                columnPlanType: w.PRO
            });
        H && Q.unshift(H);
        const I = $(O({}, t), {
                planType: rt
            }),
            se = G && [dt.CHATGPT_IOS, dt.SORA_IOS].includes(K.purchase_origin_platform),
            ee = G && K.purchase_origin_platform === dt.MOBILE_ANDROID,
            F = async z => {
                var le, je;
                if (!B && !z) {
                    L(!0);
                    return
                }
                u == null || u(w.PRO), pe.logEvent("Account Pay: Payment Checkout Clicked", I), Pt(P, "chatgpt_account_payment_modal_upgrade_button_click", rt);
                try {
                    const xe = Se(P, "3542930659").get("show_loading", !1);
                    f(xe);
                    const Ce = {
                            plan_name: "chatgptpro",
                            billing_details: c
                        },
                        ke = await ie(Ce, {
                            fromiOSWebview: _
                        });
                    i == null || i(), M(), p(), pe.logEvent("Account Pay: Navigating to Payment Checkout", $(O({}, I), {
                        url: (le = ke.url) != null ? le : ""
                    })), Pt(P, "chatgpt_account_payment_modal_navigating_to_checkout", rt, {
                        url: (je = ke.url) != null ? je : ""
                    }), b === "vza493q" && eo.setItem(to.CheckoutFrom, b), await ae(ke, {
                        checkoutPayload: Ce
                    })
                } catch (xe) {
                    v.warning(l.formatMessage(ut.paymentErrorWarning), {
                        hasCloseButton: !0
                    }), f(!1)
                }
                u == null || u(null)
            };
        V.useEffect(() => {
            !r || U.current || (U.current = !0, Z())
        }, [r]);
        const de = () => {
                pe.logEvent("Account Portal: Click iOS Manage Subscription", I)
            },
            ue = () => {
                pe.logEvent("Account Portal: Click Android Manage Subscription", I)
            };
        R && se && Q.push(a.jsx(Ae, {
            to: Os,
            target: "_blank",
            onClick: de,
            className: "px-1 font-medium underline",
            children: l.formatMessage(Et.manageSubscriptionIos.callToAction)
        }, "row-plus-plan-manage-ios")), R && ee && Q.push(a.jsx(Ae, {
            to: Ls,
            target: "_blank",
            onClick: ue,
            className: "px-1 font-medium underline",
            children: l.formatMessage(Et.manageSubscriptionAndroid.callToAction)
        }, "row-plus-plan-manage-android")), ce && Q.push(a.jsx(Ae, {
            target: "_blank",
            to: Vt,
            onClick: At,
            className: "px-1 font-medium underline",
            children: a.jsx(X, O({}, gs.billingHelp))
        }, "row-plus-plan-help-link"));
        const oe = function() {
                y(!k)
            },
            Pe = function() {
                A(!x)
            },
            ne = Es(P, "1382475798"),
            Z = async () => {
                const z = e.hasPaidSubscription(),
                    le = ne && e.isActiveSubscriptionGratis();
                z && !le ? (pe.logEvent("Account Pay: Payment Checkout Clicked", I), Pt(P, "chatgpt_account_payment_modal_upgrade_button_click", rt), A(!0)) : await F()
            },
            me = h || !S || !S.value ? Z : () => {
                oe()
            };
        return Gs(D, {
            plan: I
        }), a.jsxs(a.Fragment, {
            children: [a.jsx(gt, {
                activeDiscountMetadata: re,
                planType: rt,
                pricingPlan: T,
                isCheckoutPricingConfigLoading: N,
                checkoutPricingConfigError: ge,
                callToActionButton: a.jsxs("div", {
                    children: [se || ee ? a.jsx(Gt, {
                        side: "top",
                        sideOffset: 20,
                        label: l.formatMessage(gs.switchToMobile),
                        onOpenChange: z => {
                            z && (pe.logEvent("Account Pay: Show Mobile Subscription Tooltip", I), Pt(P, "chatgpt_account_payment_modal_show_mobile_subscription_tooltip", rt))
                        },
                        children: a.jsx(Ve, {
                            fullWidth: !0,
                            size: "large",
                            color: "primary",
                            disabled: !0,
                            "data-testid": "select-plan-button-pro-upgrade",
                            children: l.formatMessage(xt({
                                planType: w.PRO
                            }))
                        })
                    }) : q && W ? a.jsx(Gt, {
                        side: "top",
                        sideOffset: 20,
                        label: a.jsx(X, {
                            id: "MUQGzU",
                            defaultMessage: "Your subscription will remain active until {date}, when it will change to {nextPlanType}.",
                            values: {
                                date: oa(W, l.locale),
                                nextPlanType: ws((fe = (J = e.getNextPlanType()) == null ? void 0 : J.toLowerCase()) != null ? fe : "")
                            }
                        }),
                        children: a.jsx(Ve, {
                            fullWidth: !0,
                            size: "large",
                            color: "primary",
                            disabled: R || s != null,
                            "data-testid": "select-plan-button-pro-upgrade",
                            className: R || s != null ? "bg-token-sidebar-surface-tertiary text-token-text-primary hover:bg-token-sidebar-surface-tertiary dark:bg-token-text-tertiary dark:text-token-text-primary dark:hover:bg-token-text-tertiary border-none font-semibold" : "",
                            children: s === w.PRO && !x ? a.jsx(zt, {}) : R ? l.formatMessage(T.callToAction.active) : l.formatMessage(xt({
                                planType: w.PRO
                            }))
                        })
                    }) : a.jsx(Ve, {
                        fullWidth: !0,
                        size: "large",
                        color: "primary",
                        disabled: R || s != null,
                        onClick: me,
                        "data-testid": "select-plan-button-pro-upgrade",
                        className: R || s != null ? "bg-token-sidebar-surface-tertiary text-token-text-primary hover:bg-token-sidebar-surface-tertiary dark:bg-token-text-tertiary dark:text-token-text-primary dark:hover:bg-token-text-tertiary border-none font-semibold" : "",
                        children: s === w.PRO && !x ? a.jsx(zt, {}) : R ? l.formatMessage(T.callToAction.active) : l.formatMessage(xt({
                            planType: w.PRO
                        }))
                    }), a.jsx(aa, {
                        isOpen: k,
                        onClose: oe,
                        onContinue: F,
                        analyticsParams: I
                    }), x && a.jsx(ia, {
                        isOpen: x,
                        onClose: Pe,
                        accountId: e.id,
                        initialPlanType: e.planType,
                        updatedPlanType: w.PRO,
                        billingDetails: c
                    })]
                }),
                additionalLinks: Q,
                className: Ft("bg-token-main-surface-primary", o),
                billingDetails: c,
                shouldUseComparisonSpacing: g,
                enableComposerLoadPricingLayer: m
            }), a.jsx($t, {
                testId: "modal-add-email",
                isOpen: D,
                onClose: () => L(!1),
                type: "success",
                className: "max-w-sm",
                children: a.jsx(Bs, {
                    enterEmailTitle: l.formatMessage(ut.addEmailTitle),
                    enterEmailDescription: l.formatMessage(ut.addEmailDescription),
                    onVerified: () => {
                        d(), L(!1), F(!0)
                    },
                    cancelFlowButton: a.jsx(Ve, {
                        className: "w-full rounded-md",
                        color: "secondary",
                        onClick: () => L(!1),
                        children: a.jsx(X, O({}, ut.cancelAddEmail))
                    })
                })
            })]
        })
    },
    gs = qe({
        switchToPersonalAccount: {
            id: "y5FjSF",
            defaultMessage: "Switch to a personal account to upgrade"
        },
        billingHelp: {
            id: "AccountPaymentModel.billingHelp",
            defaultMessage: "I need help with a billing issue"
        },
        switchToMobile: {
            id: "gbjsg6",
            defaultMessage: "It looks like you already have an active mobile subscription. Switch to your mobile app to upgrade"
        }
    });
async function Sa() {
    return await so.safeGet("/subscriptions/has_app_store_subscription_in_billing_retry")
}
const lt = w.SELF_SERVE_BUSINESS,
    Ca = t => {
        "use forget";
        var Je;
        const e = Re.c(50),
            {
                analyticsParams: s,
                planLoading: o,
                billingDetails: i,
                type: u,
                shouldUseComparisonSpacing: c,
                shouldUseOnboardingFeatures: r,
                className: g,
                cta: _,
                currentAccount: f,
                promoCode: m,
                promoMetadata: S,
                onProceed: h,
                setShouldShowCheckoutLoadingOverlay: P,
                enableComposerLoadPricingLayer: n
            } = t,
            d = u === void 0 ? ye.standard : u;
        let l;
        e[0] === Symbol.for("react.memo_cache_sentinel") ? (l = {
            key: lt
        }, e[0] = l) : l = e[0];
        const {
            trackSelectedPixels: v
        } = It(l);
        let C;
        e[1] === Symbol.for("react.memo_cache_sentinel") ? (C = {
            key: "team-secondary"
        }, e[1] = C) : C = e[1];
        const {
            trackSelectedPixels: M
        } = It(C), p = pt(), {
            data: b,
            refetch: k
        } = Yt(Is);
        let y;
        e[2] !== i.country || e[3] !== i.currency || e[4] !== p ? (y = {
            countryCode: i.country,
            currency: i.currency,
            ctx: p
        }, e[2] = i.country, e[3] = i.currency, e[4] = p, e[5] = y) : y = e[5];
        const {
            data: x,
            isLoading: A,
            error: D
        } = wt(y), L = mt(), U = oo(p), K = Ts(), ce = Fo(), [G, R] = V.useState(!1), B = U == null ? void 0 : U.isSelfServeBusiness(), ie = U == null ? void 0 : U.isPlus(), ae = $(O({}, s), {
            planType: lt
        }), j = !!(b != null && b.email), W = Se(p, "111733276").get("show_upgrade_page_v2_copy", !1), q = Se(p, "1656913255").get("outcome_value_props_enabled", !1), T = Ns();
        let E = _o({
            isBusinessUpgradeV2CopyEnabled: W,
            shouldUseOnboardingFeatures: r,
            isTrialEnabled: T.eligible,
            isOutcomeValuePropsEnabled: q
        });
        if (!A && !D && x) {
            const ve = _t(x, Mt, St.Year);
            E = $(O({}, E), {
                cost: $(O({}, E.cost), {
                    costValue: ve.amount,
                    costTitle: Ct(ve.amount, Mt, i.currency)
                })
            })
        }
        const N = ca(),
            ge = m ? "" : N != null ? N : "",
            Q = !!(!m && N),
            {
                data: re
            } = As(ge, Q),
            H = re != null,
            I = re != null ? re : T.eligible ? {
                coupon: T.campaignId,
                state: "eligible",
                redemption: null
            } : void 0,
            se = I && (I == null ? void 0 : I.coupon) === ua && (I == null ? void 0 : I.state) === "eligible";
        let ee = S != null ? S : null,
            F = !1;
        if (m && ee && x && !A && !D) {
            const ve = _t(x, Mt, St.Month);
            E = $(O({}, E), {
                cost: $(O({}, E.cost), {
                    costValue: ve.amount,
                    costTitle: Ct(ve.amount, Mt, i.currency)
                })
            }), E = Qt({
                intl: L,
                pricingPlan: E,
                promoMetadata: ee,
                currency: i.currency,
                planName: w.SELF_SERVE_BUSINESS,
                currentAccount: f,
                checkoutPricingConfig: x
            }), F = !0
        } else !ee && se && (ee = {
            plan_name: "chatgptteamplan",
            title: "",
            summary: "",
            discount: {
                value: 0,
                currency_code: "USD"
            },
            duration: {
                num_periods: 1,
                period: "month"
            },
            price_period: "recurring",
            promotion_type: "discount",
            promotion_type_label: L.formatMessage(kt.specialOffer)
        });
        se && !F && (E = $(O({}, E), {
            cost: $(O({}, E.cost), {
                costValue: 0,
                costTitle: Nt.promoCost,
                costDuration: Nt.promoCostDuration
            }),
            disclaimer: Nt.teamFreeTrialPromoDisclaimerWithPerSeatMonthlyPrice
        })), (Je = f == null ? void 0 : f.isFreeWorkspace) != null && Je.call(f) && (E = $(O({}, E), {
            disclaimer: void 0
        }));
        const de = Rs(),
            {
                selectedPlan: ue,
                numSeats: oe
            } = ra({
                promoData: I,
                promoDataIsFromQueryParam: H
            }),
            Pe = Kt({
                ctx: p,
                isFreeTrialEligible: !!(se && !B)
            }),
            {
                handleBusinessCheckoutRedirect: ne
            } = la({
                billingDetails: i,
                promoData: I,
                promoDataIsFromQueryParam: H,
                promoMetadata: ee,
                promoCode: m
            }),
            [Z, me] = V.useState(!1),
            J = async ve => {
                var Le;
                if (!j && !ve) {
                    R(!0);
                    return
                }
                pe.logEvent("Account Pay: Payment Checkout Clicked", ae), Pt(p, "chatgpt_account_payment_modal_upgrade_button_click", lt);
                const ft = Se(p, "3950229590"),
                    Ye = Es(p, "3990391703"),
                    $e = ft.get("enabled_custom_checkout_for_team", !1);
                let Ie = !Ye && $e;
                if (Ie && (F || I || de) && (Ie = Se(p, "3755185189").get("enabled_for_promo", !1)), Ie) {
                    const Ze = !!P && Se(p, "3542930659").get("show_business_loading", !1);
                    try {
                        me(!0), P && P(Ze), v(), M(), await ne(ue, oe, !0)
                    } catch (Xe) {
                        const et = Xe;
                        Fs.addError("Could not create business checkout session", {
                            error: et
                        })
                    }
                    me(!1), Ze && (P == null || P(!1));
                    return
                }
                const ht = (Le = new URLSearchParams(window.location.search).get("referrer")) != null ? Le : document.referrer;
                ao.setPurchaseWorkspaceData({
                    minimumSeats: ce,
                    billingDetails: i,
                    promoData: (I == null ? void 0 : I.state) === "eligible" && !F ? I : void 0,
                    promoDataIsFromQueryParam: (I == null ? void 0 : I.state) === "eligible" && !F ? H : void 0,
                    promoMetadata: F ? ee : null,
                    promoCode: m != null ? m : void 0,
                    referrer: ht
                }), wo(K), h && h()
            };
        Gs(G, {
            plan: ae
        });
        const fe = gt,
            z = lt;
        let le;
        e[6] !== g ? (le = Ft(g, "md:max-w-117"), e[6] = g, e[7] = le) : le = e[7];
        const je = Io,
            xe = ee,
            Ce = d === ye.highlight,
            ke = "flex flex-col gap-2",
            De = B && d !== ye.promo && a.jsx(us, {
                planType: lt,
                isCurrentPlan: !0,
                disabled: o != null || B,
                onClick: () => J(),
                testId: "select-plan-button-teams-upgrade",
                children: L.formatMessage(E.callToAction.active)
            }),
            Ue = _ != null ? _ : a.jsx(us, {
                className: "w-full",
                planType: lt,
                disabled: o != null,
                loading: Z,
                activeColor: d === ye.highlight ? "purple" : void 0,
                onClick: () => J(),
                testId: "select-plan-button-teams-create",
                children: Pe ? L.formatMessage(Pe) : B || ie ? L.formatMessage(E.callToAction.create) : L.formatMessage(E.callToAction.inactive)
            });
        let Ge;
        e[8] !== De || e[9] !== Ue ? (Ge = a.jsxs("div", {
            className: ke,
            children: [De, Ue]
        }), e[8] = De, e[9] = Ue, e[10] = Ge) : Ge = e[10];
        let ze;
        e[11] !== fe || e[12] !== i || e[13] !== D || e[14] !== n || e[15] !== W || e[16] !== A || e[17] !== E || e[18] !== I || e[19] !== c || e[20] !== se || e[21] !== Ce || e[22] !== Ge || e[23] !== z || e[24] !== le || e[25] !== je || e[26] !== xe || e[27] !== d ? (ze = a.jsx(fe, {
            planType: z,
            className: le,
            elementId: je,
            pricingPlan: E,
            promoData: I,
            promoMetadata: xe,
            type: d,
            shouldUseComparisonSpacing: c,
            isBusinessUpgradeV2CopyEnabled: W,
            isCheckoutPricingConfigLoading: A,
            checkoutPricingConfigError: D,
            hasEnabledTeamFreeTrialCoupon: se,
            useRecommendedBadge: Ce,
            enableComposerLoadPricingLayer: n,
            callToActionButton: Ge,
            billingDetails: i
        }), e[11] = fe, e[12] = i, e[13] = D, e[14] = n, e[15] = W, e[16] = A, e[17] = E, e[18] = I, e[19] = c, e[20] = se, e[21] = Ce, e[22] = Ge, e[23] = z, e[24] = le, e[25] = je, e[26] = xe, e[27] = d, e[28] = ze) : ze = e[28];
        let Be;
        e[29] !== R ? (Be = () => R(!1), e[29] = R, e[30] = Be) : Be = e[30];
        let We;
        e[31] !== L ? (We = L.formatMessage(ut.addEmailTitle), e[31] = L, e[32] = We) : We = e[32];
        let be;
        e[33] !== L ? (be = L.formatMessage(ut.addEmailDescription), e[33] = L, e[34] = be) : be = e[34];
        let _e;
        e[35] !== J || e[36] !== k || e[37] !== R ? (_e = async () => {
            R(!1), await k(), J(!0)
        }, e[35] = J, e[36] = k, e[37] = R, e[38] = _e) : _e = e[38];
        let Ee;
        e[39] !== We || e[40] !== be || e[41] !== _e ? (Ee = a.jsx(Bs, {
            enterEmailTitle: We,
            enterEmailDescription: be,
            onVerified: _e
        }), e[39] = We, e[40] = be, e[41] = _e, e[42] = Ee) : Ee = e[42];
        let He;
        e[43] !== G || e[44] !== Be || e[45] !== Ee ? (He = a.jsx($t, {
            testId: "modal-add-email",
            isOpen: G,
            onClose: Be,
            type: "success",
            className: "max-w-sm",
            children: Ee
        }), e[43] = G, e[44] = Be, e[45] = Ee, e[46] = He) : He = e[46];
        let Oe;
        return e[47] !== ze || e[48] !== He ? (Oe = a.jsxs(a.Fragment, {
            children: [ze, He]
        }), e[47] = ze, e[48] = He, e[49] = Oe) : Oe = e[49], Oe
    },
    fs = w.GO,
    ba = t => {
        "use forget";
        const e = Re.c(63);
        let {
            analyticsParams: s,
            billingDetails: o,
            setPlanLoading: i,
            currentAccount: u,
            planLoading: c,
            promoMetadata: r,
            type: g,
            autoUpgrade: _,
            fromiOSWebview: f,
            promoCode: m,
            referralCode: S,
            onClose: h,
            shouldUseComparisonSpacing: P,
            className: n,
            setShouldShowCheckoutLoadingOverlay: d,
            enableComposerLoadPricingLayer: l
        } = t;
        const v = P === void 0 ? !1 : P,
            C = pt(),
            M = mt();
        let p;
        const {
            eligible: b,
            campaignId: k
        } = js();
        let y = So({
            ctx: C
        });
        const x = y.summary ? M.formatMessage(y.summary) : "";
        !r && b && (!m && k && (p = k), r = {
            plan_name: Ke.GO,
            title: "",
            summary: x,
            discount: {
                percentage: 100
            },
            duration: {
                num_periods: 12,
                period: "month"
            },
            price_period: "recurring",
            promotion_type: "discount",
            promotion_type_label: M.formatMessage(kt.specialOffer)
        });
        let A, D;
        e[0] !== u ? (D = u.hasPaidSubscription(), e[0] = u, e[1] = D) : D = e[1];
        const L = D;
        let U;
        e[2] !== u || e[3] !== L ? (U = L && u.isGo(), e[2] = u, e[3] = L, e[4] = U) : U = e[4];
        const K = U,
            ce = r != null && "percentage" in r.discount && r.discount.percentage === 100,
            G = !K && !c,
            R = g === "promo" && (r == null ? void 0 : r.plan_type_change) === "equal";
        let B;
        e[5] !== u ? (B = u.getNextPlanType(), e[5] = u, e[6] = B) : B = e[6];
        const ie = B === w.GO,
            j = !(G || R) || ie,
            W = L && ds(w.GO) < ds(u.planType);
        let q;
        e[7] !== o.country || e[8] !== o.currency || e[9] !== C ? (q = {
            countryCode: o.country,
            currency: o.currency,
            ctx: C
        }, e[7] = o.country, e[8] = o.currency, e[9] = C, e[10] = q) : q = e[10];
        const {
            data: T,
            isLoading: E,
            error: N
        } = wt(q);
        if (!E && !N && T) {
            const J = _t(T, is, St.Month);
            y = $(O({}, y), {
                cost: {
                    costValue: J.amount,
                    costTitle: Ct(J.amount, is, o.currency)
                }
            }), A = r && Qt({
                intl: M,
                planName: w.GO,
                pricingPlan: y,
                promoMetadata: r,
                currency: o.currency,
                currentAccount: u,
                checkoutPricingConfig: T
            })
        }
        let ge = "primary";
        (g === "promo" || g === "highlight") && (ge = "purple"), L && g !== "promo" && (ge = "secondary");
        const {
            activeDiscountMetadata: Q,
            scheduledAdditionalLink: re
        } = qt({
            currentAccount: u,
            intl: M,
            billingDetails: o,
            pricingPlan: y,
            promoMetadata: r,
            columnPlanType: w.GO
        });
        let H;
        if (e[11] !== r || e[12] !== re) {
            if (H = [], re && H.push(re), !r) {
                let J;
                e[14] === Symbol.for("react.memo_cache_sentinel") ? (J = a.jsx(X, $(O({}, jt.limitsApplyLink), {
                    values: {
                        link: va
                    }
                }), "limits-apply-link"), e[14] = J) : J = e[14], H.push(J)
            }
            e[11] = r, e[12] = re, e[13] = H
        } else H = e[13];
        const I = A != null ? A : y;
        let se;
        e[15] !== s || e[16] !== p || e[17] !== m ? (se = $(O({}, s), {
            planType: w.GO,
            promoCode: m,
            promoCampaign: p
        }), e[15] = s, e[16] = p, e[17] = m, e[18] = se) : se = e[18];
        const ee = se,
            F = (b || ce) && !K;
        let de;
        e[19] !== C || e[20] !== F ? (de = Kt({
            ctx: C,
            isFreeTrialEligible: F
        }), e[19] = C, e[20] = F, e[21] = de) : de = e[21];
        const ue = de;
        let oe;
        e[22] !== h || e[23] !== g ? (oe = g === "promo" ? a.jsx(Ve, {
            size: "large",
            color: "secondary",
            onClick: h,
            children: a.jsx(X, O({}, jt.notNow))
        }) : null, e[22] = h, e[23] = g, e[24] = oe) : oe = e[24];
        const Pe = W && g !== "promo" ? "secondary" : ge;
        let ne;
        e[25] !== ue || e[26] !== K || e[27] !== W || e[28] !== y || e[29] !== g ? (ne = g === "promo" && K ? a.jsx(X, O({}, y.callToAction.promo)) : K ? a.jsx(X, O({}, y.callToAction.active)) : ue ? a.jsx(X, O({}, ue)) : W ? a.jsx(X, O({}, jt.switchToGo)) : a.jsx(X, O({}, y.callToAction.inactive)), e[25] = ue, e[26] = K, e[27] = W, e[28] = y, e[29] = g, e[30] = ne) : ne = e[30];
        let Z;
        e[31] !== _ || e[32] !== o || e[33] !== u || e[34] !== j || e[35] !== I || e[36] !== f || e[37] !== ee || e[38] !== h || e[39] !== c || e[40] !== p || e[41] !== m || e[42] !== r || e[43] !== S || e[44] !== i || e[45] !== d || e[46] !== Pe || e[47] !== ne ? (Z = a.jsx(zs, {
            currentAccount: u,
            analyticsParams: ee,
            billingDetails: o,
            planLoading: c,
            promoCode: m,
            referralCode: S,
            promoCampaign: p,
            setPlanLoading: i,
            planType: fs,
            onPromoClose: h,
            disabled: j,
            testId: "select-plan-button-go-upgrade",
            pricingPlan: I,
            activeColor: Pe,
            promoMetadata: r,
            setShouldShowCheckoutLoadingOverlay: d,
            autoUpgrade: _,
            fromiOSWebview: f,
            children: ne
        }), e[31] = _, e[32] = o, e[33] = u, e[34] = j, e[35] = I, e[36] = f, e[37] = ee, e[38] = h, e[39] = c, e[40] = p, e[41] = m, e[42] = r, e[43] = S, e[44] = i, e[45] = d, e[46] = Pe, e[47] = ne, e[48] = Z) : Z = e[48];
        let me;
        return e[49] !== Q || e[50] !== H || e[51] !== o || e[52] !== N || e[53] !== n || e[54] !== I || e[55] !== l || e[56] !== E || e[57] !== r || e[58] !== v || e[59] !== Z || e[60] !== oe || e[61] !== g ? (me = a.jsx(gt, {
            className: n,
            type: g,
            planType: fs,
            activeDiscountMetadata: Q,
            pricingPlan: I,
            promoMetadata: r,
            secondaryCallToActionButton: oe,
            callToActionButton: Z,
            additionalLinks: H,
            billingDetails: o,
            shouldUseComparisonSpacing: v,
            isCheckoutPricingConfigLoading: E,
            checkoutPricingConfigError: N,
            enableComposerLoadPricingLayer: l
        }), e[49] = Q, e[50] = H, e[51] = o, e[52] = N, e[53] = n, e[54] = I, e[55] = l, e[56] = E, e[57] = r, e[58] = v, e[59] = Z, e[60] = oe, e[61] = g, e[62] = me) : me = e[62], me
    },
    jt = qe({
        limitsApplyLink: {
            id: "GoColumn.limitsApplyLink",
            defaultMessage: "Only available in certain regions. <link>Limits apply</link>"
        },
        switchToGo: {
            id: "GoColumn.switchToGo",
            defaultMessage: "Switch to Go"
        },
        notNow: {
            id: "GoColumn.notNow",
            defaultMessage: "Not Now"
        }
    });

function va(t) {
    return a.jsx(Ae, {
        target: "_blank",
        rel: "noopener noreferrer",
        to: Ao,
        onClick: At,
        className: "font-medium underline",
        children: t
    }, "row-go-plan-help-link")
}

function Ma(t, {
    selectedTab: e,
    currentAccount: s,
    isGoEnabled: o
}) {
    return e !== "personal" || !s.isFree() || !o ? !1 : Se(t, "3503208034").get("highlight_plus", !1)
}

function Ta() {
    const t = sessionStorage.getItem(Ds);
    if (t) try {
        const e = JSON.parse(t),
            s = sessionStorage.getItem(Lo),
            o = sessionStorage.getItem(No);
        if ((s || o) && e) {
            const i = xa(e.plan_name);
            return {
                promoCode: s != null ? s : void 0,
                referralCode: o != null ? o : void 0,
                promoMetadata: e,
                promoMetadataPlanType: i
            }
        }
    } catch (e) {}
    return {
        promoCode: void 0,
        referralCode: void 0,
        promoMetadata: null,
        promoMetadataPlanType: null
    }
}

function xa(t) {
    switch (t) {
        case Ke.GO:
            return w.GO;
        case Ke.PLUS:
            return w.PLUS;
        case Ke.PRO:
            return w.PRO;
        case Ke.SELF_SERVE_BUSINESS:
            return w.SELF_SERVE_BUSINESS;
        default:
            return null
    }
}

function ka({
    analyticsParams: t,
    currentAccount: e,
    planLoading: s,
    selectedTab: o,
    setPlanLoading: i,
    setShouldShowCheckoutLoadingOverlay: u,
    billingDetails: c,
    onClose: r,
    ctx: g,
    businessComparisonEnabled: _ = !1,
    eligibleComparisonPlans: f,
    autoUpgradePlanType: m,
    fromiOSWebview: S,
    hideProPlan: h
}) {
    const P = e.hasPaidSubscription(),
        {
            promoCode: n,
            referralCode: d,
            promoMetadata: l,
            promoMetadataPlanType: v
        } = Ta(),
        C = Oo(g),
        M = Ma(g, {
            selectedTab: o,
            currentAccount: e,
            isGoEnabled: C
        }),
        p = Ia(o, _, f, e);
    let k = Ea({
        selectedTab: o,
        hasPaidSubscription: P,
        isGoEnabled: C,
        hideProPlan: h,
        isTeamAccount: e.isSelfServeBusiness(),
        isComparisonExperiment: !!_,
        comparisonPlanName: p
    });
    return h && (k = k.filter(y => y !== "pro")), k.map(y => {
        switch (y) {
            case "free_workspace":
                return a.jsx(fa, {
                    billingDetails: c,
                    shouldUseComparisonSpacing: p === "free_workspace",
                    type: ye.standard
                }, y);
            case "free":
                return a.jsx(ma, {
                    billingDetails: c,
                    shouldUseComparisonSpacing: p === "free"
                }, y);
            case "go":
                {
                    const x = o === "business" && p === "go" ? ye.standard : C && e.isFree() && !M ? ye.highlight : ye.standard;
                    return a.jsx(ba, {
                        setShouldShowCheckoutLoadingOverlay: u,
                        promoMetadata: v === w.GO ? l : null,
                        promoCode: v === w.GO ? n : void 0,
                        referralCode: v === w.GO ? d : void 0,
                        analyticsParams: t,
                        setPlanLoading: i,
                        billingDetails: c,
                        currentAccount: e,
                        planLoading: s,
                        type: x,
                        autoUpgrade: m === w.GO,
                        fromiOSWebview: S,
                        shouldUseComparisonSpacing: p === "go",
                        enableComposerLoadPricingLayer: !0
                    }, y)
                }
            case "plus":
                {
                    const x = o === "business" && p === "plus" ? ye.standard : e.isFree() && (!C || M) ? ye.highlight : ye.standard;
                    return a.jsx(ya, {
                        promoMetadata: v === w.PLUS ? l : null,
                        promoCode: v === w.PLUS ? n : void 0,
                        referralCode: v === w.PLUS ? d : void 0,
                        analyticsParams: t,
                        currentAccount: e,
                        setPlanLoading: i,
                        setShouldShowCheckoutLoadingOverlay: u,
                        planLoading: s,
                        billingDetails: c,
                        onClose: r,
                        type: x,
                        shouldUseComparisonSpacing: p === "plus",
                        autoUpgrade: m === w.PLUS,
                        fromiOSWebview: S,
                        enableComposerLoadPricingLayer: !0
                    }, y)
                }
            case "team":
                {
                    const x = _ === !0 ? ye.highlight : ye.standard;
                    return a.jsx(Ca, {
                        promoMetadata: v === w.SELF_SERVE_BUSINESS ? l : null,
                        promoCode: v === w.SELF_SERVE_BUSINESS ? n : void 0,
                        analyticsParams: t,
                        billingDetails: c,
                        currentAccount: e,
                        planLoading: s,
                        type: x,
                        shouldUseComparisonSpacing: p !== void 0,
                        setShouldShowCheckoutLoadingOverlay: u,
                        enableComposerLoadPricingLayer: !0
                    }, y)
                }
            case "pro":
                return a.jsx(_a, {
                    setShouldShowCheckoutLoadingOverlay: u,
                    analyticsParams: t,
                    currentAccount: e,
                    setPlanLoading: i,
                    planLoading: s,
                    billingDetails: c,
                    autoUpgrade: m === w.PRO,
                    fromiOSWebview: S,
                    shouldUseComparisonSpacing: p === "pro",
                    enableComposerLoadPricingLayer: !0
                }, y)
        }
        return null
    })
}

function Ea({
    selectedTab: t,
    hasPaidSubscription: e,
    isGoEnabled: s,
    isTeamAccount: o,
    isComparisonExperiment: i,
    comparisonPlanName: u,
    hideProPlan: c
}) {
    const r = [];
    return t === "personal" ? (e || r.push("free"), s && r.push("go"), r.push("plus"), r.push("pro")) : (i && !o && u && r.push(u), r.push("team")), c ? r.filter(_ => _ !== "pro") : r
}

function Ia(t, e, s, o) {
    if (t === "business" && !(!e || !s)) {
        if (o.isFree()) return s.has("free") ? "free" : void 0;
        if (o.isGo()) return s.has("go") ? "go" : void 0;
        if (o.isPlus()) return s.has("plus") ? "plus" : void 0;
        if (o.isPro()) return s.has("pro") ? "pro" : void 0;
        if (o.isFreeWorkspace()) return s.has("free_workspace") ? "free_workspace" : void 0
    }
}

function Wt() {
    return Wt = Object.assign ? Object.assign.bind() : function(t) {
        for (var e = 1; e < arguments.length; e++) {
            var s = arguments[e];
            for (var o in s)({}).hasOwnProperty.call(s, o) && (t[o] = s[o])
        }
        return t
    }, Wt.apply(null, arguments)
}

function hs(t) {
    if (t === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return t
}

function Ht(t, e) {
    return Ht = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(s, o) {
        return s.__proto__ = o, s
    }, Ht(t, e)
}

function Fa(t, e) {
    t.prototype = Object.create(e.prototype), t.prototype.constructor = t, Ht(t, e)
}
var ys = Number.isNaN || function(e) {
    return typeof e == "number" && e !== e
};

function wa(t, e) {
    return !!(t === e || ys(t) && ys(e))
}

function Aa(t, e) {
    if (t.length !== e.length) return !1;
    for (var s = 0; s < t.length; s++)
        if (!wa(t[s], e[s])) return !1;
    return !0
}

function Dt(t, e) {
    e === void 0 && (e = Aa);
    var s, o = [],
        i, u = !1;

    function c() {
        for (var r = [], g = 0; g < arguments.length; g++) r[g] = arguments[g];
        return u && s === this && e(r, o) || (i = t.apply(this, r), u = !0, s = this, o = r), i
    }
    return c
}
var Oa = typeof performance == "object" && typeof performance.now == "function",
    Ps = Oa ? function() {
        return performance.now()
    } : function() {
        return Date.now()
    };

function _s(t) {
    cancelAnimationFrame(t.id)
}

function La(t, e) {
    var s = Ps();

    function o() {
        Ps() - s >= e ? t.call(null) : i.id = requestAnimationFrame(o)
    }
    var i = {
        id: requestAnimationFrame(o)
    };
    return i
}
var Ut = -1;

function Ss(t) {
    if (t === void 0 && (t = !1), Ut === -1 || t) {
        var e = document.createElement("div"),
            s = e.style;
        s.width = "50px", s.height = "50px", s.overflow = "scroll", document.body.appendChild(e), Ut = e.offsetWidth - e.clientWidth, document.body.removeChild(e)
    }
    return Ut
}
var ct = null;

function Cs(t) {
    if (t === void 0 && (t = !1), ct === null || t) {
        var e = document.createElement("div"),
            s = e.style;
        s.width = "50px", s.height = "50px", s.overflow = "scroll", s.direction = "rtl";
        var o = document.createElement("div"),
            i = o.style;
        return i.width = "100px", i.height = "100px", e.appendChild(o), document.body.appendChild(e), e.scrollLeft > 0 ? ct = "positive-descending" : (e.scrollLeft = 1, e.scrollLeft === 0 ? ct = "negative" : ct = "positive-ascending"), document.body.removeChild(e), ct
    }
    return ct
}
var Na = 150,
    Ra = function(e, s) {
        return e
    };

function ja(t) {
    var e, s = t.getItemOffset,
        o = t.getEstimatedTotalSize,
        i = t.getItemSize,
        u = t.getOffsetForIndexAndAlignment,
        c = t.getStartIndexForOffset,
        r = t.getStopIndexForStartIndex,
        g = t.initInstanceProps,
        _ = t.shouldResetStyleCacheOnItemSizeChange,
        f = t.validateProps;
    return e = (function(m) {
        Fa(S, m);

        function S(P) {
            var n;
            return n = m.call(this, P) || this, n._instanceProps = g(n.props, hs(n)), n._outerRef = void 0, n._resetIsScrollingTimeoutId = null, n.state = {
                instance: hs(n),
                isScrolling: !1,
                scrollDirection: "forward",
                scrollOffset: typeof n.props.initialScrollOffset == "number" ? n.props.initialScrollOffset : 0,
                scrollUpdateWasRequested: !1
            }, n._callOnItemsRendered = void 0, n._callOnItemsRendered = Dt(function(d, l, v, C) {
                return n.props.onItemsRendered({
                    overscanStartIndex: d,
                    overscanStopIndex: l,
                    visibleStartIndex: v,
                    visibleStopIndex: C
                })
            }), n._callOnScroll = void 0, n._callOnScroll = Dt(function(d, l, v) {
                return n.props.onScroll({
                    scrollDirection: d,
                    scrollOffset: l,
                    scrollUpdateWasRequested: v
                })
            }), n._getItemStyle = void 0, n._getItemStyle = function(d) {
                var l = n.props,
                    v = l.direction,
                    C = l.itemSize,
                    M = l.layout,
                    p = n._getItemStyleCache(_ && C, _ && M, _ && v),
                    b;
                if (p.hasOwnProperty(d)) b = p[d];
                else {
                    var k = s(n.props, d, n._instanceProps),
                        y = i(n.props, d, n._instanceProps),
                        x = v === "horizontal" || M === "horizontal",
                        A = v === "rtl",
                        D = x ? k : 0;
                    p[d] = b = {
                        position: "absolute",
                        left: A ? void 0 : D,
                        right: A ? D : void 0,
                        top: x ? 0 : k,
                        height: x ? "100%" : y,
                        width: x ? y : "100%"
                    }
                }
                return b
            }, n._getItemStyleCache = void 0, n._getItemStyleCache = Dt(function(d, l, v) {
                return {}
            }), n._onScrollHorizontal = function(d) {
                var l = d.currentTarget,
                    v = l.clientWidth,
                    C = l.scrollLeft,
                    M = l.scrollWidth;
                n.setState(function(p) {
                    if (p.scrollOffset === C) return null;
                    var b = n.props.direction,
                        k = C;
                    if (b === "rtl") switch (Cs()) {
                        case "negative":
                            k = -C;
                            break;
                        case "positive-descending":
                            k = M - v - C;
                            break
                    }
                    return k = Math.max(0, Math.min(k, M - v)), {
                        isScrolling: !0,
                        scrollDirection: p.scrollOffset < k ? "forward" : "backward",
                        scrollOffset: k,
                        scrollUpdateWasRequested: !1
                    }
                }, n._resetIsScrollingDebounced)
            }, n._onScrollVertical = function(d) {
                var l = d.currentTarget,
                    v = l.clientHeight,
                    C = l.scrollHeight,
                    M = l.scrollTop;
                n.setState(function(p) {
                    if (p.scrollOffset === M) return null;
                    var b = Math.max(0, Math.min(M, C - v));
                    return {
                        isScrolling: !0,
                        scrollDirection: p.scrollOffset < b ? "forward" : "backward",
                        scrollOffset: b,
                        scrollUpdateWasRequested: !1
                    }
                }, n._resetIsScrollingDebounced)
            }, n._outerRefSetter = function(d) {
                var l = n.props.outerRef;
                n._outerRef = d, typeof l == "function" ? l(d) : l != null && typeof l == "object" && l.hasOwnProperty("current") && (l.current = d)
            }, n._resetIsScrollingDebounced = function() {
                n._resetIsScrollingTimeoutId !== null && _s(n._resetIsScrollingTimeoutId), n._resetIsScrollingTimeoutId = La(n._resetIsScrolling, Na)
            }, n._resetIsScrolling = function() {
                n._resetIsScrollingTimeoutId = null, n.setState({
                    isScrolling: !1
                }, function() {
                    n._getItemStyleCache(-1, null)
                })
            }, n
        }
        S.getDerivedStateFromProps = function(n, d) {
            return Da(n, d), f(n), null
        };
        var h = S.prototype;
        return h.scrollTo = function(n) {
            n = Math.max(0, n), this.setState(function(d) {
                return d.scrollOffset === n ? null : {
                    scrollDirection: d.scrollOffset < n ? "forward" : "backward",
                    scrollOffset: n,
                    scrollUpdateWasRequested: !0
                }
            }, this._resetIsScrollingDebounced)
        }, h.scrollToItem = function(n, d) {
            d === void 0 && (d = "auto");
            var l = this.props,
                v = l.itemCount,
                C = l.layout,
                M = this.state.scrollOffset;
            n = Math.max(0, Math.min(n, v - 1));
            var p = 0;
            if (this._outerRef) {
                var b = this._outerRef;
                C === "vertical" ? p = b.scrollWidth > b.clientWidth ? Ss() : 0 : p = b.scrollHeight > b.clientHeight ? Ss() : 0
            }
            this.scrollTo(u(this.props, n, d, M, this._instanceProps, p))
        }, h.componentDidMount = function() {
            var n = this.props,
                d = n.direction,
                l = n.initialScrollOffset,
                v = n.layout;
            if (typeof l == "number" && this._outerRef != null) {
                var C = this._outerRef;
                d === "horizontal" || v === "horizontal" ? C.scrollLeft = l : C.scrollTop = l
            }
            this._callPropsCallbacks()
        }, h.componentDidUpdate = function() {
            var n = this.props,
                d = n.direction,
                l = n.layout,
                v = this.state,
                C = v.scrollOffset,
                M = v.scrollUpdateWasRequested;
            if (M && this._outerRef != null) {
                var p = this._outerRef;
                if (d === "horizontal" || l === "horizontal")
                    if (d === "rtl") switch (Cs()) {
                        case "negative":
                            p.scrollLeft = -C;
                            break;
                        case "positive-ascending":
                            p.scrollLeft = C;
                            break;
                        default:
                            var b = p.clientWidth,
                                k = p.scrollWidth;
                            p.scrollLeft = k - b - C;
                            break
                    } else p.scrollLeft = C;
                    else p.scrollTop = C
            }
            this._callPropsCallbacks()
        }, h.componentWillUnmount = function() {
            this._resetIsScrollingTimeoutId !== null && _s(this._resetIsScrollingTimeoutId)
        }, h.render = function() {
            var n = this.props,
                d = n.children,
                l = n.className,
                v = n.direction,
                C = n.height,
                M = n.innerRef,
                p = n.innerElementType,
                b = n.innerTagName,
                k = n.itemCount,
                y = n.itemData,
                x = n.itemKey,
                A = x === void 0 ? Ra : x,
                D = n.layout,
                L = n.outerElementType,
                U = n.outerTagName,
                K = n.style,
                ce = n.useIsScrolling,
                G = n.width,
                R = this.state.isScrolling,
                B = v === "horizontal" || D === "horizontal",
                ie = B ? this._onScrollHorizontal : this._onScrollVertical,
                ae = this._getRangeToRender(),
                j = ae[0],
                W = ae[1],
                q = [];
            if (k > 0)
                for (var T = j; T <= W; T++) q.push(V.createElement(d, {
                    data: y,
                    key: A(T, y),
                    index: T,
                    isScrolling: ce ? R : void 0,
                    style: this._getItemStyle(T)
                }));
            var E = o(this.props, this._instanceProps);
            return V.createElement(L || U || "div", {
                className: l,
                onScroll: ie,
                ref: this._outerRefSetter,
                style: Wt({
                    position: "relative",
                    height: C,
                    width: G,
                    overflow: "auto",
                    WebkitOverflowScrolling: "touch",
                    willChange: "transform",
                    direction: v
                }, K)
            }, V.createElement(p || b || "div", {
                children: q,
                ref: M,
                style: {
                    height: B ? "100%" : E,
                    pointerEvents: R ? "none" : void 0,
                    width: B ? E : "100%"
                }
            }))
        }, h._callPropsCallbacks = function() {
            if (typeof this.props.onItemsRendered == "function") {
                var n = this.props.itemCount;
                if (n > 0) {
                    var d = this._getRangeToRender(),
                        l = d[0],
                        v = d[1],
                        C = d[2],
                        M = d[3];
                    this._callOnItemsRendered(l, v, C, M)
                }
            }
            if (typeof this.props.onScroll == "function") {
                var p = this.state,
                    b = p.scrollDirection,
                    k = p.scrollOffset,
                    y = p.scrollUpdateWasRequested;
                this._callOnScroll(b, k, y)
            }
        }, h._getRangeToRender = function() {
            var n = this.props,
                d = n.itemCount,
                l = n.overscanCount,
                v = this.state,
                C = v.isScrolling,
                M = v.scrollDirection,
                p = v.scrollOffset;
            if (d === 0) return [0, 0, 0, 0];
            var b = c(this.props, p, this._instanceProps),
                k = r(this.props, b, p, this._instanceProps),
                y = !C || M === "backward" ? Math.max(1, l) : 1,
                x = !C || M === "forward" ? Math.max(1, l) : 1;
            return [Math.max(0, b - y), Math.max(0, Math.min(d - 1, k + x)), b, k]
        }, S
    })(V.PureComponent), e.defaultProps = {
        direction: "ltr",
        itemData: void 0,
        layout: "vertical",
        overscanCount: 2,
        useIsScrolling: !1
    }, e
}
var Da = function(e, s) {
        e.children, e.direction, e.height, e.layout, e.innerTagName, e.outerTagName, e.width, s.instance
    },
    Ua = ja({
        getItemOffset: function(e, s) {
            var o = e.itemSize;
            return s * o
        },
        getItemSize: function(e, s) {
            var o = e.itemSize;
            return o
        },
        getEstimatedTotalSize: function(e) {
            var s = e.itemCount,
                o = e.itemSize;
            return o * s
        },
        getOffsetForIndexAndAlignment: function(e, s, o, i, u, c) {
            var r = e.direction,
                g = e.height,
                _ = e.itemCount,
                f = e.itemSize,
                m = e.layout,
                S = e.width,
                h = r === "horizontal" || m === "horizontal",
                P = h ? S : g,
                n = Math.max(0, _ * f - P),
                d = Math.min(n, s * f),
                l = Math.max(0, s * f - P + f + c);
            switch (o === "smart" && (i >= l - P && i <= d + P ? o = "auto" : o = "center"), o) {
                case "start":
                    return d;
                case "end":
                    return l;
                case "center":
                    {
                        var v = Math.round(l + (d - l) / 2);
                        return v < Math.ceil(P / 2) ? 0 : v > n + Math.floor(P / 2) ? n : v
                    }
                case "auto":
                default:
                    return i >= l && i <= d ? i : i < l ? l : d
            }
        },
        getStartIndexForOffset: function(e, s) {
            var o = e.itemCount,
                i = e.itemSize;
            return Math.max(0, Math.min(o - 1, Math.floor(s / i)))
        },
        getStopIndexForStartIndex: function(e, s, o) {
            var i = e.direction,
                u = e.height,
                c = e.itemCount,
                r = e.itemSize,
                g = e.layout,
                _ = e.width,
                f = i === "horizontal" || g === "horizontal",
                m = s * r,
                S = f ? _ : u,
                h = Math.ceil((S + o - m) / r);
            return Math.max(0, Math.min(c - 1, s + h - 1))
        },
        initInstanceProps: function(e) {},
        shouldResetStyleCacheOnItemSizeChange: !0,
        validateProps: function(e) {
            e.itemSize
        }
    });

function Ga({
    onChange: t,
    value: e
}) {
    const s = Ro(),
        o = jo(),
        i = V.useMemo(() => o.filter(c => c !== e), [e, o]),
        u = 480;
    return a.jsx("div", {
        children: a.jsxs(Ne.Root, {
            value: e,
            onValueChange: t,
            children: [a.jsxs(Ne.Trigger, {
                children: [a.jsx(Ne.Value, {}), a.jsx(Ne.Icon, {})]
            }), a.jsx(Ne.Portal, {
                children: a.jsxs(Ne.Content, {
                    position: "popper",
                    style: {
                        maxHeight: u,
                        width: 200
                    },
                    children: [a.jsx(Ne.Item, {
                        value: e,
                        children: s(e)
                    }), a.jsx(Ne.Separator, {}), a.jsx(Ua, {
                        className: "no-scrollbar",
                        height: u - 80,
                        itemCount: i.length,
                        itemSize: 50,
                        layout: "vertical",
                        width: "100%",
                        overscanCount: 20,
                        itemKey: c => i[c],
                        children: ({
                            index: c,
                            style: r
                        }) => {
                            const g = i[c];
                            return a.jsx(Ne.Item, {
                                value: g,
                                style: r,
                                children: s(g)
                            })
                        }
                    })]
                })
            })]
        })
    })
}
const za = xs.memo(Ga);

function Ba(t) {
    "use forget";
    const e = Re.c(15),
        {
            modalTitle: s,
            subtitle: o,
            isFromIosWebview: i,
            handleClose: u
        } = t,
        c = no();
    let r;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (r = a.jsx("div", {}), e[0] = r) : r = e[0];
    let g;
    e[1] !== s ? (g = a.jsx("h2", {
        className: "text-page-header",
        children: a.jsx(X, O({}, s))
    }), e[1] = s, e[2] = g) : g = e[2];
    let _;
    e[3] !== o ? (_ = o ? a.jsx("div", {
        className: "text-token-text-secondary mt-3 mb-1",
        children: a.jsx(X, O({}, o))
    }) : null, e[3] = o, e[4] = _) : _ = e[4];
    let f;
    e[5] !== g || e[6] !== _ ? (f = a.jsxs("div", {
        className: "my-1 flex flex-col items-center justify-center md:mt-0 md:mb-0",
        children: [g, _]
    }), e[5] = g, e[6] = _, e[7] = f) : f = e[7];
    let m;
    e[8] !== u || e[9] !== i || e[10] !== c ? (m = !i && a.jsx("button", {
        className: "text-token-text-primary justify-self-end opacity-50 transition hover:opacity-75 md:absolute md:end-6 md:top-6",
        onClick: () => {
            u()
        },
        children: a.jsx(io, {
            className: Ft({
                "h-5 w-5": !c,
                "icon-lg": c
            })
        })
    }), e[8] = u, e[9] = i, e[10] = c, e[11] = m) : m = e[11];
    let S;
    return e[12] !== f || e[13] !== m ? (S = a.jsxs("div", {
        className: "relative grid grid-cols-[1fr_auto_1fr] px-6 py-4 md:pt-[4.5rem] md:pb-6",
        children: [r, f, m]
    }), e[12] = f, e[13] = m, e[14] = S) : S = e[14], S
}
const bs = "https://help.openai.com/ko-kr",
    Wa = "https://openai.com/ko-KR/policies/row-terms-of-use/",
    Ha = "https://www.ftc.go.kr/selectBizOvrCommPop.do?apvPermMgtNo=2025%EA%B3%B5%EC%A0%950019";

function Ya() {
    "use forget";
    var r, g;
    const t = Re.c(2);
    if (!((g = (r = mt().locale) == null ? void 0 : r.toLowerCase()) != null ? g : "").startsWith("ko")) return null;
    let i;
    t[0] === Symbol.for("react.memo_cache_sentinel") ? (i = [{
        label: "OpenAI, L.L.C."
    }, {
        label: "대표자: Sam Altman"
    }, {
        label: "주소: 1455 3rd Street, San Francisco, CA 94158"
    }, {
        label: "전화: 02-735-2109"
    }, {
        label: bs,
        href: bs
    }, {
        label: "사업자등록번호: 634-80-02934"
    }, {
        label: "통신판매업신고번호: 2025-공정-0019"
    }, {
        label: "이용 약관",
        href: Wa
    }, {
        label: "호스팅 서비스 제공: Microsoft Azure"
    }, {
        label: "사업자 추가 정보",
        href: Ha
    }], t[0] = i) : i = t[0];
    const u = i;
    let c;
    return t[1] === Symbol.for("react.memo_cache_sentinel") ? (c = a.jsx("div", {
        className: "text-token-text-secondary flex w-full max-w-5xl flex-wrap items-center justify-center gap-x-2 gap-y-1 px-3 py-2 text-center text-xs leading-relaxed md:px-4 md:py-3",
        children: u.map($a)
    }), t[1] = c) : c = t[1], c
}

function $a(t, e) {
    return a.jsxs(xs.Fragment, {
        children: [e > 0 && a.jsx("span", {
            "aria-hidden": "true",
            children: "|"
        }), t.href ? a.jsx("a", {
            href: t.href,
            target: "_blank",
            rel: "noreferrer",
            className: "text-token-text-secondary decoration-token-text-secondary hover:text-token-text-primary underline transition",
            children: t.label
        }) : a.jsx("span", {
            children: t.label
        })]
    }, "".concat(t.label, "-").concat(e))
}

function Va() {
    "use forget";
    const t = Re.c(4),
        e = Do(),
        s = e.eligible && e.campaignId ? e.campaignId : void 0,
        o = Ns(),
        i = o.eligible && o.campaignId ? o.campaignId : void 0,
        u = js(),
        c = u.eligible && u.campaignId ? u.campaignId : void 0;
    let r;
    return t[0] !== c || t[1] !== s || t[2] !== i ? (r = {
        plusPromoCampaignForAnalytics: s,
        teamPromoCampaignForAnalytics: i,
        goPromoCampaignForAnalytics: c
    }, t[0] = c, t[1] = s, t[2] = i, t[3] = r) : r = t[3], r
}

function Ka({
    ctx: t,
    currentAccount: e,
    selectedTab: s,
    user: o,
    shouldUseBusinessFreeWorkspaceExperience: i
}) {
    const u = {
        comparisonEnabled: !1,
        eligiblePlans: new Set
    };
    if (s !== "business") return u;
    if (i) return {
        comparisonEnabled: !0,
        eligiblePlans: new Set(["free_workspace"])
    };
    const r = o != null && co(o) && (e.isFree() || e.isPlus()),
        g = Se(t, "2762630623"),
        _ = r ? g.get("variant", "control") : "control",
        f = e.isFree() || e.isGo() || e.isPlus() || e.isPro(),
        m = Se(t, "4105912492");
    return (f ? m.get("variant", "control") : "control") !== "control" ? {
        comparisonEnabled: !0,
        eligiblePlans: new Set(["free", "go", "plus", "pro"])
    } : _ !== "control" ? {
        comparisonEnabled: !0,
        eligiblePlans: new Set(["free", "plus"])
    } : u
}

function Cn(t) {
    "use forget";
    const e = Re.c(99),
        {
            currentAccount: s,
            defaultTab: o,
            onClose: i,
            subtitle: u,
            title: c
        } = t,
        r = o === void 0 ? "personal" : o,
        [g, _] = V.useState(null),
        [f, m] = V.useState(!1),
        S = vs(),
        [h] = Ms(),
        P = h.get("plan");
    let n;
    e[0] !== h ? (n = h.get("from_webview"), e[0] = h, e[1] = n) : n = e[1];
    const d = n,
        l = !s.hasPaidSubscription() && d === "ios" && !!P,
        v = P === w.PLUS || P === w.PRO || P === w.GO ? P : null;
    let C;
    e[2] !== h ? (C = h.get("from_webview"), e[2] = h, e[3] = C) : C = e[3];
    const M = C === "ios",
        p = ro(),
        b = qs(),
        k = V.useRef(!1),
        y = pt(),
        x = s.isFreeWorkspace(),
        A = x ? "business" : r;
    let D;
    e[4] !== S.state || e[5] !== h ? (D = () => {
        var Me;
        const Y = (Me = S.state) == null ? void 0 : Me[rs],
            Fe = h.get(rs);
        return Y === ls || Fe === ls
    }, e[4] = S.state, e[5] = h, e[6] = D) : D = e[6];
    const [L] = V.useState(D), U = L && Se(y, "3856567563").get("plus_trial_pricing_focus", !1);
    let K;
    e[7] === Symbol.for("react.memo_cache_sentinel") ? (K = [], e[7] = K) : K = e[7], V.useEffect(Za, K);
    let ce;
    e[8] !== s.subscriptionAnalyticsParams ? (ce = $(O({}, s.subscriptionAnalyticsParams), {
        referrer: document.referrer
    }), e[8] = s.subscriptionAnalyticsParams, e[9] = ce) : ce = e[9];
    const G = ce,
        R = Ts();
    let B;
    e[10] !== y ? (B = lo(y), e[10] = y, e[11] = B) : B = e[11];
    const ie = B;
    let ae;
    e[12] !== G || e[13] !== i ? (ae = () => {
        pe.logEvent("Account Pay: Close Account Payment Modal", G), i()
    }, e[12] = G, e[13] = i, e[14] = ae) : ae = e[14];
    const j = ae;
    let W, q;
    e[15] !== s.id || e[16] !== j || e[17] !== ie ? (q = () => {
        const Y = localStorage.getItem("subscriptionUpdateMessage_".concat(s.id));
        if (Y) {
            localStorage.removeItem("subscriptionUpdateMessage_".concat(s.id)), ie.success(Y, {
                hasCloseButton: !0
            });
            const Fe = setTimeout(() => {
                j()
            }, 5e3);
            return () => {
                clearTimeout(Fe)
            }
        }
    }, W = [s.id, ie, j], e[15] = s.id, e[16] = j, e[17] = ie, e[18] = W, e[19] = q) : (W = e[18], q = e[19]), V.useEffect(q, W);
    const [T, E] = V.useState(A), {
        country: N,
        setCountry: ge,
        userCountry: Q
    } = Uo();
    let re;
    e[20] !== s || e[21] !== T ? (re = Ja({
        currentAccount: s,
        selectedTab: T
    }), e[20] = s, e[21] = T, e[22] = re) : re = e[22];
    const H = re,
        I = H ? N : Go,
        se = T === "personal";
    let ee;
    e[23] !== s || e[24] !== I || e[25] !== se ? (ee = {
        country: I,
        currentAccount: s,
        location: "AccountPaymentModal",
        shouldUsePaidSubscriptionBillingCurrency: se
    }, e[23] = s, e[24] = I, e[25] = se, e[26] = ee) : ee = e[26];
    const F = zo(ee),
        {
            plusPromoCampaignForAnalytics: de,
            teamPromoCampaignForAnalytics: ue,
            goPromoCampaignForAnalytics: oe
        } = Va(),
        {
            comparisonEnabled: Pe,
            eligiblePlans: ne
        } = Ka({
            ctx: y,
            currentAccount: s,
            selectedTab: T,
            user: p,
            shouldUseBusinessFreeWorkspaceExperience: x
        });
    let Z;
    e[27] !== G || e[28] !== (F == null ? void 0 : F.country) || e[29] !== (F == null ? void 0 : F.currency) || e[30] !== oe || e[31] !== H || e[32] !== S.hash || e[33] !== S.search || e[34] !== S.state || e[35] !== R || e[36] !== b || e[37] !== A || e[38] !== de || e[39] !== N || e[40] !== ue || e[41] !== Q ? (Z = () => {
        var we, Zt, Jt, Xt, es, ts;
        const Y = (we = S.state) == null ? void 0 : we[Vo];
        Y && R({
            hash: S.hash,
            search: S.search
        }, {
            replace: !0,
            state: {}
        });
        const Me = (Zt = new URLSearchParams(window.location.search).get("referrer")) != null ? Zt : document.referrer;
        uo.count(mo.DEFAULT, "chatgpt_account_payment_modal_show", [{
            key: "location",
            value: Y
        }, {
            key: "navigationType",
            value: b
        }, {
            key: "initialTab",
            value: A
        }, {
            key: "initialCountrySelectorCountry",
            value: N
        }, {
            key: "selectedCountry",
            value: (Jt = F == null ? void 0 : F.country) != null ? Jt : ""
        }, {
            key: "selectedCurrency",
            value: (Xt = F == null ? void 0 : F.currency) != null ? Xt : ""
        }, {
            key: "userCountry",
            value: Q != null ? Q : ""
        }, {
            key: "isCountrySelectorEnabled",
            value: String(H)
        }]), pe.logEventWithStatsig("Account Pay: Account Payment Modal Show", "chatgpt_account_payment_modal_show", $(O({}, G), {
            initialTab: A,
            location: Y,
            navigationType: b,
            initialCountrySelectorCountry: N,
            selectedCountry: (es = F == null ? void 0 : F.country) != null ? es : "",
            selectedCurrency: (ts = F == null ? void 0 : F.currency) != null ? ts : "",
            userCountry: Q != null ? Q : "",
            isCountrySelectorEnabled: H,
            referrer: Me,
            plusPromoCampaign: de != null ? de : null,
            teamPromoCampaign: ue != null ? ue : null,
            goPromoCampaign: oe != null ? oe : null
        }))
    }, e[27] = G, e[28] = F == null ? void 0 : F.country, e[29] = F == null ? void 0 : F.currency, e[30] = oe, e[31] = H, e[32] = S.hash, e[33] = S.search, e[34] = S.state, e[35] = R, e[36] = b, e[37] = A, e[38] = de, e[39] = N, e[40] = ue, e[41] = Q, e[42] = Z) : Z = e[42], Bo(Z);
    let me;
    e[43] !== N || e[44] !== ge ? (me = Y => {
        Fs.addAction("chatgpt_selected_country_changed_in_pricing_modal", {
            old_selected_country: N,
            new_selected_country: Y
        }), pe.logEventWithStatsig("Selected country changed in pricing modal", "chatgpt_selected_country_changed_in_pricing_modal", {
            old_selected_country: N,
            new_selected_country: Y
        }), ge(Y)
    }, e[43] = N, e[44] = ge, e[45] = me) : me = e[45];
    const J = me;
    let fe;
    e[46] === Symbol.for("react.memo_cache_sentinel") ? (fe = Y => {
        var we;
        E(Y);
        const Me = (we = new URLSearchParams(window.location.search).get("referrer")) != null ? we : document.referrer;
        pe.logEventWithStatsig("Account Pay: Account Payment Modal Toggle Clicked", "chatgpt_account_payment_modal_toggle_clicked", {
            selectedTab: Y,
            referrer: Me
        })
    }, e[46] = fe) : fe = e[46];
    const z = fe,
        [le, je] = V.useState(),
        xe = V.useRef(null);
    let Ce;
    e[47] === Symbol.for("react.memo_cache_sentinel") ? (Ce = () => {
        const Y = () => {
            if (xe.current) {
                const Fe = document.documentElement.clientHeight,
                    Me = xe.current.getBoundingClientRect().height,
                    we = Fe - Me;
                je(Math.max(we, 136))
            }
        };
        return Y(), window.addEventListener("resize", Y), () => window.removeEventListener("resize", Y)
    }, e[47] = Ce) : Ce = e[47];
    let ke;
    e[48] !== T ? (ke = [T], e[48] = T, e[49] = ke) : ke = e[49], V.useEffect(Ce, ke);
    let De, Ue;
    e[50] !== A || e[51] !== T ? (De = () => {
        if (k.current || T !== "business") return;
        const Y = window.setTimeout(() => {
            k.current = !0, pe.logEventWithStatsig("Account Pay: Business Tab Viewed 5 Seconds", "chatgpt_account_payment_modal_business_tab_viewed_5_seconds", {
                dwell_threshold_ms: 5e3,
                default_tab: A
            })
        }, 5e3);
        return () => {
            window.clearTimeout(Y)
        }
    }, Ue = [A, T], e[50] = A, e[51] = T, e[52] = De, e[53] = Ue) : (De = e[52], Ue = e[53]), V.useEffect(De, Ue);
    const Ge = Wo(),
        ze = Ho(),
        Be = Rs(),
        We = Se(y, "1671916711"),
        be = h.get(Yo);
    let _e;
    e: {
        const Y = be == null ? void 0 : be.toLowerCase(),
            Fe = Y === "plus" && T === "personal",
            Me = Y === "business" && T === "business";
        if (!be || !Fe && !Me) {
            _e = void 0;
            break e
        }
        const we = We.get("enabled_see_if_you_qualify_variant", !1);
        if (Fe && we) {
            _e = Te.giftPlusHeading;
            break e
        }
        if (Me && we) {
            _e = Te.giftBusinessHeading;
            break e
        }
        _e = void 0
    }
    const Ee = _e,
        He = s.isPro();
    let Oe;
    e[54] === Symbol.for("react.memo_cache_sentinel") ? (Oe = sessionStorage.getItem(Ds), e[54] = Oe) : Oe = e[54];
    const Je = Xa({
            defaultTitle: Ee != null ? Ee : c,
            showGoFreeTrialTitle: Ge && T === "personal",
            showPlusFreeTrialTitle: ze && T === "personal",
            showBusinessFreeTrialTitle: Be && T === "business",
            shouldUseBusinessFreeWorkspaceExperience: x,
            hasProSubscription: He,
            hasStoredPromoMetadata: !!Oe
        }),
        ve = x ? Te.businessFreeWorkspaceModalSubtitle : u;
    if (!F) return null;
    const ft = ka({
        analyticsParams: G,
        currentAccount: s,
        planLoading: g,
        selectedTab: T,
        setPlanLoading: _,
        setShouldShowCheckoutLoadingOverlay: m,
        billingDetails: F,
        onClose: i,
        ctx: y,
        businessComparisonEnabled: Pe,
        eligibleComparisonPlans: ne,
        autoUpgradePlanType: v,
        fromiOSWebview: M,
        hideProPlan: U
    });
    let Ye;
    e[55] !== j || e[56] !== M || e[57] !== ve || e[58] !== Je ? (Ye = a.jsx(Ba, {
        modalTitle: Je,
        subtitle: ve,
        isFromIosWebview: M,
        handleClose: j
    }), e[55] = j, e[56] = M, e[57] = ve, e[58] = Je, e[59] = Ye) : Ye = e[59];
    let $e;
    e[60] !== s || e[61] !== M || e[62] !== z || e[63] !== T || e[64] !== x ? ($e = !M && s.isPersonalAccount() && !x ? a.jsx("div", {
        className: "mb-3 flex justify-center md:mb-6",
        children: a.jsx("div", {
            className: "w-[fit-content]",
            children: a.jsx(da, {
                value: T,
                onChange: z
            })
        })
    }) : null, e[60] = s, e[61] = M, e[62] = z, e[63] = T, e[64] = x, e[65] = $e) : $e = e[65];
    let Ie;
    e[66] !== ft ? (Ie = a.jsx("div", {
        className: "flex justify-center gap-6 flex-col md:flex-row px-4",
        children: ft
    }), e[66] = ft, e[67] = Ie) : Ie = e[67];
    let Qe;
    e[68] !== Ye || e[69] !== $e || e[70] !== Ie ? (Qe = a.jsxs("div", {
        ref: xe,
        className: "bg-token-bg-elevated-secondary",
        children: [Ye, $e, Ie]
    }), e[68] = Ye, e[69] = $e, e[70] = Ie, e[71] = Qe) : Qe = e[71];
    const ht = "".concat(le, "px");
    let Le;
    e[72] !== ht ? (Le = {
        height: ht
    }, e[72] = ht, e[73] = Le) : Le = e[73];
    let Ze;
    e[74] === Symbol.for("react.memo_cache_sentinel") ? (Ze = a.jsx("div", {}), e[74] = Ze) : Ze = e[74];
    let Xe;
    e[75] === Symbol.for("react.memo_cache_sentinel") ? (Xe = a.jsx(go, {}), e[75] = Xe) : Xe = e[75];
    let et;
    e[76] === Symbol.for("react.memo_cache_sentinel") ? (et = a.jsx(X, O({}, Te.needMoreCapabilities)), e[76] = et) : et = e[76];
    let bt;
    e[77] === Symbol.for("react.memo_cache_sentinel") ? (bt = a.jsxs("div", {
        className: "text-token-text-secondary mt-8 mb-12 flex flex-col items-center justify-start gap-2 text-sm md:mt-8 md:mt-10 md:mb-8",
        children: [Xe, a.jsxs("div", {
            className: "flex flex-col items-center justify-center",
            children: [et, a.jsx("div", {
                children: a.jsx(X, $(O({}, Te.seeChatGptEnterprise), {
                    values: {
                        link: qa
                    }
                }))
            })]
        }), a.jsx(Ya, {})]
    }), e[77] = bt) : bt = e[77];
    const Ot = !H;
    let tt;
    e[78] !== Ot ? (tt = Ft({
        hidden: Ot
    }, "text-token-text-primary justify-self-end opacity-50 transition hover:opacity-75 md:absolute md:end-4 md:bottom-4"), e[78] = Ot, e[79] = tt) : tt = e[79];
    let st;
    e[80] !== J || e[81] !== N ? (st = a.jsx(za, {
        onChange: J,
        value: N
    }), e[80] = J, e[81] = N, e[82] = st) : st = e[82];
    let ot;
    e[83] !== tt || e[84] !== st ? (ot = a.jsx("span", {
        "data-testid": "country-selector-in-pricing-modal",
        className: tt,
        children: st
    }), e[83] = tt, e[84] = st, e[85] = ot) : ot = e[85];
    let at;
    e[86] !== Le || e[87] !== ot ? (at = a.jsxs("div", {
        className: "bg-token-bg-elevated-secondary relative grid grid-cols-[1fr_auto_1fr]",
        style: Le,
        children: [Ze, bt, ot]
    }), e[86] = Le, e[87] = ot, e[88] = at) : at = e[88];
    let nt;
    e[89] !== l ? (nt = l && a.jsx("div", {
        className: "bg-token-bg-primary absolute inset-0 z-[9999] grid place-items-center dark:bg-[#1B1B1D]",
        "data-testid": "account-payment-modal-loading",
        children: a.jsx(zt, {
            className: "icon-xl text-token-text-primary"
        })
    }), e[89] = l, e[90] = nt) : nt = e[90];
    let it;
    e[91] !== f ? (it = f && a.jsx("div", {
        className: "bg-token-bg-primary absolute inset-0 z-[10000] grid place-items-center dark:bg-[#1B1B1D]",
        "data-testid": "account-payment-modal-checkout-loading",
        children: a.jsx(po, {})
    }), e[91] = f, e[92] = it) : it = e[92];
    let vt;
    return e[93] !== j || e[94] !== Qe || e[95] !== at || e[96] !== nt || e[97] !== it ? (vt = a.jsxs($t, {
        testId: "modal-account-payment",
        size: "fullscreen",
        isOpen: !0,
        onClose: j,
        type: "success",
        className: "bg-token-bg-elevated-secondary! flex flex-col",
        removePopoverStyling: !0,
        children: [Qe, at, nt, it]
    }), e[93] = j, e[94] = Qe, e[95] = at, e[96] = nt, e[97] = it, e[98] = vt) : vt = e[98], vt
}

function qa(t) {
    return a.jsx(Ae, {
        target: "_blank",
        to: $o,
        onClick: Qa,
        className: "mx-1 font-medium underline",
        children: t
    })
}

function Qa() {
    pe.logEventWithStatsig("Account Pay: Click see enterprise link from Modal", "chatgpt_account_payment_modal_enterprise_link_clicked")
}

function Za() {
    const t = performance.now();
    return () => {
        if (t) {
            const e = performance.now() - t;
            pe.logValueEventWithStatsig({
                segmentEventName: "Account Pay: Account Payment Modal Time Spent",
                statsigEventName: "chatgpt_web_account_payment_modal_time_spent",
                value: Math.round(e)
            })
        }
    }
}

function Ja({
    currentAccount: t,
    selectedTab: e
}) {
    return !!(!t.hasPaidSubscription() || (t.isPlus() || t.isPro()) && e === "business" || t.isSelfServeBusiness())
}

function Xa({
    defaultTitle: t,
    hasProSubscription: e,
    showGoFreeTrialTitle: s,
    showPlusFreeTrialTitle: o,
    showBusinessFreeTrialTitle: i,
    shouldUseBusinessFreeWorkspaceExperience: u,
    hasStoredPromoMetadata: c
}) {
    return t || (u ? Te.businessFreeWorkspaceModalTitle : s && !c ? Te.goFreeTrialModalTitle : o && !c ? Te.plusFreeTrialModalTitle : i && !c ? Te.businessFreeTrialModalTitle : e ? Te.proModalTitle : Te.modalTitle)
}
const Te = qe({
    modalTitle: {
        id: "AccountPaymentModal.modalTitle",
        defaultMessage: "Upgrade your plan"
    },
    goFreeTrialModalTitle: {
        id: "AccountPaymentModal.goFreeTrialModalTitle",
        defaultMessage: "Try Go free for 12 months"
    },
    plusFreeTrialModalTitle: {
        id: "AccountPaymentModal.plusFreeTrialModalTitle",
        defaultMessage: "Try Plus free for 1 month"
    },
    businessFreeTrialModalTitle: {
        id: "AccountPaymentModal.businessFreeTrialModalTitle",
        defaultMessage: "Try Business free for 1 month"
    },
    giftPlusHeading: {
        id: "AccountPaymentModal.giftPlusHeading",
        defaultMessage: "You qualify for 1 free month of Plus"
    },
    giftBusinessHeading: {
        id: "AccountPaymentModal.giftBusinessHeading",
        defaultMessage: "You qualify for 1 free month of Business"
    },
    proModalTitle: {
        id: "AccountPaymentModal.proModalTitle",
        defaultMessage: "Choose your plan"
    },
    modalFooterCapabilities: {
        id: "AccountPaymentModal.modalFooterCapabilities",
        defaultMessage: "Need more capabilities? See <link> ChatGPT Enterprise </link>"
    },
    needMoreCapabilities: {
        id: "SdJWr7",
        defaultMessage: "Need more capabilities for your business?"
    },
    seeChatGptEnterprise: {
        id: "7C5fuF",
        defaultMessage: "See<link>ChatGPT Enterprise</link>"
    },
    promoNotEligibleMessage: {
        id: "AccountPaymentModal.promoNotEligibleMessage",
        defaultMessage: "Thanks for being a subscriber. Since you already use ChatGPT Plus, you're not eligible for this offer."
    },
    businessFreeWorkspaceModalTitle: {
        id: "AccountPaymentModal.businessFreeWorkspaceModalTitle",
        defaultMessage: "Choose the best plan to get more done"
    },
    businessFreeWorkspaceModalSubtitle: {
        id: "AccountPaymentModal.businessFreeWorkspaceModalSubtitle",
        defaultMessage: "Get more work done with AI for teams"
    }
});
export {
    Cn as A, ba as G, za as M, ya as P, Ca as T, ka as a, Ka as g
};
//# sourceMappingURL=hrv77bu834ppv90t.js.map