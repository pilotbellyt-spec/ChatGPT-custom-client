var U = Object.defineProperty,
    E = Object.defineProperties;
var L = Object.getOwnPropertyDescriptors;
var h = Object.getOwnPropertySymbols;
var w = Object.prototype.hasOwnProperty,
    R = Object.prototype.propertyIsEnumerable;
var T = (s, t, e) => t in s ? U(s, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : s[t] = e,
    o = (s, t) => {
        for (var e in t || (t = {})) w.call(t, e) && T(s, e, t[e]);
        if (h)
            for (var e of h(t)) R.call(t, e) && T(s, e, t[e]);
        return s
    },
    n = (s, t) => E(s, L(t));
var q = (s, t) => {
    var e = {};
    for (var i in s) w.call(s, i) && t.indexOf(i) < 0 && (e[i] = s[i]);
    if (s != null && h)
        for (var i of h(s)) t.indexOf(i) < 0 && R.call(s, i) && (e[i] = s[i]);
    return e
};
import {
    kb as F,
    g8 as H,
    ka as N
} from "./dykg4ktvbu3mhmdo.js";
import {
    h as j,
    m as z,
    a as Q
} from "./gjyisy9q1t8rz8p4.js";
const m = {
        cartId: "",
        cartMetadata: void 0,
        isCheckoutOpen: !1,
        items: [],
        shippingAddress: void 0,
        billingAddress: void 0,
        shippingMethodId: void 0,
        totals: void 0,
        merchant: void 0,
        paymentDetails: void 0,
        currencyCode: "USD",
        shippingOptions: [],
        grandTotal: {
            title: "",
            subtitle: "",
            value: "",
            value_minor: 0,
            formatted_value: ""
        },
        paymentTypes: {},
        cartStatus: "idle",
        isShippingAddressSameAsBilling: !1,
        paymentSheetButtonCta: "",
        headerMessage: void 0,
        errors: void 0,
        preloadCustomerSessionClientSecret: void 0,
        cachedPaymentDetailsResponse: void 0,
        agreements: void 0
    },
    x = H(() => N((s, t) => n(o({}, m), {
        openNewCheckout: d => {
            var l = d,
                {
                    metadata: e
                } = l,
                i = q(l, ["metadata"]);
            return s(r => {
                var p, c, a, g;
                return n(o(o({}, m), i), {
                    cartMetadata: e ? o({}, e) : void 0,
                    isCheckoutOpen: !0,
                    paymentDetails: (p = r.paymentDetails) != null && p.complete ? o({}, r.paymentDetails) : void 0,
                    shippingAddress: (c = r.shippingAddress) != null && c.complete ? o({}, r.shippingAddress) : void 0,
                    billingAddress: (a = r.billingAddress) != null && a.complete ? o({}, r.billingAddress) : void 0,
                    cachedPaymentDetailsResponse: r.cachedPaymentDetailsResponse ? o({}, r.cachedPaymentDetailsResponse) : void 0,
                    isShippingAddressSameAsBilling: ((g = r.billingAddress) == null ? void 0 : g.complete) && r.isShippingAddressSameAsBilling
                })
            })
        },
        closeCheckout: (e = !1) => s(i => o({}, e ? m : n(o({}, i), {
            isCheckoutOpen: !1
        }))),
        setInitialCart: e => {
            var a;
            const i = e.cart.line_items[0].item,
                d = i.item_metadata,
                l = e.cart.line_items[0].seller,
                r = (a = l == null ? void 0 : l.name) != null ? a : d == null ? void 0 : d.merchant_subtitle,
                p = d == null ? void 0 : d.merchant_title,
                c = (p == null ? void 0 : p.toLowerCase()) === "walmart" && !!(l != null && l.name);
            s(g => {
                var u, _, v, A, y, f, I, b, D, k, P, B;
                const S = ((u = e.cart.header_level_message) == null ? void 0 : u.trim()) || void 0;
                return n(o({}, g), {
                    cartId: e.id,
                    totals: e.cart.totals,
                    grandTotal: e.cart.grand_total,
                    shippingAddress: e.cart.shipping_address ? n(o({}, z(e.cart.shipping_address)), {
                        complete: !0
                    }) : (_ = g.shippingAddress) != null && _.complete ? o({}, g.shippingAddress) : void 0,
                    paymentSheetButtonCta: e.payment_sheet_button_cta.trim(),
                    shippingOptions: (v = e.cart.shipping_options) != null ? v : [],
                    shippingMethodId: (A = e.cart.shipping_option_id) != null ? A : void 0,
                    footerMessage: (y = e.cart.footer_level_message) != null ? y : void 0,
                    headerMessage: S,
                    agreements: (f = e.agreements) != null ? f : [],
                    paymentTypes: Object.fromEntries(((I = e.payment_surfaces_and_types) != null ? I : []).map(O => [O.surface, O.types])),
                    currencyCode: e.cart.currency,
                    errors: e.cart.errors,
                    merchant: {
                        title: p,
                        subtitle: c ? (b = l == null ? void 0 : l.name) != null ? b : "" : r,
                        subtitlePrefix: c ? "Sold by " : void 0,
                        subtitleUrl: (D = l == null ? void 0 : l.link) != null ? D : void 0,
                        url: d == null ? void 0 : d.product_url,
                        logoUrl: d == null ? void 0 : d.merchant_logo_url,
                        externalId: e.seller_details.external_id,
                        networkId: e.seller_details.network_id
                    },
                    items: [{
                        id: (k = i.id) != null ? k : "",
                        productId: d == null ? void 0 : d.product_id,
                        quantity: i.quantity,
                        value: i.value,
                        title: d == null ? void 0 : d.product_title,
                        variant: d == null ? void 0 : d.product_variant_info,
                        price: d == null ? void 0 : d.product_price,
                        imageUrl: d == null ? void 0 : d.product_image_url,
                        url: d == null ? void 0 : d.product_url,
                        metadata: {
                            isDigital: d == null ? void 0 : d.is_digital
                        }
                    }],
                    allowedCountries: (P = e.allowed_countries) != null ? P : [],
                    additionalFields: (B = e.additional_fields) != null ? B : []
                })
            })
        },
        updateCart: e => s(i => {
            var d, l, r, p, c, a;
            return n(o({}, i), {
                totals: e.cart.totals,
                grandTotal: e.cart.grand_total,
                shippingOptions: (d = e.cart.shipping_options) != null ? d : [],
                shippingMethodId: (l = e.cart.shipping_option_id) != null ? l : void 0,
                footerMessage: (r = e.cart.footer_level_message) != null ? r : void 0,
                headerMessage: e.cart.header_level_message !== void 0 ? (c = (p = e.cart.header_level_message) == null ? void 0 : p.trim()) != null ? c : void 0 : i.headerMessage,
                errors: e.cart.errors,
                cartStatus: i.cartStatus === "updating" ? "idle" : i.cartStatus,
                items: [n(o({}, i.items[0]), {
                    id: (a = e.cart.line_items[0].item.id) != null ? a : "",
                    quantity: e.cart.line_items[0].item.quantity,
                    value: e.cart.line_items[0].item.value
                })]
            })
        }),
        updateQuantity: (e, i) => {
            const l = t().items.map(r => r.id === e ? n(o({}, r), {
                quantity: i
            }) : r);
            return s({
                items: l
            }), l
        },
        setShippingAddress: e => s(i => n(o({}, i), {
            shippingAddress: e ? o({}, e) : void 0
        })),
        setHasAcceptedAgreement: (e, i) => {
            var l;
            const d = (l = t().agreements) == null ? void 0 : l.map(r => r.id === e ? n(o({}, r), {
                is_checked: i
            }) : r);
            s(o({
                agreements: d
            }, j(d) ? {
                errors: void 0
            } : {}))
        },
        setBillingAddress: e => s(i => n(o({}, i), {
            billingAddress: o({}, e)
        })),
        setShippingMethodId: e => s(i => n(o({}, i), {
            shippingMethodId: e
        })),
        setMerchant: e => s(i => n(o({}, i), {
            merchant: o({}, e)
        })),
        setCachedPaymentDetailsResponse: e => s(i => n(o({}, i), {
            cachedPaymentDetailsResponse: e
        })),
        setPaymentDetails: e => s(i => n(o({}, i), {
            paymentDetails: e ? o({}, e) : void 0
        })),
        setCartStatus: e => s(i => n(o({}, i), {
            cartStatus: e
        })),
        setIsShippingAddressSameAsBilling: e => s(i => n(o({}, i), {
            isShippingAddressSameAsBilling: e
        })),
        setErrors: e => s(i => n(o({}, i), {
            errors: e
        }))
    }))),
    K = s => x(s).getState(),
    W = s => F(x(s)),
    X = s => {
        var t, e;
        return !!((t = s.shippingAddress) != null && t.complete && ((e = s.paymentDetails) != null && e.complete) && (s.shippingMethodId || Q(s.items)))
    };
export {
    X as a, K as g, W as u
};
//# sourceMappingURL=zdzro29lk5w2w085.js.map