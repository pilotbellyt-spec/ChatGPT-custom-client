var H = Object.defineProperty,
    R = Object.defineProperties;
var F = Object.getOwnPropertyDescriptors;
var C = Object.getOwnPropertySymbols;
var G = Object.prototype.hasOwnProperty,
    U = Object.prototype.propertyIsEnumerable;
var T = (t, s, a) => s in t ? H(t, s, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: a
    }) : t[s] = a,
    c = (t, s) => {
        for (var a in s || (s = {})) G.call(s, a) && T(t, a, s[a]);
        if (C)
            for (var a of C(s)) U.call(s, a) && T(t, a, s[a]);
        return t
    },
    f = (t, s) => R(t, F(s));
import {
    e as z,
    E as I,
    j as e,
    M as l,
    f as V
} from "./fg33krlcm0qyi6yw.js";
import {
    b as O
} from "./k2oaaf8ac9lafsub.js";
import {
    v as Q,
    w as X,
    x as Y,
    y as J,
    z as K
} from "./k15yxxoybkkir2ou.js";
import {
    du as Z,
    ag as $,
    bO as L,
    iw as ee,
    l as ae
} from "./dykg4ktvbu3mhmdo.js";
const se = 128;

function re({
    workspaceId: t
}) {
    var D, M;
    const s = z(),
        {
            data: a,
            isPending: S
        } = Z(t),
        {
            mutateAsync: y,
            isPending: n
        } = Q(t),
        {
            mutateAsync: P,
            isPending: w
        } = X(t),
        b = $(),
        N = (D = b == null ? void 0 : b.email) == null ? void 0 : D.split("@")[1],
        p = !!(a != null && a.workspace_discoverable),
        q = (a == null ? void 0 : a.auto_accept_requests) === !0,
        d = (a == null ? void 0 : a.use_workspace_name_for_discovery) === !0,
        r = d ? "" : (M = a == null ? void 0 : a.public_display_name) != null ? M : "",
        j = O(),
        [x, _] = I.useState(""),
        [k, u] = I.useState(!1);
    if ((a == null ? void 0 : a.support_workspace_discovery) === !1) return null;
    const W = k ? x : r,
        v = x.trim(),
        g = !k || v === r.trim(),
        h = S,
        A = h || n || w,
        E = h || w,
        B = !n && !d && (k ? x.trim() !== "" : r.trim() !== "");
    return e.jsx(Y, {
        title: e.jsx(l, c({}, i.discoveryTitle)),
        body: N ? e.jsx(l, f(c({}, i.discoveryBodyWithDomain), {
            values: {
                domain: N
            }
        })) : e.jsx(l, c({}, i.discoveryBodyGeneric)),
        toggle: e.jsx(L, {
            disabled: A,
            checked: p,
            onCheckedChange: async o => {
                await y({
                    value: o,
                    public_display_name: r === "" ? null : r,
                    use_workspace_name_for_discovery: d,
                    action: "toggle"
                }), o || u(!1)
            },
            "aria-label": s.formatMessage(i.discoveryToggleLabel)
        }),
        disabled: h,
        children: p && e.jsxs(e.Fragment, {
            children: [e.jsxs("div", {
                className: "flex items-center justify-between",
                children: [e.jsx("div", {
                    className: "text-token-text-primary text-base font-semibold",
                    children: e.jsx(l, c({}, i.autoAcceptLabel))
                }), e.jsx(L, {
                    disabled: E,
                    checked: q,
                    onCheckedChange: async o => {
                        await P({
                            autoAcceptRequests: o
                        })
                    },
                    "aria-label": s.formatMessage(i.autoAcceptToggleLabel)
                })]
            }), e.jsx("div", {
                className: "text-token-text-secondary mb-4 text-xs",
                children: e.jsx(l, c({}, i.autoAcceptHelp))
            }), e.jsxs("div", {
                className: "w-full",
                children: [e.jsx("label", {
                    htmlFor: "public_display_name",
                    className: "text-token-text-primary mb-1 block text-base font-semibold",
                    children: e.jsx(l, c({}, i.publicDisplayNameLabel))
                }), e.jsx("div", {
                    className: "text-token-text-secondary mb-2 text-xs",
                    children: e.jsx(l, f(c({}, i.publicDisplayNameHelp), {
                        values: {
                            workspaceName: j
                        }
                    }))
                }), e.jsx("div", {
                    className: "mb-2",
                    children: e.jsx(J, {
                        id: "use-workspace-name-for-discovery",
                        checked: d,
                        disabled: A,
                        onChange: async o => {
                            const m = o.currentTarget.checked;
                            await y({
                                value: p,
                                public_display_name: m ? null : r || null,
                                use_workspace_name_for_discovery: m,
                                action: "name"
                            }), m && u(!1)
                        },
                        label: e.jsx("span", {
                            className: "text-sm",
                            children: e.jsx(l, c({}, i.workspaceNameSameAsCheckbox))
                        })
                    })
                }), !d && e.jsxs(e.Fragment, {
                    children: [e.jsx(K, {
                        name: "public_display_name",
                        ariaLabel: !1,
                        placeholder: j,
                        maxLength: se,
                        value: W,
                        onChange: o => {
                            _(o.target.value), u(!0)
                        },
                        insideContainerChildren: B ? e.jsx("button", {
                            type: "button",
                            className: "text-token-text-tertiary hover:text-token-text-secondary absolute end-0 top-1/2 -translate-y-1/2 pe-1",
                            "aria-label": s.formatMessage(i.clearToWorkspaceNameAria),
                            onClick: () => {
                                _(""), u(!0)
                            },
                            children: e.jsx(ee, {
                                className: "icon-sm"
                            })
                        }) : null
                    }), e.jsx("div", {
                        className: "mt-2 flex justify-end",
                        children: e.jsx("div", {
                            className: "flex items-center gap-2",
                            children: e.jsx("button", {
                                className: ae("disabled:pointer-events-none disabled:cursor-auto disabled:hover:bg-transparent", n || g ? "btn btn-secondary" : "btn btn-primary"),
                                disabled: n || g,
                                "aria-busy": n || void 0,
                                onClick: async () => {
                                    if (n || g) return;
                                    const o = v === "" ? null : v;
                                    await y({
                                        value: p,
                                        public_display_name: o,
                                        use_workspace_name_for_discovery: o == null,
                                        action: "name"
                                    }), u(!1)
                                },
                                children: e.jsx(l, c({}, i.saveDisplayNameCta))
                            })
                        })
                    })]
                })]
            })]
        })
    })
}
const i = V({
    discoveryTitle: {
        id: "workspaceIdentity.discoveryTitle",
        defaultMessage: "Enable workspace discovery"
    },
    discoveryBodyGeneric: {
        id: "workspaceIdentity.discoveryBodyGeneric",
        defaultMessage: "Allow users with your email domain and your workspace verified domains to find and request to join this workspace."
    },
    discoveryBodyWithDomain: {
        id: "workspaceIdentity.discoveryBodyWithDomain",
        defaultMessage: "Allow users with the email domain {domain} and your workspace verified domains to find and request to join this workspace."
    },
    discoveryToggleLabel: {
        id: "workspaceIdentity.discoveryToggleLabel",
        defaultMessage: "Enable workspace discovery"
    },
    publicDisplayNameLabel: {
        id: "workspaceIdentity.publicDisplayNameLabel",
        defaultMessage: "Discoverable name"
    },
    autoAcceptLabel: {
        id: "workspaceIdentity.autoAcceptLabel",
        defaultMessage: "Automatically accept join requests"
    },
    autoAcceptToggleLabel: {
        id: "workspaceIdentity.autoAcceptToggleLabel",
        defaultMessage: "Toggle automatic acceptance of join requests"
    },
    autoAcceptHelp: {
        id: "workspaceIdentity.autoAcceptHelp",
        defaultMessage: "When on, users who request to join your workspace are added automatically. Each new member is billed as a seat."
    },
    saveDisplayNameCta: {
        id: "workspaceIdentity.saveDisplayNameCta",
        defaultMessage: "Save"
    },
    publicDisplayNameHelp: {
        id: "workspaceIdentity.publicDisplayNameHelp",
        defaultMessage: "This is what users will see when they request access to this workspace."
    },
    clearToWorkspaceNameAria: {
        id: "workspaceIdentity.clearToWorkspaceNameAria",
        defaultMessage: "Clear and use workspace name"
    },
    workspaceNameSameAsCheckbox: {
        id: "workspaceIdentity.workspaceNameSameAsCheckbox",
        defaultMessage: "Same as workspace name"
    }
});
export {
    re as D, se as P
};
//# sourceMappingURL=hpmzcrnchtp2pgs4.js.map