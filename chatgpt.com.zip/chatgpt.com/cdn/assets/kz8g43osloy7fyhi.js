var Ks = Object.defineProperty,
    zs = Object.defineProperties;
var Gs = Object.getOwnPropertyDescriptors;
var Ut = Object.getOwnPropertySymbols;
var Ws = Object.prototype.hasOwnProperty,
    Qs = Object.prototype.propertyIsEnumerable;
var qt = (e, n, s) => n in e ? Ks(e, n, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : e[n] = s,
    J = (e, n) => {
        for (var s in n || (n = {})) Ws.call(n, s) && qt(e, s, n[s]);
        if (Ut)
            for (var s of Ut(n)) Qs.call(n, s) && qt(e, s, n[s]);
        return e
    },
    $ = (e, n) => zs(e, Gs(n));
import {
    e as V,
    j as t,
    M as ut,
    r as m,
    a as ze,
    u as de,
    b as ds,
    f as Zs,
    w as Ys
} from "./fg33krlcm0qyi6yw.js";
import {
    hO as Xs,
    hR as Js,
    AR as Ge,
    qC as N,
    qD as q,
    qF as Ue,
    AS as ms,
    AT as $s,
    AU as Vs,
    nN as en,
    rE as tn,
    rW as Kt,
    vf as sn,
    rj as nn,
    rk as an,
    rm as on,
    AV as rn,
    AW as cn,
    cx as ln,
    a5 as zt,
    cw as un,
    Z as Se,
    fu as Gt,
    Y as Wt,
    ib as dn,
    kS as mn,
    ab as fn,
    ac as gn,
    AX as Fe,
    ax as hn,
    b0 as pn,
    qH as Cn,
    e4 as xn,
    AY as vn,
    gX as yn,
    hk as xe,
    AZ as bn,
    A_ as fs,
    A$ as Sn,
    B0 as Tn,
    B1 as dt,
    B2 as An,
    tC as En,
    B3 as wn,
    qW as ve,
    B4 as _n,
    B5 as In,
    l5 as kn,
    B6 as jn,
    c as Pn,
    B7 as Rn,
    B8 as Dn,
    B9 as Mn,
    Ba as Nn,
    hg as Bn,
    hh as On,
    hi as Ln,
    rU as Qt,
    jZ as Zt,
    hj as Yt,
    Bb as Hn,
    Bc as Fn,
    b as Un,
    Bd as qn,
    j0 as Kn,
    pq as zn,
    aB as Gn,
    Be as Xt,
    hm as Jt,
    Bf as it,
    Bg as $t,
    Bh as Le,
    Bi as He,
    Bj as Vt
} from "./k15yxxoybkkir2ou.js";
import {
    oH as gs,
    C as Wn,
    aY as Qn,
    M as es,
    fD as Zn,
    bg as oe,
    a9 as ts,
    v9 as Yn,
    x as Xn,
    fN as mt,
    bv as We,
    dF as hs,
    e2 as ss,
    dB as Jn,
    b as Qe,
    d as $n,
    k5 as Vn,
    l as be,
    _ as ps,
    R as G,
    hh as Cs,
    Ab as xs,
    g2 as k,
    se as ea,
    dv as ns,
    T as qe,
    H as ta,
    b9 as sa,
    hv as na,
    aW as aa,
    o as vs,
    gJ as oa,
    jQ as ra,
    fe as ia,
    fZ as as,
    gd as ca,
    kq as la,
    kh as ua,
    mI as da,
    fX as ma,
    j0 as fa,
    P as ga
} from "./dykg4ktvbu3mhmdo.js";
import {
    C as re,
    u as ha,
    a as pa,
    h as Ca,
    g as xa,
    A as va,
    f as os,
    D as ya
} from "./bxjmpsz2dryfouus.js";
import {
    e as ba
} from "./jjqluv6nhf16nnr9.js";
import {
    C as Sa
} from "./nh559o9htk2jfyt0.js";
import {
    A as Ta
} from "./iv26jzbt1vvl49kt.js";
import {
    i as Aa,
    b as Ea,
    T as wa,
    a as _a,
    g as Ia
} from "./eo73z75xc7fd61fn.js";
import {
    g as ka
} from "./coi95al0vrqe13ds.js";
import {
    C as le
} from "./b2l059fz4znz94nm.js";
import {
    C as Ke,
    k as rs,
    S as is
} from "./iwhq2rihp0137gzf.js";
import {
    u as ja,
    C as Pa,
    a as Ra,
    H as Da,
    T as Ma
} from "./hzx735z33xljaym3.js";
import {
    a as Na
} from "./m77bejnre58pj934.js";
import {
    O as Ba
} from "./o589vqy9dgmjuag5.js";
import {
    D as Oa
} from "./eaak105t3h6pgvs1.js";
import {
    C as La
} from "./i5kvudettvxsr7pw.js";
import {
    g as ct,
    S as Ha
} from "./irqko7c1s7qpl41n.js";
import {
    s as lt,
    B as Fa
} from "./e1qtg70ehhxpvvw9.js";
import {
    N as Ua
} from "./ce3hgmw4iyyhicud.js";
import {
    L as qa
} from "./l13qvsuc1mktoblg.js";
import {
    i as cs
} from "./njpaiih217owxm7n.js";
import {
    g as Ka
} from "./loeoawlgsw5vcwar.js";
var ys = (e => (e.Close = "close", e.Loaded = "loaded", e.Streaming = "streaming", e.Download = "download", e))(ys || {});
const za = ({
    isOpen: e,
    dismissModal: n,
    closeTextdocEditor: s,
    textdocVersion: a,
    clientThreadId: i
}) => {
    const r = V(),
        o = Xs(i),
        l = Js(i),
        h = gs(),
        c = Ge(a == null ? void 0 : a.textdocId),
        u = async v => {
            N.logButtonClick(q.SAVE_TO_CHAT_ON_EDITOR_CLOSE), !((a == null ? void 0 : a.versionInt) == null || h) && (l({
                sourceEvent: v,
                promptMessage: Zn("", {
                    canvas: {
                        user_created_textdocs: a != null && a.status === ms.ATTACHED_PENDING && c != null ? [{
                            user_created_temp_textdoc_id: a.textdocId,
                            type: a.type,
                            title: a.title,
                            content: a.content,
                            create_source: c.create_source
                        }] : void 0
                    },
                    open_in_canvas_view: {
                        type: "canvas_textdoc",
                        id: a.textdocId
                    }
                }),
                completionMetadata: o ? {
                    conversationMode: o
                } : void 0
            }), c && Ue.markAsSent(c.tempTextdocId), n(), s())
        };
    return t.jsx(Wn, {
        testId: "modal-confirm-close-editor",
        isOpen: e,
        size: "custom",
        className: "max-w-xl",
        onClose: n,
        type: "warning",
        hideSeparator: !0,
        title: t.jsx("span", {
            className: "text-xl",
            children: t.jsx(ut, {
                id: "jgd5rD",
                defaultMessage: "Are you sure you want to close?"
            })
        }),
        primaryButton: t.jsx(es.Button, {
            title: r.formatMessage({
                id: "XE+GiU",
                defaultMessage: "Save to chat"
            }),
            color: "primary",
            onClick: u
        }),
        secondaryButton: t.jsx(es.Button, {
            title: r.formatMessage({
                id: "MbWco5",
                defaultMessage: "Don’t save and close"
            }),
            color: "secondary",
            onClick: () => {
                N.logButtonClick(q.CLOSE_WITHOUT_SAVING), c && Ue.removeTempTextdoc(c.tempTextdocId), n(), s()
            }
        }),
        showCloseButton: !0,
        closeButton: t.jsx(Qn, {
            onClick: n
        }),
        children: t.jsx("div", {
            className: "text-md text-token-text-secondary -mt-6 pb-2",
            children: t.jsx(ut, {
                id: "q9rJ+Y",
                defaultMessage: "Changes will not be saved unless you save this canvas to your chat."
            })
        })
    })
};

function bs(e) {
    const n = $s();
    if (!e) return {
        isCodePreviewable: !1,
        isCodeExecutable: !1,
        hasCanvasCodeExecution: n
    };
    const s = Aa(e == null ? void 0 : e.type, e == null ? void 0 : e.content),
        a = Ea(e.type);
    return {
        isCodePreviewable: s,
        isCodeExecutable: a,
        hasCanvasCodeExecution: n
    }
}
const Ga = ({
    isTextdocStreaming: e,
    isRequestActive: n,
    value: s,
    comments: a
}) => {
    const [i, r] = m.useState(!1);
    return m.useEffect(() => {
        e && i && (r(!1), Ke.reset())
    }, [s, a]), m.useEffect(() => {
        n || (r(!1), Ke.reset())
    }, [n]), [i, r]
};

function Wa({
    onClickRestore: e,
    onClickResetLatest: n
}) {
    const s = V();
    return t.jsx(oe.div, {
        initial: {
            height: 0
        },
        animate: {
            height: "auto"
        },
        exit: {
            height: 0
        },
        transition: {
            type: "spring",
            bounce: 0
        },
        className: "bg-token-main-surface-primary z-30",
        children: t.jsx(oe.div, {
            className: "bg-token-main-surface-primary dark:border-token-border-xlight @container w-full items-center border-t border-gray-100 p-6 shadow-[0_-4px_32px_rgba(0,0,0,0.08)] lg:border-s dark:shadow-[0_-4px_32px_rgba(0,0,0,0.12)]",
            children: t.jsxs("div", {
                className: "mx-auto flex max-w-[48rem] flex-col flex-wrap justify-center gap-5 @2xl:flex-row @2xl:justify-between",
                children: [t.jsxs("div", {
                    className: "flex flex-col px-2 text-center @2xl:text-start",
                    children: [t.jsx("span", {
                        className: "text-md text-token-text-primary font-semibold text-wrap",
                        children: s.formatMessage({
                            id: "gt23pb",
                            defaultMessage: "You are viewing a previous version"
                        })
                    }), t.jsx("span", {
                        className: "text-token-text-secondary text-sm text-wrap",
                        children: s.formatMessage({
                            id: "sAlUJn",
                            defaultMessage: "Restore this version to make edits"
                        })
                    })]
                }), t.jsxs("div", {
                    className: "flex flex-wrap items-center justify-center gap-4",
                    children: [t.jsx(ts, {
                        as: "button",
                        color: "primary",
                        onClick: e,
                        children: s.formatMessage({
                            id: "+cddAb",
                            defaultMessage: "Restore this version"
                        })
                    }), t.jsx(ts, {
                        as: "button",
                        color: "secondary",
                        onClick: n,
                        children: s.formatMessage({
                            id: "qCD3eu",
                            defaultMessage: "Back to latest version"
                        })
                    })]
                })]
            })
        })
    })
}
const Qa = {
        type: "spring",
        bounce: .2,
        duration: .56
    },
    Za = ({
        conversation: e,
        turn: n
    }) => {
        const s = Yn();
        return t.jsxs(oe.div, {
            className: "absolute start-0 end-0 top-0 z-10 -translate-y-full",
            children: [t.jsx(oe.div, {
                initial: {
                    opacity: 0
                },
                animate: {
                    opacity: 1
                },
                exit: {
                    opacity: 0
                },
                className: "bg-vert-light-gradient dark:from-token-main-surface-primary absolute inset-0 -top-5 dark:bg-linear-to-t dark:to-transparent"
            }), t.jsx(oe.div, {
                className: "flex items-center py-2",
                initial: {
                    opacity: .75,
                    translateX: -50,
                    translateY: "100%"
                },
                animate: {
                    opacity: 1,
                    translateX: 0,
                    translateY: "0"
                },
                exit: {
                    opacity: 0,
                    filter: "blur(8px)",
                    transition: {
                        delay: .4,
                        duration: .72
                    }
                },
                transition: Qa,
                children: t.jsx(La, {
                    conversation: e,
                    onRequestCompletion: Xn,
                    groupedMessagesToRender: n.messageGroups,
                    allGroupedMessages: n.messageGroups,
                    allMessages: n.messages,
                    isUserTurn: !0,
                    isFinalUserTurn: !1,
                    isFinalAssistantTurn: !1,
                    turnIndex: 0,
                    isCompletionRequestInProgress: !1,
                    isFeedbackEnabled: !1,
                    isFinalTurn: !1,
                    hasActiveRequest: s
                })
            })]
        }, "user-message")
    },
    Ya = ({
        conversation: e
    }) => {
        const n = e.id,
            {
                lastUserTurn: s,
                lastAssistantTurn: a
            } = mt(n, r => {
                const o = hs.getConversationTurns(r);
                let l = null,
                    h = null;
                for (let c = o.length - 1; c > 0; c--) {
                    const u = o[c];
                    if (!l && u.role === ss.User ? l = u : !h && u.role === ss.Assistant && (h = u), l && h) break
                }
                return {
                    lastUserTurn: l,
                    lastAssistantTurn: h
                }
            }),
            i = s && !(a != null && a.messages.some(r => {
                var o;
                return (o = r.recipient) == null ? void 0 : o.startsWith(Vs)
            }));
        return t.jsx(We, {
            initial: !1,
            children: i && t.jsx(Za, {
                turn: s,
                conversation: e
            })
        })
    },
    Xa = ({
        isRequestActive: e = !1,
        clientThreadId: n,
        readonlyReason: s,
        onCancel: a,
        onSubmit: i,
        onSubmitAccelerator: r,
        acceleratorActions: o = []
    }) => {
        var P;
        const l = Qe(),
            h = Jn(l, n),
            [c, u] = m.useState(!1),
            [v, S] = m.useState(""),
            [f, A] = m.useState(!0),
            _ = V(),
            [T, g] = m.useState(!1),
            x = $n(Vn),
            b = d => {
                i == null || i(d, v), S("")
            },
            E = d => {
                if (d.nativeEvent.isComposing) return;
                const {
                    metaKey: w,
                    shiftKey: I,
                    key: j
                } = d;
                j === "Enter" && v.trim() && !(I || w) && (b(d), d.preventDefault())
            };
        return t.jsxs(t.Fragment, {
            children: [c && !x && t.jsx(Ba, {
                zIndexKey: "acceleratorsOverlay",
                className: "bg-white/95 dark:bg-black/85"
            }), t.jsx("div", {
                className: "relative mb-3 flex items-end justify-center",
                children: t.jsxs("div", {
                    className: "relative mx-6 max-w-2xl flex-1",
                    children: [t.jsx(Ya, {
                        conversation: h
                    }), t.jsx("div", {
                        className: "flex flex-auto items-start",
                        children: t.jsx("div", {
                            className: be("dark:bg-token-main-surface-secondary flex min-h-12 flex-auto items-center bg-[#f4f4f4] py-1 ps-6 pe-2", {
                                "rounded-full": f,
                                "rounded-2xl": !f,
                                "bg-transparent": T
                            }),
                            children: t.jsxs("div", {
                                className: "relative flex flex-auto items-center self-stretch",
                                children: [t.jsx(en, {
                                    placeholder: _.formatMessage({
                                        id: "zrUbTJ",
                                        defaultMessage: "Ask ChatGPT to edit"
                                    }),
                                    disabled: e,
                                    value: v,
                                    className: be("text-token-text-primary placeholder:text-token-text-secondary w-full resize-none border-0 bg-transparent p-0 outline-0 focus:ring-0 focus-visible:ring-0", {
                                        "opacity-0": T
                                    }),
                                    maxRows: 4,
                                    onChange: ({
                                        target: {
                                            value: d
                                        }
                                    }) => S(d),
                                    onKeyDown: E,
                                    onHeightChange: (d, {
                                        rowHeight: w
                                    }) => A(Math.floor(d / w) <= 1)
                                }), v ? t.jsx(oe.button, {
                                    className: be("dark bg-token-main-surface-primary h-8 w-8 rounded-full text-center disabled:bg-[#D7D7D7]", {
                                        "self-end": !f
                                    }),
                                    initial: {
                                        opacity: 0
                                    },
                                    animate: {
                                        opacity: 1
                                    },
                                    exit: {
                                        opacity: 0
                                    },
                                    transition: {
                                        type: "tween",
                                        duration: .1
                                    },
                                    onMouseDown: b,
                                    children: t.jsx(tn, {
                                        className: "text-token-text-primary h-8 w-8"
                                    })
                                }) : ((P = o == null ? void 0 : o.length) != null ? P : 0) > 0 && t.jsx(Oa, {
                                    disableHint: !0,
                                    isVisuallyHidden: (s == null ? void 0 : s.isReadonly) && !s.isStreaming,
                                    disableOverlay: !0,
                                    isEmbeddedInPromptArea: !0,
                                    isRequestActive: e,
                                    actions: o,
                                    onCancel: a,
                                    onExpandedChange: d => {
                                        x || g(d), u(d)
                                    },
                                    onSubmit: r,
                                    right: 0,
                                    bottom: 4
                                })]
                            })
                        })
                    })]
                })
            })]
        })
    };

function Ja(e, n) {
    const s = new Set(e.map(l => l.id)),
        a = new Set(n.map(l => l.id)),
        i = e.filter(l => !a.has(l.id)).map(l => $(J({}, l), {
            diffStatus: Kt.REMOVED
        })),
        r = n.filter(l => !s.has(l.id)).map(l => $(J({}, l), {
            diffStatus: Kt.ADDED
        })),
        o = e.filter(l => a.has(l.id));
    return i.concat(r, o)
}
const $a = e => {
    const {
        textdocId: n
    } = e, s = sn(a => {
        var i;
        return (i = a == null ? void 0 : a.resolveTempTextdocId[n]) != null ? i : n
    });
    return m.useMemo(() => $(J({}, e), {
        textdocId: s
    }), [s, e])
};
async function Va({
    textdocId: e,
    newTitle: n
}) {
    n != null && await G.safePost("/textdoc/{textdoc_id}/rename", {
        parameters: {
            path: {
                textdoc_id: e
            }
        },
        requestBody: {
            title: n
        }
    }).catch(s => {
        ps.addError("renameCanvasTitle Error:", s)
    })
}
const eo = ({
    serverThreadId: e,
    textdocVersion: n,
    initialTitle: s = "Untitled Document",
    isEditingTitle: a,
    setIsEditingTitle: i
}) => {
    const r = ze(),
        {
            mutateAsync: o
        } = de({
            mutationKey: [e, "textdocs"],
            mutationFn: Va,
            onMutate: async ({
                textdocId: g,
                newTitle: x
            }) => {
                await r.cancelQueries({
                    queryKey: [e, "textdocs"]
                });
                const b = r.getQueryData([e, "textdocs"]);
                return r.setQueryData([e, "textdocs"], E => {
                    if (!E) return E;
                    const P = new Map(E.persistedTextdocVersionById),
                        d = P.get(g);
                    if (d) {
                        const R = $(J({}, d), {
                            title: x != null ? x : ""
                        });
                        P.set(g, R)
                    }
                    const w = E.persistedTextdocVersions.map(R => R.textdocId === g ? $(J({}, R), {
                            title: x != null ? x : ""
                        }) : R),
                        I = new Map(E.persistedTextdocById),
                        j = I.get(g);
                    if (j) {
                        const R = $(J({}, j), {
                            title: x != null ? x : ""
                        });
                        I.set(g, R)
                    }
                    return $(J({}, E), {
                        persistedTextdocVersionById: P,
                        persistedTextdocVersions: w,
                        persistedTextdocById: I
                    })
                }), {
                    previousTextDocData: b
                }
            },
            retry: 2,
            onError: (g, x, b) => {
                b != null && b.previousTextDocData && r.setQueryData([e, "textdocs"], b.previousTextDocData), ps.addError("Error updating title:", g)
            },
            onSettled: () => {
                r.invalidateQueries({
                    queryKey: [e, "textdocs"]
                })
            }
        }),
        l = async g => {
            var x;
            n && await o({
                textdocId: (x = n.textdocId) != null ? x : "",
                newTitle: g
            })
        },
        [h, c] = m.useState(s),
        u = m.useRef(null),
        v = m.useRef(h),
        S = m.useRef(!1);
    m.useEffect(() => {
        a && u.current && (u.current.focus(), u.current.select())
    }, [a]);
    const f = g => {
            c(g.target.value)
        },
        A = () => {
            v.current = h
        },
        _ = async () => {
            S.current || await l(h), S.current = !1, i(!1)
        },
        T = g => {
            (g.key === "Enter" || g.key === "Escape") && g.preventDefault(), g.key === "Enter" ? g.currentTarget.blur() : g.key === "Escape" && (c(v.current), S.current = !0, g.currentTarget.blur())
        };
    return t.jsx("input", {
        className: "w-[300px] rounded-lg border-none px-3 py-2 outline-hidden focus:ring-0",
        ref: u,
        value: h,
        onChange: f,
        onFocus: A,
        onBlur: _,
        onKeyDown: T,
        style: {
            fontSize: "1.125rem",
            boxSizing: "border-box",
            backgroundColor: "var(--global-states-light-element-hover, rgba(0, 0, 0, 0.05))"
        }
    })
};

function to(e) {
    const {
        voiceName: n
    } = nn(), s = e ? () => so(e.textdocId, n, on()) : null, a = "".concat(e == null ? void 0 : e.textdocId, ".").concat(e == null ? void 0 : e.versionInt, ".").concat(n);
    return an(s, a)
}

function so(e, n, s) {
    return G.safeGet("/textdoc/{textdoc_id}/synthesize", {
        parameters: {
            path: {
                textdoc_id: e
            },
            query: {
                voice: n,
                format: s
            }
        },
        skipJsonTransform: !0
    })
}
const no = ({
    textdocVersion: e,
    isPersisting: n = !1,
    isTextdocAttachedPending: s,
    isTextdocStreaming: a,
    hasDebug: i,
    shouldShowPlayButton: r = !1,
    hideRenameButton: o = !1,
    toggleDebugView: l,
    isDebugVisible: h,
    toggleConsoleVisibility: c,
    isConsoleOpen: u,
    clientThreadId: v
}) => {
    var H, W;
    const S = Qe(),
        f = V();
    rn(S), to(e);
    const [A, _] = m.useState(!1), T = (H = e == null ? void 0 : e.title) != null ? H : "", g = (W = Cs(v)) != null ? W : "", x = Ge(e == null ? void 0 : e.textdocId), b = !T || (x == null ? void 0 : x.status) === cn.INFERRING, E = () => {
        _(!0)
    }, [P, d] = m.useState(!1), {
        container: w,
        triggerRef: I
    } = xs({
        isOpen: P,
        onClose: () => d(!1)
    }), j = [!x && !o && !a ? t.jsx(k.Item, {
        icon: ln,
        onClick: E,
        children: f.formatMessage({
            id: "z/PT9T",
            defaultMessage: "Rename"
        })
    }, "rename") : null, null, r ? t.jsx(k.Item, {
        icon: ea,
        onClick: c,
        children: u ? f.formatMessage({
            id: "owGHqE",
            defaultMessage: "Close console"
        }) : f.formatMessage({
            id: "GPb4WX",
            defaultMessage: "Open console"
        })
    }, "console") : null, null].filter(Boolean);
    if (j.length === 0) return t.jsxs(t.Fragment, {
        children: [t.jsx("div", {
            className: "flex h-6 grow items-center overflow-hidden",
            children: t.jsx(re.Title, {
                className: "@[0px]:hidden @[150px]:block",
                children: b ? t.jsx("div", {
                    className: "w-52",
                    children: t.jsx(ns, {
                        lines: 1,
                        size: "base",
                        width: 100,
                        widthVariance: 0
                    })
                }) : T
            })
        }), n && t.jsx(zt, {
            size: 12,
            className: "text-token-text-tertiary ps-1"
        })]
    });
    const R = e && t.jsx(k.Portal, {
        container: w,
        children: t.jsx(k.Content, {
            onCloseAutoFocus: te => te.preventDefault(),
            children: j
        })
    });
    return t.jsx(t.Fragment, {
        children: A ? t.jsx(eo, {
            serverThreadId: g,
            textdocVersion: e,
            initialTitle: T,
            isEditingTitle: A,
            setIsEditingTitle: _
        }) : t.jsxs(t.Fragment, {
            children: [!1, t.jsxs(k.Root, {
                open: P,
                onOpenChange: d,
                children: [t.jsxs(k.Trigger, {
                    ref: I,
                    className: "hover:bg-token-surface-hover grid grid-cols-[1fr_auto] border-none bg-transparent! pe-2",
                    children: [t.jsx(re.Title, {
                        className: "max-w-[270px] truncate overflow-hidden",
                        children: b ? t.jsx("div", {
                            className: "w-52",
                            children: t.jsx(ns, {
                                lines: 1,
                                size: "base",
                                width: 100,
                                widthVariance: 0
                            })
                        }) : T
                    }), t.jsx("div", {
                        className: "flex items-center ps-1",
                        children: n ? t.jsx(zt, {
                            size: 12,
                            className: "text-token-text-tertiary"
                        }) : t.jsx(un, {
                            className: "icon-sm text-token-text-tertiary"
                        })
                    })]
                }), R]
            })]
        })
    })
};

function ao({
    textdocVersion: e,
    clientThreadId: n,
    color: s
}) {
    const {
        handleCopy: a,
        Icon: i,
        copyLabel: r
    } = ha({
        textdocVersion: e,
        clientThreadId: n
    });
    return t.jsx(qe, {
        label: r,
        children: t.jsx(Se, {
            icon: i,
            onClick: a,
            color: s
        })
    })
}

function oo({
    textdocVersion: e,
    disabled: n,
    clientThreadId: s
}) {
    const a = V(),
        {
            handleFileDownload: i,
            handleBlobDownload: r,
            isLoading: o,
            downloadCopyLabel: l,
            isDocument: h
        } = pa({
            textdocVersion: e,
            clientThreadId: s
        });
    return h ? t.jsxs(k.Sub, {
        children: [t.jsx(k.SubMenuTrigger, {
            icon: Gt,
            label: l,
            disabled: o || n
        }), t.jsx(k.Portal, {
            children: t.jsxs(k.SubContent, {
                align: "end",
                children: [t.jsx(k.Item, {
                    onClick: c => {
                        c.preventDefault(), i("pdf")
                    },
                    children: a.formatMessage({
                        id: "canvas.download-pdf-button.menu",
                        defaultMessage: "PDF Document (.pdf)"
                    })
                }), t.jsx(k.Item, {
                    onClick: c => {
                        c.preventDefault(), i("docx")
                    },
                    children: a.formatMessage({
                        id: "canvas.download-docx-button.menu",
                        defaultMessage: "Microsoft Word Document (.docx)"
                    })
                }), t.jsx(k.Item, {
                    onClick: c => {
                        c.preventDefault(), i("md")
                    },
                    children: a.formatMessage({
                        id: "canvas.download-md-button.menu",
                        defaultMessage: "Markdown Document (.md)"
                    })
                })]
            })
        })]
    }) : t.jsx(k.Item, {
        label: l,
        icon: Gt,
        disabled: o || n,
        onClick: r
    })
}

function ro(e) {
    for (const n of io) {
        const s = e.match(n);
        if (s) return s[0]
    }
    return null
}
const io = [/AKIA[0-9A-Z]{16}/, /AIza[0-9A-Za-z_-]{35}/, /^(?:ghp_[A-Za-z0-9]{36}|github_pat_[A-Za-z0-9]{22}_[A-Za-z0-9]{59}|gho_[A-Za-z0-9]{36}|ghu_[A-Za-z0-9]{36}|ghs_[A-Za-z0-9]{36}|ghr_[A-Za-z0-9]{36})$/, /xox[baprs]-[0-9A-Za-z-]+/, /sk-[A-Za-z0-9]{48}/, /SK[0-9a-fA-F]{32}/, /(sk_live_[0-9a-zA-Z]{24})|(sk_test_[0-9a-zA-Z]{24})/, /-----BEGIN PRIVATE KEY-----/],
    co = "".concat(Ha, "...");

function ue(e) {
    return ["canvas", "textdoc", "share", e]
}

function lo({
    isLoading: e,
    isPublishedVersionLatest: n,
    sharedTextdoc: s,
    textdocVersion: a,
    title: i
}) {
    const {
        textdocId: r
    } = a, [o, l] = m.useState(!1), h = ro(a.content), c = (d, w) => {
        d && na(d, void 0, w).then(() => {
            l(!0), setTimeout(() => {
                l(!1)
            }, 1500)
        }).catch(() => {})
    }, u = ze(), {
        mutate: v,
        isPending: S
    } = de({
        scope: {
            id: r
        },
        mutationFn: d => G.safePost("/textdoc/{textdoc_id}/share", {
            parameters: {
                path: {
                    textdoc_id: d
                }
            }
        }).then(w => Fe(w.shared_textdoc)),
        onSuccess: d => {
            u.setQueryData(ue(r), d), c(ct(d.sharedTextdocId))
        }
    }), {
        mutate: f,
        isSuccess: A
    } = de({
        scope: {
            id: r
        },
        mutationFn: d => G.safePost("/textdoc/shared/{shared_textdoc_id}/update_to_latest", {
            parameters: {
                path: {
                    shared_textdoc_id: d
                }
            }
        }).then(w => Fe(w.shared_textdoc)),
        onSuccess: d => {
            u.setQueryData(ue(r), d)
        }
    }), {
        mutate: _
    } = de({
        scope: {
            id: r
        },
        mutationFn: ({
            sharedTextdocId: d,
            access: w
        }) => G.safePost("/textdoc/shared/{shared_textdoc_id}/update_access", {
            parameters: {
                path: {
                    shared_textdoc_id: d
                }
            },
            requestBody: {
                shared_textdoc_access: w
            }
        }).then(I => Fe(I.shared_textdoc)),
        onMutate: ({
            access: d
        }) => {
            const w = ue(r),
                I = u.getQueryData(w);
            return u.setQueryData(w, I && $(J({}, I), {
                access: d
            })), {
                previousAccess: I == null ? void 0 : I.access
            }
        },
        onSuccess: d => {
            u.setQueryData(ue(r), d)
        },
        onError: (d, w, I) => {
            const j = ue(r),
                R = u.getQueryData(j);
            u.setQueryData(j, R && $(J({}, R), {
                access: I == null ? void 0 : I.previousAccess
            }))
        }
    }), T = m.useRef(null), g = d => {
        var w;
        (w = T.current) == null || w.focus(), s ? (N.logButtonClick(q.COPY_SHARE_LINK, ye(a)), c(ct(s.sharedTextdocId), d)) : (N.logButtonClick(q.CREATE_SHARE_LINK, ye(a)), v(r))
    }, x = d => {
        s && (N.logButtonClick(d === hn.PUBLIC ? q.UPDATE_SHARE_LINK_PUBLIC : q.UPDATE_SHARE_LINK_PRIVATE, ye(a)), _({
            sharedTextdocId: s.sharedTextdocId,
            access: d
        }))
    }, b = s ? ct(s.sharedTextdocId) : void 0, E = () => {
        s && (N.logButtonClick(q.UPDATE_SHARE_LINK_TO_LATEST, ye(a)), f(s.sharedTextdocId))
    }, P = h || (s == null ? void 0 : s.isAnonifyApiKeyDetected);
    return t.jsx(Fa, {
        inputRef: T,
        isLoading: e,
        isPublishedVersionLatest: n,
        sharedObject: s && {
            id: s.sharedTextdocId,
            title: i,
            access: s.access,
            versionInt: s.versionInt,
            isModerationBlocked: s.isModerationBlocked,
            isAnonifyApiKeyDetected: s.isAnonifyApiKeyDetected
        },
        title: i,
        shareTextPlaceholder: co,
        shareUrl: b,
        isCopySuccessful: o,
        didPublishUpdates: A,
        isCreateLinkRequestInProgress: S,
        handleUpdateLatestSharedVersion: E,
        handlePrivacyChange: x,
        handlePrimaryButtonClick: g,
        maybeRenderWarndingContent: () => t.jsx(t.Fragment, {
            children: P && t.jsx(mo, {})
        })
    })
}

function ye(e) {
    return {
        textdocType: e.type,
        textdocId: e.textdocId
    }
}

function uo({
    textdocVersion: e,
    isDisabled: n,
    title: s
}) {
    const a = ta(),
        i = V(),
        r = e == null ? void 0 : e.textdocId,
        {
            data: o,
            isLoading: l
        } = ds({
            enabled: !!r && !n,
            queryKey: ue(r),
            queryFn: () => !r || r.startsWith(Cn) ? Promise.resolve(null) : G.safeGet("/textdoc/{textdoc_id}/share", {
                parameters: {
                    path: {
                        textdoc_id: r
                    }
                }
            }).then(T => T.shared_textdoc && Fe(T.shared_textdoc))
        }),
        [h, c] = m.useState(!1),
        {
            triggerRef: u,
            container: v
        } = xs({
            isOpen: h,
            onClose: () => c(!1)
        }),
        S = (a == null ? void 0 : a.isWorkspaceAccount()) && !(a != null && a.features.includes(sa.WorkspaceShareLinks));
    if (n || S || !e) return t.jsx(qe, {
        label: S ? i.formatMessage(lt.workspaceSharingDisabled) : i.formatMessage(lt.share),
        children: t.jsx(Se, {
            disabled: !0,
            icon: Wt
        })
    });
    const f = () => {
            N.logButtonClick(q.OPEN_SHARE_MENU, ye(e))
        },
        A = (o == null ? void 0 : o.versionInt) === e.versionInt && (o == null ? void 0 : o.title) === e.title,
        _ = ({
            className: T
        }) => t.jsxs("div", {
            className: "relative h-fit w-fit",
            children: [t.jsx(Wt, {
                className: T
            }), !A && o && t.jsx("div", {
                className: "absolute end-0 top-[1px] flex items-center gap-1.5",
                children: t.jsx("div", {
                    className: "h-1.5 w-1.5 rounded-full bg-blue-400"
                })
            })]
        });
    return t.jsxs(dn, {
        open: h,
        onOpenChange: c,
        children: [t.jsx(qe, {
            label: i.formatMessage(lt.share),
            children: t.jsx(mn, {
                ref: u,
                asChild: !0,
                children: t.jsx(Se, {
                    icon: _,
                    onClick: f
                })
            })
        }), t.jsx(We, {
            children: h && t.jsx(fn, {
                forceMount: !0,
                container: v,
                children: t.jsx(gn, {
                    align: "end",
                    className: "z-50",
                    sideOffset: 8,
                    collisionPadding: 8,
                    children: t.jsx(lo, {
                        title: s,
                        sharedTextdoc: o,
                        isLoading: l,
                        isPublishedVersionLatest: A,
                        textdocVersion: e
                    })
                })
            })
        })]
    })
}

function mo() {
    return t.jsx(pn, {
        type: "danger",
        className: "w-auto md:p-3",
        children: t.jsx(ut, {
            id: "8NG6sN",
            defaultMessage: "There may be an API key in your canvas. If you share the canvas, anyone with the link can see its contents."
        })
    })
}

function fo({
    disabled: e = !1,
    isShowingChanges: n,
    onMouseEnter: s,
    onClick: a,
    onEsc: i
}) {
    const r = V(),
        o = m.useRef(null);
    return m.useEffect(() => {
        if (n) {
            const l = h => {
                h.key === "Escape" && (i == null || i(), o.current && o.current === document.activeElement && o.current.blur())
            };
            return window.document.addEventListener("keydown", l), () => {
                window.document.removeEventListener("keydown", l)
            }
        }
    }, [n, i]), t.jsx(qe, {
        label: !e && r.formatMessage(n ? ls.hideChanges : ls.showChanges),
        children: t.jsx(Se, {
            icon: xn,
            ref: o,
            disabled: e,
            onClick: a,
            onMouseEnter: s,
            className: be("transition-colors enabled:hover:bg-black/5 dark:enabled:hover:bg-white/10", n && Ua)
        })
    })
}
const ls = Zs({
        showChanges: {
            id: "3jMGNS",
            defaultMessage: "Show changes"
        },
        hideChanges: {
            id: "HWiQSk",
            defaultMessage: "Hide changes"
        }
    }),
    go = ({
        clientThreadId: e,
        isHistoricalVersion: n,
        textdocVersion: s,
        readonlyReason: a,
        hasDebug: i,
        isEmbedded: r,
        isPersisting: o,
        isShowingChanges: l,
        hideRunCode: h = !1,
        hideHistoryActions: c = !1,
        hideRenameButton: u = !1,
        onHoverPrevious: v,
        onHoverShowChanges: S,
        onToggleShowChanges: f,
        onClickPrevious: A,
        onClickNext: _,
        onClickCodePreview: T,
        onClose: g,
        toggleDebugView: x,
        toggleConsoleVisibility: b,
        isCodeRunning: E,
        isTextdocAttachedPending: P,
        isTextdocStreaming: d,
        isConsoleOpen: w,
        isDebugVisible: I
    }) => {
        var Q, he, Ie, ke;
        const j = V(),
            R = aa(),
            H = Ge(s == null ? void 0 : s.textdocId),
            W = (Q = s == null ? void 0 : s.title) != null ? Q : "",
            {
                isCodePreviewable: te,
                isCodeExecutable: F,
                hasCanvasCodeExecution: O
            } = bs(s),
            ne = (he = s == null ? void 0 : s.metadata) == null ? void 0 : he.hive_id,
            D = (Ie = s == null ? void 0 : s.metadata) == null ? void 0 : Ie.record_meeting_id,
            me = Qe(),
            Te = (D != null || ne != null) && vs(me, "292227286"),
            {
                mutate: Ze,
                isPending: Ye
            } = de({
                scope: {
                    id: (ke = D != null ? D : ne) != null ? ke : ""
                },
                mutationFn: () => D ? G.safePost("/record/meetings/{meeting_id}/send_summary_to_slack", {
                    parameters: {
                        path: {
                            meeting_id: D
                        }
                    }
                }) : ne ? G.safePost("/hive/{hive_id}/send_summary_to_slack", {
                    parameters: {
                        path: {
                            hive_id: ne
                        }
                    }
                }) : Promise.resolve({
                    textdoc_id: ""
                })
            }),
            Ae = () => {
                !D && !ne || Ze()
            },
            U = !h && (te || F),
            ee = s == null ? void 0 : s.versionInt,
            ae = ee != null && ee > 1,
            fe = n,
            ge = !c,
            Ee = te && E,
            we = s == null || H != null || n || a.isStreaming,
            _e = s == null || a.isStreaming;
        return t.jsxs(re.Header, {
            className: be("@container", te && E && "bg-transparent!"),
            children: [t.jsx(re.CloseButton, {
                onClick: g
            }), t.jsx("div", {
                className: "@container flex flex-1 basis-0 items-center truncate leading-[0]",
                children: t.jsx(no, {
                    hasDebug: i,
                    isConsoleOpen: w,
                    isDebugVisible: I,
                    toggleConsoleVisibility: b,
                    toggleDebugView: x,
                    isPersisting: o,
                    textdocVersion: s,
                    isTextdocAttachedPending: P,
                    isTextdocStreaming: d,
                    shouldShowPlayButton: U,
                    hideRenameButton: u,
                    clientThreadId: e
                })
            }), t.jsxs("div", {
                className: "flex min-w-0 basis-auto items-center leading-[0] select-none",
                children: [t.jsx(ao, {
                    clientThreadId: e,
                    textdocVersion: s
                }), t.jsx(uo, {
                    isDisabled: we,
                    textdocVersion: s,
                    title: W
                }), ge && t.jsx(We, {
                    children: t.jsx(oe.div, {
                        initial: {
                            opacity: 0
                        },
                        animate: {
                            opacity: 1
                        },
                        exit: {
                            opacity: 0,
                            width: 0
                        },
                        transition: {
                            type: "spring",
                            bounce: .24,
                            duration: .4
                        },
                        children: t.jsx(fo, {
                            disabled: Ee || a.isStreaming || !ae,
                            isShowingChanges: l,
                            onMouseEnter: S,
                            onClick: f,
                            onEsc: f
                        })
                    })
                }), t.jsxs(k.Root, {
                    children: [t.jsx(k.BasicTrigger, {
                        children: t.jsx(Se, {
                            icon: oa
                        })
                    }), t.jsx(k.Portal, {
                        children: t.jsxs(k.Content, {
                            align: "end",
                            children: [t.jsx(k.Item, {
                                icon: vn,
                                disabled: !ae,
                                onClick: A,
                                onMouseOver: v,
                                label: j.formatMessage({
                                    id: "PoD5+8",
                                    defaultMessage: "Previous version"
                                })
                            }), t.jsx(k.Item, {
                                icon: yn,
                                disabled: !fe,
                                onClick: _,
                                label: j.formatMessage({
                                    id: "PJ8YVJ",
                                    defaultMessage: "Next version"
                                })
                            }), t.jsxs(k.Group, {
                                children: [s && s.type !== xe.LOADING && H == null && t.jsx(oo, {
                                    disabled: _e,
                                    textdocVersion: s,
                                    clientThreadId: e
                                }), Te && t.jsx(k.Item, {
                                    icon: ra,
                                    disabled: Ye,
                                    onClick: Ae,
                                    label: j.formatMessage({
                                        id: "CRHbjv",
                                        defaultMessage: "Send to Slack"
                                    })
                                })]
                            })]
                        })
                    })]
                }), U && t.jsx(wa, {
                    clientThreadId: e,
                    isCodePreviewable: te,
                    isDisabled: !O || a.isTextdocStreaming && !E,
                    disabledTooltip: O ? void 0 : j.formatMessage({
                        id: "NTZRWe",
                        defaultMessage: "Code execution for canvas is disabled for your workspace. Contact your admin to enable."
                    }),
                    onClick: T,
                    isCodeRunning: E
                }), !r && !R && t.jsx(qa, {
                    clientThreadId: e
                })]
            })]
        })
    };

function ho(e) {
    const n = /\[([^\]]+)\]\((https?:\/\/[^\s)]+|www\.[^\s)]+)\)/gi,
        s = new Set,
        a = e.matchAll(n);
    for (const i of a) {
        const r = i[2];
        try {
            let o = r;
            o.startsWith("www.") && (o = "http://" + r), new URL(o), s.add(r)
        } catch (o) {}
    }
    return s
}
const po = async ({
        lastVersion: e,
        textdocId: n,
        content: s,
        comments: a
    }) => {
        const i = bn(a, s);
        return (await G.safePost("/textdoc/{textdoc_id}", {
            parameters: {
                path: {
                    textdoc_id: n
                }
            },
            requestBody: {
                version: e,
                content: s,
                comments: i
            }
        })).version
    },
    Co = () => {
        const e = m.useRef([]),
            n = m.useRef(null),
            {
                mutateAsync: s,
                isPending: a
            } = de({
                mutationKey: ["canvas", "textdoc", "persist"],
                mutationFn: po
            });
        return [m.useCallback(async (r, o, l) => {
            const h = new AbortController,
                u = (async () => {
                    var _, T;
                    const [A] = e.current;
                    try {
                        await (A == null ? void 0 : A.promise)
                    } catch (g) {
                        N.logError("Saving document", g)
                    }
                    if (!h.signal.aborted) try {
                        const g = Math.max((_ = n.current) != null ? _ : 0, (T = r.versionInt) != null ? T : fs);
                        let x = "";
                        try {
                            cs(o) ? x = o() : x = o
                        } catch (d) {
                            N.logError("Serializing document", d)
                        }
                        let b = [];
                        try {
                            cs(l) ? b = l() : b = l
                        } catch (d) {
                            N.logError("Adjusting comments", d)
                        }
                        const {
                            textdocId: E
                        } = r;
                        Sn({
                            textdocId: E,
                            basedOnVersionInt: g,
                            content: x,
                            comments: b
                        });
                        const P = await s({
                            textdocId: E,
                            lastVersion: g,
                            content: x,
                            comments: b
                        });
                        Tn({
                            textdocId: E,
                            basedOnVersionInt: g,
                            newVersion: P
                        }), n.current = P
                    } catch (g) {
                        N.logError("Error saving document", g)
                    } finally {
                        e.current.shift()
                    }
                })(),
                v = {
                    abort: () => h.abort(),
                    promise: u
                },
                [S, f] = e.current;
            return f && (f.abort(), e.current = S ? [S] : []), e.current = S ? [S, v] : [v], u
        }, [s]), e, a]
    },
    xo = 3e3,
    vo = e => {
        const [n, s, a] = Co(), i = V(), r = m.useRef(null), o = m.useCallback(ia(async (c, u, v) => {
            if (!dt(c)) return n(c, u, v);
            Ue.replaceTempTextdocContent(c.textdocId, typeof u == "string" ? u : u())
        }, xo, {
            leading: !1
        }), [n]), l = An(e);
        return m.useEffect(() => {
            if (!l) return;
            const c = as(window, {
                    pagehide: () => o.flush(),
                    beforeunload: v => {
                        o.flush(), v.returnValue = i.formatMessage({
                            id: "QZrKwi",
                            defaultMessage: "You have a canvas save in progress."
                        })
                    }
                }),
                u = as(document, {
                    visibilitychange: () => o.flush(),
                    keydown: () => {
                        r.current = "keyboard"
                    },
                    mousemove: () => {
                        r.current !== "mouse" && o.flush(), r.current = "mouse"
                    }
                });
            return () => {
                r.current = null, u(), c()
            }
        }, [i, l, o]), m.useEffect(() => () => {
            o.flush()
        }, [e, o]), En(async () => {
            var c, u;
            await o.flush(), await Promise.allSettled((u = (c = s.current) == null ? void 0 : c.map(({
                promise: v
            }) => v)) != null ? u : [])
        }), [m.useCallback((c, u, v) => {
            const {
                textdocId: S
            } = c;
            return dt(c) || wn(S), o(c, u, v)
        }, [o]), o.flush, a || l]
    };

function yo(e, n, s) {
    const a = ze(),
        i = s != null && n != null,
        {
            data: r,
            error: o,
            fetchNextPage: l,
            hasNextPage: h,
            isFetching: c
        } = Ys(us(e, n, i)),
        u = m.useCallback(async () => {
            const _ = n != null;
            await a.prefetchInfiniteQuery(us(e, n, _))
        }, [a, e, n]);
    m.useEffect(() => {
        const _ = n;
        return () => {
            a.removeQueries({
                queryKey: Ss(e, _),
                exact: !0
            })
        }
    }, [a, e, n]);
    const [v, S, f, A] = m.useMemo(() => {
        var T;
        if (r && s) {
            const g = r.pages.flatMap(b => b),
                x = g.findIndex(b => {
                    var E;
                    return "beforeVersion" in s ? ((E = b.versionInt) != null ? E : fs) < s.beforeVersion : b.versionInt === s.version
                });
            if (x !== -1) return [x === g.length - 1, g[x], x > 0 ? g[x - 1] : null, x < g.length - 1 ? g[x + 1] : null]
        }
        const _ = (T = r == null ? void 0 : r.pages.flatMap(g => g)) != null ? T : [];
        return [!0, null, null, _.length === 0 ? null : _[0]]
    }, [r, s]);
    return m.useEffect(() => {
        !c && i && h && v && l()
    }, [c, i, h, v, l]), m.useEffect(() => {
        !S && o && ve(e)
    }, [S, o, e]), {
        historicalTextdocVersion: S,
        nextHistoricalTextdocVersion: f,
        prefetchHistoricalTextdocVersion: u,
        previousHistoricalTextdocVersion: A
    }
}

function Ss(e, n = null) {
    return ["textdocHistory", e, n]
}

function us(e, n, s = !0) {
    return {
        queryKey: Ss(e, n),
        queryFn: ({
            pageParam: a
        }) => bo(e, a),
        initialPageParam: n != null ? n : void 0,
        getNextPageParam: a => {
            var r;
            const i = (r = ca(a)) == null ? void 0 : r.versionInt;
            if (i && i > 1) return i
        },
        enabled: s,
        staleTime: 1 / 0,
        retry: 2
    }
}
async function bo(e, n) {
    return n === void 0 || n <= 1 ? [] : (await G.safeGet("/textdoc/{textdoc_id}/history", {
        parameters: {
            path: {
                textdoc_id: e
            },
            query: {
                before_version: n
            }
        }
    })).previous_doc_states.map(({
        id: a,
        version: i,
        textdoc_type: r,
        title: o,
        content: l,
        updated_at: h,
        comments: c,
        metadata: u
    }) => ({
        textdocId: a,
        versionInt: i,
        messageId: null,
        title: o,
        type: In(r),
        content: l,
        status: ms.COMPLETE,
        createdAt: la(h),
        comments: _n(c, l),
        metadata: {
            content_references: u == null ? void 0 : u.content_references,
            hive_id: u == null ? void 0 : u.hive_id
        }
    }))
}
const Qo = ({
    isFullScreen: e = !1,
    isEmbedded: n = !1,
    hideHeader: s = !1,
    hideRunCode: a = !1,
    isReadonlyFromQueryParam: i = !1,
    hideRenameButton: r = !1,
    clientThreadId: o,
    focusedTextdoc: l,
    onClose: h,
    isAnimating: c = !1,
    width: u,
    hideBottomComposer: v = !1
}) => {
    "use no forget";
    var Ot, Lt, Ht, Ft;
    const S = Qe(),
        {
            textdocId: f,
            history: A,
            showChangesAtVersion: _ = null,
            shouldRunCodeOnOpen: T = !1
        } = $a(l),
        g = V(),
        [x, b, E] = vo(f),
        {
            targetedContent: P
        } = kn(),
        d = jn(S),
        [w, I] = m.useState(!1),
        [j, R] = m.useState(!1),
        H = Pn(f),
        W = Rn(),
        te = mt(o, hs.getRequestId),
        F = ua(te),
        {
            data: O,
            isLoading: ne
        } = ds(it(f, _)),
        [D, me] = m.useState(!1),
        [Te, Ze] = m.useState(null),
        Ye = Dn(o),
        Ae = m.useRef(null),
        U = (Ot = H == null ? void 0 : H.versions) != null ? Ot : [],
        ee = (Lt = U[0]) == null ? void 0 : Lt.versionInt,
        {
            historicalTextdocVersion: ae,
            nextHistoricalTextdocVersion: fe,
            previousHistoricalTextdocVersion: ge,
            prefetchHistoricalTextdocVersion: Ee
        } = yo(f, ee, A),
        we = ze();
    m.useEffect(() => {
        Ke.reset()
    }, [f]);
    const _e = U.length > 0 ? U[U.length - 1] : null,
        Q = U.length > 1 ? U[U.length - 2] : null,
        he = Cs(o),
        {
            restoreHistoricalTextdocVersion: Ie,
            optimisticRestoredTextdocVersion: ke
        } = Mn(he, _e, ae),
        ie = A != null,
        p = ie ? ae : _e,
        Z = _ != null,
        pe = ja(o, p),
        je = c ? null : O,
        Pe = (() => {
            if (c || p == null) return [];
            const C = os(p.comments);
            return !Z && ae != null ? ae.comments : !Z || O == null ? C : O.contentBefore !== O.contentAfter ? [] : Ja(O.commentsBefore, O.commentsAfter)
        })(),
        B = (Ht = p == null ? void 0 : p.type) != null ? Ht : xe.LOADING,
        ft = Ca({
            textdocVersion: p,
            clientThreadId: o
        }),
        Ts = m.useCallback(() => {
            var y, M;
            const C = (M = (y = window.getSelection()) == null ? void 0 : y.toString()) != null ? M : "";
            ft({
                source: "keyboard",
                selectedText: C,
                productLogOnly: !0
            })
        }, [ft]),
        Xe = Nn(),
        gt = dt(p),
        se = Bn(p),
        Je = On(p),
        ht = Ln(p),
        As = ht && !n,
        Es = Qt(W),
        ws = Qt(F);
    m.useEffect(() => {
        !gt && U.length === 0 && Xe !== Zt.NATIVE && (!W && Es.current || !F && ws.current || !W && !F) && (h == null || h())
    }, [U.length, W, F]);
    const {
        content: L,
        currentlyStreamingLineIndex: Re
    } = (O == null ? void 0 : O.contentBefore) != null && !Yt(B) ? {
        content: O.contentBefore,
        currentlyStreamingLineIndex: null
    } : xa(p, Q), _s = Hn(he, Array.from(ho(L))), [De, $e] = Ga({
        value: L,
        isRequestActive: F,
        isTextdocStreaming: se,
        comments: Pe
    }), pt = Fn(p), Ct = Xe === Zt.LAST_TURN || De || E;
    m.useEffect(() => {
        Un().sendMessage({
            type: ys.Streaming,
            streaming: Ct
        })
    }, [Ct]);
    const Is = ({
            getSerializedDocument: C,
            getAdjustedComments: y
        }) => {
            p && x(p, C, y)
        },
        ks = C => {
            var M;
            if (!p) return;
            const y = C.doc.toString();
            x(p, y, (M = C.field(ba, !1)) != null ? M : [])
        },
        xt = (C, y, M, X, ce) => {
            $e(!0), pe({
                sourceEvent: C,
                action: M,
                content: y,
                userMessageType: Le.ASK_CHATGPT,
                sourceRange: X,
                selectionMetadata: {
                    selection_type: ce,
                    selection_position_range: X
                }
            })
        },
        vt = ({
            id: C
        }) => {
            pt(C, $t.DISMISS), Ke.reset()
        },
        yt = async (C, y) => {
            $e(!0);
            const {
                id: M,
                at: X,
                content: ce
            } = y;
            if (await pt(M, $t.ACCEPT) === !1) return $e(!1);
            pe({
                sourceEvent: C,
                content: ce,
                userMessageType: Le.ACCEPT_COMMENT,
                sourceRange: X,
                action: is.EDIT,
                selectionMetadata: {
                    selection_type: rs.SELECTION,
                    selection_position_range: X
                }
            })
        },
        Ve = (C, y, M, X) => {
            const {
                action: ce
            } = X;
            pe({
                sourceEvent: C,
                action: ce,
                content: M,
                sourceRange: y,
                userMessageType: Le.ACCELERATOR,
                acceleratorMetadata: {
                    action: ce,
                    id: X.id,
                    prompt: M
                },
                selectionMetadata: y != null ? {
                    selection_type: rs.SELECTION,
                    selection_position_range: y
                } : void 0
            })
        },
        js = (C, y) => {
            pe({
                sourceEvent: C,
                action: is.EDIT,
                content: y,
                userMessageType: Le.FULL_SCREEN_SUBMIT
            })
        },
        et = qn(),
        bt = C => {
            var y;
            return (y = et == null ? void 0 : et[C]) != null ? y : C
        },
        tt = () => Kn(o, void 0, {
            clientInitiated: !0,
            reason: "textdoc_canvas_cancel"
        }),
        Ps = () => {
            A ? He(f, A) : ve(f)
        },
        K = _a({
            streamingSource: Xe,
            isRestoring: ke != null,
            isRequestActive: F,
            isTextdocStreaming: se,
            isReadonlyFromQueryParam: i,
            isHistoricalVersion: ie,
            isShowingChanges: Z
        });
    let Me = null;
    const St = c || K.isReadonly || De,
        Ne = gs() || Ye || i || gt,
        Tt = () => c && Pe.length > 0 ? le.ALL_HIDDEN : Ne ? le.COMMENTS_READONLY : K.isReadonly ? K.isStreaming ? le.ENABLED : K.isReadonlyFromQueryParam || K.isShowingChanges || K.isHistoricalVersion ? le.COMMENTS_READONLY : le.ALL_HIDDEN : le.ENABLED,
        Rs = m.useCallback(async C => {
            const {
                suggestion: y
            } = await G.safePost("/textdoc/{textdoc_id}/autocomplete", {
                parameters: {
                    path: {
                        textdoc_id: f
                    }
                },
                requestBody: {
                    content: C
                }
            });
            return y
        }, [f]),
        At = e || c || i;
    let st = [];
    switch (B) {
        case xe.LOADING:
            Me = t.jsx(ya, {});
            break;
        case xe.DOCUMENT:
            Me = t.jsx(va, {
                value: L,
                comments: Pe,
                previousValue: Q == null ? void 0 : Q.content,
                getAutocompleteSuggestion: Rs,
                previousComments: os(Q == null ? void 0 : Q.comments),
                isRewriting: Je,
                isAnimatingFromPreview: c,
                isSendDisabled: Ne,
                getStableCommentId: bt,
                diff: je,
                isRequestActive: F,
                isDisabled: K.isReadonly || W,
                isWaitingForCommentResponse: De,
                hideAccelerators: At,
                hideToolbar: St,
                hideEditOverlay: c,
                commentsMode: Tt(),
                readonlyReason: K,
                onBlur: b,
                onSave: b,
                onChange: Is,
                onCancelRequest: tt,
                targetedContent: P,
                onAddComment: xt,
                onAcceptComment: yt,
                onDismissComment: vt,
                onSubmitAccelerator: Ve,
                onExitShowChanges: Ps,
                safeUrls: _s,
                width: u,
                modelCursor: ht || se && !Je ? p == null ? void 0 : p.modelCursor : void 0,
                shouldResetSelection: (p == null ? void 0 : p.versionInt) === 1,
                metadata: H == null ? void 0 : H.metadata
            }), st = Na;
            break;
        default:
            Yt(B) && (Me = t.jsx(Ta, {
                id: "codemirror",
                getStableCommentId: bt,
                language: ka(B),
                value: L,
                comments: Pe,
                hideAccelerators: At,
                commentsMode: Tt(),
                hideToolbar: St,
                onSubmitAccelerator: Ve,
                currentlyStreamingLineIndex: Re != null ? Re : null,
                readonlyReason: K,
                isRequestActive: F,
                isSendDisabled: Ne,
                isWaitingForCommentResponse: De,
                onChange: ks,
                onCancelRequest: tt,
                onAddComment: xt,
                onBlur: b,
                onSave: b,
                codemirrorRef: Ae,
                onDismissComment: vt,
                onAcceptComment: yt,
                textdocDiff: je != null ? je : void 0,
                modelCursor: se && Re == null ? p == null ? void 0 : p.modelCursor : void 0
            }), st = Sa)
    }
    const Ce = m.useRef(null),
        nt = m.useRef(null),
        {
            hasCanvasCodeExecution: at,
            isCodeExecutable: Et,
            isCodePreviewable: Y
        } = bs(p),
        wt = at && Y,
        _t = at && Et,
        Ds = zn(),
        It = m.useCallback(() => {
            var C, y;
            !D && (wt || _t) ? (me(!0), (C = Ce.current) == null || C.runCode(B, L)) : ((y = Ce.current) == null || y.stopCode(), me(!1))
        }, [wt, _t, D, L, B]),
        kt = Gn(() => {
            It()
        });
    m.useEffect(() => {
        T && kt()
    }, [T, kt]);
    const z = p == null ? void 0 : p.versionInt,
        Ms = z != null && z > 1,
        Ns = ie,
        Be = ge == null ? void 0 : ge.versionInt,
        ot = fe == null ? void 0 : fe.versionInt,
        Bs = () => {
            Z ? A ? He(f, A) : ve(f) : (N.logButtonClick(q.SHOW_CHANGES, {
                textdocType: B,
                textdocId: f,
                versionInt: z,
                latestVersionInt: ee
            }), z && Vt(f, z, A))
        },
        Os = () => {
            N.logButtonClick(q.HISTORY_PREVIOUS, {
                textdocType: B,
                textdocId: f,
                versionInt: z,
                latestVersionInt: ee,
                isShowingChanges: Z
            }), f && z && Ms && He(f, {
                beforeVersion: z
            }, Z && Be != null ? Be : void 0)
        },
        Ls = () => {
            N.logButtonClick(q.HISTORY_NEXT, {
                textdocType: B,
                textdocId: f,
                versionInt: z,
                latestVersionInt: ee,
                isShowingChanges: Z
            }), Ns && (ot ? He(f, {
                version: ot
            }, Z ? ot : void 0) : Z && ee ? Vt(f, ee, null) : ve(f))
        },
        Hs = vs(S, "1804926979"),
        jt = mt(o, Ka(f)),
        Fs = da(),
        Pt = Ge(p == null ? void 0 : p.textdocId),
        Us = !s && t.jsx(go, {
            hideRunCode: a,
            clientThreadId: o,
            isHistoricalVersion: ie,
            textdocVersion: p,
            readonlyReason: K,
            hasDebug: d,
            isEmbedded: n,
            isPersisting: E,
            isShowingChanges: Z,
            isConsoleOpen: j,
            isDebugVisible: w,
            hideHistoryActions: i,
            hideRenameButton: r,
            onHoverPrevious: () => {
                Ee(), Be && we.prefetchQuery(it(f, Be))
            },
            onHoverShowChanges: () => {
                Ee(), z && we.prefetchQuery(it(f, z))
            },
            onToggleShowChanges: Bs,
            onClickPrevious: Os,
            onClickNext: Ls,
            toggleDebugView: () => I(C => !C),
            toggleConsoleVisibility: () => {
                j || ga.logEvent("Canvas Open Console Clicked"), R(C => !C)
            },
            onClose: () => {
                if (N.logButtonClick(q.CLOSE_TEXTDOC, {
                        textdocType: p == null ? void 0 : p.type
                    }), Pt && !e) {
                    const {
                        create_source: C,
                        hasUserEdits: y,
                        tempTextdocId: M
                    } = Pt;
                    if (y && C !== Jt.USER_CREATED_COMPOSER) {
                        Mt(!0);
                        return
                    }
                    if (Ue.removeTempTextdoc(M), C === Jt.USER_CREATED_COMPOSER) {
                        const X = ma(Fs);
                        fa(X, L)
                    }
                }
                h == null || h()
            },
            onClickCodePreview: It,
            isCodeRunning: D,
            isTextdocStreaming: se,
            isTextdocAttachedPending: Xt(p)
        });
    let Rt = null;
    const Oe = !a && at && (Et || Y),
        rt = Ia(B, L);
    m.useEffect(() => {
        var C;
        Oe && rt && ((C = nt.current) == null || C.prepareEnvironment(L, rt))
    }, [Oe, rt]), m.useEffect(() => {
        var C;
        Y && D && !se && ((C = Ce.current) == null || C.runCode(B, L))
    }, [Y, se, L, B]);
    const Dt = (Ft = p == null ? void 0 : p.title) != null ? Ft : "";
    Oe && (Rt = t.jsx(Pa, {
        id: f,
        title: Dt,
        onChangeBackgroundColor: Ze,
        onCodeRunComplete: () => me(!1),
        visuallyHidden: !Y || !D,
        disableNetworkRequests: !Ds,
        networkAccessDeniedMessage: g.formatMessage({
            id: "GE4AJf",
            defaultMessage: "Network requests in canvas are disabled for your workspace. Contact your admin to enable this feature."
        }),
        enableTransition: Y && B !== xe.CODE_HTML,
        isCodeUpdating: se,
        ref: nt,
        onRetryCodeRun: () => {
            var C;
            return (C = Ce.current) == null ? void 0 : C.runCode(B, L)
        }
    }));
    const [qs, Mt] = m.useState(!1), Nt = t.jsx(za, {
        isOpen: qs,
        dismissModal: () => Mt(!1),
        closeTextdocEditor: () => {
            h == null || h()
        },
        textdocVersion: p,
        clientThreadId: o
    }), Bt = t.jsxs(t.Fragment, {
        children: [Us, t.jsx(re.Content, {
            scrollToBottomMode: As ? "bottom" : "top",
            shouldScrollToTop: Je,
            isLoading: ne,
            hideChildren: Y && D,
            overlay: Rt,
            onCopy: Ts,
            children: Me
        }), Oe && t.jsx(Ra, {
            ref: Ce,
            sandboxRef: nt,
            textdocId: f,
            textdocTitle: Dt,
            textdocContent: L,
            isTextdocAttachedPending: Xt(p),
            highlightLine: C => {
                var y;
                return (y = Ae.current) == null ? void 0 : y.highlightLine(C)
            },
            isRequestActive: F,
            createTextdocTurn: pe,
            isOpen: j,
            onOpenChange: R
        }), t.jsx(We, {
            children: ie && !i && t.jsx(Wa, {
                onClickRestore: Ie,
                onClickResetLatest: () => ve(f)
            })
        }), e && !ie && !v && !(D && Y) && !Ne && t.jsx(Xa, {
            isRequestActive: F,
            clientThreadId: o,
            onSubmitAccelerator: Ve,
            onSubmit: js,
            onCancel: tt,
            readonlyReason: K,
            acceleratorActions: st
        })]
    });
    if (Hs && jt && p) {
        const y = new URLSearchParams(window.location.search).get(Da),
            M = y == null ? void 0 : parseInt(y);
        return t.jsxs(t.Fragment, {
            children: [Nt, t.jsx(re, {
                previewBackgroundColor: Te,
                isPreviewingCode: Y && D,
                children: t.jsxs("div", {
                    className: "flex h-full",
                    children: [t.jsx("div", {
                        className: "relative flex h-full min-h-0 flex-auto grow flex-col",
                        children: Bt
                    }), t.jsx(Ma, {
                        hiveId: jt,
                        clientThreadId: o,
                        textdocVersion: p,
                        ts: M
                    })]
                })
            })]
        })
    }
    return t.jsxs(t.Fragment, {
        children: [Nt, t.jsx(re, {
            previewBackgroundColor: Te,
            isPreviewingCode: Y && D,
            children: Bt
        })]
    })
};
export {
    ys as C, Qo as T
};
//# sourceMappingURL=kz8g43osloy7fyhi.js.map