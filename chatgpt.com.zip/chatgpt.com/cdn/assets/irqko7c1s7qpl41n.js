const a = "https://chatgpt.com/canvas/shared/";

function s(t) {
    return "".concat(a).concat(t)
}
export {
    a as S, s as g
};
//# sourceMappingURL=irqko7c1s7qpl41n.js.map