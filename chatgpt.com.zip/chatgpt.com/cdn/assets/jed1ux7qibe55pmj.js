var M = Object.defineProperty;
var D = Object.getOwnPropertySymbols;
var $ = Object.prototype.hasOwnProperty,
    O = Object.prototype.propertyIsEnumerable;
var F = (n, e, t) => e in n ? M(n, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : n[e] = t,
    V = (n, e) => {
        for (var t in e || (e = {})) $.call(e, t) && F(n, t, e[t]);
        if (D)
            for (var t of D(e)) O.call(e, t) && F(n, t, e[t]);
        return n
    };
import {
    h as Y
} from "./fg33krlcm0qyi6yw.js";
import {
    s as G
} from "./h1em0bjkpkjv8ykw.js";

function k(n) {
    if (n) throw n
}
var A, N;

function J() {
    if (N) return A;
    N = 1;
    var n = Object.prototype.hasOwnProperty,
        e = Object.prototype.toString,
        t = Object.defineProperty,
        r = Object.getOwnPropertyDescriptor,
        i = function(o) {
            return typeof Array.isArray == "function" ? Array.isArray(o) : e.call(o) === "[object Array]"
        },
        s = function(o) {
            if (!o || e.call(o) !== "[object Object]") return !1;
            var l = n.call(o, "constructor"),
                u = o.constructor && o.constructor.prototype && n.call(o.constructor.prototype, "isPrototypeOf");
            if (o.constructor && !l && !u) return !1;
            var h;
            for (h in o);
            return typeof h > "u" || n.call(o, h)
        },
        f = function(o, l) {
            t && l.name === "__proto__" ? t(o, l.name, {
                enumerable: !0,
                configurable: !0,
                value: l.newValue,
                writable: !0
            }) : o[l.name] = l.newValue
        },
        c = function(o, l) {
            if (l === "__proto__")
                if (n.call(o, l)) {
                    if (r) return r(o, l).value
                } else return;
            return o[l]
        };
    return A = function a() {
        var o, l, u, h, y, g, d = arguments[0],
            b = 1,
            H = arguments.length,
            E = !1;
        for (typeof d == "boolean" && (E = d, d = arguments[1] || {}, b = 2), (d == null || typeof d != "object" && typeof d != "function") && (d = {}); b < H; ++b)
            if (o = arguments[b], o != null)
                for (l in o) u = c(d, l), h = c(o, l), d !== h && (E && h && (s(h) || (y = i(h))) ? (y ? (y = !1, g = u && i(u) ? u : []) : g = u && s(u) ? u : {}, f(d, {
                    name: l,
                    newValue: a(E, g, h)
                })) : typeof h < "u" && f(d, {
                    name: l,
                    newValue: h
                }));
        return d
    }, A
}
var K = J();
const I = Y(K);

function L(n) {
    if (typeof n != "object" || n === null) return !1;
    const e = Object.getPrototypeOf(n);
    return (e === null || e === Object.prototype || Object.getPrototypeOf(e) === null) && !(Symbol.toStringTag in n) && !(Symbol.iterator in n)
}

function Q() {
    const n = [],
        e = {
            run: t,
            use: r
        };
    return e;

    function t(...i) {
        let s = -1;
        const f = i.pop();
        if (typeof f != "function") throw new TypeError("Expected function as last argument, not " + f);
        c(null, ...i);

        function c(a, ...o) {
            const l = n[++s];
            let u = -1;
            if (a) {
                f(a);
                return
            }
            for (; ++u < i.length;)(o[u] === null || o[u] === void 0) && (o[u] = i[u]);
            i = o, l ? W(l, c)(...o) : f(null, ...o)
        }
    }

    function r(i) {
        if (typeof i != "function") throw new TypeError("Expected `middelware` to be a function, not " + i);
        return n.push(i), e
    }
}

function W(n, e) {
    let t;
    return r;

    function r(...f) {
        const c = n.length > f.length;
        let a;
        c && f.push(i);
        try {
            a = n.apply(this, f)
        } catch (o) {
            const l = o;
            if (c && t) throw l;
            return i(l)
        }
        c || (a instanceof Promise ? a.then(s, i) : a instanceof Error ? i(a) : s(a))
    }

    function i(f, ...c) {
        t || (t = !0, e(f, ...c))
    }

    function s(f) {
        i(null, f)
    }
}
class p extends Error {
    constructor(e, t, r) {
        super(), typeof t == "string" && (r = t, t = void 0);
        let i = "",
            s = {},
            f = !1;
        if (t && ("line" in t && "column" in t ? s = {
                place: t
            } : "start" in t && "end" in t ? s = {
                place: t
            } : "type" in t ? s = {
                ancestors: [t],
                place: t.position
            } : s = V({}, t)), typeof e == "string" ? i = e : !s.cause && e && (f = !0, i = e.message, s.cause = e), !s.ruleId && !s.source && typeof r == "string") {
            const a = r.indexOf(":");
            a === -1 ? s.ruleId = r : (s.source = r.slice(0, a), s.ruleId = r.slice(a + 1))
        }
        if (!s.place && s.ancestors && s.ancestors) {
            const a = s.ancestors[s.ancestors.length - 1];
            a && (s.place = a.position)
        }
        const c = s.place && "start" in s.place ? s.place.start : s.place;
        this.ancestors = s.ancestors || void 0, this.cause = s.cause || void 0, this.column = c ? c.column : void 0, this.fatal = void 0, this.file, this.message = i, this.line = c ? c.line : void 0, this.name = G(s.place) || "1:1", this.place = s.place || void 0, this.reason = this.message, this.ruleId = s.ruleId || void 0, this.source = s.source || void 0, this.stack = f && s.cause && typeof s.cause.stack == "string" ? s.cause.stack : "", this.actual, this.expected, this.note, this.url
    }
}
p.prototype.file = "";
p.prototype.name = "";
p.prototype.reason = "";
p.prototype.message = "";
p.prototype.stack = "";
p.prototype.column = void 0;
p.prototype.line = void 0;
p.prototype.ancestors = void 0;
p.prototype.cause = void 0;
p.prototype.fatal = void 0;
p.prototype.place = void 0;
p.prototype.ruleId = void 0;
p.prototype.source = void 0;
const m = {
    basename: X,
    dirname: Z,
    extname: v,
    join: ee,
    sep: "/"
};

function X(n, e) {
    if (e !== void 0 && typeof e != "string") throw new TypeError('"ext" argument must be a string');
    w(n);
    let t = 0,
        r = -1,
        i = n.length,
        s;
    if (e === void 0 || e.length === 0 || e.length > n.length) {
        for (; i--;)
            if (n.codePointAt(i) === 47) {
                if (s) {
                    t = i + 1;
                    break
                }
            } else r < 0 && (s = !0, r = i + 1);
        return r < 0 ? "" : n.slice(t, r)
    }
    if (e === n) return "";
    let f = -1,
        c = e.length - 1;
    for (; i--;)
        if (n.codePointAt(i) === 47) {
            if (s) {
                t = i + 1;
                break
            }
        } else f < 0 && (s = !0, f = i + 1), c > -1 && (n.codePointAt(i) === e.codePointAt(c--) ? c < 0 && (r = i) : (c = -1, r = f));
    return t === r ? r = f : r < 0 && (r = n.length), n.slice(t, r)
}

function Z(n) {
    if (w(n), n.length === 0) return ".";
    let e = -1,
        t = n.length,
        r;
    for (; --t;)
        if (n.codePointAt(t) === 47) {
            if (r) {
                e = t;
                break
            }
        } else r || (r = !0);
    return e < 0 ? n.codePointAt(0) === 47 ? "/" : "." : e === 1 && n.codePointAt(0) === 47 ? "//" : n.slice(0, e)
}

function v(n) {
    w(n);
    let e = n.length,
        t = -1,
        r = 0,
        i = -1,
        s = 0,
        f;
    for (; e--;) {
        const c = n.codePointAt(e);
        if (c === 47) {
            if (f) {
                r = e + 1;
                break
            }
            continue
        }
        t < 0 && (f = !0, t = e + 1), c === 46 ? i < 0 ? i = e : s !== 1 && (s = 1) : i > -1 && (s = -1)
    }
    return i < 0 || t < 0 || s === 0 || s === 1 && i === t - 1 && i === r + 1 ? "" : n.slice(i, t)
}

function ee(...n) {
    let e = -1,
        t;
    for (; ++e < n.length;) w(n[e]), n[e] && (t = t === void 0 ? n[e] : t + "/" + n[e]);
    return t === void 0 ? "." : te(t)
}

function te(n) {
    w(n);
    const e = n.codePointAt(0) === 47;
    let t = ne(n, !e);
    return t.length === 0 && !e && (t = "."), t.length > 0 && n.codePointAt(n.length - 1) === 47 && (t += "/"), e ? "/" + t : t
}

function ne(n, e) {
    let t = "",
        r = 0,
        i = -1,
        s = 0,
        f = -1,
        c, a;
    for (; ++f <= n.length;) {
        if (f < n.length) c = n.codePointAt(f);
        else {
            if (c === 47) break;
            c = 47
        }
        if (c === 47) {
            if (!(i === f - 1 || s === 1))
                if (i !== f - 1 && s === 2) {
                    if (t.length < 2 || r !== 2 || t.codePointAt(t.length - 1) !== 46 || t.codePointAt(t.length - 2) !== 46) {
                        if (t.length > 2) {
                            if (a = t.lastIndexOf("/"), a !== t.length - 1) {
                                a < 0 ? (t = "", r = 0) : (t = t.slice(0, a), r = t.length - 1 - t.lastIndexOf("/")), i = f, s = 0;
                                continue
                            }
                        } else if (t.length > 0) {
                            t = "", r = 0, i = f, s = 0;
                            continue
                        }
                    }
                    e && (t = t.length > 0 ? t + "/.." : "..", r = 2)
                } else t.length > 0 ? t += "/" + n.slice(i + 1, f) : t = n.slice(i + 1, f), r = f - i - 1;
            i = f, s = 0
        } else c === 46 && s > -1 ? s++ : s = -1
    }
    return t
}

function w(n) {
    if (typeof n != "string") throw new TypeError("Path must be a string. Received " + JSON.stringify(n))
}
const ie = {
    cwd: re
};

function re() {
    return "/"
}

function R(n) {
    return !!(n !== null && typeof n == "object" && "href" in n && n.href && "protocol" in n && n.protocol && n.auth === void 0)
}

function se(n) {
    if (typeof n == "string") n = new URL(n);
    else if (!R(n)) {
        const e = new TypeError('The "path" argument must be of type string or an instance of URL. Received `' + n + "`");
        throw e.code = "ERR_INVALID_ARG_TYPE", e
    }
    if (n.protocol !== "file:") {
        const e = new TypeError("The URL must be of scheme file");
        throw e.code = "ERR_INVALID_URL_SCHEME", e
    }
    return oe(n)
}

function oe(n) {
    if (n.hostname !== "") {
        const r = new TypeError('File URL host must be "localhost" or empty on darwin');
        throw r.code = "ERR_INVALID_FILE_URL_HOST", r
    }
    const e = n.pathname;
    let t = -1;
    for (; ++t < e.length;)
        if (e.codePointAt(t) === 37 && e.codePointAt(t + 1) === 50) {
            const r = e.codePointAt(t + 2);
            if (r === 70 || r === 102) {
                const i = new TypeError("File URL path must not include encoded / characters");
                throw i.code = "ERR_INVALID_FILE_URL_PATH", i
            }
        }
    return decodeURIComponent(e)
}
const P = ["history", "path", "basename", "stem", "extname", "dirname"];
class fe {
    constructor(e) {
        let t;
        e ? R(e) ? t = {
            path: e
        } : typeof e == "string" || ce(e) ? t = {
            value: e
        } : t = e : t = {}, this.cwd = "cwd" in t ? "" : ie.cwd(), this.data = {}, this.history = [], this.messages = [], this.value, this.map, this.result, this.stored;
        let r = -1;
        for (; ++r < P.length;) {
            const s = P[r];
            s in t && t[s] !== void 0 && t[s] !== null && (this[s] = s === "history" ? [...t[s]] : t[s])
        }
        let i;
        for (i in t) P.includes(i) || (this[i] = t[i])
    }
    get basename() {
        return typeof this.path == "string" ? m.basename(this.path) : void 0
    }
    set basename(e) {
        T(e, "basename"), S(e, "basename"), this.path = m.join(this.dirname || "", e)
    }
    get dirname() {
        return typeof this.path == "string" ? m.dirname(this.path) : void 0
    }
    set dirname(e) {
        U(this.basename, "dirname"), this.path = m.join(e || "", this.basename)
    }
    get extname() {
        return typeof this.path == "string" ? m.extname(this.path) : void 0
    }
    set extname(e) {
        if (S(e, "extname"), U(this.dirname, "extname"), e) {
            if (e.codePointAt(0) !== 46) throw new Error("`extname` must start with `.`");
            if (e.includes(".", 1)) throw new Error("`extname` cannot contain multiple dots")
        }
        this.path = m.join(this.dirname, this.stem + (e || ""))
    }
    get path() {
        return this.history[this.history.length - 1]
    }
    set path(e) {
        R(e) && (e = se(e)), T(e, "path"), this.path !== e && this.history.push(e)
    }
    get stem() {
        return typeof this.path == "string" ? m.basename(this.path, this.extname) : void 0
    }
    set stem(e) {
        T(e, "stem"), S(e, "stem"), this.path = m.join(this.dirname || "", e + (this.extname || ""))
    }
    fail(e, t, r) {
        const i = this.message(e, t, r);
        throw i.fatal = !0, i
    }
    info(e, t, r) {
        const i = this.message(e, t, r);
        return i.fatal = void 0, i
    }
    message(e, t, r) {
        const i = new p(e, t, r);
        return this.path && (i.name = this.path + ":" + i.name, i.file = this.path), i.fatal = !1, this.messages.push(i), i
    }
    toString(e) {
        return this.value === void 0 ? "" : typeof this.value == "string" ? this.value : new TextDecoder(e || void 0).decode(this.value)
    }
}

function S(n, e) {
    if (n && n.includes(m.sep)) throw new Error("`" + e + "` cannot be a path: did not expect `" + m.sep + "`")
}

function T(n, e) {
    if (!n) throw new Error("`" + e + "` cannot be empty")
}

function U(n, e) {
    if (!n) throw new Error("Setting `" + e + "` requires `path` to be set too")
}

function ce(n) {
    return !!(n && typeof n == "object" && "byteLength" in n && "byteOffset" in n)
}
const le = (function(n) {
        const r = this.constructor.prototype,
            i = r[n],
            s = function() {
                return i.apply(s, arguments)
            };
        Object.setPrototypeOf(s, r);
        const f = Object.getOwnPropertyNames(i);
        for (const c of f) {
            const a = Object.getOwnPropertyDescriptor(i, c);
            a && Object.defineProperty(s, c, a)
        }
        return s
    }),
    ae = {}.hasOwnProperty;
class C extends le {
    constructor() {
        super("copy"), this.Compiler = void 0, this.Parser = void 0, this.attachers = [], this.compiler = void 0, this.freezeIndex = -1, this.frozen = void 0, this.namespace = {}, this.parser = void 0, this.transformers = Q()
    }
    copy() {
        const e = new C;
        let t = -1;
        for (; ++t < this.attachers.length;) {
            const r = this.attachers[t];
            e.use(...r)
        }
        return e.data(I(!0, {}, this.namespace)), e
    }
    data(e, t) {
        return typeof e == "string" ? arguments.length === 2 ? (z("data", this.frozen), this.namespace[e] = t, this) : ae.call(this.namespace, e) && this.namespace[e] || void 0 : e ? (z("data", this.frozen), this.namespace = e, this) : this.namespace
    }
    freeze() {
        if (this.frozen) return this;
        const e = this;
        for (; ++this.freezeIndex < this.attachers.length;) {
            const [t, ...r] = this.attachers[this.freezeIndex];
            if (r[0] === !1) continue;
            r[0] === !0 && (r[0] = void 0);
            const i = t.call(e, ...r);
            typeof i == "function" && this.transformers.use(i)
        }
        return this.frozen = !0, this.freezeIndex = Number.POSITIVE_INFINITY, this
    }
    parse(e) {
        this.freeze();
        const t = x(e),
            r = this.parser || this.Parser;
        return _("parse", r), r(String(t), t)
    }
    process(e, t) {
        const r = this;
        return this.freeze(), _("process", this.parser || this.Parser), j("process", this.compiler || this.Compiler), t ? i(void 0, t) : new Promise(i);

        function i(s, f) {
            const c = x(e),
                a = r.parse(c);
            r.run(a, c, function(l, u, h) {
                if (l || !u || !h) return o(l);
                const y = u,
                    g = r.stringify(y, h);
                de(g) ? h.value = g : h.result = g, o(l, h)
            });

            function o(l, u) {
                l || !u ? f(l) : s ? s(u) : t(void 0, u)
            }
        }
    }
    processSync(e) {
        let t = !1,
            r;
        return this.freeze(), _("processSync", this.parser || this.Parser), j("processSync", this.compiler || this.Compiler), this.process(e, i), q("processSync", "process", t), r;

        function i(s, f) {
            t = !0, k(s), r = f
        }
    }
    run(e, t, r) {
        B(e), this.freeze();
        const i = this.transformers;
        return !r && typeof t == "function" && (r = t, t = void 0), r ? s(void 0, r) : new Promise(s);

        function s(f, c) {
            const a = x(t);
            i.run(e, a, o);

            function o(l, u, h) {
                const y = u || e;
                l ? c(l) : f ? f(y) : r(void 0, y, h)
            }
        }
    }
    runSync(e, t) {
        let r = !1,
            i;
        return this.run(e, t, s), q("runSync", "run", r), i;

        function s(f, c) {
            k(f), i = c, r = !0
        }
    }
    stringify(e, t) {
        this.freeze();
        const r = x(t),
            i = this.compiler || this.Compiler;
        return j("stringify", i), B(e), i(e, r)
    }
    use(e, ...t) {
        const r = this.attachers,
            i = this.namespace;
        if (z("use", this.frozen), e != null)
            if (typeof e == "function") a(e, t);
            else if (typeof e == "object") Array.isArray(e) ? c(e) : f(e);
        else throw new TypeError("Expected usable value, not `" + e + "`");
        return this;

        function s(o) {
            if (typeof o == "function") a(o, []);
            else if (typeof o == "object")
                if (Array.isArray(o)) {
                    const [l, ...u] = o;
                    a(l, u)
                } else f(o);
            else throw new TypeError("Expected usable value, not `" + o + "`")
        }

        function f(o) {
            if (!("plugins" in o) && !("settings" in o)) throw new Error("Expected usable value but received an empty preset, which is probably a mistake: presets typically come with `plugins` and sometimes with `settings`, but this has neither");
            c(o.plugins), o.settings && (i.settings = I(!0, i.settings, o.settings))
        }

        function c(o) {
            let l = -1;
            if (o != null)
                if (Array.isArray(o))
                    for (; ++l < o.length;) {
                        const u = o[l];
                        s(u)
                    } else throw new TypeError("Expected a list of plugins, not `" + o + "`")
        }

        function a(o, l) {
            let u = -1,
                h = -1;
            for (; ++u < r.length;)
                if (r[u][0] === o) {
                    h = u;
                    break
                }
            if (h === -1) r.push([o, ...l]);
            else if (l.length > 0) {
                let [y, ...g] = l;
                const d = r[h][1];
                L(d) && L(y) && (y = I(!0, d, y)), r[h] = [o, y, ...g]
            }
        }
    }
}
const ue = new C().freeze();

function _(n, e) {
    if (typeof e != "function") throw new TypeError("Cannot `" + n + "` without `parser`")
}

function j(n, e) {
    if (typeof e != "function") throw new TypeError("Cannot `" + n + "` without `compiler`")
}

function z(n, e) {
    if (e) throw new Error("Cannot call `" + n + "` on a frozen processor.\nCreate a new processor first, by calling it: use `processor()` instead of `processor`.")
}

function B(n) {
    if (!L(n) || typeof n.type != "string") throw new TypeError("Expected node, got `" + n + "`")
}

function q(n, e, t) {
    if (!t) throw new Error("`" + n + "` finished async. Use `" + e + "` instead")
}

function x(n) {
    return he(n) ? n : new fe(n)
}

function he(n) {
    return !!(n && typeof n == "object" && "message" in n && "messages" in n)
}

function de(n) {
    return typeof n == "string" || pe(n)
}

function pe(n) {
    return !!(n && typeof n == "object" && "byteLength" in n && "byteOffset" in n)
}
const we = Object.freeze(Object.defineProperty({
    __proto__: null,
    unified: ue
}, Symbol.toStringTag, {
    value: "Module"
}));
export {
    p as V, fe as a, we as i, ue as u
};
//# sourceMappingURL=jed1ux7qibe55pmj.js.map