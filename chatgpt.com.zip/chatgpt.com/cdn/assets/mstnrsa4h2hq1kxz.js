const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/bjf2euslr2rcym6s.js", "assets/fg33krlcm0qyi6yw.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/bjw1bhiym4zdbb7x.js", "assets/k15yxxoybkkir2ou.js", "assets/conversation-small-332fs9rk.css", "assets/o7ro57s5jd1zyhex.js", "assets/k2oaaf8ac9lafsub.js", "assets/lans8a2ikbh9ax9r.js", "assets/k78yzov06lrhyte9.js", "assets/l13qvsuc1mktoblg.js", "assets/jlu292yvnhcpthaw.js", "assets/f78b2oufkmgyeo1t.js", "assets/ew68kf01y1h7e4uk.js", "assets/ib78f9d5brp6znzf.js", "assets/ou2xm3xmri21t4zm.js", "assets/gtvj6yadewsafzfs.js", "assets/mm7oppm8z1zdg3f3.js", "assets/7v5348ti11nhyc2o.js", "assets/kkqntspc4urhepir.js", "assets/bmppzp3y84hr7irx.js"]))) => i.map(i => d[i]);
var qe = Object.defineProperty;
var Ae = Object.getOwnPropertySymbols;
var Ye = Object.prototype.hasOwnProperty,
    Ze = Object.prototype.propertyIsEnumerable;
var Re = (o, e, s) => e in o ? qe(o, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : o[e] = s,
    pe = (o, e) => {
        for (var s in e || (e = {})) Ye.call(e, s) && Re(o, s, e[s]);
        if (Ae)
            for (var s of Ae(e)) Ze.call(e, s) && Re(o, s, e[s]);
        return o
    };
import {
    e as es,
    m as ss,
    f as ts,
    j as t,
    L as We,
    c as G,
    r as I,
    _ as as,
    a1 as os,
    l as ns,
    M as rs
} from "./fg33krlcm0qyi6yw.js";
import {
    hX as we,
    ba as je,
    k as Ee,
    he as is,
    d as U,
    uG as ls,
    uH as cs,
    fI as ds,
    hf as hs,
    b as X,
    l as M,
    T as Fe,
    dg as us,
    e$ as Le,
    c_ as Se,
    da as ze,
    fP as Be,
    b9 as ms,
    gy as fs,
    mx as gs,
    o as xs,
    hj as ps,
    fN as De,
    eo as Ne,
    dF as Ue,
    bh as bs,
    hG as vs,
    I as ws,
    H as js,
    du as Ss,
    uI as Ns,
    aP as Ts,
    kI as Ps,
    eX as Cs,
    d6 as ys,
    V as Me,
    aa as Hs,
    nu as _s,
    ej as Is,
    iF as ks,
    oZ as As
} from "./dykg4ktvbu3mhmdo.js";
import {
    mI as Rs,
    bV as Ms,
    mJ as Os,
    ag as Ge,
    ic as Ws,
    u as Es,
    mK as Fs,
    bv as Ls,
    mL as zs,
    mM as Bs,
    mN as Ds,
    jt as Us,
    mO as be,
    mP as Gs,
    mQ as $s,
    mR as Oe,
    i4 as Qs,
    mS as Vs,
    mT as Xs,
    a0 as Js,
    a6 as Ks,
    bB as qs,
    mU as Ys,
    mV as Zs,
    a9 as et,
    aa as st,
    kB as tt
} from "./k15yxxoybkkir2ou.js";
import {
    C as at
} from "./l13qvsuc1mktoblg.js";
import {
    S as ot
} from "./o67bv4dtwt5l98l7.js";
import {
    S as nt
} from "./f78b2oufkmgyeo1t.js";

function $e({
    projectResource: o
}) {
    var w;
    const e = es(),
        s = X(),
        f = (w = o.gizmo) == null ? void 0 : w.id,
        r = we(s, f),
        n = je(Ee),
        v = ss(),
        x = (() => {
            const S = v.pathname.replace(/\/+$/, "");
            return /^\/g\/[^/]+\/project$/.test(S)
        })(),
        c = is(o),
        m = o.gizmo.display.name,
        d = U(() => ls(s, o)),
        p = U(() => cs(s, o));
    if (!(r && !n && !x) || o.gizmo.gizmo_type !== ds.PROJECT) return null;
    const i = m ? e.formatMessage(ve.openProjectHome, {
            projectName: m
        }) : e.formatMessage(ve.openProjectHomeFallback),
        b = hs(s, o);
    let a = t.jsx(Ms, {
            color: d,
            emoji: p,
            strict: !0,
            isSharedProject: c
        }),
        l = i;
    const u = t.jsx(We, {
            to: b,
            "aria-label": l,
            className: M("hover:bg-token-bg-tertiary focus-visible:outline-token-outline-primary text-token-text-secondary ms-2 inline-flex items-center justify-center rounded-lg focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2", "h-9 w-9"),
            children: a
        }),
        g = m != null ? m : e.formatMessage(ve.projectNameFallback);
    return t.jsxs("div", {
        className: "flex items-center",
        children: [t.jsx(Fe, {
            label: g,
            children: u
        }), t.jsx(Rs, {
            className: "icon-sm text-token-text-tertiary",
            "aria-hidden": "true"
        })]
    })
}
const ve = ts({
    openProjectHome: {
        id: "threadHeader.openProjectHome",
        defaultMessage: "Open {projectName} project"
    },
    openProjectHomeFallback: {
        id: "threadHeader.openProjectHomeFallback",
        defaultMessage: "Open project home"
    },
    projectNameFallback: {
        id: "threadHeader.projectNameFallback",
        defaultMessage: "Project"
    }
});

function rt(o) {
    "use forget";
    const e = G.c(16),
        {
            className: s,
            threadHeaderDropdown: f,
            conversationActions: r,
            superWidgetTabs: n,
            projectResource: v
        } = o,
        x = X(),
        c = us(),
        m = Le(x);
    let d;
    e[0] !== x || e[1] !== c ? (d = c && !Se(), e[0] = x, e[1] = c, e[2] = d) : d = e[2];
    const p = !d;
    let h;
    e[3] !== n ? (h = n != null ? n : t.jsx(Os, {
        textClassName: "text-sm"
    }), e[3] = n, e[4] = h) : h = e[4];
    const i = h;
    if (m) {
        const l = p && f;
        let u;
        return e[5] !== s || e[6] !== r || e[7] !== v || e[8] !== l || e[9] !== i ? (u = t.jsx(it, {
            className: s,
            conversationActions: r,
            threadHeaderDropdown: l,
            superWidgetTabs: i,
            projectResource: v
        }), e[5] = s, e[6] = r, e[7] = v, e[8] = l, e[9] = i, e[10] = u) : u = e[10], u
    }
    const b = p && f;
    let a;
    return e[11] !== s || e[12] !== r || e[13] !== b || e[14] !== i ? (a = t.jsx(lt, {
        className: s,
        conversationActions: r,
        threadHeaderDropdown: b,
        superWidgetTabs: i
    }), e[11] = s, e[12] = r, e[13] = b, e[14] = i, e[15] = a) : a = e[15], a
}

function it(o) {
    "use forget";
    const e = G.c(22),
        {
            className: s,
            conversationActions: f,
            threadHeaderDropdown: r,
            superWidgetTabs: n,
            projectResource: v
        } = o,
        x = I.useRef(null),
        c = I.useRef(null),
        m = I.useRef(null),
        d = I.useRef(null);
    let p, h;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (p = () => {
        const C = x.current,
            H = c.current,
            P = m.current,
            O = d.current;
        if (!C || !H || !P || !O) return;
        const y = () => {
                const _ = C.getBoundingClientRect().width,
                    W = P.getBoundingClientRect().width,
                    $ = H.getBoundingClientRect(),
                    k = .5 * (_ - W),
                    Q = $.right > k;
                P.style.justifySelf = Q ? "start" : "center"
            },
            j = new ResizeObserver(y);
        return j.observe(C, {
            box: "border-box"
        }), j.observe(H, {
            box: "border-box"
        }), j.observe(P, {
            box: "border-box"
        }), y(), () => {
            j.disconnect()
        }
    }, h = [], e[0] = p, e[1] = h) : (p = e[0], h = e[1]), ze(p, h);
    let i;
    e[2] !== s ? (i = M("h-header-height w-full px-2 sm:grid sm:grid-cols-[minmax(max-content,1fr)_auto_minmax(0,1fr)] sm:px-0", s), e[2] = s, e[3] = i) : i = e[3];
    let b;
    e[4] !== v ? (b = v ? t.jsx($e, {
        projectResource: v
    }) : null, e[4] = v, e[5] = b) : b = e[5];
    let a;
    e[6] !== r ? (a = t.jsx("div", {
        ref: c,
        children: r
    }), e[6] = r, e[7] = a) : a = e[7];
    let l;
    e[8] !== b || e[9] !== a ? (l = t.jsxs("div", {
        className: "z-10 col-start-1 row-start-1 hidden items-center self-center justify-self-start md:flex",
        children: [b, a]
    }), e[8] = b, e[9] = a, e[10] = l) : l = e[10];
    let u, g;
    e[11] === Symbol.for("react.memo_cache_sentinel") ? (u = t.jsx(Ge, {
        className: "col-span-3 col-start-1 row-start-1 w-full",
        children: t.jsx("div", {
            className: "w-full",
            ref: d
        })
    }), g = M("no-scrollbar col-start-2 row-start-1 -mb-px h-full w-full min-w-0 overflow-x-auto overflow-y-hidden"), e[11] = u, e[12] = g) : (u = e[11], g = e[12]);
    let w;
    e[13] !== n ? (w = t.jsx("div", {
        className: g,
        ref: m,
        children: n
    }), e[13] = n, e[14] = w) : w = e[14];
    let S;
    e[15] !== f ? (S = t.jsx("div", {
        className: "col-start-3 row-start-1 hidden items-center justify-self-end overflow-visible md:flex",
        children: f
    }), e[15] = f, e[16] = S) : S = e[16];
    let T;
    return e[17] !== S || e[18] !== i || e[19] !== l || e[20] !== w ? (T = t.jsxs("div", {
        className: i,
        ref: x,
        children: [l, u, w, S]
    }), e[17] = S, e[18] = i, e[19] = l, e[20] = w, e[21] = T) : T = e[21], T
}

function lt(o) {
    "use forget";
    const e = G.c(17),
        {
            className: s,
            conversationActions: f,
            threadHeaderDropdown: r,
            superWidgetTabs: n
        } = o,
        v = I.useRef(null),
        x = I.useRef(null),
        c = I.useRef(null),
        m = I.useRef(null);
    let d, p;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (d = () => {
        const w = v.current,
            S = x.current,
            T = c.current,
            C = m.current;
        if (!w || !S || !T || !C) return;
        const H = () => {
                const O = w.getBoundingClientRect().width,
                    y = T.getBoundingClientRect().width,
                    j = S.getBoundingClientRect(),
                    _ = .5 * (O - y),
                    W = j.right > _;
                T.style.justifySelf = W ? "start" : "center"
            },
            P = new ResizeObserver(H);
        return P.observe(w, {
            box: "border-box"
        }), P.observe(S, {
            box: "border-box"
        }), P.observe(T, {
            box: "border-box"
        }), H(), () => {
            P.disconnect()
        }
    }, p = [], e[0] = d, e[1] = p) : (d = e[0], p = e[1]), ze(d, p);
    let h;
    e[2] !== s ? (h = M("h-header-height w-full px-2 sm:grid sm:grid-cols-[minmax(max-content,1fr)_auto_minmax(0,1fr)] sm:px-0", s), e[2] = s, e[3] = h) : h = e[3];
    let i;
    e[4] !== r ? (i = t.jsx("div", {
        className: "z-10 col-start-1 row-start-1 hidden self-center justify-self-start pe-2 md:flex",
        ref: x,
        children: r
    }), e[4] = r, e[5] = i) : i = e[5];
    let b, a;
    e[6] === Symbol.for("react.memo_cache_sentinel") ? (b = t.jsx(Ge, {
        className: "col-span-3 col-start-1 row-start-1 w-full",
        children: t.jsx("div", {
            className: "w-full",
            ref: m
        })
    }), a = M("no-scrollbar col-start-2 row-start-1 -mb-px h-full w-full min-w-0 overflow-x-auto overflow-y-hidden"), e[6] = b, e[7] = a) : (b = e[6], a = e[7]);
    let l;
    e[8] !== n ? (l = t.jsx("div", {
        className: a,
        ref: c,
        children: n
    }), e[8] = n, e[9] = l) : l = e[9];
    let u;
    e[10] !== f ? (u = t.jsx("div", {
        className: "col-start-3 row-start-1 hidden items-center justify-self-end overflow-visible md:flex",
        children: f
    }), e[10] = f, e[11] = u) : u = e[11];
    let g;
    return e[12] !== h || e[13] !== i || e[14] !== l || e[15] !== u ? (g = t.jsxs("div", {
        className: h,
        ref: v,
        children: [i, b, l, u]
    }), e[12] = h, e[13] = i, e[14] = l, e[15] = u, e[16] = g) : g = e[16], g
}
const ct = ({
        clientThreadId: o
    }) => {
        var l;
        const e = X(),
            s = Be(u => u.activeStageSidebar),
            f = Ws(ms.WorkspaceShareLinks),
            r = !Se(),
            n = fs(),
            v = gs(o),
            x = we(e, v),
            c = xs(e, "16480203"),
            m = Es(),
            d = ps(),
            p = !!((l = De(o, u => Ue.mostRecentEcosystemMessage(u, "cocoon"))) != null && l.id),
            h = je(Ne),
            i = f && !r && !n && (!x || c) && !m && !p && !d && !h,
            b = !s,
            a = h;
        return t.jsx("div", {
            className: "flex items-center",
            id: "conversation-header-actions",
            children: t.jsx(at, {
                showShareButton: i,
                showProfileDropdown: b,
                showConversationPrivacyIndicator: a,
                clientThreadId: o
            })
        })
    },
    dt = bs(() => as(() =>
        import ("./bjf2euslr2rcym6s.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21])).then(o => o.GizmoUsingAsOwnerNotice)),
    ht = "text-lg",
    ut = "icon-sm";

function yt(o) {
    "use forget";
    var ye, He, _e, Ie, ke;
    const e = G.c(83),
        {
            conversation: s,
            className: f
        } = o,
        r = os(),
        n = X(),
        v = Fs(n);
    let x;
    e[0] !== s ? (x = () => Is(s), e[0] = s, e[1] = x) : x = e[1];
    const c = U(x);
    let m;
    e[2] !== n || e[3] !== c ? (m = we(n, c), e[2] = n, e[3] = c, e[4] = m) : m = e[4];
    const d = m,
        p = ns();
    let h;
    e[5] !== p ? (h = Ls(p, "images-app"), e[5] = p, e[6] = h) : h = e[6];
    const i = h,
        b = zs() && !i,
        {
            data: a
        } = vs(c),
        l = ws(n),
        u = l == null ? void 0 : l.getWorkspaceId(),
        g = js(),
        {
            data: w
        } = Ss(u),
        S = (ye = g == null ? void 0 : g.data.profilePictureUrl) != null ? ye : null,
        T = (He = g == null ? void 0 : g.data.name) != null ? He : void 0;
    let C;
    e[7] !== g || e[8] !== S || e[9] !== (w == null ? void 0 : w.beta_settings) ? (C = (g == null ? void 0 : g.isWorkspaceAccount()) && S && ((_e = w == null ? void 0 : w.beta_settings) == null ? void 0 : _e[Ns.SHOW_LOGO_IN_HEADER]), e[7] = g, e[8] = S, e[9] = w == null ? void 0 : w.beta_settings, e[10] = C) : C = e[10];
    const H = !!C,
        P = Ts(),
        O = Ps(),
        [y, j] = je(ft);
    let _;
    e[11] !== s.id ? (_ = Cs(s.id), e[11] = s.id, e[12] = _) : _ = e[12];
    const W = _,
        $ = Be(mt),
        k = De(s.id, Ue.hasUserMessage) || !W,
        Q = ys(),
        Te = Q && O;
    let J;
    e[13] !== n || e[14] !== a ? (J = ks(), e[13] = n, e[14] = a, e[15] = J) : J = e[15];
    const Qe = J,
        N = Bs() && k && !Q && !Qe,
        Pe = !c && !N && !j;
    let K;
    e[16] !== s.id ? (K = {
        clientThreadId: s.id,
        fromHeader: !0
    }, e[16] = s.id, e[17] = K) : K = e[17];
    const {
        shouldShow: Ve,
        handleClose: q
    } = Ds(K), V = Ve && !Te;
    let Y;
    e[18] !== n ? (Y = Se(), e[18] = n, e[19] = Y) : Y = e[19];
    const A = !Y;
    let Ce = !1;
    !k && !j && !N && A && O && Pe && Me(n, "2118136551").get("header_navigation_enabled", !1) && r != null && r.headerNavData && (Ce = !0);
    let E;
    e[20] !== s.id ? (E = t.jsx(ct, {
        clientThreadId: s.id
    }), e[20] = s.id, e[21] = E) : E = e[21];
    let Z;
    e[22] !== s.id || e[23] !== E ? (Z = t.jsx(Us, {
        clientThreadId: s.id,
        children: E
    }), e[22] = s.id, e[23] = E, e[24] = Z) : Z = e[24];
    const F = Z;
    let ee;
    e[25] !== y || e[26] !== N ? (ee = y && !N ? {
        textClassName: ht,
        chevronClassName: ut
    } : {}, e[25] = y, e[26] = N, e[27] = ee) : ee = e[27];
    const se = ee;
    let te;
    e[28] !== s || e[29] !== F || e[30] !== se || e[31] !== c || e[32] !== a || e[33] !== j || e[34] !== P || e[35] !== d || e[36] !== N ? (te = N ? t.jsx(rt, {
        projectResource: a != null ? a : void 0,
        threadHeaderDropdown: t.jsx(be, pe({
            conversation: s
        }, se)),
        conversationActions: F
    }) : j ? t.jsx(Gs, {
        clientThreadId: s.id
    }) : P && (d || !c) ? t.jsx($s, {
        conversation: s,
        children: t.jsx(be, {
            conversation: s
        })
    }) : t.jsx(be, pe({
        conversation: s
    }, se)), e[28] = s, e[29] = F, e[30] = se, e[31] = c, e[32] = a, e[33] = j, e[34] = P, e[35] = d, e[36] = N, e[37] = te) : te = e[37];
    const ae = te;
    let oe;
    e: {
        if (y) {
            oe = $ ? "[box-shadow:var(--sharp-edge-top-shadow)]" : "[box-shadow:var(--sharp-edge-top-shadow-placeholder)]";
            break e
        }
        if (!v) {
            oe = $ ? "[box-shadow:var(--sharp-edge-top-shadow)]" : "[box-shadow:var(--sharp-edge-top-shadow-placeholder)]";
            break e
        }
        oe = "[box-shadow:var(--sharp-edge-top-shadow-placeholder)] group-data-scroll-from-top/thread:[box-shadow:var(--sharp-edge-top-shadow)]"
    }
    const de = oe;
    let ne;
    e[38] !== s ? (ne = () => qs(s).hasPinnedWidget$(), e[38] = s, e[39] = ne) : ne = e[39];
    const Xe = U(ne);
    let re;
    e[40] !== s ? (re = () => Ys(s), e[40] = s, e[41] = re) : re = e[41];
    const Je = U(re),
        R = Pe && !Q && !Xe;
    let ie;
    e[42] !== n || e[43] !== k || e[44] !== A || e[45] !== R ? (ie = R && !A && k && Me(n, "2874358162").get("open_personalization_button_enabled", !1), e[42] = n, e[43] = k, e[44] = A, e[45] = R, e[46] = ie) : ie = e[46];
    const he = R && ie;
    let le;
    e[47] !== n || e[48] !== a || e[49] !== N ? (le = !!a && !(Le(n) && N), e[47] = n, e[48] = a, e[49] = N, e[50] = le) : le = e[50];
    const ue = le;
    if (Je) return null;
    const me = xt,
        Ke = "page-header",
        fe = d && W,
        ge = $ && V,
        xe = !j && !N && !i && t.jsxs("div", {
            className: "pointer-events-none absolute start-0 flex flex-col items-center gap-2 lg:start-1/2 ltr:-translate-x-1/2 rtl:translate-x-1/2",
            children: [a == null && H && S && t.jsx(Hs, {
                src: S,
                alt: T != null ? T : ""
            }), a != null && (l == null ? void 0 : l.isWorkspaceAccount()) && ((Ie = a.gizmo.tags) == null ? void 0 : Ie.includes(_s.WorkspaceDisabled)) && t.jsx(dt, {
                gizmo: a
            }), V && t.jsx("div", {
                className: "hidden lg:block",
                children: t.jsx(Oe, {
                    onClose: q,
                    clientThreadId: s.id
                })
            }), Te && t.jsx(ot, {}), Ce && t.jsx(Qs, {
                effectiveLocale: (ke = r == null ? void 0 : r.locale) != null ? ke : Vs,
                slug: "/",
                children: t.jsx(Xs, {
                    navData: r.headerNavData
                })
            })]
        });
    let L;
    e[51] !== ae || e[52] !== s.id || e[53] !== a || e[54] !== q || e[55] !== j || e[56] !== A || e[57] !== N || e[58] !== V || e[59] !== ue ? (L = j ? ae : t.jsxs("div", {
        className: "pointer-events-none! flex flex-1 items-center *:pointer-events-auto",
        children: [A ? t.jsx(gt, {}) : t.jsx(nt, {}), ue && t.jsx($e, {
            projectResource: a
        }), ae, !N && t.jsx("div", {
            className: "block lg:hidden",
            children: V && t.jsx(Oe, {
                onClose: q,
                clientThreadId: s.id
            })
        })]
    }), e[51] = ae, e[52] = s.id, e[53] = a, e[54] = q, e[55] = j, e[56] = A, e[57] = N, e[58] = V, e[59] = ue, e[60] = L) : L = e[60];
    let z;
    e[61] !== s.id || e[62] !== F || e[63] !== c || e[64] !== j || e[65] !== N ? (z = !N && !j && t.jsxs("div", {
        className: "flex items-center justify-center gap-3 overflow-x-hidden",
        children: [t.jsx("div", {
            className: "shrink-0",
            children: t.jsx(Js, {
                gizmoId: c,
                clientThreadId: s.id
            })
        }), t.jsx("div", {
            className: "flex items-center justify-end gap-2 overflow-x-hidden",
            children: F
        })]
    }), e[61] = s.id, e[62] = F, e[63] = c, e[64] = j, e[65] = N, e[66] = z) : z = e[66];
    let B;
    e[67] !== me || e[68] !== f || e[69] !== de || e[70] !== R || e[71] !== fe || e[72] !== ge || e[73] !== xe || e[74] !== L || e[75] !== z || e[76] !== he ? (B = t.jsxs(me, {
        id: Ke,
        shouldStickSnorlaxNewThread: fe,
        shouldUseTransparentDefaultHeaderBackground: R,
        shouldShowUpgradeStyles: ge,
        edgeShadowClass: de,
        useW2xlTransparentBackground: he,
        className: f,
        children: [xe, L, z]
    }), e[67] = me, e[68] = f, e[69] = de, e[70] = R, e[71] = fe, e[72] = ge, e[73] = xe, e[74] = L, e[75] = z, e[76] = he, e[77] = B) : B = e[77];
    let D;
    e[78] !== b ? (D = b && t.jsx(Zs, {}), e[78] = b, e[79] = D) : D = e[79];
    let ce;
    return e[80] !== B || e[81] !== D ? (ce = t.jsxs(t.Fragment, {
        children: [B, D]
    }), e[80] = B, e[81] = D, e[82] = ce) : ce = e[82], ce
}

function mt(o) {
    return o.isConversationScrolledFromTop
}

function ft(o) {
    return [Ne(o), Ee(o)]
}
const gt = o => {
    "use forget";
    const e = G.c(13),
        {
            className: s
        } = o,
        f = X();
    let r;
    e[0] !== f ? (r = () => Ne(f), e[0] = f, e[1] = r) : r = e[1];
    const n = U(r),
        v = Ks();
    let x;
    e[2] === Symbol.for("react.memo_cache_sentinel") ? (x = t.jsx(rs, {
        id: "mG13YW",
        defaultMessage: "New chat"
    }), e[2] = x) : x = e[2];
    const c = n && "self-center";
    let m;
    e[3] !== s || e[4] !== c ? (m = M("hover:bg-token-bg-tertiary group touch:h-10 flex aspect-square h-9 items-center justify-center rounded-[10px]", c, s), e[3] = s, e[4] = c, e[5] = m) : m = e[5];
    let d;
    e[6] !== f ? (d = i => {
        et(f, i, {
            location: "Anon desktop header"
        })
    }, e[6] = f, e[7] = d) : d = e[7];
    let p;
    e[8] === Symbol.for("react.memo_cache_sentinel") ? (p = t.jsxs("div", {
        children: [t.jsx(As, {
            className: "icon-lg cant-hover:hidden -m-1 group-hover:hidden"
        }), t.jsx(st, {
            className: "icon can-hover:not-group-hover:hidden"
        })]
    }), e[8] = p) : p = e[8];
    let h;
    return e[9] !== v || e[10] !== m || e[11] !== d ? (h = t.jsx(Fe, {
        label: x,
        contentClassName: "cant-hover:hidden",
        triggerAs: null,
        children: t.jsx(We, {
            to: "/",
            state: v,
            className: m,
            onClick: d,
            children: p
        })
    }), e[9] = v, e[10] = m, e[11] = d, e[12] = h) : h = e[12], h
};

function xt(o) {
    "use forget";
    const e = G.c(11),
        {
            children: s,
            id: f,
            shouldStickSnorlaxNewThread: r,
            shouldUseTransparentDefaultHeaderBackground: n,
            shouldShowUpgradeStyles: v,
            edgeShadowClass: x,
            shouldDisableTransition: c,
            useW2xlTransparentBackground: m,
            className: d
        } = o,
        p = c === void 0 ? !1 : c,
        h = m === void 0 ? !1 : m,
        i = p ? "transition-none motion-safe:transition-none" : "motion-safe:transition",
        b = r && "sharp-edge-on-scroll-start sticky top-0",
        a = n && (h ? "@w-2xl/main:bg-transparent @w-2xl/main:shadow-none!" : "@w-xl/main:bg-transparent @w-xl/main:shadow-none!"),
        l = v && "@w-xl/main:bg-token-main-surface-primary @w-xl/main:[box-shadow:var(--sharp-edge-top-shadow)]!";
    let u;
    e[0] !== d || e[1] !== x || e[2] !== i || e[3] !== b || e[4] !== a || e[5] !== l ? (u = M("pointer-events-none select-none [view-transition-name:var(--vt-page-header)] *:pointer-events-auto", i, b, a, x, l, d), e[0] = d, e[1] = x, e[2] = i, e[3] = b, e[4] = a, e[5] = l, e[6] = u) : u = e[6];
    let g;
    return e[7] !== s || e[8] !== f || e[9] !== u ? (g = t.jsx(tt, {
        id: f,
        className: u,
        children: s
    }), e[7] = s, e[8] = f, e[9] = u, e[10] = g) : g = e[10], g
}
export {
    ct as C, gt as L, xt as P, yt as T
};
//# sourceMappingURL=mstnrsa4h2hq1kxz.js.map