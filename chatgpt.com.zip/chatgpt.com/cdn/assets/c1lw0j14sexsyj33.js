import {
    r as f,
    v as y,
    e as x,
    j as t,
    f as M
} from "./fg33krlcm0qyi6yw.js";
import {
    oH as b,
    fD as j,
    e4 as v,
    e2 as C,
    g2 as u,
    a9 as S
} from "./dykg4ktvbu3mhmdo.js";
import {
    hO as E,
    hR as T,
    gX as h,
    fy as _
} from "./k15yxxoybkkir2ou.js";
const w = (e, s, o, r) => {
    const a = E(e),
        c = T(e),
        n = b();
    return f.useCallback((l, m) => {
        if (n) return;
        const d = '\n        The user would like you to focus on a file from an earlier search result as you respond to their prompt: "'.concat(o.replaceAll('"', ""), '". The file\'s ID is "').concat(s.replaceAll('"', ""), "\".\n        When you respond, try to acknowledge that you're focusing on the file if it's not clear from the context. For example, if you mclick the file, you could mention that you've looked at the file.\n        "),
            i = A(d, {
                exclude_after_next_user_message: !0
            });
        c({
            sourceEvent: l,
            promptMessage: j(m, {
                retrieval_hint_file_data: {
                    id: s,
                    name: o,
                    url: r
                }
            }),
            completionMetadata: a ? {
                conversationMode: a
            } : void 0,
            appendMessages: [i]
        })
    }, [n, o, s, c, a, r])
};

function A(e, s) {
    return {
        id: y(),
        author: {
            role: C.System
        },
        content: {
            content_type: v.Text,
            parts: Array.isArray(e) ? e : [e]
        },
        metadata: s
    }
}

function G({
    className: e,
    clientThreadId: s,
    fileCloudDocUrl: o,
    fileId: r,
    fileName: a,
    isFollowupMenuOpen: c,
    setIsFollowupMenuOpen: n,
    trackFileSourceFollowup: l
}) {
    const m = x(),
        d = w(s, r, a, o),
        p = f.useCallback((i, g) => {
            g.length && (d(i, g), n(!1), l == null || l())
        }, [d, n, l]);
    return t.jsxs(u.Root, {
        open: c,
        onOpenChange: n,
        children: [t.jsx(u.Trigger, {
            className: e,
            children: t.jsx(h, {
                className: "icon"
            })
        }), t.jsx(u.Portal, {
            children: t.jsxs(u.Content, {
                size: "medium",
                children: [Object.values(k).map(i => t.jsx(R, {
                    sendReply: p,
                    suggestedText: m.formatMessage(i)
                }, i.defaultMessage)), t.jsx("div", {
                    className: "mx-2 flex cursor-pointer flex-row items-center gap-2 p-2.5 px-3 py-2.5 text-sm",
                    children: t.jsx(D, {
                        sendReply: p
                    })
                })]
            })
        })]
    })
}

function R({
    suggestedText: e,
    sendReply: s
}) {
    return t.jsx(u.Item, {
        icon: h,
        onSelect: o => s(o, e),
        textValue: "",
        children: e
    })
}
const k = M({
    fileFollowupSuggestionTellMeMore: {
        id: "skmNc0",
        defaultMessage: "Tell me more about this."
    },
    fileFollowupSuggestionSummarize: {
        id: "BiNEEG",
        defaultMessage: "Summarize this."
    }
});

function D({
    sendReply: e
}) {
    const s = x(),
        [o, r] = f.useState("");
    return t.jsxs("form", {
        onSubmit: a => {
            a.preventDefault(), e(a, o), r("")
        },
        className: "border-token-border-default flex flex-1 items-center gap-2 rounded-full border border-solid px-4 py-2 pe-2",
        children: [t.jsx("input", {
            type: "text",
            onChange: a => r(a.target.value),
            className: "text-token-text-primary w-full flex-1 border-none bg-transparent p-0 text-sm font-normal ring-0 focus:border-none focus:shadow-none focus:ring-0",
            placeholder: s.formatMessage({
                id: "tJa6v0",
                defaultMessage: "Ask about this…"
            }),
            value: o
        }), t.jsx(S, {
            className: "flex-0",
            disabled: !o,
            icon: _,
            color: "primary",
            size: "small",
            type: "submit"
        })]
    })
}
export {
    G as F, D as a, w as u
};
//# sourceMappingURL=c1lw0j14sexsyj33.js.map