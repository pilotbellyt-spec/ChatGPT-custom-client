var L = Object.defineProperty,
    E = Object.defineProperties;
var T = Object.getOwnPropertyDescriptors;
var v = Object.getOwnPropertySymbols;
var N = Object.prototype.hasOwnProperty,
    w = Object.prototype.propertyIsEnumerable;
var b = (t, e, a) => e in t ? L(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: a
    }) : t[e] = a,
    p = (t, e) => {
        for (var a in e || (e = {})) N.call(e, a) && b(t, a, e[a]);
        if (v)
            for (var a of v(e)) w.call(e, a) && b(t, a, e[a]);
        return t
    },
    g = (t, e) => E(t, T(e));
var k = (t, e) => {
    var a = {};
    for (var r in t) N.call(t, r) && e.indexOf(r) < 0 && (a[r] = t[r]);
    if (t != null && v)
        for (var r of v(t)) e.indexOf(r) < 0 && w.call(t, r) && (a[r] = t[r]);
    return a
};
import {
    j as s,
    M as f,
    b as q,
    i as O,
    r as F
} from "./fg33krlcm0qyi6yw.js";
import {
    R as x,
    A as m,
    _ as I,
    tb as R,
    P as _,
    iU as y,
    a9 as j,
    py as H,
    e1 as W,
    l as U,
    nW as z,
    b3 as G,
    tc as S
} from "./dykg4ktvbu3mhmdo.js";
import {
    ej as B,
    eU as $,
    fx as Q
} from "./k15yxxoybkkir2ou.js";
import {
    S as A
} from "./nzl91iujqafxz8y1.js";
import {
    M as K
} from "./ebc4iyfg14nu1gw4.js";
import {
    r as X
} from "./b5s349mvbdzayaxi.js";
const le = async t => await x.safePost("/shopping/customer", {
        requestBody: {
            items: t.map(e => ({
                id: e.id,
                value: e.value,
                quantity: e.quantity
            }))
        },
        authOption: m.SendIfAvailable
    }),
    ce = async c => {
        var n = c,
            {
                conversationId: t,
                sharedConversationUrl: e,
                existing_customer_session_client_secret: a
            } = n,
            r = k(n, ["conversationId", "sharedConversationUrl", "existing_customer_session_client_secret"]);
        const l = async () => await x.safePost("/shopping/checkout", {
            requestBody: {
                items: r.items.map(d => ({
                    id: d.id,
                    value: d.value,
                    quantity: d.quantity
                })),
                conversation_id: t,
                shared_conversation_url: e,
                existing_customer_session_client_secret: a
            },
            authOption: m.SendIfAvailable
        });
        try {
            return await l()
        } catch (d) {
            return await l()
        }
    },
    de = async (t, {
        shippingMethodId: e,
        shippingAddress: a,
        items: r
    }) => {
        var d, h, i;
        const c = performance.now(),
            n = {
                items: r.map(o => ({
                    id: o.id,
                    value: o.value,
                    quantity: o.quantity
                }))
            };
        e != null && (n.shipping_option_id = e), a != null && (n.shipping_address = {
            name: (d = a.name) != null ? d : void 0,
            line_one: (h = a.addressLine1) != null ? h : void 0,
            line_two: a.addressLine2,
            city: a.city,
            state: a.state,
            postal_code: a.postalCode,
            country: a.country,
            phone_number: (i = a.phoneNumber) != null ? i : void 0
        }), n.items = r.map(o => ({
            id: o.id,
            value: o.value,
            quantity: o.quantity
        }));
        const l = await x.safePatch("/shopping/checkout/{checkout_session_id}/update", {
            parameters: {
                path: {
                    checkout_session_id: t
                }
            },
            requestBody: n,
            authOption: m.SendIfAvailable
        });
        return I.addAction("shopping_checkout.update", {
            durationMs: performance.now() - c
        }), l
    },
    xe = async (t, e, a, r, c) => await x.safePost("/shopping/checkout/{checkout_session_id}/complete", {
        parameters: {
            path: {
                checkout_session_id: t
            }
        },
        requestBody: {
            items: e.map(n => ({
                id: n.id,
                value: n.value,
                quantity: n.quantity
            })),
            payment_method: a,
            attempt_id: r,
            shipping_address: c
        },
        authOption: m.SendIfAvailable
    }),
    J = async () => (await x.safeGet("/shopping/orders", {
        authOption: m.SendIfAvailable
    })).orders,
    V = async t => await x.safeGet("/shopping/order/{order_id}", {
        parameters: {
            path: {
                order_id: t
            }
        },
        authOption: m.SendIfAvailable
    }),
    C = 1e3 * 5 * 60;

function me() {
    const t = ee();
    return t ? s.jsx(D, {
        orderId: t
    }) : s.jsx(R, {
        title: s.jsx(f, {
            id: "xdSD9Q",
            defaultMessage: "Orders"
        }),
        children: s.jsx(Y, {})
    })
}
const P = () => s.jsxs("div", {
    className: "flex w-full gap-3 py-2",
    children: [s.jsx("div", {
        className: "bg-token-bg-tertiary h-20 w-20 rounded-xl"
    }), s.jsxs("div", {
        className: "flex flex-1 flex-col items-start justify-start gap-1",
        children: [s.jsx(S, {
            index: 0,
            width: 50,
            heightSize: "sm"
        }), s.jsx(S, {
            index: 0,
            width: 70,
            heightSize: "sm"
        })]
    })]
});

function Y() {
    const t = O(),
        {
            data: e,
            isLoading: a,
            isError: r,
            error: c
        } = q({
            queryKey: ["orders"],
            queryFn: J,
            staleTime: C,
            refetchOnMount: "always",
            refetchOnWindowFocus: "always"
        });
    return a ? s.jsx(P, {}) : r ? s.jsxs("div", {
        className: "flex min-h-[400px] w-full flex-col items-center justify-center py-6 text-sm",
        children: [s.jsx(z, {
            className: "icon-xl"
        }), s.jsx("div", {
            className: "text-base font-medium",
            children: s.jsx(f, {
                id: "/GqhEc",
                defaultMessage: "Error loading orders"
            })
        }), !1]
    }) : e && (e != null && e.length) ? s.jsx("div", {
        className: "flex flex-col",
        children: e == null ? void 0 : e.map((n, l) => s.jsxs(s.Fragment, {
            children: [s.jsx(Z, {
                order: n,
                onClick: () => {
                    M(t, n.order.id)
                }
            }, n.order.id), l !== e.length - 1 && s.jsx("div", {
                className: "bg-token-border-light h-px"
            })]
        }))
    }) : s.jsxs("div", {
        className: "flex min-h-[400px] w-full flex-col items-center justify-center py-6 text-sm",
        children: [s.jsx(A, {
            className: "icon-xl"
        }), s.jsx("div", {
            className: "text-base font-medium",
            children: s.jsx(f, {
                id: "2XILkl",
                defaultMessage: "No orders yet"
            })
        }), s.jsx("div", {
            className: "text-token-text-secondary text-xs",
            children: s.jsx(f, {
                id: "LwFNFv",
                defaultMessage: "Products you buy with ChatGPT will show here."
            })
        })]
    })
}
const Z = ({
        order: t,
        onClick: e
    }) => {
        var a;
        return s.jsxs("button", {
            className: "my-3",
            onClick: e,
            children: [s.jsxs("div", {
                className: "flex gap-3",
                children: [s.jsx("div", {
                    children: s.jsx("img", {
                        className: "border-token-border-default bg-token-bg-primary shadow-xxs relative h-14 w-14 rounded-[10px] border border-[.5px]",
                        src: (a = t.image_url) != null ? a : "",
                        alt: t.title
                    })
                }), s.jsxs("div", {
                    className: "flex flex-1 flex-col items-start justify-start gap-0.5",
                    children: [s.jsx("div", {
                        className: "-mt-1 line-clamp-2 text-start text-base",
                        children: t.title
                    }), s.jsx("div", {
                        className: "text-token-text-secondary text-xs",
                        children: t.subtitle
                    })]
                }), s.jsx("div", {
                    className: "me-2 flex items-center justify-center",
                    children: s.jsx(Q, {
                        className: "icon"
                    })
                })]
            }), t.error_message && s.jsx("div", {
                className: "bg-token-bg-status-error text-token-interactive-label-danger-secondary-default mt-3 flex items-center rounded-lg px-3 py-1 text-sm",
                children: t.error_message
            })]
        })
    },
    D = ({
        orderId: t
    }) => {
        var c, n, l, d, h;
        const {
            data: e,
            isLoading: a
        } = q({
            queryKey: ["order", t],
            queryFn: () => V(t),
            staleTime: C,
            refetchOnMount: "always",
            refetchOnWindowFocus: "always"
        }), r = O();
        return F.useEffect(() => {
            (e != null && e.order.conversation_id || e != null && e.order.shared_conversation_url) && t && _.logEventWithStatsig("product_order_history", "product_order_history", g(p({}, y({
                clientThreadId: e == null ? void 0 : e.order.conversation_id
            })), {
                action: "shown",
                order_id: t,
                shared_conversation_url: e.order.shared_conversation_url
            }))
        }, [e == null ? void 0 : e.order.conversation_id, e == null ? void 0 : e.order.shared_conversation_url, t]), s.jsxs("div", {
            children: [s.jsxs("div", {
                className: "h-header-height my-1 -ms-1 flex flex-shrink-0 items-center gap-2",
                children: [s.jsx(j, {
                    color: "ghost",
                    size: "medium",
                    onClick: () => M(r, void 0),
                    contentWrapperClassName: "gap-[6px]",
                    className: "w-9 rounded-lg",
                    children: s.jsx(H, {
                        className: "icon icon-sm"
                    })
                }), s.jsxs("div", {
                    className: "flex flex-col",
                    children: [s.jsxs("div", {
                        className: "flex items-center gap-1",
                        children: [s.jsx(B, {
                            className: "icon h-[18px] w-[18px] rounded-full",
                            url: (c = e == null ? void 0 : e.merchant_logo_url) != null ? c : "",
                            size: 128,
                            minSize: 16,
                            fallback: s.jsx($, {
                                className: "text-token-text-tertiary"
                            })
                        }), s.jsx("div", {
                            className: "text-sm font-normal",
                            children: e == null ? void 0 : e.merchant_title
                        })]
                    }), s.jsx("div", {
                        className: "text-token-text-secondary text-xs",
                        children: e == null ? void 0 : e.merchant_subtitle
                    })]
                })]
            }), a ? s.jsx(P, {}) : e ? s.jsxs("div", {
                className: "flex flex-col pt-1 pb-4",
                children: [s.jsxs("div", {
                    className: "flex gap-4",
                    children: [s.jsx("div", {
                        className: "bg-token-bg-tertiary dark:bg-token-main-surface-primary-inverse overflow-clip rounded-lg",
                        children: s.jsx("img", {
                            className: "m-0 aspect-square h-32 w-32 object-cover mix-blend-darken",
                            src: (n = e == null ? void 0 : e.image_url) != null ? n : "",
                            alt: (l = e == null ? void 0 : e.title) != null ? l : ""
                        })
                    }), s.jsxs("div", {
                        className: "flex flex-1 flex-col gap-0.5",
                        children: [s.jsx("div", {
                            className: "text-normal line-clamp-2 text-[17px] font-medium",
                            children: e.title
                        }), s.jsx("div", {
                            className: "text-token-text-secondary text-sm",
                            children: e == null ? void 0 : e.subtitle
                        }), s.jsxs("div", {
                            className: "mt-2 flex w-full flex-1 items-end gap-2",
                            children: [((d = e.order.conversation_id) != null ? d : e.order.shared_conversation_url) && s.jsx(j, {
                                as: "a",
                                to: e.order.shared_conversation_url || W(e.order.conversation_id),
                                onClick: i => {
                                    i.stopPropagation(), _.logEventWithStatsig("product_order_history", "product_order_history", g(p({}, y({
                                        clientThreadId: e == null ? void 0 : e.order.conversation_id
                                    })), {
                                        action: "open_conversation_button_clicked",
                                        order_id: t,
                                        shared_conversation_url: e.order.shared_conversation_url
                                    }))
                                },
                                color: "ghost",
                                className: "border-token-border-light rounded-2xl border px-4",
                                children: s.jsx(f, {
                                    id: "bLLnUh",
                                    defaultMessage: "Open in ChatGPT"
                                })
                            }), e.external_buttons.map((i, o) => s.jsx(s.Fragment, {
                                children: s.jsx(j, {
                                    as: "a",
                                    to: i.url,
                                    openNewTab: !0,
                                    onClick: u => {
                                        u.stopPropagation(), _.logEventWithStatsig("product_order_history", "product_order_history", g(p({}, y({
                                            clientThreadId: e == null ? void 0 : e.order.conversation_id
                                        })), {
                                            action: "external_link_button_clicked",
                                            url: i.url,
                                            order_id: t
                                        }))
                                    },
                                    color: "ghost",
                                    className: "border-token-border-light rounded-2xl border px-4",
                                    children: i.title
                                }, "".concat(i.title, "-").concat(o))
                            }))]
                        })]
                    })]
                }), e.error_message && s.jsx("div", {
                    className: "bg-token-bg-status-error text-token-interactive-label-danger-secondary-default mt-4 flex items-center rounded-lg px-3 py-1 text-sm",
                    children: e.error_message
                }), s.jsx("div", {
                    className: "mt-8 flex flex-col gap-8",
                    children: (h = e == null ? void 0 : e.sections) == null ? void 0 : h.map(i => s.jsxs("div", {
                        className: "flex flex-col",
                        children: [s.jsx("div", {
                            className: "border-token-border-light border-b pb-2.5 text-base font-medium",
                            children: i.title
                        }), s.jsx("dl", {
                            className: "divide-token-border-light divide-y",
                            children: i.items.map(o => s.jsxs("div", {
                                className: "text-token-text-primary flex items-start gap-2 py-2.5 text-sm",
                                children: [s.jsx("dt", {
                                    className: "flex-grow text-sm",
                                    children: o.label
                                }), s.jsx("dd", {
                                    className: "text-end text-sm font-medium whitespace-pre",
                                    children: s.jsx(K, {
                                        remarkPlugins: [
                                            [X, {
                                                singleTilde: !1
                                            }]
                                        ],
                                        components: {
                                            a: u => s.jsx("a", g(p({}, u), {
                                                className: U(u.className, "underline"),
                                                target: "_blank",
                                                children: u.children
                                            }))
                                        },
                                        children: o.value
                                    })
                                })]
                            }, o.label))
                        })]
                    }, i.title))
                })]
            }) : null]
        })
    },
    M = (t, e) => {
        const a = window.location.hash,
            [r, c] = a.split("?"),
            n = new URLSearchParams(c);
        e ? n.set("order", e) : n.delete("order");
        const l = "#settings/".concat(G.Orders).concat(n.toString() ? "?".concat(n.toString()) : "");
        t(l, {
            replace: !0
        })
    },
    ee = () => {
        const t = window.location.hash,
            [e, a] = t.split("?");
        return new URLSearchParams(a).get("order")
    };
export {
    me as O, le as a, xe as c, ce as g, M as s, de as u
};
//# sourceMappingURL=lqog7ixiwnif6sbp.js.map