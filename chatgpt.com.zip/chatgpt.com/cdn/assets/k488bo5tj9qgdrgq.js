var F = Object.defineProperty;
var R = Object.getOwnPropertySymbols;
var G = Object.prototype.hasOwnProperty,
    X = Object.prototype.propertyIsEnumerable;
var A = (n, e, t) => e in n ? F(n, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : n[e] = t,
    P = (n, e) => {
        for (var t in e || (e = {})) G.call(e, t) && A(n, t, e[t]);
        if (R)
            for (var t of R(e)) X.call(e, t) && A(n, t, e[t]);
        return n
    };
import {
    c as H,
    r as j,
    j as l,
    e as Y
} from "./fg33krlcm0qyi6yw.js";
import {
    b7 as q,
    h as c,
    d as L,
    bg as B,
    bX as J,
    bv as K
} from "./dykg4ktvbu3mhmdo.js";
import {
    V as Q
} from "./e9kbgh7j5o6g3dr6.js";
const a = () => ({
        id: null,
        hintMessage: null,
        modalMessage: null
    }),
    W = c(a()),
    Z = c(a()),
    S = c(a()),
    U = c(a()),
    ee = c(a()),
    se = c(a()),
    te = c(a()),
    V = [{
        signal: W,
        type: "normal"
    }, {
        signal: Z,
        type: "transient"
    }, {
        signal: S,
        type: "normal"
    }, {
        signal: U,
        type: "normal"
    }, {
        signal: ee,
        type: "normal"
    }, {
        signal: se,
        type: "normal"
    }, {
        signal: te,
        type: "normal"
    }],
    ne = q(() => {
        for (const n of V) {
            const e = n.signal();
            if (e.hintMessage != null) return {
                messageState: e,
                transient: n.type === "transient",
                clearMessage: () => {
                    n.signal.set(a())
                }
            }
        }
        return {
            messageState: void 0,
            transient: !1
        }
    }),
    pe = () => L(U).modalMessage != null,
    ue = () => {
        for (const {
                signal: n
            } of V) n.set(a())
    },
    D = "inline-flex items-center bg-transparent text-token-text-secondary hover:text-token-text-primary",
    oe = 3e3,
    ie = n => {
        "use forget";
        const e = H.c(7),
            {
                message: t,
                onClick: r
            } = n,
            d = Y();
        let s;
        e[0] !== d ? (s = d.formatMessage(le.openInfoModal), e[0] = d, e[1] = s) : s = e[1];
        let o;
        e[2] === Symbol.for("react.memo_cache_sentinel") ? (o = l.jsx(J, {
            className: "icon-sm ms-1"
        }), e[2] = o) : o = e[2];
        let i;
        return e[3] !== t || e[4] !== r || e[5] !== s ? (i = l.jsxs("button", {
            onClick: r,
            className: D,
            "aria-label": s,
            children: [t, o]
        }), e[3] = t, e[4] = r, e[5] = s, e[6] = i) : i = e[6], i
    },
    ae = n => {
        "use forget";
        var O, I, k, E, $, C;
        const e = H.c(23),
            {
                conversationId: t
            } = n,
            [r, d] = j.useState(!1),
            {
                messageState: s,
                transient: o,
                clearMessage: i
            } = L(re);
        let g;
        e[0] === Symbol.for("react.memo_cache_sentinel") ? (g = {
            title: void 0,
            description_markdown: void 0,
            buttons: []
        }, e[0] = g) : g = e[0];
        const [_, z] = j.useState(g);
        let M;
        e[1] !== ((O = s == null ? void 0 : s.modalMessage) == null ? void 0 : O.buttons) || e[2] !== ((I = s == null ? void 0 : s.modalMessage) == null ? void 0 : I.description_markdown) || e[3] !== ((k = s == null ? void 0 : s.modalMessage) == null ? void 0 : k.title) ? (M = () => {
            var u, T, w, N;
            z({
                title: (u = s == null ? void 0 : s.modalMessage) == null ? void 0 : u.title,
                description_markdown: (T = s == null ? void 0 : s.modalMessage) == null ? void 0 : T.description_markdown,
                buttons: (N = (w = s == null ? void 0 : s.modalMessage) == null ? void 0 : w.buttons) != null ? N : []
            }), d(!0)
        }, e[1] = (E = s == null ? void 0 : s.modalMessage) == null ? void 0 : E.buttons, e[2] = ($ = s == null ? void 0 : s.modalMessage) == null ? void 0 : $.description_markdown, e[3] = (C = s == null ? void 0 : s.modalMessage) == null ? void 0 : C.title, e[4] = M) : M = e[4];
        const v = M;
        let x, b;
        e[5] !== i || e[6] !== o ? (x = () => {
            let u;
            return o && (u = setTimeout(() => {
                i == null || i()
            }, oe)), () => {
                clearTimeout(u)
            }
        }, b = [o, i], e[5] = i, e[6] = o, e[7] = x, e[8] = b) : (x = e[7], b = e[8]), j.useEffect(x, b);
        let m;
        e[9] !== v || e[10] !== s || e[11] !== o ? (m = s && l.jsx(B.div, {
            initial: {
                opacity: 0
            },
            animate: {
                opacity: 1
            },
            exit: {
                opacity: 0
            },
            transition: {
                duration: .5
            },
            style: {
                pointerEvents: o ? "none" : "auto",
                cursor: o ? "default" : "pointer"
            },
            children: l.jsx("div", {
                className: "flex items-center text-xs",
                children: typeof s.hintMessage == "string" ? l.jsx(ie, {
                    message: s.hintMessage,
                    onClick: v
                }) : s.hintMessage
            })
        }, s.id), e[9] = v, e[10] = s, e[11] = o, e[12] = m) : m = e[12];
        let f;
        e[13] !== m ? (f = l.jsx(K, {
            mode: "wait",
            children: m
        }), e[13] = m, e[14] = f) : f = e[14];
        let h;
        e[15] === Symbol.for("react.memo_cache_sentinel") ? (h = () => d(!1), e[15] = h) : h = e[15];
        let p;
        e[16] !== t || e[17] !== r || e[18] !== _ ? (p = l.jsx(Q, P({
            conversationId: t,
            isOpen: r,
            onClose: h
        }, _)), e[16] = t, e[17] = r, e[18] = _, e[19] = p) : p = e[19];
        let y;
        return e[20] !== f || e[21] !== p ? (y = l.jsxs("div", {
            className: "absolute bottom-1 max-h-6 min-h-6",
            children: [f, p]
        }), e[20] = f, e[21] = p, e[22] = y) : y = e[22], y
    },
    le = {
        openInfoModal: {
            id: "hintMessage.openInfoModal",
            defaultMessage: "Open info modal",
            description: "Open info modal about voice mode usage"
        }
    };

function re() {
    return ne()
}
const ge = Object.freeze(Object.defineProperty({
    __proto__: null,
    VoiceHintContainer: ae,
    hintMessageClassName: D
}, Symbol.toStringTag, {
    value: "Module"
}));
export {
    U as a, ee as b, ue as c, te as d, a as e, D as h, se as i, W as m, S as r, Z as t, pe as u, ge as v
};
//# sourceMappingURL=k488bo5tj9qgdrgq.js.map