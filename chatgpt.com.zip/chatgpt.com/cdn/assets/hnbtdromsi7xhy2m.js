var b = Object.defineProperty,
    h = Object.defineProperties;
var k = Object.getOwnPropertyDescriptors;
var c = Object.getOwnPropertySymbols;
var f = Object.prototype.hasOwnProperty,
    x = Object.prototype.propertyIsEnumerable;
var p = (e, r, t) => r in e ? b(e, r, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : e[r] = t,
    a = (e, r) => {
        for (var t in r || (r = {})) f.call(r, t) && p(e, t, r[t]);
        if (c)
            for (var t of c(r)) x.call(r, t) && p(e, t, r[t]);
        return e
    },
    o = (e, r) => h(e, k(r));
var y = (e, r) => {
    var t = {};
    for (var n in e) f.call(e, n) && r.indexOf(n) < 0 && (t[n] = e[n]);
    if (e != null && c)
        for (var n of c(e)) r.indexOf(n) < 0 && x.call(e, n) && (t[n] = e[n]);
    return t
};
import {
    r as I,
    j as s
} from "./fg33krlcm0qyi6yw.js";
import {
    ab as R,
    ac as T,
    ad as v,
    ae as E
} from "./k15yxxoybkkir2ou.js";
import {
    f$ as A,
    l as g,
    bv as C,
    bg as w
} from "./dykg4ktvbu3mhmdo.js";
const F = M => {
    var u = M,
        {
            children: e,
            sideOffset: r = 6,
            isOpen: t,
            closePopover: n,
            popoverContentRef: j
        } = u,
        d = y(u, ["children", "sideOffset", "isOpen", "closePopover", "popoverContentRef"]);
    var m;
    const l = A();
    return I.useEffect(() => {
        if (!t) return;
        const i = N => {
            N.key === "Escape" && n()
        };
        return document.addEventListener("keydown", i, {
            capture: !0,
            passive: !0
        }), () => document.removeEventListener("keydown", i, {
            capture: !0
        })
    }, [t, n]), s.jsx(R, {
        children: s.jsx(T, o(a({
            forceMount: !0,
            asChild: !0,
            align: "center",
            sideOffset: r,
            onOpenAutoFocus: i => {
                i.preventDefault()
            }
        }, d), {
            style: o(a({}, (m = d.style) != null ? m : {}), {
                zIndex: 60
            }),
            children: s.jsx("div", {
                ref: j,
                className: g(!t && "pointer-events-none", "z-20"),
                children: s.jsx(C, {
                    mode: "sync",
                    children: t && s.jsx(w.div, {
                        className: g("popover bg-token-main-surface-primary dark:bg-token-main-surface-primary shadow-long overflow-auto rounded-2xl bg-clip-padding"),
                        variants: {
                            open: {
                                opacity: 1,
                                y: 0,
                                transition: l ? v : o(a({}, E), {
                                    duration: .1
                                })
                            },
                            closed: {
                                opacity: 0,
                                y: -4,
                                transition: l ? v : o(a({}, E), {
                                    duration: .1
                                })
                            }
                        },
                        initial: "closed",
                        animate: "open",
                        exit: "closed",
                        children: e
                    })
                })
            })
        }))
    })
};
export {
    F as C
};
//# sourceMappingURL=hnbtdromsi7xhy2m.js.map