var X = Object.defineProperty;
var S = Object.getOwnPropertySymbols;
var F = Object.prototype.hasOwnProperty,
    L = Object.prototype.propertyIsEnumerable;
var A = (s, e, a) => e in s ? X(s, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: a
    }) : s[e] = a,
    R = (s, e) => {
        for (var a in e || (e = {})) F.call(e, a) && A(s, a, e[a]);
        if (S)
            for (var a of S(e)) L.call(e, a) && A(s, a, e[a]);
        return s
    };
var B = (s, e) => {
    var a = {};
    for (var i in s) F.call(s, i) && e.indexOf(i) < 0 && (a[i] = s[i]);
    if (s != null && S)
        for (var i of S(s)) e.indexOf(i) < 0 && L.call(s, i) && (a[i] = s[i]);
    return a
};
import {
    c as $,
    e as T,
    j as t,
    r as g,
    M as p,
    _ as U
} from "./fg33krlcm0qyi6yw.js";
import {
    py as Y,
    iK as z,
    bb as H,
    hh as K,
    aX as G,
    f$ as V,
    l as b,
    nW as q,
    a9 as N,
    bv as E,
    bg as v,
    c0 as Q,
    tc as O,
    n0 as Z
} from "./dykg4ktvbu3mhmdo.js";
import {
    ej as J,
    eU as ee,
    fx as te
} from "./k15yxxoybkkir2ou.js";
import {
    l as se,
    b as ae
} from "./cdnrxzg58mayu5uf.js";
import {
    C as D
} from "./gmop4abenl57iboh.js";
import {
    E as ne
} from "./jhvz2qkf3st8xisu.js";
import {
    M as W
} from "./lts8z3c38wfynrxz.js";
import {
    S as ie
} from "./ccj0kc5w6drbfrlh.js";
import {
    t as re
} from "./ef7gr7kimbtxrws9.js";
import {
    c as oe
} from "./nr0ly5umft9hqfl0.js";
const we = s => {
        "use forget";
        var m;
        const e = $.c(23);
        let a, i, r, n;
        e[0] !== s ? (m = s, {
            currentPane: i,
            popPane: r,
            PANES: a
        } = m, n = B(m, ["currentPane", "popPane", "PANES"]), e[0] = s, e[1] = a, e[2] = i, e[3] = r, e[4] = n) : (a = e[1], i = e[2], r = e[3], n = e[4]);
        const o = T();
        if (i === "overview") {
            let h;
            return e[5] !== n ? (h = t.jsx(le, R({}, n)), e[5] = n, e[6] = h) : h = e[6], h
        }
        let c;
        e[7] !== o ? (c = o.formatMessage({
            id: "Px7S/2",
            defaultMessage: "Close"
        }), e[7] = o, e[8] = c) : c = e[8];
        let l;
        e[9] === Symbol.for("react.memo_cache_sentinel") ? (l = t.jsx(Y, {
            className: "icon-md text-token-interactive-icon-tertiary-default"
        }), e[9] = l) : l = e[9];
        let f;
        e[10] !== r || e[11] !== c ? (f = t.jsx("button", {
            type: "button",
            onClick: r,
            className: "bg-token-main-surface-primary hover:bg-token-main-surface-secondary focus-visible:ring-token-text-quaternary dark:hover:bg-token-main-surface-tertiary -ms-1 flex h-8 w-8 items-center justify-center rounded-full focus-visible:ring-2 focus-visible:ring-offset-1 focus-visible:ring-offset-transparent focus-visible:outline-hidden",
            "aria-label": c,
            children: l
        }), e[10] = r, e[11] = c, e[12] = f) : f = e[12];
        let u;
        e[13] !== a || e[14] !== i || e[15] !== o ? (u = o.formatMessage(a[i].name), e[13] = a, e[14] = i, e[15] = o, e[16] = u) : u = e[16];
        let d;
        e[17] !== u ? (d = t.jsx("span", {
            className: "text-xl font-medium",
            children: u
        }), e[17] = u, e[18] = d) : d = e[18];
        let x;
        return e[19] !== i || e[20] !== f || e[21] !== d ? (x = t.jsxs("div", {
            className: "flex items-center gap-2 pt-1",
            children: [f, d]
        }, i), e[19] = i, e[20] = f, e[21] = d, e[22] = x) : x = e[22], x
    },
    le = s => {
        "use forget";
        const e = $.c(17),
            {
                url: a,
                faviconUrl: i,
                logoUrl: r,
                title: n,
                subtitle: o,
                subtitlePrefix: c,
                subtitleUrl: l
            } = s;
        let f;
        e[0] !== i || e[1] !== r || e[2] !== n ? (f = r ? t.jsx("img", {
            src: r,
            alt: n,
            className: "icon rounded-full"
        }) : t.jsx(J, {
            className: "icon rounded-full",
            url: i != null ? i : "",
            size: 128,
            minSize: 16,
            fallback: t.jsx(ee, {
                className: "text-token-text-tertiary"
            })
        }), e[0] = i, e[1] = r, e[2] = n, e[3] = f) : f = e[3];
        let u;
        e[4] !== n || e[5] !== a ? (u = a ? t.jsx(z, {
            className: "text-sm font-medium",
            href: a,
            target: "_blank",
            children: n
        }) : t.jsx("div", {
            className: "text-sm font-medium",
            children: n
        }), e[4] = n, e[5] = a, e[6] = u) : u = e[6];
        let d;
        e[7] !== f || e[8] !== u ? (d = t.jsxs("div", {
            className: "flex items-center gap-2",
            children: [f, u]
        }), e[7] = f, e[8] = u, e[9] = d) : d = e[9];
        let x;
        e[10] !== o || e[11] !== c || e[12] !== l ? (x = o && t.jsxs("div", {
            className: "text-token-text-secondary text-xs",
            children: [c, l ? t.jsx(z, {
                className: "text-token-text-link inline text-xs underline",
                href: l,
                target: "_blank",
                children: o
            }) : o]
        }), e[10] = o, e[11] = c, e[12] = l, e[13] = x) : x = e[13];
        let m;
        return e[14] !== d || e[15] !== x ? (m = t.jsxs("div", {
            className: "flex min-h-[36px] flex-col justify-center",
            children: [d, x]
        }), e[14] = d, e[15] = x, e[16] = m) : m = e[16], m
    },
    ce = ["card", "shop_pay", "us_bank_account"],
    ue = ["payment_element_change_preview_beta_1", "prepare_payment_method_beta_1", "elements_icon_style_beta_1", "elements_address_element_sync_checkbox_beta_1", "link_forest_beta_1", "ece_prefer_plain_single_row_beta_1", "relax_spm_address_validation_beta_1", "change_event_improvements_beta_1"],
    de = 15e3;

function Pe({
    clientThreadId: s,
    grandTotal: e,
    merchantExternalId: a,
    merchantNetworkId: i,
    merchantTitle: r,
    paymentMethodTypes: n,
    fetchSession: o,
    children: c
}) {
    const {
        stripeCartSession: l,
        loading: f,
        error: u
    } = fe(s, o), d = H(), x = T(), [m, h] = g.useState(null), _ = g.useMemo(() => l != null && l.publishable_key ? se(l.publishable_key, {
        betas: ue
    }) : null, [l == null ? void 0 : l.publishable_key]), C = g.useMemo(() => !(l != null && l.client_secret) || !(n != null && n.length) ? null : {
        mode: "payment",
        currency: "usd",
        amount: e,
        customerSessionClientSecret: l.client_secret,
        paymentMethodTypes: n.filter(w => ce.includes(w)),
        paymentMethodOptions: n.includes("shop_pay") ? {
            shop_pay: {
                shop_id: a
            }
        } : void 0,
        sellerDetails: a && i && r ? {
            externalId: a,
            networkId: i,
            businessName: r
        } : void 0,
        syncAddressCheckbox: {
            mode: "shipping",
            formBehavior: "editable"
        },
        appearance: me(d)
    }, [d, a, i, r, n, l == null ? void 0 : l.client_secret, e]), M = f || !_ || !C;
    return g.useEffect(() => {
        if (!M) return;
        const w = setTimeout(() => {
            h(x.formatMessage({
                id: "Vj32Tb",
                defaultMessage: "Failed to load cart session (1298). Please refresh the page and try again."
            }))
        }, de);
        return () => clearTimeout(w)
    }, [M, x]), M ? c({
        loadingCartSession: !0,
        cartLoadError: u != null ? u : m
    }) : t.jsx(ae, {
        stripe: _,
        options: C,
        children: c({
            loadingCartSession: f,
            cartLoadError: u
        })
    })
}

function me(s) {
    return {
        icons: "outline",
        theme: s ? "night" : "stripe",
        labels: "floating",
        inputs: "condensed",
        variables: {
            fontSizeBase: "16px",
            colorPrimary: s ? "white" : "black",
            colorBackground: s ? "#2f2f2f" : "white",
            borderRadius: "30px",
            gridRowSpacing: "8px",
            gridColumnSpacing: "8px",
            colorTextSecondary: "#8F8F8F",
            fontSizeXs: "0.8rem"
        },
        rules: {
            ".Input, .PickerItem, .Tab, .AccordionItem, .Dropdown, .Block": {
                borderRadius: "16px",
                boxShadow: "none"
            },
            ".Input": {
                padding: "12px 16px 10px 16px",
                fontSize: "1em"
            },
            ".CheckboxLabel": {
                fontWeight: "500",
                fontSize: ".9rem",
                alignItems: "center"
            },
            ".Label--floating": {
                padding: "0",
                fontSize: ".75em",
                marginTop: "-3px"
            },
            ".AccordionItem--selected": {
                border: "solid 1px ".concat(s ? "white" : "black")
            },
            ".Input:focus": {
                boxShadow: "none",
                borderColor: s ? "white" : "black"
            },
            ".Label": {
                fontWeight: "500",
                fontSize: "14px",
                marginBottom: "6px",
                color: "#8F8F8F"
            }
        },
        disableAnimations: !0
    }
}

function fe(s, e) {
    const a = T(),
        i = K(s),
        n = (window && window.location.href).includes("/share/"),
        [o, c] = g.useState(null),
        [l, f] = g.useState(!0),
        [u, d] = g.useState(null),
        x = G(async () => {
            try {
                const {
                    error: m,
                    client_secret: h,
                    publishable_key: _
                } = await e();
                return m ? d(m) : h && _ ? c({
                    client_secret: h,
                    publishable_key: _
                }) : d(a.formatMessage({
                    id: "imEcZX",
                    defaultMessage: "Failed to load cart session (1300)"
                }))
            } catch (m) {
                return d(m instanceof Error ? m.message : a.formatMessage({
                    id: "S86mYy",
                    defaultMessage: "Failed to load cart session (1301)"
                }))
            } finally {
                f(!1)
            }
        });
    return g.useEffect(() => {
        if (!i && !n) {
            d(a.formatMessage({
                id: "/zl1B7",
                defaultMessage: "Failed to load cart session (1299). Please refresh the page and try again."
            }));
            return
        }
        x()
    }, []), {
        stripeCartSession: o,
        loading: l,
        error: u
    }
}
const j = 200,
    P = 150;

function Ie(s) {
    const [e, a] = g.useState([s]), [i, r] = g.useState(null), [n, o] = g.useState("right"), c = e[e.length - 1], l = g.useCallback(d => {
        o("right"), r(c), a(x => [...x, d]), setTimeout(() => r(null), j + P)
    }, [c]), f = g.useCallback(() => {
        e.length <= 1 || (o("left"), r(c), a(d => d.slice(0, d.length - 1)), setTimeout(() => r(null), j + P))
    }, [c, e.length]), u = g.useCallback(() => {
        e.length <= 1 || (o("left"), r(c), a([e[0]]), setTimeout(() => r(null), j + P))
    }, [c, e]);
    return {
        currentPane: c,
        exitingPane: i,
        direction: n,
        pushPane: l,
        popPane: f,
        resetPanes: u
    }
}

function Te({
    renderPane: s,
    className: e,
    paneStack: a,
    useDelayedEnteringPane: i,
    alwaysMountedPanes: r = []
}) {
    const {
        currentPane: n,
        exitingPane: o,
        direction: c
    } = a, l = V(), [f, u] = g.useState(!0), d = g.useRef(n), x = g.useRef(null);
    return g.useEffect(() => {
        if (d.current !== n)
            if (u(!1), !l && i) {
                const m = setTimeout(() => {
                    u(!0), d.current = n
                }, j + 50);
                return () => clearTimeout(m)
            } else u(!0), d.current = n
    }, [n, l, i]), g.useEffect(() => {
        setTimeout(() => {
            var m;
            x.current && ((m = x.current) == null || m.scrollTo({
                top: 0
            }))
        }, j)
    }, [o]), t.jsxs("div", {
        className: b("relative overflow-x-clip", e),
        children: [o != null && !l && !r.includes(o) && t.jsx("div", {
            className: b("absolute inset-0 overflow-y-auto", k("exit", c)),
            children: s(o)
        }), !r.includes(n) && t.jsx("div", {
            className: b("absolute inset-0 overflow-y-auto", d.current !== n && !l ? k("enter", c) : ""),
            children: f && s(n)
        }), r.map(m => {
            const h = m === o;
            return t.jsx("div", {
                ref: h ? x : void 0,
                className: b("absolute inset-0 overflow-y-auto", m === n || m === o ? "" : "hidden", o === m && !l && k("exit", c), n === m && d.current !== n && !l && k("enter", c)),
                children: s(m)
            }, "persist-".concat(String(m)))
        })]
    })
}

function k(s, e) {
    return s === "enter" ? e === "right" ? "animate-[slide-in-right_0.2s_forwards]" : "animate-[slide-in-left_0.2s_forwards]" : e === "right" ? "animate-[slide-out-left_0.2s_forwards]" : "animate-[slide-out-right_0.2s_forwards]"
}
const xe = {
        error: "bg-token-bg-status-error text-token-interactive-label-danger-secondary-default",
        warning: "bg-token-bg-status-warning text-token-text-status-warning",
        info: "bg-blue-50 text-blue-800 dark:bg-blue-900/40 dark:text-blue-100"
    },
    Ee = ({
        message: s,
        level: e = "error"
    }) => t.jsxs("div", {
        className: "".concat(xe[e], " flex items-center rounded-lg px-3 py-2 text-sm"),
        children: [t.jsx(q, {
            className: "me-2 shrink-0"
        }), s]
    }),
    I = ({
        messages: s,
        intervalMs: e = 4e3,
        repeat: a
    }) => {
        const [i, r] = g.useState(0);
        return g.useEffect(() => {
            if (s.length <= 1) return;
            const n = setInterval(() => {
                r(o => !a && o >= s.length - 1 ? (clearInterval(n), o) : (o + 1) % s.length)
            }, e);
            return () => clearInterval(n)
        }, [s.length, e, a]), t.jsx(N, {
            contentsFullWidth: !0,
            fullWidth: !0,
            disabled: !0,
            className: "h-10 text-base",
            children: t.jsx("div", {
                className: "relative h-6 w-full overflow-hidden",
                children: t.jsx(E, {
                    initial: !1,
                    children: t.jsxs(v.span, {
                        initial: {
                            y: "100%",
                            opacity: 0
                        },
                        animate: {
                            y: "0%",
                            opacity: 1
                        },
                        exit: {
                            y: "-100%",
                            opacity: 0
                        },
                        transition: {
                            duration: .3
                        },
                        className: "absolute inset-0 flex items-center justify-center",
                        children: [t.jsx(Q, {
                            className: "me-2"
                        }), s[i]]
                    }, i)
                })
            })
        })
    },
    Ce = ({
        isSubmitting: s,
        isUpdating: e,
        isDisabled: a,
        merchantTitle: i,
        hasValidPaymentMethod: r,
        paymentSheetButtonCta: n,
        onClickPay: o,
        pushPane: c,
        expressCheckoutElement: l,
        expressCheckoutElementReady: f
    }) => {
        const u = g.useMemo(() => ge(i), [i]),
            d = a || !r,
            x = s ? t.jsx(I, {
                messages: u
            }) : t.jsx(N, {
                fullWidth: !0,
                disabled: d,
                onClick: o,
                className: "btn-primary h-10 rounded-full px-6 text-sm font-medium",
                contentWrapperClassName: "w-full min-w-0",
                children: t.jsx("span", {
                    className: "truncate",
                    children: t.jsx(p, {
                        id: "BbrtuK",
                        defaultMessage: "Pay {merchant}",
                        values: {
                            merchant: i
                        }
                    })
                })
            }),
            m = t.jsxs("div", {
                className: "flex w-full flex-col gap-2 overflow-hidden",
                style: {
                    minHeight: f ? void 0 : "104px"
                },
                children: [t.jsxs("div", {
                    className: "relative",
                    children: [t.jsx(E, {
                        initial: !1,
                        children: !f && !s && t.jsx(v.div, {
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            exit: {
                                opacity: 0
                            },
                            transition: {
                                duration: .3
                            },
                            className: "absolute inset-0",
                            children: t.jsx(I, {
                                messages: [t.jsx(p, {
                                    id: "4NPTWv",
                                    defaultMessage: "Loading payment methods"
                                }, "loading")]
                            })
                        }, "working")
                    }), t.jsx(v.div, {
                        initial: {
                            opacity: 0
                        },
                        animate: {
                            opacity: f ? 1 : 0
                        },
                        transition: {
                            opacity: {
                                duration: .3
                            }
                        },
                        style: {
                            pointerEvents: f ? "auto" : "none"
                        },
                        className: b(s && "hidden"),
                        children: l
                    }, "express")]
                }), !r && t.jsx("div", {
                    className: "flex place-items-start",
                    children: s ? t.jsx(I, {
                        messages: u
                    }) : t.jsx(N, {
                        fullWidth: !0,
                        color: "ghost",
                        className: "border-token-border-light h-10 rounded-full border text-base",
                        onClick: () => c("paymentMethod"),
                        children: t.jsx(p, {
                            id: "checkout.payButtons.paymentSheetCta",
                            defaultMessage: "{cta}",
                            values: {
                                cta: n.trim().length > 0 ? n : "Pay another way"
                            }
                        })
                    })
                })]
            });
        return t.jsxs("div", {
            className: b("flex flex-col gap-2 pt-4 transition-opacity duration-300", e && "pointer-events-none opacity-30 [&_*]:pointer-events-none"),
            children: [r && x, m]
        })
    },
    ge = s => [t.jsx(p, {
        id: "RHR6oM",
        defaultMessage: "Talking to {store}",
        values: {
            store: s
        }
    }, "working"), t.jsx(p, {
        id: "QGko3r",
        defaultMessage: "Still working"
    }, "talking"), t.jsx(p, {
        id: "D8fGfD",
        defaultMessage: "Finalizing details"
    }, "securing")],
    Ae = ({
        text: s,
        className: e = "",
        duration: a = .15
    }) => {
        const i = g.useMemo(() => [...s].map((r, n) => ({
            key: "".concat(n, "-").concat(r),
            char: r,
            delay: Math.random() * .4
        })), [s]);
        return t.jsx("span", {
            className: "perspective-1000 inline-block ".concat(e),
            children: i.map(({
                key: r,
                char: n,
                delay: o
            }, c) => t.jsxs(v.span, {
                layout: !0,
                transition: {
                    layout: {
                        type: "spring",
                        stiffness: 320,
                        damping: 30
                    }
                },
                className: "relative inline-block align-baseline",
                children: [t.jsx("span", {
                    className: "invisible",
                    children: n === " " ? " " : n
                }), t.jsx(E, {
                    initial: !1,
                    children: t.jsx(v.span, {
                        className: "absolute inset-0 inline-block will-change-transform",
                        initial: {
                            rotateX: 90,
                            opacity: 0,
                            translateY: "0.2em"
                        },
                        animate: {
                            rotateX: 0,
                            opacity: 1,
                            translateY: 0
                        },
                        exit: {
                            rotateX: -90,
                            opacity: 0,
                            translateY: "-0.2em"
                        },
                        transition: {
                            duration: a,
                            ease: "easeInOut",
                            delay: o
                        },
                        children: n === " " ? " " : n
                    }, r)
                })]
            }, c))
        })
    },
    y = ({
        onClick: s,
        className: e = "",
        icon: a,
        primaryText: i,
        secondaryText: r,
        disabled: n,
        showChevron: o = !0
    }) => t.jsxs("button", {
        type: "button",
        disabled: n,
        className: b("bg-token-bg-elevated-primary flex min-h-[62px] w-full items-center justify-between rounded px-1 py-0 select-none", e, !s && "cursor-default"),
        onClick: s,
        style: {
            boxShadow: "none"
        },
        children: [t.jsxs("div", {
            className: "flex items-center gap-3.5 py-3",
            children: [a, t.jsxs("div", {
                className: "flex flex-col items-start",
                children: [t.jsx("span", {
                    className: "flex items-center gap-2 text-sm font-medium",
                    children: i
                }), r && t.jsx("span", {
                    className: "text-token-text-secondary text-[13px] leading-tight",
                    children: r
                })]
            })]
        }), o && t.jsx(te, {
            className: "text-token-text-tertiary icon-lg"
        })]
    }),
    Fe = ({
        onClick: s,
        isComplete: e,
        icon: a,
        label: i,
        sublabel: r,
        isLoading: n
    }) => n ? t.jsx(y, {
        disabled: !0,
        icon: t.jsx(D, {
            className: "icon-lg"
        }),
        primaryText: t.jsx(O, {
            index: 1,
            width: 100,
            heightSize: "sm",
            className: "min-w-28"
        })
    }) : t.jsx(y, {
        onClick: s,
        icon: e && a ? t.jsx(Z, {
            svgString: a == null ? void 0 : a.outerHTML,
            className: "icon-lg"
        }) : t.jsx(D, {
            className: "icon-lg"
        }),
        primaryText: e ? i : t.jsx(p, {
            id: "nO5Crd",
            defaultMessage: "Add payment method"
        }),
        secondaryText: e ? r : void 0
    }),
    Le = ({
        isLoading: s,
        onClick: e,
        name: a,
        addressLine1: i,
        addressLine2: r,
        city: n,
        state: o,
        isComplete: c
    }) => s ? t.jsx(y, {
        disabled: !0,
        icon: t.jsx(W, {
            className: "icon-lg"
        }),
        primaryText: t.jsx(O, {
            index: 1,
            width: 100,
            heightSize: "sm",
            className: "min-w-28"
        })
    }) : t.jsx(y, {
        onClick: e,
        icon: t.jsx(W, {
            className: "icon-lg"
        }),
        primaryText: c ? t.jsx(t.Fragment, {
            children: a && t.jsx("span", {
                children: a
            })
        }) : t.jsx(p, {
            id: "BlMnQg",
            defaultMessage: "Add shipping address"
        }),
        secondaryText: c ? t.jsx(p, {
            id: "XZ62ju",
            defaultMessage: "{line1}{line2}{city}, {state}",
            values: {
                line1: i ? "".concat(i, ", ") : "",
                line2: r ? "".concat(r, ", ") : "",
                city: n || "",
                state: o || ""
            }
        }) : void 0
    }),
    Re = ({
        emailAddress: s
    }) => t.jsx(y, {
        onClick: void 0,
        icon: t.jsx(ne, {
            className: "icon-lg"
        }),
        showChevron: !1,
        primaryText: t.jsx(p, {
            id: "xNqXJN",
            defaultMessage: "Digital Delivery"
        }),
        secondaryText: t.jsx(p, {
            id: "a8C3IV",
            defaultMessage: "Email to {emailAddress}",
            values: {
                emailAddress: s
            }
        })
    }),
    Be = ({
        method: s,
        onClick: e
    }) => t.jsx(y, {
        onClick: e,
        icon: t.jsx(ie, {
            className: "icon-lg"
        }),
        primaryText: s.title,
        secondaryText: s.subtitle
    });

function ze(s, e, a) {
    var i, r, n, o;
    return {
        name: s,
        line_one: (i = e.line1) != null ? i : void 0,
        line_two: e.line2,
        city: (r = e.city) != null ? r : "",
        state: (n = e.state) != null ? n : "",
        postal_code: (o = e.postal_code) != null ? o : "",
        country: e.country,
        phone_number: a
    }
}

function De(s, e, a) {
    var i, r, n, o, c, l;
    return {
        name: s != null ? s : "",
        line_one: (i = e.line1) != null ? i : "",
        line_two: (r = e.line2) != null ? r : "",
        city: (n = e.city) != null ? n : "",
        state: (o = e.state) != null ? o : "",
        country: (c = re(e.country)) != null ? c : "US",
        postal_code: (l = e.postal_code) != null ? l : "",
        phone_number: a != null ? a : ""
    }
}
async function We({
    stripe: s,
    elements: e,
    intl: a,
    billingName: i,
    billingEmail: r,
    isExpressCheckout: n
}) {
    var l, f;
    if (!n) {
        const u = await e.submit();
        if (u != null && u.error) return {
            isError: !0,
            action: "payment_failed",
            reason: "stripe_payment_submit_failed",
            uiMessage: (l = u.error.message) != null ? l : a.formatMessage({
                id: "Fken/H",
                defaultMessage: "Failed to submit payment (1341)"
            }),
            internalMessage: u.error.message ? "".concat(u.error.message, " (").concat(u.error.code, ")") : void 0,
            extraLogData: {
                error_message: u.error.message,
                error_code: u.error.code
            }
        }
    }
    const {
        error: o,
        paymentMethod: c
    } = await s.preparePaymentMethod({
        elements: e,
        params: {
            allow_redisplay: "always",
            billing_details: {
                name: i,
                email: r
            }
        }
    });
    return o ? {
        isError: !0,
        action: "payment_failed",
        reason: "stripe_prepare_payment_method_failed",
        uiMessage: (f = o.message) != null ? f : a.formatMessage({
            id: "bUeW4/",
            defaultMessage: "Failed to submit payment (1342)"
        }),
        internalMessage: String(o),
        extraLogData: {
            error_message: o
        }
    } : c
}
const $e = oe({
        animationLoader: () => U(() =>
            import ("./g7ok40ush52euab4.js"), []),
        StaticIcon: () => t.jsx(t.Fragment, {})
    }),
    Oe = ({
        onClick: s,
        isDisabled: e = !1,
        isSaving: a = !1
    }) => t.jsx(N, {
        fullWidth: !0,
        color: "primary",
        onClick: s,
        disabled: e,
        className: "h-10",
        children: a ? t.jsx(p, {
            id: "WmDyLh",
            defaultMessage: "Saving..."
        }) : t.jsx(p, {
            id: "8jETK0",
            defaultMessage: "Continue"
        })
    });
export {
    Ee as C, Re as D, Fe as P, Ae as R, we as S, De as a, $e as b, Ce as c, Oe as d, Pe as e, Te as f, Le as g, Be as h, ze as m, We as p, Ie as u
};
//# sourceMappingURL=bdob0mmccomv88dh.js.map