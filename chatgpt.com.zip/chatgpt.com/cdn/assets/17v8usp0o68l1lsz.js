var v = Object.defineProperty,
    L = Object.defineProperties;
var j = Object.getOwnPropertyDescriptors;
var w = Object.getOwnPropertySymbols;
var S = Object.prototype.hasOwnProperty,
    I = Object.prototype.propertyIsEnumerable;
var b = (e, n, r) => n in e ? v(e, n, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : e[n] = r,
    g = (e, n) => {
        for (var r in n || (n = {})) S.call(n, r) && b(e, r, n[r]);
        if (w)
            for (var r of w(n)) I.call(n, r) && b(e, r, n[r]);
        return e
    },
    m = (e, n) => L(e, j(n));
import {
    f as x,
    a as T,
    p as G,
    h as P
} from "./dbshkzvpochy4889.js";
import {
    d as M
} from "./hu1bt0oauegdhua6.js";
var A = {}.hasOwnProperty;

function _(e, n) {
    var r = n || {};

    function t(a) {
        var c = t.invalid,
            i = t.handlers;
        if (a && A.call(a, e) && (c = A.call(i, a[e]) ? i[a[e]] : t.unknown), c) return c.apply(this, arguments)
    }
    return t.handlers = r.handlers || {}, t.invalid = r.invalid, t.unknown = r.unknown, t
}
const $ = {}.hasOwnProperty;

function F(e, n) {
    let r = -1,
        t;
    if (n.extensions)
        for (; ++r < n.extensions.length;) F(e, n.extensions[r]);
    for (t in n)
        if ($.call(n, t)) switch (t) {
            case "extensions":
                break;
            case "unsafe":
                {
                    y(e[t], n[t]);
                    break
                }
            case "join":
                {
                    y(e[t], n[t]);
                    break
                }
            case "handlers":
                {
                    z(e[t], n[t]);
                    break
                }
            default:
                e.options[t] = n[t]
        }
    return e
}

function y(e, n) {
    n && e.push(...n)
}

function z(e, n) {
    n && Object.assign(e, n)
}
const R = [D];

function D(e, n, r, t) {
    if (n.type === "code" && x(n, t) && (e.type === "list" || e.type === n.type && x(e, t))) return !1;
    if ("spread" in r && typeof r.spread == "boolean") return e.type === "paragraph" && (e.type === n.type || n.type === "definition" || n.type === "heading" && T(n, t)) ? void 0 : r.spread ? 1 : 0
}
const d = ["autolink", "destinationLiteral", "destinationRaw", "reference", "titleQuote", "titleApostrophe"],
    E = [{
        character: "	",
        after: "[\\r\\n]",
        inConstruct: "phrasing"
    }, {
        character: "	",
        before: "[\\r\\n]",
        inConstruct: "phrasing"
    }, {
        character: "	",
        inConstruct: ["codeFencedLangGraveAccent", "codeFencedLangTilde"]
    }, {
        character: "\r",
        inConstruct: ["codeFencedLangGraveAccent", "codeFencedLangTilde", "codeFencedMetaGraveAccent", "codeFencedMetaTilde", "destinationLiteral", "headingAtx"]
    }, {
        character: "\n",
        inConstruct: ["codeFencedLangGraveAccent", "codeFencedLangTilde", "codeFencedMetaGraveAccent", "codeFencedMetaTilde", "destinationLiteral", "headingAtx"]
    }, {
        character: " ",
        after: "[\\r\\n]",
        inConstruct: "phrasing"
    }, {
        character: " ",
        before: "[\\r\\n]",
        inConstruct: "phrasing"
    }, {
        character: " ",
        inConstruct: ["codeFencedLangGraveAccent", "codeFencedLangTilde"]
    }, {
        character: "!",
        after: "\\[",
        inConstruct: "phrasing",
        notInConstruct: d
    }, {
        character: '"',
        inConstruct: "titleQuote"
    }, {
        atBreak: !0,
        character: "#"
    }, {
        character: "#",
        inConstruct: "headingAtx",
        after: "(?:[\r\n]|$)"
    }, {
        character: "&",
        after: "[#A-Za-z]",
        inConstruct: "phrasing"
    }, {
        character: "'",
        inConstruct: "titleApostrophe"
    }, {
        character: "(",
        inConstruct: "destinationRaw"
    }, {
        before: "\\]",
        character: "(",
        inConstruct: "phrasing",
        notInConstruct: d
    }, {
        atBreak: !0,
        before: "\\d+",
        character: ")"
    }, {
        character: ")",
        inConstruct: "destinationRaw"
    }, {
        atBreak: !0,
        character: "*",
        after: "(?:[ 	\r\n*])"
    }, {
        character: "*",
        inConstruct: "phrasing",
        notInConstruct: d
    }, {
        atBreak: !0,
        character: "+",
        after: "(?:[ 	\r\n])"
    }, {
        atBreak: !0,
        character: "-",
        after: "(?:[ 	\r\n-])"
    }, {
        atBreak: !0,
        before: "\\d+",
        character: ".",
        after: "(?:[ 	\r\n]|$)"
    }, {
        atBreak: !0,
        character: "<",
        after: "[!/?A-Za-z]"
    }, {
        character: "<",
        after: "[!/?A-Za-z]",
        inConstruct: "phrasing",
        notInConstruct: d
    }, {
        character: "<",
        inConstruct: "destinationLiteral"
    }, {
        atBreak: !0,
        character: "="
    }, {
        atBreak: !0,
        character: ">"
    }, {
        character: ">",
        inConstruct: "destinationLiteral"
    }, {
        atBreak: !0,
        character: "["
    }, {
        character: "[",
        inConstruct: "phrasing",
        notInConstruct: d
    }, {
        character: "[",
        inConstruct: ["label", "reference"]
    }, {
        character: "\\",
        after: "[\\r\\n]",
        inConstruct: "phrasing"
    }, {
        character: "]",
        inConstruct: ["label", "reference"]
    }, {
        atBreak: !0,
        character: "_"
    }, {
        character: "_",
        inConstruct: "phrasing",
        notInConstruct: d
    }, {
        atBreak: !0,
        character: "`"
    }, {
        character: "`",
        inConstruct: ["codeFencedLangGraveAccent", "codeFencedMetaGraveAccent"]
    }, {
        character: "`",
        inConstruct: "phrasing",
        notInConstruct: d
    }, {
        atBreak: !0,
        character: "~"
    }];

function O(e) {
    return e.label || !e.identifier ? e.label || "" : M(e.identifier)
}

function Z(e) {
    if (!e._compiled) {
        const n = (e.atBreak ? "[\\r\\n][\\t ]*" : "") + (e.before ? "(?:" + e.before + ")" : "");
        e._compiled = new RegExp((n ? "(" + n + ")" : "") + (/[|\\{}()[\]^$+*?.-]/.test(e.character) ? "\\" : "") + e.character + (e.after ? "(?:" + e.after + ")" : ""), "g")
    }
    return e._compiled
}

function Q(e, n, r) {
    const t = n.indexStack,
        a = e.children || [],
        c = [];
    let i = -1,
        s = r.before;
    t.push(-1);
    let l = n.createTracker(r);
    for (; ++i < a.length;) {
        const u = a[i];
        let o;
        if (t[t.length - 1] = i, i + 1 < a.length) {
            let h = n.handle.handlers[a[i + 1].type];
            h && h.peek && (h = h.peek), o = h ? h(a[i + 1], e, n, g({
                before: "",
                after: ""
            }, l.current())).charAt(0) : ""
        } else o = r.after;
        c.length > 0 && (s === "\r" || s === "\n") && u.type === "html" && (c[c.length - 1] = c[c.length - 1].replace(/(\r?\n|\r)$/, " "), s = " ", l = n.createTracker(r), l.move(c.join(""))), c.push(l.move(n.handle(u, e, n, m(g({}, l.current()), {
            before: s,
            after: o
        })))), s = c[c.length - 1].slice(-1)
    }
    return t.pop(), c.join("")
}

function U(e, n, r) {
    const t = n.indexStack,
        a = e.children || [],
        c = n.createTracker(r),
        i = [];
    let s = -1;
    for (t.push(-1); ++s < a.length;) {
        const l = a[s];
        t[t.length - 1] = s, i.push(c.move(n.handle(l, e, n, g({
            before: "\n",
            after: "\n"
        }, c.current())))), l.type !== "list" && (n.bulletLastUsed = void 0), s < a.length - 1 && i.push(c.move(H(l, a[s + 1], e, n)))
    }
    return t.pop(), i.join("")
}

function H(e, n, r, t) {
    let a = t.join.length;
    for (; a--;) {
        const c = t.join[a](e, n, r, t);
        if (c === !0 || c === 1) break;
        if (typeof c == "number") return "\n".repeat(1 + c);
        if (c === !1) return "\n\n<!---->\n\n"
    }
    return "\n\n"
}
const q = /\r?\n|\r/g;

function J(e, n) {
    const r = [];
    let t = 0,
        a = 0,
        c;
    for (; c = q.exec(e);) i(e.slice(t, c.index)), r.push(c[0]), t = c.index + c[0].length, a++;
    return i(e.slice(t)), r.join("");

    function i(s) {
        r.push(n(s, a, !s))
    }
}

function K(e, n, r) {
    const t = (r.before || "") + (n || "") + (r.after || ""),
        a = [],
        c = [],
        i = {};
    let s = -1;
    for (; ++s < e.unsafe.length;) {
        const o = e.unsafe[s];
        if (!G(e.stack, o)) continue;
        const h = e.compilePattern(o);
        let p;
        for (; p = h.exec(t);) {
            const k = "before" in o || !!o.atBreak,
                C = "after" in o,
                f = p.index + (k ? p[1].length : 0);
            a.includes(f) ? (i[f].before && !k && (i[f].before = !1), i[f].after && !C && (i[f].after = !1)) : (a.push(f), i[f] = {
                before: k,
                after: C
            })
        }
    }
    a.sort(N);
    let l = r.before ? r.before.length : 0;
    const u = t.length - (r.after ? r.after.length : 0);
    for (s = -1; ++s < a.length;) {
        const o = a[s];
        o < l || o >= u || o + 1 < u && a[s + 1] === o + 1 && i[o].after && !i[o + 1].before && !i[o + 1].after || a[s - 1] === o - 1 && i[o].before && !i[o - 1].before && !i[o - 1].after || (l !== o && c.push(B(t.slice(l, o), "\\")), l = o, /[!-/:-@[-`{-~]/.test(t.charAt(o)) && (!r.encode || !r.encode.includes(t.charAt(o))) ? c.push("\\") : (c.push("&#x" + t.charCodeAt(o).toString(16).toUpperCase() + ";"), l++))
    }
    return c.push(B(t.slice(l, u), r.after)), c.join("")
}

function N(e, n) {
    return e - n
}

function B(e, n) {
    const r = /\\(?=[!-/:-@[-`{-~])/g,
        t = [],
        a = [],
        c = e + n;
    let i = -1,
        s = 0,
        l;
    for (; l = r.exec(c);) t.push(l.index);
    for (; ++i < t.length;) s !== t[i] && a.push(e.slice(s, t[i])), a.push("\\"), s = t[i];
    return a.push(e.slice(s)), a.join("")
}

function V(e) {
    const n = e || {},
        r = n.now || {};
    let t = n.lineShift || 0,
        a = r.line || 1,
        c = r.column || 1;
    return {
        move: l,
        current: i,
        shift: s
    };

    function i() {
        return {
            now: {
                line: a,
                column: c
            },
            lineShift: t
        }
    }

    function s(u) {
        t += u
    }

    function l(u) {
        const o = u || "",
            h = o.split(/\r?\n|\r/g),
            p = h[h.length - 1];
        return a += h.length - 1, c = h.length === 1 ? c + p.length : 1 + p.length + t, o
    }
}

function ie(e, n = {}) {
    const r = {
        enter: a,
        indentLines: J,
        associationId: O,
        containerPhrasing: ee,
        containerFlow: ne,
        createTracker: V,
        compilePattern: Z,
        safe: te,
        stack: [],
        unsafe: [...E],
        join: [...R],
        handlers: g({}, P),
        options: {},
        indexStack: [],
        handle: void 0
    };
    F(r, n), r.options.tightDefinitions && r.join.push(Y), r.handle = _("type", {
        invalid: W,
        unknown: X,
        handlers: r.handlers
    });
    let t = r.handle(e, void 0, r, {
        before: "\n",
        after: "\n",
        now: {
            line: 1,
            column: 1
        },
        lineShift: 0
    });
    return t && t.charCodeAt(t.length - 1) !== 10 && t.charCodeAt(t.length - 1) !== 13 && (t += "\n"), t;

    function a(c) {
        return r.stack.push(c), i;

        function i() {
            r.stack.pop()
        }
    }
}

function W(e) {
    throw new Error("Cannot handle value `" + e + "`, expected node")
}

function X(e) {
    const n = e;
    throw new Error("Cannot handle unknown node `" + n.type + "`")
}

function Y(e, n) {
    if (e.type === "definition" && e.type === n.type) return 0
}

function ee(e, n) {
    return Q(e, this, n)
}

function ne(e, n) {
    return U(e, this, n)
}

function te(e, n) {
    return K(this, e, n)
}
export {
    ie as t
};
//# sourceMappingURL=17v8usp0o68l1lsz.js.map