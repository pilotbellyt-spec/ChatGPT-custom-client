function W(t) {
    const f = P(t, new WeakMap);
    try {
        return structuredClone(f)
    } catch (d) {}
    return f
}

function P(t, r) {
    if (t === null || typeof t == "string" || typeof t == "number" || typeof t == "boolean" || typeof t == "bigint") return t;
    if (typeof t == "symbol" || typeof t == "function" || typeof t > "u") return String(t);
    if (r.has(t)) return r.get(t);
    try {
        return structuredClone(t)
    } catch (n) {}
    const f = Object.prototype.toString.call(t);
    if (f === "[object Date]") return new Date(t.getTime());
    if (f === "[object RegExp]") return G(t);
    if (f === "[object ArrayBuffer]") return t.slice(0);
    if (f === "[object DataView]") {
        const n = t,
            e = P(n.buffer, r);
        try {
            return new DataView(e, n.byteOffset, n.byteLength)
        } catch (s) {
            return String(t)
        }
    }
    if (ArrayBuffer.isView(t) && !(t instanceof DataView)) try {
        const n = t.constructor;
        if (typeof t.slice == "function") return t.slice();
        const e = new n(t.length);
        return e.set(t), e
    } catch (n) {
        return String(t)
    }
    if (f === "[object Map]") {
        const n = new Map;
        r.set(t, n);
        for (const [e, s] of t) n.set(b(e, r), b(s, r));
        return n
    }
    if (f === "[object Set]") {
        const n = new Set;
        r.set(t, n);
        for (const e of t) n.add(b(e, r));
        return n
    }
    if (typeof Blob < "u" && t instanceof Blob) try {
        return typeof File < "u" && t instanceof File ? new File([t], t.name, {
            type: t.type,
            lastModified: t.lastModified
        }) : new Blob([t], {
            type: t.type
        })
    } catch (n) {
        return String(t)
    }
    if (typeof URL < "u" && t instanceof URL) try {
        return new URL(t.toString())
    } catch (n) {
        return String(t)
    }
    if (typeof URLSearchParams < "u" && t instanceof URLSearchParams) try {
        return new URLSearchParams(t.toString())
    } catch (n) {
        return String(t)
    }
    if (t instanceof Error) {
        const n = t;
        let e;
        try {
            const s = n.constructor;
            e = typeof s == "function" ? new s(n.message) : new Error(n.message)
        } catch (s) {
            e = new Error(n.message)
        }
        if (e.name = n.name, typeof n.stack == "string" && (e.stack = n.stack), "cause" in n) try {
            e.cause = b(n.cause, r)
        } catch (s) {
            e.cause = String(n.cause)
        }
        for (const s of Object.keys(n)) try {
            e[s] = b(n[s], r)
        } catch (y) {
            e[s] = String(n[s])
        }
        return e
    }
    if (typeof SharedArrayBuffer < "u" && t instanceof SharedArrayBuffer || typeof WeakMap < "u" && t instanceof WeakMap || typeof WeakSet < "u" && t instanceof WeakSet) return String(t);
    if (Array.isArray(t)) {
        const n = new Array(t.length);
        r.set(t, n);
        for (let e = 0; e < t.length; e++) e in t && (n[e] = b(t[e], r));
        return n
    }
    const d = {};
    r.set(t, d);
    for (const n of Object.keys(t)) {
        let e;
        try {
            e = t[n]
        } catch (s) {
            e = String(s)
        }
        d[n] = b(e, r)
    }
    return d
}

function b(t, r) {
    try {
        return structuredClone(t)
    } catch (f) {}
    return P(t, r)
}

function G(t) {
    const r = new RegExp(t.source, t.flags);
    return r.lastIndex = t.lastIndex, r
}
const M = "ABORT",
    L = "CALL",
    N = "REJECT",
    C = "RESOLVE";

function w(t, r) {
    const f = e => {
        const s = e.data;
        if (Array.isArray(s) && s[0] === L) {
            e.stopImmediatePropagation();
            const [y] = e.ports;
            if (!y) throw new Error("RPCCallMessage must contains a port.");
            r ? (async function() {
                const i = new AbortController;
                try {
                    y.onmessage = ({
                        data: c
                    }) => Array.isArray(c) && c[0] === M && i.abort(), y.postMessage([C, await r.call({
                        signal: i.signal
                    }, ...s.slice(1))])
                } catch (c) {
                    if (c instanceof Error && c.name === "DataCloneError") try {
                        y.postMessage([C, await r.call({
                            signal: i.signal
                        }, ...W(s.slice(1)))]);
                        return
                    } catch (o) {}
                    y.postMessage([N, c])
                } finally {
                    y.close()
                }
            })() : (y.postMessage([N, new Error("No function was registered on this RPC. This is probably calling a client which do not implement the function.")]), y.close())
        }
    };
    t.addEventListener("message", f), t.start();
    const d = e => (...s) => new Promise((y, i) => {
            var a;
            const {
                port1: c,
                port2: o
            } = new MessageChannel;
            c.onmessage = p => {
                const g = p.data;
                g[0] === C ? y(g[1]) : i(g[1]), c.close()
            }, (a = e == null ? void 0 : e.signal) == null || a.addEventListener("abort", () => {
                c.postMessage([M]), c.close(), i(new Error("Aborted."))
            }), t.postMessage([L, ...s], [o, ...e.transfer || []])
        }),
        n = d({});
    return n.withOptions = d, n
}
const T = "GENERATOR_GENERATE";

function _(t, r) {
    const f = e => {
        const s = e.data;
        if (Array.isArray(s) && s[0] === T) {
            if (e.stopImmediatePropagation(), !r) throw new Error("No function was registered on this RPC. This is probably calling a client which do not implement the function.");
            const [y, i, ...c] = s, o = r(...c);
            w(i.next, o.next.bind(o)), w(i.return, a => {
                var p;
                return ((p = o.return) == null ? void 0 : p.call(o, a)) || {
                    done: !0
                }
            }), w(i.throw, a => {
                var p;
                return ((p = o.throw) == null ? void 0 : p.call(o, a)) || Promise.reject(a)
            }), w(i.asyncDispose, async () => {
                var g, u;
                const a = Symbol.asyncDispose || Symbol.for("Symbol.asyncDispose"),
                    p = Symbol.dispose || Symbol.for("Symbol.dispose");
                a in o ? await ((g = o[a]) == null ? void 0 : g.call(o)) : p in o && ((u = o[p]) == null || u.call(o))
            })
        }
    };
    t.addEventListener("message", f), t.start();
    const d = e => {
            let s;
            return (...y) => {
                var R;
                const {
                    port1: i,
                    port2: c
                } = new MessageChannel, {
                    port1: o,
                    port2: a
                } = new MessageChannel, {
                    port1: p,
                    port2: g
                } = new MessageChannel, {
                    port1: u,
                    port2: l
                } = new MessageChannel, E = {
                    signal: e.signal
                }, m = () => {
                    i.close(), c.close(), o.close(), a.close(), p.close(), g.close(), u.close(), l.close()
                }, j = w(i).withOptions(E), k = w(o).withOptions(E), x = w(p).withOptions(E), B = w(u).withOptions(E);
                let O = !1;
                const S = async h => {
                        if (s == null || s(), O) return {
                            done: !0
                        };
                        const D = await h();
                        return D.done && (O = !0, m()), D
                    },
                    U = async h => {
                        s == null || s(), await h(), O = !0, m(), s = () => {
                            throw new Error("This generator has been disposed.")
                        }
                    },
                    A = {
                        next: h => S(() => k(h)),
                        return: h => S(() => x(h)),
                        throw: h => S(() => B(h)),
                        [Symbol.asyncDispose || Symbol.for("Symbol.asyncDispose")]: () => U(() => j()),
                        [Symbol.asyncIterator]: () => A
                    };
                return t.postMessage([T, {
                    asyncDispose: c,
                    next: a,
                    return: g,
                    throw: l
                }, ...y], [...e.transfer || [], c, a, g, l]), (R = e.signal) == null || R.addEventListener("abort", () => {
                    s = () => {
                        throw new Error("This generator has been aborted.")
                    }, m()
                }, {
                    once: !0
                }), A
            }
        },
        n = d({});
    return n.withOptions = d, n
}
const I = async (t, r, f = []) => {
        const d = new Set(Object.keys(r).filter(i => {
                var c, o;
                return ((o = (c = r[i]) == null ? void 0 : c.constructor) == null ? void 0 : o.name) === "AsyncGeneratorFunction"
            })),
            n = {};
        for (const i of Object.keys(r)) {
            if (r[i] === void 0) continue;
            const c = new MessageChannel;
            d.has(i) ? _(c.port1, (...o) => {
                var a;
                return (a = r[i]) == null ? void 0 : a.call(r, ...o)
            }) : w(c.port1, (...o) => {
                var a;
                return (a = r[i]) == null ? void 0 : a.call(r, ...o)
            }), n[i] = c.port2
        }
        const {
            ports: e,
            replyPort: s
        } = await new Promise(i => {
            const c = o => {
                o.data.type === "init" && o.source && o.source === t.contentWindow && (window.removeEventListener("message", c), i(o.data))
            };
            window.addEventListener("message", c)
        });
        return s.postMessage(n, Object.values(n)), s.start(), Object.fromEntries(Object.entries(e).map(([i, c]) => [i, f.includes(i) ? _(c) : w(c)]))
    },
    X = "web-sandbox.oaiusercontent.com",
    V = "https://".concat(X),
    {
        origin: F,
        protocol: J
    } = new URL(V),
    K = [F, "https://cdn.jsdelivr.net", "https://cdn.tailwindcss.com", "https://esm.sh", "https://unpkg.com", "https://pypi.org", "https://files.pythonhosted.org"];
export {
    F as C, V as L, J as a, K as b, I as i
};
//# sourceMappingURL=ktlrbeajo849nxci.js.map