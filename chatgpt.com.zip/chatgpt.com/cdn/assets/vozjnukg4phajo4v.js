var K = Object.defineProperty,
    Q = Object.defineProperties;
var Y = Object.getOwnPropertyDescriptors;
var B = Object.getOwnPropertySymbols;
var G = Object.prototype.hasOwnProperty,
    J = Object.prototype.propertyIsEnumerable;
var z = (e, s, t) => s in e ? K(e, s, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : e[s] = t,
    A = (e, s) => {
        for (var t in s || (s = {})) G.call(s, t) && z(e, t, s[t]);
        if (B)
            for (var t of B(s)) J.call(s, t) && z(e, t, s[t]);
        return e
    },
    F = (e, s) => Q(e, Y(s));
import {
    c as X,
    e as Z,
    r as D,
    f as V,
    j as o,
    M as L
} from "./fg33krlcm0qyi6yw.js";
import {
    az as ee
} from "./k15yxxoybkkir2ou.js";
import {
    s6 as te,
    H as se,
    rL as oe,
    b as ne,
    d as ae,
    s7 as N,
    s8 as ce,
    _ as ie,
    B as re,
    M as H,
    C as le,
    x as ue,
    P as de,
    y as fe,
    z as me
} from "./dykg4ktvbu3mhmdo.js";
import {
    d as he
} from "./k2oaaf8ac9lafsub.js";
import "./lans8a2ikbh9ax9r.js";

function Se(e) {
    switch (e) {
        case N.SSOMismatch:
            return {
                title: a.cannotAccessWorkspace,
                description: a.ssoMismatchDescription
            };
        case N.RequireSSOLogin:
            return {
                title: a.cannotAccessWorkspace,
                description: a.requireSSODescription
            };
        case N.UnexpectedSSOLogin:
            return {
                title: a.cannotAccessWorkspace,
                description: a.unexpectedSSODescription
            }
    }
}
const pe = 2e3;

function Ae() {
    "use forget";
    var v, b;
    const e = X.c(33),
        s = te(),
        t = se(),
        T = Z(),
        i = ne(),
        q = oe();
    let h;
    e[0] !== i ? (h = () => ce(i).isFetched, e[0] = i, e[1] = h) : h = e[1];
    const P = ae(h),
        c = s == null ? void 0 : s.errorCode,
        f = s != null && P && q == null && !!t,
        [R, W] = D.useState(!1);
    let S, p;
    e[2] !== f ? (S = () => {
        f && setTimeout(() => {
            W(!0)
        }, pe)
    }, p = [f], e[2] = f, e[3] = S, e[4] = p) : (S = e[3], p = e[4]), D.useEffect(S, p);
    const $ = c === N.UnexpectedSSOLogin,
        m = f && ($ ? R : !0),
        n = he();
    let g, O;
    if (e[5] !== n || e[6] !== c || e[7] !== m ? (g = () => {
            var U;
            if (!c || !m) return;
            const I = (U = n == null ? void 0 : n.split("@")) == null ? void 0 : U[1];
            ie.addError("SSO Catch All Modal: ".concat(c, " for ").concat(n != null ? n : "unknown user"), {
                sso_error: c,
                email: n,
                email_hostname: I
            })
        }, O = [c, m, n], e[5] = n, e[6] = c, e[7] = m, e[8] = g, e[9] = O) : (g = e[8], O = e[9]), D.useEffect(g, O), !m) return null;
    let x;
    e[10] !== T || e[11] !== s.accountName || e[12] !== (t == null ? void 0 : t.name) ? (x = (b = (v = s == null ? void 0 : s.accountName) != null ? v : t == null ? void 0 : t.name) != null ? b : T.formatMessage(a.workspacePlaceholder), e[10] = T, e[11] = s.accountName, e[12] = t == null ? void 0 : t.name, e[13] = x) : x = e[13];
    const E = x;
    let M;
    e[14] !== i || e[15] !== t ? (M = () => {
        const I = t != null && t.ssoConnectionName ? {
            connection: t.ssoConnectionName
        } : void 0;
        re(i, {
            fallbackScreenHint: "login",
            additionalAuthParams: I
        })
    }, e[14] = i, e[15] = t, e[16] = M) : M = e[16];
    const k = M;
    let C;
    e[17] !== s.errorCode ? (C = Se(s.errorCode), e[17] = s.errorCode, e[18] = C) : C = e[18];
    const {
        title: j,
        description: w
    } = C;
    let r;
    e[19] !== j ? (r = o.jsx("div", {
        className: "flex flex-col",
        children: o.jsx("div", {
            className: "text-lg",
            children: o.jsx(L, A({}, j))
        })
    }), e[19] = j, e[20] = r) : r = e[20];
    let l;
    e[21] !== E ? (l = o.jsx(L, F(A({}, a.authenticateNotice), {
        values: {
            workspaceName: E
        }
    })), e[21] = E, e[22] = l) : l = e[22];
    let u;
    e[23] !== k || e[24] !== l ? (u = o.jsx(H.Button, {
        onClick: k,
        color: "primary",
        children: l
    }), e[23] = k, e[24] = l, e[25] = u) : u = e[25];
    let y;
    e[26] === Symbol.for("react.memo_cache_sentinel") ? (y = o.jsx(H.Button, {
        onClick: ge,
        children: o.jsx(L, {
            id: "KlMYRb",
            defaultMessage: "Log out"
        })
    }), e[26] = y) : y = e[26];
    let d;
    e[27] !== w ? (d = o.jsx("div", {
        className: "flex flex-col space-y-4",
        children: o.jsx("div", {
            children: o.jsx(L, A({}, w))
        })
    }), e[27] = w, e[28] = d) : d = e[28];
    let _;
    return e[29] !== u || e[30] !== d || e[31] !== r ? (_ = o.jsx(le, {
        testId: "modal-sso-catch-all",
        isOpen: !0,
        onClose: ue,
        type: "warning",
        size: "custom",
        className: "max-w-3xl",
        title: r,
        icon: ee,
        primaryButton: u,
        secondaryButton: y,
        children: d
    }), e[29] = u, e[30] = d, e[31] = r, e[32] = _) : _ = e[32], _
}

function ge() {
    de.logLogOutButtonClicked({
        location: "sso_catch_all_modal"
    }, fe.ACCESS_LOGOUT_ACTION_LOCATION_SSO_CATCH_ALL_MODAL), me()
}
const a = V({
    authenticateNotice: {
        id: "zF1QJE",
        defaultMessage: "Authenticate to {workspaceName}"
    },
    workspacePlaceholder: {
        id: "IIY4N4",
        defaultMessage: "this workspace"
    },
    cannotAccessWorkspace: {
        id: "IlXHdd",
        defaultMessage: "Cannot Access This Workspace"
    },
    ssoMismatchDescription: {
        id: "xSuU9q",
        defaultMessage: "The SSO you logged in with does not match the SSO registered for this workspace. Try re-authenticating with that SSO."
    },
    unexpectedSSODescription: {
        id: "uSkRZx",
        defaultMessage: "This workspace doesn't have an SSO associated with it, but you're trying to log in with SSO. Try logging in with social authentication (i.e. Google) or with your password."
    },
    requireSSODescription: {
        id: "akKMy1",
        defaultMessage: "Your organization requires that you log in with SSO to access this workspace"
    }
});
export {
    Ae as
    default
};
//# sourceMappingURL=vozjnukg4phajo4v.js.map