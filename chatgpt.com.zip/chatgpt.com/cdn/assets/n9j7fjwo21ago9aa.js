import {
    c as oe,
    j as i,
    r as D,
    M as fe
} from "./fg33krlcm0qyi6yw.js";
import {
    d as ie,
    ac as he,
    bg as pe,
    bv as be,
    e as ue,
    gz as ge,
    py as xe,
    aY as ye
} from "./dykg4ktvbu3mhmdo.js";
import {
    g as _e,
    E as Se,
    e as le
} from "./jzcvgi3ud281qm7h.js";
import {
    eD as ve,
    eE as we,
    Z as je
} from "./k15yxxoybkkir2ou.js";
import "./ef7gr7kimbtxrws9.js";
import "./ktlrbeajo849nxci.js";
import "./kl7c6054usfnqmd4.js";
import "./ns51nblw8ziscsgd.js";
const Ce = {
        type: "spring",
        bounce: .05
    },
    V = 500,
    Ee = r => {
        const e = r == null ? void 0 : r.layout,
            t = e != null && e.sidebarWidthPx ? Number(e.sidebarWidthPx) : V;
        return "".concat(Math.round(t), "px")
    },
    Te = r => {
        "use forget";
        const e = oe.c(8),
            {
                conversation: t
            } = r;
        let o;
        e[0] !== t ? (o = () => le(t), e[0] = t, e[1] = o) : o = e[1];
        const s = ie(o),
            a = s != null;
        let l;
        e[2] !== t || e[3] !== a || e[4] !== s ? (l = a && i.jsx(Ne, {
            conversation: t,
            focusedObject: s.focusedObject,
            chatSDK: s.chatSDK
        }), e[2] = t, e[3] = a, e[4] = s, e[5] = l) : l = e[5];
        let c;
        return e[6] !== l ? (c = i.jsx(be, {
            children: l
        }), e[6] = l, e[7] = c) : c = e[7], c
    },
    Ne = r => {
        "use forget";
        var X, ee, te, se;
        const e = oe.c(57),
            {
                focusedObject: t,
                conversation: o,
                chatSDK: s
            } = r;
        let a, l;
        e[0] === Symbol.for("react.memo_cache_sentinel") ? (a = ue(), l = he(), e[0] = a, e[1] = l) : (a = e[0], l = e[1]);
        const {
            locale: c
        } = l, y = ve(s);
        let _;
        e[2] === Symbol.for("react.memo_cache_sentinel") ? (_ = () => ge(a), e[2] = _) : _ = e[2];
        const B = ie(_),
            {
                html: P,
                domain: T,
                subdomain: z,
                csp: F
            } = y,
            {
                widgetParent: S,
                widgetType: O,
                metadata: n,
                widgetId: $
            } = s,
            G = (X = n == null ? void 0 : n.attribution_id) != null ? X : S,
            W = (ee = n == null ? void 0 : n.height_hint) != null ? ee : 400,
            H = (te = n == null ? void 0 : n.suggestion_message_id) != null ? te : null,
            [ne, ae] = D.useState(!1),
            [K, re] = D.useState(!1),
            ce = D.useRef(null);
        let v;
        e[3] !== o ? (v = () => {
            le.set(o, null)
        }, e[3] = o, e[4] = v) : v = e[4];
        const d = v,
            [L, de] = D.useState(null),
            Y = L != null ? L : 0;
        let w;
        e[5] !== Y ? (w = {
            insets: {
                top: Y,
                bottom: 0,
                left: 0,
                right: 0
            }
        }, e[5] = Y, e[6] = w) : w = e[6];
        const U = w;
        let j;
        e[7] !== s || e[8] !== B ? (j = _e(B, s), e[7] = s, e[8] = B, e[9] = j) : j = e[9];
        const Z = j;
        let C;
        e[10] !== t.params ? (C = t != null && t.params ? Ee(t == null ? void 0 : t.params) : V, e[10] = t.params, e[11] = C) : C = e[11];
        const q = C,
            J = !ne;
        let E;
        e[12] === Symbol.for("react.memo_cache_sentinel") ? (E = {
            width: 0
        }, e[12] = E) : E = e[12];
        const Q = q != null ? q : V;
        let m;
        e[13] !== Q ? (m = {
            width: Q
        }, e[13] = Q, e[14] = m) : m = e[14];
        let N;
        e[15] === Symbol.for("react.memo_cache_sentinel") ? (N = {
            width: 0
        }, e[15] = N) : N = e[15];
        let k;
        e[16] === Symbol.for("react.memo_cache_sentinel") ? (k = {
            width: "100%"
        }, e[16] = k) : k = e[16];
        let I;
        e[17] === Symbol.for("react.memo_cache_sentinel") ? (I = we({
            axis: "height",
            onChange: A => {
                const {
                    height: me
                } = A;
                return de(me)
            }
        }), e[17] = I) : I = e[17];
        let f;
        e[18] !== K ? (f = K && i.jsx(je, {
            onClick: () => {
                var A;
                return (A = ce.current) == null ? void 0 : A.navigate({
                    delta: -1
                })
            },
            className: "text-white mix-blend-difference grayscale",
            children: i.jsx(xe, {})
        }), e[18] = K, e[19] = f) : f = e[19];
        let h;
        e[20] !== t.title ? (h = (se = t.title) != null ? se : i.jsx(fe, {
            id: "OY2FrM",
            defaultMessage: "ChatGPT Application"
        }), e[20] = t.title, e[21] = h) : h = e[21];
        let p;
        e[22] !== h ? (p = i.jsx("div", {
            className: "line-clamp-1 flex-1 truncate px-2 text-lg",
            children: h
        }), e[22] = h, e[23] = p) : p = e[23];
        let b;
        e[24] !== d ? (b = i.jsx(ye, {
            onClick: d,
            iconSize: "lg",
            className: "text-token-text-primary ms-auto mix-blend-difference grayscale"
        }), e[24] = d, e[25] = b) : b = e[25];
        let u;
        e[26] !== f || e[27] !== p || e[28] !== b ? (u = i.jsxs("header", {
            className: "border-token-border-light bg-primary sticky start-0 end-0 top-0 z-[1000] flex w-full items-center justify-between border-b p-2",
            ref: I,
            children: [f, p, b]
        }), e[26] = f, e[27] = p, e[28] = b, e[29] = u) : u = e[29];
        let R;
        e[30] === Symbol.for("react.memo_cache_sentinel") ? (R = () => ae(!0), e[30] = R) : R = e[30];
        let g;
        e[31] !== G || e[32] !== s || e[33] !== o || e[34] !== F || e[35] !== T || e[36] !== Z || e[37] !== t.params || e[38] !== t.title || e[39] !== d || e[40] !== W || e[41] !== P || e[42] !== y || e[43] !== U || e[44] !== z || e[45] !== H || e[46] !== $ || e[47] !== S || e[48] !== O ? (g = i.jsx("div", {
            className: "flex-1 overflow-auto",
            children: i.jsx(Se, {
                onReady: R,
                onClose: d,
                onCanGoBack: re,
                domain: T,
                html: P,
                attributionId: G,
                widgetId: $,
                widgetParent: S,
                suggestionMessageId: H,
                widgetType: O,
                features: Z,
                subdomain: z,
                displayMode: "sidebar",
                csp: F,
                locale: c,
                heightHint: W,
                safeArea: U,
                conversation: o,
                chatSDK: s,
                clientThreadId: o.id,
                resolvedWidget: y,
                params: t.params,
                title: t.title
            })
        }), e[31] = G, e[32] = s, e[33] = o, e[34] = F, e[35] = T, e[36] = Z, e[37] = t.params, e[38] = t.title, e[39] = d, e[40] = W, e[41] = P, e[42] = y, e[43] = U, e[44] = z, e[45] = H, e[46] = $, e[47] = S, e[48] = O, e[49] = g) : g = e[49];
        let x;
        e[50] !== u || e[51] !== g ? (x = i.jsxs("div", {
            className: "flex h-full flex-col overflow-hidden contain-size",
            style: k,
            children: [u, g]
        }), e[50] = u, e[51] = g, e[52] = x) : x = e[52];
        let M;
        return e[53] !== m || e[54] !== x || e[55] !== J ? (M = i.jsx(pe.div, {
            layout: !0,
            "aria-hidden": J,
            className: "border-token-border-light bg-token-bg-primary relative h-screen overflow-hidden border-s shadow-[0px_0px_48px_rgba(0,0,0,0.08)]",
            initial: E,
            animate: m,
            exit: N,
            transition: Ce,
            children: x
        }, "about-me-sidebar"), e[53] = m, e[54] = x, e[55] = J, e[56] = M) : M = e[56], M
    };
export {
    Te as EcosystemAppSidebar
};
//# sourceMappingURL=n9j7fjwo21ago9aa.js.map