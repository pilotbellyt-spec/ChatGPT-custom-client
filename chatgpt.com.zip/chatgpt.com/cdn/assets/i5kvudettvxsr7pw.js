const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/gaphvnjebtzdtxfg.js", "assets/fg33krlcm0qyi6yw.js", "assets/k15yxxoybkkir2ou.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/conversation-small-332fs9rk.css", "assets/oc8fs8bcw8g6jsf9.js", "assets/l7a8egw0mweabdbx.js", "assets/e3nv6hvbmio0y9xi.js", "assets/hz9475nc5ndyfqsu.js", "assets/ou2xm3xmri21t4zm.js", "assets/d7rlq0jakxw4xftp.js", "assets/h3mm4dcmy7evm6n4.js", "assets/og5o4sw4c4stlwx8.js", "assets/o83wojjcqigmj3pl.js", "assets/bs2inoi5zs5d1t2y.js", "assets/nr0ly5umft9hqfl0.js", "assets/obmzp3ebe8x6w67a.js", "assets/djpmlcnv0hwdbvt3.js", "assets/jwpogvkjudya01jq.js", "assets/m3nlgnsrugqi2gr9.js", "assets/gb3g89r4fqk97sov.js", "assets/bzqbnv68e5p19ax6.js", "assets/tjmll0bdtco26rsw.js", "assets/jnh7gh80gtj0452q.js", "assets/fs51lw7sk01ucw2k.js", "assets/gzawuxr3t3jsprp5.js", "assets/hnkonxwit7dqywl1.js", "assets/cxsk4sfhrrxijhsv.js", "assets/hh9rsyoswiukh5cc.js", "assets/gry8j32h87k624fm.js", "assets/bx8o5u3qhj3ykfih.js", "assets/fyac27lwp2ges2bl.js", "assets/jzcvgi3ud281qm7h.js", "assets/ef7gr7kimbtxrws9.js", "assets/ktlrbeajo849nxci.js", "assets/kl7c6054usfnqmd4.js", "assets/ns51nblw8ziscsgd.js", "assets/gbmggnydp7mcsebl.js", "assets/ce3hgmw4iyyhicud.js", "assets/c43bn0h5becxd9zb.js", "assets/t78mnq11g4hn5899.js", "assets/fu96nxanm8bvt745.js", "assets/gd2ozzf4upgi0amm.js", "assets/f4emdhmpnt7z5af8.js", "assets/o9wnx2r6h1qfy4ir.js", "assets/d500l0l73692yic4.js", "assets/jbh6ambg0gcrgcqd.js", "assets/b31u62knn5mcc1vg.js", "assets/msn8hpk3ivp7ibnw.js", "assets/c2wfb3iy9wkb85gs.js", "assets/ovpdmx71kjznjdh8.js", "assets/pbl95wx6493wq92j.js", "assets/fyk9tph6baj60t7u.js", "assets/cjybewlxcr1rdyw3.js", "assets/cot-message-g4jkzz65.css", "assets/fymkrlvs65gsh17v.js", "assets/h7cgi5y3akol4cqi.js", "assets/f9njdfff9vl67oeu.js", "assets/oba8e1s7hs6f0mpl.js"]))) => i.map(i => d[i]);
import {
    _ as x,
    r as L,
    j as t,
    M as pe
} from "./fg33krlcm0qyi6yw.js";
import {
    bh as _,
    kM as He,
    fN as Te,
    d as K,
    eW as Ke,
    ej as Ue,
    b as Xe,
    eo as Ye,
    kH as e,
    bc as Ze,
    bd as qe,
    gd as X,
    kz as Ge,
    gG as Y,
    kF as P,
    P as st,
    km as et,
    er as ye,
    l as be,
    dQ as Ie,
    e2 as tt,
    pT as je,
    r6 as at,
    eh as U,
    ed as nt,
    da as it,
    gF as ot,
    e4 as lt
} from "./dykg4ktvbu3mhmdo.js";
import {
    aA as rt,
    aB as ct,
    aC as mt,
    aD as dt,
    aE as Ee,
    aF as gt,
    aG as ht,
    aH as ut,
    aI as _t,
    aJ as ft,
    aK as xt,
    aL as Tt,
    aM as yt,
    aN as bt,
    aO as It,
    aP as jt,
    aQ as Et,
    aR as St,
    aS as pt,
    aT as wt,
    aU as At,
    aV as Ct,
    aW as Se,
    aX as Lt,
    aY as Pt,
    aZ as Dt,
    a_ as kt,
    a$ as Rt,
    b0 as vt,
    b1 as Ot
} from "./k15yxxoybkkir2ou.js";
import {
    T as Vt
} from "./hz9475nc5ndyfqsu.js";
import {
    g as zt
} from "./ou2xm3xmri21t4zm.js";
const Bt = _(() => x(() =>
        import ("./gaphvnjebtzdtxfg.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5]))),
    Nt = _(() => x(() =>
        import ("./oc8fs8bcw8g6jsf9.js"), __vite__mapDeps([6, 1, 3, 4, 7]))),
    Qt = _(() => x(() =>
        import ("./e3nv6hvbmio0y9xi.js"), __vite__mapDeps([8, 1, 3, 4, 9, 2, 5, 10]))),
    Ft = _(() => x(() =>
        import ("./d7rlq0jakxw4xftp.js"), __vite__mapDeps([11, 1, 3, 4, 12, 13, 2, 5, 14, 15, 16]))),
    Mt = _(async () => () => null),
    $t = _(async () => (await x(() =>
        import ("./obmzp3ebe8x6w67a.js"), __vite__mapDeps([17, 1, 3, 4, 2, 5]))).GlauxMessage),
    Jt = _(async () => (await x(() =>
        import ("./djpmlcnv0hwdbvt3.js"), __vite__mapDeps([18, 1, 3, 4, 2, 5, 14, 19, 20, 21, 15, 16, 22, 23, 24]))).ImageGenMessage),
    Wt = _(() => x(() =>
        import ("./fs51lw7sk01ucw2k.js"), __vite__mapDeps([25, 1, 3, 4, 2, 5]))),
    Ht = _(() => x(() =>
        import ("./k15yxxoybkkir2ou.js").then(a => a.Fd), __vite__mapDeps([2, 1, 3, 4, 5])).then(a => a.BrowsingMessage)),
    Kt = _(() => x(() =>
        import ("./gzawuxr3t3jsprp5.js"), __vite__mapDeps([26, 1, 3, 4, 2, 5, 10])).then(a => a.BrowserToolMessage)),
    Ut = _(() => x(() =>
        import ("./hnkonxwit7dqywl1.js"), __vite__mapDeps([27, 1, 3, 4, 2, 5])).then(a => a.SearchResultMessage)),
    Xt = _(() => x(() =>
        import ("./cxsk4sfhrrxijhsv.js"), __vite__mapDeps([28, 1, 3, 4, 2, 5, 29, 30, 31, 32, 33, 34, 35, 36, 37, 12, 13, 38, 39])).then(a => a.JITPluginMessage)),
    Yt = _(() => x(() =>
        import ("./c43bn0h5becxd9zb.js"), __vite__mapDeps([40, 1, 3, 4, 2, 5, 32])).then(a => a.APIToolElicitationMessage)),
    Zt = _(() => x(() =>
        import ("./t78mnq11g4hn5899.js"), __vite__mapDeps([41, 1, 3, 4, 42, 43, 2, 5])).then(a => a.DataAnalysisMessage)),
    qt = _(() => x(() =>
        import ("./f4emdhmpnt7z5af8.js"), __vite__mapDeps([44, 1, 3, 4, 2, 5, 45, 22, 23, 16, 24, 46, 17, 43, 47, 10, 48, 49, 50, 51, 52, 21, 15, 53, 54, 55]))),
    Gt = _(() => x(() =>
        import ("./fymkrlvs65gsh17v.js"), __vite__mapDeps([56, 1, 3, 4, 45, 2, 5, 22, 23, 16, 24, 46, 17, 43, 47, 10, 48, 49, 50, 51, 52, 21, 15, 53, 54, 55])).then(a => a.LegacyCoTMessage)),
    sa = _(() => x(() =>
        import ("./o9wnx2r6h1qfy4ir.js"), __vite__mapDeps([45, 1, 3, 4, 2, 5, 22, 23, 16, 24, 46, 17, 43, 47, 10, 48, 49, 50, 51, 52, 21, 15, 53, 54, 55])).then(a => a.CoT)),
    ea = _(() => x(() =>
        import ("./h7cgi5y3akol4cqi.js"), __vite__mapDeps([57, 1, 3, 4, 2, 5, 58])).then(a => a.JawboneMessage)),
    ta = _(async () => () => null),
    aa = _(() => x(() =>
        import ("./oba8e1s7hs6f0mpl.js"), __vite__mapDeps([59, 1, 3, 4, 2, 5])).then(a => a.HazelnutEnablePrompt));

function na(a) {
    if (a.some(c => c.type === e.SearchGPTQuery)) {
        const u = a.filter(d => d.type === P).flatMap(d => d.groups),
            o = u.flatMap(d => d.messages.map(m => {
                var f;
                return (f = m.metadata) == null ? void 0 : f.search_turns_count
            })).findLast(d => d != null);
        return o != null ? o > 1 : (function() {
            const m = u.filter(I => I.type === e.StructuredThoughts),
                f = u.filter(I => I.type === e.CoTSearchTool),
                g = (() => {
                    function I(E) {
                        return E.type === e.StructuredThoughts && E.messages.flatMap(h => h.content).some(h => h.content_type === lt.StructuredThoughts && h.thoughts.length > 0)
                    }
                    let j = !1;
                    for (const E of u)
                        if (E.type === e.CoTSearchTool) j = !0;
                        else if (I(E) && j) return !0;
                    return !1
                })();
            return m.length > 1 || f.length > 1 || g
        })()
    }
    return !0
}

function ia(a, c) {
    var u;
    if (a.type === P) {
        const o = X(a.groups);
        return ((u = o == null ? void 0 : o.messages[0].metadata) == null ? void 0 : u.is_visually_hidden_reasoning_group) && c === 0
    }
    return !1
}

function oa(a) {
    return a.type === P ? !1 : a.messages.some(c => Rt(c))
}

function _a({
    groupedMessagesToRender: a,
    allMessages: c,
    allGroupedMessages: u,
    conversation: o,
    isUserTurn: d,
    isCompletionRequestInProgress: m,
    isFeedbackEnabled: f,
    isFinalTurn: g,
    isFinalUserTurn: I,
    isFinalAssistantTurn: j,
    isGlauxTurn: E = !1,
    hasActiveRequest: h,
    onRequestCompletion: D,
    turnIndex: S,
    shouldGrowContainer: V = !0,
    isParagen: Z = !1,
    renderingView: we = "chat",
    isAgentTurn: z = !1,
    isAsyncCorrectionTurn: Ae = !1,
    isKAUR1BR5: Ce = !1,
    query: q = null,
    wasInterrupted: Le = !1,
    superWidgetContent: Pe = null,
    lastAgentMetadataNode: G,
    isWithinFirstAssistantTurns: De = !1,
    hasSearchSystemHint: ke = !1
}) {
    var ds, gs;
    const F = Xe(),
        {
            showDebugConversationTurns: M
        } = He(),
        [k] = Te(o.id, s => [s == null ? void 0 : s.mode]),
        ss = K(() => Ke(o)),
        es = K(() => Ue(o)),
        Re = rt(F),
        ve = K(() => Ye(F));
    let ts = u.some(s => s.type === e.Browsing || s.type === e.RetrievalBrowsing || s.type === e.SearchGPTQuery || s.type === e.n7jupd || s.type === e.q7dr546);
    const Oe = u.some(s => s.type === e.SearchGPTQuery),
        as = !d && ke && m && h && !Oe && ve,
        ns = L.useRef(!1);
    as && (ns.current = !0, ts = !0);
    const Ve = Te(o.id, s => {
            var n;
            for (let b = c.length - 1; b >= 0; b--) {
                const r = c[b],
                    w = (n = s == null ? void 0 : s.tree.getNodeIfExists(r.id)) == null ? void 0 : n.message,
                    Q = w ? Ot(w) : void 0;
                if (Q) return Object.assign({
                    conversation: o,
                    messageId: c[b].id
                }, Q)
            }
        }),
        ze = ct(() => Ze.count(qe.DEFAULT, "conversation_turn_grouped_messages.attempted_render_missing_type_f959b8c")),
        $ = X(c),
        is = Ge({
            clientThreadId: o.id,
            conversationMode: k
        }),
        Be = L.useCallback(({
            sourceEvent: s,
            requestedModelId: n,
            appendMessages: b,
            extraStreamParams: r,
            isReasoningSkipped: w
        }) => {
            $ && is({
                sourceEvent: s,
                nodeId: $.id,
                requestedModelId: n,
                appendMessages: b,
                extraStreamParams: r,
                isReasoningSkipped: w
            })
        }, [$, is]),
        {
            closeThreadSidebar: Ne
        } = mt(),
        os = Y(a, s => s.type !== e.Debug),
        Qe = M ? u.length - 1 : os,
        J = a.map((s, n) => {
            var _s, fs, xs, Ts, ys, bs, Is, js, Es, Ss, ps, ws, As, Cs, Ls, Ps, Ds, ks, Rs, vs, Os, Vs, zs, Bs, Ns, Qs, Fs, Ms, $s, Js, Ws, Hs, Ks, Us, Xs, Ys, Zs, qs, Gs, se, ee, te, ae, ne, ie, oe, le, re, ce, me, de, ge, he, ue, _e, fe;
            const b = h || oa(s),
                r = z ? n === os : n === Qe,
                w = na(a),
                Q = ia(s, n),
                T = n === u.length - 1 ? void 0 : u[n + 1],
                Me = (T == null ? void 0 : T.type) === P ? T.groups.at(-1) : T,
                v = n === 0 ? void 0 : a[n - 1],
                A = (v == null ? void 0 : v.type) !== P ? v : void 0,
                hs = A == null ? void 0 : A.type,
                us = A == null ? void 0 : A.messages,
                $e = c == null ? void 0 : c.filter(i => {
                    var l, y;
                    return ((l = i.metadata) == null ? void 0 : l.python_citation) || ((y = i.metadata) == null ? void 0 : y.container_citation)
                });
            if (s.type === P) {
                const i = s.groups[0].messages[0];
                return !w || Q ? null : t.jsx(sa, {
                    isStreaming: g && r && m,
                    latestError: Ve,
                    isFinalAssistantTurn: j,
                    messageGroups: s.groups,
                    nextMessageGroup: Me,
                    prevMessageGroup: A,
                    isAutoswitchOptOutEnabled: !!((_s = i.metadata) != null && _s.classifier_response),
                    handleSkipClick: l => {
                        Ne(), st.logEventWithStatsig("chatgpt_web_autoswitch_reasoning_skip_clicked", "chatgpt_web_autoswitch_reasoning_skip_clicked", {
                            conversationId: o.id,
                            messageId: s.groups[0].messages[0].id
                        }), ss && Be({
                            sourceEvent: l,
                            requestedModelId: ss.id,
                            isReasoningSkipped: !0,
                            isAgentTurn: z
                        })
                    },
                    isAgentTurn: z,
                    isAsyncCorrectionTurn: Ae,
                    isGlauxTurn: E,
                    isKAUR1BR5: Ce,
                    wasInterrupted: Le,
                    lastAgentMetadataNode: G,
                    conversation: o,
                    turnIndex: S,
                    currentGroupedMessageIndex: n
                }, "cot-" + i.id)
            }
            const Je = s && !et(s.messages[0]),
                We = ts && Je,
                C = [];
            if (We || C.push(t.jsx(Vt, {
                    className: "min-h-8",
                    message: s.messages[0],
                    isFeedbackEnabled: f,
                    isFinalUserTurn: I,
                    isWithinFirstAssistantTurns: De,
                    isCompletionInProgress: r && m,
                    hasActiveRequest: h,
                    turnIndex: S,
                    conversation: o,
                    isUserTurn: d,
                    prevGroupedMessageType: hs,
                    prevGroupedMessages: us,
                    citableMessages: $e,
                    superWidgetContent: Pe
                }, "text-message-" + s.messages[0].id)), M && C.push(t.jsx(ta, {
                    clientThreadId: o.id,
                    message: s.messages[0]
                }, "message-debug-" + s.messages[0].id)), s.type === e.Text && ((fs = s.messages[0].metadata) != null && fs[ye])) {
                const i = s.messages[0].metadata[ye];
                return t.jsxs(L.Fragment, {
                    children: [t.jsx(dt, {
                        browserContextMetadata: i,
                        className: be(zt(!0), "mb-1", "block", "[.text-message+&]:mt-5")
                    }), C]
                }, "group-" + s.messages[0].id)
            }
            if (as && r) return t.jsx(Ee, {
                clientThreadId: o.id,
                turnIndex: S,
                isRequestActive: h,
                isLastMessage: r,
                isLastTurnInConversation: g,
                query: q,
                searchModelQueries: [],
                searchResultGroups: [],
                showFastNav: !1,
                isForcedMessage: !0,
                shouldShowAnimatedBlackDot: !1
            }, "searchquery-forced-".concat(o.id, "-").concat(S));
            switch (s.type) {
                case e.Text:
                case e.MultiText:
                    if (s.type === e.Text) {
                        const i = (xs = s.messages[0]) == null ? void 0 : xs.metadata,
                            l = typeof(i == null ? void 0 : i.source) == "string" && (i == null ? void 0 : i.source) === "dream_followup";
                        return t.jsxs(L.Fragment, {
                            children: [l && v && t.jsxs("div", {
                                className: "mx-auto mt-8 mb-6 flex w-full items-center justify-center",
                                children: [t.jsx("div", {
                                    className: "h-px flex-1 bg-gray-200 dark:bg-gray-700",
                                    "aria-hidden": "true"
                                }), t.jsx("p", {
                                    className: "mx-3 shrink text-[14px] whitespace-nowrap text-gray-500",
                                    children: t.jsx(pe, {
                                        id: "threadLayout.proactiveAssistantFollowupDivider",
                                        defaultMessage: "Follow-up question"
                                    })
                                }), t.jsx("div", {
                                    className: "h-px flex-1 bg-gray-200 dark:bg-gray-700",
                                    "aria-hidden": "true"
                                })]
                            }, "proactive-divider-" + s.messages[0].id), C, z && t.jsx(pt, {
                                conversation: o,
                                currentGroupedMessage: s,
                                isLastMessage: r,
                                isLastTurnInConversation: g,
                                turnIndex: S,
                                lastAgentMetadataNode: G
                            }), t.jsx(wt, {
                                isUserTurn: d,
                                message: s.messages[0]
                            }), t.jsx(At, {
                                isUserTurn: d,
                                message: s.messages[0],
                                clientThreadId: o.id
                            })]
                        }, "group-" + s.messages[0].id)
                    } else return s.type === e.MultiText ? t.jsx(Qt, {
                        conversation: o,
                        messages: s.messages,
                        isCompletionInProgress: r && m,
                        isFeedbackEnabled: f,
                        hasActiveRequest: h,
                        prevGroupedMessageType: hs,
                        prevGroupedMessages: us
                    }, "multitext-" + ((ys = (Ts = s.messages[0]) == null ? void 0 : Ts.id) != null ? ys : n)) : s.type;
                case e.PIMBlock:
                    {
                        const i = X(c);
                        return k && i ? t.jsx(St, {
                            isFinalTurn: g,
                            hasActiveRequest: h,
                            conversationMode: k,
                            clientThreadId: o.id,
                            justification: (bs = i.metadata) == null ? void 0 : bs.pim_justification,
                            flaggedMessageId: (Is = i.metadata) == null ? void 0 : Is.pim_message_id,
                            children: C
                        }) : null
                    }
                case e.HazelnutEnablePrompt:
                    {
                        const i = s.messages[0],
                            l = i == null ? void 0 : i.content;
                        return (l == null ? void 0 : l.type) !== "hazelnut_enable_prompt" ? null : t.jsx(aa, {
                            conversationId: o.id,
                            hazelnutId: l.hazelnut_id,
                            hazelnutName: l.name
                        }, "hazelnut-enable-".concat(i.id))
                    }
                case e.n7jupd_n:
                    return t.jsx(Et, {});
                case e.Browsing:
                case e.RetrievalBrowsing:
                    {
                        const i = k != null && [U.GizmoInteraction, U.GizmoMagicCreate, U.GizmoTest].includes(k.kind),
                            l = es ? nt(es) : !1;
                        return t.jsx(Ht, {
                            messages: s.messages,
                            isRequestActive: h,
                            isLastMessageInTurn: r,
                            isUsingGizmo: i,
                            isUsingProject: l,
                            isRetrieval: s.type === e.RetrievalBrowsing
                        }, "browsing-" + ((Es = (js = s.messages[0]) == null ? void 0 : js.id) != null ? Es : n))
                    }
                case e.kaur1br5:
                    return t.jsx(Kt, {
                        messages: s.messages,
                        isRequestActive: h,
                        isLastMessageInTurn: r,
                        clientThreadId: o.id
                    }, "kaur1br5-tool-" + ((ps = (Ss = s.messages[0]) == null ? void 0 : Ss.id) != null ? ps : n));
                case e.SearchGPTQuery:
                    {
                        if (a.some(p => p.type === P) && w) return null;
                        const l = a.slice(n + 1).findLast(p => p.type === e.Text || p.type === e.CoTSearchTool),
                            y = c.findLast(p => je(p).length > 0),
                            O = new Set,
                            xe = [];
                        for (const p of c) {
                            const W = at(p);
                            if (W && W.length > 0)
                                for (const H of W) O.has(H) || (O.add(H), xe.push(H))
                        }
                        return t.jsx(Ee, {
                            clientThreadId: o.id,
                            turnIndex: S,
                            isRequestActive: h,
                            isLastMessage: r,
                            isLastTurnInConversation: g,
                            nextMessage: l == null ? void 0 : l.messages[0],
                            query: q,
                            searchResultGroups: je(y),
                            searchModelQueries: xe,
                            shouldShowAnimatedBlackDot: !ns.current
                        }, "searchquery-" + ((As = (ws = s.messages[0]) == null ? void 0 : ws.id) != null ? As : n))
                    }
                case e.StructuredThoughts:
                    return null;
                case e.ReasoningRecap:
                    return null;
                case e.n7jupd:
                    return null;
                case e.n7jupd_native_api_tool:
                case e.n7jupd_a:
                case e.n7jupd_x:
                    return null;
                case e.a8km123:
                    {
                        if (!s.messages.every(l => {
                                var y;
                                return !((y = l.metadata) != null && y.reasoning_status)
                            })) {
                            const l = Y(c, y => y.author.role === tt.Assistant && y.recipient === "all");
                            return t.jsx(Gt, {
                                conversation: o,
                                turnIndex: S,
                                isStreaming: (r || l < n) && m,
                                isFinalAssistantTurn: j,
                                messages: s.messages
                            }, "sum-" + ((Ls = (Cs = s.messages[0]) == null ? void 0 : Cs.id) != null ? Ls : n))
                        }
                        return t.jsx(qt, {
                            messages: s.messages,
                            isStreaming: r && m,
                            isCompletionRequestInProgress: m,
                            hasActiveRequest: h,
                            isLastMessage: r,
                            isFinalTurn: g,
                            isFeedbackEnabled: f,
                            conversation: o,
                            currentGroupedMessageIndex: n,
                            turnIndex: S
                        }, "sum-" + ((Ds = (Ps = s.messages[0]) == null ? void 0 : Ps.id) != null ? Ds : n))
                    }
                case e.f959b8c:
                    return ze(), null;
                case e.is_loading_message:
                    if (r && m) {
                        const i = s.messages[0],
                            l = Ie(i);
                        return t.jsx(jt, {
                            text: l
                        }, "loading-message-" + n)
                    } else return null;
                case e.b47u8ra0_t:
                    {
                        const i = s.messages[0],
                            l = "Reference Browser Memories?",
                            y = Ie(i);
                        return t.jsx(It, {
                            title: l,
                            description: y,
                            settingsTab: (Rs = (ks = i.metadata) == null ? void 0 : ks.b47u8ra0_t) != null ? Rs : "general",
                            clientThreadId: o.id,
                            parentMessageId: i.id
                        }, "b47u8ra0_t-" + n)
                    }
                case e.l1p9k3u:
                    return null;
                case e.b1de6e2_c:
                    return t.jsx(bt, {
                        messages: s.messages,
                        clientThreadId: o.id,
                        isLastMessage: r
                    }, "b1de6e2-" + ((Os = (vs = s.messages[0]) == null ? void 0 : vs.id) != null ? Os : n));
                case e.b1de6e2_s:
                    return t.jsx(yt, {
                        messages: s.messages,
                        clientThreadId: o.id
                    }, "b1de6e2_s-" + ((zs = (Vs = s.messages[0]) == null ? void 0 : Vs.id) != null ? zs : n));
                case e.b1de6e2_d:
                    return null;
                case e.b1de6e2_rm:
                    return t.jsx(Tt, {
                        messages: s.messages,
                        clientThreadId: o.id,
                        renderingView: we,
                        children: C
                    }, "b1de6e2_rm-" + ((Ns = (Bs = s.messages[0]) == null ? void 0 : Bs.id) != null ? Ns : n));
                case e.async_task_result_message:
                    return t.jsx(xt, {
                        clientThreadId: o.id,
                        messages: s.messages,
                        children: C
                    }, "async_task_result_message-" + ((Fs = (Qs = s.messages[0]) == null ? void 0 : Qs.id) != null ? Fs : n));
                case e.de1d73e:
                    if (Re) {
                        const i = n + 1 < u.length ? u[n + 1] : void 0;
                        return t.jsx(ea, {
                            clientThreadId: o.id,
                            currentGroupedMessage: s,
                            nextMessage: i && i.type === e.Text ? i.messages[0] : void 0,
                            isLastMessage: r,
                            isRequestActive: h
                        }, "jawbone-" + (($s = (Ms = s.messages[0]) == null ? void 0 : Ms.id) != null ? $s : n))
                    } else return null;
                case e.ParallelBrowsing:
                    return t.jsx(Wt, {
                        messages: s.messages
                    }, "parallel-" + ((Ws = (Js = s.messages[0]) == null ? void 0 : Js.id) != null ? Ws : n));
                case e.CodeInterpreter:
                    return t.jsx(Zt, {
                        messages: s.messages,
                        isRequestActive: h || m,
                        clientThreadId: o.id
                    }, "ada-" + ((Ks = (Hs = s.messages[0]) == null ? void 0 : Hs.id) != null ? Ks : n));
                case e.UserSettings:
                    {
                        const i = n + 1 < u.length ? u[n + 1] : void 0;
                        return (i == null ? void 0 : i.type) === e.UserSettings ? null : t.jsx(ft, {
                            messages: s.messages,
                            isRequestActive: h
                        }, "user-settings-" + ((Xs = (Us = s.messages[0]) == null ? void 0 : Us.id) != null ? Xs : n))
                    }
                case e.q7dr546:
                    return t.jsx(_t, {
                        messages: s.messages,
                        isLastMessage: r,
                        nextMessage: T
                    }, "q7dr546-" + ((Zs = (Ys = s.messages[0]) == null ? void 0 : Ys.id) != null ? Zs : n));
                case e.DILWidget:
                    {
                        const i = s.messages[0],
                            l = (qs = i == null ? void 0 : i.metadata) == null ? void 0 : qs.chatgpt_sdk,
                            y = l == null ? void 0 : l.dil,
                            O = (Gs = l == null ? void 0 : l.tool_response_metadata) == null ? void 0 : Gs.kakao_widget;
                        return O ? t.jsx("div", {
                            children: t.jsx(ut, {
                                rootWidget: O,
                                dil: y
                            })
                        }, "dil-".concat((se = i == null ? void 0 : i.id) != null ? se : n)) : null
                    }
                case e.JITPlugin:
                    return t.jsx(Xt, {
                        messages: s.messages,
                        nextMessage: (T == null ? void 0 : T.type) === e.JITPlugin ? T.messages[0] : void 0,
                        clientThreadId: o.id,
                        isLastTurnInConversation: g,
                        isLastMessageInTurn: r,
                        onRequestCompletion: D
                    }, "jit-" + ((te = (ee = s.messages[0]) == null ? void 0 : ee.id) != null ? te : n));
                case e.Mercury:
                    return null;
                case e.APIToolElicitation:
                    return t.jsx(Yt, {
                        messages: s.messages,
                        nextMessage: (T == null ? void 0 : T.type) === e.APIToolElicitation ? T.messages[0] : void 0,
                        clientThreadId: o.id,
                        isLastTurnInConversation: g,
                        isLastMessageInTurn: r,
                        onRequestCompletion: D
                    }, "api-tool-elicitation-" + ((ne = (ae = s.messages[0]) == null ? void 0 : ae.id) != null ? ne : n));
                case e.t2uay3k:
                    return t.jsx(Jt, {
                        messages: s.messages,
                        clientThreadId: o.id,
                        isParagen: Z,
                        isLastTurnInConversation: g
                    }, "t2uay3k-" + ((oe = (ie = s.messages[0]) == null ? void 0 : ie.id) != null ? oe : n));
                case e.Dalle:
                    return t.jsx(Ft, {
                        messages: s.messages,
                        clientThreadId: o.id,
                        disableClickThru: Z
                    }, "dalle-" + ((re = (le = s.messages[0]) == null ? void 0 : le.id) != null ? re : n));
                case e.GizmoEditor:
                    return t.jsx(Bt, {
                        messages: s.messages
                    }, "gizmo-editor-" + ((me = (ce = s.messages[0]) == null ? void 0 : ce.id) != null ? me : n));
                case e.oiw209h:
                    return t.jsx(Mt, {
                        messages: s.messages,
                        clientThreadId: o.id
                    }, "oiw209h-" + ((ge = (de = s.messages[0]) == null ? void 0 : de.id) != null ? ge : n));
                case e.n7jupd_p:
                    return t.jsx(ht, {});
                case e.Canmore:
                    return t.jsx(gt, {
                        messages: s.messages,
                        allTurnMessages: c,
                        isFinalTurn: g,
                        isRequestActive: b,
                        clientThreadId: o.id,
                        isUserTurn: d
                    }, "canmore-" + ((ue = (he = s.messages[0]) == null ? void 0 : he.id) != null ? ue : n));
                case e.Container:
                case e.Oboe:
                    return null;
                case e.Croquette:
                    return null;
                case e.Debug:
                    return M ? t.jsx(Nt, {
                        message: s.messages[0]
                    }, "debug-" + s.messages[0].id) : null;
                case e.SearchResult:
                    return t.jsx(Ut, {
                        messages: s.messages
                    }, "search-result-" + ((fe = (_e = s.messages[0]) == null ? void 0 : _e.id) != null ? fe : n));
                case e.Mochi:
                    return null;
                case e.CoTSearchTool:
                    return null;
                case e.SuperWidget:
                    return null;
                case e.n7jupd_image_gen:
                    return null;
                case e.e1ld0dvz:
                    return null;
                case e.Glaux:
                    return t.jsx($t, {
                        messages: s.messages,
                        isLastMessage: r
                    }, "glaux-" + s.messages[0].id);
                case e.Strix:
                    return null;
                case e.xdeo6rao:
                    return null
            }
        }),
        Fe = kt(),
        {
            wordFadeType: R,
            animationDurationMs: ls
        } = Ct(),
        B = L.useRef([]),
        rs = L.useRef(void 0),
        cs = L.useRef(null),
        N = !d && g && m,
        ms = (ds = c[0]) == null ? void 0 : ds.id;
    return it(() => {
        if (R !== "indexed" || !N) return;
        const s = cs.current;
        if (!s) return;
        rs.current !== ms && (rs.current = ms, B.current = []);
        const n = s.getAnimations({
            subtree: !0
        }).filter(b => b.animationName === Se["fade-in"]);
        if (n.length !== 0) {
            const b = ca({
                now: performance.now(),
                previousStartTimes: B.current,
                groupCount: n.length
            });
            B.current = b;
            for (let r = 0; r < n.length; r++) n[r].startTime = b[r]
        } else B.current = []
    }, [J, R, N]), t.jsx("div", {
        className: be("flex max-w-full flex-col", {
            [Se.root]: R === "indexed" && N,
            grow: V
        }),
        style: R === "indexed" ? {
            "--duration": "".concat(ls, "ms")
        } : void 0,
        ref: cs,
        children: t.jsx(ot, {
            name: "GroupedMessages",
            fallback: la,
            children: d ? J : t.jsxs(Lt, {
                isDisabled: !N || R !== "delay",
                defaultAnimationDurationPerSegmentMs: ls,
                children: [Pt(F) && g && t.jsx(Dt, {
                    isStreaming: m,
                    debug: Fe
                }), J]
            }, (gs = c[0]) == null ? void 0 : gs.id)
        })
    })
}

function la({
    error: a
}) {
    return t.jsxs(vt, {
        type: "danger",
        children: [t.jsx(pe, {
            id: "5eGo3w",
            defaultMessage: "Unable to display this message due to an error."
        }), !1]
    })
}

function ra(a, c, u) {
    if (a.length < 2 || c <= 0) return 0;
    const o = c / Math.log(2);
    a = [...a].sort((f, g) => f - g);
    let d = 0,
        m = 0;
    for (let f = a.length - 1; f > 0; --f) {
        const g = Math.exp(-(u - a[f]) / o);
        if (d > 0 && g / d < .01) break;
        const I = a[f] - a[f - 1];
        d += g, m += g * I
    }
    return d === 0 ? 0 : d / m
}

function ca({
    now: a,
    previousStartTimes: c,
    groupCount: u,
    initialRate: o = 50,
    halfLife: d = 1
}) {
    var E;
    const m = c.slice(0, Y(c, h => h <= a) + 1),
        f = m.length < 2 ? o / 1e3 : Math.max(.01, ra(m, d * 1e3, a)),
        g = u - m.length;
    let I = (E = m[m.length - 1]) != null ? E : 0,
        j = 1;
    for (let h = 0; h < g; h++) {
        const D = f * 1e3 * j;
        g < D ? j *= .8 : g > D && (j *= 1.5);
        const S = 1 / (f * j),
            V = Math.max(a, I + S);
        m.push(V), I = V
    }
    return m
}
export {
    _a as C
};
//# sourceMappingURL=i5kvudettvxsr7pw.js.map