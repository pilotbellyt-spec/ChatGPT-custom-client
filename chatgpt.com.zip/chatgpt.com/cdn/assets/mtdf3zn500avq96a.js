var F = Object.defineProperty,
    w = Object.defineProperties;
var B = Object.getOwnPropertyDescriptors;
var M = Object.getOwnPropertySymbols;
var H = Object.prototype.hasOwnProperty,
    L = Object.prototype.propertyIsEnumerable;
var P = (s, e, t) => e in s ? F(s, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : s[e] = t,
    R = (s, e) => {
        for (var t in e || (e = {})) H.call(e, t) && P(s, t, e[t]);
        if (M)
            for (var t of M(e)) L.call(e, t) && P(s, t, e[t]);
        return s
    },
    U = (s, e) => w(s, B(e));
import {
    c as A,
    j as l,
    M as T,
    L as V
} from "./fg33krlcm0qyi6yw.js";
import {
    ca as $
} from "./k15yxxoybkkir2ou.js";
import {
    l as _,
    bb as z
} from "./dykg4ktvbu3mhmdo.js";
var K = (s => (s.DIRECT_PURCHASE = "direct_purchase", s.CHECKOUT = "checkout", s))(K || {});

function O(s) {
    "use forget";
    const e = A.c(25),
        {
            feature: t,
            type: r
        } = s,
        {
            label: c,
            icon: x
        } = t,
        y = z(),
        m = x != null ? x : $,
        i = r === "checkout",
        p = r === "direct_purchase",
        o = i || p,
        a = S;
    let n;
    e[0] !== c ? (n = a(c), e[0] = c, e[1] = n) : n = e[1];
    const u = n,
        C = i && "py-2";
    let f;
    e[2] !== C ? (f = _("relative", C), e[2] = C, e[3] = f) : f = e[3];
    const E = (i || p) && "items-center";
    let d;
    e[4] !== E ? (d = _("text-l flex cursor-default justify-start gap-3.5", E), e[4] = E, e[5] = d) : d = e[5];
    const v = o ? y ? "#8F8DF6" : "#5856D6" : "primary";
    let h;
    e[6] !== m || e[7] !== v ? (h = l.jsx(m, {
        className: "h-5 w-5 shrink-0",
        color: v
    }), e[6] = m, e[7] = v, e[8] = h) : h = e[8];
    const D = i && "text-[15px]!",
        I = p && "text-black!";
    let g;
    e[9] !== D || e[10] !== I ? (g = _("text-token-text-primary min-w-0 font-normal", D, I), e[9] = D, e[10] = I, e[11] = g) : g = e[11];
    let k;
    e[12] !== c || e[13] !== u ? (k = l.jsx(T, U(R({}, c), {
        values: u
    })), e[12] = c, e[13] = u, e[14] = k) : k = e[14];
    let j;
    e[15] !== g || e[16] !== k ? (j = l.jsx("div", {
        className: "flex flex-1 items-start gap-2",
        children: l.jsx("span", {
            className: g,
            children: k
        })
    }), e[15] = g, e[16] = k, e[17] = j) : j = e[17];
    let b;
    e[18] !== j || e[19] !== d || e[20] !== h ? (b = l.jsxs("div", {
        className: d,
        children: [h, j]
    }), e[18] = j, e[19] = d, e[20] = h, e[21] = b) : b = e[21];
    let N;
    return e[22] !== b || e[23] !== f ? (N = l.jsx("li", {
        className: f,
        children: b
    }), e[22] = b, e[23] = f, e[24] = N) : N = e[24], N
}

function S(s) {
    return {
        link: e => {
            var t;
            return l.jsx(V, {
                className: "underline",
                target: "_blank",
                rel: "noopener noreferrer",
                to: (t = s.link) != null ? t : "",
                children: e
            })
        },
        b: q,
        article: e => {
            var t;
            return l.jsx(V, {
                className: "underline",
                target: "_blank",
                rel: "noopener noreferrer",
                to: (t = s.article) != null ? t : "",
                children: e
            })
        }
    }
}

function q(s) {
    return l.jsx("strong", {
        children: s
    })
}

function X(s) {
    "use forget";
    const e = A.c(12),
        {
            advertisedFeatures: t,
            type: r,
            isTeamColumn: c,
            isBusinessUpgradeV2CopyEnabled: x
        } = s,
        y = x === void 0 ? !1 : x;
    if (!(t != null && t.length)) return null;
    const m = c && !y ? "gap-3" : "gap-5",
        i = r === "checkout" && "mb-3 gap-0!",
        p = r === "direct_purchase" && "gap-3!";
    let o;
    e[0] !== m || e[1] !== i || e[2] !== p ? (o = _("mb-2 flex flex-col", m, i, p), e[0] = m, e[1] = i, e[2] = p, e[3] = o) : o = e[3];
    let a;
    if (e[4] !== t || e[5] !== r) {
        let u;
        e[7] !== r ? (u = (C, f) => l.jsx(O, {
            feature: C,
            type: r
        }, f), e[7] = r, e[8] = u) : u = e[8], a = t.map(u), e[4] = t, e[5] = r, e[6] = a
    } else a = e[6];
    let n;
    return e[9] !== o || e[10] !== a ? (n = l.jsx("ul", {
        className: o,
        children: a
    }), e[9] = o, e[10] = a, e[11] = n) : n = e[11], n
}
export {
    K as A, X as P
};
//# sourceMappingURL=mtdf3zn500avq96a.js.map