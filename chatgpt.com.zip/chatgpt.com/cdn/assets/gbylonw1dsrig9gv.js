import {
    c as w,
    r as C,
    j as n,
    M as N
} from "./fg33krlcm0qyi6yw.js";
import {
    u0 as L,
    u1 as _,
    b as M,
    _ as P,
    c0 as S,
    a9 as O
} from "./dykg4ktvbu3mhmdo.js";
import {
    E as z
} from "./jdg49hmintmo4ij6.js";
import {
    E as $
} from "./iyee7iaydnyssoa4.js";
import {
    E as y
} from "./ohbt708he61xvuqb.js";

function B(o) {
    "use forget";
    const e = w.c(8),
        [i, s] = C.useState(!1);
    let t;
    e[0] !== o ? (t = d => {
        o && s(d)
    }, e[0] = o, e[1] = t) : t = e[1];
    const a = t;
    let r, l;
    e[2] !== o ? (r = () => {
        if (!o) return;
        const d = function(g) {
            g.persisted && s(!1)
        };
        return window.addEventListener("pagehide", d), () => window.removeEventListener("pagehide", d)
    }, l = [o], e[2] = o, e[3] = r, e[4] = l) : (r = e[3], l = e[4]), C.useEffect(r, l);
    let c;
    return e[5] !== i || e[6] !== a ? (c = [i, a], e[5] = i, e[6] = a, e[7] = c) : c = e[7], c
}

function W(o) {
    "use forget";
    const e = w.c(3);
    let i, s;
    e[0] !== o ? (i = () => {
        const t = function(r) {
            r.persisted && o()
        };
        return window.addEventListener("pagehide", t), () => window.removeEventListener("pagehide", t)
    }, s = [o], e[0] = o, e[1] = i, e[2] = s) : (i = e[1], s = e[2]), C.useEffect(i, s)
}
const x = {
        openAI: y,
        apple: z,
        google: L,
        microsoft: $
    },
    F = {
        openAI: x.openAI,
        apple: x.apple,
        google: x.google,
        microsoft: x.microsoft
    },
    v = o => {
        "use forget";
        const e = w.c(4),
            {
                name: i,
                size: s,
                className: t
            } = o,
            a = F[i];
        let r;
        return e[0] !== a || e[1] !== t || e[2] !== s ? (r = n.jsx(a, {
            height: s,
            width: s,
            className: t
        }), e[0] = a, e[1] = t, e[2] = s, e[3] = r) : r = e[3], r
    },
    q = o => {
        "use forget";
        const e = w.c(18),
            {
                provider: i,
                className: s,
                onClick: t,
                disabled: a,
                color: r
            } = o,
            l = r === void 0 ? "secondary" : r;
        let c;
        e[0] !== i ? (c = function() {
            switch (i) {
                case "apple":
                    return {
                        logo: n.jsx(v, {
                            name: "apple",
                            size: 20
                        }),
                        ddActionName: "continue_with_apple",
                        children: n.jsx(N, {
                            id: "socialLogin.apple",
                            defaultMessage: "Continue with Apple"
                        })
                    };
                case "google":
                    return {
                        logo: n.jsx(v, {
                            name: "google",
                            size: 19
                        }),
                        ddActionName: "continue_with_google",
                        children: n.jsx(N, {
                            id: "login.google",
                            defaultMessage: "Continue with Google"
                        })
                    };
                case "microsoft":
                    return {
                        logo: n.jsx(v, {
                            name: "microsoft",
                            size: 17
                        }),
                        ddActionName: "continue_with_microsoft",
                        children: n.jsx(N, {
                            id: "login.microsoft",
                            defaultMessage: "Continue with Microsoft"
                        })
                    }
            }
        }(), e[0] = i, e[1] = c) : c = e[1];
        const {
            logo: d,
            ddActionName: u,
            children: g
        } = c, E = M();
        let m;
        e[2] !== E ? (m = _(E), e[2] = E, e[3] = m) : m = e[3];
        const [j, A] = B(m);
        let p;
        e[4] !== u || e[5] !== t || e[6] !== A ? (p = I => {
            A(!0), P.addAction("login-form.".concat(u)), t == null || t(I)
        }, e[4] = u, e[5] = t, e[6] = A, e[7] = p) : p = e[7];
        let f;
        e[8] !== g || e[9] !== j || e[10] !== d ? (f = j ? n.jsxs(n.Fragment, {
            children: [n.jsx(S, {
                className: "text-token-text-tertiary"
            }), n.jsx("span", {
                className: "sr-only",
                children: g
            })]
        }) : n.jsxs(n.Fragment, {
            children: [n.jsx("span", {
                className: "relative grid h-4 w-4 place-items-center",
                children: n.jsx("span", {
                    className: "absolute",
                    children: d
                })
            }), g]
        }), e[8] = g, e[9] = j, e[10] = d, e[11] = f) : f = e[11];
        let h;
        return e[12] !== s || e[13] !== l || e[14] !== a || e[15] !== p || e[16] !== f ? (h = n.jsx(O, {
            type: "button",
            onClick: p,
            className: s,
            contentWrapperClassName: "gap-2",
            color: l,
            disabled: a,
            children: f
        }), e[12] = s, e[13] = l, e[14] = a, e[15] = p, e[16] = f, e[17] = h) : h = e[17], h
    };
export {
    q as S, W as a, B as u
};
//# sourceMappingURL=gbylonw1dsrig9gv.js.map