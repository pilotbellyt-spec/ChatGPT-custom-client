var W = Object.defineProperty,
    M = Object.defineProperties;
var N = Object.getOwnPropertyDescriptors;
var u = Object.getOwnPropertySymbols;
var b = Object.prototype.hasOwnProperty,
    v = Object.prototype.propertyIsEnumerable;
var d = (e, s, t) => s in e ? W(e, s, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : e[s] = t,
    i = (e, s) => {
        for (var t in s || (s = {})) b.call(s, t) && d(e, t, s[t]);
        if (u)
            for (var t of u(s)) v.call(s, t) && d(e, t, s[t]);
        return e
    },
    m = (e, s) => M(e, N(s));
import {
    j as a,
    M as p,
    f as A,
    ad as y,
    a as R,
    e as I,
    r as x
} from "./fg33krlcm0qyi6yw.js";
import {
    ag as k,
    aN as l,
    C as P,
    x as E,
    I as L,
    b as w,
    m as T,
    r0 as F,
    fG as O,
    r1 as z,
    io as U,
    c0 as B,
    ab as D,
    aS as Y,
    ih as q,
    aa as G
} from "./dykg4ktvbu3mhmdo.js";
import {
    P as h,
    R as K,
    I as Q
} from "./k15yxxoybkkir2ou.js";
import {
    u as V,
    a as $
} from "./k2oaaf8ac9lafsub.js";

function H({
    workspace: e
}) {
    const s = R(),
        t = k(),
        r = w(),
        c = I(),
        o = T(),
        [S, g] = x.useState(!1),
        j = x.useCallback(() => {
            g(!0);
            const {
                willRedirect: n
            } = F(s, e.id, r, c, o);
            O.set(r, !1), n || z()
        }, [s, e.id, r, c, o]),
        C = $(e);
    return e.structure === l.PERSONAL && !t ? null : a.jsx(U, {
        as: Q,
        hasManagedFocus: !0,
        value: e.id,
        role: "radio",
        onPointerMove: n => n.currentTarget.focus(),
        onClick: j,
        size: "large",
        icon: e.structure === l.PERSONAL ? a.jsx(q, {
            user: t
        }) : a.jsx(G, {
            src: e.data.profilePictureUrl
        }),
        label: C,
        trailing: S ? a.jsx(B, {}) : a.jsxs(a.Fragment, {
            children: [a.jsx(D, {
                className: "icon-sm group-data-[state=off]:hidden"
            }), a.jsx(Y, {
                className: "icon-sm group-data-[state=on]:hidden"
            })]
        }),
        disabled: !e.canAccessWithCurrentSession
    })
}

function J({
    data: e
}) {
    const s = w(),
        t = L(s);
    return a.jsx(K, {
        type: "single",
        className: "static flex w-full flex-col rounded-2xl border py-1.5",
        value: t == null ? void 0 : t.id,
        children: e.map(r => a.jsx(H, {
            workspace: r
        }, r.id))
    })
}

function ae() {
    var c;
    const {
        data: e
    } = V(), s = k(), t = (c = s == null ? void 0 : s.email) != null ? c : "";
    if (!e || e.length === 0) return null;
    h.markStart("WorkspaceSwitcherModal"), h.markRendered("WorkspaceSwitcherModal");
    const r = e.filter(o => o.structure === l.WORKSPACE);
    return a.jsx(P, {
        testId: "modal-workspace-switcher",
        isOpen: !0,
        onClose: E,
        type: "success",
        size: "normal",
        title: a.jsxs("div", {
            className: "flex flex-col",
            children: [a.jsx(p, i({}, f.workspaceSwitcherTitle)), a.jsx("span", {
                className: "text-token-text-secondary mt-0.5 text-sm",
                children: t
            })]
        }),
        children: a.jsxs("div", {
            className: "flex w-full flex-col items-center justify-between",
            children: [a.jsx(J, {
                data: e
            }), a.jsx("span", {
                className: "text-token-text-secondary mt-4 text-sm",
                children: a.jsx(p, m(i({}, f.workspaceSwitcherDisclaimer), {
                    values: {
                        workspaces: a.jsx("span", {
                            className: "contents font-bold",
                            children: a.jsx(y, {
                                value: r.map(o => o.data.name)
                            })
                        }),
                        numWorkspaces: r.length
                    }
                }))
            })]
        })
    })
}
const f = A({
    workspaceSwitcherTitle: {
        id: "workspaceSwitcher.title",
        defaultMessage: "Select a workspace"
    },
    workspaceSwitcherDisclaimer: {
        id: "workspaceSwitcher.disclaimer",
        defaultMessage: "You've been added to the {workspaces} {numWorkspaces, plural, one {workspace} other {workspaces}}. You can switch between workspaces at any time."
    }
});
export {
    J as W, ae as a
};
//# sourceMappingURL=j63amn1eooyu8ua6.js.map