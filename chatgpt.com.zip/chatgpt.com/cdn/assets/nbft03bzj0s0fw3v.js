import {
    c as e,
    s as o
} from "./dykg4ktvbu3mhmdo.js";
const a = e(o, "19c64a", 20, 20);
export {
    a as E
};
//# sourceMappingURL=nbft03bzj0s0fw3v.js.map