import {
    r4 as h
} from "./dykg4ktvbu3mhmdo.js";
import {
    c5 as o
} from "./k15yxxoybkkir2ou.js";

function v(t) {
    return "children" in t
}
const E = t => t.type === "text" && "value" in t && typeof t.value == "string",
    n = "hiveTranscript",
    u = /(::hiveTranscript\{([^}]+)\})/g,
    f = /\btimestamp\s*=\s*["']?(\d+)["']?(?=\s|,|$)/,
    m = () => t => {
        o(t, e => {
            if (e.type !== "paragraph" && e.type !== "tableCell" || !v(e) || !Array.isArray(e.children)) return;
            const r = [];
            for (const i of e.children)
                if (E(i) && i.value.includes("::".concat(n))) {
                    u.lastIndex = 0;
                    let s = 0,
                        a;
                    for (;
                        (a = u.exec(i.value)) != null;) {
                        a.index > s && r.push({
                            type: "text",
                            value: i.value.slice(s, a.index)
                        });
                        const p = a[2],
                            c = f.exec(p),
                            l = c == null ? void 0 : c[1];
                        l && Number.isInteger(Number(l)) && r.push({
                            type: "textDirective",
                            name: n,
                            attributes: {
                                timestamp: l
                            },
                            data: {
                                hName: n,
                                hProperties: {
                                    timestamp: l
                                }
                            },
                            children: [],
                            position: i.position
                        }), s = u.lastIndex
                    }
                    s < i.value.length && r.push({
                        type: "text",
                        value: i.value.slice(s)
                    })
                } else r.push(i);
            e.children = r
        })
    },
    T = Object.freeze(Object.defineProperty({
        __proto__: null,
        HIVE_LOG_DIRECTIVE_NAME: n,
        hiveLogDirectivePlugin: m
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    _ = [h, n],
    d = () => t => {
        o(t, "textDirective", e => {
            _.includes(e.name) || (e.type = "text", e.value = ":".concat(e.name))
        })
    };
export {
    n as H, m as a, T as b, d as f, _ as h, v as i
};
//# sourceMappingURL=jsd0vs4cv2vks3ah.js.map