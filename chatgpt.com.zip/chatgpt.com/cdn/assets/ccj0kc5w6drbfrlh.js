import {
    c as e,
    s as o
} from "./dykg4ktvbu3mhmdo.js";
const p = e(o, "b9ef21", 20, 20);
export {
    p as S
};
//# sourceMappingURL=ccj0kc5w6drbfrlh.js.map