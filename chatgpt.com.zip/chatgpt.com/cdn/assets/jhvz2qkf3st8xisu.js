import {
    c as e,
    s as o
} from "./dykg4ktvbu3mhmdo.js";
const r = e(o, "86dc94", 20, 20);
export {
    r as E
};
//# sourceMappingURL=jhvz2qkf3st8xisu.js.map