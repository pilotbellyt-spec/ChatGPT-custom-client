import {
    e as V,
    r as ae,
    a as ze,
    j as t,
    c as H,
    M as g
} from "./fg33krlcm0qyi6yw.js";
import {
    de as Ye,
    m as $e,
    H as Ge,
    P as ee,
    L as Y,
    N as Me,
    ad as re,
    im as Ke,
    b$ as Pe,
    C as He,
    b as Qe,
    $ as ye,
    E as qe,
    Z as he,
    S as we,
    l as _e,
    c0 as Ve,
    Y as q
} from "./dykg4ktvbu3mhmdo.js";
import {
    fQ as Ze,
    iq as Je,
    fP as We,
    fR as ve,
    e7 as Xe,
    cQ as et,
    dg as tt,
    ir as se,
    is as ne,
    it as je,
    iu as Ce,
    iv as be,
    iw as le
} from "./k15yxxoybkkir2ou.js";
import {
    i as at,
    C as st
} from "./gogo7bs85ip5x228.js";
import {
    a as Se,
    g as nt
} from "./jd9zt1u141h04j00.js";
import {
    p as oe
} from "./by32wbrf3h6krwuu.js";
const lt = Ye(o => ({
    recentlyDowngraded: !1,
    recentlyUpgraded: !1,
    recentlyCanceled: !1,
    setRecentlyDowngraded: e => o({
        recentlyDowngraded: e
    }),
    setRecentlyUpgraded: e => o({
        recentlyUpgraded: e
    }),
    setRecentlyCanceled: e => o({
        recentlyCanceled: e
    })
}));

function Ue(o) {
    switch (o) {
        case Y.FREE:
            return "chatgptfreeplan";
        case Y.GO:
            return "chatgptgoplan";
        case Y.PLUS:
            return "chatgptplusplan";
        case Y.PRO:
            return "chatgptpro";
        case Y.SELF_SERVE_BUSINESS:
            return "chatgptteamplan";
        default:
            throw new Error("Invalid plan type: ".concat(o))
    }
}

function $(o) {
    return tt(o.toLowerCase())
}

function ot({
    isOpen: o,
    onClose: e,
    accountId: a,
    initialPlanType: r,
    updatedPlanType: n,
    billingDetails: u,
    promoMetadata: l,
    promoCode: d,
    fullPriceResumeDateString: f,
    onPromoClose: c
}) {
    "use no forget";
    var ge, fe, me;
    const h = Qe(),
        i = V(),
        R = $e(),
        s = Ge(),
        [x, P] = ae.useState(!1),
        w = (l == null ? void 0 : l.plan_type_change) === "equal",
        m = r === n && !w,
        M = Se(r) < Se(n),
        j = Ue(n);
    ae.useEffect(() => {
        ee.logTogglePlanManagementModal({
            isOpen: !0
        })
    }, []);
    const y = () => {
            ee.logTogglePlanManagementModal({
                isOpen: !1
            }), e()
        },
        F = Ze(a),
        C = Je(a),
        b = We(a),
        {
            data: p,
            isError: S,
            isLoading: U
        } = ve(a, void 0, j, void 0, w),
        {
            data: O,
            isLoading: k,
            error: E
        } = Xe({
            countryCode: u.country,
            currency: u.currency,
            ctx: h
        });
    !m && (S || E != null) && ((s == null ? void 0 : s.planType) === Y.SELF_SERVE_BUSINESS ? R.warning(i.formatMessage({
        id: "planManagement.errorUpgradingTeam",
        defaultMessage: "Updates to {capitalizedUpdatedPlanType} aren't yet supported for users with Team subscriptions"
    }, {
        capitalizedUpdatedPlanType: $(n)
    }), {
        hasCloseButton: !0
    }) : R.warning(i.formatMessage({
        id: "planManagement.errorFetchingPreview",
        defaultMessage: "There was a problem updating your subscription"
    }), {
        hasCloseButton: !0
    }), e());
    const A = K => new Intl.DateTimeFormat(i.locale, {
            year: "numeric",
            month: "short",
            day: "numeric"
        }).format(K),
        D = s == null ? void 0 : s.getDaysUntilPlanRenews();
    let _ = typeof D == "number" && D > 0 ? Me(new Date, D) : null,
        v = _ ? A(_) : "";
    const N = s == null ? void 0 : s.getDaysUntilSubscriptionCancelAt();
    _ && typeof D == "number" && typeof N == "number" && N > 0 && N > D && (_ = Me(new Date, N), v = A(_));
    const {
        recentlyCanceled: T,
        setRecentlyUpgraded: I,
        setRecentlyDowngraded: L
    } = lt(), B = (s == null ? void 0 : s.willRenewSubscription()) || T, [z, G] = ae.useState(!1), Z = ze();
    if (!s) return null;
    const de = w ? _ : p != null && p.renewal_date ? new Date(p.renewal_date) : null,
        ce = de ? de.toLocaleDateString(i.locale, {
            year: "numeric",
            month: "long",
            day: "numeric"
        }) : i.formatMessage(re.notApplicable),
        ue = f ? new Date(f).toLocaleDateString(i.locale, {
            year: "numeric",
            month: "long",
            day: "numeric"
        }) : i.formatMessage(re.notApplicable),
        J = Ke(u.currency),
        {
            goCost: ke,
            plusCost: Ae,
            proCost: Te
        } = Ee(u.currency, O),
        Ie = (fe = (ge = l == null ? void 0 : l.duration) == null ? void 0 : ge.num_periods) != null ? fe : 1,
        {
            formattedDiscountedCost: W
        } = l != null && l.discount && !k && !E && O ? nt(i, Ie, l.discount, (me = J.code.defaultMessage) == null ? void 0 : me.toString(), O, n) : {
            formattedDiscountedCost: null
        },
        te = async K => {
            var pe;
            P(!0);
            try {
                if (m) await C.mutateAsync(a), R.success(v === "" ? i.formatMessage({
                    id: "planManagement.successfullyRenewedSubscription2",
                    defaultMessage: "Your subscription has been renewed."
                }) : i.formatMessage({
                    id: "planManagement.successfullyRenewedSubscription",
                    defaultMessage: "Your subscription has been renewed. Your subscription will auto-renew on {renewalDate}."
                }, {
                    renewalDate: v
                }), {
                    hasCloseButton: !0
                }), ee.logEvent("Renew Plan Success", {
                    planType: K
                }), ye.logEvent("chatgpt_renew_plan_success", null, {
                    planType: K
                });
                else if (w && d) await F.mutateAsync({
                    accountId: a,
                    updatedPlan: void 0,
                    updatedPriceInterval: void 0,
                    updatedSeats: void 0,
                    updatedPromoCode: d
                }), R.success(v === "" ? i.formatMessage({
                    id: "planManagement.successfullyRenewedSubscriptionPromotion",
                    defaultMessage: "Your subscription has been updated and will auto-renew at the promotional rate of {promotionalCost} during your next billing cycle."
                }, {
                    promotionalCost: W
                }) : i.formatMessage({
                    id: "planManagement.successfullyRenewedSubscriptionPromotion2",
                    defaultMessage: "Your subscription has been updated and will auto-renew at your promotional rate of {promotionalCost} on {renewalDate}."
                }, {
                    renewalDate: v,
                    promotionalCost: W
                }), {
                    hasCloseButton: !0
                });
                else {
                    B || (await C.mutateAsync(a), G(!0));
                    const Le = d ? void 0 : j;
                    await F.mutateAsync({
                        accountId: a,
                        updatedPlan: Le,
                        updatedPriceInterval: void 0,
                        updatedSeats: void 0,
                        updatedPromoCode: d != null ? d : void 0
                    });
                    const xe = M ? i.formatMessage({
                        id: "planManagement.successfullyUpdatedSubscription",
                        defaultMessage: "You're now subscribed to ChatGPT {capitalizedUpdatedPlanType}"
                    }, {
                        capitalizedUpdatedPlanType: $(n)
                    }) : i.formatMessage({
                        id: "planManagement.updatedSubscriptionToPlus",
                        defaultMessage: "Your subscription has been updated. Your subscription will change to {capitalizedUpdatedPlanType} on {renewalDateFormatted}."
                    }, {
                        renewalDateFormatted: ce,
                        capitalizedUpdatedPlanType: $(n)
                    });
                    if (K !== n) {
                        const Oe = M ? "Upgrade Plan Success" : "Downgrade Plan Success",
                            Be = M ? "chatgpt_upgrade_plan_success" : "chatgpt_downgrade_plan_success";
                        ee.logEvent(Oe, {
                            fromPlan: K,
                            toPlan: n
                        }), ye.logEvent(Be, null, {
                            fromPlan: K,
                            toPlan: n
                        }), M ? I(!0) : L(!0), R.success(xe, {
                            hasCloseButton: !0
                        })
                    }
                    localStorage.setItem("subscriptionUpdateMessage_".concat(s.id), xe)
                }
                et(), Z.invalidateQueries(qe());
                const Q = he.getItem(we.CheckoutFrom);
                at(Q) && (he.removeItem(we.CheckoutFrom), window.location.href = st[Q]), e()
            } catch (Q) {
                ((pe = Q == null ? void 0 : Q.detail) == null ? void 0 : pe.error_type) === "card_declined" ? R.warning(i.formatMessage({
                    id: "planManagement.cardDeclinedError",
                    defaultMessage: "Payment error. Your card may be invalid or authentication may be needed."
                }), {
                    hasCloseButton: !0
                }): R.warning(i.formatMessage({
                    id: "planManagement.errorUpdatingSubscription",
                    defaultMessage: "There was a problem updating your subscription"
                }), {
                    hasCloseButton: !0
                }), z && await b.mutateAsync(a), e()
            } finally {
                P(!1), d && (c == null || c())
            }
        };
    let X = Ae;
    return n === Y.GO ? X = ke : n === Y.PRO ? X = Te : n !== Y.PLUS && Pe.error("Invalid target plan type: ".concat(n)), t.jsx(He, {
        testId: "modal-plan-management",
        type: "success",
        isOpen: o,
        onClose: y,
        size: "custom",
        noPadding: !0,
        className: "max-w-xl",
        showCloseButton: !0,
        title: i.formatMessage({
            id: "planManagementModal.title",
            defaultMessage: "Confirm plan changes"
        }),
        removePopoverStyling: !0,
        headerClassName: "py-4! px-6! [&_h2]:font-medium",
        children: U || k ? t.jsx(De, {}) : w || m && s ? t.jsx(ft, {
            account: s,
            renewalDate: v,
            handleUpdate: () => te(r),
            isUpdating: x,
            onClose: y,
            targetPlanCost: X,
            currencySymbol: J,
            promoMetadata: l,
            fullPriceResumeDateFormatted: ue,
            formattedDiscountedCost: W,
            renewalDateFormatted: ce
        }) : S || E != null || !p ? null : M ? t.jsx(rt, {
            accountId: a,
            handleUpdate: () => te(r),
            isUpdating: x,
            onClose: y,
            initialPlanType: r,
            updatedPlanType: n,
            currencySymbol: J
        }) : t.jsx(gt, {
            renewalDate: p.renewal_date,
            handleUpdate: () => te(r),
            isUpdating: x,
            onClose: y,
            targetPlanCost: X,
            currentPlanType: r,
            updatedPlanType: n,
            currencySymbol: J,
            promoMetadata: l,
            fullPriceResumeDateFormatted: ue,
            formattedDiscountedCost: W
        })
    })
}

function De() {
    "use forget";
    const o = H.c(1);
    let e;
    return o[0] === Symbol.for("react.memo_cache_sentinel") ? (e = t.jsx("div", {
        className: "flex items-center justify-center p-6",
        children: t.jsx(Ve, {})
    }), o[0] = e) : e = o[0], e
}

function Ne(o) {
    "use forget";
    const e = H.c(12),
        {
            adjustmentMessage: a,
            proratedCreditMessage: r,
            proratedCreditInfoMessage: n
        } = o;
    let u;
    e[0] !== a ? (u = t.jsx("span", {
        className: "font-semibold",
        children: a
    }), e[0] = a, e[1] = u) : u = e[1];
    let l;
    e[2] !== r ? (l = t.jsx("span", {
        className: "font-semibold text-green-600",
        children: r
    }), e[2] = r, e[3] = l) : l = e[3];
    let d;
    e[4] !== u || e[5] !== l ? (d = t.jsxs("div", {
        className: "mt-4 flex justify-between",
        children: [u, l]
    }), e[4] = u, e[5] = l, e[6] = d) : d = e[6];
    let f;
    e[7] !== n ? (f = t.jsx("span", {
        className: "text-token-text-secondary text-sm",
        children: n
    }), e[7] = n, e[8] = f) : f = e[8];
    let c;
    return e[9] !== d || e[10] !== f ? (c = t.jsxs("div", {
        children: [d, f]
    }), e[9] = d, e[10] = f, e[11] = c) : c = e[11], c
}

function rt(o) {
    "use forget";
    const e = H.c(42),
        {
            accountId: a,
            handleUpdate: r,
            isUpdating: n,
            onClose: u,
            currencySymbol: l,
            updatedPlanType: d,
            initialPlanType: f
        } = o,
        c = V();
    let h;
    e[0] !== d ? (h = Ue(d), e[0] = d, e[1] = h) : h = e[1];
    const {
        data: i,
        isError: R,
        isLoading: s
    } = ve(a, void 0, h);
    if (s) {
        let U;
        return e[2] === Symbol.for("react.memo_cache_sentinel") ? (U = t.jsx(De, {}), e[2] = U) : U = e[2], U
    }
    if (R || !i) return null;
    let x, P, w;
    if (e[3] !== l || e[4] !== i || e[5] !== f || e[6] !== c || e[7] !== d) {
        const U = ct({
            data: i,
            intl: c,
            currencySymbol: l,
            currentPlanType: f
        });
        x = "px-6 pb-6", e[11] !== l || e[12] !== i || e[13] !== d ? (P = t.jsx(ut, {
            data: i,
            currencySymbol: l,
            updatedPlanType: d
        }), e[11] = l, e[12] = i, e[13] = d, e[14] = P) : P = e[14], w = U.filter(dt).map(it), e[3] = l, e[4] = i, e[5] = f, e[6] = c, e[7] = d, e[8] = x, e[9] = P, e[10] = w
    } else x = e[8], P = e[9], w = e[10];
    let m;
    e[15] === Symbol.for("react.memo_cache_sentinel") ? (m = t.jsx("hr", {
        className: "mt-4 mb-4"
    }), e[15] = m) : m = e[15];
    let M;
    e[16] !== l || e[17] !== i ? (M = t.jsx(Re, {
        data: i,
        currencySymbol: l
    }), e[16] = l, e[17] = i, e[18] = M) : M = e[18];
    let j;
    e[19] !== i.default_payment_method ? (j = i.default_payment_method && t.jsxs(t.Fragment, {
        children: [t.jsx("hr", {
            className: "mt-4 mb-4"
        }), t.jsx(Fe, {
            defaultPaymentMethod: i.default_payment_method
        })]
    }), e[19] = i.default_payment_method, e[20] = j) : j = e[20];
    let y;
    e[21] !== c ? (y = c.formatMessage({
        id: "planUpgradeModal.cancel",
        defaultMessage: "Cancel"
    }), e[21] = c, e[22] = y) : y = e[22];
    let F;
    e[23] !== u || e[24] !== y ? (F = t.jsx(q, {
        title: y,
        color: "secondary",
        onClick: u
    }), e[23] = u, e[24] = y, e[25] = F) : F = e[25];
    let C;
    e[26] !== c ? (C = c.formatMessage({
        id: "planUpgradeModal.payNow",
        defaultMessage: "Pay now"
    }), e[26] = c, e[27] = C) : C = e[27];
    let b;
    e[28] !== r || e[29] !== n || e[30] !== C ? (b = t.jsx(q, {
        title: C,
        color: "primary",
        onClick: r,
        loading: n
    }), e[28] = r, e[29] = n, e[30] = C, e[31] = b) : b = e[31];
    let p;
    e[32] !== b || e[33] !== F ? (p = t.jsxs("div", {
        className: "mt-8 flex justify-end gap-2",
        children: [F, b]
    }), e[32] = b, e[33] = F, e[34] = p) : p = e[34];
    let S;
    return e[35] !== p || e[36] !== x || e[37] !== P || e[38] !== w || e[39] !== M || e[40] !== j ? (S = t.jsxs("div", {
        className: x,
        children: [P, w, m, M, j, p]
    }), e[35] = p, e[36] = x, e[37] = P, e[38] = w, e[39] = M, e[40] = j, e[41] = S) : S = e[41], S
}

function it(o, e) {
    return t.jsx(Ne, {
        adjustmentMessage: o.adjustmentMessage,
        proratedCreditMessage: o.proratedCreditMessage,
        proratedCreditInfoMessage: o.proratedCreditInfoMessage
    }, e)
}

function dt(o) {
    return o.value !== 0
}

function ct({
    data: o,
    intl: e,
    currencySymbol: a,
    currentPlanType: r
}) {
    return [{
        adjustmentMessage: t.jsx(g, {
            id: "planUpgradeModal.adjustment",
            defaultMessage: "Adjustment"
        }),
        proratedCreditMessage: t.jsx(g, {
            id: "planUpgradeModal.proratedCredit",
            defaultMessage: "-{currencySign}{adjustment}",
            values: {
                currencySign: e.formatMessage(a.sign),
                adjustment: (-o.negative_line_item_total / 100).toFixed(2)
            }
        }),
        proratedCreditInfoMessage: t.jsx(g, {
            id: "planUpgradeModal.proratedCreditInfo",
            defaultMessage: "Prorated credit for the remainder of your {currentPlanType} subscription",
            values: {
                currentPlanType: r
            }
        }),
        value: o.negative_line_item_total
    }, {
        adjustmentMessage: t.jsx(g, {
            id: "planUpgradeModal.discount",
            defaultMessage: "Adjustment"
        }),
        proratedCreditMessage: t.jsx(g, {
            id: "planUpgradeModal.discountAmount",
            defaultMessage: "-{currencySign}{discount}",
            values: {
                currencySign: e.formatMessage(a.sign),
                discount: (o.discount_amount / 100).toFixed(2)
            }
        }),
        proratedCreditInfoMessage: t.jsx(g, {
            id: "planUpgradeModal.discountInfo",
            defaultMessage: "Account discount applied"
        }),
        value: o.discount_amount
    }, {
        adjustmentMessage: t.jsx(g, {
            id: "planUpgradeModal.credits",
            defaultMessage: "Adjustments"
        }),
        proratedCreditMessage: t.jsx(g, {
            id: "planUpgradeModal.creditsAmount",
            defaultMessage: "-{currencySign}{credits}",
            values: {
                currencySign: e.formatMessage(a.sign),
                credits: (o.applied_balance / 100).toFixed(2)
            }
        }),
        proratedCreditInfoMessage: t.jsx(g, {
            id: "planUpgradeModal.creditsInfo",
            defaultMessage: "Credits applied"
        }),
        value: o.applied_balance
    }]
}

function ut({
    data: o,
    currencySymbol: e,
    updatedPlanType: a
}) {
    const r = V();
    return t.jsxs(t.Fragment, {
        children: [t.jsxs("div", {
            className: "flex justify-between",
            children: [t.jsx("span", {
                className: "font-semibold",
                children: t.jsx(g, {
                    id: "planUpgradeModal.subscription",
                    defaultMessage: "ChatGPT {capitalizedUpdatedPlanType} subscription",
                    values: {
                        capitalizedUpdatedPlanType: $(a)
                    }
                })
            }), t.jsx("span", {
                className: "font-semibold",
                children: t.jsx(g, {
                    id: "planUpgradeModal.subscriptionCost",
                    defaultMessage: "{currencySign}{totalCost}",
                    values: {
                        currencySign: r.formatMessage(e.sign),
                        totalCost: (o.positive_line_item_total / 100).toFixed(2)
                    }
                })
            })]
        }), t.jsx("span", {
            className: "text-token-text-secondary text-sm",
            children: t.jsx(g, {
                id: "planUpgradeModal.billingCycle",
                defaultMessage: "Billed monthly, starting today"
            })
        })]
    })
}

function Re(o) {
    "use forget";
    const e = H.c(17),
        {
            data: a,
            currencySymbol: r
        } = o,
        n = V();
    let u;
    e[0] !== r.sign || e[1] !== a.amount_due.amount_excluding_tax || e[2] !== a.amount_due.tax_amount || e[3] !== n ? (u = a.amount_due.tax_amount > 0 && t.jsxs(t.Fragment, {
        children: [t.jsxs("div", {
            className: "mt-4 flex justify-between",
            children: [t.jsx("span", {
                className: "font-semibold",
                children: t.jsx(g, {
                    id: "planUpgradeModal.subTotal",
                    defaultMessage: "Subtotal"
                })
            }), t.jsx("span", {
                children: t.jsx(g, {
                    id: "planUpgradeModal.subtotalPrice",
                    defaultMessage: "{currencySign}{totalCost}",
                    values: {
                        currencySign: n.formatMessage(r.sign),
                        totalCost: (a.amount_due.amount_excluding_tax / 100).toFixed(2)
                    }
                })
            })]
        }), t.jsxs("div", {
            className: "mt-2 flex justify-between",
            children: [t.jsxs("span", {
                className: "font-semibold",
                children: [t.jsx(g, {
                    id: "planUpgradeModal.tax",
                    defaultMessage: "Tax"
                }), t.jsx("span", {
                    className: "text-token-text-secondary font-normal",
                    children: t.jsx(g, {
                        id: "planUpgradeModal.taxPercent",
                        defaultMessage: " {taxPercent}%",
                        values: {
                            taxPercent: (a.amount_due.tax_amount / a.amount_due.amount_excluding_tax * 100).toFixed(0)
                        }
                    })
                })]
            }), t.jsx("span", {
                children: t.jsx(g, {
                    id: "planUpgradeModal.taxAmount",
                    defaultMessage: "{currencySign}{tax}",
                    values: {
                        currencySign: n.formatMessage(r.sign),
                        tax: (a.amount_due.tax_amount / 100).toFixed(2)
                    }
                })
            })]
        })]
    }), e[0] = r.sign, e[1] = a.amount_due.amount_excluding_tax, e[2] = a.amount_due.tax_amount, e[3] = n, e[4] = u) : u = e[4];
    let l;
    e[5] === Symbol.for("react.memo_cache_sentinel") ? (l = t.jsx("span", {
        className: "font-semibold",
        children: t.jsx(g, {
            id: "planUpgradeModal.totalDueToday",
            defaultMessage: "Total due today"
        })
    }), e[5] = l) : l = e[5];
    let d;
    e[6] !== r.sign || e[7] !== n ? (d = n.formatMessage(r.sign), e[6] = r.sign, e[7] = n, e[8] = d) : d = e[8];
    const f = a.amount_due.amount / 100;
    let c;
    e[9] !== f ? (c = f.toFixed(2), e[9] = f, e[10] = c) : c = e[10];
    let h;
    e[11] !== d || e[12] !== c ? (h = t.jsxs("div", {
        className: "mt-2 flex justify-between",
        children: [l, t.jsx("span", {
            className: "font-semibold",
            children: t.jsx(g, {
                id: "planUpgradeModal.totalDueTodayAmount",
                defaultMessage: "{currencySign}{totalCost}",
                values: {
                    currencySign: d,
                    totalCost: c
                }
            })
        })]
    }), e[11] = d, e[12] = c, e[13] = h) : h = e[13];
    let i;
    return e[14] !== u || e[15] !== h ? (i = t.jsxs(t.Fragment, {
        children: [u, h]
    }), e[14] = u, e[15] = h, e[16] = i) : i = e[16], i
}

function Fe(o) {
    "use forget";
    var l;
    const e = H.c(6),
        {
            defaultPaymentMethod: a
        } = o;
    let r;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (r = t.jsx("span", {
        className: "font-semibold",
        children: t.jsx(g, {
            id: "planUpgradeModal.paymentMethod",
            defaultMessage: "Payment Method"
        })
    }), e[0] = r) : r = e[0];
    let n;
    e[1] !== a.card_brand ? (n = (l = a.card_brand) == null ? void 0 : l.toUpperCase(), e[1] = a.card_brand, e[2] = n) : n = e[2];
    let u;
    return e[3] !== a.card_last4 || e[4] !== n ? (u = t.jsxs("div", {
        className: "flex justify-between",
        children: [r, t.jsxs("span", {
            className: "text-token-text-secondary",
            children: [n, " *", a.card_last4]
        })]
    }), e[3] = a.card_last4, e[4] = n, e[5] = u) : u = e[5], u
}

function gt(o) {
    "use forget";
    var G, Z;
    const e = H.c(66),
        {
            renewalDate: a,
            handleUpdate: r,
            isUpdating: n,
            onClose: u,
            targetPlanCost: l,
            currentPlanType: d,
            currencySymbol: f,
            updatedPlanType: c,
            promoMetadata: h,
            fullPriceResumeDateFormatted: i,
            formattedDiscountedCost: R
        } = o,
        s = V(),
        x = (h == null ? void 0 : h.plan_type_change) === "downgrade",
        P = (Z = (G = h == null ? void 0 : h.duration) == null ? void 0 : G.period) != null ? Z : "month";
    let w;
    e[0] !== s || e[1] !== a ? (w = a ? new Date(a).toLocaleDateString(s.locale, {
        year: "numeric",
        month: "long",
        day: "numeric"
    }) : s.formatMessage(re.notApplicable), e[0] = s, e[1] = a, e[2] = w) : w = e[2];
    const m = w;
    let M;
    e[3] !== d ? (M = $(d), e[3] = d, e[4] = M) : M = e[4];
    let j;
    e[5] !== c ? (j = $(c), e[5] = c, e[6] = j) : j = e[6];
    let y;
    e[7] !== m || e[8] !== M || e[9] !== j ? (y = t.jsx("p", {
        className: "text-token-text-secondary",
        children: t.jsx(g, {
            id: "planDowngradeModal.currentSubscription",
            defaultMessage: "Your current {currentPlanType} subscription will remain active until {renewalDateFormatted}, when it will change to {nextPlanType}.",
            values: {
                renewalDateFormatted: m,
                currentPlanType: M,
                nextPlanType: j
            }
        })
    }), e[7] = m, e[8] = M, e[9] = j, e[10] = y) : y = e[10];
    const F = x ? "text-token-text-primary text-[15px]" : "font-semibold";
    let C;
    e[11] !== c ? (C = $(c), e[11] = c, e[12] = C) : C = e[12];
    let b;
    e[13] !== C ? (b = t.jsx(g, {
        id: "planDowngradeModal.newPlan",
        defaultMessage: "ChatGPT {capitalizedUpdatedPlanType}",
        values: {
            capitalizedUpdatedPlanType: C
        }
    }), e[13] = C, e[14] = b) : b = e[14];
    let p;
    e[15] !== F || e[16] !== b ? (p = t.jsx("span", {
        className: F,
        children: b
    }), e[15] = F, e[16] = b, e[17] = p) : p = e[17];
    let S;
    e[18] !== f || e[19] !== R || e[20] !== s || e[21] !== x || e[22] !== l ? (S = x ? t.jsx("span", {
        className: "text-token-text-primary text-[15px]",
        children: t.jsx(g, {
            id: "planDowngradeModal.newPlanCostOfPromo",
            defaultMessage: "{promotionalCost} w/ promo",
            values: {
                promotionalCost: R
            }
        })
    }) : t.jsx("span", {
        className: "text-token-text-secondary",
        children: t.jsx(g, {
            id: "planDowngradeModal.newPlanCost",
            defaultMessage: "{currencyCode} {currencySign}{planCost}/month",
            values: {
                currencyCode: s.formatMessage(f.code),
                currencySign: s.formatMessage(f.sign),
                planCost: s.formatMessage(l)
            }
        })
    }), e[18] = f, e[19] = R, e[20] = s, e[21] = x, e[22] = l, e[23] = S) : S = e[23];
    let U;
    e[24] !== p || e[25] !== S ? (U = t.jsxs("div", {
        className: "flex justify-between",
        children: [p, S]
    }), e[24] = p, e[25] = S, e[26] = U) : U = e[26];
    const O = x && "text-token-text-secondary text-xs";
    let k;
    e[27] !== O ? (k = _e("text-token-text-secondary", O), e[27] = O, e[28] = k) : k = e[28];
    let E;
    e[29] !== i || e[30] !== x || e[31] !== P || e[32] !== m ? (E = x ? ie({
        fullPriceResumeDateFormatted: i,
        period: P,
        type: "billingStartAfterPromo"
    }) : t.jsx(g, {
        id: "planDowngradeModal.billingStart",
        defaultMessage: "Billing will start on {renewalDateFormatted}",
        values: {
            renewalDateFormatted: m
        }
    }), e[29] = i, e[30] = x, e[31] = P, e[32] = m, e[33] = E) : E = e[33];
    let A;
    e[34] !== k || e[35] !== E ? (A = t.jsx("span", {
        className: k,
        children: E
    }), e[34] = k, e[35] = E, e[36] = A) : A = e[36];
    let D;
    e[37] !== f || e[38] !== s || e[39] !== x || e[40] !== l ? (D = x && t.jsx("span", {
        className: "text-token-text-secondary text-xs",
        children: t.jsx(g, {
            id: "planDowngradeModal.newPlanCostAfterPromo",
            defaultMessage: "{currencySign}{planCost}/month after",
            values: {
                currencySign: s.formatMessage(f.sign),
                planCost: s.formatMessage(l)
            }
        })
    }), e[37] = f, e[38] = s, e[39] = x, e[40] = l, e[41] = D) : D = e[41];
    let _;
    e[42] !== A || e[43] !== D ? (_ = t.jsxs("div", {
        className: "flex items-center justify-between",
        children: [A, D]
    }), e[42] = A, e[43] = D, e[44] = _) : _ = e[44];
    let v;
    e[45] !== U || e[46] !== _ ? (v = t.jsxs("div", {
        className: "bg-token-main-surface-secondary mt-4 flex flex-col gap-1 rounded-2xl! rounded-md border-[1px] p-4",
        children: [U, _]
    }), e[45] = U, e[46] = _, e[47] = v) : v = e[47];
    let N;
    e[48] !== s ? (N = s.formatMessage({
        id: "planDowngradeModal.cancel",
        defaultMessage: "Cancel"
    }), e[48] = s, e[49] = N) : N = e[49];
    let T;
    e[50] !== u || e[51] !== N ? (T = t.jsx(q, {
        title: N,
        color: "secondary",
        onClick: u
    }), e[50] = u, e[51] = N, e[52] = T) : T = e[52];
    let I;
    e[53] !== s ? (I = s.formatMessage({
        id: "planDowngradeModal.confirm",
        defaultMessage: "Confirm"
    }), e[53] = s, e[54] = I) : I = e[54];
    let L;
    e[55] !== r || e[56] !== n || e[57] !== I ? (L = t.jsx(q, {
        title: I,
        color: "primary",
        onClick: r,
        loading: n
    }), e[55] = r, e[56] = n, e[57] = I, e[58] = L) : L = e[58];
    let B;
    e[59] !== T || e[60] !== L ? (B = t.jsxs("div", {
        className: "mt-8 flex justify-end gap-2",
        children: [T, L]
    }), e[59] = T, e[60] = L, e[61] = B) : B = e[61];
    let z;
    return e[62] !== v || e[63] !== B || e[64] !== y ? (z = t.jsxs("div", {
        className: "px-6 pb-6",
        children: [y, v, B]
    }), e[62] = v, e[63] = B, e[64] = y, e[65] = z) : z = e[65], z
}

function ft(o) {
    "use forget";
    var z, G;
    const e = H.c(63),
        {
            account: a,
            renewalDate: r,
            handleUpdate: n,
            isUpdating: u,
            onClose: l,
            targetPlanCost: d,
            currencySymbol: f,
            promoMetadata: c,
            fullPriceResumeDateFormatted: h,
            renewalDateFormatted: i,
            formattedDiscountedCost: R
        } = o,
        s = V(),
        x = a.data.subscriptionStatus.planType;
    let P;
    e[0] !== x ? (P = $(x), e[0] = x, e[1] = P) : P = e[1];
    const w = P,
        m = (c == null ? void 0 : c.plan_type_change) === "equal",
        M = (G = (z = c == null ? void 0 : c.duration) == null ? void 0 : z.period) != null ? G : "month";
    let j;
    e[2] !== m || e[3] !== M || e[4] !== w || e[5] !== r || e[6] !== i ? (j = m ? ie({
        renewalDateFormatted: i,
        period: M,
        type: "currentSubscriptionPromo"
    }) : t.jsx(g, {
        id: "planRenewalModal.currentSubscription",
        defaultMessage: "Your current {planName} subscription will auto-renew on {renewalDate}.",
        values: {
            planName: w,
            renewalDate: r
        }
    }), e[2] = m, e[3] = M, e[4] = w, e[5] = r, e[6] = i, e[7] = j) : j = e[7];
    let y;
    e[8] !== j ? (y = t.jsx("p", {
        className: "text-token-text-primary",
        children: j
    }), e[8] = j, e[9] = y) : y = e[9];
    const F = m ? "text-token-text-primary text-[15px]" : "font-semibold";
    let C;
    e[10] !== w ? (C = t.jsx(g, {
        id: "planRenewalModal.newPlan",
        defaultMessage: "ChatGPT {planName}",
        values: {
            planName: w
        }
    }), e[10] = w, e[11] = C) : C = e[11];
    let b;
    e[12] !== F || e[13] !== C ? (b = t.jsx("span", {
        className: F,
        children: C
    }), e[12] = F, e[13] = C, e[14] = b) : b = e[14];
    let p;
    e[15] !== f || e[16] !== R || e[17] !== s || e[18] !== m || e[19] !== d ? (p = m ? t.jsx("span", {
        className: "text-token-text-primary text-[15px]",
        children: t.jsx(g, {
            id: "planRenewalModal.newPlanCostAfterPromo",
            defaultMessage: "{promotionalCost} w/ promo",
            values: {
                promotionalCost: R
            }
        })
    }) : t.jsx("span", {
        className: "text-token-text-secondary",
        children: t.jsx(g, {
            id: "planRenewalModal.newPlanCost",
            defaultMessage: "{currencyCode} {currencySign}{planCost}/month",
            values: {
                currencyCode: s.formatMessage(f.code),
                currencySign: s.formatMessage(f.sign),
                planCost: s.formatMessage(d)
            }
        })
    }), e[15] = f, e[16] = R, e[17] = s, e[18] = m, e[19] = d, e[20] = p) : p = e[20];
    let S;
    e[21] !== b || e[22] !== p ? (S = t.jsxs("div", {
        className: "flex justify-between",
        children: [b, p]
    }), e[21] = b, e[22] = p, e[23] = S) : S = e[23];
    const U = m && "text-token-text-secondary text-xs";
    let O;
    e[24] !== U ? (O = _e("text-token-text-secondary", U), e[24] = U, e[25] = O) : O = e[25];
    let k;
    e[26] !== h || e[27] !== m || e[28] !== r ? (k = m ? t.jsx(g, {
        id: "planRenewalModal.billingStartAfterPromo",
        defaultMessage: "Billing will start on {fullPriceResumeDateFormatted}",
        values: {
            fullPriceResumeDateFormatted: h
        }
    }) : t.jsx(g, {
        id: "planRenewalModal.billingStart",
        defaultMessage: "Billing will auto-renew on {renewalDate}",
        values: {
            renewalDate: r
        }
    }), e[26] = h, e[27] = m, e[28] = r, e[29] = k) : k = e[29];
    let E;
    e[30] !== O || e[31] !== k ? (E = t.jsx("span", {
        className: O,
        children: k
    }), e[30] = O, e[31] = k, e[32] = E) : E = e[32];
    let A;
    e[33] !== f || e[34] !== s || e[35] !== m || e[36] !== M || e[37] !== d ? (A = m && t.jsx("span", {
        className: "text-token-text-secondary text-xs",
        children: ie({
            period: M,
            type: "newPlanCostAfterPromo",
            currencySign: s.formatMessage(f.sign),
            planCost: s.formatMessage(d)
        })
    }), e[33] = f, e[34] = s, e[35] = m, e[36] = M, e[37] = d, e[38] = A) : A = e[38];
    let D;
    e[39] !== E || e[40] !== A ? (D = t.jsxs("div", {
        className: "flex items-center justify-between",
        children: [E, A]
    }), e[39] = E, e[40] = A, e[41] = D) : D = e[41];
    let _;
    e[42] !== D || e[43] !== S ? (_ = t.jsxs("div", {
        className: "bg-token-main-surface-secondary mt-4 flex flex-col gap-1 rounded-2xl! rounded-md border-[1px] p-4",
        children: [S, D]
    }), e[42] = D, e[43] = S, e[44] = _) : _ = e[44];
    let v;
    e[45] !== s ? (v = s.formatMessage({
        id: "planRenewalModal.cancel",
        defaultMessage: "Cancel"
    }), e[45] = s, e[46] = v) : v = e[46];
    let N;
    e[47] !== l || e[48] !== v ? (N = t.jsx(q, {
        title: v,
        color: "secondary",
        onClick: l
    }), e[47] = l, e[48] = v, e[49] = N) : N = e[49];
    let T;
    e[50] !== s ? (T = s.formatMessage({
        id: "planRenewalModal.confirm",
        defaultMessage: "Confirm"
    }), e[50] = s, e[51] = T) : T = e[51];
    let I;
    e[52] !== n || e[53] !== u || e[54] !== T ? (I = t.jsx(q, {
        title: T,
        color: "primary",
        onClick: n,
        loading: u
    }), e[52] = n, e[53] = u, e[54] = T, e[55] = I) : I = e[55];
    let L;
    e[56] !== N || e[57] !== I ? (L = t.jsxs("div", {
        className: "mt-8 flex justify-end gap-2",
        children: [N, I]
    }), e[56] = N, e[57] = I, e[58] = L) : L = e[58];
    let B;
    return e[59] !== _ || e[60] !== L || e[61] !== y ? (B = t.jsxs("div", {
        className: "px-6 pb-6",
        children: [y, _, L]
    }), e[59] = _, e[60] = L, e[61] = y, e[62] = B) : B = e[62], B
}

function Ee(o, e) {
    if (!e) return {
        goCost: oe.free.costRetrievalError,
        plusCost: oe.free.costRetrievalError,
        proCost: oe.free.costRetrievalError
    };
    const a = se(e, je, ne.Month),
        r = se(e, Ce, ne.Month),
        n = se(e, be, ne.Month);
    return {
        goCost: le(a.amount, je, o),
        plusCost: le(r.amount, Ce, o),
        proCost: le(n.amount, be, o)
    }
}

function ie({
    fullPriceResumeDateFormatted: o,
    renewalDateFormatted: e,
    period: a,
    type: r,
    currencySign: n,
    planCost: u
}) {
    switch (["month", "year"].includes(a) || Pe.warn("Invalid period passed to PlanManagementModal.getPeriodFormattedMessage", {
        period: a
    }), r) {
        case "billingStartAfterPromo":
            return t.jsx(g, {
                id: "planDowngradeModal.billingResumeAfterPromo",
                defaultMessage: "Billing will resume on {fullPriceResumeDateFormatted}",
                values: {
                    fullPriceResumeDateFormatted: o
                }
            });
        case "currentSubscriptionPromo":
            return t.jsx(g, {
                id: "planRenewalModal.currentSubscriptionPromo",
                defaultMessage: "After the billing cycle for your current plan ends on {renewalDateFormatted}, your promotional subscription will go into effect.",
                values: {
                    renewalDateFormatted: e
                }
            });
        case "newPlanCostAfterPromo":
            if (a === "month") return t.jsx(g, {
                id: "planDowngradeModal.newPlanCostAfterPromoMonth",
                defaultMessage: "{currencySign}{planCost}/month after",
                values: {
                    currencySign: n,
                    planCost: u
                }
            });
            if (a === "year") return t.jsx(g, {
                id: "planDowngradeModal.newPlanCostAfterPromoYear",
                defaultMessage: "{currencySign}{planCost}/year after",
                values: {
                    currencySign: n,
                    planCost: u
                }
            });
            break
    }
}
const wt = Object.freeze(Object.defineProperty({
    __proto__: null,
    AdjustmentSection: Ne,
    PaymentMethodSection: Fe,
    TotalCostSection: Re,
    default: ot,
    getPrice: Ee
}, Symbol.toStringTag, {
    value: "Module"
}));
export {
    Ne as A, Fe as P, Re as T, ot as a, wt as b, Ee as g, lt as u
};
//# sourceMappingURL=oi0jufgbruu7yg53.js.map