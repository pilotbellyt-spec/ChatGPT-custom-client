var p = Object.defineProperty;
var P = Object.getOwnPropertySymbols;
var I = Object.prototype.hasOwnProperty,
    B = Object.prototype.propertyIsEnumerable;
var C = (r, s, t) => s in r ? p(r, s, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : r[s] = t,
    A = (r, s) => {
        for (var t in s || (s = {})) I.call(s, t) && C(r, t, s[t]);
        if (P)
            for (var t of P(s)) B.call(s, t) && C(r, t, s[t]);
        return r
    };
import {
    r as l,
    j as w
} from "./fg33krlcm0qyi6yw.js";
import {
    da as M,
    fe as F
} from "./dykg4ktvbu3mhmdo.js";
import {
    pM as v
} from "./k15yxxoybkkir2ou.js";
const X = {
        bands: 5,
        loPass: 100,
        hiPass: 600,
        updateInterval: 32,
        analyserOptions: {
            fftSize: 2048
        }
    },
    q = r => {
        const s = t => {
            let a = 1 - Math.max(-100, Math.min(-10, t)) * -1 / 100;
            return a = Math.sqrt(a), a
        };
        return r.map(t => t === -1 / 0 ? 0 : s(t))
    };

function W(r, s = {}) {
    const t = A(A({}, X), s),
        [i, d] = l.useState(new Array(t.bands).fill(0));
    return l.useEffect(() => {
        if (!r) return;
        const {
            analyser: a,
            cleanup: h
        } = U(r, t.analyserOptions), R = a.frequencyBinCount, g = new Float32Array(R), S = setInterval(() => {
            a.getFloatFrequencyData(g);
            let c = new Float32Array(g.length);
            for (let f = 0; f < g.length; f++) c[f] = g[f];
            c = c.slice(t.loPass, t.hiPass);
            const b = q(c),
                e = Math.ceil(b.length / t.bands),
                _ = [];
            for (let f = 0; f < t.bands; f++) {
                const n = b.slice(f * e, (f + 1) * e).reduce((y, o) => y += o, 0);
                _.push(n / e)
            }
            d(_)
        }, t.updateInterval);
        return () => {
            h(), clearInterval(S)
        }
    }, [r, JSON.stringify(s)]), i
}

function U(r, s) {
    const t = A({
            fftSize: 2048,
            smoothingTimeConstant: .8,
            minDecibels: -100,
            maxDecibels: -80
        }, s),
        i = N();
    if (!i) throw new Error("Audio Context not supported on this browser");
    let d;
    r instanceof HTMLAudioElement ? d = i.createMediaElementSource(r) : d = i.createMediaStreamSource(new MediaStream([r]));
    const a = i.createAnalyser();
    a.minDecibels = t.minDecibels, a.maxDecibels = t.maxDecibels, a.fftSize = t.fftSize, a.smoothingTimeConstant = t.smoothingTimeConstant, d.connect(a), r instanceof HTMLAudioElement && a.connect(i.destination);
    const h = new Uint8Array(a.frequencyBinCount);
    return {
        calculateVolume: () => {
            a.getByteFrequencyData(h);
            let E = 0;
            for (const c of h) E += Math.pow(c / 255, 2);
            return Math.sqrt(E / h.length)
        },
        analyser: a,
        cleanup: async () => {
            await i.close()
        }
    }
}

function N() {
    const r = typeof window < "u" && (window.AudioContext || window.webkitAudioContext);
    if (r) return new r({
        latencyHint: "interactive"
    })
}

function O(r) {
    const s = l.useRef(r);
    s.current = r;
    const [t, i] = l.useState(null), d = l.useCallback(a => {
        i(a)
    }, []);
    return M(() => {
        const a = new ResizeObserver(h => {
            for (const R of h) s.current(R)
        });
        return t && a.observe(t), () => {
            a.disconnect()
        }
    }, [t]), d
}
const D = v.createChild("GLCanvas");

function j({
    className: r,
    vert: s,
    frag: t,
    Behaviors: i,
    onViewportUpdate: d,
    onRenderComplete: a,
    onGlAvailable: h,
    onCanvasSizeUpdate: R,
    scale: g
}) {
    const E = l.useRef(null),
        S = l.useRef(null),
        [c, b] = l.useState(null),
        [e, _] = l.useState(),
        f = l.useRef(F(o => {
            const {
                width: u,
                height: m
            } = o.contentRect, T = Math.floor(Math.min(u != null ? u : 0, m != null ? m : 0));
            b(T), d == null || d({
                width: T,
                height: T
            })
        }, 100)),
        n = O(f.current);
    if (M(() => {
            const o = E.current,
                {
                    width: u,
                    height: m
                } = o != null ? o : {};
            if (o && c != null && u && m) {
                const T = o.getContext("webgl2", {
                    premultipliedAlpha: !0
                });
                T ? _(T) : D.error("webgl2 context not supported")
            }
        }, [c]), M(() => {
            if (!e) return;
            const o = e.createProgram(),
                u = e.createShader(e.VERTEX_SHADER),
                m = e.createShader(e.FRAGMENT_SHADER);
            if (!o) {
                D.debug("failed to create program");
                return
            }
            if (!u || !m) {
                D.debug("failed to create shaders", u, m);
                return
            }
            let T = "";
            if (e.shaderSource(u, s), e.compileShader(u), T += "vertShader:\n".concat(e.getShaderInfoLog(u), "\n"), e.attachShader(o, u), e.shaderSource(m, t), e.compileShader(m), T += "fragShader:\n".concat(e.getShaderInfoLog(m), "\n"), e.attachShader(o, m), e.linkProgram(o), e.useProgram(o), T += e.getProgramInfoLog(o), !e.getProgramParameter(o, e.LINK_STATUS)) throw "Could not compile WebGL program. \n\n".concat(T);
            S.current = o, D.debug("program created"), h == null || h(e, o);
            const L = e.fenceSync(e.SYNC_GPU_COMMANDS_COMPLETE, 0);
            return L && (e.waitSync(L, 0, e.TIMEOUT_IGNORED), a == null || a()), () => {
                D.debug("cleaning up"), S.current = null, e.detachShader(o, u), e.detachShader(o, m), e.deleteShader(u), e.deleteShader(m), e.deleteProgram(o)
            }
        }, [e, t, s]), c != null && e && E.current) {
        const o = E.current,
            u = c * window.devicePixelRatio * (g != null ? g : 1);
        o.width = u, o.height = u, e.viewport(0, 0, u, u), R == null || R({
            width: u,
            height: u
        })
    }
    const y = S.current;
    return w.jsxs("div", {
        className: r,
        ref: n,
        children: [w.jsx("canvas", {
            ref: E,
            style: {
                width: c != null ? c : void 0,
                height: c != null ? c : void 0
            }
        }, c), e && y && i && w.jsx(i, {
            ctx: e,
            program: y
        })]
    })
}

function $({
    GLUniformsSetter: r,
    textureImage: s,
    textureName: t,
    variablesRef: i,
    className: d,
    vert: a,
    frag: h,
    onViewportUpdate: R,
    onRenderComplete: g,
    onGlAvailable: E,
    onCanvasSizeUpdate: S,
    scale: c
}) {
    const b = l.useRef(void 0),
        e = l.useCallback(async (n, y) => {
            if (b.current = new r(n, y), s && t) {
                const o = n.createTexture();
                n.bindTexture(n.TEXTURE_2D, o), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_WRAP_S, n.CLAMP_TO_EDGE), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_WRAP_T, n.CLAMP_TO_EDGE), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_MIN_FILTER, n.LINEAR), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_MAG_FILTER, n.LINEAR), n.texImage2D(n.TEXTURE_2D, 0, n.RGBA, n.RGBA, n.UNSIGNED_BYTE, s);
                const u = n.getUniformLocation(y, t);
                n.activeTexture(n.TEXTURE0), n.bindTexture(n.TEXTURE_2D, o), n.uniform1i(u, 0)
            }
            E == null || E(n, y)
        }, [r, s, t, E]),
        _ = l.useRef(void 0),
        f = l.useCallback(() => {
            b.current && i.current && b.current.setVariablesAndRender(i.current), _.current = requestAnimationFrame(f)
        }, [i]);
    return l.useEffect(() => (f(), () => {
        _.current && cancelAnimationFrame(_.current)
    }), [f]), w.jsx(j, {
        className: d,
        vert: a,
        frag: h,
        onViewportUpdate: R,
        onRenderComplete: g,
        onGlAvailable: e,
        onCanvasSizeUpdate: S,
        scale: c,
        Behaviors: () => null
    })
}
const z = 60,
    K = Math.floor(1e3 / z);
export {
    K as B, $ as G, W as u
};
//# sourceMappingURL=dapgo43htqk76ir6.js.map