import {
    c as e,
    s
} from "./dykg4ktvbu3mhmdo.js";
const o = e(s, "c63066", 20, 20),
    t = e(s, "d436f0", 20, 20),
    a = e(s, "c42337", 20, 20),
    i = e(s, "705604", 20, 20);
export {
    o as M, a as S, i as V, t as a
};
//# sourceMappingURL=nm0so544a95lw6u3.js.map