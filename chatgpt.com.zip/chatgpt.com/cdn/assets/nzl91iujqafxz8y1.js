import {
    c as e,
    s as t
} from "./dykg4ktvbu3mhmdo.js";
const p = e(t, "a9e984", 20, 20);
export {
    p as S
};
//# sourceMappingURL=nzl91iujqafxz8y1.js.map