var dn = Object.defineProperty,
    fn = Object.defineProperties;
var pn = Object.getOwnPropertyDescriptors;
var Le = Object.getOwnPropertySymbols;
var dt = Object.prototype.hasOwnProperty,
    ft = Object.prototype.propertyIsEnumerable;
var Ke = (e, n, t) => n in e ? dn(e, n, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : e[n] = t,
    ve = (e, n) => {
        for (var t in n || (n = {})) dt.call(n, t) && Ke(e, t, n[t]);
        if (Le)
            for (var t of Le(n)) ft.call(n, t) && Ke(e, t, n[t]);
        return e
    },
    Ce = (e, n) => fn(e, pn(n));
var pt = (e, n) => {
    var t = {};
    for (var r in e) dt.call(e, r) && n.indexOf(r) < 0 && (t[r] = e[r]);
    if (e != null && Le)
        for (var r of Le(e)) n.indexOf(r) < 0 && ft.call(e, r) && (t[r] = e[r]);
    return t
};
var W = (e, n, t) => Ke(e, typeof n != "symbol" ? n + "" : n, t);
import {
    m as hn,
    q as vn,
    eu as De,
    k_ as Y,
    dD as mn,
    gy as bn,
    xs as yn,
    Z as Sn,
    S as gn,
    en as wn,
    o0 as kn,
    eh as ht,
    o3 as Tn
} from "./dykg4ktvbu3mhmdo.js";
import {
    r as a,
    j as nt,
    e as Cn
} from "./fg33krlcm0qyi6yw.js";
import {
    jN as Ye,
    pM as $,
    sk as _n,
    sl as En,
    nz as Ne,
    sm as ye,
    sn as Mn,
    so as In,
    sp as xn,
    sq as Pn,
    sr as vt,
    ss as On,
    st as An,
    su as Rn,
    sv as Ln,
    sw as Dn,
    sx as Nn,
    sy as Rt,
    sz as rt,
    sA as Un,
    sB as Vn,
    sC as $n,
    sD as Z,
    rj as jn,
    nE as Fn,
    sE as Wn,
    sF as zn,
    sG as qn,
    sH as He,
    sI as Qn,
    jf as Yn,
    sJ as mt,
    sK as bt,
    sL as Bn,
    sM as Gn,
    sN as yt,
    bt as Jn,
    sO as Kn,
    sP as Hn,
    sQ as Zn,
    jg as Xn
} from "./k15yxxoybkkir2ou.js";
import {
    L as er,
    R as w,
    T as B,
    P as M,
    a as ie,
    C as z
} from "./ftef8970ba1zoykr.js";
const tr = () => {
    const e = hn(),
        n = Ye(),
        t = a.useCallback(() => n.getState().isVoiceModeActive, [n]);
    return a.useMemo(() => new Proxy(e, {
        get(r, o) {
            const i = r[o];
            return t() || o === "closeAll" ? i : () => {}
        }
    }), [t, e])
};
var nr = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};

function rr(e) {
    return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
}
var Lt = {
    exports: {}
};
(function(e) {
    (function(n, t) {
        e.exports ? e.exports = t() : n.log = t()
    })(nr, function() {
        var n = function() {},
            t = "undefined",
            r = typeof window !== t && typeof window.navigator !== t && /Trident\/|MSIE /.test(window.navigator.userAgent),
            o = ["trace", "debug", "info", "warn", "error"],
            i = {},
            c = null;

        function u(f, x) {
            var m = f[x];
            if (typeof m.bind == "function") return m.bind(f);
            try {
                return Function.prototype.bind.call(m, f)
            } catch (g) {
                return function() {
                    return Function.prototype.apply.apply(m, [f, arguments])
                }
            }
        }

        function s() {
            console.log && (console.log.apply ? console.log.apply(console, arguments) : Function.prototype.apply.apply(console.log, [console, arguments])), console.trace && console.trace()
        }

        function l(f) {
            return f === "debug" && (f = "log"), typeof console === t ? !1 : f === "trace" && r ? s : console[f] !== void 0 ? u(console, f) : console.log !== void 0 ? u(console, "log") : n
        }

        function h() {
            for (var f = this.getLevel(), x = 0; x < o.length; x++) {
                var m = o[x];
                this[m] = x < f ? n : this.methodFactory(m, f, this.name)
            }
            if (this.log = this.debug, typeof console === t && f < this.levels.SILENT) return "No console available for logging"
        }

        function C(f) {
            return function() {
                typeof console !== t && (h.call(this), this[f].apply(this, arguments))
            }
        }

        function _(f, x, m) {
            return l(f) || C.apply(this, arguments)
        }

        function y(f, x) {
            var m = this,
                g, R, L, O = "loglevel";
            typeof f == "string" ? O += ":" + f : typeof f == "symbol" && (O = void 0);

            function ce(E) {
                var P = (o[E] || "silent").toUpperCase();
                if (!(typeof window === t || !O)) {
                    try {
                        window.localStorage[O] = P;
                        return
                    } catch (q) {}
                    try {
                        window.document.cookie = encodeURIComponent(O) + "=" + P + ";"
                    } catch (q) {}
                }
            }

            function G() {
                var E;
                if (!(typeof window === t || !O)) {
                    try {
                        E = window.localStorage[O]
                    } catch (D) {}
                    if (typeof E === t) try {
                        var P = window.document.cookie,
                            q = encodeURIComponent(O),
                            b = P.indexOf(q + "=");
                        b !== -1 && (E = /^([^;]+)/.exec(P.slice(b + q.length + 1))[1])
                    } catch (D) {}
                    return m.levels[E] === void 0 && (E = void 0), E
                }
            }

            function X() {
                if (!(typeof window === t || !O)) {
                    try {
                        window.localStorage.removeItem(O)
                    } catch (E) {}
                    try {
                        window.document.cookie = encodeURIComponent(O) + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC"
                    } catch (E) {}
                }
            }

            function F(E) {
                var P = E;
                if (typeof P == "string" && m.levels[P.toUpperCase()] !== void 0 && (P = m.levels[P.toUpperCase()]), typeof P == "number" && P >= 0 && P <= m.levels.SILENT) return P;
                throw new TypeError("log.setLevel() called with invalid level: " + E)
            }
            m.name = f, m.levels = {
                TRACE: 0,
                DEBUG: 1,
                INFO: 2,
                WARN: 3,
                ERROR: 4,
                SILENT: 5
            }, m.methodFactory = x || _, m.getLevel = function() {
                var E;
                return (E = L != null ? L : R) != null ? E : g
            }, m.setLevel = function(E, P) {
                return L = F(E), P !== !1 && ce(L), h.call(m)
            }, m.setDefaultLevel = function(E) {
                R = F(E), G() || m.setLevel(E, !1)
            }, m.resetLevel = function() {
                L = null, X(), h.call(m)
            }, m.enableAll = function(E) {
                m.setLevel(m.levels.TRACE, E)
            }, m.disableAll = function(E) {
                m.setLevel(m.levels.SILENT, E)
            }, m.rebuild = function() {
                if (c !== m && (g = F(c.getLevel())), h.call(m), c === m)
                    for (var E in i) i[E].rebuild()
            }, g = F(c ? c.getLevel() : "WARN");
            var J = G();
            J != null && (L = F(J)), h.call(m)
        }
        c = new y, c.getLogger = function(f) {
            if (typeof f != "symbol" && typeof f != "string" || f === "") throw new TypeError("You must supply a name when creating a logger.");
            var x = i[f];
            return x || (x = i[f] = new y(f, c.methodFactory)), x
        };
        var I = typeof window !== t ? window.log : void 0;
        return c.noConflict = function() {
            return typeof window !== t && window.log === c && (window.log = I), c
        }, c.getLoggers = function() {
            return i
        }, c.default = c, c
    })
})(Lt);
var or = Lt.exports;
const ir = rr(or);
var ot = function(e, n) {
    return ot = Object.setPrototypeOf || {
        __proto__: []
    }
    instanceof Array && function(t, r) {
        t.__proto__ = r
    } || function(t, r) {
        for (var o in r) Object.prototype.hasOwnProperty.call(r, o) && (t[o] = r[o])
    }, ot(e, n)
};

function ne(e, n) {
    if (typeof n != "function" && n !== null) throw new TypeError("Class extends value " + String(n) + " is not a constructor or null");
    ot(e, n);

    function t() {
        this.constructor = e
    }
    e.prototype = n === null ? Object.create(n) : (t.prototype = n.prototype, new t)
}

function cr(e, n, t, r) {
    function o(i) {
        return i instanceof t ? i : new t(function(c) {
            c(i)
        })
    }
    return new(t || (t = Promise))(function(i, c) {
        function u(h) {
            try {
                l(r.next(h))
            } catch (C) {
                c(C)
            }
        }

        function s(h) {
            try {
                l(r.throw(h))
            } catch (C) {
                c(C)
            }
        }

        function l(h) {
            h.done ? i(h.value) : o(h.value).then(u, s)
        }
        l((r = r.apply(e, [])).next())
    })
}

function Dt(e, n) {
    var t = {
            label: 0,
            sent: function() {
                if (i[0] & 1) throw i[1];
                return i[1]
            },
            trys: [],
            ops: []
        },
        r, o, i, c = Object.create((typeof Iterator == "function" ? Iterator : Object).prototype);
    return c.next = u(0), c.throw = u(1), c.return = u(2), typeof Symbol == "function" && (c[Symbol.iterator] = function() {
        return this
    }), c;

    function u(l) {
        return function(h) {
            return s([l, h])
        }
    }

    function s(l) {
        if (r) throw new TypeError("Generator is already executing.");
        for (; c && (c = 0, l[0] && (t = 0)), t;) try {
            if (r = 1, o && (i = l[0] & 2 ? o.return : l[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, l[1])).done) return i;
            switch (o = 0, i && (l = [l[0] & 2, i.value]), l[0]) {
                case 0:
                case 1:
                    i = l;
                    break;
                case 4:
                    return t.label++, {
                        value: l[1],
                        done: !1
                    };
                case 5:
                    t.label++, o = l[1], l = [0];
                    continue;
                case 7:
                    l = t.ops.pop(), t.trys.pop();
                    continue;
                default:
                    if (i = t.trys, !(i = i.length > 0 && i[i.length - 1]) && (l[0] === 6 || l[0] === 2)) {
                        t = 0;
                        continue
                    }
                    if (l[0] === 3 && (!i || l[1] > i[0] && l[1] < i[3])) {
                        t.label = l[1];
                        break
                    }
                    if (l[0] === 6 && t.label < i[1]) {
                        t.label = i[1], i = l;
                        break
                    }
                    if (i && t.label < i[2]) {
                        t.label = i[2], t.ops.push(l);
                        break
                    }
                    i[2] && t.ops.pop(), t.trys.pop();
                    continue
            }
            l = n.call(e, t)
        } catch (h) {
            l = [6, h], o = 0
        } finally {
            r = i = 0
        }
        if (l[0] & 5) throw l[1];
        return {
            value: l[0] ? l[1] : void 0,
            done: !0
        }
    }
}

function we(e) {
    var n = typeof Symbol == "function" && Symbol.iterator,
        t = n && e[n],
        r = 0;
    if (t) return t.call(e);
    if (e && typeof e.length == "number") return {
        next: function() {
            return e && r >= e.length && (e = void 0), {
                value: e && e[r++],
                done: !e
            }
        }
    };
    throw new TypeError(n ? "Object is not iterable." : "Symbol.iterator is not defined.")
}

function Fe(e, n) {
    var t = typeof Symbol == "function" && e[Symbol.iterator];
    if (!t) return e;
    var r = t.call(e),
        o, i = [],
        c;
    try {
        for (;
            (n === void 0 || n-- > 0) && !(o = r.next()).done;) i.push(o.value)
    } catch (u) {
        c = {
            error: u
        }
    } finally {
        try {
            o && !o.done && (t = r.return) && t.call(r)
        } finally {
            if (c) throw c.error
        }
    }
    return i
}

function We(e, n, t) {
    if (arguments.length === 2)
        for (var r = 0, o = n.length, i; r < o; r++)(i || !(r in n)) && (i || (i = Array.prototype.slice.call(n, 0, r)), i[r] = n[r]);
    return e.concat(i || Array.prototype.slice.call(n))
}

function ge(e) {
    return this instanceof ge ? (this.v = e, this) : new ge(e)
}

function sr(e, n, t) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var r = t.apply(e, n || []),
        o, i = [];
    return o = Object.create((typeof AsyncIterator == "function" ? AsyncIterator : Object).prototype), u("next"), u("throw"), u("return", c), o[Symbol.asyncIterator] = function() {
        return this
    }, o;

    function c(y) {
        return function(I) {
            return Promise.resolve(I).then(y, C)
        }
    }

    function u(y, I) {
        r[y] && (o[y] = function(f) {
            return new Promise(function(x, m) {
                i.push([y, f, x, m]) > 1 || s(y, f)
            })
        }, I && (o[y] = I(o[y])))
    }

    function s(y, I) {
        try {
            l(r[y](I))
        } catch (f) {
            _(i[0][3], f)
        }
    }

    function l(y) {
        y.value instanceof ge ? Promise.resolve(y.value.v).then(h, C) : _(i[0][2], y)
    }

    function h(y) {
        s("next", y)
    }

    function C(y) {
        s("throw", y)
    }

    function _(y, I) {
        y(I), i.shift(), i.length && s(i[0][0], i[0][1])
    }
}

function ar(e) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var n = e[Symbol.asyncIterator],
        t;
    return n ? n.call(e) : (e = typeof we == "function" ? we(e) : e[Symbol.iterator](), t = {}, r("next"), r("throw"), r("return"), t[Symbol.asyncIterator] = function() {
        return this
    }, t);

    function r(i) {
        t[i] = e[i] && function(c) {
            return new Promise(function(u, s) {
                c = e[i](c), o(u, s, c.done, c.value)
            })
        }
    }

    function o(i, c, u, s) {
        Promise.resolve(s).then(function(l) {
            i({
                value: l,
                done: u
            })
        }, c)
    }
}

function A(e) {
    return typeof e == "function"
}

function ct(e) {
    var n = function(r) {
            Error.call(r), r.stack = new Error().stack
        },
        t = e(n);
    return t.prototype = Object.create(Error.prototype), t.prototype.constructor = t, t
}
var Ze = ct(function(e) {
    return function(n) {
        e(this), this.message = n ? n.length + " errors occurred during unsubscription:\n" + n.map(function(t, r) {
            return r + 1 + ") " + t.toString()
        }).join("\n  ") : "", this.name = "UnsubscriptionError", this.errors = n
    }
});

function ze(e, n) {
    if (e) {
        var t = e.indexOf(n);
        0 <= t && e.splice(t, 1)
    }
}
var Ee = (function() {
        function e(n) {
            this.initialTeardown = n, this.closed = !1, this._parentage = null, this._finalizers = null
        }
        return e.prototype.unsubscribe = function() {
            var n, t, r, o, i;
            if (!this.closed) {
                this.closed = !0;
                var c = this._parentage;
                if (c)
                    if (this._parentage = null, Array.isArray(c)) try {
                        for (var u = we(c), s = u.next(); !s.done; s = u.next()) {
                            var l = s.value;
                            l.remove(this)
                        }
                    } catch (f) {
                        n = {
                            error: f
                        }
                    } finally {
                        try {
                            s && !s.done && (t = u.return) && t.call(u)
                        } finally {
                            if (n) throw n.error
                        }
                    } else c.remove(this);
                var h = this.initialTeardown;
                if (A(h)) try {
                    h()
                } catch (f) {
                    i = f instanceof Ze ? f.errors : [f]
                }
                var C = this._finalizers;
                if (C) {
                    this._finalizers = null;
                    try {
                        for (var _ = we(C), y = _.next(); !y.done; y = _.next()) {
                            var I = y.value;
                            try {
                                St(I)
                            } catch (f) {
                                i = i != null ? i : [], f instanceof Ze ? i = We(We([], Fe(i)), Fe(f.errors)) : i.push(f)
                            }
                        }
                    } catch (f) {
                        r = {
                            error: f
                        }
                    } finally {
                        try {
                            y && !y.done && (o = _.return) && o.call(_)
                        } finally {
                            if (r) throw r.error
                        }
                    }
                }
                if (i) throw new Ze(i)
            }
        }, e.prototype.add = function(n) {
            var t;
            if (n && n !== this)
                if (this.closed) St(n);
                else {
                    if (n instanceof e) {
                        if (n.closed || n._hasParent(this)) return;
                        n._addParent(this)
                    }(this._finalizers = (t = this._finalizers) !== null && t !== void 0 ? t : []).push(n)
                }
        }, e.prototype._hasParent = function(n) {
            var t = this._parentage;
            return t === n || Array.isArray(t) && t.includes(n)
        }, e.prototype._addParent = function(n) {
            var t = this._parentage;
            this._parentage = Array.isArray(t) ? (t.push(n), t) : t ? [t, n] : n
        }, e.prototype._removeParent = function(n) {
            var t = this._parentage;
            t === n ? this._parentage = null : Array.isArray(t) && ze(t, n)
        }, e.prototype.remove = function(n) {
            var t = this._finalizers;
            t && ze(t, n), n instanceof e && n._removeParent(this)
        }, e.EMPTY = (function() {
            var n = new e;
            return n.closed = !0, n
        })(), e
    })(),
    Nt = Ee.EMPTY;

function Ut(e) {
    return e instanceof Ee || e && "closed" in e && A(e.remove) && A(e.add) && A(e.unsubscribe)
}

function St(e) {
    A(e) ? e() : e.unsubscribe()
}
var ur = {
        Promise: void 0
    },
    lr = {
        setTimeout: function(e, n) {
            for (var t = [], r = 2; r < arguments.length; r++) t[r - 2] = arguments[r];
            return setTimeout.apply(void 0, We([e, n], Fe(t)))
        },
        clearTimeout: function(e) {
            return clearTimeout(e)
        },
        delegate: void 0
    };

function Vt(e) {
    lr.setTimeout(function() {
        throw e
    })
}

function gt() {}

function Ve(e) {
    e()
}
var st = (function(e) {
        ne(n, e);

        function n(t) {
            var r = e.call(this) || this;
            return r.isStopped = !1, t ? (r.destination = t, Ut(t) && t.add(r)) : r.destination = pr, r
        }
        return n.create = function(t, r, o) {
            return new it(t, r, o)
        }, n.prototype.next = function(t) {
            this.isStopped || this._next(t)
        }, n.prototype.error = function(t) {
            this.isStopped || (this.isStopped = !0, this._error(t))
        }, n.prototype.complete = function() {
            this.isStopped || (this.isStopped = !0, this._complete())
        }, n.prototype.unsubscribe = function() {
            this.closed || (this.isStopped = !0, e.prototype.unsubscribe.call(this), this.destination = null)
        }, n.prototype._next = function(t) {
            this.destination.next(t)
        }, n.prototype._error = function(t) {
            try {
                this.destination.error(t)
            } finally {
                this.unsubscribe()
            }
        }, n.prototype._complete = function() {
            try {
                this.destination.complete()
            } finally {
                this.unsubscribe()
            }
        }, n
    })(Ee),
    dr = (function() {
        function e(n) {
            this.partialObserver = n
        }
        return e.prototype.next = function(n) {
            var t = this.partialObserver;
            if (t.next) try {
                t.next(n)
            } catch (r) {
                Ue(r)
            }
        }, e.prototype.error = function(n) {
            var t = this.partialObserver;
            if (t.error) try {
                t.error(n)
            } catch (r) {
                Ue(r)
            } else Ue(n)
        }, e.prototype.complete = function() {
            var n = this.partialObserver;
            if (n.complete) try {
                n.complete()
            } catch (t) {
                Ue(t)
            }
        }, e
    })(),
    it = (function(e) {
        ne(n, e);

        function n(t, r, o) {
            var i = e.call(this) || this,
                c;
            return A(t) || !t ? c = {
                next: t != null ? t : void 0,
                error: r != null ? r : void 0,
                complete: o != null ? o : void 0
            } : c = t, i.destination = new dr(c), i
        }
        return n
    })(st);

function Ue(e) {
    Vt(e)
}

function fr(e) {
    throw e
}
var pr = {
        closed: !0,
        next: gt,
        error: fr,
        complete: gt
    },
    at = (function() {
        return typeof Symbol == "function" && Symbol.observable || "@@observable"
    })();

function $t(e) {
    return e
}

function hr(e) {
    return e.length === 0 ? $t : e.length === 1 ? e[0] : function(n) {
        return e.reduce(function(t, r) {
            return r(t)
        }, n)
    }
}
var j = (function() {
    function e(n) {
        n && (this._subscribe = n)
    }
    return e.prototype.lift = function(n) {
        var t = new e;
        return t.source = this, t.operator = n, t
    }, e.prototype.subscribe = function(n, t, r) {
        var o = this,
            i = mr(n) ? n : new it(n, t, r);
        return Ve(function() {
            var c = o,
                u = c.operator,
                s = c.source;
            i.add(u ? u.call(i, s) : s ? o._subscribe(i) : o._trySubscribe(i))
        }), i
    }, e.prototype._trySubscribe = function(n) {
        try {
            return this._subscribe(n)
        } catch (t) {
            n.error(t)
        }
    }, e.prototype.forEach = function(n, t) {
        var r = this;
        return t = wt(t), new t(function(o, i) {
            var c = new it({
                next: function(u) {
                    try {
                        n(u)
                    } catch (s) {
                        i(s), c.unsubscribe()
                    }
                },
                error: i,
                complete: o
            });
            r.subscribe(c)
        })
    }, e.prototype._subscribe = function(n) {
        var t;
        return (t = this.source) === null || t === void 0 ? void 0 : t.subscribe(n)
    }, e.prototype[at] = function() {
        return this
    }, e.prototype.pipe = function() {
        for (var n = [], t = 0; t < arguments.length; t++) n[t] = arguments[t];
        return hr(n)(this)
    }, e.prototype.toPromise = function(n) {
        var t = this;
        return n = wt(n), new n(function(r, o) {
            var i;
            t.subscribe(function(c) {
                return i = c
            }, function(c) {
                return o(c)
            }, function() {
                return r(i)
            })
        })
    }, e.create = function(n) {
        return new e(n)
    }, e
})();

function wt(e) {
    var n;
    return (n = e != null ? e : ur.Promise) !== null && n !== void 0 ? n : Promise
}

function vr(e) {
    return e && A(e.next) && A(e.error) && A(e.complete)
}

function mr(e) {
    return e && e instanceof st || vr(e) && Ut(e)
}

function br(e) {
    return A(e == null ? void 0 : e.lift)
}

function Me(e) {
    return function(n) {
        if (br(n)) return n.lift(function(t) {
            try {
                return e(t, this)
            } catch (r) {
                this.error(r)
            }
        });
        throw new TypeError("Unable to lift unknown Observable type")
    }
}

function qe(e, n, t, r, o) {
    return new yr(e, n, t, r, o)
}
var yr = (function(e) {
        ne(n, e);

        function n(t, r, o, i, c, u) {
            var s = e.call(this, t) || this;
            return s.onFinalize = c, s.shouldUnsubscribe = u, s._next = r ? function(l) {
                try {
                    r(l)
                } catch (h) {
                    t.error(h)
                }
            } : e.prototype._next, s._error = i ? function(l) {
                try {
                    i(l)
                } catch (h) {
                    t.error(h)
                } finally {
                    this.unsubscribe()
                }
            } : e.prototype._error, s._complete = o ? function() {
                try {
                    o()
                } catch (l) {
                    t.error(l)
                } finally {
                    this.unsubscribe()
                }
            } : e.prototype._complete, s
        }
        return n.prototype.unsubscribe = function() {
            var t;
            if (!this.shouldUnsubscribe || this.shouldUnsubscribe()) {
                var r = this.closed;
                e.prototype.unsubscribe.call(this), !r && ((t = this.onFinalize) === null || t === void 0 || t.call(this))
            }
        }, n
    })(st),
    Sr = ct(function(e) {
        return function() {
            e(this), this.name = "ObjectUnsubscribedError", this.message = "object unsubscribed"
        }
    }),
    jt = (function(e) {
        ne(n, e);

        function n() {
            var t = e.call(this) || this;
            return t.closed = !1, t.currentObservers = null, t.observers = [], t.isStopped = !1, t.hasError = !1, t.thrownError = null, t
        }
        return n.prototype.lift = function(t) {
            var r = new kt(this, this);
            return r.operator = t, r
        }, n.prototype._throwIfClosed = function() {
            if (this.closed) throw new Sr
        }, n.prototype.next = function(t) {
            var r = this;
            Ve(function() {
                var o, i;
                if (r._throwIfClosed(), !r.isStopped) {
                    r.currentObservers || (r.currentObservers = Array.from(r.observers));
                    try {
                        for (var c = we(r.currentObservers), u = c.next(); !u.done; u = c.next()) {
                            var s = u.value;
                            s.next(t)
                        }
                    } catch (l) {
                        o = {
                            error: l
                        }
                    } finally {
                        try {
                            u && !u.done && (i = c.return) && i.call(c)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                }
            })
        }, n.prototype.error = function(t) {
            var r = this;
            Ve(function() {
                if (r._throwIfClosed(), !r.isStopped) {
                    r.hasError = r.isStopped = !0, r.thrownError = t;
                    for (var o = r.observers; o.length;) o.shift().error(t)
                }
            })
        }, n.prototype.complete = function() {
            var t = this;
            Ve(function() {
                if (t._throwIfClosed(), !t.isStopped) {
                    t.isStopped = !0;
                    for (var r = t.observers; r.length;) r.shift().complete()
                }
            })
        }, n.prototype.unsubscribe = function() {
            this.isStopped = this.closed = !0, this.observers = this.currentObservers = null
        }, Object.defineProperty(n.prototype, "observed", {
            get: function() {
                var t;
                return ((t = this.observers) === null || t === void 0 ? void 0 : t.length) > 0
            },
            enumerable: !1,
            configurable: !0
        }), n.prototype._trySubscribe = function(t) {
            return this._throwIfClosed(), e.prototype._trySubscribe.call(this, t)
        }, n.prototype._subscribe = function(t) {
            return this._throwIfClosed(), this._checkFinalizedStatuses(t), this._innerSubscribe(t)
        }, n.prototype._innerSubscribe = function(t) {
            var r = this,
                o = this,
                i = o.hasError,
                c = o.isStopped,
                u = o.observers;
            return i || c ? Nt : (this.currentObservers = null, u.push(t), new Ee(function() {
                r.currentObservers = null, ze(u, t)
            }))
        }, n.prototype._checkFinalizedStatuses = function(t) {
            var r = this,
                o = r.hasError,
                i = r.thrownError,
                c = r.isStopped;
            o ? t.error(i) : c && t.complete()
        }, n.prototype.asObservable = function() {
            var t = new j;
            return t.source = this, t
        }, n.create = function(t, r) {
            return new kt(t, r)
        }, n
    })(j),
    kt = (function(e) {
        ne(n, e);

        function n(t, r) {
            var o = e.call(this) || this;
            return o.destination = t, o.source = r, o
        }
        return n.prototype.next = function(t) {
            var r, o;
            (o = (r = this.destination) === null || r === void 0 ? void 0 : r.next) === null || o === void 0 || o.call(r, t)
        }, n.prototype.error = function(t) {
            var r, o;
            (o = (r = this.destination) === null || r === void 0 ? void 0 : r.error) === null || o === void 0 || o.call(r, t)
        }, n.prototype.complete = function() {
            var t, r;
            (r = (t = this.destination) === null || t === void 0 ? void 0 : t.complete) === null || r === void 0 || r.call(t)
        }, n.prototype._subscribe = function(t) {
            var r, o;
            return (o = (r = this.source) === null || r === void 0 ? void 0 : r.subscribe(t)) !== null && o !== void 0 ? o : Nt
        }, n
    })(jt);
(function(e) {
    ne(n, e);

    function n(t) {
        var r = e.call(this) || this;
        return r._value = t, r
    }
    return Object.defineProperty(n.prototype, "value", {
        get: function() {
            return this.getValue()
        },
        enumerable: !1,
        configurable: !0
    }), n.prototype._subscribe = function(t) {
        var r = e.prototype._subscribe.call(this, t);
        return !r.closed && t.next(this._value), r
    }, n.prototype.getValue = function() {
        var t = this,
            r = t.hasError,
            o = t.thrownError,
            i = t._value;
        if (r) throw o;
        return this._throwIfClosed(), i
    }, n.prototype.next = function(t) {
        e.prototype.next.call(this, this._value = t)
    }, n
})(jt);
var gr = {
        now: function() {
            return Date.now()
        }
    },
    wr = (function(e) {
        ne(n, e);

        function n(t, r) {
            return e.call(this) || this
        }
        return n.prototype.schedule = function(t, r) {
            return this
        }, n
    })(Ee),
    Tt = {
        setInterval: function(e, n) {
            for (var t = [], r = 2; r < arguments.length; r++) t[r - 2] = arguments[r];
            return setInterval.apply(void 0, We([e, n], Fe(t)))
        },
        clearInterval: function(e) {
            return clearInterval(e)
        },
        delegate: void 0
    },
    kr = (function(e) {
        ne(n, e);

        function n(t, r) {
            var o = e.call(this, t, r) || this;
            return o.scheduler = t, o.work = r, o.pending = !1, o
        }
        return n.prototype.schedule = function(t, r) {
            var o;
            if (r === void 0 && (r = 0), this.closed) return this;
            this.state = t;
            var i = this.id,
                c = this.scheduler;
            return i != null && (this.id = this.recycleAsyncId(c, i, r)), this.pending = !0, this.delay = r, this.id = (o = this.id) !== null && o !== void 0 ? o : this.requestAsyncId(c, this.id, r), this
        }, n.prototype.requestAsyncId = function(t, r, o) {
            return o === void 0 && (o = 0), Tt.setInterval(t.flush.bind(t, this), o)
        }, n.prototype.recycleAsyncId = function(t, r, o) {
            if (o === void 0 && (o = 0), o != null && this.delay === o && this.pending === !1) return r;
            r != null && Tt.clearInterval(r)
        }, n.prototype.execute = function(t, r) {
            if (this.closed) return new Error("executing a cancelled action");
            this.pending = !1;
            var o = this._execute(t, r);
            if (o) return o;
            this.pending === !1 && this.id != null && (this.id = this.recycleAsyncId(this.scheduler, this.id, null))
        }, n.prototype._execute = function(t, r) {
            var o = !1,
                i;
            try {
                this.work(t)
            } catch (c) {
                o = !0, i = c || new Error("Scheduled action threw falsy error")
            }
            if (o) return this.unsubscribe(), i
        }, n.prototype.unsubscribe = function() {
            if (!this.closed) {
                var t = this,
                    r = t.id,
                    o = t.scheduler,
                    i = o.actions;
                this.work = this.state = this.scheduler = null, this.pending = !1, ze(i, this), r != null && (this.id = this.recycleAsyncId(o, r, null)), this.delay = null, e.prototype.unsubscribe.call(this)
            }
        }, n
    })(wr),
    Ct = (function() {
        function e(n, t) {
            t === void 0 && (t = e.now), this.schedulerActionCtor = n, this.now = t
        }
        return e.prototype.schedule = function(n, t, r) {
            return t === void 0 && (t = 0), new this.schedulerActionCtor(this, n).schedule(r, t)
        }, e.now = gr.now, e
    })(),
    Tr = (function(e) {
        ne(n, e);

        function n(t, r) {
            r === void 0 && (r = Ct.now);
            var o = e.call(this, t, r) || this;
            return o.actions = [], o._active = !1, o
        }
        return n.prototype.flush = function(t) {
            var r = this.actions;
            if (this._active) {
                r.push(t);
                return
            }
            var o;
            this._active = !0;
            do
                if (o = t.execute(t.state, t.delay)) break; while (t = r.shift());
            if (this._active = !1, o) {
                for (; t = r.shift();) t.unsubscribe();
                throw o
            }
        }, n
    })(Ct);
new Tr(kr);

function Cr(e) {
    return e && A(e.schedule)
}

function _r(e) {
    return e[e.length - 1]
}

function Ft(e) {
    return Cr(_r(e)) ? e.pop() : void 0
}
var Wt = function(e) {
    return e && typeof e.length == "number" && typeof e != "function"
};

function zt(e) {
    return A(e == null ? void 0 : e.then)
}

function qt(e) {
    return A(e[at])
}

function Qt(e) {
    return Symbol.asyncIterator && A(e == null ? void 0 : e[Symbol.asyncIterator])
}

function Yt(e) {
    return new TypeError("You provided " + (e !== null && typeof e == "object" ? "an invalid object" : "'" + e + "'") + " where a stream was expected. You can provide an Observable, Promise, ReadableStream, Array, AsyncIterable, or Iterable.")
}

function Er() {
    return typeof Symbol != "function" || !Symbol.iterator ? "@@iterator" : Symbol.iterator
}
var Bt = Er();

function Gt(e) {
    return A(e == null ? void 0 : e[Bt])
}

function Jt(e) {
    return sr(this, arguments, function() {
        var n, t, r, o;
        return Dt(this, function(i) {
            switch (i.label) {
                case 0:
                    n = e.getReader(), i.label = 1;
                case 1:
                    i.trys.push([1, , 9, 10]), i.label = 2;
                case 2:
                    return [4, ge(n.read())];
                case 3:
                    return t = i.sent(), r = t.value, o = t.done, o ? [4, ge(void 0)] : [3, 5];
                case 4:
                    return [2, i.sent()];
                case 5:
                    return [4, ge(r)];
                case 6:
                    return [4, i.sent()];
                case 7:
                    return i.sent(), [3, 2];
                case 8:
                    return [3, 10];
                case 9:
                    return n.releaseLock(), [7];
                case 10:
                    return [2]
            }
        })
    })
}

function Kt(e) {
    return A(e == null ? void 0 : e.getReader)
}

function Ie(e) {
    if (e instanceof j) return e;
    if (e != null) {
        if (qt(e)) return Mr(e);
        if (Wt(e)) return Ir(e);
        if (zt(e)) return xr(e);
        if (Qt(e)) return Ht(e);
        if (Gt(e)) return Pr(e);
        if (Kt(e)) return Or(e)
    }
    throw Yt(e)
}

function Mr(e) {
    return new j(function(n) {
        var t = e[at]();
        if (A(t.subscribe)) return t.subscribe(n);
        throw new TypeError("Provided object does not correctly implement Symbol.observable")
    })
}

function Ir(e) {
    return new j(function(n) {
        for (var t = 0; t < e.length && !n.closed; t++) n.next(e[t]);
        n.complete()
    })
}

function xr(e) {
    return new j(function(n) {
        e.then(function(t) {
            n.closed || (n.next(t), n.complete())
        }, function(t) {
            return n.error(t)
        }).then(null, Vt)
    })
}

function Pr(e) {
    return new j(function(n) {
        var t, r;
        try {
            for (var o = we(e), i = o.next(); !i.done; i = o.next()) {
                var c = i.value;
                if (n.next(c), n.closed) return
            }
        } catch (u) {
            t = {
                error: u
            }
        } finally {
            try {
                i && !i.done && (r = o.return) && r.call(o)
            } finally {
                if (t) throw t.error
            }
        }
        n.complete()
    })
}

function Ht(e) {
    return new j(function(n) {
        Ar(e, n).catch(function(t) {
            return n.error(t)
        })
    })
}

function Or(e) {
    return Ht(Jt(e))
}

function Ar(e, n) {
    var t, r, o, i;
    return cr(this, void 0, void 0, function() {
        var c, u;
        return Dt(this, function(s) {
            switch (s.label) {
                case 0:
                    s.trys.push([0, 5, 6, 11]), t = ar(e), s.label = 1;
                case 1:
                    return [4, t.next()];
                case 2:
                    if (r = s.sent(), !!r.done) return [3, 4];
                    if (c = r.value, n.next(c), n.closed) return [2];
                    s.label = 3;
                case 3:
                    return [3, 1];
                case 4:
                    return [3, 11];
                case 5:
                    return u = s.sent(), o = {
                        error: u
                    }, [3, 11];
                case 6:
                    return s.trys.push([6, , 9, 10]), r && !r.done && (i = t.return) ? [4, i.call(t)] : [3, 8];
                case 7:
                    s.sent(), s.label = 8;
                case 8:
                    return [3, 10];
                case 9:
                    if (o) throw o.error;
                    return [7];
                case 10:
                    return [7];
                case 11:
                    return n.complete(), [2]
            }
        })
    })
}

function me(e, n, t, r, o) {
    r === void 0 && (r = 0), o === void 0 && (o = !1);
    var i = n.schedule(function() {
        t(), o ? e.add(this.schedule(null, r)) : this.unsubscribe()
    }, r);
    if (e.add(i), !o) return i
}

function Zt(e, n) {
    return n === void 0 && (n = 0), Me(function(t, r) {
        t.subscribe(qe(r, function(o) {
            return me(r, e, function() {
                return r.next(o)
            }, n)
        }, function() {
            return me(r, e, function() {
                return r.complete()
            }, n)
        }, function(o) {
            return me(r, e, function() {
                return r.error(o)
            }, n)
        }))
    })
}

function Xt(e, n) {
    return n === void 0 && (n = 0), Me(function(t, r) {
        r.add(e.schedule(function() {
            return t.subscribe(r)
        }, n))
    })
}

function Rr(e, n) {
    return Ie(e).pipe(Xt(n), Zt(n))
}

function Lr(e, n) {
    return Ie(e).pipe(Xt(n), Zt(n))
}

function Dr(e, n) {
    return new j(function(t) {
        var r = 0;
        return n.schedule(function() {
            r === e.length ? t.complete() : (t.next(e[r++]), t.closed || this.schedule())
        })
    })
}

function Nr(e, n) {
    return new j(function(t) {
        var r;
        return me(t, n, function() {
                r = e[Bt](), me(t, n, function() {
                    var o, i, c;
                    try {
                        o = r.next(), i = o.value, c = o.done
                    } catch (u) {
                        t.error(u);
                        return
                    }
                    c ? t.complete() : t.next(i)
                }, 0, !0)
            }),
            function() {
                return A(r == null ? void 0 : r.return) && r.return()
            }
    })
}

function en(e, n) {
    if (!e) throw new Error("Iterable cannot be null");
    return new j(function(t) {
        me(t, n, function() {
            var r = e[Symbol.asyncIterator]();
            me(t, n, function() {
                r.next().then(function(o) {
                    o.done ? t.complete() : t.next(o.value)
                })
            }, 0, !0)
        })
    })
}

function Ur(e, n) {
    return en(Jt(e), n)
}

function Vr(e, n) {
    if (e != null) {
        if (qt(e)) return Rr(e, n);
        if (Wt(e)) return Dr(e, n);
        if (zt(e)) return Lr(e, n);
        if (Qt(e)) return en(e, n);
        if (Gt(e)) return Nr(e, n);
        if (Kt(e)) return Ur(e, n)
    }
    throw Yt(e)
}

function $r(e, n) {
    return n ? Vr(e, n) : Ie(e)
}
ct(function(e) {
    return function(n) {
        n === void 0 && (n = null), e(this), this.message = "Timeout has occurred", this.name = "TimeoutError", this.info = n
    }
});

function xe(e, n) {
    return Me(function(t, r) {
        var o = 0;
        t.subscribe(qe(r, function(i) {
            r.next(e.call(n, i, o++))
        }))
    })
}

function jr(e, n, t, r, o, i, c, u) {
    var s = [],
        l = 0,
        h = 0,
        C = !1,
        _ = function() {
            C && !s.length && !l && n.complete()
        },
        y = function(f) {
            return l < r ? I(f) : s.push(f)
        },
        I = function(f) {
            l++;
            var x = !1;
            Ie(t(f, h++)).subscribe(qe(n, function(m) {
                n.next(m)
            }, function() {
                x = !0
            }, void 0, function() {
                if (x) try {
                    l--;
                    for (var m = function() {
                            var g = s.shift();
                            c || I(g)
                        }; s.length && l < r;) m();
                    _()
                } catch (g) {
                    n.error(g)
                }
            }))
        };
    return e.subscribe(qe(n, y, function() {
            C = !0, _()
        })),
        function() {}
}

function tn(e, n, t) {
    return t === void 0 && (t = 1 / 0), A(n) ? tn(function(r, o) {
        return xe(function(i, c) {
            return n(r, i, o, c)
        })(Ie(e(r, o)))
    }, t) : (typeof n == "number" && (t = n), Me(function(r, o) {
        return jr(r, o, e, t)
    }))
}

function Fr(e) {
    return tn($t, e)
}

function Wr() {
    return Fr(1)
}

function _t() {
    for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
    return Wr()($r(e, Ft(e)))
}

function Pe() {
    for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
    var t = Ft(e);
    return Me(function(r, o) {
        (t ? _t(e, r, t) : _t(e, r)).subscribe(o)
    })
}
var zr = "lk";

function nn(e) {
    return typeof e > "u" ? !1 : qr(e) || Qr(e)
}

function qr(e) {
    var n;
    return e ? e.hasOwnProperty("participant") && e.hasOwnProperty("source") && e.hasOwnProperty("track") && typeof((n = e.publication) == null ? void 0 : n.track) < "u" : !1
}

function Qr(e) {
    return e ? e.hasOwnProperty("participant") && e.hasOwnProperty("source") && e.hasOwnProperty("publication") && typeof e.publication < "u" : !1
}

function Yr(e) {
    return e ? e.hasOwnProperty("participant") && e.hasOwnProperty("source") && typeof e.publication > "u" : !1
}

function Io(e) {
    if (typeof e == "string" || typeof e == "number") return "".concat(e);
    if (Yr(e)) return "".concat(e.participant.identity, "_").concat(e.source, "_placeholder");
    if (nn(e)) return "".concat(e.participant.identity, "_").concat(e.publication.source, "_").concat(e.publication.trackSid);
    throw new Error("Can't generate a id for the given track reference: ".concat(e))
}

function xo(e) {
    return e instanceof er
}
var Br = [w.ConnectionStateChanged, w.RoomMetadataChanged, w.ActiveSpeakersChanged, w.ConnectionQualityChanged, w.ParticipantConnected, w.ParticipantDisconnected, w.ParticipantPermissionsChanged, w.ParticipantMetadataChanged, w.ParticipantNameChanged, w.ParticipantAttributesChanged, w.TrackMuted, w.TrackUnmuted, w.TrackPublished, w.TrackUnpublished, w.TrackStreamStateChanged, w.TrackSubscriptionFailed, w.TrackSubscriptionPermissionChanged, w.TrackSubscriptionStatusChanged],
    Gr = [...Br, w.LocalTrackPublished, w.LocalTrackUnpublished];
M.TrackPublished, M.TrackUnpublished, M.TrackMuted, M.TrackUnmuted, M.TrackStreamStateChanged, M.TrackSubscribed, M.TrackUnsubscribed, M.TrackSubscriptionPermissionChanged, M.TrackSubscriptionFailed, M.LocalTrackPublished, M.LocalTrackUnpublished;
var Jr = [M.ConnectionQualityChanged, M.IsSpeakingChanged, M.ParticipantMetadataChanged, M.ParticipantPermissionsChanged, M.TrackMuted, M.TrackUnmuted, M.TrackPublished, M.TrackUnpublished, M.TrackStreamStateChanged, M.TrackSubscriptionFailed, M.TrackSubscriptionPermissionChanged, M.TrackSubscriptionStatusChanged];
[...Jr, M.LocalTrackPublished, M.LocalTrackUnpublished];
var Qe = ir.getLogger("lk-components-js");
Qe.setDefaultLevel("WARN");

function rn(e) {
    return typeof e == "object"
}

function on(e) {
    return Array.isArray(e) && e.filter(rn).length > 0
}

function Kr(e) {
    return "".concat(zr, "-").concat(e)
}

function Po(e) {
    const n = Et(e),
        t = cn(e.participant).pipe(xe(() => Et(e)), Pe(n));
    return {
        className: Kr(e.source === B.Source.Camera || e.source === B.Source.ScreenShare ? "participant-media-video" : "participant-media-audio"),
        trackObserver: t
    }
}

function Et(e) {
    if (nn(e)) return e.publication; {
        const {
            source: n,
            name: t,
            participant: r
        } = e;
        if (n && t) return r.getTrackPublications().find(o => o.source === n && o.trackName === t);
        if (t) return r.getTrackPublicationByName(t);
        if (n) return r.getTrackPublication(n);
        throw new Error("At least one of source and name needs to be defined")
    }
}

function Hr(e, ...n) {
    return new j(t => {
        const r = () => {
            t.next(e)
        };
        return n.forEach(o => {
            e.on(o, r)
        }), () => {
            n.forEach(o => {
                e.off(o, r)
            })
        }
    }).pipe(Pe(e))
}

function Zr(e, n) {
    return new j(t => {
        const r = (...o) => {
            t.next(o)
        };
        return e.on(n, r), () => {
            e.off(n, r)
        }
    })
}

function Xr(e) {
    return Zr(e, w.ConnectionStateChanged).pipe(xe(([n]) => n), Pe(e.state))
}

function eo(e, ...n) {
    return new j(t => {
        const r = () => {
            t.next(e)
        };
        return n.forEach(o => {
            e.on(o, r)
        }), () => {
            n.forEach(o => {
                e.off(o, r)
            })
        }
    }).pipe(Pe(e))
}

function cn(e) {
    return eo(e, M.TrackMuted, M.TrackUnmuted, M.ParticipantPermissionsChanged, M.TrackPublished, M.TrackUnpublished, M.LocalTrackPublished, M.LocalTrackUnpublished, M.MediaDevicesError, M.TrackSubscriptionStatusChanged).pipe(xe(n => {
        const {
            isMicrophoneEnabled: t,
            isCameraEnabled: r,
            isScreenShareEnabled: o
        } = n, i = n.getTrackPublication(B.Source.Microphone), c = n.getTrackPublication(B.Source.Camera);
        return {
            isCameraEnabled: r,
            isMicrophoneEnabled: t,
            isScreenShareEnabled: o,
            cameraTrack: c,
            microphoneTrack: i,
            participant: n
        }
    }))
}
new TextEncoder;
new TextDecoder;

function Oo() {
    return {
        className: "lk-room-container"
    }
}

function Mt(e, n, t = !0) {
    const r = [e.localParticipant, ...Array.from(e.remoteParticipants.values())],
        o = [];
    return r.forEach(i => {
        n.forEach(c => {
            const u = Array.from(i.trackPublications.values()).filter(s => s.source === c && (!t || s.track)).map(s => ({
                participant: i,
                publication: s,
                source: s.source
            }));
            o.push(...u)
        })
    }), {
        trackReferences: o,
        participants: r
    }
}

function to(e, n, t) {
    var r, o;
    const i = (r = t.additionalRoomEvents) != null ? r : Gr,
        c = (o = t.onlySubscribed) != null ? o : !0,
        u = Array.from(new Set([w.ParticipantConnected, w.ParticipantDisconnected, w.ConnectionStateChanged, w.LocalTrackPublished, w.LocalTrackUnpublished, w.TrackPublished, w.TrackUnpublished, w.TrackSubscriptionStatusChanged, ...i]).values());
    return Hr(e, ...u).pipe(xe(s => {
        const l = Mt(s, n, c);
        return Qe.debug("TrackReference[] was updated. (length ".concat(l.trackReferences.length, ")"), l), l
    }), Pe(Mt(e, n, c)))
}
a.createContext(void 0);
const no = a.createContext(void 0);

function ro() {
    return a.useContext(no)
}

function Ao(e) {
    const n = ro(),
        t = e != null ? e : n;
    if (!t) throw new Error("No TrackRef, make sure you are inside a TrackRefContext or pass the TrackRef explicitly");
    return t
}
a.createContext(void 0);
const oo = a.createContext(void 0);

function sn() {
    return a.useContext(oo)
}

function ut(e) {
    const n = sn(),
        t = e != null ? e : n;
    if (!t) throw new Error("No room provided, make sure you are inside a Room context or pass the room explicitly");
    return t
}
const Ro = a.createContext(void 0);

function io(e, n, t = !0) {
    const [r, o] = a.useState(n);
    return a.useEffect(() => {
        if (t && o(n), typeof window > "u" || !e) return;
        const i = e.subscribe(o);
        return () => i.unsubscribe()
    }, [e, t]), r
}

function co(e) {
    const n = ut(e),
        t = a.useMemo(() => Xr(n), [n]);
    return io(t, n.state)
}

function Lo(e = {}) {
    const n = ut(e.room),
        [t, r] = a.useState(n.localParticipant),
        [o, i] = a.useState(t.isMicrophoneEnabled),
        [c, u] = a.useState(t.isMicrophoneEnabled),
        [s, l] = a.useState(t.lastMicrophoneError),
        [h, C] = a.useState(t.lastCameraError),
        [_, y] = a.useState(t.isMicrophoneEnabled),
        [I, f] = a.useState(void 0),
        [x, m] = a.useState(void 0),
        g = R => {
            u(R.isCameraEnabled), i(R.isMicrophoneEnabled), y(R.isScreenShareEnabled), m(R.cameraTrack), f(R.microphoneTrack), l(R.participant.lastMicrophoneError), C(R.participant.lastCameraError), r(R.participant)
        };
    return a.useEffect(() => {
        const R = cn(n.localParticipant).subscribe(g);
        return () => R.unsubscribe()
    }, [n]), {
        isMicrophoneEnabled: o,
        isScreenShareEnabled: _,
        isCameraEnabled: c,
        microphoneTrack: I,
        cameraTrack: x,
        lastMicrophoneError: s,
        lastCameraError: h,
        localParticipant: t
    }
}

function so(e = [B.Source.Camera, B.Source.Microphone, B.Source.ScreenShare, B.Source.ScreenShareAudio, B.Source.Unknown], n = {}) {
    const t = ut(n.room),
        [r, o] = a.useState([]),
        [i, c] = a.useState([]),
        u = a.useMemo(() => e.map(s => rn(s) ? s.source : s), [JSON.stringify(e)]);
    return a.useEffect(() => {
        const s = to(t, u, {
            additionalRoomEvents: n.updateOnlyOn,
            onlySubscribed: n.onlySubscribed
        }).subscribe(({
            trackReferences: l,
            participants: h
        }) => {
            Qe.debug("setting track bundles", l, h), o(l), c(h)
        });
        return () => s.unsubscribe()
    }, [t, JSON.stringify(n.onlySubscribed), JSON.stringify(n.updateOnlyOn), JSON.stringify(e)]), a.useMemo(() => {
        if (on(e)) {
            const s = uo(e, i),
                l = Array.from(r);
            return i.forEach(h => {
                var C;
                s.has(h.identity) && ((C = s.get(h.identity)) != null ? C : []).forEach(_ => {
                    if (r.find(({
                            participant: I,
                            publication: f
                        }) => h.identity === I.identity && f.source === _)) return;
                    Qe.debug("Add ".concat(_, " placeholder for participant ").concat(h.identity, "."));
                    const y = {
                        participant: h,
                        source: _
                    };
                    l.push(y)
                })
            }), l
        } else return r
    }, [r, i, e])
}

function ao(e, n) {
    const t = new Set(e);
    for (const r of n) t.delete(r);
    return t
}

function uo(e, n) {
    const t = new Map;
    if (on(e)) {
        const r = e.filter(o => o.withPlaceholder).map(o => o.source);
        n.forEach(o => {
            const i = o.getTrackPublications().map(u => {
                    var s;
                    return (s = u.track) == null ? void 0 : s.source
                }).filter(u => u !== void 0),
                c = Array.from(ao(new Set(r), new Set(i)));
            c.length > 0 && t.set(o.identity, c)
        })
    }
    return t
}
var $e = (e => (e.Local = "local", e.Remote = "remote", e))($e || {}),
    an = (e => (e.Audio = "audio", e.Video = "video", e))(an || {}),
    _e = (e => (e.Camera = "camera", e.Microphone = "microphone", e.ScreenShare = "screen_share", e))(_e || {});
const lo = e => e.flatMap(n => {
        const t = [],
            r = n.publication.trackName,
            o = n.participant.identity,
            i = n.participant.isLocal ? "local" : "remote";
        let c;
        n.publication.source === B.Source.Camera ? c = "camera" : n.publication.source === B.Source.ScreenShare ? c = "screen_share" : c = "microphone";
        const u = (s, l) => {
            s && t.push({
                id: s.mediaStreamTrack.id,
                source: c,
                name: r,
                userName: o,
                origin: i,
                media: l,
                track: s.mediaStreamTrack,
                isMuted: s.isMuted,
                isSystemMuted: s.mediaStreamTrack.muted,
                setMuted: h => {
                    s.mediaStreamTrack.enabled = !h
                },
                onEnded: h => {
                    s.on("ended", h)
                },
                offEnded: h => {
                    s.off("ended", h)
                }
            })
        };
        return u(n.publication.audioTrack, "audio"), u(n.publication.videoTrack, "video"), t
    }),
    Xe = (e, n) => {
        var r;
        const t = {
            id: e.id,
            source: n.source,
            name: n.name,
            userName: n.userName,
            media: e.kind === "audio" ? "audio" : "video",
            origin: n.origin,
            track: e,
            get isMuted() {
                return !e.enabled || e.muted
            },
            get isSystemMuted() {
                return e.muted
            },
            setMuted: o => {
                var i;
                e.enabled = !o, (i = n.mutedCb) == null || i.call(n, t.isMuted, t.isSystemMuted)
            },
            onEnded: o => {
                e.onended = o
            },
            offEnded: o => {
                e.onended = null
            }
        };
        return e.onmute = () => {
            var o;
            (o = n.mutedCb) == null || o.call(n, t.isMuted, t.isSystemMuted)
        }, e.onunmute = () => {
            var o;
            (o = n.mutedCb) == null || o.call(n, t.isMuted, t.isSystemMuted)
        }, (r = n.mutedCb) == null || r.call(n, t.isMuted, t.isSystemMuted), t
    },
    fo = 500,
    po = 1e3,
    ho = 3,
    vo = 2e3;

function It({
    packets: e,
    packetsLost: n,
    fractionLost: t,
    rtt: r
}) {
    let o;
    if (e !== void 0 && n !== void 0 ? o = n * 100 / e : t !== void 0 && (o = t * 100), o === void 0 || r === void 0 || isNaN(o)) return;
    const i = r * 1e3 / 2;
    let c = i / 40;
    i > 160 && (c = (i - 120) / 10);
    const u = 100 - c - o;
    return Math.max(u, 0)
}

function xt(e) {
    if (e === void 0) return ie.Unknown;
    let n;
    return e <= 0 ? n = 1 : e >= 100 ? n = 4.5 : n = 1 + .035 * e + 7e-6 * e * (e - 60) * (100 - e), n > 4 ? ie.Excellent : n > 3.5 ? ie.Good : ie.Poor
}
class Se {
    constructor(n, t) {
        W(this, "size");
        W(this, "type");
        W(this, "buf");
        this.size = n, this.type = t, this.buf = []
    }
    push(n) {
        n !== void 0 && (this.buf.length === this.size && this.buf.shift(), this.buf.push(n))
    }
    get() {
        if (this.buf.length !== 0) switch (this.type) {
            case "cumulative":
                {
                    const n = this.buf[0];
                    return (this.buf[this.buf.length - 1] - n) / this.buf.length
                }
            case "individual":
                return this.buf.reduce((n, t) => n + t, 0) / this.buf.length
        }
    }
}
class mo {
    constructor(n, t) {
        W(this, "pc");
        W(this, "cb");
        W(this, "reportTimerId");
        W(this, "pollingTimerId");
        W(this, "localWindow");
        W(this, "remoteWindow");
        W(this, "reportTimestamps");
        W(this, "stale", !1);
        const r = ho;
        this.pc = n, this.cb = t, this.reportTimerId = void 0, this.localWindow = {
            packetsLost: new Se(r, "cumulative"),
            fractionLost: new Se(r, "individual"),
            rtt: new Se(r, "individual")
        }, this.remoteWindow = {
            packetsSent: new Se(r, "cumulative"),
            packetsLost: new Se(r, "cumulative"),
            rtt: new Se(r, "individual")
        }, this.reportTimestamps = {}
    }
    start() {
        this.reportTimerId || this.pollingTimerId || (this.reportTimerId = window.setInterval(this.report.bind(this), fo), this.pollingTimerId = window.setInterval(this.poll.bind(this), po))
    }
    stop() {
        window.clearInterval(this.reportTimerId), window.clearInterval(this.pollingTimerId), this.reportTimerId = void 0, this.pollingTimerId = void 0
    }
    isFresh(n) {
        let t = !0;
        if (this.reportTimestamps[n.type] !== void 0) {
            const o = Date.now() - this.reportTimestamps[n.type] < vo;
            t = n.timestamp !== this.reportTimestamps[n.type] || o
        }
        return this.reportTimestamps[n.type] = n.timestamp, t
    }
    async poll() {
        const n = await this.pc.getStats();
        let t;
        const r = {};
        let o = !1;
        n.forEach(c => {
            const u = c.kind || c.mediaType;
            c.type === "transport" && c.selectedCandidatePairId && (t = c.selectedCandidatePairId), c.type === "remote-inbound-rtp" && u === "audio" && (o || (o = !this.isFresh(c)), this.localWindow.packetsLost.push(c.packetsLost), this.localWindow.fractionLost.push(c.fractionLost)), c.type === "inbound-rtp" && u === "audio" && (o || (o = !this.isFresh(c)), this.remoteWindow.packetsSent.push(c.packetsReceived + c.packetsLost), this.remoteWindow.packetsLost.push(c.packetsLost)), c.type === "candidate-pair" && (r[c.id] = c)
        }), this.stale = o;
        const i = t !== void 0 && r[t];
        i ? (this.remoteWindow.rtt.push(i.currentRoundTripTime), this.localWindow.rtt.push(i.currentRoundTripTime)) : $.error("QualityMonitor no candidate-pair found!")
    }
    report() {
        if (this.stale) return this.cb({
            local: ie.Unknown,
            general: ie.Unknown
        });
        const n = It({
                packets: void 0,
                packetsLost: this.localWindow.packetsLost.get(),
                fractionLost: this.localWindow.fractionLost.get(),
                rtt: this.localWindow.rtt.get()
            }),
            t = It({
                packets: this.remoteWindow.packetsSent.get(),
                packetsLost: this.remoteWindow.packetsLost.get(),
                fractionLost: void 0,
                rtt: this.remoteWindow.rtt.get()
            }),
            r = [n, t].filter(u => u !== void 0),
            o = r.length > 0 ? Math.min(...r) : void 0,
            i = xt(n),
            c = xt(o);
        this.cb({
            local: i,
            general: c
        })
    }
}
class je {
    static abortPendingNegotiation(n) {
        this._controller && (this._controller.abort("[abort] ".concat(n)), this._controller = null)
    }
    static clearNegotiation() {
        this._controller = null
    }
    static beginNegotiation() {
        this._controller && this._controller.abort("[abort] Starting new negotiation");
        const n = new AbortController;
        return this._controller = n, n.signal
    }
}
W(je, "_controller", null);
const Pt = "User",
    Ot = "Assistant",
    At = 0,
    bo = [];

function yo(e) {
    let n;
    try {
        return n = JSON.parse(e), typeof n != "object" ? {
            success: !1,
            result: e
        } : {
            success: !0,
            result: n
        }
    } catch (t) {
        return {
            success: !1,
            result: e
        }
    }
}
const lt = a.createContext({
        room: void 0,
        getTracks: () => bo,
        getConnectionState: () => null,
        selectVoiceModeMetadata: () => {
            throw new Error("Null implementation - please provide a proper context")
        },
        getTokenSetup: () => {},
        initVoiceMode: () => Promise.reject(new Error("Null implementation - please provide a proper context"))
    }),
    un = () => a.useContext(lt),
    Do = ({
        children: e
    }) => {
        const n = sn(),
            t = so(),
            r = co(n),
            o = Ye(),
            i = a.useCallback(h => {
                const C = lo(t);
                return h ? C.filter(_ => h.includes(_.source)) : C
            }, [t]),
            c = a.useCallback(() => r, [r]),
            u = a.useCallback(h => {
                const {
                    default_voice_mode: C,
                    modes: _
                } = h, y = _.find(I => I.mode === C);
                if (!y) throw new Error("No voice status mode found for default mode " + C);
                return y
            }, []),
            s = a.useCallback(async (h, C) => {
                var y;
                const _ = await Rt.startLivekitSession(h, C.eventSource, C.proofOfWorkAnswer);
                return _.token && _.url && _.e2ee_key ? (rt({
                    conversationId: (y = h.conversation_id) != null ? y : C.clientThreadId,
                    voiceSessionId: h.voice_session_id,
                    voiceMode: _.voice_mode_decision.voice_mode,
                    credentials: Ce(ve({}, _), {
                        e2eeKey: _.e2ee_key
                    })
                }, o), {
                    type: "livekit",
                    success: !0
                }) : {
                    type: "livekit",
                    success: !1,
                    error: "get_token failed to return expected fields .token, .url and .e2ee_key",
                    response: _
                }
            }, [o]),
            l = a.useMemo(() => ({
                room: n,
                getTracks: i,
                getConnectionState: c,
                getTokenSetup: () => {},
                initVoiceMode: s,
                selectVoiceModeMetadata: u
            }), [n, i, c, s, u]);
        return nt.jsx(lt.Provider, {
            value: l,
            children: e
        })
    };
let et;
const So = () => (et === void 0 && (et = new TextEncoder), et);

function go(e) {
    switch (e) {
        case "checking":
            return z.Connecting;
        case "connected":
        case "completed":
            return z.Connected;
        case "disconnected":
            return z.Reconnecting;
        case "new":
        case "failed":
        case "closed":
            return z.Disconnected
    }
}
const No = ({
    children: e
}) => {
    const n = Ye(),
        t = vn(mn()),
        r = a.useRef(null),
        o = a.useRef(void 0),
        i = a.useRef(void 0),
        c = a.useCallback(async ({
            avmTrack: S,
            initialSetup: p = !1
        }) => {
            const d = S.media === an.Audio ? o : i;
            if (d.current && !d.current.stopped) await d.current.sender.replaceTrack(S.track);
            else if (p) d.current = ue().addTransceiver(S.track);
            else throw new Error("Cannot replace track on ".concat(S.media, " transceiver that was not initialized."))
        }, []),
        [u, s] = a.useState(void 0),
        [l, h] = a.useState(void 0),
        [C, _] = a.useState(void 0),
        y = a.useRef(void 0),
        I = a.useRef(void 0),
        f = a.useRef(void 0),
        x = n(S => S.voiceMode),
        [m, g] = a.useState(null),
        R = a.useCallback(() => m, [m]),
        L = a.useCallback(S => {
            te(p => De(p, d => {
                d && (d.activeSpeakers.some(v => v.identity === S) || d.activeSpeakers.push({
                    identity: S
                }))
            }))
        }, []),
        O = a.useCallback(S => {
            te(p => De(p, d => {
                d && (d.activeSpeakers = d.activeSpeakers.filter(v => v.identity !== S))
            }))
        }, []),
        ce = a.useRef(null),
        G = a.useRef([]),
        X = a.useRef([]),
        F = a.useRef([]),
        J = a.useRef([]),
        E = a.useRef([]),
        P = a.useRef(!1),
        q = a.useRef([]),
        b = a.useCallback(S => {
            q.current.forEach(p => p(S))
        }, []),
        D = a.useRef(m);
    a.useEffect(() => {
        D.current = m
    }, [m]);
    const K = a.useRef(void 0);
    a.useEffect(() => {
        K.current = u
    }, [u]);
    const N = a.useRef(void 0);
    a.useEffect(() => {
        N.current = C
    }, [C]);
    const se = a.useRef(void 0),
        ae = a.useRef(void 0),
        ee = a.useRef(void 0),
        [ke, te] = a.useState(() => ({
            localParticipant: {
                isMicrophoneEnabled: !1,
                setMicrophoneEnabled: function(p) {
                    var d;
                    return (d = K.current) == null || d.setMuted(!p), Promise.resolve(void 0)
                },
                setCameraEnabled: async function(p, d, v) {
                    if (p) try {
                        const k = await Ae("camera");
                        await c({
                            avmTrack: k
                        }), b(k)
                    } catch (k) {
                        throw $.error("[transceiver] Error acquiring camera input", k), k
                    } else await be();
                    return Promise.resolve(void 0)
                },
                setScreenShareEnabled: async function(p, d, v) {
                    if (p) try {
                        const k = await Ae("screenshare");
                        await c({
                            avmTrack: k
                        }), b(k)
                    } catch (k) {
                        throw $.error("[transceiver] Error acquiring screen share input", k), k
                    } else await be();
                    return Promise.resolve(void 0)
                },
                publishData: async function(p, d) {
                    const v = ce.current;
                    if (!v || v.readyState !== "open") throw new Error("Data channel is not open");
                    const k = new TextDecoder().decode(p),
                        T = JSON.stringify({
                            type: "data_message",
                            data: k
                        });
                    v.send(T)
                },
                on: function(p, d) {
                    p === w.ConnectionQualityChanged && X.current.push(d)
                },
                off: function(p, d) {
                    p === w.ConnectionQualityChanged && (X.current = X.current.filter(v => v !== d))
                }
            },
            getActiveDevice: p => {
                switch (p) {
                    case "audioinput":
                        return y.current;
                    case "videoinput":
                        return I.current;
                    case "audiooutput":
                        return f.current
                }
            },
            disconnect: async function() {
                var p;
                je.abortPendingNegotiation("Disconnecting"), (p = se.current) == null || p.stop(), P.current = !0, Ne.closeAllStreams(), Q.current && (Q.current.close(), Q.current = void 0), r.current && (r.current.srcObject = null), await be(), g(z.Disconnected), D.current = z.Disconnected, E.current.forEach(d => d())
            },
            name: "",
            switchActiveDevice: async (p, d, v) => {
                var k;
                if (D.current !== z.Connected) return $.debug("[transceiver] Attempt to switch device when not connected, current state is", D.current), !1;
                try {
                    switch (p) {
                        case "audioinput":
                            {
                                const T = await Oe(d);
                                return await c({
                                    avmTrack: T
                                }),
                                b(T),
                                !0
                            }
                        case "videoinput":
                            {
                                const T = await Ae("camera", d);
                                return await c({
                                    avmTrack: T
                                }),
                                b(T),
                                !0
                            }
                        case "audiooutput":
                            return await ((k = r.current) == null ? void 0 : k.setSinkId(d)), f.current = d, !0
                    }
                } catch (T) {
                    return $.error("[transceiver] Failed to switch ".concat(p, " device"), T), !1
                }
            },
            on: function(p, d) {
                switch (p) {
                    case w.DataReceived:
                        F.current.push(d);
                        break;
                    case w.Disconnected:
                        E.current.push(d);
                        break;
                    case w.Connected:
                        J.current.push(d);
                        break;
                    case w.TrackPublished:
                        q.current.push(d);
                        break;
                    case w.ConnectionQualityChanged:
                        G.current.push(d);
                        break
                }
            },
            off: function(p, d) {
                switch (p) {
                    case w.DataReceived:
                        F.current = F.current.filter(v => v !== d);
                        break;
                    case w.Disconnected:
                        E.current = E.current.filter(v => v !== d);
                        break;
                    case w.Connected:
                        J.current = J.current.filter(v => v !== d);
                        break;
                    case w.TrackPublished:
                        q.current = q.current.filter(v => v !== d);
                        break;
                    case w.ConnectionQualityChanged:
                        G.current = G.current.filter(v => v !== d);
                        break
                }
            },
            state: z.Disconnected,
            numParticipants: 0,
            activeSpeakers: []
        })),
        re = a.useRef(!1),
        Q = a.useRef(void 0),
        ue = () => (Q.current === void 0 && (Q.current = _n.getFreshPeerConnection("voice-mode")), Q.current),
        le = a.useCallback((S, p) => {
            te(d => De(d, v => {
                v && (v.localParticipant.isMicrophoneEnabled = !S, v.localParticipant.isMicrophoneForceMuted = p, S ? O(Pt) : L(Pt))
            }))
        }, [L, O]),
        Be = a.useCallback(S => {
            const p = [u, l, C].filter(d => d !== void 0);
            return S ? p.filter(d => S.includes(d.source)) : p
        }, [u, l, C]),
        Oe = a.useCallback(async S => {
            S || (S = await En());
            const d = (await Ne.getUserMedia({
                audio: S ? {
                    deviceId: {
                        exact: S
                    }
                } : !0
            })).getTracks();
            if (d.length !== 1) throw $.error("[transceiver] Only one input is supported for now, detected these tracks", d), new Error("Only one input is supported for now");
            const [v] = d;
            y.current = v.getSettings().deviceId, K.current && K.current.track !== v && K.current.track.stop();
            const k = Xe(v, {
                source: _e.Microphone,
                name: "user",
                userName: "User",
                origin: $e.Local,
                mutedCb: le
            });
            return s(k), le(k.isMuted, k.isSystemMuted), k
        }, [le]),
        Ae = a.useCallback(async (S, p) => {
            const v = (S === "camera" ? await Ne.getUserMedia({
                video: p ? {
                    deviceId: {
                        exact: p
                    }
                } : !0
            }) : await Ne.getDisplayMedia()).getTracks();
            if (v.length !== 1) throw $.error("[transceiver] Only one video input is supported for now, detected these tracks", v), new Error("Only one video input is supported for now");
            const [k] = v;
            S === "camera" && (I.current = k.getSettings().deviceId), N.current && N.current.track !== k && N.current.track.stop();
            const T = Xe(k, {
                source: S === "camera" ? _e.Camera : _e.ScreenShare,
                name: "user",
                userName: "User",
                origin: $e.Local
            });
            return _(T), T
        }, []),
        be = a.useCallback(async () => {
            if (N.current && ($.debug("[transceiver] Stop and clear video track"), N.current.track.stop(), _(void 0), i.current && !i.current.stopped)) {
                $.debug("[transceiver] Stop the video transceiver");
                try {
                    await i.current.sender.replaceTrack(null)
                } catch (S) {
                    $.debug("[transceiver] Failed to stop transceiver on disconnect due to", S)
                }
            }
        }, []),
        Ge = a.useCallback(S => {
            const {
                default_voice_mode: p,
                modes: d
            } = S, v = d.find(k => k.mode === p);
            if (!v) throw new Error("No voice status mode found for default mode ".concat(p));
            return v
        }, []),
        de = a.useCallback(async () => {
            const S = performance.now(),
                p = ye(Mn, () => ue()),
                d = ye(In, () => ue().createDataChannel("", {
                    negotiated: !0,
                    id: At
                }));
            ce.current = d, ye(xn, () => {
                d.onopen = () => {
                    n.setState(T => {
                        T.metrics.dataChannelOpenTime || (T.metrics.dataChannelOpenTime = new Date)
                    })
                }, d.onmessage = T => {
                    const {
                        success: V,
                        result: H
                    } = yo(T.data);
                    if (!V) return Y.dataChannel.parseError({
                        badData: H
                    });
                    const fe = H;
                    if (fe.type === "data_message") {
                        const pe = So().encode(fe.data);
                        F.current.forEach(he => he(pe))
                    }
                }, d.onclose = () => {
                    P.current ? P.current = !1 : E.current.forEach(T => T()), O(Ot)
                }, p.oniceconnectionstatechange = () => {
                    const T = ue().iceConnectionState,
                        V = go(T);
                    V === z.Connected && J.current.forEach(H => H()), g(V), n.setState(H => {
                        H.server.connectionState = V
                    })
                }, p.ontrack = T => {
                    if (r.current != null) {
                        r.current.srcObject = T.streams[0];
                        const V = T.streams[0].getTracks();
                        if (V.length !== 1) throw $.error("[transceiver] Only one remote track is supported for now, detected these tracks", V), new Error("Only one remote track is supported for transceiver");
                        const [H] = V, fe = Xe(H, {
                            source: _e.Microphone,
                            name: x === "advanced" ? "audio" : "shout",
                            userName: "Assistant",
                            origin: $e.Remote
                        });
                        h(fe), b(fe), te(pe => De(pe, he => {
                            he && (he.numParticipants = 2)
                        })), L(Ot)
                    }
                }
            }), ye(Pn, () => {
                o.current = p.addTransceiver("audio"), i.current && !i.current.stopped && (i.current.stop(), p.removeTrack(i.current.sender)), i.current = p.addTransceiver("video", {
                    direction: "sendonly"
                })
            });
            const v = await vt(Un, async () => {
                    const T = await p.createOffer();
                    return p.setLocalDescription(T), T
                }),
                k = performance.now();
            return On.set({
                start_time: S,
                end_time: k
            }), {
                offer: v
            }
        }, [L, b, O, x, n]),
        oe = a.useCallback(() => {
            const S = performance.now(),
                p = Oe();
            return p.then(() => {
                const v = performance.now();
                An.set({
                    start_time: S,
                    end_time: v
                })
            }), {
                completeAudioSetup: async () => {
                    const v = await p,
                        k = performance.now();
                    await c({
                        avmTrack: v,
                        initialSetup: !0
                    });
                    const T = performance.now();
                    return Vn.set({
                        start_time: k,
                        end_time: T
                    }), {
                        microphoneTrack: v
                    }
                }
            }
        }, [Oe, c]),
        Te = a.useCallback(() => {
            const S = performance.now(),
                p = ue();
            se.current && se.current.stop(), se.current = new mo(p, v => {
                const k = D.current && [z.Disconnected, z.Reconnecting, z.SignalReconnecting].includes(D.current);
                G.current.forEach(T => T(k ? ie.Lost : v.general)), X.current.forEach(T => T(k ? ie.Lost : v.local))
            }), se.current.start();
            const d = performance.now();
            Rn.set({
                start_time: S,
                end_time: d
            })
        }, []),
        Re = a.useCallback(() => {
            ee.current = oe(), ae.current = de()
        }, [de, oe]),
        Je = a.useCallback(async (S, p, d) => {
            const v = performance.now(),
                k = await vt($n, () => d.text()),
                T = ue();
            ye(Ln, () => {
                T.setRemoteDescription({
                    sdp: k,
                    type: "answer"
                })
            }), ee.current || ($.error("[transceiver] Audio input setup step not executed for initial TC offer!"), ee.current = oe());
            const {
                completeAudioSetup: V
            } = ee.current, {
                microphoneTrack: H
            } = await V();
            b(H), n.setState(pe => {
                var he;
                pe.conversationId = (he = S.conversation_id) != null ? he : p.clientThreadId, pe.voiceSessionId = S.voice_session_id, pe.voiceMode = S.voice_mode
            }), re.current = !1, g(z.Connected);
            const fe = performance.now();
            Dn.set({
                start_time: v,
                end_time: fe
            })
        }, [oe, ee, b, n]),
        U = a.useCallback(async (S, p) => {
            var T, V;
            if (re.current) throw new Error("Not ready to connect, ".concat(JSON.stringify({
                isConnecting: re.current
            })));
            re.current = !0, (T = ae.current) != null || (ae.current = de()), (V = ee.current) != null || (ee.current = oe());
            const {
                offer: d
            } = await ae.current, v = ye(Nn, () => je.beginNegotiation()), k = await Rt.startTransceiverSession({
                payload: S,
                accessToken: t,
                proofOfWorkAnswer: p.proofOfWorkAnswer,
                eventSource: p.eventSource,
                signal: v,
                dataChannelId: At,
                offer: d
            });
            return je.clearNegotiation(), Te(), Je(S, p, k), {
                type: "transceiver",
                success: !0
            }
        }, [de, oe, t, Te, Je]),
        ln = a.useMemo(() => ({
            room: ke,
            getTracks: Be,
            getConnectionState: R,
            initVoiceMode: U,
            selectVoiceModeMetadata: Ge,
            getTokenSetup: Re
        }), [ke, Be, R, U, Ge, Re]);
    return nt.jsxs(lt.Provider, {
        value: ln,
        children: [nt.jsx("audio", {
            ref: r,
            autoPlay: !0,
            playsInline: !0
        }), e]
    })
};

function wo() {
    const {
        room: e
    } = un(), n = a.useRef({
        debug: (...t) => {
            var r;
            return $.debug("[".concat((r = e == null ? void 0 : e.name) != null ? r : "no room", "]"), ...t)
        },
        encoder: new TextEncoder,
        decoder: new TextDecoder
    }).current;
    return ve({
        room: e
    }, n)
}

function ko() {
    if (performance.getEntriesByName(Z.SessionCreateStart).length > 0) {
        performance.mark(Z.ClickLatencyEnd);
        const n = performance.measure(Z.ClickLatencyMeasure, Z.SessionCreateStart, Z.ClickLatencyEnd);
        Y.voiceMode.clickLatency({
            durationMs: n.duration
        })
    }
}

function tt(e) {
    return [...e].sort().join(", ")
}

function Uo(e) {
    return ve({
        conversation_id: e.serverThreadId,
        parent_message_id: e.parentMessageId,
        voice_mode: e.isAdvancedMode ? "advanced" : "standard",
        eventSource: e.eventSource,
        clientThreadId: e.clientThreadId,
        gizmo_id: e.gizmoId,
        voice: e.voice
    }, e.skipCacheReason ? {
        useVoiceStatusCache: !1,
        skipCacheReason: e.skipCacheReason
    } : {
        useVoiceStatusCache: !0
    })
}

function Vo({
    requestMicPermissions: e
} = {
    requestMicPermissions: !1
}) {
    const n = Cn(),
        t = Ye(),
        r = tr(),
        {
            voiceName: o,
            voiceMainLanguage: i
        } = jn(),
        c = Fn(g => g.isVoiceModeActive),
        u = Wn(),
        {
            room: s
        } = wo(),
        {
            initVoiceMode: l,
            selectVoiceModeMetadata: h,
            getTokenSetup: C
        } = un(),
        _ = zn(),
        y = qn(),
        I = bn(),
        f = n.formatMessage({
            id: "useVoiceModeButtonAction.error",
            defaultMessage: "Failed to start voice mode"
        }),
        x = a.useCallback(async () => {
            u && (await (s == null ? void 0 : s.disconnect()), rt(null, t), t.setState(g => {
                g.server.remoteState = He.Halted
            }))
        }, [u, s, t]);
    return {
        startVoiceMode: a.useCallback(async g => {
            var ce, G, X, F, E, P, q;
            ko(), yn(), Sn.setItem(gn.VoiceLastUsed, new Date().toUTCString()), (u || g.forceDisconnect) && (await (s == null ? void 0 : s.disconnect()), rt(null, t)), e && await y();
            const R = await Qn("audioinput");
            Yn(Xn.Unknown, {
                allowOverride: !1
            });
            const L = wn(() => kn());
            C(), t.setState(b => {
                b.audioInputDevice = R, b.isVoiceModeActive = !0, b.voiceMode = g.voice_mode, b.server.remoteState = He.Connecting, b.metrics.totalLatencyMs = [], b.metrics.currentRttMs = [], b.metrics.numSpeaking = 0, b.metrics.numThinking = 0, b.metrics.numListening = 0, b.metrics.getStatusSentTime = void 0, b.metrics.getStatusSuccessTime = void 0, b.metrics.getStatusFailedTime = void 0, b.metrics.proofOfWorkStartTime = void 0, b.metrics.proofOfWorkEndTime = void 0, b.metrics.getTokenSentTime = void 0, b.metrics.getTokenSuccessTime = void 0, b.metrics.getTokenFailedTime = void 0, b.metrics.livekitConnectTime = void 0, b.metrics.livekitConnectSuccessTime = void 0, b.metrics.livekitConnectFailTime = void 0, b.metrics.conversationStartSuccessTime = void 0, b.metrics.conversationStartFailTime = void 0, b.metrics.sessionConnectedTime = void 0
            });
            const O = performance.now();
            try {
                Y.livekit.connectCalled(), t.setState(U => {
                    U.metrics.getStatusSentTime = new Date
                });
                const b = mt(),
                    D = tt(bt()),
                    K = tt(Bn()),
                    N = tt(Gn()),
                    se = D.length > 0,
                    ae = K.length > 0;
                !g.useVoiceStatusCache ? (Y.voiceStatusCache.skipped({
                    reason: g.skipCacheReason
                }), yt.set(g.skipCacheReason)) : (yt.set(void 0), ae ? Y.voiceStatusCache.ineligible({
                    reason: K
                }) : se ? Y.voiceStatusCache.failed({
                    reason: D
                }) : b ? Y.voiceStatusCache.hit({
                    allowlisted: N || !1
                }) : bt.set(["unexpected-empty-cache"]));
                const ke = b == null ? void 0 : b.proofOfWorkPromise,
                    te = g.useVoiceStatusCache && b ? b : await _({
                        conversation_id: (ce = g.conversation_id) != null ? ce : null,
                        requested_voice_mode: (G = g.voice_mode) != null ? G : null,
                        gizmo_id: (X = g.gizmo_id) != null ? X : null,
                        voice: g.voice,
                        requested_default_model: (F = g.requested_default_model) != null ? F : null
                    }, g.eventSource);
                t.setState(U => {
                    U.metrics.getStatusSuccessTime = new Date, U.metrics.proofOfWorkStartTime = new Date
                });
                const {
                    default_voice_mode: re,
                    chatreq: Q
                } = te;
                t.setState(U => {
                    U.voiceMode = re
                }), performance.mark(Z.LivekitStart);
                const J = g,
                    {
                        eventSource: ue,
                        voice: le,
                        clientThreadId: Be,
                        voice_mode: Oe,
                        gizmo_id: Ae
                    } = J,
                    be = pt(J, ["eventSource", "voice", "clientThreadId", "voice_mode", "gizmo_id"]),
                    de = h(te).default_model_slug,
                    oe = re === "advanced" ? de : void 0,
                    Te = g.useVoiceStatusCache && ke ? await ke : Q ? await Jn.getEnforcementToken(Q) : null,
                    Re = g.gizmo_id ? {
                        kind: ht.GizmoInteraction,
                        gizmo_id: g.gizmo_id
                    } : {
                        kind: ht.PrimaryAssistant
                    };
                t.setState(U => {
                    U.metrics.proofOfWorkEndTime = new Date, U.metrics.getTokenSentTime = new Date
                }), mt.set(Ce(ve({}, te), {
                    proofOfWorkPromise: Promise.resolve(Te)
                })), Kn(be), (await l(Ce(ve({}, be), {
                    voice: le != null ? le : o,
                    language_code: i,
                    voice_session_id: L,
                    voice_status_request_id: te.voice_status_request_id,
                    timezone_offset_min: new Date().getTimezoneOffset(),
                    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
                    voice_mode: re,
                    model_slug: de,
                    model_slug_advanced: oe,
                    chatreq_token: Q == null ? void 0 : Q.token,
                    history_and_training_disabled: I,
                    conversation_mode: Re
                }), {
                    eventSource: g.eventSource,
                    clientThreadId: g.clientThreadId,
                    proofOfWorkAnswer: Te
                })).success && (t.setState(U => {
                    U.metrics.getTokenSuccessTime = new Date, U.metrics.livekitConnectTime = new Date
                }), Tn({
                    lastVoiceSessionStartTime: new Date
                }), performance.mark(Z.LivekitEnd), Y.livekit.success({
                    durationMs: performance.measure(Z.LivekitMeasure, Z.LivekitStart, Z.LivekitEnd).duration.toFixed(0),
                    voice_session_id: L
                }), Y.connectionLatency.success({
                    durationMs: performance.now() - O
                }))
            } catch (b) {
                const D = Hn(b);
                t.setState(N => {
                    D || (N.metrics.getStatusSuccessTime || (N.metrics.getStatusFailedTime = new Date), N.metrics.getTokenSuccessTime || (N.metrics.getTokenFailedTime = new Date))
                });
                const K = Zn(t.getState());
                throw Y.livekit.failure(b, Ce(ve({}, K), {
                    voice_session_id: L,
                    eventSource: g.eventSource,
                    voice: (E = g.voice) != null ? E : "(undefined)",
                    requested_voice_mode: (P = g.voice_mode) != null ? P : "(undefined)",
                    gizmo_id: (q = g.gizmo_id) != null ? q : "(undefined)",
                    user_aborted: D
                })), $.debug("failed to get voice token", b), t.setState(N => {
                    N.server.remoteState = He.Halted
                }), Y.connectionLatency.failure(b, {
                    durationMs: performance.now() - O,
                    voice_session_id: L,
                    user_aborted: D
                }), r.danger(f, {
                    toastId: "start_voice_mode_failure"
                }), b
            }
        }, [y, f, _, u, I, e, s, r, i, o, t, l, h, C]),
        stopVoiceMode: x,
        isConnected: u,
        isVoiceModeActive: c
    }
}
export {
    oo as $, _e as A, Ro as C, nn as F, Ao as I, Do as L, Io as N, xo as O, Et as R, nr as S, No as T, so as W, Po as Y, Qe as _, un as a, $e as b, tr as c, wo as d, Lo as e, Uo as g, Vo as u, Oo as y
};
//# sourceMappingURL=fz8xw1971c2kf2eb.js.map