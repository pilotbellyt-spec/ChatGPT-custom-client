import {
    f as I,
    e as T,
    j as e,
    M as v
} from "./fg33krlcm0qyi6yw.js";
import {
    I as A,
    b as S,
    bg as o,
    l as M,
    a9 as w,
    bv as L,
    r5 as E
} from "./dykg4ktvbu3mhmdo.js";
import {
    aw as _,
    an as r,
    ax as i,
    ay as b,
    az as U
} from "./k15yxxoybkkir2ou.js";

function W({
    inputRef: l,
    isLoading: n,
    shareUrl: c,
    sharedObject: s,
    shareTextPlaceholder: N,
    title: m,
    isCopySuccessful: u,
    isCreateLinkRequestInProgress: f,
    didPublishUpdates: j,
    isPublishedVersionLatest: g,
    handleUpdateLatestSharedVersion: k,
    handlePrivacyChange: C,
    handlePrimaryButtonClick: P,
    maybeRenderWarndingContent: d
}) {
    const t = T(),
        D = S(),
        p = A(D),
        B = p == null ? void 0 : p.isWorkspaceAccount(),
        h = m ? e.jsx(v, {
            id: "mxstAC",
            defaultMessage: "Share {title}",
            values: {
                title: "'".concat(m, "'")
            }
        }) : e.jsx(v, {
            id: "dm0aoB",
            defaultMessage: "Share"
        });
    return s != null && s.isModerationBlocked ? e.jsx("div", {
        className: "w-[max(95vw,300px)] sm:w-[460px]",
        children: e.jsx("div", {
            className: "overflow-hidden rounded-[22px] shadow-[0_4px_24px_-5px_rgba(0,0,0,0.2)]",
            children: e.jsxs("div", {
                className: "bg-token-main-surface-primary flex flex-col gap-4 border-b border-black/10 pt-5 *:px-5 dark:border-white/10",
                children: [e.jsx("div", {
                    className: "text-lg font-semibold",
                    children: h
                }), e.jsx("div", {
                    className: "pb-6",
                    children: e.jsx("div", {
                        className: "text-md border-token-surface-error/5 bg-token-surface-error/5 text-token-text-error rounded-lg border px-4 py-2",
                        children: t.formatMessage(a.moderationBlocked)
                    })
                })]
            })
        })
    }) : e.jsx(o.div, {
        initial: {
            opacity: 0,
            scale: .75
        },
        animate: {
            opacity: 1,
            scale: 1
        },
        exit: {
            opacity: 0,
            scale: .75
        },
        style: {
            transformOrigin: "top right"
        },
        transition: {
            type: "spring",
            bounce: .2,
            duration: .32
        },
        className: "w-[max(95vw,300px)] sm:w-[460px]",
        children: e.jsx("div", {
            className: "overflow-hidden rounded-[22px] shadow-[0_4px_24px_-5px_rgba(0,0,0,0.2)]",
            children: e.jsxs("div", {
                className: "bg-token-main-surface-primary flex flex-col gap-4 border-b border-black/10 p-6 dark:border-white/10",
                children: [e.jsx("div", {
                    className: "line-clamp-1 text-lg font-medium",
                    children: h
                }), e.jsx("div", {
                    children: e.jsxs("div", {
                        className: "border-token-border-default text-token-text-secondary flex items-center justify-between rounded-full border",
                        children: [e.jsxs("div", {
                            className: "relative grow",
                            children: [e.jsx("input", {
                                ref: l,
                                type: "text",
                                readOnly: !0,
                                onPointerDown: y => {
                                    y.currentTarget.select(), y.preventDefault()
                                },
                                value: c,
                                placeholder: N,
                                className: M("text-md w-full rounded-xl border-0 bg-transparent py-2 ps-4 pe-0 focus:ring-0 focus:outline-hidden", s ? "text-token-text-secondary" : "text-token-text-tertiary")
                            }), e.jsx("div", {
                                className: "from-token-main-surface-primary pointer-events-none absolute end-0 top-0 bottom-0 w-6 bg-linear-to-l"
                            })]
                        }), e.jsx(w, {
                            icon: s ? null : _,
                            disabled: u,
                            loading: n || f,
                            onClick: P,
                            size: "medium",
                            className: M("absolute inset-0 m-1 font-semibold transition-opacity duration-300", n ? "pointer-events-none opacity-0" : "opacity-100"),
                            children: u ? t.formatMessage(a.copied) : s ? t.formatMessage(a.copyLink) : f ? t.formatMessage(a.creatingLink) : n ? null : t.formatMessage(a.createLink)
                        })]
                    })
                }), d == null ? void 0 : d(), s && e.jsx(r.Root, {
                    value: s.access,
                    onValueChange: C,
                    children: e.jsxs("div", {
                        className: "items-start",
                        children: [e.jsx(r.Trigger, {
                            asChild: !0,
                            className: "text-md text-token-text-secondary hover:bg-token-bg-primary dark:hover:bg-token-bg-primary flex h-auto w-full items-center justify-between p-0",
                            children: e.jsxs("div", {
                                className: "flex w-full items-start justify-between gap-2",
                                children: [e.jsx("div", {
                                    className: "text-token-text-secondary flex flex-col items-start text-sm",
                                    children: (() => {
                                        switch (s == null ? void 0 : s.access) {
                                            case i.PUBLIC:
                                                return e.jsxs(e.Fragment, {
                                                    children: [e.jsx("span", {
                                                        children: t.formatMessage(a.publicDescription)
                                                    }), e.jsx("span", {
                                                        children: t.formatMessage(a.conversationPrivateDescription)
                                                    })]
                                                });
                                            case i.PRIVATE:
                                                return e.jsx("span", {
                                                    children: t.formatMessage(a.privateDescription)
                                                });
                                            case i.WORKSPACE:
                                                return e.jsx("span", {
                                                    children: t.formatMessage(a.workspaceDescription)
                                                });
                                            case void 0:
                                                return null
                                        }
                                    })()
                                }), e.jsxs("button", {
                                    className: "text-token-text-primary hover:bg-token-main-surface-tertiary dark:hover:bg-token-main-surface-secondary flex items-center gap-1 rounded-lg py-1.5 ps-3 pe-2 text-sm font-semibold",
                                    children: [(() => {
                                        switch (s == null ? void 0 : s.access) {
                                            case i.PUBLIC:
                                                return e.jsx(b, {
                                                    className: "icon-xs me-1"
                                                });
                                            case i.PRIVATE:
                                                return e.jsx(U, {
                                                    className: "icon-xs me-1"
                                                });
                                            case i.WORKSPACE:
                                                return e.jsx(b, {
                                                    className: "icon-xs me-1"
                                                });
                                            case void 0:
                                                return null
                                        }
                                    })(), t.formatMessage((s == null ? void 0 : s.access) === i.WORKSPACE ? a.workspace : (s == null ? void 0 : s.access) === i.PUBLIC ? a.public : a.private), e.jsx("span", {
                                        className: "text-token-text-tertiary",
                                        children: e.jsx(r.Icon, {})
                                    })]
                                })]
                            })
                        }), e.jsx(r.Portal, {
                            children: e.jsxs(r.Content, {
                                className: "min-w-[var(--radix-select-trigger-width)]",
                                position: "popper",
                                sideOffset: -50,
                                children: [B ? e.jsx(x, {
                                    access: i.WORKSPACE,
                                    title: t.formatMessage(a.workspace),
                                    description: t.formatMessage(a.workspaceDescription)
                                }) : e.jsx(x, {
                                    access: i.PUBLIC,
                                    title: t.formatMessage(a.public),
                                    description: t.formatMessage(a.publicDescription)
                                }), e.jsx(x, {
                                    access: i.PRIVATE,
                                    title: t.formatMessage(a.private),
                                    description: t.formatMessage(a.privateDescription)
                                })]
                            })
                        })]
                    })
                }), e.jsx(L, {
                    mode: "wait",
                    children: s && k && (!g || j) && e.jsx("div", {
                        className: "border-token-border-default border-t-token-border-xlight bg-token-main-surface-secondary text-token-text-secondary -mx-6 -mb-6 flex items-center justify-between gap-4 border-t px-[22px] py-4 text-sm",
                        children: g ? e.jsxs(e.Fragment, {
                            children: [e.jsx(o.div, {
                                initial: {
                                    opacity: 0
                                },
                                animate: {
                                    opacity: 1
                                },
                                exit: {
                                    opacity: 0
                                },
                                transition: {
                                    type: "spring",
                                    bounce: .2,
                                    duration: .32
                                },
                                children: t.formatMessage(a.publishedChanges)
                            }), e.jsx(o.div, {
                                initial: {
                                    opacity: 0,
                                    scale: 0
                                },
                                animate: {
                                    opacity: 1,
                                    scale: 1
                                },
                                transition: {
                                    type: "spring",
                                    bounce: .2,
                                    duration: .32
                                },
                                children: e.jsx(E, {
                                    className: "icon-lg my-2 me-2 shrink-0 opacity-50"
                                })
                            })]
                        }) : e.jsxs(o.div, {
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            exit: {
                                opacity: 0
                            },
                            transition: {
                                type: "spring",
                                bounce: .2,
                                duration: .32
                            },
                            className: "flex w-full items-center justify-between gap-4",
                            children: [t.formatMessage(a.unsharedChanges), e.jsx(w, {
                                color: "secondary",
                                size: "medium",
                                className: "me-1 px-4",
                                onClick: () => k(s.id),
                                children: t.formatMessage(a.publish)
                            })]
                        })
                    })
                })]
            })
        })
    })
}

function x({
    access: l,
    title: n,
    description: c
}) {
    return e.jsx(r.Item, {
        iconClassName: "icon-lg",
        value: l,
        children: e.jsx("div", {
            className: "flex w-full items-start justify-between gap-2",
            children: e.jsxs("div", {
                className: "text-md flex flex-col items-start",
                children: [e.jsx("span", {
                    className: "text-md text-token-text-primary",
                    children: n
                }), e.jsx("span", {
                    className: "text-token-text-secondary text-sm",
                    children: c
                })]
            })
        })
    })
}
const a = I({
    share: {
        id: "Tne3oh",
        defaultMessage: "Share"
    },
    createLink: {
        id: "Ns/mpl",
        defaultMessage: "Create link"
    },
    copyLink: {
        id: "dHmHBn",
        defaultMessage: "Copy link"
    },
    creatingLink: {
        id: "hHh4kJ",
        defaultMessage: "Creating ..."
    },
    copied: {
        id: "zMndTF",
        defaultMessage: "Copied"
    },
    workspace: {
        id: "XuBl8l",
        defaultMessage: "Workspace"
    },
    public: {
        id: "i4Czrk",
        defaultMessage: "Public"
    },
    private: {
        id: "WZUwOD",
        defaultMessage: "Private"
    },
    privateDescription: {
        id: "hBkTCk",
        defaultMessage: "Only you can view."
    },
    publicDescription: {
        id: "k38+6+",
        defaultMessage: "Anyone with the link can view."
    },
    workspaceDescription: {
        id: "RRaxxv",
        defaultMessage: "Members of your workspace can view."
    },
    conversationPrivateDescription: {
        id: "dP5iAS",
        defaultMessage: "Your chat messages will not be shared."
    },
    failedToCopyLink: {
        id: "ChbUTM",
        defaultMessage: "Failed to copy link to clipboard."
    },
    publish: {
        id: "MT1/Gm",
        defaultMessage: "Update"
    },
    unsharedChanges: {
        id: "X9C94W",
        defaultMessage: "Your latest changes aren’t included."
    },
    publishedChanges: {
        id: "+VCnlg",
        defaultMessage: "The shared canvas is up to date."
    },
    moderationBlocked: {
        id: "UbWyx9",
        defaultMessage: "This shared link has been blocked by moderation"
    },
    workspaceSharingDisabled: {
        id: "+HZ/LH",
        defaultMessage: "Sharing has been disabled for this workspace. Contact your admin to enable."
    }
});
export {
    W as B, a as s
};
//# sourceMappingURL=e1qtg70ehhxpvvw9.js.map