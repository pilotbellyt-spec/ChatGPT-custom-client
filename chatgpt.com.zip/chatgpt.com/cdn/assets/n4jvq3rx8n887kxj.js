const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/gnf5x18zszgh02tj.js", "assets/fg33krlcm0qyi6yw.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/peoqhwtrjqotgzjw.js", "assets/octb28fiwkwdqaay.js", "assets/k15yxxoybkkir2ou.js", "assets/conversation-small-332fs9rk.css", "assets/c82q89wfy6odbwlp.js", "assets/nzjsohh941f1fuvy.js", "assets/fqdux96o99o6e1bu.js", "assets/f96c6fguu1kcw0go.js", "assets/cn8eg48nrtfdn3hv.js", "assets/hwa6pbq6i57ntwuh.js", "assets/jr50j1lqn6fa60e9.js", "assets/tm7b14kn4qjlarhq.js", "assets/nb22pb07i8ebbv0i.js", "assets/hkq4ft1vs44iddnx.js", "assets/d7j30y1sf5jmsddi.js", "assets/dcboyjh87ll7k264.js", "assets/l09h2qppleubii6l.js", "assets/c1lw0j14sexsyj33.js", "assets/jbh6ambg0gcrgcqd.js", "assets/brbv8u56dvmb3wbc.js", "assets/u9jpwxvw30u3h6nc.js", "assets/kx34yg3blv92o8xp.js", "assets/map-with-entities-ejapwmw2.css", "assets/f9yd7jtcv3kpecrv.js", "assets/jzwivbl10of3y0cy.js", "assets/e0qtk69d4k3s8kri.js", "assets/bcsv6m4oh341rml5.js", "assets/lqog7ixiwnif6sbp.js", "assets/nzl91iujqafxz8y1.js", "assets/ebc4iyfg14nu1gw4.js", "assets/gy1lpvuoewmzh42c.js", "assets/jed1ux7qibe55pmj.js", "assets/h1em0bjkpkjv8ykw.js", "assets/nfccle6oyncifphl.js", "assets/hu1bt0oauegdhua6.js", "assets/b5s349mvbdzayaxi.js", "assets/dbshkzvpochy4889.js", "assets/zdzro29lk5w2w085.js", "assets/gjyisy9q1t8rz8p4.js", "assets/djfxxaryk37v3pj1.js", "assets/b31u62knn5mcc1vg.js", "assets/product-variants-pcfu1bfm.css", "assets/fyk9tph6baj60t7u.js", "assets/ou2xm3xmri21t4zm.js", "assets/nbft03bzj0s0fw3v.js", "assets/iiok29s29bpdre61.js", "assets/dv2e3o9gddnli9b5.js", "assets/k57uzqpnr7k7r909.js", "assets/ekwi2j2bxci5d5rf.js", "assets/dqz86fcur874gotm.js", "assets/17v8usp0o68l1lsz.js", "assets/fnxhy13zl746u1sp.js", "assets/zqbip2ya77i1mx4s.js", "assets/hfur3m15nh6zuk4s.js", "assets/n3mktr5m7sakg90x.js", "assets/jb9b7tatrnyq635u.js", "assets/mvhcdm28zmc6uy2d.js", "assets/cmaobpdpreyiep8p.js", "assets/lz6fx1tx77vtpv95.js", "assets/ab9pr9c8apckuums.js", "assets/hnbtdromsi7xhy2m.js", "assets/j8efhdgdagw30nd8.js", "assets/jdbfnvyv9bb4osfa.js", "assets/f1b9xcddv1uk610d.js", "assets/cei3le5szo5glbj4.js", "assets/elwpnpvd3n8263yf.js", "assets/g8wlcyv24gz22o70.js", "assets/kg0cp341m64rddpv.js", "assets/ansi-1f6vhsjh.css", "assets/h21g9slzr4ujv9kj.js", "assets/bi6phpick816e345.js", "assets/lep2wptoy14cfe2w.js", "assets/gd2ozzf4upgi0amm.js", "assets/du4xh8plp0f7ydun.js", "assets/f1axa7efo9jhz2uv.js", "assets/hn5e71c3hkpkv00z.js", "assets/n6upldbhvll48b0q.js", "assets/ol9d5wxhynx9q2is.js", "assets/nbd6wafppmcw1yix.js", "assets/g0f4hjqp90x9s4o7.js", "assets/oxont9zeuaiwb679.js", "assets/table-components-gjyj5koo.css", "assets/jdzosouyvpzu0tpb.js", "assets/g63j6um9azgogw0s.js", "assets/bt8940c6l4ej9r7j.js", "assets/fgxxkkb4il90gii6.js", "assets/eafv7vq0yf9bv0fi.js", "assets/f76gy0b8ieo4s693.js", "assets/jsd0vs4cv2vks3ah.js", "assets/loeoawlgsw5vcwar.js", "assets/e7ytp4eqtgc6bl6p.js", "assets/owg1rbxotm5jsyn7.js", "assets/gbmggnydp7mcsebl.js", "assets/ce3hgmw4iyyhicud.js", "assets/kwqlokvhsdnnmw9d.js", "assets/gb3g89r4fqk97sov.js", "assets/kl7c6054usfnqmd4.js", "assets/k97n0y6ba9c9h39c.js", "assets/dfk80oxw9xer35fj.js", "assets/hlntli3lea5dl5vn.js"]))) => i.map(i => d[i]);
var Ta = Object.freeze,
    Ia = Object.defineProperty,
    lf = Object.defineProperties;
var cf = Object.getOwnPropertyDescriptors;
var Fo = Object.getOwnPropertySymbols;
var Na = Object.prototype.hasOwnProperty,
    Pa = Object.prototype.propertyIsEnumerable;
var ti = (t, e) => (e = Symbol[t]) ? e : Symbol.for("Symbol." + t);
var si = (t, e, s) => e in t ? Ia(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : t[e] = s,
    F = (t, e) => {
        for (var s in e || (e = {})) Na.call(e, s) && si(t, s, e[s]);
        if (Fo)
            for (var s of Fo(e)) Pa.call(e, s) && si(t, s, e[s]);
        return t
    },
    ce = (t, e) => lf(t, cf(e));
var Bt = (t, e) => {
    var s = {};
    for (var n in t) Na.call(t, n) && e.indexOf(n) < 0 && (s[n] = t[n]);
    if (t != null && Fo)
        for (var n of Fo(t)) e.indexOf(n) < 0 && Pa.call(t, n) && (s[n] = t[n]);
    return s
};
var Ra = (t, e, s) => si(t, typeof e != "symbol" ? e + "" : e, s);
var Qs = (t, e) => Ta(Ia(t, "raw", {
    value: Ta(e || t.slice())
}));
var Bo = function(t, e) {
        this[0] = t, this[1] = e
    },
    $a = (t, e, s) => {
        var n = (i, l, c, d) => {
                try {
                    var u = s[i](l),
                        f = (l = u.value) instanceof Bo,
                        h = u.done;
                    Promise.resolve(f ? l[0] : l).then(m => f ? n(i === "return" ? i : "next", l[1] ? {
                        done: m.done,
                        value: m.value
                    } : m, c, d) : c({
                        value: m,
                        done: h
                    })).catch(m => n("throw", m, c, d))
                } catch (m) {
                    d(m)
                }
            },
            o = i => r[i] = l => new Promise((c, d) => n(i, l, c, d)),
            r = {};
        return s = s.apply(t, e), r[ti("asyncIterator")] = () => r, o("next"), o("throw"), o("return"), r
    };
var ni = (t, e, s) => (e = t[ti("asyncIterator")]) ? e.call(t) : (t = t[ti("iterator")](), e = {}, s = (n, o) => (o = t[n]) && (e[n] = r => new Promise((i, l, c) => (r = o.call(t, r), c = r.done, Promise.resolve(r.value).then(d => i({
    value: d,
    done: c
}), l)))), s("next"), s("return"), e);
import {
    _ as Es,
    r as x,
    j as a,
    E as vr,
    M as me,
    e as Ne,
    v as df,
    c as xe,
    u as kr,
    d as Tn,
    i as uf,
    y as ff,
    b as $c,
    f as Ts,
    a as mf,
    k as hf
} from "./fg33krlcm0qyi6yw.js";
import {
    A as gf
} from "./e0qtk69d4k3s8kri.js";
import {
    bh as Kn,
    gt as Sr,
    d as Rt,
    P as Xe,
    l as W,
    cU as pf,
    b as et,
    C1 as xf,
    bc as Ot,
    bd as Ft,
    hv as Di,
    dI as Xn,
    fN as Ls,
    e4 as bf,
    c0 as _n,
    m as ys,
    o as at,
    id as Er,
    eD as Oi,
    sF as yf,
    d6 as wf,
    c2 as _f,
    _ as ts,
    bH as vf,
    eF as kf,
    bI as yi,
    jR as Sf,
    fh as Ac,
    de as Ef,
    Z as sr,
    S as nr,
    f$ as jf,
    a9 as us,
    M as Ns,
    az as Mf,
    aq as Cf,
    ar as Tf,
    bg as On,
    T as Yn,
    m2 as Lc,
    fX as Dc,
    vs as If,
    se as Nf,
    dF as fs,
    es as Pf,
    cS as Rf,
    b3 as $f,
    aW as Zn,
    py as Oc,
    i as jr,
    iK as Ds,
    nV as Af,
    hh as Jn,
    k2 as Lf,
    R as vn,
    A as Mr,
    ki as Df,
    k as Fc,
    e as Bc,
    kM as Of,
    iU as Cr,
    js as Ff,
    aX as Aa,
    da as un,
    kW as Bf,
    aY as Wf,
    fA as zf,
    tc as Mn,
    aP as Wc,
    bb as Fi,
    p_ as Hf,
    kI as Uf,
    bv as wi,
    F as Tr,
    C2 as Gf,
    C3 as qf,
    BV as Vf,
    gK as zc,
    g2 as Ut,
    Q as Kf,
    cX as Xf,
    f8 as Yf,
    gd as Zf,
    mO as Jf,
    gF as Hc,
    e2 as Qf,
    AK as or,
    rx as em,
    ry as Uc,
    gq as tm,
    eG as sm,
    eh as nm,
    fD as om,
    mI as rm,
    C4 as im,
    dL as am,
    dR as lm,
    fG as cm,
    c_ as dm,
    g8 as Gc,
    h as Ht,
    C5 as Bi,
    C6 as um,
    cY as fm,
    oO as an,
    aj as mm,
    ao as hm,
    ai as gm,
    wJ as ws,
    oa as fn,
    rT as Wt,
    wV as Os,
    xG as as,
    xH as ln,
    wN as it,
    Ah as pm,
    dD as xm,
    AE as bm,
    B$ as ym,
    rS as mn,
    C7 as wm,
    p as _m,
    ga as Zo,
    C8 as vm,
    hq as km,
    hr as Sm,
    C9 as Em,
    uz as qc,
    hu as jm,
    fe as La,
    b$ as Mm,
    aA as Vc,
    na as Kc,
    nc as Xc,
    nb as Yc,
    n9 as Zc,
    nh as Jc,
    nZ as Cm,
    ow as Tm,
    Ca as Im,
    ab as Nm,
    l9 as Pm,
    mv as Rm,
    j7 as Fn,
    b9 as Bn,
    uZ as Da,
    Cb as Oa,
    th as $m,
    Cc as Am,
    Cd as Lm,
    Ce as Dm,
    x6 as Qc,
    mR as Wi,
    o4 as Om,
    Cf as Fa,
    Cg as Ba,
    x3 as Wa,
    w_ as Fm,
    wZ as Bm,
    Ch as Wm,
    pJ as zm,
    d9 as Hm,
    kC as Um,
    ck as Gm,
    qA as qm,
    l3 as Vm,
    Ci as Km,
    Cj as Xm,
    dH as ed,
    r4 as Ym,
    kv as Zm,
    AL as Jm,
    AM as Qm,
    Ck as eh
} from "./dykg4ktvbu3mhmdo.js";
import {
    hd as js,
    EA as td,
    EB as th,
    EC as sh,
    ED as za,
    EE as Qn,
    EF as nh,
    EG as sd,
    vo as oh,
    oE as nd,
    jq as od,
    b2 as rd,
    BE as rh,
    rI as ih,
    cj as Ir,
    fY as ah,
    fJ as lh,
    Y as ch,
    hb as dh,
    eq as uh,
    nc as fh,
    gJ as _i,
    ib as Nr,
    kS as Pr,
    ab as Rr,
    ac as $r,
    uX as mh,
    eX as id,
    iO as hh,
    iN as gh,
    cx as ph,
    jS as xh,
    pY as bh,
    n6 as hn,
    dU as zi,
    c8 as yh,
    fx as Hi,
    EH as wh,
    EI as ad,
    eT as Ar,
    ej as Jo,
    nb as _h,
    dn as vh,
    EJ as kh,
    rU as Sh,
    n2 as Eh,
    jy as jh,
    aC as eo,
    jd as ld,
    N as Mh,
    l5 as Ch,
    EK as Th,
    qI as Ih,
    EL as cd,
    aW as dd,
    EM as Nh,
    EN as Ph,
    je as Rh,
    qL as $h,
    gg as Ah,
    EO as Lh,
    f5 as Dh,
    e$ as Oh,
    cw as ud,
    nJ as Fh,
    kz as Bh,
    jc as Wh,
    EP as zh,
    hO as fd,
    jb as Hh,
    wM as Uh,
    cf as Gh,
    DS as qh,
    EQ as rr,
    ER as Vh,
    ES as Kh,
    ET as Xh,
    CX as Ui,
    j1 as Yh,
    rE as Gi,
    EU as md,
    cE as Ha,
    EV as Zh,
    EW as Jh,
    EX as Qh,
    EY as eg,
    EZ as tg,
    E_ as sg,
    cD as ng,
    fS as og,
    dr as oi,
    bq as en,
    bp as ri,
    E$ as Ua,
    l as rg,
    ca as ig,
    c$ as ag,
    vg as lg,
    DN as cg,
    F0 as dg,
    aV as ug,
    pa as fg,
    Ck as mg,
    F1 as hg,
    F2 as gg,
    iF as pg,
    lf as Lr
} from "./k15yxxoybkkir2ou.js";
import {
    u as xg,
    g as bg,
    s as ii,
    F as Is,
    C as yg,
    I as wg,
    P as _g,
    a as vg,
    b as kg,
    c as Sg,
    d as Eg
} from "./bcsv6m4oh341rml5.js";
import {
    u as qi
} from "./fyk9tph6baj60t7u.js";
import {
    N as jg
} from "./ou2xm3xmri21t4zm.js";
import {
    g as Wo,
    F as Mg,
    i as Cg
} from "./jzwivbl10of3y0cy.js";
import {
    E as Tg
} from "./nbft03bzj0s0fw3v.js";
import {
    f as Ig
} from "./f96c6fguu1kcw0go.js";
import {
    W as Ng
} from "./nb22pb07i8ebbv0i.js";
import {
    L as hd
} from "./iiok29s29bpdre61.js";
import {
    u as Pg
} from "./nzjsohh941f1fuvy.js";
import {
    a as Rg,
    d as $g,
    C as Ag
} from "./dv2e3o9gddnli9b5.js";
import {
    a as Lg
} from "./ekwi2j2bxci5d5rf.js";
import {
    A as Qo,
    g as Dg,
    m as Og,
    b as vi,
    o as Fg,
    I as gd,
    D as Bg,
    c as Wg
} from "./k57uzqpnr7k7r909.js";
import {
    W as zg,
    d as Hg,
    b as Ug,
    a as Gg
} from "./dqz86fcur874gotm.js";
import qg from "./fnxhy13zl746u1sp.js";
import {
    W as Dr
} from "./zqbip2ya77i1mx4s.js";
import {
    W as Vg
} from "./hfur3m15nh6zuk4s.js";
import {
    W as Ga,
    i as Kg
} from "./n3mktr5m7sakg90x.js";
import {
    h as Xg,
    q as Yg,
    x as Zg
} from "./jb9b7tatrnyq635u.js";
import {
    W as Jg
} from "./mvhcdm28zmc6uy2d.js";
import {
    A as Qg
} from "./kg0cp341m64rddpv.js";
import {
    u as pd
} from "./u9jpwxvw30u3h6nc.js";
import {
    j as ep
} from "./brbv8u56dvmb3wbc.js";
import {
    A as tp
} from "./h21g9slzr4ujv9kj.js";
import {
    u as Vi,
    R as Ki,
    b as Xi,
    r as sp,
    c as np,
    d as op,
    e as rp,
    f as ip,
    g as ap
} from "./bi6phpick816e345.js";
import {
    M as Or
} from "./ebc4iyfg14nu1gw4.js";
import {
    a as lp,
    b as cp
} from "./gd2ozzf4upgi0amm.js";
import {
    g as dp,
    b as up,
    a as fp,
    c as mp,
    F as hp,
    d as gp
} from "./dcboyjh87ll7k264.js";
import {
    v as qa,
    C as pp,
    A as xp,
    h as bp,
    j as yp,
    f as wp,
    p as _p,
    k as vp,
    n as kp,
    P as Sp,
    o as Ep,
    q as jp,
    L as Mp
} from "./du4xh8plp0f7ydun.js";
import {
    u as In,
    t as Va,
    r as ki,
    g as bs
} from "./f1axa7efo9jhz2uv.js";
import {
    T as Kt
} from "./hn5e71c3hkpkv00z.js";
import {
    c as xd
} from "./n6upldbhvll48b0q.js";
import {
    markdownToClipboardContent as bd
} from "./nbd6wafppmcw1yix.js";
import {
    a as Cp,
    T as Tp
} from "./g0f4hjqp90x9s4o7.js";
import {
    c as Yi
} from "./jdzosouyvpzu0tpb.js";
import {
    S as Ka,
    E as Ip
} from "./g63j6um9azgogw0s.js";
import {
    P as Np,
    S as Pp,
    a as Rp,
    h as $p,
    r as Xa,
    u as Ap
} from "./bt8940c6l4ej9r7j.js";
import {
    f as Lp,
    P as yd,
    H as Nn,
    L as Dp,
    R as Op,
    T as Fp
} from "./eafv7vq0yf9bv0fi.js";
import {
    M as Bp,
    N as Wp,
    E as zp,
    S as Hp
} from "./f76gy0b8ieo4s693.js";
import {
    c as Up,
    d as Gp,
    B as Si,
    e as qp,
    b as Vp,
    H as Kp,
    f as Xp,
    I as Ei,
    L as Yp,
    O as Zi,
    U as Ji,
    S as Zp,
    T as Jp,
    g as Qp,
    h as e1,
    C as t1,
    s as s1,
    i as n1,
    t as o1
} from "./fgxxkkb4il90gii6.js";
import {
    f as r1
} from "./jsd0vs4cv2vks3ah.js";
import {
    r as i1
} from "./nfccle6oyncifphl.js";
import {
    r as a1
} from "./b5s349mvbdzayaxi.js";
import {
    B as l1,
    I as c1
} from "./owg1rbxotm5jsyn7.js";
import {
    b as ir,
    S as wd,
    R as _d,
    a as Ya
} from "./gbmggnydp7mcsebl.js";
import {
    Z as Qi,
    T as ea
} from "./ce3hgmw4iyyhicud.js";
import {
    u as d1
} from "./l09h2qppleubii6l.js";
import {
    s as u1
} from "./kwqlokvhsdnnmw9d.js";
import {
    C as Za
} from "./gb3g89r4fqk97sov.js";
import {
    d as f1
} from "./kl7c6054usfnqmd4.js";
import {
    g as m1
} from "./k97n0y6ba9c9h39c.js";
import {
    T as h1
} from "./djfxxaryk37v3pj1.js";
import {
    gdocRegex as g1
} from "./dfk80oxw9xer35fj.js";
const p1 = xd("ChevronDownFilled", "1em", ["M15.8 7.73c.28.3.27.78-.03 1.06l-5.25 5a.75.75 0 0 1-1.04 0l-5.25-5a.75.75 0 0 1 1.04-1.08L10 12.2l4.73-4.5a.75.75 0 0 1 1.06.02Z"]),
    x1 = xd("ChevronLeftFilled", "1em", ["M12.27 15.8a.75.75 0 0 1-1.06-.03l-5-5.25a.75.75 0 0 1 0-1.04l5-5.25a.75.75 0 1 1 1.08 1.04L7.8 10l4.5 4.73c.29.3.28.78-.02 1.06Z"]),
    b1 = Kn(() => Es(() =>
        import ("./gnf5x18zszgh02tj.js"), __vite__mapDeps([0, 1, 2, 3])).then(t => t.SafeLinkWarningModal)),
    Ja = {},
    Qa = {},
    el = {};

function tl(t, e) {
    return "".concat(t, "::").concat(e)
}

function vd(l) {
    var c = l,
        {
            node: t,
            onClick: e,
            children: s,
            messageId: n,
            href: o,
            disableSafeURLs: r
        } = c,
        i = Bt(c, ["node", "onClick", "children", "messageId", "href", "disableSafeURLs"]);
    var g, k, E, j;
    const d = et(),
        u = Sr();
    let f = e;
    const h = (g = t == null ? void 0 : t.properties) == null ? void 0 : g.href,
        m = x.useContext(js),
        b = Rt(() => u == null ? void 0 : u.serverId$()),
        y = td(b, o, (m == null ? void 0 : m.useSafeUrls) && !r),
        p = th(u == null ? void 0 : u.id, n),
        w = (j = (E = (k = p == null ? void 0 : p.metadata) == null ? void 0 : k.__internal) == null ? void 0 : E.utm_tags) != null ? j : {},
        C = sh(u == null ? void 0 : u.id),
        v = !r && y === void 0;
    return n != null && typeof h == "string" && h.includes("/bing/redirect") && (Ja[n] || (Xe.logEvent("Browsing Show Bing Link", {
        id: n,
        content: h
    }), Ja[n] = !0), f = M => {
        Qa[n] || (Xe.logEvent("Browsing Click Bing Link", {
            id: n,
            content: h
        }), Qa[n] = !0), e == null || e(M)
    }), f = M => {
        const T = "" + h;
        if (n && !el[tl(n, T)]) {
            const N = y || v ? "URL Clicked Allowed" : "URL Clicked Blocked";
            Xe.logEvent(N, {
                id: n,
                content: T
            }), el[tl(n, T)] = !0
        }
        e == null || e(M), v && o && (M.preventDefault(), pf(d, b1, {
            urls: za(o, w, C)
        }))
    }, a.jsx(a.Fragment, {
        children: a.jsx("a", ce(F({
            onClick: f
        }, i), {
            className: W(i.className, v && "cursor-pointer"),
            href: y && za(y, w, C),
            rel: "noopener",
            children: s
        }))
    })
}

function y1(s) {
    var n = s,
        {
            children: t
        } = n,
        e = Bt(n, ["children"]);
    return a.jsxs(vd, ce(F({}, e), {
        className: "decorated-link",
        children: [t, a.jsx("span", {
            "aria-hidden": !0,
            className: "ms-0.5 inline-block align-middle leading-none",
            children: a.jsx(gf, {
                className: "block h-[0.75em] w-[0.75em] stroke-current stroke-[0.75]"
            })
        })]
    }))
}
const sl = ({
        children: t,
        "data-start": e = null,
        "data-end": s = null,
        "data-is-last-node": n,
        "data-is-only-node": o,
        tag: r
    }) => {
        const {
            animationTiming: i,
            shouldAnimate: l,
            shouldHide: c,
            isDisabled: d,
            onComplete: u,
            onReady: f
        } = xg({
            isMarker: !0,
            tag: r,
            children: t,
            start: e,
            end: s,
            isLastNode: n,
            isOnlyNode: o
        });
        return d || c ? a.jsx(r, {
            "data-start": e,
            "data-end": s,
            className: W(c && "hidden"),
            children: t
        }) : a.jsx(r, {
            "data-start": e,
            "data-end": s,
            className: W(ii.marker, l ? ii.animate : ii.hidden),
            onAnimationStart: () => f(0),
            onAnimationEnd: () => u(0),
            style: bg(i),
            children: t
        })
    },
    w1 = {
        p: t => a.jsx(Is, F({
            tag: "p"
        }, t)),
        h1: t => a.jsx(Is, F({
            tag: "h1"
        }, t)),
        h2: t => a.jsx(Is, F({
            tag: "h2"
        }, t)),
        h3: t => a.jsx(Is, F({
            tag: "h3"
        }, t)),
        h4: t => a.jsx(Is, F({
            tag: "h4"
        }, t)),
        h5: t => a.jsx(Is, F({
            tag: "h5"
        }, t)),
        h6: t => a.jsx(Is, F({
            tag: "h6"
        }, t)),
        li: t => a.jsx(sl, F({
            tag: "li",
            isListItem: !0
        }, t)),
        hr: t => a.jsx(sl, F({
            tag: "hr"
        }, t))
    };

function _1(t) {
    const e = kd(t),
        s = P1(e);
    return R1(s)
}

function kd(t) {
    const e = t.length > 0 ? t.split("\n") : [];
    let s = !1,
        n = null;
    for (let o = 0; o < e.length; o++) {
        const r = e[o],
            i = Qn(r);
        if (i) {
            const c = i.info.trimStart(),
                d = i.info.trim();
            if (s) n && i.marker === n.marker && i.fence.length === n.fence.length && d.length === 0 && (n = null);
            else if (c.startsWith("{")) {
                const u = j1(e, o, i);
                e[o] = u.normalizedLine, (u.linesConsumed > 0 || u.replacementLines.length) && e.splice(o + 1, u.linesConsumed, ...u.replacementLines), n = i
            } else if (d.length === 0 && o === e.length - 1) {
                e.splice(o, 1);
                continue
            }
            s = !s;
            continue
        }
        if (s) {
            n && I1(r, n) && (e[o] = "".concat(n.leadingWhitespace).concat(n.fence), n = null, s = !1);
            continue
        }
        const l = r.trim();
        if (l.startsWith(":::") && l !== ":::") {
            const c = l.indexOf("{");
            if (c === -1) {
                const d = l.slice(3).trim();
                if (d.length > 0 && !xf.has(d)) {
                    e[o] = ":::";
                    continue
                }
                if (d === "writing") {
                    const u = r.replace(/\s+$/, "");
                    e[o] = u + "{}"
                } else e[o] = r.replace(/\s+$/, "");
                continue
            }
            k1(l, c) || (e[o] = v1(r, r.indexOf("{")))
        }
        e.length > 1 && e[e.length - 1] === ":::" && e[e.length - 2] === ":::" && e.splice(-2)
    }
    if (n && (e.push("".concat(n.leadingWhitespace).concat(n.fence)), n = null), e.length > 0) {
        const o = e[e.length - 1];
        (o === ":" || o === "::") && (e.pop(), e.length > 0 && e.push(""))
    }
    return e.join("\n")
}

function v1(t, e) {
    const s = t.replace(/\s+$/, ""),
        n = s.slice(0, e).replace(/\s+$/, ""),
        o = s.slice(e + 1);
    if (o.trim().length === 0 || !/=/.test(o)) return n + "{}";
    let i = null,
        l = !1;
    for (let c = 0; c < o.length; c++) {
        const d = o[c];
        if (l) {
            l = !1;
            continue
        }
        if (d === "\\") {
            l = !0;
            continue
        }
        if (i) {
            d === i && (i = null);
            continue
        }
        if (d === '"' || d === "'") {
            i = d;
            continue
        }
    }
    return i ? s + i + "}" : /=[\s]*$/.test(o) ? s + '""}' : s + "}"
}

function k1(t, e) {
    let s = null,
        n = 0,
        o = !1;
    for (let r = e; r < t.length; r++) {
        const i = t[r];
        if (o) {
            o = !1;
            continue
        }
        if (i === "\\") {
            o = !0;
            continue
        }
        if (s) {
            i === s && (s = null);
            continue
        }
        if (i === '"' || i === "'") {
            s = i;
            continue
        }
        if (i === "{") {
            n++;
            continue
        }
        if (i === "}") {
            if (n--, n === 0) return !0;
            continue
        }
    }
    return !1
}

function S1(t) {
    const e = t.match(/^\s*/),
        s = e ? e[0] : "",
        n = t.slice(s.length);
    if (!n.startsWith("{")) return "".concat(s, "{}");
    let o;
    try {
        const [l] = sd(n, !0);
        o = l
    } catch (l) {
        return "".concat(s, "{}")
    }
    const r = Sd(o);
    if (!r) return "".concat(s, "{}");
    const i = JSON.stringify(r);
    return "".concat(s).concat(i)
}

function Sd(t) {
    if (!(!t || Array.isArray(t) || typeof t != "object")) return t
}
const E1 = 8,
    Ed = 2048;

function j1(t, e, s) {
    var d, u;
    const n = s.leadingWhitespace.length + s.fence.length;
    let r = (u = (d = t[e]) == null ? void 0 : d.slice(n)) != null ? u : "",
        i = 0,
        l = nl(r);
    if (l.kind === "complete") {
        const f = ol(l.remainder, s.fence),
            h = rl(s, l.value);
        return f.trim().length === 0 && f.length > 0 && !f.includes("\n") ? {
            normalizedLine: h + f,
            linesConsumed: 0,
            replacementLines: []
        } : {
            normalizedLine: h,
            linesConsumed: 0,
            replacementLines: il(f)
        }
    }
    for (; l.kind === "needsMore" && i < E1 && r.length < Ed;) {
        const f = e + i + 1;
        if (f >= t.length) break;
        const h = t[f];
        if (!C1(h)) break;
        if (i++, r = "".concat(r, "\n").concat(h != null ? h : ""), l = nl(r), l.kind === "complete") {
            const m = ol(l.remainder, s.fence);
            return {
                normalizedLine: rl(s, l.value),
                linesConsumed: i,
                replacementLines: il(m)
            }
        }
        if (l.kind === "invalid") break
    }
    return {
        normalizedLine: M1(s, r),
        linesConsumed: i,
        replacementLines: []
    }
}

function nl(t) {
    if (!t) return {
        kind: "invalid"
    };
    const e = t.indexOf("{");
    if (e === -1) return {
        kind: "invalid"
    };
    const s = t.slice(e),
        n = T1(s);
    if (n == null) return t.length >= Ed ? {
        kind: "invalid"
    } : {
        kind: "needsMore"
    };
    const o = s.slice(0, n + 1);
    try {
        const [r, i] = sd(o.trim()), l = Sd(r);
        if (!l) return {
            kind: "invalid"
        };
        if (i != null) return {
            kind: "needsMore"
        };
        const c = s.slice(n + 1);
        return {
            kind: "complete",
            value: l,
            remainder: c
        }
    } catch (r) {
        return {
            kind: "invalid"
        }
    }
}

function ol(t, e) {
    const s = t.trim();
    return s.length === 0 ? t : s.includes(e) ? s.replace(e, "") : t
}

function rl(t, e) {
    const s = "".concat(t.leadingWhitespace).concat(t.fence);
    return "".concat(s).concat(JSON.stringify(e))
}

function M1(t, e) {
    const s = "".concat(t.leadingWhitespace).concat(t.fence),
        n = S1(e.replace(/\r?\n+/g, " ").trimStart()).trim();
    return n.length === 0 ? "".concat(s, "{}") : "".concat(s).concat(n)
}

function C1(t) {
    if (!t) return !1;
    const e = t.trimStart();
    if (e.length === 0) return !0;
    const s = e[0];
    return s === '"' || s === "'" || s === "{" || s === "}" || s === "[" || s === ","
}

function T1(t) {
    let e = !1,
        s = 0,
        n = !1,
        o = !1;
    for (let r = 0; r < t.length; r++) {
        const i = t[r];
        if (!e) {
            i === "{" && (e = !0, s = 1);
            continue
        }
        if (o) {
            o = !1;
            continue
        }
        if (i === "\\") {
            o = !0;
            continue
        }
        if (n) {
            i === '"' && (n = !1);
            continue
        }
        if (i === '"') {
            n = !0;
            continue
        }
        if (i === "{") {
            s++;
            continue
        }
        if (i === "}") {
            if (s--, s === 0) return r;
            continue
        }
    }
    return null
}

function il(t) {
    if (!t) return [];
    const e = t.startsWith("\n") ? t.slice(1) : t;
    return e.length === 0 ? [] : e.split("\n")
}

function I1(t, e) {
    const s = t.trim();
    return s.length === 0 || !N1(s, e.marker) ? !1 : s.length < e.fence.length
}

function N1(t, e) {
    for (let s = 0; s < t.length; s++)
        if (t[s] !== e) return !1;
    return !0
}

function P1(t) {
    var i, l;
    const e = t.length > 0 ? t.split("\n") : [],
        s = [],
        n = [];
    let o = null,
        r = null;
    for (let c = 0; c < e.length; c++) {
        const d = e[c],
            u = Qn(d),
            f = (i = u == null ? void 0 : u.info.trimStart()) != null ? i : "",
            h = (l = u == null ? void 0 : u.info.trim()) != null ? l : "",
            m = u && f.startsWith("{") && u.fence.length > 0;
        if (o && u && h.length === 0 && u.marker === o.marker && u.fence.length === o.length && n.length === 0) {
            const y = r == null ? "" : kd(r.join("\n")),
                p = y.length > 0 ? y.split("\n") : r && r.length > 0 ? [""] : [];
            s.push(...p), o = null, r = null;
            continue
        }
        if (!o && u && !m && h.length === 0 && u.marker === "`" && n.length === 0 && $1(e[c + 1]) && A1(e, c + 1, u.marker, u.fence.length) != null) {
            o = {
                marker: u.marker,
                length: u.fence.length
            }, r = [];
            continue
        }
        if (u && !m && u.marker === "`") {
            const y = n[n.length - 1];
            y && h.length === 0 && u.marker === y.marker && u.fence.length === y.length ? n.pop() : n.push({
                marker: u.marker,
                length: u.fence.length
            })
        }
        o ? r == null || r.push(d) : s.push(d)
    }
    return s.join("\n")
}

function R1(t) {
    const e = t.length > 0 ? t.split("\n") : [];
    for (let s = 0; s < e.length; s++) {
        const n = Qn(e[s]);
        if (!n || !(n.info.trimStart().startsWith("{") && n.fence.length > 0)) continue;
        const i = n.fence,
            l = e[s].replace(/\s+$/, "");
        if (!l.endsWith(i)) continue;
        const c = l.slice(0, l.length - i.length);
        e[s] = c.trimEnd()
    }
    return e.join("\n")
}

function $1(t) {
    if (!t || !nh.test(t)) return !1;
    const e = Qn(t);
    return e ? e.marker === "~" && e.fence.length === 3 : !1
}

function A1(t, e, s, n) {
    const o = [{
        marker: s,
        length: n
    }];
    for (let r = e; r < t.length; r++) {
        const i = Qn(t[r]);
        if (!i || i.marker !== "`" || i.info.trimStart().startsWith("{") && i.fence.length > 0) continue;
        const c = i.info.trim(),
            d = o[o.length - 1];
        if (d && c.length === 0 && i.marker === d.marker && i.fence.length === d.length) {
            if (o.pop(), o.length === 0) return r;
            continue
        }
        o.push({
            marker: i.marker,
            length: i.fence.length
        })
    }
    return null
}

function L1(r) {
    var i = r,
        {
            messageId: t,
            conversation: e,
            text: s,
            children: n
        } = i,
        o = Bt(i, ["messageId", "conversation", "text", "children"]);
    const l = window.location.origin,
        c = "".concat(l, "?q=").concat(encodeURIComponent(s)),
        d = oh(),
        u = x.useCallback(async f => {
            f.preventDefault(), Ot.count(Ft.DEFAULT, "instant_follow_up_anchor_clicked"), Xe.logEventWithStatsig("Instant Follow Up Anchor Clicked", "chatgpt_instant_follow_up_anchor_clicked", {
                clientThreadId: e.id,
                messageId: t
            }), d(f, {
                text: s,
                type: nd.Reply
            }, [], 0)
        }, [e, t, s, d]);
    return a.jsx(vd, ce(F({}, o), {
        href: c,
        disableSafeURLs: !0,
        messageId: t,
        className: "cursor-pointer",
        onClick: u,
        children: n
    }))
}
const D1 = vr.memo(L1);

function O1(t) {
    const e = t.length > 0 ? t.split("\n") : [],
        s = e.pop(),
        n = F1(s).trimEnd();
    return n && e.push(n), e.join("\n")
}

function F1(t) {
    if (!t || /^\s*-\s*([*_]+)?\s*$/.test(t)) return "";
    const e = [];
    let s = "",
        n = 0;
    for (; n < t.length;) {
        if (t[n] === "*" && t[n + 1] === "*") {
            s += "**", e.length && e[e.length - 1] === "**" ? e.pop() : e.push("**"), n += 2;
            continue
        }
        if (t[n] === "*" || t[n] === "_") {
            s += t[n];
            const r = t[n];
            e.length && e[e.length - 1] === r ? e.pop() : e.push(r), n++;
            continue
        }
        if (t[n] === "[") {
            const r = t[n];
            s += r, e.push(r), n++;
            continue
        }
        if (t[n] === "]") {
            const r = t[n];
            s += r, e.length && e[e.length - 1] === "[" && e.pop(), n++;
            continue
        }
        if (t[n] === "(" && t[n - 1] === "]") {
            const r = t[n];
            s += r, e.push(r), n++;
            continue
        }
        if (t[n] === ")") {
            const r = t[n];
            s += r, e.length && e[e.length - 1] === "(" && e.pop(), n++;
            continue
        }
        s += t[n], n++
    }
    if (e.length === 0) return t;
    let o = s.trimEnd();
    for (; e.length;) {
        const r = e.pop();
        if (r == null) break;
        r === "(" ? o += ")" : o.endsWith(r) ? o = o.slice(0, -r.length).trimEnd() : r === "[" ? o += "]()" : o += r
    }
    return o
}

function B1({
    citation: t
}) {
    return a.jsx(od, {
        side: "top",
        triggerButton: a.jsx("span", {
            className: "inline-flex items-center font-bold",
            children: a.jsx(me, {
                id: "ZNWtPG",
                defaultMessage: "{startChar}clipboard {icon}{endChar}",
                values: {
                    startChar: "「",
                    icon: a.jsx(rh, {
                        className: "mb-1 inline-block size-5"
                    }),
                    endChar: "」"
                }
            })
        }),
        className: "max-w-xl",
        children: a.jsxs("div", {
            className: "flex flex-col items-stretch gap-1",
            children: [a.jsx("div", {
                className: "flex justify-end border-b",
                children: a.jsx(rd, {
                    onCopy: e => Di(t.text, void 0, e),
                    buttonText: !0,
                    textPosition: "left"
                })
            }), a.jsx("div", {
                children: t.text
            })]
        })
    })
}

function W1({
    citation: t,
    conversation: e,
    nodeType: s
}) {
    const n = Ne(),
        o = Xn(e.id),
        r = ih(t.screenshot_asset_pointer, o);
    return s === "containerDirective" && n.formatMessage({
        id: "4/Vs6a",
        defaultMessage: "Cited Screenshot"
    }), a.jsx(od, {
        side: "top",
        triggerButton: a.jsx("span", {
            className: "inline-flex items-center font-bold",
            children: a.jsx(me, {
                id: "qUxKU1",
                defaultMessage: "{startChar}screenshot {icon}{endChar}",
                values: {
                    startChar: "「",
                    icon: a.jsx(Ir, {
                        className: "mb-1 inline-block size-5"
                    }),
                    endChar: "」"
                }
            })
        }),
        className: "max-w-xl",
        children: r ? a.jsx("img", {
            className: "w-xl max-w-screen",
            src: r,
            alt: n.formatMessage({
                id: "4/Vs6a",
                defaultMessage: "Cited Screenshot"
            })
        }) : a.jsx("div", {
            className: "text-sm",
            children: a.jsx(me, {
                id: "BUdJTR",
                defaultMessage: "Screenshot not available"
            })
        })
    })
}

function jd({
    conversation: t,
    messageId: e,
    fileId: s,
    fileName: n,
    processedMarkdownInfo: o,
    isStandaloneAttachment: r
}) {
    const i = Xn(t.id),
        l = Ls(t.id, y => {
            var p;
            return e ? (p = y == null ? void 0 : y.tree.getNodeIfExists(e)) == null ? void 0 : p.message : void 0
        }),
        c = x.useMemo(() => {
            var w;
            if (!l) return null;
            const y = {
                    content_type: bf.Text,
                    parts: ["{{file:".concat(s, "}}")]
                },
                p = ce(F({}, l == null ? void 0 : l.metadata), {
                    is_synthetic_share_message: !0,
                    is_standalone_share_attachment: r
                });
            return p.content_references = (w = o == null ? void 0 : o.displayedContentReferences.filter(C => C.type !== "debug")) != null ? w : [], p.citations = [], o && (y.parts = [o.rawText], p.n7jupd_crefs = o.n7jupdCrefs), ce(F({}, l), {
                id: df(),
                content: y,
                metadata: p
            })
        }, [l, s, o, r]),
        d = x.useMemo(() => {
            if (!(!l || !c || !i)) return {
                previewMessage: c,
                clientThreadId: t.id,
                fileId: s,
                messageId: l.id,
                serverThreadId: i,
                isStandaloneAttachment: r,
                fileName: n
            }
        }, [c, t.id, s, l, i, r, n]),
        u = ah({
            odysseyShareIntent: d,
            clientThreadId: t.id
        }),
        [f, h] = x.useState(!1);
    return {
        onClick: x.useCallback(async () => {
            h(!0), await u(), h(!1)
        }, [h, u]),
        isLoading: f,
        isEnabled: !!d
    }
}

function z1({
    conversation: t,
    messageId: e,
    fileId: s,
    fileName: n,
    processedMarkdownInfo: o
}) {
    const r = Ne(),
        {
            onClick: i,
            isLoading: l,
            isEnabled: c
        } = jd({
            conversation: t,
            messageId: e,
            fileId: s,
            fileName: n,
            processedMarkdownInfo: o,
            isStandaloneAttachment: !1
        });
    return c ? a.jsx(lh, {
        onClick: i,
        label: r.formatMessage({
            id: "ConversationTurn.sharePostButtonTooltip",
            defaultMessage: "Share"
        }),
        icon: l ? _n : ch
    }) : null
}

function H1(t) {
    return t.endsWith(".md")
}
const U1 = ({
    citation: t,
    conversation: e,
    messageId: s
}) => {
    const n = et(),
        [o, r] = x.useState(!1),
        i = Xn(e.id),
        l = ys(),
        [c, d] = x.useState(null),
        u = x.useRef(null),
        f = x.useCallback(k => {
            l.danger(k, {
                toastId: "ttom_file_citation_failed_to_download_file"
            })
        }, [l]),
        h = t.file_id,
        m = at(n, "3154019201"),
        b = m,
        y = Er(),
        p = qi(!0, i, h, void 0, f),
        w = p == null ? void 0 : p.data,
        C = (p == null ? void 0 : p.isPending) || !1;
    x.useEffect(() => {
        var k;
        if ((w == null ? void 0 : w.status) === "success" && w.download_url) {
            (k = u.current) == null || k.abort();
            const E = new AbortController;
            u.current = E, r(!0), (async () => {
                try {
                    const j = await fetch(w.download_url, {
                        headers: y ? {} : Oi(),
                        signal: E.signal
                    });
                    if (!j.ok) throw new Error("HTTP ".concat(j.status));
                    d(await j.text())
                } catch (j) {
                    j.name !== "AbortError" && l.danger("Failed to download file", {
                        toastId: "ttom_file_citation_failed_to_download_file"
                    })
                } finally {
                    r(!1)
                }
            })()
        }
        return () => {
            var E;
            (E = u.current) == null || E.abort()
        }
    }, [w, l, y]);
    const v = x.useContext(js),
        g = x.useMemo(() => {
            var _, R, A, $, P, U, z, B, G;
            if (c == null) return null;
            const E = ($ = ((A = (R = (_ = v == null ? void 0 : v.message) == null ? void 0 : _.metadata) == null ? void 0 : R.content_references_by_file) != null ? A : {})[t.cite_key]) != null ? $ : [],
                j = yf(c, E);
            let M = j.processedText;
            const T = (P = j.displayedContentReferences) != null ? P : [],
                I = (G = ((B = (z = (U = v == null ? void 0 : v.message) == null ? void 0 : U.metadata) == null ? void 0 : z.n7jupd_crefs_by_file) != null ? B : {})[t.cite_key]) != null ? G : [];
            return I.length > 0 && (M = dh(M, I)), {
                processedText: M,
                displayedContentReferences: T,
                n7jupdCrefs: I,
                rawText: c
            }
        }, [c, v, t.cite_key]);
    return C || o ? a.jsx(_n, {
        className: "inline"
    }) : !g || !(v != null && v.message) ? "[Could not display report]" : a.jsx(js.Provider, {
        value: ce(F({}, v), {
            contentReferences: g.displayedContentReferences,
            n7jupdCrefs: g.n7jupdCrefs
        }),
        children: a.jsxs("div", {
            className: "border-token-border-light dark:border-token-bg-tertiary @container relative mx-[-16px] mt-4 mb-4 flex cursor-text flex-col items-start overflow-hidden rounded-[14px] border px-4 pt-6 pb-6 contain-inline-size sm:mx-[-32px] sm:rounded-[28px] sm:px-8 sm:shadow-sm",
            children: [a.jsx("div", {
                className: "w-full pt-1 pb-1 sm:pt-4 sm:pb-3",
                children: a.jsx(uh, {
                    conversation: e,
                    componentOverrides: jg,
                    children: g.processedText
                })
            }), b && a.jsx("div", {
                className: "flex",
                children: m && a.jsx(z1, {
                    conversation: e,
                    messageId: s,
                    fileId: h,
                    fileName: t.file_name,
                    processedMarkdownInfo: g,
                    isStandaloneAttachment: !1
                })
            })]
        })
    })
};

function G1(t, e) {
    if (!t || t.length === 0) return Promise.resolve(t);
    const s = new hd(new URL("/cdn/assets/calculate-worker-Cge-dq8f.js",
        import.meta.url), {
        type: "module"
    });
    return new Promise((n, o) => {
        const r = t.slice();
        let i = !1;
        const l = () => {
            i || (i = !0, s.postMessage({
                protoBytes: r,
                trailmixEnabled: e
            }, [r.buffer]))
        };
        s.onmessage = c => {
            var d, u;
            if (((d = c.data) == null ? void 0 : d.kind) === "calculate-worker-ready") {
                l();
                return
            }
            if (s.terminate(), c.data.error) {
                o(new Error(c.data.error));
                return
            }
            n((u = c.data.protoBytes) != null ? u : t)
        }, s.onerror = c => {
            s.terminate(), o(c)
        }
    })
}
const al = (t, e) => {
        const s = new hd(new URL("/cdn/assets/walnut-worker-WTOPKrTa.js",
            import.meta.url), {
            type: "module"
        });
        return new Promise((n, o) => {
            let r = !1;
            const i = {
                    bytes: t.buffer,
                    ext: e
                },
                l = () => {
                    r || (r = !0, s.postMessage(i, [t.buffer]))
                };
            s.onmessage = c => {
                var d, u;
                if (((d = c.data) == null ? void 0 : d.kind) === "walnut-worker-ready") {
                    l();
                    return
                }
                s.terminate(), c.data.error ? o(new Error(c.data.error)) : n((u = c.data.protoBytes) != null ? u : new Uint8Array)
            }, s.onerror = c => {
                s.terminate(), o(c)
            }
        })
    },
    q1 = "Walnut",
    V1 = {
        hash: "sha256-2aieaigVT3OqyUgsLZYlh2hM9cqu/i4COVPtcot09Q4=",
        fingerprinting: {
            "DocumentFormat.OpenXml.Framework.y6f0htgyhv.wasm": "DocumentFormat.OpenXml.Framework.wasm",
            "DocumentFormat.OpenXml.h9dy1651j0.wasm": "DocumentFormat.OpenXml.wasm",
            "Google.Protobuf.bvef67su4p.wasm": "Google.Protobuf.wasm",
            "System.Collections.Concurrent.9lu1brd9dn.wasm": "System.Collections.Concurrent.wasm",
            "System.Collections.NonGeneric.knkpn76dbg.wasm": "System.Collections.NonGeneric.wasm",
            "System.Collections.Specialized.fphqfm20s9.wasm": "System.Collections.Specialized.wasm",
            "System.Collections.zpof7ebupv.wasm": "System.Collections.wasm",
            "System.ComponentModel.Primitives.19qfe9vx44.wasm": "System.ComponentModel.Primitives.wasm",
            "System.ComponentModel.TypeConverter.v6ok9r0yls.wasm": "System.ComponentModel.TypeConverter.wasm",
            "System.ComponentModel.qu3d3gzmkd.wasm": "System.ComponentModel.wasm",
            "System.Console.xgvsggvnx2.wasm": "System.Console.wasm",
            "System.Diagnostics.DiagnosticSource.j8ly62mron.wasm": "System.Diagnostics.DiagnosticSource.wasm",
            "System.IO.Compression.1207vjwudi.wasm": "System.IO.Compression.wasm",
            "System.IO.Packaging.8th4tkd3a0.wasm": "System.IO.Packaging.wasm",
            "System.Linq.Expressions.v4h61ruutf.wasm": "System.Linq.Expressions.wasm",
            "System.Linq.ggmptkukob.wasm": "System.Linq.wasm",
            "System.Memory.3sw3whopgd.wasm": "System.Memory.wasm",
            "System.Net.Http.6m95liy40q.wasm": "System.Net.Http.wasm",
            "System.Net.Primitives.gd20ym2wiq.wasm": "System.Net.Primitives.wasm",
            "System.ObjectModel.toe3uknb7z.wasm": "System.ObjectModel.wasm",
            "System.Private.CoreLib.zi56pc4vac.wasm": "System.Private.CoreLib.wasm",
            "System.Private.Uri.zuxqy2gx3e.wasm": "System.Private.Uri.wasm",
            "System.Private.Xml.Linq.zd546umqfo.wasm": "System.Private.Xml.Linq.wasm",
            "System.Private.Xml.6t8s398ltr.wasm": "System.Private.Xml.wasm",
            "System.Runtime.InteropServices.JavaScript.5w5ncmofpv.wasm": "System.Runtime.InteropServices.JavaScript.wasm",
            "System.Security.Cryptography.88lukhdacm.wasm": "System.Security.Cryptography.wasm",
            "System.Text.RegularExpressions.k2or4udmln.wasm": "System.Text.RegularExpressions.wasm",
            "System.t4d4s3f398.wasm": "System.wasm",
            "System.Xml.Linq.62mgoxb9g2.wasm": "System.Xml.Linq.wasm",
            "Walnut.j832kq9pa8.wasm": "Walnut.wasm",
            "dotnet.native.d40gqx23ha.js": "dotnet.native.js",
            "dotnet.native.v3otg86x7v.wasm": "dotnet.native.wasm",
            "dotnet.js": "dotnet.js",
            "dotnet.runtime.9o45ky8ejm.js": "dotnet.runtime.js",
            "icudt_CJK.tjcz0u77k5.dat": "icudt_CJK.dat",
            "icudt_EFIGS.tptq2av103.dat": "icudt_EFIGS.dat",
            "icudt_no_CJK.lfu7j35m59.dat": "icudt_no_CJK.dat"
        },
        jsModuleNative: {
            "dotnet.native.d40gqx23ha.js": "sha256-Yz25lwtGCTLJ6ZGeuldtG8q1sARdTE3ncbdIoV+a32k="
        },
        jsModuleRuntime: {
            "dotnet.runtime.9o45ky8ejm.js": "sha256-6QIZYgG+ftoT9N1H1EEJeXIhD/qbKqEcnmawDskiwdI="
        },
        wasmNative: {
            "dotnet.native.v3otg86x7v.wasm": "sha256-S++3trG184tMIGi30cBqEtlrS+Clt7wNIOpPLiWDtBI="
        },
        icu: {
            "icudt_CJK.tjcz0u77k5.dat": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
            "icudt_EFIGS.tptq2av103.dat": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
            "icudt_no_CJK.lfu7j35m59.dat": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs="
        },
        coreAssembly: {
            "System.Private.CoreLib.zi56pc4vac.wasm": "sha256-e8rU/JzuXIMq3ri6K08hUKggTUP0lduUqRpgeA+Yr0k=",
            "System.Runtime.InteropServices.JavaScript.5w5ncmofpv.wasm": "sha256-lWFSmAKoXr5ke4quj4mDqc9K8FtiqsRli8yH2+AsiIQ="
        },
        assembly: {
            "DocumentFormat.OpenXml.Framework.y6f0htgyhv.wasm": "sha256-6hFb9I1YUZZBZNmBNoyLKm9PSrbly9UpHeU+yVNuRf0=",
            "DocumentFormat.OpenXml.h9dy1651j0.wasm": "sha256-W3/xwwlsy5SGW4inHeT7EbEyxQUxZLHMtS9jvsryI0k=",
            "Google.Protobuf.bvef67su4p.wasm": "sha256-+YTHK5iMJ1qqT8rwso0msRnFimxTnVn7anp423wPdM4=",
            "System.Collections.Concurrent.9lu1brd9dn.wasm": "sha256-42c4PHN0rCakEdhwYIF+Gh+zYzH0USVgLTHmAM67dsA=",
            "System.Collections.NonGeneric.knkpn76dbg.wasm": "sha256-MDgXzSQ6+n31fzEot23il4Tz8icWhBQOPJBWcPAWNpY=",
            "System.Collections.Specialized.fphqfm20s9.wasm": "sha256-I4ObXcfKEYFE/rWO7yMwb52mB+TxNlVDr74zFi7VZBc=",
            "System.Collections.zpof7ebupv.wasm": "sha256-57lJgKNbZqY86RSEXEugr/5z+KG34t3H/xRf3BGJxGA=",
            "System.ComponentModel.Primitives.19qfe9vx44.wasm": "sha256-WwsxFkhJ2bnScc14Iq3C/Oujc30kI7N1c7AclgPMcWE=",
            "System.ComponentModel.TypeConverter.v6ok9r0yls.wasm": "sha256-idNBYnCGYv7oJHAVQRZZMsHKhnISygjKF/7Pc/6YNaE=",
            "System.ComponentModel.qu3d3gzmkd.wasm": "sha256-wifBFoiHVP4KaFhjz887NKTzJH/M6gWTCeR9gYcM078=",
            "System.Console.xgvsggvnx2.wasm": "sha256-UY6M99pYB1FVWuUtdMP4VBoubK7+XwmMVLy5ymKPpjs=",
            "System.Diagnostics.DiagnosticSource.j8ly62mron.wasm": "sha256-/TGI24Jx79K7wdRMcd2B8hLSAt55XyrqqilZYuSGURc=",
            "System.IO.Compression.1207vjwudi.wasm": "sha256-99gjke7Xs66Q1t3Tnc6hyJXTJNs242YuR+JF1Dmr2Uc=",
            "System.IO.Packaging.8th4tkd3a0.wasm": "sha256-1C+I5A7ESuL28X57RP+FiTL8ayuTe86SmJE6NSg4dQA=",
            "System.Linq.Expressions.v4h61ruutf.wasm": "sha256-P+nlIV3Lelxh/GL45XSlhIbqfl8wROUSaM30VuJyr0M=",
            "System.Linq.ggmptkukob.wasm": "sha256-ENWMas8jrh+VDxfIedAgvo+Xq5NDv5fkxQyQnGz8+JE=",
            "System.Memory.3sw3whopgd.wasm": "sha256-s4ytDaGz9lgkWcvugGm7uXm32ktFEgEnljd75YCGsns=",
            "System.Net.Http.6m95liy40q.wasm": "sha256-EmMh+7TEbcrjE07LZSbqsT+i3cg2SfuFEwB3v81srW0=",
            "System.Net.Primitives.gd20ym2wiq.wasm": "sha256-/FmecRu5Wfb7p4wjY3KDbGzMWRfNbwsnnAnzdbPF9b8=",
            "System.ObjectModel.toe3uknb7z.wasm": "sha256-HUvykr+C4XE/y2OMQ49bBU8+S644IUrkWewmynWp8Gs=",
            "System.Private.Uri.zuxqy2gx3e.wasm": "sha256-Fejtz3SBcZXQZfPLUq7OAR777eOvADHVRni2jgd9CrE=",
            "System.Private.Xml.Linq.zd546umqfo.wasm": "sha256-uS0XUclnc6brmaGFCZXDocwEPNdIW+RDVJtuiUSHUzQ=",
            "System.Private.Xml.6t8s398ltr.wasm": "sha256-moJdO1oBJXlis9s2IobGWvvzrmZkBMWMGJohZ+K8KLU=",
            "System.Security.Cryptography.88lukhdacm.wasm": "sha256-+I6ReCyc24I6xnyCUAOnvbs2DJc+kq8hkMUcQYNODvs=",
            "System.Text.RegularExpressions.k2or4udmln.wasm": "sha256-nL7n4NFLJuA7lHZQLCCKYPQC2vL/5Fco431ijPaCsRs=",
            "System.t4d4s3f398.wasm": "sha256-fVP2BxRRKpBA0PmBbKxmO45bXDrAXVn1GthlDclLbeU=",
            "System.Xml.Linq.62mgoxb9g2.wasm": "sha256-UgDQgumqZj6p9gp1AxxwuF7FY0ittV25c4qrMW9q7XY=",
            "Walnut.j832kq9pa8.wasm": "sha256-44hskhXlwBsiWaeiHuvMmjy7rYjKcRLe0HDkJUWMGyg="
        }
    },
    K1 = 0,
    X1 = !0,
    Y1 = "sharded",
    Z1 = {
        mainAssemblyName: q1,
        resources: V1,
        debugLevel: K1,
        linkerEnabled: X1,
        globalizationMode: Y1
    }; //! The .NET Foundation licenses this file to you under the MIT license.
var J1 = !1;
const Q1 = async () => WebAssembly.validate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 4, 1, 96, 0, 0, 3, 2, 1, 0, 10, 8, 1, 6, 0, 6, 64, 25, 11, 11])),
    ex = async () => WebAssembly.validate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 5, 1, 96, 0, 1, 123, 3, 2, 1, 0, 10, 10, 1, 8, 0, 65, 0, 253, 15, 253, 98, 11])),
    ta = Symbol.for("wasm promise_control");

function vs(t, e) {
    let s = null;
    const n = new Promise((function(r, i) {
        s = {
            isDone: !1,
            promise: null,
            resolve: l => {
                s.isDone || (s.isDone = !0, r(l), t && t())
            },
            reject: l => {
                s.isDone || (s.isDone = !0, i(l), e && e())
            }
        }
    }));
    s.promise = n;
    const o = n;
    return o[ta] = s, {
        promise: o,
        promise_control: s
    }
}

function tx(t) {
    return t[ta]
}

function sx(t) {
    t && (function(e) {
        return e[ta] !== void 0
    })(t) || Re(!1, "Promise is not controllable")
}
const nx = "__mono_message__",
    Md = ["debug", "log", "trace", "warn", "info", "error"],
    Wn = "MONO_WASM: ";
let ss, ji, Ss, Fr;

function ox(t) {
    Fr = t
}

function Mt(t) {
    if (L.diagnosticTracing) {
        const e = typeof t == "function" ? t() : t;
        console.debug(Wn + e)
    }
}

function Cd(t, ...e) {
    console.info(Wn + t, ...e)
}

function Td(t, ...e) {
    console.info(t, ...e)
}

function gn(t, ...e) {
    console.warn(Wn + t, ...e)
}

function pn(t, ...e) {
    if (e && e.length > 0 && e[0] && typeof e[0] == "object") {
        if (e[0].silent) return;
        if (e[0].toString) return void console.error(Wn + t, e[0].toString())
    }
    console.error(Wn + t, ...e)
}

function Id(t, e, s) {
    return function(...n) {
        try {
            let o = n[0];
            if (o === void 0) o = "undefined";
            else if (o === null) o = "null";
            else if (typeof o == "function") o = o.toString();
            else if (typeof o != "string") try {
                o = JSON.stringify(o)
            } catch (r) {
                o = o.toString()
            }
            e(s ? JSON.stringify({
                method: t,
                payload: o,
                arguments: n.slice(1)
            }) : [t + o, ...n.slice(1)])
        } catch (o) {
            Ss.error("proxyConsole failed: ".concat(o))
        }
    }
}

function Nd(t, e, s) {
    ji = e, Fr = t, Ss = F({}, e);
    const n = "".concat(s, "/console").replace("https://", "wss://").replace("http://", "ws://");
    ss = new WebSocket(n), ss.addEventListener("error", Pd), ss.addEventListener("close", Rd), (function() {
        for (const o of Md) ji[o] = Id("console.".concat(o), rx, !0)
    })()
}

function ll(t) {
    let e = 30;
    const s = () => {
        ss ? ss.bufferedAmount == 0 || e == 0 ? (t && Td(t), (function() {
            for (const n of Md) ji[n] = Id("console.".concat(n), Ss.log, !1)
        })(), ss.removeEventListener("error", Pd), ss.removeEventListener("close", Rd), ss.close(1e3, t), ss = void 0) : (e--, globalThis.setTimeout(s, 100)) : t && Ss && Ss.log(t)
    };
    s()
}

function rx(t) {
    ss && ss.readyState === WebSocket.OPEN ? ss.send(t) : Ss.log(t)
}

function Pd(t) {
    Ss.error("[".concat(Fr, "] proxy console websocket error: ").concat(t), t)
}

function Rd(t) {
    Ss.debug("[".concat(Fr, "] proxy console websocket closed: ").concat(t), t)
}
new Date().valueOf();
const $d = {},
    Mi = {},
    Ci = {};
let ar, ai, cl;

function ix() {
    const t = Object.values(Ci),
        e = Object.values(Mi),
        s = ul(t),
        n = ul(e),
        o = s + n;
    if (o === 0) return;
    const r = ns ? "%c" : "",
        i = ns ? ["background: purple; color: white; padding: 1px 3px; border-radius: 3px;", "font-weight: bold;", "font-weight: normal;"] : [],
        l = L.config.linkerEnabled ? "" : "\nThis application was built with linking (tree shaking) disabled. \nPublished applications will be significantly smaller if you install wasm-tools workload. \nSee also https://aka.ms/dotnet-wasm-features";
    console.groupCollapsed("".concat(r, "dotnet").concat(r, " Loaded ").concat(li(o), " resources").concat(r).concat(l), ...i), t.length && (console.groupCollapsed("Loaded ".concat(li(s), " resources from cache")), console.table(Ci), console.groupEnd()), e.length && (console.groupCollapsed("Loaded ".concat(li(n), " resources from network")), console.table(Mi), console.groupEnd()), console.groupEnd()
}
async function ax() {
    const t = ar;
    if (t) {
        const e = (await t.keys()).map((async s => {
            s.url in $d || await t.delete(s)
        }));
        await Promise.all(e)
    }
}

function dl(t) {
    return "".concat(t.resolvedUrl, ".").concat(t.hash)
}
async function Ad() {
    ar = await (async function(t) {
        if (!L.config.cacheBootResources || globalThis.caches === void 0 || globalThis.document === void 0 || globalThis.isSecureContext === !1) return null;
        const e = "dotnet-resources-".concat(globalThis.document.baseURI.substring(globalThis.document.location.origin.length));
        try {
            return await caches.open(e) || null
        } catch (s) {
            return null
        }
    })()
}

function ul(t) {
    return t.reduce(((e, s) => e + (s.responseBytes || 0)), 0)
}

function li(t) {
    return "".concat((t / 1048576).toFixed(2), " MB")
}

function Ld() {
    L.preferredIcuAsset = Dd(L.config);
    let t = L.config.globalizationMode == "invariant";
    if (!t)
        if (L.preferredIcuAsset) L.diagnosticTracing && Mt("ICU data archive(s) available, disabling invariant mode");
        else {
            if (L.config.globalizationMode === "custom" || L.config.globalizationMode === "all" || L.config.globalizationMode === "sharded") {
                const o = "invariant globalization mode is inactive and no ICU data archives are available";
                throw pn("ERROR: ".concat(o)), new Error(o)
            }
            L.diagnosticTracing && Mt("ICU data archive(s) not available, using invariant globalization mode"), t = !0, L.preferredIcuAsset = null
        }
    const e = "DOTNET_SYSTEM_GLOBALIZATION_INVARIANT",
        s = "DOTNET_SYSTEM_GLOBALIZATION_HYBRID",
        n = L.config.environmentVariables;
    if (n[s] === void 0 && L.config.globalizationMode === "hybrid" ? n[s] = "1" : n[e] === void 0 && t && (n[e] = "1"), n.TZ === void 0) try {
        const o = Intl.DateTimeFormat().resolvedOptions().timeZone || null;
        o && (n.TZ = o)
    } catch (o) {
        Cd("failed to detect timezone, will fallback to UTC")
    }
}

function Dd(t) {
    var e;
    if (!((e = t.resources) === null || e === void 0) && e.icu && t.globalizationMode != "invariant") {
        const s = t.applicationCulture || (ns ? globalThis.navigator && globalThis.navigator.languages && globalThis.navigator.languages[0] : Intl.DateTimeFormat().resolvedOptions().locale),
            n = Object.keys(t.resources.icu),
            o = {};
        for (let i = 0; i < n.length; i++) {
            const l = n[i];
            t.resources.fingerprinting ? o[Hd(l)] = l : o[l] = l
        }
        let r = null;
        if (t.globalizationMode === "custom") {
            if (n.length >= 1) return n[0]
        } else t.globalizationMode === "hybrid" ? r = "icudt_hybrid.dat" : s && t.globalizationMode !== "all" ? t.globalizationMode === "sharded" && (r = (function(i) {
            const l = i.split("-")[0];
            return l === "en" || ["fr", "fr-FR", "it", "it-IT", "de", "de-DE", "es", "es-ES"].includes(i) ? "icudt_EFIGS.dat" : ["zh", "ko", "ja"].includes(l) ? "icudt_CJK.dat" : "icudt_no_CJK.dat"
        })(s)) : r = "icudt.dat";
        if (r && o[r]) return o[r]
    }
    return t.globalizationMode = "invariant", null
}
const fl = class {
    constructor(t) {
        this.url = t
    }
    toString() {
        return this.url
    }
};
async function lx(t, e) {
    try {
        const s = typeof globalThis.fetch == "function";
        if (Ms) {
            const n = t.startsWith("file://");
            if (!n && s) return globalThis.fetch(t, e || {
                credentials: "same-origin"
            });
            ai || (cl = Cs.require("url"), ai = Cs.require("fs")), n && (t = cl.fileURLToPath(t));
            const o = await ai.promises.readFile(t);
            return {
                ok: !0,
                headers: {
                    length: 0,
                    get: () => null
                },
                url: t,
                arrayBuffer: () => o,
                json: () => JSON.parse(o),
                text: () => {
                    throw new Error("NotImplementedException")
                }
            }
        }
        if (s) return globalThis.fetch(t, e || {
            credentials: "same-origin"
        });
        if (typeof read == "function") return {
            ok: !0,
            url: t,
            headers: {
                length: 0,
                get: () => null
            },
            arrayBuffer: () => new Uint8Array(read(t, "binary")),
            json: () => JSON.parse(read(t, "utf8")),
            text: () => read(t, "utf8")
        }
    } catch (s) {
        return {
            ok: !1,
            url: t,
            status: 500,
            headers: {
                length: 0,
                get: () => null
            },
            statusText: "ERR28: " + s,
            arrayBuffer: () => {
                throw s
            },
            json: () => {
                throw s
            },
            text: () => {
                throw s
            }
        }
    }
    throw new Error("No fetch implementation available")
}

function Od(t) {
    return typeof t != "string" && Re(!1, "url must be a string"), !Fd(t) && t.indexOf("./") !== 0 && t.indexOf("../") !== 0 && globalThis.URL && globalThis.document && globalThis.document.baseURI && (t = new URL(t, globalThis.document.baseURI).toString()), t
}
const cx = /^[a-zA-Z][a-zA-Z\d+\-.]*?:\/\//,
    dx = /[a-zA-Z]:[\\/]/;

function Fd(t) {
    return Ms || Wr ? t.startsWith("/") || t.startsWith("\\") || t.indexOf("///") !== -1 || dx.test(t) : cx.test(t)
}
let tn, zo = 0;
const Cn = [],
    ps = [],
    Bd = new Map,
    sa = {
        "js-module-threads": !0,
        "js-module-globalization": !0,
        "js-module-runtime": !0,
        "js-module-dotnet": !0,
        "js-module-native": !0
    },
    na = ce(F({}, sa), {
        "js-module-library-initializer": !0
    }),
    Wd = ce(F({}, sa), {
        dotnetwasm: !0,
        heap: !0,
        manifest: !0
    }),
    ux = ce(F({}, na), {
        manifest: !0
    }),
    ml = ce(F({}, na), {
        dotnetwasm: !0
    }),
    Ti = {
        dotnetwasm: !0,
        symbols: !0,
        "segmentation-rules": !0
    },
    ci = ce(F({}, na), {
        dotnetwasm: !0,
        symbols: !0,
        "segmentation-rules": !0
    }),
    fx = {
        symbols: !0,
        "segmentation-rules": !0
    };

function Ho(t) {
    return !(t.behavior == "icu" && t.name != L.preferredIcuAsset)
}

function Uo(t, e, s) {
    const n = Object.keys(e || {});
    Re(n.length == 1, "Expect to have one ".concat(s, " asset in resources"));
    const o = n[0],
        r = {
            name: o,
            hash: e[o],
            behavior: s
        };
    return oa(r), t.push(r), r
}

function oa(t) {
    Wd[t.behavior] && Bd.set(t.behavior, t)
}

function zn(t) {
    const e = (function(s) {
        Re(Wd[s], "Unknown single asset behavior ".concat(s));
        const n = Bd.get(s);
        return Re(n, "Single asset for ".concat(s, " not found")), n
    })(t);
    if (!e.resolvedUrl) {
        if (e.resolvedUrl = L.locateFile(e.name), sa[e.behavior]) {
            const s = Ud(e);
            s ? (typeof s != "string" && Re(!1, "loadBootResource response for 'dotnetjs' type should be a URL string"), e.resolvedUrl = s) : e.resolvedUrl = Br(e.resolvedUrl, e.behavior)
        } else if (e.behavior !== "dotnetwasm") throw new Error("Unknown single asset behavior ".concat(t))
    }
    return e
}
let hl = !1;
async function lr() {
    if (!hl) {
        hl = !0, L.diagnosticTracing && Mt("mono_download_assets");
        try {
            const t = [],
                e = [],
                s = (i, l) => {
                    !ci[i.behavior] && Ho(i) && L.expected_instantiated_assets_count++, !ml[i.behavior] && Ho(i) && (L.expected_downloaded_assets_count++, l.push(ra(i)))
                };
            for (const i of Cn) s(i, t);
            for (const i of ps) s(i, e);
            L.allDownloadsQueued.promise_control.resolve(), Promise.all([...t, ...e]).then((() => {
                L.allDownloadsFinished.promise_control.resolve()
            })).catch((i => {
                throw L.err("Error in mono_download_assets: " + i), Ie(1, i), i
            })), await L.runtimeModuleLoaded.promise;
            const n = async i => {
                    const l = await i;
                    if (l.buffer) {
                        if (!ci[l.behavior]) {
                            l.buffer && typeof l.buffer == "object" || Re(!1, "asset buffer must be array-like or buffer-like or promise of these"), typeof l.resolvedUrl != "string" && Re(!1, "resolvedUrl must be string");
                            const c = l.resolvedUrl,
                                d = await l.buffer,
                                u = new Uint8Array(d);
                            ui(l), await ve.beforeOnRuntimeInitialized.promise, ve.instantiate_asset(l, c, u)
                        }
                    } else Ti[l.behavior] ? (l.behavior === "symbols" ? (await ve.instantiate_symbols_asset(l), ui(l)) : l.behavior === "segmentation-rules" && (await ve.instantiate_segmentation_rules_asset(l), ui(l)), Ti[l.behavior] && ++L.actual_downloaded_assets_count) : (l.isOptional || Re(!1, "Expected asset to have the downloaded buffer"), !ml[l.behavior] && Ho(l) && L.expected_downloaded_assets_count--, !ci[l.behavior] && Ho(l) && L.expected_instantiated_assets_count--)
                },
                o = [],
                r = [];
            for (const i of t) o.push(n(i));
            for (const i of e) r.push(n(i));
            Promise.all(o).then((() => {
                Rn || ve.coreAssetsInMemory.promise_control.resolve()
            })).catch((i => {
                throw L.err("Error in mono_download_assets: " + i), Ie(1, i), i
            })), Promise.all(r).then((async () => {
                Rn || (await ve.coreAssetsInMemory.promise, ve.allAssetsInMemory.promise_control.resolve())
            })).catch((i => {
                throw L.err("Error in mono_download_assets: " + i), Ie(1, i), i
            }))
        } catch (t) {
            throw L.err("Error in mono_download_assets: " + t), t
        }
    }
}
let gl = !1;

function zd() {
    if (gl) return;
    gl = !0;
    const t = L.config,
        e = [];
    if (t.assets)
        for (const s of t.assets) typeof s != "object" && Re(!1, "asset must be object, it was ".concat(typeof s, " : ").concat(s)), typeof s.behavior != "string" && Re(!1, "asset behavior must be known string"), typeof s.name != "string" && Re(!1, "asset name must be string"), s.resolvedUrl && typeof s.resolvedUrl != "string" && Re(!1, "asset resolvedUrl could be string"), s.hash && typeof s.hash != "string" && Re(!1, "asset resolvedUrl could be string"), s.pendingDownload && typeof s.pendingDownload != "object" && Re(!1, "asset pendingDownload could be object"), s.isCore ? Cn.push(s) : ps.push(s), oa(s);
    else if (t.resources) {
        const s = t.resources;
        s.wasmNative || Re(!1, "resources.wasmNative must be defined"), s.jsModuleNative || Re(!1, "resources.jsModuleNative must be defined"), s.jsModuleRuntime || Re(!1, "resources.jsModuleRuntime must be defined"), Uo(ps, s.wasmNative, "dotnetwasm"), Uo(e, s.jsModuleNative, "js-module-native"), Uo(e, s.jsModuleRuntime, "js-module-runtime"), t.globalizationMode == "hybrid" && Uo(e, s.jsModuleGlobalization, "js-module-globalization");
        const n = (r, i) => {
            !s.fingerprinting || r.behavior != "assembly" && r.behavior != "pdb" && r.behavior != "resource" || (r.virtualPath = Hd(r.name)), i ? (r.isCore = !0, Cn.push(r)) : ps.push(r)
        };
        if (s.coreAssembly)
            for (const r in s.coreAssembly) n({
                name: r,
                hash: s.coreAssembly[r],
                behavior: "assembly"
            }, !0);
        if (s.assembly)
            for (const r in s.assembly) n({
                name: r,
                hash: s.assembly[r],
                behavior: "assembly"
            }, !s.coreAssembly);
        if (t.debugLevel != 0) {
            if (s.corePdb)
                for (const r in s.corePdb) n({
                    name: r,
                    hash: s.corePdb[r],
                    behavior: "pdb"
                }, !0);
            if (s.pdb)
                for (const r in s.pdb) n({
                    name: r,
                    hash: s.pdb[r],
                    behavior: "pdb"
                }, !s.corePdb)
        }
        if (t.loadAllSatelliteResources && s.satelliteResources)
            for (const r in s.satelliteResources)
                for (const i in s.satelliteResources[r]) n({
                    name: i,
                    hash: s.satelliteResources[r][i],
                    behavior: "resource",
                    culture: r
                }, !s.coreAssembly);
        if (s.coreVfs)
            for (const r in s.coreVfs)
                for (const i in s.coreVfs[r]) n({
                    name: i,
                    hash: s.coreVfs[r][i],
                    behavior: "vfs",
                    virtualPath: r
                }, !0);
        if (s.vfs)
            for (const r in s.vfs)
                for (const i in s.vfs[r]) n({
                    name: i,
                    hash: s.vfs[r][i],
                    behavior: "vfs",
                    virtualPath: r
                }, !s.coreVfs);
        const o = Dd(t);
        if (o && s.icu)
            for (const r in s.icu) r === o ? ps.push({
                name: r,
                hash: s.icu[r],
                behavior: "icu",
                loadRemote: !0
            }) : r.startsWith("segmentation-rules") && r.endsWith(".json") && ps.push({
                name: r,
                hash: s.icu[r],
                behavior: "segmentation-rules"
            });
        if (s.wasmSymbols)
            for (const r in s.wasmSymbols) Cn.push({
                name: r,
                hash: s.wasmSymbols[r],
                behavior: "symbols"
            })
    }
    if (t.appsettings)
        for (let s = 0; s < t.appsettings.length; s++) {
            const n = t.appsettings[s],
                o = xx(n);
            o !== "appsettings.json" && o !== "appsettings.".concat(t.applicationEnvironment, ".json") || ps.push({
                name: n,
                behavior: "vfs",
                noCache: !0,
                useCredentials: !0
            })
        }
    t.assets = [...Cn, ...ps, ...e]
}

function Hd(t) {
    var e;
    const s = (e = L.config.resources) === null || e === void 0 ? void 0 : e.fingerprinting;
    return s && s[t] ? s[t] : t
}
async function mx(t) {
    const e = await ra(t);
    return await e.pendingDownloadInternal.response, e.buffer
}
async function ra(t) {
    try {
        return await di(t)
    } catch (e) {
        if (!L.enableDownloadRetry || Wr || Ms || t.pendingDownload && t.pendingDownloadInternal == t.pendingDownload || t.resolvedUrl && t.resolvedUrl.indexOf("file://") != -1 || e && e.status == 404) throw e;
        t.pendingDownloadInternal = void 0, await L.allDownloadsQueued.promise;
        try {
            return L.diagnosticTracing && Mt("Retrying download '".concat(t.name, "'")), await di(t)
        } catch (s) {
            return t.pendingDownloadInternal = void 0, await new Promise((n => globalThis.setTimeout(n, 100))), L.diagnosticTracing && Mt("Retrying download (2) '".concat(t.name, "' after delay")), await di(t)
        }
    }
}
async function di(t) {
    for (; tn;) await tn.promise;
    try {
        ++zo, zo == L.maxParallelDownloads && (L.diagnosticTracing && Mt("Throttling further parallel downloads"), tn = vs());
        const e = await (async function(s) {
            if (s.pendingDownload && (s.pendingDownloadInternal = s.pendingDownload), s.pendingDownloadInternal && s.pendingDownloadInternal.response) return s.pendingDownloadInternal.response;
            if (s.buffer) {
                const i = await s.buffer;
                return s.resolvedUrl || (s.resolvedUrl = "undefined://" + s.name), s.pendingDownloadInternal = {
                    url: s.resolvedUrl,
                    name: s.name,
                    response: Promise.resolve({
                        ok: !0,
                        arrayBuffer: () => i,
                        json: () => JSON.parse(new TextDecoder("utf-8").decode(i)),
                        text: () => {
                            throw new Error("NotImplementedException")
                        },
                        headers: {
                            get: () => {}
                        }
                    })
                }, s.pendingDownloadInternal.response
            }
            const n = s.loadRemote && L.config.remoteSources ? L.config.remoteSources : [""];
            let o;
            for (let i of n) {
                i = i.trim(), i === "./" && (i = "");
                const l = hx(s, i);
                s.name === l ? L.diagnosticTracing && Mt("Attempting to download '".concat(l, "'")) : L.diagnosticTracing && Mt("Attempting to download '".concat(l, "' for ").concat(s.name));
                try {
                    s.resolvedUrl = l;
                    const c = gx(s);
                    if (s.pendingDownloadInternal = c, o = await c.response, !o || !o.ok) continue;
                    return o
                } catch (c) {
                    o || (o = {
                        ok: !1,
                        url: l,
                        status: 0,
                        statusText: "" + c
                    });
                    continue
                }
            }
            const r = s.isOptional || s.name.match(/\.pdb$/) && L.config.ignorePdbLoadErrors;
            if (o || Re(!1, "Response undefined ".concat(s.name)), !r) {
                const i = new Error("download '".concat(o.url, "' for ").concat(s.name, " failed ").concat(o.status, " ").concat(o.statusText));
                throw i.status = o.status, i
            }
            Cd("optional download '".concat(o.url, "' for ").concat(s.name, " failed ").concat(o.status, " ").concat(o.statusText))
        })(t);
        return e && (Ti[t.behavior] || (t.buffer = await e.arrayBuffer(), ++L.actual_downloaded_assets_count)), t
    } finally {
        if (--zo, tn && zo == L.maxParallelDownloads - 1) {
            L.diagnosticTracing && Mt("Resuming more parallel downloads");
            const e = tn;
            tn = void 0, e.promise_control.resolve()
        }
    }
}

function hx(t, e) {
    let s;
    return e == null && Re(!1, "sourcePrefix must be provided for ".concat(t.name)), t.resolvedUrl ? s = t.resolvedUrl : (s = e === "" ? t.behavior === "assembly" || t.behavior === "pdb" ? t.name : t.behavior === "resource" && t.culture && t.culture !== "" ? "".concat(t.culture, "/").concat(t.name) : t.name : e + t.name, s = Br(L.locateFile(s), t.behavior)), s && typeof s == "string" || Re(!1, "attemptUrl need to be path or url string"), s
}

function Br(t, e) {
    return L.modulesUniqueQuery && ux[e] && (t += L.modulesUniqueQuery), t
}
let pl = 0;
const xl = new Set;

function gx(t) {
    try {
        t.resolvedUrl || Re(!1, "Request's resolvedUrl must be set");
        const e = (async function(n) {
                let o = await (async function(r) {
                    const i = ar;
                    if (!i || r.noCache || !r.hash || r.hash.length === 0) return;
                    const l = dl(r);
                    let c;
                    $d[l] = !0;
                    try {
                        c = await i.match(l)
                    } catch (u) {}
                    if (!c) return;
                    const d = parseInt(c.headers.get("content-length") || "0");
                    return Ci[r.name] = {
                        responseBytes: d
                    }, c
                })(n);
                return o || (o = await (function(r) {
                    let i = r.resolvedUrl;
                    if (L.loadBootResource) {
                        const c = Ud(r);
                        if (c instanceof Promise) return c;
                        typeof c == "string" && (i = c)
                    }
                    const l = {};
                    return L.config.disableNoCacheFetch || (l.cache = "no-cache"), r.useCredentials ? l.credentials = "include" : !L.config.disableIntegrityCheck && r.hash && (l.integrity = r.hash), L.fetch_like(i, l)
                })(n), (function(r, i) {
                    const l = ar;
                    if (!l || r.noCache || !r.hash || r.hash.length === 0) return;
                    const c = i.clone();
                    setTimeout((() => {
                        const d = dl(r);
                        (async function(u, f, h, m) {
                            const b = await m.arrayBuffer(),
                                y = (function(C) {
                                    if (typeof performance < "u") return performance.getEntriesByName(C)[0]
                                })(m.url),
                                p = y && y.encodedBodySize || void 0;
                            Mi[f] = {
                                responseBytes: p
                            };
                            const w = new Response(b, {
                                headers: {
                                    "content-type": m.headers.get("content-type") || "",
                                    "content-length": (p || m.headers.get("content-length") || "").toString()
                                }
                            });
                            try {
                                await u.put(h, w)
                            } catch (C) {}
                        })(l, r.name, d, c)
                    }), 0)
                })(n, o)), o
            })(t),
            s = {
                name: t.name,
                url: t.resolvedUrl,
                response: e
            };
        return xl.add(t.name), s.response.then((() => {
            t.behavior == "assembly" && L.loadedAssemblies.push(t.name), pl++, L.onDownloadResourceProgress && L.onDownloadResourceProgress(pl, xl.size)
        })), s
    } catch (e) {
        const s = {
            ok: !1,
            url: t.resolvedUrl,
            status: 500,
            statusText: "ERR29: " + e,
            arrayBuffer: () => {
                throw e
            },
            json: () => {
                throw e
            }
        };
        return {
            name: t.name,
            url: t.resolvedUrl,
            response: Promise.resolve(s)
        }
    }
}
const px = {
    resource: "assembly",
    assembly: "assembly",
    pdb: "pdb",
    icu: "globalization",
    vfs: "configuration",
    manifest: "manifest",
    dotnetwasm: "dotnetwasm",
    "js-module-dotnet": "dotnetjs",
    "js-module-native": "dotnetjs",
    "js-module-runtime": "dotnetjs",
    "js-module-threads": "dotnetjs"
};

function Ud(t) {
    var e;
    if (L.loadBootResource) {
        const s = (e = t.hash) !== null && e !== void 0 ? e : "",
            n = t.resolvedUrl,
            o = px[t.behavior];
        if (o) {
            const r = L.loadBootResource(o, t.name, n, s, t.behavior);
            return typeof r == "string" ? Od(r) : r
        }
    }
}

function ui(t) {
    t.pendingDownloadInternal = null, t.pendingDownload = null, t.buffer = null, t.moduleExports = null
}

function xx(t) {
    let e = t.lastIndexOf("/");
    return e >= 0 && e++, t.substring(e)
}
async function Gd(t) {
    if (!t) return;
    const e = Object.keys(t);
    await Promise.all(e.map((s => (async function(n) {
        try {
            const o = Br(L.locateFile(n), "js-module-library-initializer");
            L.diagnosticTracing && Mt("Attempting to import '".concat(o, "' for ").concat(n));
            const r = await
            import (o);
            L.libraryInitializers.push({
                scriptName: n,
                exports: r
            })
        } catch (o) {
            gn("Failed to import library initializer '".concat(n, "': ").concat(o))
        }
    })(s))))
}
async function cr(t, e) {
    if (!L.libraryInitializers) return;
    const s = [];
    for (let n = 0; n < L.libraryInitializers.length; n++) {
        const o = L.libraryInitializers[n];
        o.exports[t] && s.push(bx(o.scriptName, t, (() => o.exports[t](...e))))
    }
    await Promise.all(s)
}
async function bx(t, e, s) {
    try {
        await s()
    } catch (n) {
        throw gn("Failed to invoke '".concat(e, "' on library initializer '").concat(t, "': ").concat(n)), Ie(1, n), n
    }
}
var yx = "Release";

function wt(t, e) {
    if (t === e) return t;
    const s = F({}, e);
    return s.assets !== void 0 && s.assets !== t.assets && (s.assets = [...t.assets || [], ...s.assets || []]), s.resources !== void 0 && (s.resources = qd(t.resources || {
        assembly: {},
        jsModuleNative: {},
        jsModuleRuntime: {},
        wasmNative: {}
    }, s.resources)), s.environmentVariables !== void 0 && (s.environmentVariables = F(F({}, t.environmentVariables || {}), s.environmentVariables || {})), s.runtimeOptions !== void 0 && s.runtimeOptions !== t.runtimeOptions && (s.runtimeOptions = [...t.runtimeOptions || [], ...s.runtimeOptions || []]), Object.assign(t, s)
}

function Pn(t, e) {
    if (t === e) return t;
    const s = F({}, e);
    return s.config && (t.config || (t.config = {}), s.config = wt(t.config, s.config)), Object.assign(t, s)
}

function qd(t, e) {
    if (t === e) return t;
    const s = F({}, e);
    return s.assembly !== void 0 && (s.assembly = F(F({}, t.assembly || {}), s.assembly || {})), s.lazyAssembly !== void 0 && (s.lazyAssembly = F(F({}, t.lazyAssembly || {}), s.lazyAssembly || {})), s.pdb !== void 0 && (s.pdb = F(F({}, t.pdb || {}), s.pdb || {})), s.jsModuleWorker !== void 0 && (s.jsModuleWorker = F(F({}, t.jsModuleWorker || {}), s.jsModuleWorker || {})), s.jsModuleNative !== void 0 && (s.jsModuleNative = F(F({}, t.jsModuleNative || {}), s.jsModuleNative || {})), s.jsModuleGlobalization !== void 0 && (s.jsModuleGlobalization = F(F({}, t.jsModuleGlobalization || {}), s.jsModuleGlobalization || {})), s.jsModuleRuntime !== void 0 && (s.jsModuleRuntime = F(F({}, t.jsModuleRuntime || {}), s.jsModuleRuntime || {})), s.wasmSymbols !== void 0 && (s.wasmSymbols = F(F({}, t.wasmSymbols || {}), s.wasmSymbols || {})), s.wasmNative !== void 0 && (s.wasmNative = F(F({}, t.wasmNative || {}), s.wasmNative || {})), s.icu !== void 0 && (s.icu = F(F({}, t.icu || {}), s.icu || {})), s.satelliteResources !== void 0 && (s.satelliteResources = bl(t.satelliteResources || {}, s.satelliteResources || {})), s.modulesAfterConfigLoaded !== void 0 && (s.modulesAfterConfigLoaded = F(F({}, t.modulesAfterConfigLoaded || {}), s.modulesAfterConfigLoaded || {})), s.modulesAfterRuntimeReady !== void 0 && (s.modulesAfterRuntimeReady = F(F({}, t.modulesAfterRuntimeReady || {}), s.modulesAfterRuntimeReady || {})), s.extensions !== void 0 && (s.extensions = F(F({}, t.extensions || {}), s.extensions || {})), s.vfs !== void 0 && (s.vfs = bl(t.vfs || {}, s.vfs || {})), Object.assign(t, s)
}

function bl(t, e) {
    if (t === e) return t;
    for (const s in e) t[s] = F(F({}, t[s]), e[s]);
    return t
}

function er() {
    const t = L.config;
    if (t.environmentVariables = t.environmentVariables || {}, t.runtimeOptions = t.runtimeOptions || [], t.resources = t.resources || {
            assembly: {},
            jsModuleNative: {},
            jsModuleGlobalization: {},
            jsModuleWorker: {},
            jsModuleRuntime: {},
            wasmNative: {},
            vfs: {},
            satelliteResources: {}
        }, t.assets) {
        L.diagnosticTracing && Mt("config.assets is deprecated, use config.resources instead");
        for (const e of t.assets) {
            const s = {};
            s[e.name] = e.hash || "";
            const n = {};
            switch (e.behavior) {
                case "assembly":
                    n.assembly = s;
                    break;
                case "pdb":
                    n.pdb = s;
                    break;
                case "resource":
                    n.satelliteResources = {}, n.satelliteResources[e.culture] = s;
                    break;
                case "icu":
                    n.icu = s;
                    break;
                case "symbols":
                    n.wasmSymbols = s;
                    break;
                case "vfs":
                    n.vfs = {}, n.vfs[e.virtualPath] = s;
                    break;
                case "dotnetwasm":
                    n.wasmNative = s;
                    break;
                case "js-module-threads":
                    n.jsModuleWorker = s;
                    break;
                case "js-module-globalization":
                    n.jsModuleGlobalization = s;
                    break;
                case "js-module-runtime":
                    n.jsModuleRuntime = s;
                    break;
                case "js-module-native":
                    n.jsModuleNative = s;
                    break;
                case "js-module-dotnet":
                    break;
                default:
                    throw new Error("Unexpected behavior ".concat(e.behavior, " of asset ").concat(e.name))
            }
            qd(t.resources, n)
        }
    }
    t.debugLevel, t.cachedResourcesPurgeDelay === void 0 && (t.cachedResourcesPurgeDelay = 1e4), t.applicationCulture && (t.environmentVariables.LANG = "".concat(t.applicationCulture, ".UTF-8")), ve.diagnosticTracing = L.diagnosticTracing = !!t.diagnosticTracing, ve.waitForDebugger = t.waitForDebugger, ve.enablePerfMeasure = !!t.browserProfilerOptions && globalThis.performance && typeof globalThis.performance.measure == "function", L.maxParallelDownloads = t.maxParallelDownloads || L.maxParallelDownloads, L.enableDownloadRetry = t.enableDownloadRetry !== void 0 ? t.enableDownloadRetry : L.enableDownloadRetry
}
let yl = !1;
async function Vd(t) {
    var e;
    if (yl) return void await L.afterConfigLoaded.promise;
    let s;
    try {
        if (t.configSrc || L.config && Object.keys(L.config).length !== 0 && (L.config.assets || L.config.resources) || (t.configSrc = "./blazor.boot.json"), s = t.configSrc, yl = !0, s && (L.diagnosticTracing && Mt("mono_wasm_load_config"), await (async function(n) {
                const o = L.locateFile(n.configSrc),
                    r = L.loadBootResource !== void 0 ? L.loadBootResource("manifest", "blazor.boot.json", o, "", "manifest") : c(o);
                let i;
                i = r ? typeof r == "string" ? await c(Od(r)) : await r : await c(Br(o, "manifest"));
                const l = await (async function(d) {
                    const u = L.config,
                        f = await d.json();
                    u.applicationEnvironment || (f.applicationEnvironment = d.headers.get("Blazor-Environment") || d.headers.get("DotNet-Environment") || "Production"), f.environmentVariables || (f.environmentVariables = {});
                    const h = d.headers.get("DOTNET-MODIFIABLE-ASSEMBLIES");
                    h && (f.environmentVariables.DOTNET_MODIFIABLE_ASSEMBLIES = h);
                    const m = d.headers.get("ASPNETCORE-BROWSER-TOOLS");
                    return m && (f.environmentVariables.__ASPNETCORE_BROWSER_TOOLS = m), f
                })(i);

                function c(d) {
                    return L.fetch_like(d, {
                        method: "GET",
                        credentials: "include",
                        cache: "no-cache"
                    })
                }
                wt(L.config, l)
            })(t)), er(), await Gd((e = L.config.resources) === null || e === void 0 ? void 0 : e.modulesAfterConfigLoaded), await cr("onRuntimeConfigLoaded", [L.config]), t.onConfigLoaded) try {
            await t.onConfigLoaded(L.config, Hn), er()
        } catch (n) {
            throw pn("onConfigLoaded() failed", n), n
        }
        er(), L.afterConfigLoaded.promise_control.resolve(L.config)
    } catch (n) {
        const o = "Failed to load config file ".concat(s, " ").concat(n, " ").concat(n == null ? void 0 : n.stack);
        throw L.config = t.config = Object.assign(L.config, {
            message: o,
            error: n,
            isError: !0
        }), Ie(1, new Error(o)), n
    }
}
typeof importScripts != "function" || globalThis.onmessage || (globalThis.dotnetSidecar = !0);
const Ms = typeof process == "object" && typeof process.versions == "object" && typeof process.versions.node == "string",
    ia = typeof importScripts == "function",
    wx = ia && typeof dotnetSidecar < "u",
    Rn = ia && !wx,
    ns = typeof window == "object" || ia && !Ms,
    Wr = !ns && !Ms;
let ve = {},
    aa = {},
    L = {},
    Hn = {},
    Cs = {},
    wl = !1;
const rt = {},
    ot = {
        config: rt
    },
    xn = {
        mono: {},
        binding: {},
        internal: Cs,
        module: ot,
        loaderHelpers: L,
        runtimeHelpers: ve,
        globalizationHelpers: aa,
        api: Hn
    };

function Re(t, e) {
    if (t) return;
    const s = "Assert failed: " + (typeof e == "function" ? e() : e),
        n = new Error(s);
    pn(s, n), ve.nativeAbort(n)
}

function zr() {
    return L.exitCode !== void 0
}

function _x() {
    return ve.runtimeReady && !zr()
}

function vx() {
    zr() && Re(!1, ".NET runtime already exited with ".concat(L.exitCode, " ").concat(L.exitReason, ". You can use runtime.runMain() which doesn't exit the runtime.")), ve.runtimeReady || Re(!1, ".NET runtime didn't start yet. Please call dotnet.create() first.")
}

function Kd() {
    ns && (globalThis.addEventListener("unhandledrejection", Zd), globalThis.addEventListener("error", Jd))
}
let dr, ur;

function Xd(t) {
    ur && ur(t), Ie(t, L.exitReason)
}

function Yd(t) {
    dr && dr(t || L.exitReason), Ie(1, t || L.exitReason)
}

function Ie(t, e) {
    var s, n;
    const o = e && typeof e == "object";
    t = o && typeof e.status == "number" ? e.status : t === void 0 ? -1 : t;
    const r = o && typeof e.message == "string" ? e.message : "" + e;
    (e = o ? e : ve.ExitStatus ? (function(c, d) {
        const u = new ve.ExitStatus(c);
        return u.message = d, u.toString = () => d, u
    })(t, r) : new Error("Exit with code " + t + " " + r)).status = t, e.message || (e.message = r);
    const i = "" + (e.stack || new Error().stack);
    try {
        Object.defineProperty(e, "stack", {
            get: () => i
        })
    } catch (c) {}
    const l = !!e.silent;
    if (e.silent = !0, zr()) L.diagnosticTracing && Mt("mono_exit called after exit");
    else {
        try {
            ot.onAbort == Yd && (ot.onAbort = dr), ot.onExit == Xd && (ot.onExit = ur), ns && (globalThis.removeEventListener("unhandledrejection", Zd), globalThis.removeEventListener("error", Jd)), ve.runtimeReady ? (ve.jiterpreter_dump_stats && ve.jiterpreter_dump_stats(!1), t === 0 && (!((s = L.config) === null || s === void 0) && s.interopCleanupOnExit) && ve.forceDisposeProxies(!0, !0), J1 && t !== 0 && ((n = L.config) === null || n === void 0 || n.dumpThreadsOnNonZeroExit)) : (L.diagnosticTracing && Mt("abort_startup, reason: ".concat(e)), (function(c) {
                L.allDownloadsQueued.promise_control.reject(c), L.allDownloadsFinished.promise_control.reject(c), L.afterConfigLoaded.promise_control.reject(c), L.wasmCompilePromise.promise_control.reject(c), L.runtimeModuleLoaded.promise_control.reject(c), ve.dotnetReady && (ve.dotnetReady.promise_control.reject(c), ve.afterInstantiateWasm.promise_control.reject(c), ve.beforePreInit.promise_control.reject(c), ve.afterPreInit.promise_control.reject(c), ve.afterPreRun.promise_control.reject(c), ve.beforeOnRuntimeInitialized.promise_control.reject(c), ve.afterOnRuntimeInitialized.promise_control.reject(c), ve.afterPostRun.promise_control.reject(c))
            })(e))
        } catch (c) {
            gn("mono_exit A failed", c)
        }
        try {
            l || ((function(c, d) {
                if (c !== 0 && d) {
                    const u = ve.ExitStatus && d instanceof ve.ExitStatus ? Mt : pn;
                    typeof d == "string" ? u(d) : (d.stack === void 0 && (d.stack = new Error().stack + ""), d.message ? u(ve.stringify_as_error_with_stack ? ve.stringify_as_error_with_stack(d.message + "\n" + d.stack) : d.message + "\n" + d.stack) : u(JSON.stringify(d)))
                }!Rn && L.config && (L.config.logExitCode ? L.config.forwardConsoleLogsToWS ? ll("WASM EXIT " + c) : Td("WASM EXIT " + c) : L.config.forwardConsoleLogsToWS && ll())
            })(t, e), (function(c) {
                if (ns && !Rn && L.config && L.config.appendElementOnExit && document) {
                    const d = document.createElement("label");
                    d.id = "tests_done", c !== 0 && (d.style.background = "red"), d.innerHTML = "" + c, document.body.appendChild(d)
                }
            })(t))
        } catch (c) {
            gn("mono_exit B failed", c)
        }
        L.exitCode = t, L.exitReason || (L.exitReason = e), !Rn && ve.runtimeReady && ot.runtimeKeepalivePop()
    }
    if (L.config && L.config.asyncFlushOnExit && t === 0) throw (async () => {
        try {
            await (async function() {
                try {
                    const c = await Es(() =>
                            import ("./peoqhwtrjqotgzjw.js").then(b => b.b), __vite__mapDeps([4, 1])),
                        d = b => new Promise(((y, p) => {
                            b.on("error", p), b.end("", "utf8", y)
                        })),
                        u = d(c.stderr),
                        f = d(c.stdout);
                    let h;
                    const m = new Promise((b => {
                        h = setTimeout((() => b("timeout")), 1e3)
                    }));
                    await Promise.race([Promise.all([f, u]), m]), clearTimeout(h)
                } catch (c) {
                    pn("flushing std* streams failed: ".concat(c))
                }
            })()
        } finally {
            _l(t, e)
        }
    })(), e;
    _l(t, e)
}

function _l(t, e) {
    if (ve.runtimeReady && ve.nativeExit) try {
        ve.nativeExit(t)
    } catch (s) {
        !ve.ExitStatus || s instanceof ve.ExitStatus || gn("set_exit_code_and_quit_now failed: " + s.toString())
    }
    if (t !== 0 || !ns) throw Ms && Cs.process ? Cs.process.exit(t) : ve.quit && ve.quit(t, e), e
}

function Zd(t) {
    Qd(t, t.reason, "rejection")
}

function Jd(t) {
    Qd(t, t.error, "error")
}

function Qd(t, e, s) {
    t.preventDefault();
    try {
        e || (e = new Error("Unhandled " + s)), e.stack === void 0 && (e.stack = new Error().stack), e.stack = e.stack + "", e.silent || (pn("Unhandled error:", e), Ie(1, e))
    } catch (n) {}
}(function(t) {
    if (wl) throw new Error("Loader module already loaded");
    wl = !0, ve = t.runtimeHelpers, aa = t.globalizationHelpers, L = t.loaderHelpers, Hn = t.api, Cs = t.internal, Object.assign(Hn, {
        INTERNAL: Cs,
        invokeLibraryInitializers: cr
    }), Object.assign(t.module, {
        config: wt(rt, {
            environmentVariables: {}
        })
    });
    const e = {
            mono_wasm_bindings_is_ready: !1,
            config: t.module.config,
            diagnosticTracing: !1,
            nativeAbort: n => {
                throw n || new Error("abort")
            },
            nativeExit: n => {
                throw new Error("exit:" + n)
            }
        },
        s = {
            gitHash: "fa7cdded37981a97cec9a3e233c4a6af58a91c57",
            config: t.module.config,
            diagnosticTracing: !1,
            maxParallelDownloads: 16,
            enableDownloadRetry: !0,
            _loaded_files: [],
            loadedFiles: [],
            loadedAssemblies: [],
            libraryInitializers: [],
            workerNextNumber: 1,
            actual_downloaded_assets_count: 0,
            actual_instantiated_assets_count: 0,
            expected_downloaded_assets_count: 0,
            expected_instantiated_assets_count: 0,
            afterConfigLoaded: vs(),
            allDownloadsQueued: vs(),
            allDownloadsFinished: vs(),
            wasmCompilePromise: vs(),
            runtimeModuleLoaded: vs(),
            loadingWorkers: vs(),
            is_exited: zr,
            is_runtime_running: _x,
            assert_runtime_running: vx,
            mono_exit: Ie,
            createPromiseController: vs,
            getPromiseController: tx,
            assertIsControllablePromise: sx,
            mono_download_assets: lr,
            resolve_single_asset_path: zn,
            setup_proxy_console: Nd,
            set_thread_prefix: ox,
            logDownloadStatsToConsole: ix,
            purgeUnusedCacheEntriesAsync: ax,
            installUnhandledErrorHandler: Kd,
            retrieve_asset_download: mx,
            invokeLibraryInitializers: cr,
            exceptions: Q1,
            simd: ex
        };
    Object.assign(ve, e), Object.assign(L, s)
})(xn);
let Go, qo, vl = !1,
    kl = !1;
async function eu(t) {
    if (!kl) {
        if (kl = !0, ns && L.config.forwardConsoleLogsToWS && globalThis.WebSocket !== void 0 && Nd("main", globalThis.console, globalThis.location.origin), ot || Re(!1, "Null moduleConfig"), L.config || Re(!1, "Null moduleConfig.config"), typeof t == "function") {
            const e = t(xn.api);
            if (e.ready) throw new Error("Module.ready couldn't be redefined.");
            Object.assign(ot, e), Pn(ot, e)
        } else {
            if (typeof t != "object") throw new Error("Can't use moduleFactory callback of createDotnetRuntime function.");
            Pn(ot, t)
        }
        await (async function(e) {
            if (Ms) {
                const r = await Es(() =>
                        import ("./peoqhwtrjqotgzjw.js").then(l => l.b), __vite__mapDeps([4, 1])),
                    i = 14;
                if (r.versions.node.split(".")[0] < i) throw new Error("NodeJS at '".concat(r.execPath, "' has too low version '").concat(r.versions.node, "', please use at least ").concat(i, ". See also https://aka.ms/dotnet-wasm-features"))
            }
            const s =
                import.meta.url,
                n = s.indexOf("?");
            var o;
            if (n > 0 && (L.modulesUniqueQuery = s.substring(n)), L.scriptUrl = s.replace(/\\/g, "/").replace(/[?#].*/, ""), L.scriptDirectory = (o = L.scriptUrl).slice(0, o.lastIndexOf("/")) + "/", L.locateFile = r => "URL" in globalThis && globalThis.URL !== fl ? new URL(r, L.scriptDirectory).toString() : Fd(r) ? r : L.scriptDirectory + r, L.fetch_like = lx, L.out = console.log, L.err = console.error, L.onDownloadResourceProgress = e.onDownloadResourceProgress, ns && globalThis.navigator) {
                const r = globalThis.navigator,
                    i = r.userAgentData && r.userAgentData.brands;
                i && i.length > 0 ? L.isChromium = i.some((l => l.brand === "Google Chrome" || l.brand === "Microsoft Edge" || l.brand === "Chromium")) : r.userAgent && (L.isChromium = r.userAgent.includes("Chrome"), L.isFirefox = r.userAgent.includes("Firefox"))
            }
            Cs.require = Ms ? await Es(() =>
                import ("./dykg4ktvbu3mhmdo.js").then(r => r.CG), __vite__mapDeps([2, 1, 3])).then((r => r.createRequire(
                import.meta.url))) : Promise.resolve((() => {
                throw new Error("require not supported")
            })), globalThis.URL === void 0 && (globalThis.URL = fl)
        })(ot)
    }
}
async function kx(t) {
    return await eu(t), dr = ot.onAbort, ur = ot.onExit, ot.onAbort = Yd, ot.onExit = Xd, ot.ENVIRONMENT_IS_PTHREAD ? (async function() {
        (function() {
            const n = new MessageChannel,
                o = n.port1,
                r = n.port2;
            o.addEventListener("message", (i => {
                var l, c;
                l = JSON.parse(i.data.config), c = JSON.parse(i.data.monoThreadInfo), vl ? L.diagnosticTracing && Mt("mono config already received") : (wt(L.config, l), ve.monoThreadInfo = c, er(), L.diagnosticTracing && Mt("mono config received"), vl = !0, L.afterConfigLoaded.promise_control.resolve(L.config), ns && l.forwardConsoleLogsToWS && globalThis.WebSocket !== void 0 && L.setup_proxy_console("worker-idle", console, globalThis.location.origin)), o.close(), r.close()
            }), {
                once: !0
            }), o.start(), self.postMessage({
                [nx]: {
                    monoCmd: "preload",
                    port: r
                }
            }, [r])
        })(), await L.afterConfigLoaded.promise, (function() {
            const n = L.config;
            n.assets || Re(!1, "config.assets must be defined");
            for (const o of n.assets) oa(o), fx[o.behavior] && ps.push(o)
        })(), setTimeout((async () => {
            try {
                await lr()
            } catch (n) {
                Ie(1, n)
            }
        }), 0);
        const e = Sl(),
            s = await Promise.all(e);
        return await El(s), ot
    })() : (async function() {
        var e;
        await Vd(ot), zd();
        const s = Sl();
        await Ad(), (async function() {
            try {
                const o = zn("dotnetwasm");
                await ra(o), o && o.pendingDownloadInternal && o.pendingDownloadInternal.response || Re(!1, "Can't load dotnet.native.wasm");
                const r = await o.pendingDownloadInternal.response,
                    i = r.headers && r.headers.get ? r.headers.get("Content-Type") : void 0;
                let l;
                if (typeof WebAssembly.compileStreaming == "function" && i === "application/wasm") l = await WebAssembly.compileStreaming(r);
                else {
                    ns && i !== "application/wasm" && gn('WebAssembly resource does not have the expected content type "application/wasm", so falling back to slower ArrayBuffer instantiation.');
                    const c = await r.arrayBuffer();
                    L.diagnosticTracing && Mt("instantiate_wasm_module buffered"), l = Wr ? await Promise.resolve(new WebAssembly.Module(c)) : await WebAssembly.compile(c)
                }
                o.pendingDownloadInternal = null, o.pendingDownload = null, o.buffer = null, o.moduleExports = null, L.wasmCompilePromise.promise_control.resolve(l)
            } catch (o) {
                L.wasmCompilePromise.promise_control.reject(o)
            }
        })(), setTimeout((async () => {
            try {
                Ld(), await lr()
            } catch (o) {
                Ie(1, o)
            }
        }), 0);
        const n = await Promise.all(s);
        return await El(n), await ve.dotnetReady.promise, await Gd((e = L.config.resources) === null || e === void 0 ? void 0 : e.modulesAfterRuntimeReady), await cr("onRuntimeReady", [xn.api]), Hn
    })()
}

function Sl() {
    const t = zn("js-module-runtime"),
        e = zn("js-module-native");
    return Go && qo || (typeof t.moduleExports == "object" ? Go = t.moduleExports : (L.diagnosticTracing && Mt("Attempting to import '".concat(t.resolvedUrl, "' for ").concat(t.name)), Go =
        import (t.resolvedUrl)), typeof e.moduleExports == "object" ? qo = e.moduleExports : (L.diagnosticTracing && Mt("Attempting to import '".concat(e.resolvedUrl, "' for ").concat(e.name)), qo =
        import (e.resolvedUrl))), [Go, qo]
}
async function El(t) {
    const {
        initializeExports: e,
        initializeReplacements: s,
        configureRuntimeStartup: n,
        configureEmscriptenStartup: o,
        configureWorkerStartup: r,
        setRuntimeGlobals: i,
        passEmscriptenInternals: l
    } = t[0], {
        default: c
    } = t[1];
    if (i(xn), e(xn), L.config.globalizationMode === "hybrid") {
        const d = await (async function() {
                let f;
                const h = zn("js-module-globalization");
                return typeof h.moduleExports == "object" ? f = h.moduleExports : (Mt("Attempting to import '".concat(h.resolvedUrl, "' for ").concat(h.name)), f =
                    import (h.resolvedUrl)), await f
            })(),
            {
                initHybrid: u
            } = d;
        u(aa, ve)
    }
    await n(ot), L.runtimeModuleLoaded.promise_control.resolve(), c((d => (Object.assign(ot, {
        ready: d.ready,
        __dotnet_runtime: {
            initializeReplacements: s,
            configureEmscriptenStartup: o,
            configureWorkerStartup: r,
            passEmscriptenInternals: l
        }
    }), ot))).catch((d => {
        throw d.message && d.message.toLowerCase().includes("out of memory") ? new Error(".NET runtime has failed to start, because too much memory was requested. Please decrease the memory by adjusting EmccMaximumHeapSize. See also https://aka.ms/dotnet-wasm-features") : d
    }))
}
const Sx = new class {
    withModuleConfig(t) {
        try {
            return Pn(ot, t), this
        } catch (e) {
            throw Ie(1, e), e
        }
    }
    withOnConfigLoaded(t) {
        try {
            return Pn(ot, {
                onConfigLoaded: t
            }), this
        } catch (e) {
            throw Ie(1, e), e
        }
    }
    withConsoleForwarding() {
        try {
            return wt(rt, {
                forwardConsoleLogsToWS: !0
            }), this
        } catch (t) {
            throw Ie(1, t), t
        }
    }
    withExitOnUnhandledError() {
        try {
            return wt(rt, {
                exitOnUnhandledError: !0
            }), Kd(), this
        } catch (t) {
            throw Ie(1, t), t
        }
    }
    withAsyncFlushOnExit() {
        try {
            return wt(rt, {
                asyncFlushOnExit: !0
            }), this
        } catch (t) {
            throw Ie(1, t), t
        }
    }
    withExitCodeLogging() {
        try {
            return wt(rt, {
                logExitCode: !0
            }), this
        } catch (t) {
            throw Ie(1, t), t
        }
    }
    withElementOnExit() {
        try {
            return wt(rt, {
                appendElementOnExit: !0
            }), this
        } catch (t) {
            throw Ie(1, t), t
        }
    }
    withInteropCleanupOnExit() {
        try {
            return wt(rt, {
                interopCleanupOnExit: !0
            }), this
        } catch (t) {
            throw Ie(1, t), t
        }
    }
    withDumpThreadsOnNonZeroExit() {
        try {
            return wt(rt, {
                dumpThreadsOnNonZeroExit: !0
            }), this
        } catch (t) {
            throw Ie(1, t), t
        }
    }
    withWaitingForDebugger(t) {
        try {
            return wt(rt, {
                waitForDebugger: t
            }), this
        } catch (e) {
            throw Ie(1, e), e
        }
    }
    withInterpreterPgo(t, e) {
        try {
            return wt(rt, {
                interpreterPgo: t,
                interpreterPgoSaveDelay: e
            }), rt.runtimeOptions ? rt.runtimeOptions.push("--interp-pgo-recording") : rt.runtimeOptions = ["--interp-pgo-recording"], this
        } catch (s) {
            throw Ie(1, s), s
        }
    }
    withConfig(t) {
        try {
            return wt(rt, t), this
        } catch (e) {
            throw Ie(1, e), e
        }
    }
    withConfigSrc(t) {
        try {
            return t && typeof t == "string" || Re(!1, "must be file path or URL"), Pn(ot, {
                configSrc: t
            }), this
        } catch (e) {
            throw Ie(1, e), e
        }
    }
    withVirtualWorkingDirectory(t) {
        try {
            return t && typeof t == "string" || Re(!1, "must be directory path"), wt(rt, {
                virtualWorkingDirectory: t
            }), this
        } catch (e) {
            throw Ie(1, e), e
        }
    }
    withEnvironmentVariable(t, e) {
        try {
            const s = {};
            return s[t] = e, wt(rt, {
                environmentVariables: s
            }), this
        } catch (s) {
            throw Ie(1, s), s
        }
    }
    withEnvironmentVariables(t) {
        try {
            return t && typeof t == "object" || Re(!1, "must be dictionary object"), wt(rt, {
                environmentVariables: t
            }), this
        } catch (e) {
            throw Ie(1, e), e
        }
    }
    withDiagnosticTracing(t) {
        try {
            return typeof t != "boolean" && Re(!1, "must be boolean"), wt(rt, {
                diagnosticTracing: t
            }), this
        } catch (e) {
            throw Ie(1, e), e
        }
    }
    withDebugging(t) {
        try {
            return t != null && typeof t == "number" || Re(!1, "must be number"), wt(rt, {
                debugLevel: t
            }), this
        } catch (e) {
            throw Ie(1, e), e
        }
    }
    withApplicationArguments(...t) {
        try {
            return t && Array.isArray(t) || Re(!1, "must be array of strings"), wt(rt, {
                applicationArguments: t
            }), this
        } catch (e) {
            throw Ie(1, e), e
        }
    }
    withRuntimeOptions(t) {
        try {
            return t && Array.isArray(t) || Re(!1, "must be array of strings"), rt.runtimeOptions ? rt.runtimeOptions.push(...t) : rt.runtimeOptions = t, this
        } catch (e) {
            throw Ie(1, e), e
        }
    }
    withMainAssembly(t) {
        try {
            return wt(rt, {
                mainAssemblyName: t
            }), this
        } catch (e) {
            throw Ie(1, e), e
        }
    }
    withApplicationArgumentsFromQuery() {
        try {
            if (!globalThis.window) throw new Error("Missing window to the query parameters from");
            if (globalThis.URLSearchParams === void 0) throw new Error("URLSearchParams is supported");
            const t = new URLSearchParams(globalThis.window.location.search).getAll("arg");
            return this.withApplicationArguments(...t)
        } catch (t) {
            throw Ie(1, t), t
        }
    }
    withApplicationEnvironment(t) {
        try {
            return wt(rt, {
                applicationEnvironment: t
            }), this
        } catch (e) {
            throw Ie(1, e), e
        }
    }
    withApplicationCulture(t) {
        try {
            return wt(rt, {
                applicationCulture: t
            }), this
        } catch (e) {
            throw Ie(1, e), e
        }
    }
    withResourceLoader(t) {
        try {
            return L.loadBootResource = t, this
        } catch (e) {
            throw Ie(1, e), e
        }
    }
    async download() {
        try {
            await (async function() {
                eu(ot), await Vd(ot), zd(), await Ad(), Ld(), lr(), await L.allDownloadsFinished.promise
            })()
        } catch (t) {
            throw Ie(1, t), t
        }
    }
    async create() {
        try {
            return this.instance || (this.instance = await (async function() {
                return await kx(ot), xn.api
            })()), this.instance
        } catch (t) {
            throw Ie(1, t), t
        }
    }
    async run() {
        try {
            return ot.config || Re(!1, "Null moduleConfig.config"), this.instance || await this.create(), this.instance.runMainAndExit()
        } catch (t) {
            throw Ie(1, t), t
        }
    }
};
Wr || typeof globalThis.URL == "function" || Re(!1, "This browser/engine doesn't support URL API. Please use a modern version. See also https://aka.ms/dotnet-wasm-features"), typeof globalThis.BigInt64Array != "function" && Re(!1, "This browser/engine doesn't support BigInt64Array API. Please use a modern version. See also https://aka.ms/dotnet-wasm-features");
let Vo = null;
async function Ex() {
    const t = await Sx.withConfig(Z1).withResourceLoader((s, n, o, r) => s === "dotnetjs" ? o : new URL(o, location.href).origin !== location.origin ? fetch(o, {
            credentials: "omit",
            integrity: r
        }) : o).create(),
        e = t.getConfig().mainAssemblyName;
    return e ? t.getAssemblyExports(e) : null
}
const jx = () => (Vo != null || (Vo = Ex()), Vo);

function Mx(t) {
    "use forget";
    const e = xe.c(2),
        s = t === void 0 ? !0 : t;
    let n;
    return e[0] !== s ? (n = s ? jx() : Promise.resolve(null), e[0] = s, e[1] = n) : n = e[1], n
}
const Cx = Kn(() => Es(() =>
        import ("./octb28fiwkwdqaay.js"), __vite__mapDeps([5, 1, 6, 2, 3, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17])).then(t => t.WalnutMiniPlayer)),
    Tx = ["group my-4 w-full rounded-2xl corner-superellipse/1.1 relative z-0", "bg-token-bg-primary", "dark:bg-[#2a2a2a]", "shadow-[0px_0px_0px_1px_rgba(0,0,0,0.08),0px_2px_2px_rgba(0,0,0,0.08),0px_4px_80px_rgba(0,0,0,0.03)]", "dark:shadow-[0px_0px_0px_1px_rgba(255,255,255,0.12),0px_2px_2px_rgba(0,0,0,0.2)]"].join(" "),
    Ix = t => {
        "use forget";
        var Be, st, ht, St, Tt, bt, We, Et, $t;
        const e = xe.c(113),
            {
                citation: s,
                conversation: n,
                messageId: o,
                showWorksheetTabs: r,
                showFileName: i,
                isSandboxDownload: l,
                sandboxOverrides: c,
                isResponsiveSheet: d,
                responsiveSheetHeight: u,
                onPreviewTriggered: f
            } = t,
            h = r === void 0 ? !1 : r,
            m = i === void 0 ? !1 : i,
            b = l === void 0 ? !1 : l,
            y = d === void 0 ? !1 : d,
            [p, w] = x.useState(!1),
            [C, v] = x.useState(null),
            [g, k] = x.useState(!1),
            E = !!((st = (Be = x.useContext(js)) == null ? void 0 : Be.message.metadata) != null && st.is_standalone_share_attachment),
            j = wf(),
            {
                presentationMap: M,
                updatePresentationMap: T,
                open: N
            } = Pg(),
            I = et();
        let _;
        e[0] !== n.id ? (_ = Xn(n.id), e[0] = n.id, e[1] = _) : _ = e[1];
        const R = _;
        let A;
        e[2] !== I || e[3] !== b || e[4] !== R ? (A = !b && at(I, "3154019201") && !!R, e[2] = I, e[3] = b, e[4] = R, e[5] = A) : A = e[5];
        const $ = A;
        let P;
        e[6] !== I ? (P = at(I, "638971034"), e[6] = I, e[7] = P) : P = e[7];
        const U = P,
            z = Mx(!U);
        let B;
        e[8] !== I ? (B = at(I, "2400755524"), e[8] = I, e[9] = B) : B = e[9];
        const G = B;
        let O;
        e[10] !== I ? (O = _f(I, "2888003541"), e[10] = I, e[11] = O) : O = e[11];
        const H = O.value,
            S = Number((ht = H == null ? void 0 : H.max_bytes) != null ? ht : 3e7),
            V = ys(),
            J = x.useRef(null),
            q = x.useRef(!1);
        let Z, D;
        e[12] !== s.file_name ? (Z = () => {
            if (q.current) return;
            const nt = Wo(s.file_name);
            Xe.logEvent("Walnut Preview Mounted", {
                extension: nt
            }), q.current = !0
        }, D = [s.file_name], e[12] = s.file_name, e[13] = Z, e[14] = D) : (Z = e[13], D = e[14]), x.useEffect(Z, D);
        let te;
        e[15] !== V ? (te = nt => {
            V.danger(nt, {
                toastId: "w_failed_to_download_file"
            })
        }, e[15] = V, e[16] = te) : te = e[16];
        const se = te,
            re = !!s.file_id,
            X = qi(!1, n.id, s.file_id, Px, se),
            he = (St = M[s.file_id]) == null ? void 0 : St.presentation,
            K = (Tt = M[s.file_id]) == null ? void 0 : Tt.workbook;
        let oe;
        e[17] !== s.file_name ? (oe = Wo(s.file_name), e[17] = s.file_name, e[18] = oe) : oe = e[18];
        const ye = oe,
            ke = ye === "pptx",
            ie = ye === "xlsx";
        let ee;
        e[19] !== X || e[20] !== s.file_name || e[21] !== n.id || e[22] !== V ? (ee = async nt => {
            const Dt = Wo(s.file_name);
            if (Xe.logEvent("Walnut Download Click", {
                    extension: Dt
                }), n.id !== void 0) {
                nt.preventDefault();
                const {
                    data: jt
                } = await X.refetch();
                if (jt === void 0 || (jt == null ? void 0 : jt.status) !== "success") {
                    V.danger("Failed to download file");
                    return
                }
                const At = document.createElement("a");
                At.href = jt.download_url, At.click()
            }
        }, e[19] = X, e[20] = s.file_name, e[21] = n.id, e[22] = V, e[23] = ee) : ee = e[23];
        const fe = ee,
            {
                refetch: Se
            } = X,
            je = Er();
        let Te, Ye;
        e[24] !== s.file_id || e[25] !== s.file_name || e[26] !== ye || e[27] !== j || e[28] !== b || e[29] !== je || e[30] !== S || e[31] !== N || e[32] !== z || e[33] !== Se || e[34] !== U || e[35] !== V || e[36] !== G || e[37] !== T ? (Te = () => {
            var qt;
            if (b) return;
            (qt = J.current) == null || qt.abort();
            const nt = new AbortController;
            J.current = nt;
            let Dt = !1,
                jt = !1;
            return (async () => {
                w(!0), k(!1), v(null);
                const {
                    data: qe
                } = await Se();
                if (qe === void 0 || (qe == null ? void 0 : qe.status) !== "success" || !qe.download_url) {
                    V.danger("Failed to download file");
                    return
                }
                const Zt = await fetch(qe.download_url, {
                    headers: je ? {} : Oi(),
                    signal: nt.signal
                });
                if (!Zt.ok) {
                    ts.addError(new Error("Walnut file download HTTP ".concat(Zt.status)), {
                        file_id: s.file_id
                    }), k(!0);
                    return
                }
                const ne = await Zt.blob();
                if (S !== 0 && ne.size > S) {
                    k(!0), v("fileTooLarge"), jt = !0;
                    return
                }
                const le = new Uint8Array(await ne.arrayBuffer()),
                    Pe = ye != null ? ye : "pptx",
                    Ee = ne.size;
                if (Pe === "pptx") {
                    let Qe;
                    if (U) {
                        const Jt = performance.now();
                        Qe = await al(le, Pe);
                        const os = performance.now() - Jt;
                        ts.addAction("walnut_pptx_import_time_ms", {
                            extension: "pptx",
                            duration_ms: Math.round(os),
                            file_size_bytes: Ee
                        })
                    } else {
                        const Jt = await z;
                        if (!Jt) return;
                        Qe = Jt.PptxReader.ExtractSlidesProto(le, !1)
                    }
                    if (!Qe) return;
                    const Lt = Ig.decode(Qe);
                    T(s.file_id, {
                        fileBlob: ne,
                        fileName: s.file_name,
                        presentation: Lt,
                        workbook: null,
                        document: null,
                        selectedSlideIdx: 0,
                        selectedSheetIdx: 0
                    }), Xe.logEvent("Walnut Preview Loaded", {
                        extension: "pptx"
                    });
                    return
                }
                let Ce;
                if (U) {
                    const Qe = performance.now();
                    Ce = await al(le, Pe);
                    const Lt = performance.now() - Qe;
                    if (ts.addAction("walnut_xlsx_import_time_ms", {
                            extension: "xlsx",
                            duration_ms: Math.round(Lt),
                            file_size_bytes: Ee
                        }), Ce) {
                        const Jt = performance.now();
                        try {
                            Ce = await G1(Ce, G);
                            const os = performance.now() - Jt;
                            ts.addAction("walnut_xlsx_recalculate_time_ms", {
                                extension: "xlsx",
                                duration_ms: Math.round(os),
                                file_size_bytes: Ee
                            })
                        } catch (os) {
                            const ms = os;
                            ts.addError(ms, {
                                file_id: s.file_id
                            })
                        }
                    }
                } else {
                    const Qe = await z;
                    if (!Qe) return;
                    Ce = Qe.XlsxReader.ExtractXlsxProto(le, !1)
                }
                if (!Ce) return;
                const zt = Ng.decode(Ce);
                T(s.file_id, {
                    fileBlob: ne,
                    fileName: s.file_name,
                    presentation: null,
                    workbook: zt,
                    document: null,
                    selectedSlideIdx: 0,
                    selectedSheetIdx: 0
                }), Xe.logEvent("Walnut Preview Loaded", {
                    extension: Pe
                })
            })().then(() => {
                Dt || (w(!1), j && !jt && N(s.file_id))
            }).catch(qe => {
                Dt || qe instanceof DOMException && qe.name === "AbortError" || (k(!0), w(!1), ts.addError(qe, {
                    file_id: s.file_id
                }))
            }), () => {
                var qe;
                Dt = !0, (qe = J.current) == null || qe.abort()
            }
        }, Ye = [Se, V, T, s.file_name, s.file_id, j, N, S, je, z, U, G, b, ye], e[24] = s.file_id, e[25] = s.file_name, e[26] = ye, e[27] = j, e[28] = b, e[29] = je, e[30] = S, e[31] = N, e[32] = z, e[33] = Se, e[34] = U, e[35] = V, e[36] = G, e[37] = T, e[38] = Te, e[39] = Ye) : (Te = e[38], Ye = e[39]), x.useEffect(Te, Ye);
        let ge;
        e[40] !== s.file_id || e[41] !== s.file_name || e[42] !== N ? (ge = function(Dt) {
            Dt.preventDefault(), N(s.file_id);
            const jt = Wo(s.file_name);
            Xe.logEvent("Walnut Expand Click", {
                extension: jt
            })
        }, e[40] = s.file_id, e[41] = s.file_name, e[42] = N, e[43] = ge) : ge = e[43];
        const lt = ge;
        let Ze;
        e[44] !== s.file_id || e[45] !== s.file_name || e[46] !== n || e[47] !== o ? (Ze = {
            conversation: n,
            messageId: o,
            fileId: s.file_id,
            fileName: s.file_name,
            processedMarkdownInfo: null,
            isStandaloneAttachment: !0
        }, e[44] = s.file_id, e[45] = s.file_name, e[46] = n, e[47] = o, e[48] = Ze) : Ze = e[48];
        const {
            onClick: pe,
            isLoading: de,
            isEnabled: Me
        } = jd(Ze), we = E && !j, $e = (bt = c == null ? void 0 : c.isLoading) != null ? bt : p, Ue = (We = c == null ? void 0 : c.isError) != null ? We : g, Ae = !!(c != null && c.isPreviewCollapsed), pt = (Et = c == null ? void 0 : c.errorMessage) != null ? Et : C, Le = ($t = c == null ? void 0 : c.handleDownloadClick) != null ? $t : fe, ct = E && "mx-auto my-0", Ct = (!ie || Ue || Ae) && "max-w-max";
        let ft;
        e[49] !== ct || e[50] !== Ct ? (ft = W(Tx, "flex max-w-[calc(0.8*var(--thread-content-max-width,40rem))] flex-col overflow-hidden", ct, Ct), e[49] = ct, e[50] = Ct, e[51] = ft) : ft = e[51];
        const _t = Ue || Ae ? "border-0" : "border-b";
        let Q;
        e[52] !== _t ? (Q = W("text-token-text-primary border-token-border-light flex flex-row justify-between gap-4 p-2 text-sm font-medium", _t), e[52] = _t, e[53] = Q) : Q = e[53];
        const ae = f && "cursor-pointer";
        let _e;
        e[54] !== ae ? (_e = W("flex flex-row items-center gap-2 overflow-hidden ps-1", ae), e[54] = ae, e[55] = _e) : _e = e[55];
        const Ge = f || void 0;
        let ze;
        e[56] !== s.file_name ? (ze = a.jsx(Mg, {
            fileName: s.file_name
        }), e[56] = s.file_name, e[57] = ze) : ze = e[57];
        let Ve;
        e[58] !== s.file_name || e[59] !== ke || e[60] !== m ? (Ve = m ? s.file_name : ke ? a.jsx(me, {
            id: "HTIcmf",
            defaultMessage: "Presentation"
        }) : a.jsx(me, {
            id: "pftlup",
            defaultMessage: "Spreadsheet"
        }), e[58] = s.file_name, e[59] = ke, e[60] = m, e[61] = Ve) : Ve = e[61];
        let De;
        e[62] !== Ve ? (De = a.jsx("div", {
            className: "truncate text-sm font-medium",
            children: Ve
        }), e[62] = Ve, e[63] = De) : De = e[63];
        let tt;
        e[64] !== _e || e[65] !== Ge || e[66] !== ze || e[67] !== De ? (tt = a.jsxs("div", {
            className: _e,
            onClick: Ge,
            children: [ze, De]
        }), e[64] = _e, e[65] = Ge, e[66] = ze, e[67] = De, e[68] = tt) : tt = e[68];
        let mt;
        e[69] !== lt || e[70] !== re || e[71] !== we || e[72] !== he || e[73] !== Le || e[74] !== Ue || e[75] !== Ae || e[76] !== K ? (mt = !we && a.jsxs(a.Fragment, {
            children: [re && a.jsx("button", {
                className: "hover:text-token-text-secondary hover:bg-token-bg-tertiary rounded-full p-1",
                onClick: Le,
                children: a.jsx(_i, {})
            }), !(Ue || Ae) && a.jsx("button", {
                className: "hover:text-token-text-secondary hover:bg-token-bg-tertiary disabled:text-token-text-tertiary rounded-full p-1 disabled:cursor-not-allowed disabled:bg-transparent",
                disabled: !he && !K,
                onClick: lt,
                children: a.jsx(Tg, {})
            })]
        }), e[69] = lt, e[70] = re, e[71] = we, e[72] = he, e[73] = Le, e[74] = Ue, e[75] = Ae, e[76] = K, e[77] = mt) : mt = e[77];
        let vt;
        e[78] !== $ || e[79] !== Me || e[80] !== de || e[81] !== o || e[82] !== pe ? (vt = $ && !!o && Me && a.jsx("button", {
            className: "hover:text-token-text-secondary hover:bg-token-bg-tertiary rounded-full p-1",
            disabled: !Me,
            onClick: pe,
            children: de ? a.jsx(_n, {}) : a.jsx(Nx, {})
        }), e[78] = $, e[79] = Me, e[80] = de, e[81] = o, e[82] = pe, e[83] = vt) : vt = e[83];
        let kt;
        e[84] !== mt || e[85] !== vt ? (kt = a.jsxs("div", {
            className: "text-token-text-secondary flex flex-row items-center gap-1 text-sm",
            children: [mt, vt]
        }), e[84] = mt, e[85] = vt, e[86] = kt) : kt = e[86];
        let Je;
        e[87] !== Q || e[88] !== tt || e[89] !== kt ? (Je = a.jsxs("div", {
            className: Q,
            children: [tt, kt]
        }), e[87] = Q, e[88] = tt, e[89] = kt, e[90] = Je) : Je = e[90];
        let He;
        e[91] === Symbol.for("react.memo_cache_sentinel") ? (He = W("bg-token-bg-tertiary group relative"), e[91] = He) : He = e[91];
        let Ke;
        e[92] !== s.file_id || e[93] !== we || e[94] !== ke || e[95] !== y || e[96] !== pt || e[97] !== Le || e[98] !== $e || e[99] !== Ue || e[100] !== Ae || e[101] !== u || e[102] !== h ? (Ke = !Ae && a.jsx(Cx, {
            walnutId: s.file_id,
            isPresentation: ke,
            isLoading: $e,
            isError: Ue,
            isInShareModal: we,
            errorMessage: pt,
            handleDownloadClick: Le,
            showWorksheetTabs: h,
            isResponsiveSheet: y,
            responsiveSheetHeight: u
        }), e[92] = s.file_id, e[93] = we, e[94] = ke, e[95] = y, e[96] = pt, e[97] = Le, e[98] = $e, e[99] = Ue, e[100] = Ae, e[101] = u, e[102] = h, e[103] = Ke) : Ke = e[103];
        let dt;
        e[104] !== we ? (dt = we && a.jsx("div", {
            className: "absolute end-5 top-46 z-10 inline-flex flex-shrink-0 items-end justify-end",
            children: a.jsx(fh, {
                className: W("inline h-4 w-24 text-end")
            })
        }), e[104] = we, e[105] = dt) : dt = e[105];
        let ut;
        e[106] !== Ke || e[107] !== dt ? (ut = a.jsxs("div", {
            className: He,
            children: [Ke, dt]
        }), e[106] = Ke, e[107] = dt, e[108] = ut) : ut = e[108];
        let Oe;
        return e[109] !== ft || e[110] !== Je || e[111] !== ut ? (Oe = a.jsxs("div", {
            className: ft,
            children: [Je, ut]
        }), e[109] = ft, e[110] = Je, e[111] = ut, e[112] = Oe) : Oe = e[112], Oe
    },
    Nx = t => {
        "use forget";
        const e = xe.c(4),
            {
                className: s
            } = t;
        let n, o;
        e[0] === Symbol.for("react.memo_cache_sentinel") ? (n = a.jsx("path", {
            d: "M3 12.4428V12.2806C3 11.9219 3.2843 11.631 3.63497 11.631C3.98563 11.631 4.26993 11.9219 4.26993 12.2806V12.4428C4.26993 13.1372 4.2708 13.6193 4.3007 13.994C4.33 14.3609 4.38426 14.5675 4.46108 14.7218L4.52821 14.8459C4.69655 15.1266 4.93812 15.3556 5.22657 15.5061L5.35059 15.5604C5.48786 15.6107 5.6688 15.6476 5.938 15.6701C6.30417 15.7008 6.77519 15.7007 7.45408 15.7007H12.546C13.2246 15.7007 13.6959 15.7008 14.0621 15.6701C14.4204 15.6402 14.6226 15.5846 14.7735 15.5061L14.8946 15.4364C15.169 15.2642 15.3929 15.0169 15.5399 14.7218L15.593 14.595C15.6421 14.4546 15.6782 14.2692 15.7003 13.994C15.7301 13.6193 15.73 13.1372 15.73 12.4428V12.2806C15.73 11.922 16.0145 11.6312 16.3651 11.631C16.7157 11.631 17 11.9219 17 12.2806V12.4428C17 13.1158 17.0006 13.6601 16.9655 14.0999C16.9342 14.4916 16.8722 14.8443 16.7343 15.1731L16.6709 15.3123C16.4174 15.8213 16.0318 16.2469 15.5585 16.544L15.3506 16.6632C14.9909 16.8507 14.6028 16.9281 14.1655 16.9646C13.7356 17.0006 13.2038 17 12.546 17H7.45408C6.79615 17 6.26438 17.0006 5.8345 16.9646C5.45207 16.9327 5.10749 16.8699 4.78649 16.729L4.65035 16.6632C4.1528 16.4038 3.73604 16.0094 3.44569 15.5251L3.32914 15.3123C3.14585 14.9444 3.07023 14.5473 3.03451 14.0999C2.9994 13.6601 3 13.1158 3 12.4428Z"
        }), o = a.jsx("path", {
            d: "M9.99993 13.2544C10.3505 13.2544 10.6348 12.9635 10.6348 12.6047V5.218L12.7337 7.36545L12.8335 7.44845C13.0799 7.61506 13.4146 7.58749 13.6316 7.36545C13.8486 7.14342 13.8756 6.80101 13.7127 6.54884L13.6316 6.44677L10.4493 3.19088C10.3302 3.06897 10.1683 3 9.99993 3C9.8316 3.0001 9.67044 3.06906 9.55138 3.19088L6.36815 6.44677C6.12048 6.70037 6.12057 7.11179 6.36815 7.36545C6.58526 7.58755 6.92077 7.61523 7.1673 7.44845L7.26707 7.36545L9.36491 5.21897V12.6047C9.36491 12.9634 9.64934 13.2542 9.99993 13.2544Z"
        }), e[0] = n, e[1] = o) : (n = e[0], o = e[1]);
        let r;
        return e[2] !== s ? (r = a.jsxs("svg", {
            width: "20",
            height: "20",
            viewBox: "0 0 20 20",
            fill: "currentColor",
            xmlns: "http://www.w3.org/2000/svg",
            className: s,
            children: [n, o]
        }), e[2] = s, e[3] = r) : r = e[3], r
    };

function Px() {}
const Rx = new Set(["jpg", "jpeg", "png", "gif", "webp", "svg"]),
    $x = t => {
        const e = t.split(".").pop();
        return e ? Rx.has(e) : !1
    };

function Ax({
    citation: t,
    conversation: e,
    messageId: s
}) {
    var c;
    const n = et(),
        o = vf(),
        r = kf(),
        i = x.useRef(o !== yi.Research),
        l = Rt(e.serverId$);
    if (x.useEffect(() => {
            !i.current && o === yi.Research && (i.current = !0, r(null))
        }, [o, r]), Cg(t.file_name) && at(n, "3392860057")) return a.jsx(Ix, {
        citation: t,
        conversation: e,
        messageId: s,
        children: (c = t.label) != null ? c : t.file_name
    });
    if (H1(t.file_name)) return a.jsx(U1, {
        citation: t,
        conversation: e,
        messageId: s
    });
    if (l) return a.jsx(Lx, {
        citation: t,
        serverThreadId: l
    })
}

function Lx({
    citation: t,
    serverThreadId: e
}) {
    var r, i;
    const s = ys(),
        n = x.useCallback(l => {
            s.danger(l, {
                toastId: "fcoa_renderer_failed_to_download_file"
            })
        }, [s]),
        {
            data: o
        } = qi(!0, e, t.file_id, void 0, n);
    return $x(t.file_name) && (o != null && o.download_url) ? a.jsx("img", {
        src: o == null ? void 0 : o.download_url,
        alt: (r = t.label) != null ? r : t.file_name,
        className: "max-h-[350px] max-w-screen"
    }) : a.jsx("a", {
        href: o == null ? void 0 : o.download_url,
        children: (i = t.label) != null ? i : t.file_name
    })
}

function Dx({
    citationIndex: t,
    conversation: e,
    nodeType: s,
    messageId: n
}) {
    var l;
    const o = parseInt(t, 10),
        r = x.useContext(js);
    if (!r) return null;
    const i = (l = r.n7jupdCrefs) == null ? void 0 : l[o];
    if (!i) return null;
    switch (i.type) {
        case "clipboard":
            return a.jsx(B1, {
                citation: i
            });
        case "computer_output":
            return a.jsx(W1, {
                citation: i,
                conversation: e,
                nodeType: s
            });
        case "file":
            return a.jsx(Ax, {
                citation: i,
                conversation: e,
                messageId: n
            });
        case "invalid":
            return null
    }
}

function Ox(t) {
    return t && /^turn[0-9]+ifs[0-9]+$/.test(t)
}

function Fx({
    path: t,
    lineRangeStart: e,
    lineRangeEnd: s,
    gitUrl: n
}) {
    const [o, r] = x.useState(!1), i = x.useContext(Dr), l = x.useRef(null), c = x.useRef(null), d = x.useRef(null), u = () => {
        d.current && (clearTimeout(d.current), d.current = null), r(!0)
    }, f = () => {
        d.current = window.setTimeout(() => {
            r(!1)
        }, 200)
    };
    if (!t) return null;
    const h = i == null ? void 0 : i.fileSnapshots.find(b => b.path === t);
    if (!h) return null;
    const m = Wx(e, s, h);
    return m.length ? a.jsxs(Nr, {
        open: o,
        onOpenChange: r,
        children: [a.jsx(Pr, {
            asChild: !0,
            onMouseEnter: u,
            onMouseLeave: f,
            children: a.jsx("span", {
                ref: l,
                className: "bg-token-bg-secondary text-token-text-secondary mx-0.5 inline-flex aspect-square size-min cursor-default items-center justify-center rounded-full p-1",
                children: a.jsx(qg, {
                    className: "size-[10px]"
                })
            })
        }), a.jsx(Rr, {
            children: a.jsx($r, {
                ref: c,
                className: "z-50 focus:outline-none",
                side: "right",
                onMouseEnter: u,
                onMouseLeave: f,
                onOpenAutoFocus: b => b.preventDefault(),
                children: a.jsx(Bx, {
                    snapshot: h,
                    snippetLines: m,
                    lineRangeStart: e,
                    lineRangeEnd: s,
                    gitUrl: n
                })
            })
        })]
    }) : null
}

function Bx({
    snapshot: t,
    snippetLines: e,
    lineRangeStart: s,
    lineRangeEnd: n,
    gitUrl: o
}) {
    var c;
    const r = (c = t.path.split(".").pop()) != null ? c : "sh",
        i = e.reduce((d, u) => {
            if (u.trim() === "") return d;
            const f = u.match(/^\s*/),
                h = f ? f[0].length : 0;
            return d === -1 ? h : Math.min(d, h)
        }, -1),
        l = e.map(d => i > 0 ? d.slice(i) : d).join("\n");
    return a.jsxs("div", {
        className: "bg-token-bg-primary border-token-border-default mx-4 flex max-h-[600px] flex-col rounded-2xl border px-2 pt-2 pb-4 shadow-[0px_4px_16px_0px_rgba(0,0,0,0.05)] focus:outline-none dark:shadow-none",
        children: [l && a.jsx(mh, {
            wrapperClassName: "rounded-lg !bg-token-bg-tertiary !border-none mb-3 max-h-[400px] overflow-auto text-xs w-[600px] max-w-full",
            codeContainerClassName: "!p-2",
            language: r,
            content: l,
            showActionBar: !1
        }), a.jsxs("div", {
            className: "grid w-full grid-cols-[minmax(0,1fr)_auto] items-center justify-between gap-1 px-2 text-sm",
            children: [t.path, a.jsxs("div", {
                className: "text-token-text-tertiary flex items-center gap-1 whitespace-nowrap",
                children: [a.jsx(me, {
                    id: "wham.citation.file.lineRange",
                    defaultMessage: "Lines {lineRangeStart}-{lineRangeEnd}",
                    values: {
                        lineRangeStart: s,
                        lineRangeEnd: n
                    }
                }), o && a.jsx("a", {
                    className: "group flex w-full items-center gap-1 p-1",
                    href: o,
                    target: "_blank",
                    rel: "noopener noreferrer",
                    children: a.jsx(Sf, {
                        className: "icon-xs hover:text-token-text-primary"
                    })
                })]
            })]
        })]
    })
}

function Wx(t, e, s) {
    var i;
    if (s.contents) {
        const l = s.contents.split("\n"),
            c = Math.max(0, t - 1),
            d = e ? Math.min(l.length, e) : c + 1;
        return l.slice(c, d)
    }
    const n = (i = s.line_range_contents) == null ? void 0 : i.find(l => zx(l, t, e));
    if (!n) return [];
    const o = Math.max(t - n.line_range_start, 0),
        r = o + (e - t + 1);
    return n.content.slice(o, r)
}

function zx(t, e, s) {
    return e < t.line_range_start ? !1 : !(s > t.line_range_end)
}

function Hx({
    assetPointer: t
}) {
    var i, l, c, d, u;
    const e = x.useContext(Dr),
        s = Ne(),
        n = e == null ? void 0 : e.imagePointers.find(f => f.asset_pointer === t),
        o = id({
            asset: {
                content_type: Ac.ImageAssetPointer,
                asset_pointer: (i = n == null ? void 0 : n.asset_pointer) != null ? i : "",
                size_bytes: (l = n == null ? void 0 : n.size_bytes) != null ? l : 0,
                width: (c = n == null ? void 0 : n.width) != null ? c : 0,
                height: (d = n == null ? void 0 : n.height) != null ? d : 0
            }
        });
    if (!n || !((u = o.data) != null && u.url)) return null;
    const r = s.formatMessage({
        id: "wham.contentReference.imageAlt",
        defaultMessage: "Captured screenshot"
    });
    return a.jsx(hh, {
        src: o.data.url,
        alt: r,
        className: "max-h-[250px] max-w-[250px]",
        children: a.jsx(gh, {
            src: o.data.url,
            alt: r,
            width: n.width,
            height: n.height,
            className: "max-h-[250px] max-w-[250px] object-contain"
        })
    })
}

function Ux() {
    const t = sr.getItem(nr.ProposedTasks);
    return t && typeof t == "object" ? t : {}
}
const jl = Ef(t => ({
    tasks: Ux(),
    store(e) {
        t(s => {
            const n = ce(F({}, s.tasks), {
                [e.contentId]: e
            });
            return sr.setItem(nr.ProposedTasks, n), {
                tasks: n
            }
        })
    }
}));

function Gx({
    title: t,
    prompt: e,
    environmentId: s,
    branch: n,
    contentId: o,
    hasHitRateLimit: r
}) {
    const [i, l] = x.useState(!1), c = jf(), {
        setEnvironmentId: d,
        setBranch: u
    } = Xg(), {
        refetch: f
    } = Yg(), h = Ne(), m = ys(), b = jl(g => g.tasks[o]), y = jl(g => g.store), {
        mutate: p,
        isPending: w
    } = kr({
        mutationFn: () => Jg.createNewTask(s, n, e, !1).catch(g => {
            throw m.danger(Tn({
                id: "wham.whamComposer.failedToCreateTask",
                defaultMessage: "Failed to create task"
            }), {
                id: "suggestion-".concat(o),
                duration: 5,
                hasCloseButton: !0,
                toastId: "wham_proposed_task_failed_to_create_task"
            }), g
        }),
        onSuccess: async g => {
            await f(), C(g)
        }
    }), C = g => {
        try {
            const k = g.task.id,
                E = g.turn.id,
                j = "/codex/tasks/".concat(k);
            y({
                contentId: o,
                prompt: e,
                scheduledTaskId: k,
                turnId: E,
                url: j
            }), l(!1)
        } catch (k) {}
    }, v = !s || !n || w || r;
    return a.jsxs("div", {
        className: W("mt-1 mb-3 flex w-full items-center rounded-xl px-3 py-3", b ? "bg-token-bg-secondary border border-transparent" : "bg-token-bg-primary border-token-border-default border shadow-[0px_1px_1px_0px_rgba(0,0,0,0.05)]"),
        children: [a.jsxs("div", {
            className: W("group flex flex-1 items-center gap-1", !b && "-my-3 py-3", !b && !v && "cursor-pointer"),
            onClick: () => {
                v || b || (d(s), u(n), l(!0), Ga.recordProposedTaskClicked("edit"))
            },
            children: [a.jsxs("div", {
                className: "flex flex-col gap-0.5",
                children: [a.jsx("span", {
                    className: "text-token-text-tertiary text-xs",
                    children: a.jsx(me, {
                        id: "wham.whamProposedTask.title",
                        defaultMessage: "Suggested task"
                    })
                }), a.jsx("span", {
                    className: W("text-sm font-medium", b && "text-token-text-tertiary"),
                    children: t
                })]
            }), !v && !b && a.jsx(ph, {
                className: "icon-sm text-token-text-secondary mb-0.5 cursor-pointer self-end opacity-0 transition-opacity group-hover:opacity-100"
            })]
        }), a.jsx("div", {
            className: "flex items-center justify-end gap-2 text-xs",
            children: b ? a.jsx(us, {
                size: "small",
                color: "secondary",
                as: "a",
                to: b == null ? void 0 : b.url,
                openNewTab: !0,
                children: a.jsx("span", {
                    className: "text-token-text-primary font-medium",
                    children: a.jsx(me, {
                        id: "lwqFNG",
                        defaultMessage: "View task"
                    })
                })
            }) : a.jsx(qx, {
                prompt: r ? h.formatMessage({
                    id: "wham.proposedTask.hitRateLimit",
                    defaultMessage: "You have reached your rate limit"
                }) : e,
                tooltipEnabled: !b && !i,
                children: a.jsx(us, {
                    size: "small",
                    color: "secondary",
                    disabled: v,
                    onClick: () => {
                        Ga.recordProposedTaskClicked("create"), p()
                    },
                    children: a.jsxs("div", {
                        className: "flex items-center gap-0.5",
                        children: [a.jsx(me, {
                            id: "b2N2Y8",
                            defaultMessage: "Start task"
                        }), w ? a.jsx(_n, {
                            className: "icon-xs me-[2px]"
                        }) : a.jsx(xh, {
                            className: "icon-sm"
                        })]
                    })
                })
            })
        }), a.jsx(Ns.Root, {
            testId: "modal-task-stub-composer",
            isOpen: i,
            onClose: () => l(!1),
            children: a.jsx(Ns.Overlay, {
                children: a.jsxs(Ns.Content, {
                    className: "flex max-w-3xl! items-center justify-center px-12 py-4 focus:outline-hidden",
                    size: "normal",
                    removeBackground: !0,
                    onEscapeKeyDown: g => {
                        g.stopPropagation(), l(!1)
                    },
                    children: [a.jsxs(Mf, {
                        children: [a.jsx(Cf, {
                            children: a.jsx(me, {
                                id: "wham.proposedTaskModel.title",
                                defaultMessage: "Kick off a new Codex task"
                            })
                        }), a.jsx(Tf, {
                            children: a.jsx(me, {
                                id: "wham.proposedTaskModel.description",
                                defaultMessage: "Codex can propose new follow up tasks"
                            })
                        })]
                    }), a.jsx(On.div, {
                        initial: {
                            opacity: 0,
                            translateY: 20
                        },
                        animate: {
                            opacity: 1,
                            translateY: 0
                        },
                        transition: {
                            duration: c ? 0 : .25
                        },
                        className: "w-full",
                        children: a.jsxs("div", {
                            className: "flex flex-col items-center gap-8",
                            children: [a.jsx("h1", {
                                className: "text-token-text-primary dark text-[28px] font-semibold",
                                children: a.jsx(me, {
                                    id: "wham.proposedTaskModal.title",
                                    defaultMessage: "Edit suggested task"
                                })
                            }), a.jsx(Vx, {
                                prompt: e,
                                onSuccess: C
                            })]
                        })
                    })]
                })
            })
        })]
    })
}

function qx({
    prompt: t,
    tooltipEnabled: e,
    children: s
}) {
    return e ? a.jsx(Yn, {
        side: "right",
        label: a.jsx("span", {
            className: "block p-2 text-start whitespace-pre-wrap",
            children: t
        }),
        wide: !0,
        children: s
    }) : s
}

function Vx({
    prompt: t,
    onSuccess: e
}) {
    const {
        composerController: s
    } = bh();
    return x.useEffect(() => {
        Lc(Dc(s), t.trimEnd())
    }, [s, t]), a.jsx(If.Provider, {
        value: s,
        children: a.jsx(Vg, {
            isBigBoxMode: !0,
            expanded: !0,
            disableDuringSubmit: !0,
            onSuccess: e
        })
    })
}

function Kx({
    title: t,
    prompt: e
}) {
    const s = x.useContext(Dr),
        {
            data: n
        } = Zg(),
        o = Kg(n),
        r = x.useMemo(() => Xx("".concat(s == null ? void 0 : s.taskId, ":").concat(t, ":").concat(e)), [s == null ? void 0 : s.taskId, t, e]);
    return !s || !s.environmentId || !s.branch ? null : a.jsx(Gx, {
        title: t,
        prompt: e,
        environmentId: s.environmentId,
        branch: s.branch,
        contentId: r,
        hasHitRateLimit: o
    })
}

function Xx(t) {
    let e = 5381;
    for (let s = 0; s < t.length; s++) e = (e << 5) + e ^ t.charCodeAt(s);
    return (e >>> 0).toString(16).padStart(8, "0")
}

function Yx({
    chunkId: t,
    lineRangeStart: e,
    lineRangeEnd: s
}) {
    const [n, o] = x.useState(!1), r = x.useContext(Dr), i = r == null ? void 0 : r.terminalMessageContents.find(b => b.includes(t)), l = x.useRef(null), c = x.useRef(null), d = x.useRef(null);
    if (!i) return null;
    const u = Jx(i);
    if (!u) return null;
    const f = u.output.slice(e - 1, s);
    if (!f.some(b => !!b.length)) return null;
    const h = () => {
            d.current && (clearTimeout(d.current), d.current = null), o(!0)
        },
        m = () => {
            d.current = window.setTimeout(() => {
                o(!1)
            }, 200)
        };
    return a.jsxs(Nr, {
        open: n,
        onOpenChange: o,
        children: [a.jsx(Pr, {
            asChild: !0,
            onMouseEnter: h,
            onMouseLeave: m,
            children: a.jsx("span", {
                ref: l,
                className: "bg-token-bg-secondary text-token-text-secondary mx-0.5 inline-flex aspect-square size-min cursor-default items-center justify-center rounded-full p-1",
                children: a.jsx(Nf, {
                    className: "size-[10px]"
                })
            })
        }), a.jsx(Rr, {
            children: a.jsx($r, {
                ref: c,
                className: "z-50 focus:outline-none",
                side: "right",
                onMouseEnter: h,
                onMouseLeave: m,
                onOpenAutoFocus: b => b.preventDefault(),
                children: a.jsx("div", {
                    className: "max-h-[500px] max-w-screen px-4",
                    children: a.jsx(Zx, {
                        lines: f,
                        lineRangeStart: e,
                        lineRangeEnd: s
                    })
                })
            })
        })]
    })
}

function Zx({
    lines: t,
    lineRangeStart: e,
    lineRangeEnd: s
}) {
    return a.jsxs("div", {
        className: "bg-token-bg-primary border-token-border-default mx-4 flex flex-col overflow-auto rounded-2xl border px-2 pt-2 pb-3 shadow-[0px_4px_16px_0px_rgba(0,0,0,0.05)] focus:outline-none dark:shadow-none",
        children: [a.jsx(Qg, {
            className: "bg-token-sidebar-surface-primary dark mb-2.5 max-h-[200px] w-full overflow-auto rounded-lg p-3 font-mono text-xs whitespace-pre text-white dark:border dark:border-white/10",
            children: t.join("\n")
        }), a.jsx("div", {
            className: "flex w-full justify-end gap-1 px-2 text-sm",
            children: a.jsx("span", {
                className: "text-token-text-tertiary",
                children: a.jsx(me, {
                    id: "wham.citation.terminal.lineRange",
                    defaultMessage: "Lines {lineRangeStart}-{lineRangeEnd}",
                    values: {
                        lineRangeStart: e,
                        lineRangeEnd: s
                    }
                })
            })
        })]
    })
}

function Jx(t) {
    try {
        const e = JSON.parse(t);
        return !("chunk_id" in e) || typeof e.chunk_id != "string" || !("session_name" in e) || typeof e.session_name != "string" || !("start_line_no" in e) || typeof e.start_line_no != "number" ? null : "output" in e ? e : null
    } catch (e) {
        return null
    }
}
const tu = x.createContext(null),
    Qx = (t, e, s) => {
        Pf(s, t, void 0, e), Ot.count(Ft.WRITING_BLOCKS, t)
    };

function eb(t) {
    "use forget";
    const e = xe.c(22),
        {
            messageId: s,
            conversationId: n,
            isActivelyStreaming: o,
            containsWritingDirectiveInMarkdown: r,
            onMissingWritingBlock: i,
            children: l
        } = t,
        c = o === void 0 ? !1 : o,
        d = et(),
        u = x.useRef(!1),
        f = x.useRef(!1),
        h = x.useRef(!1);
    let m;
    e[0] !== s ? (m = R => s == null || R == null ? !1 : fs.isLastActorMessage(R, s), e[0] = s, e[1] = m) : m = e[1];
    const b = Ls(n, m);
    let y, p;
    e[2] !== c || e[3] !== b ? (y = () => {
        c && b && (f.current = !0)
    }, p = [c, b], e[2] = c, e[3] = b, e[4] = y, e[5] = p) : (y = e[4], p = e[5]), x.useEffect(y, p);
    let w;
    e[6] === Symbol.for("react.memo_cache_sentinel") ? (w = () => {
        u.current = !0
    }, e[6] = w) : w = e[6];
    const C = w,
        v = r ? "true" : "false",
        g = n != null ? n : "",
        k = s != null ? s : "";
    let E;
    e[7] !== v || e[8] !== g || e[9] !== k ? (E = {
        contains_writing_directive: v,
        client_thread_id: g,
        message_id: k
    }, e[7] = v, e[8] = g, e[9] = k, e[10] = E) : E = e[10];
    const j = E;
    let M, T;
    e[11] !== r || e[12] !== d || e[13] !== j || e[14] !== c || e[15] !== b || e[16] !== i ? (M = () => {
        r && (c || u.current || (i == null || i(), !h.current && (f.current && b && Qx("chatgpt_writing_block_first_render_failed", j, d), h.current = !0)))
    }, T = [r, c, b, i, j, d], e[11] = r, e[12] = d, e[13] = j, e[14] = c, e[15] = b, e[16] = i, e[17] = M, e[18] = T) : (M = e[17], T = e[18]), x.useEffect(M, T);
    let N;
    e[19] === Symbol.for("react.memo_cache_sentinel") ? (N = {
        markRendered: C
    }, e[19] = N) : N = e[19];
    const I = N;
    let _;
    return e[20] !== l ? (_ = a.jsx(tu.Provider, {
        value: I,
        children: l
    }), e[20] = l, e[21] = _) : _ = e[21], _
}

function tb({
    metadata: t,
    trackContentReferenceEvent: e
}) {
    var i;
    const s = uf(),
        n = et(),
        o = Er(),
        r = at(n, "3375735072");
    return x.useEffect(() => {
        e("Search Content Reference Shown", "search_content_reference_shown", t.type, {
            checkout_id: t.checkout_id
        })
    }, [e, t.type, t.checkout_id]), r ? a.jsxs("div", {
        className: "border-token-border-default bg-token-bg-primary not-prose mb-6 flex max-w-[420px] flex-col gap-4 rounded-[20px] border py-4 shadow-[0px_4px_16px_0px_rgba(0,_0,_0,_0.05)]",
        "data-order-id": t.checkout_id,
        role: "group",
        children: [a.jsxs("div", {
            className: "flex items-center gap-2 px-4 text-sm font-medium",
            children: [a.jsx(Rf, {
                className: "icon-lg text-green-400"
            }), a.jsx(me, {
                id: "checkout_purchase_confirmation_status",
                defaultMessage: "Purchase complete"
            })]
        }), a.jsxs("div", {
            className: "border-token-border-light flex items-start gap-3 border-b px-4 pb-4",
            children: [a.jsx("div", {
                className: "flex-shrink-0 overflow-hidden rounded-xl bg-gray-100 dark:bg-gray-700",
                children: a.jsx("img", {
                    src: t.product_image_urls[0],
                    alt: t.title,
                    className: "m-0 aspect-square h-32 w-32 object-cover mix-blend-darken dark:mix-blend-lighten"
                })
            }), a.jsxs("div", {
                className: "min-w-0 flex-1",
                children: [a.jsx("div", {
                    className: "line-clamp-2 min-h-6 text-base leading-snug font-medium",
                    title: t.title,
                    children: t.title
                }), a.jsx("div", {
                    className: "text-token-text-secondary text-[13px] leading-snug whitespace-pre-wrap",
                    children: t.subtitle
                })]
            })]
        }), t.error_message && a.jsx("div", {
            className: "bg-token-bg-status-error text-token-interactive-label-danger-secondary-default mx-4 flex items-center rounded-lg px-3 py-1 text-sm",
            children: t.error_message
        }), a.jsx("dl", {
            className: "space-y-1 px-4",
            children: (i = t.details) == null ? void 0 : i.map(l => a.jsxs("div", {
                className: "flex items-center gap-2",
                children: [a.jsx("dt", {
                    className: "text-token-text-secondary flex-grow text-[13px] font-medium",
                    children: l.label
                }), a.jsx("dd", {
                    className: "text-token-text-primary text-[13px] font-medium",
                    children: l.value
                })]
            }, l.label))
        }), !o && a.jsx("div", {
            className: "px-4",
            children: a.jsx(us, {
                fullWidth: !0,
                color: "secondary",
                className: "rounded-2xl border",
                onClick: () => {
                    s("#settings/".concat($f.Orders, "?order=").concat(t.checkout_id))
                },
                children: a.jsx(me, {
                    id: "2Dn5nu",
                    defaultMessage: "View details"
                })
            })
        })]
    }) : null
}
const Ml = 4;

function sb(t) {
    "use forget";
    const e = xe.c(41),
        {
            metadata: s,
            analyticsMetadata: n,
            trackContentReferenceEvent: o,
            imageSource: r
        } = t,
        i = r != null ? r : hn.Turn,
        l = Zn();
    let c, d, u;
    e[0] !== s.images ? (c = s.images.some(ab) ? [] : s.images.map(ib), u = ff, d = c.map(rb), e[0] = s.images, e[1] = c, e[2] = d, e[3] = u) : (c = e[1], d = e[2], u = e[3]);
    let f;
    e[4] !== c ? (f = v => {
        const g = new Set;
        return v.forEach((k, E) => {
            k.isSuccess && g.add(c[E])
        }), g
    }, e[4] = c, e[5] = f) : f = e[5];
    let h;
    e[6] !== d || e[7] !== f ? (h = {
        queries: d,
        combine: f
    }, e[6] = d, e[7] = f, e[8] = h) : h = e[8];
    const m = u(h),
        b = s.images;
    let y, p, w;
    if (e[9] !== n || e[10] !== m || e[11] !== i || e[12] !== l || e[13] !== s.images || e[14] !== o) {
        w = Symbol.for("react.early_return_sentinel");
        e: {
            let v;e[18] !== m ? (v = j => m.has(j.thumbnail_url), e[18] = m, e[19] = v) : v = e[19];
            const g = b.filter(v),
                k = s.images.length;
            if (s.images.some(ob)) {
                let j;
                e[20] !== s.images ? (j = s.images.find(nb), e[20] = s.images, e[21] = j) : j = e[21];
                const M = j,
                    T = M != null && M.float_top ? "relative block" : "float-image z-10 float-end clear-end ms-7 overflow-hidden";
                let N;
                e[22] !== T ? (N = W("mb-7 mt-1 min-w-32 max-w-[22%] rounded-xl border-[0.5px] border-token-border-default", T), e[22] = T, e[23] = N) : N = e[23];
                const I = N,
                    _ = M == null ? void 0 : M.content_url;
                let R;
                e[24] === Symbol.for("react.memo_cache_sentinel") ? (R = {
                    imageUse: "deepResearch"
                }, e[24] = R) : R = e[24];
                let A;
                e[25] !== n || e[26] !== I || e[27] !== i || e[28] !== M || e[29] !== _ || e[30] !== o ? (A = a.jsx(Ps, {
                    image: M,
                    imageSource: i,
                    analyticsMetadata: n,
                    trackContentReferenceEvent: o,
                    eventMetadata: R,
                    aspectRatio: Qo,
                    className: I,
                    contentReferenceType: "image_v2"
                }, _), e[25] = n, e[26] = I, e[27] = i, e[28] = M, e[29] = _, e[30] = o, e[31] = A) : A = e[31], w = A;
                break e
            }
            if (k === 0) {
                w = null;
                break e
            }
            if (k === 1) {
                const j = s.images[0];
                let M;
                e[32] === Symbol.for("react.memo_cache_sentinel") ? (M = {
                    imageUse: "legacyCarousel"
                }, e[32] = M) : M = e[32];
                let T;
                e[33] !== n || e[34] !== i || e[35] !== j || e[36] !== o ? (T = a.jsx(Ps, {
                    image: j,
                    imageSource: i,
                    analyticsMetadata: n,
                    trackContentReferenceEvent: o,
                    eventMetadata: M,
                    aspectRatio: Qo,
                    className: "float-image border-token-border-default float-end clear-end ms-7 mt-1 mb-7 max-w-[22%] min-w-32 overflow-hidden rounded-xl border-[0.5px]",
                    contentReferenceType: "image_v2"
                }, j.content_url), e[33] = n, e[34] = i, e[35] = j, e[36] = o, e[37] = T) : T = e[37], w = T;
                break e
            }
            const E = l || Ml == null ? g.length : Math.min(g.length, Ml);y = "no-scrollbar mt-1 mb-6 flex min-h-36 flex-nowrap gap-0.5 overflow-auto sm:gap-1 sm:overflow-hidden xl:min-h-44",
            p = g.slice(0, E).map((j, M) => a.jsx("div", {
                className: W("border-token-border-default relative aspect-square w-32 shrink-0 overflow-hidden rounded-xl border-[0.5px] md:shrink", "max-h-48 sm:w-[calc((100%-0.5rem)/4)]", M === 0 && "rounded-s-xl", M === E - 1 && "rounded-e-xl"),
                children: a.jsx(Ps, {
                    image: j,
                    imageSource: i,
                    analyticsMetadata: n,
                    trackContentReferenceEvent: o,
                    eventMetadata: {
                        imageUse: "legacyCarousel"
                    },
                    aspectRatio: Qo,
                    className: "h-full w-full",
                    contentReferenceType: "image_v2"
                }, j.thumbnail_url)
            }, j.thumbnail_url))
        }
        e[9] = n, e[10] = m, e[11] = i, e[12] = l, e[13] = s.images, e[14] = o, e[15] = y, e[16] = p, e[17] = w
    } else y = e[15], p = e[16], w = e[17];
    if (w !== Symbol.for("react.early_return_sentinel")) return w;
    let C;
    return e[38] !== y || e[39] !== p ? (C = a.jsx("div", {
        className: y,
        children: p
    }), e[38] = y, e[39] = p, e[40] = C) : C = e[40], C
}

function nb(t) {
    return t.is_proxied_image
}

function ob(t) {
    return t.is_proxied_image
}

function rb(t) {
    return Dg(t, "_ImageCarousel")
}

function ib(t) {
    return t.thumbnail_url
}

function ab(t) {
    return t.is_proxied_image
}
const la = x.memo(sb, (t, e) => t.numImageResults === e.numImageResults && t.analyticsMetadata === e.analyticsMetadata && t.trackContentReferenceEvent === e.trackContentReferenceEvent && t.metadata.images.length === e.metadata.images.length && t.metadata.images.every((s, n) => s.content_url === e.metadata.images[n].content_url));

function Ps(t) {
    "use forget";
    var D, te;
    const e = xe.c(72),
        {
            image: s,
            imageSource: n,
            className: o,
            imgClassName: r,
            style: i,
            analyticsMetadata: l,
            trackContentReferenceEvent: c,
            eventMetadata: d,
            badge: u,
            lightboxImages: f,
            aspectRatio: h,
            enableHoverAnimation: m,
            fadeInOnMount: b,
            skeletonEl: y,
            contentReferenceType: p
        } = t;
    let w;
    e[0] !== d ? (w = d === void 0 ? {} : d, e[0] = d, e[1] = w) : w = e[1];
    const C = w,
        v = m === void 0 ? !0 : m,
        g = h != null ? h : void 0;
    let k;
    e[2] !== g ? (k = {
        width: Bg,
        aspectRatio: g
    }, e[2] = g, e[3] = k) : k = e[3];
    const E = Og(s, k);
    let j;
    e[4] !== (s == null ? void 0 : s.content_url) ? (j = s == null ? void 0 : s.content_url.replace(/^http:\/\//, "https://"), e[4] = s == null ? void 0 : s.content_url, e[5] = j) : j = e[5];
    const M = j;
    let T;
    e[6] !== s ? (T = cb(s), e[6] = s, e[7] = T) : T = e[7];
    const N = T,
        {
            isSuccess: I
        } = vi(E, "ImageCarousel_thumbnail"),
        {
            isSuccess: _,
            isError: R
        } = vi(N ? M : void 0, "ImageCarousel_full");
    s == null || s.title;
    const A = s == null ? void 0 : s.title;
    let $;
    e[8] !== C || e[9] !== A || e[10] !== E ? ($ = F({
        image_url: E,
        title: A
    }, C), e[8] = C, e[9] = A, e[10] = E, e[11] = $) : $ = e[11];
    const P = $;
    let U, z;
    e[12] !== p || e[13] !== P || e[14] !== s || e[15] !== I || e[16] !== c ? (U = () => {
        s && I && c("Search Content Reference Shown", "search_content_reference_shown", p, P)
    }, z = [c, s, I, P, p], e[12] = p, e[13] = P, e[14] = s, e[15] = I, e[16] = c, e[17] = U, e[18] = z) : (U = e[17], z = e[18]), x.useEffect(U, z);
    let B, G;
    e[19] !== M || e[20] !== R || e[21] !== E ? (B = () => {
        M && R && ts.addAction("Failed to download full image", {
            url: M,
            thumbnailUrl: E
        })
    }, G = [M, R, E], e[19] = M, e[20] = R, e[21] = E, e[22] = B, e[23] = G) : (B = e[22], G = e[23]), x.useEffect(B, G);
    const O = zi.useStore();
    let H, S, V, J;
    if (e[24] !== l || e[25] !== h || e[26] !== o || e[27] !== p || e[28] !== M || e[29] !== v || e[30] !== P || e[31] !== b || e[32] !== s || e[33] !== O || e[34] !== n || e[35] !== r || e[36] !== _ || e[37] !== I || e[38] !== f || e[39] !== N || e[40] !== y || e[41] !== i || e[42] !== E || e[43] !== c) {
        const se = Fg((D = s == null ? void 0 : s.thumbnail_crop_info) != null ? D : null, (te = s == null ? void 0 : s.thumbnail_size) != null ? te : null, h != null ? h : void 0),
            re = !s || !(I || _ || s.is_proxied_image);
        let X;
        e: {
            if (re) {
                X = void 0;
                break e
            }
            if (s.is_proxied_image) {
                X = s.url;
                break e
            }
            if (N && _) {
                X = M;
                break e
            }
            X = E
        }
        const he = X;
        let K;
        e[48] !== h ? (K = h ? {
            aspectRatio: "".concat(h.width, "/").concat(h.height)
        } : {}, e[48] = h, e[49] = K) : K = e[49];
        let oe;
        e[50] !== i || e[51] !== K ? (oe = F(F({}, i), K), e[50] = i, e[51] = K, e[52] = oe) : oe = e[52];
        const ye = oe;
        e[53] !== o ? (H = W("relative overflow-hidden", o), e[53] = o, e[54] = H) : H = e[54], S = ye, e[55] !== l || e[56] !== p || e[57] !== P || e[58] !== s || e[59] !== O || e[60] !== n || e[61] !== f || e[62] !== c ? (V = () => {
            c("Search Content Reference Clicked", "search_content_reference_clicked", p, P), O.setCurrentImage(s ? {
                image: s,
                source: n,
                analyticsMetadata: l,
                imageResults: f
            } : void 0)
        }, e[55] = l, e[56] = p, e[57] = P, e[58] = s, e[59] = O, e[60] = n, e[61] = f, e[62] = c, e[63] = V) : V = e[63], J = lb({
            isLoading: re,
            enableHoverAnimation: v,
            fadeInOnMount: b,
            src: he,
            image: s,
            objectPosition: se,
            className: r,
            skeletonEl: y
        }), e[24] = l, e[25] = h, e[26] = o, e[27] = p, e[28] = M, e[29] = v, e[30] = P, e[31] = b, e[32] = s, e[33] = O, e[34] = n, e[35] = r, e[36] = _, e[37] = I, e[38] = f, e[39] = N, e[40] = y, e[41] = i, e[42] = E, e[43] = c, e[44] = H, e[45] = S, e[46] = V, e[47] = J
    } else H = e[44], S = e[45], V = e[46], J = e[47];
    let q;
    e[64] !== u ? (q = u && a.jsx("div", {
        className: "pointer-events-none absolute end-2 bottom-2",
        children: u
    }), e[64] = u, e[65] = q) : q = e[65];
    let Z;
    return e[66] !== H || e[67] !== S || e[68] !== V || e[69] !== J || e[70] !== q ? (Z = a.jsxs("button", {
        className: H,
        style: S,
        onClick: V,
        children: [J, q]
    }), e[66] = H, e[67] = S, e[68] = V, e[69] = J, e[70] = q, e[71] = Z) : Z = e[71], Z
}

function lb({
    isLoading: t,
    enableHoverAnimation: e,
    fadeInOnMount: s,
    src: n,
    image: o,
    objectPosition: r,
    className: i,
    skeletonEl: l
}) {
    const c = l != null ? l : a.jsx("div", {
            className: "bg-token-main-surface-tertiary aspect-square h-full w-full animate-pulse"
        }),
        d = !t && n != null ? a.jsx(On.img, {
            src: n,
            alt: o == null ? void 0 : o.content_url,
            referrerPolicy: "no-referrer",
            style: r ? {
                objectPosition: r
            } : {},
            className: W("bg-token-main-surface-tertiary absolute inset-0 m-0 h-full w-full object-cover", i),
            initial: s ? {
                opacity: 0
            } : !1,
            animate: {
                opacity: 1
            },
            transition: s ? {
                duration: .3,
                ease: "easeInOut"
            } : void 0
        }) : null;
    return e ? t ? c : a.jsx(gd, {
        children: d
    }) : a.jsxs(a.Fragment, {
        children: [c, d]
    })
}

function cb(t) {
    return !t || t.is_proxied_image ? !1 : t.thumbnail_url.includes("images.openai.com")
}

function su({
    numImages: t
}) {
    return a.jsxs("div", {
        className: "flex items-center gap-1 rounded-full px-2 py-1.5 text-white backdrop-blur-md backdrop-brightness-75",
        children: [a.jsx(yh, {
            className: "h-4 w-4"
        }), a.jsx("span", {
            className: "text-xs font-semibold",
            children: t
        })]
    })
}

function db(t) {
    "use forget";
    const e = xe.c(70),
        {
            images: s,
            className: n,
            aspect: o,
            objectPosition: r,
            showArrows: i,
            imageClassName: l,
            slideClassName: c,
            gap: d,
            peekPercent: u,
            showDots: f,
            onClick: h
        } = t,
        m = n === void 0 ? "" : n,
        b = o === void 0 ? "aspect-[16/9]" : o,
        y = r === void 0 ? "object-cover" : r,
        p = i === void 0 ? !0 : i,
        w = l === void 0 ? "" : l,
        C = c === void 0 ? "" : c,
        v = d === void 0 ? 2 : d,
        g = u === void 0 ? 95 : u,
        k = f === void 0 ? !1 : f,
        [E, j] = x.useState(0),
        [M, T] = x.useState(!1),
        N = x.useRef(null);
    let I;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (I = [], e[0] = I) : I = e[0];
    const _ = x.useRef(I),
        R = x.useRef(null),
        A = Ne(),
        $ = s.length;
    let P;
    e[1] !== g ? (P = sn(g, 0, 100), e[1] = g, e[2] = P) : P = e[2];
    const U = P,
        z = "".concat(U, "%");
    let B;
    e[3] !== z ? (B = {
        maxWidth: z
    }, e[3] = z, e[4] = B) : B = e[4];
    const G = B;
    let O;
    e[5] !== $ ? (O = (pe, de) => {
        const Me = _.current[pe];
        if (!Me) return 0;
        const we = Me.offsetLeft,
            $e = we + Me.offsetWidth,
            Ue = de.clientWidth,
            Ae = Math.max(0, de.scrollWidth - Ue);
        if ($ <= 1 || pe === 0) return sn(we, 0, Ae);
        if (pe === $ - 1) {
            const Le = $e - Ue;
            return sn(Le, 0, Ae)
        }
        const pt = we - (Ue - Me.offsetWidth) / 2;
        return sn(pt, 0, Ae)
    }, e[5] = $, e[6] = O) : O = e[6];
    const H = O;
    let S;
    e[7] !== H || e[8] !== $ ? (S = (pe, de) => {
        const Me = de === void 0 ? "smooth" : de;
        if ($ === 0 || pe < 0 || pe >= $) return;
        const we = N.current;
        if (!we) return;
        const $e = H(pe, we);
        if (Tl(we.scrollLeft, $e)) {
            Me !== "auto" && we.scrollTo({
                left: $e,
                behavior: "auto"
            }), R.current = null;
            return
        }
        R.current = $e, we.scrollTo({
            left: $e,
            behavior: Me
        })
    }, e[7] = H, e[8] = $, e[9] = S) : S = e[9];
    const V = S,
        J = M && E !== 0,
        q = M;
    let Z;
    e[10] !== E || e[11] !== V || e[12] !== $ ? (Z = pe => {
        if ($ === 0) return;
        const de = sn(pe, 0, $ - 1);
        V(de, "smooth"), de !== E && j(de)
    }, e[10] = E, e[11] = V, e[12] = $, e[13] = Z) : Z = e[13];
    const D = Z;
    let te;
    e[14] !== D || e[15] !== E || e[16] !== $ ? (te = () => {
        if ($ !== 0) {
            if (E >= $ - 1) {
                D(0);
                return
            }
            D(E + 1)
        }
    }, e[14] = D, e[15] = E, e[16] = $, e[17] = te) : te = e[17];
    const se = te;
    let re;
    e[18] !== D || e[19] !== E ? (re = () => D(E - 1), e[18] = D, e[19] = E, e[20] = re) : re = e[20];
    const X = re;
    let he, K;
    e[21] !== H || e[22] !== E || e[23] !== $ ? (he = () => {
        const pe = N.current;
        if (!pe) return;
        const de = () => {
            const Me = pe.scrollLeft || 0,
                we = R.current;
            if (we != null) {
                Tl(Me, we) && (R.current = null);
                return
            }
            let $e = E,
                Ue = Number.POSITIVE_INFINITY;
            for (let Ae = 0; Ae < $; Ae++) {
                const pt = H(Ae, pe),
                    Le = Math.abs(pt - Me);
                Le < Ue - .5 && (Ue = Le, $e = Ae)
            }
            $e !== E && j($e)
        };
        return pe.addEventListener("scroll", de, {
            passive: !0
        }), () => pe.removeEventListener("scroll", de)
    }, K = [$, E, H], e[21] = H, e[22] = E, e[23] = $, e[24] = he, e[25] = K) : (he = e[24], K = e[25]), x.useEffect(he, K);
    let oe, ye;
    e[26] !== M || e[27] !== se || e[28] !== X || e[29] !== $ ? (oe = () => {
        if (!M) return;
        const pe = de => {
            if (de.defaultPrevented || de.altKey || de.ctrlKey || de.metaKey || de.shiftKey) return;
            const Me = de.target;
            if (Me instanceof HTMLElement) {
                if (Me.isContentEditable) return;
                const we = Me.tagName;
                if (we === "INPUT" || we === "TEXTAREA" || we === "SELECT") return;
                const $e = Me.getAttribute("role");
                if ($e === "textbox" || $e === "combobox") return
            }
            $ <= 1 || (de.key === "ArrowRight" ? (de.preventDefault(), se()) : de.key === "ArrowLeft" && (de.preventDefault(), X()))
        };
        return window.addEventListener("keydown", pe), () => window.removeEventListener("keydown", pe)
    }, ye = [M, $, se, X], e[26] = M, e[27] = se, e[28] = X, e[29] = $, e[30] = oe, e[31] = ye) : (oe = e[30], ye = e[31]), x.useEffect(oe, ye);
    const ke = "select-none ".concat(m, " relative");
    let ie, ee;
    e[32] === Symbol.for("react.memo_cache_sentinel") ? (ie = () => T(!0), ee = () => T(!1), e[32] = ie, e[33] = ee) : (ie = e[32], ee = e[33]);
    const fe = "relative w-full ".concat(b, " overflow-clip");
    let Se;
    e[34] !== v ? (Se = {
        gap: v
    }, e[34] = v, e[35] = Se) : Se = e[35];
    let je;
    e[36] !== w || e[37] !== s || e[38] !== A || e[39] !== y || e[40] !== h || e[41] !== C || e[42] !== $ || e[43] !== G ? (je = s.map((pe, de) => {
        var Me;
        return a.jsx("div", {
            onClick: () => h == null ? void 0 : h(pe, de),
            ref: we => {
                _.current[de] = we
            },
            className: W("relative flex h-full shrink-0 grow-0 snap-always items-stretch", de === 0 && "snap-start", de === $ - 1 && "snap-end", de > 0 && de < $ - 1 && "snap-center", C),
            style: G,
            children: pe.content ? pe.content : a.jsx("img", {
                src: pe.src,
                alt: (Me = pe.alt) != null ? Me : A.formatMessage({
                    id: "wHCsqa",
                    defaultMessage: "Slide {index}"
                }, {
                    index: de + 1
                }),
                className: "h-full w-auto ".concat(y, " ").concat(w)
            })
        }, de)
    }), e[36] = w, e[37] = s, e[38] = A, e[39] = y, e[40] = h, e[41] = C, e[42] = $, e[43] = G, e[44] = je) : je = e[44];
    let Te;
    e[45] !== Se || e[46] !== je ? (Te = a.jsx("div", {
        ref: N,
        className: "no-scrollbar flex h-full w-full touch-pan-x snap-x snap-mandatory overflow-x-scroll scroll-smooth",
        style: Se,
        children: je
    }), e[45] = Se, e[46] = je, e[47] = Te) : Te = e[47];
    let Ye;
    e[48] !== s.length || e[49] !== A || e[50] !== J || e[51] !== se || e[52] !== X || e[53] !== q || e[54] !== p ? (Ye = p && s.length > 1 && a.jsxs(a.Fragment, {
        children: [a.jsx(Il, {
            ariaLabel: A.formatMessage({
                id: "l9pylv",
                defaultMessage: "Previous slide"
            }),
            onClick: X,
            side: "start",
            visible: J,
            children: a.jsx(Oc, {
                className: "icon-md"
            })
        }), a.jsx(Il, {
            ariaLabel: A.formatMessage({
                id: "L0pbQh",
                defaultMessage: "Next slide"
            }),
            onClick: se,
            side: "end",
            visible: q,
            children: a.jsx(Hi, {
                className: "icon-md"
            })
        })]
    }), e[48] = s.length, e[49] = A, e[50] = J, e[51] = se, e[52] = X, e[53] = q, e[54] = p, e[55] = Ye) : Ye = e[55];
    let ge;
    e[56] !== D || e[57] !== s || e[58] !== E || e[59] !== A || e[60] !== k ? (ge = k && s.length > 1 && s.length <= 20 && a.jsx("div", {
        className: "absolute start-0 end-0 bottom-3 flex items-center justify-center",
        children: a.jsx("div", {
            className: "flex w-fit items-center justify-center gap-2 rounded-full bg-[#0D0D0D66] bg-clip-padding p-1 backdrop-blur",
            children: s.map((pe, de) => a.jsx("button", {
                onClick: () => D(de),
                "aria-label": A.formatMessage({
                    id: "PUV+4+",
                    defaultMessage: "Go to slide {index}"
                }, {
                    index: de + 1
                }),
                className: "h-1.5 w-1.5 rounded-full transition-opacity ".concat(de === E ? "bg-white" : "bg-gray-400 opacity-60")
            }, de))
        })
    }), e[56] = D, e[57] = s, e[58] = E, e[59] = A, e[60] = k, e[61] = ge) : ge = e[61];
    let lt;
    e[62] !== fe || e[63] !== Te || e[64] !== Ye || e[65] !== ge ? (lt = a.jsxs("div", {
        className: fe,
        children: [Te, Ye, ge]
    }), e[62] = fe, e[63] = Te, e[64] = Ye, e[65] = ge, e[66] = lt) : lt = e[66];
    let Ze;
    return e[67] !== ke || e[68] !== lt ? (Ze = a.jsx("div", {
        className: ke,
        "aria-roledescription": "carousel",
        onMouseEnter: ie,
        onMouseLeave: ee,
        children: lt
    }), e[67] = ke, e[68] = lt, e[69] = Ze) : Ze = e[69], Ze
}
const Cl = {
    width: 4,
    height: 5
};

function ub(t) {
    "use forget";
    const e = xe.c(7),
        {
            image: s
        } = t,
        n = Cl.height / Cl.width;
    let o;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (o = {
        maxHeight: "calc(100cqw * ".concat(n, ")")
    }, e[0] = o) : o = e[0];
    let r;
    e[1] !== s.alt || e[2] !== s.content || e[3] !== s.src ? (r = s.content ? s.content : a.jsx("img", {
        src: s.src,
        alt: s.alt,
        className: "h-full w-full object-cover"
    }), e[1] = s.alt, e[2] = s.content, e[3] = s.src, e[4] = r) : r = e[4];
    let i;
    return e[5] !== r ? (i = a.jsx("div", {
        className: "[container-type:inline-size] w-full overflow-hidden [font-size:0] leading-none",
        style: o,
        children: r
    }), e[5] = r, e[6] = i) : i = e[6], i
}

function fb(t) {
    "use forget";
    const e = xe.c(4);
    if (t.images.length === 0) return null;
    if (t.images.length === 1) {
        let n;
        return e[0] !== t.images[0] ? (n = a.jsx(ub, {
            image: t.images[0]
        }), e[0] = t.images[0], e[1] = n) : n = e[1], n
    }
    let s;
    return e[2] !== t ? (s = a.jsx(db, F({}, t)), e[2] = t, e[3] = s) : s = e[3], s
}
const sn = (t, e, s) => Math.min(Math.max(t, e), s),
    Tl = (t, e, s = 1) => Math.abs(t - e) <= s;

function Il(t) {
    "use forget";
    const e = xe.c(11),
        {
            ariaLabel: s,
            onClick: n,
            side: o,
            visible: r,
            children: i
        } = t,
        l = o === "start" ? "start-0 justify-end" : "end-0 justify-start",
        c = r ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none ";
    let d;
    e[0] !== l || e[1] !== c ? (d = W("group absolute top-0 bottom-0 flex h-full w-12.5 cursor-pointer items-center transition-opacity duration-300", l, c), e[0] = l, e[1] = c, e[2] = d) : d = e[2];
    let u;
    e[3] === Symbol.for("react.memo_cache_sentinel") ? (u = W("btn-secondary active:bg-token-bg-tertiary group-hover:bg-token-bg-secondary flex h-8 w-8 items-center justify-center rounded-full bg-clip-padding shadow-sm group-hover:shadow-[0px_4px_16px_0px_rgba(0,0,0,0.05)] active:opacity-100!"), e[3] = u) : u = e[3];
    let f;
    e[4] !== s || e[5] !== i ? (f = a.jsx("button", {
        "aria-label": s,
        className: u,
        children: i
    }), e[4] = s, e[5] = i, e[6] = f) : f = e[6];
    let h;
    return e[7] !== n || e[8] !== d || e[9] !== f ? (h = a.jsx("div", {
        className: d,
        onClick: n,
        children: f
    }), e[7] = n, e[8] = d, e[9] = f, e[10] = h) : h = e[10], h
}
const nu = "mt-1 mb-5 [&:not(:first-child)]:mt-4",
    mb = /^image_group[\s\S]*$/;

function hb({
    contentReference: t,
    trackContentReferenceEvent: e,
    analyticsMetadata: s
}) {
    var m;
    const o = ad().renderExtent === "preview",
        r = x.useRef(!1),
        {
            images: i,
            layout: l = "carousel"
        } = t,
        c = mb.test((m = t.matched_text) != null ? m : ""),
        d = {
            images: i,
            trackContentReferenceEvent: e,
            analyticsMetadata: s,
            isReferenceComplete: c
        },
        u = i.length,
        f = i.filter(b => b.image_result != null).length,
        h = new Set(i.map(b => b.image_search_query).filter(b => b != null)).size;
    return x.useEffect(() => {
        const b = !c && f === 0;
        o || r.current || b || (r.current = !0, e("Search Content Reference Shown", "search_content_reference_shown", "image_group", {
            layout: l,
            card_count: u,
            image_result_count: f,
            image_query_count: h
        }), ts.addAction("image_group_shown", {
            layout: l,
            card_count: u,
            image_result_count: f,
            image_query_count: h
        }))
    }, [o, l, u, f, h, c, e]), o ? null : l === "carousel" ? a.jsx(Mb, F({}, d)) : l === "bento" ? a.jsx(vb, F({}, d)) : l === "full_width" ? a.jsx(Nb, F({}, d)) : null
}
const gb = {
        width: 9,
        height: 5
    },
    pb = {
        width: 21,
        height: 9
    };

function xb(t) {
    switch (t) {
        case 0:
            return "rounded-se-md rounded-ee-md rounded-ss-xl rounded-es-xl";
        case 1:
            return "rounded-se-xl rounded-ee-md rounded-ss-md rounded-es-md";
        case 2:
            return "rounded-se-md rounded-ee-xl rounded-ss-md rounded-es-md";
        default:
            return ""
    }
}
const bb = (t, e) => {
    var s;
    return t.image_result ? t.image_result.content_url : "".concat((s = t.image_search_query) != null ? s : t.image_ref_id, "-").concat(e)
};

function yb(t) {
    "use forget";
    const e = xe.c(14),
        {
            images: s,
            trackContentReferenceEvent: n,
            analyticsMetadata: o
        } = t,
        r = et(),
        l = jr(r) ? pb : gb,
        c = l.width / 3,
        d = l.height / 2;
    let u;
    e[0] !== c || e[1] !== d ? (u = {
        width: c,
        height: d
    }, e[0] = c, e[1] = d, e[2] = u) : u = e[2];
    const f = u;
    let h;
    e[3] === Symbol.for("react.memo_cache_sentinel") ? (h = W("grid grid-flow-dense grid-cols-3 grid-rows-2 gap-1", nu), e[3] = h) : h = e[3];
    const m = "".concat(l.width, "/").concat(l.height);
    let b;
    e[4] !== m ? (b = {
        aspectRatio: m
    }, e[4] = m, e[5] = b) : b = e[5];
    let y;
    e[6] !== o || e[7] !== s || e[8] !== f || e[9] !== n ? (y = s.map((w, C) => {
        var k;
        if (C >= 3) return null;
        const g = C === Math.min(3, s.length) - 1 && s.length > 3;
        return a.jsx(Ps, {
            image: (k = w.image_result) != null ? k : void 0,
            imageSource: hn.ImageGroup,
            className: W("border-token-border-default h-full w-full border-[0.5px]", C === 0 && "col-span-2 row-span-2", xb(C)),
            badge: g ? a.jsx(su, {
                numImages: s.length
            }) : void 0,
            lightboxImages: s.map(_b).filter(wb),
            aspectRatio: f,
            trackContentReferenceEvent: n,
            eventMetadata: {
                imageUse: "imageGroup",
                layout: "bento"
            },
            analyticsMetadata: o,
            contentReferenceType: "image_group"
        }, bb(w, C))
    }), e[6] = o, e[7] = s, e[8] = f, e[9] = n, e[10] = y) : y = e[10];
    let p;
    return e[11] !== b || e[12] !== y ? (p = a.jsx("div", {
        className: h,
        style: b,
        children: y
    }), e[11] = b, e[12] = y, e[13] = p) : p = e[13], p
}

function wb(t) {
    return !!t
}

function _b(t) {
    return t.image_result
}
const ca = (t, e) => t.images.length === e.images.length && t.analyticsMetadata === e.analyticsMetadata && t.trackContentReferenceEvent === e.trackContentReferenceEvent && t.images.every((s, n) => {
        var o, r;
        return ((o = s.image_result) == null ? void 0 : o.content_url) === ((r = e.images[n].image_result) == null ? void 0 : r.content_url)
    }),
    vb = x.memo(yb, ca),
    kb = 3,
    fi = {
        width: 5,
        height: 4
    };

function Sb(t) {
    "use forget";
    var b;
    const e = xe.c(23),
        {
            images: s,
            analyticsMetadata: n,
            trackContentReferenceEvent: o,
            isReferenceComplete: r
        } = t,
        i = Zn(),
        l = s.length;
    let c;
    e[0] !== s ? (c = s.map(jb).filter(Eb), e[0] = s, e[1] = c) : c = e[1];
    const d = c;
    if (l === 0) return null;
    if (l === 1) {
        const y = s[0];
        if (!y.image_result && !r) return null;
        let p;
        e[2] === Symbol.for("react.memo_cache_sentinel") ? (p = a.jsx("span", {
            "aria-hidden": !0,
            className: "clear-both m-0 block h-0 p-0"
        }), e[2] = p) : p = e[2];
        const w = (b = y == null ? void 0 : y.image_result) != null ? b : void 0;
        let C;
        e[3] === Symbol.for("react.memo_cache_sentinel") ? (C = {
            imageUse: "imageGroup",
            layout: "single"
        }, e[3] = C) : C = e[3];
        let v;
        return e[4] !== n || e[5] !== w || e[6] !== o ? (v = a.jsxs(a.Fragment, {
            children: [p, a.jsx(Ps, {
                image: w,
                imageSource: hn.ImageGroup,
                analyticsMetadata: n,
                trackContentReferenceEvent: o,
                eventMetadata: C,
                aspectRatio: Qo,
                className: "float-image border-token-border-default float-end clear-end ms-7 mt-1 mb-7 w-[22%] min-w-32 overflow-hidden rounded-xl border-[0.5px]",
                contentReferenceType: "image_group"
            })]
        }), e[4] = n, e[5] = w, e[6] = o, e[7] = v) : v = e[7], v
    }
    const u = i ? s.length : Math.min(s.length, kb);
    let f;
    e[8] === Symbol.for("react.memo_cache_sentinel") ? (f = W("no-scrollbar flex min-h-36 flex-nowrap gap-0.5 overflow-auto sm:gap-1 sm:overflow-hidden xl:min-h-44", nu), e[8] = f) : f = e[8];
    let h;
    if (e[9] !== n || e[10] !== d || e[11] !== s || e[12] !== u || e[13] !== o) {
        let y;
        e[15] !== n || e[16] !== d || e[17] !== s.length || e[18] !== u || e[19] !== o ? (y = (p, w) => {
            var v, g, k;
            const C = w === u - 1;
            return a.jsx("div", {
                className: W("border-token-border-default relative w-32 shrink-0 overflow-hidden rounded-xl border-[0.5px] md:shrink", "max-h-64 sm:w-[calc((100%-0.5rem)/3)]", w === 0 && "rounded-s-xl", C && "rounded-e-xl"),
                style: {
                    aspectRatio: "".concat(fi.width, "/").concat(fi.height)
                },
                children: a.jsx(Ps, {
                    image: (v = p.image_result) != null ? v : void 0,
                    imageSource: hn.ImageGroup,
                    lightboxImages: d,
                    analyticsMetadata: n,
                    trackContentReferenceEvent: o,
                    eventMetadata: {
                        imageUse: "imageGroup",
                        layout: "carousel"
                    },
                    className: "h-full w-full",
                    badge: C && s.length > u && a.jsx(su, {
                        numImages: s.length
                    }),
                    aspectRatio: fi,
                    contentReferenceType: "image_group"
                })
            }, (k = (g = p.image_result) == null ? void 0 : g.thumbnail_url) != null ? k : "".concat(p.image_search_query, "-").concat(p.image_ref_id, "-").concat(w))
        }, e[15] = n, e[16] = d, e[17] = s.length, e[18] = u, e[19] = o, e[20] = y) : y = e[20], h = s.slice(0, u).map(y), e[9] = n, e[10] = d, e[11] = s, e[12] = u, e[13] = o, e[14] = h
    } else h = e[14];
    let m;
    return e[21] !== h ? (m = a.jsx("div", {
        className: f,
        children: h
    }), e[21] = h, e[22] = m) : m = e[22], m
}

function Eb(t) {
    return !!t
}

function jb(t) {
    return t.image_result
}
const Mb = x.memo(Sb, ca);

function Cb(t) {
    "use forget";
    var w;
    const e = xe.c(14),
        {
            images: s,
            analyticsMetadata: n,
            trackContentReferenceEvent: o
        } = t,
        r = pd();
    let i;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (i = {
        track: "height"
    }, e[0] = i) : i = e[0];
    const [l, c] = wh(i), d = (w = l == null ? void 0 : l.height) != null ? w : -1, u = r == null ? void 0 : r.onFullWidthImageHeightChange;
    let f, h;
    e[1] !== u || e[2] !== d ? (f = () => {
        !u || d == null || u(d)
    }, h = [u, d], e[1] = u, e[2] = d, e[3] = f, e[4] = h) : (f = e[3], h = e[4]), x.useEffect(f, h);
    let m;
    e[5] !== n || e[6] !== s || e[7] !== o ? (m = s.map(C => {
        var v;
        return {
            content: a.jsx(Ps, {
                image: (v = C.image_result) != null ? v : void 0,
                imageSource: hn.ImageGroup,
                aspectRatio: null,
                enableHoverAnimation: !1,
                analyticsMetadata: n,
                trackContentReferenceEvent: o,
                skeletonEl: a.jsx("div", {
                    className: "bg-tertiary aspect-[5/4] h-full w-full animate-pulse"
                }),
                lightboxImages: s.map(Ib).filter(Tb),
                className: "h-full w-full",
                contentReferenceType: "image_group",
                fadeInOnMount: !0
            })
        }
    }), e[5] = n, e[6] = s, e[7] = o, e[8] = m) : m = e[8];
    const b = m;
    let y;
    e[9] !== b ? (y = a.jsx(fb, {
        images: b,
        aspect: "aspect-[5/4]",
        showDots: !0
    }), e[9] = b, e[10] = y) : y = e[10];
    let p;
    return e[11] !== c || e[12] !== y ? (p = a.jsx("div", {
        ref: c,
        className: "-mx-6 mt-[calc(-1rem-3px)] pb-5",
        children: y
    }), e[11] = c, e[12] = y, e[13] = p) : p = e[13], p
}

function Tb(t) {
    return !!t
}

function Ib(t) {
    return t.image_result
}
const Nb = x.memo(Cb, ca),
    Pb = 200,
    Rb = 100,
    Ko = Tn({
        id: "imagePill.screenshot",
        defaultMessage: "screenshot"
    }),
    ou = "m-0 p-[2px] pe-1",
    $b = W(ou, "h-full rounded-lg object-contain"),
    Ab = W(ou, "p-[4px]");

function Nl({
    image: t
}) {
    const [e, s] = x.useState(!1), n = zi.useStore(), o = x.useRef(null), r = x.useRef(null), i = Ne(), l = t == null ? void 0 : t.content_url, c = x.useMemo(() => l ? Ar(l, "hostname") : null, [l]), d = x.useCallback(() => {
        o.current && clearTimeout(o.current)
    }, []), u = x.useCallback(() => {
        t && (d(), s(!1), n.setCurrentImage({
            image: t
        }))
    }, [n, t, d]), f = x.useCallback(() => {
        r.current && clearTimeout(r.current)
    }, []), h = x.useCallback(() => {
        s(!1)
    }, [s]), m = x.useCallback(p => {
        p.stopPropagation(), f(), o.current = setTimeout(() => {
            s(!0)
        }, Pb)
    }, [f]), b = x.useCallback(p => {
        p.stopPropagation(), d(), r.current = setTimeout(() => {
            h()
        }, Rb)
    }, [d, h]);
    x.useEffect(() => {
        e && f()
    }, [e, f]);
    const y = x.useMemo(() => ({
        onBlur: b,
        onMouseLeave: b,
        onMouseEnter: m,
        onFocus: m
    }), [b, m]);
    return t ? a.jsxs("span", ce(F({
        onClick: u,
        className: "relative"
    }, y), {
        children: [a.jsxs(Pl, {
            isOpen: e,
            children: [a.jsx("img", {
                className: $b,
                src: t.thumbnail_url
            }), a.jsx("span", {
                children: c != null ? c : i.formatMessage(Ko)
            })]
        }), e && a.jsx("div", {
            className: "absolute start-0 z-50",
            children: a.jsxs("div", ce(F({
                className: W("text-token-text-secondary border-token-border-light w-[256px] cursor-pointer px-3 pt-2 pb-3 text-sm shadow-md outline-[0.5px] outline-black/5", Af)
            }, y), {
                children: [a.jsxs(Ds, {
                    href: t.content_url,
                    target: "_blank",
                    rel: "noopener",
                    className: "z-50 mb-2 flex items-center gap-2 hover:opacity-70",
                    onClick: p => p.stopPropagation(),
                    children: [a.jsx(Jo, {
                        url: t.content_url,
                        className: "m-0 size-4 p-0",
                        size: 32
                    }), c != null ? c : i.formatMessage(Ko)]
                }), a.jsx("img", {
                    className: "border-token-border-light m-0 cursor-pointer rounded-lg object-contain p-0 outline-[0.5px] outline-black/5",
                    src: t.thumbnail_url,
                    alt: c != null ? c : i.formatMessage(Ko),
                    onClick: p => {
                        p.preventDefault(), u()
                    }
                })]
            }))
        })]
    })) : a.jsxs(Pl, {
        isOpen: !1,
        children: [a.jsx("span", {
            className: Ab,
            children: a.jsx(_n, {})
        }), a.jsx("span", {
            children: c != null ? c : i.formatMessage(Ko)
        })]
    })
}

function Pl(n) {
    var o = n,
        {
            children: t,
            isOpen: e
        } = o,
        s = Bt(o, ["children", "isOpen"]);
    return a.jsx("span", ce(F({
        className: W("ms-1 cursor-pointer", "inline-flex max-w-full items-center", "relative top-[0.2rem]", "animate-[show_150ms_ease-in]")
    }, s), {
        children: a.jsx("span", {
            className: W("text-token-text-secondary flex h-4.5 overflow-hidden rounded-xl bg-[#F4F4F4] pe-2 text-[0.5625em] font-medium dark:bg-[#303030]", "hover:bg-token-text-primary! hover:text-token-text-inverted", e && "bg-token-main-surface-tertiary text-token-text-secondary", "transition-colors duration-150 ease-in-out", "items-center justify-center"),
            children: t
        })
    }))
}
async function Lb({
    conversationId: t,
    messageId: e,
    assetPointerLinks: s,
    sharedConversationLikeId: n
}) {
    return await vn.safePost("/conversation/get_images_for_message", {
        requestBody: {
            conversation_id: t != null ? t : null,
            share_id: n != null ? n : null,
            message_id: e,
            asset_pointer_links: s
        },
        authOption: Mr.SendIfAvailable
    })
}

function Db({
    reference: t,
    conversationId: e,
    messageId: s,
    sharedConversationLikeId: n,
    isN7jupdMessage: o
}) {
    return $c(F({
        queryKey: ["inline-images", t, e, s],
        queryFn: async () => {
            if (!t.asset_pointer_links || t.asset_pointer_links.length === 0 || !e && !n) return {
                images: [],
                formats: []
            };
            const i = await Lb({
                conversationId: e,
                messageId: s,
                assetPointerLinks: t.asset_pointer_links,
                sharedConversationLikeId: n
            });
            for (let l = 0; l < i.images.length; l++) {
                const c = i.images[l],
                    d = i.formats[l],
                    u = "image/".concat(d),
                    f = Ob(c, u);
                i.images[l] = f
            }
            return i
        }
    }, o ? {
        retry: 3,
        retryDelay: 5e3
    } : {}))
}

function Ob(t, e = "", s = 512) {
    const n = atob(t),
        o = [];
    for (let i = 0; i < n.length; i += s) {
        const l = n.slice(i, i + s),
            c = new Array(l.length);
        for (let u = 0; u < l.length; u++) c[u] = l.charCodeAt(u);
        const d = new Uint8Array(c);
        o.push(d)
    }
    const r = new Blob(o, {
        type: e
    });
    return URL.createObjectURL(r)
}
const Fb = 200;

function Bb({
    reference: t,
    clientThreadId: e,
    message: s,
    trackContentReferenceEvent: n
}) {
    var h;
    const o = Jn(e),
        {
            postId: r
        } = x.useContext(_h),
        {
            data: i,
            isLoading: l,
            isError: c,
            error: d
        } = Db({
            reference: t,
            conversationId: o,
            messageId: s.id,
            sharedConversationLikeId: r,
            isN7jupdMessage: (h = s.metadata) == null ? void 0 : h.n7jupd_message
        }),
        u = x.useRef([]);
    x.useEffect(() => () => {
        u.current.forEach(m => {
            URL.revokeObjectURL(m)
        }), u.current = []
    }, []);
    const f = ru(s, t);
    return d || c || i && !("images" in i) || l || !(i != null && i.images.length) ? null : (u.current = [], a.jsx(a.Fragment, {
        children: i == null ? void 0 : i.images.map((m, b) => {
            const y = iu(t, m, f);
            return a.jsx(la, {
                metadata: y,
                analyticsMetadata: {
                    clientThreadId: e,
                    messageId: s.id
                },
                numImageResults: 1,
                trackContentReferenceEvent: n
            }, "image-carousel-inline-".concat(b))
        })
    }))
}
const Wb = (t, e) => {
    const s = new RegExp(e + "\\s*([^\\n]+)", "m"),
        n = t.match(s);
    return n && n[1] ? n[1].trim().length : 0
};

function ru(t, e) {
    return x.useMemo(() => {
        let s = -1;
        return t.content.content_type === "text" && (s = Wb(t.content.parts.join(""), e.matched_text)), s < Fb || s === -1
    }, [t, e.matched_text])
}

function iu(t, e, s) {
    var n, o, r;
    return {
        matched_text: t.matched_text,
        start_idx: t.start_idx,
        end_idx: t.end_idx,
        safe_urls: t.safe_urls,
        alt: t.alt,
        prompt_text: t.prompt_text,
        type: "image_v2",
        refs: [],
        images: [{
            url: e,
            content_url: (n = t.clicked_from_url) != null ? n : "",
            thumbnail_url: e,
            title: (o = t.clicked_from_title) != null ? o : "",
            attribution: Ar((r = t.clicked_from_url) != null ? r : e, "hostname"),
            content_size: {
                width: Rl,
                height: $l
            },
            thumbnail_size: {
                width: Rl,
                height: $l
            },
            is_proxied_image: !0,
            float_top: s
        }]
    }
}
const Rl = 141,
    $l = 143;

function zb({
    reference: t,
    clientThreadId: e,
    message: s,
    trackContentReferenceEvent: n
}) {
    var m, b, y, p, w;
    const o = ((m = s.metadata) == null ? void 0 : m.n7jupd_message) && t.matched_text.includes("screenshot"),
        r = Jn(e),
        i = (y = (b = x.useContext(Lf)) == null ? void 0 : b.serverSharedThreadId) != null ? y : void 0,
        l = vh(t.asset_pointer_links[0]),
        c = x.useMemo(() => ({
            content_type: Ac.ImageAssetPointer,
            size_bytes: 0,
            width: 0,
            height: 0,
            asset_pointer: l
        }), [l]),
        d = id({
            asset: c,
            sharedThreadId: i,
            conversationId: r
        }),
        u = (p = d.data) == null ? void 0 : p.url,
        f = ru(s, t),
        h = x.useMemo(() => u ? iu(t, u, f) : null, [u, t, f]);
    return d.error || d.isError ? null : o && !((w = d.data) != null && w.url) && d.isLoading ? a.jsx(Nl, {
        image: null
    }, "image-pill-loading") : !o && (d.isLoading || !d.data) || !h ? null : o ? a.jsx(Nl, {
        image: h.images[0]
    }) : a.jsx(la, {
        metadata: h,
        analyticsMetadata: {
            clientThreadId: e,
            messageId: s.id
        },
        numImageResults: 1,
        trackContentReferenceEvent: n
    })
}
const xs = {
        TTFP: "products.ttfp",
        TTLT: "products.ttlt",
        TTF_VISIBLE_CONTENT_TOKEN: "products.ttf_visible_content_token"
    },
    da = {
        [xs.TTFP]: new Set,
        [xs.TTLT]: new Set,
        [xs.TTF_VISIBLE_CONTENT_TOKEN]: new Set
    };

function mi({
    profiler: t,
    messageId: e,
    metric: s,
    overrideDurationMs: n
}) {
    da[s].add(e);
    const o = jh();
    t.logTimingOnce(s, {
        context: {
            eval_preset: o.eval_preset
        },
        overrideDurationMs: n
    })
}

function hi({
    messageId: t,
    metric: e
}) {
    return da[e].has(t)
}

function au(t) {
    "use forget";
    const e = xe.c(27),
        {
            clientThreadId: s,
            messageId: n,
            products: o
        } = t;
    let r;
    e[0] !== n ? (r = g => [fs.getRequestId(g), fs.isMessageTurnEnded(g, n)], e[0] = n, e[1] = r) : r = e[1];
    const [i, l] = Ls(s, r);
    let c;
    e[2] !== s ? (c = {
        namespace: Eh.ProductsCompletionRequest,
        clientThreadId: s
    }, e[2] = s, e[3] = c) : c = e[3];
    const {
        profiler: d,
        isRequestActive: u
    } = kh(c), f = u && !l, h = Sh(f);
    let m, b;
    e[4] !== f || e[5] !== n || e[6] !== o.length || e[7] !== d ? (m = () => {
        hi({
            messageId: n,
            metric: xs.TTFP
        }) || d && f && o.length > 0 && mi({
            profiler: d,
            messageId: n,
            metric: xs.TTFP
        })
    }, b = [f, n, o.length, d], e[4] = f, e[5] = n, e[6] = o.length, e[7] = d, e[8] = m, e[9] = b) : (m = e[8], b = e[9]), x.useEffect(m, b);
    let y, p;
    e[10] !== f || e[11] !== n || e[12] !== h || e[13] !== d ? (y = () => {
        hi({
            messageId: n,
            metric: xs.TTLT
        }) || d && h.current && !f && mi({
            profiler: d,
            messageId: n,
            metric: xs.TTLT
        })
    }, p = [n, h, f, d], e[10] = f, e[11] = n, e[12] = h, e[13] = d, e[14] = y, e[15] = p) : (y = e[14], p = e[15]), x.useEffect(y, p);
    const w = et();
    let C;
    e[16] !== w || e[17] !== n || e[18] !== d || e[19] !== i ? (C = () => {
        if (hi({
                messageId: n,
                metric: xs.TTF_VISIBLE_CONTENT_TOKEN
            })) return;
        const g = i ? Df(w, i) : null;
        if (d && g) {
            const k = xs.TTF_VISIBLE_CONTENT_TOKEN;
            da[k].add(n), mi({
                profiler: d,
                messageId: n,
                metric: k,
                overrideDurationMs: g.turnTracker.first_visible_content_token_lat
            })
        }
    }, e[16] = w, e[17] = n, e[18] = d, e[19] = i, e[20] = C) : C = e[20];
    let v;
    e[21] !== w || e[22] !== n || e[23] !== o.length || e[24] !== d || e[25] !== i ? (v = [n, d, i, o.length, w], e[21] = w, e[22] = n, e[23] = o.length, e[24] = d, e[25] = i, e[26] = v) : v = e[26], x.useEffect(C, v)
}

function Hb({
    contentReference: t,
    clientThreadId: e,
    messageId: s,
    turnIndex: n,
    trackContentReferenceEvent: o
}) {
    const r = x.useCallback(() => o("Search Content Reference Shown", "search_content_reference_shown", "product_entity", {
            content_reference_start_index: t.start_idx,
            product_id: t.product.id
        }), [o, t.start_idx, t.product.id]),
        i = x.useCallback(() => o("Search Content Reference Clicked", "search_content_reference_clicked", "product_entity", {
            content_reference_start_index: t.start_idx,
            product_id: t.product.id
        }), [o, t.start_idx, t.product.id]),
        l = t.product;
    x.useEffect(() => r(), [r]), au({
        clientThreadId: e,
        messageId: s,
        products: [l]
    });
    const {
        openThreadSidebar: c
    } = eo();
    return a.jsx("span", {
        className: "entity-underline hover:entity-accent inline cursor-pointer align-baseline",
        onClick: () => {
            if (i(), l.offers || !l.url) {
                if (!e) return;
                c({
                    type: "product",
                    messageId: s,
                    turnIndex: n,
                    contentReferenceStartIndex: t.start_idx,
                    productIndex: 0,
                    productId: l.id,
                    productUrl: l.url,
                    interactionSource: "inline_link"
                })
            } else window.open(l.url, "_blank")
        },
        children: a.jsx("span", {
            className: "whitespace-normal",
            children: l.title
        })
    })
}

function lu({
    items: t,
    targetItemCount: e,
    onCardRender: s,
    onCardShown: n,
    onCardClicked: o,
    onReplyClicked: r,
    allowFullWidth: i = !1,
    cardClassName: l,
    showGradient: c = !0,
    arrowClassName: d
}) {
    const u = Bc(),
        f = x.useRef(null),
        h = Rt(() => Fc(u)),
        [m, b] = x.useState(null),
        y = x.useRef(null),
        p = () => {
            y.current = setTimeout(() => {
                b(null), y.current = null
            }, 200)
        },
        w = () => {
            y.current && (clearTimeout(y.current), y.current = null)
        },
        C = x.useRef(null),
        [v, g] = x.useState({
            left: 0,
            top: 0
        }),
        k = 8;
    x.useEffect(() => {
        const N = f.current,
            I = C.current;
        if (!r || !m || !N || !I) return;
        const _ = () => {
            const R = m.card.getBoundingClientRect(),
                A = N.getBoundingClientRect(),
                $ = I.getBoundingClientRect(),
                P = R.bottom - A.top + k;
            var U = R.left - A.left;
            U = Math.max(0, U), U = Math.min(U, A.width - $.width), g({
                left: U,
                top: P
            })
        };
        return _(), N.addEventListener("scroll", _), () => N.removeEventListener("scroll", _)
    }, [m, t, r]);
    const E = Zn(),
        j = E ? 2 : 4;
    if (e === void 0) e = t.length;
    else if (!e && t.length < j) return null;
    const M = (e != null ? e : t.length) >= j,
        T = M && E;
    return a.jsxs("div", {
        className: "relative",
        children: [a.jsx("div", {
            ref: f,
            className: W("flex flex-row gap-4 py-2", T && "mx-[-1rem] px-[1rem]", M && "no-scrollbar snap-x snap-mandatory overflow-x-scroll scroll-smooth"),
            children: t.map((N, I) => a.jsx("div", {
                className: W(M || !i ? h ? "xs:basis-[calc((100%-2rem)/3)] shrink-0 basis-[calc((100%-2rem)/2)]" : "shrink-0 basis-[calc((100%-2rem)/3)] snap-start" : "min-w-0 flex-1"),
                children: a.jsx(Ub, {
                    cardClassName: W(l, h && "bg-transparent"),
                    onShown: () => n(N, I),
                    onClick: () => o(N, I),
                    onHover: _ => {
                        w(), _ ? b({
                            card: _,
                            item: N,
                            index: I
                        }) : p()
                    },
                    children: s(N, !E && e === 1)
                })
            }, I))
        }), M && !T && a.jsx(Gb, {
            scrollableRef: f,
            units: t.length,
            showGradient: c,
            arrowClassName: d
        }), r && a.jsx("div", {
            ref: C,
            className: W("absolute z-10", m ? "pointer-events-auto opacity-100" : "pointer-events-none opacity-0", "transition-[transform,opacity] duration-200"),
            style: {
                willChange: "opacity, transform",
                left: v.left,
                top: v.top,
                transform: m ? "translateY(0)" : "translateY(".concat(-k, "px)")
            },
            onMouseEnter: w,
            onMouseLeave: p,
            children: a.jsx(us, {
                className: W(m ? "pointer-events-auto" : "pointer-events-none", "border-light bg-clip-padding px-4 py-2 shadow-md"),
                size: "small",
                color: "secondary",
                onClick: () => m && r(m.item, m.index),
                children: a.jsxs("div", {
                    className: "flex flex-row items-center gap-1",
                    children: [a.jsx(tp, {
                        className: "icon-sm text-token-text-secondary"
                    }), a.jsx(me, {
                        id: "9TG7OR",
                        defaultMessage: "Ask about this"
                    })]
                })
            })
        })]
    })
}

function Ub({
    onShown: t,
    onClick: e,
    onHover: s,
    children: n,
    cardClassName: o
}) {
    const r = x.useRef(null),
        i = x.useRef(t);
    return x.useEffect(() => {
        i.current = t
    }, [t]), x.useEffect(() => {
        if (!r.current) return;
        const l = new IntersectionObserver(([c]) => c.isIntersecting && i.current(), {
            threshold: .5
        });
        return l.observe(r.current), () => l.disconnect()
    }, []), a.jsx("div", {
        ref: r,
        className: W("h-full w-full", "bg-token-bg-primary cursor-pointer", o),
        onClick: e,
        onMouseEnter: () => r.current && s(r.current),
        onMouseLeave: () => s(null),
        children: n
    })
}

function Gb({
    scrollableRef: t,
    units: e,
    showGradient: s,
    arrowClassName: n
}) {
    const [o, r] = x.useState({
        left: !1,
        right: !1
    }), [i, l] = x.useState(!1);
    x.useEffect(() => {
        const d = t.current;
        if (!d) return;
        const u = () => {
            const {
                scrollLeft: f,
                scrollWidth: h,
                clientWidth: m
            } = d, b = f / (h - m);
            r({
                left: b > 0,
                right: b < .99
            }), !i && f > 0 && l(!0)
        };
        return u(), d.addEventListener("scroll", u), () => d.removeEventListener("scroll", u)
    }, [t, e, i]);
    const c = d => {
        const u = t.current;
        if (!u) return;
        l(!0);
        const {
            clientWidth: f,
            scrollWidth: h,
            scrollLeft: m
        } = u, b = Math.max(0, h - f), y = Math.max(0, Math.min(b, m + d * f));
        u.scrollTo({
            left: y,
            behavior: "smooth"
        })
    };
    return a.jsxs("div", {
        className: "pointer-events-none absolute start-0 top-0 flex h-full w-full flex-row",
        children: [a.jsx("div", {
            className: W("flex h-full w-9 items-center justify-start", i && s && "bg-linear-to-r from-(--bg-primary) to-transparent", o.left ? "opacity-100" : "opacity-0", "transition-opacity duration-100"),
            children: a.jsx(us, {
                color: "secondary",
                size: "small",
                className: W("border-token-border-default active:bg-token-bg-tertiary hover:bg-token-bg-primary h-8 w-8 translate-x-[-50%] rounded-full bg-clip-padding hover:shadow-[0px_4px_16px_0px_rgba(0,0,0,0.05)] active:opacity-100!", n),
                onClick: () => c(-1),
                children: a.jsx(Oc, {
                    className: "icon"
                })
            })
        }), a.jsx("div", {
            className: W("ms-auto flex h-full w-9 items-center justify-end", i && s && "bg-linear-to-l from-(--bg-primary) to-transparent", o.right ? "opacity-100" : "opacity-0", "transition-opacity duration-200"),
            children: a.jsx(us, {
                color: "secondary",
                size: "small",
                className: W("border-token-border-default active:bg-token-bg-tertiary hover:bg-token-bg-primary h-8 w-8 translate-x-[50%] rounded-full bg-clip-padding hover:shadow-[0px_4px_16px_0px_rgba(0,0,0,0.05)] active:opacity-100!", n),
                onClick: () => c(1),
                children: a.jsx(Hi, {
                    className: "icon"
                })
            })
        })]
    })
}

function qb({
    contentReference: t,
    clientThreadId: e,
    messageId: s,
    turnIndex: n,
    analyticsMetadata: o
}) {
    const r = t.products,
        i = t.target_product_count;
    au({
        clientThreadId: e,
        messageId: s,
        products: r
    });
    const {
        showDebugConversationTurns: l
    } = Of(), c = Ls(e, g => {
        var j, M;
        const E = (M = (j = fs.getNode(g, s).message.metadata) == null ? void 0 : j.content_references) == null ? void 0 : M.find(T => T.type === "products");
        return t.start_idx === (E == null ? void 0 : E.start_idx)
    }), d = et(), u = at(d, "3144771298"), f = at(d, "2212894775"), h = ld(o), m = x.useCallback((g, k) => h("Search Content Reference Shown", "search_content_reference_shown", "products", {
        content_reference_start_index: t.start_idx,
        product_index: k,
        product_id: g.id,
        product_url: g.url
    }), [h, t.start_idx]), b = x.useCallback((g, k) => h("Search Content Reference Clicked", "search_content_reference_clicked", "products", {
        content_reference_start_index: t.start_idx,
        product_index: k,
        product_id: g.id
    }), [h, t.start_idx]), y = Mh(d), {
        openThreadSidebar: p
    } = eo(), w = (g, k) => {
        if (e)
            if (b(g, k), g.offers) {
                const E = Th(),
                    j = E ? y.rooms$().get(E) : null,
                    M = {
                        type: "product",
                        messageId: s,
                        turnIndex: n,
                        contentReferenceStartIndex: t.start_idx,
                        productIndex: k,
                        productId: g.id,
                        productUrl: g.url,
                        interactionSource: "carousel"
                    };
                j != null ? y.hasAccess && y.openThreadSidebar$(j, M) : p(M)
            } else window.open(g.url, "_blank")
    }, {
        setTargetedContent: C
    } = Ch(), v = (g, k) => {
        Xe.logEventWithStatsig("Product Targeted Reply Clicked", "product_targeted_reply_clicked", ce(F({}, Cr(o)), {
            content_reference_start_index: t.start_idx,
            product_index: (k + 1).toString(),
            product_id: g.id
        })), C({
            type: "object",
            label: g.title,
            createNewCompletionParams: E => {
                var M;
                const j = Ff(g.title);
                return ce(F({}, E), {
                    promptMessage: Ih(E.promptMessage, {
                        metadata: {
                            targeted_reply: g.title,
                            targeted_reply_label: g.title,
                            targeted_reply_icon: "product_tag"
                        }
                    }),
                    appendMessages: [...(M = E.appendMessages) != null ? M : [], j]
                })
            },
            onCreateCompletion: ({
                serverThreadId: E,
                currentLeafId: j
            }) => {
                Xe.logEventWithStatsig("Targeted Reply Submitted", "chatgpt_targeted_reply_submitted", {
                    conversation_id: E,
                    current_leaf_id: j,
                    source_message_id: s,
                    content_reference_start_index: t.start_idx,
                    product_index: (k + 1).toString(),
                    product_id: g.id
                })
            },
            onCleared: ({
                serverThreadId: E,
                currentLeafId: j
            }) => {
                Xe.logEventWithStatsig("Targeted Reply Cleared", "chatgpt_targeted_reply_cleared", {
                    conversation_id: E,
                    current_leaf_id: j,
                    source_message_id: s,
                    content_reference_start_index: t.start_idx,
                    product_index: (k + 1).toString(),
                    product_id: g.id
                })
            }
        })
    };
    if (t.inline_carousel && r.length === 1) {
        const g = r[0];
        return a.jsx("div", {
            className: "flex flex-col",
            "data-testid": "shopping-widget",
            children: a.jsx(Zb, {
                product: g,
                showDebug: l,
                onShown: () => m(g, 0),
                onClicked: () => w(g, 0)
            })
        })
    }
    return a.jsxs("div", {
        className: "flex flex-col",
        "data-testid": "products-widget",
        children: [a.jsx(lu, {
            items: r,
            targetItemCount: i,
            onCardRender: (g, k) => a.jsx(Vb, {
                product: g,
                wide: k,
                showDebug: l,
                isProductV2CardEnabled: f
            }),
            onCardShown: m,
            onCardClicked: w,
            onReplyClicked: f ? void 0 : v,
            arrowClassName: f ? "translate-y-[-85%]" : "",
            allowFullWidth: !0,
            showGradient: !f,
            cardClassName: W(f ? "group" : "transition-all duration-200 border-token-border-default hover:border-light border rounded-xl bg-clip-padding hover:shadow-md overflow-hidden")
        }), c && u && !f && a.jsxs("div", {
            className: "text-token-text-tertiary flex text-xs hover:cursor-pointer hover:underline",
            onClick: () => window.open("https://help.openai.com/en/articles/11128490", "_blank"),
            children: [a.jsx(me, {
                id: "4Y5Zn5",
                defaultMessage: "ChatGPT chooses products independently. Learn more"
            }), a.jsx(Hi, {
                className: "icon -ms-0.5"
            })]
        }), !1]
    })
}

function Vb(t) {
    "use forget";
    const e = xe.c(5),
        {
            product: s,
            wide: n,
            showDebug: o,
            isProductV2CardEnabled: r
        } = t,
        i = o === void 0 ? !1 : o;
    let l;
    return e[0] !== r || e[1] !== s || e[2] !== i || e[3] !== n ? (l = r ? a.jsx(Xb, {
        product: s,
        wide: n,
        showDebug: i
    }) : a.jsx(Kb, {
        product: s,
        wide: n,
        showDebug: i
    }), e[0] = r, e[1] = s, e[2] = i, e[3] = n, e[4] = l) : l = e[4], l
}

function Kb({
    product: t,
    wide: e,
    showDebug: s = !1
}) {
    var l, c;
    const n = t.image_urls ? t.image_urls[0] : void 0,
        [o, r] = x.useState("contain"),
        i = x.useRef(null);
    return a.jsxs("div", {
        className: W("flex", e ? "flex-row" : "flex-col"),
        children: [a.jsxs("div", {
            className: W("relative aspect-square", e ? "w-1/3" : "w-full", "bg-token-main-surface-secondary dark:bg-token-main-surface-primary-inverse"),
            children: [n ? a.jsx("img", {
                ref: i,
                className: "absolute inset-0 m-0 h-full w-full mix-blend-darken object-".concat(o),
                src: n,
                alt: t.title,
                onLoad: () => {
                    if (!i.current) return;
                    const {
                        naturalWidth: d,
                        naturalHeight: u
                    } = i.current, f = d / u;
                    r(Math.abs(f - 1) < .25 ? "cover" : "contain")
                }
            }) : a.jsx("div", {
                className: "flex aspect-square items-center justify-center",
                children: a.jsx(Ir, {
                    className: "text-token-text-tertiary h-12 w-12"
                })
            }), t.featured_tag && a.jsx("div", {
                className: "absolute start-3 end-3 bottom-3",
                children: a.jsxs("div", {
                    className: "relative max-w-fit px-2 py-1",
                    children: [a.jsx("div", {
                        className: "absolute inset-0 rounded-full bg-white/60 backdrop-blur-xl"
                    }), a.jsx("div", {
                        className: "relative truncate text-xs font-semibold text-gray-950",
                        children: t.featured_tag
                    })]
                })
            })]
        }), a.jsxs("div", {
            className: "flex flex-1 flex-col p-4",
            children: [a.jsx("div", {
                className: "line-clamp-2 leading-snug font-semibold text-ellipsis",
                children: t.title
            }), t.description && a.jsx("div", {
                className: "line-clamp-3 pt-3 text-sm text-ellipsis",
                children: t.description
            }), a.jsx("div", {
                className: "flex-1"
            }), a.jsxs("div", {
                className: "flex flex-row items-end pt-3",
                children: [a.jsxs("div", {
                    className: "flex flex-col overflow-hidden",
                    children: [a.jsx("div", {
                        className: "text-md leading-snug font-semibold",
                        children: t.price
                    }), a.jsx("div", {
                        className: "text-token-text-secondary overflow-hidden pt-0.5 text-xs text-ellipsis whitespace-nowrap",
                        children: t.merchants
                    })]
                }), a.jsx("div", {
                    className: "flex-1"
                }), t.num_reviews && t.num_reviews > 0 && a.jsxs("div", {
                    className: "text-token-text-secondary flex w-fit flex-row gap-1 text-sm",
                    children: [a.jsx(yg, {
                        rating: (l = t.rating) != null ? l : 0 / 5
                    }), ((c = t.rating) != null ? c : 0).toFixed(1)]
                })]
            }), !1]
        })]
    })
}

function Xb({
    product: t,
    wide: e,
    showDebug: s = !1
}) {
    const n = t.image_urls ? t.image_urls[0] : void 0,
        [o, r] = x.useState("contain"),
        [i, l] = x.useState("top"),
        c = x.useRef(null);
    return a.jsxs("div", {
        className: W("flex pb-2", e ? "flex-row gap-3" : "flex-col gap-2"),
        children: [a.jsx("div", {
            className: W("relative", e ? "aspect-square w-1/4" : "aspect-[13/16] w-full", "overflow-clip rounded-xl bg-[#F3F3F3] dark:bg-[#F3F3F3]"),
            children: a.jsx(gd, {
                className: "mix-blend-darken",
                children: n ? a.jsx("img", {
                    ref: c,
                    className: "absolute inset-0 m-0 h-full w-full object-".concat(o, " object-").concat(i),
                    src: n,
                    alt: t.title,
                    onLoad: () => {
                        if (!c.current) return;
                        const {
                            naturalWidth: d,
                            naturalHeight: u
                        } = c.current, f = d / u;
                        r(Math.abs(f - 1) < .4 ? "cover" : "contain"), l(u > d ? "top" : "center")
                    }
                }) : a.jsx("div", {
                    className: "flex aspect-square items-center justify-center",
                    children: a.jsx(Ir, {
                        className: "text-token-text-tertiary h-12 w-12"
                    })
                })
            })
        }), a.jsxs("div", {
            className: "flex flex-col gap-1 px-1",
            children: [a.jsx("div", {
                className: W("line-clamp-2 font-medium text-ellipsis", e ? "text-base" : "text-sm"),
                children: t.title
            }), a.jsxs("div", {
                className: "text-token-text-secondary flex flex-row gap-0.25 text-sm",
                children: [a.jsx("div", {
                    children: t.price
                }), a.jsx("div", {
                    className: "mx-0.5",
                    children: "•"
                }), a.jsx("div", {
                    className: "w-0 flex-1 truncate",
                    children: t.merchants
                })]
            }), !1]
        })]
    })
}

function Yb({
    className: t,
    imageUrl: e,
    productTitle: s,
    onClicked: n
}) {
    const [o, r] = x.useState("contain"), i = x.useRef(null);
    return a.jsx("div", {
        className: W(t, "hover:scale-[1.005]", "dark:bg-token-text-inverted bg-token-bg-primary", "cursor-pointer overflow-hidden rounded-xl shadow-inner transition-all duration-200", "relative aspect-square max-h-60"),
        onClick: n,
        children: e ? a.jsx("img", {
            ref: i,
            className: "m-0 h-full w-full overflow-hidden object-".concat(o, " mix-blend-darken"),
            src: e,
            alt: s,
            onLoad: () => {
                if (!i.current) return;
                const {
                    naturalWidth: l,
                    naturalHeight: c
                } = i.current, d = l / c;
                r(Math.abs(d - 1) < .5 ? "cover" : "contain")
            }
        }) : a.jsx("div", {
            className: "flex aspect-square items-center justify-center",
            children: a.jsx(Ir, {
                className: "text-token-text-tertiary h-12 w-12"
            })
        })
    })
}

function Zb({
    product: t,
    showDebug: e = !1,
    onShown: s,
    onClicked: n
}) {
    return x.useEffect(() => {
        s()
    }, [s]), a.jsxs(a.Fragment, {
        children: [a.jsx("div", {
            className: "flex flex-row gap-2 py-2",
            children: t.image_urls && t.image_urls.length > 0 && t.image_urls.slice(0, 3).map(o => a.jsx(Yb, {
                imageUrl: o,
                productTitle: t.title,
                onClicked: n
            }, o))
        }), !1]
    })
}
const bn = new Map,
    Jb = 256 * 256;

function Qb() {
    "use forget";
    const t = xe.c(2),
        [e, s] = x.useState(160);
    let n, o;
    return t[0] === Symbol.for("react.memo_cache_sentinel") ? (n = () => {
        if (typeof window > "u" || !window.matchMedia) return;
        const r = window.matchMedia("(min-width: 1024px)"),
            i = () => s(r.matches ? 200 : 160);
        i();
        try {
            return r.addEventListener("change", i), () => r.removeEventListener("change", i)
        } catch (l) {
            return r.addListener(i), () => {
                r.removeListener(i)
            }
        }
    }, o = [], t[0] = n, t[1] = o) : (n = t[0], o = t[1]), x.useEffect(n, o), e
}

function ey() {
    "use forget";
    const t = xe.c(2),
        [e, s] = x.useState(!1);
    let n, o;
    return t[0] === Symbol.for("react.memo_cache_sentinel") ? (n = () => {
        if (typeof window > "u" || !window.matchMedia) return;
        const r = window.matchMedia("(min-width: 1024px)"),
            i = () => s(r.matches);
        i();
        try {
            return r.addEventListener("change", i), () => r.removeEventListener("change", i)
        } catch (l) {
            return r.addListener(i), () => {
                r.removeListener(i)
            }
        }
    }, o = [], t[0] = n, t[1] = o) : (n = t[0], o = t[1]), x.useEffect(n, o), e
}

function ty() {
    "use forget";
    const t = xe.c(2),
        [e, s] = x.useState(!1);
    let n, o;
    return t[0] === Symbol.for("react.memo_cache_sentinel") ? (n = () => {
        if (typeof window > "u" || !window.matchMedia) return;
        const r = window.matchMedia("(max-width: 400px)"),
            i = () => s(r.matches);
        i();
        try {
            return r.addEventListener("change", i), () => r.removeEventListener("change", i)
        } catch (l) {
            return r.addListener(i), () => {
                r.removeListener(i)
            }
        }
    }, o = [], t[0] = n, t[1] = o) : (n = t[0], o = t[1]), x.useEffect(n, o), e
}

function sy(t, e, s) {
    let n = bn.get(t);
    if (n || (n = {
            widths: new Map,
            subs: new Set,
            anchorId: void 0,
            anchorWidth: void 0
        }, bn.set(t, n)), n.widths.set(e, s), !n.anchorId) {
        n.anchorId = e, n.anchorWidth = s;
        for (const o of n.subs) o(n.anchorWidth);
        return
    }
    if (n.anchorId === e && n.anchorWidth !== s) {
        n.anchorWidth = s;
        for (const o of n.subs) o(n.anchorWidth)
    }
}

function ny(t, e) {
    const s = bn.get(t);
    s && (s.widths.delete(e), s.anchorId === e && (s.anchorId = void 0), s.widths.size === 0 && bn.delete(t))
}

function oy(t, e) {
    let s = bn.get(t);
    return s || (s = {
        widths: new Map,
        subs: new Set,
        anchorId: void 0,
        anchorWidth: void 0
    }, bn.set(t, s)), s.subs.add(e), e(s.anchorWidth), () => {
        s == null || s.subs.delete(e)
    }
}

function ry(t) {
    "use forget";
    var ft, _t, Q, ae, _e, Ge, ze, Ve, De, tt, mt, vt, kt;
    const e = xe.c(114),
        {
            contentReference: s,
            clientThreadId: n,
            messageId: o,
            trackContentReferenceEvent: r,
            contentReferenceIndex: i,
            displayLayout: l
        } = t,
        c = et();
    let d;
    e[0] !== c ? (d = at(c, "3974614370"), e[0] = c, e[1] = d) : d = e[1];
    const u = d,
        f = Jn(n);
    let h;
    e[2] !== s.end_idx || e[3] !== s.product.id || e[4] !== s.product.merchants || e[5] !== s.product.price || e[6] !== s.product.title || e[7] !== s.product.url || e[8] !== s.render_as || e[9] !== s.start_idx || e[10] !== o || e[11] !== f || e[12] !== r ? (h = () => r("Shopping Content Reference Shown", "chatgpt_shopping_content_reference_shown", "product", {
        content_reference_start_index: s.start_idx,
        content_reference_end_index: s.end_idx,
        product_id: s.product.id,
        message_id: o,
        conversation_id: f,
        product_url: s.product.url,
        render_as: s.render_as,
        price: s.product.price,
        product_name: s.product.title,
        merchant_name: s.product.merchants
    }), e[2] = s.end_idx, e[3] = s.product.id, e[4] = s.product.merchants, e[5] = s.product.price, e[6] = s.product.title, e[7] = s.product.url, e[8] = s.render_as, e[9] = s.start_idx, e[10] = o, e[11] = f, e[12] = r, e[13] = h) : h = e[13];
    const m = Aa(h);
    let b;
    e[14] !== s.end_idx || e[15] !== s.product.id || e[16] !== s.product.merchants || e[17] !== s.product.price || e[18] !== s.product.title || e[19] !== s.product.url || e[20] !== s.render_as || e[21] !== s.start_idx || e[22] !== o || e[23] !== f || e[24] !== r ? (b = () => r("Shopping Content Reference Clicked", "chatgpt_shopping_content_reference_clicked", "product", {
        content_reference_start_index: s.start_idx,
        content_reference_end_index: s.end_idx,
        product_id: s.product.id,
        message_id: o,
        conversation_id: f,
        product_url: s.product.url,
        render_as: s.render_as,
        price: s.product.price,
        product_name: s.product.title,
        merchant_name: s.product.merchants
    }), e[14] = s.end_idx, e[15] = s.product.id, e[16] = s.product.merchants, e[17] = s.product.price, e[18] = s.product.title, e[19] = s.product.url, e[20] = s.render_as, e[21] = s.start_idx, e[22] = o, e[23] = f, e[24] = r, e[25] = b) : b = e[25];
    const y = Aa(b),
        p = s.product;
    let w, C;
    e[26] !== m ? (w = () => m(), C = [m], e[26] = m, e[27] = w, e[28] = C) : (w = e[27], C = e[28]), x.useEffect(w, C);
    const {
        openThreadSidebar: v
    } = eo();
    let g;
    e[29] !== s.start_idx || e[30] !== o || e[31] !== v || e[32] !== p || e[33] !== u || e[34] !== y ? (g = () => {
        y(), u ? v({
            type: "product_agent",
            messageId: o,
            product: p,
            contentReferenceStartIndex: s.start_idx,
            productIndex: 0,
            interactionSource: "deep_shop"
        }) : window.open(p.url, "_blank")
    }, e[29] = s.start_idx, e[30] = o, e[31] = v, e[32] = p, e[33] = u, e[34] = y, e[35] = g) : g = e[35];
    const k = g,
        E = (ft = p.image_urls) == null ? void 0 : ft[0],
        j = (_t = s.render_as) != null ? _t : "inline",
        M = j === "hero",
        [T, N] = x.useState(!0),
        I = M && T,
        _ = j === "table",
        R = l === "inline" && !_;
    let A;
    e[36] !== p.price ? (A = (Q = p.price) == null ? void 0 : Q.trim(), e[36] = p.price, e[37] = A) : A = e[37];
    const $ = A;
    let P;
    e[38] !== p.merchants ? (P = (ae = p.merchants) == null ? void 0 : ae.trim(), e[38] = p.merchants, e[39] = P) : P = e[39];
    const U = P,
        z = !!($ != null ? $ : U),
        B = _ ? "table" : R ? "compact" : "default",
        G = _ ? "flex w-full flex-col items-stretch gap-2 text-start self-start flex-1" : R ? "inline-flex max-w-full items-center gap-3 align-middle" : "flex flex-row items-center gap-8 py-4";
    let O;
    e[40] !== G ? (O = W(G, "cursor-pointer"), e[40] = G, e[41] = O) : O = e[41];
    const H = O,
        S = _ ? "items-start text-start" : "justify-center";
    let V;
    e[42] !== S ? (V = W("flex flex-col gap-1", S), e[42] = S, e[43] = V) : V = e[43];
    const J = V,
        q = _ ? "text-sm font-semibold line-clamp-2 text-balance" : R ? "text-base font-medium line-clamp-2 text-balance" : "text-lg font-medium line-clamp-2 text-balance";
    let Z;
    e[44] !== q ? (Z = W(q), e[44] = q, e[45] = Z) : Z = e[45];
    const D = Z,
        te = _ ? "justify-start text-xs max-w-full" : "text-sm";
    let se;
    e[46] !== te ? (se = W("text-token-text-tertiary flex flex-wrap items-center gap-1 font-normal", te), e[46] = te, e[47] = se) : se = e[47];
    const re = se,
        X = x.useRef(null),
        he = x.useId(),
        K = String(i != null ? i : he),
        oe = _ ? "product-table-".concat(o) : "",
        [ye, ke] = x.useState(void 0),
        ie = Qb(),
        ee = ey(),
        fe = ty(),
        [Se, je] = x.useState(null),
        [Te, Ye] = x.useState(!1),
        ge = Se ? Se.w / Math.max(1, Se.h) : null,
        lt = ge != null && ge >= 1.8,
        Ze = ge != null && ge <= .6,
        pe = ge == null || lt || Ze ? "contain" : "cover",
        de = ay,
        Me = iy;
    let we, $e;
    if (e[48] !== oe || e[49] !== K || e[50] !== E || e[51] !== _ ? (we = () => {
            if (!_ || !E) return;
            const Je = X.current;
            if (!Je) return;
            const He = de(Je);
            if (He) {
                He.style.paddingInlineEnd = "8px";
                for (const Oe of He.querySelectorAll("td")) Oe.style.textAlign = "left"
            }
            const Ke = Me(Je);
            Ke && (Ke.style.verticalAlign = "top", Ke.getAttribute("data-col-size") === "sm" && Ke.setAttribute("data-col-size", "md"));
            const dt = new ResizeObserver(Oe => {
                for (const Be of Oe) {
                    const st = Math.floor(Be.contentRect.width);
                    st > 0 && sy(oe, K, st)
                }
            });
            dt.observe(Je);
            const ut = oy(oe, ke);
            return () => {
                dt.disconnect(), ut(), ny(oe, K)
            }
        }, $e = [oe, K, _, E], e[48] = oe, e[49] = K, e[50] = E, e[51] = _, e[52] = we, e[53] = $e) : (we = e[52], $e = e[53]), un(we, $e), !p) return null;
    if (I) {
        let Je;
        e[54] === Symbol.for("react.memo_cache_sentinel") ? (Je = W("relative w-full overflow-hidden rounded-2xl bg-[#F3F3F3] dark:bg-[#F3F3F3]", "aspect-auto h-auto", "max-[400px]:h-auto"), e[54] = Je) : Je = e[54];
        let He;
        e: {
            if (pe === "cover") {
                if (ee) {
                    let nt;
                    e[55] === Symbol.for("react.memo_cache_sentinel") ? (nt = {
                        aspectRatio: 2.59
                    }, e[55] = nt) : nt = e[55], He = nt;
                    break e
                }
                if (fe) {
                    let nt;
                    e[56] === Symbol.for("react.memo_cache_sentinel") ? (nt = {
                        aspectRatio: 1.5
                    }, e[56] = nt) : nt = e[56], He = nt;
                    break e
                }
                const We = typeof ge == "number" && ge > 0 ? ge : 2.59,
                    Et = Math.min(We, 2.59);
                let $t;
                e[57] !== Et ? ($t = {
                    aspectRatio: Et
                }, e[57] = Et, e[58] = $t) : $t = e[58], He = $t;
                break e
            }
            if (fe) {
                let We;
                e[59] === Symbol.for("react.memo_cache_sentinel") ? (We = {
                    aspectRatio: 1
                }, e[59] = We) : We = e[59], He = We;
                break e
            }
            let bt;e[60] === Symbol.for("react.memo_cache_sentinel") ? (bt = {
                height: 300
            }, e[60] = bt) : bt = e[60],
            He = bt
        }
        let Ke;
        e[61] !== Te || e[62] !== pe || e[63] !== E || e[64] !== p.title ? (Ke = E && !Te && a.jsx("img", {
            src: E,
            alt: (_e = p.title) != null ? _e : "",
            draggable: !1,
            className: W("absolute start-1/2 top-1/2 z-0 -translate-x-1/2 -translate-y-1/2", "max-h-full max-w-full select-none", pe === "cover" ? "object-cover" : "object-contain", "m-0 origin-center scale-100 mix-blend-darken transition-transform duration-200 hover:scale-105"),
            onLoad: bt => {
                const We = bt.currentTarget;
                We.naturalWidth && We.naturalHeight && (je({
                    w: We.naturalWidth,
                    h: We.naturalHeight
                }), We.naturalWidth * We.naturalHeight < Jb && N(!1))
            },
            onError: () => Ye(!0)
        }), e[61] = Te, e[62] = pe, e[63] = E, e[64] = p.title, e[65] = Ke) : Ke = e[65];
        let dt;
        e[66] !== Te || e[67] !== E ? (dt = (!E || Te) && a.jsx("div", {
            className: "text-token-text-tertiary/60 absolute start-1/2 top-1/2 z-0 -translate-x-1/2 -translate-y-1/2",
            children: a.jsx(cu, {
                className: "h-10 w-10"
            })
        }), e[66] = Te, e[67] = E, e[68] = dt) : dt = e[68];
        let ut;
        e[69] === Symbol.for("react.memo_cache_sentinel") ? (ut = a.jsx("div", {
            className: "pointer-events-none absolute inset-x-0 bottom-0 z-[5] mx-[-12px] mb-[-12px] h-[50%] bg-gradient-to-t from-black/30 to-transparent blur-md"
        }), e[69] = ut) : ut = e[69];
        let Oe;
        e[70] === Symbol.for("react.memo_cache_sentinel") ? (Oe = W("line-clamp-2 text-xl font-semibold text-balance text-ellipsis text-white lg:text-2xl", "drop-shadow-[0_0_14px_rgba(0,0,0,0.45)]"), e[70] = Oe) : Oe = e[70];
        let Be;
        e[71] !== p.title ? (Be = a.jsx("h3", {
            className: Oe,
            children: p.title
        }), e[71] = p.title, e[72] = Be) : Be = e[72];
        let st;
        e[73] !== p.merchants || e[74] !== p.price ? (st = !!((Ge = p.price) != null ? Ge : p.merchants) && a.jsxs("div", {
            className: "mt-1 flex flex-wrap items-center gap-1 text-sm text-white/85 lg:text-base",
            children: [((ze = p.price) == null ? void 0 : ze.trim()) && a.jsx("span", {
                children: (Ve = p.price) == null ? void 0 : Ve.trim()
            }), ((De = p.price) == null ? void 0 : De.trim()) && ((tt = p.merchants) == null ? void 0 : tt.trim()) && a.jsx("span", {
                className: "mx-0.5",
                children: "•"
            }), ((mt = p.merchants) == null ? void 0 : mt.trim()) && a.jsx("span", {
                className: "truncate",
                children: (vt = p.merchants) == null ? void 0 : vt.trim()
            })]
        }), e[73] = p.merchants, e[74] = p.price, e[75] = st) : st = e[75];
        let ht;
        e[76] !== Be || e[77] !== st ? (ht = a.jsxs("div", {
            className: "pointer-events-none absolute inset-x-0 bottom-0 z-10 max-w-[70%] p-4 text-white dark:text-white",
            children: [Be, st]
        }), e[76] = Be, e[77] = st, e[78] = ht) : ht = e[78];
        let St;
        e[79] !== He || e[80] !== Ke || e[81] !== dt || e[82] !== ht ? (St = a.jsxs("div", {
            className: Je,
            style: He,
            children: [Ke, dt, ut, ht]
        }), e[79] = He, e[80] = Ke, e[81] = dt, e[82] = ht, e[83] = St) : St = e[83];
        let Tt;
        return e[84] !== k || e[85] !== St ? (Tt = a.jsx("div", {
            className: "w-full cursor-pointer",
            onClick: k,
            children: St
        }), e[84] = k, e[85] = St, e[86] = Tt) : Tt = e[86], Tt
    }
    let Ue;
    e[87] !== ye ? (Ue = {
        width: ye
    }, e[87] = ye, e[88] = Ue) : Ue = e[88];
    let Ae;
    e[89] !== B || e[90] !== E || e[91] !== _ || e[92] !== p.title || e[93] !== ie || e[94] !== ye ? (Ae = E && a.jsx(ly, {
        imageUrl: E,
        productTitle: (kt = p.title) != null ? kt : "",
        size: B,
        pixelSize: _ && ye ? Math.min(ye, ie) : void 0
    }), e[89] = B, e[90] = E, e[91] = _, e[92] = p.title, e[93] = ie, e[94] = ye, e[95] = Ae) : Ae = e[95];
    let pt;
    e[96] !== p.title || e[97] !== D ? (pt = a.jsx("div", {
        className: D,
        children: p.title
    }), e[96] = p.title, e[97] = D, e[98] = pt) : pt = e[98];
    let Le;
    e[99] !== U || e[100] !== re || e[101] !== $ || e[102] !== z ? (Le = z && a.jsxs("div", {
        className: re,
        children: [$ && a.jsx("span", {
            children: $
        }), $ && U && a.jsx("span", {
            className: "mx-0.5",
            children: "•"
        }), U && a.jsx("span", {
            className: "truncate",
            children: U
        })]
    }), e[99] = U, e[100] = re, e[101] = $, e[102] = z, e[103] = Le) : Le = e[103];
    let ct;
    e[104] !== pt || e[105] !== Le || e[106] !== J ? (ct = a.jsxs("div", {
        className: J,
        children: [pt, Le]
    }), e[104] = pt, e[105] = Le, e[106] = J, e[107] = ct) : ct = e[107];
    let Ct;
    return e[108] !== H || e[109] !== k || e[110] !== Ue || e[111] !== Ae || e[112] !== ct ? (Ct = a.jsxs("div", {
        ref: X,
        className: H,
        style: Ue,
        onClick: k,
        children: [Ae, ct]
    }), e[108] = H, e[109] = k, e[110] = Ue, e[111] = Ae, e[112] = ct, e[113] = Ct) : Ct = e[113], Ct
}

function iy(t) {
    const e = t.parentElement;
    return e && e.tagName.toLowerCase() === "th" ? e : null
}

function ay(t) {
    var s, n, o;
    const e = (o = (n = (s = t.parentElement) == null ? void 0 : s.parentElement) == null ? void 0 : n.parentElement) == null ? void 0 : o.parentElement;
    return e && e.tagName.toLowerCase() === "table" ? e : null
}

function ly(t) {
    "use forget";
    const e = xe.c(14),
        {
            className: s,
            imageUrl: n,
            productTitle: o,
            onClicked: r,
            size: i,
            pixelSize: l
        } = t,
        c = r === void 0 ? cy : r,
        f = {
            table: "w-full max-w-[160px] lg:max-w-[200px]",
            compact: "max-h-16",
            default: "w-[88px] lg:w-[160px]"
        }[i === void 0 ? "default" : i],
        [h, m] = x.useState(null),
        [b, y] = x.useState(!1),
        p = h ? h.w / Math.max(1, h.h) : null,
        w = p != null && p >= 1.8,
        C = p != null && p <= .6,
        v = w || C ? "contain" : "cover",
        g = W(s, "overflow-hidden rounded-xl", "relative flex aspect-square shrink-0 items-center justify-center", f, "bg-[#F3F3F3] dark:bg-[#F3F3F3]");
    let k;
    e[0] !== l ? (k = l ? {
        width: l,
        height: l
    } : void 0, e[0] = l, e[1] = k) : k = e[1];
    let E;
    e[2] !== b || e[3] !== n || e[4] !== v || e[5] !== o || e[6] !== y || e[7] !== m ? (E = b ? a.jsx(cu, {
        className: "text-token-text-tertiary/60 h-6 w-6"
    }) : a.jsx("img", {
        className: W("size-full max-h-full max-w-full origin-center object-center mix-blend-darken transition-all duration-200 select-none", v === "contain" ? "object-contain" : "object-cover", "scale-100 hover:scale-105"),
        src: n,
        alt: o,
        draggable: !1,
        onLoad: M => {
            const T = M.currentTarget;
            T.naturalWidth && T.naturalHeight && m({
                w: T.naturalWidth,
                h: T.naturalHeight
            })
        },
        onError: () => y(!0)
    }), e[2] = b, e[3] = n, e[4] = v, e[5] = o, e[6] = y, e[7] = m, e[8] = E) : E = e[8];
    let j;
    return e[9] !== c || e[10] !== g || e[11] !== k || e[12] !== E ? (j = a.jsx("div", {
        className: g,
        onClick: c,
        style: k,
        children: E
    }), e[9] = c, e[10] = g, e[11] = k, e[12] = E, e[13] = j) : j = e[13], j
}

function cy() {}

function cu(t) {
    "use forget";
    const e = xe.c(5),
        {
            className: s
        } = t;
    let n, o, r;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (n = a.jsx("rect", {
        x: "3",
        y: "5",
        width: "18",
        height: "14",
        rx: "2",
        ry: "2"
    }), o = a.jsx("circle", {
        cx: "8.5",
        cy: "10",
        r: "1.5"
    }), r = a.jsx("path", {
        d: "M21 16l-5.5-5.5a1 1 0 00-1.4 0L7 18"
    }), e[0] = n, e[1] = o, e[2] = r) : (n = e[0], o = e[1], r = e[2]);
    let i;
    return e[3] !== s ? (i = a.jsxs("svg", {
        className: s,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        strokeWidth: "1.5",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        "aria-hidden": !0,
        children: [n, o, r]
    }), e[3] = s, e[4] = i) : i = e[4], i
}

function dy({
    attribution: t,
    wordFadeType: e
}) {
    var r;
    const s = x.useContext(js),
        n = Nh(s == null ? void 0 : s.message.id, t.attributable_index),
        o = Ph();
    return a.jsx(my, {
        isHighlighted: n,
        isDebugMode: o && !1,
        content: (r = t.alt) != null ? r : "",
        attributableIndex: t.attributable_index,
        attributions: void 0,
        attributionsDebug: void 0,
        wordFadeType: e
    })
}
const uy = x.memo(Or);

function fy({
    content: t,
    isHighlighted: e,
    isDebugMode: s,
    attributableIndex: n,
    attributions: o,
    attributionsDebug: r,
    wordFadeType: i
}) {
    const l = i === "indexed",
        c = cd(),
        d = x.useMemo(() => l ? {
            handlers: {
                text: (h, m, b) => {
                    const y = [];
                    for (const p of c(m.value)) y.push({
                        type: "element",
                        tagName: "span",
                        properties: {
                            className: dd.fadeIn
                        },
                        children: [{
                            type: "text",
                            value: p
                        }]
                    });
                    return y
                }
            }
        } : void 0, [l, c]),
        u = x.useMemo(() => ({
            p: ({
                children: h
            }) => a.jsx(a.Fragment, {
                children: h
            })
        }), []),
        f = a.jsx(uy, {
            rehypePlugins: Xi,
            remarkPlugins: Ki,
            urlTransform: Vi,
            remarkRehypeOptions: d,
            components: u,
            children: t
        });
    return a.jsx(hy, {
        isHighlighted: e,
        children: f
    })
}
const my = vr.memo(fy);

function hy({
    isHighlighted: t,
    className: e,
    children: s
}) {
    return a.jsx("span", {
        className: W("relative", "-mx-px my-[-0.2rem] rounded px-px py-[0.2rem]", t && "attribution-highlight-bg", "transition-colors duration-100 ease-in-out", e),
        children: s
    })
}

function Al(t, e) {
    try {
        return BigInt(t).toLocaleString(e)
    } catch (s) {
        const n = Number(t);
        return t.includes("e") || t.includes("E") ? n.toExponential() : n.toLocaleString(e, {
            maximumFractionDigits: 6
        })
    }
}

function gy({
    data: t,
    trackContentReferenceEvent: e
}) {
    x.useEffect(() => {
        e("Search Content Reference Shown", "search_content_reference_shown", t.type)
    }, [e, t.type]);
    const s = Bf().locale;
    return t.expression && t.result != null ? a.jsxs("div", {
        className: "no-scrollbar overflow-auto sm:overflow-hidden",
        children: [a.jsxs("div", {
            className: "pb-1 text-lg font-semibold",
            children: [t.prefix && a.jsx("span", {
                children: t.prefix
            }), a.jsx("span", {
                children: Al(t.result, s)
            }), t.suffix && a.jsx("span", {
                children: t.suffix
            })]
        }), a.jsx("div", {
            className: "text-token-text-primary tracking-wide",
            children: "".concat(t.expression, "=").concat(Al(t.result, s))
        })]
    }) : null
}

function du({
    ref: t,
    onClick: e,
    onMouseEnter: s,
    onMouseLeave: n
}) {
    const o = Ne();
    return a.jsx("button", {
        ref: t,
        "aria-label": o.formatMessage({
            id: "citation.icon.label",
            defaultMessage: "Coding Citation"
        }),
        onClick: e,
        onMouseEnter: s,
        onMouseLeave: n,
        className: W("rounded-xl px-1", "text-token-text-secondary bg-token-bg-tertiary hover:text-token-text-primary hover:bg-token-interactive-bg-secondary-selected"),
        children: a.jsx(Rh, {
            className: "icon-sm"
        })
    })
}

function py({
    codeMessage: t,
    codeExecutionOutputMessage: e,
    onDismiss: s,
    FormattedText: n
}) {
    const o = Ne();
    return a.jsx(Ns.Root, {
        isOpen: !0,
        onClose: s,
        testId: "modal-code-execution",
        children: a.jsx(Ns.Overlay, {
            children: a.jsxs(Ns.Content, {
                className: "flex max-h-[75vh] max-w-lg flex-col overflow-hidden",
                children: [a.jsx(Ns.Header, {
                    title: o.formatMessage(xy.title),
                    type: "success",
                    closeButton: a.jsx(Wf, {
                        onClick: s
                    })
                }), a.jsxs("div", {
                    className: "flex flex-1 flex-col overflow-auto",
                    children: [a.jsx("div", {
                        children: a.jsx(lp, {
                            FormattedText: n,
                            message: t,
                            codeRendererClassName: "border-none rounded-none",
                            removeTopBorderRadius: !0
                        })
                    }), a.jsx("div", {
                        children: a.jsx(cp, {
                            message: e
                        })
                    })]
                })]
            })
        })
    })
}
const xy = Ts({
    title: {
        id: "CodeExecutionOutputModal.title",
        defaultMessage: "Analysis"
    }
});

function by({
    displayInfo: t,
    FormattedText: e,
    trackContentReferenceEvent: s
}) {
    const [n, o] = x.useState(!1), r = Ne();
    return x.useEffect(() => {
        s("Search Content Reference Shown", "search_content_reference_shown", t.type)
    }, [s, t.type]), a.jsxs(a.Fragment, {
        children: [a.jsx(Yn, {
            label: r.formatMessage(yy.viewAnalysis),
            side: "top",
            delayDuration: 150,
            className: "align-middle",
            children: a.jsx(du, {
                onClick: () => o(!0)
            })
        }), n && a.jsx(py, {
            FormattedText: e,
            codeMessage: t.codeMessage,
            codeExecutionOutputMessage: t.codeExecutionOutputMessage,
            onDismiss: () => o(!1)
        })]
    })
}
const yy = Ts({
    viewAnalysis: {
        id: "viewAnalysis",
        defaultMessage: "View analysis"
    }
});

function wy({
    contentReference: t,
    clientThreadId: e,
    turnIndex: s
}) {
    var m, b, y, p, w, C, v;
    const {
        toggleThreadSidebar: n
    } = eo(), o = $h("codingCitations"), [r, i] = x.useState(!1), l = x.useRef(null), c = () => {
        l.current != null && window.clearTimeout(l.current), i(!0)
    }, d = () => {
        l.current = window.setTimeout(() => i(!1), 100)
    }, u = x.useCallback(() => {
        var g, k;
        e && n({
            type: "codingCitations",
            turnIndex: s || 1,
            messageId: (k = (g = t.cited_message) == null ? void 0 : g.id) != null ? k : "",
            matchedText: t.matched_text
        }, o)
    }, [n, e, o, t, s]);
    if (!t.cited_message || !t.highlighted_text) return null;
    let f;
    t.type === "python" ? f = (y = (b = (m = t.cited_message) == null ? void 0 : m.metadata) == null ? void 0 : b.aggregate_result) == null ? void 0 : y.code : t.type === "container" && (f = (C = (w = (p = t.cited_message) == null ? void 0 : p.metadata) == null ? void 0 : w.container_citation) == null ? void 0 : C.source_cmd);
    const h = (v = f == null ? void 0 : f.split("\n").length) != null ? v : 0;
    return a.jsx("span", {
        className: "relative top-[0.1rem] inline-block align-middle",
        children: a.jsx("span", {
            className: "inline-flex items-center",
            children: a.jsxs(Nr, {
                open: r,
                onOpenChange: i,
                children: [a.jsx(Pr, {
                    asChild: !0,
                    children: a.jsx(du, {
                        onClick: u,
                        onMouseEnter: c,
                        onMouseLeave: d
                    })
                }), a.jsx(Rr, {
                    children: a.jsx($r, {
                        align: "start",
                        sideOffset: 4,
                        onMouseEnter: c,
                        onMouseLeave: d,
                        className: W("border-default bg-token-bg-primary rounded-2xl border p-3"),
                        children: a.jsxs("aside", {
                            className: "flex flex-col gap-3",
                            children: [a.jsx("h2", {
                                className: W("text-token-text-secondary text-xs font-medium"),
                                children: t.type === "python" ? a.jsx(me, {
                                    id: "citation.popover.label.python",
                                    defaultMessage: "Python script · {count, number} lines",
                                    values: {
                                        count: h
                                    }
                                }) : a.jsx(me, {
                                    id: "citation.popover.label.container",
                                    defaultMessage: "Bash script · {count, number} lines",
                                    values: {
                                        count: h
                                    }
                                })
                            }), a.jsx("hr", {}), a.jsx("h2", {
                                className: W("text-sm font-medium", "max-w-full break-words whitespace-pre-line sm:max-w-[300px]"),
                                children: t.highlighted_text
                            })]
                        })
                    })
                })]
            })
        })
    })
}
const _y = "2758269539",
    vy = Kn(() => Es(() =>
        import ("./k15yxxoybkkir2ou.js").then(t => t.Fb), __vite__mapDeps([6, 1, 2, 3, 7])).then(t => t.DILWidget));

function ky({
    dil: t,
    dilUrl: e,
    trackContentReferenceEvent: s,
    widgetName: n
}) {
    x.useEffect(() => {
        const r = n == null ? void 0 : {
            widget_name: n
        };
        s("Search Content Reference Shown", "search_content_reference_shown", "dil", r)
    }, [s, n]);
    const o = et();
    return at(o, _y) ? null : a.jsx(vy, {
        dil: t
    })
}
const uu = t => {
        const e = {};
        return t == null || t.forEach(s => {
            s.selected_option_id && (e[s.id] = s.selected_option_id)
        }), e
    },
    Ii = t => {
        if (!t) return t;
        const e = t.map(n => n.id),
            s = uu(t);
        return t.map(n => {
            var l, c;
            const o = n.options.map(d => {
                    var h, m;
                    const u = (h = d.compatible_option_ids_by_group) != null ? h : void 0;
                    let f = (m = d.available) != null ? m : !0;
                    if (u && (e.filter(y => y !== n.id).some(y => {
                            var p, w;
                            return ((w = (p = u[y]) == null ? void 0 : p.length) != null ? w : 0) === 0
                        }) && e.length > 1 && (f = !1), f))
                        for (const [y, p] of Object.entries(s)) {
                            if (!p || y === n.id) continue;
                            const w = u[y];
                            if (!w || !w.includes(p)) {
                                f = !1;
                                break
                            }
                        }
                    return ce(F({}, d), {
                        available: f
                    })
                }),
                r = (c = (l = o.find(d => d.selected && d.available)) == null ? void 0 : l.id) != null ? c : "",
                i = o.map(d => ce(F({}, d), {
                    selected: r !== "" && d.id === r
                }));
            return ce(F({}, n), {
                options: i,
                selected_option_id: r || void 0
            })
        })
    };

function Sy({
    variants: t,
    optionGroupId: e,
    selectedOptionId: s
}) {
    var l;
    if (!t) return {
        variants: t,
        variantOptionsQuery: null
    };
    const n = t.map(c => c.id === e ? ce(F({}, c), {
            options: c.options.map(d => ce(F({}, d), {
                selected: d.id === s
            })),
            selected_option_id: s
        }) : c),
        o = Ii(n),
        r = uu(o),
        i = (l = o == null ? void 0 : o.every(c => c.selected_option_id)) != null ? l : !1;
    return {
        variants: o,
        variantOptionsQuery: i ? r : null
    }
}

function Ey({
    product: t,
    clientThreadId: e,
    messageId: s,
    contentReferenceStartIndex: n,
    trackContentReferenceEvent: o,
    showTitle: r = !1,
    showImageGallery: i = !1
}) {
    var v, g, k, E;
    const l = et(),
        c = at(l, "3375735072"),
        d = at(l, "232003972"),
        u = x.useMemo(() => ({
            clientThreadId: e,
            messageId: s
        }), [e, s]),
        f = zi.useStore(),
        [h, m] = x.useState(!1),
        [b, y] = x.useState(ce(F({}, t), {
            variants: Ii(t.variants)
        })),
        [p, w] = x.useState(!1),
        C = r || d || c;
    return x.useEffect(() => {
        let j = !0;
        return (async T => {
            w(!0);
            try {
                try {
                    for (var N = ni(jy(T)), I, _, R; I = !(_ = await N.next()).done; I = !1) {
                        const A = _.value;
                        j && y(ce(F({}, A), {
                            variants: Ii(A.variants)
                        }))
                    }
                } catch (_) {
                    R = [_]
                } finally {
                    try {
                        I && (_ = N.return) && await _.call(N)
                    } finally {
                        if (R) throw R[0]
                    }
                }
            } finally {
                j && w(!1)
            }
        })(b), () => {
            j = !1
        }
    }, [(v = b.product_lookup_key) == null ? void 0 : v.variant_options_query]), b ? a.jsxs("div", {
        className: "-mx-6",
        children: [i && a.jsx(wg, {
            imageUrls: (g = b.image_urls) != null ? g : [],
            title: b.title,
            onImageClick: j => {
                f.setCurrentImage({
                    image: {
                        url: j,
                        content_url: j,
                        thumbnail_url: j,
                        title: b.title,
                        content_size: {
                            width: 0,
                            height: 0
                        },
                        thumbnail_size: {
                            width: 0,
                            height: 0
                        }
                    },
                    source: hn.ProductDetails,
                    analyticsMetadata: u,
                    contentReferenceStartIndex: n
                })
            }
        }), a.jsxs("div", {
            className: "bg-token-bg-primary flex w-full flex-col",
            children: [C && a.jsxs("div", {
                className: "border-token-border-light flex flex-col border-b px-6 pb-3",
                children: [r && a.jsx("div", {
                    className: "text-token-text-primary text-xl font-medium capitalize",
                    children: b.title
                }), d && b.num_reviews && b.rating && a.jsx(_g, {
                    rating: b.rating,
                    numReviews: b.num_reviews,
                    ratingGroupedCitation: b.rating_grouped_citation,
                    trackContentReferenceEvent: () => {},
                    analyticsMetadata: u
                }), c && b.variants && b.variants.length > 0 && a.jsx("div", {
                    className: "mt-5 mb-2",
                    children: a.jsx(vg, {
                        options: b.variants,
                        showErrors: h,
                        updateOption: (j, M, T) => y(N => My({
                            optionGroupId: j,
                            selectedId: M,
                            variant_index: T,
                            product: N,
                            trackContentReferenceEvent: o
                        }))
                    })
                })]
            }), a.jsx(kg, {
                className: "border-token-border-light -pt-3 -mx-3 flex flex-col border-b px-6 pb-3",
                offers: (k = t.offers) != null ? k : [],
                contentReferenceStartIndex: n,
                productIndex: 0,
                product: t,
                trackContentReferenceEvent: o,
                analyticsMetadata: u,
                imageUrls: (E = t.image_urls) != null ? E : [],
                isLoading: p,
                onOpenCheckout: () => m(!0)
            })]
        })]
    }) : null
}

function jy(t) {
    return $a(this, null, function*() {
        const {
            product_lookup_key: e
        } = t;
        if (!!!(e != null && e.variant_options_query)) {
            yield t;
            return
        }
        const n = Ah("".concat(zf, "/search/product_info_variants"), {
            method: "POST",
            headers: F({}, Oi({
                isAuthOptional: !0
            })),
            body: {
                product_lookup_key: t.product_lookup_key
            }
        });
        try {
            for (var o = ni(n), r, i, l; r = !(i = yield new Bo(o.next())).done; r = !1) {
                const c = i.value;
                "data" in c && (yield c.data.product)
            }
        } catch (i) {
            l = [i]
        } finally {
            try {
                r && (i = o.return) && (yield new Bo(i.call(o)))
            } finally {
                if (l) throw l[0]
            }
        }
    })
}

function My({
    optionGroupId: t,
    selectedId: e,
    variant_index: s,
    product: n,
    trackContentReferenceEvent: o
}) {
    var c, d, u, f;
    const r = (c = n.variants) == null ? void 0 : c.find(h => h.id === t);
    o("product_detail", "product_detail", "product_entity", {
        product_id: n.id,
        action: "variant_selected",
        section: "product_detail",
        section_location: "sidebar",
        variant_name: (d = r == null ? void 0 : r.label) != null ? d : "",
        variant_value: (f = (u = r == null ? void 0 : r.options.find(h => h.id === e)) == null ? void 0 : u.label) != null ? f : "",
        variant_index: s
    });
    const {
        variants: i,
        variantOptionsQuery: l
    } = Sy({
        variants: n.variants,
        optionGroupId: t,
        selectedOptionId: e
    });
    return ce(F({}, n), {
        variants: i,
        product_lookup_key: ce(F({}, n.product_lookup_key), {
            variant_options_query: l
        })
    })
}

function Cy({
    contentReference: t,
    clientThreadId: e,
    messageId: s,
    trackContentReferenceEvent: n
}) {
    var o, r, i;
    if (x.useEffect(() => {
            var l, c;
            n("Entity Metadata Content Reference Shown", "entity_metadata_content_reference_shown", "entity_metadata", F({
                entity_type: t.entity_type
            }, t.entity_type === "local_business" ? {
                business_id: (l = t.entity_data) == null ? void 0 : l.id
            } : t.entity_type === "product" ? {
                product_id: (c = t.entity_data) == null ? void 0 : c.id
            } : {}))
        }, [n, t.entity_type, (o = t.entity_data) == null ? void 0 : o.id]), !(t != null && t.entity_data)) return null;
    if (t.entity_type === "local_business") {
        const c = t.layout !== "one-line";
        return a.jsx(Lh, {
            isLoading: (r = t.metadata) == null ? void 0 : r.is_loading,
            business: t.entity_data,
            mapUrl: (i = t.metadata) == null ? void 0 : i.map_url,
            showActionButtons: c,
            showExtendedDetails: c,
            showTitle: c,
            showHourDetail: c,
            showPrice: c,
            trackContentReferenceEvent: n,
            topOffset: c ? 0 : -4
        })
    } else if (t.entity_type === "product") return a.jsx(Ey, {
        product: t.entity_data,
        clientThreadId: e,
        messageId: s,
        contentReferenceStartIndex: t.start_idx,
        trackContentReferenceEvent: n
    });
    return null
}

function Ty(t, e) {
    return new Date(t).toLocaleDateString(e, {
        month: "long",
        day: "numeric",
        year: "numeric"
    })
}

function Iy({
    metadata: t,
    trackContentReferenceEvent: e
}) {
    const s = t.items.filter(n => n.cloud_doc_url || Dh(n.id));
    return s.length === 0 ? null : a.jsx("div", {
        className: "mt-6 flex flex-col gap-3",
        children: s.map((n, o) => a.jsx(Ny, {
            item: n,
            index: o,
            trackContentReferenceEvent: e
        }, o))
    })
}

function Ny({
    item: t,
    index: e,
    trackContentReferenceEvent: s
}) {
    const n = Ne(),
        o = et(),
        r = Oh(),
        {
            fileName: i,
            fileTypeDisplayName: l,
            fileTypeIcon: c,
            snippet: d,
            url: u,
            fileLastModifiedTime: f
        } = dp(t, "icon object-contain", o, n, r),
        h = {
            title: i,
            description: d != null ? d : "",
            index: e
        };
    return x.useEffect(() => {
        s("Contextual Answers Content Reference Shown", "contextual_answers_content_reference_shown", "file_navlist", h)
    }, []), a.jsxs(Ds, {
        className: "group/nav-list relative flex items-center gap-6 py-1.5",
        href: u != null ? u : "/",
        onClick: () => {
            s("Contextual Answers Content Reference Clicked", "contextual_answers_content_reference_clicked", "file_navlist", h)
        },
        children: [a.jsx("div", {
            className: "absolute start-0 top-0 bottom-0 w-[3px] rounded-t-lg rounded-b-lg bg-black/10"
        }), a.jsxs("div", {
            className: "ms-4 flex grow flex-col gap-1 overflow-hidden text-ellipsis",
            children: [a.jsxs("div", {
                className: "not-prose text-token-text-primary flex items-center gap-1.5 text-sm",
                children: [c, a.jsx("div", {
                    className: "text-token-text-primary line-clamp-2 text-sm",
                    children: l
                })]
            }), a.jsx("div", {
                className: "text-token-link decoration-token-link line-clamp-2 font-semibold group-hover/nav-list:underline",
                children: i
            }), a.jsx("div", {
                className: "text-token-text-primary line-clamp-2 text-sm leading-snug font-normal",
                children: d
            }), f && a.jsx("div", {
                className: "text-token-text-secondary text-sm",
                children: Ty(f, n.locale)
            })]
        })]
    })
}
var gi = {
        line: {
            color: "#F66",
            width: 1,
            dashPattern: []
        },
        sync: {
            enabled: !0,
            group: 1,
            suppressTooltips: !1
        },
        zoom: {
            enabled: !0,
            zoomboxBackgroundColor: "rgba(66,133,244,0.2)",
            zoomboxBorderColor: "#48F",
            zoomButtonText: "Reset Zoom",
            zoomButtonClass: "reset-zoom"
        },
        snap: {
            enabled: !1
        },
        callbacks: {
            beforeZoom: function(t, e) {
                return !0
            },
            afterZoom: function(t, e) {}
        }
    },
    Py = {
        id: "crosshair",
        afterInit: function(t) {
            if (t.config.options.scales.x) {
                var e = t.config.options.scales.x.type;
                if (!(e !== "linear" && e !== "time" && e !== "category" && e !== "logarithmic")) {
                    t.options.plugins.crosshair === void 0 && (t.options.plugins.crosshair = gi), t.crosshair = {
                        enabled: !1,
                        suppressUpdate: !1,
                        x: null,
                        originalData: [],
                        originalXRange: {},
                        dragStarted: !1,
                        dragStartX: null,
                        dragEndX: null,
                        suppressTooltips: !1,
                        ignoreNextEvents: 0,
                        reset: function() {
                            this.resetZoom(t, !1, !1)
                        }.bind(this)
                    };
                    var s = this.getOption(t, "sync", "enabled");
                    s && (t.crosshair.syncEventHandler = function(n) {
                        this.handleSyncEvent(t, n)
                    }.bind(this), t.crosshair.resetZoomEventHandler = function(n) {
                        var o = this.getOption(t, "sync", "group");
                        n.chartId !== t.id && n.syncGroup === o && this.resetZoom(t, !0)
                    }.bind(this), window.addEventListener("sync-event", t.crosshair.syncEventHandler), window.addEventListener("reset-zoom-event", t.crosshair.resetZoomEventHandler)), t.panZoom = this.panZoom.bind(this, t)
                }
            }
        },
        afterDestroy: function(t) {
            var e = this.getOption(t, "sync", "enabled");
            e && (window.removeEventListener("sync-event", t.crosshair.syncEventHandler), window.removeEventListener("reset-zoom-event", t.crosshair.resetZoomEventHandler))
        },
        panZoom: function(t, e) {
            if (t.crosshair.originalData.length !== 0) {
                var s = t.crosshair.end - t.crosshair.start,
                    n = t.crosshair.min,
                    o = t.crosshair.max;
                e < 0 ? (t.crosshair.start = Math.max(t.crosshair.start + e, n), t.crosshair.end = t.crosshair.start === n ? n + s : t.crosshair.end + e) : (t.crosshair.end = Math.min(t.crosshair.end + e, t.crosshair.max), t.crosshair.start = t.crosshair.end === o ? o - s : t.crosshair.start + e), this.doZoom(t, t.crosshair.start, t.crosshair.end)
            }
        },
        getOption: function(t, e, s) {
            return qa(t.options.plugins.crosshair[e] ? t.options.plugins.crosshair[e][s] : void 0, gi[e][s])
        },
        getXScale: function(t) {
            return t.data.datasets.length ? t.scales[t.getDatasetMeta(0).xAxisID] : null
        },
        getYScale: function(t) {
            return t.scales[t.getDatasetMeta(0).yAxisID]
        },
        handleSyncEvent: function(t, e) {
            var s = this.getOption(t, "sync", "group");
            if (e.chartId !== t.id && e.syncGroup === s) {
                var n = this.getXScale(t);
                if (n) {
                    var o = e.original.native.buttons === void 0 ? e.original.native.which : e.original.native.buttons;
                    e.original.type === "mouseup" && (o = 0);
                    var r = {
                        type: e.original.type == "click" ? "mousemove" : e.original.type,
                        chart: t,
                        x: n.getPixelForValue(e.xValue),
                        y: e.original.y,
                        native: {
                            buttons: o
                        },
                        stop: !0
                    };
                    t._eventHandler(r)
                }
            }
        },
        afterEvent: function(t, e) {
            if (t.config.options.scales.x.length == 0) return;
            let s = e.event;
            var n = t.config.options.scales.x.type;
            if (!(n !== "linear" && n !== "time" && n !== "category" && xscaleType !== "logarithmic")) {
                var o = this.getXScale(t);
                if (o) {
                    if (t.crosshair.ignoreNextEvents > 0) {
                        t.crosshair.ignoreNextEvents -= 1;
                        return
                    }
                    var r = s.native.buttons === void 0 ? s.native.which : s.native.buttons;
                    s.native.type === "mouseup" && (r = 0);
                    var i = this.getOption(t, "sync", "enabled"),
                        l = this.getOption(t, "sync", "group");
                    if (!s.stop && i) {
                        var e = new CustomEvent("sync-event");
                        e.chartId = t.id, e.syncGroup = l, e.original = s, e.xValue = o.getValueForPixel(s.x), window.dispatchEvent(e)
                    }
                    var c = this.getOption(t, "sync", "suppressTooltips");
                    if (t.crosshair.suppressTooltips = s.stop && c, t.crosshair.enabled = s.type !== "mouseout" && s.x > o.getPixelForValue(o.min) && s.x < o.getPixelForValue(o.max), !t.crosshair.enabled && !t.crosshair.suppressUpdate) return s.x > o.getPixelForValue(o.max) && (t.crosshair.suppressUpdate = !0, t.update("none")), t.crosshair.dragStarted = !1, !1;
                    t.crosshair.suppressUpdate = !1;
                    var d = this.getOption(t, "zoom", "enabled");
                    if (r === 1 && !t.crosshair.dragStarted && d && (t.crosshair.dragStartX = s.x, t.crosshair.dragStarted = !0), t.crosshair.dragStarted && r === 0) {
                        t.crosshair.dragStarted = !1;
                        var u = o.getValueForPixel(t.crosshair.dragStartX),
                            f = o.getValueForPixel(t.crosshair.x);
                        Math.abs(t.crosshair.dragStartX - t.crosshair.x) > 1 && this.doZoom(t, u, f), t.update("none")
                    }
                    t.crosshair.x = s.x, t.draw()
                }
            }
        },
        afterDraw: function(t) {
            if (t.crosshair.enabled) return t.crosshair.dragStarted ? this.drawZoombox(t) : (this.drawTraceLine(t), this.interpolateValues(t), this.drawTracePoints(t)), !0
        },
        beforeTooltipDraw: function(t) {
            return !t.crosshair.dragStarted && !t.crosshair.suppressTooltips
        },
        resetZoom: function(t) {
            var e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1,
                s = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0;
            if (s) {
                if (t.crosshair.originalData.length > 0)
                    for (var n = 0; n < t.data.datasets.length; n++) {
                        var o = t.data.datasets[n];
                        o.data = t.crosshair.originalData.shift(0)
                    }
                t.crosshair.originalXRange.min ? (t.options.scales.x.min = t.crosshair.originalXRange.min, t.crosshair.originalXRange.min = null) : delete t.options.scales.x.min, t.crosshair.originalXRange.max ? (t.options.scales.x.max = t.crosshair.originalXRange.max, t.crosshair.originalXRange.max = null) : delete t.options.scales.x.max
            }
            t.crosshair.button && t.crosshair.button.parentNode && (t.crosshair.button.parentNode.removeChild(t.crosshair.button), t.crosshair.button = !1);
            var r = this.getOption(t, "sync", "enabled");
            if (!e && s && r) {
                var i = this.getOption(t, "sync", "group"),
                    l = new CustomEvent("reset-zoom-event");
                l.chartId = t.id, l.syncGroup = i, window.dispatchEvent(l)
            }
            s && t.update("none")
        },
        doZoom: function(t, e, s) {
            if (e > s) {
                var n = e;
                e = s, s = n
            }
            var o = qa(t.options.plugins.crosshair.callbacks ? t.options.plugins.crosshair.callbacks.beforeZoom : void 0, gi.callbacks.beforeZoom);
            if (!o(e, s)) return !1;
            if (t.crosshair.dragStarted = !1, t.options.scales.x.min && t.crosshair.originalData.length === 0 && (t.crosshair.originalXRange.min = t.options.scales.x.min), t.options.scales.x.max && t.crosshair.originalData.length === 0 && (t.crosshair.originalXRange.max = t.options.scales.x.max), !t.crosshair.button) {
                var r = document.createElement("button"),
                    i = this.getOption(t, "zoom", "zoomButtonText"),
                    l = this.getOption(t, "zoom", "zoomButtonClass"),
                    c = document.createTextNode(i);
                r.appendChild(c), r.className = l, r.addEventListener("click", function() {
                    this.resetZoom(t)
                }.bind(this)), t.canvas.parentNode.appendChild(r), t.crosshair.button = r
            }
            t.options.scales.x.min = e, t.options.scales.x.max = s;
            var d = t.crosshair.originalData.length === 0,
                u = t.config.options.scales.x.type !== "category";
            if (u)
                for (var f = 0; f < t.data.datasets.length; f++) {
                    var h = [],
                        m = 0,
                        b = !1,
                        y = !1;
                    d && (t.crosshair.originalData[f] = t.data.datasets[f].data);
                    for (var p = t.crosshair.originalData[f], w = 0; w < p.length; w++) {
                        var C = p[w],
                            v = C.x !== void 0 ? C.x : NaN;
                        v >= e && !b && m > 0 && (h.push(p[m - 1]), b = !0), v >= e && v <= s && h.push(C), v > s && !y && m < p.length && (h.push(C), y = !0), m += 1
                    }
                    t.data.datasets[f].data = h
                }
            if (t.crosshair.start = e, t.crosshair.end = s, d) {
                var g = this.getXScale(t);
                t.crosshair.min = g.min, t.crosshair.max = g.max
            }
            t.crosshair.ignoreNextEvents = 2, t.update("none");
            var k = this.getOption(t, "callbacks", "afterZoom");
            k(e, s)
        },
        drawZoombox: function(t) {
            var e = this.getYScale(t),
                s = this.getOption(t, "zoom", "zoomboxBorderColor"),
                n = this.getOption(t, "zoom", "zoomboxBackgroundColor");
            t.ctx.beginPath(), t.ctx.rect(t.crosshair.dragStartX, e.getPixelForValue(e.max), t.crosshair.x - t.crosshair.dragStartX, e.getPixelForValue(e.min) - e.getPixelForValue(e.max)), t.ctx.lineWidth = 1, t.ctx.strokeStyle = s, t.ctx.fillStyle = n, t.ctx.fill(), t.ctx.fillStyle = "", t.ctx.stroke(), t.ctx.closePath()
        },
        drawTraceLine: function(t) {
            var e = this.getYScale(t),
                s = this.getOption(t, "line", "width"),
                n = this.getOption(t, "line", "color"),
                o = this.getOption(t, "line", "dashPattern"),
                r = this.getOption(t, "snap", "enabled"),
                i = t.crosshair.x;
            r && t._active.length && (i = t._active[0].element.x), t.ctx.beginPath(), t.ctx.setLineDash(o), t.ctx.moveTo(i, e.getPixelForValue(e.max)), t.ctx.lineWidth = s, t.ctx.strokeStyle = n, t.ctx.lineTo(i, e.getPixelForValue(e.min)), t.ctx.stroke(), t.ctx.setLineDash([])
        },
        drawTracePoints: function(t) {
            for (var e = 0; e < t.data.datasets.length; e++) {
                var s = t.data.datasets[e],
                    n = t.getDatasetMeta(e),
                    o = t.scales[n.yAxisID];
                n.hidden || !s.interpolate || (t.ctx.beginPath(), t.ctx.arc(t.crosshair.x, o.getPixelForValue(s.interpolatedValue), 3, 0, 2 * Math.PI, !1), t.ctx.fillStyle = "white", t.ctx.lineWidth = 2, t.ctx.strokeStyle = s.borderColor, t.ctx.fill(), t.ctx.stroke())
            }
        },
        interpolateValues: function(t) {
            for (var e = 0; e < t.data.datasets.length; e++) {
                var s = t.data.datasets[e],
                    n = t.getDatasetMeta(e),
                    o = t.scales[n.xAxisID],
                    r = o.getValueForPixel(t.crosshair.x);
                if (!(n.hidden || !s.interpolate)) {
                    var i = s.data,
                        l = i.findIndex(function(f) {
                            return f.x >= r
                        }),
                        c = i[l - 1],
                        d = i[l];
                    if (t.data.datasets[e].steppedLine && c) s.interpolatedValue = c.y;
                    else if (c && d) {
                        var u = (d.y - c.y) / (d.x - c.x);
                        s.interpolatedValue = c.y + (r - c.x) * u
                    } else s.interpolatedValue = NaN
                }
            }
        }
    };
const fr = (t = 1) => "rgba(48, 166, 51, ".concat(t, ")"),
    mr = (t = 1) => "rgba(241, 77, 66, ".concat(t, ")"),
    Ll = "text-[#30a633]",
    Dl = "text-[#f14d42]",
    Ry = ["1d", "5d", "1m", "6m", "ytd", "1y", "5y", "max"];

function $y({
    histories: t,
    selectedInterval: e,
    onSelectHistoryInterval: s
}) {
    var o;
    const n = Object.keys((o = t == null ? void 0 : t.quotes) != null ? o : {});
    return a.jsx("div", {
        className: "text-token-text-tertiary inline-flex items-start justify-between rounded-[10px] bg-[#f4f4f4] p-[3px] text-xs font-semibold sm:justify-start sm:gap-1 dark:bg-[#393939]",
        children: n.map(r => a.jsx("button", {
            onClick: () => {
                s == null || s(r)
            },
            className: W("border border-transparent px-3 py-1.5 text-xs font-semibold uppercase", e === r ? "border-token-border-default! bg-token-main-surface-primary text-token-text-primary shadow-xxs dark:border-token-border-medium! rounded-lg" : "hover:text-token-text-secondary"),
            children: fu[r].label
        }, r))
    })
}
const fu = {
    "1d": {
        label: "1D",
        formatTimestampLabel: Ol,
        formatTimestampTooltip: Ol,
        maxTicksLimit: 6,
        lineTension: .1
    },
    "5d": {
        label: "5D",
        formatTimestampLabel: Fl,
        formatTimestampTooltip: Ly,
        maxTicksLimit: 6,
        lineTension: .1
    },
    "1m": {
        label: "1M",
        formatTimestampLabel: Fl,
        formatTimestampTooltip: Dy,
        maxTicksLimit: 6,
        lineTension: .1,
        useUtc: !0
    },
    "6m": {
        label: "6M",
        formatTimestampLabel: pi,
        formatTimestampTooltip: jn,
        maxTicksLimit: 5,
        lineTension: .1,
        useUtc: !0
    },
    ytd: {
        label: "YTD",
        formatTimestampLabel: pi,
        formatTimestampTooltip: jn,
        maxTicksLimit: 5,
        lineTension: .1,
        useUtc: !0
    },
    "1y": {
        label: "1Y",
        formatTimestampLabel: pi,
        formatTimestampTooltip: jn,
        maxTicksLimit: 5,
        lineTension: .2,
        useUtc: !0
    },
    "5y": {
        label: "5Y",
        formatTimestampLabel: Bl,
        formatTimestampTooltip: jn,
        maxTicksLimit: 5,
        lineTension: .2,
        useUtc: !0
    },
    max: {
        label: "max",
        formatTimestampLabel: Bl,
        formatTimestampTooltip: jn,
        maxTicksLimit: 5,
        lineTension: .2,
        useUtc: !0
    }
};

function Ay(t) {
    return t ? Ry.filter(s => s in t.quotes).find(s => t.quotes[s].length > 0) : void 0
}

function Fs(t, e) {
    return In(new Date(t * 1e3), e != null ? e : "America/New_York")
}

function Ol(t, e, s) {
    const n = Fs(e, s);
    return t.formatTime(n, {
        hour: "numeric",
        minute: "numeric"
    })
}

function Ly(t, e, s) {
    const n = Fs(e, s);
    return t.formatDate(n, {
        weekday: "short",
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "numeric"
    })
}

function jn(t, e, s) {
    const n = Fs(e, s);
    return t.formatDate(n, {
        month: "short",
        day: "numeric",
        year: "numeric"
    })
}

function pi(t, e, s) {
    const n = Fs(e, s);
    return t.formatDate(n, {
        month: "short",
        year: "numeric"
    })
}

function Fl(t, e, s) {
    const n = Fs(e, s);
    return t.formatDate(n, {
        month: "short",
        day: "numeric"
    })
}

function Dy(t, e, s) {
    const n = Fs(e, s);
    return t.formatDate(n, {
        weekday: "short",
        month: "short",
        day: "numeric"
    })
}

function Bl(t, e, s) {
    const n = Fs(e, s);
    return t.formatDate(n, {
        year: "numeric"
    })
}
pp.register(xp, bp, yp, wp, _p, vp, kp, Sp, Ep, Py, jp);
const Oy = 100,
    Wl = {
        color: "#b4b4b4",
        font: {
            size: 10,
            weight: "600",
            family: "Menlo"
        }
    };

function Fy({
    isUp: t,
    histories: e,
    selectedInterval: s,
    setHighlightedPrice: n,
    latestTradingPeriod: o,
    timezone: r
}) {
    return a.jsx(a.Fragment, {
        children: e && s && o ? a.jsx(By, {
            isUp: t,
            histories: e,
            selectedInterval: s,
            latestTradingPeriod: o,
            timezone: r,
            setHighlightedPrice: n
        }) : a.jsx(Mn, {
            className: "h-full",
            index: 1,
            width: 100
        })
    })
}

function By({
    isUp: t,
    histories: e,
    selectedInterval: s,
    latestTradingPeriod: n,
    timezone: o,
    setHighlightedPrice: r
}) {
    const [i, l] = x.useState(null), [c, d] = x.useState(!1), u = s === "1d", f = x.useMemo(() => {
        let g = e.quotes[s].filter(k => k.close >= 0);
        if (u && n) {
            const k = n.regular.start_timestamp,
                E = n.regular.end_timestamp;
            if (g = g.filter(j => j.timestamp >= k && j.timestamp <= E), g.length === 0 || g[g.length - 1].timestamp < E) {
                let M = g.length > 0 ? g[g.length - 1].timestamp : k - 600;
                for (; M < E;) M += 600, g.push({
                    timestamp: M,
                    close: null
                })
            }
        }
        return g
    }, [e, s, u, n]), h = fu[s], {
        formatTimestampTooltip: m,
        maxTicksLimit: b,
        useUtc: y = !1
    } = h, p = Ne(), w = Wc(), C = Fi(), v = x.useMemo(() => {
        const {
            formatTimestampLabel: g,
            lineTension: k
        } = h;
        return {
            labels: f.map(E => g(p, E.timestamp, y ? "UTC" : o)),
            datasets: [{
                data: f.map(E => E.close),
                borderColor: t ? fr() : mr(),
                pointRadius: 0,
                pointHoverRadius: 4,
                pointStyle: "circle",
                pointBackgroundColor: t ? fr() : mr(),
                pointHoverBorderWidth: 2,
                pointHoverBorderColor: "rgba(255, 255, 255, 1)",
                backgroundColor: function(E) {
                    const {
                        ctx: j,
                        chartArea: M
                    } = E.chart;
                    if (M) return zy(j, M, t)
                },
                fill: !0,
                borderWidth: 2,
                lineTension: k != null ? k : .4
            }]
        }
    }, [h, f, t, y, o, p]);
    return a.jsx("div", {
        className: "flex h-full flex-col gap-6",
        children: a.jsxs("div", {
            className: "relative h-full",
            onMouseEnter: () => d(!0),
            onMouseLeave: () => {
                d(!1), r(null)
            },
            children: [a.jsx(Mp, {
                options: {
                    responsive: !0,
                    maintainAspectRatio: !1,
                    interaction: {
                        intersect: !1,
                        mode: "index"
                    },
                    hover: {
                        mode: c ? "index" : "point"
                    },
                    animation: !1,
                    scales: {
                        x: {
                            afterBuildTicks: g => {
                                if (g.ticks.length > b)
                                    if (u) g.ticks = g.ticks.filter((k, E) => f[E].timestamp % (w ? 3600 : 7200) === 0);
                                    else {
                                        const k = Math.ceil(g.ticks.length / (b - 1));
                                        g.ticks = g.ticks.filter((E, j) => j > 0 && (j % k === 0 || j === g.ticks.length - 1))
                                    }
                            },
                            grid: {
                                display: !1
                            },
                            ticks: ce(F({}, Wl), {
                                align: "end"
                            })
                        },
                        y: {
                            ticks: ce(F({}, Wl), {
                                maxTicksLimit: 7
                            }),
                            border: {
                                display: !1
                            },
                            grid: {
                                color: C ? "rgba(255, 255, 255, 0.1)" : "rgba(229, 229, 229, 0.5)"
                            }
                        }
                    },
                    plugins: {
                        datalabels: {
                            display: !1
                        },
                        legend: {
                            display: !1
                        },
                        tooltip: {
                            enabled: !1,
                            animation: !1,
                            displayColors: !1,
                            callbacks: {
                                title: function(g) {
                                    var j;
                                    const k = g[0];
                                    if (!k) return "";
                                    const E = (j = f[k.dataIndex]) == null ? void 0 : j.timestamp;
                                    return E ? m(p, E, y ? "UTC" : o) : ""
                                }
                            },
                            external: ({
                                tooltip: g
                            }) => {
                                var k, E, j, M;
                                c && g.opacity > 0 && r($n((M = (j = (E = (k = g.dataPoints) == null ? void 0 : k[0]) == null ? void 0 : E.parsed) == null ? void 0 : j.y) != null ? M : 0)), l(T => {
                                    var _, R, A, $, P;
                                    const N = g.chart.width,
                                        I = g.caretX > N - Oy;
                                    return !T || T.x !== g.caretX || T.y !== g.caretY || T.opacity !== g.opacity || T.flip !== I ? ce(F({}, T), {
                                        x: g.caretX,
                                        y: g.caretY,
                                        dateLabel: (_ = g.title) == null ? void 0 : _[0],
                                        value: $n((P = ($ = (A = (R = g.dataPoints) == null ? void 0 : R[0]) == null ? void 0 : A.parsed) == null ? void 0 : $.y) != null ? P : 0),
                                        opacity: g.opacity,
                                        flip: I
                                    }) : T
                                })
                            }
                        },
                        dropShadow: !1,
                        crosshair: {
                            line: {
                                color: C ? "rgba(255, 255, 255, 0.3)" : "rgba(0, 0, 0, 0.3)",
                                width: .5
                            },
                            zoom: {
                                enabled: !1
                            }
                        }
                    }
                },
                data: v
            }), a.jsx(Wy, {
                tooltipData: i
            })]
        })
    })
}

function Wy({
    tooltipData: t
}) {
    return !t || !t.opacity ? null : a.jsx("div", {
        style: {
            left: t.x - 5,
            top: 10,
            transform: "translate(-50%, -50%)"
        },
        className: W("text-token-main-surface-primary dark:bg-token-main-surface-secondary pointer-events-none absolute translate-y-[-100%] rounded-lg bg-black px-2 py-1 font-mono font-semibold whitespace-nowrap dark:text-white"),
        children: a.jsx("div", {
            className: "text-xs",
            children: t.dateLabel
        })
    })
}

function zy(t, e, s) {
    const n = t.createLinearGradient(0, e.top, 0, e.bottom);
    return n.addColorStop(0, s ? fr(.4) : mr(.4)), n.addColorStop(1, s ? fr(0) : mr(0)), n
}

function $n(t) {
    return new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: "USD"
    }).format(t)
}

function gs({
    label: t,
    value: e,
    className: s
}) {
    return a.jsxs("div", {
        className: W("flex w-full flex-1 flex-row justify-between text-sm", s),
        children: [a.jsx("span", {
            className: "text-token-text-secondary font-normal whitespace-nowrap",
            children: t
        }), a.jsx("span", {
            className: "text-token-text-primary font-normal whitespace-nowrap",
            children: e
        })]
    })
}

function Hy({
    metrics: t
}) {
    const e = Ne(),
        s = !!(t.marketCap && t.peRatio && t.eps);
    return a.jsx("div", {
        className: "border-token-border-default flex flex-col gap-1 rounded-b-lg border-t bg-[#f4f4f4] px-4 py-3 dark:bg-[#393939]",
        children: a.jsxs("div", {
            className: W("grid grid-cols-2 gap-x-10 gap-y-3 lg:grid-cols-3 lg:gap-x-6"),
            children: [a.jsx(gs, {
                label: e.formatMessage({
                    id: "MDHEj7",
                    defaultMessage: "Open"
                }),
                value: e.formatNumber(t.openPrice, {
                    style: "decimal",
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }),
                className: "order-1"
            }), a.jsx(gs, {
                label: e.formatMessage({
                    id: "PboNMC",
                    defaultMessage: "Volume"
                }),
                value: e.formatNumber(t.intradayVolume, {
                    notation: "compact",
                    maximumFractionDigits: 1
                }),
                className: W("order-2", !s && "lg:order-last")
            }), a.jsxs("div", {
                className: "order-4 row-span-2 flex flex-col gap-3",
                children: [a.jsx(gs, {
                    label: e.formatMessage({
                        id: "bresUW",
                        defaultMessage: "Day Low"
                    }),
                    value: e.formatNumber(t.intradayLow, {
                        style: "decimal",
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    })
                }), a.jsx(gs, {
                    label: e.formatMessage({
                        id: "oWyv5V",
                        defaultMessage: "Day High"
                    }),
                    value: e.formatNumber(t.intradayHigh, {
                        style: "decimal",
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    })
                })]
            }), a.jsxs("div", {
                className: "order-5 row-span-2 flex flex-col gap-3",
                children: [a.jsx(gs, {
                    label: e.formatMessage({
                        id: "DcEYIK",
                        defaultMessage: "Year Low"
                    }),
                    value: e.formatNumber(t.fiftyTwoWeekLow, {
                        style: "decimal",
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    })
                }), a.jsx(gs, {
                    label: e.formatMessage({
                        id: "ZfFtJ4",
                        defaultMessage: "Year High"
                    }),
                    value: e.formatNumber(t.fiftyTwoWeekHigh, {
                        style: "decimal",
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    })
                })]
            }), t.marketCap && a.jsx(gs, {
                label: e.formatMessage({
                    id: "o7Vbua",
                    defaultMessage: "Market Cap (TTM)"
                }),
                value: e.formatNumber(t.marketCap, {
                    notation: "compact",
                    maximumFractionDigits: 2
                }),
                className: "order-last lg:order-3"
            }), t.peRatio && t.eps && a.jsxs(a.Fragment, {
                children: [a.jsx(gs, {
                    label: e.formatMessage({
                        id: "edGd+S",
                        defaultMessage: "EPS (TTM)"
                    }),
                    value: e.formatNumber(t.eps, {
                        style: "decimal",
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    }),
                    className: "order-last"
                }), a.jsx(gs, {
                    label: e.formatMessage({
                        id: "uX5YWo",
                        defaultMessage: "P/E Ratio (TTM)"
                    }),
                    value: e.formatNumber(t.peRatio, {
                        style: "decimal",
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    }),
                    className: "order-last"
                })]
            })]
        })
    })
}

function Uy({
    data: t,
    priceChange: e,
    highlightedPrice: s,
    extendedPriceChange: n,
    url: o
}) {
    var i;

    function r(l, c = "intraday", d = null) {
        const {
            isUp: u,
            changePercentage: f,
            changeLabel: h,
            changeAmount: m
        } = l, b = Math.abs(f).toFixed(2), y = $n(m);
        return a.jsxs("span", {
            className: "flex min-w-0 items-center gap-1",
            children: [c === "extended_hours" && d != null && a.jsx("span", {
                className: "font-semibold",
                children: a.jsx(me, {
                    id: "HWwWpW",
                    defaultMessage: "{price}",
                    values: {
                        price: d
                    }
                })
            }), a.jsx("span", {
                className: W("font-semibold", u ? Ll : Dl),
                children: a.jsx(me, {
                    id: "3x4Lkl",
                    defaultMessage: "{sign}{changeAmount}",
                    values: {
                        changeAmount: y,
                        sign: u ? "+" : ""
                    }
                })
            }), a.jsx("span", {
                className: W("font-semibold", u ? Ll : Dl),
                children: a.jsx(me, {
                    id: "MbfF1T",
                    defaultMessage: "({sign}{changePercentage}%)",
                    values: {
                        changePercentage: b,
                        sign: u ? "+" : "-"
                    }
                })
            }), c === "extended_hours" ? a.jsx("span", {
                className: "text-token-text-primary min-w-0 truncate",
                children: h
            }) : a.jsx("span", {
                className: "text-token-text-primary min-w-0 truncate",
                children: h
            })]
        })
    }
    return a.jsxs("div", {
        children: [a.jsx("div", {
            className: "mt-2 text-sm",
            children: t ? a.jsx(me, {
                id: "+2WHuv",
                defaultMessage: "{name} ({ticker})",
                values: {
                    name: t.asset.name,
                    ticker: t.asset.ticker
                }
            }) : a.jsx("div", {
                className: "w-32 font-medium",
                children: a.jsx(Mn, {
                    index: 9,
                    width: 100
                })
            })
        }), a.jsx("div", {
            className: "text-token-text-tertiary text-sm",
            children: t ? a.jsx(a.Fragment, {
                children: o != null && a.jsxs(a.Fragment, {
                    children: [" · ", a.jsx(Ds, {
                        href: o,
                        className: "text-token-link hover:underline",
                        children: Ar(o, "hostname")
                    })]
                })
            }) : a.jsx("div", {
                className: "mt-2 w-36",
                children: a.jsx(Mn, {
                    index: 6,
                    width: 100
                })
            })
        }), a.jsx("div", {
            className: "mt-2 flex text-4xl font-semibold",
            children: t ? a.jsx(me, {
                id: "s+1uly",
                defaultMessage: "{price}",
                values: {
                    price: s != null ? s : $n(t.price.price)
                }
            }) : a.jsx("div", {
                className: "w-32",
                children: a.jsx(Mn, {
                    index: 0,
                    width: 100
                })
            })
        }), a.jsx("div", {
            className: "mt-2 flex items-center justify-start gap-1 text-sm",
            children: e ? r(e) : a.jsx("div", {
                className: "mt-2 w-40",
                children: a.jsx(Mn, {
                    index: 3,
                    width: 100
                })
            })
        }), a.jsx("div", {
            className: "mt-0.5 flex items-center justify-start gap-1 text-sm",
            children: ((i = t == null ? void 0 : t.price) == null ? void 0 : i.extended_price) != null && n != null && r(n, "extended_hours", $n(t.price.extended_price))
        })]
    })
}

function Gy({
    contentReference: t,
    trackContentReferenceEvent: e
}) {
    var C, v, g, k, E, j, M, T, N, I, _, R, A, $, P;
    const s = Ne();
    x.useEffect(() => {
        e("Search Content Reference Shown", "search_content_reference_shown", "stock")
    }, [e]);
    const n = Ay((C = t == null ? void 0 : t.stock) == null ? void 0 : C.histories),
        o = t == null ? void 0 : t.stock,
        [r, i] = x.useState(n),
        [l, c] = x.useState(null),
        d = r === "1d",
        u = (k = (g = (v = o == null ? void 0 : o.histories) == null ? void 0 : v.quotes) == null ? void 0 : g[r != null ? r : ""]) == null ? void 0 : k[0],
        f = r && r in tr ? r : void 0,
        h = o && (u && !d ? {
            changePercentage: (o.price.price - u.close) / u.close * 100,
            changeAmount: o.price.price - u.close,
            changeLabel: f ? s.formatMessage(tr[f]) : "",
            isUp: o.price.price > u.close
        } : o.price.change_percent && o.price.change ? {
            changePercentage: o.price.change_percent * 100,
            changeAmount: o.price.change,
            changeLabel: Vy(o.price.latest_trade_timestamp, o.asset.timezone, s),
            isUp: o.price.change ? o.price.change > 0 : !1
        } : null),
        m = o && o.price.extended_price != null && o.price.extended_change_percent != null && o.price.extended_change != null ? {
            changePercentage: o.price.extended_change_percent * 100,
            changeAmount: o.price.extended_change,
            changeLabel: s.formatMessage((E = qy(o.price.market_status)) != null ? E : tr.extended),
            isUp: o.price.extended_change > 0
        } : null,
        {
            fiftyTwoWeekHigh: b,
            fiftyTwoWeekLow: y
        } = x.useMemo(() => {
            var G;
            const U = (G = o == null ? void 0 : o.histories) == null ? void 0 : G.quotes["1y"];
            if (!U) return {
                fiftyTwoWeekHigh: null,
                fiftyTwoWeekLow: null
            };
            const z = U.map(O => O.high).filter(O => O != null),
                B = U.map(O => O.low).filter(O => O != null);
            return {
                fiftyTwoWeekHigh: z.length > 0 ? Math.max(...z) : null,
                fiftyTwoWeekLow: B.length > 0 ? Math.min(...B) : null
            }
        }, [(j = o == null ? void 0 : o.histories) == null ? void 0 : j.quotes]),
        p = o != null && o.price.open_price && o.price.intraday_high && o.price.intraday_low && o.price.intraday_volume && b && y ? {
            openPrice: o.price.open_price,
            intradayHigh: o.price.intraday_high,
            intradayLow: o.price.intraday_low,
            intradayVolume: o.price.intraday_volume,
            fiftyTwoWeekHigh: b,
            fiftyTwoWeekLow: y,
            marketCap: (T = (M = o.metrics) == null ? void 0 : M.market_cap) != null ? T : void 0,
            peRatio: (I = (N = o.metrics) == null ? void 0 : N.pe_ratio) != null ? I : void 0,
            eps: (R = (_ = o.metrics) == null ? void 0 : _.eps) != null ? R : void 0
        } : null,
        w = p != null;
    return a.jsxs("div", {
        "data-testid": "finance-widget",
        className: W("border-token-border-default mb-2 flex min-h-[480px] flex-col gap-8 rounded-lg border"),
        children: [a.jsxs("div", {
            className: "mx-6 flex flex-wrap items-end justify-between",
            children: [a.jsx(Uy, {
                data: o != null ? o : null,
                highlightedPrice: l,
                priceChange: h != null ? h : null,
                extendedPriceChange: m != null ? m : null,
                url: (A = t == null ? void 0 : t.url) != null ? A : null
            }), a.jsx("div", {
                className: "mt-4",
                children: a.jsx($y, {
                    selectedInterval: r,
                    onSelectHistoryInterval: i,
                    histories: o == null ? void 0 : o.histories
                })
            })]
        }), a.jsx("div", {
            className: "mx-6 h-[340px]",
            children: a.jsx(Fy, {
                isUp: ($ = h == null ? void 0 : h.isUp) != null ? $ : !1,
                selectedInterval: r,
                histories: o == null ? void 0 : o.histories,
                setHighlightedPrice: c,
                onSelectHistoryInterval: U => i(U),
                latestTradingPeriod: o == null ? void 0 : o.asset.latest_trading_period,
                timezone: (P = o == null ? void 0 : o.asset.timezone) != null ? P : null
            })
        }), w && a.jsx("div", {
            className: "-mt-4",
            children: a.jsx(Hy, {
                metrics: p
            })
        })]
    })
}

function qy(t) {
    if (t == null) return null;
    const e = t.toLowerCase();
    return e === "premarket" || e === "open" ? Tn({
        id: "By+pvF",
        defaultMessage: "Pre-Market"
    }) : e === "afterhours" || e === "closed" ? Tn({
        id: "aLCg3c",
        defaultMessage: "After Hours"
    }) : Tn({
        id: "2p526c",
        defaultMessage: "Extended Hours"
    })
}

function Vy(t, e, s) {
    function n(o, r) {
        const l = In(new Date, r),
            c = s.formatDate(l, {
                year: "numeric",
                month: "2-digit",
                day: "2-digit"
            }),
            d = Va(o * 1e3),
            u = In(d, r),
            f = s.formatDate(u, {
                year: "numeric",
                month: "2-digit",
                day: "2-digit"
            });
        return c === f
    }
    if (!t || !e || n(t, e)) return s.formatMessage(tr["1d"]); {
        const o = Va(t * 1e3),
            r = In(o, e);
        return s.formatDate(r, {
            month: "long",
            day: "numeric"
        })
    }
}
const tr = Ts({
    "1d": {
        id: "SMdcuo",
        defaultMessage: "Today"
    },
    extended: {
        id: "2p526c",
        defaultMessage: "Extended Hours"
    },
    "5d": {
        id: "HCA6lr",
        defaultMessage: "Past 5 days"
    },
    "1m": {
        id: "DJpPMq",
        defaultMessage: "Past month"
    },
    "6m": {
        id: "1mUJ2L",
        defaultMessage: "Past 6 months"
    },
    ytd: {
        id: "b9KkhV",
        defaultMessage: "Year to date"
    },
    "1y": {
        id: "XnvD9A",
        defaultMessage: "Past year"
    },
    "5y": {
        id: "DfI1RB",
        defaultMessage: "Past 5 years"
    },
    max: {
        id: "WzOhuU",
        defaultMessage: "Max"
    }
});

function Ky({
    metadata: t,
    trackContentReferenceEvent: e
}) {
    const s = x.useCallback(l => {
        e("link_action", null, t.type, {
            url: t.url,
            title: t.title,
            pub_date: null,
            sub_pill_index: null,
            link_type: "link_title",
            action: l
        })
    }, [t.title, t.type, t.url, e]);
    x.useEffect(() => {
        s("show")
    }, [s]);
    const [n, o] = x.useState(!1), r = () => {
        n || (s("hover"), o(!0))
    }, i = () => {
        s("click")
    };
    return a.jsx(Ds, {
        href: t.url,
        onClick: i,
        onMouseEnter: r,
        onFocus: r,
        className: "underline",
        children: t.title
    })
}
const Xy = {
    google_maps: {
        title: "Google Maps"
    }
};

function Yy({
    metadata: t,
    trackContentReferenceEvent: e
}) {
    var n, o;
    x.useEffect(() => {
        e("Search Content Reference Shown", "search_content_reference_shown", t.type)
    }, [e, t.type]);
    const s = (o = (n = Xy[t.provider]) == null ? void 0 : n.title) != null ? o : "Maps";
    return a.jsx("span", {
        children: a.jsx(me, {
            id: "ZSUz1k",
            defaultMessage: " ({link}) ",
            values: {
                link: a.jsx(Ds, {
                    href: t.url,
                    children: s
                })
            }
        })
    })
}

function Zy(t) {
    "use forget";
    const e = xe.c(25),
        {
            metadata: s,
            trackContentReferenceEvent: n,
            isFirstAssistantContent: o
        } = t,
        r = et();
    let i;
    e[0] !== r ? (i = jr(r), e[0] = r, e[1] = i) : i = e[1];
    const l = i,
        c = s.items.length > 0,
        d = x.useRef(n);
    let u, f;
    e[2] !== n ? (u = () => {
        d.current = n
    }, f = [n], e[2] = n, e[3] = u, e[4] = f) : (u = e[3], f = e[4]), x.useEffect(u, f);
    let h, m;
    e[5] !== c ? (h = () => {
        c && d.current("Search Content Reference Shown", "search_content_reference_shown", "nav_list")
    }, m = [c], e[5] = c, e[6] = h, e[7] = m) : (h = e[6], m = e[7]), x.useEffect(h, m);
    let b;
    e[8] !== n ? (b = (T, N) => {
        n("link_action", null, "nav_list", ce(F({}, zl(T, N)), {
            action: "click"
        }))
    }, e[8] = n, e[9] = b) : b = e[9];
    const y = b;
    let p;
    e[10] !== n ? (p = (T, N) => {
        n("link_action", null, "nav_list", ce(F({}, zl(T, N)), {
            action: "show"
        }))
    }, e[10] = n, e[11] = p) : p = e[11];
    const w = p,
        C = l && o,
        v = s.title && !C;
    if (s.items.length === 0) return null;
    const g = !C && "mt-6";
    let k;
    e[12] !== g ? (k = W("mb-1", g), e[12] = g, e[13] = k) : k = e[13];
    let E;
    e[14] !== s.title || e[15] !== v ? (E = v && a.jsx("div", {
        className: "text-token-text-primary -mb-1 pb-3 font-semibold",
        children: s.title
    }), e[14] = s.title, e[15] = v, e[16] = E) : E = e[16];
    let j;
    e[17] !== y || e[18] !== w || e[19] !== s.items ? (j = a.jsx(lu, {
        items: s.items,
        onCardRender: Jy,
        onCardShown: w,
        onCardClicked: y,
        showGradient: !1,
        cardClassName: "transition-all duration-200 border-token-border-default hover:border-light border rounded-xl bg-clip-padding hover:shadow-md overflow-hidden"
    }), e[17] = y, e[18] = w, e[19] = s.items, e[20] = j) : j = e[20];
    let M;
    return e[21] !== E || e[22] !== j || e[23] !== k ? (M = a.jsxs("div", {
        className: k,
        "data-testid": "nav-list-widget",
        children: [E, j]
    }), e[21] = E, e[22] = j, e[23] = k, e[24] = M) : M = e[24], M
}

function Jy(t) {
    return a.jsx(Qy, {
        item: t
    })
}

function Qy({
    item: t
}) {
    var i, l;
    const {
        isSuccess: e
    } = vi((i = t.thumbnail_url) != null ? i : void 0, "NavListItem"), s = Ne(), n = et(), o = jr(n), r = Hf(s, t.pub_date);
    return a.jsxs(Ds, {
        className: "flex flex-col items-center gap-4 overflow-hidden pb-6",
        href: t.url,
        children: [e && t.thumbnail_url ? a.jsx("div", {
            className: "relative h-36 w-full overflow-hidden",
            children: a.jsx("img", {
                src: t.thumbnail_url,
                className: "m-0 h-full w-full",
                style: {
                    objectFit: "cover"
                },
                alt: t.title
            })
        }) : a.jsxs("div", {
            className: W("icon-bg relative flex h-36 w-full shrink-0 items-center justify-center overflow-hidden", o && "bg-token-bg-secondary"),
            children: [a.jsx("div", {
                className: "absolute inset-0 flex items-center justify-center bg-cover bg-center bg-no-repeat blur-3xl",
                children: a.jsx(Jo, {
                    url: t.url,
                    size: 256,
                    minSize: 128,
                    className: "mix-soft-light opacity-30 dark:opacity-20"
                })
            }), a.jsx("div", {
                className: "absolute flex h-10 w-10 items-center justify-center",
                children: a.jsx(Jo, {
                    url: t.url,
                    size: 128,
                    minSize: 80,
                    className: "icon-xl rounded-full"
                })
            })]
        }), a.jsxs("div", {
            className: W("flex flex-col gap-2 overflow-hidden px-4 text-ellipsis", o && "w-full items-start"),
            children: [a.jsxs("div", {
                className: "text-token-text-primary flex items-center gap-1.5 text-xs",
                children: [a.jsx(Jo, {
                    url: t.url,
                    size: 32,
                    minSize: 16,
                    className: "icon-xs my-0 rounded-full"
                }), (l = t.attribution) != null ? l : Ar(t.url)]
            }), a.jsx("div", {
                className: "text-token-text-primary decoration-token-link line-clamp-5 text-sm font-medium",
                children: t.title
            }), r && a.jsx("div", {
                className: "text-token-text-secondary text-xs",
                children: r
            })]
        })]
    })
}
const zl = (t, e) => ({
        url: t.url,
        title: t.title,
        section_index: e,
        link_type: "text",
        section: "nav_list",
        section_location: "response"
    }),
    e0 = "/cdn/assets/missing-logo-h96s4tk9.webp",
    Hl = {
        src: e0
    };

function mu({
    team: t,
    className: e
}) {
    var r;
    const [s, n] = x.useState((r = t.logo) != null ? r : Hl.src), o = () => {
        ts.addError("Unable to load sports widget logo", {
            name: t.name,
            logo: t.logo
        }), n(Hl.src)
    };
    return a.jsx("img", {
        src: s,
        alt: t.name,
        className: e,
        onError: o
    })
}
const Un = ["ipl"],
    Ul = 6,
    Rs = "home",
    $s = "away";

function t0({
    scheduleRef: t,
    trackContentReferenceEvent: e
}) {
    var b, y, p, w;
    const [s, n] = x.useState(!0), o = Ne(), r = t.games.length > 0, i = t.league.id, l = Uf(), c = Zn();
    if (x.useEffect(() => {
            r && e("Search Content Reference Shown", "search_content_reference_shown", "sports", {
                hasSchedule: !0
            })
        }, [r]), !r) return null;
    const u = ((y = (b = o.formatDateToParts(new Date, {
        timeZoneName: "long"
    }).find(C => C.type === "timeZoneName")) == null ? void 0 : b.value) != null ? y : Intl.DateTimeFormat().resolvedOptions().timeZone).replace(/Daylight|Standard/g, "");
    let f = t.games;
    const h = C => Math.abs(new Date().getTime() - new Date(C.date).getTime());
    h(f[0]) > h(f[f.length - 1]) && (f = f.slice().reverse());
    const m = s ? f.slice(0, Ul) : f;
    return a.jsxs("div", {
        className: "not-prose mb-3",
        "data-testid": "sports-schedule-widget",
        children: [a.jsx("div", {
            className: "font-semibold",
            children: a.jsx(me, {
                id: "LA6z9q",
                defaultMessage: "{league} Schedule",
                values: {
                    league: t.league.display_name
                }
            })
        }), a.jsx("div", {
            className: "text-token-text-secondary text-sm",
            children: u
        }), m.length === 1 ? a.jsx("div", {
            children: a.jsx(wi, {
                children: a.jsx(On.div, {
                    initial: {
                        opacity: 0,
                        y: 15
                    },
                    animate: {
                        opacity: 1,
                        y: 0
                    },
                    exit: {
                        opacity: 0,
                        y: -15
                    },
                    transition: {
                        duration: .2
                    },
                    children: a.jsx("div", {
                        className: "border-token-border-medium mt-3 rounded-xl border py-3",
                        children: a.jsx(n0, {
                            game: m[0],
                            useAlias: Un.includes(i),
                            leagueId: i,
                            activeTeam: (w = (p = m[0]) == null ? void 0 : p.active_team) != null ? w : null,
                            isMobile: c
                        })
                    })
                })
            })
        }) : a.jsx("div", {
            className: "grid grid-cols-1 pt-3 lg:grid-cols-2",
            children: a.jsx(wi, {
                children: m.map((C, v) => {
                    var g;
                    return a.jsx(On.div, {
                        initial: {
                            opacity: 0,
                            y: 15
                        },
                        animate: {
                            opacity: 1,
                            y: 0,
                            transition: {
                                delay: v * .04
                            }
                        },
                        exit: {
                            opacity: 0,
                            y: -15
                        },
                        transition: {
                            duration: .2
                        },
                        children: a.jsx("div", {
                            className: W("border-token-border-medium border-b py-3", v % 2 === 0 && "lg:border-e lg:pe-4", v % 2 === 1 && "lg:ps-4", Math.floor(v / 2) === Math.ceil(f.length / 2) - 1 && "lg:border-b-0", v === f.length - 1 && "border-b-0"),
                            children: a.jsx(s0, {
                                game: C,
                                useAlias: (l || c) && Un.includes(i),
                                leagueId: i,
                                activeTeam: (g = C.active_team) != null ? g : null
                            })
                        })
                    }, v)
                })
            })
        }), f.length > Ul && a.jsx("div", {
            className: "mt-2 flex items-center justify-between",
            children: a.jsx("button", {
                className: "flex items-center text-sm font-semibold",
                onClick: () => n(!s),
                children: s ? a.jsx(me, {
                    id: "BH/Ee5",
                    defaultMessage: "Show more {icon}",
                    values: {
                        icon: a.jsx(ud, {
                            className: "mb-[-2px]"
                        })
                    }
                }) : a.jsx(me, {
                    id: "Z9BlEu",
                    defaultMessage: "Show less {icon}",
                    values: {
                        icon: a.jsx(Fh, {
                            className: "mb-[-2px]"
                        })
                    }
                })
            })
        })]
    })
}

function s0({
    game: t,
    useAlias: e = !1,
    leagueId: s,
    activeTeam: n
}) {
    var u, f;
    const o = gu(t),
        r = [t.first_team_info, t.second_team_info],
        i = (u = r.find(h => h.location === Rs)) != null ? u : t.first_team_info,
        l = (f = r.find(h => h.location === $s)) != null ? f : t.second_team_info,
        c = (o == null ? void 0 : o.team.name) === (i == null ? void 0 : i.team.name),
        d = (o == null ? void 0 : o.team.name) === (l == null ? void 0 : l.team.name);
    return a.jsxs("div", {
        className: "flex w-full gap-1.5 py-3 text-base",
        children: [a.jsxs("div", {
            className: "flex flex-auto flex-col items-start gap-1 pe-3",
            children: [a.jsx(gr, {
                team: l.team,
                isWinner: d,
                isActive: n === $s,
                logoSize: "small",
                useAlias: e
            }), a.jsx(gr, {
                team: i.team,
                isWinner: c,
                isActive: n === Rs,
                logoSize: "small",
                useAlias: e
            })]
        }), a.jsxs("div", {
            className: W("flex flex-none flex-col items-start gap-1", Un.includes(s) && "me-4"),
            children: [a.jsx(pr, {
                score: l.score,
                scoreSuffix: l.score_suffix,
                scoreParenthetical: l.score_parenthetical ? {
                    message: l.score_parenthetical,
                    position: "right"
                } : null,
                isWinner: d,
                negateScore: hr(s, $s, n)
            }), a.jsx(pr, {
                score: i.score,
                scoreSuffix: i.score_suffix,
                scoreParenthetical: i.score_parenthetical ? {
                    message: i.score_parenthetical,
                    position: "right"
                } : null,
                isWinner: c,
                negateScore: hr(s, Rs, n)
            })]
        }), a.jsx("div", {
            className: "flex min-w-24 flex-none flex-col items-end justify-center gap-1 text-sm",
            children: a.jsx(pu, {
                game: t
            })
        })]
    })
}

function n0({
    game: t,
    useAlias: e = !1,
    leagueId: s,
    activeTeam: n,
    isMobile: o
}) {
    var f, h;
    const r = gu(t),
        i = [t.first_team_info, t.second_team_info],
        l = (f = i.find(m => m.location === Rs)) != null ? f : t.first_team_info,
        c = (h = i.find(m => m.location === $s)) != null ? h : t.second_team_info,
        d = (r == null ? void 0 : r.team.name) === (l == null ? void 0 : l.team.name),
        u = (r == null ? void 0 : r.team.name) === (c == null ? void 0 : c.team.name);
    return a.jsxs("div", {
        className: "flex w-full py-3 text-base",
        children: [a.jsx("div", {
            className: "flex flex-1 items-center justify-center px-2",
            children: a.jsx(gr, {
                team: c.team,
                isWinner: u,
                isActive: n === $s,
                useAlias: e,
                layoutDirection: o ? "column" : "row"
            })
        }), a.jsx("div", {
            className: "ms-2 flex items-center justify-start sm:ms-8",
            children: a.jsx(pr, {
                score: c.score,
                scoreSuffix: c.score_suffix,
                scoreParenthetical: c.score_parenthetical ? {
                    message: c.score_parenthetical,
                    position: "bottom"
                } : null,
                isWinner: u,
                negateScore: hr(s, $s, n),
                className: "text-sm font-semibold sm:text-lg"
            })
        }), a.jsx("div", {
            className: "mx-2 flex w-24 shrink flex-col items-center justify-center gap-1 align-middle text-sm",
            children: a.jsx(pu, {
                game: t
            })
        }), a.jsx("div", {
            className: "me-2 flex items-center justify-end sm:me-8",
            children: a.jsx(pr, {
                score: l.score,
                scoreSuffix: l.score_suffix,
                scoreParenthetical: l.score_parenthetical ? {
                    message: l.score_parenthetical,
                    position: "bottom"
                } : null,
                isWinner: d,
                negateScore: hr(s, Rs, n),
                className: "text-sm font-semibold sm:text-lg"
            })
        }), a.jsx("div", {
            className: "flex flex-1 items-center justify-center md:px-2",
            children: a.jsx(gr, {
                team: l.team,
                isWinner: d,
                isActive: n === Rs,
                useAlias: e,
                layoutDirection: o ? "column" : "row"
            })
        })]
    })
}

function hu(t) {
    return t.live ? "live" : new Date(t.date) < new Date ? "complete" : "scheduled"
}

function gu(t) {
    return hu(t) !== "complete" || t.first_team_info.score == null || t.second_team_info.score == null ? null : t.first_team_info.score > t.second_team_info.score ? t.first_team_info : t.second_team_info
}

function hr(t, e, s) {
    return Un.includes(t) && e === Rs && s === $s
}

function gr({
    team: t,
    isWinner: e,
    isActive: s,
    logoSize: n,
    useAlias: o = !1,
    layoutDirection: r = "row"
}) {
    return a.jsxs("span", {
        className: W("flex items-center gap-1", e && "font-semibold", "max-w-64 lg:max-w-52 xl:max-w-64", r === "column" && "flex-col"),
        children: [t.logo && a.jsx(mu, {
            team: {
                name: t.name,
                logo: t.logo
            },
            className: W(n === "small" ? "w-6" : "w-8")
        }), a.jsx("span", {
            className: "truncate",
            children: o ? t.alias : t.name
        }), s && a.jsx("span", {
            className: "bg-token-surface-error inline-block h-2 w-2 rounded-full"
        })]
    })
}

function pr({
    score: t,
    scoreSuffix: e,
    scoreParenthetical: s,
    isWinner: n,
    negateScore: o = !1,
    className: r
}) {
    const i = Ne();
    return t == null ? null : a.jsxs("span", {
        className: W(n && "font-semibold", r),
        children: [o ? i.formatMessage({
            id: "sports.dash",
            defaultMessage: "-"
        }) : t, e && !o && a.jsx("span", {
            children: e
        }), s && !o && a.jsx("span", {
            className: W("text-token-text-secondary font-normal", s.position === "right" && "ms-1", s.position === "bottom" && "mx-auto block text-center"),
            children: "(".concat(s.message, ")")
        })]
    })
}

function pu({
    game: t
}) {
    const e = Ne();
    switch (hu(t)) {
        case "live":
            return a.jsxs(a.Fragment, {
                children: [a.jsx(o0, {}), a.jsx("div", {
                    children: t.details
                })]
            });
        case "complete":
            return a.jsxs(a.Fragment, {
                children: [a.jsx("div", {
                    className: "font-semibold",
                    children: a.jsx(me, {
                        id: "q/iMZL",
                        defaultMessage: "Final"
                    })
                }), a.jsx("div", {
                    className: "text-token-text-secondary",
                    children: ki(e, new Date(t.date))
                })]
            });
        case "scheduled":
            {
                const s = new Date(t.date);
                return isNaN(s.getTime()) ? null : a.jsxs(a.Fragment, {
                    children: [a.jsx("div", {
                        children: ki(e, s)
                    }), a.jsx("div", {
                        className: "text-token-text-secondary",
                        children: e.formatDate(s, {
                            timeStyle: "short"
                        })
                    })]
                })
            }
    }
}

function o0() {
    return a.jsx("div", {
        className: "bg-token-surface-error rounded-[4px] px-1.5 py-1 text-xs font-semibold text-white",
        children: a.jsx(me, {
            id: "vObALn",
            defaultMessage: "Live"
        })
    })
}

function r0({
    standingsRef: t,
    trackContentReferenceEvent: e
}) {
    const [s, n] = x.useState(0), o = t.conferences.length > 0, r = Zn(), i = t.league.id;
    x.useEffect(() => {
        o && e("Search Content Reference Shown", "search_content_reference_shown", "sports", {
            hasStandings: !0
        })
    }, [o]);
    const l = t.conferences[s],
        c = t.conferences.length > 1 ? t.conferences.map((d, u) => a.jsx("button", {
            className: W(s === u ? "text-token-text-primary" : "text-token-text-tertiary", "text-sm font-semibold"),
            onClick: () => n(u),
            children: d.name
        }, d.name)) : null;
    return a.jsxs("div", {
        "data-testid": "sports-standings-widget",
        children: [c && a.jsx("div", {
            className: "flex gap-4",
            children: c
        }), a.jsx("div", {
            className: "mt-3",
            children: l.divisions.map(d => d.name ? a.jsx("div", {
                className: "mt-3",
                children: a.jsx(Gl, {
                    division: d,
                    teamsColumnHeader: d.name
                })
            }, d.name) : a.jsx(Gl, {
                division: d,
                useAlias: r && Un.includes(i)
            }))
        })]
    })
}

function Gl({
    division: t,
    teamsColumnHeader: e,
    useAlias: s
}) {
    const n = t.headers.map(o => o.key);
    return a.jsxs(Kt.Root, {
        size: "compact",
        className: "not-prose",
        children: [a.jsxs(Kt.Header, {
            children: [a.jsx(i0, {
                children: e != null ? e : a.jsx(me, {
                    id: "kKSGje",
                    defaultMessage: "Team"
                })
            }), t.headers.map(o => a.jsx(xu, {
                textAlign: "center",
                className: "min-w-11 px-0!",
                children: a.jsx(ql, {
                    data: o
                })
            }, o.key))]
        }), a.jsx(Kt.Body, {
            children: t.teams.map(({
                team: o,
                data: r
            }, i) => {
                const l = r.reduce((c, d) => (c[d.key] = d, c), {});
                return a.jsxs(Kt.Row, {
                    children: [a.jsx(Kt.Cell, {
                        className: "w-full border-0! py-0! ps-0!",
                        children: a.jsxs("div", {
                            className: "flex items-center",
                            children: [a.jsx("div", {
                                className: "text-token-text-tertiary me-2 w-4 whitespace-nowrap tabular-nums",
                                children: i + 1
                            }), a.jsxs("div", {
                                className: "flex items-center justify-start gap-2",
                                children: [a.jsx(mu, {
                                    team: o,
                                    className: "w-6"
                                }), a.jsx("span", {
                                    className: "text-base whitespace-nowrap",
                                    children: s ? o.alias : o.name
                                })]
                            })]
                        })
                    }), n.map(c => a.jsx(Kt.Cell, {
                        className: "min-w-11 border-0! px-0! py-0! text-start whitespace-nowrap tabular-nums",
                        textAlign: "center",
                        children: a.jsx(ql, {
                            data: l[c]
                        })
                    }, c))]
                }, o.name)
            })
        })]
    })
}

function ql({
    data: t
}) {
    switch (t.type) {
        case "text":
            return a.jsx(a.Fragment, {
                children: t.text
            });
        default:
            return a.jsx(a.Fragment, {
                children: t.alt
            })
    }
}
var Tc;
const xu = Tr(Kt.HeaderCell)(Tc || (Tc = Qs(["text-token-text-secondary font-normal! text-sm static! bg-transparent! border-token-border-default! border-t-0! border-s-0! border-e-0!"])));
var Ic;
const i0 = Tr(xu)(Ic || (Ic = Qs(["text-token-text-primary ps-0!"])));

function a0({
    metadata: t,
    trackContentReferenceEvent: e
}) {
    x.useEffect(() => {
        e("Search Content Reference Shown", "search_content_reference_shown", t.type)
    }, [e, t.type]);
    const s = Ne(),
        n = In(t.utc_time, t.utc_offset),
        o = s.formatDate(n, {
            hour: "numeric",
            minute: "numeric"
        });
    return a.jsx("span", {
        children: o
    })
}

function l0({
    metadata: t,
    trackContentReferenceEvent: e
}) {
    return x.useEffect(() => {
        e("Search Content Reference Shown", "search_content_reference_shown", t.type)
    }, [e, t.type]), a.jsx("div", {
        children: t.url ? a.jsx(up, {
            webpageItem: {
                url: t.url,
                title: t.description,
                pub_date: null,
                snippet: "",
                attributions: null
            },
            className: "inline-flex flex-col",
            children: a.jsx(Ds, {
                href: t.url,
                className: "font-semibold!",
                children: t.description
            })
        }) : a.jsx("div", {
            className: "font-semibold!",
            children: t.description
        })
    })
}

function c0({
    videoId: t,
    title: e = "YouTube video player",
    fallbackText: s,
    cookieLess: n = !0,
    timeoutMs: o = 5e3,
    className: r = ""
}) {
    const i = x.useRef(null),
        l = x.useRef(null),
        c = x.useRef(!1),
        [d, u] = x.useState("idle"),
        f = () => {
            c.current = !0, l.current && (clearTimeout(l.current), l.current = null)
        };
    if (x.useEffect(() => {
            u("loading"), c.current = !1;
            let m = null;
            return d0().then(() => {
                if (!i.current) return;
                i.current.textContent = "", m = document.createElement("div"), m.style.width = "200px", m.style.height = "150px", i.current.appendChild(m), l.current = window.setTimeout(() => {
                    c.current || u("timeout")
                }, o);
                const b = n ? "https://www.youtube-nocookie.com" : "https://www.youtube.com";
                new window.YT.Player(m, {
                    width: 200,
                    height: 150,
                    videoId: t,
                    host: b,
                    playerVars: {
                        rel: 0,
                        playsinline: 1,
                        origin: window.location.origin
                    },
                    events: {
                        onReady: () => {
                            f(), u("ready")
                        },
                        onError: () => {
                            f(), u("error")
                        }
                    }
                })
            }).catch(() => u("error")), () => {
                f()
            }
        }, [t, n, o]), d === "error" || d === "timeout") return a.jsx("a", {
        href: "https://www.youtube.com/watch?v=".concat(t),
        target: "_blank",
        rel: "noopener noreferrer",
        children: s
    });
    const h = n ? "https://www.youtube-nocookie.com" : "https://www.youtube.com";
    return a.jsxs(a.Fragment, {
        children: [a.jsx("div", {
            ref: i,
            "aria-hidden": !0,
            inert: !0,
            className: "hidden"
        }), a.jsx("iframe", {
            src: "".concat(h, "/embed/").concat(t),
            allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",
            referrerPolicy: "strict-origin-when-cross-origin",
            allowFullScreen: !0,
            className: r,
            title: e
        })]
    })
}

function d0() {
    return new Promise(t => {
        var s;
        if ((s = window.YT) != null && s.Player) return t();
        const e = window.onYouTubeIframeAPIReady;
        if (window.onYouTubeIframeAPIReady = () => {
                e == null || e(), t(), window.onYouTubeIframeAPIReady = e || (() => {})
            }, !document.querySelector("script[src*='youtube.com/iframe_api']")) {
            const n = document.createElement("script");
            n.src = "https://www.youtube.com/iframe_api", document.head.appendChild(n)
        }
    })
}

function u0({
    url: t,
    className: e,
    iframeClassName: s,
    iframeTitle: n
}) {
    let o;
    const r = W("aspect-video w-full", s),
        i = f0(t);
    i && (o = a.jsx(c0, {
        className: r,
        videoId: i,
        title: n,
        fallbackText: n != null ? n : a.jsx(me, {
            id: "sonic.video.youtube.title",
            defaultMessage: "YouTube video link"
        }),
        cookieLess: !1
    }));
    const l = m0(t);
    return l && (o = a.jsx(h0, {
        videoId: l,
        className: r,
        iframeTitle: n
    })), o ? a.jsx("div", {
        className: e,
        children: o
    }) : null
}

function f0(t) {
    const e = /^(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/|v\/|live\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/,
        s = t.match(e);
    return s ? s[1] : null
}

function m0(t) {
    const e = /vimeo\.com\/(?:channels\/(?:\w+\/)?|groups\/[^/]+\/videos\/|video\/|)(\d+)/,
        s = t.match(e);
    return s ? s[1] : null
}

function h0({
    videoId: t,
    className: e,
    iframeTitle: s
}) {
    return a.jsx(a.Fragment, {
        children: a.jsx("iframe", {
            className: e,
            src: "https://player.vimeo.com/video/".concat(t),
            frameBorder: "0",
            allow: "autoplay; fullscreen; picture-in-picture",
            allowFullScreen: !0,
            title: s
        })
    })
}

function g0({
    video: t,
    trackContentReferenceEvent: e
}) {
    const s = {
        url: t.url,
        title: t.title
    };
    return x.useEffect(() => {
        e("Search Content Reference Shown", "search_content_reference_shown", t.type, s)
    }, []), t.url == null || t.url === "" ? null : a.jsx("div", {
        className: "not-prose mb-3 flex flex-col gap-4 text-base",
        "data-testid": "video-widget",
        children: a.jsx(u0, {
            url: t.url,
            iframeClassName: "rounded-lg"
        })
    })
}
const p0 = "webp",
    x0 = 96,
    b0 = 96,
    y0 = "srgb",
    w0 = 4,
    _0 = "uchar",
    v0 = 288,
    k0 = !1,
    S0 = !1,
    E0 = !0,
    j0 = "/cdn/assets/cloud-foggy-o4a3hmky.webp",
    M0 = {
        format: p0,
        width: x0,
        height: b0,
        space: y0,
        channels: w0,
        depth: _0,
        density: v0,
        isProgressive: k0,
        hasProfile: S0,
        hasAlpha: E0,
        src: j0
    },
    C0 = "webp",
    T0 = 96,
    I0 = 96,
    N0 = "srgb",
    P0 = 4,
    R0 = "uchar",
    $0 = 288,
    A0 = !1,
    L0 = !1,
    D0 = !0,
    O0 = "/cdn/assets/cloudy-co8vwrk7.webp",
    F0 = {
        format: C0,
        width: T0,
        height: I0,
        space: N0,
        channels: P0,
        depth: R0,
        density: $0,
        isProgressive: A0,
        hasProfile: L0,
        hasAlpha: D0,
        src: O0
    },
    B0 = "webp",
    W0 = 96,
    z0 = 96,
    H0 = "srgb",
    U0 = 4,
    G0 = "uchar",
    q0 = 288,
    V0 = !1,
    K0 = !1,
    X0 = !0,
    Y0 = "/cdn/assets/heavy-snow-mke52kag.webp",
    Z0 = {
        format: B0,
        width: W0,
        height: z0,
        space: H0,
        channels: U0,
        depth: G0,
        density: q0,
        isProgressive: V0,
        hasProfile: K0,
        hasAlpha: X0,
        src: Y0
    },
    J0 = "webp",
    Q0 = 96,
    e2 = 96,
    t2 = "srgb",
    s2 = 4,
    n2 = "uchar",
    o2 = 288,
    r2 = !1,
    i2 = !1,
    a2 = !0,
    l2 = "/cdn/assets/light-snow-mcy1l7t9.webp",
    c2 = {
        format: J0,
        width: Q0,
        height: e2,
        space: t2,
        channels: s2,
        depth: n2,
        density: o2,
        isProgressive: r2,
        hasProfile: i2,
        hasAlpha: a2,
        src: l2
    },
    d2 = "webp",
    u2 = 96,
    f2 = 96,
    m2 = "srgb",
    h2 = 4,
    g2 = "uchar",
    p2 = 288,
    x2 = !1,
    b2 = !1,
    y2 = !0,
    w2 = "/cdn/assets/moon-drizzle-cplxr2ub.webp",
    _2 = {
        format: d2,
        width: u2,
        height: f2,
        space: m2,
        channels: h2,
        depth: g2,
        density: p2,
        isProgressive: x2,
        hasProfile: b2,
        hasAlpha: y2,
        src: w2
    },
    v2 = "webp",
    k2 = 96,
    S2 = 96,
    E2 = "srgb",
    j2 = 4,
    M2 = "uchar",
    C2 = 288,
    T2 = !1,
    I2 = !1,
    N2 = !0,
    P2 = "/cdn/assets/moon-hazy-jvgt25bp.webp",
    R2 = {
        format: v2,
        width: k2,
        height: S2,
        space: E2,
        channels: j2,
        depth: M2,
        density: C2,
        isProgressive: T2,
        hasProfile: I2,
        hasAlpha: N2,
        src: P2
    },
    $2 = "webp",
    A2 = 96,
    L2 = 96,
    D2 = "srgb",
    O2 = 4,
    F2 = "uchar",
    B2 = 288,
    W2 = !1,
    z2 = !1,
    H2 = !0,
    U2 = "/cdn/assets/moon-mostly-cloudy-cia3do0v.webp",
    G2 = {
        format: $2,
        width: A2,
        height: L2,
        space: D2,
        channels: O2,
        depth: F2,
        density: B2,
        isProgressive: W2,
        hasProfile: z2,
        hasAlpha: H2,
        src: U2
    },
    q2 = "webp",
    V2 = 96,
    K2 = 96,
    X2 = "srgb",
    Y2 = 4,
    Z2 = "uchar",
    J2 = 288,
    Q2 = !1,
    ew = !1,
    tw = !0,
    sw = "/cdn/assets/moon-mostly-sunny-n3mh1b6a.webp",
    nw = {
        format: q2,
        width: V2,
        height: K2,
        space: X2,
        channels: Y2,
        depth: Z2,
        density: J2,
        isProgressive: Q2,
        hasProfile: ew,
        hasAlpha: tw,
        src: sw
    },
    ow = "webp",
    rw = 96,
    iw = 96,
    aw = "srgb",
    lw = 4,
    cw = "uchar",
    dw = 288,
    uw = !1,
    fw = !1,
    mw = !0,
    hw = "/cdn/assets/moon-shower-ntzhti9o.webp",
    gw = {
        format: ow,
        width: rw,
        height: iw,
        space: aw,
        channels: lw,
        depth: cw,
        density: dw,
        isProgressive: uw,
        hasProfile: fw,
        hasAlpha: mw,
        src: hw
    },
    pw = "webp",
    xw = 96,
    bw = 96,
    yw = "srgb",
    ww = 4,
    _w = "uchar",
    vw = 288,
    kw = !1,
    Sw = !1,
    Ew = !0,
    jw = "/cdn/assets/moon-sunny-eg2emh4d.webp",
    Mw = {
        format: pw,
        width: xw,
        height: bw,
        space: yw,
        channels: ww,
        depth: _w,
        density: vw,
        isProgressive: kw,
        hasProfile: Sw,
        hasAlpha: Ew,
        src: jw
    },
    Cw = "webp",
    Tw = 96,
    Iw = 96,
    Nw = "srgb",
    Pw = 4,
    Rw = "uchar",
    $w = 288,
    Aw = !1,
    Lw = !1,
    Dw = !0,
    Ow = "/cdn/assets/rain-thunder-bx7a0l5g.webp",
    Fw = {
        format: Cw,
        width: Tw,
        height: Iw,
        space: Nw,
        channels: Pw,
        depth: Rw,
        density: $w,
        isProgressive: Aw,
        hasProfile: Lw,
        hasAlpha: Dw,
        src: Ow
    },
    Bw = "webp",
    Ww = 96,
    zw = 96,
    Hw = "srgb",
    Uw = 4,
    Gw = "uchar",
    qw = 288,
    Vw = !1,
    Kw = !1,
    Xw = !0,
    Yw = "/cdn/assets/rain-cxs76xuj.webp",
    Zw = {
        format: Bw,
        width: Ww,
        height: zw,
        space: Hw,
        channels: Uw,
        depth: Gw,
        density: qw,
        isProgressive: Vw,
        hasProfile: Kw,
        hasAlpha: Xw,
        src: Yw
    },
    Jw = "webp",
    Qw = 96,
    e_ = 96,
    t_ = "srgb",
    s_ = 4,
    n_ = "uchar",
    o_ = 288,
    r_ = !1,
    i_ = !1,
    a_ = !0,
    l_ = "/cdn/assets/sleet-gc63vwmo.webp",
    c_ = {
        format: Jw,
        width: Qw,
        height: e_,
        space: t_,
        channels: s_,
        depth: n_,
        density: o_,
        isProgressive: r_,
        hasProfile: i_,
        hasAlpha: a_,
        src: l_
    },
    d_ = "webp",
    u_ = 96,
    f_ = 96,
    m_ = "srgb",
    h_ = 4,
    g_ = "uchar",
    p_ = 288,
    x_ = !1,
    b_ = !1,
    y_ = !0,
    w_ = "/cdn/assets/snow-d0k6tmmc.webp",
    __ = {
        format: d_,
        width: u_,
        height: f_,
        space: m_,
        channels: h_,
        depth: g_,
        density: p_,
        isProgressive: x_,
        hasProfile: b_,
        hasAlpha: y_,
        src: w_
    },
    v_ = "webp",
    k_ = 96,
    S_ = 96,
    E_ = "srgb",
    j_ = 4,
    M_ = "uchar",
    C_ = 288,
    T_ = !1,
    I_ = !1,
    N_ = !0,
    P_ = "/cdn/assets/sun-drizzle-g94obr5e.webp",
    R_ = {
        format: v_,
        width: k_,
        height: S_,
        space: E_,
        channels: j_,
        depth: M_,
        density: C_,
        isProgressive: T_,
        hasProfile: I_,
        hasAlpha: N_,
        src: P_
    },
    $_ = "webp",
    A_ = 96,
    L_ = 96,
    D_ = "srgb",
    O_ = 4,
    F_ = "uchar",
    B_ = 288,
    W_ = !1,
    z_ = !1,
    H_ = !0,
    U_ = "/cdn/assets/sun-hazy-c3z1j0hy.webp",
    G_ = {
        format: $_,
        width: A_,
        height: L_,
        space: D_,
        channels: O_,
        depth: F_,
        density: B_,
        isProgressive: W_,
        hasProfile: z_,
        hasAlpha: H_,
        src: U_
    },
    q_ = "webp",
    V_ = 96,
    K_ = 96,
    X_ = "srgb",
    Y_ = 4,
    Z_ = "uchar",
    J_ = 288,
    Q_ = !1,
    ev = !1,
    tv = !0,
    sv = "/cdn/assets/sun-mostly-cloudy-d4o4zkga.webp",
    nv = {
        format: q_,
        width: V_,
        height: K_,
        space: X_,
        channels: Y_,
        depth: Z_,
        density: J_,
        isProgressive: Q_,
        hasProfile: ev,
        hasAlpha: tv,
        src: sv
    },
    ov = "webp",
    rv = 96,
    iv = 96,
    av = "srgb",
    lv = 4,
    cv = "uchar",
    dv = 288,
    uv = !1,
    fv = !1,
    mv = !0,
    hv = "/cdn/assets/sun-mostly-sunny-livrdkgu.webp",
    gv = {
        format: ov,
        width: rv,
        height: iv,
        space: av,
        channels: lv,
        depth: cv,
        density: dv,
        isProgressive: uv,
        hasProfile: fv,
        hasAlpha: mv,
        src: hv
    },
    pv = "webp",
    xv = 96,
    bv = 96,
    yv = "srgb",
    wv = 4,
    _v = "uchar",
    vv = 288,
    kv = !1,
    Sv = !1,
    Ev = !0,
    jv = "/cdn/assets/sun-shower-lvtjthah.webp",
    Mv = {
        format: pv,
        width: xv,
        height: bv,
        space: yv,
        channels: wv,
        depth: _v,
        density: vv,
        isProgressive: kv,
        hasProfile: Sv,
        hasAlpha: Ev,
        src: jv
    },
    Cv = "webp",
    Tv = 96,
    Iv = 96,
    Nv = "srgb",
    Pv = 4,
    Rv = "uchar",
    $v = 288,
    Av = !1,
    Lv = !1,
    Dv = !0,
    Ov = "/cdn/assets/sun-sunny-kqjpjzd8.webp",
    Fv = {
        format: Cv,
        width: Tv,
        height: Iv,
        space: Nv,
        channels: Pv,
        depth: Rv,
        density: $v,
        isProgressive: Av,
        hasProfile: Lv,
        hasAlpha: Dv,
        src: Ov
    },
    Bv = "webp",
    Wv = 96,
    zv = 96,
    Hv = "srgb",
    Uv = 4,
    Gv = "uchar",
    qv = 288,
    Vv = !1,
    Kv = !1,
    Xv = !0,
    Yv = "/cdn/assets/thunder-jgjqg9ai.webp",
    Zv = {
        format: Bv,
        width: Wv,
        height: zv,
        space: Hv,
        channels: Uv,
        depth: Gv,
        density: qv,
        isProgressive: Vv,
        hasProfile: Kv,
        hasAlpha: Xv,
        src: Yv
    },
    Jv = "webp",
    Qv = 96,
    ek = 96,
    tk = "srgb",
    sk = 4,
    nk = "uchar",
    ok = 288,
    rk = !1,
    ik = !1,
    ak = !0,
    lk = "/cdn/assets/tornado-opa24tq3.webp",
    ck = {
        format: Jv,
        width: Qv,
        height: ek,
        space: tk,
        channels: sk,
        depth: nk,
        density: ok,
        isProgressive: rk,
        hasProfile: ik,
        hasAlpha: ak,
        src: lk
    },
    dk = "webp",
    uk = 96,
    fk = 96,
    mk = "srgb",
    hk = 4,
    gk = "uchar",
    pk = 288,
    xk = !1,
    bk = !1,
    yk = !0,
    wk = "/cdn/assets/windy-mw0a3u21.webp",
    _k = {
        format: dk,
        width: uk,
        height: fk,
        space: mk,
        channels: hk,
        depth: gk,
        density: pk,
        isProgressive: xk,
        hasProfile: bk,
        hasAlpha: yk,
        src: wk
    },
    vk = "webp",
    kk = 96,
    Sk = 96,
    Ek = "srgb",
    jk = 4,
    Mk = "uchar",
    Ck = 288,
    Tk = !1,
    Ik = !1,
    Nk = !0,
    Pk = "/cdn/assets/cloud-foggy-fhg0jn0w.webp",
    Rk = {
        format: vk,
        width: kk,
        height: Sk,
        space: Ek,
        channels: jk,
        depth: Mk,
        density: Ck,
        isProgressive: Tk,
        hasProfile: Ik,
        hasAlpha: Nk,
        src: Pk
    },
    $k = "webp",
    Ak = 96,
    Lk = 96,
    Dk = "srgb",
    Ok = 4,
    Fk = "uchar",
    Bk = 288,
    Wk = !1,
    zk = !1,
    Hk = !0,
    Uk = "/cdn/assets/cloudy-disd26f3.webp",
    Gk = {
        format: $k,
        width: Ak,
        height: Lk,
        space: Dk,
        channels: Ok,
        depth: Fk,
        density: Bk,
        isProgressive: Wk,
        hasProfile: zk,
        hasAlpha: Hk,
        src: Uk
    },
    qk = "webp",
    Vk = 96,
    Kk = 96,
    Xk = "srgb",
    Yk = 4,
    Zk = "uchar",
    Jk = 288,
    Qk = !1,
    e3 = !1,
    t3 = !0,
    s3 = "/cdn/assets/heavy-snow-g6jjwo2d.webp",
    n3 = {
        format: qk,
        width: Vk,
        height: Kk,
        space: Xk,
        channels: Yk,
        depth: Zk,
        density: Jk,
        isProgressive: Qk,
        hasProfile: e3,
        hasAlpha: t3,
        src: s3
    },
    o3 = "webp",
    r3 = 96,
    i3 = 96,
    a3 = "srgb",
    l3 = 4,
    c3 = "uchar",
    d3 = 288,
    u3 = !1,
    f3 = !1,
    m3 = !0,
    h3 = "/cdn/assets/light-snow-iz0efpkh.webp",
    g3 = {
        format: o3,
        width: r3,
        height: i3,
        space: a3,
        channels: l3,
        depth: c3,
        density: d3,
        isProgressive: u3,
        hasProfile: f3,
        hasAlpha: m3,
        src: h3
    },
    p3 = "webp",
    x3 = 96,
    b3 = 96,
    y3 = "srgb",
    w3 = 4,
    _3 = "uchar",
    v3 = 288,
    k3 = !1,
    S3 = !1,
    E3 = !0,
    j3 = "/cdn/assets/moon-drizzle-b1nfv39c.webp",
    M3 = {
        format: p3,
        width: x3,
        height: b3,
        space: y3,
        channels: w3,
        depth: _3,
        density: v3,
        isProgressive: k3,
        hasProfile: S3,
        hasAlpha: E3,
        src: j3
    },
    C3 = "webp",
    T3 = 96,
    I3 = 96,
    N3 = "srgb",
    P3 = 4,
    R3 = "uchar",
    $3 = 288,
    A3 = !1,
    L3 = !1,
    D3 = !0,
    O3 = "/cdn/assets/moon-hazy-nfnzea7a.webp",
    F3 = {
        format: C3,
        width: T3,
        height: I3,
        space: N3,
        channels: P3,
        depth: R3,
        density: $3,
        isProgressive: A3,
        hasProfile: L3,
        hasAlpha: D3,
        src: O3
    },
    B3 = "webp",
    W3 = 96,
    z3 = 96,
    H3 = "srgb",
    U3 = 4,
    G3 = "uchar",
    q3 = 288,
    V3 = !1,
    K3 = !1,
    X3 = !0,
    Y3 = "/cdn/assets/moon-mostly-cloudy-e56e3z55.webp",
    Z3 = {
        format: B3,
        width: W3,
        height: z3,
        space: H3,
        channels: U3,
        depth: G3,
        density: q3,
        isProgressive: V3,
        hasProfile: K3,
        hasAlpha: X3,
        src: Y3
    },
    J3 = "webp",
    Q3 = 96,
    eS = 96,
    tS = "srgb",
    sS = 4,
    nS = "uchar",
    oS = 288,
    rS = !1,
    iS = !1,
    aS = !0,
    lS = "/cdn/assets/moon-mostly-sunny-ffu4gzf4.webp",
    cS = {
        format: J3,
        width: Q3,
        height: eS,
        space: tS,
        channels: sS,
        depth: nS,
        density: oS,
        isProgressive: rS,
        hasProfile: iS,
        hasAlpha: aS,
        src: lS
    },
    dS = "webp",
    uS = 96,
    fS = 96,
    mS = "srgb",
    hS = 4,
    gS = "uchar",
    pS = 288,
    xS = !1,
    bS = !1,
    yS = !0,
    wS = "/cdn/assets/moon-shower-e5dy9u48.webp",
    _S = {
        format: dS,
        width: uS,
        height: fS,
        space: mS,
        channels: hS,
        depth: gS,
        density: pS,
        isProgressive: xS,
        hasProfile: bS,
        hasAlpha: yS,
        src: wS
    },
    vS = "webp",
    kS = 96,
    SS = 96,
    ES = "srgb",
    jS = 4,
    MS = "uchar",
    CS = 288,
    TS = !1,
    IS = !1,
    NS = !0,
    PS = "/cdn/assets/moon-sunny-d9o08xiw.webp",
    RS = {
        format: vS,
        width: kS,
        height: SS,
        space: ES,
        channels: jS,
        depth: MS,
        density: CS,
        isProgressive: TS,
        hasProfile: IS,
        hasAlpha: NS,
        src: PS
    },
    $S = "webp",
    AS = 96,
    LS = 96,
    DS = "srgb",
    OS = 4,
    FS = "uchar",
    BS = 288,
    WS = !1,
    zS = !1,
    HS = !0,
    US = "/cdn/assets/rain-thunder-eplemvu1.webp",
    GS = {
        format: $S,
        width: AS,
        height: LS,
        space: DS,
        channels: OS,
        depth: FS,
        density: BS,
        isProgressive: WS,
        hasProfile: zS,
        hasAlpha: HS,
        src: US
    },
    qS = "webp",
    VS = 96,
    KS = 96,
    XS = "srgb",
    YS = 4,
    ZS = "uchar",
    JS = 288,
    QS = !1,
    eE = !1,
    tE = !0,
    sE = "/cdn/assets/rain-ogayr6kt.webp",
    nE = {
        format: qS,
        width: VS,
        height: KS,
        space: XS,
        channels: YS,
        depth: ZS,
        density: JS,
        isProgressive: QS,
        hasProfile: eE,
        hasAlpha: tE,
        src: sE
    },
    oE = "webp",
    rE = 96,
    iE = 96,
    aE = "srgb",
    lE = 4,
    cE = "uchar",
    dE = 288,
    uE = !1,
    fE = !1,
    mE = !0,
    hE = "/cdn/assets/sleet-o8noil7l.webp",
    gE = {
        format: oE,
        width: rE,
        height: iE,
        space: aE,
        channels: lE,
        depth: cE,
        density: dE,
        isProgressive: uE,
        hasProfile: fE,
        hasAlpha: mE,
        src: hE
    },
    pE = "webp",
    xE = 96,
    bE = 96,
    yE = "srgb",
    wE = 4,
    _E = "uchar",
    vE = 288,
    kE = !1,
    SE = !1,
    EE = !0,
    jE = "/cdn/assets/snow-lq4cl3uc.webp",
    ME = {
        format: pE,
        width: xE,
        height: bE,
        space: yE,
        channels: wE,
        depth: _E,
        density: vE,
        isProgressive: kE,
        hasProfile: SE,
        hasAlpha: EE,
        src: jE
    },
    CE = "webp",
    TE = 96,
    IE = 96,
    NE = "srgb",
    PE = 4,
    RE = "uchar",
    $E = 288,
    AE = !1,
    LE = !1,
    DE = !0,
    OE = "/cdn/assets/sun-drizzle-htsohv65.webp",
    FE = {
        format: CE,
        width: TE,
        height: IE,
        space: NE,
        channels: PE,
        depth: RE,
        density: $E,
        isProgressive: AE,
        hasProfile: LE,
        hasAlpha: DE,
        src: OE
    },
    BE = "webp",
    WE = 96,
    zE = 96,
    HE = "srgb",
    UE = 4,
    GE = "uchar",
    qE = 288,
    VE = !1,
    KE = !1,
    XE = !0,
    YE = "/cdn/assets/sun-hazy-nfj7clcd.webp",
    ZE = {
        format: BE,
        width: WE,
        height: zE,
        space: HE,
        channels: UE,
        depth: GE,
        density: qE,
        isProgressive: VE,
        hasProfile: KE,
        hasAlpha: XE,
        src: YE
    },
    JE = "webp",
    QE = 96,
    e4 = 96,
    t4 = "srgb",
    s4 = 4,
    n4 = "uchar",
    o4 = 288,
    r4 = !1,
    i4 = !1,
    a4 = !0,
    l4 = "/cdn/assets/sun-mostly-cloudy-e3pqqgs7.webp",
    c4 = {
        format: JE,
        width: QE,
        height: e4,
        space: t4,
        channels: s4,
        depth: n4,
        density: o4,
        isProgressive: r4,
        hasProfile: i4,
        hasAlpha: a4,
        src: l4
    },
    d4 = "webp",
    u4 = 96,
    f4 = 96,
    m4 = "srgb",
    h4 = 4,
    g4 = "uchar",
    p4 = 288,
    x4 = !1,
    b4 = !1,
    y4 = !0,
    w4 = "/cdn/assets/sun-mostly-sunny-o99k1c7a.webp",
    _4 = {
        format: d4,
        width: u4,
        height: f4,
        space: m4,
        channels: h4,
        depth: g4,
        density: p4,
        isProgressive: x4,
        hasProfile: b4,
        hasAlpha: y4,
        src: w4
    },
    v4 = "webp",
    k4 = 96,
    S4 = 96,
    E4 = "srgb",
    j4 = 4,
    M4 = "uchar",
    C4 = 288,
    T4 = !1,
    I4 = !1,
    N4 = !0,
    P4 = "/cdn/assets/sun-shower-ldwl4jbp.webp",
    R4 = {
        format: v4,
        width: k4,
        height: S4,
        space: E4,
        channels: j4,
        depth: M4,
        density: C4,
        isProgressive: T4,
        hasProfile: I4,
        hasAlpha: N4,
        src: P4
    },
    $4 = "webp",
    A4 = 96,
    L4 = 96,
    D4 = "srgb",
    O4 = 4,
    F4 = "uchar",
    B4 = 288,
    W4 = !1,
    z4 = !1,
    H4 = !0,
    U4 = "/cdn/assets/sun-sunny-kqjpjzd8.webp",
    G4 = {
        format: $4,
        width: A4,
        height: L4,
        space: D4,
        channels: O4,
        depth: F4,
        density: B4,
        isProgressive: W4,
        hasProfile: z4,
        hasAlpha: H4,
        src: U4
    },
    q4 = "webp",
    V4 = 96,
    K4 = 96,
    X4 = "srgb",
    Y4 = 4,
    Z4 = "uchar",
    J4 = 288,
    Q4 = !1,
    e5 = !1,
    t5 = !0,
    s5 = "/cdn/assets/thunder-xzn1cku3.webp",
    n5 = {
        format: q4,
        width: V4,
        height: K4,
        space: X4,
        channels: Y4,
        depth: Z4,
        density: J4,
        isProgressive: Q4,
        hasProfile: e5,
        hasAlpha: t5,
        src: s5
    },
    o5 = "webp",
    r5 = 96,
    i5 = 96,
    a5 = "srgb",
    l5 = 4,
    c5 = "uchar",
    d5 = 288,
    u5 = !1,
    f5 = !1,
    m5 = !0,
    h5 = "/cdn/assets/tornado-diqu61wg.webp",
    g5 = {
        format: o5,
        width: r5,
        height: i5,
        space: a5,
        channels: l5,
        depth: c5,
        density: d5,
        isProgressive: u5,
        hasProfile: f5,
        hasAlpha: m5,
        src: h5
    },
    p5 = "webp",
    x5 = 96,
    b5 = 96,
    y5 = "srgb",
    w5 = 4,
    _5 = "uchar",
    v5 = 288,
    k5 = !1,
    S5 = !1,
    E5 = !0,
    j5 = "/cdn/assets/windy-n2v8wtyp.webp",
    M5 = {
        format: p5,
        width: x5,
        height: b5,
        space: y5,
        channels: w5,
        depth: _5,
        density: v5,
        isProgressive: k5,
        hasProfile: S5,
        hasAlpha: E5,
        src: j5
    },
    C5 = {
        foggy: {
            default: M0
        },
        cloudy: {
            default: F0
        },
        "heavy-snow": {
            default: Z0
        },
        "light-snow": {
            default: c2
        },
        sleet: {
            default: c_
        },
        drizzle: {
            default: R_,
            night: _2
        },
        hazy: {
            default: G_,
            night: R2
        },
        "mostly-cloudy": {
            default: nv,
            night: G2
        },
        "mostly-sunny": {
            default: gv,
            night: nw
        },
        shower: {
            default: Mv,
            night: gw
        },
        sunny: {
            default: Fv,
            night: Mw
        },
        "rain-thunder": {
            default: Fw
        },
        rain: {
            default: Zw
        },
        snow: {
            default: __
        },
        thunder: {
            default: Zv
        },
        tornado: {
            default: ck
        },
        windy: {
            default: _k
        }
    },
    T5 = {
        foggy: {
            default: Rk
        },
        cloudy: {
            default: Gk
        },
        "heavy-snow": {
            default: n3
        },
        "light-snow": {
            default: g3
        },
        sleet: {
            default: gE
        },
        drizzle: {
            default: FE,
            night: M3
        },
        hazy: {
            default: ZE,
            night: F3
        },
        "mostly-cloudy": {
            default: c4,
            night: Z3
        },
        "mostly-sunny": {
            default: _4,
            night: cS
        },
        shower: {
            default: R4,
            night: _S
        },
        sunny: {
            default: G4,
            night: RS
        },
        "rain-thunder": {
            default: GS
        },
        rain: {
            default: nE
        },
        snow: {
            default: ME
        },
        thunder: {
            default: n5
        },
        tornado: {
            default: g5
        },
        windy: {
            default: M5
        }
    };

function I5({
    weatherCode: t,
    isDarkMode: e,
    isNight: s
}) {
    const n = e ? T5 : C5,
        o = N5(t),
        r = n[o];
    return r.night && s ? r.night : r.default
}

function N5(t) {
    switch (t) {
        case 1:
        case 33:
            return "sunny";
        case 2:
        case 3:
        case 34:
        case 35:
        case 36:
            return "mostly-sunny";
        case 4:
        case 6:
        case 13:
        case 14:
        case 38:
            return "mostly-cloudy";
        case 5:
        case 37:
            return "hazy";
        case 7:
        case 8:
            return "cloudy";
        case 11:
            return "foggy";
        case 12:
        case 39:
        case 40:
            return "shower";
        case 15:
        case 16:
        case 17:
        case 41:
        case 42:
            return "thunder";
        case 18:
            return "rain";
        case 19:
        case 20:
        case 21:
        case 43:
            return "light-snow";
        case 22:
        case 23:
        case 44:
            return "snow";
        case 24:
        case 25:
        case 26:
        case 29:
            return "sleet";
        case 32:
            return "windy";
        default:
            return "cloudy"
    }
}
const P5 = "C";

function R5(t, e) {
    return Math.round(t === "F" ? e * 9 / 5 + 32 : (e - 32) * 5 / 9)
}

function Vl(t, e, s = P5) {
    return t === s ? "".concat(Math.round(e), "°") : "".concat(R5(t, e), "°")
}
const $5 = 7,
    Kl = 8,
    A5 = x.memo(function({
        weatherResults: e,
        dateRange: s,
        turnIndex: n,
        trackContentReferenceEvent: o
    }) {
        const [r, i] = q5(), l = O5(e);
        x.useEffect(() => {
            o("Search Content Reference Shown", "search_content_reference_shown", "forecast")
        }, [o]);
        const {
            daily: c,
            hourly: d,
            historical: u
        } = e;
        let f = "daily";
        if (s || d && c.length < 2) f = "hourly";
        else if (c.length > 0) f = "daily";
        else if (u && (u == null ? void 0 : u.length) > 0) f = "historical";
        else return null;
        return a.jsxs("div", {
            className: "relative",
            "data-testid": "weather-widget",
            children: [l ? a.jsxs(a.Fragment, {
                children: [a.jsx(D5, {
                    weatherResults: e
                }), a.jsx(F5, {
                    weatherResults: e,
                    temperatureUnit: r,
                    setTemperatureUnit: i
                })]
            }) : a.jsx("div", {
                className: "bg-token-main-surface-primary absolute end-0 top-3 z-10 rounded-sm",
                children: a.jsx(bu, {
                    onTemperatureUnitChange: i,
                    temperatureUnit: r
                })
            }), a.jsx(H5, {
                turnIndex: n
            }), f === "hourly" && a.jsx(B5, {
                weatherResults: e,
                temperatureUnit: r,
                dateRange: s
            }), f === "daily" && a.jsx(W5, {
                dailyForecast: c.slice(0, $5),
                temperatureUnit: r
            }), f === "historical" && a.jsx(z5, {
                historical: u,
                temperatureUnit: r
            })]
        })
    });

function L5({
    weatherAlert: t
}) {
    const [e, s] = x.useState(!1), n = Ne(), o = Wc(), r = bs(t.start_timestamp, t.utc_offset_sec), i = t.end_timestamp ? bs(t.end_timestamp, t.utc_offset_sec) : null, l = a.jsxs(a.Fragment, {
        children: [a.jsx("div", {
            children: a.jsx(me, {
                id: "JnuGPS",
                defaultMessage: "{start}{separator}{end}",
                values: {
                    start: n.formatDate(r, {
                        weekday: "short",
                        month: "short",
                        day: "numeric",
                        hour: "numeric",
                        minute: "numeric"
                    }),
                    separator: i ? " - " : "",
                    end: i ? n.formatDate(i, {
                        weekday: "short",
                        month: "short",
                        day: "numeric",
                        hour: "numeric",
                        minute: "numeric"
                    }) : ""
                }
            })
        }), a.jsx("div", {
            children: t.summary
        })]
    });
    return a.jsxs("button", {
        className: "my-2 flex w-full flex-col gap-2 rounded-xl border border-red-200 bg-red-100 px-4 py-3 text-start text-sm text-red-800",
        onClick: () => s(!e),
        children: [a.jsxs("div", {
            className: "flex w-full items-center gap-4",
            children: [a.jsx(Xf, {
                className: "h-9 w-9 shrink-0"
            }), a.jsxs("div", {
                className: "flex flex-col",
                children: [a.jsx("div", {
                    className: "font-bold",
                    children: a.jsx(me, {
                        id: "y+fy/l",
                        defaultMessage: "Severe Weather: {name}",
                        values: {
                            name: t.name
                        }
                    })
                }), o && l]
            }), a.jsx("div", {
                className: "grow"
            }), a.jsx("div", {
                className: "opacity-30",
                children: e ? a.jsx(x1, {
                    className: "icon-lg"
                }) : a.jsx(p1, {
                    className: "icon-lg"
                })
            })]
        }), e && t.details && a.jsxs(a.Fragment, {
            children: [!o && l, a.jsx("div", {
                className: "mt-1 whitespace-pre-wrap",
                children: t.details.trim()
            })]
        })]
    })
}

function D5({
    weatherResults: t
}) {
    const {
        severe: e
    } = t;
    return e ? a.jsx("div", {
        className: "my-2",
        children: e.map((s, n) => a.jsx(L5, {
            weatherAlert: s
        }, n))
    }) : null
}

function O5(t) {
    const {
        historical: e,
        daily: s,
        hourly: n,
        current: o
    } = t;
    if (!o) return !1;
    let r = !1;
    const i = bs(o.timestamp, o.utc_offset_sec);
    for (const l of [e, s, n]) l && (r = r || (l == null ? void 0 : l.some(c => Gf(i, bs(c.timestamp, c.utc_offset_sec)))));
    return r
}

function F5({
    weatherResults: t,
    temperatureUnit: e,
    setTemperatureUnit: s
}) {
    const n = Ne(),
        {
            current: o
        } = t;
    if (!o) return null;
    const r = o.temperature.current,
        i = o.description,
        l = r != null && i && " · ";
    return a.jsxs("div", {
        className: "not-prose flex items-center gap-4",
        children: [a.jsxs("div", {
            className: "grow",
            children: [a.jsxs("div", {
                className: "text-lg font-semibold",
                children: [r != null && a.jsx(me, {
                    id: "FiwByI",
                    defaultMessage: "Currently {temperature}",
                    values: {
                        temperature: As(n, r, e)
                    }
                }), l, i.description]
            }), a.jsx("div", {
                className: "text-token-text-secondary",
                children: G5(t.location)
            })]
        }), a.jsxs("div", {
            className: "flex",
            children: [a.jsx(bu, {
                onTemperatureUnitChange: s,
                temperatureUnit: e
            }), a.jsx(fa, {
                weatherDescriptionData: i,
                isNight: o.night
            })]
        })]
    })
}

function ua({
    children: t
}) {
    return a.jsx("div", {
        className: "no-scrollbar not-prose mt-1 overflow-auto sm:overflow-hidden",
        children: a.jsx(Kt.Root, {
            className: "min-w-0",
            children: a.jsx(Kt.Body, {
                className: "border-token-border-medium border-b-[0.5px] [&_tr:last-child]:border-b-0",
                children: t
            })
        })
    })
}

function B5({
    weatherResults: t,
    temperatureUnit: e,
    dateRange: s
}) {
    const n = Ne(),
        {
            hourly: o,
            current: r
        } = t;
    let i = o != null ? o : [];
    s && (i = i.filter(u => u.timestamp >= s.start_timestamp && u.timestamp < s.end_timestamp));
    const [l, c] = x.useState(!1), d = i.length > Kl;
    if (!l && d) {
        const u = i[0],
            f = bs(u.timestamp, u.utc_offset_sec);
        let h = !1;
        if (r) {
            const m = bs(r.timestamp, r.utc_offset_sec);
            f.getTime() - m.getTime() > 480 * 60 * 1e3 && i.length > 18 && (i = i.slice(7, 18), h = !0)
        }
        h || (i = i.slice(0, Kl))
    }
    return a.jsxs(ua, {
        children: [i.map((u, f) => a.jsxs(Kt.Row, {
            children: [a.jsxs(ds, {
                className: "w-44",
                children: [a.jsx(fa, {
                    weatherDescriptionData: u.description,
                    isNight: u.night,
                    size: "small"
                }), a.jsx("div", {
                    className: "ms-3 whitespace-nowrap",
                    children: a.jsx("span", {
                        className: "lowercase",
                        children: U5(n, u)
                    })
                })]
            }), a.jsx(ds, {
                className: "w-[60px] tabular-nums",
                children: a.jsx("div", {
                    children: As(n, u.temperature.current, e)
                })
            }), a.jsx(ds, {
                children: u.description.description
            })]
        }, f)), d && a.jsx(Kt.Row, {
            children: a.jsx(ds, {
                className: "w-44",
                children: a.jsx(us, {
                    color: "secondary",
                    onClick: () => c(!l),
                    size: "small",
                    children: l ? a.jsx(me, {
                        id: "KoC8Ym",
                        defaultMessage: "Show less"
                    }) : a.jsx(me, {
                        id: "X8F8Y/",
                        defaultMessage: "Show more"
                    })
                })
            })
        })]
    })
}

function W5({
    dailyForecast: t,
    temperatureUnit: e
}) {
    const s = Ne();
    return a.jsx(ua, {
        children: t.map((n, o) => a.jsxs(Kt.Row, {
            children: [a.jsxs(ds, {
                className: "w-[7.5rem] min-w-[7.5rem]",
                children: [a.jsx(fa, {
                    weatherDescriptionData: n.description,
                    isNight: n.night,
                    size: "small"
                }), a.jsx("div", {
                    className: "ms-3 whitespace-nowrap",
                    children: ki(s, bs(n.timestamp, n.utc_offset_sec))
                })]
            }), a.jsxs(ds, {
                className: "tabular-nums",
                children: [a.jsx("div", {
                    children: As(s, n.temperature.max, e)
                }), a.jsx("div", {
                    className: "text-token-text-secondary ms-1",
                    children: As(s, n.temperature.min, e)
                })]
            }), a.jsx(ds, {
                className: "min-w-80",
                children: n.description.description
            })]
        }, o))
    })
}

function z5({
    historical: t,
    temperatureUnit: e
}) {
    const s = Ne();
    return t ? a.jsx(ua, {
        children: t.map((n, o) => {
            const r = bs(n.timestamp, n.utc_offset_sec);
            return a.jsxs(Kt.Row, {
                children: [a.jsx(ds, {
                    className: "w-[250px]",
                    children: a.jsx("div", {
                        className: "ms-3 whitespace-nowrap",
                        children: s.formatDate(r, {
                            weekday: "long",
                            month: "short",
                            day: "numeric"
                        })
                    })
                }), a.jsx(ds, {
                    className: "tabular-nums",
                    children: n.temperature.max && n.temperature.min ? a.jsxs(a.Fragment, {
                        children: [a.jsx("div", {
                            children: As(s, n.temperature.max, e)
                        }), a.jsx("div", {
                            className: "text-token-text-secondary ms-1",
                            children: As(s, n.temperature.min, e)
                        })]
                    }) : a.jsx("div", {
                        children: As(s, n.temperature.current, e)
                    })
                }), a.jsx(ds, {})]
            }, o)
        })
    }) : null
}

function ds({
    className: t,
    children: e
}) {
    return a.jsx(Kt.Cell, {
        className: W("border-token-border-xlight! border-s-0! border-e-0! py-2! ps-4! pe-3! first:ps-0! last:pe-0!", t),
        divClassName: "items-start leading-relaxed",
        children: e
    })
}

function H5({
    turnIndex: t
}) {
    const e = Wg(n => {
            var o, r;
            return (r = (o = n.thread) == null ? void 0 : o.turns[t]) == null ? void 0 : r.use_location
        }),
        [s] = qf();
    return !s.useLocation && e ? a.jsx("div", {
        className: "mt-3",
        children: a.jsx(us, {
            color: "secondary",
            icon: Vf,
            onClick: () => {
                Lg.setSettingsModalOpen(!0)
            },
            children: a.jsx(me, {
                id: "f47VEc",
                defaultMessage: "Share precise location"
            })
        })
    }) : null
}

function bu({
    temperatureUnit: t,
    onTemperatureUnitChange: e
}) {
    const s = n => t === n ? "font-bold" : "font-light";
    return a.jsx(zc, {
        size: "small",
        triggerButton: a.jsx("button", {
            className: "text-token-text-tertiary hover:text-token-text-primary flex items-center justify-center p-1.5",
            children: a.jsx(Bh, {
                className: "icon-sm"
            })
        }),
        children: a.jsxs(Ut.Item, {
            onClick: () => {
                e(t === "C" ? "F" : "C")
            },
            className: "text-token-text-primary",
            children: [a.jsx(me, {
                id: "bQIoe/",
                defaultMessage: "Temperature"
            }), a.jsxs("div", {
                className: "flex items-center",
                children: [a.jsx("div", {
                    className: s("F"),
                    children: a.jsx(me, {
                        id: "bvDeBB",
                        defaultMessage: "°F"
                    })
                }), a.jsx("div", {
                    className: "mx-1 h-4 border-s border-gray-300"
                }), a.jsx("div", {
                    className: s("C"),
                    children: a.jsx(me, {
                        id: "iNiz6O",
                        defaultMessage: "°C"
                    })
                })]
            })]
        })
    })
}

function fa({
    weatherDescriptionData: t,
    isNight: e = !1,
    size: s = "normal"
}) {
    const n = Fi(),
        o = s === "small" ? 30 : 50;
    return a.jsx("img", {
        draggable: !1,
        alt: t.description,
        src: I5({
            weatherCode: t.id,
            isDarkMode: n,
            isNight: e
        }).src,
        width: o,
        height: o
    })
}

function U5(t, e) {
    const s = bs(e.timestamp, e.utc_offset_sec);
    return t.formatDate(s, {
        hour: "numeric"
    })
}

function As(t, e, s) {
    return e == null ? "-" : Vl(s ? s != null ? s : "F" : yu(t), e)
}

function yu(t) {
    const e = ["en-US", "en-BZ", "en-BS", "en-KY", "en-PW"],
        s = t.locale || "en-US";
    return e.includes(s) ? "F" : "C"
}

function G5(t) {
    const e = t.name.split(",").map(s => s.trim());
    return t.country && !e.includes(t.country) && e.push(t.country), e.join(", ")
}
const q5 = () => {
    const t = Ne(),
        [e, s] = Kf("USER_TEMPERATURE_UNIT", yu(t), n => ["F", "C"].includes(n));
    return [e, s]
};

function V5({
    contentReference: t,
    clientThreadId: e,
    messageId: s,
    trackContentReferenceEvent: n,
    contentReferenceIndex: o
}) {
    var b;
    const r = et(),
        i = at(r, "1950533395"),
        l = pd(),
        c = l ? "sidebar" : "primary",
        d = "metadata" in t && ((b = t.metadata) != null && b.location) ? String(t.metadata.location) : void 0,
        u = x.useMemo(() => ({
            content_reference_start_index: t.start_idx,
            entity_name: t.name,
            category: t.category,
            conversation_type: c,
            contentReferenceIndex: o,
            metadata_location: d
        }), [t.start_idx, t.name, t.category, c, o, d]);
    x.useEffect(() => {
        i && n("Entity Anchor Content Reference Shown", "entity_anchor_content_reference_shown", "entity", u)
    }, [n, u, i]);
    const {
        openThreadSidebar: f
    } = eo(), {
        resetSidebarHistory: h
    } = Wh(), m = x.useCallback(y => {
        var p, w;
        y.preventDefault(), n("Entity Anchor Content Reference Clicked", "entity_anchor_content_reference_clicked", "entity", u), e && (l || h(), f({
            type: "entity",
            debugThreadId: void 0,
            messageId: s,
            contentReferenceStartIndex: t.start_idx,
            query: t.name,
            category: (p = t.category) != null ? p : void 0,
            extraParams: (w = t.extra_params) != null ? w : void 0
        }))
    }, [n, u, e, l, f, s, t.start_idx, t.name, t.category, t.extra_params, h]);
    return t.category === "product_link" ? i ? a.jsx(us, {
        size: "medium",
        color: "secondary",
        className: "my-2",
        onClick: m,
        children: a.jsx(me, {
            id: "entityAnchor.buyingOptions",
            defaultMessage: "Buying Options"
        })
    }) : a.jsx("span", {
        className: "text-token-text-primary font-semibold",
        children: a.jsx(me, {
            id: "entityAnchor.buyingOptions",
            defaultMessage: "Buying Options"
        })
    }) : !i || t.status === "loading" ? a.jsx("span", {
        className: "text-token-text-primary font-semibold",
        children: t.name
    }) : a.jsx("span", {
        className: "hover:entity-accent entity-underline inline cursor-pointer align-baseline",
        onClick: m,
        children: a.jsx("span", {
            className: "whitespace-normal",
            children: t.name
        })
    })
}
const K5 = Kn(() => Es(() =>
        import ("./d7j30y1sf5jmsddi.js"), __vite__mapDeps([18, 1, 2, 3, 19, 6, 7, 20, 21, 22, 23, 24, 25, 26])).then(t => t.BusinessesMap)),
    X5 = t => !!t.dil,
    Y5 = t => (t == null ? void 0 : t.type) === "element",
    Z5 = t => t === "inline" || t === "block" || t === "container",
    J5 = t => {
        var s;
        if (!Y5(t)) return;
        const e = (s = t.properties) == null ? void 0 : s.displayLayout;
        return Z5(e) ? e : void 0
    };

function Q5(t) {
    "use forget";
    var B, G, O, H;
    const e = xe.c(173),
        {
            index: s,
            FormattedText: n,
            node: o,
            wordFadeType: r
        } = t;
    let i;
    e[0] !== o ? (i = J5(o), e[0] = o, e[1] = i) : i = e[1];
    const l = i,
        c = parseInt(s, 10),
        d = x.useContext(js),
        u = et(),
        f = Yf({
            id: (O = (G = (B = d == null ? void 0 : d.message) == null ? void 0 : B.metadata) == null ? void 0 : G.model_slug) != null ? O : ""
        }, u),
        h = ad(),
        m = f || at(u, "2137702454");
    let b;
    e[2] !== u ? (b = jr(u), e[2] = u, e[3] = b) : b = e[3];
    const y = b;
    let p;
    e[4] !== d || e[5] !== y ? (p = S => {
        if (!y || (d == null ? void 0 : d.analyticsMetadata.turnIndex) === void 0) return [void 0, void 0];
        const V = fs.getConversationTurns(S),
            J = d.analyticsMetadata.turnIndex,
            q = V.findIndex(sj) === J,
            Z = J > 0 ? fs.getConversationTurnAtIndex(S, J - 1) : null,
            D = Zf(Z == null ? void 0 : Z.messages.filter(Jf));
        return [q, D]
    }, e[4] = d, e[5] = y, e[6] = p) : p = e[6];
    const [w, C] = Ls(d == null ? void 0 : d.clientThreadId, p), v = w === !0 && c === 0, g = ld(d == null ? void 0 : d.analyticsMetadata), k = x.useRef(!1);
    if (d == null) return null;
    const {
        contentReferences: E,
        onShowSearchResults: j,
        numImageResults: M,
        analyticsMetadata: T,
        message: N,
        superWidgetContent: I
    } = d, _ = E == null ? void 0 : E[c];
    if (!_ || T.turnIndex === void 0 || _.type === void 0) return null;
    let R;
    e[7] === Symbol.for("react.memo_cache_sentinel") ? (R = {
        img: tj
    }, e[7] = R) : R = e[7];
    let A;
    e[8] !== _.alt ? (A = a.jsx(Or, {
        components: R,
        children: _.alt
    }), e[8] = _.alt, e[9] = A) : A = e[9];
    const $ = A;
    if (h != null && h.renderContentReferencesAsAlt) return $;
    let P = null;
    e: switch (_.type) {
        case "title_citation":
            {
                let S;e[10] !== _ || e[11] !== g ? (S = a.jsx(l0, {
                    metadata: _,
                    trackContentReferenceEvent: g
                }), e[10] = _, e[11] = g, e[12] = S) : S = e[12],
                P = S;
                break e
            }
        case "link_title":
            {
                let S;e[13] !== _ || e[14] !== g ? (S = a.jsx(Ky, {
                    metadata: _,
                    trackContentReferenceEvent: g
                }), e[13] = _, e[14] = g, e[15] = S) : S = e[15],
                P = S;
                break e
            }
        case "location_search":
            {
                let S;e[16] !== _ || e[17] !== g ? (S = a.jsx(Yy, {
                    metadata: _,
                    trackContentReferenceEvent: g
                }), e[16] = _, e[17] = g, e[18] = S) : S = e[18],
                P = S;
                break e
            }
        case "time":
            {
                let S;e[19] !== _ || e[20] !== g ? (S = a.jsx(a0, {
                    metadata: _,
                    trackContentReferenceEvent: g
                }), e[19] = _, e[20] = g, e[21] = S) : S = e[21],
                P = S;
                break e
            }
        case "image_v2":
            {
                const S = M != null ? M : 0;
                let V;e[22] !== T || e[23] !== _ || e[24] !== g || e[25] !== S ? (V = a.jsx(la, {
                    metadata: _,
                    numImageResults: S,
                    analyticsMetadata: T,
                    trackContentReferenceEvent: g
                }), e[22] = T, e[23] = _, e[24] = g, e[25] = S, e[26] = V) : V = e[26],
                P = V;
                break e
            }
        case "nav_list":
            {
                let S;e[27] !== _ || e[28] !== g || e[29] !== v ? (S = a.jsx(Zy, {
                    metadata: _,
                    trackContentReferenceEvent: g,
                    isFirstAssistantContent: v
                }), e[27] = _, e[28] = g, e[29] = v, e[30] = S) : S = e[30],
                P = S;
                break e
            }
        case "file_navlist":
            {
                let S;e[31] !== _ || e[32] !== g ? (S = a.jsx(Iy, {
                    metadata: _,
                    trackContentReferenceEvent: g
                }), e[31] = _, e[32] = g, e[33] = S) : S = e[33],
                P = S;
                break e
            }
        case "file":
            {
                if (m) {
                    let S;
                    e[34] !== _ || e[35] !== E || e[36] !== g || e[37] !== c ? (S = a.jsx(hp, {
                        contentReferences: E,
                        fileRef: _,
                        index: c,
                        trackContentReferenceEvent: g
                    }), e[34] = _, e[35] = E, e[36] = g, e[37] = c, e[38] = S) : S = e[38], P = S
                } else {
                    let S;
                    e[39] !== _ || e[40] !== g || e[41] !== c ? (S = a.jsx(gp, {
                        fileRef: _,
                        index: c,
                        trackContentReferenceEvent: g
                    }), e[39] = _, e[40] = g, e[41] = c, e[42] = S) : S = e[42], P = S
                }
                break e
            }
        case "grouped_webpages_model_predicted_fallback":
            {
                let S;e[43] !== _ || e[44] !== d.message || e[45] !== g || e[46] !== c || e[47] !== o ? (S = a.jsx(mp, {
                    webpageRef: _,
                    node: o,
                    trackContentReferenceEvent: g,
                    message: d.message,
                    index: c
                }), e[43] = _, e[44] = d.message, e[45] = g, e[46] = c, e[47] = o, e[48] = S) : S = e[48],
                P = S;
                break e
            }
        case "grouped_webpages":
            {
                let S;e[49] !== _ || e[50] !== d.message || e[51] !== g || e[52] !== c || e[53] !== o ? (S = a.jsx(fp, {
                    webpageRef: _,
                    node: o,
                    trackContentReferenceEvent: g,
                    message: d.message,
                    index: c
                }), e[49] = _, e[50] = d.message, e[51] = g, e[52] = c, e[53] = o, e[54] = S) : S = e[54],
                P = S;
                break e
            }
        case "tldr":
            break e;
        case "navigation":
            {
                let S;e[55] !== _ || e[56] !== g || e[57] !== j ? (S = a.jsx(zh, {
                    navigation: _,
                    onShowSearchResults: j,
                    trackContentReferenceEvent: g
                }), e[55] = _, e[56] = g, e[57] = j, e[58] = S) : S = e[58],
                P = S;
                break e
            }
        case "stock":
            {
                let S;e[59] !== _ || e[60] !== g ? (S = a.jsx(Gy, {
                    contentReference: _,
                    trackContentReferenceEvent: g
                }), e[59] = _, e[60] = g, e[61] = S) : S = e[61],
                P = S;
                break e
            }
        case "calculator":
            {
                let S;e[62] !== _ || e[63] !== g ? (S = a.jsx(gy, {
                    data: _,
                    trackContentReferenceEvent: g
                }), e[62] = _, e[63] = g, e[64] = S) : S = e[64],
                P = S;
                break e
            }
        case "python":
        case "container":
            {
                let S;e[65] !== T.turnIndex || e[66] !== _ || e[67] !== d.clientThreadId ? (S = a.jsx(wy, {
                    clientThreadId: d.clientThreadId,
                    turnIndex: T.turnIndex,
                    contentReference: _
                }), e[65] = T.turnIndex, e[66] = _, e[67] = d.clientThreadId, e[68] = S) : S = e[68],
                P = S;
                break e
            }
        case "code_execution":
            {
                let S;e[69] !== n || e[70] !== _ || e[71] !== g ? (S = a.jsx(by, {
                    FormattedText: n,
                    displayInfo: _,
                    trackContentReferenceEvent: g
                }), e[69] = n, e[70] = _, e[71] = g, e[72] = S) : S = e[72],
                P = S;
                break e
            }
        case "forecast":
            {
                let S;e[73] !== T || e[74] !== _.date_range || e[75] !== _.forecast || e[76] !== g ? (S = (_ == null ? void 0 : _.forecast) && a.jsx(A5, {
                    weatherResults: _.forecast,
                    dateRange: _.date_range,
                    turnIndex: T.turnIndex,
                    trackContentReferenceEvent: g
                }), e[73] = T, e[74] = _.date_range, e[75] = _.forecast, e[76] = g, e[77] = S) : S = e[77],
                P = S;
                break e
            }
        case "businesses_map":
            {
                let S;e[78] !== _ || e[79] !== g ? (S = a.jsx(K5, {
                    contentReference: _,
                    trackContentReferenceEvent: g
                }), e[78] = _, e[79] = g, e[80] = S) : S = e[80],
                P = S;
                break e
            }
        case "map":
            {
                let S;e[81] !== T.turnIndex || e[82] !== _ || e[83] !== d.clientThreadId || e[84] !== d.message.id || e[85] !== g ? (S = a.jsx(ep, {
                    contentReference: _,
                    trackContentReferenceEvent: g,
                    clientThreadId: d.clientThreadId,
                    messageId: d.message.id,
                    turnIndex: T.turnIndex
                }), e[81] = T.turnIndex, e[82] = _, e[83] = d.clientThreadId, e[84] = d.message.id, e[85] = g, e[86] = S) : S = e[86],
                P = S;
                break e
            }
        case "video":
            {
                let S;e[87] !== _ || e[88] !== g ? (S = a.jsx(g0, {
                    video: _,
                    trackContentReferenceEvent: g
                }), e[87] = _, e[88] = g, e[89] = S) : S = e[89],
                P = S;
                break e
            }
        case "sports_standings":
            {
                let S;e[90] !== _ || e[91] !== g ? (S = a.jsx(r0, {
                    standingsRef: _,
                    trackContentReferenceEvent: g
                }), e[90] = _, e[91] = g, e[92] = S) : S = e[92],
                P = S;
                break e
            }
        case "sports_schedule":
            {
                let S;e[93] !== _ || e[94] !== g ? (S = a.jsx(t0, {
                    scheduleRef: _,
                    trackContentReferenceEvent: g
                }), e[93] = _, e[94] = g, e[95] = S) : S = e[95],
                P = S;
                break e
            }
        case "attribution":
            {
                let S;e[96] !== _ || e[97] !== r ? (S = a.jsx(dy, {
                    attribution: _,
                    wordFadeType: r
                }), e[96] = _, e[97] = r, e[98] = S) : S = e[98],
                P = S;
                break e
            }
        case "debug":
            {
                let S;e[99] !== _ ? (S = a.jsx(a.Fragment, {
                    children: Object.entries(_).map(ej)
                }), e[99] = _, e[100] = S) : S = e[100],
                P = S;
                break e
            }
        case "image_inline":
            {
                let S;e[101] !== _ || e[102] !== d.clientThreadId || e[103] !== g || e[104] !== N ? (S = (H = N.metadata) != null && H.b1de6e2_rm ? a.jsx(Bb, {
                    reference: _,
                    clientThreadId: d.clientThreadId,
                    trackContentReferenceEvent: g,
                    message: N
                }) : a.jsx(zb, {
                    reference: _,
                    clientThreadId: d.clientThreadId,
                    trackContentReferenceEvent: g,
                    message: N
                }), e[101] = _, e[102] = d.clientThreadId, e[103] = g, e[104] = N, e[105] = S) : S = e[105],
                P = S;
                break e
            }
        case "image_group":
            {
                const S = C != null ? C : null,
                    V = I != null ? I : null;
                let J;e[106] !== T || e[107] !== _ || e[108] !== g || e[109] !== w || e[110] !== S || e[111] !== V ? (J = a.jsx(hb, {
                    contentReference: _,
                    trackContentReferenceEvent: g,
                    analyticsMetadata: T,
                    isFirstAssistantTurn: w,
                    lastUserMsgOfPrevTurn: S,
                    superWidgetContent: V
                }), e[106] = T, e[107] = _, e[108] = g, e[109] = w, e[110] = S, e[111] = V, e[112] = J) : J = e[112],
                P = J;
                break e
            }
        case "product_entity":
            {
                let S;e[113] !== T.turnIndex || e[114] !== _ || e[115] !== d.clientThreadId || e[116] !== d.message.id || e[117] !== g ? (S = a.jsx(Hb, {
                    contentReference: _,
                    clientThreadId: d.clientThreadId,
                    messageId: d.message.id,
                    turnIndex: T.turnIndex,
                    trackContentReferenceEvent: g
                }), e[113] = T.turnIndex, e[114] = _, e[115] = d.clientThreadId, e[116] = d.message.id, e[117] = g, e[118] = S) : S = e[118],
                P = S;
                break e
            }
        case "entity_metadata":
            {
                let S;e[119] !== _ || e[120] !== d.clientThreadId || e[121] !== d.message.id || e[122] !== g ? (S = a.jsx(Cy, {
                    contentReference: _,
                    clientThreadId: d.clientThreadId,
                    messageId: d.message.id,
                    trackContentReferenceEvent: g
                }), e[119] = _, e[120] = d.clientThreadId, e[121] = d.message.id, e[122] = g, e[123] = S) : S = e[123],
                P = S;
                break e
            }
        case "checkout_confirmation":
            {
                let S;e[124] !== _ || e[125] !== g ? (S = a.jsx(tb, {
                    metadata: _,
                    trackContentReferenceEvent: g
                }), e[124] = _, e[125] = g, e[126] = S) : S = e[126],
                P = S;
                break e
            }
        case "entity":
            {
                let S;e[127] !== T.turnIndex || e[128] !== _ || e[129] !== d.clientThreadId || e[130] !== d.message.id || e[131] !== g || e[132] !== c ? (S = a.jsx(V5, {
                    contentReference: _,
                    clientThreadId: d.clientThreadId,
                    messageId: d.message.id,
                    turnIndex: T.turnIndex,
                    trackContentReferenceEvent: g,
                    contentReferenceIndex: c
                }), e[127] = T.turnIndex, e[128] = _, e[129] = d.clientThreadId, e[130] = d.message.id, e[131] = g, e[132] = c, e[133] = S) : S = e[133],
                P = S;
                break e
            }
        case "product":
            {
                let S;e[134] !== T || e[135] !== _ || e[136] !== d.clientThreadId || e[137] !== d.message.id || e[138] !== l || e[139] !== g || e[140] !== c ? (S = a.jsx(ry, {
                    contentReference: _,
                    clientThreadId: d.clientThreadId,
                    messageId: d.message.id,
                    trackContentReferenceEvent: g,
                    contentReferenceIndex: c,
                    analyticsMetadata: T,
                    displayLayout: l
                }), e[134] = T, e[135] = _, e[136] = d.clientThreadId, e[137] = d.message.id, e[138] = l, e[139] = g, e[140] = c, e[141] = S) : S = e[141],
                P = S;
                break e
            }
        case "products":
            {
                let S;e[142] !== T || e[143] !== _ || e[144] !== d.clientThreadId || e[145] !== d.message.id ? (S = a.jsx(qb, {
                    contentReference: _,
                    clientThreadId: d.clientThreadId,
                    messageId: d.message.id,
                    turnIndex: T.turnIndex,
                    analyticsMetadata: T
                }), e[142] = T, e[143] = _, e[144] = d.clientThreadId, e[145] = d.message.id, e[146] = S) : S = e[146],
                P = S;
                break e
            }
        case "product_reviews":
            {
                let S;e[147] !== _ || e[148] !== g ? (S = a.jsx(Eg, {
                    contentReference: _,
                    disableAnimation: !0,
                    trackContentReferenceEvent: g
                }), e[147] = _, e[148] = g, e[149] = S) : S = e[149],
                P = S;
                break e
            }
        case "product_rationale":
            {
                let S;e[150] !== _ || e[151] !== g ? (S = a.jsx(Sg, {
                    contentReference: _,
                    trackContentReferenceEvent: g,
                    disableAnimation: !0
                }), e[150] = _, e[151] = g, e[152] = S) : S = e[152],
                P = S;
                break e
            }
        case "dil":
            {
                let S;e[153] !== _.dil || e[154] !== _.dil_url || e[155] !== _.name || e[156] !== g ? (S = a.jsx(ky, {
                    dil: _.dil,
                    dilUrl: _.dil_url,
                    trackContentReferenceEvent: g,
                    widgetName: _.name
                }), e[153] = _.dil, e[154] = _.dil_url, e[155] = _.name, e[156] = g, e[157] = S) : S = e[157],
                P = S;
                break e
            }
        case "strix":
            break e;
        case "sources_footnote":
            return null
    }
    X5(_) && "dil_url" in _;
    let U;
    e[166] !== $ || e[167] !== _ || e[168] !== g ? (U = S => (k.current || (g("Search Content Reference Failed", "search_content_reference_failed", _.type), ts.addError("Error rendering content reference: ".concat(_.type), ce(F({}, S), {
        contentReference: _
    })), k.current = !0), _ != null && _.alt ? $ : a.jsx("span", {
        className: "errored-object-".concat(_.type)
    })), e[166] = $, e[167] = _, e[168] = g, e[169] = U) : U = e[169];
    let z;
    return e[170] !== P || e[171] !== U ? (z = a.jsx(Hc, {
        name: "content-reference-renderer",
        fallback: U,
        children: P
    }), e[170] = P, e[171] = U, e[172] = z) : z = e[172], z
}

function ej(t) {
    const [e, s] = t;
    return a.jsx("sub", {
        className: "ms-1 w-fit rounded-md border-2 border-solid border-orange-500 px-1 leading-none",
        children: s
    }, e)
}

function tj(t) {
    const {
        src: e,
        alt: s
    } = t;
    return a.jsx("img", {
        src: e,
        alt: s,
        className: "max-h-28"
    })
}

function sj(t) {
    return t.role === Qf.Assistant
}
const nj = Kn(() => Es(() =>
    import ("./f9yd7jtcv3kpecrv.js"), __vite__mapDeps([27, 1, 2, 3, 28, 6, 7, 9, 11, 16, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 19, 20, 21, 22, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 24, 23, 25, 26, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103])).then(t => t.WalnutSandboxFileCitation));

function oj(t) {
    const e = new URL(t).searchParams.get("se");
    if (!e) return !1;
    const s = Date.parse(e);
    return Number.isNaN(s) ? !1 : Date.now() > s
}

function rj(o) {
    var r = o,
        {
            messageId: t,
            conversation: e,
            href: s
        } = r,
        n = Bt(r, ["messageId", "conversation", "href"]);
    const i = mf(),
        [l, c] = x.useState(!1),
        d = s.substring(or.length),
        u = Rt(() => e.serverId$()),
        f = Ne(),
        h = ys(),
        m = et(),
        b = at(m, "1081475731"),
        y = x.useCallback(v => {
            const g = document.createElement("a");
            g.href = v, g.click(), c(!1)
        }, []),
        p = x.useCallback(v => {
            c(!1), h.danger(v, {
                toastId: "file_download_failed"
            })
        }, [h]),
        w = aj(l, t, u, d, p, y).data,
        C = x.useCallback(async v => {
            v.preventDefault();
            const g = (w == null ? void 0 : w.download_url) && oj(w.download_url);
            (w === void 0 || (w == null ? void 0 : w.status) !== "success" || g) && i.invalidateQueries({
                queryKey: wu(t, d)
            }), (w == null ? void 0 : w.status) === "success" && (w != null && w.download_url) && !g ? y(w.download_url) : c(!0)
        }, [w, i, t, d, y]);
    if (b) {
        const v = k => {
                var M, T;
                return ((T = ((M = k.split("/").pop()) != null ? M : "").split(".").pop()) == null ? void 0 : T.toLowerCase()) === "xlsx"
            },
            g = k => {
                var M, T;
                return ((T = ((M = k.split("/").pop()) != null ? M : "").split(".").pop()) == null ? void 0 : T.toLowerCase()) === "pptx"
            };
        if (v(d) || g(d)) return a.jsx(nj, {
            conversation: e,
            messageId: t,
            filepath: d,
            isResponsiveSheet: !0,
            responsiveSheetHeight: 300
        })
    }
    return a.jsx(Yn, {
        closeOnOutsideClick: !1,
        label: a.jsxs("span", {
            className: "flex items-center gap-1",
            children: [l ? f.formatMessage(Xl.startingDownload) : f.formatMessage(Xl.downloadFile), l && a.jsx(_n, {})]
        }),
        side: "top",
        children: a.jsx("a", ce(F({}, n), {
            className: "cursor-pointer",
            onClick: v => !l && C(v)
        }))
    })
}
async function ij(t, e, s) {
    const n = await vn.safeGet("/conversation/{conversation_id}/interpreter/download", {
        parameters: {
            path: {
                conversation_id: e
            },
            query: {
                message_id: t,
                sandbox_path: s
            }
        }
    });
    if (n.status === tm.Success) return n;
    throw new Uc("Could not download file from advanced data analysis", "error_code" in n ? n.error_code : "unknown_error")
}

function aj(t, e, s, n, o, r) {
    const i = em();
    return $c({
        queryKey: wu(e, n),
        queryFn: () => {
            if (s) return ij(e, s, n).then(l => ((l == null ? void 0 : l.status) === "success" && r(l.download_url), l)).catch(l => {
                let c = i("default_download_link_error", {
                    fileName: n
                });
                throw l instanceof Uc && l.code != null && (c = i(l.code)), o == null || o(c), l
            })
        },
        enabled: !!(t && e && s && n)
    })
}

function wu(t, e) {
    return ["downloadSandboxLink", t, e]
}
const Xl = Ts({
        downloadFile: {
            id: "SandboxDownload.downloadFile",
            defaultMessage: "Download file"
        },
        startingDownload: {
            id: "SandboxDownload.startingDownload",
            defaultMessage: "Starting download"
        }
    }),
    _u = (t, e, s = !1) => {
        const n = x.useRef(!1);
        x.useEffect(() => {
            n.current || (n.current = !0, Ot.count(Ft.DEFAULT, "clickable_follow_up_text_shown"), s && Ot.count(Ft.DEFAULT, "clickable_follow_up_deep_research_text_shown"), Xe.logEventWithStatsig("Clickable Follow Up Text Shown", "chatgpt_clickable_follow_up_text_shown", F({}, Cr({
                clientThreadId: t.id,
                messageId: e
            }))))
        }, [t, e, s])
    },
    vu = ({
        messageId: t,
        conversation: e,
        text: s
    }) => {
        const n = sm.useStore(),
            o = fd(e.id);
        _u(e, t, !1);
        const r = x.useCallback(i => {
            i.preventDefault(), Ot.count(Ft.DEFAULT, "clickable_follow_up_text_clicked"), Xe.logEventWithStatsig("Clickable Follow Up Text Clicked", "chatgpt_clickable_follow_up_text_clicked", Cr({
                clientThreadId: e.id,
                messageId: t
            }));
            const l = n.getActiveSystemHintType();
            Hh({
                conversation: e,
                sourceEvent: i,
                promptMessage: om(s.toLowerCase(), {
                    suggestion_type: nd.Reply
                }),
                completionMetadata: {
                    systemHints: l ? [l] : [],
                    conversationMode: o != null ? o : {
                        kind: nm.PrimaryAssistant
                    }
                }
            })
        }, [e, o, t, n, s]);
        return a.jsx("span", {
            className: "decoration-token-text-secondary hover:text-token-text-secondary cursor-pointer underline decoration-dotted decoration-[12%] underline-offset-4 transition-colors duration-200 ease-in-out",
            onClick: r,
            children: s
        })
    },
    lj = ({
        messageId: t,
        conversation: e,
        text: s
    }) => a.jsx(vu, {
        messageId: t,
        conversation: e,
        text: s
    }),
    cj = vr.memo(lj),
    dj = ({
        messageId: t,
        conversation: e,
        text: s
    }) => {
        const n = rm(),
            {
                setThreadSystemHintMode: o
            } = Uh(),
            r = !!im(),
            i = fd(e.id);
        _u(e, t, !0);
        const l = x.useCallback(c => {
            c.preventDefault(), Ot.count(Ft.DEFAULT, "clickable_follow_up_text_clicked"), Ot.count(Ft.DEFAULT, "clickable_follow_up_deep_research_text_clicked"), Xe.logEventWithStatsig("Clickable Follow Up Text Clicked", "chatgpt_clickable_follow_up_text_clicked", Cr({
                clientThreadId: e.id,
                messageId: t
            }));
            const d = {
                clientThreadId: e.id
            };
            o(yi.Research, !0, d); {
                const u = Dc(n);
                u.focus(), Lc(u, s)
            }
        }, [e, t, s, n, o, i]);
        return r ? a.jsx(vu, {
            messageId: t,
            conversation: e,
            text: s
        }) : a.jsxs("span", {
            className: "decoration-token-text-secondary hover:text-token-text-secondary cursor-pointer underline decoration-dotted decoration-[12%] underline-offset-4 transition-colors duration-200 ease-in-out",
            onClick: l,
            children: [a.jsx(Gh, {
                className: "icon me-1 inline-block"
            }), s]
        })
    },
    uj = ({
        messageId: t,
        conversation: e,
        text: s
    }) => a.jsx(dj, {
        messageId: t,
        conversation: e,
        text: s
    }),
    fj = vr.memo(uj);
var Nc;
const mj = new RegExp(String.raw(Nc || (Nc = Qs(["]((?!<)(", "[^)\r\n]+?))"], ["\\]\\((?!<)(", "[^)\\r\\n]+?)\\)"])), or), "g"),
    hj = /\s/;

function ku(t) {
    return t.replace(mj, (e, s) => hj.test(s) ? "](".concat("<".concat(s, ">"), ")") : e)
}
const gj = {
        markRendered: () => {}
    },
    pj = () => {
        "use forget";
        const t = x.useContext(tu);
        return t == null ? gj : t
    };
var yn = (t => (t.STANDARD = "standard", t.EMAIL = "email", t.CREATIVE = "creative", t.CHAT_MESSAGE = "chat_message", t.SOCIAL_POST = "social_post", t.UNKNOWN = "unknown", t))(yn || {});

function xj(t) {
    return Object.values(yn).includes(t) ? t : "unknown"
}
var Gn = (t => (t.TOOLBAR = "toolbar", t.FULLSCREEN_COMPOSER = "fullscreen-composer", t))(Gn || {});

function bj({
    serverThreadId: t,
    index: e,
    messageId: s,
    writingBlock: n,
    dirty: o,
    setDirty: r,
    onSave: i,
    delay: l = 2e3,
    isStreaming: c = !1,
    saveDisabled: d = !1
}) {
    var z;
    const [u, f] = x.useState(!1), [h, m] = x.useState(null), [b, y] = x.useState(null), [p, w] = x.useState(!1), [C, v] = x.useState(!1), g = x.useRef(0), k = x.useRef(n.content), E = x.useRef(n.title), j = x.useRef((z = n.metadata) != null ? z : {}), M = x.useRef(!1), T = x.useRef(!1), N = x.useRef(0), I = x.useRef(null), {
        mutate: _
    } = kr({
        mutationFn: async ({
            content: B,
            title: G,
            metadata: O
        }) => {
            d || (g.current += 1, g.current > 1 && v(!0), !(!t || !s) && await vn.safePost("/conversation/message/writing-blocks", {
                requestBody: {
                    message_id: s,
                    conversation_id: t,
                    index: String(e),
                    id: n.id,
                    writing_block: {
                        content: B,
                        index: String(e),
                        variant: n.variant.toString(),
                        metadata: O,
                        title: G,
                        id: n.id
                    },
                    updated_at: new Date().toISOString()
                },
                authOption: Mr.SendIfAvailable
            }))
        },
        onSuccess: (B, G, O) => {
            I.current === (O == null ? void 0 : O.myVersion) && (r(!1), y(new Date), i == null || i())
        },
        onMutate: () => {
            g.current = 0, v(!1);
            const B = ++N.current;
            return I.current = B, f(!0), m(null), {
                myVersion: B
            }
        },
        onError: (B, G, O) => {
            m(B.message), r(!0)
        },
        onSettled: (B, G, O, H) => {
            g.current = 0, v(!1), I.current === (H == null ? void 0 : H.myVersion) && (f(!1), I.current = null, M.current && R.flush())
        },
        retry: 1,
        retryDelay: 3e3
    }), R = Yi(({
        content: B,
        title: G,
        metadata: O
    }) => {
        M.current = !1, w(!1), _({
            content: B,
            title: G,
            metadata: O
        })
    }, l);
    x.useEffect(() => {
        var B, G;
        if (!(c || d)) {
            if (n.content === k.current && n.title === E.current && n.metadata === j.current) {
                T.current = !1;
                return
            }
            k.current = n.content, E.current = n.title, j.current = (B = n.metadata) != null ? B : {}, M.current = !0, w(!0), R({
                content: n.content,
                title: n.title,
                metadata: (G = n.metadata) != null ? G : {}
            }), T.current && (Promise.resolve().then(() => {
                R.flush()
            }), T.current = !1)
        }
    }, [n.content, n.title, n.metadata, R, c, d]), x.useEffect(() => () => {
        R.cancel(), T.current = !1, w(!1)
    }, [R]);
    const A = x.useCallback(() => {
            if (!o && !M.current) {
                T.current = !1, w(!1);
                return
            }
            T.current = !0, M.current && (R.flush(), T.current = !1, w(!1))
        }, [o, R]),
        $ = x.useCallback(() => {
            if (T.current = !1, M.current) {
                R.flush();
                return
            }
            w(!1), _({
                content: k.current,
                title: E.current,
                metadata: j.current
            })
        }, [R, _]),
        P = x.useMemo(() => !!b && !o && !u, [b, o, u]);
    return {
        status: x.useMemo(() => C ? "retrying" : u ? "saving" : h ? "error" : p ? "queued" : o ? "dirty" : P ? "saved" : "idle", [C, u, h, p, o, P]),
        savedAt: b,
        error: h,
        flushPendingChanges: A,
        forceSave: $
    }
}
const yj = () => {
    "use forget";
    const t = xe.c(1),
        e = wj;
    let s;
    return t[0] === Symbol.for("react.memo_cache_sentinel") ? (s = {
        editWritingBlock: e
    }, t[0] = s) : s = t[0], s
};

function wj(t) {
    const {
        content: e,
        clientThreadId: s,
        message: n,
        index: o,
        variant: r,
        metadata: i,
        title: l,
        id: c
    } = t;
    am(s, d => lm.updateTree(d, u => {
        var f, h;
        return u.updateNodeMessageMetadata(n.id, {
            writing_blocks: ce(F({}, (h = (f = n.metadata) == null ? void 0 : f.writing_blocks) != null ? h : {}), {
                [c]: {
                    id: c,
                    index: o,
                    content: e,
                    variant: r,
                    title: l,
                    metadata: i
                }
            })
        })
    }))
}

function _j({
    conversation: t,
    messageId: e,
    id: s,
    originalContent: n,
    index: o,
    variant: r,
    title: i,
    subject: l,
    recipient: c,
    onSave: d,
    isStreaming: u = !1
}) {
    var B, G;
    const f = et(),
        h = Sr(),
        m = t != null ? t : h,
        [b, y] = x.useState(!1),
        p = Rt(() => m == null ? void 0 : m.serverId$()),
        w = Ls(m == null ? void 0 : m.id, O => {
            if (!e || !O) return;
            const S = fs.getTree(O).getNodeIfExists(e);
            return S == null ? void 0 : S.message
        }, {
            disablePerfDetector: !0
        }),
        C = (G = (B = w == null ? void 0 : w.metadata) == null ? void 0 : B.writing_blocks) == null ? void 0 : G[s],
        v = x.useMemo(() => {
            var O;
            return (O = C == null ? void 0 : C.metadata) != null ? O : {
                recipient: c != null ? c : null,
                subject: l != null ? l : null
            }
        }, [c, l, C == null ? void 0 : C.metadata]),
        g = !!C,
        {
            editWritingBlock: k
        } = yj(),
        E = Er(),
        j = Rt(() => cm(f)),
        M = !dm(),
        T = p != null && !E,
        N = x.useMemo(() => {
            var O, H, S;
            return (S = (H = (O = w == null ? void 0 : w.metadata) == null ? void 0 : O.writing_blocks) == null ? void 0 : H[s]) != null ? S : {
                id: s,
                content: n,
                index: o,
                variant: r,
                title: i,
                metadata: v
            }
        }, [w, s, n, o, r, i, v]),
        I = x.useMemo(() => {
            var O, H;
            return (H = (O = w == null ? void 0 : w.metadata) == null ? void 0 : O.content_references) != null ? H : []
        }, [w]),
        {
            status: _,
            flushPendingChanges: R,
            forceSave: A
        } = bj({
            serverThreadId: p,
            index: o,
            messageId: e,
            dirty: b,
            setDirty: y,
            writingBlock: N,
            onSave: d,
            isStreaming: u,
            saveDisabled: j || M
        }),
        $ = x.useCallback(({
            content: O,
            title: H,
            metadata: S
        }) => {
            !(m != null && m.id) || !w || !w.id || k({
                content: O != null ? O : N.content,
                clientThreadId: m == null ? void 0 : m.id,
                message: w,
                index: o,
                variant: r,
                metadata: Object.assign({}, v, S),
                title: H != null ? H : N.title,
                id: s
            })
        }, [m == null ? void 0 : m.id, w, o, r, k, s, N, v]),
        P = x.useRef(null),
        U = x.useRef(null),
        z = x.useMemo(() => {
            var O;
            return {
                serverThreadId: p,
                messageId: e,
                blockId: (O = N.id) != null ? O : String(N.index)
            }
        }, [p, e, N.id, N.index]);
    return {
        conversation: m,
        writingBlock: N,
        contentReferences: I,
        autosaveStatus: _,
        flushPendingChanges: R,
        handleOnChange: $,
        messageRef: P,
        editorViewRef: U,
        analyticsMetadata: z,
        hasBeenEdited: g,
        isWritingBlockEditingAllowed: T,
        setDirty: y,
        dirty: b,
        forceSave: A
    }
}
const Su = Gc(() => {
        const t = Ht(!1),
            e = Ht(null);
        return {
            isLoading$: t,
            currentAIOperation$: e
        }
    }),
    Eu = t => Su(t).currentAIOperation$,
    ju = t => Su(t).isLoading$,
    Yl = (t, e) => {
        Eu(t).set(e)
    },
    Zl = (t, e) => {
        ju(t).set(e)
    },
    vj = "bg-token-bg-primary/98 dark:bg-[#2a2a2a]/98",
    kj = "placeholder:text-token-text-tertiary min-w-0 flex-1 shrink-0 truncate border-none bg-transparent focus:border-transparent focus:ring-0 focus:outline-hidden",
    Mu = "text-sm font-medium",
    Hr = 0,
    ma = (t, e, s, n) => Bi() ? {
        top: 0,
        right: 0,
        bottom: 0,
        left: 0
    } : s ? t === yn.EMAIL ? n ? {
        top: 3,
        right: 10,
        bottom: e ? 32 : 4,
        left: 5
    } : {
        top: 3,
        right: 2,
        bottom: e ? 32 : 4,
        left: 5
    } : e ? {
        top: 12,
        right: 14,
        bottom: 32,
        left: 14
    } : {
        top: 4,
        right: 5,
        bottom: 4,
        left: 5
    } : {
        top: 3,
        right: 3,
        bottom: 3,
        left: 4
    };

function Ni(l) {
    var c = l,
        {
            icon: t,
            label: e,
            tooltip: s,
            disabled: n = !1,
            onClick: o,
            iconColor: r
        } = c,
        i = Bt(c, ["icon", "label", "tooltip", "disabled", "onClick", "iconColor"]);
    const d = a.jsx("button", ce(F({
        "aria-label": e,
        className: W("hover:[&_.icon]:text-token-text-primary px-2 py-2 select-none", n && "opacity-50"),
        onClick: o,
        disabled: n
    }, i), {
        children: a.jsx(t, {
            className: W("icon", r != null ? r : "text-token-text-tertiary")
        })
    }));
    return s ? a.jsx(Yn, {
        label: s,
        sideOffset: Hr,
        children: d
    }) : d
}

function Sj(t) {
    "use forget";
    const e = xe.c(54),
        {
            onClick: s,
            clientThreadId: n,
            messageId: o
        } = t,
        r = Ne();
    let i;
    e[0] !== r ? (i = r.formatMessage({
        id: "EmailSendButton.tooltip",
        defaultMessage: "Open in email"
    }), e[0] = r, e[1] = i) : i = e[1];
    const l = i;
    let c;
    e[2] !== n || e[3] !== o || e[4] !== s ? (c = P => {
        Xe.logStructuredEvent(um, {
            conversationId: n,
            messageId: o,
            provider: P
        }), Ot.count(Ft.WRITING_BLOCKS, "chatgpt_writing_block_email_send_button_clicked"), s(P)
    }, e[2] = n, e[3] = o, e[4] = s, e[5] = c) : c = e[5];
    const d = c;
    let u;
    e[6] !== r ? (u = r.formatMessage({
        id: "BnHAsh",
        defaultMessage: "Open email in app"
    }), e[6] = r, e[7] = u) : u = e[7];
    let f;
    e[8] !== u ? (f = a.jsx(Ni, {
        icon: Ka,
        label: u
    }), e[8] = u, e[9] = f) : f = e[9];
    let h;
    e[10] !== d ? (h = () => d("gmail"), e[10] = d, e[11] = h) : h = e[11];
    let m;
    e[12] === Symbol.for("react.memo_cache_sentinel") ? (m = a.jsx(fm, {}), e[12] = m) : m = e[12];
    let b;
    e[13] !== r ? (b = r.formatMessage({
        id: "2cYA6Z",
        defaultMessage: "Open email using Gmail"
    }), e[13] = r, e[14] = b) : b = e[14];
    let y;
    e[15] === Symbol.for("react.memo_cache_sentinel") ? (y = a.jsx(me, {
        id: "N+/ksm",
        defaultMessage: "Gmail"
    }), e[15] = y) : y = e[15];
    let p;
    e[16] !== h || e[17] !== b ? (p = a.jsx(Ut.Item, {
        onSelect: h,
        icon: m,
        "aria-label": b,
        label: y
    }), e[16] = h, e[17] = b, e[18] = p) : p = e[18];
    let w;
    e[19] !== d ? (w = () => d("outlook"), e[19] = d, e[20] = w) : w = e[20];
    let C;
    e[21] === Symbol.for("react.memo_cache_sentinel") ? (C = a.jsx(qh, {}), e[21] = C) : C = e[21];
    let v;
    e[22] !== r ? (v = r.formatMessage({
        id: "puDMOA",
        defaultMessage: "Open email using Outlook"
    }), e[22] = r, e[23] = v) : v = e[23];
    let g;
    e[24] === Symbol.for("react.memo_cache_sentinel") ? (g = a.jsx(me, {
        id: "0Laq6P",
        defaultMessage: "Outlook"
    }), e[24] = g) : g = e[24];
    let k;
    e[25] !== w || e[26] !== v ? (k = a.jsx(Ut.Item, {
        onSelect: w,
        icon: C,
        "aria-label": v,
        label: g
    }), e[25] = w, e[26] = v, e[27] = k) : k = e[27];
    let E;
    e[28] !== d ? (E = () => d("default"), e[28] = d, e[29] = E) : E = e[29];
    let j;
    e[30] === Symbol.for("react.memo_cache_sentinel") ? (j = a.jsx(Ip, {}), e[30] = j) : j = e[30];
    let M;
    e[31] !== r ? (M = r.formatMessage({
        id: "aW6dXc",
        defaultMessage: "Open email using default email app"
    }), e[31] = r, e[32] = M) : M = e[32];
    let T;
    e[33] === Symbol.for("react.memo_cache_sentinel") ? (T = a.jsx(me, {
        id: "DcalRY",
        defaultMessage: "Default email app"
    }), e[33] = T) : T = e[33];
    let N;
    e[34] !== E || e[35] !== M ? (N = a.jsx(Ut.Item, {
        onSelect: E,
        icon: j,
        "aria-label": M,
        label: T
    }), e[34] = E, e[35] = M, e[36] = N) : N = e[36];
    let I;
    e[37] !== l || e[38] !== k || e[39] !== N || e[40] !== f || e[41] !== p ? (I = a.jsx("div", {
        className: "hidden md:block",
        children: a.jsxs(zc, {
            alignOffset: -8,
            size: "small",
            tooltip: l,
            tooltipSideOffset: Hr,
            triggerButton: f,
            children: [p, k, N]
        })
    }), e[37] = l, e[38] = k, e[39] = N, e[40] = f, e[41] = p, e[42] = I) : I = e[42];
    let _;
    e[43] !== r ? (_ = r.formatMessage({
        id: "5fZEc+",
        defaultMessage: "Open in email"
    }), e[43] = r, e[44] = _) : _ = e[44];
    let R;
    e[45] !== d ? (R = () => d("default"), e[45] = d, e[46] = R) : R = e[46];
    let A;
    e[47] !== l || e[48] !== _ || e[49] !== R ? (A = a.jsx("div", {
        className: "block md:hidden",
        children: a.jsx(Ni, {
            icon: Ka,
            label: _,
            tooltip: l,
            onClick: R
        })
    }), e[47] = l, e[48] = _, e[49] = R, e[50] = A) : A = e[50];
    let $;
    return e[51] !== I || e[52] !== A ? ($ = a.jsxs(a.Fragment, {
        children: [I, A]
    }), e[51] = I, e[52] = A, e[53] = $) : $ = e[53], $
}
const Cu = x.createContext(void 0);

function Pi() {
    "use forget";
    const t = x.useContext(Cu);
    if (!t) throw new Error("useWritingBlockMessageContext must be used within a WritingBlockMessageContext");
    return t
}

function Ur(t) {
    "use forget";
    const e = xe.c(27),
        {
            isStreamingPlaceholder: s,
            messageRef: n,
            messageId: o,
            editorViewRef: r,
            children: i
        } = t,
        l = s === void 0 ? !1 : s,
        {
            shouldBlockDialogEscapeKeyDown: c
        } = Pi(),
        d = Rt(an),
        u = x.useRef(null),
        [f, h] = x.useState(null);
    let m;
    e[0] !== f ? (m = () => {
        if (typeof document > "u") return;
        if (!an()) {
            f != null && h(null);
            return
        }
        const j = document.getElementById("thread");
        j && j !== f && h(j)
    }, e[0] = f, e[1] = m) : m = e[1];
    let b;
    e[2] !== f || e[3] !== d ? (b = [d, f], e[2] = f, e[3] = d, e[4] = b) : b = e[4], x.useEffect(m, b);
    const {
        isFullscreenDialogOpen: y,
        setIsFullscreenDialogOpen: p
    } = Pi();
    let w;
    e[5] !== f ? (w = () => {
        if (typeof document > "u") return;
        if (!an()) {
            f != null && h(null);
            return
        }
        const j = document.getElementById("thread");
        j && j !== f && h(j)
    }, e[5] = f, e[6] = w) : w = e[6];
    let C;
    e[7] !== f || e[8] !== d ? (C = [d, f], e[7] = f, e[8] = d, e[9] = C) : C = e[9], x.useEffect(w, C);
    let v;
    e[10] !== i || e[11] !== y || e[12] !== l || e[13] !== o || e[14] !== n ? (v = !y && a.jsx("div", {
        ref: n,
        id: "writing-block-".concat(o),
        className: W("group relative z-0 my-4 w-full overflow-visible rounded-2xl", "bg-token-bg-primary", "dark:bg-[#2a2a2a]", "shadow-[0px_0px_0px_1px_rgba(0,0,0,0.07),0px_4px_80px_rgba(0,0,0,0.02)]", l && "h-10 px-4 py-2"),
        "data-writing-block": !0,
        children: i
    }), e[10] = i, e[11] = y, e[12] = l, e[13] = o, e[14] = n, e[15] = v) : v = e[15];
    let g;
    e[16] !== i || e[17] !== f || e[18] !== r || e[19] !== y || e[20] !== c ? (g = y && a.jsxs(mm, {
        container: f,
        children: [a.jsx("div", {
            id: "writing-block-dialog-overlay",
            className: "bg-token-bg-primary fixed inset-0 z-30 cursor-zoom-out"
        }), a.jsx(hm, {
            onInteractOutside: Ej,
            onEscapeKeyDown: E => {
                c && E.preventDefault()
            },
            onOpenAutoFocus: E => {
                E.preventDefault();
                const j = u.current;
                j && j.focus()
            },
            onCloseAutoFocus: E => {
                E.preventDefault();
                const j = r.current;
                j && j.focus()
            },
            className: W("group bg-token-bg-primary fixed z-40 w-full", "fixed inset-y-0 start-1/2 z-30 flex h-full -translate-x-1/2 cursor-auto flex-col overflow-y-auto shadow-[0px_0px_0px_1px_rgba(0,0,0,0.07),0px_4px_80px_rgba(0,0,0,0.02)] outline-none lg:max-w-[50rem] dark:bg-[#2a2a2a]"),
            children: i
        })]
    }), e[16] = i, e[17] = f, e[18] = r, e[19] = y, e[20] = c, e[21] = g) : g = e[21];
    let k;
    return e[22] !== y || e[23] !== p || e[24] !== v || e[25] !== g ? (k = a.jsxs(gm, {
        modal: !1,
        open: y,
        onOpenChange: p,
        children: [v, g]
    }), e[22] = y, e[23] = p, e[24] = v, e[25] = g, e[26] = k) : k = e[26], k
}

function Ej(t) {
    const e = t.target;
    e != null && e.closest("#writing-block-dialog-overlay") || t.preventDefault()
}
const jj = new Set(["list", "ordered_list"]);

function Mj(t) {
    var s;
    const e = t.nodes.regular_list_item;
    if (e) return e;
    for (const n of Object.values(t.nodes))
        if (((s = n.spec.group) != null ? s : "").split(/\s+/).filter(Boolean).includes("list_item")) return n;
    return null
}

function Tu(t) {
    const {
        selection: e
    } = t;
    return e.empty && e.$from.parent.isTextblock && e.$from.parentOffset === 0
}

function Iu(t) {
    return t ? jj.has(t.type.name) : !1
}

function Nu(t, e, s) {
    var l;
    if (!e || s === 0) return t;
    const n = c => c.map(d => {
        if (d.type !== e) return d;
        const u = Number(d.attrs.start),
            f = Number(d.attrs.end),
            h = F({}, d.attrs);
        return Number.isFinite(u) && (h.start = u + s), Number.isFinite(f) && (h.end = f + s), e.create(h)
    });
    if (t.isText) return t.mark(n(t.marks));
    const o = (l = t.marks) != null ? l : [];
    if (t.isInline && o.length > 0) return t.mark(n(o));
    if (t.childCount === 0) return t;
    let r = !1;
    const i = [];
    for (let c = 0; c < t.childCount; c += 1) {
        const d = t.child(c),
            u = Nu(d, e, s);
        u !== d && (r = !0), i.push(u)
    }
    return r ? t.copy(Wt.fromArray(i)) : t
}

function Cj(t, e) {
    let s = !1;
    return t.descendants(n => {
        if (!n.isText) return !s;
        for (const o of n.marks)
            if (o.type !== e) return s = !0, !1;
        return !s
    }), s
}

function Jl(t, e) {
    let s = null,
        n = null;
    return t.descendants(o => {
        if (!o.isText) return !0;
        for (const r of o.marks) {
            if (r.type !== e) continue;
            const i = Number(r.attrs.start),
                l = Number(r.attrs.end);
            if (!(!Number.isFinite(i) || !Number.isFinite(l))) {
                s = s == null ? i : Math.min(s, i), n = n == null ? l : Math.max(n, l);
                break
            }
        }
        return !0
    }), s == null || n == null ? null : {
        start: s,
        end: n
    }
}

function Tj(t, e, s) {
    if (!Tu(t)) return !1;
    const {
        $from: n
    } = t.selection;
    for (let o = n.depth; o > 0; o -= 1)
        if (n.node(o).type === s) return Lp(s)(t, e);
    return !1
}

function Pu(t, e, s) {
    let n = t + 1;
    for (let o = 0; o < s; o += 1) n += e.child(o).nodeSize;
    return n
}

function Ij(t, e) {
    for (let s = t.childCount - 1; s >= 0; s -= 1) {
        const n = t.child(s),
            o = Pu(e, t, s);
        if (n.type.isTextblock) return {
            node: n,
            start: o
        };
        if (Iu(n)) {
            const r = Ru(n, o);
            if (r) return r
        }
    }
    return null
}

function Ru(t, e) {
    for (let s = t.childCount - 1; s >= 0; s -= 1) {
        const n = t.child(s),
            o = Pu(e, t, s),
            r = Ij(n, o);
        if (r) return r
    }
    return null
}

function Nj(t, e) {
    var P, U, z;
    const {
        selection: s,
        schema: n
    } = t;
    if (!Tu(t)) return !1;
    const o = n.nodes.paragraph;
    if (!o) return !1;
    const {
        $from: r
    } = s;
    if (r.parent.type !== o || r.depth !== 1) return !1;
    const i = r.before(1),
        l = r.after(1),
        c = t.doc.childBefore(i);
    if (!c.node || !Iu(c.node)) return !1;
    const d = c.node,
        u = i - d.nodeSize,
        f = Ru(d, u);
    if (!f) return !1;
    const {
        node: h,
        start: m
    } = f, b = m + h.nodeSize - 1, y = r.parent, p = (P = n.marks.startend) != null ? P : null, w = p != null ? Jl(h, p) : null, C = p != null ? Jl(y, p) : null, v = C != null && w != null ? Math.max(0, C.end - C.start) : y.textContent.length, g = l - i, k = v - g, E = C != null ? C.start + k : null, j = C != null ? C.end + k : w != null ? w.end + v : null, M = t.tr;
    M.delete(i, l);
    const T = M.mapping.map(b, -1);
    if (y.content.size === 0) return e && (M.setSelection(fn.create(M.doc, T)), e(M.scrollIntoView())), !0;
    let N = y.content;
    if (k !== 0 && p != null) {
        const B = [];
        for (let G = 0; G < y.childCount; G += 1) B.push(Nu(y.child(G), p, k));
        N = Wt.fromArray(B)
    }
    M.insert(T, N);
    const I = M.mapping.map(m + 1, -1),
        _ = M.doc.resolve(I),
        R = _.parent,
        A = [];
    w && Number.isFinite(w.end) && A.push(w.end), typeof j == "number" && Number.isFinite(j) && A.push(j);
    const $ = A.length > 0 ? Math.max(...A) : null;
    if ($ != null) {
        for (let G = 1; G <= _.depth; G += 1) {
            const O = _.node(G),
                H = (U = O.attrs) != null ? U : {},
                S = _.before(G);
            M.setNodeMarkup(S, O.type, ce(F({}, H), {
                end: $
            }))
        }
        const B = Number((z = M.doc.attrs) == null ? void 0 : z.end);
        if (Number.isFinite(B) && k !== 0 ? M.setDocAttribute("end", B + k) : !Number.isFinite(B) && $ != null && M.setDocAttribute("end", $), p != null && w != null && j != null && !Cj(R, p)) {
            const G = R.content.size;
            if (G > 0) {
                const O = I + G,
                    H = [];
                Number.isFinite(w.start) && H.push(w.start), typeof E == "number" && Number.isFinite(E) && H.push(E);
                const S = H.length > 0 ? Math.min(...H) : w.start,
                    V = p.create({
                        start: S,
                        end: Math.max(w.end, j)
                    });
                M.removeMark(I, O, p), M.addMark(I, O, V)
            }
        }
    }
    return e && (M.setSelection(fn.create(M.doc, T)), e(M.scrollIntoView())), !0
}
const Pj = (t, e) => {
    const s = Mj(t.schema);
    return s ? Tj(t, e, s) || Nj(t, e) : !1
};

function Rj() {
    return new ws({
        props: {
            handleKeyDown(t, e) {
                return e.defaultPrevented || e.key !== "Backspace" || e.metaKey || e.ctrlKey || e.altKey ? !1 : Pj(t.state, t.dispatch)
            }
        }
    })
}
const $j = "data-writing-block-empty-placeholder",
    Aj = "paragraph",
    An = new Os("writingBlockEmptyNodePlaceholder");

function Lj(t, e) {
    return new ws({
        key: An,
        state: {
            init(s, n) {
                return {
                    decorations: ec(n.doc, n.selection, t, e),
                    isDisabled: t,
                    placeholderText: e
                }
            },
            apply(s, n) {
                var l, c, d, u;
                const o = s.getMeta(An),
                    r = (c = (l = Ql(o) ? o.isDisabled : void 0) != null ? l : n.isDisabled) != null ? c : t,
                    i = (u = (d = Ql(o) ? o.placeholderText : void 0) != null ? d : n.placeholderText) != null ? u : e;
                return !s.docChanged && !s.selectionSet && r === n.isDisabled && i === n.placeholderText ? n : {
                    decorations: ec(s.doc, s.selection, r, i),
                    isDisabled: r,
                    placeholderText: i
                }
            }
        },
        props: {
            decorations(s) {
                var n, o;
                return (o = (n = An.getState(s)) == null ? void 0 : n.decorations) != null ? o : null
            }
        }
    })
}

function Dj(t, e) {
    return t.setMeta(An, e)
}

function Ql(t) {
    return typeof t == "object" && t != null && (Object.prototype.hasOwnProperty.call(t, "isDisabled") || Object.prototype.hasOwnProperty.call(t, "placeholderText"))
}

function ec(t, e, s, n) {
    if (s || !e.empty) return as.empty;
    const o = Oj(e, n);
    return o ? as.create(t, [o]) : as.empty
}

function Oj(t, e) {
    const s = t.$from.parent;
    if (!s.isTextblock || s.type.name !== Aj || s.content.size > 0) return null;
    const n = t.$from.before();
    if (typeof n != "number") return null;
    const o = n + s.nodeSize;
    return ln.node(n, o, {
        [$j]: e
    })
}
const cn = "generateSuggestionId";
class ha extends Bp {
    static proseMirrorMarkName() {
        return "generate_suggestion"
    }
    unistNodeName() {
        return ha.proseMirrorMarkName()
    }
    unistToProseMirrorTest() {
        return !1
    }
    unistNodeToProseMirrorNodes(e) {
        return [null]
    }
    proseMirrorMarkSpec() {
        return {
            inclusive: !0,
            attrs: {
                [cn]: {
                    default: null
                }
            },
            parseDOM: [{
                tag: "span.writing-block-generate-suggestion",
                getAttrs: e => e instanceof HTMLElement ? {
                    [cn]: e.getAttribute("data-generate-suggestion")
                } : !1
            }],
            toDOM(e) {
                var r;
                const s = (r = e.attrs) == null ? void 0 : r[cn];
                return ["span", {
                    class: "writing-block-generate-suggestion",
                    "data-generate-suggestion": typeof s == "string" ? s : ""
                }]
            }
        }
    }
    processConvertedUnistNode(e) {
        return e
    }
}
const Xt = new Os("writingBlockGenerate"),
    Ri = as.empty,
    Fj = {
        input: null,
        suggestion: null,
        decorations: Ri,
        lastResolvedSuggestionId: null,
        lastResolvedReason: null
    },
    ga = t => typeof t == "object" && t != null,
    Bj = t => ga(t) && typeof t.anchorPos == "number" && typeof t.caretPos == "number" && typeof t.blockFrom == "number" && typeof t.blockTo == "number" && typeof t.triggerPos == "number",
    Wj = t => ga(t) && typeof t.id == "string" && typeof t.from == "number" && typeof t.to == "number",
    zj = t => t === "accept" || t === "reject" || t === "cancel",
    Hj = t => {
        if (!ga(t) || typeof t.type != "string") return !1;
        switch (t.type) {
            case "set-suggestion":
                return Wj(t.suggestion);
            case "clear-suggestion":
                return zj(t.reason) && (t.suggestionId == null || typeof t.suggestionId == "string");
            case "open-input":
                return Bj(t.input);
            case "close-input":
                return !0;
            default:
                return !1
        }
    },
    Uj = (t, e, s) => {
        if (!e) return null;
        const n = t.map(e.anchorPos, 1),
            o = t.map(e.caretPos, 1),
            r = t.map(e.blockFrom, -1),
            i = t.map(e.blockTo, 1),
            l = t.map(e.triggerPos, -1);
        return r < 0 || r >= s.content.size || i < r ? null : {
            anchorPos: n,
            caretPos: o,
            blockFrom: r,
            blockTo: i,
            triggerPos: l
        }
    },
    Gj = (t, e, s) => {
        if (!e) return null;
        const n = s.type.schema.marks.generate_suggestion;
        if (!n) return null;
        const o = t.map(e.from, -1);
        if (o < 0 || o >= s.content.size) return null;
        const r = s.nodeAt(o);
        if (!r || !r.isText || !n.isInSet(r.marks)) return null;
        const i = o + r.nodeSize;
        return i <= o ? null : {
            id: e.id,
            from: o,
            to: i
        }
    },
    tc = t => {
        const e = t.type.schema.marks.generate_suggestion;
        if (!e) return null;
        let s = null;
        return t.descendants((n, o) => {
            var r;
            if (s) return !1;
            if (n.isText) {
                const i = e.isInSet(n.marks);
                if (i) {
                    const l = (r = i.attrs) == null ? void 0 : r[cn];
                    if (typeof l == "string" && l.length > 0) return s = {
                        id: l,
                        from: o,
                        to: o + n.nodeSize
                    }, !1
                }
            }
            return !0
        }), s
    },
    qj = () => new ws({
        key: Xt,
        state: {
            init: (t, e) => {
                const s = tc(e.doc);
                return ce(F({}, Fj), {
                    suggestion: s
                })
            },
            apply(t, e) {
                let s = e.decorations.map(t.mapping, t.doc),
                    n = Uj(t.mapping, e.input, t.doc),
                    o = Gj(t.mapping, e.suggestion, t.doc),
                    r = e.lastResolvedSuggestionId,
                    i = e.lastResolvedReason;
                t.docChanged && e.suggestion && !o && (r = e.suggestion.id, i = "reject");
                const l = t.getMeta(Xt),
                    c = Hj(l) ? l : null;
                t.docChanged && (c == null ? void 0 : c.type) !== "set-suggestion" && n && (n = null), (c == null ? void 0 : c.type) === "open-input" ? (n = c.input, r = null, i = null) : (c == null ? void 0 : c.type) === "close-input" ? n = null : (c == null ? void 0 : c.type) === "set-suggestion" ? (o = c.suggestion, s = Ri, n = null, r = null, i = null) : (c == null ? void 0 : c.type) === "clear-suggestion" && (o ? (r = o.id, i = c.reason) : c.suggestionId && (r = c.suggestionId, i = c.reason), o = null, s = Ri);
                const d = tc(t.doc);
                return d ? (o = d, (c == null ? void 0 : c.type) !== "set-suggestion" && (r = null, i = null)) : (c == null ? void 0 : c.type) !== "set-suggestion" && (c == null ? void 0 : c.type) !== "clear-suggestion" && (o = null), {
                    input: n,
                    suggestion: o,
                    decorations: s,
                    lastResolvedSuggestionId: r,
                    lastResolvedReason: i
                }
            }
        },
        props: {
            decorations(t) {
                var e;
                return (e = Xt.getState(t)) == null ? void 0 : e.decorations
            }
        }
    }),
    Vj = (t, e) => {
        const s = {
                type: "open-input",
                input: e
            },
            n = t.state.tr.setMeta(Xt, s);
        t.dispatch(n)
    },
    sc = t => {
        var r, i;
        const e = Xt.getState(t.state);
        let s = t.state.tr;
        const n = (r = e == null ? void 0 : e.input) != null ? r : null;
        if (n) {
            const l = s.doc,
                c = Math.max(0, Math.min(n.caretPos, l.content.size)),
                d = (i = it.findFrom(l.resolve(c), 1, !0)) != null ? i : it.near(l.resolve(c), 1);
            s.selection.eq(d) || (s = s.setSelection(d))
        }
        const o = {
            type: "close-input"
        };
        s = s.setMeta(Xt, o), t.dispatch(s), t.hasFocus() || t.focus()
    },
    Kj = ({
        view: t,
        pmu: e,
        suggestionId: s,
        text: n
    }) => {
        var T, N, I;
        const o = Xt.getState(t.state);
        if (!(o != null && o.input)) return !1;
        const i = (T = t.state.schema.marks.generate_suggestion) != null ? T : null;
        if (!i) return !1;
        const {
            caretPos: l,
            triggerPos: c,
            anchorPos: d
        } = o.input, u = e.parse(n != null ? n : "");
        if (u.content.size === 0) return !1;
        let f = t.state.tr;
        const h = Math.max(d, l);
        c < h && (f = f.delete(c, h));
        const m = _ => Math.max(0, Math.min(f.mapping.map(_), f.doc.content.size)),
            b = Math.min(d, l),
            y = Math.max(d, l),
            p = m(b),
            w = m(y);
        p < w && (f = f.delete(p, w));
        const C = p,
            v = f.doc.resolve(C),
            g = u.childCount === 1 && ((N = u.firstChild) == null ? void 0 : N.type.name) === "paragraph",
            k = g ? u.firstChild.content : u.content,
            E = v.parent.isTextblock && v.parent.content.size === 0;
        let j = C,
            M = 0;
        if (E && !g) {
            const _ = v.before(),
                R = v.after();
            f = f.replaceWith(_, R, k), j = _, M = k.size
        } else f = f.insert(C, k), j = C, M = k.size;
        if (M > 0) {
            const _ = i.create({
                [cn]: s
            });
            f = f.addMark(j, j + M, _);
            const R = (I = it.findFrom(f.doc.resolve(j + M), 1, !0)) != null ? I : it.near(f.doc.resolve(j + M), 1);
            f = f.setSelection(R), f.setMeta(rr, !0);
            const A = {
                type: "set-suggestion",
                suggestion: {
                    id: s,
                    from: j,
                    to: j + M
                }
            };
            return f.setMeta(Xt, A), t.dispatch(f), !0
        }
        return !1
    },
    Xj = (t, e) => Qj(t, e, "accept"),
    Yj = (t, e) => {
        const s = $u(t.state, e).sort((r, i) => i.from - r.from);
        if (s.length === 0) return !1;
        let n = t.state.tr;
        s.forEach(({
            from: r,
            to: i
        }) => {
            const l = n.mapping.map(r),
                c = n.mapping.map(i);
            l >= c || (n = n.delete(l, c), Jj(n, l))
        });
        const o = {
            type: "clear-suggestion",
            reason: "reject",
            suggestionId: e
        };
        return n = n.setMeta(Xt, o), t.dispatch(n), !0
    },
    Zj = t => {
        if (t.isLeaf) return !0;
        let e = !1;
        return t.descendants(s => {
            var n;
            return e ? !1 : s.isLeaf || s.isText && ((n = s.text) != null && n.length) ? (e = !0, !1) : !0
        }), e
    },
    Jj = (t, e) => {
        let s = e;
        for (;;) {
            const n = Math.min(Math.max(s, 0), t.doc.content.size),
                o = t.doc.resolve(n);
            if (o.depth === 0) break;
            let r = !1;
            for (let i = o.depth; i > 0; i--) {
                const l = o.node(i);
                if (Zj(l)) continue;
                const c = o.before(i),
                    d = o.after(i);
                t.delete(c, d), s = Math.max(0, c), r = !0;
                break
            }
            if (!r) break
        }
    },
    Qj = (t, e, s) => {
        const n = t.state.schema.marks.generate_suggestion;
        if (!n) return !1;
        const o = $u(t.state, e);
        if (o.length === 0) return !1;
        let r = t.state.tr;
        o.forEach(({
            from: c,
            to: d
        }) => {
            r = r.removeMark(c, d, n)
        });
        const i = {
            type: "clear-suggestion",
            reason: s,
            suggestionId: e
        };
        r = r.setMeta(Xt, i);
        const l = o[o.length - 1];
        return l && (r = r.setSelection(it.near(r.doc.resolve(l.to))), r = r.scrollIntoView()), t.dispatch(r), !0
    },
    $u = (t, e) => {
        const s = t.schema.marks.generate_suggestion;
        if (!s) return [];
        const n = [];
        return t.doc.descendants((o, r) => {
            var l;
            if (!o.isText) return !0;
            const i = s.isInSet(o.marks);
            return i && ((l = i.attrs) == null ? void 0 : l[cn]) === e && n.push({
                from: r,
                to: r + o.nodeSize
            }), !0
        }), n
    },
    wn = "magicEditId",
    xr = "magicEditHighlightFrom",
    br = "magicEditHighlightTo",
    qn = "magicEditSegmentIndex",
    yr = "magicEditSegmentStartOffset",
    wr = "magicEditSegmentEndOffset";
class Au extends Wp {
    unistToProseMirrorTest() {
        return !1
    }
    unistNodeToProseMirrorNodes(e) {
        return [null]
    }
    createNodeSpec({
        role: e,
        contentEditable: s
    }) {
        return {
            attrs: {
                [wn]: {
                    default: null
                },
                [xr]: {
                    default: null
                },
                [br]: {
                    default: null
                },
                [qn]: {
                    default: null
                },
                [yr]: {
                    default: null
                },
                [wr]: {
                    default: null
                }
            },
            group: "block",
            content: "block*",
            isolating: !0,
            defining: !0,
            selectable: !1,
            allowGapCursor: !1,
            parseDOM: [],
            toDOM(n) {
                var d, u;
                const o = (d = n.attrs) == null ? void 0 : d[wn],
                    r = typeof o == "string" ? o : "",
                    i = (u = n.attrs) == null ? void 0 : u[qn],
                    l = typeof i == "number" ? String(i) : typeof i == "string" ? i : "",
                    c = {
                        "data-me-role": e,
                        "data-me-id": r,
                        "data-magic-edit-block": "true"
                    };
                return l !== "" && (c["data-me-segment"] = l), s || (c.contenteditable = "false", c["aria-readonly"] = "true"), ["div", c, 0]
            }
        }
    }
}
class pa extends Au {
    static proseMirrorNodeName() {
        return "magic_edit_original_block"
    }
    unistNodeName() {
        return pa.proseMirrorNodeName()
    }
    proseMirrorNodeSpec() {
        return this.createNodeSpec({
            role: "orig",
            contentEditable: !1
        })
    }
    proseMirrorNodeToUnistNodes(e, s) {
        return s
    }
}
class xa extends Au {
    static proseMirrorNodeName() {
        return "magic_edit_suggested_block"
    }
    unistNodeName() {
        return xa.proseMirrorNodeName()
    }
    proseMirrorNodeSpec() {
        return this.createNodeSpec({
            role: "sugg",
            contentEditable: !0
        })
    }
    proseMirrorNodeToUnistNodes() {
        return []
    }
}
class eM extends zp {
    constructor(s = {}) {
        super();
        Ra(this, "options");
        this.options = s
    }
    dependencies() {
        let s = !1;
        try {
            s = pm(xm())
        } catch (n) {}
        return [new Up, new yd, new Gp, new Si, new qp, new Vp, new Nn, new Kp, new Xp, new Ei, new Yp, new Dp, new Zi, new Op, new Fp, new Ji, new Zp, new Hp, new Jp, new Qp, new e1, new pa, new xa, new ha, ...s ? [new t1] : []]
    }
    unifiedInitializationHook(s) {
        var o;
        const n = (o = this.options.contentReferences) != null ? o : [];
        return s.use(i1).use(sp).use(a1, {
            singleTilde: !1
        }).use(Rg).use([
            [np, n]
        ]).use(op).use(r1).use(rp).use(s1).use(n1)
    }
}
const nc = new Map;

function tM(t = {}) {
    var o, r;
    const e = {
            shouldStripDirectives: (o = t.shouldStripDirectives) != null ? o : !1,
            contentReferences: (r = t.contentReferences) != null ? r : []
        },
        s = JSON.stringify(e);
    let n = nc.get(s);
    if (n == null) {
        const i = [new eM({
            contentReferences: e.contentReferences
        })];
        t.shouldStripDirectives && i.push(new Pp), n = new Np(i), nc.set(s, n)
    }
    return n
}

function sM(t) {
    return typeof t == "object" && t != null && Object.prototype.hasOwnProperty.call(t, "maxLength")
}
const on = new Os("writingBlockInputConstraints");

function nM(t) {
    return new ws({
        key: on,
        state: {
            init() {
                return {
                    maxLength: t
                }
            },
            apply(e, s) {
                const n = e.getMeta(on);
                return sM(n) ? {
                    maxLength: typeof n.maxLength == "number" ? n.maxLength : null
                } : s
            }
        },
        props: {
            handleTextInput(e, s, n, o) {
                var d;
                const r = on.getState(e.state),
                    i = (d = r == null ? void 0 : r.maxLength) != null ? d : null;
                if (i == null) return !1;
                const l = oc(e.state, i, s, n);
                if (l <= 0) return !0;
                if (o.length <= l) return !1;
                const c = o.slice(0, l);
                return c.length > 0 && e.dispatch(e.state.tr.insertText(c, s, n)), !0
            },
            handlePaste(e, s) {
                var h, m, b;
                const n = on.getState(e.state),
                    o = (h = n == null ? void 0 : n.maxLength) != null ? h : null;
                if (o == null) return !1;
                const r = s.clipboardData;
                if (!r) return !1;
                const i = r.getData("text/html"),
                    l = (m = r.getData("text/plain")) != null ? m : "",
                    {
                        from: c,
                        to: d
                    } = e.state.selection,
                    u = oc(e.state, o, c, d);
                if (i) {
                    if (s.preventDefault(), u <= 0) return !0;
                    const y = new window.DOMParser().parseFromString(i, "text/html");
                    aM(y.body);
                    const p = (b = y.body.innerText) != null ? b : "";
                    p.length > u && (y.body.innerHTML = "", y.body.append(document.createTextNode(p.slice(0, u))));
                    const w = e.state.schema,
                        C = bm.fromSchema(w).parseSlice(y.body, {
                            preserveWhitespace: !0
                        });
                    return e.dispatch(e.state.tr.replaceSelection(C)), !0
                }
                if (l.length === 0) return !1;
                if (u <= 0) return s.preventDefault(), !0;
                if (l.length <= u) return !1;
                s.preventDefault();
                const f = l.slice(0, u);
                return e.dispatch(e.state.tr.insertText(f, c, d)), !0
            }
        }
    })
}

function oM(t, e) {
    return t.setMeta(on, {
        maxLength: typeof e == "number" ? e : null
    })
}

function oc(t, e, s, n) {
    const o = rM(t.doc),
        r = iM(t, s, n);
    return e - (o - r)
}

function rM(t) {
    return t.textBetween(0, t.content.size, "\n", "\n").length
}

function iM(t, e, s) {
    return e === s ? 0 : t.doc.textBetween(e, s, "\n", "\n").length
}

function aM(t) {
    const e = document.createTreeWalker(t, NodeFilter.SHOW_ELEMENT),
        s = [];
    for (; e.nextNode();) {
        const n = e.currentNode;
        if (!(n instanceof HTMLElement)) continue;
        const o = n;
        o.style && (o.style.color = "", o.style.backgroundColor = "", o.style.fontFamily = "", o.style.fontSize = "", o.style.lineHeight = "", o.style.textDecoration = "", o.style.textShadow = ""), (o.tagName === "SPAN" || o.tagName === "FONT") && !o.hasAttributes() && s.push(o)
    }
    for (const n of s.reverse()) {
        const o = n.parentNode;
        if (o) {
            for (; n.firstChild;) o.insertBefore(n.firstChild, n);
            o.removeChild(n)
        }
    }
}

function Vn(t, e) {
    return lM(t)(e)
}
const lM = Gc(() => ym(t => {
        const e = Ht(t),
            s = Ht(null),
            n = Ht(null),
            o = Ht(null),
            r = Ht(null),
            i = Ht(null),
            l = Ht(null),
            c = Ht(null),
            d = Ht([]),
            u = Ht("pending"),
            f = Ht(null),
            h = Ht([]);
        return {
            magicEditId$: e,
            domAnchor$: s,
            textAnchor$: n,
            baseBlockVersion$: o,
            freeformFeedback$: r,
            fullBlockBodyMarkdown$: i,
            startIndex$: l,
            endIndex$: c,
            replacements$: d,
            status$: u,
            modelSlug$: f,
            segmentDiffs$: h
        }
    })),
    cM = "_4ccM4G_keyBindingTight",
    ba = {
        keyBindingTight: cM,
        "magic-edit-selection": "_4ccM4G_magic-edit-selection"
    };

function dM(t, e) {
    var i;
    const n = ((i = t.dom.ownerDocument) != null ? i : document).createRange(),
        o = t.domAtPos(e.from),
        r = t.domAtPos(e.to);
    return n.setStart(o.node, o.offset), n.setEnd(r.node, r.offset), n
}

function uM(t, e, s) {
    const n = t.resolve(e);
    if (n.parent.inlineContent) return e;
    const o = it.findFrom(n, s, !0);
    return o ? s < 0 ? o.to : o.from : null
}

function $i(t, e, s, n, o) {
    const r = uM(t, n, o);
    if (r == null) throw new Error("Unable to place selection marker.");
    const i = new mn(Wt.from(t.type.schema.text(s)), 0, 0),
        l = t.replace(r, r, i),
        d = e.serialize(l).indexOf(s);
    if (d === -1) throw new Error("Failed to locate selection marker in markdown.");
    return d
}

function fM(t, e) {
    let s = null,
        n = null;
    return t.forEach((o, r) => {
        const i = r,
            l = r + o.nodeSize,
            c = i + 1,
            d = l - 1;
        e.from <= d && e.to >= c && (s != null || (s = i), n = l)
    }), s == null || n == null ? {
        from: 0,
        to: t.content.size
    } : {
        from: s,
        to: n
    }
}

function mM(t, e) {
    const s = t.slice(e.from, e.to),
        n = t.type.create(null, s.content);
    if (!n) throw new Error("Failed to build document segment for magic edit selection.");
    return n
}

function Lu({
    view: t,
    pmu: e,
    range: s
}) {
    const {
        state: n
    } = t, o = n.doc, r = fM(o, s), i = {
        from: Math.max(0, s.from - r.from),
        to: Math.max(0, s.to - r.from)
    }, l = mM(o, r), c = l.content.size, d = e.serialize(l), u = i.from <= 0, f = i.to >= c, h = u ? 0 : $i(l, e, "⟦MAGICSTART⟧", i.from, 1), m = f ? d.length : $i(l, e, "⟦MAGICEND⟧", i.to, -1);
    if (h > m) throw new Error("Failed to locate selection markers in markdown.");
    return {
        fullMarkdown: d,
        startIndex: h,
        endIndex: m,
        blockRange: r
    }
}
const Yt = new Os("writingBlockMagicEdit");

function Ln(t, e, s) {
    return Math.max(e, Math.min(s, t))
}

function rc(t) {
    return typeof t == "object" && t != null
}

function hM(t) {
    if (t === void 0) return !0;
    if (!rc(t)) return !1;
    const {
        setPinnedRange: e,
        removeEntryId: s
    } = t, n = e == null || rc(e) && typeof e.from == "number" && typeof e.to == "number", o = s == null || typeof s == "string";
    return n && o
}

function Du(t, e) {
    if (!e) return null;
    const s = t.map(e.from, -1),
        n = t.map(e.to, 1);
    return {
        from: s,
        to: n
    }
}

function ic(t, e) {
    if (!e) return null;
    const s = Du(t, e);
    return !s || s.to <= s.from ? null : s
}

function Ou(t) {
    var n, o;
    const e = (n = t.nodes.magic_edit_original_block) != null ? n : null,
        s = (o = t.nodes.magic_edit_suggested_block) != null ? o : null;
    return !e || !s ? null : {
        originalType: e,
        suggestedType: s
    }
}

function ac(t) {
    if (typeof t == "number") return Number.isFinite(t) ? t : null;
    if (typeof t == "string" && t.trim() !== "") {
        const e = Number(t);
        return Number.isFinite(e) ? e : null
    }
    return null
}

function lc(t) {
    if (typeof t == "number") return Number.isFinite(t) ? t : null;
    if (typeof t == "string" && t.trim() !== "") {
        const e = Number(t);
        return Number.isFinite(e) ? e : null
    }
    return null
}

function gM(t, e) {
    var i, l;
    const s = ac((i = t.attrs) == null ? void 0 : i[xr]),
        n = ac((l = t.attrs) == null ? void 0 : l[br]);
    if (s == null || n == null) return null;
    const o = e + 1 + Math.max(0, s),
        r = e + 1 + Math.max(0, n);
    return r <= o ? null : {
        from: o,
        to: r
    }
}

function Ai(t, e) {
    if (!t) return null;
    const s = e.pos + 1,
        n = e.pos + e.nodeSize - 1,
        o = Math.max(s, t.from),
        r = Math.min(n, t.to);
    return r <= o ? null : {
        from: o,
        to: r
    }
}

function cc(t) {
    const e = Ou(t.type.schema);
    if (!e) return new Map;
    const s = new Map,
        n = r => {
            if (typeof r == "number" && Number.isFinite(r)) return r;
            if (typeof r == "string" && r.trim() !== "") {
                const i = Number(r);
                if (Number.isFinite(i)) return i
            }
            return 0
        };
    t.descendants((r, i) => {
        var l, c, d, u;
        if (r.type === e.originalType || r.type === e.suggestedType) {
            const f = (l = r.attrs) == null ? void 0 : l[wn];
            if (!f) return !1;
            const h = n((c = r.attrs) == null ? void 0 : c[qn]);
            let m = s.get(f);
            m || (m = new Map, s.set(f, m));
            let b = m.get(h);
            b || (b = {}, m.set(h, b));
            const y = {
                    pos: i,
                    nodeSize: r.nodeSize
                },
                p = Ai(gM(r, i), y),
                w = {
                    position: y,
                    highlight: p,
                    selectionStartOffset: lc((d = r.attrs) == null ? void 0 : d[yr]),
                    selectionEndOffset: lc((u = r.attrs) == null ? void 0 : u[wr])
                };
            return r.type === e.originalType ? b.original = w : b.suggested = w, !1
        }
        return !0
    });
    const o = new Map;
    return s.forEach((r, i) => {
        const l = [];
        if (r.forEach((u, f) => {
                var h, m, b, y, p, w, C, v, g, k, E, j, M, T, N, I;
                !u.original && !u.suggested || l.push({
                    index: f,
                    original: (m = (h = u.original) == null ? void 0 : h.position) != null ? m : null,
                    suggested: (y = (b = u.suggested) == null ? void 0 : b.position) != null ? y : null,
                    originalHighlight: (w = (p = u.original) == null ? void 0 : p.highlight) != null ? w : null,
                    suggestedHighlight: (v = (C = u.suggested) == null ? void 0 : C.highlight) != null ? v : null,
                    selectionStartOffset: (j = (E = (g = u.original) == null ? void 0 : g.selectionStartOffset) != null ? E : (k = u.suggested) == null ? void 0 : k.selectionStartOffset) != null ? j : 0,
                    selectionEndOffset: (I = (N = (M = u.original) == null ? void 0 : M.selectionEndOffset) != null ? N : (T = u.suggested) == null ? void 0 : T.selectionEndOffset) != null ? I : 0
                })
            }), l.length === 0) return;
        l.sort((u, f) => u.index - f.index);
        let c = 1 / 0,
            d = -1 / 0;
        l.forEach(u => {
            u.original && (c = Math.min(c, u.original.pos), d = Math.max(d, u.original.pos + u.original.nodeSize)), u.suggested && (c = Math.min(c, u.suggested.pos), d = Math.max(d, u.suggested.pos + u.suggested.nodeSize))
        }), o.set(i, {
            id: i,
            from: c === 1 / 0 ? 0 : c,
            to: d === -1 / 0 ? 0 : d,
            segments: l
        })
    }), o
}

function Fu(t, e, s) {
    const n = t.topNodeType.createAndFill({}, Wt.from(s));
    return n ? e.serialize(n) : ""
}

function dc(t, e, s) {
    if (!s || s.size === 0) return "";
    const n = t.topNodeType.createAndFill({}, s);
    return n ? e.serialize(n) : ""
}

function uc(t, e, s, n) {
    try {
        return $i(t, e, "⟦MAGICSEG⟧", s, n)
    } catch (o) {
        return -1
    }
}
const pM = new RegExp("\\s+(?=\\r?\\n|$)", "gu");

function Bu(t) {
    return t && t.replace(pM, "")
}

function xM(t, e, s, n) {
    const o = [];
    let r = e;
    for (let i = 0; i < t.content.childCount; i++) {
        const l = t.content.child(i),
            c = l.nodeSize,
            d = r,
            u = r + c,
            f = Fu(n, s, l);
        o.push({
            node: l,
            from: d,
            to: u,
            normalizedText: Bu(f),
            textLength: f.length
        }), r = u
    }
    return o
}

function bM(t, e, s) {
    const n = [];
    for (let o = 0; o < t.content.childCount; o++) {
        const r = t.content.child(o),
            i = Fu(s, e, r);
        n.push({
            node: r,
            normalizedText: Bu(i)
        })
    }
    return n
}

function yM(t, e) {
    const s = t.length,
        n = e.length;
    if (s === 0 && n === 0) return [];
    const o = Array.from({
        length: s + 1
    }, () => Array(n + 1).fill(0));
    for (let u = s - 1; u >= 0; u--)
        for (let f = n - 1; f >= 0; f--) t[u].normalizedText === e[f].normalizedText ? o[u][f] = o[u + 1][f + 1] + 1 : o[u][f] = Math.max(o[u + 1][f], o[u][f + 1]);
    const r = [];
    let i = 0,
        l = 0,
        c = null;
    const d = () => {
        c && (r.push(c), c = null)
    };
    for (; i < s || l < n;) {
        if (i < s && l < n && t[i].normalizedText === e[l].normalizedText) {
            d(), i++, l++;
            continue
        }(l >= n || i < s && o[i + 1][l] >= o[i][l + 1]) && i < s ? (c || (c = {
            origStart: i,
            origEnd: i,
            suggStart: l,
            suggEnd: l
        }), c.origEnd = i + 1, i++) : (c || (c = {
            origStart: i,
            origEnd: i,
            suggStart: l,
            suggEnd: l
        }), c.suggEnd = Math.min(l + 1, n), l++)
    }
    return d(), r
}

function wM(t, e, s, n) {
    if (t.length === 0) return [];
    const o = [0];
    for (const r of e) {
        const i = o[o.length - 1];
        o.push(i + r.textLength)
    }
    return t.map((r, i) => {
        var m, b;
        const l = e.slice(r.origStart, r.origEnd),
            c = s.slice(r.suggStart, r.suggEnd);
        let d, u;
        if (l.length > 0) d = l[0].from, u = l[l.length - 1].to;
        else {
            const y = r.origStart < e.length ? e[r.origStart].from : e.length > 0 ? e[e.length - 1].to : n;
            d = y, u = y
        }
        const f = l.length > 0 ? Wt.fromArray(l.map(y => y.node)) : null,
            h = c.length > 0 ? Wt.fromArray(c.map(y => y.node)) : null;
        return {
            from: d,
            to: u,
            originalFragment: f,
            suggestedFragment: h,
            index: i,
            selectionStartOffset: (m = o[r.origStart]) != null ? m : 0,
            selectionEndOffset: (b = o[r.origEnd]) != null ? b : 0
        }
    })
}

function _M({
    segmentStart: t,
    originalSize: e,
    suggestedSize: s,
    selectionStart: n,
    selectionEnd: o
}) {
    if (e <= 0) return {
        originalHighlight: null,
        suggestedHighlight: null
    };
    const r = t,
        i = t + e,
        l = Math.max(r, n),
        c = Math.min(i, o);
    if (c <= l) return {
        originalHighlight: null,
        suggestedHighlight: null
    };
    const d = {
        from: l - r,
        to: c - r
    };
    if (s <= 0) return {
        originalHighlight: d,
        suggestedHighlight: null
    };
    const u = d.to - d.from,
        f = s - e,
        h = Ln(d.from, 0, Math.max(0, s)),
        m = Ln(h + Math.max(0, u + f), h, Math.max(h, s));
    return {
        originalHighlight: d,
        suggestedHighlight: m > h ? {
            from: h,
            to: m
        } : null
    }
}

function fc(t, e, s) {
    const n = [];
    return e && n.push(ln.inline(e.from, e.to, {
        class: "magic-edit-selection ".concat(ba["magic-edit-selection"])
    })), s.forEach(o => {
        o.segments.forEach(r => {
            r.originalHighlight && n.push(ln.inline(r.originalHighlight.from, r.originalHighlight.to, {
                nodeName: "span",
                "data-me-change": "delta"
            })), r.suggestedHighlight && n.push(ln.inline(r.suggestedHighlight.from, r.suggestedHighlight.to, {
                nodeName: "span",
                "data-me-change": "delta"
            }))
        })
    }), n.length === 0 ? as.empty : as.create(t, n)
}

function vM() {
    return new ws({
        key: Yt,
        state: {
            init: (t, e) => {
                const s = cc(e.doc);
                return {
                    pinnedRange: null,
                    entries: s,
                    decorations: fc(e.doc, null, s)
                }
            },
            apply(t, e, s, n) {
                let o = Du(t.mapping, e.pinnedRange);
                const r = new Map;
                e.entries.forEach((f, h) => {
                    const m = new Map;
                    f.segments.forEach(b => {
                        m.set(b.index, {
                            originalHighlight: ic(t.mapping, b.originalHighlight),
                            suggestedHighlight: ic(t.mapping, b.suggestedHighlight)
                        })
                    }), r.set(h, m)
                });
                const i = t.getMeta(Yt),
                    l = hM(i) ? i : void 0;
                l && l.setPinnedRange !== void 0 && (o = l.setPinnedRange), l != null && l.removeEntryId && r.delete(l.removeEntryId);
                const c = cc(n.doc),
                    d = new Map;
                c.forEach((f, h) => {
                    if (l != null && l.removeEntryId && l.removeEntryId === h) return;
                    const m = r.get(h),
                        b = f.segments.map(y => {
                            var v, g;
                            const p = m == null ? void 0 : m.get(y.index);
                            let w = null;
                            y.original && (w = Ai((v = p == null ? void 0 : p.originalHighlight) != null ? v : y.originalHighlight, y.original));
                            let C = null;
                            return y.suggested && (C = Ai((g = p == null ? void 0 : p.suggestedHighlight) != null ? g : y.suggestedHighlight, y.suggested)), {
                                index: y.index,
                                original: y.original,
                                suggested: y.suggested,
                                originalHighlight: w,
                                suggestedHighlight: C,
                                selectionStartOffset: y.selectionStartOffset,
                                selectionEndOffset: y.selectionEndOffset
                            }
                        });
                    d.set(h, {
                        id: f.id,
                        from: f.from,
                        to: f.to,
                        segments: b
                    })
                });
                const u = fc(n.doc, o, d);
                return {
                    pinnedRange: o,
                    entries: d,
                    decorations: u
                }
            }
        },
        props: {
            decorations(t) {
                var e, s;
                return (s = (e = Yt.getState(t)) == null ? void 0 : e.decorations) != null ? s : as.empty
            }
        }
    })
}

function kM(t) {
    const {
        from: e,
        to: s
    } = t.state.selection;
    if (e === s) return !1;
    const n = t.state.tr;
    return n.setMeta(Yt, {
        setPinnedRange: {
            from: e,
            to: s
        }
    }), t.dispatch(n), !0
}

function SM(t) {
    const e = t.state.tr;
    e.setMeta(Yt, {
        setPinnedRange: null
    }), t.dispatch(e)
}

function EM({
    ctx: t,
    view: e,
    pmu: s,
    magicEditId: n,
    replacementDoc: o,
    selection: r
}) {
    var E, j;
    const {
        state: i
    } = e, l = Ou(i.schema), c = Vn(t, n);
    if (!l) return !1;
    const d = Ln(r.from, 0, i.doc.content.size),
        u = Ln(r.to, d, i.doc.content.size),
        f = i.doc.slice(0, i.doc.content.size),
        h = new mn(o.content, 0, 0),
        m = xM(f, 0, s, i.schema),
        b = bM(h, s, i.schema),
        y = wM(yM(m, b), m, b, 0);
    if (y.length === 0) return !1;
    let p = i.tr,
        w = null;
    const C = [],
        v = d,
        g = u;
    let k = null;
    if (y.forEach(M => {
            var V, J, q, Z, D, te, se, re;
            const T = (V = M.originalFragment) == null ? void 0 : V.size,
                N = (J = M.suggestedFragment) == null ? void 0 : J.size,
                I = p.mapping.map(M.from, -1),
                _ = T ? p.mapping.map(M.to, 1) : I,
                R = k != null && !T ? Math.max(I, k) : I,
                A = T ? _ : R,
                $ = (Z = (q = M.originalFragment) == null ? void 0 : q.size) != null ? Z : 0,
                P = (te = (D = M.suggestedFragment) == null ? void 0 : D.size) != null ? te : 0,
                {
                    originalHighlight: U,
                    suggestedHighlight: z
                } = _M({
                    segmentStart: M.from,
                    originalSize: $,
                    suggestedSize: P,
                    selectionStart: v,
                    selectionEnd: g
                }),
                B = [];
            if (T) {
                const X = l.originalType.create({
                    [wn]: n,
                    [qn]: M.index,
                    [xr]: U ? Math.floor(U.from) : null,
                    [br]: U ? Math.floor(U.to) : null,
                    [yr]: M.selectionStartOffset,
                    [wr]: M.selectionEndOffset
                }, M.originalFragment);
                B.push(X)
            }
            if (N) {
                const X = l.suggestedType.create({
                    [wn]: n,
                    [qn]: M.index,
                    [xr]: z ? Math.floor(z.from) : null,
                    [br]: z ? Math.floor(z.to) : null,
                    [yr]: M.selectionStartOffset,
                    [wr]: M.selectionEndOffset
                }, M.suggestedFragment);
                B.push(X)
            }
            if (B.length === 0) return;
            const G = new mn(Wt.fromArray(B), 0, 0);
            p = p.replaceRange(R, A, G);
            const O = B.reduce((X, he) => X + he.nodeSize, 0);
            if (k = R + O, w == null && N && P > 0) {
                const X = R + (T ? B[0].nodeSize : 0);
                w = Math.min(p.doc.content.size, X + 1)
            }
            const H = dc(i.schema, s, (se = M.originalFragment) != null ? se : Wt.empty),
                S = dc(i.schema, s, (re = M.suggestedFragment) != null ? re : Wt.empty);
            C.push({
                segmentIndex: M.index,
                startIndex: uc(i.doc, s, M.from, 1),
                endIndex: uc(i.doc, s, M.to, -1),
                originalMarkdown: H,
                suggestedMarkdown: S
            })
        }), p.setMeta(rr, !0), p.setMeta(Yt, {
            setPinnedRange: null
        }), w != null) {
        const M = (E = it.findFrom(p.doc.resolve(w), 1, !0)) != null ? E : it.near(p.doc.resolve(w), 1);
        p.setSelection(M)
    } else {
        const M = Ln(d, 0, p.doc.content.size),
            T = (j = it.findFrom(p.doc.resolve(M), -1, !0)) != null ? j : it.near(p.doc.resolve(M), -1);
        p.setSelection(T)
    }
    return p.scrollIntoView(), e.dispatch(p), c.segmentDiffs$.set(C), !0
}

function jM(t, e, s) {
    var u, f, h;
    const n = Yt.getState(t.state);
    if (!n) return;
    const o = n.entries.get(e);
    if (!o) return;
    const r = t.state.doc,
        i = o.segments.map(m => {
            var C, v, g, k, E, j, M, T, N, I, _, R, A, $;
            const b = m.original ? r.nodeAt(m.original.pos) : null,
                y = m.suggested ? r.nodeAt(m.suggested.pos) : null;
            if (!b && !y) return null;
            const p = Math.min((k = (g = (C = m.original) == null ? void 0 : C.pos) != null ? g : (v = m.suggested) == null ? void 0 : v.pos) != null ? k : 0, (T = (M = (E = m.suggested) == null ? void 0 : E.pos) != null ? M : (j = m.original) == null ? void 0 : j.pos) != null ? T : 0),
                w = Math.max(((N = m.original) == null ? void 0 : N.pos) != null ? m.original.pos + ((I = b == null ? void 0 : b.nodeSize) != null ? I : 0) : p, ((_ = m.suggested) == null ? void 0 : _.pos) != null ? m.suggested.pos + ((R = y == null ? void 0 : y.nodeSize) != null ? R : 0) : p);
            return {
                from: p,
                to: w,
                originalContent: (A = b == null ? void 0 : b.content) != null ? A : Wt.empty,
                suggestedContent: ($ = y == null ? void 0 : y.content) != null ? $ : Wt.empty
            }
        }).filter(m => m != null);
    if (i.length === 0) return;
    let l = t.state.tr;
    i.forEach(m => {
        const b = l.mapping.map(m.from, -1),
            y = l.mapping.map(m.to, 1),
            p = s === "keep" ? m.originalContent : m.suggestedContent;
        l = l.replaceRange(b, y, new mn(p, 0, 0))
    }), l.setMeta(Yt, {
        setPinnedRange: null,
        removeEntryId: e
    });
    const c = Math.min(l.doc.content.size, (f = (u = i[0]) == null ? void 0 : u.from) != null ? f : 0),
        d = (h = it.findFrom(l.doc.resolve(c), -1, !0)) != null ? h : it.near(l.doc.resolve(c), -1);
    l.setSelection(d), l.scrollIntoView(), t.dispatch(l)
}

function MM(t, e, s, n) {
    var v, g, k, E, j, M, T, N, I, _, R, A, $, P, U;
    const o = Yt.getState(t.state);
    if (!o) return !1;
    const r = o.entries.get(e);
    if (!r) return !1;
    const i = r.segments.find(z => z.index === s);
    if (!i) return !1;
    const l = t.state.doc,
        c = i.original ? l.nodeAt(i.original.pos) : null,
        d = i.suggested ? l.nodeAt(i.suggested.pos) : null;
    if (!c && !d) return !1;
    const u = Math.min((E = (k = (v = i.original) == null ? void 0 : v.pos) != null ? k : (g = i.suggested) == null ? void 0 : g.pos) != null ? E : 0, (N = (T = (j = i.suggested) == null ? void 0 : j.pos) != null ? T : (M = i.original) == null ? void 0 : M.pos) != null ? N : 0),
        f = Math.max(((I = i.original) == null ? void 0 : I.pos) != null ? i.original.pos + ((_ = c == null ? void 0 : c.nodeSize) != null ? _ : 0) : u, ((R = i.suggested) == null ? void 0 : R.pos) != null ? i.suggested.pos + ((A = d == null ? void 0 : d.nodeSize) != null ? A : 0) : u);
    let h = t.state.tr;
    const m = h.mapping.map(u, -1),
        b = h.mapping.map(f, 1),
        y = n === "keep" ? ($ = c == null ? void 0 : c.content) != null ? $ : Wt.empty : (P = d == null ? void 0 : d.content) != null ? P : Wt.empty;
    h = h.replaceRange(m, b, new mn(y, 0, 0));
    const p = {
        setPinnedRange: null
    };
    r.segments.length === 1 && (p.removeEntryId = e), h.setMeta(Yt, p);
    const w = Math.min(h.doc.content.size, m),
        C = (U = it.findFrom(h.doc.resolve(w), -1, !0)) != null ? U : it.near(h.doc.resolve(w), -1);
    return h.setSelection(C), h.scrollIntoView(), t.dispatch(h), !0
}

function Wu(t) {
    const e = Yt.getState(t.state);
    if (!e) return !1;
    const {
        from: s,
        to: n
    } = t.state.selection;
    if (s === n) return !1;
    for (const o of e.entries.values())
        if (s >= o.from && n <= o.to) return !0;
    return !1
}

function CM(t) {
    var e, s;
    return (s = (e = Yt.getState(t.state)) == null ? void 0 : e.pinnedRange) != null ? s : null
}

function mc(t) {
    var r, i;
    const e = new Map,
        {
            nodes: s
        } = t.type.schema,
        n = (r = s.magic_edit_original_block) != null ? r : null,
        o = (i = s.magic_edit_suggested_block) != null ? i : null;
    return !n || !o || t.descendants((l, c) => {
        var f, h;
        if (l.type !== n && l.type !== o) return !0;
        const d = (f = l.attrs) == null ? void 0 : f[wn];
        if (!d) return !1;
        const u = (h = e.get(d)) != null ? h : {
            hasOriginal: !1,
            hasSuggested: !1
        };
        return l.type === n ? u.hasOriginal = !0 : u.hasSuggested = !0, e.set(d, u), !1
    }), e
}

function TM(t) {
    if (!t) return new Set;
    const e = t,
        s = new Set;
    return typeof e.removeEntryId == "string" && s.add(e.removeEntryId), s
}
const IM = new Os("writingBlockMagicEditGuard");

function NM() {
    return new ws({
        key: IM,
        filterTransaction(t, e) {
            if (!t.docChanged || t.getMeta(Rp)) return !0;
            const s = TM(t.getMeta(Yt)),
                n = mc(e.doc),
                o = mc(t.doc);
            for (const [r, i] of n) {
                const l = o.get(r),
                    c = s.has(r);
                if (!l) {
                    if (!c) return !1;
                    continue
                }
                if (i.hasOriginal && !l.hasOriginal && !c || i.hasSuggested && !l.hasSuggested && !c) return !1
            }
            return !0
        }
    })
}
const PM = "\\[[^\\[\\]]+\\]";

function RM(t) {
    var o;
    const e = new RegExp(PM, "g"),
        s = [];
    let n = e.exec(t);
    for (; n;) {
        const r = (o = n.index) != null ? o : -1;
        r >= 0 && s.push({
            start: r,
            end: r + n[0].length,
            text: n[0]
        }), n = e.exec(t)
    }
    return s
}
const $M = {
    class: "text-token-text-primary cursor-text rounded-sm",
    "data-placeholder-token": "true",
    style: "background-color: color-mix(in srgb, var(--theme-user-selection-bg, var(--selection)) 30%, transparent); padding-top: 4px; padding-bottom: 4px;"
};

function AM(t) {
    return typeof t == "object" && t != null && Object.prototype.hasOwnProperty.call(t, "isDisabled")
}
const rn = new Os("writingBlockPlaceholder");

function LM(t) {
    return new ws({
        key: rn,
        state: {
            init(e, s) {
                return {
                    decorations: hc(s.doc, t),
                    isDisabled: t
                }
            },
            apply(e, s) {
                var r, i;
                const n = e.getMeta(rn),
                    o = (i = (r = AM(n) ? n.isDisabled : void 0) != null ? r : s.isDisabled) != null ? i : t;
                return !e.docChanged && o === s.isDisabled ? s : {
                    isDisabled: o,
                    decorations: hc(e.doc, o)
                }
            }
        },
        props: {
            decorations(e) {
                var s, n;
                return (n = (s = rn.getState(e)) == null ? void 0 : s.decorations) != null ? n : null
            },
            handleDOMEvents: {
                mousedown(e, s) {
                    const n = s.target;
                    if (!(n instanceof HTMLElement)) return !1;
                    const o = n.closest("[data-placeholder-token]");
                    if (!(o instanceof HTMLElement)) return !1;
                    const r = rn.getState(e.state);
                    if (r != null && r.isDisabled) return !1;
                    s.preventDefault(), e.hasFocus() || e.focus();
                    const i = e.posAtDOM(o, 0),
                        l = e.posAtDOM(o, o.childNodes.length),
                        c = fn.create(e.state.doc, i, l);
                    return e.dispatch(e.state.tr.setSelection(c)), !0
                }
            }
        }
    })
}

function DM(t, e) {
    return t.setMeta(rn, {
        isDisabled: e
    })
}

function hc(t, e) {
    if (e) return as.empty;
    const s = [];
    return t.descendants((n, o) => {
        if (!n.type.isText || !n.text) return;
        const r = RM(n.text);
        for (const i of r) {
            const l = o + i.start,
                c = o + i.end;
            s.push(ln.inline(l, c, $M))
        }
    }), as.create(t, s)
}
const ya = [{
    id: "paragraph",
    command: "text paragraph normal",
    messageKey: "text"
}, {
    id: "heading1",
    command: "heading1 h1 heading 1",
    messageKey: "heading1"
}, {
    id: "heading2",
    command: "heading2 h2 heading 2",
    messageKey: "heading2"
}, {
    id: "heading3",
    command: "heading3 h3 heading 3",
    messageKey: "heading3"
}, {
    id: "orderedList",
    command: "ordered list numbered",
    messageKey: "orderedList"
}, {
    id: "unorderedList",
    command: "unordered list bulleted",
    messageKey: "unorderedList"
}];
new Map(ya.map(t => [t.id, t]));
const OM = ya.map(t => t.id),
    FM = () => ya,
    BM = t => ({
        id: t.id,
        command: t.command,
        disabled: !1,
        messageKey: t.messageKey,
        kind: "text-style"
    }),
    WM = FM().map(BM),
    wa = [{
        id: "generate",
        command: "magic text generate",
        disabled: !1,
        messageKey: "generate",
        kind: "generate"
    }, {
        id: "divider",
        command: "divider hr horizontal rule",
        disabled: !1,
        messageKey: "divider",
        kind: "divider"
    }, ...WM],
    zu = new Map(wa.map(t => [t.id, t])),
    zM = ["generate", "divider", ...OM],
    Hu = t => {
        var e;
        return (e = t == null ? void 0 : t.includeMagicTextOption) != null ? e : !0
    },
    Uu = (t, e) => Hu(e) ? t : t.filter(s => s.id !== "generate"),
    HM = (t, e) => Hu(e) ? [...t] : t.filter(s => s !== "generate"),
    UM = t => Uu(wa, t),
    GM = t => {
        var e;
        return (e = zu.get(t)) != null ? e : null
    },
    qM = t => {
        var e, s;
        return (s = (e = zu.get(t)) == null ? void 0 : e.disabled) != null ? s : !0
    },
    VM = t => {
        const e = t.trim().toLowerCase();
        return e.startsWith("/") ? e.slice(1) : e
    },
    KM = (t, e) => t === "" ? HM(zM, e) : Uu(wa, e).filter(s => s.command.includes(t)).map(s => s.id),
    Gt = new Os("writingBlockSlashMenu"),
    XM = t => typeof t == "object" && t != null && "type" in t,
    dn = {
        triggerPos: null,
        anchorPos: null,
        query: "",
        normalizedQuery: "",
        visibleOptionIds: [],
        highlightedOptionId: null
    },
    is = t => (t == null ? void 0 : t.triggerPos) != null && (t == null ? void 0 : t.anchorPos) != null,
    YM = (t, e) => {
        const s = t.selection;
        if (!s.empty || s.from < e || t.doc.textBetween(e, e + 1, "\0", "\0") !== "/") return !1;
        const o = t.doc.resolve(e),
            r = t.selection.$from;
        return o.parent === r.parent
    },
    gc = (t, e, s) => {
        var w, C, v, g, k, E;
        const n = t.doc,
            o = n.content.size,
            r = Math.min(e + 1, o),
            i = (w = s == null ? void 0 : s.previousState) != null ? w : null,
            l = (v = (C = s == null ? void 0 : s.anchorOverride) != null ? C : i == null ? void 0 : i.anchorPos) != null ? v : null,
            c = l != null ? l : r,
            d = t.selection.from,
            u = d >= r ? d : c,
            f = Math.min(Math.max(u, r), o),
            h = f <= r ? "" : n.textBetween(r, f, "\0", "\0"),
            m = VM(h),
            b = KM(m, {
                includeMagicTextOption: s == null ? void 0 : s.includeMagicTextOption
            }),
            y = (g = i == null ? void 0 : i.highlightedOptionId) != null ? g : null,
            p = y && b.length > 0 ? b.includes(y) ? y : (k = b[0]) != null ? k : null : (E = b[0]) != null ? E : null;
        return {
            triggerPos: e,
            anchorPos: f,
            query: h,
            normalizedQuery: m,
            visibleOptionIds: b,
            highlightedOptionId: p
        }
    },
    ZM = t => new ws({
        key: Gt,
        state: {
            init: () => dn,
            apply(e, s, n, o) {
                var d, u;
                const r = e.getMeta(Gt),
                    i = XM(r) ? r : void 0;
                if ((i == null ? void 0 : i.type) === "open") return gc(o, i.triggerPos, {
                    previousState: s,
                    anchorOverride: i.anchorPos,
                    includeMagicTextOption: t == null ? void 0 : t.includeMagicTextOption
                });
                if ((i == null ? void 0 : i.type) === "close") return dn;
                if ((i == null ? void 0 : i.type) === "highlight") {
                    if (!is(s)) return s;
                    const f = i.commandId;
                    return f == null ? ce(F({}, s), {
                        highlightedOptionId: (d = s.visibleOptionIds[0]) != null ? d : null
                    }) : s.visibleOptionIds.includes(f) ? s.highlightedOptionId === f ? s : ce(F({}, s), {
                        highlightedOptionId: f
                    }) : s
                }
                if ((i == null ? void 0 : i.type) === "navigate") {
                    if (!is(s)) return s;
                    const f = s.visibleOptionIds;
                    if (f.length === 0) return s.highlightedOptionId == null ? s : ce(F({}, s), {
                        highlightedOptionId: null
                    });
                    const h = i.direction === "previous" ? -1 : 1,
                        m = s.highlightedOptionId ? f.indexOf(s.highlightedOptionId) : -1,
                        y = ((m >= 0 ? m : 0) + h + f.length) % f.length;
                    return f[y] === s.highlightedOptionId ? s : ce(F({}, s), {
                        highlightedOptionId: (u = f[y]) != null ? u : null
                    })
                }
                if ((i == null ? void 0 : i.type) === "execute" || !is(s)) return s;
                const l = s.triggerPos != null ? e.mapping.map(s.triggerPos, -1) : null,
                    c = s.anchorPos != null ? e.mapping.map(s.anchorPos, 1) : null;
                return l == null || c == null || !YM(o, l) ? dn : gc(o, l, {
                    previousState: ce(F({}, s), {
                        triggerPos: l,
                        anchorPos: c
                    }),
                    includeMagicTextOption: t == null ? void 0 : t.includeMagicTextOption
                })
            }
        },
        props: {
            handleTextInput(e, s, n, o) {
                const r = o.lastIndexOf("/");
                if (r === -1) return !1;
                const i = e.state.tr;
                i.insertText(o, s, n);
                const l = s + r,
                    c = s + o.length;
                return e.dispatch(i.setMeta(Gt, {
                    type: "open",
                    triggerPos: l,
                    anchorPos: c
                })), !0
            },
            handleKeyDown(e, s) {
                const n = Gt.getState(e.state);
                if (s.key === "Escape" && is(n)) {
                    s.preventDefault(), s.stopPropagation();
                    const o = e.state.tr.setMeta(Gt, {
                        type: "close"
                    });
                    return e.dispatch(o), !0
                }
                if (!n || !is(n)) return !1;
                if ((s.key === "ArrowUp" || s.key === "ArrowDown") && n.visibleOptionIds.length > 0) {
                    s.preventDefault(), s.stopPropagation();
                    const o = e.state.tr.setMeta(Gt, {
                        type: "navigate",
                        direction: s.key === "ArrowUp" ? "previous" : "next"
                    });
                    return e.dispatch(o), !0
                }
                if (s.key === "Enter") {
                    s.preventDefault(), s.stopPropagation();
                    const o = n.highlightedOptionId;
                    if (!o || qM(o)) return !0;
                    const r = e.state.tr.setMeta(Gt, {
                        type: "execute",
                        commandId: o
                    });
                    return e.dispatch(r), !0
                }
                return !1
            }
        }
    }),
    Dn = t => {
        const e = Gt.getState(t.state);
        if (!is(e)) return;
        const s = t.state.tr.setMeta(Gt, {
            type: "close"
        });
        t.dispatch(s)
    },
    Gu = "<|magic_edit_start|>",
    qu = "<|magic_edit_end|>";

function Vu(t, e, s) {
    if (e < 0 || s < e || s > t.length) throw new Error("Selection indices must satisfy 0 <= start <= end <= len(md)");
    return t.slice(0, e) + Gu + t.slice(e, s) + qu + t.slice(s)
}

function Ku() {
    "use no forget";
    const t = x.useRef(null),
        e = kr({
            mutationFn: async ({
                payload: n
            }) => {
                var r;
                (r = t.current) == null || r.abort(new DOMException("Request canceled", "AbortError"));
                const o = new AbortController;
                t.current = o;
                try {
                    return await vn.safePost("/conversation/message/writing-blocks/magic-edit", {
                        requestBody: n,
                        authOption: Mr.SendIfAvailable,
                        signal: o.signal
                    })
                } finally {
                    t.current === o && (t.current = null)
                }
            }
        }),
        s = x.useCallback(() => {
            var n;
            (n = t.current) == null || n.abort(new DOMException("Request canceled", "AbortError")), t.current = null
        }, []);
    return F({
        cancel: s
    }, e)
}

function JM({
    fullMarkdown: t,
    startIndex: e,
    endIndex: s
}) {
    if (!(e >= 0 && s >= e && s <= t.length)) {
        console.warn("[MagicEdit] Invalid selection indices", {
            startIndex: e,
            endIndex: s,
            fullMarkdownLength: t.length
        });
        return
    }
    const o = t.slice(0, e) + Gu + t.slice(e, s) + qu + t.slice(s);
    console.warn("[MagicEdit] Marked selection preview", {
        startIndex: e,
        endIndex: s,
        marked: o
    })
}

function QM(t) {
    console.warn("[MagicEdit] Request payload", t)
}

function e6(t, e) {
    const s = Math.max(0, Math.min(t.from, e)),
        n = Math.max(s, Math.min(t.to, e));
    return {
        from: s,
        to: n
    }
}

function pc(t, e) {
    return t.state.doc.textBetween(e.from, e.to, "\n", "\n").endsWith("\n") && e.to > e.from ? ce(F({}, e), {
        to: e.to - 1
    }) : e
}
async function t6({
    view: t,
    pmu: e,
    ctx: s,
    range: n,
    instruction: o,
    numVariations: r,
    magicEditId: i,
    conversationId: l,
    mode: c,
    shouldLogMagicEditDebug: d
}) {
    let u;
    try {
        u = Lu({
            view: t,
            pmu: e,
            range: n
        }), d && JM(u)
    } catch (C) {
        throw new Error("Unable to serialize the current selection for magic edit.")
    }
    const f = dM(t, n),
        h = Vh(t.dom, f),
        m = Kh(u.fullMarkdown, u.startIndex, u.endIndex),
        b = Vu(u.fullMarkdown, u.startIndex, u.endIndex),
        y = await Xh(u.fullMarkdown),
        p = Vn(s, i);
    p.domAnchor$.set(h), p.textAnchor$.set(m), p.baseBlockVersion$.set(y), p.freeformFeedback$.set(o), p.fullBlockBodyMarkdown$.set(u.fullMarkdown), p.startIndex$.set(u.startIndex), p.endIndex$.set(u.endIndex), p.segmentDiffs$.set([]);
    const w = {
        conversation_id: l,
        full_block_body_markdown: u.fullMarkdown,
        start_index: u.startIndex,
        end_index: u.endIndex,
        marked_block_body_markdown: b,
        instruction: o,
        num_variations: r,
        mode: c
    };
    return d && QM(w), {
        payload: w,
        snapshot: {
            domAnchor: h,
            textAnchor: m,
            baseBlockVersion: y,
            blockRange: u.blockRange
        }
    }
}

function xc(t) {
    "use forget";
    const e = xe.c(37),
        {
            view: s,
            pmu: n,
            mode: o
        } = t,
        r = o === void 0 ? "edit" : o,
        i = et(),
        l = ys(),
        c = Ne(),
        d = Sr();
    let u;
    e[0] !== d ? (u = () => d == null ? void 0 : d.serverId$(), e[0] = d, e[1] = u) : u = e[1];
    const f = Rt(u);
    let h;
    e[2] !== i ? (h = at(i, "2671346616"), e[2] = i, e[3] = h) : h = e[3];
    const m = h,
        b = x.useRef(null),
        y = x.useRef(null),
        p = x.useRef(null),
        [w, C] = x.useState(null),
        {
            mutateAsync: v,
            isPending: g,
            cancel: k
        } = Ku();
    let E;
    e[4] !== k ? (E = () => {
        k(), C(null)
    }, e[4] = k, e[5] = E) : E = e[5];
    const j = E;
    let M;
    e[6] !== i || e[7] !== v ? (M = async (B, G) => {
        const O = await v({
                payload: B
            }),
            H = O.choices,
            S = Vn(i, G);
        return S.replacements$.set(H), S.modelSlug$.set(O.model_slug), S.status$.set("ready"), {
            replacements: H,
            magicEditId: G
        }
    }, e[6] = i, e[7] = v, e[8] = M) : M = e[8];
    const T = M;
    let N;
    e[9] !== f || e[10] !== i || e[11] !== T || e[12] !== c || e[13] !== r || e[14] !== n || e[15] !== m || e[16] !== l || e[17] !== s ? (N = async B => {
        var q, Z;
        const {
            instruction: G,
            numVariations: O,
            range: H,
            submissionSource: S
        } = B, V = O === void 0 ? 1 : O;
        if (!s) return null;
        if (!H) {
            const D = c.formatMessage({
                id: "zpmbDf",
                defaultMessage: "Highlight text in the block to use magic edit."
            });
            return l.danger(D, {
                duration: 2
            }), null
        }
        const J = pc(s, H);
        C(S);
        try {
            const D = crypto.randomUUID();
            p.current = D;
            const {
                payload: te,
                snapshot: se
            } = await t6({
                view: s,
                pmu: n,
                ctx: i,
                range: J,
                instruction: G,
                numVariations: V,
                magicEditId: D,
                conversationId: f,
                mode: r,
                shouldLogMagicEditDebug: m
            });
            b.current = se, y.current = te;
            const re = await T(te, D);
            return Xe.logStructuredEvent(wm, {
                conversationId: f,
                magicEditId: D,
                submissionSource: S
            }), Ot.count(Ft.WRITING_BLOCKS, "chatgpt_writing_block_magic_edit_submitted"), C(null), re
        } catch (D) {
            const te = D;
            if (C(null), te instanceof _m && te.rawError.name === "AbortError") return null;
            const se = (q = Zo(te)) != null ? q : c.formatMessage({
                id: "oSt4Kz",
                defaultMessage: "An error occured during magic edit."
            });
            return l.danger(se, {
                duration: 2
            }), Xe.logStructuredEvent(vm, {
                conversationId: f,
                magicEditId: (Z = p.current) != null ? Z : void 0,
                errorName: te instanceof Error ? te.name : "UnknownError"
            }), Ot.count(Ft.WRITING_BLOCKS, "chatgpt_writing_block_magic_edit_failed"), null
        }
    }, e[9] = f, e[10] = i, e[11] = T, e[12] = c, e[13] = r, e[14] = n, e[15] = m, e[16] = l, e[17] = s, e[18] = N) : N = e[18];
    const I = N;
    let _;
    e[19] !== T ? (_ = () => !y.current || !p.current ? Promise.resolve(null) : T(y.current, p.current), e[19] = T, e[20] = _) : _ = e[20];
    const R = _;
    let A;
    e[21] !== i || e[22] !== c || e[23] !== n || e[24] !== l || e[25] !== s ? (A = B => {
        var te, se;
        const {
            magicEditId: G,
            replacement: O,
            range: H
        } = B;
        if (!s) return !1;
        const S = b.current;
        if (!S || !H) return !1;
        const V = pc(s, H);
        let J;
        const q = O != null ? O : "";
        try {
            J = n.parse(q)
        } catch (re) {
            const he = (te = Zo(re)) != null ? te : c.formatMessage({
                id: "wh4sET",
                defaultMessage: "We couldn’t apply magic edit because the suggestion was invalid."
            });
            return l.danger(he, {
                duration: 3
            }), !1
        }
        let Z;
        try {
            const re = e6(S.blockRange, s.state.doc.content.size);
            Z = s.state.doc.replace(re.from, re.to, new mn(J.content, 0, 0))
        } catch (re) {
            const he = (se = Zo(re)) != null ? se : c.formatMessage({
                id: "wh4sET",
                defaultMessage: "We couldn’t apply magic edit because the suggestion was invalid."
            });
            return l.danger(he, {
                duration: 3
            }), !1
        }
        const D = EM({
            ctx: i,
            view: s,
            pmu: n,
            selection: V,
            magicEditId: G,
            replacementDoc: Z
        });
        return D && (b.current = null), D
    }, e[21] = i, e[22] = c, e[23] = n, e[24] = l, e[25] = s, e[26] = A) : A = e[26];
    const $ = A;
    let P;
    e[27] !== s ? (P = () => s ? Wu(s) : !1, e[27] = s, e[28] = P) : P = e[28];
    const U = P;
    let z;
    return e[29] !== $ || e[30] !== j || e[31] !== g || e[32] !== w || e[33] !== R || e[34] !== U || e[35] !== I ? (z = {
        isLoading: g,
        submitMagicEdit: I,
        cancelMagicEdit: j,
        applyMagicEditResult: $,
        isSelectionInsideMagicEdit: U,
        retry: R,
        magicEditSubmissionSource: w
    }, e[29] = $, e[30] = j, e[31] = g, e[32] = w, e[33] = R, e[34] = U, e[35] = I, e[36] = z) : z = e[36], z
}
const s6 = "shadow-[0_8px_12px_0_rgba(0,0,0,0.16),0_0_1px_0_rgba(0,0,0,0.60)] dark:shadow-[0_8px_16px_0_rgba(0,0,0,0.40),inset_0_0_1px_0_rgba(255,255,255,0.25),0_0_1px_0_rgba(0,0,0,0.60)]",
    _a = ({
        children: t
    }) => a.jsx(_d, {
        className: W("bg-token-main-surface-primary m-0 flex h-9 w-fit min-w-0 shrink items-center overflow-hidden rounded-xl px-1 dark:bg-[#353535]", s6, "py-1"),
        children: t
    }),
    Xu = ({
        icon: t,
        hideLabel: e,
        isActive: s,
        label: n,
        subLabel: o,
        iconClassName: r,
        labelClassName: i
    }) => a.jsxs(a.Fragment, {
        children: [t && a.jsx(t, {
            className: W("icon-sm", {
                "me-0.5": !e,
                "text-token-text-tertiary": !e && !s,
                "text-token-text-primary": e && !s,
                "text-token-interactive-label-accent-default hover:text-token-interactive-label-accent-hover": s
            }, r)
        }), !e && a.jsx("span", {
            className: W("truncate text-sm", {
                "text-token-text-primary": !s,
                "text-token-interactive-label-accent-default hover:text-token-interactive-label-accent-hover": s
            }, i),
            children: n
        }), o]
    });
var Pc;
const n6 = Tr(ir)(Pc || (Pc = Qs(["flex h-full items-center rounded-lg gap-2 px-2 hover:bg-black/5 dark:hover:bg-token-interactive-bg-secondary-hover disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-transparent"]))),
    _r = ({
        label: t,
        subLabel: e,
        icon: s,
        isDisabled: n = !1,
        isActive: o = !1,
        hideLabel: r = !1,
        onClick: i,
        onMouseDown: l,
        iconClassName: c,
        labelClassName: d
    }) => a.jsx(n6, {
        onClick: i,
        "aria-label": r ? t : void 0,
        onMouseDown: l,
        disabled: n,
        "aria-pressed": o || void 0,
        "data-state": o ? "on" : void 0,
        children: a.jsx(Xu, {
            icon: s,
            hideLabel: r,
            label: t,
            subLabel: e,
            isActive: o,
            iconClassName: c,
            labelClassName: d
        })
    });
var Rc;
const o6 = Tr(wd)(Rc || (Rc = Qs(["mx-1 p-0 list-none h-3 w-[1px] bg-token-border-default"])));

function r6({
    buttonText: t,
    triggerLabel: e,
    options: s,
    selectedOptionId: n,
    isOpen: o,
    onOpenChange: r,
    onSelect: i,
    preserveSelection: l,
    editorRef: c
}) {
    "use no forget";
    const d = x.useRef(null),
        [u, f] = x.useState(null);
    x.useEffect(() => {
        const m = d.current;
        !m || typeof document > "u" || f(m.closest('[aria-hidden="true"]') != null)
    }, []);
    const h = a.jsxs(a.Fragment, {
        children: [a.jsx("span", {
            className: "text-sm font-medium",
            children: t
        }), a.jsx(ud, {
            "aria-hidden": !0,
            className: "icon-xs text-current"
        })]
    });
    return u !== !1 ? a.jsx("div", {
        ref: d,
        "data-toolbar-surface": "true",
        className: "h-full",
        children: a.jsx(Ya.Button, {
            type: "button",
            "aria-label": e,
            "aria-haspopup": "menu",
            "aria-expanded": o,
            tabIndex: -1,
            "data-state": o ? "open" : "closed",
            className: W("text-token-text-primary flex h-full items-center gap-1 rounded-lg px-2.5", "dark:hover:bg-token-interactive-bg-secondary-hover hover:bg-black/5", o && "bg-token-interactive-bg-secondary-selected"),
            children: h
        })
    }) : a.jsx("div", {
        ref: d,
        "data-toolbar-surface": "true",
        className: "h-full",
        children: a.jsxs(Nr, {
            open: o,
            onOpenChange: m => {
                m && l(), r(m)
            },
            children: [a.jsx(Pr, {
                asChild: !0,
                children: a.jsx(Ya.Button, {
                    type: "button",
                    "aria-label": e,
                    "aria-haspopup": "menu",
                    "aria-expanded": o,
                    className: W("text-token-text-primary flex h-full items-center gap-1 rounded-lg px-2.5", "dark:hover:bg-token-interactive-bg-secondary-hover hover:bg-black/5", "data-[state=open]:bg-token-interactive-bg-secondary-selected"),
                    onMouseDown: m => m.preventDefault(),
                    onPointerDownCapture: l,
                    onKeyDownCapture: m => {
                        (m.key === " " || m.key === "Enter") && l()
                    },
                    children: h
                })
            }), a.jsx(Rr, {
                children: a.jsx($r, {
                    align: "start",
                    alignOffset: -8,
                    sideOffset: 8,
                    className: W(Qi.toolbar, "popover", "bg-token-main-surface-primary w-fit rounded-2xl p-1.5", ea),
                    "data-toolbar-surface": "true",
                    onOpenAutoFocus: m => m.preventDefault(),
                    onCloseAutoFocus: m => {
                        var b;
                        m.preventDefault(), (b = c.current) == null || b.focus({
                            preventScroll: !0
                        })
                    },
                    children: a.jsx("div", {
                        className: "flex flex-col gap-0.5",
                        role: "menu",
                        children: s.map(m => {
                            const b = m.id === n;
                            return a.jsx("button", {
                                type: "button",
                                role: "menuitemradio",
                                "aria-checked": b,
                                "data-selected": b ? "true" : void 0,
                                className: W("text-token-text-primary dark:hover:bg-token-main-surface-secondary rounded-[10px] py-1.5 ps-3 pe-1 text-start text-sm hover:bg-[#f5f5f5]", b && "dark:bg-token-main-surface-secondary bg-[#f5f5f5] font-medium"),
                                onPointerDown: y => y.preventDefault(),
                                onClick: () => i(m.id),
                                children: a.jsxs("span", {
                                    className: "flex w-full items-center justify-between gap-8",
                                    children: [a.jsx("span", {
                                        className: m.className,
                                        children: m.label
                                    }), a.jsx("span", {
                                        className: "text-token-text-tertiary",
                                        children: a.jsx(Ui, {
                                            binding: m.shortcut
                                        })
                                    })]
                                })
                            }, m.id)
                        })
                    })
                })
            })]
        })
    })
}

function Yu(t) {
    "use forget";
    var w, C;
    const e = xe.c(22),
        {
            onDismiss: s,
            editorView: n,
            toolbarContentRef: o,
            isToolbarOpen: r,
            dismissOnPointerDown: i
        } = t,
        l = i === void 0 ? !0 : i;
    let c;
    e[0] !== o ? (c = v => {
        if (!(v instanceof Node)) return !1;
        const g = o.current;
        return g && g.contains(v) ? !0 : v instanceof Element ? v.closest('[data-toolbar-surface="true"]') != null : !1
    }, e[0] = o, e[1] = c) : c = e[1];
    const d = c;
    let u;
    e[2] !== n.dom || e[3] !== r || e[4] !== s ? (u = v => {
        if (v.key !== "Escape" || !r) return;
        s();
        const g = n.dom;
        g && g.focus({
            preventScroll: !0
        })
    }, e[2] = n.dom, e[3] = r, e[4] = s, e[5] = u) : u = e[5];
    const f = u;
    let h;
    e[6] !== d || e[7] !== r || e[8] !== s ? (h = v => {
        const g = v.button === 0 && v.ctrlKey && km() && !Sm();
        d(v.target) || !r || v.button !== 0 || g || s()
    }, e[6] = d, e[7] = r, e[8] = s, e[9] = h) : h = e[9];
    const m = h;
    let b;
    e[10] !== l || e[11] !== ((w = n.dom) == null ? void 0 : w.ownerDocument) || e[12] !== f || e[13] !== m ? (b = () => {
        var g, k;
        const v = (k = (g = n.dom) == null ? void 0 : g.ownerDocument) != null ? k : typeof document < "u" ? document : null;
        if (v) return v.addEventListener("keydown", f), l && v.addEventListener("pointerdown", m, {
            capture: !0
        }), () => {
            v.removeEventListener("keydown", f), l && v.removeEventListener("pointerdown", m, !0)
        }
    }, e[10] = l, e[11] = (C = n.dom) == null ? void 0 : C.ownerDocument, e[12] = f, e[13] = m, e[14] = b) : b = e[14];
    let y;
    e[15] !== l || e[16] !== n || e[17] !== f || e[18] !== m ? (y = [l, n, f, m], e[15] = l, e[16] = n, e[17] = f, e[18] = m, e[19] = y) : y = e[19], x.useEffect(b, y);
    let p;
    return e[20] !== f ? (p = {
        handleKeyDown: f
    }, e[20] = f, e[21] = p) : p = e[21], p
}
const i6 = 12,
    a6 = 250,
    l6 = t => {
        "use forget";
        const e = xe.c(22),
            {
                toolbarRef: s,
                message: n,
                isVisible: o,
                transitionDurationMs: r
            } = t,
            i = r === void 0 ? a6 : r,
            [l, c] = x.useState(null);
        let d;
        e[0] !== o ? (d = () => o, e[0] = o, e[1] = d) : d = e[1];
        const [u, f] = x.useState(d);
        let h;
        e[2] !== o ? (h = () => o, e[2] = o, e[3] = h) : h = e[3];
        const [m, b] = x.useState(h);
        let y, p;
        e[4] !== o || e[5] !== i ? (y = () => {
            if (typeof window > "u") return;
            if (o) {
                let N = null;
                const I = window.requestAnimationFrame(() => {
                    f(!0), N = window.requestAnimationFrame(() => {
                        b(!0)
                    })
                });
                return () => {
                    N != null && window.cancelAnimationFrame(N), window.cancelAnimationFrame(I)
                }
            }
            const M = window.requestAnimationFrame(() => {
                    b(!1)
                }),
                T = window.setTimeout(() => {
                    f(!1), c(null)
                }, i);
            return () => {
                window.cancelAnimationFrame(M), window.clearTimeout(T)
            }
        }, p = [o, i], e[4] = o, e[5] = i, e[6] = y, e[7] = p) : (y = e[6], p = e[7]), x.useEffect(y, p);
        let w, C;
        if (e[8] !== o || e[9] !== s ? (w = () => {
                if (!o || typeof window > "u" || typeof document > "u") return;
                const M = s.current;
                if (!M) {
                    const _ = () => {
                        c(null)
                    };
                    typeof queueMicrotask == "function" ? queueMicrotask(_) : window.requestAnimationFrame(_);
                    return
                }
                const T = () => {
                    const _ = M.getBoundingClientRect();
                    c({
                        left: _.left + _.width / 2,
                        top: _.top - i6
                    })
                };
                typeof queueMicrotask == "function" ? queueMicrotask(T) : T(), window.addEventListener("resize", T), document.addEventListener("scroll", T, !0);
                let N = null;
                typeof ResizeObserver < "u" && (N = new ResizeObserver(() => {
                    T()
                }), N.observe(M));
                let I = null;
                return typeof MutationObserver < "u" && (I = new MutationObserver(() => {
                    T()
                }), I.observe(M, {
                    attributes: !0,
                    attributeFilter: ["style", "class"]
                })), () => {
                    window.removeEventListener("resize", T), document.removeEventListener("scroll", T, !0), N == null || N.disconnect(), I == null || I.disconnect()
                }
            }, C = [o, s], e[8] = o, e[9] = s, e[10] = w, e[11] = C) : (w = e[10], C = e[11]), x.useEffect(w, C), !u || l == null || typeof document > "u" || !document.body) return null;
        const v = "pointer-events-none fixed z-[60] -translate-x-1/2 -translate-y-full transition-opacity ".concat(m ? "opacity-100" : "opacity-0"),
            g = "".concat(i, "ms");
        let k;
        e[12] !== l.left || e[13] !== l.top || e[14] !== g ? (k = {
            left: l.left,
            top: l.top,
            transitionDuration: g
        }, e[12] = l.left, e[13] = l.top, e[14] = g, e[15] = k) : k = e[15];
        let E;
        e[16] !== n ? (E = a.jsx("div", {
            className: "max-w-[320px] rounded-lg bg-blue-400 px-2 py-1 text-center text-xs font-semibold text-white shadow-[0_4px_12px_rgba(0,0,0,0.16)] dark:shadow-[0_4px_12px_rgba(0,0,0,0.4)]",
            children: n
        }), e[16] = n, e[17] = E) : E = e[17];
        let j;
        return e[18] !== k || e[19] !== E || e[20] !== v ? (j = hf.createPortal(a.jsx("div", {
            className: v,
            style: k,
            children: E
        }), document.body), e[18] = k, e[19] = E, e[20] = v, e[21] = j) : j = e[21], j
    },
    Zu = ({
        size: t = 48,
        className: e,
        backgroundStrokeClassName: s,
        spinnerColorClassName: n,
        onClick: o,
        disabled: r = !1,
        ariaLabel: i = "Stop",
        percentage: l = 25
    }) => {
        const c = t,
            d = 1 / 20,
            u = c * d,
            f = (c - u) / 2,
            h = 2 * Math.PI * f,
            m = h - l / 100 * h,
            b = t * .625;
        return a.jsxs("button", {
            type: "button",
            "aria-label": i,
            onClick: o,
            disabled: r,
            className: W("relative inline-flex items-center justify-center rounded-full", "disabled:cursor-not-allowed disabled:opacity-50", "composer-secondary-button-color", e),
            style: {
                width: t,
                height: t
            },
            children: [a.jsxs("svg", {
                width: c,
                height: c,
                viewBox: "0 0 ".concat(c, " ").concat(c),
                className: W("animate-spin", n),
                children: [a.jsx("circle", {
                    className: W("origin-[50%_50%] -rotate-90", s),
                    strokeWidth: u,
                    fill: "transparent",
                    r: f,
                    cx: c / 2,
                    cy: c / 2
                }), a.jsx("circle", {
                    className: "origin-[50%_50%] -rotate-90",
                    stroke: "currentColor",
                    strokeWidth: u,
                    strokeDashoffset: m,
                    strokeDasharray: "".concat(h, " ").concat(h),
                    fill: "transparent",
                    r: f,
                    cx: c / 2,
                    cy: c / 2,
                    style: {
                        strokeLinecap: "round"
                    }
                })]
            }), a.jsx(Yh, {
                className: W("absolute flex items-center justify-center", "rounded-[2px]", "composer-secondary-button-color"),
                style: {
                    width: b,
                    height: b
                }
            })]
        })
    };

function Ju(t) {
    "use forget";
    const e = xe.c(36),
        {
            value: s,
            onChange: n,
            placeholder: o,
            onSubmit: r,
            onCancel: i,
            isLoading: l,
            submitAriaLabel: c,
            cancelAriaLabel: d,
            name: u,
            autoFocus: f,
            disabled: h,
            selectAllOnFocus: m,
            inputRef: b,
            inputClassName: y,
            onKeyDownCapture: p,
            isSubmitDisabled: w
        } = t,
        C = m === void 0 ? !1 : m;
    let v;
    e[0] !== l || e[1] !== w || e[2] !== s ? (v = !l && (w != null ? w : s.trim() === ""), e[0] = l, e[1] = w, e[2] = s, e[3] = v) : v = e[3];
    const g = v;
    let k;
    e[4] !== n ? (k = R => n(R.target.value), e[4] = n, e[5] = k) : k = e[5];
    let E;
    e[6] !== l || e[7] !== i || e[8] !== r ? (E = () => {
        if (l) {
            i();
            return
        }
        r()
    }, e[6] = l, e[7] = i, e[8] = r, e[9] = E) : E = e[9];
    let j;
    e[10] !== y ? (j = W("mx-0! min-w-[300px]! ps-2.5! pe-9!", y), e[10] = y, e[11] = j) : j = e[11];
    const M = h != null ? h : l;
    let T;
    e[12] !== p ? (T = R => {
        p == null || p(R)
    }, e[12] = p, e[13] = T) : T = e[13];
    let N;
    e[14] !== f || e[15] !== b || e[16] !== u || e[17] !== o || e[18] !== C || e[19] !== k || e[20] !== E || e[21] !== j || e[22] !== M || e[23] !== T || e[24] !== s ? (N = a.jsx(Em, {
        ref: b,
        value: s,
        onChange: k,
        placeholder: o,
        onSubmit: E,
        border: !1,
        className: j,
        name: u,
        autoFocus: f,
        disabled: M,
        selectAllOnFocus: C,
        onKeyDownCapture: T
    }), e[14] = f, e[15] = b, e[16] = u, e[17] = o, e[18] = C, e[19] = k, e[20] = E, e[21] = j, e[22] = M, e[23] = T, e[24] = s, e[25] = N) : N = e[25];
    let I;
    e[26] !== d || e[27] !== l || e[28] !== i || e[29] !== r || e[30] !== g || e[31] !== c ? (I = a.jsx("div", {
        className: "absolute end-1.5 top-1/2 flex -translate-y-1/2 items-center justify-center",
        children: l ? a.jsx(Zu, {
            ariaLabel: d,
            size: 20,
            onClick: i
        }) : a.jsx("button", {
            className: W("icon", "composer-submit-btn composer-submit-button-color"),
            onClick: r,
            disabled: g,
            "aria-label": c,
            children: a.jsx(Gi, {
                className: "icon-xs"
            })
        })
    }), e[26] = d, e[27] = l, e[28] = i, e[29] = r, e[30] = g, e[31] = c, e[32] = I) : I = e[32];
    let _;
    return e[33] !== N || e[34] !== I ? (_ = a.jsxs("div", {
        className: "relative",
        children: [N, I]
    }), e[33] = N, e[34] = I, e[35] = _) : _ = e[35], _
}

function c6(t) {
    "use forget";
    const e = xe.c(46),
        {
            editorView: s,
            intl: n,
            isMagicEditOpen: o,
            toggleMagicEdit: r,
            isMagicEditDisabled: i,
            handleKeyDown: l,
            highlightMagicEdit: c,
            isMagicEditLoading: d,
            submitMagicEdit: u,
            applyMagicEditResult: f,
            cancelMagicEdit: h,
            magicEditSubmissionSource: m
        } = t,
        b = c === void 0 ? !1 : c,
        [y, p] = x.useState(""),
        w = x.useRef(null),
        C = x.useRef(!1);
    let v;
    e[0] !== f || e[1] !== s || e[2] !== y || e[3] !== u || e[4] !== r ? (v = async B => {
        var J;
        C.current = !1, B == null || B.preventDefault(), B == null || B.stopPropagation();
        const G = y.trim(),
            O = CM(s);
        if (!G) return;
        const H = await u({
            instruction: G,
            range: O,
            submissionSource: Gn.TOOLBAR
        });
        if (!H || C.current) return;
        const S = (J = H.replacements[0]) != null ? J : "";
        f({
            magicEditId: H.magicEditId,
            replacement: S,
            range: O
        }) && (p(""), r(!1))
    }, e[0] = f, e[1] = s, e[2] = y, e[3] = u, e[4] = r, e[5] = v) : v = e[5];
    const g = v;
    let k;
    e[6] !== h ? (k = () => {
        C.current = !0, h()
    }, e[6] = h, e[7] = k) : k = e[7];
    const E = k;
    let j;
    e[8] !== n ? (j = n.formatMessage({
        id: "ffl53Q",
        defaultMessage: "Describe changes"
    }), e[8] = n, e[9] = j) : j = e[9];
    const M = j;
    let T;
    e[10] !== n ? (T = n.formatMessage({
        defaultMessage: "Submit",
        id: "aria.submit"
    }), e[10] = n, e[11] = T) : T = e[11];
    const N = T;
    let I;
    e[12] !== n ? (I = n.formatMessage({
        defaultMessage: "Cancel",
        id: "aria.cancel"
    }), e[12] = n, e[13] = I) : I = e[13];
    const _ = I;
    let R;
    e[14] !== n ? (R = n.formatMessage({
        id: "OVwqWy",
        defaultMessage: "Ask for changes"
    }), e[14] = n, e[15] = R) : R = e[15];
    const A = R;
    if (!o) {
        const B = b ? "font-semibold text-[#007aff] dark:text-[#4fa6f7]" : "font-medium";
        let G;
        e[16] !== B ? (G = W(B), e[16] = B, e[17] = G) : G = e[17];
        const O = G,
            H = b && "[&_kbd]:text-[#007aff]! dark:[&_kbd]:text-[#4fa6f7]!";
        let S;
        e[18] !== H ? (S = W("text-sm", ba.keyBindingTight, H), e[18] = H, e[19] = S) : S = e[19];
        const V = S;
        let J;
        e[20] !== V ? (J = a.jsx(Ui, {
            binding: md,
            className: V
        }), e[20] = V, e[21] = J) : J = e[21];
        let q;
        e[22] !== r ? (q = () => r(!0), e[22] = r, e[23] = q) : q = e[23];
        let Z;
        e[24] !== i || e[25] !== O || e[26] !== A || e[27] !== J || e[28] !== q ? (Z = a.jsx(_r, {
            label: A,
            labelClassName: O,
            subLabel: J,
            onClick: q,
            onMouseDown: d6,
            isDisabled: i
        }), e[24] = i, e[25] = O, e[26] = A, e[27] = J, e[28] = q, e[29] = Z) : Z = e[29];
        let D;
        e[30] === Symbol.for("react.memo_cache_sentinel") ? (D = a.jsx(o6, {}), e[30] = D) : D = e[30];
        let te;
        return e[31] !== Z ? (te = a.jsxs(a.Fragment, {
            children: [Z, D]
        }), e[31] = Z, e[32] = te) : te = e[32], te
    }
    const $ = m === Gn.TOOLBAR && d;
    let P;
    e[33] !== y ? (P = y.trim(), e[33] = y, e[34] = P) : P = e[34];
    const U = P === "";
    let z;
    return e[35] !== _ || e[36] !== l || e[37] !== E || e[38] !== g || e[39] !== d || e[40] !== y || e[41] !== M || e[42] !== N || e[43] !== U || e[44] !== $ ? (z = a.jsx(Ju, {
        inputRef: w,
        value: y,
        onChange: p,
        placeholder: M,
        onSubmit: g,
        onCancel: E,
        isLoading: $,
        submitAriaLabel: N,
        cancelAriaLabel: _,
        name: "writing-block-magic-edit-instruction",
        autoFocus: !0,
        disabled: d,
        selectAllOnFocus: !1,
        onKeyDownCapture: l,
        isSubmitDisabled: U
    }), e[35] = _, e[36] = l, e[37] = E, e[38] = g, e[39] = d, e[40] = y, e[41] = M, e[42] = N, e[43] = U, e[44] = $, e[45] = z) : z = e[45], z
}

function d6(t) {
    return t.preventDefault()
}
const Li = (t, e) => {
        const s = t.state.schema,
            n = r => {
                r(t.state, t.dispatch)
            };
        let o = null;
        switch (e) {
            case "paragraph":
                o = yd.paragraphStyleCommand(s);
                break;
            case "heading1":
                o = Nn.headingStyleCommand(s, 1);
                break;
            case "heading2":
                o = Nn.headingStyleCommand(s, 2);
                break;
            case "heading3":
                o = Nn.headingStyleCommand(s, 3);
                break;
            case "orderedList":
                o = Zi.orderedListCommand(s);
                break;
            case "unorderedList":
                o = Ji.unorderedListCommand(s);
                break
        }
        o && n(o)
    },
    u6 = (t, e) => {
        var d, u;
        const s = Gt.getState(t.state),
            n = (d = s == null ? void 0 : s.triggerPos) != null ? d : null,
            o = (u = s == null ? void 0 : s.anchorPos) != null ? u : null;
        if (n == null) {
            Li(t, e), Dn(t);
            return
        }
        const r = Math.max(n + 1, o != null ? o : n + 1);
        let i = t.state.tr.delete(n, r);
        const l = Math.max(Math.min(n, i.doc.content.size), 0),
            c = fn.create(i.doc, l);
        i = i.setSelection(c), t.dispatch(i), Li(t, e), Dn(t)
    },
    Xo = .5,
    bc = (t, e) => Math.abs(t.left - e.left) < Xo && Math.abs(t.top - e.top) < Xo && Math.abs(t.width - e.width) < Xo && Math.abs(t.height - e.height) < Xo,
    f6 = (t, e) => {
        if (!t) return null;
        const {
            selectionRect: s,
            editorRect: n
        } = t, o = 8, r = s.left + s.width / 2 - e.width / 2, i = Math.min(Math.max(r, n.left), Math.max(n.left + n.width - e.width, 0)), l = s.top - e.height - o;
        return {
            left: i,
            top: l,
            height: s.height + e.height * 2 + o * 2
        }
    },
    rs = Ts({
        bold: {
            id: "Z0FJiE",
            defaultMessage: "Bold"
        },
        italic: {
            id: "Ros0Mw",
            defaultMessage: "Italic"
        },
        textStylesTrigger: {
            id: "hngz+P",
            defaultMessage: "Text styles"
        },
        text: {
            id: "fGeL2E",
            defaultMessage: "Text"
        },
        heading1: {
            id: "Z1ugOp",
            defaultMessage: "Heading 1"
        },
        heading2: {
            id: "lVfGMg",
            defaultMessage: "Heading 2"
        },
        heading3: {
            id: "c55YcX",
            defaultMessage: "Heading 3"
        },
        heading1Glyph: {
            id: "QzkS3/",
            defaultMessage: "H1"
        },
        heading2Glyph: {
            id: "F2BLPp",
            defaultMessage: "H2"
        },
        heading3Glyph: {
            id: "SVuVmp",
            defaultMessage: "H3"
        },
        numberedList: {
            id: "IGi1BS",
            defaultMessage: "Numbered list"
        },
        bulletedList: {
            id: "EkLnA6",
            defaultMessage: "Bulleted list"
        },
        magicEditSelectNux: {
            id: "oihe9x",
            defaultMessage: "Ask ChatGPT for changes"
        }
    }),
    m6 = ({
        editorView: t,
        intl: e,
        isMagicEditEnabled: s,
        shouldDisableMagicEdit: n,
        toolbarContentRef: o,
        onToolbarOpenChange: r,
        onMagicEditInvoked: i,
        highlightMagicEdit: l = !1,
        isMagicEditLoading: c,
        submitMagicEdit: d,
        applyMagicEditResult: u,
        cancelMagicEdit: f,
        magicEditSubmissionSource: h,
        fullscreenMode: m
    }) => {
        "use no forget";
        const b = et(),
            y = qc(),
            p = x.useRef(null),
            w = o != null ? o : p,
            [C, v] = x.useState(!1);
        x.useEffect(() => {
            r == null || r(C)
        }, [C, r]);
        const [g, k] = x.useState(!1), [E, j] = x.useState(!1), M = n || E, [T, N] = x.useState(!1), I = x.useRef(null), _ = x.useCallback(() => t.dom, [t]), R = x.useRef(null), A = x.useRef(null), [$, P] = x.useState(0), U = x.useRef(!1), z = x.useRef(null), [B, G] = x.useState(!1), [O, H] = x.useState(!1), [S, V] = x.useState("paragraph"), J = x.useCallback(Q => {
            const ae = R.current;
            ae == null && Q == null || ae != null && Q != null && bc(ae.selectionRect, Q.selectionRect) && bc(ae.editorRect, Q.editorRect) || (R.current = Q, P(Ge => Ge + 1))
        }, []), q = x.useCallback(() => {
            var Je, He, Ke, dt, ut;
            const Q = t.state,
                {
                    from: ae,
                    to: _e,
                    empty: Ge,
                    $from: ze
                } = Q.selection,
                Ve = Q.schema.marks[Si.proseMirrorMarkName()],
                De = Q.schema.marks[Ei.proseMirrorMarkName()];
            if (Ge) {
                const Oe = (Je = Q.storedMarks) != null ? Je : ze.marks(),
                    Be = !!Ve && !!(Oe != null && Oe.find(ht => ht.type === Ve)),
                    st = !!De && !!(Oe != null && Oe.find(ht => ht.type === De));
                G(Be), H(st)
            } else {
                const Oe = Q.doc.textBetween(ae, _e, "\n", "\n"),
                    Be = (Ke = (He = Oe.match(/^\s*/)) == null ? void 0 : He[0].length) != null ? Ke : 0,
                    st = (ut = (dt = Oe.match(/\s*$/)) == null ? void 0 : dt[0].length) != null ? ut : 0,
                    ht = ae + Be,
                    St = _e - st;
                if (ht >= St) G(!1), H(!1);
                else {
                    let Tt = !1,
                        bt = !0,
                        We = !0;
                    Q.doc.nodesBetween(ht, St, Et => {
                        var $t;
                        if (Et.isText) {
                            if (!(($t = Et.text) != null ? $t : "").trim()) return !0;
                            Tt = !0;
                            const Dt = !!Ve && Et.marks.some(At => At.type === Ve),
                                jt = !!De && Et.marks.some(At => At.type === De);
                            if (Dt || (bt = !1), jt || (We = !1), !bt && !We) return !1
                        }
                        return !0
                    }), G(Tt && bt), H(Tt && We)
                }
            }
            let tt = "paragraph";
            const mt = Q.schema.nodes[Nn.proseMirrorNodeName()],
                vt = Q.schema.nodes[Zi.proseMirrorNodeName()],
                kt = Q.schema.nodes[Ji.proseMirrorNodeName()];
            for (let Oe = ze.depth; Oe >= 0; Oe--) {
                const Be = ze.node(Oe);
                if (Be.type === vt) {
                    tt = "orderedList";
                    break
                }
                if (Be.type === kt) {
                    tt = "unorderedList";
                    break
                }
                if (Be.type === mt) {
                    const st = Number(Be.attrs.level);
                    st === 1 ? tt = "heading1" : st === 2 ? tt = "heading2" : tt = "heading3";
                    break
                }
            }
            V(tt)
        }, [t]), Z = x.useCallback(() => {
            if (typeof window > "u") return;
            A.current != null && window.cancelAnimationFrame(A.current);
            const Q = U.current;
            A.current = window.requestAnimationFrame(() => {
                if (A.current = null, Q) return;
                const ae = t.dom;
                if (!ae) {
                    J(null);
                    return
                }
                j(Wu(t));
                const _e = window.getSelection();
                if (!_e || _e.rangeCount === 0 || _e.isCollapsed) {
                    q(), J(null);
                    return
                }
                const Ge = _e.getRangeAt(0);
                if (!Ge || !ae.contains(Ge.commonAncestorContainer)) {
                    q(), J(null);
                    return
                }
                q();
                const ze = Ge.getBoundingClientRect();
                if (!ze || ze.width === 0 && ze.height === 0) {
                    J(null);
                    return
                }
                const Ve = ae.getBoundingClientRect(),
                    {
                        focusNode: De,
                        focusOffset: tt
                    } = _e;
                if (De != null) try {
                    const mt = document.createRange();
                    mt.setStart(De, tt), mt.setEnd(De, tt)
                } catch (mt) {}
                J({
                    selectionRect: {
                        top: ze.top,
                        left: ze.left,
                        width: ze.width,
                        height: ze.height
                    },
                    editorRect: {
                        top: Ve.top,
                        left: Ve.left,
                        width: Ve.width,
                        height: Ve.height
                    }
                })
            })
        }, [J, t, q]);
        x.useEffect(() => {
            if (typeof document > "u" || typeof window > "u") return;
            const Q = () => {
                    Z()
                },
                ae = () => {
                    Z()
                };
            return document.addEventListener("selectionchange", Q), window.addEventListener("resize", ae), window.addEventListener("scroll", ae, !0), Z(), () => {
                document.removeEventListener("selectionchange", Q), window.removeEventListener("resize", ae), window.removeEventListener("scroll", ae), A.current != null && (window.cancelAnimationFrame(A.current), A.current = null)
            }
        }, [Z]);
        const D = x.useCallback(() => {
                const {
                    state: Q,
                    dispatch: ae
                } = t, {
                    selection: _e
                } = Q;
                if (_e.empty) return;
                const Ge = Math.min(_e.to, Q.doc.content.size),
                    ze = Q.doc.resolve(Ge),
                    Ve = it.near(ze, -1);
                Ve.eq(_e) || ae(Q.tr.setSelection(Ve))
            }, [t]),
            te = x.useCallback(() => {
                var _e, Ge, ze;
                const Q = (Ge = (_e = t.dom) == null ? void 0 : _e.ownerDocument) != null ? Ge : typeof document < "u" ? document : null,
                    ae = (ze = Q == null ? void 0 : Q.getSelection) == null ? void 0 : ze.call(Q);
                ae && ae.removeAllRanges()
            }, [t]),
            se = x.useCallback(() => {
                D(), te()
            }, [D, te]),
            re = x.useCallback(Q => {
                Q ? (g || i == null || i(), kM(t), N(!0), k(!0)) : (SM(t), N(!1), k(!1))
            }, [t, g, i]),
            X = x.useCallback(() => {
                re(!1), se()
            }, [re, se]),
            {
                handleKeyDown: he
            } = Yu({
                editorView: t,
                toolbarContentRef: w,
                isToolbarOpen: C,
                onDismiss: X,
                dismissOnPointerDown: !y
            }),
            K = x.useCallback((Q, ae) => {
                const _e = t.dom;
                if (!_e) return;
                const Ge = (ae == null ? void 0 : ae.maintainToolbarPosition) === !0;
                U.current = !0, typeof window < "u" && z.current && (window.clearTimeout(z.current), z.current = null), _e.focus({
                    preventScroll: !0
                });
                try {
                    Q(), q()
                } finally {
                    typeof window < "u" ? z.current = window.setTimeout(() => {
                        U.current = !1, z.current = null, Ge || Z()
                    }, 0) : U.current = !1
                }
            }, [t, Z, q]),
            oe = x.useCallback(Q => {
                K(() => {
                    const {
                        state: ae,
                        dispatch: _e
                    } = t, Ge = ae.schema.marks[Q];
                    Ge && o1(ae, _e, Ge)
                }, {
                    maintainToolbarPosition: !0
                })
            }, [t, K]);
        x.useEffect(() => () => {
            typeof window < "u" && z.current != null && (window.clearTimeout(z.current), z.current = null)
        }, []), x.useEffect(() => {
            if (!s) return;
            const Q = () => {
                I.current && (I.current.action(), I.current.limitToGroups(), I.current = null)
            };
            if (C && !M) {
                const {
                    addAction: ae,
                    limitActionGroups: _e
                } = jm(b);
                I.current = {
                    action: ae({
                        key: "magicEdit",
                        action: () => re(!0),
                        actionMessageDescriptor: e.formatMessage({
                            id: "MWHvyw",
                            defaultMessage: "Toggle magic edit"
                        }),
                        group: Ha.Chat,
                        keyboardBinding: md
                    }),
                    limitToGroups: _e([Ha.Chat])
                }
            } else Q();
            return () => {
                Q()
            }
        }, [b, e, s, C, M, re]);
        const ye = x.useCallback(Q => {
                K(() => {
                    Li(t, Q)
                })
            }, [t, K]),
            ke = x.useMemo(() => [{
                id: "paragraph",
                label: e.formatMessage(rs.text),
                shortcut: Zh
            }, {
                id: "heading1",
                label: e.formatMessage(rs.heading1),
                className: "font-semibold text-[16px]",
                shortcut: Jh
            }, {
                id: "heading2",
                label: e.formatMessage(rs.heading2),
                className: "font-semibold text-[15px]",
                shortcut: Qh
            }, {
                id: "heading3",
                label: e.formatMessage(rs.heading3),
                className: "font-semibold text-[14px]",
                shortcut: eg
            }, {
                id: "orderedList",
                label: e.formatMessage(rs.numberedList),
                shortcut: tg
            }, {
                id: "unorderedList",
                label: e.formatMessage(rs.bulletedList),
                shortcut: sg
            }], [e]),
            ie = e.formatMessage(rs.textStylesTrigger),
            [ee, fe] = x.useState(!1),
            Se = x.useRef(null),
            je = x.useCallback(() => {
                if (typeof window > "u") {
                    Se.current = null;
                    return
                }
                const Q = window.getSelection();
                if (!Q || Q.rangeCount === 0) {
                    Se.current = null;
                    return
                }
                Se.current = Q.getRangeAt(0).cloneRange()
            }, []),
            Te = x.useCallback(() => {
                if (typeof window > "u") return;
                const Q = Se.current;
                if (!Q) return;
                const ae = window.getSelection();
                ae && (ae.removeAllRanges(), ae.addRange(Q))
            }, []);
        x.useEffect(() => {
            ee || (Se.current = null)
        }, [ee]);
        const Ye = x.useMemo(() => {
                const Q = ke.find(ae => ae.id === S);
                return Q ? Q.label : e.formatMessage(rs.text)
            }, [S, e, ke]),
            ge = e.formatMessage(rs.magicEditSelectNux),
            lt = l && C && !g,
            [{
                height: Ze,
                width: pe
            }, de] = d1(),
            [Me, we] = x.useState(!0),
            [$e, Ue] = x.useState(!1),
            [Ae, pt] = x.useState(!0),
            Le = _(),
            [ct, Ct] = x.useState(null),
            ft = x.useCallback(() => {
                const Q = _(),
                    ae = document.getSelection();
                return !ae || ae.type !== "Range" || ae.isCollapsed || !(Q != null && Q.contains(ae.anchorNode))
            }, [_]);
        x.useEffect(() => {
            const Q = La(() => {
                    pt(!0)
                }, 200, {
                    leading: !1
                }),
                ae = La(() => {
                    Ue(!0), pt(!1), Q()
                }, 200, {
                    leading: !0
                }),
                _e = () => {
                    ae.cancel(), Ue(!1)
                };
            return Le == null || Le.addEventListener("pointerdown", ae, {
                passive: !0
            }), document.addEventListener("pointerup", _e, {
                passive: !0
            }), () => {
                Le == null || Le.removeEventListener("pointerdown", ae), document.removeEventListener("pointerup", _e)
            }
        }, [Le]), x.useEffect(() => {
            const Q = () => {
                we(ft())
            };
            return document.addEventListener("selectionchange", Q, {
                passive: !0
            }), () => {
                document.removeEventListener("selectionchange", Q)
            }
        }, [ft]), un(() => {
            if (Me || ft()) return we(!0);
            try {
                const Q = f6(R.current, {
                    width: pe,
                    height: Ze
                });
                Q != null && Ct(Q)
            } catch (Q) {
                Mm.error("Invalid position in getToolbarPosition", {
                    error: Q
                })
            }
        }, [Ze, pe, Me, ft, $]);
        const _t = (!Me || T) && ct != null && Ae;
        return x.useEffect(() => {
            v == null || v(_t)
        }, [_t, v]), a.jsxs(a.Fragment, {
            children: [a.jsx(Vc, {
                asChild: !0,
                children: a.jsx("div", {
                    style: _t && ct ? {
                        top: ct.top,
                        left: ct.left,
                        height: ct.height
                    } : void 0,
                    className: W("pointer-events-none absolute start-0 top-0 h-0", !_t && "invisible overflow-clip"),
                    ref: w,
                    children: a.jsx("div", {
                        ref: de,
                        className: W("sticky", m ? "top-2" : "@w-xl/main:top-2 top-[calc(var(--header-height,48px)+48px+8px)]", $e ? "pointer-events-none" : "pointer-events-auto"),
                        children: a.jsxs(_a, {
                            children: [s && a.jsx(c6, {
                                editorView: t,
                                intl: e,
                                isMagicEditOpen: g,
                                toggleMagicEdit: re,
                                isMagicEditDisabled: M,
                                handleKeyDown: he,
                                highlightMagicEdit: l,
                                isMagicEditLoading: c,
                                magicEditSubmissionSource: h,
                                submitMagicEdit: d,
                                applyMagicEditResult: u,
                                cancelMagicEdit: f
                            }), !g && a.jsxs(a.Fragment, {
                                children: [a.jsx(_r, {
                                    label: e.formatMessage(rs.bold),
                                    hideLabel: !0,
                                    icon: l1,
                                    onClick: () => oe(Si.proseMirrorMarkName()),
                                    onMouseDown: Q => Q.preventDefault(),
                                    isActive: B
                                }), a.jsx(_r, {
                                    label: e.formatMessage(rs.italic),
                                    hideLabel: !0,
                                    icon: c1,
                                    onClick: () => oe(Ei.proseMirrorMarkName()),
                                    onMouseDown: Q => Q.preventDefault(),
                                    isActive: O
                                }), a.jsx(r6, {
                                    buttonText: Ye,
                                    editorRef: {
                                        current: t.dom
                                    },
                                    selectedOptionId: S,
                                    isOpen: ee,
                                    onOpenChange: Q => {
                                        Q ? je() : Se.current = null, fe(Q)
                                    },
                                    onSelect: Q => {
                                        Te(), ye(Q), fe(!1), X()
                                    },
                                    options: ke,
                                    preserveSelection: je,
                                    triggerLabel: ie
                                })]
                            })]
                        })
                    })
                })
            }), a.jsx(l6, {
                toolbarRef: w,
                message: ge,
                isVisible: lt
            })]
        })
    },
    h6 = "calc(300px + 1rem)",
    xi = Ts({
        placeholder: {
            id: "Qk8WA/",
            defaultMessage: "Tell ChatGPT what to write"
        },
        cancelLabel: {
            id: "dFfo1P",
            defaultMessage: "Cancel"
        },
        submitLabel: {
            id: "4jyv9s",
            defaultMessage: "Submit"
        }
    });

function g6(t) {
    "use forget";
    const e = xe.c(48),
        {
            value: s,
            onChange: n,
            onSubmit: o,
            onCancel: r,
            isLoading: i,
            anchorPos: l,
            editorView: c,
            editorRootRef: d
        } = t,
        u = Ne(),
        f = x.useRef(null),
        h = x.useRef(null);
    let m;
    e[0] !== d ? (m = (q, Z, D) => {
        var te;
        return Jc((te = d.current) != null ? te : q, Z, D, {
            ancestorResize: !0,
            ancestorScroll: !0
        })
    }, e[0] = d, e[1] = m) : m = e[1];
    const b = m;
    let y;
    e[2] === Symbol.for("react.memo_cache_sentinel") ? (y = [Kc(8), Xc({
        fallbackPlacements: ["top-start"]
    }), Yc({
        padding: 8
    })], e[2] = y) : y = e[2];
    let p;
    e[3] !== b ? (p = {
        placement: "bottom-start",
        middleware: y,
        whileElementsMounted: b
    }, e[3] = b, e[4] = p) : p = e[4];
    const {
        refs: w,
        floatingStyles: C,
        update: v,
        x: g,
        y: k
    } = Zc(p), E = g !== 0 && k !== 0;
    let j, M;
    e[5] !== E ? (j = () => {
        var q;
        E && ((q = h.current) == null || q.focus())
    }, M = [E], e[5] = E, e[6] = j, e[7] = M) : (j = e[6], M = e[7]), x.useEffect(j, M);
    const T = w.setReference,
        N = w.setFloating;
    let I, _;
    e[8] !== l || e[9] !== d || e[10] !== c || e[11] !== T || e[12] !== v ? (I = () => {
        var Z;
        if (!c || l == null) {
            T(null);
            return
        }
        const q = {
            contextElement: (Z = d.current) != null ? Z : void 0,
            getBoundingClientRect: () => {
                try {
                    const D = c.coordsAtPos(l);
                    return new DOMRect(D.left, D.bottom, 0, 0)
                } catch (D) {
                    return new DOMRect
                }
            }
        };
        return T(q), v(), () => {
            T(null)
        }
    }, _ = [l, d, c, T, v], e[8] = l, e[9] = d, e[10] = c, e[11] = T, e[12] = v, e[13] = I, e[14] = _) : (I = e[13], _ = e[14]), x.useEffect(I, _);
    let R, A;
    e[15] !== r ? (R = () => {
        const q = D => {
                const te = f.current;
                te && (D.target instanceof Node && te.contains(D.target) || r())
            },
            Z = D => {
                const te = f.current;
                if (!te) {
                    r();
                    return
                }
                D.target instanceof Node && te.contains(D.target) || r()
            };
        return document.addEventListener("pointerdown", q, !0), document.addEventListener("focusin", Z, !0), () => {
            document.removeEventListener("pointerdown", q, !0), document.removeEventListener("focusin", Z, !0)
        }
    }, A = [r], e[15] = r, e[16] = R, e[17] = A) : (R = e[16], A = e[17]), x.useEffect(R, A);
    let $;
    e[18] !== N ? ($ = q => {
        f.current = q, N(q)
    }, e[18] = N, e[19] = $) : $ = e[19];
    let P;
    e[20] === Symbol.for("react.memo_cache_sentinel") ? (P = W(Qi.toolbar, "absolute"), e[20] = P) : P = e[20];
    let U;
    e[21] !== C ? (U = ce(F({}, C), {
        width: "max-content",
        minWidth: h6
    }), e[21] = C, e[22] = U) : U = e[22];
    let z;
    e[23] !== u ? (z = u.formatMessage(xi.placeholder), e[23] = u, e[24] = z) : z = e[24];
    let B;
    e[25] !== u ? (B = u.formatMessage(xi.submitLabel), e[25] = u, e[26] = B) : B = e[26];
    let G;
    e[27] !== u ? (G = u.formatMessage(xi.cancelLabel), e[27] = u, e[28] = G) : G = e[28];
    let O;
    e[29] !== r ? (O = q => {
        q.key === "Escape" && (q.preventDefault(), r())
    }, e[29] = r, e[30] = O) : O = e[30];
    let H;
    e[31] !== s ? (H = s.trim(), e[31] = s, e[32] = H) : H = e[32];
    const S = H === "";
    let V;
    e[33] !== i || e[34] !== r || e[35] !== n || e[36] !== o || e[37] !== z || e[38] !== B || e[39] !== G || e[40] !== O || e[41] !== S || e[42] !== s ? (V = a.jsx(_a, {
        children: a.jsx("div", {
            className: "flex min-w-0 flex-1",
            children: a.jsx(Ju, {
                inputRef: h,
                value: s,
                onChange: n,
                placeholder: z,
                onSubmit: o,
                onCancel: r,
                isLoading: i,
                submitAriaLabel: B,
                cancelAriaLabel: G,
                disabled: i,
                selectAllOnFocus: !1,
                onKeyDownCapture: O,
                isSubmitDisabled: S,
                inputClassName: "w-full"
            })
        })
    }), e[33] = i, e[34] = r, e[35] = n, e[36] = o, e[37] = z, e[38] = B, e[39] = G, e[40] = O, e[41] = S, e[42] = s, e[43] = V) : V = e[43];
    let J;
    return e[44] !== $ || e[45] !== U || e[46] !== V ? (J = a.jsx("div", {
        ref: $,
        className: P,
        style: U,
        children: V
    }), e[44] = $, e[45] = U, e[46] = V, e[47] = J) : J = e[47], J
}
const p6 = [];

function x6(t, e) {
    return t.length === e.length && t.every((s, n) => s.role === e[n].role && s.entryId === e[n].entryId && s.segmentIndex === e[n].segmentIndex && s.top === e[n].top && s.left === e[n].left && s.right === e[n].right && s.bottom === e[n].bottom && s.width === e[n].width && s.height === e[n].height)
}

function Qu(t) {
    "use forget";
    const e = xe.c(8);
    let s;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (s = [], e[0] = s) : s = e[0];
    const [n, o] = x.useState(s);
    let r;
    e[1] !== t ? (r = () => {
        const d = t.current;
        if (!d) {
            o(p6);
            return
        }
        const u = d.querySelectorAll("[data-me-role='orig'], [data-me-role='sugg'], [data-generate-suggestion]"),
            f = Array.from(u).map(b6);
        o(h => x6(h, f) ? h : f)
    }, e[1] = t, e[2] = r) : r = e[2];
    const i = r;
    let l;
    e[3] !== t || e[4] !== i ? (l = () => {
        const d = t.current;
        if (!d) return;
        i();
        const u = new ResizeObserver(i);
        return u.observe(d), () => u.disconnect()
    }, e[3] = t, e[4] = i, e[5] = l) : l = e[5];
    let c;
    return e[6] !== t ? (c = [t], e[6] = t, e[7] = c) : c = e[7], un(l, c), n
}

function b6(t) {
    const {
        offsetTop: e,
        offsetLeft: s,
        offsetWidth: n,
        offsetHeight: o
    } = t;
    return {
        top: e,
        left: s,
        right: s + n,
        bottom: e + o,
        width: n,
        height: o,
        role: t.dataset.meRole,
        entryId: t.dataset.meId,
        segmentIndex: t.dataset.meSegment
    }
}
const Yo = Ts({
        accept: {
            id: "XljG3e",
            defaultMessage: "Accept"
        },
        acceptAll: {
            id: "C+wqRb",
            defaultMessage: "Accept all edits"
        },
        reject: {
            id: "ClnYCK",
            defaultMessage: "Undo"
        },
        rejectAll: {
            id: "niZJIE",
            defaultMessage: "Undo all"
        }
    }),
    y6 = [ng.Mod, "Enter"],
    yc = 36,
    w6 = 5,
    _6 = 12;

function wc(t) {
    "use forget";
    const e = xe.c(49),
        {
            editorView: s,
            editorRootRef: n,
            activeEntryId: o,
            onAccept: r,
            onReject: i,
            fullscreenMode: l
        } = t,
        c = Ne(),
        d = x.useRef(null),
        u = et(),
        f = x.useRef(null),
        h = Qu(n),
        m = h[0],
        b = h[h.length - 1],
        y = h.filter(v6).length > 1,
        p = o != null && m != null && b != null;
    let w;
    e[0] !== s || e[1] !== p || e[2] !== i ? (w = {
        editorView: s,
        toolbarContentRef: d,
        isToolbarOpen: p,
        onDismiss: i,
        dismissOnPointerDown: !1
    }, e[0] = s, e[1] = p, e[2] = i, e[3] = w) : w = e[3], Yu(w);
    let C;
    e[4] !== o || e[5] !== n || e[6] !== r ? (C = () => {
        var S, V;
        if (!o) return;
        const O = (V = (S = n.current) == null ? void 0 : S.ownerDocument) != null ? V : document,
            H = J => {
                Cm(J) || Tm(J) !== Im() || J.key !== "Enter" || (J.preventDefault(), r())
            };
        return O.addEventListener("keydown", H, !0), () => {
            O.removeEventListener("keydown", H, !0)
        }
    }, e[4] = o, e[5] = n, e[6] = r, e[7] = C) : C = e[7];
    let v;
    e[8] !== o || e[9] !== u || e[10] !== n || e[11] !== c || e[12] !== r ? (v = [o, n, r, u, c], e[8] = o, e[9] = u, e[10] = n, e[11] = c, e[12] = r, e[13] = v) : v = e[13], x.useEffect(C, v);
    const g = y ? Yo.acceptAll : Yo.accept,
        k = y ? Yo.rejectAll : Yo.reject;
    let E;
    e[14] !== c || e[15] !== k ? (E = c.formatMessage(k), e[14] = c, e[15] = k, e[16] = E) : E = e[16];
    let j;
    e[17] === Symbol.for("react.memo_cache_sentinel") ? (j = a.jsx("span", {
        className: "text-token-text-tertiary ms-1.5 text-sm",
        children: a.jsx(me, {
            id: "R6HH9/",
            defaultMessage: "ESC"
        })
    }), e[17] = j) : j = e[17];
    let M;
    e[18] !== i || e[19] !== E ? (M = a.jsx(_r, {
        label: E,
        onClick: i,
        labelClassName: "font-semibold text-black! dark:text-white!",
        iconClassName: "text-black! dark:text-gray-400!",
        subLabel: j
    }), e[18] = i, e[19] = E, e[20] = M) : M = e[20];
    let T;
    e[21] !== g || e[22] !== c ? (T = c.formatMessage(g), e[21] = g, e[22] = c, e[23] = T) : T = e[23];
    let N;
    e[24] !== g || e[25] !== c ? (N = c.formatMessage(g), e[24] = g, e[25] = c, e[26] = N) : N = e[26];
    let I;
    e[27] === Symbol.for("react.memo_cache_sentinel") ? (I = a.jsx("span", {
        className: W(ba.keyBindingTight, "ms-1.5 [&_kbd]:text-blue-100! dark:[&_kbd]:text-white/40!"),
        children: a.jsx(Ui, {
            binding: y6
        })
    }), e[27] = I) : I = e[27];
    let _;
    e[28] !== N ? (_ = a.jsx(Xu, {
        label: N,
        subLabel: I,
        labelClassName: "font-semibold text-white"
    }), e[28] = N, e[29] = _) : _ = e[29];
    let R;
    e[30] !== r || e[31] !== _ || e[32] !== T ? (R = a.jsx(ir, {
        onClick: r,
        "aria-label": T,
        className: "bg-token-interactive-label-accent-default ms-1 flex h-full items-center gap-1 rounded-lg px-2 dark:bg-blue-500",
        children: _
    }), e[30] = r, e[31] = _, e[32] = T, e[33] = R) : R = e[33];
    let A;
    e[34] !== R || e[35] !== M ? (A = a.jsxs(_a, {
        children: [M, R]
    }), e[34] = R, e[35] = M, e[36] = A) : A = e[36];
    const $ = A;
    if (!p) return null;
    const P = yc + w6,
        U = yc + _6;
    let z;
    e[37] !== o || e[38] !== $ ? (z = o && a.jsx("div", {
        "aria-hidden": "true",
        className: "pointer-events-none invisible fixed start-0 top-0 h-0 overflow-clip",
        children: a.jsx("div", {
            ref: f,
            children: $
        })
    }), e[37] = o, e[38] = $, e[39] = z) : z = e[39];
    let B;
    e[40] !== m || e[41] !== l || e[42] !== p || e[43] !== b || e[44] !== $ ? (B = p && a.jsx("div", {
        ref: d,
        style: {
            top: m.top - P,
            height: b.bottom - m.top + P + U
        },
        className: "pointer-events-none absolute start-1/2 z-1 -translate-x-1/2",
        children: a.jsx("div", {
            className: W("pointer-events-auto sticky", l ? "top-2" : "@w-xl/main:top-2 top-[calc(var(--header-height,48px)+8px)]"),
            children: $
        })
    }), e[40] = m, e[41] = l, e[42] = p, e[43] = b, e[44] = $, e[45] = B) : B = e[45];
    let G;
    return e[46] !== z || e[47] !== B ? (G = a.jsxs(a.Fragment, {
        children: [z, B]
    }), e[46] = z, e[47] = B, e[48] = G) : G = e[48], G
}

function v6(t) {
    return t.role === "sugg"
}
const k6 = 8,
    S6 = [];

function E6({
    editorRootRef: t,
    activeEntry: e,
    onAccept: s,
    onReject: n,
    focusEditor: o
}) {
    "use no forget";
    var h;
    const r = Ne(),
        i = (h = e == null ? void 0 : e.segments) != null ? h : S6,
        l = x.useRef(i.length > 1);
    x.useEffect(() => {
        l.current = l.current || i.length > 1
    }, [i.length]);
    const c = Qu(t),
        d = x.useMemo(() => i.map(m => {
            const b = m.index,
                y = c.find(C => C.role === "orig" && C.segmentIndex === "".concat(b)),
                p = c.find(C => C.role === "sugg" && C.segmentIndex === "".concat(b)),
                w = p != null ? p : y;
            return w ? {
                top: w.bottom,
                segmentIndex: b
            } : null
        }).filter(m => m != null), [i, c]),
        u = x.useCallback(m => {
            s(m), o()
        }, [o, s]),
        f = x.useCallback(m => {
            n(m), o()
        }, [o, n]);
    return d.length === 0 || !l.current ? null : a.jsx("div", {
        className: "pointer-events-none absolute inset-0",
        children: d.map(({
            top: m,
            segmentIndex: b
        }) => a.jsxs(_d, {
            className: W("bg-token-main-surface-primary text-token-text-primary pointer-events-auto m-0 flex h-9 items-center gap-0.5 rounded-xl px-1 py-1.5 dark:bg-[#353535]", "pointer-events-auto absolute", ea),
            style: {
                top: m,
                right: k6
            },
            children: [a.jsx(ir, {
                type: "button",
                "aria-label": r.formatMessage({
                    id: "0VTqgn",
                    defaultMessage: "Undo segment"
                }),
                className: "dark:hover:bg-token-interactive-bg-secondary-hover focus-visible:outline-token-interactive-label-accent-default text-token-text-primary flex h-7 w-7 items-center justify-center rounded-lg hover:bg-black/5 focus-visible:outline-2 focus-visible:outline-offset-2",
                onClick: () => f(b),
                children: a.jsx(og, {
                    className: "h-4 w-4"
                })
            }), a.jsx(wd, {
                className: "bg-token-border-default h-4 w-[1px] list-none p-0"
            }), a.jsx(ir, {
                type: "button",
                "aria-label": r.formatMessage({
                    id: "oV/UED",
                    defaultMessage: "Accept segment"
                }),
                className: W("focus-visible:outline-token-interactive-label-accent-default dark:hover:bg-token-interactive-bg-secondary-hover flex h-7 w-7 items-center justify-center rounded-lg text-[rgba(2,133,255,1)] hover:bg-black/5 focus-visible:outline-2 focus-visible:outline-offset-2"),
                onClick: () => u(b),
                children: a.jsx(Nm, {
                    className: "h-4 w-4"
                })
            })]
        }, "".concat(b)))
    })
}
const _c = Ts({
        text: {
            id: "+lD8Gj",
            defaultMessage: "Text"
        },
        heading1: {
            id: "rIYI87",
            defaultMessage: "Heading 1"
        },
        heading2: {
            id: "TDeCdX",
            defaultMessage: "Heading 2"
        },
        heading3: {
            id: "g1V+cN",
            defaultMessage: "Heading 3"
        },
        orderedList: {
            id: "rCWWta",
            defaultMessage: "Numbered list"
        },
        unorderedList: {
            id: "TxDV7n",
            defaultMessage: "Bulleted list"
        },
        divider: {
            id: "5lM+d4",
            defaultMessage: "Divider"
        },
        generate: {
            id: "xa7JTa",
            defaultMessage: "Generate text"
        },
        menuLabel: {
            id: "ZmuIH8",
            defaultMessage: "Insert options"
        }
    }),
    j6 = "text-token-text-primary hover:text-token-text-primary dark:hover:bg-token-main-surface-secondary rounded-[10px] px-2.5 py-1.5 text-left text-sm hover:bg-[#f5f5f5] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-token-border-strong";

function ef(t) {
    "use forget";
    var te, se, re;
    const e = xe.c(50),
        {
            state: s,
            style: n,
            floatingRef: o,
            dispatchSlashMenuMeta: r,
            disabledOptionIds: i
        } = t,
        l = Ne(),
        c = Pm(),
        d = x.useRef(null);
    let u;
    e[0] !== s ? (u = is(s), e[0] = s, e[1] = u) : u = e[1];
    const f = u;
    s == null || s.visibleOptionIds;
    let h;
    e[2] !== (s == null ? void 0 : s.visibleOptionIds) ? (h = (te = s == null ? void 0 : s.visibleOptionIds) != null ? te : [], e[2] = s == null ? void 0 : s.visibleOptionIds, e[3] = h) : h = e[3];
    const m = h,
        b = (se = s == null ? void 0 : s.highlightedOptionId) != null ? se : null;
    let y;
    e[4] !== r ? (y = () => {
        r({
            type: "close"
        })
    }, e[4] = r, e[5] = y) : y = e[5];
    const p = y;
    let w;
    e[6] !== r ? (w = X => {
        r({
            type: "highlight",
            commandId: X
        })
    }, e[6] = r, e[7] = w) : w = e[7];
    const C = w;
    let v;
    e[8] !== r ? (v = X => {
        r({
            type: "execute",
            commandId: X
        })
    }, e[8] = r, e[9] = v) : v = e[9];
    const g = v;
    let k;
    e[10] !== i || e[11] !== g ? (k = new Map, UM().forEach(X => {
        var K;
        const he = X.disabled || ((K = i == null ? void 0 : i.includes(X.id)) != null ? K : !1);
        k.set(X.id, {
            id: X.id,
            messageKey: X.messageKey,
            disabled: he,
            onSelect: () => {
                g(X.id)
            }
        })
    }), e[10] = i, e[11] = g, e[12] = k) : k = e[12];
    const E = k;
    let j;
    if (e[13] !== E || e[14] !== m) {
        let X;
        e[16] !== E ? (X = he => {
            var K;
            return (K = E.get(he)) != null ? K : null
        }, e[16] = E, e[17] = X) : X = e[17], j = m.map(X).filter(T6), e[13] = E, e[14] = m, e[15] = j
    } else j = e[15];
    const M = j;
    let T;
    e[18] !== C || e[19] !== b || e[20] !== M.length ? (T = X => {
        const he = X.id === b;
        return a.jsx("button", {
            type: "button",
            role: "menuitem",
            "data-highlighted": he ? "true" : void 0,
            className: W(j6, X.disabled && "cursor-not-allowed opacity-50", he && "dark:bg-token-main-surface-secondary bg-[#f5f5f5]"),
            disabled: X.disabled,
            "aria-disabled": X.disabled ? "true" : void 0,
            onClick: () => {
                X.disabled || (C(X.id), X.onSelect())
            },
            onPointerDown: K => {
                K.preventDefault(), K.stopPropagation(), X.disabled || (C(X.id), X.onSelect())
            },
            onMouseEnter: () => {
                M.length > 0 && C(X.id)
            },
            onFocus: () => {
                M.length > 0 && C(X.id)
            },
            children: a.jsx(me, F({}, _c[X.messageKey]))
        }, X.id)
    }, e[18] = C, e[19] = b, e[20] = M.length, e[21] = T) : T = e[21];
    const N = T,
        I = (re = M.find(C6)) != null ? re : null,
        _ = M.filter(M6);
    let R, A;
    e[22] !== p || e[23] !== f || e[24] !== M.length ? (R = () => {
        f && (M.length > 0 || p())
    }, A = [f, p, M.length], e[22] = p, e[23] = f, e[24] = M.length, e[25] = R, e[26] = A) : (R = e[25], A = e[26]), x.useEffect(R, A);
    let $, P;
    e[27] !== p || e[28] !== f ? ($ = () => {
        if (!f) return;
        const X = he => {
            d.current && (he.target instanceof Node && d.current.contains(he.target) || p())
        };
        return document.addEventListener("pointerdown", X, !0), () => {
            document.removeEventListener("pointerdown", X, !0)
        }
    }, P = [f, p], e[27] = p, e[28] = f, e[29] = $, e[30] = P) : ($ = e[29], P = e[30]), x.useEffect($, P);
    let U, z;
    if (e[31] !== p || e[32] !== f ? (U = () => {
            if (!f) return;
            const X = K => {
                    if (!d.current) {
                        p();
                        return
                    }
                    K.target instanceof Node && d.current.contains(K.target) || p()
                },
                he = () => {
                    p()
                };
            return window.addEventListener("blur", he), document.addEventListener("focusin", X, !0), () => {
                window.removeEventListener("blur", he), document.removeEventListener("focusin", X, !0)
            }
        }, z = [f, p], e[31] = p, e[32] = f, e[33] = U, e[34] = z) : (U = e[33], z = e[34]), x.useEffect(U, z), !f) return null;
    const B = Vc,
        G = !0;
    let O;
    e[35] !== o ? (O = X => {
        d.current = X, o == null || o(X)
    }, e[35] = o, e[36] = O) : O = e[36];
    const H = "menu";
    let S;
    e[37] !== l ? (S = l.formatMessage(_c.menuLabel), e[37] = l, e[38] = S) : S = e[38];
    let V;
    e[39] === Symbol.for("react.memo_cache_sentinel") ? (V = W(Qi.toolbar, ea, "writing-block-slash-menu popover bg-token-main-surface-primary absolute w-fit rounded-2xl p-1.5", "flex flex-col gap-1"), e[39] = V) : V = e[39];
    const J = -1,
        q = M.length === 0 ? null : a.jsxs(a.Fragment, {
            children: [I ? N(I) : null, I && _.length > 0 ? a.jsx("div", {
                "aria-hidden": "true",
                role: "separator",
                className: "border-token-border-subtle w-full border-t opacity-100"
            }) : null, _.map(X => N(X))]
        });
    let Z;
    e[40] !== n || e[41] !== O || e[42] !== S || e[43] !== V || e[44] !== q ? (Z = a.jsx("div", {
        ref: O,
        role: H,
        "aria-label": S,
        className: V,
        style: n,
        tabIndex: J,
        children: q
    }), e[40] = n, e[41] = O, e[42] = S, e[43] = V, e[44] = q, e[45] = Z) : Z = e[45];
    let D;
    return e[46] !== B || e[47] !== c || e[48] !== Z ? (D = a.jsx(B, ce(F({}, c), {
        asChild: G,
        children: Z
    })), e[46] = B, e[47] = c, e[48] = Z, e[49] = D) : D = e[49], D
}

function M6(t) {
    return t.id !== "generate"
}

function C6(t) {
    return t.id === "generate"
}

function T6(t) {
    return t != null
}
ef.displayName = "WritingBlockSlashMenu";
const tf = Ht(!1),
    vc = 10,
    kc = -35,
    nn = -32,
    Sc = (t, e, s) => Math.max(e, Math.min(s, t)),
    Ec = {
        pointer: 0,
        caret: 1,
        select: 2
    },
    I6 = t => {
        "use forget";
        const e = xe.c(109),
            {
                editorAreaRef: s,
                isInlineWritingBlockEditEnabled: n,
                docChangeCount: o,
                selectionIsCollapsed: r,
                isFormatToolbarOpen: i,
                magicEditTriggerCount: l,
                onSelectNuxVisibilityChange: c,
                analyticsMetadata: d
            } = t,
            u = i === void 0 ? !1 : i,
            f = l === void 0 ? 0 : l,
            h = et(),
            m = Ne();
        let b;
        e[0] === Symbol.for("react.memo_cache_sentinel") ? (b = Rm(), e[0] = b) : b = e[0];
        const y = b,
            p = Fn(Bn.WritingBlockNux),
            {
                eligible: w,
                isLoading: C
            } = oi(en.hasSeenWritingInlineEditNux),
            {
                eligible: v
            } = oi(en.hasSeenWritingInlineEditCaretNux),
            {
                eligible: g,
                isLoading: k
            } = oi(en.hasSeenWritingInlineEditSelectNux),
            [E, j] = x.useState(!1),
            [M, T] = x.useState(null),
            [N, I] = x.useState(null),
            [_, R] = x.useState(!1),
            [A, $] = x.useState(!1),
            [P, U] = x.useState(!1),
            z = x.useRef(!1),
            B = x.useRef(!1),
            G = x.useRef(!1),
            O = x.useRef(null),
            H = x.useRef(null),
            S = x.useRef(o),
            V = x.useRef(f),
            J = x.useRef(null),
            q = x.useRef(!1);
        let Z;
        e[1] !== d.blockId || e[2] !== d.clientThreadId || e[3] !== d.messageId ? (Z = {
            writingBlockId: d.blockId
        }, d.clientThreadId && (Z.clientThreadId = d.clientThreadId), d.messageId && (Z.messageId = d.messageId), e[1] = d.blockId, e[2] = d.clientThreadId, e[3] = d.messageId, e[4] = Z) : Z = e[4];
        const D = Z;
        let te, se;
        e[5] === Symbol.for("react.memo_cache_sentinel") ? (te = () => {
            J.current = $m()
        }, se = [], e[5] = te, e[6] = se) : (te = e[5], se = e[6]), x.useEffect(te, se);
        let re;
        e[7] === Symbol.for("react.memo_cache_sentinel") ? (re = () => {
            O.current = null, q.current = !1
        }, e[7] = re) : re = e[7];
        let X;
        e[8] !== d.blockId ? (X = [d.blockId], e[8] = d.blockId, e[9] = X) : X = e[9], x.useEffect(re, X);
        let he;
        e[10] !== s ? (he = () => {
            var ms;
            const ne = s.current;
            if (!ne) {
                I(null);
                return
            }
            const le = document.getSelection();
            if (!le || le.rangeCount === 0 || !le.anchorNode || !le.focusNode || !le.isCollapsed || !ne.contains(le.anchorNode) && !ne.contains(le.focusNode)) {
                I(null);
                return
            }
            const Pe = le.getRangeAt(0),
                Ee = ne.getBoundingClientRect();
            let Ce = Pe.getBoundingClientRect();
            if (!Number.isFinite(Ce.left) || !Number.isFinite(Ce.top) || Ce.width === 0 && Ce.height === 0 || Ce.left === 0 && Ce.top === 0) {
                const Bs = Pe.getClientRects();
                if (Bs.length > 0) Ce = Bs[0];
                else {
                    let Vt = null;
                    const _s = le.anchorNode;
                    for (_s && (Vt = _s instanceof Element ? _s : (ms = _s.parentElement) != null ? ms : null); Vt && Vt !== ne && !ne.contains(Vt);) Vt = Vt.parentElement;
                    Ce = Vt && ne.contains(Vt) ? Vt.getBoundingClientRect() : Ee
                }
            }
            let Qe = Ce.left - Ee.left + vc,
                Lt = Ce.top - Ee.top + kc;
            const Jt = Math.max(nn, Ee.width - nn),
                os = Math.max(nn, Ee.height - nn);
            Qe = Sc(Qe, nn, Jt), Lt = Sc(Lt, nn, os), I({
                x: Qe,
                y: Lt
            })
        }, e[10] = s, e[11] = he) : he = e[11];
        const K = he;
        let oe;
        e[12] !== h ? (oe = at(h, "2862575767"), e[12] = h, e[13] = oe) : oe = e[13];
        const ke = !y && n && (oe || p),
            ie = ke && w && !E,
            ee = Rt(P6),
            fe = ee || ke && !w && !C && v && !_,
            Se = (ee || fe) && A && N != null,
            je = ie && M != null,
            Te = Se && N != null,
            ge = ke && !C && !k && !w && !v && g && !P && u,
            lt = Te && E && !_;
        let Ze;
        e: {
            if (je) {
                Ze = "pointer";
                break e
            }
            if (Te) {
                Ze = "caret";
                break e
            }
            if (ge) {
                Ze = "select";
                break e
            }
            Ze = null
        }
        const pe = Ze;
        let de;
        e[14] !== D.clientThreadId || e[15] !== D.messageId || e[16] !== D.variant || e[17] !== D.writingBlockId ? (de = ne => {
            const le = J.current;
            Xe.logStructuredEvent(Am, {
                conversationId: D.clientThreadId,
                messageId: D.messageId,
                writingBlockId: D.writingBlockId,
                variant: D.variant,
                phase: ne,
                sessionLoggingId: le || void 0
            }), Ot.count(Ft.WRITING_BLOCKS, "chatgpt_writing_block_inline_edit_nux_shown");
            const Pe = O.current;
            Pe != null && Ec[ne] === Ec[Pe] + 1 && (Xe.logStructuredEvent(Lm, {
                conversationId: D.clientThreadId,
                messageId: D.messageId,
                writingBlockId: D.writingBlockId,
                variant: D.variant,
                fromPhase: Pe,
                toPhase: ne,
                sessionLoggingId: le || void 0
            }), Ot.count(Ft.WRITING_BLOCKS, "chatgpt_writing_block_inline_edit_nux_advanced")), O.current = ne
        }, e[14] = D.clientThreadId, e[15] = D.messageId, e[16] = D.variant, e[17] = D.writingBlockId, e[18] = de) : de = e[18];
        const Me = de;
        let we, $e;
        e[19] !== pe || e[20] !== Me ? (we = () => {
            pe && Me(pe)
        }, $e = [pe, Me], e[19] = pe, e[20] = Me, e[21] = we, e[22] = $e) : (we = e[21], $e = e[22]), x.useEffect(we, $e);
        let Ue;
        e[23] === Symbol.for("react.memo_cache_sentinel") ? (Ue = () => {
            z.current = !1
        }, e[23] = Ue) : Ue = e[23];
        let Ae;
        e[24] !== ie ? (Ae = [ie], e[24] = ie, e[25] = Ae) : Ae = e[25], x.useEffect(Ue, Ae);
        let pt;
        e[26] !== h ? (pt = () => {
            j(!0), T(null), ri(h, en.hasSeenWritingInlineEditNux)
        }, e[26] = h, e[27] = pt) : pt = e[27];
        const Le = pt;
        let ct;
        e[28] !== h ? (ct = () => {
            B.current || (B.current = !0, R(!0), I(null), ri(h, en.hasSeenWritingInlineEditCaretNux))
        }, e[28] = h, e[29] = ct) : ct = e[29];
        const Ct = ct;
        let ft;
        e[30] !== h ? (ft = () => {
            G.current || (G.current = !0, U(!0), ri(h, en.hasSeenWritingInlineEditSelectNux))
        }, e[30] = h, e[31] = ft) : ft = e[31];
        const _t = ft;
        let Q;
        e[32] !== s ? (Q = ne => {
            const le = s.current;
            if (!le) return !1;
            if (ne.composedPath().includes(le)) return !0;
            const Ee = ne.target;
            if (Ee instanceof Node && le.contains(Ee)) return !0;
            const Ce = le.getBoundingClientRect(),
                {
                    clientX: zt,
                    clientY: Qe
                } = ne;
            return zt >= Ce.left && zt <= Ce.right && Qe >= Ce.top && Qe <= Ce.bottom
        }, e[32] = s, e[33] = Q) : Q = e[33];
        const ae = Q;
        let _e, Ge;
        e[34] !== Le || e[35] !== s || e[36] !== ae || e[37] !== ie ? (_e = () => {
            if (!ie) return;
            const ne = s.current;
            if (!ne) return;
            const le = () => {
                    H.current != null && (window.clearTimeout(H.current), H.current = null)
                },
                Pe = Qe => {
                    le(), ae(Qe) || T(null)
                },
                Ee = Qe => {
                    if (le(), !ae(Qe)) {
                        T(null);
                        return
                    }
                    z.current = !0;
                    const Lt = ne.getBoundingClientRect();
                    T({
                        x: Qe.clientX - Lt.left + vc,
                        y: Qe.clientY - Lt.top + kc
                    })
                },
                Ce = () => {
                    le(), H.current = window.setTimeout(() => {
                        T(null)
                    }, 80)
                },
                zt = Qe => {
                    le(), ae(Qe) && z.current && Le()
                };
            return ne.addEventListener("pointerenter", Pe), ne.addEventListener("pointermove", Ee), ne.addEventListener("pointerleave", Ce), ne.addEventListener("pointercancel", Ce), ne.addEventListener("pointerdown", zt), () => {
                le(), ne.removeEventListener("pointerenter", Pe), ne.removeEventListener("pointermove", Ee), ne.removeEventListener("pointerleave", Ce), ne.removeEventListener("pointercancel", Ce), ne.removeEventListener("pointerdown", zt)
            }
        }, Ge = [s, Le, ae, ie], e[34] = Le, e[35] = s, e[36] = ae, e[37] = ie, e[38] = _e, e[39] = Ge) : (_e = e[38], Ge = e[39]), x.useEffect(_e, Ge);
        let ze, Ve;
        e[40] !== Le || e[41] !== ie ? (ze = () => {
            if (!ie) return;
            const ne = le => {
                le.key === "Escape" && Le()
            };
            return window.addEventListener("keydown", ne), () => window.removeEventListener("keydown", ne)
        }, Ve = [Le, ie], e[40] = Le, e[41] = ie, e[42] = ze, e[43] = Ve) : (ze = e[42], Ve = e[43]), x.useEffect(ze, Ve);
        let De, tt;
        e[44] !== s || e[45] !== fe || e[46] !== K ? (De = () => {
            const ne = s.current;
            if (!ne) return;
            const le = () => {
                    $(!0), fe && K()
                },
                Pe = Ee => {
                    const Ce = Ee.relatedTarget;
                    Ce instanceof Node && ne.contains(Ce) || ($(!1), I(null))
                };
            return ne.addEventListener("focusin", le), ne.addEventListener("focusout", Pe), () => {
                ne.removeEventListener("focusin", le), ne.removeEventListener("focusout", Pe)
            }
        }, tt = [s, fe, K], e[44] = s, e[45] = fe, e[46] = K, e[47] = De, e[48] = tt) : (De = e[47], tt = e[48]), x.useEffect(De, tt);
        let mt, vt;
        e[49] !== fe || e[50] !== K ? (mt = () => {
            if (fe) return queueMicrotask(() => {
                K()
            }), document.addEventListener("selectionchange", K), window.addEventListener("resize", K), document.addEventListener("scroll", K, !0), () => {
                document.removeEventListener("selectionchange", K), window.removeEventListener("resize", K), document.removeEventListener("scroll", K, !0)
            }
        }, vt = [fe, K], e[49] = fe, e[50] = K, e[51] = mt, e[52] = vt) : (mt = e[51], vt = e[52]), x.useEffect(mt, vt);
        let kt, Je;
        e[53] !== Ct || e[54] !== o || e[55] !== fe ? (kt = () => {
            if (!fe) {
                S.current = o;
                return
            }
            o !== S.current && (S.current = o, queueMicrotask(() => {
                Ct()
            }))
        }, Je = [Ct, o, fe], e[53] = Ct, e[54] = o, e[55] = fe, e[56] = kt, e[57] = Je) : (kt = e[56], Je = e[57]), x.useEffect(kt, Je);
        let He, Ke;
        e[58] !== Ct || e[59] !== fe || e[60] !== r ? (He = () => {
            fe && (r || queueMicrotask(() => {
                Ct()
            }))
        }, Ke = [Ct, fe, r], e[58] = Ct, e[59] = fe, e[60] = r, e[61] = He, e[62] = Ke) : (He = e[61], Ke = e[62]), x.useEffect(He, Ke);
        let dt, ut;
        e[63] !== s || e[64] !== ee ? (dt = () => {
            const ne = s.current;
            if (!ne || !ee) return;
            const le = R6;
            return ne.addEventListener("pointerdown", le), () => {
                ne.removeEventListener("pointerdown", le)
            }
        }, ut = [s, ee], e[63] = s, e[64] = ee, e[65] = dt, e[66] = ut) : (dt = e[65], ut = e[66]), x.useEffect(dt, ut);
        let Oe, Be;
        e[67] !== _t || e[68] !== f ? (Oe = () => {
            if (f === V.current || f === 0) {
                V.current = f;
                return
            }
            V.current = f, queueMicrotask(() => {
                _t()
            })
        }, Be = [_t, f], e[67] = _t, e[68] = f, e[69] = Oe, e[70] = Be) : (Oe = e[69], Be = e[70]), x.useEffect(Oe, Be);
        let st, ht;
        e[71] !== c || e[72] !== ge ? (st = () => {
            c == null || c(ge)
        }, ht = [c, ge], e[71] = c, e[72] = ge, e[73] = st, e[74] = ht) : (st = e[73], ht = e[74]), x.useEffect(st, ht);
        let St;
        e[75] !== D.clientThreadId || e[76] !== D.messageId || e[77] !== D.variant || e[78] !== D.writingBlockId || e[79] !== P ? (St = () => {
            if (q.current || !P) return;
            const ne = J.current;
            Xe.logStructuredEvent(Dm, {
                conversationId: D.clientThreadId,
                messageId: D.messageId,
                writingBlockId: D.writingBlockId,
                variant: D.variant,
                sessionLoggingId: ne || void 0
            }), Ot.count(Ft.WRITING_BLOCKS, "chatgpt_writing_block_inline_edit_nux_completed"), q.current = !0
        }, e[75] = D.clientThreadId, e[76] = D.messageId, e[77] = D.variant, e[78] = D.writingBlockId, e[79] = P, e[80] = St) : St = e[80];
        let Tt;
        e[81] !== D || e[82] !== P ? (Tt = [D, P], e[81] = D, e[82] = P, e[83] = Tt) : Tt = e[83], x.useEffect(St, Tt);
        let bt;
        e[84] !== m ? (bt = m.formatMessage({
            id: "sN5Jyl",
            defaultMessage: "Click to edit"
        }), e[84] = m, e[85] = bt) : bt = e[85];
        const We = bt;
        let Et;
        e[86] !== m ? (Et = m.formatMessage({
            id: "z5OrYQ",
            defaultMessage: "Start typing or select text to ask for changes"
        }), e[86] = m, e[87] = Et) : Et = e[87];
        const $t = Et;
        let nt;
        e: {
            if (!je || !M) {
                nt = null;
                break e
            }
            let ne;e[88] !== m ? (ne = m.formatMessage({
                id: "HJxwKm",
                defaultMessage: "New!"
            }), e[88] = m, e[89] = ne) : ne = e[89];
            let le;e[90] !== ne ? (le = a.jsx("span", {
                className: "text-white/75",
                children: ne
            }), e[90] = ne, e[91] = le) : le = e[91];
            let Pe;e[92] !== We ? (Pe = a.jsx("span", {
                children: We
            }), e[92] = We, e[93] = Pe) : Pe = e[93];
            let Ee;e[94] !== le || e[95] !== Pe ? (Ee = a.jsxs(a.Fragment, {
                children: [le, Pe]
            }), e[94] = le, e[95] = Pe, e[96] = Ee) : Ee = e[96];
            let Ce;e[97] !== M || e[98] !== Ee ? (Ce = {
                key: "writing-inline-edit-nux",
                position: M,
                message: Ee
            }, e[97] = M, e[98] = Ee, e[99] = Ce) : Ce = e[99],
            nt = Ce
        }
        const Dt = nt;
        let jt;
        e: {
            if (!Te || !N) {
                jt = null;
                break e
            }
            const ne = lt ? "writing-inline-edit-nux" : "writing-inline-edit-nux-caret";
            let le;e[100] !== $t || e[101] !== N || e[102] !== ne ? (le = {
                key: ne,
                position: N,
                message: $t
            }, e[100] = $t, e[101] = N, e[102] = ne, e[103] = le) : le = e[103],
            jt = le
        }
        const At = jt,
            qt = Dt != null ? Dt : At;
        if (y) return null;
        let qe;
        e[104] !== qt || e[105] !== Te ? (qe = qt && a.jsx(N6, {
            position: qt.position,
            message: qt.message,
            interactive: Te,
            anchor: qt.anchor
        }, qt.key), e[104] = qt, e[105] = Te, e[106] = qe) : qe = e[106];
        let Zt;
        return e[107] !== qe ? (Zt = a.jsx(wi, {
            children: qe
        }), e[107] = qe, e[108] = Zt) : Zt = e[108], Zt
    },
    N6 = t => {
        "use forget";
        const e = xe.c(36),
            {
                position: s,
                message: n,
                interactive: o,
                anchor: r
            } = t,
            i = o === void 0 ? !1 : o,
            l = r === void 0 ? "top-left" : r,
            c = x.useRef(null);
        let d;
        e[0] === Symbol.for("react.memo_cache_sentinel") ? (d = {
            width: 0,
            height: 0
        }, e[0] = d) : d = e[0];
        const [u, f] = x.useState(d), h = Da(s.x), m = Da(s.y);
        let b;
        e[1] === Symbol.for("react.memo_cache_sentinel") ? (b = {
            stiffness: 160,
            damping: 20,
            mass: .6
        }, e[1] = b) : b = e[1];
        const y = Oa(h, b);
        let p;
        e[2] === Symbol.for("react.memo_cache_sentinel") ? (p = {
            stiffness: 160,
            damping: 20,
            mass: .6
        }, e[2] = p) : p = e[2];
        const w = Oa(m, p);
        let C;
        e[3] === Symbol.for("react.memo_cache_sentinel") ? (C = () => {
            const G = c.current;
            if (!G) {
                f({
                    width: 0,
                    height: 0
                });
                return
            }
            const O = () => {
                const S = G.getBoundingClientRect();
                f({
                    width: S.width,
                    height: S.height
                })
            };
            if (O(), typeof ResizeObserver > "u") return;
            const H = new ResizeObserver(() => {
                O()
            });
            return H.observe(G), () => {
                H.disconnect()
            }
        }, e[3] = C) : C = e[3];
        let v;
        e[4] !== n ? (v = [n], e[4] = n, e[5] = v) : v = e[5], un(C, v);
        let g = s.x,
            k = s.y;
        (l === "top-center" || l === "bottom-center") && (g = g - u.width / 2), l === "bottom-center" && (k = k - u.height);
        let E;
        e[6] !== g || e[7] !== k ? (E = {
            x: g,
            y: k
        }, e[6] = g, e[7] = k, e[8] = E) : E = e[8];
        const j = E;
        let M, T;
        e[9] !== j.x || e[10] !== j.y || e[11] !== y || e[12] !== w || e[13] !== h || e[14] !== m ? (T = () => {
            y.set(j.x), w.set(j.y), h.set(j.x), m.set(j.y)
        }, M = [j.x, j.y, y, w, h, m], e[9] = j.x, e[10] = j.y, e[11] = y, e[12] = w, e[13] = h, e[14] = m, e[15] = M, e[16] = T) : (M = e[15], T = e[16]), un(T, M);
        let N, I;
        e[17] !== j.x || e[18] !== j.y || e[19] !== h || e[20] !== m ? (N = () => {
            h.set(j.x), m.set(j.y)
        }, I = [j.x, j.y, h, m], e[17] = j.x, e[18] = j.y, e[19] = h, e[20] = m, e[21] = N, e[22] = I) : (N = e[21], I = e[22]), x.useEffect(N, I);
        let _, R, A, $;
        e[23] === Symbol.for("react.memo_cache_sentinel") ? (_ = {
            opacity: 0,
            scale: .95
        }, R = {
            opacity: 1,
            scale: 1
        }, A = {
            opacity: 0,
            scale: .95
        }, $ = {
            type: "spring",
            stiffness: 500,
            damping: 45,
            mass: .5
        }, e[23] = _, e[24] = R, e[25] = A, e[26] = $) : (_ = e[23], R = e[24], A = e[25], $ = e[26]);
        let P;
        e[27] !== y || e[28] !== w ? (P = {
            x: y,
            y: w
        }, e[27] = y, e[28] = w, e[29] = P) : P = e[29];
        const U = (i ? "pointer-events-auto " : "pointer-events-none ") + "flex items-center gap-1 rounded-lg bg-blue-400 px-2 py-1 text-xs font-semibold text-white shadow-[0_4px_12px_rgba(0,0,0,0.16)] dark:shadow-[0_4px_12px_rgba(0,0,0,0.4)]";
        let z;
        e[30] !== n || e[31] !== U ? (z = a.jsx("div", {
            className: U,
            "data-testid": "writing-inline-edit-nux",
            children: n
        }), e[30] = n, e[31] = U, e[32] = z) : z = e[32];
        let B;
        return e[33] !== P || e[34] !== z ? (B = a.jsx(On.div, {
            className: "pointer-events-none fixed z-30",
            initial: _,
            animate: R,
            exit: A,
            transition: $,
            style: P,
            ref: c,
            children: z
        }), e[33] = P, e[34] = z, e[35] = B) : B = e[35], B
    };

function P6() {
    return tf()
}

function R6() {
    tf.set(!1)
}

function $6(t) {
    "use forget";
    const e = xe.c(48),
        {
            disabled: s,
            editorView: n,
            isMagicEditLoading: o,
            submitMagicEdit: r,
            cancelMagicEdit: i,
            applyMagicEditResult: l,
            magicEditSubmissionSource: c
        } = t,
        d = s === void 0 ? !1 : s,
        u = Ne(),
        [f, h] = x.useState(""),
        m = x.useRef(null),
        b = x.useRef(!1);
    let y;
    e[0] !== l || e[1] !== d || e[2] !== n.state.doc.content.size || e[3] !== f || e[4] !== r ? (y = async D => {
        var K;
        if (d) return;
        b.current = !1, D == null || D.preventDefault(), D == null || D.stopPropagation();
        const te = {
                from: 0,
                to: n.state.doc.content.size
            },
            se = f.trim();
        if (!se) return;
        const re = await r({
            instruction: se,
            range: te,
            submissionSource: Gn.FULLSCREEN_COMPOSER
        });
        if (!re || b.current) return;
        const X = (K = re.replacements[0]) != null ? K : "";
        l({
            magicEditId: re.magicEditId,
            replacement: X,
            range: te
        }) && h("")
    }, e[0] = l, e[1] = d, e[2] = n.state.doc.content.size, e[3] = f, e[4] = r, e[5] = y) : y = e[5];
    const p = y,
        [w, C] = x.useState(null);
    let v, g;
    e[6] !== w ? (v = () => {
        if (m.current && w == null) {
            const D = parseFloat(getComputedStyle(m.current).lineHeight);
            C(D)
        }
    }, g = [w], e[6] = w, e[7] = v, e[8] = g) : (v = e[7], g = e[8]), x.useEffect(v, g);
    const [k, E] = x.useState(1), [j, M] = x.useState(!1);
    let T, N;
    e[9] !== j || e[10] !== w || e[11] !== f || e[12] !== k ? (T = () => {
        const D = m.current;
        if (!D || w == null) return;
        D.style.height = "auto";
        const te = D.scrollHeight;
        D.style.height = "".concat(te, "px");
        const se = Math.max(1, Math.floor(te / w));
        if (k !== se && E(se), se > 1) {
            j || M(!0);
            return
        }
        j && f.length === 0 && M(!1)
    }, N = [f, w, j, k], e[9] = j, e[10] = w, e[11] = f, e[12] = k, e[13] = T, e[14] = N) : (T = e[13], N = e[14]), un(T, N);
    let I;
    e[15] !== i ? (I = () => {
        b.current = !0, i()
    }, e[15] = i, e[16] = I) : I = e[16];
    const _ = I;
    let R;
    e[17] !== d || e[18] !== p ? (R = D => {
        if (D.key === "Enter" && !D.shiftKey && !D.nativeEvent.isComposing) {
            if (D.preventDefault(), d) {
                D.stopPropagation();
                return
            }
            p(D)
        }
    }, e[17] = d, e[18] = p, e[19] = R) : R = e[19];
    const A = R,
        $ = k > 1 || j,
        P = $ ? "flex-wrap items-stretch" : "flex-nowrap items-center gap-2";
    let U;
    e[20] !== P ? (U = W("bg-token-bg-primary shadow-short fixed start-1/2 z-20 flex h-auto w-[min(90vw,40rem)] -translate-x-1/2 transform items-center rounded-[28px] dark:dark:bg-[#303030] dark:shadow-[0px_4px_12px_0px_var(--shadow-color-1,rgba(0,_0,_0,_0.24)),inset_0px_0px_1px_0px_var(--shadow-color-2,rgba(255,_255,_255,_0.3))]", "bottom-6 py-2 ps-3 pe-2.5 sm:bottom-8", P), e[20] = P, e[21] = U) : U = e[21];
    let z;
    e[22] === Symbol.for("react.memo_cache_sentinel") ? (z = D => h(D.target.value), e[22] = z) : z = e[22];
    let B;
    e[23] !== u ? (B = u.formatMessage({
        id: "o/23xf",
        defaultMessage: "Describe edits"
    }), e[23] = u, e[24] = B) : B = e[24];
    const G = $ ? "w-full" : "min-w-0 flex-1";
    let O;
    e[25] !== G ? (O = W("text-token-text-primary placeholder:text-token-text-tertiary resize-none overflow-hidden border-none bg-transparent py-1 outline-none focus:border-transparent focus:ring-0 focus:outline-none", G), e[25] = G, e[26] = O) : O = e[26];
    let H;
    e[27] !== A || e[28] !== f || e[29] !== B || e[30] !== O ? (H = a.jsx("textarea", {
        value: f,
        rows: 1,
        onChange: z,
        onKeyDown: A,
        placeholder: B,
        ref: m,
        className: O
    }), e[27] = A, e[28] = f, e[29] = B, e[30] = O, e[31] = H) : H = e[31];
    const S = $ ? "w-full justify-end" : "justify-center";
    let V;
    e[32] !== S ? (V = W("flex flex-shrink-0", S), e[32] = S, e[33] = V) : V = e[33];
    let J;
    e[34] !== d || e[35] !== _ || e[36] !== p || e[37] !== o || e[38] !== f || e[39] !== c ? (J = c === Gn.FULLSCREEN_COMPOSER && o ? a.jsx(Zu, {
        size: 36,
        onClick: _
    }) : a.jsx("button", {
        onClick: p,
        disabled: f.trim().length === 0 || d,
        id: "writing-block-fullscreen-composer-submit-button",
        className: W("composer-submit-btn", "composer-submit-button-color", "flex", "h-9", "w-9", "items-center", "justify-center"),
        children: a.jsx(Gi, {
            className: "icon"
        })
    }), e[34] = d, e[35] = _, e[36] = p, e[37] = o, e[38] = f, e[39] = c, e[40] = J) : J = e[40];
    let q;
    e[41] !== V || e[42] !== J ? (q = a.jsx("div", {
        className: V,
        children: J
    }), e[41] = V, e[42] = J, e[43] = q) : q = e[43];
    let Z;
    return e[44] !== U || e[45] !== H || e[46] !== q ? (Z = a.jsxs("div", {
        className: U,
        children: [H, q]
    }), e[44] = U, e[45] = H, e[46] = q, e[47] = Z) : Z = e[47], Z
}
const A6 = new ws({
        props: {
            decorations(t) {
                const {
                    doc: e,
                    selection: s
                } = t;
                if (s.empty) return as.empty;
                const {
                    from: n,
                    to: o
                } = s, r = [];
                return e.nodesBetween(n, o, (i, l) => {
                    if (!i.isBlock || i.type.name !== "paragraph") return;
                    const c = l + i.nodeSize - 1;
                    o > c && n <= c && r.push(ln.node(l, l + i.nodeSize, {
                        class: "isSelectedEnd"
                    }))
                }), as.create(e, r)
            }
        }
    }),
    L6 = ({
        view: t,
        pmu: e,
        prompt: s,
        input: n,
        conversationId: o
    }) => {
        const {
            anchorPos: r,
            caretPos: i,
            triggerPos: l
        } = n, c = {
            from: Math.min(l, r, i),
            to: Math.max(r, i)
        }, d = Lu({
            view: t,
            pmu: e,
            range: c
        }), u = Vu(d.fullMarkdown, d.startIndex, d.endIndex);
        return {
            conversation_id: o,
            full_block_body_markdown: d.fullMarkdown,
            start_index: d.startIndex,
            end_index: d.endIndex,
            marked_block_body_markdown: u,
            instruction: s,
            num_variations: 1,
            mode: "generate"
        }
    };

function D6(t) {
    "use forget";
    const e = xe.c(13),
        {
            view: s,
            pmu: n
        } = t,
        o = ys(),
        r = Ne(),
        i = x.useRef(!1),
        l = Sr();
    let c;
    e[0] !== l ? (c = () => l == null ? void 0 : l.serverId$(), e[0] = l, e[1] = c) : c = e[1];
    const d = Rt(c),
        {
            mutateAsync: u,
            isPending: f
        } = Ku();
    let h;
    e[2] !== d || e[3] !== u || e[4] !== r || e[5] !== n || e[6] !== o || e[7] !== s ? (h = async w => {
        var k;
        if (!s || !n) return !1;
        i.current = !1;
        const C = w.trim();
        if (C === "") return !1;
        const v = Xt.getState(s.state);
        if (!(v != null && v.input)) return !1;
        let g;
        try {
            g = L6({
                view: s,
                pmu: n,
                prompt: C,
                input: v.input,
                conversationId: d
            })
        } catch (E) {
            const j = r.formatMessage({
                id: "afsmrO",
                defaultMessage: "Unable to prepare generate request."
            });
            return o.danger(j, {
                duration: 2
            }), !1
        }
        try {
            const E = await u({
                payload: g
            });
            if (i.current) return !1;
            let j = "";
            const M = E.choices;
            if (Array.isArray(M)) {
                const I = M[0];
                if (typeof I == "string") j = I;
                else if (I != null) {
                    if (typeof I == "object") {
                        const _ = I;
                        if ("text" in _) {
                            const R = _.text;
                            typeof R == "string" && (j = R)
                        }
                    }
                }
            }
            const T = crypto.randomUUID();
            if (!Kj({
                    view: s,
                    pmu: n,
                    suggestionId: T,
                    text: j
                })) {
                const I = r.formatMessage({
                    id: "FckTpR",
                    defaultMessage: "Unable to insert generated text."
                });
                return o.danger(I, {
                    duration: 2
                }), !1
            }
            return !0
        } catch (E) {
            const j = E;
            if (!i.current) {
                const M = (k = Zo(j)) != null ? k : r.formatMessage({
                    id: "6QyguR",
                    defaultMessage: "An error occurred while generating text."
                });
                o.danger(M, {
                    duration: 2
                })
            }
            return !1
        }
    }, e[2] = d, e[3] = u, e[4] = r, e[5] = n, e[6] = o, e[7] = s, e[8] = h) : h = e[8];
    const m = h;
    let b;
    e[9] === Symbol.for("react.memo_cache_sentinel") ? (b = () => {
        i.current = !0
    }, e[9] = b) : b = e[9];
    const y = b;
    let p;
    return e[10] !== f || e[11] !== m ? (p = {
        isLoading: f,
        submitGenerate: m,
        cancelGenerate: y
    }, e[10] = f, e[11] = m, e[12] = p) : p = e[12], p
}
const O6 = (t, e) => {
        if (t === e) return !0;
        if (!t || !e) return t === e;
        const s = t.input,
            n = e.input,
            o = !s && !n || s != null && n != null && s.anchorPos === n.anchorPos && s.caretPos === n.caretPos && s.blockFrom === n.blockFrom && s.blockTo === n.blockTo && s.triggerPos === n.triggerPos,
            r = t.suggestion,
            i = e.suggestion,
            l = !r && !i || r != null && i != null && r.id === i.id && r.from === i.from && r.to === i.to;
        return o && l && t.lastResolvedSuggestionId === e.lastResolvedSuggestionId && t.lastResolvedReason === e.lastResolvedReason
    },
    F6 = (t, e) => t === e ? !0 : t.triggerPos !== e.triggerPos || t.anchorPos !== e.anchorPos || t.query !== e.query || t.normalizedQuery !== e.normalizedQuery || t.highlightedOptionId !== e.highlightedOptionId || t.visibleOptionIds.length !== e.visibleOptionIds.length ? !1 : t.visibleOptionIds.every((s, n) => s === e.visibleOptionIds[n]),
    jc = (t, e) => t === e ? !0 : !t || !e ? t === e : t.pos === e.pos && t.nodeSize === e.nodeSize,
    Mc = (t, e) => t === e ? !0 : !t || !e ? t === e : t.from === e.from && t.to === e.to,
    B6 = (t, e) => t === e ? !0 : !t || !e ? t === e : t.index === e.index && jc(t.original, e.original) && jc(t.suggested, e.suggested) && Mc(t.originalHighlight, e.originalHighlight) && Mc(t.suggestedHighlight, e.suggestedHighlight) && t.selectionStartOffset === e.selectionStartOffset && t.selectionEndOffset === e.selectionEndOffset,
    W6 = (t, e) => {
        if (t === e) return !0;
        if (!t || !e) return t === e;
        if (t.id !== e.id || t.from !== e.from || t.to !== e.to || t.segments.length !== e.segments.length) return !1;
        for (let s = 0; s < t.segments.length; s++)
            if (!B6(t.segments[s], e.segments[s])) return !1;
        return !0
    },
    z6 = t => {
        if (!t || t.entries.size === 0) return null;
        const e = t.entries.values().next().value;
        return e != null ? e : null
    },
    H6 = {
        editorView: null,
        slashMenuState: dn,
        generatePluginState: null,
        activeMagicEditEntry: null,
        selectionSummary: {
            isCollapsed: !0
        },
        docChangeCount: 0
    },
    U6 = (t, e) => t.editorView === e.editorView && F6(t.slashMenuState, e.slashMenuState) && O6(t.generatePluginState, e.generatePluginState) && W6(t.activeMagicEditEntry, e.activeMagicEditEntry) && t.selectionSummary.isCollapsed === e.selectionSummary.isCollapsed && t.docChangeCount === e.docChangeCount,
    G6 = () => {
        let t = H6;
        const e = new Set,
            s = () => {
                e.forEach(o => o())
            },
            n = o => {
                const r = F(F({}, t), o);
                U6(t, r) || (t = r, s())
            };
        return {
            getSnapshot: () => t,
            subscribe: o => (e.add(o), () => {
                e.delete(o)
            }),
            setView: o => {
                if (!o) {
                    n({
                        editorView: null,
                        slashMenuState: dn,
                        generatePluginState: null,
                        activeMagicEditEntry: null,
                        selectionSummary: {
                            isCollapsed: !0
                        },
                        docChangeCount: 0
                    });
                    return
                }
                n({
                    editorView: o
                })
            },
            syncFromState: (o, r, i) => {
                var m, b;
                const l = (m = Gt.getState(o)) != null ? m : dn,
                    c = (b = Xt.getState(o)) != null ? b : null,
                    d = r.isMagicEditEnabled ? Yt.getState(o) : null,
                    u = r.isMagicEditEnabled ? z6(d) : null,
                    f = {
                        isCollapsed: o.selection.empty
                    },
                    h = i != null && i.docChanged ? 1 : 0;
                n({
                    slashMenuState: l,
                    generatePluginState: c,
                    activeMagicEditEntry: u,
                    selectionSummary: f,
                    docChangeCount: t.docChangeCount + h
                })
            }
        }
    },
    q6 = t => {
        "use forget";
        return x.useSyncExternalStore(t.subscribe, t.getSnapshot, t.getSnapshot)
    },
    V6 = 2e4,
    K6 = t => typeof t == "object" && t != null,
    X6 = t => {
        if (!K6(t) || typeof t.type != "string") return !1;
        switch (t.type) {
            case "open":
                return typeof t.triggerPos == "number" && typeof t.anchorPos == "number";
            case "close":
                return !0;
            case "navigate":
                return t.direction === "previous" || t.direction === "next";
            case "highlight":
                return typeof t.commandId == "string" || t.commandId == null;
            case "execute":
                return typeof t.commandId == "string";
            default:
                return !1
        }
    },
    ks = (t, e) => typeof t == "number" && Number.isFinite(t) ? t : e,
    bi = {
        accept: {
            applyAction: "use",
            eventName: "ChatGPT Writing Block Magic Edit Accepted",
            eventType: "chatgpt_writing_block_magic_edit_accepted"
        },
        reject: {
            applyAction: "keep",
            eventName: "ChatGPT Writing Block Magic Edit Rejected",
            eventType: "chatgpt_writing_block_magic_edit_rejected"
        }
    },
    Y6 = Qc["Mod-a"],
    Z6 = (t, e, s) => {
        const {
            doc: n
        } = t, o = it.findFrom(n.resolve(0), 1, !0), r = it.findFrom(n.resolve(n.content.size), -1, !0);
        if (o && r) {
            const i = fn.create(n, Math.min(o.from, r.to), Math.max(o.from, r.to));
            return e && e(t.tr.setSelection(i)), !0
        }
        return Y6(t, e, s)
    };

function Cc(t, e, s, n) {
    var i;
    const o = ks(t.startIndex$(), -1),
        r = ks(t.endIndex$(), -1);
    return {
        writing_block_id: e.blockId,
        magic_edit_id: s,
        freeform_feedback: t.freeformFeedback$(),
        full_block_body_markdown: t.fullBlockBodyMarkdown$(),
        start_index: ks(n == null ? void 0 : n.startIndex, o),
        end_index: ks(n == null ? void 0 : n.endIndex, r),
        suggested_content: (i = n == null ? void 0 : n.suggestedContent) != null ? i : t.replacements$()[0]
    }
}

function J6(t, e, s) {
    var C, v;
    const {
        schema: n
    } = t.state, o = n.nodes.horizontal_rule, r = n.nodes.paragraph;
    if (!o) return !1;
    let i = t.state.tr;
    const l = Math.max(s != null ? s : e + 1, e + 1);
    i = i.delete(e, l);
    const c = i.mapping.map(e, -1),
        d = i.doc.childBefore(c + 1),
        u = d.node,
        f = d.offset;
    if (r && (u == null ? void 0 : u.type) === r && u.isTextblock && (u == null ? void 0 : u.content.size) === 0) {
        const g = o.create(),
            k = f + u.nodeSize;
        i = i.replaceRangeWith(f, k, g);
        const E = f + g.nodeSize,
            j = i.doc.childAfter(E);
        if (!!r && !j.node && r) {
            const N = r.create();
            i = i.insert(E, Wt.from(N));
            const I = (C = it.findFrom(i.doc.resolve(E + 1), 1, !0)) != null ? C : it.near(i.doc.resolve(E + 1), 1);
            return t.dispatch(i.setSelection(I).scrollIntoView()), !0
        }
        const T = j != null && j.node ? it.near(i.doc.resolve(j.offset + 1), 1) : it.near(i.doc.resolve(E), 1);
        return t.dispatch(i.setSelection(T).scrollIntoView()), !0
    }
    const m = o.create();
    i = i.insert(c, Wt.from(m));
    const b = c + m.nodeSize,
        y = i.doc.childAfter(b);
    if (!!r && !y.node && r) {
        const g = r.create(),
            k = b;
        i = i.insert(k, Wt.from(g));
        const E = (v = it.findFrom(i.doc.resolve(k + 1), 1, !0)) != null ? v : it.near(i.doc.resolve(k + 1), 1);
        return t.dispatch(i.setSelection(E).scrollIntoView()), !0
    }
    const w = y != null && y.node ? it.near(i.doc.resolve(y.offset + 1), 1) : it.near(i.doc.resolve(b), 1);
    return t.dispatch(i.setSelection(w).scrollIntoView()), !0
}

function Q6(t) {
    "use forget";
    const e = xe.c(2);
    let s;
    return e[0] !== t ? (s = tM({
        shouldStripDirectives: !0,
        contentReferences: t
    }), e[0] = t, e[1] = s) : s = e[1], s
}
const va = t => {
    "use forget";
    var ka, Sa, Ea, ja, Ma;
    const e = xe.c(252),
        {
            analyticsMetadata: s,
            markdown: n,
            variant: o,
            onChange: r,
            isDisabled: i,
            isInlineWritingBlockEditEnabled: l,
            className: c,
            maxLength: d,
            contentReferences: u,
            setDirty: f,
            flushPendingChanges: h,
            editorViewRef: m,
            fullscreenMode: b,
            disableOnChangeDebounce: y,
            showBottomComposer: p,
            isStreaming: w,
            styleOverrides: C,
            children: v
        } = t,
        g = d === void 0 ? V6 : d,
        k = b === void 0 ? !1 : b,
        E = y === void 0 ? !1 : y,
        j = p === void 0 ? !0 : p,
        M = w === void 0 ? !1 : w;
    let T;
    e[0] !== C ? (T = C === void 0 ? {} : C, e[0] = C, e[1] = T) : T = e[1];
    const N = T,
        I = et(),
        _ = Rt(Wi),
        R = Rt(an);
    let A;
    e[2] === Symbol.for("react.memo_cache_sentinel") ? (A = qc() || Bi(), e[2] = A) : A = e[2];
    const $ = A,
        P = Ne();
    let U;
    e[3] !== P ? (U = $ ? P.formatMessage({
        id: "M13+fz",
        defaultMessage: "Write something..."
    }) : P.formatMessage({
        id: "n70ZZB",
        defaultMessage: "Write or type ‘/’ for commands..."
    }), e[3] = P, e[4] = U) : U = e[4];
    const z = U,
        B = x.useRef(z),
        G = Fn(Bn.MagicEditEnabled);
    let O;
    e[5] !== I ? (O = at(I, "2459982630"), e[5] = I, e[6] = O) : O = e[6];
    const S = G || O;
    let V;
    e[7] !== I ? (V = at(I, "3539089402"), e[7] = I, e[8] = V) : V = e[8];
    const q = V && !$;
    let Z;
    e[9] !== I ? (Z = at(I, "1629932585"), e[9] = I, e[10] = Z) : Z = e[10];
    const D = !1;
    let te;
    e[11] !== u || e[12] !== M ? (te = M ? [] : u, e[11] = u, e[12] = M, e[13] = te) : te = e[13];
    const se = Q6(te),
        re = tC;
    let X;
    e[14] !== s || e[15] !== I ? (X = (Y, ue, be, Fe, xt) => {
        const gt = Fe.modelSlug$(),
            yt = Cc(Fe, s, ue, {
                startIndex: be.startIndex,
                endIndex: be.endIndex,
                suggestedContent: be.suggestedMarkdown
            });
        Ua(Y, yt, s.clientThreadId, s.messageId, gt, I);
        const It = {
            conversationId: s.clientThreadId,
            messageId: s.messageId,
            magicEditId: ue,
            decisionSource: xt,
            magicEditSegmentIndex: be.index,
            magicEditSegmentStartIndex: be.startIndex,
            magicEditSegmentEndIndex: be.endIndex,
            modelSlug: gt != null ? gt : void 0
        };
        Y === "accept" ? Xe.logStructuredEvent(Fa, It) : Xe.logStructuredEvent(Ba, It), Ot.count(Ft.WRITING_BLOCKS, bi[Y].eventType)
    }, e[14] = s, e[15] = I, e[16] = X) : X = e[16];
    const he = X,
        K = x.useRef(null),
        oe = x.useRef(null),
        ye = x.useRef(null);
    let ke;
    e[17] === Symbol.for("react.memo_cache_sentinel") ? (ke = G6(), e[17] = ke) : ke = e[17];
    const ie = ke,
        {
            editorView: ee,
            slashMenuState: fe,
            generatePluginState: Se,
            activeMagicEditEntry: je,
            selectionSummary: Te,
            docChangeCount: Ye
        } = q6(ie),
        ge = (ka = je == null ? void 0 : je.id) != null ? ka : null,
        [lt, Ze] = x.useState(""),
        [pe, de] = x.useState(!1),
        [Me, we] = x.useState(0),
        [$e, Ue] = x.useState(!1);
    let Ae;
    e[18] === Symbol.for("react.memo_cache_sentinel") ? (Ae = () => {
        we(sC)
    }, e[18] = Ae) : Ae = e[18];
    const pt = Ae,
        Le = Yi(r, 300);
    let ct;
    e[19] !== r ? (ct = Y => {
        r(Y)
    }, e[19] = r, e[20] = ct) : ct = e[20];
    const ft = E ? ct : Le,
        _t = x.useRef(ft),
        Q = x.useRef(f),
        ae = x.useRef(h);
    let _e;
    e[21] === Symbol.for("react.memo_cache_sentinel") ? (_e = {
        placement: "bottom-start",
        middleware: [Kc(8), Xc({
            fallbackPlacements: ["top-start"]
        }), Yc({
            padding: 8
        })],
        whileElementsMounted: (Y, ue, be) => {
            var Fe;
            return Jc((Fe = K.current) != null ? Fe : Y, ue, be, {
                ancestorResize: !0,
                ancestorScroll: !0
            })
        }
    }, e[21] = _e) : _e = e[21];
    const {
        refs: Ge,
        floatingStyles: ze,
        update: Ve
    } = Zc(_e), De = Ge.setReference, tt = Ge.setFloating, mt = x.useRef(null);
    let vt;
    e[22] !== m || e[23] !== De || e[24] !== Ve ? (vt = (Y, ue) => {
        var xt;
        const be = m.current;
        if (!be || Y == null) {
            ue.current = null, De(null);
            return
        }
        const Fe = {
            contextElement: (xt = K.current) != null ? xt : void 0,
            getBoundingClientRect: () => {
                try {
                    const gt = be.coordsAtPos(Y);
                    return new DOMRect(gt.left, gt.bottom, 0, 0)
                } catch (gt) {
                    return new DOMRect
                }
            }
        };
        ue.current = Fe, De(Fe), Ve()
    }, e[22] = m, e[23] = De, e[24] = Ve, e[25] = vt) : vt = e[25];
    const kt = vt;
    let Je;
    e[26] !== c ? (Je = W("markdown", "prose", "dark:prose-invert", "w-full", "min-h-6", "break-words", "focus:outline-none", c), e[26] = c, e[27] = Je) : Je = e[27];
    const He = Je;
    let Ke;
    e[28] !== He || e[29] !== i || e[30] !== n || e[31] !== g ? (Ke = {
        markdown: n,
        maxLength: g,
        isDisabled: i,
        editorClassName: He
    }, e[28] = He, e[29] = i, e[30] = n, e[31] = g, e[32] = Ke) : Ke = e[32];
    const dt = x.useRef(Ke),
        ut = x.useRef(n);
    let Oe;
    e[33] !== ee || e[34] !== se ? (Oe = {
        view: ee,
        pmu: se
    }, e[33] = ee, e[34] = se, e[35] = Oe) : Oe = e[35];
    const {
        isLoading: Be,
        submitMagicEdit: st,
        cancelMagicEdit: ht,
        applyMagicEditResult: St,
        magicEditSubmissionSource: Tt
    } = xc(Oe);
    let bt;
    e[36] !== ee || e[37] !== se ? (bt = {
        view: ee,
        pmu: se,
        mode: "full-edit"
    }, e[36] = ee, e[37] = se, e[38] = bt) : bt = e[38];
    const {
        isLoading: We,
        submitMagicEdit: Et,
        cancelMagicEdit: $t,
        applyMagicEditResult: nt,
        magicEditSubmissionSource: Dt
    } = xc(bt);
    let jt;
    e[39] !== ee || e[40] !== se ? (jt = {
        view: ee,
        pmu: se
    }, e[39] = ee, e[40] = se, e[41] = jt) : jt = e[41];
    const {
        isLoading: At,
        submitGenerate: qt,
        cancelGenerate: qe
    } = D6(jt);
    let Zt, ne;
    e[42] !== I || e[43] !== We || e[44] !== At || e[45] !== Be ? (Zt = () => (Zl(I, At || Be || We), () => {
        Zl(I, !1)
    }), ne = [At, Be, We, I], e[42] = I, e[43] = We, e[44] = At, e[45] = Be, e[46] = Zt, e[47] = ne) : (Zt = e[46], ne = e[47]), x.useEffect(Zt, ne);
    const le = (Sa = Se == null ? void 0 : Se.input) != null ? Sa : null,
        Pe = le != null,
        Ee = (ja = (Ea = Se == null ? void 0 : Se.suggestion) == null ? void 0 : Ea.id) != null ? ja : null;
    let Ce;
    e[48] !== m ? (Ce = Y => {
        const ue = m.current;
        if (!ue) return;
        const be = ue.state.tr.setMeta(Gt, Y);
        ue.dispatch(be)
    }, e[48] = m, e[49] = Ce) : Ce = e[49];
    const zt = Ce;
    let Qe;
    e[50] !== zt ? (Qe = () => {
        zt({
            type: "close"
        })
    }, e[50] = zt, e[51] = Qe) : Qe = e[51];
    const Lt = Qe;
    let Jt;
    e[52] !== m || e[53] !== Lt ? (Jt = () => {
        const Y = m.current;
        if (!Y) return;
        const ue = Gt.getState(Y.state);
        if (!is(ue)) return;
        const {
            triggerPos: be,
            anchorPos: Fe
        } = ue;
        if (!J6(Y, be, Fe)) {
            Lt();
            return
        }
        Dn(Y)
    }, e[52] = m, e[53] = Lt, e[54] = Jt) : Jt = e[54];
    const os = Jt;
    let ms;
    e[55] !== m ? (ms = () => {
        var En, Oo;
        const Y = m.current;
        if (!Y) return;
        const ue = (En = Xt.getState(Y.state)) != null ? En : null;
        if (ue != null && ue.input || ue != null && ue.suggestion) return;
        const be = Gt.getState(Y.state);
        if (!is(be)) return;
        const Fe = be.triggerPos;
        if (Fe == null) return;
        const xt = (Oo = be.anchorPos) != null ? Oo : Fe + 1,
            gt = Math.max(Fe + 1, xt);
        let yt = Y.state.tr.delete(Fe, gt);
        const It = Math.max(Math.min(Fe, yt.doc.content.size), 0);
        yt = yt.setSelection(fn.create(yt.doc, It)), Y.dispatch(yt);
        const Nt = Y.state,
            es = Nt.selection.to,
            Pt = Nt.doc.resolve(es),
            cs = Pt.start(),
            hs = Pt.end();
        Vj(Y, {
            anchorPos: es,
            caretPos: es,
            blockFrom: cs,
            blockTo: hs,
            triggerPos: es
        }), Ze(""), Dn(Y)
    }, e[55] = m, e[56] = ms) : ms = e[56];
    const Bs = ms;
    let Vt;
    e[57] !== qe || e[58] !== m ? (Vt = () => {
        var Fe, xt, gt;
        qe(), Ze("");
        const Y = m.current;
        if (!Y) return;
        const ue = Xt.getState(Y.state),
            be = (xt = (Fe = ue == null ? void 0 : ue.input) == null ? void 0 : Fe.triggerPos) != null ? xt : null;
        if (sc(Y), be != null) {
            const yt = Y.state.doc,
                It = Math.max(0, Math.min(be, yt.content.size)),
                Nt = yt.resolve(It),
                ls = (gt = it.findFrom(Nt, 1, !0)) != null ? gt : it.near(Nt, 1);
            if (!Y.state.selection.eq(ls)) {
                const es = Y.state.tr.setSelection(ls);
                Y.dispatch(es)
            }
        }
        Y.hasFocus() || Y.focus()
    }, e[57] = qe, e[58] = m, e[59] = Vt) : Vt = e[59];
    const _s = Vt;
    let kn;
    e[60] !== lt || e[61] !== qt ? (kn = async () => {
        await qt(lt) && Ze("")
    }, e[60] = lt, e[61] = qt, e[62] = kn) : kn = e[62];
    const Gr = kn;
    let to;
    e[63] !== Ee || e[64] !== m ? (to = () => {
        if (!Ee) return;
        const Y = m.current;
        Y && (Xj(Y, Ee), Y.hasFocus() || Y.focus())
    }, e[63] = Ee, e[64] = m, e[65] = to) : to = e[65];
    const qr = to;
    let so;
    e[66] !== Ee || e[67] !== m ? (so = () => {
        if (!Ee) return;
        const Y = m.current;
        Y && (Yj(Y, Ee), Y.hasFocus() || Y.focus())
    }, e[66] = Ee, e[67] = m, e[68] = so) : so = e[68];
    const Vr = so;
    let no;
    e[69] !== ge || e[70] !== s || e[71] !== I || e[72] !== ee ? (no = Y => {
        if (!ge || !ee) return;
        ee.focus();
        const ue = Vn(I, ge),
            be = ue.modelSlug$(),
            Fe = Cc(ue, s, ge);
        Ua(Y, Fe, s.clientThreadId, s.messageId, be, I);
        const xt = ks(ue.startIndex$(), -1),
            gt = ks(ue.endIndex$(), -1),
            {
                applyAction: yt,
                eventType: It
            } = bi[Y],
            Nt = {
                conversationId: s.clientThreadId,
                messageId: s.messageId,
                magicEditId: ge,
                decisionSource: "toolbar",
                magicEditSegmentStartIndex: xt,
                magicEditSegmentEndIndex: gt,
                modelSlug: be != null ? be : void 0
            };
        Y === "accept" ? Xe.logStructuredEvent(Fa, Nt) : Xe.logStructuredEvent(Ba, Nt), Ot.count(Ft.WRITING_BLOCKS, It), jM(ee, ge, yt)
    }, e[69] = ge, e[70] = s, e[71] = I, e[72] = ee, e[73] = no) : no = e[73];
    const Ws = no;
    let oo;
    e[74] !== Ws ? (oo = () => Ws("accept"), e[74] = Ws, e[75] = oo) : oo = e[75];
    const Kr = oo;
    let ro;
    e[76] !== Ws ? (ro = () => Ws("reject"), e[76] = Ws, e[77] = ro) : ro = e[77];
    const Xr = ro;
    let io;
    e[78] !== I || e[79] !== ee || e[80] !== he ? (io = (Y, ue, be) => {
        if (!ee) return;
        const Fe = Vn(I, ue),
            [xt] = re(Fe, be);
        xt && he(Y, ue, xt, Fe, "segment"), MM(ee, ue, be, bi[Y].applyAction), ee.focus()
    }, e[78] = I, e[79] = ee, e[80] = he, e[81] = io) : io = e[81];
    const ao = io;
    let lo;
    e[82] !== m || e[83] !== Bs || e[84] !== os ? (lo = Y => {
        if (Y === "divider") {
            os();
            return
        }
        if (Y === "generate") {
            Bs();
            return
        }
        const ue = GM(Y);
        if ((ue == null ? void 0 : ue.kind) === "text-style") {
            const be = m.current;
            if (!be) return;
            be.focus(), u6(be, ue.id)
        }
    }, e[82] = m, e[83] = Bs, e[84] = os, e[85] = lo) : lo = e[85];
    const co = lo;
    let uo, fo;
    e[86] !== ft ? (uo = () => {
        _t.current = ft
    }, fo = [ft], e[86] = ft, e[87] = uo, e[88] = fo) : (uo = e[87], fo = e[88]), x.useEffect(uo, fo);
    let mo, ho;
    e[89] !== f ? (mo = () => {
        Q.current = f
    }, ho = [f], e[89] = f, e[90] = mo, e[91] = ho) : (mo = e[90], ho = e[91]), x.useEffect(mo, ho);
    let go, po;
    e[92] !== h ? (go = () => {
        ae.current = h
    }, po = [h], e[92] = h, e[93] = go, e[94] = po) : (go = e[93], po = e[94]), x.useEffect(go, po);
    let xo, bo;
    e[95] !== qe || e[96] !== m || e[97] !== co || e[98] !== Lt || e[99] !== S || e[100] !== q || e[101] !== se || e[102] !== De || e[103] !== D ? (xo = () => {
        const Y = oe.current;
        if (!Y) return;
        const {
            markdown: ue,
            maxLength: be,
            isDisabled: Fe,
            editorClassName: xt
        } = dt.current, gt = se.parse(ue != null ? ue : "");
        ut.current = ue;
        const yt = [$p(), se.inputRulesPlugin(), ...q ? [ZM({
            includeMagicTextOption: S
        })] : [], ...q ? [qj()] : [], Rj(), Wa({
            "Mod-a": Z6
        }), se.keymapPlugin(), Wa(ce(F({}, Qc), {
            "Mod-z": Ap,
            "Mod-shift-z": Xa,
            "Mod-y": Xa
        })), LM(Fe), Lj(Fe, B.current), nM(typeof be == "number" ? be : null), A6];
        S && (yt.push(vM()), yt.push(NM()));
        const It = Fm.create({
                doc: gt,
                schema: se.schema(),
                plugins: yt
            }),
            Nt = new Bm({
                mount: Y
            }, {
                state: It,
                scrollThreshold: 120,
                scrollMargin: 130,
                editable: () => !Fe,
                attributes: {
                    class: W("ProseMirror", xt),
                    "aria-disabled": String(Fe)
                },
                dispatchTransaction(Pt) {
                    const cs = Pt.getMeta(Gt),
                        hs = X6(cs) ? cs : null,
                        En = (hs == null ? void 0 : hs.type) === "execute" ? hs.commandId : null,
                        Oo = Pt.getMeta(rr) === !0,
                        ei = Nt.state.apply(Pt);
                    if (Nt.updateState(ei), ie.syncFromState(ei, {
                            isMagicEditEnabled: S
                        }, {
                            docChanged: Pt.docChanged
                        }), En && co(En), !Pt.docChanged || Oo) return;
                    const Ca = se.serialize(ei.doc);
                    ut.current = Ca, Q.current(!0), _t.current({
                        content: Ca
                    })
                }
            });
        m.current = Nt, ie.setView(Nt), ie.syncFromState(Nt.state, {
            isMagicEditEnabled: S
        });
        const ls = Nt.dom,
            es = () => {
                var Pt, cs, hs;
                (cs = (Pt = _t.current).flush) == null || cs.call(Pt), (hs = ae.current) == null || hs.call(ae), Lt()
            };
        return ls.addEventListener("blur", es, !0), () => {
            var Pt, cs;
            ls.removeEventListener("blur", es, !0), (cs = (Pt = _t.current).flush) == null || cs.call(Pt), Nt.destroy(), m.current = null, ie.setView(null), mt.current = null, De(null), qe(), Ze("")
        }
    }, bo = [se, Lt, De, S, q, D, co, qe, ie, m], e[95] = qe, e[96] = m, e[97] = co, e[98] = Lt, e[99] = S, e[100] = q, e[101] = se, e[102] = De, e[103] = D, e[104] = xo, e[105] = bo) : (xo = e[104], bo = e[105]), x.useEffect(xo, bo);
    let yo, wo;
    e[106] !== He || e[107] !== m || e[108] !== z || e[109] !== Pe || e[110] !== i ? (yo = () => {
        const Y = m.current;
        if (!Y) return;
        Y.setProps({
            editable: () => !i,
            attributes: {
                class: W("ProseMirror", He),
                "aria-disabled": String(i)
            }
        });
        const ue = rn.getState(Y.state),
            be = An.getState(Y.state),
            Fe = (ue == null ? void 0 : ue.isDisabled) !== i,
            xt = i || Pe,
            gt = (be == null ? void 0 : be.isDisabled) !== xt,
            yt = (be == null ? void 0 : be.placeholderText) !== z;
        if (Fe || gt || yt) {
            let It = Y.state.tr;
            Fe && (It = DM(It, i)), (gt || yt) && (It = Dj(It, {
                isDisabled: xt,
                placeholderText: z
            })), Y.dispatch(It)
        }
    }, wo = [He, z, Pe, i, m], e[106] = He, e[107] = m, e[108] = z, e[109] = Pe, e[110] = i, e[111] = yo, e[112] = wo) : (yo = e[111], wo = e[112]), x.useEffect(yo, wo);
    let _o, vo;
    e[113] !== m || e[114] !== S ? (_o = () => {
        const Y = m.current;
        Y && ie.syncFromState(Y.state, {
            isMagicEditEnabled: S
        })
    }, vo = [S, ie, m], e[113] = m, e[114] = S, e[115] = _o, e[116] = vo) : (_o = e[115], vo = e[116]), x.useEffect(_o, vo);
    let ko, So;
    e[117] !== le || e[118] !== De || e[119] !== fe || e[120] !== kt ? (ko = () => {
        if (le) {
            mt.current = null, De(null);
            return
        }
        if (is(fe)) {
            kt(fe.anchorPos, mt);
            return
        }
        mt.current = null, De(null)
    }, So = [le, fe, De, kt], e[117] = le, e[118] = De, e[119] = fe, e[120] = kt, e[121] = ko, e[122] = So) : (ko = e[121], So = e[122]), x.useEffect(ko, So);
    let Eo, jo;
    e[123] !== qe || e[124] !== m || e[125] !== i ? (Eo = () => {
        if (!i) return;
        const Y = m.current;
        Y && (Dn(Y), sc(Y)), qe()
    }, jo = [qe, i, m], e[123] = qe, e[124] = m, e[125] = i, e[126] = Eo, e[127] = jo) : (Eo = e[126], jo = e[127]), x.useEffect(Eo, jo);
    let Mo, Co;
    e[128] !== Ee || e[129] !== ge || e[130] !== I ? (Mo = () => (Yl(I, ge ? {
        type: "magic-edit",
        id: ge
    } : Ee ? {
        type: "generate",
        id: Ee
    } : null), () => {
        Yl(I, null)
    }), Co = [Ee, ge, I], e[128] = Ee, e[129] = ge, e[130] = I, e[131] = Mo, e[132] = Co) : (Mo = e[131], Co = e[132]), x.useEffect(Mo, Co);
    let To, Io;
    e[133] !== m || e[134] !== g ? (To = () => {
        var gt;
        const Y = m.current;
        if (!Y) return;
        const ue = on.getState(Y.state),
            be = (gt = ue == null ? void 0 : ue.maxLength) != null ? gt : null,
            Fe = typeof g == "number" ? g : null;
        if (be === Fe) return;
        const xt = oM(Y.state.tr, Fe);
        Y.dispatch(xt)
    }, Io = [g, m], e[133] = m, e[134] = g, e[135] = To, e[136] = Io) : (To = e[135], Io = e[136]), x.useEffect(To, Io);
    let No, Po;
    e[137] !== m || e[138] !== n || e[139] !== se ? (No = () => {
        const Y = m.current;
        if (!Y || n === ut.current) return;
        ut.current = n;
        const ue = se.parse(n != null ? n : ""),
            be = Y.state.tr.replaceWith(0, Y.state.doc.content.size, ue.content);
        be.setMeta(rr, !0), Y.dispatch(be)
    }, Po = [n, se, m], e[137] = m, e[138] = n, e[139] = se, e[140] = No, e[141] = Po) : (No = e[140], Po = e[141]), x.useEffect(No, Po);
    const af = is(fe),
        Qt = Pe || ge != null || Ee != null || At || Be || We,
        {
            setShouldBlockDialogEscapeKeyDown: Ro
        } = Pi();
    let $o, Ao;
    e[142] !== pe || e[143] !== Ro || e[144] !== Qt ? ($o = () => {
        Ro(Qt || pe)
    }, Ao = [Qt, pe, Ro], e[142] = pe, e[143] = Ro, e[144] = Qt, e[145] = $o, e[146] = Ao) : ($o = e[145], Ao = e[146]), x.useEffect($o, Ao);
    let Lo;
    e[147] !== Qt ? (Lo = Qt ? ["generate"] : void 0, e[147] = Qt, e[148] = Lo) : Lo = e[148];
    const Yr = Lo,
        Zr = !Pe && af ? ze : void 0;
    let Sn;
    e: {
        if (!ee) {
            Sn = null;
            break e
        }
        if (S && ge) {
            let Y;
            e[149] !== ge || e[150] !== ee || e[151] !== k || e[152] !== Kr || e[153] !== Xr ? (Y = a.jsx(wc, {
                editorView: ee,
                editorRootRef: K,
                activeEntryId: ge,
                onAccept: Kr,
                onReject: Xr,
                fullscreenMode: k
            }), e[149] = ge, e[150] = ee, e[151] = k, e[152] = Kr, e[153] = Xr, e[154] = Y) : Y = e[154], Sn = Y;
            break e
        }
        if (Ee) {
            let Y;
            e[155] !== Ee || e[156] !== ee || e[157] !== k || e[158] !== qr || e[159] !== Vr ? (Y = a.jsx(wc, {
                editorView: ee,
                editorRootRef: K,
                activeEntryId: Ee,
                onAccept: qr,
                onReject: Vr,
                fullscreenMode: k
            }), e[155] = Ee, e[156] = ee, e[157] = k, e[158] = qr, e[159] = Vr, e[160] = Y) : Y = e[160], Sn = Y;
            break e
        }
        Sn = null
    }
    const Jr = Sn;
    let zs, Hs, Us;
    if (e[161] !== k || e[162] !== R || e[163] !== _ || e[164] !== N || e[165] !== o) {
        const Y = Om();
        let ue;
        e[169] !== k || e[170] !== R || e[171] !== _ || e[172] !== o ? (ue = ma(o, k, _, R), e[169] = k, e[170] = R, e[171] = _, e[172] = o, e[173] = ue) : ue = e[173];
        const {
            top: be,
            right: Fe,
            bottom: xt,
            left: gt
        } = ue;
        zs = K;
        const yt = N.lineHeight ? "".concat(N.lineHeight, "px") : void 0,
            It = N.marginTop ? "".concat(N.marginTop, "px") : "calc(".concat(be, " * var(--spacing))"),
            Nt = N.marginRight ? "".concat(N.marginRight, "px") : "calc(".concat(Fe, " * var(--spacing))"),
            ls = N.marginBottom ? "".concat(N.marginBottom, "px") : "calc(".concat(xt, " * var(--spacing))"),
            es = N.marginLeft ? "".concat(N.marginLeft, "px") : "calc(".concat(gt, " * var(--spacing))");
        let Pt;
        e[174] !== N || e[175] !== yt || e[176] !== It || e[177] !== Nt || e[178] !== ls || e[179] !== es ? (Pt = ce(F({}, N), {
            lineHeight: yt,
            "--writing-block-editor-pt": It,
            "--writing-block-editor-pr": Nt,
            "--writing-block-editor-pb": ls,
            "--writing-block-editor-pl": es
        }), e[174] = N, e[175] = yt, e[176] = It, e[177] = Nt, e[178] = ls, e[179] = es, e[180] = Pt) : Pt = e[180], Hs = Pt, Us = W("writing-block-editor markdown-new-styling relative flow-root", Y && "firefox", N.fontSize && "override-font-size", N.fontWeight && "override-font-weight", N.lineHeight && "override-line-height", N.letterSpacing && "override-letter-spacing", "pt-(--writing-block-editor-pt)", "pe-(--writing-block-editor-pr)", "pb-(--writing-block-editor-pb)", "ps-(--writing-block-editor-pl)"), e[161] = k, e[162] = R, e[163] = _, e[164] = N, e[165] = o, e[166] = zs, e[167] = Hs, e[168] = Us
    } else zs = e[166], Hs = e[167], Us = e[168];
    let Gs;
    e[181] !== s || e[182] !== Ye || e[183] !== pe || e[184] !== l || e[185] !== Me || e[186] !== Te ? (Gs = !$ && a.jsx(I6, {
        editorAreaRef: oe,
        isInlineWritingBlockEditEnabled: l,
        docChangeCount: Ye,
        selectionIsCollapsed: Te.isCollapsed,
        isFormatToolbarOpen: pe,
        magicEditTriggerCount: Me,
        onSelectNuxVisibilityChange: Ue,
        analyticsMetadata: s
    }), e[181] = s, e[182] = Ye, e[183] = pe, e[184] = l, e[185] = Me, e[186] = Te, e[187] = Gs) : Gs = e[187];
    const Qr = k && "min-h-[75vh]";
    let qs;
    e[188] !== Qr ? (qs = W(Qr), e[188] = Qr, e[189] = qs) : qs = e[189];
    let Vs;
    e[190] !== qs ? (Vs = a.jsx("div", {
        ref: oe,
        className: qs
    }), e[190] = qs, e[191] = Vs) : Vs = e[191];
    let Ks;
    e[192] !== Yr || e[193] !== zt || e[194] !== Pe || e[195] !== q || e[196] !== tt || e[197] !== fe || e[198] !== Zr ? (Ks = q && !Pe && a.jsx(ef, {
        state: fe,
        floatingRef: tt,
        style: Zr,
        dispatchSlashMenuMeta: zt,
        disabledOptionIds: Yr
    }), e[192] = Yr, e[193] = zt, e[194] = Pe, e[195] = q, e[196] = tt, e[197] = fe, e[198] = Zr, e[199] = Ks) : Ks = e[199];
    let Xs;
    e[200] !== ee || e[201] !== Pe || e[202] !== (le == null ? void 0 : le.anchorPos) || e[203] !== lt || e[204] !== _s || e[205] !== Gr || e[206] !== At ? (Xs = Pe && ee && a.jsx(g6, {
        value: lt,
        onChange: Ze,
        onSubmit: () => {
            Gr()
        },
        onCancel: _s,
        isLoading: At,
        anchorPos: (Ma = le == null ? void 0 : le.anchorPos) != null ? Ma : null,
        editorView: ee,
        editorRootRef: K
    }), e[200] = ee, e[201] = Pe, e[202] = le == null ? void 0 : le.anchorPos, e[203] = lt, e[204] = _s, e[205] = Gr, e[206] = At, e[207] = Xs) : Xs = e[207];
    let Ys;
    e[208] !== je || e[209] !== ge || e[210] !== ee || e[211] !== ao || e[212] !== S ? (Ys = S && je && ge && a.jsx(E6, {
        editorRootRef: K,
        activeEntry: je,
        onAccept: Y => ao("accept", ge, Y),
        onReject: Y => ao("reject", ge, Y),
        focusEditor: () => {
            ee == null || ee.focus()
        }
    }), e[208] = je, e[209] = ge, e[210] = ee, e[211] = ao, e[212] = S, e[213] = Ys) : Ys = e[213];
    let Zs;
    e[214] !== St || e[215] !== ht || e[216] !== ee || e[217] !== k || e[218] !== Tt || e[219] !== P || e[220] !== i || e[221] !== Be || e[222] !== S || e[223] !== $e || e[224] !== Qt || e[225] !== st ? (Zs = !$ && !i && ee && a.jsx(m6, {
        editorView: ee,
        intl: P,
        isMagicEditEnabled: S,
        shouldDisableMagicEdit: Qt,
        toolbarContentRef: ye,
        onToolbarOpenChange: de,
        onMagicEditInvoked: pt,
        highlightMagicEdit: $e,
        isMagicEditLoading: Be,
        submitMagicEdit: st,
        applyMagicEditResult: St,
        magicEditSubmissionSource: Tt,
        fullscreenMode: k,
        cancelMagicEdit: ht
    }), e[214] = St, e[215] = ht, e[216] = ee, e[217] = k, e[218] = Tt, e[219] = P, e[220] = i, e[221] = Be, e[222] = S, e[223] = $e, e[224] = Qt, e[225] = st, e[226] = Zs) : Zs = e[226];
    let Js;
    e[227] !== nt || e[228] !== $t || e[229] !== ee || e[230] !== Dt || e[231] !== k || e[232] !== R || e[233] !== We || e[234] !== S || e[235] !== Qt || e[236] !== j || e[237] !== Et ? (Js = k && S && ee && R && j && a.jsx($6, {
        disabled: Qt || We,
        editorView: ee,
        isMagicEditLoading: We,
        submitMagicEdit: Et,
        cancelMagicEdit: $t,
        applyMagicEditResult: nt,
        magicEditSubmissionSource: Dt
    }), e[227] = nt, e[228] = $t, e[229] = ee, e[230] = Dt, e[231] = k, e[232] = R, e[233] = We, e[234] = S, e[235] = Qt, e[236] = j, e[237] = Et, e[238] = Js) : Js = e[238];
    let Do;
    return e[239] !== v || e[240] !== Jr || e[241] !== zs || e[242] !== Hs || e[243] !== Us || e[244] !== Gs || e[245] !== Vs || e[246] !== Ks || e[247] !== Xs || e[248] !== Ys || e[249] !== Zs || e[250] !== Js ? (Do = a.jsxs("div", {
        ref: zs,
        style: Hs,
        className: Us,
        children: [Gs, v, Vs, Ks, Xs, Jr, Ys, Zs, Js]
    }), e[239] = v, e[240] = Jr, e[241] = zs, e[242] = Hs, e[243] = Us, e[244] = Gs, e[245] = Vs, e[246] = Ks, e[247] = Xs, e[248] = Ys, e[249] = Zs, e[250] = Js, e[251] = Do) : Do = e[251], Do
};

function eC(t) {
    var e, s;
    return {
        index: t.segmentIndex,
        startIndex: ks(t.startIndex, -1),
        endIndex: ks(t.endIndex, -1),
        originalMarkdown: (e = t.originalMarkdown) != null ? e : "",
        suggestedMarkdown: (s = t.suggestedMarkdown) != null ? s : ""
    }
}

function tC(t, e) {
    const s = t.segmentDiffs$();
    return !Array.isArray(s) || s.length === 0 ? [] : s.filter(n => e == null ? !0 : n.segmentIndex === e).map(eC)
}

function sC(t) {
    return t + 1
}

function nC({
    content: t,
    clientThreadId: e,
    messageId: s,
    contentReferences: n
}) {
    const o = et(),
        r = Ne(),
        i = ys(),
        [l, c] = x.useState(!1),
        d = rg();
    return {
        handleCopy: async f => {
            if (l) return;
            Xe.logStructuredEvent(Wm, {
                conversationId: e,
                messageId: s
            }), Ot.count(Ft.WRITING_BLOCKS, "chatgpt_writing_block_copy_button_clicked");
            const h = await u1(t, {
                    preserveContentReferences: !0
                }),
                m = Xn(e);
            t != null && m != null && s != null && (Xe.logStructuredEvent(zm, {
                conversationId: m,
                messageId: s
            }), lg(o, {
                type: "copy",
                source: "mouse",
                location: "writing-block",
                selectedText: h,
                messageId: s,
                serverThreadId: m,
                contentType: "text"
            }));
            let b = {
                "text/plain": h
            };
            try {
                b = bd(h, n)
            } catch (y) {
                ts.addError(y)
            }
            Di(b, i, f), c(!0), d(() => c(!1), 2e3)
        },
        Icon: l ? ig : ag,
        copyLabel: r.formatMessage({
            id: "D5UU6P",
            defaultMessage: "Copy"
        })
    }
}

function oC(t) {
    "use forget";
    const e = xe.c(8),
        {
            clientThreadId: s,
            messageId: n,
            content: o,
            contentReferences: r
        } = t;
    let i;
    e[0] !== s || e[1] !== o || e[2] !== r || e[3] !== n ? (i = {
        clientThreadId: s,
        messageId: n,
        content: o,
        contentReferences: r
    }, e[0] = s, e[1] = o, e[2] = r, e[3] = n, e[4] = i) : i = e[4];
    const {
        handleCopy: l
    } = nC(i);
    let c;
    e[5] === Symbol.for("react.memo_cache_sentinel") ? (c = W(Mu, "text-token-text-tertiary hover:text-token-text-primary px-2 py-2"), e[5] = c) : c = e[5];
    let d;
    return e[6] !== l ? (d = a.jsx(rd, {
        onCopy: l,
        iconClassName: "icon-md",
        className: c,
        iconOnly: !0,
        tooltipSideOffset: Hr
    }), e[6] = l, e[7] = d) : d = e[7], d
}

function rC({
    clientThreadId: t,
    messageId: e,
    index: s,
    title: n,
    isStreaming: o
}) {
    "use no forget";
    const r = ys(),
        i = Ne(),
        [l, c] = x.useState(!1),
        d = !Hm(),
        u = Jn(t);
    if (!t) return null;
    const f = i.formatMessage({
        id: "writingblock.downloadFileError",
        defaultMessage: "Download failed. Please try again."
    });
    async function h(m) {
        var b;
        if (u) {
            c(!0);
            try {
                const y = await vn.safePost("/export_doc/writing_block", {
                    requestBody: {
                        conversation_id: u.toString(),
                        message_id: e,
                        index: s,
                        export_type: m
                    },
                    skipJsonTransform: !0
                });
                y.ok || r.danger(f);
                const p = await y.blob(),
                    w = y.headers.get("Content-Disposition"),
                    C = (b = m1(w)) != null ? b : "".concat((n != null ? n : "Export").replaceAll("/", "-"), ".").concat(m);
                f1(p, C)
            } catch (y) {
                ts.addError(y, {
                    tags: ["type:writing_block_download_button", "export_type:".concat(m)]
                }), r.danger(f)
            } finally {
                c(!1)
            }
        }
    }
    return a.jsxs(Ut.Root, {
        children: [a.jsx(Yn, {
            sideOffset: Hr,
            label: a.jsx(me, {
                id: "WritingBlockDownloadButton.downloadTooltip",
                defaultMessage: "Download"
            }),
            children: a.jsx(Ut.BasicTrigger, {
                asChild: !0,
                children: a.jsx("button", {
                    className: W("flex items-center gap-1 px-2 py-2 select-none", (!u || o) && "text-token-text-secondary"),
                    disabled: l || !u || o,
                    children: d ? l ? a.jsx(Za, {
                        size: 16
                    }) : a.jsx(_i, {
                        className: "text-token-text-tertiary hover:text-token-text-primary block"
                    }) : a.jsx("div", {
                        className: W("flex items-center gap-1", Mu, "font-normal"),
                        children: l ? a.jsx(Za, {
                            size: 20
                        }) : a.jsx(_i, {
                            className: "text-token-text-tertiary hover:text-token-text-primary block"
                        })
                    })
                })
            })
        }), a.jsx(Ut.Portal, {
            children: a.jsxs(Ut.Content, {
                align: "end",
                children: [a.jsx(Ut.Label, {
                    children: a.jsx(me, {
                        id: "WritingBlockDownloadButton.menuTitle",
                        defaultMessage: "Download"
                    })
                }), a.jsx(Ut.Item, {
                    onSelect: () => {
                        h("pdf")
                    },
                    icon: cg,
                    label: i.formatMessage({
                        id: "WritingBlockDownloadButton.downloadPdf.label",
                        defaultMessage: "PDF document"
                    }),
                    trailing: a.jsx("span", {
                        children: i.formatMessage({
                            id: "WritingBlockDownloadButton.downloadPdf.ext",
                            defaultMessage: ".pdf"
                        })
                    })
                }), a.jsx(Ut.Item, {
                    onSelect: () => {
                        h("docx")
                    },
                    icon: Um,
                    label: i.formatMessage({
                        id: "WritingBlockDownloadButton.downloadDocx.label",
                        defaultMessage: "Microsoft Word"
                    }),
                    trailing: a.jsx("span", {
                        children: i.formatMessage({
                            id: "WritingBlockDownloadButton.downloadDocx.ext",
                            defaultMessage: ".docx"
                        })
                    })
                })]
            })
        })]
    })
}

function iC({
    messageId: t,
    clientThreadId: e,
    writingBlockId: s
}) {
    var l, c;
    const n = Ls(e, d => {
            if (!t || !d) return;
            const f = fs.getTree(d).getNodeIfExists(t);
            return f == null ? void 0 : f.message
        }),
        o = ((c = (l = n == null ? void 0 : n.metadata) == null ? void 0 : l.writing_blocks) == null ? void 0 : c[s]) !== void 0,
        r = Jn(e);
    return kr({
        mutationFn: async d => {
            try {
                await vn.safePost("/conversation/message/writing-blocks/feedback", {
                    requestBody: {
                        message_id: t != null ? t : "unknown",
                        conversation_id: r != null ? r : "unknown",
                        writing_block_id: s,
                        feedback: d,
                        user_edited_writing_block: o
                    },
                    authOption: Mr.SendIfAvailable
                })
            } catch (u) {
                return
            }
        }
    })
}

function aC(t) {
    "use forget";
    const e = xe.c(40),
        {
            messageId: s,
            clientThreadId: n,
            writingBlockId: o,
            hideWritingBlockFeedback: r
        } = t,
        i = Ne();
    let l;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (l = Gm(Bc()), e[0] = l) : l = e[0];
    const c = l,
        [d, u] = x.useState(""),
        [f, h] = x.useState(!1);
    let m;
    e[1] !== n || e[2] !== s || e[3] !== o ? (m = {
        messageId: s,
        clientThreadId: n,
        writingBlockId: o
    }, e[1] = n, e[2] = s, e[3] = o, e[4] = m) : m = e[4];
    const {
        mutate: b
    } = iC(m);
    let y;
    e[5] !== d || e[6] !== r || e[7] !== i || e[8] !== b ? (y = () => {
        b(d), c.success(i.formatMessage({
            id: "fGxMWX",
            defaultMessage: "Your feedback has been submitted"
        })), u(""), h(!1), r()
    }, e[5] = d, e[6] = r, e[7] = i, e[8] = b, e[9] = y) : y = e[9];
    const p = y;
    let w;
    e[10] !== i ? (w = i.formatMessage({
        id: "GmCXKv",
        defaultMessage: "Give feedback"
    }), e[10] = i, e[11] = w) : w = e[11];
    const C = w;
    let v;
    e[12] !== C ? (v = a.jsx(Ut.BasicTrigger, {
        asChild: !0,
        children: a.jsx(Ni, {
            icon: h1,
            iconColor: "text-token-interactive-icon-accent-default",
            label: C,
            tooltip: C
        })
    }), e[12] = C, e[13] = v) : v = e[13];
    let g;
    e[14] === Symbol.for("react.memo_cache_sentinel") ? (g = a.jsxs("div", {
        className: "px-2 py-1 text-sm",
        children: [a.jsx("div", {
            className: "font-bold",
            children: a.jsx(me, {
                id: "B5fNd/",
                defaultMessage: "Help us improve ChatGPT"
            })
        }), a.jsx("div", {
            children: a.jsx(me, {
                id: "J4xuST",
                defaultMessage: "Let us know what you like or dislike about the writing blocks feature."
            })
        })]
    }), e[14] = g) : g = e[14];
    let k;
    e[15] === Symbol.for("react.memo_cache_sentinel") ? (k = P => u(P.target.value), e[15] = k) : k = e[15];
    let E;
    e[16] !== i ? (E = i.formatMessage({
        id: "UmOoD3",
        defaultMessage: "Give feedback..."
    }), e[16] = i, e[17] = E) : E = e[17];
    let j;
    e[18] !== p ? (j = P => {
        P.preventDefault(), p()
    }, e[18] = p, e[19] = j) : j = e[19];
    let M;
    e[20] !== d || e[21] !== E || e[22] !== j ? (M = a.jsx("textarea", {
        autoFocus: !0,
        value: d,
        onChange: k,
        placeholder: E,
        onSubmit: j,
        rows: 5,
        className: "border-token-border-default w-full resize-none border-none bg-transparent px-2 ps-2 pe-8 text-sm focus:border-transparent focus:ring-0 focus:outline-none"
    }), e[20] = d, e[21] = E, e[22] = j, e[23] = M) : M = e[23];
    let T;
    e[24] !== d ? (T = d.trim(), e[24] = d, e[25] = T) : T = e[25];
    const N = T === "";
    let I;
    e[26] !== i ? (I = i.formatMessage({
        defaultMessage: "Submit",
        id: "aria.submit"
    }), e[26] = i, e[27] = I) : I = e[27];
    let _;
    e[28] === Symbol.for("react.memo_cache_sentinel") ? (_ = a.jsx(Gi, {
        className: "icon-xs"
    }), e[28] = _) : _ = e[28];
    let R;
    e[29] !== p || e[30] !== N || e[31] !== I ? (R = a.jsx("button", {
        className: "icon composer-submit-btn composer-submit-button-color absolute end-2 bottom-2",
        disabled: N,
        onClick: p,
        "aria-label": I,
        children: _
    }), e[29] = p, e[30] = N, e[31] = I, e[32] = R) : R = e[32];
    let A;
    e[33] !== M || e[34] !== R ? (A = a.jsx(Ut.Portal, {
        children: a.jsxs(Ut.Content, {
            side: "bottom",
            align: "end",
            sideOffset: 8,
            alignOffset: 0,
            onCloseAutoFocus: lC,
            className: "flex w-[320px] flex-col gap-2 p-2",
            children: [g, a.jsxs("div", {
                className: "bg-token-bg-secondary relative flex flex-col justify-between gap-1 rounded-lg shadow-[inset_0px_0px_1px_rgba(0,0,0,0.5)] dark:shadow-[inset_0px_0px_1px_rgba(255,255,255,0.3)]",
                children: [M, R]
            })]
        })
    }), e[33] = M, e[34] = R, e[35] = A) : A = e[35];
    let $;
    return e[36] !== f || e[37] !== A || e[38] !== v ? ($ = a.jsxs(Ut.Root, {
        onOpenChange: h,
        open: f,
        children: [v, A]
    }), e[36] = f, e[37] = A, e[38] = v, e[39] = $) : $ = e[39], $
}

function lC(t) {
    t.preventDefault()
}

function cC(t) {
    "use forget";
    var N, I, _, R;
    const e = xe.c(22),
        {
            content: s,
            clientThreadId: n,
            messageId: o
        } = t,
        r = qm(),
        i = Rt(dC),
        l = i == null ? void 0 : i.selectionIsEditable;
    let c;
    e[0] !== (i == null ? void 0 : i.selection) ? (c = (N = i == null ? void 0 : i.selection) == null ? void 0 : N.trim(), e[0] = i == null ? void 0 : i.selection, e[1] = c) : c = e[1];
    const d = !!c,
        u = (I = i == null ? void 0 : i.url) != null ? I : "";
    let f, h;
    if (e[2] !== u) {
        const A = (_ = (() => {
            try {
                return new URL(u).host
            } catch ($) {
                return ""
            }
        })()) != null ? _ : "";
        f = !!u.match(g1), h = A.includes("notion.so"), e[2] = u, e[3] = f, e[4] = h
    } else f = e[3], h = e[4];
    const m = h,
        y = !!(f || m || l),
        p = !!(!m && d);
    let w;
    e[5] !== n || e[6] !== s || e[7] !== r || e[8] !== o ? (w = () => {
        r && (Xe.logStructuredEvent(Km, {
            conversationId: n,
            messageId: o
        }), Ot.count(Ft.WRITING_BLOCKS, "chatgpt_writing_block_insert_button_clicked"), r.insertTextFromWebContent(s))
    }, e[5] = n, e[6] = s, e[7] = r, e[8] = o, e[9] = w) : w = e[9];
    const C = w;
    if (!r) return null;
    const v = !y,
        g = i == null ? void 0 : i.base64favicon,
        k = (R = i == null ? void 0 : i.title) != null ? R : u;
    let E;
    e[10] !== g || e[11] !== k ? (E = a.jsx(dg, {
        base64: g,
        title: k,
        className: "not-prose h-3 w-3 flex-shrink-0 rounded-[4px]"
    }), e[10] = g, e[11] = k, e[12] = E) : E = e[12];
    let j;
    e[13] !== p ? (j = p ? a.jsx(me, {
        id: "SjFYnK",
        defaultMessage: "Update"
    }) : a.jsx(me, {
        id: "8SKT1J",
        defaultMessage: "Insert"
    }), e[13] = p, e[14] = j) : j = e[14];
    let M;
    e[15] !== E || e[16] !== j ? (M = a.jsxs("span", {
        className: "flex items-center gap-1.5",
        children: [E, j]
    }), e[15] = E, e[16] = j, e[17] = M) : M = e[17];
    let T;
    return e[18] !== C || e[19] !== v || e[20] !== M ? (T = a.jsx(us, {
        color: "secondary",
        type: "button",
        onClick: C,
        disabled: v,
        size: "small",
        children: M
    }), e[18] = C, e[19] = v, e[20] = M, e[21] = T) : T = e[21], T
}

function dC() {
    return Vm.context$()
}
const sf = t => {
        "use forget";
        var k;
        const e = xe.c(32),
            {
                writingBlock: s,
                clientThreadId: n,
                messageId: o,
                contentReferences: r,
                hideDownloadButton: i,
                isInlineWritingBlockExportEnabled: l,
                title: c,
                index: d,
                isStreaming: u,
                primaryAction: f,
                shouldShowAuraInsertButton: h,
                isWritingBlockFeedbackEnabled: m,
                isWritingBlockFeedbackHidden: b,
                hideWritingBlockFeedback: y
            } = t;
        let p;
        e[0] !== n || e[1] !== r || e[2] !== o || e[3] !== s ? (p = n && o && a.jsx(oC, {
            content: s.content,
            clientThreadId: n,
            messageId: o,
            contentReferences: r
        }), e[0] = n, e[1] = r, e[2] = o, e[3] = s, e[4] = p) : p = e[4];
        let w;
        e[5] !== n || e[6] !== i || e[7] !== d || e[8] !== l || e[9] !== u || e[10] !== o || e[11] !== c ? (w = !i && l && n && o && a.jsx(rC, {
            clientThreadId: n,
            messageId: o,
            title: c,
            index: d,
            isStreaming: u
        }), e[5] = n, e[6] = i, e[7] = d, e[8] = l, e[9] = u, e[10] = o, e[11] = c, e[12] = w) : w = e[12];
        let C;
        e[13] !== n || e[14] !== y || e[15] !== d || e[16] !== m || e[17] !== b || e[18] !== o || e[19] !== s ? (C = m && !b && a.jsx(aC, {
            messageId: o,
            clientThreadId: n,
            writingBlockId: (k = s.id) != null ? k : "index-".concat(d),
            hideWritingBlockFeedback: y
        }), e[13] = n, e[14] = y, e[15] = d, e[16] = m, e[17] = b, e[18] = o, e[19] = s, e[20] = C) : C = e[20];
        let v;
        e[21] !== n || e[22] !== o || e[23] !== h || e[24] !== s ? (v = h && n && o && a.jsx("div", {
            className: "ps-2",
            children: a.jsx(cC, {
                content: s.content,
                clientThreadId: n,
                messageId: o
            })
        }), e[21] = n, e[22] = o, e[23] = h, e[24] = s, e[25] = v) : v = e[25];
        let g;
        return e[26] !== f || e[27] !== p || e[28] !== w || e[29] !== C || e[30] !== v ? (g = a.jsxs("div", {
            className: "flex items-center",
            children: [p, w, f, C, v]
        }), e[26] = f, e[27] = p, e[28] = w, e[29] = C, e[30] = v, e[31] = g) : g = e[31], g
    },
    nf = t => {
        "use forget";
        const e = xe.c(56),
            {
                primaryLabel: s,
                primaryAction: n,
                writingBlock: o,
                clientThreadId: r,
                messageId: i,
                isInlineWritingBlockExportEnabled: l,
                title: c,
                index: d,
                autosaveStatus: u,
                hideDownloadButton: f,
                contentReferences: h,
                fullscreenMode: m,
                isStreaming: b,
                className: y,
                isWritingBlockFeedbackEnabled: p,
                isWritingBlockFeedbackHidden: w,
                hideWritingBlockFeedback: C
            } = t,
            v = f === void 0 ? !1 : f,
            g = m === void 0 ? !1 : m,
            k = et();
        let E;
        e[0] !== k ? (E = () => Fc(k), e[0] = k, e[1] = E) : E = e[1];
        const j = Rt(E);
        let M;
        e[2] !== k ? (M = at(k, "1600402835"), e[2] = k, e[3] = M) : M = e[3];
        let T;
        e[4] !== k ? (T = at(k, "3877999974"), e[4] = k, e[5] = T) : T = e[5];
        const N = T,
            I = !1,
            _ = "idle";
        let R;
        e: {
            R = "text-token-text-primary/35";
            break e
        }
        const A = R;
        let $;
        e[6] !== g || e[7] !== N || e[8] !== j || e[9] !== o.content ? ($ = !g && j && o.content.trim().length > 0 && N, e[6] = g, e[7] = N, e[8] = j, e[9] = o.content, e[10] = $) : $ = e[10];
        const P = $,
            U = Rt(Wi),
            z = Rt(an);
        let B;
        e[11] !== g || e[12] !== z || e[13] !== U || e[14] !== o.variant ? (B = ma(o.variant, g, U, z), e[11] = g, e[12] = z, e[13] = U, e[14] = o.variant, e[15] = B) : B = e[15];
        const {
            left: G
        } = B, O = g ? "rounded-none" : "rounded-t-2xl", H = P ? "pe-2.5" : "pe-2";
        let S;
        e[16] !== y || e[17] !== H || e[18] !== O ? (S = W(vj, "flex w-full items-center justify-between gap-3 py-1.5 font-sans", O, H, y), e[16] = y, e[17] = H, e[18] = O, e[19] = S) : S = e[19];
        const V = "calc(".concat(P ? 3.5 : Math.min(G, 5), " * var(--spacing))");
        let J;
        e[20] !== V ? (J = {
            paddingLeft: V
        }, e[20] = V, e[21] = J) : J = e[21];
        let q;
        e[22] !== s ? (q = s != null ? s : a.jsx(me, {
            id: "Ui6xge",
            defaultMessage: "Writing"
        }), e[22] = s, e[23] = q) : q = e[23];
        let Z;
        e[24] !== q ? (Z = a.jsx("div", {
            className: "truncate",
            children: q
        }), e[24] = q, e[25] = Z) : Z = e[25];
        let D;
        e[26] !== A || e[27] !== _ || e[28] !== I ? (D = I, e[26] = A, e[27] = _, e[28] = I, e[29] = D) : D = e[29];
        let te;
        e[30] !== Z || e[31] !== D ? (te = a.jsxs("div", {
            className: "text-token-text-tertiary flex max-w-[75%] min-w-0 grow cursor-default items-center text-sm font-medium",
            children: [Z, D]
        }), e[30] = Z, e[31] = D, e[32] = te) : te = e[32];
        let se;
        e[33] !== r || e[34] !== h || e[35] !== v || e[36] !== C || e[37] !== d || e[38] !== l || e[39] !== b || e[40] !== p || e[41] !== w || e[42] !== i || e[43] !== n || e[44] !== P || e[45] !== c || e[46] !== o ? (se = !Bi() && a.jsx(sf, {
            writingBlock: o,
            clientThreadId: r,
            messageId: i,
            contentReferences: h,
            hideDownloadButton: v,
            isInlineWritingBlockExportEnabled: l,
            title: c,
            index: d,
            isStreaming: b,
            primaryAction: n,
            shouldShowAuraInsertButton: P,
            isWritingBlockFeedbackEnabled: p,
            isWritingBlockFeedbackHidden: w,
            hideWritingBlockFeedback: C
        }), e[33] = r, e[34] = h, e[35] = v, e[36] = C, e[37] = d, e[38] = l, e[39] = b, e[40] = p, e[41] = w, e[42] = i, e[43] = n, e[44] = P, e[45] = c, e[46] = o, e[47] = se) : se = e[47];
        let re;
        e[48] !== S || e[49] !== J || e[50] !== te || e[51] !== se ? (re = a.jsxs("div", {
            className: S,
            style: J,
            children: [te, se]
        }), e[48] = S, e[49] = J, e[50] = te, e[51] = se, e[52] = re) : re = e[52];
        let X;
        e[53] === Symbol.for("react.memo_cache_sentinel") ? (X = a.jsx("hr", {
            className: "border-token-border-light! border-0.5 mx-4 my-0! md:mx-5"
        }), e[53] = X) : X = e[53];
        let he;
        return e[54] !== re ? (he = a.jsxs("div", {
            className: "@w-xl/main:-top-(--header-height) sticky top-0 z-1",
            children: [re, X]
        }), e[54] = re, e[55] = he) : he = e[55], he
    },
    uC = "my-0! border-0 border-t !border-token-border-light mx-4 md:mx-5";

function fC(t) {
    "use forget";
    var Ye, ge, lt, Ze, pe;
    const e = xe.c(72),
        {
            analyticsMetadata: s,
            hasBeenEdited: n,
            messageId: o,
            clientThreadId: r,
            messageRef: i,
            editorViewRef: l,
            shouldShowWritingBlockCanvasEdit: c,
            isInlineWritingBlockEditEnabled: d,
            isInlineWritingBlockExportEnabled: u,
            isWritingBlockFocusedModeEnabled: f,
            writingBlock: h,
            index: m,
            onChange: b,
            isStreaming: y,
            autosaveStatus: p,
            subject: w,
            setDirty: C,
            flushPendingChanges: v,
            contentReferences: g,
            isWritingBlockFeedbackEnabled: k,
            isWritingBlockFeedbackHidden: E,
            hideWritingBlockFeedback: j
        } = t,
        M = c === void 0 ? !1 : c,
        [T, N] = x.useState(String((lt = (ge = (Ye = h.metadata) == null ? void 0 : Ye.subject) != null ? ge : h.title) != null ? lt : "")),
        [I] = x.useState(String((pe = (Ze = h.metadata) == null ? void 0 : Ze.recipient) != null ? pe : "")),
        _ = Yi(b, 300);
    let R;
    e[0] !== _ || e[1] !== C ? (R = de => {
        C(!0), N(de.target.value), _({
            metadata: {
                subject: de.target.value
            }
        })
    }, e[0] = _, e[1] = C, e[2] = R) : R = e[2];
    const A = R;
    let $;
    e[3] !== _ || e[4] !== v || e[5] !== C ? ($ = de => {
        C(!0), _({
            metadata: {
                subject: de.target.value
            }
        }), _.flush(), v == null || v()
    }, e[3] = _, e[4] = v, e[5] = C, e[6] = $) : $ = e[6];
    const P = $;
    let U;
    e[7] !== I || e[8] !== T || e[9] !== h.content ? (U = de => {
        const Me = encodeURIComponent(ip(h.content)),
            we = encodeURIComponent(I),
            $e = encodeURIComponent(T);
        switch (de) {
            case "gmail":
                return "https://mail.google.com/mail/u/0/?tf=cm&to=".concat(we, "&su=").concat($e, "&body=").concat(Me);
            case "outlook":
                return "https://outlook.office.com/mail/deeplink/compose?to=".concat(we, "&subject=").concat($e, "&body=").concat(Me);
            case "default":
                return "mailto:".concat(I, "?subject=").concat($e, "&body=").concat(Me)
        }
    }, e[7] = I, e[8] = T, e[9] = h.content, e[10] = U) : U = e[10];
    const z = U;
    let B;
    e[11] === Symbol.for("react.memo_cache_sentinel") ? (B = a.jsx(me, {
        id: "PrFQxx",
        defaultMessage: "Email"
    }), e[11] = B) : B = e[11];
    const G = B;
    let O;
    e[12] !== z ? (O = de => window.open(z(de), "_blank"), e[12] = z, e[13] = O) : O = e[13];
    let H;
    e[14] !== r || e[15] !== o || e[16] !== O ? (H = a.jsx(Sj, {
        clientThreadId: r,
        messageId: o,
        onClick: O
    }), e[14] = r, e[15] = o, e[16] = O, e[17] = H) : H = e[17];
    const S = H,
        V = Rt(Wi),
        J = Rt(an);
    let q;
    e[18] !== J || e[19] !== V ? (q = ma(yn.EMAIL, !1, V, J), e[18] = J, e[19] = V, e[20] = q) : q = e[20];
    const {
        left: Z,
        right: D
    } = q, te = "calc(".concat(Z, " * var(--spacing))"), se = "calc(".concat(D, " * var(--spacing))");
    let re;
    e[21] !== se || e[22] !== te ? (re = {
        paddingLeft: te,
        paddingRight: se
    }, e[21] = se, e[22] = te, e[23] = re) : re = e[23];
    let X;
    e[24] === Symbol.for("react.memo_cache_sentinel") ? (X = a.jsx("div", {
        className: "font-medium",
        children: a.jsx(me, {
            id: "eQGtfX",
            defaultMessage: "Subject"
        })
    }), e[24] = X) : X = e[24];
    const he = y || !d,
        K = y ? w != null ? w : "" : T;
    let oe;
    e[25] !== P || e[26] !== A || e[27] !== he || e[28] !== K ? (oe = a.jsx("input", {
        disabled: he,
        className: kj,
        value: K,
        maxLength: 240,
        onChange: A,
        onBlur: P,
        onCopy: mC
    }), e[25] = P, e[26] = A, e[27] = he, e[28] = K, e[29] = oe) : oe = e[29];
    let ye;
    e[30] !== re || e[31] !== oe ? (ye = a.jsxs("div", {
        className: "flex w-full min-w-0 items-center px-5 py-1.5 font-sans",
        style: re,
        children: [X, oe]
    }), e[30] = re, e[31] = oe, e[32] = ye) : ye = e[32];
    const ke = ye;
    let ie;
    e[33] !== p || e[34] !== r || e[35] !== g || e[36] !== S || e[37] !== n || e[38] !== j || e[39] !== m || e[40] !== u || e[41] !== y || e[42] !== k || e[43] !== E || e[44] !== f || e[45] !== o || e[46] !== M || e[47] !== w || e[48] !== h ? (ie = a.jsx(nf, {
        primaryLabel: G,
        primaryAction: S,
        writingBlock: h,
        clientThreadId: r,
        messageId: o,
        title: w,
        hideDownloadButton: !0,
        hasBeenEdited: n,
        autosaveStatus: p,
        shouldShowWritingBlockCanvasEdit: M,
        isInlineWritingBlockExportEnabled: u,
        isWritingBlockFocusedModeEnabled: f,
        index: m,
        contentReferences: g,
        isStreaming: y,
        isWritingBlockFeedbackEnabled: k,
        isWritingBlockFeedbackHidden: E,
        hideWritingBlockFeedback: j
    }), e[33] = p, e[34] = r, e[35] = g, e[36] = S, e[37] = n, e[38] = j, e[39] = m, e[40] = u, e[41] = y, e[42] = k, e[43] = E, e[44] = f, e[45] = o, e[46] = M, e[47] = w, e[48] = h, e[49] = ie) : ie = e[49];
    let ee;
    e[50] !== ke ? (ee = a.jsx("div", {
        className: "flex items-center pe-2",
        children: ke
    }), e[50] = ke, e[51] = ee) : ee = e[51];
    let fe;
    e[52] === Symbol.for("react.memo_cache_sentinel") ? (fe = a.jsx("hr", {
        className: W(uC, "mx-4")
    }), e[52] = fe) : fe = e[52];
    const Se = y || !d;
    let je;
    e[53] !== s || e[54] !== g || e[55] !== l || e[56] !== v || e[57] !== d || e[58] !== y || e[59] !== b || e[60] !== C || e[61] !== Se || e[62] !== h.content || e[63] !== h.variant ? (je = a.jsx(va, {
        editorViewRef: l,
        setDirty: C,
        analyticsMetadata: s,
        markdown: h.content,
        variant: h.variant,
        onChange: b,
        isDisabled: Se,
        isInlineWritingBlockEditEnabled: d,
        flushPendingChanges: v,
        contentReferences: g,
        showBottomComposer: !0,
        isStreaming: y
    }), e[53] = s, e[54] = g, e[55] = l, e[56] = v, e[57] = d, e[58] = y, e[59] = b, e[60] = C, e[61] = Se, e[62] = h.content, e[63] = h.variant, e[64] = je) : je = e[64];
    let Te;
    return e[65] !== l || e[66] !== o || e[67] !== i || e[68] !== ie || e[69] !== ee || e[70] !== je ? (Te = a.jsxs(Ur, {
        messageRef: i,
        messageId: o,
        editorViewRef: l,
        children: [ie, ee, fe, je]
    }), e[65] = l, e[66] = o, e[67] = i, e[68] = ie, e[69] = ee, e[70] = je, e[71] = Te) : Te = e[71], Te
}

function mC(t) {
    return t.stopPropagation()
}

function hC(t) {
    "use forget";
    const e = xe.c(28),
        {
            analyticsMetadata: s,
            clientThreadId: n,
            contentReferences: o,
            editorViewRef: r,
            flushPendingChanges: i,
            forceCaretNux: l,
            index: c,
            isInlineWritingBlockEditEnabled: d,
            isInlineWritingBlockExportEnabled: u,
            isStreaming: f,
            messageId: h,
            messageRef: m,
            onChange: b,
            setDirty: y,
            writingBlock: p,
            isWritingBlockFeedbackEnabled: w,
            isWritingBlockFeedbackHidden: C,
            hideWritingBlockFeedback: v
        } = t,
        g = f || !d;
    let k;
    e[0] !== n || e[1] !== v || e[2] !== c || e[3] !== u || e[4] !== w || e[5] !== C || e[6] !== h || e[7] !== p ? (k = a.jsx("div", {
        className: "float-end -me-3 -mt-1",
        children: a.jsx(sf, {
            writingBlock: p,
            clientThreadId: n,
            messageId: h,
            hideDownloadButton: !0,
            isInlineWritingBlockExportEnabled: u,
            index: c,
            shouldShowAuraInsertButton: !1,
            isWritingBlockFeedbackEnabled: w,
            isWritingBlockFeedbackHidden: C,
            hideWritingBlockFeedback: v
        })
    }), e[0] = n, e[1] = v, e[2] = c, e[3] = u, e[4] = w, e[5] = C, e[6] = h, e[7] = p, e[8] = k) : k = e[8];
    let E;
    e[9] !== s || e[10] !== o || e[11] !== r || e[12] !== i || e[13] !== l || e[14] !== d || e[15] !== f || e[16] !== b || e[17] !== y || e[18] !== g || e[19] !== k || e[20] !== p.content || e[21] !== p.variant ? (E = a.jsx(va, {
        editorViewRef: r,
        setDirty: y,
        analyticsMetadata: s,
        markdown: p.content,
        variant: p.variant,
        onChange: b,
        isDisabled: g,
        isInlineWritingBlockEditEnabled: d,
        flushPendingChanges: i,
        contentReferences: o,
        showBottomComposer: !0,
        isStreaming: f,
        forceCaretNux: l,
        children: k
    }), e[9] = s, e[10] = o, e[11] = r, e[12] = i, e[13] = l, e[14] = d, e[15] = f, e[16] = b, e[17] = y, e[18] = g, e[19] = k, e[20] = p.content, e[21] = p.variant, e[22] = E) : E = e[22];
    let j;
    return e[23] !== r || e[24] !== h || e[25] !== m || e[26] !== E ? (j = a.jsx(Ur, {
        messageRef: m,
        messageId: h,
        editorViewRef: r,
        children: E
    }), e[23] = r, e[24] = h, e[25] = m, e[26] = E, e[27] = j) : j = e[27], j
}

function gC(t) {
    "use forget";
    const e = xe.c(34),
        {
            analyticsMetadata: s,
            autosaveStatus: n,
            clientThreadId: o,
            contentReferences: r,
            editorViewRef: i,
            flushPendingChanges: l,
            hasBeenEdited: c,
            index: d,
            isInlineWritingBlockEditEnabled: u,
            isInlineWritingBlockExportEnabled: f,
            isStreaming: h,
            isWritingBlockFocusedModeEnabled: m,
            messageId: b,
            messageRef: y,
            onChange: p,
            setDirty: w,
            shouldShowWritingBlockCanvasEdit: C,
            title: v,
            writingBlock: g,
            isWritingBlockFeedbackEnabled: k,
            isWritingBlockFeedbackHidden: E,
            hideWritingBlockFeedback: j
        } = t,
        M = C === void 0 ? !1 : C;
    let T;
    e[0] !== n || e[1] !== o || e[2] !== r || e[3] !== c || e[4] !== j || e[5] !== d || e[6] !== f || e[7] !== h || e[8] !== k || e[9] !== E || e[10] !== m || e[11] !== b || e[12] !== M || e[13] !== v || e[14] !== g ? (T = a.jsx(nf, {
        hasBeenEdited: c,
        autosaveStatus: n,
        writingBlock: g,
        primaryLabel: g.title,
        clientThreadId: o,
        messageId: b,
        isInlineWritingBlockExportEnabled: f,
        isWritingBlockFocusedModeEnabled: m,
        shouldShowWritingBlockCanvasEdit: M,
        title: v,
        index: d,
        contentReferences: r,
        isStreaming: h,
        isWritingBlockFeedbackEnabled: k,
        isWritingBlockFeedbackHidden: E,
        hideWritingBlockFeedback: j
    }), e[0] = n, e[1] = o, e[2] = r, e[3] = c, e[4] = j, e[5] = d, e[6] = f, e[7] = h, e[8] = k, e[9] = E, e[10] = m, e[11] = b, e[12] = M, e[13] = v, e[14] = g, e[15] = T) : T = e[15];
    const N = h || !u;
    let I;
    e[16] !== s || e[17] !== r || e[18] !== i || e[19] !== l || e[20] !== u || e[21] !== h || e[22] !== p || e[23] !== w || e[24] !== N || e[25] !== g.content || e[26] !== g.variant ? (I = a.jsx(va, {
        editorViewRef: i,
        setDirty: w,
        analyticsMetadata: s,
        markdown: g.content,
        variant: g.variant,
        onChange: p,
        isDisabled: N,
        isInlineWritingBlockEditEnabled: u,
        flushPendingChanges: l,
        contentReferences: r,
        showBottomComposer: !0,
        isStreaming: h
    }), e[16] = s, e[17] = r, e[18] = i, e[19] = l, e[20] = u, e[21] = h, e[22] = p, e[23] = w, e[24] = N, e[25] = g.content, e[26] = g.variant, e[27] = I) : I = e[27];
    let _;
    return e[28] !== i || e[29] !== b || e[30] !== y || e[31] !== T || e[32] !== I ? (_ = a.jsxs(Ur, {
        messageRef: y,
        messageId: b,
        editorViewRef: i,
        children: [T, I]
    }), e[28] = i, e[29] = b, e[30] = y, e[31] = T, e[32] = I, e[33] = _) : _ = e[33], _
}
const pC = t => {
        "use forget";
        const e = xe.c(17);
        let s;
        e[0] !== t ? (s = Bt(t, []), e[0] = t, e[1] = s) : s = e[1];
        const n = et(),
            o = Ne();
        let r;
        e[2] === Symbol.for("react.memo_cache_sentinel") ? (r = new Set, e[2] = r) : r = e[2];
        const i = x.useRef(r);
        let l;
        e[3] === Symbol.for("react.memo_cache_sentinel") ? (l = (C, v) => {
            i.current.has(C) || (i.current.add(C), v())
        }, e[3] = l) : l = e[3];
        const c = l,
            [d, u] = x.useState(!1),
            [f, h] = x.useState(!1);
        let m;
        e[4] !== n || e[5] !== o || e[6] !== s ? (m = C => {
            const v = ju(n)(),
                g = Eu(n)();
            C === !1 && (v || g) && !window.confirm(o.formatMessage({
                id: "S9skgG",
                defaultMessage: "You have pending edits - are you sure you want to close?"
            })) || (C && c("chatgpt_writing_block_fullscreen_opened", () => {
                var E;
                return Xe.logStructuredEvent(Xm, {
                    conversationId: (E = s.conversation) == null ? void 0 : E.id,
                    messageId: s.messageId,
                    writingBlockId: s.id,
                    variant: s.variant
                })
            }), u(C))
        }, e[4] = n, e[5] = o, e[6] = s, e[7] = m) : m = e[7];
        const b = m;
        let y;
        e[8] !== d || e[9] !== b || e[10] !== f ? (y = {
            isFullscreenDialogOpen: d,
            setIsFullscreenDialogOpen: b,
            shouldBlockDialogEscapeKeyDown: f,
            setShouldBlockDialogEscapeKeyDown: h
        }, e[8] = d, e[9] = b, e[10] = f, e[11] = y) : y = e[11];
        let p;
        e[12] !== s ? (p = a.jsx(xC, F({}, s)), e[12] = s, e[13] = p) : p = e[13];
        let w;
        return e[14] !== y || e[15] !== p ? (w = a.jsx(Cu.Provider, {
            value: y,
            children: p
        }), e[14] = y, e[15] = p, e[16] = w) : w = e[16], w
    },
    xC = t => {
        "use forget";
        const e = xe.c(55),
            {
                conversation: s,
                title: n,
                originalContent: o,
                messageId: r,
                variant: i,
                recipient: l,
                subject: c,
                isStreaming: d,
                index: u,
                id: f
            } = t,
            h = et();
        let m;
        e[0] !== h ? (m = at(h, "4118263484"), e[0] = h, e[1] = m) : m = e[1];
        const b = m,
            y = Fn(Bn.EditInCanvas);
        let p;
        e[2] !== h ? (p = at(h, "669593727"), e[2] = h, e[3] = p) : p = e[3];
        const w = p;
        let C;
        e[4] !== h ? (C = at(h, "1594900112"), e[4] = h, e[5] = C) : C = e[5];
        const v = C;
        let g;
        e[6] === Symbol.for("react.memo_cache_sentinel") ? (g = sr.getItem(nr.HideWritingBlockFeedback), e[6] = g) : g = e[6];
        const [k, E] = x.useState(g);
        let j;
        e[7] === Symbol.for("react.memo_cache_sentinel") ? (j = () => {
            E(!0), sr.setItem(nr.HideWritingBlockFeedback, !0)
        }, e[7] = j) : j = e[7];
        const M = j,
            T = Fn(Bn.MagicEditEnabled);
        let N;
        e[8] !== h || e[9] !== T ? (N = at(h, "1101084612") || T, e[8] = h, e[9] = T, e[10] = N) : N = e[10];
        const I = N;
        let _;
        e[11] !== s || e[12] !== f || e[13] !== u || e[14] !== d || e[15] !== r || e[16] !== o || e[17] !== l || e[18] !== c || e[19] !== n || e[20] !== i ? (_ = {
            conversation: s,
            messageId: r,
            id: f,
            originalContent: o,
            index: u,
            variant: i,
            title: n,
            recipient: l,
            subject: c,
            isStreaming: d
        }, e[11] = s, e[12] = f, e[13] = u, e[14] = d, e[15] = r, e[16] = o, e[17] = l, e[18] = c, e[19] = n, e[20] = i, e[21] = _) : _ = e[21];
        const {
            conversation: R,
            writingBlock: A,
            contentReferences: $,
            autosaveStatus: P,
            flushPendingChanges: U,
            handleOnChange: z,
            messageRef: B,
            editorViewRef: G,
            analyticsMetadata: O,
            hasBeenEdited: H,
            isWritingBlockEditingAllowed: S,
            setDirty: V
        } = _j(_);
        if (d && i === yn.UNKNOWN && o === "") {
            let D;
            return e[22] !== G || e[23] !== r || e[24] !== B ? (D = a.jsx(Ur, {
                messageRef: B,
                messageId: r,
                editorViewRef: G,
                isStreamingPlaceholder: !0
            }), e[22] = G, e[23] = r, e[24] = B, e[25] = D) : D = e[25], D
        }
        const J = R == null ? void 0 : R.id;
        let q;
        e[26] !== O || e[27] !== P || e[28] !== $ || e[29] !== G || e[30] !== U || e[31] !== z || e[32] !== H || e[33] !== u || e[34] !== w || e[35] !== d || e[36] !== S || e[37] !== v || e[38] !== k || e[39] !== I || e[40] !== r || e[41] !== B || e[42] !== V || e[43] !== y || e[44] !== J || e[45] !== A ? (q = {
            analyticsMetadata: O,
            autosaveStatus: P,
            clientThreadId: J,
            contentReferences: $,
            editorViewRef: G,
            flushPendingChanges: U,
            hasBeenEdited: H,
            index: u,
            isInlineWritingBlockEditEnabled: S,
            isInlineWritingBlockExportEnabled: w,
            isStreaming: d,
            isWritingBlockFocusedModeEnabled: I,
            messageId: r,
            messageRef: B,
            onChange: z,
            setDirty: V,
            shouldShowWritingBlockCanvasEdit: y,
            writingBlock: A,
            isWritingBlockFeedbackEnabled: v,
            isWritingBlockFeedbackHidden: k,
            hideWritingBlockFeedback: M
        }, e[26] = O, e[27] = P, e[28] = $, e[29] = G, e[30] = U, e[31] = z, e[32] = H, e[33] = u, e[34] = w, e[35] = d, e[36] = S, e[37] = v, e[38] = k, e[39] = I, e[40] = r, e[41] = B, e[42] = V, e[43] = y, e[44] = J, e[45] = A, e[46] = q) : q = e[46];
        const Z = q;
        switch (i) {
            case yn.EMAIL:
                {
                    const D = c != null ? c : n;
                    let te;
                    return e[47] !== Z || e[48] !== l || e[49] !== D ? (te = a.jsx(fC, ce(F({}, Z), {
                        recipient: l,
                        subject: D
                    })), e[47] = Z, e[48] = l, e[49] = D, e[50] = te) : te = e[50],
                    te
                }
            default:
                {
                    let D;
                    return e[51] !== Z || e[52] !== b || e[53] !== n ? (D = b ? a.jsx(hC, F({}, Z)) : a.jsx(gC, ce(F({}, Z), {
                        title: n
                    })), e[51] = Z, e[52] = b, e[53] = n, e[54] = D) : D = e[54],
                    D
                }
        }
    },
    bC = x.memo(Or);

function yC(t) {
    "use forget";
    var E, j, M, T;
    const e = xe.c(28),
        {
            conversation: s,
            messageId: n,
            isActivelyStreaming: o,
            fallbackMarkdownComponents: r,
            content: i,
            index: l,
            id: c,
            title: d,
            variant: u,
            recipient: f,
            subject: h,
            children: m
        } = t,
        b = Fn(Bn.DisableWritingBlockRendering),
        {
            markRendered: y
        } = pj();
    let p, w;
    if (e[0] !== o || e[1] !== y ? (p = () => {
            o || y()
        }, w = [y, o], e[0] = o, e[1] = y, e[2] = p, e[3] = w) : (p = e[2], w = e[3]), x.useEffect(p, w), b) {
        const N = c != null ? c : String(l);
        let I = i;
        if (N != null && s != null && n != null) {
            let A;
            try {
                let P;
                if (e[4] !== s || e[5] !== n) {
                    const U = ed(s.id);
                    P = fs.getNode(U, n), e[4] = s, e[5] = n, e[6] = P
                } else P = e[6];
                A = P
            } catch (P) {}
            const $ = (T = (M = (j = (E = A == null ? void 0 : A.message) == null ? void 0 : E.metadata) == null ? void 0 : j.writing_blocks) == null ? void 0 : M[N]) == null ? void 0 : T.content;
            I = $ != null ? $ : I
        }
        if (!I) {
            let A;
            return e[7] !== m ? (A = a.jsx(a.Fragment, {
                children: m
            }), e[7] = m, e[8] = A) : A = e[8], A
        }
        let _;
        e[9] !== I ? (_ = ku(I), e[9] = I, e[10] = _) : _ = e[10];
        let R;
        return e[11] !== r || e[12] !== _ ? (R = a.jsx(bC, {
            components: r,
            remarkPlugins: Ki,
            rehypePlugins: Xi,
            urlTransform: Vi,
            children: _
        }), e[11] = r, e[12] = _, e[13] = R) : R = e[13], R
    }
    const C = u != null ? u : "";
    let v;
    e[14] !== C ? (v = xj(C), e[14] = C, e[15] = v) : v = e[15];
    const g = c != null ? c : String(l);
    let k;
    return e[16] !== m || e[17] !== i || e[18] !== s || e[19] !== l || e[20] !== o || e[21] !== n || e[22] !== f || e[23] !== h || e[24] !== v || e[25] !== g || e[26] !== d ? (k = a.jsx(pC, {
        conversation: s,
        messageId: n,
        title: d,
        originalContent: i,
        variant: v,
        recipient: f,
        subject: h,
        isStreaming: o,
        index: l,
        id: g,
        children: m
    }), e[16] = m, e[17] = i, e[18] = s, e[19] = l, e[20] = o, e[21] = n, e[22] = f, e[23] = h, e[24] = v, e[25] = g, e[26] = d, e[27] = k) : k = e[27], k
}

function wC(t) {
    var u;
    const d = t,
        {
            src: e,
            conversation: s,
            useSafeUrls: n
        } = d,
        o = Bt(d, ["src", "conversation", "useSafeUrls"]),
        r = Rt(() => s == null ? void 0 : s.serverId$()),
        i = x.useContext(js),
        l = (u = n != null ? n : i == null ? void 0 : i.useSafeUrls) != null ? u : !0,
        c = td(r, e, l);
    return c == null ? a.jsx("div", {}) : a.jsx("img", ce(F({}, o), {
        src: c
    }))
}

function _C(t) {
    return a.jsx(Q5, ce(F({}, t), {
        FormattedText: of
    }))
}

function of (t) {
    "use forget";
    const e = xe.c(74),
        {
            size: s,
            children: n,
            className: o,
            conversation: r,
            messageId: i,
            isActivelyStreaming: l,
            componentOverrides: c,
            isDeepResearchResultMessage: d,
            forceDarkMode: u,
            disableWordFade: f,
            useSafeUrls: h
        } = t,
        m = s === void 0 ? "medium" : s,
        b = l === void 0 ? !1 : l,
        y = et(),
        p = Fi() || u,
        {
            wordFadeType: w
        } = ug(),
        C = fg();
    let v;
    e[0] !== w ? (v = K => a.jsx(_C, F({
        wordFadeType: w
    }, K)), e[0] = w, e[1] = v) : v = e[1];
    let g;
    e[2] !== r || e[3] !== i ? (g = K => r == null ? null : a.jsx(Dx, ce(F({}, K), {
        conversation: r,
        messageId: i
    })), e[2] = r, e[3] = i, e[4] = g) : g = e[4];
    let k, E;
    e[5] !== r || e[6] !== i ? (k = K => {
        var fe, Se, je, Te;
        const ee = K,
            {
                node: oe,
                children: ye
            } = ee,
            ke = Bt(ee, ["node", "children"]),
            ie = (fe = oe == null ? void 0 : oe.properties) == null ? void 0 : fe.href;
        if (typeof ie == "string" && ie.startsWith(or)) return r != null && i != null ? a.jsx(rj, ce(F({}, ke), {
            conversation: r,
            messageId: i,
            href: ie,
            children: ye
        })) : null;
        if (typeof ie == "string" && ie === Jm) {
            if (r == null || i == null) return ye;
            const Ye = (Se = oe == null ? void 0 : oe.children) == null ? void 0 : Se.map(CC).join("").trim();
            return a.jsx(D1, ce(F({}, K), {
                text: Ye,
                conversation: r,
                messageId: i,
                className: "cursor-pointer"
            }))
        }
        if (typeof ie == "string" && ie === Qm) {
            if (r == null || i == null) return ye;
            const Ye = (je = oe == null ? void 0 : oe.children) == null ? void 0 : je.map(MC).join("").trim();
            return a.jsx(cj, ce(F({}, K), {
                text: Ye,
                conversation: r,
                messageId: i
            }))
        }
        if (typeof ie == "string" && ie === eh) {
            if (r == null || i == null) return ye;
            const Ye = (Te = oe == null ? void 0 : oe.children) == null ? void 0 : Te.map(jC).join("").trim();
            return a.jsx(fj, ce(F({}, K), {
                text: Ye,
                conversation: r,
                messageId: i
            }))
        }
        return ie && typeof ie == "string" && Ox(ie) ? ye : a.jsx(y1, ce(F({}, K), {
            messageId: i
        }))
    }, E = K => {
        const ke = K,
            {
                node: oe
            } = ke,
            ye = Bt(ke, ["node"]);
        return a.jsx(Tp, ce(F({}, ye), {
            onClickCopy: ie => {
                var fe;
                Xe.logEvent("ChatGPT Table Copy Clicked");
                const ee = r != null && i != null ? fs.getNode(ed(r.id), i).message : void 0;
                Di(bd(oe.markdownSource, (fe = ee == null ? void 0 : ee.metadata) == null ? void 0 : fe.content_references), void 0, ie)
            }
        }))
    }, e[5] = r, e[6] = i, e[7] = k, e[8] = E) : (k = e[7], E = e[8]);
    let j;
    e[9] !== C ? (j = C ? {
        h1: EC,
        h2: SC,
        h3: kC,
        li: vC
    } : {}, e[9] = C, e[10] = j) : j = e[10];
    let M;
    e[11] !== r || e[12] !== h ? (M = K => {
        var ee;
        const ie = K,
            {
                node: oe
            } = ie,
            ye = Bt(ie, ["node"]),
            ke = (ee = oe == null ? void 0 : oe.properties) == null ? void 0 : ee.src;
        return typeof ke == "string" && (ke.startsWith(or) || ke.startsWith("attachment:")) ? null : a.jsx(wC, ce(F({}, ye), {
            conversation: r,
            useSafeUrls: h
        }))
    }, e[11] = r, e[12] = h, e[13] = M) : M = e[13];
    let T;
    e[14] !== w ? (T = w === "delay" ? w1 : [], e[14] = w, e[15] = T) : T = e[15];
    let N;
    e[16] !== c ? (N = c != null ? c : {}, e[16] = c, e[17] = N) : N = e[17];
    let I;
    e[18] !== N || e[19] !== v || e[20] !== g || e[21] !== k || e[22] !== E || e[23] !== j || e[24] !== M || e[25] !== T ? (I = F(F(ce(F({
        pre: IC,
        code: TC,
        [Ym]: v,
        [mg]: g,
        [Ag]: $g,
        [Gg]: Fx,
        [Ug]: Yx,
        [Hg]: Kx,
        [zg]: Hx,
        a: k,
        table: E,
        td: Cp
    }, j), {
        img: M
    }), T), N), e[18] = N, e[19] = v, e[20] = g, e[21] = k, e[22] = E, e[23] = j, e[24] = M, e[25] = T, e[26] = I) : I = e[26];
    const _ = I;
    let R;
    e[27] !== _ || e[28] !== r || e[29] !== b || e[30] !== i ? (R = K => {
        "use forget";
        return a.jsx(yC, ce(F({}, K), {
            conversation: r,
            messageId: i,
            isActivelyStreaming: b,
            fallbackMarkdownComponents: _
        }))
    }, e[27] = _, e[28] = r, e[29] = b, e[30] = i, e[31] = R) : R = e[31];
    const A = R;
    let $;
    e[32] !== A || e[33] !== _ ? ($ = ce(F({}, _), {
        [Zm]: A
    }), e[32] = A, e[33] = _, e[34] = $) : $ = e[34];
    const P = $,
        U = at(y, "1839283687"),
        [z, B] = x.useState(!1),
        G = n != null ? n : "";
    let O;
    if (e[35] !== G || e[36] !== n || e[37] !== b) {
        const K = b && n ? O1(n) : G;
        O = _1(ku(K)), e[35] = G, e[36] = n, e[37] = b, e[38] = O
    } else O = e[38];
    const H = O;
    let S;
    e[39] !== H ? (S = hg(H), e[39] = H, e[40] = S) : S = e[40];
    const V = S;
    let J;
    e: {
        if (!z) {
            J = H;
            break e
        }
        let K;e[41] !== H ? (K = gg(H), e[41] = H, e[42] = K) : K = e[42],
        J = K
    }
    const q = J,
        Z = cd();
    let D;
    e[43] !== q ? (D = [...Xi, [ap, q]], e[43] = q, e[44] = D) : D = e[44];
    const te = D;
    let se;
    e[45] !== f || e[46] !== Z || e[47] !== w ? (se = w === "indexed" && !f ? {
        handlers: {
            text: (K, oe, ye) => {
                const ke = [];
                for (const ie of Z(oe.value)) ke.push({
                    type: "element",
                    tagName: "span",
                    properties: {
                        className: dd.fadeIn
                    },
                    children: [{
                        type: "text",
                        value: ie
                    }]
                });
                return ke
            }
        }
    } : void 0, e[45] = f, e[46] = Z, e[47] = w, e[48] = se) : se = e[48];
    const re = se;
    let X;
    e[49] === Symbol.for("react.memo_cache_sentinel") ? (X = () => {
        B(!0)
    }, e[49] = X) : X = e[49];
    const he = X;
    if (U) {
        let K;
        return e[50] !== q ? (K = !1, e[50] = q, e[51] = K) : K = e[51], K
    } else {
        let K;
        e[52] !== q ? (K = () => a.jsx(a.Fragment, {
            children: q
        }), e[52] = q, e[53] = K) : K = e[53];
        const oe = r == null ? void 0 : r.id,
            ye = p ? "dark" : "light",
            ke = m === "small" && "prose-xs",
            ie = d && "deep-research-result";
        let ee;
        e[54] !== o || e[55] !== ye || e[56] !== ke || e[57] !== ie ? (ee = W(o, "markdown prose dark:prose-invert w-full break-words", ye, ke, ie, "markdown-new-styling"), e[54] = o, e[55] = ye, e[56] = ke, e[57] = ie, e[58] = ee) : ee = e[58];
        let fe;
        e[59] !== P || e[60] !== q || e[61] !== te || e[62] !== re || e[63] !== ee ? (fe = a.jsx(rf, {
            rehypePlugins: te,
            remarkPlugins: Ki,
            remarkRehypeOptions: re,
            className: ee,
            urlTransform: Vi,
            components: P,
            children: q
        }), e[59] = P, e[60] = q, e[61] = te, e[62] = re, e[63] = ee, e[64] = fe) : fe = e[64];
        let Se;
        e[65] !== V || e[66] !== b || e[67] !== i || e[68] !== oe || e[69] !== fe ? (Se = a.jsx(eb, {
            messageId: i,
            conversationId: oe,
            isActivelyStreaming: b,
            containsWritingDirectiveInMarkdown: V,
            onMissingWritingBlock: he,
            children: fe
        }), e[65] = V, e[66] = b, e[67] = i, e[68] = oe, e[69] = fe, e[70] = Se) : Se = e[70];
        let je;
        return e[71] !== K || e[72] !== Se ? (je = a.jsx(Hc, {
            name: "formatted_text_error",
            fallback: K,
            children: Se
        }), e[71] = K, e[72] = Se, e[73] = je) : je = e[73], je
    }
}

function vC(t) {
    const n = t,
        {
            node: e
        } = n,
        s = Bt(n, ["node"]);
    return a.jsx("li", F({
        "data-section-id": Lr(e.markdownSource)
    }, s))
}

function kC(t) {
    const n = t,
        {
            node: e
        } = n,
        s = Bt(n, ["node"]);
    return a.jsx("h3", F({
        "data-section-id": Lr(e.markdownSource)
    }, s))
}

function SC(t) {
    const n = t,
        {
            node: e
        } = n,
        s = Bt(n, ["node"]);
    return a.jsx("h2", F({
        "data-section-id": Lr(e.markdownSource)
    }, s))
}

function EC(t) {
    const n = t,
        {
            node: e
        } = n,
        s = Bt(n, ["node"]);
    return a.jsx("h1", F({
        "data-section-id": Lr(e.markdownSource)
    }, s))
}

function jC(t) {
    return typeof t.value == "string" ? t.value : ""
}

function MC(t) {
    return typeof t.value == "string" ? t.value : ""
}

function CC(t) {
    return typeof t.value == "string" ? t.value : ""
}

function TC(t) {
    return a.jsx(pg, F({}, t))
}

function IC(t) {
    const {
        children: e,
        "data-start": s,
        "data-end": n,
        "data-is-last-node": o
    } = t;
    return a.jsx("pre", {
        className: "overflow-visible! px-0!",
        "data-start": s,
        "data-end": n,
        "data-is-last-node": o,
        children: e
    })
}
const rf = x.memo(Or),
    AT = Object.freeze(Object.defineProperty({
        __proto__: null,
        FormattedText: of ,
        ReactMarkdownMemo: rf
    }, Symbol.toStringTag, {
        value: "Module"
    }));
export {
    AT as F, Ix as W, G1 as c, al as p, Mx as u
};
//# sourceMappingURL=n4jvq3rx8n887kxj.js.map