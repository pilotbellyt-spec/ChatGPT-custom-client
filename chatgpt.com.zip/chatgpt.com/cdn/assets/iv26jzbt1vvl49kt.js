const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/ey0xgn20b189d7sz.js", "assets/fg33krlcm0qyi6yw.js", "assets/k6uqcdrwdyhjh2vj.js", "assets/ovpdmx71kjznjdh8.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/jjqluv6nhf16nnr9.js", "assets/iwhq2rihp0137gzf.js", "assets/k15yxxoybkkir2ou.js", "assets/conversation-small-332fs9rk.css", "assets/ce3hgmw4iyyhicud.js", "assets/coi95al0vrqe13ds.js", "assets/h1j5sazq8s0md41z.js", "assets/f76gy0b8ieo4s693.js", "assets/c2wfb3iy9wkb85gs.js", "assets/ntchvpvpq5wusw4s.js", "assets/eafv7vq0yf9bv0fi.js", "assets/comments-plugin-ivzj8m6u.css", "assets/l09h2qppleubii6l.js", "assets/codemirror-kfd8ygeu.css", "assets/eaak105t3h6pgvs1.js", "assets/o589vqy9dgmjuag5.js", "assets/bx3hw2b03xwysw4n.js", "assets/b2l059fz4znz94nm.js", "assets/gbmggnydp7mcsebl.js", "assets/1r6f1vy5gwgg645w.js", "assets/nh559o9htk2jfyt0.js", "assets/nf79rzyd6jobmpxe.js", "assets/kyjerv6rln8oin0o.js"]))) => i.map(i => d[i]);
var m = Object.defineProperty;
var a = Object.getOwnPropertySymbols;
var t = Object.prototype.hasOwnProperty,
    l = Object.prototype.propertyIsEnumerable;
var d = (o, s, e) => s in o ? m(o, s, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : o[s] = e,
    i = (o, s) => {
        for (var e in s || (s = {})) t.call(s, e) && d(o, e, s[e]);
        if (a)
            for (var e of a(s)) l.call(s, e) && d(o, e, s[e]);
        return o
    };
import {
    j as r,
    _ as n
} from "./fg33krlcm0qyi6yw.js";
import {
    C as c
} from "./ce3hgmw4iyyhicud.js";
import {
    bh as p,
    dv as x
} from "./dykg4ktvbu3mhmdo.js";
const C = p(() => n(() =>
        import ("./ey0xgn20b189d7sz.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28])).then(o => o.CodeComposer), {
        loading: () => r.jsx("div", {
            className: c.code,
            children: r.jsx("div", {
                className: "h-full w-full px-4",
                children: r.jsx(x, {
                    lines: 20
                })
            })
        })
    }),
    u = o => r.jsx(C, i({}, o));
export {
    u as A
};
//# sourceMappingURL=iv26jzbt1vvl49kt.js.map