import {
    h as i
} from "./fg33krlcm0qyi6yw.js";
import {
    i2 as o
} from "./k15yxxoybkkir2ou.js";
import {
    dO as n
} from "./dykg4ktvbu3mhmdo.js";
var e, t;

function a() {
    if (t) return e;
    t = 1;
    var u = o(),
        m = n();

    function s(r) {
        return r && r.length ? u(r, m) : 0
    }
    return e = s, e
}
var f = a();
const v = i(f);
export {
    v as s
};
//# sourceMappingURL=b31u62knn5mcc1vg.js.map