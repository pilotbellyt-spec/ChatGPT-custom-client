var te = Object.freeze,
    ae = Object.defineProperty,
    Ae = Object.defineProperties;
var _e = Object.getOwnPropertyDescriptors;
var se = Object.getOwnPropertySymbols;
var Se = Object.prototype.hasOwnProperty,
    Ee = Object.prototype.propertyIsEnumerable;
var oe = (s, e, a) => e in s ? ae(s, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: a
    }) : s[e] = a,
    V = (s, e) => {
        for (var a in e || (e = {})) Se.call(e, a) && oe(s, a, e[a]);
        if (se)
            for (var a of se(e)) Ee.call(e, a) && oe(s, a, e[a]);
        return s
    },
    le = (s, e) => Ae(s, _e(e));
var B = (s, e) => te(ae(s, "raw", {
    value: te(e || s.slice())
}));
import {
    c as Ce,
    j as o,
    e as we,
    r as J,
    f as ve,
    M as X
} from "./fg33krlcm0qyi6yw.js";
import {
    oJ as Oe,
    aL as he,
    m as Ie,
    c_ as Fe,
    b as Ne,
    aK as Be,
    _ as Pe,
    aF as ie,
    aG as ne,
    aH as Te,
    bO as ce,
    a9 as re,
    C as Ge,
    F as $
} from "./dykg4ktvbu3mhmdo.js";
import {
    fi as Le,
    fj as Ue,
    fk as ze,
    fl as De
} from "./k15yxxoybkkir2ou.js";

function Qe() {
    "use forget";
    const s = Ce.c(2),
        e = Oe(he.CookieManagement);
    let a;
    return s[0] !== e ? (a = e ? o.jsx(Re, {
        onClose: Ke
    }) : null, s[0] = e, s[1] = a) : a = s[1], a
}

function Ke() {
    Be.closeModal(he.CookieManagement)
}

function Re(s) {
    "use forget";
    var Z, ee;
    const e = Ce.c(72),
        {
            onClose: a
        } = s,
        Y = Ne(),
        t = we(),
        Q = Ie();
    let P;
    e[0] !== Y ? (P = Fe(), e[0] = Y, e[1] = P) : P = e[1];
    const c = !P,
        {
            data: r
        } = Le(),
        n = (Z = r == null ? void 0 : r.serverPrimedAllowBrowserStorageValue) != null ? Z : !1,
        q = ((ee = r == null ? void 0 : r.isStorageComplianceEnabled) != null ? ee : !1) && !c;
    let T;
    e[2] !== n || e[3] !== q ? (T = {
        serverPrimedAllowBrowserStorageValue: n,
        enabled: q
    }, e[2] = n, e[3] = q, e[4] = T) : T = e[4];
    const xe = Ue(T),
        [ye, W] = J.useState(n),
        H = c ? ye : xe,
        i = N => {
            ie.setBooleanCookie(ne.AllowNonessential, N, {
                maxAge: De,
                domain: Te
            }), c ? W(N) : be.mutateAsync({
                analytics_cookies_accepted: N
            }, {
                onSuccess() {
                    Q.success(t.formatMessage(l.updateSuccess))
                },
                onError() {
                    Q.danger(l.updateFailure, {
                        toastId: "manage_cookies_modal"
                    })
                }
            })
        };
    let G, L;
    e[5] !== c || e[6] !== n ? (G = () => {
        var N;
        if (c) {
            const je = (N = ie.getBooleanCookie(ne.AllowNonessential)) != null ? N : n;
            W(je)
        }
    }, L = [c, n], e[5] = c, e[6] = n, e[7] = G, e[8] = L) : (G = e[7], L = e[8]), J.useEffect(G, L);
    let U;
    e[9] === Symbol.for("react.memo_cache_sentinel") ? (U = [], e[9] = U) : U = e[9], J.useEffect($e, U);
    const be = ze();
    let d;
    e[10] !== t ? (d = t.formatMessage(l.title), e[10] = t, e[11] = d) : d = e[11];
    let z;
    e[12] === Symbol.for("react.memo_cache_sentinel") ? (z = o.jsx(X, le(V({}, l.description), {
        values: {
            cookiePolicy: Ve
        }
    })), e[12] = z) : z = e[12];
    let f;
    e[13] !== t ? (f = t.formatMessage(l.preference1title), e[13] = t, e[14] = f) : f = e[14];
    let u;
    e[15] !== f ? (u = o.jsx(ue, {
        children: f
    }), e[15] = f, e[16] = u) : u = e[16];
    let g;
    e[17] !== t ? (g = t.formatMessage(l.preference1desc), e[17] = t, e[18] = g) : g = e[18];
    let p;
    e[19] !== g ? (p = o.jsx(ge, {
        children: g
    }), e[19] = g, e[20] = p) : p = e[20];
    let m;
    e[21] !== u || e[22] !== p ? (m = o.jsxs(fe, {
        children: [u, p]
    }), e[21] = u, e[22] = p, e[23] = m) : m = e[23];
    let M;
    e[24] !== t ? (M = t.formatMessage(l.preference1toggle), e[24] = t, e[25] = M) : M = e[25];
    let k;
    e[26] !== M ? (k = o.jsx(ce, {
        checked: !0,
        disabled: !0,
        "aria-label": M
    }), e[26] = M, e[27] = k) : k = e[27];
    let C;
    e[28] !== m || e[29] !== k ? (C = o.jsxs(de, {
        children: [m, k]
    }), e[28] = m, e[29] = k, e[30] = C) : C = e[30];
    let h;
    e[31] !== t ? (h = t.formatMessage(l.preference2title), e[31] = t, e[32] = h) : h = e[32];
    let x;
    e[33] !== h ? (x = o.jsx(ue, {
        children: h
    }), e[33] = h, e[34] = x) : x = e[34];
    let y;
    e[35] !== t ? (y = t.formatMessage(l.preference2desc), e[35] = t, e[36] = y) : y = e[36];
    let b;
    e[37] !== y ? (b = o.jsx(ge, {
        children: y
    }), e[37] = y, e[38] = b) : b = e[38];
    let j;
    e[39] !== x || e[40] !== b ? (j = o.jsxs(fe, {
        children: [x, b]
    }), e[39] = x, e[40] = b, e[41] = j) : j = e[41];
    let A;
    e[42] !== t ? (A = t.formatMessage(l.preference2toggle), e[42] = t, e[43] = A) : A = e[43];
    let _;
    e[44] !== i || e[45] !== H || e[46] !== A ? (_ = o.jsx(ce, {
        onCheckedChange: i,
        checked: H,
        "aria-label": A
    }), e[44] = i, e[45] = H, e[46] = A, e[47] = _) : _ = e[47];
    let S;
    e[48] !== j || e[49] !== _ ? (S = o.jsxs(de, {
        children: [j, _]
    }), e[48] = j, e[49] = _, e[50] = S) : S = e[50];
    let E;
    e[51] !== i ? (E = () => i(!1), e[51] = i, e[52] = E) : E = e[52];
    let D;
    e[53] === Symbol.for("react.memo_cache_sentinel") ? (D = o.jsx(X, V({}, l.reject)), e[53] = D) : D = e[53];
    let w;
    e[54] !== E ? (w = o.jsx(re, {
        color: "secondary",
        onClick: E,
        children: D
    }), e[54] = E, e[55] = w) : w = e[55];
    let v;
    e[56] !== i ? (v = () => i(!0), e[56] = i, e[57] = v) : v = e[57];
    let K;
    e[58] === Symbol.for("react.memo_cache_sentinel") ? (K = o.jsx(X, V({}, l.accept)), e[58] = K) : K = e[58];
    let O;
    e[59] !== v ? (O = o.jsx(re, {
        color: "secondary",
        onClick: v,
        children: K
    }), e[59] = v, e[60] = O) : O = e[60];
    let I;
    e[61] !== w || e[62] !== O ? (I = o.jsxs("div", {
        className: "flex justify-end gap-3 border-t border-black/10 pt-4 dark:border-white/10",
        children: [w, O]
    }), e[61] = w, e[62] = O, e[63] = I) : I = e[63];
    let F;
    e[64] !== C || e[65] !== S || e[66] !== I ? (F = o.jsxs("div", {
        className: "text-token-text-secondary text-sm",
        children: [z, C, S, I]
    }), e[64] = C, e[65] = S, e[66] = I, e[67] = F) : F = e[67];
    let R;
    return e[68] !== a || e[69] !== F || e[70] !== d ? (R = o.jsx(Ge, {
        testId: "modal-manage-cookies",
        type: "success",
        isOpen: !0,
        onClose: a,
        title: d,
        showCloseButton: !0,
        children: F
    }), e[68] = a, e[69] = F, e[70] = d, e[71] = R) : R = e[71], R
}

function Ve(s) {
    return o.jsx("a", {
        className: "underline",
        href: "https://openai.com/policies/privacy-policy",
        children: s
    })
}

function $e() {
    Pe.addAction("privacy_policy.show_manage_cookies_modal")
}
var pe;
const de = $.div(pe || (pe = B(["flex gap-4 border-t last:border-b border-black/10 dark:border-white/10 py-4 mt-4 text-token-text-secondary"])));
var me;
const fe = $.div(me || (me = B(["flex gap-2 flex-col "])));
var Me;
const ue = $.p(Me || (Me = B(["font-semibold text-sm text-token-text-primary"])));
var ke;
const ge = $.p(ke || (ke = B(["text-xs"]))),
    l = ve({
        title: {
            id: "ManageCookiesModal.title",
            defaultMessage: "Manage cookies"
        },
        description: {
            id: "ManageCookiesModal.description",
            defaultMessage: "OpenAI uses cookies to improve your experience and analyze site traffic. For more information, read our <cookiePolicy>cookie policy</cookiePolicy>."
        },
        preference1title: {
            id: "ManageCookiesModal.preference1title",
            defaultMessage: "Essential"
        },
        preference1desc: {
            id: "ManageCookiesModal.preference1desc.0",
            defaultMessage: "These cookies are required to operate our Services. For example, they allow us to authenticate users or enable specific features within the Services, including for security purposes."
        },
        preference1toggle: {
            id: "ManageCookiesModal.preference1toggle",
            defaultMessage: "Allow essential cookies"
        },
        preference2title: {
            id: "ManageCookiesModal.preference2title",
            defaultMessage: "Analytics"
        },
        preference2desc: {
            id: "ManageCookiesModal.preference2desc.0",
            defaultMessage: "These cookies help us analyze and understand how our Services perform and are used, such as the number of users, how they interact with our Services, and time spent using the Services."
        },
        preference2toggle: {
            id: "ManageCookiesModal.preference2toggle",
            defaultMessage: "Allow analytics cookies"
        },
        reject: {
            id: "ManageCookiesModal.reject",
            defaultMessage: "Reject all"
        },
        accept: {
            id: "ManageCookiesModal.accept",
            defaultMessage: "Accept all"
        },
        updateSuccess: {
            id: "ManageCookiesModal.updateSuccess",
            defaultMessage: "Your cookie preferences were updated successfully"
        },
        updateFailure: {
            id: "ManageCookiesModal.updateFailure",
            defaultMessage: "Unable to update cookie preferences. Try again later."
        }
    });
export {
    Re as ManageCookiesModal, Qe as
    default
};
//# sourceMappingURL=glhgbnfau97gd4im.js.map