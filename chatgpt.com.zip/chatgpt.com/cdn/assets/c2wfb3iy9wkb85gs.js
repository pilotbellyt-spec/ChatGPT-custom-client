import {
    P as or,
    E as X,
    F as Z,
    b as Ke,
    V as Qe,
    R as Tt,
    g as ar,
    S as _e,
    c as Nt,
    D as H,
    G as hr,
    d as fr,
    e as me,
    f as ot,
    l as ur,
    W as It,
    h as cr,
    i as at
} from "./ovpdmx71kjznjdh8.js";
const dr = 1024;
let pr = 0;
class j {
    constructor(e, t) {
        this.from = e, this.to = t
    }
}
class k {
    constructor(e = {}) {
        this.id = pr++, this.perNode = !!e.perNode, this.deserialize = e.deserialize || (() => {
            throw new Error("This node type doesn't define a deserialize function")
        })
    }
    add(e) {
        if (this.perNode) throw new RangeError("Can't add per-node props to node types");
        return typeof e != "function" && (e = F.match(e)), t => {
            let r = e(t);
            return r === void 0 ? null : [this, r]
        }
    }
}
k.closedBy = new k({
    deserialize: i => i.split(" ")
});
k.openedBy = new k({
    deserialize: i => i.split(" ")
});
k.group = new k({
    deserialize: i => i.split(" ")
});
k.isolate = new k({
    deserialize: i => {
        if (i && i != "rtl" && i != "ltr" && i != "auto") throw new RangeError("Invalid value for isolate: " + i);
        return i || "auto"
    }
});
k.contextHash = new k({
    perNode: !0
});
k.lookAhead = new k({
    perNode: !0
});
k.mounted = new k({
    perNode: !0
});
class ke {
    constructor(e, t, r) {
        this.tree = e, this.overlay = t, this.parser = r
    }
    static get(e) {
        return e && e.props && e.props[k.mounted.id]
    }
}
const gr = Object.create(null);
class F {
    constructor(e, t, r, n = 0) {
        this.name = e, this.props = t, this.id = r, this.flags = n
    }
    static define(e) {
        let t = e.props && e.props.length ? Object.create(null) : gr,
            r = (e.top ? 1 : 0) | (e.skipped ? 2 : 0) | (e.error ? 4 : 0) | (e.name == null ? 8 : 0),
            n = new F(e.name || "", t, e.id, r);
        if (e.props) {
            for (let s of e.props)
                if (Array.isArray(s) || (s = s(n)), s) {
                    if (s[0].perNode) throw new RangeError("Can't store a per-node prop on a node type");
                    t[s[0].id] = s[1]
                }
        }
        return n
    }
    prop(e) {
        return this.props[e.id]
    }
    get isTop() {
        return (this.flags & 1) > 0
    }
    get isSkipped() {
        return (this.flags & 2) > 0
    }
    get isError() {
        return (this.flags & 4) > 0
    }
    get isAnonymous() {
        return (this.flags & 8) > 0
    }
    is(e) {
        if (typeof e == "string") {
            if (this.name == e) return !0;
            let t = this.prop(k.group);
            return t ? t.indexOf(e) > -1 : !1
        }
        return this.id == e
    }
    static match(e) {
        let t = Object.create(null);
        for (let r in e)
            for (let n of r.split(" ")) t[n] = e[r];
        return r => {
            for (let n = r.prop(k.group), s = -1; s < (n ? n.length : 0); s++) {
                let l = t[s < 0 ? r.name : n[s]];
                if (l) return l
            }
        }
    }
}
F.none = new F("", Object.create(null), 0, 8);
class Xe {
    constructor(e) {
        this.types = e;
        for (let t = 0; t < e.length; t++)
            if (e[t].id != t) throw new RangeError("Node type ids should correspond to array positions when creating a node set")
    }
    extend(...e) {
        let t = [];
        for (let r of this.types) {
            let n = null;
            for (let s of e) {
                let l = s(r);
                l && (n || (n = Object.assign({}, r.props)), n[l[0].id] = l[1])
            }
            t.push(n ? new F(r.name, n, r.id, r.flags) : r)
        }
        return new Xe(t)
    }
}
const ve = new WeakMap,
    ht = new WeakMap;
var I;
(function(i) {
    i[i.ExcludeBuffers = 1] = "ExcludeBuffers", i[i.IncludeAnonymous = 2] = "IncludeAnonymous", i[i.IgnoreMounts = 4] = "IgnoreMounts", i[i.IgnoreOverlays = 8] = "IgnoreOverlays"
})(I || (I = {}));
class C {
    constructor(e, t, r, n, s) {
        if (this.type = e, this.children = t, this.positions = r, this.length = n, this.props = null, s && s.length) {
            this.props = Object.create(null);
            for (let [l, o] of s) this.props[typeof l == "number" ? l : l.id] = o
        }
    }
    toString() {
        let e = ke.get(this);
        if (e && !e.overlay) return e.tree.toString();
        let t = "";
        for (let r of this.children) {
            let n = r.toString();
            n && (t && (t += ","), t += n)
        }
        return this.type.name ? (/\W/.test(this.type.name) && !this.type.isError ? JSON.stringify(this.type.name) : this.type.name) + (t.length ? "(" + t + ")" : "") : t
    }
    cursor(e = 0) {
        return new Ie(this.topNode, e)
    }
    cursorAt(e, t = 0, r = 0) {
        let n = ve.get(this) || this.topNode,
            s = new Ie(n);
        return s.moveTo(e, t), ve.set(this, s._tree), s
    }
    get topNode() {
        return new _(this, 0, 0, null)
    }
    resolve(e, t = 0) {
        let r = be(ve.get(this) || this.topNode, e, t, !1);
        return ve.set(this, r), r
    }
    resolveInner(e, t = 0) {
        let r = be(ht.get(this) || this.topNode, e, t, !0);
        return ht.set(this, r), r
    }
    resolveStack(e, t = 0) {
        return br(this, e, t)
    }
    iterate(e) {
        let {
            enter: t,
            leave: r,
            from: n = 0,
            to: s = this.length
        } = e, l = e.mode || 0, o = (l & I.IncludeAnonymous) > 0;
        for (let a = this.cursor(l | I.IncludeAnonymous);;) {
            let h = !1;
            if (a.from <= s && a.to >= n && (!o && a.type.isAnonymous || t(a) !== !1)) {
                if (a.firstChild()) continue;
                h = !0
            }
            for (; h && r && (o || !a.type.isAnonymous) && r(a), !a.nextSibling();) {
                if (!a.parent()) return;
                h = !0
            }
        }
    }
    prop(e) {
        return e.perNode ? this.props ? this.props[e.id] : void 0 : this.type.prop(e)
    }
    get propValues() {
        let e = [];
        if (this.props)
            for (let t in this.props) e.push([+t, this.props[t]]);
        return e
    }
    balance(e = {}) {
        return this.children.length <= 8 ? this : et(F.none, this.children, this.positions, 0, this.children.length, 0, this.length, (t, r, n) => new C(this.type, t, r, n, this.propValues), e.makeTree || ((t, r, n) => new C(F.none, t, r, n)))
    }
    static build(e) {
        return yr(e)
    }
}
C.empty = new C(F.none, [], [], 0);
class Ye {
    constructor(e, t) {
        this.buffer = e, this.index = t
    }
    get id() {
        return this.buffer[this.index - 4]
    }
    get start() {
        return this.buffer[this.index - 3]
    }
    get end() {
        return this.buffer[this.index - 2]
    }
    get size() {
        return this.buffer[this.index - 1]
    }
    get pos() {
        return this.index
    }
    next() {
        this.index -= 4
    }
    fork() {
        return new Ye(this.buffer, this.index)
    }
}
class re {
    constructor(e, t, r) {
        this.buffer = e, this.length = t, this.set = r
    }
    get type() {
        return F.none
    }
    toString() {
        let e = [];
        for (let t = 0; t < this.buffer.length;) e.push(this.childString(t)), t = this.buffer[t + 3];
        return e.join(",")
    }
    childString(e) {
        let t = this.buffer[e],
            r = this.buffer[e + 3],
            n = this.set.types[t],
            s = n.name;
        if (/\W/.test(s) && !n.isError && (s = JSON.stringify(s)), e += 4, r == e) return s;
        let l = [];
        for (; e < r;) l.push(this.childString(e)), e = this.buffer[e + 3];
        return s + "(" + l.join(",") + ")"
    }
    findChild(e, t, r, n, s) {
        let {
            buffer: l
        } = this, o = -1;
        for (let a = e; a != t && !(Bt(s, n, l[a + 1], l[a + 2]) && (o = a, r > 0)); a = l[a + 3]);
        return o
    }
    slice(e, t, r) {
        let n = this.buffer,
            s = new Uint16Array(t - e),
            l = 0;
        for (let o = e, a = 0; o < t;) {
            s[a++] = n[o++], s[a++] = n[o++] - r;
            let h = s[a++] = n[o++] - r;
            s[a++] = n[o++] - e, l = Math.max(l, h)
        }
        return new re(s, l, this.set)
    }
}

function Bt(i, e, t, r) {
    switch (i) {
        case -2:
            return t < e;
        case -1:
            return r >= e && t < e;
        case 0:
            return t < e && r > e;
        case 1:
            return t <= e && r > e;
        case 2:
            return r > e;
        case 4:
            return !0
    }
}

function be(i, e, t, r) {
    for (var n; i.from == i.to || (t < 1 ? i.from >= e : i.from > e) || (t > -1 ? i.to <= e : i.to < e);) {
        let l = !r && i instanceof _ && i.index < 0 ? null : i.parent;
        if (!l) return i;
        i = l
    }
    let s = r ? 0 : I.IgnoreOverlays;
    if (r)
        for (let l = i, o = l.parent; o; l = o, o = l.parent) l instanceof _ && l.index < 0 && ((n = o.enter(e, t, s)) === null || n === void 0 ? void 0 : n.from) != l.from && (i = o);
    for (;;) {
        let l = i.enter(e, t, s);
        if (!l) return i;
        i = l
    }
}
class Mt {
    cursor(e = 0) {
        return new Ie(this, e)
    }
    getChild(e, t = null, r = null) {
        let n = ft(this, e, t, r);
        return n.length ? n[0] : null
    }
    getChildren(e, t = null, r = null) {
        return ft(this, e, t, r)
    }
    resolve(e, t = 0) {
        return be(this, e, t, !1)
    }
    resolveInner(e, t = 0) {
        return be(this, e, t, !0)
    }
    matchContext(e) {
        return He(this, e)
    }
    enterUnfinishedNodesBefore(e) {
        let t = this.childBefore(e),
            r = this;
        for (; t;) {
            let n = t.lastChild;
            if (!n || n.to != t.to) break;
            n.type.isError && n.from == n.to ? (r = t, t = n.prevSibling) : t = n
        }
        return r
    }
    get node() {
        return this
    }
    get next() {
        return this.parent
    }
}
class _ extends Mt {
    constructor(e, t, r, n) {
        super(), this._tree = e, this.from = t, this.index = r, this._parent = n
    }
    get type() {
        return this._tree.type
    }
    get name() {
        return this._tree.type.name
    }
    get to() {
        return this.from + this._tree.length
    }
    nextChild(e, t, r, n, s = 0) {
        for (let l = this;;) {
            for (let {
                    children: o,
                    positions: a
                } = l._tree, h = t > 0 ? o.length : -1; e != h; e += t) {
                let f = o[e],
                    u = a[e] + l.from;
                if (Bt(n, r, u, u + f.length)) {
                    if (f instanceof re) {
                        if (s & I.ExcludeBuffers) continue;
                        let d = f.findChild(0, f.buffer.length, t, r - u, n);
                        if (d > -1) return new K(new mr(l, f, e, u), null, d)
                    } else if (s & I.IncludeAnonymous || !f.type.isAnonymous || Ze(f)) {
                        let d;
                        if (!(s & I.IgnoreMounts) && (d = ke.get(f)) && !d.overlay) return new _(d.tree, u, e, l);
                        let p = new _(f, u, e, l);
                        return s & I.IncludeAnonymous || !p.type.isAnonymous ? p : p.nextChild(t < 0 ? f.children.length - 1 : 0, t, r, n)
                    }
                }
            }
            if (s & I.IncludeAnonymous || !l.type.isAnonymous || (l.index >= 0 ? e = l.index + t : e = t < 0 ? -1 : l._parent._tree.children.length, l = l._parent, !l)) return null
        }
    }
    get firstChild() {
        return this.nextChild(0, 1, 0, 4)
    }
    get lastChild() {
        return this.nextChild(this._tree.children.length - 1, -1, 0, 4)
    }
    childAfter(e) {
        return this.nextChild(0, 1, e, 2)
    }
    childBefore(e) {
        return this.nextChild(this._tree.children.length - 1, -1, e, -2)
    }
    enter(e, t, r = 0) {
        let n;
        if (!(r & I.IgnoreOverlays) && (n = ke.get(this._tree)) && n.overlay) {
            let s = e - this.from;
            for (let {
                    from: l,
                    to: o
                } of n.overlay)
                if ((t > 0 ? l <= s : l < s) && (t < 0 ? o >= s : o > s)) return new _(n.tree, n.overlay[0].from + this.from, -1, this)
        }
        return this.nextChild(0, 1, e, t, r)
    }
    nextSignificantParent() {
        let e = this;
        for (; e.type.isAnonymous && e._parent;) e = e._parent;
        return e
    }
    get parent() {
        return this._parent ? this._parent.nextSignificantParent() : null
    }
    get nextSibling() {
        return this._parent && this.index >= 0 ? this._parent.nextChild(this.index + 1, 1, 0, 4) : null
    }
    get prevSibling() {
        return this._parent && this.index >= 0 ? this._parent.nextChild(this.index - 1, -1, 0, 4) : null
    }
    get tree() {
        return this._tree
    }
    toTree() {
        return this._tree
    }
    toString() {
        return this._tree.toString()
    }
}

function ft(i, e, t, r) {
    let n = i.cursor(),
        s = [];
    if (!n.firstChild()) return s;
    if (t != null) {
        for (let l = !1; !l;)
            if (l = n.type.is(t), !n.nextSibling()) return s
    }
    for (;;) {
        if (r != null && n.type.is(r)) return s;
        if (n.type.is(e) && s.push(n.node), !n.nextSibling()) return r == null ? s : []
    }
}

function He(i, e, t = e.length - 1) {
    for (let r = i.parent; t >= 0; r = r.parent) {
        if (!r) return !1;
        if (!r.type.isAnonymous) {
            if (e[t] && e[t] != r.name) return !1;
            t--
        }
    }
    return !0
}
class mr {
    constructor(e, t, r, n) {
        this.parent = e, this.buffer = t, this.index = r, this.start = n
    }
}
class K extends Mt {
    get name() {
        return this.type.name
    }
    get from() {
        return this.context.start + this.context.buffer.buffer[this.index + 1]
    }
    get to() {
        return this.context.start + this.context.buffer.buffer[this.index + 2]
    }
    constructor(e, t, r) {
        super(), this.context = e, this._parent = t, this.index = r, this.type = e.buffer.set.types[e.buffer.buffer[r]]
    }
    child(e, t, r) {
        let {
            buffer: n
        } = this.context, s = n.findChild(this.index + 4, n.buffer[this.index + 3], e, t - this.context.start, r);
        return s < 0 ? null : new K(this.context, this, s)
    }
    get firstChild() {
        return this.child(1, 0, 4)
    }
    get lastChild() {
        return this.child(-1, 0, 4)
    }
    childAfter(e) {
        return this.child(1, e, 2)
    }
    childBefore(e) {
        return this.child(-1, e, -2)
    }
    enter(e, t, r = 0) {
        if (r & I.ExcludeBuffers) return null;
        let {
            buffer: n
        } = this.context, s = n.findChild(this.index + 4, n.buffer[this.index + 3], t > 0 ? 1 : -1, e - this.context.start, t);
        return s < 0 ? null : new K(this.context, this, s)
    }
    get parent() {
        return this._parent || this.context.parent.nextSignificantParent()
    }
    externalSibling(e) {
        return this._parent ? null : this.context.parent.nextChild(this.context.index + e, e, 0, 4)
    }
    get nextSibling() {
        let {
            buffer: e
        } = this.context, t = e.buffer[this.index + 3];
        return t < (this._parent ? e.buffer[this._parent.index + 3] : e.buffer.length) ? new K(this.context, this._parent, t) : this.externalSibling(1)
    }
    get prevSibling() {
        let {
            buffer: e
        } = this.context, t = this._parent ? this._parent.index + 4 : 0;
        return this.index == t ? this.externalSibling(-1) : new K(this.context, this._parent, e.findChild(t, this.index, -1, 0, 4))
    }
    get tree() {
        return null
    }
    toTree() {
        let e = [],
            t = [],
            {
                buffer: r
            } = this.context,
            n = this.index + 4,
            s = r.buffer[this.index + 3];
        if (s > n) {
            let l = r.buffer[this.index + 1];
            e.push(r.slice(n, s, l)), t.push(0)
        }
        return new C(this.type, e, t, this.to - this.from)
    }
    toString() {
        return this.context.buffer.childString(this.index)
    }
}

function Ot(i) {
    if (!i.length) return null;
    let e = 0,
        t = i[0];
    for (let s = 1; s < i.length; s++) {
        let l = i[s];
        (l.from > t.from || l.to < t.to) && (t = l, e = s)
    }
    let r = t instanceof _ && t.index < 0 ? null : t.parent,
        n = i.slice();
    return r ? n[e] = r : n.splice(e, 1), new kr(n, t)
}
class kr {
    constructor(e, t) {
        this.heads = e, this.node = t
    }
    get next() {
        return Ot(this.heads)
    }
}

function br(i, e, t) {
    let r = i.resolveInner(e, t),
        n = null;
    for (let s = r instanceof _ ? r : r.context.parent; s; s = s.parent)
        if (s.index < 0) {
            let l = s.parent;
            (n || (n = [r])).push(l.resolve(e, t)), s = l
        } else {
            let l = ke.get(s.tree);
            if (l && l.overlay && l.overlay[0].from <= e && l.overlay[l.overlay.length - 1].to >= e) {
                let o = new _(l.tree, l.overlay[0].from + s.from, -1, s);
                (n || (n = [r])).push(be(o, e, t, !1))
            }
        }
    return n ? Ot(n) : r
}
class Ie {
    get name() {
        return this.type.name
    }
    constructor(e, t = 0) {
        if (this.mode = t, this.buffer = null, this.stack = [], this.index = 0, this.bufferNode = null, e instanceof _) this.yieldNode(e);
        else {
            this._tree = e.context.parent, this.buffer = e.context;
            for (let r = e._parent; r; r = r._parent) this.stack.unshift(r.index);
            this.bufferNode = e, this.yieldBuf(e.index)
        }
    }
    yieldNode(e) {
        return e ? (this._tree = e, this.type = e.type, this.from = e.from, this.to = e.to, !0) : !1
    }
    yieldBuf(e, t) {
        this.index = e;
        let {
            start: r,
            buffer: n
        } = this.buffer;
        return this.type = t || n.set.types[n.buffer[e]], this.from = r + n.buffer[e + 1], this.to = r + n.buffer[e + 2], !0
    }
    yield(e) {
        return e ? e instanceof _ ? (this.buffer = null, this.yieldNode(e)) : (this.buffer = e.context, this.yieldBuf(e.index, e.type)) : !1
    }
    toString() {
        return this.buffer ? this.buffer.buffer.childString(this.index) : this._tree.toString()
    }
    enterChild(e, t, r) {
        if (!this.buffer) return this.yield(this._tree.nextChild(e < 0 ? this._tree._tree.children.length - 1 : 0, e, t, r, this.mode));
        let {
            buffer: n
        } = this.buffer, s = n.findChild(this.index + 4, n.buffer[this.index + 3], e, t - this.buffer.start, r);
        return s < 0 ? !1 : (this.stack.push(this.index), this.yieldBuf(s))
    }
    firstChild() {
        return this.enterChild(1, 0, 4)
    }
    lastChild() {
        return this.enterChild(-1, 0, 4)
    }
    childAfter(e) {
        return this.enterChild(1, e, 2)
    }
    childBefore(e) {
        return this.enterChild(-1, e, -2)
    }
    enter(e, t, r = this.mode) {
        return this.buffer ? r & I.ExcludeBuffers ? !1 : this.enterChild(1, e, t) : this.yield(this._tree.enter(e, t, r))
    }
    parent() {
        if (!this.buffer) return this.yieldNode(this.mode & I.IncludeAnonymous ? this._tree._parent : this._tree.parent);
        if (this.stack.length) return this.yieldBuf(this.stack.pop());
        let e = this.mode & I.IncludeAnonymous ? this.buffer.parent : this.buffer.parent.nextSignificantParent();
        return this.buffer = null, this.yieldNode(e)
    }
    sibling(e) {
        if (!this.buffer) return this._tree._parent ? this.yield(this._tree.index < 0 ? null : this._tree._parent.nextChild(this._tree.index + e, e, 0, 4, this.mode)) : !1;
        let {
            buffer: t
        } = this.buffer, r = this.stack.length - 1;
        if (e < 0) {
            let n = r < 0 ? 0 : this.stack[r] + 4;
            if (this.index != n) return this.yieldBuf(t.findChild(n, this.index, -1, 0, 4))
        } else {
            let n = t.buffer[this.index + 3];
            if (n < (r < 0 ? t.buffer.length : t.buffer[this.stack[r] + 3])) return this.yieldBuf(n)
        }
        return r < 0 ? this.yield(this.buffer.parent.nextChild(this.buffer.index + e, e, 0, 4, this.mode)) : !1
    }
    nextSibling() {
        return this.sibling(1)
    }
    prevSibling() {
        return this.sibling(-1)
    }
    atLastNode(e) {
        let t, r, {
            buffer: n
        } = this;
        if (n) {
            if (e > 0) {
                if (this.index < n.buffer.buffer.length) return !1
            } else
                for (let s = 0; s < this.index; s++)
                    if (n.buffer.buffer[s + 3] < this.index) return !1;
            ({
                index: t,
                parent: r
            } = n)
        } else({
            index: t,
            _parent: r
        } = this._tree);
        for (; r; {
                index: t,
                _parent: r
            } = r)
            if (t > -1)
                for (let s = t + e, l = e < 0 ? -1 : r._tree.children.length; s != l; s += e) {
                    let o = r._tree.children[s];
                    if (this.mode & I.IncludeAnonymous || o instanceof re || !o.type.isAnonymous || Ze(o)) return !1
                }
        return !0
    }
    move(e, t) {
        if (t && this.enterChild(e, 0, 4)) return !0;
        for (;;) {
            if (this.sibling(e)) return !0;
            if (this.atLastNode(e) || !this.parent()) return !1
        }
    }
    next(e = !0) {
        return this.move(1, e)
    }
    prev(e = !0) {
        return this.move(-1, e)
    }
    moveTo(e, t = 0) {
        for (;
            (this.from == this.to || (t < 1 ? this.from >= e : this.from > e) || (t > -1 ? this.to <= e : this.to < e)) && this.parent(););
        for (; this.enterChild(1, e, t););
        return this
    }
    get node() {
        if (!this.buffer) return this._tree;
        let e = this.bufferNode,
            t = null,
            r = 0;
        if (e && e.context == this.buffer) e: for (let n = this.index, s = this.stack.length; s >= 0;) {
            for (let l = e; l; l = l._parent)
                if (l.index == n) {
                    if (n == this.index) return l;
                    t = l, r = s + 1;
                    break e
                }
            n = this.stack[--s]
        }
        for (let n = r; n < this.stack.length; n++) t = new K(this.buffer, t, this.stack[n]);
        return this.bufferNode = new K(this.buffer, t, this.index)
    }
    get tree() {
        return this.buffer ? null : this._tree._tree
    }
    iterate(e, t) {
        for (let r = 0;;) {
            let n = !1;
            if (this.type.isAnonymous || e(this) !== !1) {
                if (this.firstChild()) {
                    r++;
                    continue
                }
                this.type.isAnonymous || (n = !0)
            }
            for (; n && t && t(this), n = this.type.isAnonymous, !this.nextSibling();) {
                if (!r) return;
                this.parent(), r--, n = !0
            }
        }
    }
    matchContext(e) {
        if (!this.buffer) return He(this.node, e);
        let {
            buffer: t
        } = this.buffer, {
            types: r
        } = t.set;
        for (let n = e.length - 1, s = this.stack.length - 1; n >= 0; s--) {
            if (s < 0) return He(this.node, e, n);
            let l = r[t.buffer[this.stack[s]]];
            if (!l.isAnonymous) {
                if (e[n] && e[n] != l.name) return !1;
                n--
            }
        }
        return !0
    }
}

function Ze(i) {
    return i.children.some(e => e instanceof re || !e.type.isAnonymous || Ze(e))
}

function yr(i) {
    var e;
    let {
        buffer: t,
        nodeSet: r,
        maxBufferLength: n = dr,
        reused: s = [],
        minRepeatType: l = r.types.length
    } = i, o = Array.isArray(t) ? new Ye(t, t.length) : t, a = r.types, h = 0, f = 0;

    function u(w, P, g, B, A, v) {
        let {
            id: b,
            start: y,
            end: M,
            size: N
        } = o, R = f;
        for (; N < 0;)
            if (o.next(), N == -1) {
                let Q = s[b];
                g.push(Q), B.push(y - w);
                return
            } else if (N == -3) {
            h = b;
            return
        } else if (N == -4) {
            f = b;
            return
        } else throw new RangeError("Unrecognized record size: ".concat(N));
        let ie = a[b],
            fe, se, st = y - w;
        if (M - y <= n && (se = D(o.pos - P, A))) {
            let Q = new Uint16Array(se.size - se.skip),
                L = o.pos - se.size,
                V = Q.length;
            for (; o.pos > L;) V = O(se.start, Q, V);
            fe = new re(Q, M - se.start, r), st = se.start - w
        } else {
            let Q = o.pos - N;
            o.next();
            let L = [],
                V = [],
                le = b >= l ? b : -1,
                ue = 0,
                we = M;
            for (; o.pos > Q;) le >= 0 && o.id == le && o.size >= 0 ? (o.end <= we - n && (x(L, V, y, ue, o.end, we, le, R), ue = L.length, we = o.end), o.next()) : v > 2500 ? d(y, Q, L, V) : u(y, Q, L, V, le, v + 1);
            if (le >= 0 && ue > 0 && ue < L.length && x(L, V, y, ue, y, we, le, R), L.reverse(), V.reverse(), le > -1 && ue > 0) {
                let lt = p(ie);
                fe = et(ie, L, V, 0, L.length, 0, M - y, lt, lt)
            } else fe = S(ie, L, V, M - y, R - M)
        }
        g.push(fe), B.push(st)
    }

    function d(w, P, g, B) {
        let A = [],
            v = 0,
            b = -1;
        for (; o.pos > P;) {
            let {
                id: y,
                start: M,
                end: N,
                size: R
            } = o;
            if (R > 4) o.next();
            else {
                if (b > -1 && M < b) break;
                b < 0 && (b = N - n), A.push(y, M, N), v++, o.next()
            }
        }
        if (v) {
            let y = new Uint16Array(v * 4),
                M = A[A.length - 2];
            for (let N = A.length - 3, R = 0; N >= 0; N -= 3) y[R++] = A[N], y[R++] = A[N + 1] - M, y[R++] = A[N + 2] - M, y[R++] = R;
            g.push(new re(y, A[2] - M, r)), B.push(M - w)
        }
    }

    function p(w) {
        return (P, g, B) => {
            let A = 0,
                v = P.length - 1,
                b, y;
            if (v >= 0 && (b = P[v]) instanceof C) {
                if (!v && b.type == w && b.length == B) return b;
                (y = b.prop(k.lookAhead)) && (A = g[v] + b.length + y)
            }
            return S(w, P, g, B, A)
        }
    }

    function x(w, P, g, B, A, v, b, y) {
        let M = [],
            N = [];
        for (; w.length > B;) M.push(w.pop()), N.push(P.pop() + g - A);
        w.push(S(r.types[b], M, N, v - A, y - v)), P.push(A - g)
    }

    function S(w, P, g, B, A = 0, v) {
        if (h) {
            let b = [k.contextHash, h];
            v = v ? [b].concat(v) : [b]
        }
        if (A > 25) {
            let b = [k.lookAhead, A];
            v = v ? [b].concat(v) : [b]
        }
        return new C(w, P, g, B, v)
    }

    function D(w, P) {
        let g = o.fork(),
            B = 0,
            A = 0,
            v = 0,
            b = g.end - n,
            y = {
                size: 0,
                start: 0,
                skip: 0
            };
        e: for (let M = g.pos - w; g.pos > M;) {
            let N = g.size;
            if (g.id == P && N >= 0) {
                y.size = B, y.start = A, y.skip = v, v += 4, B += 4, g.next();
                continue
            }
            let R = g.pos - N;
            if (N < 0 || R < M || g.start < b) break;
            let ie = g.id >= l ? 4 : 0,
                fe = g.start;
            for (g.next(); g.pos > R;) {
                if (g.size < 0)
                    if (g.size == -3) ie += 4;
                    else break e;
                else g.id >= l && (ie += 4);
                g.next()
            }
            A = fe, B += N, v += ie
        }
        return (P < 0 || B == w) && (y.size = B, y.start = A, y.skip = v), y.size > 4 ? y : void 0
    }

    function O(w, P, g) {
        let {
            id: B,
            start: A,
            end: v,
            size: b
        } = o;
        if (o.next(), b >= 0 && B < l) {
            let y = g;
            if (b > 4) {
                let M = o.pos - (b - 4);
                for (; o.pos > M;) g = O(w, P, g)
            }
            P[--g] = y, P[--g] = v - w, P[--g] = A - w, P[--g] = B
        } else b == -3 ? h = B : b == -4 && (f = B);
        return g
    }
    let E = [],
        T = [];
    for (; o.pos > 0;) u(i.start || 0, i.bufferStart || 0, E, T, -1, 0);
    let z = (e = i.length) !== null && e !== void 0 ? e : E.length ? T[0] + E[0].length : 0;
    return new C(a[i.topID], E.reverse(), T.reverse(), z)
}
const ut = new WeakMap;

function Te(i, e) {
    if (!i.isAnonymous || e instanceof re || e.type != i) return 1;
    let t = ut.get(e);
    if (t == null) {
        t = 1;
        for (let r of e.children) {
            if (r.type != i || !(r instanceof C)) {
                t = 1;
                break
            }
            t += Te(i, r)
        }
        ut.set(e, t)
    }
    return t
}

function et(i, e, t, r, n, s, l, o, a) {
    let h = 0;
    for (let x = r; x < n; x++) h += Te(i, e[x]);
    let f = Math.ceil(h * 1.5 / 8),
        u = [],
        d = [];

    function p(x, S, D, O, E) {
        for (let T = D; T < O;) {
            let z = T,
                w = S[T],
                P = Te(i, x[T]);
            for (T++; T < O; T++) {
                let g = Te(i, x[T]);
                if (P + g >= f) break;
                P += g
            }
            if (T == z + 1) {
                if (P > f) {
                    let g = x[z];
                    p(g.children, g.positions, 0, g.children.length, S[z] + E);
                    continue
                }
                u.push(x[z])
            } else {
                let g = S[T - 1] + x[T - 1].length - w;
                u.push(et(i, x, S, z, T, w, g, null, a))
            }
            d.push(w + E - s)
        }
    }
    return p(e, t, r, n, 0), (o || a)(u, d, l)
}
class Nn {
    constructor() {
        this.map = new WeakMap
    }
    setBuffer(e, t, r) {
        let n = this.map.get(e);
        n || this.map.set(e, n = new Map), n.set(t, r)
    }
    getBuffer(e, t) {
        let r = this.map.get(e);
        return r && r.get(t)
    }
    set(e, t) {
        e instanceof K ? this.setBuffer(e.context.buffer, e.index, t) : e instanceof _ && this.map.set(e.tree, t)
    }
    get(e) {
        return e instanceof K ? this.getBuffer(e.context.buffer, e.index) : e instanceof _ ? this.map.get(e.tree) : void 0
    }
    cursorSet(e, t) {
        e.buffer ? this.setBuffer(e.buffer.buffer, e.index, t) : this.map.set(e.tree, t)
    }
    cursorGet(e) {
        return e.buffer ? this.getBuffer(e.buffer.buffer, e.index) : this.map.get(e.tree)
    }
}
class Y {
    constructor(e, t, r, n, s = !1, l = !1) {
        this.from = e, this.to = t, this.tree = r, this.offset = n, this.open = (s ? 1 : 0) | (l ? 2 : 0)
    }
    get openStart() {
        return (this.open & 1) > 0
    }
    get openEnd() {
        return (this.open & 2) > 0
    }
    static addTree(e, t = [], r = !1) {
        let n = [new Y(0, e.length, e, 0, !1, r)];
        for (let s of t) s.to > e.length && n.push(s);
        return n
    }
    static applyChanges(e, t, r = 128) {
        if (!t.length) return e;
        let n = [],
            s = 1,
            l = e.length ? e[0] : null;
        for (let o = 0, a = 0, h = 0;; o++) {
            let f = o < t.length ? t[o] : null,
                u = f ? f.fromA : 1e9;
            if (u - a >= r)
                for (; l && l.from < u;) {
                    let d = l;
                    if (a >= d.from || u <= d.to || h) {
                        let p = Math.max(d.from, a) - h,
                            x = Math.min(d.to, u) - h;
                        d = p >= x ? null : new Y(p, x, d.tree, d.offset + h, o > 0, !!f)
                    }
                    if (d && n.push(d), l.to > u) break;
                    l = s < e.length ? e[s++] : null
                }
            if (!f) break;
            a = f.toA, h = f.toA - f.toB
        }
        return n
    }
}
class Dt {
    startParse(e, t, r) {
        return typeof e == "string" && (e = new xr(e)), r = r ? r.length ? r.map(n => new j(n.from, n.to)) : [new j(0, 0)] : [new j(0, e.length)], this.createParse(e, t || [], r)
    }
    parse(e, t, r) {
        let n = this.startParse(e, t, r);
        for (;;) {
            let s = n.advance();
            if (s) return s
        }
    }
}
class xr {
    constructor(e) {
        this.string = e
    }
    get length() {
        return this.string.length
    }
    chunk(e) {
        return this.string.slice(e)
    }
    get lineChunks() {
        return !1
    }
    read(e, t) {
        return this.string.slice(e, t)
    }
}

function In(i) {
    return (e, t, r, n) => new vr(e, i, t, r, n)
}
class ct {
    constructor(e, t, r, n, s) {
        this.parser = e, this.parse = t, this.overlay = r, this.target = n, this.from = s
    }
}

function dt(i) {
    if (!i.length || i.some(e => e.from >= e.to)) throw new RangeError("Invalid inner parse ranges given: " + JSON.stringify(i))
}
class wr {
    constructor(e, t, r, n, s, l, o) {
        this.parser = e, this.predicate = t, this.mounts = r, this.index = n, this.start = s, this.target = l, this.prev = o, this.depth = 0, this.ranges = []
    }
}
const Ue = new k({
    perNode: !0
});
class vr {
    constructor(e, t, r, n, s) {
        this.nest = t, this.input = r, this.fragments = n, this.ranges = s, this.inner = [], this.innerDone = 0, this.baseTree = null, this.stoppedAt = null, this.baseParse = e
    }
    advance() {
        if (this.baseParse) {
            let r = this.baseParse.advance();
            if (!r) return null;
            if (this.baseParse = null, this.baseTree = r, this.startInner(), this.stoppedAt != null)
                for (let n of this.inner) n.parse.stopAt(this.stoppedAt)
        }
        if (this.innerDone == this.inner.length) {
            let r = this.baseTree;
            return this.stoppedAt != null && (r = new C(r.type, r.children, r.positions, r.length, r.propValues.concat([
                [Ue, this.stoppedAt]
            ]))), r
        }
        let e = this.inner[this.innerDone],
            t = e.parse.advance();
        if (t) {
            this.innerDone++;
            let r = Object.assign(Object.create(null), e.target.props);
            r[k.mounted.id] = new ke(t, e.overlay, e.parser), e.target.props = r
        }
        return null
    }
    get parsedPos() {
        if (this.baseParse) return 0;
        let e = this.input.length;
        for (let t = this.innerDone; t < this.inner.length; t++) this.inner[t].from < e && (e = Math.min(e, this.inner[t].parse.parsedPos));
        return e
    }
    stopAt(e) {
        if (this.stoppedAt = e, this.baseParse) this.baseParse.stopAt(e);
        else
            for (let t = this.innerDone; t < this.inner.length; t++) this.inner[t].parse.stopAt(e)
    }
    startInner() {
        let e = new Cr(this.fragments),
            t = null,
            r = null,
            n = new Ie(new _(this.baseTree, this.ranges[0].from, 0, null), I.IncludeAnonymous | I.IgnoreMounts);
        e: for (let s, l;;) {
            let o = !0,
                a;
            if (this.stoppedAt != null && n.from >= this.stoppedAt) o = !1;
            else if (e.hasNode(n)) {
                if (t) {
                    let h = t.mounts.find(f => f.frag.from <= n.from && f.frag.to >= n.to && f.mount.overlay);
                    if (h)
                        for (let f of h.mount.overlay) {
                            let u = f.from + h.pos,
                                d = f.to + h.pos;
                            u >= n.from && d <= n.to && !t.ranges.some(p => p.from < d && p.to > u) && t.ranges.push({
                                from: u,
                                to: d
                            })
                        }
                }
                o = !1
            } else if (r && (l = Sr(r.ranges, n.from, n.to))) o = l != 2;
            else if (!n.type.isAnonymous && (s = this.nest(n, this.input)) && (n.from < n.to || !s.overlay)) {
                n.tree || Ar(n);
                let h = e.findMounts(n.from, s.parser);
                if (typeof s.overlay == "function") t = new wr(s.parser, s.overlay, h, this.inner.length, n.from, n.tree, t);
                else {
                    let f = mt(this.ranges, s.overlay || (n.from < n.to ? [new j(n.from, n.to)] : []));
                    f.length && dt(f), (f.length || !s.overlay) && this.inner.push(new ct(s.parser, f.length ? s.parser.startParse(this.input, kt(h, f), f) : s.parser.startParse(""), s.overlay ? s.overlay.map(u => new j(u.from - n.from, u.to - n.from)) : null, n.tree, f.length ? f[0].from : n.from)), s.overlay ? f.length && (r = {
                        ranges: f,
                        depth: 0,
                        prev: r
                    }) : o = !1
                }
            } else t && (a = t.predicate(n)) && (a === !0 && (a = new j(n.from, n.to)), a.from < a.to && t.ranges.push(a));
            if (o && n.firstChild()) t && t.depth++, r && r.depth++;
            else
                for (; !n.nextSibling();) {
                    if (!n.parent()) break e;
                    if (t && !--t.depth) {
                        let h = mt(this.ranges, t.ranges);
                        h.length && (dt(h), this.inner.splice(t.index, 0, new ct(t.parser, t.parser.startParse(this.input, kt(t.mounts, h), h), t.ranges.map(f => new j(f.from - t.start, f.to - t.start)), t.target, h[0].from))), t = t.prev
                    }
                    r && !--r.depth && (r = r.prev)
                }
        }
    }
}

function Sr(i, e, t) {
    for (let r of i) {
        if (r.from >= t) break;
        if (r.to > e) return r.from <= e && r.to >= t ? 2 : 1
    }
    return 0
}

function pt(i, e, t, r, n, s) {
    if (e < t) {
        let l = i.buffer[e + 1];
        r.push(i.slice(e, t, l)), n.push(l - s)
    }
}

function Ar(i) {
    let {
        node: e
    } = i, t = [], r = e.context.buffer;
    do t.push(i.index), i.parent(); while (!i.tree);
    let n = i.tree,
        s = n.children.indexOf(r),
        l = n.children[s],
        o = l.buffer,
        a = [s];

    function h(f, u, d, p, x, S) {
        let D = t[S],
            O = [],
            E = [];
        pt(l, f, D, O, E, p);
        let T = o[D + 1],
            z = o[D + 2];
        a.push(O.length);
        let w = S ? h(D + 4, o[D + 3], l.set.types[o[D]], T, z - T, S - 1) : e.toTree();
        return O.push(w), E.push(T - p), pt(l, o[D + 3], u, O, E, p), new C(d, O, E, x)
    }
    n.children[s] = h(0, o.length, F.none, 0, l.length, t.length - 1);
    for (let f of a) {
        let u = i.tree.children[f],
            d = i.tree.positions[f];
        i.yield(new _(u, d + i.from, f, i._tree))
    }
}
class gt {
    constructor(e, t) {
        this.offset = t, this.done = !1, this.cursor = e.cursor(I.IncludeAnonymous | I.IgnoreMounts)
    }
    moveTo(e) {
        let {
            cursor: t
        } = this, r = e - this.offset;
        for (; !this.done && t.from < r;) t.to >= e && t.enter(r, 1, I.IgnoreOverlays | I.ExcludeBuffers) || t.next(!1) || (this.done = !0)
    }
    hasNode(e) {
        if (this.moveTo(e.from), !this.done && this.cursor.from + this.offset == e.from && this.cursor.tree)
            for (let t = this.cursor.tree;;) {
                if (t == e.tree) return !0;
                if (t.children.length && t.positions[0] == 0 && t.children[0] instanceof C) t = t.children[0];
                else break
            }
        return !1
    }
}
class Cr {
    constructor(e) {
        var t;
        if (this.fragments = e, this.curTo = 0, this.fragI = 0, e.length) {
            let r = this.curFrag = e[0];
            this.curTo = (t = r.tree.prop(Ue)) !== null && t !== void 0 ? t : r.to, this.inner = new gt(r.tree, -r.offset)
        } else this.curFrag = this.inner = null
    }
    hasNode(e) {
        for (; this.curFrag && e.from >= this.curTo;) this.nextFrag();
        return this.curFrag && this.curFrag.from <= e.from && this.curTo >= e.to && this.inner.hasNode(e)
    }
    nextFrag() {
        var e;
        if (this.fragI++, this.fragI == this.fragments.length) this.curFrag = this.inner = null;
        else {
            let t = this.curFrag = this.fragments[this.fragI];
            this.curTo = (e = t.tree.prop(Ue)) !== null && e !== void 0 ? e : t.to, this.inner = new gt(t.tree, -t.offset)
        }
    }
    findMounts(e, t) {
        var r;
        let n = [];
        if (this.inner) {
            this.inner.cursor.moveTo(e, 1);
            for (let s = this.inner.cursor.node; s; s = s.parent) {
                let l = (r = s.tree) === null || r === void 0 ? void 0 : r.prop(k.mounted);
                if (l && l.parser == t)
                    for (let o = this.fragI; o < this.fragments.length; o++) {
                        let a = this.fragments[o];
                        if (a.from >= s.to) break;
                        a.tree == this.curFrag.tree && n.push({
                            frag: a,
                            pos: s.from - a.offset,
                            mount: l
                        })
                    }
            }
        }
        return n
    }
}

function mt(i, e) {
    let t = null,
        r = e;
    for (let n = 1, s = 0; n < i.length; n++) {
        let l = i[n - 1].to,
            o = i[n].from;
        for (; s < r.length; s++) {
            let a = r[s];
            if (a.from >= o) break;
            a.to <= l || (t || (r = t = e.slice()), a.from < l ? (t[s] = new j(a.from, l), a.to > o && t.splice(s + 1, 0, new j(o, a.to))) : a.to > o ? t[s--] = new j(o, a.to) : t.splice(s--, 1))
        }
    }
    return r
}

function Pr(i, e, t, r) {
    let n = 0,
        s = 0,
        l = !1,
        o = !1,
        a = -1e9,
        h = [];
    for (;;) {
        let f = n == i.length ? 1e9 : l ? i[n].to : i[n].from,
            u = s == e.length ? 1e9 : o ? e[s].to : e[s].from;
        if (l != o) {
            let d = Math.max(a, t),
                p = Math.min(f, u, r);
            d < p && h.push(new j(d, p))
        }
        if (a = Math.min(f, u), a == 1e9) break;
        f == a && (l ? (l = !1, n++) : l = !0), u == a && (o ? (o = !1, s++) : o = !0)
    }
    return h
}

function kt(i, e) {
    let t = [];
    for (let {
            pos: r,
            mount: n,
            frag: s
        } of i) {
        let l = r + (n.overlay ? n.overlay[0].from : 0),
            o = l + n.tree.length,
            a = Math.max(s.from, l),
            h = Math.min(s.to, o);
        if (n.overlay) {
            let f = n.overlay.map(d => new j(d.from + r, d.to + r)),
                u = Pr(e, f, a, h);
            for (let d = 0, p = a;; d++) {
                let x = d == u.length,
                    S = x ? h : u[d].from;
                if (S > p && t.push(new Y(p, S, n.tree, -l, s.from >= p || s.openStart, s.to <= S || s.openEnd)), x) break;
                p = u[d].to
            }
        } else t.push(new Y(a, h, n.tree, -l, s.from >= l || s.openStart, s.to <= o || s.openEnd))
    }
    return t
}
let Tr = 0;
class J {
    constructor(e, t, r) {
        this.set = e, this.base = t, this.modified = r, this.id = Tr++
    }
    static define(e) {
        if (e != null && e.base) throw new Error("Can not derive from a modified tag");
        let t = new J([], null, []);
        if (t.set.push(t), e)
            for (let r of e.set) t.set.push(r);
        return t
    }
    static defineModifier() {
        let e = new Be;
        return t => t.modified.indexOf(e) > -1 ? t : Be.get(t.base || t, t.modified.concat(e).sort((r, n) => r.id - n.id))
    }
}
let Nr = 0;
class Be {
    constructor() {
        this.instances = [], this.id = Nr++
    }
    static get(e, t) {
        if (!t.length) return e;
        let r = t[0].instances.find(o => o.base == e && Ir(t, o.modified));
        if (r) return r;
        let n = [],
            s = new J(n, e, t);
        for (let o of t) o.instances.push(s);
        let l = Br(t);
        for (let o of e.set)
            if (!o.modified.length)
                for (let a of l) n.push(Be.get(o, a));
        return s
    }
}

function Ir(i, e) {
    return i.length == e.length && i.every((t, r) => t == e[r])
}

function Br(i) {
    let e = [
        []
    ];
    for (let t = 0; t < i.length; t++)
        for (let r = 0, n = e.length; r < n; r++) e.push(e[r].concat(i[t]));
    return e.sort((t, r) => r.length - t.length)
}

function Mr(i) {
    let e = Object.create(null);
    for (let t in i) {
        let r = i[t];
        Array.isArray(r) || (r = [r]);
        for (let n of t.split(" "))
            if (n) {
                let s = [],
                    l = 2,
                    o = n;
                for (let u = 0;;) {
                    if (o == "..." && u > 0 && u + 3 == n.length) {
                        l = 1;
                        break
                    }
                    let d = /^"(?:[^"\\]|\\.)*?"|[^\/!]+/.exec(o);
                    if (!d) throw new RangeError("Invalid path: " + n);
                    if (s.push(d[0] == "*" ? "" : d[0][0] == '"' ? JSON.parse(d[0]) : d[0]), u += d[0].length, u == n.length) break;
                    let p = n[u++];
                    if (u == n.length && p == "!") {
                        l = 0;
                        break
                    }
                    if (p != "/") throw new RangeError("Invalid path: " + n);
                    o = n.slice(u)
                }
                let a = s.length - 1,
                    h = s[a];
                if (!h) throw new RangeError("Invalid path: " + n);
                let f = new Me(r, l, a > 0 ? s.slice(0, a) : null);
                e[h] = f.sort(e[h])
            }
    }
    return Et.add(e)
}
const Et = new k;
class Me {
    constructor(e, t, r, n) {
        this.tags = e, this.mode = t, this.context = r, this.next = n
    }
    get opaque() {
        return this.mode == 0
    }
    get inherit() {
        return this.mode == 1
    }
    sort(e) {
        return !e || e.depth < this.depth ? (this.next = e, this) : (e.next = this.sort(e.next), e)
    }
    get depth() {
        return this.context ? this.context.length : 0
    }
}
Me.empty = new Me([], 2, null);

function _t(i, e) {
    let t = Object.create(null);
    for (let s of i)
        if (!Array.isArray(s.tag)) t[s.tag.id] = s.class;
        else
            for (let l of s.tag) t[l.id] = s.class;
    let {
        scope: r,
        all: n = null
    } = e || {};
    return {
        style: s => {
            let l = n;
            for (let o of s)
                for (let a of o.set) {
                    let h = t[a.id];
                    if (h) {
                        l = l ? l + " " + h : h;
                        break
                    }
                }
            return l
        },
        scope: r
    }
}

function Or(i, e) {
    let t = null;
    for (let r of i) {
        let n = r.style(e);
        n && (t = t ? t + " " + n : n)
    }
    return t
}

function Dr(i, e, t, r = 0, n = i.length) {
    let s = new Er(r, Array.isArray(e) ? e : [e], t);
    s.highlightRange(i.cursor(), r, n, "", s.highlighters), s.flush(n)
}
class Er {
    constructor(e, t, r) {
        this.at = e, this.highlighters = t, this.span = r, this.class = ""
    }
    startSpan(e, t) {
        t != this.class && (this.flush(e), e > this.at && (this.at = e), this.class = t)
    }
    flush(e) {
        e > this.at && this.class && this.span(this.at, e, this.class)
    }
    highlightRange(e, t, r, n, s) {
        let {
            type: l,
            from: o,
            to: a
        } = e;
        if (o >= r || a <= t) return;
        l.isTop && (s = this.highlighters.filter(p => !p.scope || p.scope(l)));
        let h = n,
            f = _r(e) || Me.empty,
            u = Or(s, f.tags);
        if (u && (h && (h += " "), h += u, f.mode == 1 && (n += (n ? " " : "") + u)), this.startSpan(Math.max(t, o), h), f.opaque) return;
        let d = e.tree && e.tree.prop(k.mounted);
        if (d && d.overlay) {
            let p = e.node.enter(d.overlay[0].from + o, 1),
                x = this.highlighters.filter(D => !D.scope || D.scope(d.tree.type)),
                S = e.firstChild();
            for (let D = 0, O = o;; D++) {
                let E = D < d.overlay.length ? d.overlay[D] : null,
                    T = E ? E.from + o : a,
                    z = Math.max(t, O),
                    w = Math.min(r, T);
                if (z < w && S)
                    for (; e.from < w && (this.highlightRange(e, z, w, n, s), this.startSpan(Math.min(w, e.to), h), !(e.to >= T || !e.nextSibling())););
                if (!E || T > r) break;
                O = E.to + o, O > t && (this.highlightRange(p.cursor(), Math.max(t, E.from + o), Math.min(r, O), "", x), this.startSpan(Math.min(r, O), h))
            }
            S && e.parent()
        } else if (e.firstChild()) {
            d && (n = "");
            do
                if (!(e.to <= t)) {
                    if (e.from >= r) break;
                    this.highlightRange(e, t, r, n, s), this.startSpan(Math.min(r, e.to), h)
                }
            while (e.nextSibling());
            e.parent()
        }
    }
}

function _r(i) {
    let e = i.type.prop(Et);
    for (; e && e.context && !i.matchContext(e.context);) e = e.next;
    return e || null
}
const c = J.define,
    Se = c(),
    ee = c(),
    bt = c(ee),
    yt = c(ee),
    te = c(),
    Ae = c(te),
    Re = c(te),
    G = c(),
    oe = c(G),
    q = c(),
    $ = c(),
    Ve = c(),
    pe = c(Ve),
    Ce = c(),
    m = {
        comment: Se,
        lineComment: c(Se),
        blockComment: c(Se),
        docComment: c(Se),
        name: ee,
        variableName: c(ee),
        typeName: bt,
        tagName: c(bt),
        propertyName: yt,
        attributeName: c(yt),
        className: c(ee),
        labelName: c(ee),
        namespace: c(ee),
        macroName: c(ee),
        literal: te,
        string: Ae,
        docString: c(Ae),
        character: c(Ae),
        attributeValue: c(Ae),
        number: Re,
        integer: c(Re),
        float: c(Re),
        bool: c(te),
        regexp: c(te),
        escape: c(te),
        color: c(te),
        url: c(te),
        keyword: q,
        self: c(q),
        null: c(q),
        atom: c(q),
        unit: c(q),
        modifier: c(q),
        operatorKeyword: c(q),
        controlKeyword: c(q),
        definitionKeyword: c(q),
        moduleKeyword: c(q),
        operator: $,
        derefOperator: c($),
        arithmeticOperator: c($),
        logicOperator: c($),
        bitwiseOperator: c($),
        compareOperator: c($),
        updateOperator: c($),
        definitionOperator: c($),
        typeOperator: c($),
        controlOperator: c($),
        punctuation: Ve,
        separator: c(Ve),
        bracket: pe,
        angleBracket: c(pe),
        squareBracket: c(pe),
        paren: c(pe),
        brace: c(pe),
        content: G,
        heading: oe,
        heading1: c(oe),
        heading2: c(oe),
        heading3: c(oe),
        heading4: c(oe),
        heading5: c(oe),
        heading6: c(oe),
        contentSeparator: c(G),
        list: c(G),
        quote: c(G),
        emphasis: c(G),
        strong: c(G),
        link: c(G),
        monospace: c(G),
        strikethrough: c(G),
        inserted: c(),
        deleted: c(),
        changed: c(),
        invalid: c(),
        meta: Ce,
        documentMeta: c(Ce),
        annotation: c(Ce),
        processingInstruction: c(Ce),
        definition: J.defineModifier(),
        constant: J.defineModifier(),
        function: J.defineModifier(),
        standard: J.defineModifier(),
        local: J.defineModifier(),
        special: J.defineModifier()
    };
_t([{
    tag: m.link,
    class: "tok-link"
}, {
    tag: m.heading,
    class: "tok-heading"
}, {
    tag: m.emphasis,
    class: "tok-emphasis"
}, {
    tag: m.strong,
    class: "tok-strong"
}, {
    tag: m.keyword,
    class: "tok-keyword"
}, {
    tag: m.atom,
    class: "tok-atom"
}, {
    tag: m.bool,
    class: "tok-bool"
}, {
    tag: m.url,
    class: "tok-url"
}, {
    tag: m.labelName,
    class: "tok-labelName"
}, {
    tag: m.inserted,
    class: "tok-inserted"
}, {
    tag: m.deleted,
    class: "tok-deleted"
}, {
    tag: m.literal,
    class: "tok-literal"
}, {
    tag: m.string,
    class: "tok-string"
}, {
    tag: m.number,
    class: "tok-number"
}, {
    tag: [m.regexp, m.escape, m.special(m.string)],
    class: "tok-string2"
}, {
    tag: m.variableName,
    class: "tok-variableName"
}, {
    tag: m.local(m.variableName),
    class: "tok-variableName tok-local"
}, {
    tag: m.definition(m.variableName),
    class: "tok-variableName tok-definition"
}, {
    tag: m.special(m.variableName),
    class: "tok-variableName2"
}, {
    tag: m.definition(m.propertyName),
    class: "tok-propertyName tok-definition"
}, {
    tag: m.typeName,
    class: "tok-typeName"
}, {
    tag: m.namespace,
    class: "tok-namespace"
}, {
    tag: m.className,
    class: "tok-className"
}, {
    tag: m.macroName,
    class: "tok-macroName"
}, {
    tag: m.propertyName,
    class: "tok-propertyName"
}, {
    tag: m.operator,
    class: "tok-operator"
}, {
    tag: m.comment,
    class: "tok-comment"
}, {
    tag: m.meta,
    class: "tok-meta"
}, {
    tag: m.invalid,
    class: "tok-invalid"
}, {
    tag: m.punctuation,
    class: "tok-punctuation"
}]);
var ze;
const ae = new k;

function Ft(i) {
    return Z.define({
        combine: i ? e => e.concat(i) : void 0
    })
}
const Fr = new k;
class W {
    constructor(e, t, r = [], n = "") {
        this.data = e, this.name = n, me.prototype.hasOwnProperty("tree") || Object.defineProperty(me.prototype, "tree", {
            get() {
                return U(this)
            }
        }), this.parser = t, this.extension = [ne.of(this), me.languageData.of((s, l, o) => {
            let a = xt(s, l, o),
                h = a.type.prop(ae);
            if (!h) return [];
            let f = s.facet(h),
                u = a.type.prop(Fr);
            if (u) {
                let d = a.resolve(l - a.from, o);
                for (let p of u)
                    if (p.test(d, s)) {
                        let x = s.facet(p.facet);
                        return p.type == "replace" ? x : x.concat(f)
                    }
            }
            return f
        })].concat(r)
    }
    isActiveAt(e, t, r = -1) {
        return xt(e, t, r).type.prop(ae) == this.data
    }
    findRegions(e) {
        let t = e.facet(ne);
        if ((t == null ? void 0 : t.data) == this.data) return [{
            from: 0,
            to: e.doc.length
        }];
        if (!t || !t.allowsNesting) return [];
        let r = [],
            n = (s, l) => {
                if (s.prop(ae) == this.data) {
                    r.push({
                        from: l,
                        to: l + s.length
                    });
                    return
                }
                let o = s.prop(k.mounted);
                if (o) {
                    if (o.tree.prop(ae) == this.data) {
                        if (o.overlay)
                            for (let a of o.overlay) r.push({
                                from: a.from + l,
                                to: a.to + l
                            });
                        else r.push({
                            from: l,
                            to: l + s.length
                        });
                        return
                    } else if (o.overlay) {
                        let a = r.length;
                        if (n(o.tree, o.overlay[0].from + l), r.length > a) return
                    }
                }
                for (let a = 0; a < s.children.length; a++) {
                    let h = s.children[a];
                    h instanceof C && n(h, s.positions[a] + l)
                }
            };
        return n(U(e), 0), r
    }
    get allowsNesting() {
        return !0
    }
}
W.setState = _e.define();

function xt(i, e, t) {
    let r = i.facet(ne),
        n = U(i).topNode;
    if (!r || r.allowsNesting)
        for (let s = n; s; s = s.enter(e, t, I.ExcludeBuffers)) s.type.isTop && (n = s);
    return n
}
class qe extends W {
    constructor(e, t, r) {
        super(e, t, [], r), this.parser = t
    }
    static define(e) {
        let t = Ft(e.languageData);
        return new qe(t, e.parser.configure({
            props: [ae.add(r => r.isTop ? t : void 0)]
        }), e.name)
    }
    configure(e, t) {
        return new qe(this.data, this.parser.configure(e), t || this.name)
    }
    get allowsNesting() {
        return this.parser.hasWrappers()
    }
}

function U(i) {
    let e = i.field(W.state, !1);
    return e ? e.tree : C.empty
}
class Rr {
    constructor(e) {
        this.doc = e, this.cursorPos = 0, this.string = "", this.cursor = e.iter()
    }
    get length() {
        return this.doc.length
    }
    syncTo(e) {
        return this.string = this.cursor.next(e - this.cursorPos).value, this.cursorPos = e + this.string.length, this.cursorPos - this.string.length
    }
    chunk(e) {
        return this.syncTo(e), this.string
    }
    get lineChunks() {
        return !0
    }
    read(e, t) {
        let r = this.cursorPos - this.string.length;
        return e < r || t >= this.cursorPos ? this.doc.sliceString(e, t) : this.string.slice(e - r, t - r)
    }
}
let ge = null;
class ce {
    constructor(e, t, r = [], n, s, l, o, a) {
        this.parser = e, this.state = t, this.fragments = r, this.tree = n, this.treeLen = s, this.viewport = l, this.skipped = o, this.scheduleOn = a, this.parse = null, this.tempSkipped = []
    }
    static create(e, t, r) {
        return new ce(e, t, [], C.empty, 0, r, [], null)
    }
    startParse() {
        return this.parser.startParse(new Rr(this.state.doc), this.fragments)
    }
    work(e, t) {
        return t != null && t >= this.state.doc.length && (t = void 0), this.tree != C.empty && this.isDone(t != null ? t : this.state.doc.length) ? (this.takeTree(), !0) : this.withContext(() => {
            var r;
            if (typeof e == "number") {
                let n = Date.now() + e;
                e = () => Date.now() > n
            }
            for (this.parse || (this.parse = this.startParse()), t != null && (this.parse.stoppedAt == null || this.parse.stoppedAt > t) && t < this.state.doc.length && this.parse.stopAt(t);;) {
                let n = this.parse.advance();
                if (n)
                    if (this.fragments = this.withoutTempSkipped(Y.addTree(n, this.fragments, this.parse.stoppedAt != null)), this.treeLen = (r = this.parse.stoppedAt) !== null && r !== void 0 ? r : this.state.doc.length, this.tree = n, this.parse = null, this.treeLen < (t != null ? t : this.state.doc.length)) this.parse = this.startParse();
                    else return !0;
                if (e()) return !1
            }
        })
    }
    takeTree() {
        let e, t;
        this.parse && (e = this.parse.parsedPos) >= this.treeLen && ((this.parse.stoppedAt == null || this.parse.stoppedAt > e) && this.parse.stopAt(e), this.withContext(() => {
            for (; !(t = this.parse.advance()););
        }), this.treeLen = e, this.tree = t, this.fragments = this.withoutTempSkipped(Y.addTree(this.tree, this.fragments, !0)), this.parse = null)
    }
    withContext(e) {
        let t = ge;
        ge = this;
        try {
            return e()
        } finally {
            ge = t
        }
    }
    withoutTempSkipped(e) {
        for (let t; t = this.tempSkipped.pop();) e = wt(e, t.from, t.to);
        return e
    }
    changes(e, t) {
        let {
            fragments: r,
            tree: n,
            treeLen: s,
            viewport: l,
            skipped: o
        } = this;
        if (this.takeTree(), !e.empty) {
            let a = [];
            if (e.iterChangedRanges((h, f, u, d) => a.push({
                    fromA: h,
                    toA: f,
                    fromB: u,
                    toB: d
                })), r = Y.applyChanges(r, a), n = C.empty, s = 0, l = {
                    from: e.mapPos(l.from, -1),
                    to: e.mapPos(l.to, 1)
                }, this.skipped.length) {
                o = [];
                for (let h of this.skipped) {
                    let f = e.mapPos(h.from, 1),
                        u = e.mapPos(h.to, -1);
                    f < u && o.push({
                        from: f,
                        to: u
                    })
                }
            }
        }
        return new ce(this.parser, t, r, n, s, l, o, this.scheduleOn)
    }
    updateViewport(e) {
        if (this.viewport.from == e.from && this.viewport.to == e.to) return !1;
        this.viewport = e;
        let t = this.skipped.length;
        for (let r = 0; r < this.skipped.length; r++) {
            let {
                from: n,
                to: s
            } = this.skipped[r];
            n < e.to && s > e.from && (this.fragments = wt(this.fragments, n, s), this.skipped.splice(r--, 1))
        }
        return this.skipped.length >= t ? !1 : (this.reset(), !0)
    }
    reset() {
        this.parse && (this.takeTree(), this.parse = null)
    }
    skipUntilInView(e, t) {
        this.skipped.push({
            from: e,
            to: t
        })
    }
    static getSkippingParser(e) {
        return new class extends Dt {
            createParse(t, r, n) {
                let s = n[0].from,
                    l = n[n.length - 1].to;
                return {
                    parsedPos: s,
                    advance() {
                        let a = ge;
                        if (a) {
                            for (let h of n) a.tempSkipped.push(h);
                            e && (a.scheduleOn = a.scheduleOn ? Promise.all([a.scheduleOn, e]) : e)
                        }
                        return this.parsedPos = l, new C(F.none, [], [], l - s)
                    },
                    stoppedAt: null,
                    stopAt() {}
                }
            }
        }
    }
    isDone(e) {
        e = Math.min(e, this.state.doc.length);
        let t = this.fragments;
        return this.treeLen >= e && t.length && t[0].from == 0 && t[0].to >= e
    }
    static get() {
        return ge
    }
}

function wt(i, e, t) {
    return Y.applyChanges(i, [{
        fromA: e,
        toA: t,
        fromB: e,
        toB: t
    }])
}
class de {
    constructor(e) {
        this.context = e, this.tree = e.tree
    }
    apply(e) {
        if (!e.docChanged && this.tree == this.context.tree) return this;
        let t = this.context.changes(e.changes, e.state),
            r = this.context.treeLen == e.startState.doc.length ? void 0 : Math.max(e.changes.mapPos(this.context.treeLen), t.viewport.to);
        return t.work(20, r) || t.takeTree(), new de(t)
    }
    static init(e) {
        let t = Math.min(3e3, e.doc.length),
            r = ce.create(e.facet(ne).parser, e, {
                from: 0,
                to: t
            });
        return r.work(20, t) || r.takeTree(), new de(r)
    }
}
W.state = Ke.define({
    create: de.init,
    update(i, e) {
        for (let t of e.effects)
            if (t.is(W.setState)) return t.value;
        return e.startState.facet(ne) != e.state.facet(ne) ? de.init(e.state) : i.apply(e)
    }
});
let Rt = i => {
    let e = setTimeout(() => i(), 500);
    return () => clearTimeout(e)
};
typeof requestIdleCallback < "u" && (Rt = i => {
    let e = -1,
        t = setTimeout(() => {
            e = requestIdleCallback(i, {
                timeout: 400
            })
        }, 100);
    return () => e < 0 ? clearTimeout(t) : cancelIdleCallback(e)
});
const Le = typeof navigator < "u" && (!((ze = navigator.scheduling) === null || ze === void 0) && ze.isInputPending) ? () => navigator.scheduling.isInputPending() : null,
    zr = Qe.fromClass(class {
        constructor(e) {
            this.view = e, this.working = null, this.workScheduled = 0, this.chunkEnd = -1, this.chunkBudget = -1, this.work = this.work.bind(this), this.scheduleWork()
        }
        update(e) {
            let t = this.view.state.field(W.state).context;
            (t.updateViewport(e.view.viewport) || this.view.viewport.to > t.treeLen) && this.scheduleWork(), (e.docChanged || e.selectionSet) && (this.view.hasFocus && (this.chunkBudget += 50), this.scheduleWork()), this.checkAsyncSchedule(t)
        }
        scheduleWork() {
            if (this.working) return;
            let {
                state: e
            } = this.view, t = e.field(W.state);
            (t.tree != t.context.tree || !t.context.isDone(e.doc.length)) && (this.working = Rt(this.work))
        }
        work(e) {
            this.working = null;
            let t = Date.now();
            if (this.chunkEnd < t && (this.chunkEnd < 0 || this.view.hasFocus) && (this.chunkEnd = t + 3e4, this.chunkBudget = 3e3), this.chunkBudget <= 0) return;
            let {
                state: r,
                viewport: {
                    to: n
                }
            } = this.view, s = r.field(W.state);
            if (s.tree == s.context.tree && s.context.isDone(n + 1e5)) return;
            let l = Date.now() + Math.min(this.chunkBudget, 100, e && !Le ? Math.max(25, e.timeRemaining() - 5) : 1e9),
                o = s.context.treeLen < n && r.doc.length > n + 1e3,
                a = s.context.work(() => Le && Le() || Date.now() > l, n + (o ? 0 : 1e5));
            this.chunkBudget -= Date.now() - t, (a || this.chunkBudget <= 0) && (s.context.takeTree(), this.view.dispatch({
                effects: W.setState.of(new de(s.context))
            })), this.chunkBudget > 0 && !(a && !o) && this.scheduleWork(), this.checkAsyncSchedule(s.context)
        }
        checkAsyncSchedule(e) {
            e.scheduleOn && (this.workScheduled++, e.scheduleOn.then(() => this.scheduleWork()).catch(t => ur(this.view.state, t)).then(() => this.workScheduled--), e.scheduleOn = null)
        }
        destroy() {
            this.working && this.working()
        }
        isWorking() {
            return !!(this.working || this.workScheduled > 0)
        }
    }, {
        eventHandlers: {
            focus() {
                this.scheduleWork()
            }
        }
    }),
    ne = Z.define({
        combine(i) {
            return i.length ? i[0] : null
        },
        enables: i => [W.state, zr, X.contentAttributes.compute([i], e => {
            let t = e.facet(i);
            return t && t.name ? {
                "data-language": t.name
            } : {}
        })]
    });
class Mn {
    constructor(e, t = []) {
        this.language = e, this.support = t, this.extension = [e, t]
    }
}
const zt = Z.define(),
    Lt = Z.define({
        combine: i => {
            if (!i.length) return "  ";
            let e = i[0];
            if (!e || /\S/.test(e) || Array.from(e).some(t => t != e[0])) throw new Error("Invalid indent unit: " + JSON.stringify(i[0]));
            return e
        }
    });

function Oe(i) {
    let e = i.facet(Lt);
    return e.charCodeAt(0) == 9 ? i.tabSize * e.length : e.length
}

function Lr(i, e) {
    let t = "",
        r = i.tabSize,
        n = i.facet(Lt)[0];
    if (n == "	") {
        for (; e >= r;) t += "	", e -= r;
        n = " "
    }
    for (let s = 0; s < e; s++) t += n;
    return t
}

function jr(i, e) {
    i instanceof me && (i = new jt(i));
    for (let r of i.state.facet(zt)) {
        let n = r(i, e);
        if (n !== void 0) return n
    }
    let t = U(i.state);
    return t.length >= e ? Hr(i, t, e) : null
}
class jt {
    constructor(e, t = {}) {
        this.state = e, this.options = t, this.unit = Oe(e)
    }
    lineAt(e, t = 1) {
        let r = this.state.doc.lineAt(e),
            {
                simulateBreak: n,
                simulateDoubleBreak: s
            } = this.options;
        return n != null && n >= r.from && n <= r.to ? s && n == e ? {
            text: "",
            from: e
        } : (t < 0 ? n < e : n <= e) ? {
            text: r.text.slice(n - r.from),
            from: n
        } : {
            text: r.text.slice(0, n - r.from),
            from: r.from
        } : r
    }
    textAfterPos(e, t = 1) {
        if (this.options.simulateDoubleBreak && e == this.options.simulateBreak) return "";
        let {
            text: r,
            from: n
        } = this.lineAt(e, t);
        return r.slice(e - n, Math.min(r.length, e + 100 - n))
    }
    column(e, t = 1) {
        let {
            text: r,
            from: n
        } = this.lineAt(e, t), s = this.countColumn(r, e - n), l = this.options.overrideIndentation ? this.options.overrideIndentation(n) : -1;
        return l > -1 && (s += l - this.countColumn(r, r.search(/\S|$/))), s
    }
    countColumn(e, t = e.length) {
        return fr(e, this.state.tabSize, t)
    }
    lineIndent(e, t = 1) {
        let {
            text: r,
            from: n
        } = this.lineAt(e, t), s = this.options.overrideIndentation;
        if (s) {
            let l = s(n);
            if (l > -1) return l
        }
        return this.countColumn(r, r.search(/\S|$/))
    }
    get simulatedBreak() {
        return this.options.simulateBreak || null
    }
}
const Wr = new k;

function Hr(i, e, t) {
    let r = e.resolveStack(t),
        n = r.node.enterUnfinishedNodesBefore(t);
    if (n != r.node) {
        let s = [];
        for (let l = n; l != r.node; l = l.parent) s.push(l);
        for (let l = s.length - 1; l >= 0; l--) r = {
            node: s[l],
            next: r
        }
    }
    return Wt(r, i, t)
}

function Wt(i, e, t) {
    for (let r = i; r; r = r.next) {
        let n = Vr(r.node);
        if (n) return n(tt.create(e, t, r))
    }
    return 0
}

function Ur(i) {
    return i.pos == i.options.simulateBreak && i.options.simulateDoubleBreak
}

function Vr(i) {
    let e = i.type.prop(Wr);
    if (e) return e;
    let t = i.firstChild,
        r;
    if (t && (r = t.type.prop(k.closedBy))) {
        let n = i.lastChild,
            s = n && r.indexOf(n.name) > -1;
        return l => Ht(l, !0, 1, void 0, s && !Ur(l) ? n.from : void 0)
    }
    return i.parent == null ? qr : null
}

function qr() {
    return 0
}
class tt extends jt {
    constructor(e, t, r) {
        super(e.state, e.options), this.base = e, this.pos = t, this.context = r
    }
    get node() {
        return this.context.node
    }
    static create(e, t, r) {
        return new tt(e, t, r)
    }
    get textAfter() {
        return this.textAfterPos(this.pos)
    }
    get baseIndent() {
        return this.baseIndentFor(this.node)
    }
    baseIndentFor(e) {
        let t = this.state.doc.lineAt(e.from);
        for (;;) {
            let r = e.resolve(t.from);
            for (; r.parent && r.parent.from == r.from;) r = r.parent;
            if ($r(r, e)) break;
            t = this.state.doc.lineAt(r.from)
        }
        return this.lineIndent(t.from)
    }
    continue () {
        return Wt(this.context.next, this.base, this.pos)
    }
}

function $r(i, e) {
    for (let t = e; t; t = t.parent)
        if (i == t) return !0;
    return !1
}

function Gr(i) {
    let e = i.node,
        t = e.childAfter(e.from),
        r = e.lastChild;
    if (!t) return null;
    let n = i.options.simulateBreak,
        s = i.state.doc.lineAt(t.from),
        l = n == null || n <= s.from ? s.to : Math.min(s.to, n);
    for (let o = t.to;;) {
        let a = e.childAfter(o);
        if (!a || a == r) return null;
        if (!a.type.isSkipped) return a.from < l ? t : null;
        o = a.to
    }
}

function On({
    closing: i,
    align: e = !0,
    units: t = 1
}) {
    return r => Ht(r, e, t, i)
}

function Ht(i, e, t, r, n) {
    let s = i.textAfter,
        l = s.match(/^\s*/)[0].length,
        o = r && s.slice(l, l + r.length) == r || n == i.pos + l,
        a = e ? Gr(i) : null;
    return a ? o ? i.column(a.from) : i.column(a.to) : i.baseIndent + (o ? 0 : i.unit * t)
}
const Dn = i => i.baseIndent;

function En({
    except: i,
    units: e = 1
} = {}) {
    return t => {
        let r = i && i.test(t.textAfter);
        return t.baseIndent + (r ? 0 : e * t.unit)
    }
}
const Jr = 200;

function _n() {
    return me.transactionFilter.of(i => {
        if (!i.docChanged || !i.isUserEvent("input.type") && !i.isUserEvent("input.complete")) return i;
        let e = i.startState.languageDataAt("indentOnInput", i.startState.selection.main.head);
        if (!e.length) return i;
        let t = i.newDoc,
            {
                head: r
            } = i.newSelection.main,
            n = t.lineAt(r);
        if (r > n.from + Jr) return i;
        let s = t.sliceString(n.from, r);
        if (!e.some(h => h.test(s))) return i;
        let {
            state: l
        } = i, o = -1, a = [];
        for (let {
                head: h
            } of l.selection.ranges) {
            let f = l.doc.lineAt(h);
            if (f.from == o) continue;
            o = f.from;
            let u = jr(l, f.from);
            if (u == null) continue;
            let d = /^\s*/.exec(f.text)[0],
                p = Lr(l, u);
            d != p && a.push({
                from: f.from,
                to: f.from + d.length,
                insert: p
            })
        }
        return a.length ? [i, {
            changes: a,
            sequential: !0
        }] : i
    })
}
const Kr = Z.define(),
    Qr = new k;

function Fn(i) {
    let e = i.firstChild,
        t = i.lastChild;
    return e && e.to < t.from ? {
        from: e.to,
        to: t.type.isError ? i.to : t.from
    } : null
}

function Xr(i, e, t) {
    let r = U(i);
    if (r.length < t) return null;
    let n = r.resolveStack(t, 1),
        s = null;
    for (let l = n; l; l = l.next) {
        let o = l.node;
        if (o.to <= t || o.from > t) continue;
        if (s && o.from < e) break;
        let a = o.type.prop(Qr);
        if (a && (o.to < r.length - 50 || r.length == i.doc.length || !Yr(o))) {
            let h = a(o, i);
            h && h.from <= t && h.from >= e && h.to > t && (s = h)
        }
    }
    return s
}

function Yr(i) {
    let e = i.lastChild;
    return e && e.to == i.to && e.type.isError
}

function De(i, e, t) {
    for (let r of i.facet(Kr)) {
        let n = r(i, e, t);
        if (n) return n
    }
    return Xr(i, e, t)
}

function Ut(i, e) {
    let t = e.mapPos(i.from, 1),
        r = e.mapPos(i.to, -1);
    return t >= r ? void 0 : {
        from: t,
        to: r
    }
}
const Fe = _e.define({
        map: Ut
    }),
    xe = _e.define({
        map: Ut
    });

function Vt(i) {
    let e = [];
    for (let {
            head: t
        } of i.state.selection.ranges) e.some(r => r.from <= t && r.to >= t) || e.push(i.lineBlockAt(t));
    return e
}
const he = Ke.define({
    create() {
        return H.none
    },
    update(i, e) {
        i = i.map(e.changes);
        for (let t of e.effects)
            if (t.is(Fe) && !Zr(i, t.value.from, t.value.to)) {
                let {
                    preparePlaceholder: r
                } = e.state.facet(Gt), n = r ? H.replace({
                    widget: new ln(r(e.state, t.value))
                }) : vt;
                i = i.update({
                    add: [n.range(t.value.from, t.value.to)]
                })
            } else t.is(xe) && (i = i.update({
                filter: (r, n) => t.value.from != r || t.value.to != n,
                filterFrom: t.value.from,
                filterTo: t.value.to
            }));
        if (e.selection) {
            let t = !1,
                {
                    head: r
                } = e.selection.main;
            i.between(r, r, (n, s) => {
                n < r && s > r && (t = !0)
            }), t && (i = i.update({
                filterFrom: r,
                filterTo: r,
                filter: (n, s) => s <= r || n >= r
            }))
        }
        return i
    },
    provide: i => X.decorations.from(i),
    toJSON(i, e) {
        let t = [];
        return i.between(0, e.doc.length, (r, n) => {
            t.push(r, n)
        }), t
    },
    fromJSON(i) {
        if (!Array.isArray(i) || i.length % 2) throw new RangeError("Invalid JSON for fold state");
        let e = [];
        for (let t = 0; t < i.length;) {
            let r = i[t++],
                n = i[t++];
            if (typeof r != "number" || typeof n != "number") throw new RangeError("Invalid JSON for fold state");
            e.push(vt.range(r, n))
        }
        return H.set(e, !0)
    }
});

function Ee(i, e, t) {
    var r;
    let n = null;
    return (r = i.field(he, !1)) === null || r === void 0 || r.between(e, t, (s, l) => {
        (!n || n.from > s) && (n = {
            from: s,
            to: l
        })
    }), n
}

function Zr(i, e, t) {
    let r = !1;
    return i.between(e, e, (n, s) => {
        n == e && s == t && (r = !0)
    }), r
}

function qt(i, e) {
    return i.field(he, !1) ? e : e.concat(_e.appendConfig.of(Jt()))
}
const en = i => {
        for (let e of Vt(i)) {
            let t = De(i.state, e.from, e.to);
            if (t) return i.dispatch({
                effects: qt(i.state, [Fe.of(t), $t(i, t)])
            }), !0
        }
        return !1
    },
    tn = i => {
        if (!i.state.field(he, !1)) return !1;
        let e = [];
        for (let t of Vt(i)) {
            let r = Ee(i.state, t.from, t.to);
            r && e.push(xe.of(r), $t(i, r, !1))
        }
        return e.length && i.dispatch({
            effects: e
        }), e.length > 0
    };

function $t(i, e, t = !0) {
    let r = i.state.doc.lineAt(e.from).number,
        n = i.state.doc.lineAt(e.to).number;
    return X.announce.of("".concat(i.state.phrase(t ? "Folded lines" : "Unfolded lines"), " ").concat(r, " ").concat(i.state.phrase("to"), " ").concat(n, "."))
}
const rn = i => {
        let {
            state: e
        } = i, t = [];
        for (let r = 0; r < e.doc.length;) {
            let n = i.lineBlockAt(r),
                s = De(e, n.from, n.to);
            s && t.push(Fe.of(s)), r = (s ? i.lineBlockAt(s.to) : n).to + 1
        }
        return t.length && i.dispatch({
            effects: qt(i.state, t)
        }), !!t.length
    },
    nn = i => {
        let e = i.state.field(he, !1);
        if (!e || !e.size) return !1;
        let t = [];
        return e.between(0, i.state.doc.length, (r, n) => {
            t.push(xe.of({
                from: r,
                to: n
            }))
        }), i.dispatch({
            effects: t
        }), !0
    },
    Rn = [{
        key: "Ctrl-Shift-[",
        mac: "Cmd-Alt-[",
        run: en
    }, {
        key: "Ctrl-Shift-]",
        mac: "Cmd-Alt-]",
        run: tn
    }, {
        key: "Ctrl-Alt-[",
        run: rn
    }, {
        key: "Ctrl-Alt-]",
        run: nn
    }],
    sn = {
        placeholderDOM: null,
        preparePlaceholder: null,
        placeholderText: "…"
    },
    Gt = Z.define({
        combine(i) {
            return Nt(i, sn)
        }
    });

function Jt(i) {
    return [he, an]
}

function Kt(i, e) {
    let {
        state: t
    } = i, r = t.facet(Gt), n = l => {
        let o = i.lineBlockAt(i.posAtDOM(l.target)),
            a = Ee(i.state, o.from, o.to);
        a && i.dispatch({
            effects: xe.of(a)
        }), l.preventDefault()
    };
    if (r.placeholderDOM) return r.placeholderDOM(i, n, e);
    let s = document.createElement("span");
    return s.textContent = r.placeholderText, s.setAttribute("aria-label", t.phrase("folded code")), s.title = t.phrase("unfold"), s.className = "cm-foldPlaceholder", s.onclick = n, s
}
const vt = H.replace({
    widget: new class extends It {
        toDOM(i) {
            return Kt(i, null)
        }
    }
});
class ln extends It {
    constructor(e) {
        super(), this.value = e
    }
    eq(e) {
        return this.value == e.value
    }
    toDOM(e) {
        return Kt(e, this.value)
    }
}
const on = {
    openText: "⌄",
    closedText: "›",
    markerDOM: null,
    domEventHandlers: {},
    foldingChanged: () => !1
};
class je extends hr {
    constructor(e, t) {
        super(), this.config = e, this.open = t
    }
    eq(e) {
        return this.config == e.config && this.open == e.open
    }
    toDOM(e) {
        if (this.config.markerDOM) return this.config.markerDOM(this.open);
        let t = document.createElement("span");
        return t.textContent = this.open ? this.config.openText : this.config.closedText, t.title = e.state.phrase(this.open ? "Fold line" : "Unfold line"), t
    }
}

function zn(i = {}) {
    let e = Object.assign(Object.assign({}, on), i),
        t = new je(e, !0),
        r = new je(e, !1),
        n = Qe.fromClass(class {
            constructor(l) {
                this.from = l.viewport.from, this.markers = this.buildMarkers(l)
            }
            update(l) {
                (l.docChanged || l.viewportChanged || l.startState.facet(ne) != l.state.facet(ne) || l.startState.field(he, !1) != l.state.field(he, !1) || U(l.startState) != U(l.state) || e.foldingChanged(l)) && (this.markers = this.buildMarkers(l.view))
            }
            buildMarkers(l) {
                let o = new Tt;
                for (let a of l.viewportLineBlocks) {
                    let h = Ee(l.state, a.from, a.to) ? r : De(l.state, a.from, a.to) ? t : null;
                    h && o.add(a.from, a.from, h)
                }
                return o.finish()
            }
        }),
        {
            domEventHandlers: s
        } = e;
    return [n, ar({
        class: "cm-foldGutter",
        markers(l) {
            var o;
            return ((o = l.plugin(n)) === null || o === void 0 ? void 0 : o.markers) || cr.empty
        },
        initialSpacer() {
            return new je(e, !1)
        },
        domEventHandlers: Object.assign(Object.assign({}, s), {
            click: (l, o, a) => {
                if (s.click && s.click(l, o, a)) return !0;
                let h = Ee(l.state, o.from, o.to);
                if (h) return l.dispatch({
                    effects: xe.of(h)
                }), !0;
                let f = De(l.state, o.from, o.to);
                return f ? (l.dispatch({
                    effects: Fe.of(f)
                }), !0) : !1
            }
        })
    }), Jt()]
}
const an = X.baseTheme({
    ".cm-foldPlaceholder": {
        backgroundColor: "#eee",
        border: "1px solid #ddd",
        color: "#888",
        borderRadius: ".2em",
        margin: "0 1px",
        padding: "0 1px",
        cursor: "pointer"
    },
    ".cm-foldGutter span": {
        padding: "0 1px",
        cursor: "pointer"
    }
});
class rt {
    constructor(e, t) {
        this.specs = e;
        let r;

        function n(o) {
            let a = ot.newName();
            return (r || (r = Object.create(null)))["." + a] = o, a
        }
        const s = typeof t.all == "string" ? t.all : t.all ? n(t.all) : void 0,
            l = t.scope;
        this.scope = l instanceof W ? o => o.prop(ae) == l.data : l ? o => o == l : void 0, this.style = _t(e.map(o => ({
            tag: o.tag,
            class: o.class || n(Object.assign({}, o, {
                tag: null
            }))
        })), {
            all: s
        }).style, this.module = r ? new ot(r) : null, this.themeType = t.themeType
    }
    static define(e, t) {
        return new rt(e, t || {})
    }
}
const $e = Z.define(),
    Qt = Z.define({
        combine(i) {
            return i.length ? [i[0]] : null
        }
    });

function Ne(i) {
    let e = i.facet($e);
    return e.length ? e : i.facet(Qt)
}

function Ln(i, e) {
    let t = [fn],
        r;
    return i instanceof rt && (i.module && t.push(X.styleModule.of(i.module)), r = i.themeType), e != null && e.fallback ? t.push(Qt.of(i)) : r ? t.push($e.computeN([X.darkTheme], n => n.facet(X.darkTheme) == (r == "dark") ? [i] : [])) : t.push($e.of(i)), t
}

function jn(i, e, t) {
    let r = Ne(i),
        n = null;
    if (r) {
        for (let s of r)
            if (!s.scope || t) {
                let l = s.style(e);
                l && (n = n ? n + " " + l : l)
            }
    }
    return n
}
class hn {
    constructor(e) {
        this.markCache = Object.create(null), this.tree = U(e.state), this.decorations = this.buildDeco(e, Ne(e.state)), this.decoratedTo = e.viewport.to
    }
    update(e) {
        let t = U(e.state),
            r = Ne(e.state),
            n = r != Ne(e.startState),
            {
                viewport: s
            } = e.view,
            l = e.changes.mapPos(this.decoratedTo, 1);
        t.length < s.to && !n && t.type == this.tree.type && l >= s.to ? (this.decorations = this.decorations.map(e.changes), this.decoratedTo = l) : (t != this.tree || e.viewportChanged || n) && (this.tree = t, this.decorations = this.buildDeco(e.view, r), this.decoratedTo = s.to)
    }
    buildDeco(e, t) {
        if (!t || !this.tree.length) return H.none;
        let r = new Tt;
        for (let {
                from: n,
                to: s
            } of e.visibleRanges) Dr(this.tree, t, (l, o, a) => {
            r.add(l, o, this.markCache[a] || (this.markCache[a] = H.mark({
                class: a
            })))
        }, n, s);
        return r.finish()
    }
}
const fn = or.high(Qe.fromClass(hn, {
        decorations: i => i.decorations
    })),
    un = X.baseTheme({
        "&.cm-focused .cm-matchingBracket": {
            backgroundColor: "#328c8252"
        },
        "&.cm-focused .cm-nonmatchingBracket": {
            backgroundColor: "#bb555544"
        }
    }),
    Xt = 1e4,
    Yt = "()[]{}",
    Zt = Z.define({
        combine(i) {
            return Nt(i, {
                afterCursor: !0,
                brackets: Yt,
                maxScanDistance: Xt,
                renderMatch: pn
            })
        }
    }),
    cn = H.mark({
        class: "cm-matchingBracket"
    }),
    dn = H.mark({
        class: "cm-nonmatchingBracket"
    });

function pn(i) {
    let e = [],
        t = i.matched ? cn : dn;
    return e.push(t.range(i.start.from, i.start.to)), i.end && e.push(t.range(i.end.from, i.end.to)), e
}
const gn = Ke.define({
        create() {
            return H.none
        },
        update(i, e) {
            if (!e.docChanged && !e.selection) return i;
            let t = [],
                r = e.state.facet(Zt);
            for (let n of e.state.selection.ranges) {
                if (!n.empty) continue;
                let s = Pe(e.state, n.head, -1, r) || n.head > 0 && Pe(e.state, n.head - 1, 1, r) || r.afterCursor && (Pe(e.state, n.head, 1, r) || n.head < e.state.doc.length && Pe(e.state, n.head + 1, -1, r));
                s && (t = t.concat(r.renderMatch(s, e.state)))
            }
            return H.set(t, !0)
        },
        provide: i => X.decorations.from(i)
    }),
    mn = [gn, un];

function Wn(i = {}) {
    return [Zt.of(i), mn]
}
const kn = new k;

function Ge(i, e, t) {
    let r = i.prop(e < 0 ? k.openedBy : k.closedBy);
    if (r) return r;
    if (i.name.length == 1) {
        let n = t.indexOf(i.name);
        if (n > -1 && n % 2 == (e < 0 ? 1 : 0)) return [t[n + e]]
    }
    return null
}

function Je(i) {
    let e = i.type.prop(kn);
    return e ? e(i.node) : i
}

function Pe(i, e, t, r = {}) {
    let n = r.maxScanDistance || Xt,
        s = r.brackets || Yt,
        l = U(i),
        o = l.resolveInner(e, t);
    for (let a = o; a; a = a.parent) {
        let h = Ge(a.type, t, s);
        if (h && a.from < a.to) {
            let f = Je(a);
            if (f && (t > 0 ? e >= f.from && e < f.to : e > f.from && e <= f.to)) return bn(i, e, t, a, f, h, s)
        }
    }
    return yn(i, e, t, l, o.type, n, s)
}

function bn(i, e, t, r, n, s, l) {
    let o = r.parent,
        a = {
            from: n.from,
            to: n.to
        },
        h = 0,
        f = o == null ? void 0 : o.cursor();
    if (f && (t < 0 ? f.childBefore(r.from) : f.childAfter(r.to)))
        do
            if (t < 0 ? f.to <= r.from : f.from >= r.to) {
                if (h == 0 && s.indexOf(f.type.name) > -1 && f.from < f.to) {
                    let u = Je(f);
                    return {
                        start: a,
                        end: u ? {
                            from: u.from,
                            to: u.to
                        } : void 0,
                        matched: !0
                    }
                } else if (Ge(f.type, t, l)) h++;
                else if (Ge(f.type, -t, l)) {
                    if (h == 0) {
                        let u = Je(f);
                        return {
                            start: a,
                            end: u && u.from < u.to ? {
                                from: u.from,
                                to: u.to
                            } : void 0,
                            matched: !1
                        }
                    }
                    h--
                }
            }
    while (t < 0 ? f.prevSibling() : f.nextSibling());
    return {
        start: a,
        matched: !1
    }
}

function yn(i, e, t, r, n, s, l) {
    let o = t < 0 ? i.sliceDoc(e - 1, e) : i.sliceDoc(e, e + 1),
        a = l.indexOf(o);
    if (a < 0 || a % 2 == 0 != t > 0) return null;
    let h = {
            from: t < 0 ? e - 1 : e,
            to: t > 0 ? e + 1 : e
        },
        f = i.doc.iterRange(e, t > 0 ? i.doc.length : 0),
        u = 0;
    for (let d = 0; !f.next().done && d <= s;) {
        let p = f.value;
        t < 0 && (d += p.length);
        let x = e + d * t;
        for (let S = t > 0 ? 0 : p.length - 1, D = t > 0 ? p.length : -1; S != D; S += t) {
            let O = l.indexOf(p[S]);
            if (!(O < 0 || r.resolveInner(x + S, 1).type != n))
                if (O % 2 == 0 == t > 0) u++;
                else {
                    if (u == 1) return {
                        start: h,
                        end: {
                            from: x + S,
                            to: x + S + 1
                        },
                        matched: O >> 1 == a >> 1
                    };
                    u--
                }
        }
        t > 0 && (d += p.length)
    }
    return f.done ? {
        start: h,
        matched: !1
    } : null
}

function St(i, e, t, r = 0, n = 0) {
    e == null && (e = i.search(/[^\s\u00a0]/), e == -1 && (e = i.length));
    let s = n;
    for (let l = r; l < e; l++) i.charCodeAt(l) == 9 ? s += t - s % t : s++;
    return s
}
class er {
    constructor(e, t, r, n) {
        this.string = e, this.tabSize = t, this.indentUnit = r, this.overrideIndent = n, this.pos = 0, this.start = 0, this.lastColumnPos = 0, this.lastColumnValue = 0
    }
    eol() {
        return this.pos >= this.string.length
    }
    sol() {
        return this.pos == 0
    }
    peek() {
        return this.string.charAt(this.pos) || void 0
    }
    next() {
        if (this.pos < this.string.length) return this.string.charAt(this.pos++)
    }
    eat(e) {
        let t = this.string.charAt(this.pos),
            r;
        if (typeof e == "string" ? r = t == e : r = t && (e instanceof RegExp ? e.test(t) : e(t)), r) return ++this.pos, t
    }
    eatWhile(e) {
        let t = this.pos;
        for (; this.eat(e););
        return this.pos > t
    }
    eatSpace() {
        let e = this.pos;
        for (;
            /[\s\u00a0]/.test(this.string.charAt(this.pos));) ++this.pos;
        return this.pos > e
    }
    skipToEnd() {
        this.pos = this.string.length
    }
    skipTo(e) {
        let t = this.string.indexOf(e, this.pos);
        if (t > -1) return this.pos = t, !0
    }
    backUp(e) {
        this.pos -= e
    }
    column() {
        return this.lastColumnPos < this.start && (this.lastColumnValue = St(this.string, this.start, this.tabSize, this.lastColumnPos, this.lastColumnValue), this.lastColumnPos = this.start), this.lastColumnValue
    }
    indentation() {
        var e;
        return (e = this.overrideIndent) !== null && e !== void 0 ? e : St(this.string, null, this.tabSize)
    }
    match(e, t, r) {
        if (typeof e == "string") {
            let n = l => r ? l.toLowerCase() : l,
                s = this.string.substr(this.pos, e.length);
            return n(s) == n(e) ? (t !== !1 && (this.pos += e.length), !0) : null
        } else {
            let n = this.string.slice(this.pos).match(e);
            return n && n.index > 0 ? null : (n && t !== !1 && (this.pos += n[0].length), n)
        }
    }
    current() {
        return this.string.slice(this.start, this.pos)
    }
}

function xn(i) {
    return {
        name: i.name || "",
        token: i.token,
        blankLine: i.blankLine || (() => {}),
        startState: i.startState || (() => !0),
        copyState: i.copyState || wn,
        indent: i.indent || (() => null),
        languageData: i.languageData || {},
        tokenTable: i.tokenTable || it
    }
}

function wn(i) {
    if (typeof i != "object") return i;
    let e = {};
    for (let t in i) {
        let r = i[t];
        e[t] = r instanceof Array ? r.slice() : r
    }
    return e
}
const At = new WeakMap;
class tr extends W {
    constructor(e) {
        let t = Ft(e.languageData),
            r = xn(e),
            n, s = new class extends Dt {
                createParse(l, o, a) {
                    return new Sn(n, l, o, a)
                }
            };
        super(t, s, [zt.of((l, o) => this.getIndent(l, o))], e.name), this.topNode = Pn(t), n = this, this.streamParser = r, this.stateAfter = new k({
            perNode: !0
        }), this.tokenTable = e.tokenTable ? new sr(r.tokenTable) : Cn
    }
    static define(e) {
        return new tr(e)
    }
    getIndent(e, t) {
        let r = U(e.state),
            n = r.resolve(t);
        for (; n && n.type != this.topNode;) n = n.parent;
        if (!n) return null;
        let s, {
            overrideIndentation: l
        } = e.options;
        l && (s = At.get(e.state), s != null && s < t - 1e4 && (s = void 0));
        let o = nt(this, r, 0, n.from, s != null ? s : t),
            a, h;
        if (o ? (h = o.state, a = o.pos + 1) : (h = this.streamParser.startState(e.unit), a = 0), t - a > 1e4) return null;
        for (; a < t;) {
            let u = e.state.doc.lineAt(a),
                d = Math.min(t, u.to);
            if (u.length) {
                let p = l ? l(u.from) : -1,
                    x = new er(u.text, e.state.tabSize, e.unit, p < 0 ? void 0 : p);
                for (; x.pos < d - u.from;) nr(this.streamParser.token, x, h)
            } else this.streamParser.blankLine(h, e.unit);
            if (d == t) break;
            a = u.to + 1
        }
        let f = e.lineAt(t);
        return l && s == null && At.set(e.state, f.from), this.streamParser.indent(h, /^\s*(.*)/.exec(f.text)[1], e)
    }
    get allowsNesting() {
        return !1
    }
}

function nt(i, e, t, r, n) {
    let s = t >= r && t + e.length <= n && e.prop(i.stateAfter);
    if (s) return {
        state: i.streamParser.copyState(s),
        pos: t + e.length
    };
    for (let l = e.children.length - 1; l >= 0; l--) {
        let o = e.children[l],
            a = t + e.positions[l],
            h = o instanceof C && a < n && nt(i, o, a, r, n);
        if (h) return h
    }
    return null
}

function rr(i, e, t, r, n) {
    if (n && t <= 0 && r >= e.length) return e;
    !n && e.type == i.topNode && (n = !0);
    for (let s = e.children.length - 1; s >= 0; s--) {
        let l = e.positions[s],
            o = e.children[s],
            a;
        if (l < r && o instanceof C) {
            if (!(a = rr(i, o, t - l, r - l, n))) break;
            return n ? new C(e.type, e.children.slice(0, s).concat(a), e.positions.slice(0, s + 1), l + a.length) : a
        }
    }
    return null
}

function vn(i, e, t, r) {
    for (let n of e) {
        let s = n.from + (n.openStart ? 25 : 0),
            l = n.to - (n.openEnd ? 25 : 0),
            o = s <= t && l > t && nt(i, n.tree, 0 - n.offset, t, l),
            a;
        if (o && (a = rr(i, n.tree, t + n.offset, o.pos + n.offset, !1))) return {
            state: o.state,
            tree: a
        }
    }
    return {
        state: i.streamParser.startState(r ? Oe(r) : 4),
        tree: C.empty
    }
}
class Sn {
    constructor(e, t, r, n) {
        this.lang = e, this.input = t, this.fragments = r, this.ranges = n, this.stoppedAt = null, this.chunks = [], this.chunkPos = [], this.chunk = [], this.chunkReused = void 0, this.rangeIndex = 0, this.to = n[n.length - 1].to;
        let s = ce.get(),
            l = n[0].from,
            {
                state: o,
                tree: a
            } = vn(e, r, l, s == null ? void 0 : s.state);
        this.state = o, this.parsedPos = this.chunkStart = l + a.length;
        for (let h = 0; h < a.children.length; h++) this.chunks.push(a.children[h]), this.chunkPos.push(a.positions[h]);
        s && this.parsedPos < s.viewport.from - 1e5 && (this.state = this.lang.streamParser.startState(Oe(s.state)), s.skipUntilInView(this.parsedPos, s.viewport.from), this.parsedPos = s.viewport.from), this.moveRangeIndex()
    }
    advance() {
        let e = ce.get(),
            t = this.stoppedAt == null ? this.to : Math.min(this.to, this.stoppedAt),
            r = Math.min(t, this.chunkStart + 2048);
        for (e && (r = Math.min(r, e.viewport.to)); this.parsedPos < r;) this.parseLine(e);
        return this.chunkStart < this.parsedPos && this.finishChunk(), this.parsedPos >= t ? this.finish() : e && this.parsedPos >= e.viewport.to ? (e.skipUntilInView(this.parsedPos, t), this.finish()) : null
    }
    stopAt(e) {
        this.stoppedAt = e
    }
    lineAfter(e) {
        let t = this.input.chunk(e);
        if (this.input.lineChunks) t == "\n" && (t = "");
        else {
            let r = t.indexOf("\n");
            r > -1 && (t = t.slice(0, r))
        }
        return e + t.length <= this.to ? t : t.slice(0, this.to - e)
    }
    nextLine() {
        let e = this.parsedPos,
            t = this.lineAfter(e),
            r = e + t.length;
        for (let n = this.rangeIndex;;) {
            let s = this.ranges[n].to;
            if (s >= r || (t = t.slice(0, s - (r - t.length)), n++, n == this.ranges.length)) break;
            let l = this.ranges[n].from,
                o = this.lineAfter(l);
            t += o, r = l + o.length
        }
        return {
            line: t,
            end: r
        }
    }
    skipGapsTo(e, t, r) {
        for (;;) {
            let n = this.ranges[this.rangeIndex].to,
                s = e + t;
            if (r > 0 ? n > s : n >= s) break;
            let l = this.ranges[++this.rangeIndex].from;
            t += l - n
        }
        return t
    }
    moveRangeIndex() {
        for (; this.ranges[this.rangeIndex].to < this.parsedPos;) this.rangeIndex++
    }
    emitToken(e, t, r, n, s) {
        if (this.ranges.length > 1) {
            s = this.skipGapsTo(t, s, 1), t += s;
            let l = this.chunk.length;
            s = this.skipGapsTo(r, s, -1), r += s, n += this.chunk.length - l
        }
        return this.chunk.push(e, t, r, n), s
    }
    parseLine(e) {
        let {
            line: t,
            end: r
        } = this.nextLine(), n = 0, {
            streamParser: s
        } = this.lang, l = new er(t, e ? e.state.tabSize : 4, e ? Oe(e.state) : 2);
        if (l.eol()) s.blankLine(this.state, l.indentUnit);
        else
            for (; !l.eol();) {
                let o = nr(s.token, l, this.state);
                if (o && (n = this.emitToken(this.lang.tokenTable.resolve(o), this.parsedPos + l.start, this.parsedPos + l.pos, 4, n)), l.start > 1e4) break
            }
        this.parsedPos = r, this.moveRangeIndex(), this.parsedPos < this.to && this.parsedPos++
    }
    finishChunk() {
        let e = C.build({
            buffer: this.chunk,
            start: this.chunkStart,
            length: this.parsedPos - this.chunkStart,
            nodeSet: An,
            topID: 0,
            maxBufferLength: 2048,
            reused: this.chunkReused
        });
        e = new C(e.type, e.children, e.positions, e.length, [
            [this.lang.stateAfter, this.lang.streamParser.copyState(this.state)]
        ]), this.chunks.push(e), this.chunkPos.push(this.chunkStart - this.ranges[0].from), this.chunk = [], this.chunkReused = void 0, this.chunkStart = this.parsedPos
    }
    finish() {
        return new C(this.lang.topNode, this.chunks, this.chunkPos, this.parsedPos - this.ranges[0].from).balance()
    }
}

function nr(i, e, t) {
    e.start = e.pos;
    for (let r = 0; r < 10; r++) {
        let n = i(e, t);
        if (e.pos > e.start) return n
    }
    throw new Error("Stream parser failed to advance stream.")
}
const it = Object.create(null),
    ye = [F.none],
    An = new Xe(ye),
    Ct = [],
    Pt = Object.create(null),
    ir = Object.create(null);
for (let [i, e] of [
        ["variable", "variableName"],
        ["variable-2", "variableName.special"],
        ["string-2", "string.special"],
        ["def", "variableName.definition"],
        ["tag", "tagName"],
        ["attribute", "attributeName"],
        ["type", "typeName"],
        ["builtin", "variableName.standard"],
        ["qualifier", "modifier"],
        ["error", "invalid"],
        ["header", "heading"],
        ["property", "propertyName"]
    ]) ir[i] = lr(it, e);
class sr {
    constructor(e) {
        this.extra = e, this.table = Object.assign(Object.create(null), ir)
    }
    resolve(e) {
        return e ? this.table[e] || (this.table[e] = lr(this.extra, e)) : 0
    }
}
const Cn = new sr(it);

function We(i, e) {
    Ct.indexOf(i) > -1 || (Ct.push(i), console.warn(e))
}

function lr(i, e) {
    let t = [];
    for (let o of e.split(" ")) {
        let a = [];
        for (let h of o.split(".")) {
            let f = i[h] || m[h];
            f ? typeof f == "function" ? a.length ? a = a.map(f) : We(h, "Modifier ".concat(h, " used at start of tag")) : a.length ? We(h, "Tag ".concat(h, " used as modifier")) : a = Array.isArray(f) ? f : [f] : We(h, "Unknown highlighting tag ".concat(h))
        }
        for (let h of a) t.push(h)
    }
    if (!t.length) return 0;
    let r = e.replace(/ /g, "_"),
        n = r + " " + t.map(o => o.id),
        s = Pt[n];
    if (s) return s.id;
    let l = Pt[n] = F.define({
        id: ye.length,
        name: r,
        props: [Mr({
            [r]: t
        })]
    });
    return ye.push(l), l.id
}

function Pn(i) {
    let e = F.define({
        id: ye.length,
        name: "Document",
        props: [ae.add(() => i)],
        top: !0
    });
    return ye.push(e), e
}
at.RTL, at.LTR;
export {
    zn as A, Rn as B, Ln as C, dr as D, _n as E, rt as H, I, qe as L, Xe as N, Dt as P, tr as S, C as T, F as a, k as b, Mn as c, En as d, U as e, Qr as f, Fn as g, Nn as h, Wr as i, kn as j, On as k, Dn as l, Fr as m, Ft as n, Lt as o, In as p, jt as q, jr as r, Mr as s, m as t, Lr as u, Pe as v, Oe as w, Dr as x, jn as y, Wn as z
};
//# sourceMappingURL=c2wfb3iy9wkb85gs.js.map