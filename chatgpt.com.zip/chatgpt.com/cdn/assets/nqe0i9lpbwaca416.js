import {
    c as e,
    s as t
} from "./dykg4ktvbu3mhmdo.js";
const s = e(t, "b06de3", 20, 20);
export {
    s as M
};
//# sourceMappingURL=nqe0i9lpbwaca416.js.map