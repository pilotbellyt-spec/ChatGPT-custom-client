import {
    h as w
} from "./fg33krlcm0qyi6yw.js";
import {
    uK as C,
    uL as E,
    mX as R,
    uM as H,
    uN as S,
    uO as U,
    jq as W
} from "./dykg4ktvbu3mhmdo.js";
import {
    mX as X
} from "./k15yxxoybkkir2ou.js";
var L, x;

function D() {
    if (x) return L;
    x = 1;
    var t = C(),
        s = E(),
        n = U(),
        I = R(),
        _ = H(),
        a = S(),
        u = Math.min;

    function m(c, h, f) {
        for (var A = f ? n : s, O = c[0].length, v = c.length, e = v, l = Array(v), g = 1 / 0, b = []; e--;) {
            var r = c[e];
            e && h && (r = I(r, _(h))), g = u(r.length, g), l[e] = !f && (h || O >= 120 && r.length >= 120) ? new t(e && r) : void 0
        }
        r = c[0];
        var k = -1,
            q = l[0];
        e: for (; ++k < O && b.length < g;) {
            var i = r[k],
                o = h ? h(i) : i;
            if (i = f || i !== 0 ? i : 0, !(q ? a(q, o) : A(b, o, f))) {
                for (e = v; --e;) {
                    var y = l[e];
                    if (!(y ? a(y, o) : A(c[e], o, f))) continue e
                }
                q && q.push(o), b.push(i)
            }
        }
        return b
    }
    return L = m, L
}
var d, M;

function F() {
    if (M) return d;
    M = 1;
    var t = X();

    function s(n) {
        return t(n) ? n : []
    }
    return d = s, d
}
var j, p;

function K() {
    if (p) return j;
    p = 1;
    var t = R(),
        s = D(),
        n = W(),
        I = F(),
        _ = n(function(a) {
            var u = t(a, I);
            return u.length && u[0] === a[0] ? s(u) : []
        });
    return j = _, j
}
var N = K();
const J = w(N);
export {
    J as i
};
//# sourceMappingURL=f1b9xcddv1uk610d.js.map