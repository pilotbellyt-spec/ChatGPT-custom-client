const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/nut5e1nu68zwzskm.js", "assets/fg33krlcm0qyi6yw.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/o4n6pqcoqgw7owdr.js", "assets/k15yxxoybkkir2ou.js", "assets/conversation-small-332fs9rk.css", "assets/bo2v113kbgrh2zlp.js", "assets/65wh49bi0uv7dyfy.js", "assets/hod0x7g0nytg7mip.js", "assets/jqmv39tyqoumt55b.js", "assets/gd2ozzf4upgi0amm.js", "assets/glhgbnfau97gd4im.js"]))) => i.map(i => d[i]);
var Le = Object.freeze,
    Be = Object.defineProperty,
    Et = Object.defineProperties;
var Nt = Object.getOwnPropertyDescriptors;
var De = Object.getOwnPropertySymbols;
var At = Object.prototype.hasOwnProperty,
    It = Object.prototype.propertyIsEnumerable;
var Oe = (t, e, a) => e in t ? Be(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: a
    }) : t[e] = a,
    S = (t, e) => {
        for (var a in e || (e = {})) At.call(e, a) && Oe(t, a, e[a]);
        if (De)
            for (var a of De(e)) It.call(e, a) && Oe(t, a, e[a]);
        return t
    },
    L = (t, e) => Et(t, Nt(e));
var W = (t, e) => Le(Be(t, "raw", {
    value: Le(e || t.slice())
}));
import {
    e as I,
    r as M,
    j as s,
    M as b,
    b as rt,
    a as it,
    u as Q,
    c as F,
    f as xe,
    m as te,
    i as z,
    n as ye,
    _ as Me
} from "./fg33krlcm0qyi6yw.js";
import {
    m as se,
    ag as Pe,
    w as Rt,
    M as U,
    aK as B,
    C as T,
    aa as Tt,
    R as Z,
    n as Lt,
    c0 as ke,
    r0 as Dt,
    r1 as Fe,
    E as Ot,
    aF as ge,
    aG as pe,
    b as D,
    H as de,
    hj as Bt,
    dI as Ft,
    Ab as Gt,
    b9 as Wt,
    T as Ut,
    a9 as R,
    bv as lt,
    hv as Se,
    hh as Vt,
    gd as $t,
    dB as Ht,
    o as $,
    f$ as zt,
    bg as Yt,
    aY as ct,
    g2 as q,
    v1 as Qt,
    gv as Kt,
    P as ae,
    dQ as qt,
    _ as le,
    fP as ce,
    x as Xt,
    F as Y,
    aL as H,
    z as Jt,
    c_ as K,
    im as we,
    cQ as Zt,
    u0 as es,
    B as re,
    cy as ts,
    yx as ss,
    Ap as as,
    c1 as os,
    b3 as dt,
    e as ns,
    Y as rs,
    qI as fe,
    Z as ut,
    S as mt,
    $ as _e,
    hT as is,
    fT as ls,
    of as cs,
    l as he,
    L as ds,
    bX as us,
    c2 as ms,
    d8 as fs,
    I as ft,
    Aq as gs,
    Ar as ps,
    a$ as hs,
    oJ as xs,
    gs as ys,
    bh as Ee
} from "./dykg4ktvbu3mhmdo.js";
import {
    z as js,
    Z as bs,
    aw as Ge,
    ib as vs,
    kS as Cs,
    ab as Ms,
    ac as Ps,
    ax as je,
    ad as ks,
    rz as Ss,
    fu as ws,
    vg as _s,
    de as Es,
    dh as gt,
    db as Ne,
    dc as Ae,
    e7 as Ns,
    ir as As,
    is as Is,
    iu as We,
    iw as Rs,
    iz as Ue,
    dG as pt,
    jG as Ts,
    dr as Ls,
    BF as Ds,
    iA as ve,
    BG as Ce,
    z$ as Os,
    A0 as Bs,
    z_ as Fs,
    BH as Gs,
    di as Ws,
    A5 as Us,
    cV as Vs,
    BI as ee,
    ip as A,
    cH as $s,
    BJ as Hs,
    BK as ht,
    u_ as zs,
    BL as Ys,
    BM as xt,
    BN as Ve,
    BO as Qs,
    BP as Ks,
    du as qs,
    BQ as Xs,
    BR as Js,
    zX as Zs,
    BS as ea,
    m7 as ta
} from "./k15yxxoybkkir2ou.js";
import {
    R as sa
} from "./iji59gix74v3k54p.js";
import {
    s as $e,
    B as aa
} from "./e1qtg70ehhxpvvw9.js";
import {
    d as oa
} from "./kl7c6054usfnqmd4.js";
import {
    g as na
} from "./k97n0y6ba9c9h39c.js";
import {
    u as ra
} from "./bo2v113kbgrh2zlp.js";
import {
    T as ia,
    G as la,
    P as yt,
    A as ca
} from "./hrv77bu834ppv90t.js";
import {
    T as da
} from "./h370k1wse4qy92bx.js";
import {
    E as ua
} from "./jhvz2qkf3st8xisu.js";
import {
    E as ma
} from "./jdg49hmintmo4ij6.js";
import {
    E as fa
} from "./iyee7iaydnyssoa4.js";
import {
    a as ga,
    e as pa
} from "./hfibvokhkz8skuqw.js";
import {
    P as ha
} from "./mtdf3zn500avq96a.js";
import {
    b as xa,
    c as ya
} from "./3jqmuecsvur0aphg.js";
import {
    P as ja
} from "./ky2byeos1ob0g323.js";
import {
    b as Ie
} from "./kk75394dp7aj1ofk.js";
import {
    F as jt,
    a as bt,
    b as vt
} from "./2o5sc48pyb8we7wg.js";
import {
    u as ba
} from "./emixct2ecmtx0izd.js";
import {
    R as J,
    U as va,
    G as Ca
} from "./h1fcjd3llzasn5hk.js";
import {
    u as Ma
} from "./iedtxphyg7px1095.js";
import {
    u as Pa
} from "./b3e7s0c3jzam9sy1.js";
import "./i5kvudettvxsr7pw.js";
import "./hz9475nc5ndyfqsu.js";
import "./ou2xm3xmri21t4zm.js";
import "./o4n6pqcoqgw7owdr.js";
import "./lfxtpzw52mtvoale.js";
import "./m4js9idemp5c8b87.js";
import "./mcy89srphizz0hls.js";
import "./jd9zt1u141h04j00.js";
import "./lfdsdf4it937c4a2.js";
import "./mvl4u7g4pep6uysr.js";
import "./by32wbrf3h6krwuu.js";
import "./knmv36ayr157033d.js";
import "./hldjsmhvi0vrgsw0.js";
import "./h8afdg57t22ai4ff.js";
import "./9xukfjm3wk4gydlw.js";
import "./dmkpfqcl39i5eaqb.js";
import "./mqaxq6uz189xwrrs.js";
import "./oi0jufgbruu7yg53.js";
import "./gogo7bs85ip5x228.js";
import "./n7nqkdn53j3o5j6k.js";
import "./ma6fexe1cysk08ib.js";
import "./mh2edg92ng3qntdf.js";
import "./k2oaaf8ac9lafsub.js";
import "./lans8a2ikbh9ax9r.js";
import "./iej0cupg2dqkmejt.js";
import "./gf03dbmrlccb2uqq.js";
import "./gzhsdx8lam3386fv.js";
import "./uwm5r01je8eaqgfc.js";
import "./newet32g44ysnvsb.js";
import "./djur71wanhd4j63t.js";
import "./ogty5pbz2ckq625a.js";
import "./e3ddui4ro6nb7fig.js";
import "./jdzosouyvpzu0tpb.js";
import "./lcm07h4hrgbddd47.js";
import "./22dgvhxdlo5c1yiw.js";
import "./cehclh0a60ppuuvu.js";
import "./cjybewlxcr1rdyw3.js";
import "./lqog7ixiwnif6sbp.js";
import "./nzl91iujqafxz8y1.js";
import "./ebc4iyfg14nu1gw4.js";
import "./gy1lpvuoewmzh42c.js";
import "./jed1ux7qibe55pmj.js";
import "./h1em0bjkpkjv8ykw.js";
import "./nfccle6oyncifphl.js";
import "./hu1bt0oauegdhua6.js";
import "./b5s349mvbdzayaxi.js";
import "./dbshkzvpochy4889.js";
import "./k78yzov06lrhyte9.js";
import "./cfxpg7jffbmx1lzc.js";
import "./ml3sfbo53uz391cc.js";
import "./elwpnpvd3n8263yf.js";
import "./jjruw0pg8h58hov8.js";
import "./ni16khhtjgvldr4m.js";
import "./hn5e71c3hkpkv00z.js";
import "./cgt1h5qo3k52ojx3.js";
import "./bmupik4h4l2k89rq.js";
import "./flbjosd8n90k89o3.js";
import "./jnh7gh80gtj0452q.js";
import "./hvtbwt8zpnifppmo.js";
import "./gbylonw1dsrig9gv.js";
import "./ohbt708he61xvuqb.js";
import "./nzsuppseubp10m1q.js";
import "./fkgr3i4r43mv04zi.js";
import "./bgu63yibe22v7x29.js";

function ka(t) {
    return rt({
        queryKey: ["workspace", t, "owner_count"],
        queryFn: async () => await Z.safeGet("/accounts/{account_id}/users/owner_count", {
            parameters: {
                path: {
                    account_id: t
                }
            }
        })
    })
}

function Sa({
    workspace: t
}) {
    var k;
    const e = I(),
        a = se(),
        n = Pe(),
        [o, r] = M.useState(""),
        d = t.isOwnerOfAccount(),
        i = ka(t.id),
        {
            data: l
        } = Rt(),
        [m, f] = M.useState(!1),
        [c, u] = M.useState(!1);
    if (!l) return null;
    const p = l.accountItems.find(w => w.id !== t.id),
        y = () => {
            B.setLeaveWorkspaceData(null)
        },
        j = async () => {
            if (n !== void 0) {
                u(!0);
                try {
                    await Z.safeDelete("/accounts/{account_id}/users/{user_id}", {
                        parameters: {
                            path: {
                                account_id: t.id,
                                user_id: n.id
                            }
                        }
                    }), f(!0)
                } catch (w) {
                    a.danger(e.formatMessage({
                        id: "leaveWorkspaceModal.leaveFailed",
                        defaultMessage: "Failed to leave workspace"
                    }), {
                        toastId: "leave_workspace_modal",
                        loggingTitle: "Failed to leave workspace",
                        loggingDescription: "Error message when user fails to leave workspace"
                    })
                }
                u(!1)
            }
        };
    if (m) return s.jsx(Ea, {
        workspace: t,
        fallbackWorkspace: p,
        onClose: y
    });
    if (!i.data) return s.jsx(wa, {
        onClose: y
    });
    const h = i.data.total_count,
        P = i.data.owner_count;
    if (d && P < 2) return s.jsx(_a, {
        workspace: t,
        onClose: y
    });
    const g = s.jsx(U.Button, {
            onClick: () => {
                B.setLeaveWorkspaceData(null)
            },
            title: e.formatMessage({
                id: "leaveWorkspaceModal.cancel",
                defaultMessage: "Cancel"
            })
        }),
        v = s.jsx(U.Button, {
            color: "danger",
            disabled: n === void 0 || c || o === "" || o.toLowerCase() !== ((k = n == null ? void 0 : n.email) == null ? void 0 : k.toLowerCase()),
            title: e.formatMessage({
                id: "leaveWorkspaceModal.leaveButton",
                defaultMessage: "Leave workspace"
            }),
            onClick: () => j()
        }),
        C = e.formatMessage({
            id: "leaveWorkspaceModal.enterEmailToConfirm",
            defaultMessage: "Leave Workspace - Enter your email to confirm"
        });
    return s.jsx(T, {
        testId: "modal-leave-workspace",
        isOpen: !0,
        onClose: y,
        showCloseButton: !0,
        type: "danger",
        title: e.formatMessage({
            id: "leaveWorkspaceModal.leaveWorkspace",
            defaultMessage: "Leave the {workspaceName} workspace"
        }, {
            workspaceName: t.data.name
        }),
        primaryButton: v,
        secondaryButton: g,
        children: s.jsxs("div", {
            className: "flex flex-col gap-5",
            children: [s.jsxs("div", {
                className: "flex flex-row gap-3",
                children: [s.jsx(Tt, {
                    size: "large",
                    src: t.data.profilePictureUrl
                }), s.jsxs("div", {
                    className: "flex flex-col justify-around",
                    children: [s.jsx("div", {
                        className: "text-base font-semibold",
                        children: t.data.name
                    }), s.jsx("div", {
                        className: "text-token-text-tertiary text-sm",
                        children: s.jsx(b, {
                            id: "leaveWorkspaceModal.memberCount",
                            defaultMessage: "{memberCount, plural,\n                  one {1 member}\n                  other {{memberCount} members}\n                }",
                            values: {
                                memberCount: h
                            }
                        })
                    })]
                })]
            }), s.jsxs("div", {
                children: [s.jsx("h3", {
                    className: "mb-2 text-base font-semibold",
                    children: s.jsx(b, {
                        id: "leaveWorkspaceModal.leaveAreYouSure",
                        defaultMessage: "Are you sure?"
                    })
                }), s.jsxs("ul", {
                    className: "text-token-text-secondary ms-3 list-disc text-sm",
                    children: [s.jsx("li", {
                        className: "mb-2",
                        children: s.jsx(b, {
                            id: "leaveWorkspaceModal.leaveWorkspaceWarning1",
                            defaultMessage: "This will remove you from your workspace and you won't be able to access all data, including profile, settings, and chat history."
                        })
                    }), s.jsx("li", {
                        children: s.jsx(b, {
                            id: "leaveWorkspaceModal.leaveWorkspaceWarning2",
                            defaultMessage: "You will lose access to all channels and messages in this workspace."
                        })
                    })]
                })]
            }), s.jsxs("div", {
                children: [s.jsx("h3", {
                    className: "mb-2 text-base font-semibold",
                    children: C
                }), s.jsx(js, {
                    ariaLabel: C,
                    name: "typeEmailConfirm",
                    placeholder: "abcd@acme.com",
                    value: o,
                    onChange: w => {
                        r(w.target.value)
                    }
                })]
            })]
        })
    })
}

function wa({
    onClose: t
}) {
    return s.jsx(T, {
        testId: "modal-empty-loading",
        isOpen: !0,
        onClose: t,
        showCloseButton: !0,
        type: "warning",
        children: s.jsx("div", {
            className: "flex flex-row justify-center",
            children: s.jsx(ke, {})
        })
    })
}

function _a({
    workspace: t,
    onClose: e
}) {
    const a = I(),
        n = s.jsx(U.Button, {
            onClick: () => {
                B.setLeaveWorkspaceData(null)
            },
            title: a.formatMessage({
                id: "leaveWorkspaceModal.ok",
                defaultMessage: "OK"
            })
        });
    return s.jsx(T, {
        testId: "modal-cant-leave-workspace",
        isOpen: !0,
        onClose: e,
        showCloseButton: !0,
        type: "danger",
        title: a.formatMessage({
            id: "leaveWorkspaceModal.cantLeaveWorkspace",
            defaultMessage: "Couldn't leave the {workspaceName} workspace"
        }, {
            workspaceName: t.data.name
        }),
        secondaryButton: n,
        children: s.jsx(b, {
            id: "leaveWorkspaceModal.lastOwnerWarning",
            defaultMessage: "Because you're the only owner in the {workspaceName} workspace, assign the owner role to another member before leaving.",
            values: {
                workspaceName: t.data.name
            }
        })
    })
}

function Ea({
    workspace: t,
    fallbackWorkspace: e,
    onClose: a
}) {
    const n = it(),
        o = I(),
        r = se(),
        d = D(),
        i = Lt(f => f.currentWorkspace),
        l = () => {
            if (e !== void 0 && i)
                if (B.setLeaveWorkspaceData(null), i.id === t.id) {
                    const {
                        willRedirect: f
                    } = Dt(n, e.id, d, o, r);
                    f || Fe()
                } else n.invalidateQueries(Ot());
            else B.setLeaveWorkspaceData(null), ge.deleteCookie(pe.Workspace), ge.deleteCookie(pe.WorkspaceResidencyRegion), Fe();
            a()
        },
        m = e !== void 0 ? s.jsx(U.Button, {
            color: "primary",
            onClick: l,
            title: o.formatMessage({
                id: "leaveWorkspaceModal.done",
                defaultMessage: "Done"
            })
        }) : s.jsx(U.Button, {
            color: "primary",
            onClick: l,
            title: o.formatMessage({
                id: "leaveWorkspaceModal.startPersonalAccount",
                defaultMessage: "Start using ChatGPT for free"
            })
        });
    return s.jsx(T, {
        testId: "modal-left-workspace",
        isOpen: !0,
        onClose: l,
        primaryButton: m,
        type: "success",
        title: o.formatMessage({
            id: "leaveWorkspaceModal.leftWorkspaceTitle",
            defaultMessage: "Successfully left the {workspaceName} workspace"
        }, {
            workspaceName: t.data.name
        }),
        children: s.jsx("div", {
            className: "flex flex-col gap-5",
            children: s.jsx("p", {
                children: e !== void 0 ? s.jsx(b, {
                    id: "leaveWorkspaceModal.leftWorkspaceDescription",
                    defaultMessage: "You have successfully left the {workspaceName} workspace.",
                    values: {
                        workspaceName: t.data.name
                    }
                }) : s.jsx(b, {
                    id: "leaveWorkspaceModal.leftWorkspaceDescriptionNoOtherWorkspaces",
                    defaultMessage: "You have successfully left the {workspaceName} workspace. This will create your personal workspace automatically.",
                    values: {
                        workspaceName: t.data.name
                    }
                })
            })
        })
    })
}

function Ct(t) {
    var e;
    return !t || !t.attachments || t.attachments.length === 0 || t.attachments[0].kind !== "deep_research" ? null : {
        permissions: (e = t.permissions.share_setting) != null ? e : "public",
        postId: t.id,
        messages: t.attachments[0].messages
    }
}
const Na = "https://chatgpt.com/s/";

function be(t) {
    return "".concat(Na).concat(t)
}

function ne(t) {
    return ["research", "result", "share", t]
}
const Aa = "https://chatgpt.com/post/...";

function Ia({
    taskId: t,
    isLoading: e,
    sharedResearchResult: a,
    title: n,
    serverThreadId: o
}) {
    var P;
    const [r, d] = M.useState(!1), i = (g, v) => {
        g && Se(g, void 0, v).then(() => {
            d(!0), setTimeout(() => {
                d(!1)
            }, 1500)
        }).catch(() => {})
    }, l = it(), m = se(), {
        mutate: f,
        isPending: c
    } = Q({
        scope: {
            id: t
        },
        mutationFn: async g => {
            const v = await Z.safePost("/share/post", {
                requestBody: {
                    attachments_to_create: [{
                        kind: "deep_research",
                        conversation_id: o,
                        task_id: g
                    }]
                }
            });
            return Ct(v.post)
        },
        onSuccess: g => {
            if (!g) {
                m.danger("Failed to create share link");
                return
            }
            l.setQueryData(ne(t), g), i(be(g.postId))
        }
    }), {
        mutate: u
    } = Q({
        scope: {
            id: (P = a == null ? void 0 : a.postId) != null ? P : ""
        },
        mutationFn: async ({
            sharedResearchResultId: g,
            access: v
        }) => (await Z.safePost("/share/post/update_access", {
            requestBody: {
                post_id: g,
                share_settings: v
            }
        })).share_setting,
        onMutate: ({
            access: g
        }) => {
            const v = ne(t),
                C = l.getQueryData(v);
            return l.setQueryData(v, C && L(S({}, C), {
                permissions: g
            })), {
                previousAccess: C == null ? void 0 : C.permissions
            }
        },
        onSuccess: g => {
            const v = ne(t),
                C = l.getQueryData(v);
            C && l.setQueryData(v, L(S({}, C), {
                permissions: g
            }))
        },
        onError: (g, v, C) => {
            var E;
            const k = ne(t),
                w = l.getQueryData(k);
            l.setQueryData(k, w && L(S({}, w), {
                permissions: (E = C == null ? void 0 : C.previousAccess) != null ? E : "public"
            }))
        }
    }), x = M.useRef(null), p = g => {
        var v;
        (v = x.current) == null || v.focus(), a ? i(be(a.postId), g) : f(t)
    }, y = g => {
        a && u({
            sharedResearchResultId: a.postId,
            access: g
        })
    }, j = a ? be(a.postId) : void 0, h = g => {
        switch (g) {
            case "public":
                return je.PUBLIC;
            case "private":
                return je.PRIVATE;
            case "workspace":
                return je.WORKSPACE
        }
    };
    return s.jsx(aa, {
        inputRef: x,
        isLoading: e,
        isPublishedVersionLatest: !0,
        sharedObject: a && {
            id: a.postId,
            title: n,
            access: h(a.permissions)
        },
        title: n,
        shareTextPlaceholder: Aa,
        shareUrl: j,
        isCopySuccessful: r,
        isCreateLinkRequestInProgress: c,
        handlePrivacyChange: y,
        handlePrimaryButtonClick: p
    })
}

function Ra({
    taskId: t,
    isDisabled: e,
    title: a,
    threadId: n
}) {
    const o = de(),
        r = Bt(),
        d = I(),
        i = Ft(n),
        {
            data: l,
            isLoading: m
        } = rt({
            enabled: !!t && !e,
            queryKey: ne(t),
            queryFn: async () => {
                if (!i) return null;
                const j = await Z.safeGet("/share/post/by_research_task/{task_id}", {
                    parameters: {
                        path: {
                            task_id: t
                        }
                    }
                });
                return j.post ? Ct(j.post) : null
            }
        }),
        [f, c] = M.useState(!1),
        {
            triggerRef: u,
            container: x
        } = Gt({
            isOpen: f,
            onClose: () => c(!1)
        }),
        p = (o == null ? void 0 : o.isWorkspaceAccount()) && !(o != null && o.features.includes(Wt.WorkspaceShareLinks));
    if (e || p || !i || r) return s.jsx(Ut, {
        label: p ? d.formatMessage($e.workspaceSharingDisabled) : d.formatMessage($e.share),
        children: s.jsx(bs, {
            disabled: !0,
            icon: Ge
        })
    });
    const y = ({
        className: j
    }) => s.jsxs("div", {
        className: "relative h-fit w-fit",
        children: [s.jsx(Ge, {
            className: j
        }), l && s.jsx("div", {
            className: "absolute end-0 top-[1px] flex items-center gap-1.5",
            children: s.jsx("div", {
                className: "h-1.5 w-1.5 rounded-full"
            })
        })]
    });
    return s.jsxs(vs, {
        open: f,
        onOpenChange: c,
        children: [s.jsx(Cs, {
            ref: u,
            asChild: !0,
            children: s.jsxs(R, {
                children: [s.jsx(y, {
                    className: "me-1 h-4 w-4"
                }), s.jsx(b, {
                    id: "vaZOk/",
                    defaultMessage: "Share Link"
                })]
            })
        }), s.jsx(lt, {
            children: f && s.jsx(Ms, {
                forceMount: !0,
                container: x,
                children: s.jsx(Ps, {
                    align: "end",
                    className: "z-50",
                    sideOffset: 8,
                    collisionPadding: 8,
                    children: s.jsx(Ia, {
                        title: a,
                        taskId: t,
                        sharedResearchResult: l,
                        isLoading: m,
                        serverThreadId: i
                    })
                })
            })
        })]
    })
}
const Ta = ({
    messages: t,
    threadId: e,
    taskId: a
}) => {
    var C;
    const n = I(),
        [o, r] = M.useState(!0),
        d = M.useRef(null),
        i = Vt(e),
        l = $t(t),
        [m, f] = M.useState(!1),
        c = se(),
        u = D(),
        x = Ht(u, e),
        p = $(u, "3930843960"),
        y = $(u, "1596731578"),
        j = n.formatMessage({
            id: "deepresearch.downloadFileError",
            defaultMessage: "Failed to download file. Please try again later."
        }),
        h = async k => {
            var w;
            if (l) {
                if (!i) {
                    c.warning("Failed to download file. Please try refreshing the page."), ae.logEventWithStatsig("Deep Research Export Missing serverThreadId", "deep_research_export_missing_serverthreadid");
                    return
                }
                f(!0);
                try {
                    const E = qt(l),
                        N = await Z.safePost("/export_doc/deep_research", {
                            requestBody: {
                                conversation_id: i,
                                message_id: l.id,
                                export_type: k
                            },
                            skipJsonTransform: !0
                        });
                    if (!N.ok) throw N.status >= 400 && N.status < 600 && c.danger(j, {
                        toastId: "deep_research_share_modal",
                        loggingTitle: j,
                        loggingDescription: "Error message when a file download fails"
                    }), new Error("Failed to download file");
                    const _ = await N.blob(),
                        O = N.headers.get("Content-Disposition"),
                        oe = (w = na(O)) != null ? w : "ChatGPT Deep Research.".concat(k);
                    oa(_, oe), _s(u, {
                        source: "mouse",
                        type: "download",
                        selectedText: E,
                        location: "research-report",
                        contentType: "text",
                        messageId: l.id,
                        serverThreadId: i,
                        productLogOnly: !0
                    })
                } catch (E) {
                    le.addError(E)
                } finally {
                    f(!1)
                }
            }
        },
        P = () => {
            r(!1), d.current = setTimeout(() => {
                Kt.setResearchShareIntent(null)
            }, 400)
        },
        g = (C = l == null ? void 0 : l.metadata) == null ? void 0 : C.async_task_title,
        v = zt();
    return g ? s.jsx(lt, {
        children: s.jsx(U.Root, {
            isOpen: o,
            onClose: P,
            className: "container",
            testId: "modal-deep-research-share",
            children: s.jsx(U.Overlay, {
                showBackground: !0,
                children: s.jsx(U.Content, {
                    size: "normal",
                    className: "flex max-w-4xl flex-col bg-transparent focus:outline-hidden",
                    children: s.jsxs(Yt.div, {
                        initial: {
                            y: "100%",
                            opacity: 0
                        },
                        animate: {
                            y: 0,
                            opacity: 1
                        },
                        exit: {
                            y: "100%",
                            opacity: 0
                        },
                        transition: v ? ks : Ss,
                        className: "bg-token-bg-primary flex max-w-4xl flex-col overflow-x-scroll rounded-2xl focus:outline-hidden",
                        children: [s.jsx(U.Header, {
                            type: "success",
                            title: s.jsx("p", {
                                className: "text-token-text-primary ps-2",
                                children: s.jsx(b, {
                                    id: "pV8JSS",
                                    defaultMessage: "Preview"
                                })
                            }),
                            closeButtonSide: "left",
                            accessory: s.jsxs(s.Fragment, {
                                children: [p && i !== void 0 && s.jsxs(q.Root, {
                                    open: m ? !1 : void 0,
                                    children: [s.jsx(q.BasicTrigger, {
                                        asChild: !0,
                                        children: s.jsx(R, {
                                            disabled: m,
                                            loading: m,
                                            color: "secondary",
                                            icon: ws,
                                            children: n.formatMessage({
                                                id: "deepresearch.download-button",
                                                defaultMessage: "Download"
                                            })
                                        })
                                    }), s.jsx(q.Portal, {
                                        children: s.jsxs(q.Content, {
                                            align: "end",
                                            children: [s.jsx(q.Item, {
                                                onClick: k => {
                                                    k.preventDefault(), h("pdf")
                                                },
                                                children: n.formatMessage({
                                                    id: "deepresearch.download-pdf-button.menu",
                                                    defaultMessage: "PDF Document (.pdf)"
                                                })
                                            }), y && s.jsx(q.Item, {
                                                onClick: k => {
                                                    k.preventDefault(), h("docx")
                                                },
                                                children: n.formatMessage({
                                                    id: "deepresearch.download-docx-button.menu",
                                                    defaultMessage: "Microsoft Word Document (.docx)"
                                                })
                                            })]
                                        })
                                    })]
                                }), s.jsx(Ra, {
                                    taskId: a,
                                    isDisabled: !1,
                                    title: g,
                                    threadId: e
                                })]
                            }),
                            closeButton: s.jsx(ct, {
                                onClick: P,
                                iconSize: "lg"
                            })
                        }), s.jsx("div", {
                            className: "@container/main flex min-w-0 flex-col gap-4 px-12 py-8",
                            children: s.jsx(Qt, {
                                children: s.jsx(sa, {
                                    messages: t,
                                    conversation: x
                                })
                            })
                        })]
                    })
                })
            })
        })
    }) : null
};

function La() {
    "use forget";
    const t = F.c(13),
        e = I(),
        a = ce(Ba),
        n = "https://platform.openai.com/verify-age";
    let o;
    t[0] !== e ? (o = e.formatMessage(G.title), t[0] = e, t[1] = o) : o = t[1];
    let r;
    t[2] === Symbol.for("react.memo_cache_sentinel") ? (r = s.jsx("p", {
        className: "mb-4",
        children: s.jsx(b, S({}, G.description0))
    }), t[2] = r) : r = t[2];
    let d;
    t[3] === Symbol.for("react.memo_cache_sentinel") ? (d = s.jsx(He, {
        children: s.jsx(b, S({}, G.subtitle1))
    }), t[3] = d) : d = t[3];
    let i;
    t[4] === Symbol.for("react.memo_cache_sentinel") ? (i = s.jsxs("ol", {
        className: "ms-4 mb-4 list-decimal",
        children: [s.jsx("li", {
            className: "",
            children: s.jsx(b, S({}, G.description1Bullet1))
        }), s.jsx("li", {
            children: s.jsx(b, S({}, G.description1Bullet2))
        })]
    }), t[4] = i) : i = t[4];
    let l;
    t[5] === Symbol.for("react.memo_cache_sentinel") ? (l = s.jsx("p", {
        className: "mb-4 font-semibold",
        children: s.jsx(b, S({}, G.description1a))
    }), t[5] = l) : l = t[5];
    let m;
    t[6] === Symbol.for("react.memo_cache_sentinel") ? (m = s.jsx("p", {
        className: "mb-4",
        children: s.jsx(b, S({}, G.description1b))
    }), t[6] = m) : m = t[6];
    let f;
    t[7] === Symbol.for("react.memo_cache_sentinel") ? (f = s.jsx(He, {
        children: s.jsx(b, S({}, G.subtitle2))
    }), t[7] = f) : f = t[7];
    let c;
    t[8] === Symbol.for("react.memo_cache_sentinel") ? (c = s.jsxs("div", {
        className: "text-token-text-secondary",
        children: [r, d, i, l, m, f, s.jsx("p", {
            className: "mb-4",
            children: s.jsx(b, L(S({}, G.description2), {
                values: {
                    learnMoreLink: Oa
                }
            }))
        })]
    }), t[8] = c) : c = t[8];
    let u;
    t[9] === Symbol.for("react.memo_cache_sentinel") ? (u = s.jsx("div", {
        className: "mt-4 flex justify-center",
        children: s.jsx(R, {
            color: "primary",
            as: "link",
            to: n,
            openNewTab: !0,
            onClick: Da,
            icon: Es,
            children: s.jsx(b, S({}, G.redirect))
        })
    }), t[9] = u) : u = t[9];
    let x;
    return t[10] !== a || t[11] !== o ? (x = s.jsxs(T, {
        testId: "modal-age-verification-interstitial",
        type: "success",
        isOpen: a,
        onClose: Xt,
        title: o,
        children: [c, u]
    }), t[10] = a, t[11] = o, t[12] = x) : x = t[12], x
}

function Da() {
    return B.closeModal(H.AgeVerificationInterstitial)
}

function Oa(t) {
    return s.jsx("a", {
        href: "https://help.openai.com/en/articles/8411987-why-am-i-being-asked-to-verify-my-age",
        target: "_blank",
        rel: "noreferrer",
        className: "cursor-pointer font-normal underline",
        children: t
    })
}

function Ba(t) {
    return t.activeModals.has(H.AgeVerificationInterstitial)
}
var Je;
const He = Y.h3(Je || (Je = W(["text-token-text-primary text-base mb-1"]))),
    G = xe({
        title: {
            id: "AgeVerificationInterstitial.title",
            defaultMessage: "Please verify your age"
        },
        redirect: {
            id: "AgeVerificationInterstitial.redirect",
            defaultMessage: "Sign in on platform.openai.com"
        },
        description0: {
            id: "AgeVerificationInterstitial.description0",
            defaultMessage: "To continue using ChatGPT, you need to complete a brief age verification check"
        },
        subtitle1: {
            id: "AgeVerificationInterstitial.title1",
            defaultMessage: "What will happen next?"
        },
        description1Bullet1: {
            id: "AgeVerificationInterstitial.description1",
            defaultMessage: "You will be redirected to platform.openai.com where you will need to sign in."
        },
        description1Bullet2: {
            id: "AgeVerificationInterstitial.description2",
            defaultMessage: "You will then be redirected to Yoti, our age verification provider, to verify your age."
        },
        description1a: {
            id: "AgeVerificationInterstitial.description1a",
            defaultMessage: "If you are between the ages of 13 and 17, your parent or guardian must complete the age verification check on your behalf."
        },
        description1b: {
            id: "AgeVerificationInterstitial.description1b",
            defaultMessage: "The process is quick and secure."
        },
        subtitle2: {
            id: "AgeVerificationInterstitial.title2",
            defaultMessage: "Why do I need to do this?"
        },
        description2: {
            id: "AgeVerificationInterstitial.description2-v3",
            defaultMessage: "We are required to verify that our users in Italy are old enough to use ChatGPT. <learnMoreLink>Learn more</learnMoreLink>."
        }
    }),
    Fa = () => {
        var o;
        const t = Pe(),
            e = (o = t == null ? void 0 : t.email) != null ? o : t == null ? void 0 : t.phone_number,
            a = ce(r => r.activeModals.has(H.LogoutConfirm)),
            n = () => {
                B.closeModal(H.LogoutConfirm)
            };
        return s.jsx(T, {
            testId: "modal-logout-confirm",
            isOpen: a,
            onClose: n,
            showCloseButton: !1,
            type: "warning",
            noPadding: !0,
            size: "custom",
            className: "max-w-[373px] sm:max-w-[400px]",
            position: "center",
            children: s.jsxs("div", {
                className: "flex flex-col items-center justify-center px-6 py-8 sm:p-10",
                children: [s.jsx("p", {
                    className: "text-center text-2xl font-semibold text-balance",
                    children: s.jsx(b, S({}, ue.logoutTitle))
                }), s.jsx("p", {
                    className: "text-token-text-secondary mt-4 mb-6 text-center text-lg",
                    children: e && s.jsx(b, L(S({}, ue.logoutConfirm), {
                        values: {
                            emailOrPhone: e
                        }
                    }))
                }), s.jsx(R, {
                    as: "button",
                    size: "large",
                    color: "primary",
                    fullWidth: !0,
                    className: "mb-2 sm:mb-3",
                    "data-testid": "logout-confirm-button",
                    onClick: Jt,
                    children: s.jsx(b, S({}, ue.logoutConfirmButton))
                }), s.jsx(R, {
                    as: "button",
                    size: "large",
                    color: "secondary",
                    fullWidth: !0,
                    onClick: n,
                    children: s.jsx(b, S({}, ue.cancel))
                })]
            })
        })
    },
    ue = xe({
        logoutTitle: {
            id: "biVnvR",
            defaultMessage: "Are you sure you want to log out?"
        },
        logoutConfirm: {
            id: "2aSIBu",
            defaultMessage: "Log out of ChatGPT as {emailOrPhone}?"
        },
        logoutConfirmButton: {
            id: "NeO/CC",
            defaultMessage: "Log out"
        },
        cancel: {
            id: "EORcAJ",
            defaultMessage: "Cancel"
        }
    });
var Ze;
const me = Y.button(Ze || (Ze = W(["text-base rounded-xl justify-center gap-1 flex items-center bg-token-main-surface-primary border w-full p-3"])));
var et;
const Ga = Y.div(et || (et = W(["flex h-[1px] w-full border-b border-token-surface-tertiary"])));
var tt;
const Wa = Y.div(tt || (tt = W(["relative z-10 max-w-[465px] w-full flex flex-col items-start px-10 py-8 border-box bg-token-main-surface-primary border border-token-surface-tertiary shadow-elevation-01 rounded-[40px]"])));
var st;
const Ua = Y.div(st || (st = W(["text-token-text-secondary flex flex-col self-end text-xs"])));
var at;
const ze = Y.div(at || (at = W(["text-token-text-secondary me-0.5 flex self-start text-xl"])));
var ot;
const Ye = Y.div(ot || (ot = W(["me-2 leading-none"]))),
    Va = () => {
        const t = te(),
            e = gt(t),
            a = sessionStorage.getItem("poijcwa") === "jwoid";
        return !K() && e && a
    },
    $a = () => {
        const t = I(),
            e = z(),
            a = D(),
            {
                country: n
            } = Ne(),
            o = Ae({
                country: n,
                currentAccount: null,
                location: "PlusPurchaseInterstitialModal",
                shouldUsePaidSubscriptionBillingCurrency: !1
            }),
            {
                data: r,
                isLoading: d
            } = Ns({
                ctx: a,
                countryCode: o == null ? void 0 : o.country,
                currency: o == null ? void 0 : o.currency,
                enabled: o != null
            });
        let i = ga({
            ctx: a
        });
        if (o && !d && r) {
            const u = As(r, We, Is.Month);
            i = L(S({}, i), {
                cost: {
                    costValue: u.amount,
                    costTitle: Rs(u.amount, We, o.currency)
                }
            })
        }
        M.useEffect(() => {
            const x = new URLSearchParams(window.location.search).get("referrer") || document.referrer;
            ae.logEvent("Account Pay: Interstitial Page Impression", {
                referrer: x
            })
        }, []);
        const l = window.location.href,
            m = u => {
                if (!l.includes(Ue)) {
                    le.addError("PlusPurchaseInterstitialModal: Missing pricing hash.");
                    return
                }
                if (u === "email") {
                    re(a, {
                        fallbackScreenHint: "signup",
                        callbackUrl: l
                    });
                    return
                }
                re(a, {
                    fallbackScreenHint: "login",
                    callbackUrl: l
                })
            },
            f = () => {
                if (!l.includes(Ue)) {
                    le.addError("PlusPurchaseInterstitialModal: Missing pricing hash.");
                    return
                }
                re(a, {
                    fallbackScreenHint: "login",
                    callbackUrl: l
                })
            };
        if (!o) return null;
        const c = we(o.currency);
        return s.jsx(T, {
            testId: "modal-team-purchase-interstitial",
            size: "fullscreen",
            isOpen: !0,
            onClose: () => {},
            type: "success",
            className: "flex flex-col",
            removePopoverStyling: !0,
            children: s.jsxs("div", {
                className: "flex h-full w-full gap-8",
                children: [s.jsx("div", {
                    className: "flex min-w-[320px] flex-1 flex-col items-center p-9 px-4",
                    children: s.jsxs("div", {
                        className: "flex w-full max-w-[360px] grow flex-col items-center justify-center gap-3",
                        children: [s.jsx("button", {
                            onClick: () => e("/"),
                            className: "mb-6 cursor-pointer p-0 md:fixed md:start-4 md:top-4 md:h-6 md:w-6",
                            "aria-label": t.formatMessage({
                                id: "createAccount.plusHomeButtonAriaLabel",
                                defaultMessage: "Click here to go to the home page"
                            }),
                            children: s.jsx(Zt, {
                                className: "h-8 w-8"
                            })
                        }), s.jsxs("span", {
                            className: "text-[28px] font-normal",
                            children: [s.jsx(b, {
                                id: "createAccount.plusFormattedTitle",
                                defaultMessage: "ChatGPT"
                            }), s.jsx("span", {
                                className: "ms-1.5 text-[28px] font-normal text-[#615EEB]",
                                children: t.formatMessage(V.plus)
                            })]
                        }), s.jsx("span", {
                            className: "text-[22px] font-normal",
                            children: s.jsx(b, {
                                id: "createAccount.plusSubTitle",
                                defaultMessage: "Start your trial for free"
                            })
                        }), s.jsxs(me, {
                            onClick: () => m("email"),
                            children: [s.jsx(ua, {
                                className: "h-6 w-6"
                            }), t.formatMessage(V.email)]
                        }), s.jsxs("div", {
                            className: "relative my-12 w-full",
                            children: [s.jsx(Ga, {}), s.jsx("span", {
                                className: "bg-token-bg-primary text-token-text-secondary absolute start-1/2 -top-2 -translate-x-1/2 transform px-2 text-xs font-medium",
                                children: t.formatMessage({
                                    id: "plusPurchaseInterstitialModal.or",
                                    defaultMessage: "OR"
                                })
                            })]
                        }), s.jsxs(me, {
                            onClick: () => m("google-oauth2"),
                            children: [s.jsx(es, {
                                className: "h-6 w-6"
                            }), s.jsx("div", {
                                children: t.formatMessage(V.google)
                            })]
                        }), s.jsxs(me, {
                            onClick: () => m("windowslive"),
                            children: [s.jsx(fa, {
                                className: "h-6 w-6"
                            }), s.jsx("div", {
                                children: t.formatMessage(V.microsoft)
                            })]
                        }), s.jsxs(me, {
                            onClick: () => m("apple"),
                            children: [s.jsx(ma, {
                                className: "h-6 w-6"
                            }), s.jsx("div", {
                                children: t.formatMessage(V.apple)
                            })]
                        }), s.jsx("div", {
                            className: "flex items-center gap-1 py-1.5 text-sm font-medium",
                            children: s.jsx("div", {
                                className: "text-token-text-secondary",
                                children: t.formatMessage(V.alreadyHaveAccount, {
                                    login: u => s.jsx("span", {
                                        className: "cursor-pointer text-green-600",
                                        onClick: f,
                                        children: u
                                    })
                                })
                            })
                        })]
                    })
                }), s.jsxs("div", {
                    className: "hidden min-h-[560px] overflow-y-auto md:relative md:flex md:h-full md:flex-1 md:items-center md:justify-center md:p-4",
                    children: [s.jsxs(Wa, {
                        children: [s.jsxs("div", {
                            className: "mb-5 flex flex-col",
                            children: [s.jsx("div", {
                                className: "mb-2 flex items-center gap-2 text-[28px] font-normal",
                                children: t.formatMessage(V.valueTitle)
                            }), s.jsx("div", {
                                className: "flex h-10 flex-col items-center",
                                children: s.jsxs("div", {
                                    className: "mb-2 flex items-center text-[34px]",
                                    children: [s.jsx(ze, {
                                        className: "text-token-text-tertiary",
                                        children: t.formatMessage(c.sign)
                                    }), s.jsx(Ye, {
                                        className: "text-token-text-tertiary",
                                        "data-testid": "base-monthly-cost",
                                        children: s.jsx("s", {
                                            children: !d && i.cost ? t.formatMessage(i.cost.costTitle) : null
                                        })
                                    }), s.jsx(ze, {
                                        children: t.formatMessage(c.sign)
                                    }), s.jsx(Ye, {
                                        "data-testid": "promo-monthly-cost",
                                        children: t.formatNumber(0)
                                    }), s.jsxs(Ua, {
                                        children: [s.jsx("p", {
                                            className: "m-0",
                                            children: s.jsx(b, {
                                                id: "PlusPricingModalColumn.currencyCodeWithSlash",
                                                defaultMessage: "{currencyCode} / ",
                                                values: {
                                                    currencyCode: t.formatMessage(c.code)
                                                }
                                            })
                                        }), s.jsx(b, S({}, V.billedFirst30))]
                                    })]
                                })
                            })]
                        }), s.jsx(ha, {
                            advertisedFeatures: i.advertisedFeatures
                        })]
                    }), s.jsx("img", {
                        alt: "",
                        src: da.src,
                        className: "absolute inset-0 z-0 h-full w-full object-cover"
                    })]
                })]
            })
        })
    },
    V = xe({
        email: {
            id: "PlusPurchaseInterstitialModal.email",
            defaultMessage: "Continue with Email"
        },
        google: {
            id: "PlusPurchaseInterstitialModal.google",
            defaultMessage: "Continue with Google"
        },
        microsoft: {
            id: "PlusPurchaseInterstitialModal.microsoft",
            defaultMessage: "Continue with Microsoft"
        },
        apple: {
            id: "PlusPurchaseInterstitialModal.apple",
            defaultMessage: "Continue with Apple"
        },
        alreadyHaveAccount: {
            id: "PlusPurchaseInterstitialModal.alreadyHaveAccount",
            defaultMessage: "Already have an account? <login>Login</login>"
        },
        valueTitle: {
            id: "PlusPurchaseInterstitialModal.valueTitle",
            defaultMessage: "Plus"
        },
        billedFirst30: {
            id: "PlusPurchaseInterstitialModal.billedFirst30",
            defaultMessage: "month for first 30 days"
        },
        plus: {
            id: "PlusPurchaseInterstitialModal.plus",
            defaultMessage: "Plus"
        }
    }),
    Ha = () => {
        const t = ts(),
            e = de(),
            {
                hash: a
            } = te(),
            n = D();
        return ss(n) || !(a === "#ca-google-drive-oauth") || !e || (e == null ? void 0 : e.isPersonalAccount()) || !t ? null : s.jsx(za, {})
    },
    za = () => {
        const {
            openSettings: t
        } = pt(), {
            gDriveOAuthConnectionId: e,
            isLoading: a,
            refetch: n
        } = as();
        return M.useEffect(() => {
            !e && !a && window.history.replaceState(null, "", window.location.pathname + window.location.search)
        }, [e, a]), e ? s.jsx(os, {
            connectionId: e,
            isAdminFlow: !1,
            location: "url_hash",
            onClose: () => {
                t(dt.Connectors)
            },
            onSuccess: n
        }) : null
    },
    Ya = "https://openaiassets.blob.core.windows.net/$web/gift_plus_background.png",
    Qa = "https://chatgpt.com/rf/",
    Ka = "#holiday-referral",
    Qe = "rf",
    qa = 3;

function Xa() {
    "use forget";
    const t = F.c(13),
        e = ns(),
        a = z(),
        {
            hash: n,
            pathname: o
        } = te(),
        [r] = ye(),
        d = K(),
        i = $(e, "3813654834");
    let l;
    t[0] !== r ? (l = r.get(Qe), t[0] = r, t[1] = l) : l = t[1];
    const m = l,
        f = d && n === Ka && !!m && i;
    let c;
    t[2] !== r ? (c = r.get("p"), t[2] = r, t[3] = c) : c = t[3];
    const u = c === "7";
    if (!f || !m) {
        let j;
        return t[4] === Symbol.for("react.memo_cache_sentinel") ? (j = {
            visible: !1
        }, t[4] = j) : j = t[4], j
    }
    let x;
    t[5] !== a || t[6] !== o || t[7] !== r ? (x = () => {
        const j = new URLSearchParams(r);
        j.delete(Qe), a({
            pathname: o,
            search: j.toString() ? "?".concat(j.toString()) : "",
            hash: ""
        })
    }, t[5] = a, t[6] = o, t[7] = r, t[8] = x) : x = t[8];
    const p = x;
    let y;
    return t[9] !== p || t[10] !== m || t[11] !== u ? (y = {
        visible: !0,
        referralCode: m,
        numGiftsRemaining: qa,
        onClose: p,
        showProWording: u
    }, t[9] = p, t[10] = m, t[11] = u, t[12] = y) : y = t[12], y
}

function Ja() {
    "use forget";
    const t = F.c(36),
        e = Xa();
    if (!e.visible) return null;
    const {
        referralCode: a,
        numGiftsRemaining: n,
        onClose: o,
        showProWording: r
    } = e, d = "".concat(Qa).concat(encodeURIComponent(a));
    let i;
    t[0] !== d ? (i = d.startsWith("https://") ? d.slice(8) : d, t[0] = d, t[1] = i) : i = t[1];
    const l = i;
    let m;
    t[2] !== d ? (m = () => Se(d), t[2] = d, t[3] = m) : m = t[3];
    const f = m,
        c = r ? X.proSubtitle : X.plusSubtitle,
        u = r ? X.proDisclaimer : X.plusDisclaimer,
        x = r ? X.proTitle : X.plusTitle;
    let p;
    t[4] !== o ? (p = () => o(), t[4] = o, t[5] = p) : p = t[5];
    let y;
    t[6] !== n ? (y = {
        numGiftsRemaining: n
    }, t[6] = n, t[7] = y) : y = t[7];
    let j;
    t[8] !== y || t[9] !== x ? (j = s.jsx(b, L(S({}, x), {
        values: y
    })), t[8] = y, t[9] = x, t[10] = j) : j = t[10];
    let h;
    t[11] !== o ? (h = s.jsx("div", {
        className: "absolute end-4 top-4 z-10",
        children: s.jsx(ct, {
            className: "text-token-text-secondary rounded-full! border border-[rgba(13,13,13,0.05)] bg-white/30 ring-0! outline-0! backdrop-blur-[12px] focus:ring-0! focus:ring-offset-0! focus:outline-0!",
            onClick: o
        })
    }), t[11] = o, t[12] = h) : h = t[12];
    let P;
    t[13] === Symbol.for("react.memo_cache_sentinel") ? (P = s.jsx("img", {
        className: "h-[220px] w-full overflow-hidden bg-no-repeat object-cover",
        alt: "",
        "aria-hidden": "true",
        src: Ya,
        loading: "eager",
        fetchPriority: "high"
    }), t[13] = P) : P = t[13];
    let g;
    t[14] !== n ? (g = {
        numGiftsRemaining: n
    }, t[14] = n, t[15] = g) : g = t[15];
    let v;
    t[16] !== g || t[17] !== x ? (v = s.jsx("h2", {
        id: "plus-gifting-modal-title",
        className: "text-token-text-default-primary mb-1 text-xl leading-8 font-medium",
        children: s.jsx(b, L(S({}, x), {
            values: g
        }))
    }), t[16] = g, t[17] = x, t[18] = v) : v = t[18];
    let C;
    t[19] !== c ? (C = s.jsx("p", {
        id: "plus-gifting-modal-subtitle",
        className: "text-token-text-secondary mb-6 text-base leading-6",
        children: s.jsx(b, S({}, c))
    }), t[19] = c, t[20] = C) : C = t[20];
    let k;
    t[21] !== l || t[22] !== f ? (k = s.jsx(Ts, {
        onThennableClick: f,
        text: l
    }), t[21] = l, t[22] = f, t[23] = k) : k = t[23];
    let w;
    t[24] !== u ? (w = s.jsx("p", {
        className: "text-token-text-tertiary mt-4 text-xs leading-5",
        children: s.jsx(b, S({}, u))
    }), t[24] = u, t[25] = w) : w = t[25];
    let E;
    t[26] !== k || t[27] !== w || t[28] !== v || t[29] !== C ? (E = s.jsxs("div", {
        className: "flex flex-col items-center px-8 pt-6 pb-8 text-center",
        children: [v, C, k, w]
    }), t[26] = k, t[27] = w, t[28] = v, t[29] = C, t[30] = E) : E = t[30];
    let N;
    return t[31] !== E || t[32] !== p || t[33] !== j || t[34] !== h ? (N = s.jsxs(T, {
        isOpen: !0,
        onClose: p,
        testId: "modal-plus-gifting",
        type: "success",
        size: "custom",
        noPadding: !0,
        showCloseButton: !1,
        className: "relative flex max-w-[480px] flex-col overflow-hidden",
        ariaLabelledBy: "plus-gifting-modal-title",
        ariaDescribedBy: "plus-gifting-modal-subtitle",
        title: j,
        visuallyHiddenHeader: !0,
        children: [h, P, E]
    }), t[31] = E, t[32] = p, t[33] = j, t[34] = h, t[35] = N) : N = t[35], N
}
const X = xe({
    plusTitle: {
        id: "plus-gifting-modal.title-plus",
        defaultMessage: "Give the gift of ChatGPT Plus"
    },
    proTitle: {
        id: "plus-gifting-modal.title",
        defaultMessage: "Give {numGiftsRemaining, plural, one {# friend} other {# friends}} the gift of ChatGPT Plus"
    },
    proSubtitle: {
        id: "plus-gifting-modal.subtitle",
        defaultMessage: "Share this unique link to gift each friend 3 free months of advanced AI features."
    },
    plusSubtitle: {
        id: "plus-gifting-modal.subtitle-plus",
        defaultMessage: "Share this unique link to gift 1 free month of advanced AI features to a friend or family member."
    },
    proDisclaimer: {
        id: "plus-gifting-modal.disclaimer-pro",
        defaultMessage: "Valid for new subscribers until January 15th."
    },
    plusDisclaimer: {
        id: "plus-gifting-modal.disclaimer-plus",
        defaultMessage: "Valid for new subscribers until January 1st."
    }
});

function Re({
    testId: t = "modal-generic-ineligible",
    title: e,
    message: a,
    buttonTitle: n,
    isOpen: o,
    onClose: r
}) {
    return s.jsx(T, {
        testId: t,
        type: "success",
        isOpen: o,
        onClose: r,
        showCloseButton: !0,
        title: e,
        children: s.jsxs("div", {
            className: "",
            children: [s.jsx("p", {
                children: a
            }), s.jsx("div", {
                className: "mt-4 flex justify-end",
                children: s.jsx(rs, {
                    title: n,
                    color: "secondary",
                    onClick: r,
                    size: "large"
                })
            })]
        })
    })
}
const Za = t => {
        "use forget";
        const e = F.c(51),
            {
                currentAccount: a,
                promotionData: n
            } = t,
            o = D();
        let r;
        e[0] !== o ? (r = $(o, "2255682732"), e[0] = o, e[1] = r) : r = e[1];
        const d = r,
            {
                eligible: i,
                isLoading: l
            } = Ls(Ds),
            m = i && !d,
            f = z(),
            c = te(),
            {
                isEligible: u,
                isPromoLoading: x,
                promoCode: p,
                referralCode: y,
                promoError: j,
                promoMetadata: h
            } = n;
        let P;
        e[2] !== c.hash || e[3] !== c.pathname || e[4] !== c.search || e[5] !== f || e[6] !== h ? (P = () => {
            const _ = new URLSearchParams(c.search),
                O = _.get(ve),
                oe = _.get(Ce);
            h && (O || oe) && (O && sessionStorage.setItem(Os, O), oe && sessionStorage.setItem(Bs, oe), sessionStorage.setItem(Fs, JSON.stringify(h))), _.delete(ve), _.delete(Ce);
            const Te = _.toString();
            f({
                pathname: c.pathname,
                search: Te ? "?".concat(Te) : "",
                hash: c.hash
            })
        }, e[2] = c.hash, e[3] = c.pathname, e[4] = c.search, e[5] = f, e[6] = h, e[7] = P) : P = e[7];
        const g = P;
        let v;
        e[8] !== g || e[9] !== m || e[10] !== p || e[11] !== j || e[12] !== h || e[13] !== y ? (v = () => {
            m && !y && h && !h.schedule && !j && h.plan_name !== fe.SELF_SERVE_BUSINESS && (ut.setItem(mt.PromoCode, p), g())
        }, e[8] = g, e[9] = m, e[10] = p, e[11] = j, e[12] = h, e[13] = y, e[14] = v) : v = e[14];
        let C;
        e[15] !== g || e[16] !== m || e[17] !== l || e[18] !== p || e[19] !== j || e[20] !== h || e[21] !== y ? (C = [l, h, m, p, y, g, j], e[15] = g, e[16] = m, e[17] = l, e[18] = p, e[19] = j, e[20] = h, e[21] = y, e[22] = C) : C = e[22], M.useEffect(v, C);
        let k, w;
        e[23] !== u || e[24] !== x || e[25] !== p || e[26] !== h ? (k = () => {
            x || u && h == null && le.addError("User is eligible for promo but metadata is missing", {
                promoCode: p
            })
        }, w = [p, u, h, x], e[23] = u, e[24] = x, e[25] = p, e[26] = h, e[27] = k, e[28] = w) : (k = e[27], w = e[28]), M.useEffect(k, w);
        let E, N;
        if (e[29] !== u || e[30] !== h ? (E = () => {
                if (!(!u || h == null)) try {
                    sessionStorage.setItem(Gs, "true")
                } catch (_) {
                    const O = _;
                    le.addError(O)
                }
            }, N = [u, h], e[29] = u, e[30] = h, e[31] = E, e[32] = N) : (E = e[31], N = e[32]), M.useEffect(E, N), l && !d || m && !(h != null && h.schedule) && !j && (h == null ? void 0 : h.plan_name) !== fe.SELF_SERVE_BUSINESS) return null;
        if (x) {
            let _;
            return e[33] !== g ? (_ = s.jsx(Mt, {
                onClose: g
            }), e[33] = g, e[34] = _) : _ = e[34], _
        }
        if (u && h != null) {
            if (h.plan_name === fe.SELF_SERVE_BUSINESS && p) {
                let O;
                return e[35] !== a || e[36] !== g || e[37] !== p || e[38] !== h ? (O = s.jsx(eo, {
                    currentAccount: a,
                    onClose: g,
                    promoCode: p,
                    promoMetadata: h
                }), e[35] = a, e[36] = g, e[37] = p, e[38] = h, e[39] = O) : O = e[39], O
            }
            let _;
            return e[40] !== a || e[41] !== g || e[42] !== p || e[43] !== h || e[44] !== y ? (_ = s.jsx(to, {
                currentAccount: a,
                onClose: g,
                promoCode: p,
                referralCode: y,
                promoMetadata: h
            }), e[40] = a, e[41] = g, e[42] = p, e[43] = h, e[44] = y, e[45] = _) : _ = e[45], _
        }
        if (!u && j) {
            let _;
            return e[46] !== g || e[47] !== p || e[48] !== j || e[49] !== y ? (_ = s.jsx(so, {
                onClose: g,
                promoCode: p,
                referralCode: y,
                promoError: j
            }), e[46] = g, e[47] = p, e[48] = j, e[49] = y, e[50] = _) : _ = e[50], _
        }
        return null
    },
    eo = t => {
        "use forget";
        const e = F.c(16),
            {
                currentAccount: a,
                onClose: n,
                promoCode: o,
                promoMetadata: r
            } = t,
            {
                country: d
            } = Ne();
        let i;
        e[0] !== d || e[1] !== a ? (i = {
            country: d,
            currentAccount: a,
            location: "TeamPromoEligibleModal"
        }, e[0] = d, e[1] = a, e[2] = i) : i = e[2];
        const l = Ae(i);
        let m, f;
        if (e[3] !== o || e[4] !== r ? (m = () => {
                ae.logEvent("Promo Eligible Modal Shown", {
                    promoCode: o,
                    promoMetadata: r
                }), _e.logEvent("chatgpt_promo_eligible_modal_shown")
            }, f = [o, r], e[3] = o, e[4] = r, e[5] = m, e[6] = f) : (m = e[5], f = e[6]), M.useEffect(m, f), !l) return null;
        let c;
        e[7] !== l || e[8] !== a || e[9] !== n || e[10] !== o || e[11] !== r ? (c = s.jsx("div", {
            className: "flex h-full items-center justify-center",
            children: s.jsx("div", {
                className: "flex flex-col justify-center gap-4 px-3 py-6 md:min-h-[30rem] md:flex-row md:gap-0 md:py-0",
                children: s.jsx(ia, {
                    analyticsParams: a.subscriptionAnalyticsParams,
                    className: "bg-token-bg-primary",
                    billingDetails: l,
                    currentAccount: a,
                    planLoading: null,
                    type: Ie.promo,
                    promoCode: o,
                    promoMetadata: r,
                    onProceed: n,
                    setShouldShowCheckoutLoadingOverlay: ao
                })
            })
        }), e[7] = l, e[8] = a, e[9] = n, e[10] = o, e[11] = r, e[12] = c) : c = e[12];
        let u;
        return e[13] !== n || e[14] !== c ? (u = s.jsx(T, {
            testId: "modal-team-promo-eligible",
            size: "fullscreen",
            isOpen: !0,
            onClose: n,
            type: "success",
            className: "flex h-full flex-col items-center justify-center bg-white/70 dark:bg-gray-800/70",
            removePopoverStyling: !0,
            showOverlayBackground: !1,
            children: c
        }), e[13] = n, e[14] = c, e[15] = u) : u = e[15], u
    },
    Mt = t => {
        "use forget";
        const e = F.c(3),
            {
                onClose: a
            } = t;
        let n;
        e[0] === Symbol.for("react.memo_cache_sentinel") ? (n = s.jsx("div", {
            className: "flex h-full items-center justify-center",
            children: s.jsx("div", {
                className: "flex flex-col justify-center gap-4 px-3 py-6 md:min-h-[30rem] md:flex-row md:gap-0 md:py-0",
                children: s.jsx(ja, {
                    className: "border-token-border-light bg-token-bg-primary relative flex flex-1 flex-col justify-center gap-4 rounded-xl border-[#CFCEFC] bg-[#F5F5FF] text-sm shadow-lg md:mt-0 md:mb-0 md:min-h-[30rem] md:rounded-2xl! md:border-s-1 md:border-e-1 md:border-t-1 md:border-b-1 md:p-13.5 dark:border-[#484777] dark:bg-[#282841]"
                })
            })
        }), e[0] = n) : n = e[0];
        let o;
        return e[1] !== a ? (o = s.jsx(T, {
            testId: "modal-promo-loading",
            size: "fullscreen",
            isOpen: !0,
            onClose: a,
            type: "success",
            className: "flex h-full flex-col items-center justify-center bg-white/70 dark:bg-gray-800/70",
            removePopoverStyling: !0,
            showOverlayBackground: !1,
            children: n
        }), e[1] = a, e[2] = o) : o = e[2], o
    },
    to = t => {
        "use forget";
        const e = F.c(24),
            {
                currentAccount: a,
                onClose: n,
                promoCode: o,
                referralCode: r,
                promoMetadata: d
            } = t,
            [i, l] = M.useState(null),
            {
                country: m
            } = Ne();
        let f;
        e[0] !== m || e[1] !== a ? (f = {
            country: m,
            currentAccount: a,
            location: "PromoEligibleModal"
        }, e[0] = m, e[1] = a, e[2] = f) : f = e[2];
        const c = Ae(f),
            u = d.plan_name === fe.GO ? la : yt;
        let x;
        e[3] !== a.subscriptionAnalyticsParams ? (x = L(S({}, a.subscriptionAnalyticsParams), {
            referrer: document.referrer,
            parentComponent: "PromoRedemptionModal"
        }), e[3] = a.subscriptionAnalyticsParams, e[4] = x) : x = e[4];
        const p = x;
        let y, j;
        if (e[5] !== o || e[6] !== d ? (y = () => {
                ae.logEvent("Promo Eligible Modal Shown", {
                    promoCode: o,
                    promoMetadata: d
                }), _e.logEvent("chatgpt_promo_eligible_modal_shown")
            }, j = [o, d], e[5] = o, e[6] = d, e[7] = y, e[8] = j) : (y = e[7], j = e[8]), M.useEffect(y, j), !c) {
            let C;
            return e[9] !== n ? (C = s.jsx(Mt, {
                onClose: n
            }), e[9] = n, e[10] = C) : C = e[10], C
        }
        const h = o != null ? o : void 0,
            P = r != null ? r : void 0;
        let g;
        e[11] !== u || e[12] !== p || e[13] !== c || e[14] !== a || e[15] !== n || e[16] !== i || e[17] !== d || e[18] !== h || e[19] !== P ? (g = s.jsx("div", {
            className: "flex h-full items-center justify-center",
            children: s.jsx("div", {
                className: "flex flex-col justify-center gap-4 px-3 py-6 md:min-h-[30rem] md:flex-row md:gap-0 md:py-0",
                children: s.jsx(u, {
                    analyticsParams: p,
                    className: "bg-token-bg-primary",
                    billingDetails: c,
                    currentAccount: a,
                    onClose: n,
                    isPromoLoading: !1,
                    planLoading: i,
                    promoCode: h,
                    referralCode: P,
                    promoMetadata: d,
                    setPlanLoading: l,
                    type: Ie.promo,
                    setShouldShowCheckoutLoadingOverlay: oo
                })
            })
        }), e[11] = u, e[12] = p, e[13] = c, e[14] = a, e[15] = n, e[16] = i, e[17] = d, e[18] = h, e[19] = P, e[20] = g) : g = e[20];
        let v;
        return e[21] !== n || e[22] !== g ? (v = s.jsx(T, {
            testId: "modal-promo-eligible",
            size: "fullscreen",
            isOpen: !0,
            onClose: n,
            type: "success",
            className: "flex h-full flex-col items-center justify-center bg-white/70 dark:bg-gray-800/70",
            removePopoverStyling: !0,
            showOverlayBackground: !1,
            children: g
        }), e[21] = n, e[22] = g, e[23] = v) : v = e[23], v
    },
    so = t => {
        "use forget";
        const e = F.c(12),
            {
                onClose: a,
                promoError: n,
                promoCode: o,
                referralCode: r
            } = t,
            d = I();
        let i, l;
        e[0] !== o || e[1] !== n.code || e[2] !== r ? (i = () => {
            ae.logEvent("Promo Ineligible Modal Shown", {
                promoCode: o,
                referralCode: r,
                ineligibleReason: n.code
            }), _e.logEvent("chatgpt_promo_ineligible_modal_shown")
        }, l = [o, r, n.code], e[0] = o, e[1] = n.code, e[2] = r, e[3] = i, e[4] = l) : (i = e[3], l = e[4]), M.useEffect(i, l);
        const m = n.title,
            f = n.message;
        let c;
        e[5] !== d ? (c = d.formatMessage({
            id: "promoIneligibleModal.close",
            defaultMessage: "Close"
        }), e[5] = d, e[6] = c) : c = e[6];
        let u;
        return e[7] !== a || e[8] !== n.message || e[9] !== n.title || e[10] !== c ? (u = s.jsx(Re, {
            testId: "modal-promo-ineligible",
            title: m,
            message: f,
            buttonTitle: c,
            isOpen: !0,
            onClose: a
        }), e[7] = a, e[8] = n.message, e[9] = n.title, e[10] = c, e[11] = u) : u = e[11], u
    };

function ao() {}

function oo() {}

function no() {
    "use forget";
    const t = F.c(17);
    let e;
    t[0] === Symbol.for("react.memo_cache_sentinel") ? (e = K(), t[0] = e) : e = t[0];
    const a = e,
        n = te(),
        o = z();
    let r;
    t[1] !== n ? (r = gt(n), t[1] = n, t[2] = r) : r = t[2];
    const d = r;
    let i;
    t[3] !== n ? (i = Ws(n), t[3] = n, t[4] = i) : i = t[4];
    const l = i,
        f = !!((d || l) && a);
    let c;
    t[5] !== f || t[6] !== l ? (c = {
        isModalOpen: f,
        isTeamPricingRoute: l
    }, t[5] = f, t[6] = l, t[7] = c) : c = t[7];
    const u = ro(c);
    let x, p;
    t[8] !== o ? (x = () => {
        a && ge.getBooleanCookie(pe.ShowPaymentModal) && (ge.deleteCookie(pe.ShowPaymentModal), Vs(o, "Show payment modal cookie"))
    }, p = [a, o], t[8] = o, t[9] = x, t[10] = p) : (x = t[9], p = t[10]), M.useEffect(x, p);
    let y, j;
    t[11] !== f ? (y = () => {
        f ? (B.closeAllActiveModals(), B.openModal(H.AccountPayment)) : B.closeModal(H.AccountPayment)
    }, j = [f], t[11] = f, t[12] = y, t[13] = j) : (y = t[12], j = t[13]), M.useEffect(y, j);
    let h;
    return t[14] !== u || t[15] !== f ? (h = {
        isOpen: f,
        defaultTab: u
    }, t[14] = u, t[15] = f, t[16] = h) : h = t[16], h
}

function ro({
    isModalOpen: t,
    isTeamPricingRoute: e
}) {
    const a = de(),
        n = Pe(),
        [o] = ye(),
        r = o.get("default_tab"),
        d = o.get(Us);
    return !a || !n || !t ? "personal" : r && ["personal", "business"].includes(r) ? r : d === "business" ? "business" : d === "plus" ? "personal" : e || a.isWorkspaceAccount() || is(n) || ls && cs() || a.isPlus() ? "business" : "personal"
}

function ie({
    className: t
}) {
    return s.jsx("div", {
        className: he("flex h-full w-full items-center justify-center", t),
        children: s.jsx(ke, {})
    })
}
var nt;
const Pt = Y.div(nt || (nt = W(["p-6"])));

function io({
    emailAddress: t,
    setEmailAddress: e,
    emailTemplate: a,
    validateEmailPending: n,
    errorMessage: o,
    onClickValidateEmail: r,
    onClickCancel: d,
    title: i,
    description: l
}) {
    return s.jsx(Pt, {
        children: s.jsxs("div", {
            className: "flex flex-col",
            children: [s.jsx("div", {
                className: "text-center text-2xl font-medium",
                children: i != null ? i : s.jsx(b, {
                    id: "XSITb5",
                    defaultMessage: "Verify you are a student"
                })
            }), s.jsx("div", {
                className: "text-token-text-tertiary mt-2 text-center text-base",
                children: l != null ? l : s.jsx(b, {
                    id: "x1DjYV",
                    defaultMessage: "To claim the student discount, verify your university email address. This email will not be linked to your ChatGPT account."
                })
            }), s.jsxs("form", {
                className: "mt-8 flex flex-col",
                onSubmit: m => {
                    m.preventDefault(), r()
                },
                children: [s.jsxs(jt, {
                    className: "mb-8",
                    children: [s.jsx(bt, {
                        label: s.jsx(b, {
                            id: "jqIBGr",
                            defaultMessage: "University email address"
                        })
                    }), s.jsx(vt, {
                        className: he(o && "border-red-500"),
                        placeholder: a,
                        onChange: m => {
                            e(m.target.value)
                        }
                    }), o ? s.jsx("div", {
                        className: "text-danger mt-2 text-sm",
                        children: o
                    }) : null]
                }), s.jsx(R, {
                    type: "submit",
                    disabled: t.length === 0,
                    loading: n,
                    children: s.jsx(b, {
                        id: "aDh6He",
                        defaultMessage: "Send verification code"
                    })
                }), s.jsx(R, {
                    type: "button",
                    color: "secondary",
                    className: "mt-3",
                    onClick: d,
                    children: s.jsx(b, {
                        id: "/7nqLd",
                        defaultMessage: "Cancel"
                    })
                })]
            })]
        })
    })
}

function kt({
    programName: t,
    onContinue: e,
    onCancel: a,
    validDomain: n,
    description: o
}) {
    const r = I(),
        [d, i] = M.useState(""),
        [l, m] = M.useState(null),
        {
            mutate: f,
            isPending: c
        } = Q({
            mutationFn: () => ee.validateEmail(d, t),
            onSuccess: u => {
                m(null), A.logValidateEmailSuccess(), e(u.transaction_id)
            },
            onError: u => {
                var p, y;
                const x = (y = (p = u.detail) == null ? void 0 : p.user_error_message) != null ? y : r.formatMessage({
                    id: "9wITlN",
                    defaultMessage: "Something went wrong"
                });
                A.logValidateEmailFailure(), m(x)
            }
        });
    return s.jsx(io, {
        emailAddress: d,
        setEmailAddress: i,
        emailTemplate: n ? "name@university.".concat(n) : "",
        validateEmailPending: c,
        errorMessage: l,
        onClickValidateEmail: () => {
            f(), A.logClickValidateEmail()
        },
        onClickCancel: () => {
            A.logClose("add-email"), a()
        },
        title: n ? s.jsx(b, {
            id: "referral.addEmail.title",
            defaultMessage: "Verify {domain} email address",
            values: {
                domain: n
            }
        }) : void 0,
        description: o
    })
}

function lo(t) {
    "use forget";
    const e = F.c(31),
        {
            currentAccount: a,
            hasPaidSubscription: n,
            referralMetadata: o,
            checkoutDetails: r,
            onContinue: d,
            onClose: i
        } = t,
        l = n === void 0 ? !1 : n,
        m = D(),
        [f, c] = M.useState(null);
    let u;
    e[0] !== o.program_name ? (u = () => {
        A.logShowReferralDiscount(o.program_name, !1)
    }, e[0] = o.program_name, e[1] = u) : u = e[1];
    let x;
    e[2] !== o ? (x = [o], e[2] = o, e[3] = x) : x = e[3], M.useEffect(u, x);
    const p = uo(o);
    if (!a) return null;
    let y;
    e[4] !== m ? (y = pa({
        ctx: m
    }), e[4] = m, e[5] = y) : y = e[5];
    const j = y,
        h = p ? "overflow-auto" : "overflow-hidden";
    let P;
    e[6] !== h ? (P = he("relative flex h-full items-center justify-center", h), e[6] = h, e[7] = P) : P = e[7];
    let g;
    e[8] !== r.plusAnalyticsParams ? (g = L(S({}, r.plusAnalyticsParams), {
        referrer: document.referrer
    }), e[8] = r.plusAnalyticsParams, e[9] = g) : g = e[9];
    let v;
    e[10] !== l || e[11] !== d ? (v = () => {
        A.logClickUpgradeButton(l), c(ds.PLUS), d()
    }, e[10] = l, e[11] = d, e[12] = v) : v = e[12];
    let C;
    e[13] !== r.billingDetails || e[14] !== a || e[15] !== p || e[16] !== i || e[17] !== f || e[18] !== j || e[19] !== g || e[20] !== v ? (C = s.jsx(yt, {
        className: "bg-token-bg-primary",
        analyticsParams: g,
        plusPricingPlan: j,
        currentAccount: a,
        setPlanLoading: c,
        planLoading: f,
        onUpgradeButtonClick: v,
        billingDetails: r.billingDetails,
        promoMetadata: p,
        onClose: i,
        disableForMobile: !0,
        type: Ie.promo,
        setShouldShowCheckoutLoadingOverlay: co
    }), e[13] = r.billingDetails, e[14] = a, e[15] = p, e[16] = i, e[17] = f, e[18] = j, e[19] = g, e[20] = v, e[21] = C) : C = e[21];
    const k = p ? "invisible" : "visible";
    let w;
    e[22] !== k ? (w = he("absolute inset-0 flex items-center justify-center", k), e[22] = k, e[23] = w) : w = e[23];
    let E;
    e[24] === Symbol.for("react.memo_cache_sentinel") ? (E = s.jsx(ie, {}), e[24] = E) : E = e[24];
    let N;
    e[25] !== w ? (N = s.jsx("div", {
        className: w,
        children: E
    }), e[25] = w, e[26] = N) : N = e[26];
    let _;
    return e[27] !== N || e[28] !== P || e[29] !== C ? (_ = s.jsxs("div", {
        className: P,
        children: [C, N]
    }), e[27] = N, e[28] = P, e[29] = C, e[30] = _) : _ = e[30], _
}

function co() {}

function uo(t) {
    var i, l;
    const e = I();
    if (!t) return;
    const a = ((i = t == null ? void 0 : t.duration) == null ? void 0 : i.period) === "month" ? (l = t == null ? void 0 : t.duration) == null ? void 0 : l.num_periods : void 0,
        n = e.formatMessage({
            id: "ofib91",
            defaultMessage: "Sign up for ChatGPT, and get your {months, plural, one {first month} other {first # months}} of Plus for free. Offer valid for new users after verifying you are a student."
        }, {
            months: a
        }),
        o = {
            value: t.discount.value,
            currency_code: t.discount.currency_code
        },
        r = {
            num_periods: t.duration.num_periods,
            period: t.duration.period
        },
        d = e.formatMessage({
            id: "referral.promotionTypeLabel",
            defaultMessage: "STUDENT DISCOUNT"
        });
    return {
        plan_name: t.plan_names[0],
        summary: n,
        discount: o,
        duration: r,
        promotion_type: "student_discount",
        promotion_type_label: d,
        referrer_name: t.referrer_name
    }
}

function mo({
    emailAddress: t,
    verificationCode: e,
    errorMessage: a,
    sendErrorMessage: n,
    validateVerificationCodeIsPending: o,
    isSendingVerificationCode: r,
    setVerificationCode: d,
    onValidateVerificationCode: i,
    onResendVerificationCode: l,
    onChangeEmailAddress: m,
    onCancel: f
}) {
    return s.jsx(Pt, {
        children: s.jsxs("div", {
            className: "flex flex-col",
            children: [s.jsx("div", {
                className: "text-center text-2xl font-medium",
                children: s.jsx(b, {
                    id: "PjHZX7",
                    defaultMessage: "Check your email"
                })
            }), s.jsx("div", {
                className: "text-token-text-tertiary mt-2 text-center text-base",
                children: s.jsx(b, {
                    id: "AoOIN/",
                    defaultMessage: "Enter the verification code we just sent to {emailAddress}",
                    values: {
                        emailAddress: s.jsx("span", {
                            className: "font-medium",
                            children: t
                        })
                    }
                })
            }), n ? s.jsx("div", {
                className: "mt-8",
                children: s.jsx($s, {
                    type: "error",
                    icon: s.jsx(us, {}),
                    content: n
                })
            }) : null, s.jsxs("form", {
                className: "mt-8 flex flex-col",
                onSubmit: c => {
                    c.preventDefault(), i()
                },
                children: [s.jsxs(jt, {
                    className: "mb-8",
                    children: [s.jsx(bt, {
                        label: s.jsx(b, {
                            id: "kLJAa+",
                            defaultMessage: "Verification code"
                        })
                    }), s.jsx(vt, {
                        placeholder: "XXXXXX",
                        value: e,
                        onChange: c => {
                            d(c.target.value)
                        }
                    }), a ? s.jsx("div", {
                        className: "text-danger mt-2 text-sm",
                        children: a
                    }) : null]
                }), s.jsx(R, {
                    type: "submit",
                    disabled: e.length === 0,
                    loading: o,
                    children: s.jsx(b, {
                        id: "NRkiYA",
                        defaultMessage: "Continue"
                    })
                }), s.jsx(R, {
                    type: "button",
                    className: "mt-3",
                    color: "secondary",
                    onClick: f,
                    children: s.jsx(b, {
                        id: "vyz3Kz",
                        defaultMessage: "Cancel"
                    })
                })]
            }), s.jsx("div", {
                className: "mt-8 text-center text-sm",
                children: s.jsx(b, {
                    id: "2NzblW",
                    defaultMessage: "Didn't receive the code?"
                })
            }), s.jsxs("div", {
                className: "mt-4 flex gap-3",
                children: [s.jsx(R, {
                    loading: r,
                    className: "flex-1",
                    color: "secondary",
                    onClick: l,
                    children: s.jsx(b, {
                        id: "L6pEyt",
                        defaultMessage: "Resend code"
                    })
                }), s.jsx(R, {
                    className: "flex-1",
                    color: "secondary",
                    onClick: m,
                    children: s.jsx(b, {
                        id: "V8M7cm",
                        defaultMessage: "Change email"
                    })
                })]
            })]
        })
    })
}

function St({
    transactionId: t,
    onChangeEmailAddress: e,
    onContinue: a,
    onCancel: n
}) {
    const o = I(),
        [r, d] = M.useState(""),
        [i, l] = M.useState(null),
        [m, f] = M.useState(null),
        [c, u] = M.useState(!1),
        x = o.formatMessage({
            id: "9wITlN",
            defaultMessage: "Something went wrong"
        }),
        {
            mutate: p,
            isPending: y
        } = Q({
            mutationFn: () => ee.sendVerificationCode(t),
            onError: g => {
                var C, k;
                const v = (k = (C = g.detail) == null ? void 0 : C.user_error_message) != null ? k : x;
                f(v)
            }
        }),
        {
            mutate: j,
            isPending: h
        } = Q({
            mutationFn: () => ee.validateVerificationCode(t, r),
            onSuccess: () => {
                l(null), f(null), A.logValidateVerificationCodeSuccess();
                try {
                    u(!0), a()
                } catch (g) {
                    u(!1), l(x)
                }
            },
            onError: g => {
                var C, k;
                const v = (k = (C = g.detail) == null ? void 0 : C.user_error_message) != null ? k : o.formatMessage({
                    id: "9wITlN",
                    defaultMessage: "Something went wrong"
                });
                A.logValidateVerificationCodeFailure(), l(v)
            }
        }),
        P = M.useRef(!1);
    return M.useEffect(() => {
        P.current || (p(), A.logSendVerificationCode(), P.current = !0)
    }, [p]), s.jsx(mo, {
        emailAddress: "",
        verificationCode: r,
        errorMessage: i,
        sendErrorMessage: m,
        validateVerificationCodeIsPending: h || c,
        isSendingVerificationCode: y,
        setVerificationCode: d,
        onChangeEmailAddress: () => {
            A.logClickChangeEmailButton(), e()
        },
        onValidateVerificationCode: () => {
            A.logClickValidateVerificationCode(), j()
        },
        onResendVerificationCode: () => {
            A.logClickResendVerificationCodeButton(), p()
        },
        onCancel: () => {
            A.logClose("verify-email"), n()
        }
    })
}

function wt(t, e) {
    const a = ms(t, "1682643554").value;
    if (!e || typeof a != "object" || !a) return;
    const n = a.school_configurations;
    if (!n) return;
    const o = n[e];
    if (!o) return;
    const d = o.domains[0];
    return {
        programConfiguration: o,
        validDomain: d
    }
}

function fo({
    referralCode: t,
    onClose: e
}) {
    var h;
    const a = D(),
        n = z(),
        o = !K(),
        [r, d] = M.useState({
            name: "loading"
        }),
        {
            shouldForwardToCheckout: i,
            isReferrer: l,
            referralMetadata: m,
            programName: f,
            isReferralLoading: c
        } = Hs(t),
        {
            programConfiguration: u,
            validDomain: x
        } = (h = wt(a, f)) != null ? h : {},
        p = $(a, "550432558"),
        y = $(a, "3406933735"),
        j = po(u, m, c);
    return M.useEffect(() => {
        p || e(), j && e()
    }, [j, e, p]), M.useEffect(() => {
        l && f && n(ht(f)), o && y && ee.trackReferralSignup(t)
    }, [l, f, n, o, t, y]), p ? s.jsx(T, {
        testId: "modal-referee",
        type: "success",
        isOpen: !0,
        onClose: e,
        className: "w-full max-w-[360px] ".concat(r.name === "discount-intro" ? "bg-transparent shadow-none!" : ""),
        shouldIgnoreClickOutside: !0,
        removePopoverStyling: !0,
        noPadding: !0,
        children: s.jsx(go, {
            rootState: r,
            setRootState: d,
            referralCode: t,
            validDomain: x,
            shouldForwardToCheckout: i,
            referralMetadata: m,
            isReferralLoading: c,
            onClose: e
        })
    }) : null
}

function go({
    rootState: t,
    setRootState: e,
    referralCode: a,
    validDomain: n,
    shouldForwardToCheckout: o,
    referralMetadata: r,
    isReferralLoading: d,
    onClose: i
}) {
    var h;
    const l = D(),
        m = ba(),
        f = de(),
        c = I(),
        u = !K(),
        x = (h = f == null ? void 0 : f.hasPaidSubscription()) != null ? h : !1,
        p = Q({
            mutationFn: () => {
                if (t.name === "verify-email") return ee.redeemReferral(a, t.transactionId);
                throw new Error("Invalid state for redeeming referral")
            }
        }),
        y = M.useCallback(async P => {
            try {
                await zs(P.billingDetails, P.plusAnalyticsParams)
            } catch (g) {}
        }, []);
    M.useEffect(() => {
        if (!(d || t.name !== "loading")) {
            if (r) {
                e({
                    name: "discount-intro",
                    referralMetadata: r
                });
                return
            }
            e({
                name: "error"
            })
        }
    }, [d, o, r, m, y, t.name, e]);
    const j = Ys(a);
    switch (t.name) {
        case "loading":
            return s.jsx(ie, {
                className: "min-h-96"
            });
        case "discount-intro":
            return m ? s.jsx(lo, {
                currentAccount: f,
                hasPaidSubscription: x,
                referralMetadata: t.referralMetadata,
                checkoutDetails: m,
                onContinue: () => {
                    A.logReferralDiscountContinue(), u ? re(l, {
                        fallbackScreenHint: "signup",
                        callback: P => {
                            ae.logSignUpButtonClicked({
                                provider: P,
                                location: "Referral Discount Modal"
                            }, fs.ACCESS_FLOW_ENTRY_POINT_REFERRAL_DISCOUNT_MODAL)
                        },
                        callbackUrl: j
                    }) : o ? y(m) : e(Ke(t.referralMetadata))
                },
                onClose: () => {
                    A.logClose("discount"), t.referralMetadata.discount && t.referralMetadata.duration && ut.setItem(mt.ReferralCode, a), i()
                }
            }) : s.jsx(ie, {
                className: "min-h-96"
            });
        case "add-email":
            return s.jsx(kt, {
                programName: t.referralMetadata.program_name,
                onContinue: P => {
                    e(ho(t.referralMetadata, P))
                },
                onCancel: i,
                validDomain: n,
                description: n ? s.jsx(b, {
                    id: "referee.addEmail.description",
                    defaultMessage: "To claim the student discount, you must have a valid {domain} email address. This email will not be linked to your ChatGPT account.",
                    values: {
                        domain: n
                    }
                }) : void 0
            });
        case "verify-email":
            return m ? s.jsx(St, {
                transactionId: t.transactionId,
                onChangeEmailAddress: () => {
                    e(Ke(t.referralMetadata))
                },
                onContinue: async () => {
                    await p.mutateAsync(), y(m)
                },
                onCancel: i
            }) : s.jsx(ie, {
                className: "min-h-96"
            });
        case "error":
            return s.jsx(Re, {
                title: c.formatMessage({
                    id: "referee.genericIneligibleModal.title",
                    defaultMessage: "Promo Unavailable"
                }),
                message: s.jsx(b, {
                    id: "referee.genericIneligibleModal.message",
                    defaultMessage: "Looks like you don’t meet the eligibility criteria for this promotion. Learn more about <link>ChatGPT plans.</link>",
                    values: {
                        link: P => s.jsx("a", {
                            href: "https://openai.com/chatgpt/pricing/",
                            className: "underline",
                            children: P
                        })
                    }
                }),
                buttonTitle: c.formatMessage({
                    id: "referee.genericIneligibleModal.buttonTitle",
                    defaultMessage: "Close"
                }),
                isOpen: !0,
                onClose: i
            })
    }
}

function po(t, e, a) {
    return a ? !1 : e && !t ? !0 : e ? !(e == null ? void 0 : e.program_name) : !1
}

function Ke(t) {
    return {
        name: "add-email",
        referralMetadata: t
    }
}

function ho(t, e) {
    return {
        name: "verify-email",
        referralMetadata: t,
        transactionId: e
    }
}

function _t({
    referralMetadata: t,
    referralCode: e,
    onClose: a
}) {
    const n = I(),
        o = se(),
        {
            discount: r
        } = t,
        d = we(r.currency_code),
        i = xt(n, r.value || 0, r.currency_code);
    return s.jsxs("div", {
        className: "text-center",
        children: [s.jsxs("div", {
            className: "text-token-sidebar-surface mx-auto flex h-[64px] w-[104px] items-center justify-center rounded-md bg-[#AF52DE] px-4 py-2 text-[40px]",
            children: [s.jsx("span", {
                className: "text-[20px]",
                children: s.jsx(b, S({}, d.sign))
            }), r.value]
        }), s.jsx("p", {
            className: "text-token-text-primary mt-6 text-2xl font-semibold",
            children: s.jsx(b, S({}, J.referralLinkModalTitle))
        }), s.jsx("p", {
            className: "text-token-text-primary mt-2 text-base",
            children: s.jsx(b, S({}, J.referralLinkModalMessage))
        }), s.jsx("div", {
            className: "mt-6 flex w-full items-center justify-center rounded-md border-[1px] border-[#AF52DE] bg-[#8C43A00D] py-4 text-center",
            children: s.jsx("span", {
                className: "text-[15px] text-[#AF52DE]",
                children: e ? Ve(e) : s.jsx(ke, {})
            })
        }), s.jsxs("div", {
            className: "mt-6 flex w-full flex-col items-center space-y-3",
            children: [s.jsx(R, {
                color: "primary",
                onClick: () => {
                    e && Se(Ve(e), o).then(() => {
                        A.logCopyReferralLink(), o.success(n.formatMessage({
                            id: "1TiBkD",
                            defaultMessage: "Copied referral link to clipboard"
                        }))
                    })
                },
                size: "large",
                className: "w-full",
                children: s.jsx(b, {
                    id: "1HBlf+",
                    defaultMessage: "Copy referral link"
                })
            }), s.jsx(R, {
                color: "secondary",
                onClick: a,
                size: "large",
                className: "w-full",
                children: s.jsx(b, {
                    id: "6NQvfv",
                    defaultMessage: "Close"
                })
            })]
        }), s.jsx("p", {
            className: "text-token-text-tertiary mt-6 text-start text-xs",
            children: s.jsx(b, L(S({}, J.referralLinkModalDisclaimer), {
                values: {
                    discount: i
                }
            }))
        })]
    })
}

function xo({
    referralMetadata: t,
    referralCode: e,
    onClose: a
}) {
    return s.jsx(_t, {
        referralMetadata: t,
        referralCode: e,
        onClose: a
    })
}

function yo({
    referralMetadata: t,
    transactionId: e,
    onClose: a
}) {
    const n = D(),
        o = ft(n),
        [r, d] = M.useState(null),
        {
            mutate: i
        } = Q({
            mutationFn: () => ee.createReferralCode(e),
            onSuccess: f => {
                d(f.referral_code)
            },
            onError: f => {}
        }),
        l = M.useRef(!1);
    M.useEffect(() => {
        l.current || (l.current = !0, i(), A.logShowReferrerConclusion())
    }, [i]);
    const {
        program_name: m
    } = t;
    return !o || !m ? null : s.jsx(_t, {
        referralMetadata: t,
        referralCode: r,
        onClose: () => {
            A.logClose("referrer-conclusion"), a()
        }
    })
}

function jo({
    referralMetadata: t,
    onContinue: e,
    onClose: a
}) {
    const n = I(),
        o = D(),
        r = ft(o);
    M.useEffect(() => {
        A.logShowReferralLinkGenerationModal(t.program_name)
    }, [t]);
    const {
        discount: d,
        program_name: i
    } = t;
    if (!r || !i) return null;
    const l = we(d.currency_code),
        m = xt(n, d.value || 0, d.currency_code);
    return s.jsxs("div", {
        className: "text-center",
        children: [s.jsxs("div", {
            className: "text-token-sidebar-surface mx-auto flex h-[64px] w-[104px] items-center justify-center rounded-md bg-[#AF52DE] px-4 py-2 text-[40px]",
            children: [s.jsx("span", {
                className: "text-[20px]",
                children: s.jsx(b, S({}, l.sign))
            }), d.value]
        }), s.jsx("p", {
            className: "text-token-text-primary mt-6 text-2xl font-semibold",
            children: s.jsx(b, S({}, J.referralLinkModalTitle))
        }), s.jsx("p", {
            className: "text-token-text-primary mt-2 text-base",
            children: s.jsx(b, S({}, J.referralLinkModalMessage))
        }), s.jsxs("div", {
            className: "mt-6 flex w-full flex-col items-center space-y-3",
            children: [s.jsx(R, {
                color: "primary",
                onClick: e,
                size: "large",
                className: "w-full",
                children: s.jsx(b, {
                    id: "aESB6r",
                    defaultMessage: "Get my referral link"
                })
            }), s.jsx(R, {
                color: "secondary",
                onClick: () => {
                    A.logClickReferrerIntroNotNowButton(), a()
                },
                size: "large",
                className: "w-full",
                children: s.jsx(b, {
                    id: "i1qUk7",
                    defaultMessage: "Not Now"
                })
            })]
        }), s.jsx("p", {
            className: "text-token-text-tertiary mt-6 text-start text-xs",
            children: s.jsx(b, L(S({}, J.referralLinkModalDisclaimer), {
                values: {
                    discount: m
                }
            }))
        })]
    })
}

function bo({
    program: t,
    onClose: e
}) {
    var x;
    const a = D(),
        {
            referralMetadata: n,
            referralCode: o,
            transactionId: r,
            programName: d,
            isReferralLoading: i,
            referralError: l
        } = Qs(t),
        {
            programConfiguration: m,
            validDomain: f
        } = (x = wt(a, d)) != null ? x : {},
        c = Co(m, n, i),
        u = $(a, "550432558");
    return M.useEffect(() => {
        u || e(), c && e()
    }, [c, e, u]), u ? s.jsx(T, {
        testId: "modal-referrer",
        type: "success",
        isOpen: !0,
        onClose: e,
        showCloseButton: !0,
        className: "w-full max-w-[390px] pt-2",
        removePopoverStyling: !0,
        children: s.jsx(vo, {
            referralMetadata: n,
            referralCode: o,
            transactionId: r,
            referralError: l,
            validDomain: f,
            isReferralLoading: i,
            shouldRedirect: c,
            onClose: e
        })
    }) : null
}

function vo({
    referralMetadata: t,
    referralCode: e,
    transactionId: a,
    referralError: n,
    validDomain: o,
    shouldRedirect: r,
    isReferralLoading: d,
    onClose: i
}) {
    const l = D(),
        m = I(),
        f = !K(),
        [c, u] = M.useState({
            name: "loading"
        });
    switch (M.useEffect(() => {
        if (!d) {
            if (r) {
                i();
                return
            }
            if (n) {
                u({
                    name: "error",
                    title: n.title,
                    message: n.message
                });
                return
            }
            if (t) {
                u(e ? Mo(t, e) : a ? Xe(t, a) : {
                    name: "intro",
                    referralMetadata: t
                });
                return
            }
            u({
                name: "error"
            })
        }
    }, [d, n, t, e, a, r, i]), c.name) {
        case "loading":
            return s.jsx(ie, {
                className: "min-h-96"
            });
        case "already-enrolled":
            return s.jsx(xo, {
                referralMetadata: c.referralMetadata,
                referralCode: c.referralCode,
                onClose: i
            });
        case "intro":
            return s.jsx(jo, {
                referralMetadata: c.referralMetadata,
                onClose: i,
                onContinue: () => {
                    f ? re(l, {
                        fallbackScreenHint: "signup",
                        callbackUrl: ht(c.referralMetadata.program_name)
                    }) : u(qe(c.referralMetadata))
                }
            });
        case "add-email":
            return s.jsx(kt, {
                programName: c.referralMetadata.program_name,
                onContinue: x => {
                    u(Po(c.referralMetadata, x))
                },
                onCancel: i,
                validDomain: o,
                description: o ? s.jsx(b, {
                    id: "referrer.addEmail.description",
                    defaultMessage: "To generate a referral code, you must have a valid {domain} email address. This email will not be linked to your ChatGPT account.",
                    values: {
                        domain: o
                    }
                }) : void 0
            });
        case "verify-email":
            return s.jsx(St, {
                transactionId: c.transactionId,
                onChangeEmailAddress: () => {
                    u(qe(c.referralMetadata))
                },
                onContinue: () => {
                    u(Xe(c.referralMetadata, c.transactionId))
                },
                onCancel: i
            });
        case "conclusion":
            return s.jsx(yo, {
                referralMetadata: c.referralMetadata,
                transactionId: c.transactionId,
                onClose: i
            });
        case "error":
            return s.jsx(Re, {
                title: m.formatMessage({
                    id: "referrer.genericIneligibleModal.title",
                    defaultMessage: "Promo Unavailable"
                }),
                message: s.jsx(b, {
                    id: "referrer.genericIneligibleModal.message",
                    defaultMessage: "Looks like you don't meet the eligibility criteria for this promotion. Learn more about <link>ChatGPT plans.</link>",
                    values: {
                        link: x => s.jsx("a", {
                            href: "https://openai.com/chatgpt/pricing/",
                            className: "underline",
                            children: x
                        })
                    }
                }),
                buttonTitle: m.formatMessage({
                    id: "referrer.genericIneligibleModal.buttonTitle",
                    defaultMessage: "Close"
                }),
                isOpen: !0,
                onClose: i
            })
    }
}

function Co(t, e, a) {
    return a ? !1 : t ? e ? !(e == null ? void 0 : e.program_name) : !1 : !0
}

function Mo(t, e) {
    return {
        name: "already-enrolled",
        referralMetadata: t,
        referralCode: e
    }
}

function qe(t) {
    return {
        name: "add-email",
        referralMetadata: t
    }
}

function Po(t, e) {
    return {
        name: "verify-email",
        referralMetadata: t,
        transactionId: e
    }
}

function Xe(t, e) {
    return {
        name: "conclusion",
        referralMetadata: t,
        transactionId: e
    }
}

function ko() {
    "use forget";
    const t = F.c(6),
        e = z(),
        {
            isOpen: a,
            program: n
        } = gs(),
        {
            isOpen: o,
            referralCode: r
        } = ps();
    let d;
    return t[0] !== o || t[1] !== a || t[2] !== e || t[3] !== n || t[4] !== r ? (d = a && n ? s.jsx(bo, {
        program: n,
        onClose: () => e({
            hash: ""
        })
    }) : o && r ? s.jsx(fo, {
        referralCode: r,
        onClose: () => e({
            hash: ""
        })
    }) : null, t[0] = o, t[1] = a, t[2] = e, t[3] = n, t[4] = r, t[5] = d) : d = t[5], d
}

function So() {
    const {
        hash: t
    } = te(), {
        isOpen: e
    } = pt(), a = !K(), n = z(), o = hs(t);
    return M.useEffect(() => {
        if (e && a && o === dt.Connectors) {
            const r = "".concat(window.location.pathname).concat(window.location.hash);
            n("/auth/login?next=".concat(encodeURIComponent(r)))
        }
    }, [e, a, o, n]), e ? a ? s.jsx(va, {}) : s.jsx(Ca, {}) : null
}

function wo() {
    const t = I(),
        [e] = ye(),
        a = se(),
        n = e.get(Ks),
        o = M.useMemo(() => n === "true" ? t.formatMessage({
            id: "ogcSBw",
            defaultMessage: "ChatGPT student offer activated"
        }) : null, [n, t]);
    return M.useEffect(() => {
        o && a.success(o, {
            hasCloseButton: !0
        })
    }, [o, a]), null
}
const _o = Ee(() => Me(() =>
        import ("./nut5e1nu68zwzskm.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7])).then(t => t.FannyPackModalContainer)),
    Eo = Ee(() => Me(() =>
        import ("./65wh49bi0uv7dyfy.js"), __vite__mapDeps([8, 1, 2, 3, 5, 6, 9, 10, 11]))),
    No = Ee(() => Me(() =>
        import ("./glhgbnfau97gd4im.js"), __vite__mapDeps([12, 1, 2, 3, 5, 6])).then(t => t.default));

function Ao() {
    "use forget";
    const t = F.c(2),
        e = ce(Io);
    let a;
    return t[0] !== e ? (a = e ? s.jsx(Eo, {
        serverThreadId: e
    }) : null, t[0] = e, t[1] = a) : a = t[1], a
}

function Io(t) {
    return t.sharingModalThreadId
}

function gr() {
    var P, g;
    const t = ce(v => v.purchaseWorkspaceData),
        e = ce(v => v.leaveWorkspaceData),
        a = t != null,
        n = xs(H.GlobalMemoryOnboarding),
        o = de(),
        r = D();
    $(r, "676035580"), Pa();
    const d = Va();
    xa(a);
    const i = z(),
        {
            isOpen: l,
            defaultTab: m
        } = no(),
        {
            isFannyPackEnabled: f
        } = qs(r);
    ra();
    const c = ys(v => v.researchShareIntent),
        {
            isEnabled: u
        } = Ma(),
        [x] = ye(),
        p = x.get(ve),
        y = x.get(Ce),
        j = Xs({
            promoCode: p,
            referralCode: y
        }),
        h = (p != null ? p : y) && ((g = (P = j.promoMetadata) != null ? P : j.promoError) != null ? g : j.isPromoLoading);
    return s.jsxs(s.Fragment, {
        children: [s.jsx(Js, {}), s.jsx(So, {}), s.jsx(Ha, {}), s.jsx(ko, {}), s.jsx(La, {}), d && s.jsx($a, {}), s.jsx(Ja, {}), l && o && !h && s.jsx(ca, {
            currentAccount: o,
            defaultTab: m,
            onClose: () => Zs(i)
        }, "all-plans-pricing-modal-".concat(m)), h && o && s.jsx(Za, {
            currentAccount: o,
            promotionData: j
        }), s.jsx(ea, {}), s.jsx(No, {}), a && s.jsx(ya, S({
            isOpen: a,
            onClose: () => {
                B.setPurchaseWorkspaceData(null), i({
                    pathname: location.pathname,
                    search: "",
                    hash: ""
                })
            }
        }, t)), e && s.jsx(Sa, {
            workspace: e
        }), n && s.jsx(ta, {
            onClose: () => B.closeModal(H.GlobalMemoryOnboarding)
        }), f && s.jsx(_o, {}), s.jsx(Ao, {}), c && s.jsx(Ta, {
            taskId: c.taskId,
            messages: c.messages,
            threadId: c.threadId
        }), s.jsx(Fa, {}), u ? s.jsx(wo, {}) : null]
    })
}
export {
    gr as GlobalModalsComponent
};
//# sourceMappingURL=mzlwqydgg1tyhixa.js.map