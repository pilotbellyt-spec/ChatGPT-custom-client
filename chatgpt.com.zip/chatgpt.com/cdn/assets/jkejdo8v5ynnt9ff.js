var p = Object.defineProperty;
var f = Object.getOwnPropertySymbols;
var b = Object.prototype.hasOwnProperty,
    y = Object.prototype.propertyIsEnumerable;
var g = (s, t, e) => t in s ? p(s, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : s[t] = e,
    h = (s, t) => {
        for (var e in t || (t = {})) b.call(t, e) && g(s, e, t[e]);
        if (f)
            for (var e of f(t)) y.call(t, e) && g(s, e, t[e]);
        return s
    };
import {
    e as S,
    a as E,
    r as j,
    j as a,
    M as L
} from "./fg33krlcm0qyi6yw.js";
import {
    ag as W,
    m as M,
    r0 as R,
    b as k,
    fG as U,
    r1 as z,
    aN as N,
    ih as B,
    aa as D,
    a9 as I
} from "./dykg4ktvbu3mhmdo.js";
import {
    g as Q
} from "./k2oaaf8ac9lafsub.js";
import {
    A as T,
    p as c,
    B as q
} from "./k15yxxoybkkir2ou.js";

function J({
    workspace: s,
    onOpen: t
}) {
    var x;
    const e = S(),
        l = E(),
        i = W(),
        n = k(),
        d = M(),
        [u, v] = j.useState(!1),
        {
            data: o,
            isLoading: A
        } = T(s.id),
        m = Q(e, s, i != null ? i : void 0),
        C = j.useCallback(() => {
            t == null || t(), v(!0);
            const {
                willRedirect: r
            } = R(l, s.id, n, e, d);
            U.set(n, !1), r || z()
        }, [t, l, s.id, n, e, d]);
    return a.jsxs("div", {
        className: "flex w-full cursor-default items-center border-t p-5 first:border-t-0",
        role: "listitem",
        "data-testid": "existing-workspace-row",
        "data-workspace-id": s.id,
        children: [a.jsxs("div", {
            className: "flex min-w-0 flex-1 items-center gap-3",
            children: [s.structure === N.PERSONAL ? a.jsx(B, {
                user: i,
                size: "large"
            }) : a.jsx(D, {
                src: s.data.profilePictureUrl,
                size: "large"
            }), a.jsxs("div", {
                className: "flex-1 truncate",
                children: [a.jsx("div", {
                    className: "text-token-text-primary truncate font-medium",
                    title: m,
                    children: m
                }), a.jsx("div", {
                    className: "text-token-text-secondary truncate text-sm",
                    children: s.structure === N.PERSONAL ? a.jsx(L, h({}, c.personalWorkspace)) : A ? a.jsx(q, {
                        className: "inline-block h-4 w-16 align-middle"
                    }) : e.formatMessage(c.memberCount, {
                        count: (x = o == null ? void 0 : o.total) != null ? x : 0
                    })
                })]
            })]
        }), a.jsx("div", {
            className: "shrink-0",
            children: a.jsx(I, {
                color: "secondary",
                onClick: r => {
                    r.preventDefault(), r.stopPropagation(), C()
                },
                visuallyDisabled: u || !s.canAccessWithCurrentSession,
                disabled: u || !s.canAccessWithCurrentSession,
                children: e.formatMessage(c.open)
            })
        })]
    })
}
export {
    J as E
};
//# sourceMappingURL=jkejdo8v5ynnt9ff.js.map