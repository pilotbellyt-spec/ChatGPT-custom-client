var It = Object.defineProperty,
    Pt = Object.defineProperties;
var $t = Object.getOwnPropertyDescriptors;
var R = Object.getOwnPropertySymbols;
var Mt = Object.prototype.hasOwnProperty,
    gt = Object.prototype.propertyIsEnumerable;
var mt = (i, a, e) => a in i ? It(i, a, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : i[a] = e,
    p = (i, a) => {
        for (var e in a || (a = {})) Mt.call(a, e) && mt(i, e, a[e]);
        if (R)
            for (var e of R(a)) gt.call(a, e) && mt(i, e, a[e]);
        return i
    },
    M = (i, a) => Pt(i, $t(a));
var yt = i => typeof i == "symbol" ? i : i + "",
    Z = (i, a) => {
        var e = {};
        for (var r in i) Mt.call(i, r) && a.indexOf(r) < 0 && (e[r] = i[r]);
        if (i != null && R)
            for (var r of R(i)) a.indexOf(r) < 0 && gt.call(i, r) && (e[r] = i[r]);
        return e
    };
import {
    I as Ct,
    r as z,
    j as K
} from "./fg33krlcm0qyi6yw.js";
import {
    zD as Bt
} from "./dykg4ktvbu3mhmdo.js";
const T = new WeakMap,
    G = new WeakMap,
    H = {
        current: []
    };
let x = !1,
    B = 0;
const C = new Set,
    j = new Map;

function _t(i) {
    const a = Array.from(i).sort((e, r) => e instanceof k && e.options.deps.includes(r) ? 1 : r instanceof k && r.options.deps.includes(e) ? -1 : 0);
    for (const e of a) {
        if (H.current.includes(e)) continue;
        H.current.push(e), e.recompute();
        const r = G.get(e);
        if (r)
            for (const t of r) {
                const s = T.get(t);
                s && _t(s)
            }
    }
}

function zt(i) {
    i.listeners.forEach(a => a({
        prevVal: i.prevState,
        currentVal: i.state
    }))
}

function Wt(i) {
    i.listeners.forEach(a => a({
        prevVal: i.prevState,
        currentVal: i.state
    }))
}

function Et(i) {
    var a;
    if (B > 0 && !j.has(i) && j.set(i, i.prevState), C.add(i), !(B > 0) && !x) try {
        for (x = !0; C.size > 0;) {
            const e = Array.from(C);
            C.clear();
            for (const r of e) {
                const t = (a = j.get(r)) != null ? a : r.prevState;
                r.prevState = t, zt(r)
            }
            for (const r of e) {
                const t = T.get(r);
                t && (H.current.push(r), _t(t))
            }
            for (const r of e) {
                const t = T.get(r);
                if (t)
                    for (const s of t) Wt(s)
            }
        }
    } finally {
        x = !1, H.current = [], j.clear()
    }
}

function D(i) {
    B++;
    try {
        i()
    } finally {
        if (B--, B === 0) {
            const a = Array.from(C)[0];
            a && Et(a)
        }
    }
}
class at {
    constructor(a, e) {
        this.listeners = new Set, this.subscribe = r => {
            var t, s;
            this.listeners.add(r);
            const n = (s = (t = this.options) == null ? void 0 : t.onSubscribe) == null ? void 0 : s.call(t, r, this);
            return () => {
                this.listeners.delete(r), n == null || n()
            }
        }, this.setState = r => {
            var t, s, n;
            this.prevState = this.state, this.state = (t = this.options) != null && t.updateFn ? this.options.updateFn(this.prevState)(r) : r(this.prevState), (n = (s = this.options) == null ? void 0 : s.onUpdate) == null || n.call(s), Et(this)
        }, this.prevState = a, this.state = a, this.options = e
    }
}
class k {
    constructor(a) {
        this.listeners = new Set, this._subscriptions = [], this.lastSeenDepValues = [], this.getDepVals = () => {
            var t;
            const e = [],
                r = [];
            for (const s of this.options.deps) e.push(s.prevState), r.push(s.state);
            return this.lastSeenDepValues = r, {
                prevDepVals: e,
                currDepVals: r,
                prevVal: (t = this.prevState) != null ? t : void 0
            }
        }, this.recompute = () => {
            var e, r;
            this.prevState = this.state;
            const {
                prevDepVals: t,
                currDepVals: s,
                prevVal: n
            } = this.getDepVals();
            this.state = this.options.fn({
                prevDepVals: t,
                currDepVals: s,
                prevVal: n
            }), (r = (e = this.options).onUpdate) == null || r.call(e)
        }, this.checkIfRecalculationNeededDeeply = () => {
            for (const s of this.options.deps) s instanceof k && s.checkIfRecalculationNeededDeeply();
            let e = !1;
            const r = this.lastSeenDepValues,
                {
                    currDepVals: t
                } = this.getDepVals();
            for (let s = 0; s < t.length; s++)
                if (t[s] !== r[s]) {
                    e = !0;
                    break
                }
            e && this.recompute()
        }, this.mount = () => (this.registerOnGraph(), this.checkIfRecalculationNeededDeeply(), () => {
            this.unregisterFromGraph();
            for (const e of this._subscriptions) e()
        }), this.subscribe = e => {
            var r, t;
            this.listeners.add(e);
            const s = (t = (r = this.options).onSubscribe) == null ? void 0 : t.call(r, e, this);
            return () => {
                this.listeners.delete(e), s == null || s()
            }
        }, this.options = a, this.state = a.fn({
            prevDepVals: void 0,
            prevVal: void 0,
            currDepVals: this.getDepVals().currDepVals
        })
    }
    registerOnGraph(a = this.options.deps) {
        for (const e of a)
            if (e instanceof k) e.registerOnGraph(), this.registerOnGraph(e.options.deps);
            else if (e instanceof at) {
            let r = T.get(e);
            r || (r = new Set, T.set(e, r)), r.add(this);
            let t = G.get(this);
            t || (t = new Set, G.set(this, t)), t.add(e)
        }
    }
    unregisterFromGraph(a = this.options.deps) {
        for (const e of a)
            if (e instanceof k) this.unregisterFromGraph(e.options.deps);
            else if (e instanceof at) {
            const r = T.get(e);
            r && r.delete(this);
            const t = G.get(this);
            t && t.delete(e)
        }
    }
}

function Q(i, a) {
    return typeof i == "function" ? i(a) : i
}

function wt(i, a) {
    return ct(a).reduce((r, t) => {
        if (r === null) return null;
        if (typeof r < "u") return r[t]
    }, i)
}

function tt(i, a, e) {
    const r = ct(a);

    function t(s) {
        if (!r.length) return Q(e, s);
        const n = r.shift();
        if (typeof n == "string" || typeof n == "number" && !Array.isArray(s)) return typeof s == "object" ? (s === null && (s = {}), M(p({}, s), {
            [n]: t(s[n])
        })) : {
            [n]: t()
        };
        if (Array.isArray(s) && typeof n == "number") {
            const o = s.slice(0, n);
            return [...o.length ? o : new Array(n), t(s[n]), ...s.slice(n + 1)]
        }
        return [...new Array(n), t()]
    }
    return t(i)
}

function Rt(i, a) {
    const e = ct(a);

    function r(t) {
        if (!t) return;
        if (e.length === 1) {
            const o = e[0];
            if (Array.isArray(t) && typeof o == "number") return t.filter((h, d) => d !== o);
            const n = t,
                {
                    [o]: c
                } = n;
            return Z(n, [yt(o)])
        }
        const s = e.shift();
        if (typeof s == "string" && typeof t == "object") return M(p({}, t), {
            [s]: r(t[s])
        });
        if (typeof s == "number" && Array.isArray(t)) {
            if (s >= t.length) return t;
            const o = t.slice(0, s);
            return [...o.length ? o : new Array(s), r(t[s]), ...t.slice(s + 1)]
        }
        throw new Error("It seems we have created an infinite loop in deleteBy. ")
    }
    return r(i)
}
const jt = /^(\d*)$/gm,
    Lt = /\.(\d*)\./gm,
    Ut = /^(\d*)\./gm,
    Nt = /\.(\d*$)/gm,
    Gt = /\.{2,}/gm,
    nt = "__int__",
    L = "".concat(nt, "$1");

function ct(i) {
    if (Array.isArray(i)) return [...i];
    if (typeof i != "string") throw new Error("Path must be a string.");
    return i.replace(/\[/g, ".").replace(/\]/g, "").replace(jt, L).replace(Lt, ".".concat(L, ".")).replace(Ut, "".concat(L, ".")).replace(Nt, ".".concat(L)).replace(Gt, ".").split(".").map(a => a.indexOf(nt) === 0 ? parseInt(a.substring(nt.length), 10) : a)
}

function Kt(i) {
    return !(Array.isArray(i) && i.length === 0)
}

function ot(i, a) {
    const {
        asyncDebounceMs: e
    } = a, {
        onChangeAsync: r,
        onBlurAsync: t,
        onSubmitAsync: s,
        onBlurAsyncDebounceMs: n,
        onChangeAsyncDebounceMs: o
    } = a.validators || {}, c = e != null ? e : 0, u = {
        cause: "change",
        validate: r,
        debounceMs: o != null ? o : c
    }, h = {
        cause: "blur",
        validate: t,
        debounceMs: n != null ? n : c
    }, d = {
        cause: "submit",
        validate: s,
        debounceMs: 0
    }, l = f => M(p({}, f), {
        debounceMs: 0
    });
    switch (i) {
        case "submit":
            return [l(u), l(h), d];
        case "blur":
            return [h];
        case "change":
            return [u];
        case "server":
        default:
            return []
    }
}

function lt(i, a) {
    const {
        onChange: e,
        onBlur: r,
        onSubmit: t,
        onMount: s
    } = a.validators || {}, n = {
        cause: "change",
        validate: e
    }, o = {
        cause: "blur",
        validate: r
    }, c = {
        cause: "submit",
        validate: t
    }, u = {
        cause: "mount",
        validate: s
    }, h = {
        cause: "server",
        validate: () => {}
    };
    switch (i) {
        case "mount":
            return [u];
        case "submit":
            return [n, o, c, h];
        case "server":
            return [h];
        case "blur":
            return [o, h];
        case "change":
        default:
            return [n, h]
    }
}
const At = i => !!i && typeof i == "object" && "fields" in i;

function et(i, a) {
    if (Object.is(i, a)) return !0;
    if (typeof i != "object" || i === null || typeof a != "object" || a === null) return !1;
    if (i instanceof Map && a instanceof Map) {
        if (i.size !== a.size) return !1;
        for (const [r, t] of i)
            if (!a.has(r) || !Object.is(t, a.get(r))) return !1;
        return !0
    }
    if (i instanceof Set && a instanceof Set) {
        if (i.size !== a.size) return !1;
        for (const r of i)
            if (!a.has(r)) return !1;
        return !0
    }
    const e = Object.keys(i);
    if (e.length !== Object.keys(a).length) return !1;
    for (let r = 0; r < e.length; r++)
        if (!Object.prototype.hasOwnProperty.call(a, e[r]) || !Object.is(i[e[r]], a[e[r]])) return !1;
    return !0
}

function Ht(i) {
    var e, r;
    const a = new Map;
    for (const t of i) {
        const s = [...(e = t.path) != null ? e : []].map(n => {
            const o = typeof n == "object" ? n.key : n;
            return typeof o == "number" ? "[".concat(o, "]") : o
        }).join(".").replace(/\.\[/g, "[");
        a.set(s, ((r = a.get(s)) != null ? r : []).concat(t))
    }
    return Object.fromEntries(a)
}
const qt = i => i,
    Jt = i => {
        const a = Ht(i);
        return {
            form: a,
            fields: a
        }
    },
    St = (i, a) => i === "form" ? Jt(a) : qt(a),
    Ot = {
        validate({
            value: i,
            validationSource: a
        }, e) {
            const r = e["~standard"].validate(i);
            if (r instanceof Promise) throw new Error("async function passed to sync validator");
            if (r.issues) return St(a, r.issues)
        },
        async validateAsync({
            value: i,
            validationSource: a
        }, e) {
            const r = await e["~standard"].validate(i);
            if (r.issues) return St(a, r.issues)
        }
    },
    kt = i => !!i && "~standard" in i,
    q = {
        isValidating: !1,
        isTouched: !1,
        isBlurred: !1,
        isDirty: !1,
        isPristine: !0,
        errors: [],
        errorMap: {}
    };

function U(i) {
    function a(d, l, f, v) {
        const m = r(d, l, f, v);
        ({
            insert: () => o(m, d, l),
            remove: () => c(m),
            swap: () => v !== void 0 && h(m, d, l, v),
            move: () => v !== void 0 && u(m, d, l, v)
        })[f]()
    }

    function e(d, l) {
        return "".concat(d, "[").concat(l, "]")
    }

    function r(d, l, f, v) {
        const m = [e(d, l)];
        if (f === "swap") m.push(e(d, v));
        else if (f === "move") {
            const [g, y] = [Math.min(l, v), Math.max(l, v)];
            for (let S = g; S <= y; S++) m.push(e(d, S))
        } else {
            const g = i.getFieldValue(d),
                y = Array.isArray(g) ? g.length : 0;
            for (let S = l + 1; S < y; S++) m.push(e(d, S))
        }
        return Object.keys(i.fieldInfo).filter(g => m.some(y => g.startsWith(y)))
    }

    function t(d, l) {
        return d.replace(/\[(\d+)\]/, (f, v) => {
            const m = parseInt(v, 10),
                g = l === "up" ? m + 1 : Math.max(0, m - 1);
            return "[".concat(g, "]")
        })
    }

    function s(d, l) {
        (l === "up" ? d : [...d].reverse()).forEach(v => {
            const m = t(v.toString(), l),
                g = i.getFieldMeta(m);
            g ? i.setFieldMeta(v, g) : i.setFieldMeta(v, n())
        })
    }
    const n = () => q,
        o = (d, l, f) => {
            s(d, "down"), d.forEach(v => {
                v.toString().startsWith(e(l, f)) && i.setFieldMeta(v, n())
            })
        },
        c = d => {
            s(d, "up")
        },
        u = (d, l, f, v) => {
            const m = new Map(Object.keys(i.fieldInfo).filter(g => g.startsWith(e(l, f))).map(g => [g, i.getFieldMeta(g)]));
            s(d, f < v ? "up" : "down"), Object.keys(i.fieldInfo).filter(g => g.startsWith(e(l, v))).forEach(g => {
                const y = g.replace(e(l, v), e(l, f)),
                    S = m.get(y);
                S && i.setFieldMeta(g, S)
            })
        },
        h = (d, l, f, v) => {
            d.forEach(m => {
                if (!m.toString().startsWith(e(l, f))) return;
                const g = m.toString().replace(e(l, f), e(l, v)),
                    [y, S] = [i.getFieldMeta(m), i.getFieldMeta(g)];
                y && i.setFieldMeta(g, y), S && i.setFieldMeta(m, S)
            })
        };
    return {
        handleArrayFieldMetaShift: a
    }
}

function st(i) {
    var a, e, r, t, s, n, o, c, u;
    return {
        values: (a = i.values) != null ? a : {},
        errorMap: (e = i.errorMap) != null ? e : {},
        fieldMetaBase: (r = i.fieldMetaBase) != null ? r : {},
        isSubmitted: (t = i.isSubmitted) != null ? t : !1,
        isSubmitting: (s = i.isSubmitting) != null ? s : !1,
        isValidating: (n = i.isValidating) != null ? n : !1,
        submissionAttempts: (o = i.submissionAttempts) != null ? o : 0,
        isSubmitSuccessful: (c = i.isSubmitSuccessful) != null ? c : !1,
        validationMetaMap: (u = i.validationMetaMap) != null ? u : {
            onChange: void 0,
            onBlur: void 0,
            onSubmit: void 0,
            onMount: void 0,
            onServer: void 0
        }
    }
}
class Qt {
    constructor(a) {
        var r;
        var e;
        this.options = {}, this.fieldInfo = {}, this.prevTransformArray = [], this.cumulativeFieldsErrorMap = {}, this.mount = () => {
            const t = this.fieldMetaDerived.mount(),
                s = this.store.mount(),
                n = () => {
                    t(), s()
                },
                {
                    onMount: o
                } = this.options.validators || {};
            return o && this.validateSync("mount"), n
        }, this.update = t => {
            var s, n;
            if (!t) return;
            const o = this.options;
            this.options = t;
            const c = !!((n = (s = t.transform) == null ? void 0 : s.deps) != null && n.some((d, l) => d !== this.prevTransformArray[l])),
                u = t.defaultValues && !et(t.defaultValues, o.defaultValues) && !this.state.isTouched,
                h = !et(t.defaultState, o.defaultState) && !this.state.isTouched;
            !u && !h && !c || D(() => {
                this.baseStore.setState(() => st(Object.assign({}, this.state, h ? t.defaultState : {}, u ? {
                    values: t.defaultValues
                } : {}, c ? {
                    _force_re_eval: !this.state._force_re_eval
                } : {})))
            })
        }, this.reset = (t, s) => {
            const {
                fieldMeta: n
            } = this.state, o = this.resetFieldMeta(n);
            t && !(s != null && s.keepDefaultValues) && (this.options = M(p({}, this.options), {
                defaultValues: t
            })), this.baseStore.setState(() => {
                var u;
                var c;
                return st(M(p({}, this.options.defaultState), {
                    values: (u = t != null ? t : this.options.defaultValues) != null ? u : (c = this.options.defaultState) == null ? void 0 : c.values,
                    fieldMetaBase: o
                }))
            })
        }, this.validateAllFields = async t => {
            const s = [];
            return D(() => {
                Object.values(this.fieldInfo).forEach(o => {
                    if (!o.instance) return;
                    const c = o.instance;
                    s.push(Promise.resolve().then(() => c.validate(t, {
                        skipFormValidation: !0
                    }))), o.instance.state.meta.isTouched || o.instance.setMeta(u => M(p({}, u), {
                        isTouched: !0
                    }))
                })
            }), (await Promise.all(s)).flat()
        }, this.validateArrayFieldsStartingFrom = async (t, s, n) => {
            const o = this.getFieldValue(t),
                c = Array.isArray(o) ? Math.max(o.length - 1, 0) : null,
                u = ["".concat(t, "[").concat(s, "]")];
            for (let f = s + 1; f <= (c != null ? c : 0); f++) u.push("".concat(t, "[").concat(f, "]"));
            const h = Object.keys(this.fieldInfo).filter(f => u.some(v => f.startsWith(v))),
                d = [];
            return D(() => {
                h.forEach(f => {
                    d.push(Promise.resolve().then(() => this.validateField(f, n)))
                })
            }), (await Promise.all(d)).flat()
        }, this.validateField = (t, s) => {
            var n;
            const o = (n = this.fieldInfo[t]) == null ? void 0 : n.instance;
            return o ? (o.state.meta.isTouched || o.setMeta(c => M(p({}, c), {
                isTouched: !0
            })), o.validate(s)) : []
        }, this.validateSync = t => {
            const s = lt(t, this.options);
            let n = !1;
            const o = {};
            return D(() => {
                var c;
                for (const h of s) {
                    if (!h.validate) continue;
                    const d = this.runValidator({
                            validate: h.validate,
                            value: {
                                value: this.state.values,
                                formApi: this,
                                validationSource: "form"
                            },
                            type: "validate"
                        }),
                        {
                            formError: l,
                            fieldErrors: f
                        } = ut(d),
                        v = N(h.cause);
                    if (f)
                        for (const [m, g] of Object.entries(f)) {
                            const y = this.cumulativeFieldsErrorMap[m] || {},
                                S = M(p({}, y), {
                                    [v]: g
                                });
                            o[m] = S, this.cumulativeFieldsErrorMap[m] = S;
                            const b = this.getFieldMeta(m);
                            b && b.errorMap[v] !== g && this.setFieldMeta(m, V => M(p({}, V), {
                                errorMap: M(p({}, V.errorMap), {
                                    [v]: g
                                })
                            }))
                        }
                    for (const m of Object.keys(this.cumulativeFieldsErrorMap)) {
                        const g = this.getFieldMeta(m);
                        g != null && g.errorMap[v] && !((c = o[m]) != null && c[v]) && (this.cumulativeFieldsErrorMap[m] = M(p({}, this.cumulativeFieldsErrorMap[m]), {
                            [v]: void 0
                        }), this.setFieldMeta(m, y => M(p({}, y), {
                            errorMap: M(p({}, y.errorMap), {
                                [v]: void 0
                            })
                        })))
                    }
                    this.state.errorMap[v] !== l && this.baseStore.setState(m => M(p({}, m), {
                        errorMap: M(p({}, m.errorMap), {
                            [v]: l
                        })
                    })), (l || f) && (n = !0)
                }
                const u = N("submit");
                this.state.errorMap[u] && t !== "submit" && !n && this.baseStore.setState(h => M(p({}, h), {
                    errorMap: M(p({}, h.errorMap), {
                        [u]: void 0
                    })
                }))
            }), {
                hasErrored: n,
                fieldsErrorMap: o
            }
        }, this.validateAsync = async t => {
            const s = ot(t, this.options);
            this.state.isFormValidating || this.baseStore.setState(h => M(p({}, h), {
                isFormValidating: !0
            }));
            const n = [];
            let o;
            for (const h of s) {
                if (!h.validate) continue;
                const d = N(h.cause),
                    l = this.state.validationMetaMap[d];
                l == null || l.lastAbortController.abort();
                const f = new AbortController;
                this.state.validationMetaMap[d] = {
                    lastAbortController: f
                }, n.push(new Promise(async v => {
                    let m;
                    try {
                        m = await new Promise((b, V) => {
                            setTimeout(async () => {
                                if (f.signal.aborted) return b(void 0);
                                try {
                                    b(await this.runValidator({
                                        validate: h.validate,
                                        value: {
                                            value: this.state.values,
                                            formApi: this,
                                            validationSource: "form",
                                            signal: f.signal
                                        },
                                        type: "validateAsync"
                                    }))
                                } catch (w) {
                                    V(w)
                                }
                            }, h.debounceMs)
                        })
                    } catch (b) {
                        m = b
                    }
                    const {
                        formError: g,
                        fieldErrors: y
                    } = ut(m);
                    y && (o = o ? p(p({}, o), y) : y);
                    const S = N(h.cause);
                    if (o)
                        for (const [b, V] of Object.entries(o)) {
                            const w = this.getFieldMeta(b);
                            w && w.errorMap[S] !== V && this.setFieldMeta(b, E => M(p({}, E), {
                                errorMap: M(p({}, E.errorMap), {
                                    [S]: V
                                })
                            }))
                        }
                    this.baseStore.setState(b => M(p({}, b), {
                        errorMap: M(p({}, b.errorMap), {
                            [S]: g
                        })
                    })), v(o ? {
                        fieldErrors: o,
                        errorMapKey: S
                    } : void 0)
                }))
            }
            let c = [];
            const u = {};
            if (n.length) {
                c = await Promise.all(n);
                for (const h of c)
                    if (h != null && h.fieldErrors) {
                        const {
                            errorMapKey: d
                        } = h;
                        for (const [l, f] of Object.entries(h.fieldErrors)) {
                            const v = u[l] || {},
                                m = M(p({}, v), {
                                    [d]: f
                                });
                            u[l] = m
                        }
                    }
            }
            return this.baseStore.setState(h => M(p({}, h), {
                isFormValidating: !1
            })), u
        }, this.validate = t => {
            const {
                hasErrored: s,
                fieldsErrorMap: n
            } = this.validateSync(t);
            return s && !this.options.asyncAlways ? n : this.validateAsync(t)
        }, this.getFieldValue = t => wt(this.state.values, t), this.getFieldMeta = t => this.state.fieldMeta[t], this.getFieldInfo = t => {
            var s;
            return (s = this.fieldInfo)[t] || (s[t] = {
                instance: null,
                validationMetaMap: {
                    onChange: void 0,
                    onBlur: void 0,
                    onSubmit: void 0,
                    onMount: void 0,
                    onServer: void 0
                }
            })
        }, this.setFieldMeta = (t, s) => {
            this.baseStore.setState(n => M(p({}, n), {
                fieldMetaBase: M(p({}, n.fieldMetaBase), {
                    [t]: Q(s, n.fieldMetaBase[t])
                })
            }))
        }, this.resetFieldMeta = t => Object.keys(t).reduce((s, n) => {
            const o = n;
            return s[o] = q, s
        }, {}), this.setFieldValue = (t, s, n) => {
            var c;
            const o = (c = n == null ? void 0 : n.dontUpdateMeta) != null ? c : !1;
            D(() => {
                o || this.setFieldMeta(t, u => M(p({}, u), {
                    isTouched: !0,
                    isDirty: !0,
                    errorMap: M(p({}, u == null ? void 0 : u.errorMap), {
                        onMount: void 0
                    })
                })), this.baseStore.setState(u => M(p({}, u), {
                    values: tt(u.values, t, s)
                }))
            })
        }, this.deleteField = t => {
            const n = [...Object.keys(this.fieldInfo).filter(o => {
                const c = t.toString();
                return o !== c && o.startsWith(c)
            }), t];
            this.baseStore.setState(o => {
                const c = p({}, o);
                return n.forEach(u => {
                    c.values = Rt(c.values, u), delete this.fieldInfo[u], delete c.fieldMetaBase[u]
                }), c
            })
        }, this.pushFieldValue = (t, s, n) => {
            this.setFieldValue(t, o => [...Array.isArray(o) ? o : [], s], n), this.validateField(t, "change")
        }, this.insertFieldValue = async (t, s, n, o) => {
            this.setFieldValue(t, c => [...c.slice(0, s), n, ...c.slice(s)], o), await this.validateField(t, "change"), U(this).handleArrayFieldMetaShift(t, s, "insert"), await this.validateArrayFieldsStartingFrom(t, s, "change")
        }, this.replaceFieldValue = async (t, s, n, o) => {
            this.setFieldValue(t, c => c.map((u, h) => h === s ? n : u), o), await this.validateField(t, "change"), await this.validateArrayFieldsStartingFrom(t, s, "change")
        }, this.removeFieldValue = async (t, s, n) => {
            const o = this.getFieldValue(t),
                c = Array.isArray(o) ? Math.max(o.length - 1, 0) : null;
            if (this.setFieldValue(t, u => u.filter((h, d) => d !== s), n), U(this).handleArrayFieldMetaShift(t, s, "remove"), c !== null) {
                const u = "".concat(t, "[").concat(c, "]");
                this.deleteField(u)
            }
            await this.validateField(t, "change"), await this.validateArrayFieldsStartingFrom(t, s, "change")
        }, this.swapFieldValues = (t, s, n, o) => {
            this.setFieldValue(t, c => {
                const u = c[s],
                    h = c[n];
                return tt(tt(c, "".concat(s), h), "".concat(n), u)
            }, o), U(this).handleArrayFieldMetaShift(t, s, "swap", n), this.validateField(t, "change"), this.validateField("".concat(t, "[").concat(s, "]"), "change"), this.validateField("".concat(t, "[").concat(n, "]"), "change")
        }, this.moveFieldValues = (t, s, n, o) => {
            this.setFieldValue(t, c => (c.splice(n, 0, c.splice(s, 1)[0]), c), o), U(this).handleArrayFieldMetaShift(t, s, "move", n), this.validateField(t, "change"), this.validateField("".concat(t, "[").concat(s, "]"), "change"), this.validateField("".concat(t, "[").concat(n, "]"), "change")
        }, this.resetField = t => {
            this.baseStore.setState(s => M(p({}, s), {
                fieldMetaBase: M(p({}, s.fieldMetaBase), {
                    [t]: q
                }),
                values: M(p({}, s.values), {
                    [t]: this.options.defaultValues && this.options.defaultValues[t]
                })
            }))
        }, this.getAllErrors = () => ({
            form: {
                errors: this.state.errors,
                errorMap: this.state.errorMap
            },
            fields: Object.entries(this.state.fieldMeta).reduce((t, [s, n]) => (Object.keys(n).length && n.errors.length && (t[s] = {
                errors: n.errors,
                errorMap: n.errorMap
            }), t), {})
        }), this.baseStore = new at(st(M(p({}, a == null ? void 0 : a.defaultState), {
            values: (r = a == null ? void 0 : a.defaultValues) != null ? r : (e = a == null ? void 0 : a.defaultState) == null ? void 0 : e.values
        }))), this.fieldMetaDerived = new k({
            deps: [this.baseStore],
            fn: ({
                prevDepVals: t,
                currDepVals: s,
                prevVal: n
            }) => {
                var f;
                var o;
                const c = n,
                    u = t == null ? void 0 : t[0],
                    h = s[0];
                let d = 0;
                const l = {};
                for (const v of Object.keys(h.fieldMetaBase)) {
                    const m = h.fieldMetaBase[v],
                        g = u == null ? void 0 : u.fieldMetaBase[v],
                        y = c == null ? void 0 : c[v];
                    let S = y == null ? void 0 : y.errors;
                    if (!g || m.errorMap !== g.errorMap) {
                        S = Object.values((f = m.errorMap) != null ? f : {}).filter(w => w !== void 0);
                        const V = (o = this.getFieldInfo(v)) == null ? void 0 : o.instance;
                        V && !V.options.disableErrorFlat && (S = S == null ? void 0 : S.flat(1))
                    }
                    const b = !m.isDirty;
                    if (y && y.isPristine === b && y.errors === S && m === g) {
                        l[v] = y, d++;
                        continue
                    }
                    l[v] = M(p({}, m), {
                        errors: S,
                        isPristine: b
                    })
                }
                return Object.keys(h.fieldMetaBase).length && c && d === Object.keys(h.fieldMetaBase).length ? c : l
            }
        }), this.store = new k({
            deps: [this.baseStore, this.fieldMetaDerived],
            fn: ({
                prevDepVals: t,
                currDepVals: s,
                prevVal: n
            }) => {
                var ft, vt, pt;
                var o, c, u, h;
                const d = n,
                    l = t == null ? void 0 : t[0],
                    f = s[0],
                    v = Object.values(f.fieldMetaBase),
                    m = v.some(F => F == null ? void 0 : F.isValidating),
                    g = !v.some(F => (F == null ? void 0 : F.errorMap) && Kt(Object.values(F.errorMap).filter(Boolean))),
                    y = v.some(F => F == null ? void 0 : F.isTouched),
                    S = v.some(F => F == null ? void 0 : F.isBlurred),
                    b = y && ((o = f == null ? void 0 : f.errorMap) == null ? void 0 : o.onMount),
                    V = v.some(F => F == null ? void 0 : F.isDirty),
                    w = !V,
                    E = !!((c = f.errorMap) != null && c.onMount || v.some(F => {
                        var O;
                        return (O = F == null ? void 0 : F.errorMap) == null ? void 0 : O.onMount
                    })),
                    A = !!m;
                let _ = (ft = d == null ? void 0 : d.errors) != null ? ft : [];
                (!l || f.errorMap !== l.errorMap) && (_ = Object.values(f.errorMap).reduce((F, O) => O === void 0 ? F : O && At(O) ? (F.push(O.form), F) : (F.push(O), F), []));
                const I = _.length === 0,
                    P = g && I,
                    Tt = (vt = this.options.canSubmitWhenInvalid) != null ? vt : !1,
                    ht = f.submissionAttempts === 0 && !y && !E || !A && !f.isSubmitting && P || Tt;
                let W = f.errorMap;
                if (b && (_ = _.filter(F => F !== f.errorMap.onMount), W = Object.assign(W, {
                        onMount: void 0
                    })), d && l && d.errorMap === W && d.fieldMeta === this.fieldMetaDerived.state && d.errors === _ && d.isFieldsValidating === m && d.isFieldsValid === g && d.isFormValid === I && d.isValid === P && d.canSubmit === ht && d.isTouched === y && d.isBlurred === S && d.isPristine === w && d.isDirty === V && et(l, f)) return d;
                let X = M(p({}, f), {
                    errorMap: W,
                    fieldMeta: this.fieldMetaDerived.state,
                    errors: _,
                    isFieldsValidating: m,
                    isFieldsValid: g,
                    isFormValid: I,
                    isValid: P,
                    canSubmit: ht,
                    isTouched: y,
                    isBlurred: S,
                    isPristine: w,
                    isDirty: V
                });
                const Y = (pt = (u = this.options.transform) == null ? void 0 : u.deps) != null ? pt : [];
                if (Y.length !== this.prevTransformArray.length || Y.some((F, O) => F !== this.prevTransformArray[O])) {
                    const F = Object.assign({}, this, {
                        state: X
                    });
                    (h = this.options.transform) == null || h.fn(F), X = F.state, this.prevTransformArray = Y
                }
                return X
            }
        }), this.handleSubmit = this.handleSubmit.bind(this), this.update(a || {})
    }
    get state() {
        return this.store.state
    }
    runValidator(a) {
        return kt(a.validate) ? Ot[a.type](a.value, a.validate) : a.validate(a.value)
    }
    async handleSubmit(a) {
        var e, r, t, s, n, o;
        if (this.baseStore.setState(u => M(p({}, u), {
                isSubmitted: !1,
                submissionAttempts: u.submissionAttempts + 1,
                isSubmitSuccessful: !1
            })), !this.state.canSubmit) return;
        this.baseStore.setState(u => M(p({}, u), {
            isSubmitting: !0
        }));
        const c = () => {
            this.baseStore.setState(u => M(p({}, u), {
                isSubmitting: !1
            }))
        };
        if (await this.validateAllFields("submit"), !this.state.isFieldsValid) {
            c(), (r = (e = this.options).onSubmitInvalid) == null || r.call(e, {
                value: this.state.values,
                formApi: this
            });
            return
        }
        if (await this.validate("submit"), !this.state.isValid) {
            c(), (s = (t = this.options).onSubmitInvalid) == null || s.call(t, {
                value: this.state.values,
                formApi: this
            });
            return
        }
        D(() => {
            Object.values(this.fieldInfo).forEach(u => {
                var h, d, l;
                (l = (d = (h = u.instance) == null ? void 0 : h.options.listeners) == null ? void 0 : d.onSubmit) == null || l.call(d, {
                    value: u.instance.state.value,
                    fieldApi: u.instance
                })
            })
        });
        try {
            await ((o = (n = this.options).onSubmit) == null ? void 0 : o.call(n, {
                value: this.state.values,
                formApi: this,
                meta: a != null ? a : this.options.onSubmitMeta
            })), D(() => {
                this.baseStore.setState(u => M(p({}, u), {
                    isSubmitted: !0,
                    isSubmitSuccessful: !0
                })), c()
            })
        } catch (u) {
            throw this.baseStore.setState(h => M(p({}, h), {
                isSubmitSuccessful: !1
            })), c(), u
        }
    }
    setErrorMap(a) {
        this.baseStore.setState(e => M(p({}, e), {
            errorMap: p(p({}, e.errorMap), a)
        }))
    }
}

function ut(i) {
    if (i) {
        if (At(i)) {
            const a = ut(i.form).formError,
                e = i.fields;
            return {
                formError: a,
                fieldErrors: e
            }
        }
        return {
            formError: i
        }
    }
    return {
        formError: void 0
    }
}

function N(i) {
    switch (i) {
        case "submit":
            return "onSubmit";
        case "blur":
            return "onBlur";
        case "mount":
            return "onMount";
        case "server":
            return "onServer";
        case "change":
        default:
            return "onChange"
    }
}
class Xt {
    constructor(a) {
        this.options = {}, this.mount = () => {
            var e, r;
            const t = this.store.mount();
            this.options.defaultValue !== void 0 && this.form.setFieldValue(this.name, this.options.defaultValue, {
                dontUpdateMeta: !0
            });
            const s = this.getInfo();
            s.instance = this, this.update(this.options);
            const {
                onMount: n
            } = this.options.validators || {};
            if (n) {
                const o = this.runValidator({
                    validate: n,
                    value: {
                        value: this.state.value,
                        fieldApi: this,
                        validationSource: "field"
                    },
                    type: "validate"
                });
                o && this.setMeta(c => M(p({}, c), {
                    errorMap: M(p({}, c == null ? void 0 : c.errorMap), {
                        onMount: o
                    })
                }))
            }
            return (r = (e = this.options.listeners) == null ? void 0 : e.onMount) == null || r.call(e, {
                value: this.state.value,
                fieldApi: this
            }), t
        }, this.update = e => {
            var t;
            this.options = e;
            const r = this.name !== e.name;
            if (this.name = e.name, this.state.value === void 0) {
                const s = wt(e.form.options.defaultValues, e.name),
                    n = (t = e.defaultValue) != null ? t : s;
                r ? this.setValue(o => o || n, {
                    dontUpdateMeta: !0
                }) : n !== void 0 && this.setValue(n, {
                    dontUpdateMeta: !0
                })
            }
            this.form.getFieldMeta(this.name) === void 0 && this.setMeta(this.state.meta)
        }, this.getValue = () => this.form.getFieldValue(this.name), this.setValue = (e, r) => {
            var t, s;
            this.form.setFieldValue(this.name, e, r), (s = (t = this.options.listeners) == null ? void 0 : t.onChange) == null || s.call(t, {
                value: this.state.value,
                fieldApi: this
            }), this.validate("change")
        }, this.getMeta = () => this.store.state.meta, this.setMeta = e => this.form.setFieldMeta(this.name, e), this.getInfo = () => this.form.getFieldInfo(this.name), this.pushValue = (e, r) => {
            var t, s;
            this.form.pushFieldValue(this.name, e, r), (s = (t = this.options.listeners) == null ? void 0 : t.onChange) == null || s.call(t, {
                value: this.state.value,
                fieldApi: this
            })
        }, this.insertValue = (e, r, t) => {
            var s, n;
            this.form.insertFieldValue(this.name, e, r, t), (n = (s = this.options.listeners) == null ? void 0 : s.onChange) == null || n.call(s, {
                value: this.state.value,
                fieldApi: this
            })
        }, this.replaceValue = (e, r, t) => {
            var s, n;
            this.form.replaceFieldValue(this.name, e, r, t), (n = (s = this.options.listeners) == null ? void 0 : s.onChange) == null || n.call(s, {
                value: this.state.value,
                fieldApi: this
            })
        }, this.removeValue = (e, r) => {
            var t, s;
            this.form.removeFieldValue(this.name, e, r), (s = (t = this.options.listeners) == null ? void 0 : t.onChange) == null || s.call(t, {
                value: this.state.value,
                fieldApi: this
            })
        }, this.swapValues = (e, r, t) => {
            var s, n;
            this.form.swapFieldValues(this.name, e, r, t), (n = (s = this.options.listeners) == null ? void 0 : s.onChange) == null || n.call(s, {
                value: this.state.value,
                fieldApi: this
            })
        }, this.moveValue = (e, r, t) => {
            var s, n;
            this.form.moveFieldValues(this.name, e, r, t), (n = (s = this.options.listeners) == null ? void 0 : s.onChange) == null || n.call(s, {
                value: this.state.value,
                fieldApi: this
            })
        }, this.getLinkedFields = e => {
            const r = Object.values(this.form.fieldInfo),
                t = [];
            for (const s of r) {
                if (!s.instance) continue;
                const {
                    onChangeListenTo: n,
                    onBlurListenTo: o
                } = s.instance.options.validators || {};
                e === "change" && (n != null && n.includes(this.name)) && t.push(s.instance), e === "blur" && (o != null && o.includes(this.name)) && t.push(s.instance)
            }
            return t
        }, this.validateSync = (e, r) => {
            const t = lt(e, this.options),
                n = this.getLinkedFields(e).reduce((u, h) => {
                    const d = lt(e, h.options);
                    return d.forEach(l => {
                        l.field = h
                    }), u.concat(d)
                }, []);
            let o = !1;
            D(() => {
                const u = (h, d) => {
                    const l = $(d.cause),
                        f = d.validate ? Ft(h.runValidator({
                            validate: d.validate,
                            value: {
                                value: h.store.state.value,
                                validationSource: "field",
                                fieldApi: h
                            },
                            type: "validate"
                        })) : r[l];
                    h.state.meta.errorMap[l] !== f && h.setMeta(v => M(p({}, v), {
                        errorMap: M(p({}, v.errorMap), {
                            [$(d.cause)]: f || r[l]
                        })
                    })), (f || r[l]) && (o = !0)
                };
                for (const h of t) u(this, h);
                for (const h of n) h.validate && u(h.field, h)
            });
            const c = $("submit");
            return this.state.meta.errorMap[c] && e !== "submit" && !o && this.setMeta(u => M(p({}, u), {
                errorMap: M(p({}, u.errorMap), {
                    [c]: void 0
                })
            })), {
                hasErrored: o
            }
        }, this.validateAsync = async (e, r) => {
            const t = ot(e, this.options),
                s = await r,
                n = this.getLinkedFields(e),
                o = n.reduce((l, f) => {
                    const v = ot(e, f.options);
                    return v.forEach(m => {
                        m.field = f
                    }), l.concat(v)
                }, []);
            this.state.meta.isValidating || this.setMeta(l => M(p({}, l), {
                isValidating: !0
            }));
            for (const l of n) l.setMeta(f => M(p({}, f), {
                isValidating: !0
            }));
            const c = [],
                u = [],
                h = (l, f, v) => {
                    const m = $(f.cause),
                        g = l.getInfo().validationMetaMap[m];
                    g == null || g.lastAbortController.abort();
                    const y = new AbortController;
                    this.getInfo().validationMetaMap[m] = {
                        lastAbortController: y
                    }, v.push(new Promise(async S => {
                        var b;
                        let V;
                        try {
                            V = await new Promise((_, I) => {
                                this.timeoutIds[f.cause] && clearTimeout(this.timeoutIds[f.cause]), this.timeoutIds[f.cause] = setTimeout(async () => {
                                    if (y.signal.aborted) return _(void 0);
                                    try {
                                        _(await this.runValidator({
                                            validate: f.validate,
                                            value: {
                                                value: l.store.state.value,
                                                fieldApi: l,
                                                signal: y.signal,
                                                validationSource: "field"
                                            },
                                            type: "validateAsync"
                                        }))
                                    } catch (P) {
                                        I(P)
                                    }
                                }, f.debounceMs)
                            })
                        } catch (_) {
                            V = _
                        }
                        if (y.signal.aborted) return S(void 0);
                        const w = Ft(V),
                            E = (b = s[this.name]) == null ? void 0 : b[m],
                            A = w || E;
                        l.setMeta(_ => M(p({}, _), {
                            errorMap: M(p({}, _ == null ? void 0 : _.errorMap), {
                                [m]: A
                            })
                        })), S(A)
                    }))
                };
            for (const l of t) l.validate && h(this, l, c);
            for (const l of o) l.validate && h(l.field, l, u);
            let d = [];
            (c.length || u.length) && (d = await Promise.all(c), await Promise.all(u)), this.setMeta(l => M(p({}, l), {
                isValidating: !1
            }));
            for (const l of n) l.setMeta(f => M(p({}, f), {
                isValidating: !1
            }));
            return d.filter(Boolean)
        }, this.validate = (e, r) => {
            var c;
            var t;
            if (!this.state.meta.isTouched) return [];
            const {
                fieldsErrorMap: s
            } = r != null && r.skipFormValidation ? {
                fieldsErrorMap: {}
            } : this.form.validateSync(e), {
                hasErrored: n
            } = this.validateSync(e, (c = s[this.name]) != null ? c : {});
            if (n && !this.options.asyncAlways) return (t = this.getInfo().validationMetaMap[$(e)]) == null || t.lastAbortController.abort(), this.state.meta.errors;
            const o = r != null && r.skipFormValidation ? Promise.resolve({}) : this.form.validateAsync(e);
            return this.validateAsync(e, o)
        }, this.handleChange = e => {
            this.setValue(e)
        }, this.handleBlur = () => {
            var e, r;
            this.state.meta.isTouched || (this.setMeta(s => M(p({}, s), {
                isTouched: !0
            })), this.validate("change")), this.state.meta.isBlurred || this.setMeta(s => M(p({}, s), {
                isBlurred: !0
            })), this.validate("blur"), (r = (e = this.options.listeners) == null ? void 0 : e.onBlur) == null || r.call(e, {
                value: this.state.value,
                fieldApi: this
            })
        }, this.form = a.form, this.name = a.name, this.timeoutIds = {}, this.store = new k({
            deps: [this.form.store],
            fn: () => {
                var t;
                const e = this.form.getFieldValue(this.name),
                    r = (t = this.form.getFieldMeta(this.name)) != null ? t : p(p({}, q), a.defaultMeta);
                return {
                    value: e,
                    meta: r
                }
            }
        }), this.options = a
    }
    get state() {
        return this.store.state
    }
    runValidator(a) {
        return kt(a.validate) ? Ot[a.type](a.value, a.validate) : a.validate(a.value)
    }
    setErrorMap(a) {
        this.setMeta(e => M(p({}, e), {
            errorMap: p(p({}, e.errorMap), a)
        }))
    }
}

function Ft(i) {
    if (i) return i
}

function $(i) {
    switch (i) {
        case "submit":
            return "onSubmit";
        case "blur":
            return "onBlur";
        case "mount":
            return "onMount";
        case "server":
            return "onServer";
        case "change":
        default:
            return "onChange"
    }
}
var it = {
        exports: {}
    },
    rt = {};
/**
 * @license React
 * use-sync-external-store-shim/with-selector.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var bt;

function Yt() {
    if (bt) return rt;
    bt = 1;
    var i = Ct(),
        a = Bt();

    function e(u, h) {
        return u === h && (u !== 0 || 1 / u === 1 / h) || u !== u && h !== h
    }
    var r = typeof Object.is == "function" ? Object.is : e,
        t = a.useSyncExternalStore,
        s = i.useRef,
        n = i.useEffect,
        o = i.useMemo,
        c = i.useDebugValue;
    return rt.useSyncExternalStoreWithSelector = function(u, h, d, l, f) {
        var v = s(null);
        if (v.current === null) {
            var m = {
                hasValue: !1,
                value: null
            };
            v.current = m
        } else m = v.current;
        v = o(function() {
            function y(E) {
                if (!S) {
                    if (S = !0, b = E, E = l(E), f !== void 0 && m.hasValue) {
                        var A = m.value;
                        if (f(A, E)) return V = A
                    }
                    return V = E
                }
                if (A = V, r(b, E)) return A;
                var _ = l(E);
                return f !== void 0 && f(A, _) ? (b = E, A) : (b = E, V = _)
            }
            var S = !1,
                b, V, w = d === void 0 ? null : d;
            return [function() {
                return y(h())
            }, w === null ? void 0 : function() {
                return y(w())
            }]
        }, [h, d, l, f]);
        var g = t(u, v[0], v[1]);
        return n(function() {
            m.hasValue = !0, m.value = g
        }, [g]), c(g), g
    }, rt
}
var Vt;

function Zt() {
    return Vt || (Vt = 1, it.exports = Yt()), it.exports
}
var xt = Zt();

function dt(i, a = e => e) {
    return xt.useSyncExternalStoreWithSelector(i.subscribe, () => i.state, () => i.state, a, te)
}

function te(i, a) {
    if (Object.is(i, a)) return !0;
    if (typeof i != "object" || i === null || typeof a != "object" || a === null) return !1;
    if (i instanceof Map && a instanceof Map) {
        if (i.size !== a.size) return !1;
        for (const [r, t] of i)
            if (!a.has(r) || !Object.is(t, a.get(r))) return !1;
        return !0
    }
    if (i instanceof Set && a instanceof Set) {
        if (i.size !== a.size) return !1;
        for (const r of i)
            if (!a.has(r)) return !1;
        return !0
    }
    const e = Object.keys(i);
    if (e.length !== Object.keys(a).length) return !1;
    for (let r = 0; r < e.length; r++)
        if (!Object.prototype.hasOwnProperty.call(a, e[r]) || !Object.is(i[e[r]], a[e[r]])) return !1;
    return !0
}
const J = typeof window < "u" ? z.useLayoutEffect : z.useEffect;

function ee(i) {
    const [a] = z.useState(() => {
        const r = new Xt(M(p({}, i), {
            form: i.form,
            name: i.name
        }));
        return r.Field = Dt, r
    });
    return J(a.mount, [a]), J(() => {
        a.update(i)
    }), dt(a.store, i.mode === "array" ? e => {
        var r;
        return [e.meta, Object.keys((r = e.value) != null ? r : []).length]
    } : void 0), a
}
const Dt = e => {
    var r = e,
        {
            children: i
        } = r,
        a = Z(r, ["children"]);
    const t = ee(a),
        s = z.useMemo(() => Q(i, t), [i, t, t.state.value, t.state.meta]);
    return K.jsx(K.Fragment, {
        children: s
    })
};

function se({
    form: i,
    selector: a,
    children: e
}) {
    const r = dt(i.store, a);
    return Q(e, r)
}

function oe(i) {
    const [a] = z.useState(() => {
        const e = new Qt(i),
            r = e;
        return r.Field = function(s) {
            return K.jsx(Dt, M(p({}, s), {
                form: e
            }))
        }, r.Subscribe = t => K.jsx(se, {
            form: e,
            selector: t.selector,
            children: t.children
        }), r
    });
    return J(a.mount, []), dt(a.store, e => e.isSubmitting), J(() => {
        a.update(i)
    }), a
}
export {
    dt as a, ee as b, oe as u
};
//# sourceMappingURL=ogty5pbz2ckq625a.js.map