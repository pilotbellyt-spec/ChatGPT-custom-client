import {
    c as e,
    jx as p
} from "./dykg4ktvbu3mhmdo.js";
const r = e(p, "f5a288", 24, 24);
export {
    r as E
};
//# sourceMappingURL=jdg49hmintmo4ij6.js.map