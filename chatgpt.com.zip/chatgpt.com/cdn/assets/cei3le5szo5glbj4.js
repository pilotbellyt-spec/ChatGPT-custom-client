import {
    ag as l,
    m as u
} from "./dykg4ktvbu3mhmdo.js";
import {
    p as f,
    i as c,
    a as h
} from "./jb9b7tatrnyq635u.js";
import {
    W as p
} from "./mvhcdm28zmc6uy2d.js";
import {
    a as E,
    e as M,
    u as g,
    d as w
} from "./fg33krlcm0qyi6yw.js";

function W({
    onSuccess: t,
    showSuccessToast: m = !0
}) {
    const s = E(),
        a = l(),
        i = u(),
        d = M();
    return g({
        mutationFn: e => p.createEnvironment(e),
        onSuccess: async e => {
            var n, o, r;
            e && f(s, e, {
                id: (n = a == null ? void 0 : a.id) != null ? n : "",
                email: (o = a == null ? void 0 : a.email) != null ? o : "",
                name: (r = a == null ? void 0 : a.name) != null ? r : ""
            }), await Promise.all([c(s), h(s, e == null ? void 0 : e.id)]), m && i.success(d.formatMessage({
                id: "wham.whamMutations.environmentCreatedSuccessfully",
                defaultMessage: "Environment created successfully"
            })), t == null || t(e)
        },
        onError: () => {
            i.danger(w({
                id: "wham.whamMutations.failedToCreateEnvironment",
                defaultMessage: "Failed to create environment"
            }), {
                toastId: "wham_mutations_failed_to_create_environment"
            })
        }
    })
}
export {
    W as u
};
//# sourceMappingURL=cei3le5szo5glbj4.js.map