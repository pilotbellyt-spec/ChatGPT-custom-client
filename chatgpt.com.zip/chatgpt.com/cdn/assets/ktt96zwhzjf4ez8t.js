var q = Object.defineProperty;
var j = Object.getOwnPropertySymbols;
var R = Object.prototype.hasOwnProperty,
    Y = Object.prototype.propertyIsEnumerable;
var k = (s, n, a) => n in s ? q(s, n, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: a
    }) : s[n] = a,
    t = (s, n) => {
        for (var a in n || (n = {})) R.call(n, a) && k(s, a, n[a]);
        if (j)
            for (var a of j(n)) Y.call(n, a) && k(s, a, n[a]);
        return s
    };
import {
    j as e,
    r,
    M as l,
    d as i
} from "./fg33krlcm0qyi6yw.js";
import {
    C as M,
    bv as B,
    bg as K,
    o as W,
    b as $,
    I as G,
    a9 as H,
    k_ as J
} from "./dykg4ktvbu3mhmdo.js";
import {
    bp as Q,
    bq as X,
    jM as Z,
    az as N,
    gA as ee,
    cb as se,
    c7 as ae
} from "./k15yxxoybkkir2ou.js";
import {
    M as ie
} from "./nqe0i9lpbwaca416.js";
import {
    V as ne
} from "./kdyw5bvpba4cf5f0.js";

function te(s) {
    return e.jsx(M, {
        testId: "modal-voice-picker",
        isOpen: s.isOpen,
        onClose: s.onClose,
        type: "success",
        size: "fullscreen",
        children: e.jsx(B, {
            children: e.jsx(K.div, {
                children: e.jsx(ne, {
                    conversationId: s.conversationId,
                    onClose: s.onClose,
                    cameFromNux: s.cameFromNux,
                    initialVoiceName: s.initialVoiceName
                })
            })
        })
    })
}

function d({
    title: s,
    description: n,
    icon: a
}) {
    return e.jsxs("div", {
        className: "flex items-start",
        children: [e.jsx("div", {
            className: "shrink-0",
            children: a
        }), e.jsxs("div", {
            className: "text-start",
            children: [e.jsx("h4", {
                className: "text-token-text-primary font-semibold",
                children: e.jsx(l, t({}, s))
            }), e.jsx("p", {
                className: "text-token-text-secondary",
                children: e.jsx(l, t({}, n))
            })]
        })]
    })
}

function oe({
    conversationId: s,
    initialVoiceName: n
}) {
    var g, h;
    const a = $(),
        y = W(a, "4291846205"),
        c = G(a),
        b = (g = c == null ? void 0 : c.isPlus()) != null ? g : !1,
        u = (h = c == null ? void 0 : c.isEnterprisey()) != null ? h : !1,
        [w, C] = r.useState(!1),
        [S, P] = r.useState(!1),
        [V, F] = r.useState(!1),
        [A, I] = r.useState(!0);
    r.useEffect(() => {
        requestAnimationFrame(() => P(!0))
    }, []);
    const O = () => {
            F(!0), J.voiceAdvancedDisclosureAccepted.click(), C(!0), setTimeout(async () => {
                I(!1)
            }, Z)
        },
        m = () => {
            Q(a, X.hasSeenAdvancedVoiceNuxFullPage)
        },
        p = e.jsx(d, t({}, o.naturalConversations)),
        z = e.jsx(d, t({}, o.freePreview)),
        _ = e.jsx(d, t({}, o.multipleVoices)),
        f = e.jsx(d, t({}, o.personalized)),
        x = e.jsx(d, t({}, u ? o.controlEnterprise : o.controlDefault)),
        E = [z, p, f, x],
        L = [p, _, f, x],
        v = u || b || y,
        D = v ? L : E;
    return e.jsxs(e.Fragment, {
        children: [e.jsx(te, {
            isOpen: w,
            onClose: m,
            conversationId: s,
            cameFromNux: !0,
            initialVoiceName: n
        }), e.jsx(M, {
            testId: "modal-advanced-voice-nux",
            isOpen: A,
            onClose: m,
            type: "success",
            size: "fullscreen",
            className: "bg-white transition-opacity duration-300 dark:bg-gray-800 ".concat(S && !V ? "opacity-100" : "opacity-0"),
            showOverlayBackground: !1,
            children: e.jsxs("div", {
                className: "mx-auto flex h-full w-full max-w-lg flex-col items-center justify-center px-4 text-center",
                children: [e.jsx("h1", {
                    className: "text-token-text-primary mb-9 text-2xl font-semibold",
                    children: e.jsx(l, t({}, v ? o.headingPaid : o.headingFreePreview))
                }), e.jsx("div", {
                    className: "mb-9 space-y-5",
                    children: D.map((T, U) => e.jsx("div", {
                        children: T
                    }, U))
                }), e.jsxs("p", {
                    className: "text-token-text-primary mb-9 text-sm",
                    children: [e.jsx(l, t({}, o.disclaimerMistakes)), e.jsx("br", {}), e.jsx(l, t({}, o.disclaimerUsageLimits))]
                }), e.jsx(H, {
                    className: "bg-token-text-primary rounded-full px-20 py-3 font-semibold",
                    onClick: O,
                    children: e.jsx(l, {
                        id: "ppi93b",
                        defaultMessage: "Continue"
                    })
                })]
            })
        })]
    })
}
const o = {
        naturalConversations: {
            title: i({
                id: "advanced-voice-nux-full-page.natural-conversations",
                defaultMessage: "Natural conversations"
            }),
            description: i({
                id: "advanced-voice-nux-full-page.natural-conversations-description",
                defaultMessage: "Senses and responds to interruptions, humor, and more."
            }),
            icon: e.jsx(ae, {
                className: "me-4 h-8 w-8"
            })
        },
        freePreview: {
            title: i({
                id: "advanced-voice-nux-full-page.free-preview",
                defaultMessage: "Free monthly preview"
            }),
            description: i({
                id: "advanced-voice-nux-full-page.free-preview-description",
                defaultMessage: "Use advanced voice for a short period each month."
            }),
            icon: e.jsx(se, {
                className: "me-4 h-8 w-8"
            })
        },
        multipleVoices: {
            title: i({
                id: "advanced-voice-nux-full-page.multiple-voices",
                defaultMessage: "Multiple voices"
            }),
            description: i({
                id: "advanced-voice-nux-full-page.multiple-voices-description",
                defaultMessage: "Offers an expanded set of voices to choose from."
            }),
            icon: e.jsx(ie, {
                className: "me-4 h-8 w-8"
            })
        },
        personalized: {
            title: i({
                id: "advanced-voice-nux-full-page.personalized-title",
                defaultMessage: "Personalized to you"
            }),
            description: i({
                id: "advanced-voice-nux-full-page.personalized-description",
                defaultMessage: "Can use memory and custom instructions to shape responses."
            }),
            icon: e.jsx(ee, {
                className: "me-4 h-8 w-8"
            })
        },
        controlEnterprise: {
            title: i({
                id: "advanced-voice-nux-full-page.control-enterprise-title",
                defaultMessage: "You’re in control"
            }),
            icon: e.jsx(N, {
                className: "me-4 h-8 w-8"
            }),
            description: i({
                id: "advanced-voice-nux-full-page.control-enterprise-description",
                defaultMessage: "Your audio recordings are saved but not used for training. Learn how to <link>manage recordings</link>.",
                values: {
                    link: s => e.jsx("a", {
                        href: "https://help.openai.com/en/articles/8400625-voice-mode-faq#h_c5d6fe534b",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        className: "underline",
                        children: s
                    })
                }
            })
        },
        controlDefault: {
            title: i({
                id: "advanced-voice-nux-full-page.control-default-title",
                defaultMessage: "You’re in control"
            }),
            icon: e.jsx(N, {
                className: "me-4 h-8 w-8"
            }),
            description: i({
                id: "advanced-voice-nux-full-page.control-default-description",
                defaultMessage: "Audio recordings are saved, and you can delete them at any time. Learn how to <link>manage recordings</link>.",
                values: {
                    link: s => e.jsx("a", {
                        href: "https://help.openai.com/en/articles/8400625-voice-mode-faq#h_c5d6fe534b",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        className: "underline",
                        children: s
                    })
                }
            })
        },
        headingFreePreview: i({
            id: "advanced-voice-nux-full-page.heading-free-preview",
            defaultMessage: "Sneak a peek at advanced voice mode"
        }),
        headingPaid: i({
            id: "advanced-voice-nux-full-page.heading-paid",
            defaultMessage: "Say hello to advanced voice mode"
        }),
        disclaimerMistakes: i({
            id: "advanced-voice-nux-full-page.disclaimer-mistakes",
            defaultMessage: "<link>Voice mode can make mistakes</link> — check important info.",
            values: {
                link: s => e.jsx("a", {
                    href: "https://help.openai.com/en/articles/8313428-does-chatgpt-tell-the-truth",
                    target: "_blank",
                    rel: "noopener noreferrer",
                    className: "underline",
                    children: s
                })
            }
        }),
        disclaimerUsageLimits: i({
            id: "advanced-voice-nux-full-page.disclaimer-usage-limits",
            defaultMessage: "Usage limits may change."
        })
    },
    pe = Object.freeze(Object.defineProperty({
        __proto__: null,
        AdvancedVoiceWebNuxFullPage: oe
    }, Symbol.toStringTag, {
        value: "Module"
    }));
export {
    oe as A, te as V, pe as a
};
//# sourceMappingURL=ktt96zwhzjf4ez8t.js.map