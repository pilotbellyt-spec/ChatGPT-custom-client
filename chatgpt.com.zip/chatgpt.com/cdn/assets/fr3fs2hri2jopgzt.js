import {
    r as i,
    j as m
} from "./fg33krlcm0qyi6yw.js";
import {
    fP as g,
    hh as x,
    c_ as N,
    b6 as P,
    o1 as F,
    b as k,
    o3 as V,
    en as w,
    eW as A,
    dB as M,
    dF as j,
    dH as C,
    o2 as _,
    _ as b
} from "./dykg4ktvbu3mhmdo.js";
import {
    jN as E,
    jO as I,
    dr as U,
    bq as z,
    jf as L,
    jg as O
} from "./k15yxxoybkkir2ou.js";
import {
    s as T
} from "./enojslb0kkkm419z.js";
import {
    A as W,
    V as $
} from "./ktt96zwhzjf4ez8t.js";
import "./nqe0i9lpbwaca416.js";
import "./kdyw5bvpba4cf5f0.js";
import "./fz8xw1971c2kf2eb.js";
import "./ftef8970ba1zoykr.js";
import "./dapgo43htqk76ir6.js";
const q = () => {
    const e = E();
    return i.useCallback(s => {
        T.set(s), e.setState({
            isVoiceModeActive: !0
        })
    }, [e])
};

function y() {
    const e = U(z.hasSeenAdvancedVoiceNuxFullPage);
    return !e.isLoading && e.eligible
}

function Z({
    clientThreadId: e
}) {
    const s = k(),
        c = g(o => o.showVoicePicker),
        f = g(o => o.showVoiceNuxFullPage),
        a = x(e),
        t = a != null ? a : e,
        r = !N(),
        {
            setValue: n
        } = I(P.VoiceName),
        d = y(),
        u = F(),
        l = q();
    return i.useEffect(() => {
        const o = sessionStorage.getItem("selectedVoiceName"),
            S = h => {
                const p = w(() => A(M(s, t)).id);
                try {
                    L(O.LoggedOut), sessionStorage.removeItem("selectedVoiceName"), l({
                        voice: h,
                        conversation_id: void 0,
                        eventSource: "login_page",
                        voice_mode: "advanced",
                        clientThreadId: _(),
                        gizmo_id: j.getGizmoId(C(t)),
                        requested_default_model: p,
                        skipCacheReason: "login-direct-to-voice-mode"
                    })
                } catch (v) {
                    b.addError("Failed to start voice mode after voice picker: ".concat(v), {
                        protocol: u
                    })
                }
            };
        o && !r && (n(o), S(o))
    }, [s, t, r, n, l, u]), i.useEffect(() => {
        d || V({
            showVoiceNuxFullPage: !1
        })
    }, [d]), f ? m.jsx(W, {
        conversationId: t
    }) : c ? m.jsx($, {
        isOpen: c,
        onClose: () => {
            V({
                showVoicePicker: !1
            })
        },
        conversationId: t,
        cameFromNux: !0
    }) : null
}
export {
    Z as VoiceModals
};
//# sourceMappingURL=fr3fs2hri2jopgzt.js.map