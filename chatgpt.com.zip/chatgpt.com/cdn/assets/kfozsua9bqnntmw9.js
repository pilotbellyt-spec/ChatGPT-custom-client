const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/bmupik4h4l2k89rq.js", "assets/fg33krlcm0qyi6yw.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/k15yxxoybkkir2ou.js", "assets/conversation-small-332fs9rk.css", "assets/hn5e71c3hkpkv00z.js", "assets/cgt1h5qo3k52ojx3.js"]))) => i.map(i => d[i]);
var H = Object.defineProperty,
    Y = Object.defineProperties;
var $ = Object.getOwnPropertyDescriptors;
var N = Object.getOwnPropertySymbols;
var X = Object.prototype.hasOwnProperty,
    J = Object.prototype.propertyIsEnumerable;
var U = (t, e, o) => e in t ? H(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: o
    }) : t[e] = o,
    E = (t, e) => {
        for (var o in e || (e = {})) X.call(e, o) && U(t, o, e[o]);
        if (N)
            for (var o of N(e)) J.call(e, o) && U(t, o, e[o]);
        return t
    },
    R = (t, e) => Y(t, $(e));
import {
    r as y,
    a as W,
    b as Z,
    j as n,
    M as u,
    _ as ee,
    d as te,
    u as oe
} from "./fg33krlcm0qyi6yw.js";
import {
    R as P,
    d as S,
    k as ne,
    b as C,
    bJ as B,
    o as se,
    sO as re,
    bh as ie,
    e2 as b,
    dQ as ae,
    e4 as I,
    aK as le,
    aL as de,
    m as ue,
    dI as ce,
    l as D,
    a9 as L,
    p8 as me,
    I as fe,
    P as k,
    dL as q,
    dR as G,
    A as pe
} from "./dykg4ktvbu3mhmdo.js";
import {
    jl as he,
    jm as ye,
    jn as ge,
    jo as xe,
    dr as Me,
    bq as T,
    jp as be,
    bp as _e,
    jq as je,
    fx as ve
} from "./k15yxxoybkkir2ou.js";
import {
    M as Te
} from "./k253gzle9qy7mdll.js";
import {
    G as Pe
} from "./jjruw0pg8h58hov8.js";
import "./ni16khhtjgvldr4m.js";
import "./hn5e71c3hkpkv00z.js";
import "./cgt1h5qo3k52ojx3.js";
const A = "memories/current_memory_undo_id",
    K = {
        async getCurrentMemoryUndoId(t) {
            return await P.safeGet("/memories/current_memory_undo_id", {
                parameters: {
                    query: {
                        gizmo_id: t
                    }
                }
            })
        },
        async undoMemoryWrite(t, e) {
            return await P.safePost("/memories/undo_memory_write", {
                requestBody: {
                    gizmo_id: t,
                    memory_undo_id: e
                }
            })
        }
    },
    Se = ie(() => ee(() =>
        import ("./bmupik4h4l2k89rq.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7])));
let F = !1;

function z(t) {
    return t.find(e => {
        var o;
        return e.author.role === b.Tool && ((o = e.metadata) == null ? void 0 : o.pending_memory_info)
    })
}

function Ae(t) {
    return t.filter((e, o) => {
        const s = t[o + 1],
            i = (s == null ? void 0 : s.recipient) === "assistant" && (s == null ? void 0 : s.author.role) === b.Tool && (s == null ? void 0 : s.author.name) === "bio" && ae(s).startsWith("Model set context");
        return e.author.role === b.Assistant && e.recipient === "bio" && i
    }).flatMap(e => {
        const o = e.content.content_type;
        return o === I.Text ? e.content.parts : o === I.Code ? [e.content.text] : []
    }).map(Ie)
}

function Ce(t) {
    return t.some(e => e.author.role === b.Assistant && e.recipient === "bio" && e.status === "in_progress")
}

function ke(t) {
    var o;
    const e = t.find(s => s.author.role === b.Tool && s.author.name === "bio" && s.recipient === b.Assistant);
    return (o = e == null ? void 0 : e.metadata) == null ? void 0 : o.current_memory_undo_id
}

function we(t) {
    const {
        eligible: e,
        isLoading: o
    } = ye(), s = y.useMemo(() => t.length > 0, [t]);
    y.useEffect(() => {
        s && e && !o && le.openModal(de.GlobalMemoryOnboarding)
    }, [s, e, o])
}

function Oe(t) {
    const [e, o] = y.useState(!1);
    return {
        isPopoverOpen: e,
        setIsPopoverOpen: o,
        handleTogglePopover: r => {
            const i = r != null ? r : !e;
            o(i), i && k.logEvent("Memory Update Popover Shown", {
                updateCount: t.length
            })
        }
    }
}

function Q({
    memoryWrites: t,
    popoverState: e,
    triggerButton: o,
    isParagen: s,
    gizmoId: r,
    memoryUndoId: i,
    setShowMemoriesModal: c,
    disableActions: d
}) {
    return n.jsxs(je, {
        open: e.isPopoverOpen,
        sideOffset: 4,
        side: "bottom",
        alignAgainstAnchor: "start",
        size: "none",
        className: "z-10 max-w-96 min-w-60 text-sm",
        onOpenChange: a => e.handleTogglePopover(a),
        disableAutofocus: !0,
        triggerButton: o,
        children: [n.jsx("div", {
            className: "border-token-border-default bg-token-main-surface-secondary mb-2 rounded-sm border",
            children: t.map((a, l) => n.jsx("div", {
                className: "border-token-border-default border-b px-3 py-2 first-letter:uppercase last:border-b-0",
                children: a
            }, l))
        }), s ? n.jsx("div", {
            className: "text-token-text-tertiary text-xs",
            children: n.jsx(u, {
                id: "MemoryActionResult.paragenMessage",
                defaultMessage: "This memory will be saved if you choose this response."
            })
        }) : d ? null : n.jsxs(n.Fragment, {
            children: [n.jsx(Re, {
                gizmoId: r,
                memoryUndoId: i
            }), n.jsx(V, {
                onClick: () => {
                    c(!0), k.logEvent("Memory Update Popover Manage Button Clicked", {
                        updateCount: t.length
                    })
                },
                children: n.jsx(u, {
                    id: "MemoryActionResult.manageMemories",
                    defaultMessage: "Manage"
                })
            })]
        })]
    })
}

function Ne({
    clientThreadId: t,
    pendingMessage: e,
    memoryWrites: o,
    popoverState: s,
    setShowMemoriesModal: r,
    disableActions: i
}) {
    const c = ue(),
        d = ce(t),
        a = ge({
            clientThreadId: t
        }),
        l = o.join(" ");
    let f = l.slice(0, 50).replace(new RegExp("^\\p{L}", "u"), g => g.toLocaleUpperCase()).replace(/\.$/, "");
    l.length > 50 && (f += "...");
    const p = async g => {
        var M;
        if (!d) throw new Error("Failed to confirm or reject memory update: serverThreadId is not found");
        const x = (M = e.metadata) == null ? void 0 : M.pending_memory_info;
        q(t, h => {
            G.updateTree(h, m => {
                m.updateNodeMessageMetadata(e.id, {
                    pending_memory_info: R(E({}, x), {
                        is_pending: !1,
                        confirm_result: g
                    })
                })
            })
        });
        try {
            await P.safePost("/memories/confirm_or_reject", {
                requestBody: {
                    message_id: e.id,
                    conversation_id: d,
                    is_confirm: g
                },
                authOption: pe.SendIfAvailable
            })
        } catch (h) {
            c.danger(te({
                id: "memory.confirmOrDenyFail",
                defaultMessage: "Failed to confirm or reject memory update"
            }), {
                toastId: "memory_confirm_or_deny_fail"
            }), q(t, m => {
                G.updateTree(m, _ => {
                    _.updateNodeMessageMetadata(e.id, {
                        pending_memory_info: x
                    })
                })
            })
        }
    };
    return n.jsxs("div", {
        className: "flex items-start",
        children: [n.jsx("div", {
            className: "text-token-text-tertiary inline-block text-sm font-semibold outline-hidden",
            children: n.jsx(u, {
                id: "MemoryActionResult.memoryConfirmation",
                defaultMessage: "Update memory? {memoryText}",
                values: {
                    memoryText: n.jsx("div", {
                        className: "inline-block py-1",
                        onMouseOver: () => s.handleTogglePopover(!0),
                        onMouseOut: () => s.handleTogglePopover(!1),
                        children: n.jsx(Q, {
                            memoryWrites: o,
                            popoverState: s,
                            disableActions: i,
                            triggerButton: n.jsx("button", {
                                className: D("text-start font-normal", s.isPopoverOpen ? "text-token-text-secondary" : "text-token-text-tertiary"),
                                children: n.jsx(u, {
                                    id: "MemoryActionResult.memoryWrapper",
                                    defaultMessage: "“{memoryWrites}”",
                                    values: {
                                        memoryWrites: f
                                    }
                                })
                            }),
                            setShowMemoriesModal: r
                        })
                    })
                }
            })
        }), n.jsx(L, {
            className: "text-token-text-tertiary hover:text-token-text-primary ms-3",
            size: "small",
            color: "secondary",
            disabled: a,
            onClick: () => {
                p(!0)
            },
            children: n.jsx(u, {
                id: "MemoryActionResult.confirm",
                defaultMessage: "Yes"
            })
        }), n.jsx(L, {
            className: "text-token-text-tertiary hover:text-token-text-primary ms-2",
            size: "small",
            color: "secondary",
            disabled: a,
            onClick: () => {
                p(!1)
            },
            children: n.jsx(u, {
                id: "MemoryActionResult.deny",
                defaultMessage: "No"
            })
        })]
    })
}

function Ue({
    memoryWrites: t,
    popoverState: e,
    isParagen: o,
    memoryUndoId: s,
    gizmoId: r,
    setShowMemoriesModal: i,
    showTooltip: c,
    disableActions: d
}) {
    const a = xe(),
        {
            eligible: l,
            isLoading: f
        } = Me(T.hasSeenMemoryUpdatedTooltip),
        p = !S(me),
        [g, x] = y.useState(!1),
        M = C(),
        h = fe(M),
        m = h == null ? void 0 : h.hasPlusFeatures();
    return y.useEffect(() => {
        !f && l && a && c === !0 && !F ? (x(!0), F = !0) : !f && !l && x(!1)
    }, [c, f, l, a]), t.length === 0 ? null : n.jsxs("div", {
        className: "flex items-center",
        children: [n.jsx(be, {
            announcementKey: T.hasSeenMemoryUpdatedTooltip,
            show: g,
            onDismiss: () => {
                _e(M, T.hasSeenMemoryUpdatedTooltip), k.logEventWithStatsig("Memory Updated Tooltip Dismissed", "memory_updated_tooltip_dismissed")
            },
            dismissOnOutsideClick: !0,
            side: p ? "bottom" : "left",
            sideOffset: 4,
            theme: "bright",
            badge: "none",
            title: n.jsx(u, {
                id: "MoonshineV2Tooltip.heading",
                defaultMessage: "Memory in ChatGPT has changed"
            }),
            description: n.jsxs(n.Fragment, {
                children: [m ? n.jsx(u, {
                    id: "MoonshineV2Tooltip.description",
                    defaultMessage: "ChatGPT can now reference all chats, but you can still manage individual saved memories."
                }) : n.jsx(u, {
                    id: "MoonshineV2Tooltip.description.freeMoonshine",
                    defaultMessage: "ChatGPT can now reference recent chats, but you can still manage individual saved memories."
                }), n.jsx("br", {}), n.jsx("a", {
                    href: "https://help.openai.com/en/articles/10303002-how-does-memory-use-past-conversations",
                    target: "_blank",
                    rel: "noopener noreferrer",
                    className: "underline",
                    children: n.jsx(u, {
                        id: "MoonshineV2Tooltip.learnMoreLink",
                        defaultMessage: "Learn more"
                    })
                }, "learn-more-link")]
            }),
            children: n.jsx("div", {
                style: {
                    width: 1,
                    height: 1
                }
            })
        }), n.jsx("div", {
            className: "inline-block",
            onMouseOver: () => e.handleTogglePopover(!0),
            onMouseOut: () => e.handleTogglePopover(!1),
            children: n.jsx(Q, {
                memoryWrites: t,
                popoverState: e,
                isParagen: o,
                gizmoId: r,
                memoryUndoId: s,
                disableActions: d,
                triggerButton: n.jsxs("button", {
                    className: D("my-1 flex items-center gap-1 text-sm font-semibold outline-hidden", e.isPopoverOpen ? "text-token-text-secondary" : "text-token-text-tertiary"),
                    children: [n.jsx(Te, {
                        className: "mb-[-1px]"
                    }), t.length === 1 ? n.jsx(u, {
                        id: "MemoryActionResult.memoryWriteSingular.New",
                        defaultMessage: "Updated saved memory"
                    }) : n.jsx(u, {
                        id: "MemoryActionResult.memoryWritePlural.New",
                        defaultMessage: "Updated saved memories"
                    })]
                }),
                setShowMemoriesModal: i
            })
        })]
    })
}

function Ee(t) {
    var s, r;
    const e = z(t),
        o = (r = (s = e == null ? void 0 : e.metadata) == null ? void 0 : s.pending_memory_info) == null ? void 0 : r.confirm_result;
    return e == null ? null : o === !0 ? "confirmed" : o === !1 ? "denied" : "pending"
}

function Qe({
    messages: t,
    clientThreadId: e,
    gizmoResource: o,
    isParagen: s
}) {
    const r = o == null ? void 0 : o.gizmo.id,
        i = Ae(t),
        c = Oe(i),
        d = Ce(t),
        a = ke(t),
        l = C(),
        f = S(() => ne(l));
    we(i);
    const p = z(t),
        x = B(l, "3983984123").get("is_memory_undo_enabled", !1);
    se(l, "1900515849");
    const M = he(l),
        h = S(re(l, e)),
        m = y.useRef(!1),
        _ = W();
    y.useEffect(() => {
        d && m.current === !1 && (m.current = !0), !d && !p && a && m.current && _.invalidateQueries({
            queryKey: [A, r]
        })
    }, [d, p, a, r, _]);
    const {
        data: v
    } = Z({
        queryKey: [A, r],
        queryFn: () => K.getCurrentMemoryUndoId(r),
        enabled: x && !d && !p
    }), [w, j] = y.useState(!1), O = Ee(t);
    return O === "denied" ? null : n.jsxs(n.Fragment, {
        children: [O === "pending" ? n.jsx(Ne, {
            clientThreadId: e,
            memoryWrites: i,
            popoverState: c,
            setShowMemoriesModal: j,
            pendingMessage: p,
            disableActions: f
        }) : n.jsx(Ue, {
            memoryWrites: i,
            popoverState: c,
            isParagen: s,
            memoryUndoId: (v == null ? void 0 : v.current_memory_undo_id) === a ? a : void 0,
            setShowMemoriesModal: j,
            showTooltip: m.current && i.length > 0,
            disableActions: f
        }), w ? M ? n.jsx(Pe, {
            isOpen: w,
            initialGizmoId: r,
            contextScopes: h,
            onClose: () => j(!1)
        }) : n.jsx(Se, {
            initialGizmoId: r,
            contextScopes: h,
            onClose: () => j(!1)
        }) : null]
    })
}

function V({
    children: t,
    disabled: e,
    onClick: o
}) {
    return n.jsxs("button", {
        className: "hover:bg-token-main-surface-secondary flex w-full items-center justify-between rounded-sm px-3 py-2 font-semibold",
        disabled: e,
        onClick: o,
        children: [t, n.jsx(ve, {
            className: "icon text-token-text-tertiary -me-1"
        })]
    })
}

function Re({
    gizmoId: t,
    memoryUndoId: e
}) {
    const o = C(),
        r = B(o, "3983984123").get("is_memory_undo_enabled", !1),
        i = W(),
        {
            isPending: c,
            mutate: d
        } = oe({
            mutationFn: a => K.undoMemoryWrite(t, a),
            onSuccess: () => {
                i.invalidateQueries({
                    queryKey: [A, t]
                })
            }
        });
    return !r || !e ? null : n.jsx(V, {
        disabled: c,
        onClick: () => {
            e && d(e)
        },
        children: n.jsx(u, {
            id: "qeyS8G",
            defaultMessage: "Undo"
        })
    })
}

function Ie(t) {
    const e = ["The user ", "The user's ", "User ", "User's "];
    for (const o of e)
        if (t.startsWith(o)) return t.slice(o.length);
    return t
}
export {
    Qe as MemoryActionResult
};
//# sourceMappingURL=kfozsua9bqnntmw9.js.map