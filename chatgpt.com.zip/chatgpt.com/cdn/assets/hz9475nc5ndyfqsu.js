var w = Object.defineProperty,
    j = Object.defineProperties;
var k = Object.getOwnPropertyDescriptors;
var T = Object.getOwnPropertySymbols;
var D = Object.prototype.hasOwnProperty,
    C = Object.prototype.propertyIsEnumerable;
var S = (e, s, t) => s in e ? w(e, s, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : e[s] = t,
    P = (e, s) => {
        for (var t in s || (s = {})) D.call(s, t) && S(e, t, s[t]);
        if (T)
            for (var t of T(s)) C.call(s, t) && S(e, t, s[t]);
        return e
    },
    A = (e, s) => j(e, k(s));
var E = (e, s) => {
    var t = {};
    for (var a in e) D.call(e, a) && s.indexOf(a) < 0 && (t[a] = e[a]);
    if (e != null && T)
        for (var a of T(e)) s.indexOf(a) < 0 && C.call(e, a) && (t[a] = e[a]);
    return t
};
import {
    r as c,
    j as M,
    E as b
} from "./fg33krlcm0qyi6yw.js";
import {
    hn as F,
    ho as I,
    hp as U,
    hq as _,
    hr as R,
    hs as p,
    ht as q,
    aV as L,
    hu as V
} from "./k15yxxoybkkir2ou.js";
import {
    nm as H,
    kM as N,
    dQ as O,
    dF as Q,
    dH as X,
    fN as $
} from "./dykg4ktvbu3mhmdo.js";
import {
    T as B
} from "./ou2xm3xmri21t4zm.js";

function z(e) {
    var v;
    const x = e,
        {
            bufferType: s,
            isActivelyStreaming: t,
            messages: a,
            parts: n
        } = x,
        g = E(x, ["bufferType", "isActivelyStreaming", "messages", "parts"]),
        i = a[a.length - 1].id,
        l = c.useMemo(() => a.some(o => {
            var y;
            return (y = o.metadata) == null ? void 0 : y.mercury_message
        }), [a]),
        [m, d] = c.useState(F(n)),
        r = c.useRef(void 0),
        u = H(),
        {
            showPerformanceOverlay: h
        } = N();
    c.useEffect(() => {
        if (!(!h || s !== "Adaptive" || !t)) return I.setActiveStreamingMessageId(i), () => I.setActiveStreamingMessageId(null)
    }, [h, s, t, i]);
    const f = c.useMemo(() => u ? n.flatMap(o => {
        if (typeof o == "string") return o;
        if (o.content_type === "audio_transcription") return o.text
    }).filter(o => o !== void 0) : n, [n, u]);
    if (r.current === void 0) switch (s) {
        case "Adaptive":
            l ? r.current = new R(f, d, t, void 0, {
                minRate: .4,
                expectedDisplayInterval: .05,
                maxTokensPerStep: 7,
                messageId: i
            }) : r.current = new R(f, d, t, void 0, {
                messageId: i
            });
            break;
        case "ChunkedCatchup":
            r.current = new _(f, d, t);
            break;
        case "Punctuation":
            r.current = new U(f, d, t);
            break
    }
    return c.useEffect(() => {
        r.current != null && (r.current.onMessagePartsUpdated(f, t), r.current.isBuffering() && p.addDelayedRenderingMessage(i))
    }, [f, i, t]), c.useEffect(() => {
        r.current != null && r.current.removeDelayedRender() && p.removeDelayedRenderingMessage(i)
    }, [m, i]), c.useEffect(() => () => p.removeDelayedRenderingMessage(i), [i]), c.useEffect(() => () => {
        var o;
        (o = r.current) == null || o.destroy(), r.current = void 0
    }, []), M.jsx(B, A(P({}, g), {
        messages: a,
        parts: n,
        displayParts: m,
        isActivelyStreaming: t || !!((v = r.current) != null && v.isBuffering())
    }))
}

function G({
    message: e,
    isCompletionInProgress: s,
    hasActiveRequest: t,
    conversation: a,
    className: n,
    isUserTurn: g,
    isFinalUserTurn: i,
    isWithinFirstAssistantTurns: l,
    turnIndex: m,
    isFeedbackEnabled: d,
    prevGroupedMessageType: r,
    prevGroupedMessages: u,
    citableMessages: h,
    superWidgetContent: f
}) {
    var v, o, y;
    const x = c.useMemo(() => "parts" in e.content ? e.content.parts : [O(e)], [e]);
    return M.jsxs(M.Fragment, {
        children: [M.jsx(J, {
            parts: x,
            messages: [e],
            hasActiveRequest: t,
            isCompletionInProgress: s,
            className: n,
            citations: (v = e.metadata) == null ? void 0 : v.citations,
            contentReferences: (o = e.metadata) == null ? void 0 : o.content_references,
            attachments: (y = e.metadata) == null ? void 0 : y.attachments,
            isUserTurn: g,
            isFinalUserTurn: i,
            isWithinFirstAssistantTurns: l,
            turnIndex: m,
            id: e.id,
            isFeedbackEnabled: d,
            conversation: a,
            prevGroupedMessageType: r,
            prevGroupedMessages: u,
            citableMessages: h,
            superWidgetContent: f
        }), !1]
    })
}
const te = b.memo(G);

function J(e) {
    const s = e.messages.length > 1,
        t = Q.isLastActorMessage(X(e.conversation.id), e.messages[0].id),
        a = $(e.conversation.id, u => !!(u != null && u.sharedConversationMetadata)),
        n = s ? void 0 : q(e.messages[0], t, e.isCompletionInProgress || e.hasActiveRequest, a),
        g = (n == null ? void 0 : n.flagSeverity) !== "danger" && e.isCompletionInProgress,
        i = !e.parts.some(u => u !== ""),
        {
            bufferType: l,
            wordFadeType: m
        } = L(),
        [d, r] = c.useState(() => m !== "indexed" && l !== "none" && !e.isUserTurn && (e.isCompletionInProgress || i && !n));
    return n && d && r(!1), d ? M.jsx(z, A(P({}, e), {
        bufferType: l,
        isActivelyStreaming: g,
        errorState: n
    })) : M.jsx(B, A(P({}, e), {
        displayParts: V({
            isUserTurn: e.isUserTurn,
            parts: e.parts
        }),
        isActivelyStreaming: g,
        errorState: n
    }))
}
export {
    te as T, J as a
};
//# sourceMappingURL=hz9475nc5ndyfqsu.js.map