const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/k15yxxoybkkir2ou.js", "assets/fg33krlcm0qyi6yw.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/conversation-small-332fs9rk.css", "assets/k7bax4ffse9ora8u.js", "assets/jkejdo8v5ynnt9ff.js", "assets/k2oaaf8ac9lafsub.js", "assets/lans8a2ikbh9ax9r.js", "assets/v9p9lvhz45nq9ivc.js"]))) => i.map(i => d[i]);
var ce = Object.defineProperty,
    de = Object.defineProperties;
var ue = Object.getOwnPropertyDescriptors;
var G = Object.getOwnPropertySymbols;
var ge = Object.prototype.hasOwnProperty,
    pe = Object.prototype.propertyIsEnumerable;
var K = (s, n, t) => n in s ? ce(s, n, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : s[n] = t,
    E = (s, n) => {
        for (var t in n || (n = {})) ge.call(n, t) && K(s, t, n[t]);
        if (G)
            for (var t of G(n)) pe.call(n, t) && K(s, t, n[t]);
        return s
    },
    q = (s, n) => de(s, ue(n));
import {
    a as J,
    r as N,
    e as k,
    j as e,
    M as g,
    _ as O,
    m as me,
    i as A,
    c as he
} from "./fg33krlcm0qyi6yw.js";
import {
    w as P,
    p1 as $,
    ag as D,
    m as X,
    jW as fe,
    aK as W,
    g2 as o,
    g3 as xe,
    c0 as L,
    qj as B,
    gJ as je,
    nW as Me,
    ab as Se,
    r0 as ve,
    b as S,
    r1 as Ie,
    sE as _,
    bh as T,
    c_ as F,
    gK as ke,
    P as f,
    dz as Y,
    dg as Z,
    H as be,
    i6 as Ce,
    hh as _e,
    id as ye,
    af as ee,
    dB as We,
    cU as w,
    bc as Pe,
    bd as we,
    y as Ee,
    aL as Ne,
    io as Le,
    T as Oe,
    hv as Ae,
    es as De,
    du as Be,
    b3 as Te,
    gk as Fe,
    ad as Q
} from "./dykg4ktvbu3mhmdo.js";
import {
    go as Ue,
    gp as Re,
    az as U,
    gq as ze,
    gr as se,
    gs as He,
    gt as Ge,
    gu as Ke,
    N as qe,
    gv as Qe,
    gw as Ve,
    cg as te,
    dG as Je,
    gx as b,
    dP as $e,
    gy as Xe,
    gz as Ye,
    dQ as Ze,
    gA as es,
    ao as ss,
    cV as ne,
    gB as ts,
    eN as ae,
    gC as ns,
    gD as as,
    gE as oe,
    gF as os,
    gG as is,
    gH as rs,
    gI as ls,
    gJ as cs,
    gK as ds,
    gL as us,
    gM as gs,
    c6 as y,
    gN as ps
} from "./k15yxxoybkkir2ou.js";
import {
    c as ie,
    b as ms,
    f as hs
} from "./k2oaaf8ac9lafsub.js";

function fs({
    currentAccount: s
}) {
    return e.jsx(re, {
        workspace: s,
        isLoading: !1,
        currentWorkspaceId: s.id,
        showCheck: !1
    })
}

function xs({
    accountSwitcherRedirectUrl: s
}) {
    const n = S(),
        t = J(),
        {
            data: r
        } = P(),
        a = $(r),
        [l, i] = N.useState(!1),
        c = D(),
        d = k(),
        p = X();
    if (!a || !r) return null;
    const h = a.isWorkspaceAccount(),
        x = r.accountItems.length > 1,
        v = r.accountItems,
        I = fe([v.find(u => u.isPersonalAccount()), ...v.filter(u => !u.isPersonalAccount())]);
    return I.sort((u, m) => u.isPersonalAccount() ? 1 : m.isPersonalAccount() ? -1 : 0), x ? I.map(u => {
        const m = u.isDeactivated(),
            M = () => {
                if (m || u.id === (a == null ? void 0 : a.id)) return;
                i(!0);
                const {
                    willRedirect: j
                } = ve(t, u.id, n, d, p);
                j || Ie(s)
            };
        return u.isDeactivated() ? e.jsx(js, {
            workspace: u,
            isLoading: l
        }, u.id) : e.jsx(re, {
            workspace: u,
            isLoading: l,
            currentWorkspaceId: a == null ? void 0 : a.id,
            onSelect: M
        }, u.id)
    }) : h ? e.jsx(fs, {
        currentAccount: a
    }) : (c == null ? void 0 : c.email) && e.jsx("div", {
        className: "text-token-text-secondary ms-3 me-2 py-2 text-sm",
        children: c.email
    })
}

function re({
    workspace: s,
    isLoading: n,
    currentWorkspaceId: t,
    showCheck: r = !0,
    onSelect: a
}) {
    const l = k(),
        i = s.canAccessWithCurrentSession,
        c = !n && r && s.id === t,
        p = s.data.ekmConfig != null ? e.jsxs("div", {
            className: "relative",
            children: [e.jsx(_, {
                iconSize: "small",
                workspace: s
            }), e.jsx("div", {
                className: "border-token-border-default absolute end-0 bottom-0 flex h-[12px] w-[12px] items-center justify-center rounded-full border bg-white text-black shadow-xs",
                children: e.jsx(U, {
                    className: "h-2 w-2",
                    "aria-hidden": "true"
                })
            })]
        }) : e.jsx(_, {
            iconSize: "small",
            workspace: s
        });
    return e.jsxs(o.RadioItem, {
        value: s.id,
        onSelect: a,
        icon: p,
        secondary: !i && (s.ssoConnectionName ? e.jsx(g, {
            id: "CV7pdM",
            defaultMessage: "Authenticate with SSO to access this workspace"
        }) : e.jsx(g, {
            id: "zfCWFh",
            defaultMessage: "Authenticate without SSO to access this workspace"
        })),
        trailingColor: c ? "primary" : "tertiary",
        trailing: c ? e.jsx(Se, {
            className: "icon-sm"
        }) : i ? null : Me,
        children: [e.jsx("div", {
            className: "line-clamp-1",
            children: ie(l, s)
        }), n && e.jsx(L, {})]
    })
}

function js({
    workspace: s,
    isLoading: n
}) {
    const t = k(),
        r = s.isOwnerOfAccount(),
        [a, l] = N.useState(!1),
        {
            count: i
        } = Ue(s.id),
        c = Re(),
        d = s.mustGetSubscriptionBillingCurrency("DeactivatedWorkspaceMenuItem");
    return N.useEffect(() => {
        i != null && a && (W.setPurchaseWorkspaceData({
            minimumSeats: Math.max(i, c),
            billingDetails: {
                currency: d
            },
            existingAccount: s
        }), l(!1))
    }, [i, a, s, c, d]), e.jsxs(o.Item, {
        disabled: !0,
        icon: U,
        trailing: !n && e.jsxs(o.Root, {
            children: [e.jsx(o.BasicTrigger, {
                asChild: !0,
                children: e.jsx(B, {
                    "aria-label": t.formatMessage({
                        id: "1Fk+46",
                        defaultMessage: "Workspace options"
                    }),
                    icon: je
                })
            }), e.jsx(o.Portal, {
                children: e.jsxs(o.Content, {
                    alignOffset: 2,
                    sideOffset: -2,
                    size: "auto",
                    align: "end",
                    children: [r && e.jsx(e.Fragment, {
                        children: e.jsx(o.Item, {
                            onClick: () => {
                                i == null ? l(!0) : W.setPurchaseWorkspaceData({
                                    minimumSeats: Math.max(i, c),
                                    billingDetails: {
                                        currency: d
                                    },
                                    existingAccount: s
                                })
                            },
                            children: a ? e.jsx(L, {}) : e.jsx(g, {
                                id: "navigation.reactivateWorkspace",
                                defaultMessage: "Reactivate workspace"
                            })
                        })
                    }), e.jsx(o.Item, {
                        color: "danger",
                        onClick: () => {
                            W.setLeaveWorkspaceData(s)
                        },
                        children: e.jsx(g, {
                            id: "navigation.leaveWorkspace",
                            defaultMessage: "Leave workspace"
                        })
                    })]
                })
            })]
        }),
        children: [e.jsx("div", {
            className: "line-clamp-1",
            children: ie(t, s)
        }), e.jsx(xe, {
            children: e.jsx(g, {
                id: "navigation.deactivedWorkspacePill",
                defaultMessage: "Deactivated"
            })
        }), n && e.jsx(L, {})]
    })
}

function Ms(s) {
    var t;
    return !(s != null && s.isWorkspaceAccount()) || s.isQuorum() ? !1 : !((s == null ? void 0 : s.isEdu()) && !((t = s.isK12) != null && t.call(s)) && (s == null ? void 0 : s.isStandardUserOfAccount()))
}
const Gs = ({
    clientThreadId: s
}) => {
    const n = k();
    return F() ? null : e.jsx(ke, {
        contentAlign: "end",
        sideOffset: 4,
        triggerButton: e.jsx("button", {
            onClick: () => {
                f.logEventWithStatsig("Account: Open Profile Menu", "chatgpt_account_open_profile_menu", {
                    location: "header"
                })
            },
            "aria-label": n.formatMessage({
                id: "profileMenu.open",
                defaultMessage: "Open profile menu"
            }),
            "data-testid": "profile-button",
            className: "group user-select-none ps-2 focus:outline-0",
            children: e.jsx("div", {
                className: "group-hover:bg-token-interactive-bg-secondary-selected touch:h-10 touch:w-10 group-keyboard-focused:focus-ring flex h-9 w-9 items-center justify-center rounded-full",
                children: e.jsx(vs, {})
            })
        }),
        children: e.jsx(le, {
            clientThreadId: s
        })
    })
};

function Ks() {
    const s = b();
    return e.jsxs(o.Root, {
        onOpenChange: n => {
            n && f.logEventWithStatsig("Account: Open Profile Menu", "chatgpt_account_open_profile_menu", {
                location: s
            })
        },
        children: [e.jsx(Ss, {
            isTinyBar: s === "tiny_bar"
        }), e.jsx(o.Portal, {
            children: e.jsx(o.Content, {
                side: "top",
                size: "auto",
                className: "min-w-[calc(var(--sidebar-width)-12px)]",
                children: e.jsx(le, {})
            })
        })]
    })
}

function Ss({
    isTinyBar: s
}) {
    var C;
    const {
        data: n
    } = P(), t = $(n), r = ms(), a = hs(), l = k(), {
        enableProfileUpgradePill: i
    } = oe(), c = t == null ? void 0 : t.isSelfServeBusiness(), d = (C = t == null ? void 0 : t.isFreeWorkspace()) != null ? C : !1, h = i && !(!!c || d), x = A();
    if (!t || !n) return null;
    const v = t != null && t.isWorkspaceAccount(),
        I = n != null && n.accountItems.length > 1;
    let u;
    v || I ? u = r : t != null && t.isFree() ? u = l.formatMessage(y.free) : t != null && t.isPlus() ? u = l.formatMessage(y.plus) : t != null && t.isGo() ? u = l.formatMessage(y.go) : t != null && t.isPro() && (u = l.formatMessage(y.pro));
    const m = l.formatMessage({
            id: "profileMenu.open",
            defaultMessage: "Open profile menu"
        }),
        j = (t == null ? void 0 : t.data.ekmConfig) != null ? e.jsxs("div", {
            className: "relative",
            children: [e.jsx(_, {}), e.jsx("div", {
                className: "border-token-border-default absolute end-0 bottom-0 flex h-[12px] w-[12px] items-center justify-center rounded-full border bg-white text-black shadow-xs",
                children: e.jsx(U, {
                    className: "h-2 w-2",
                    "aria-hidden": "true"
                })
            })]
        }) : e.jsx(_, {});
    return e.jsx(o.BasicTrigger, {
        asChild: !0,
        children: e.jsx(ps, {
            "data-testid": "accounts-profile-button",
            "aria-label": m,
            size: "large",
            icon: j,
            iconOnly: s,
            label: a,
            role: "button",
            trailing: !s && h ? e.jsx(e.Fragment, {
                children: e.jsx(B, {
                    onClick: () => {
                        ne(x, "sidebar profile")
                    },
                    "aria-label": l.formatMessage(Q.upgrade),
                    className: "-my-1.5 -ms-2 -me-2.5 cursor-default py-1.5 ps-2 pe-2.5",
                    children: e.jsx("span", {
                        className: "btn-secondary btn btn-small my-0 me-0 cursor-default hover:cursor-pointer",
                        children: e.jsx(g, E({}, Q.upgrade))
                    })
                })
            }) : void 0,
            secondary: u && e.jsxs("span", {
                className: "text-token-text-secondary inline-flex items-center gap-1 truncate text-xs font-normal",
                dir: "auto",
                children: [e.jsx("span", {
                    children: u
                }), !!(t != null && t.data.isFedrampCompliantWorkspace) && e.jsx(g, {
                    id: "profile.fedramp_badge",
                    defaultMessage: "• FedRAMP"
                })]
            })
        })
    })
}
const le = ({
        clientThreadId: s
    }) => {
        const n = S(),
            t = F(),
            r = Y(),
            a = Z(),
            l = r && !a,
            i = ze(n);
        return e.jsxs("div", {
            className: "flex flex-col",
            children: [t ? e.jsx(Is, {}) : e.jsx(Ds, {}), e.jsx(Ps, {}), e.jsx(o.Separator, {}), !t && e.jsx(Ts, {
                clientThreadId: s
            }), t ? e.jsx(ys, {}) : e.jsx(se, {}), t && !l && e.jsx(Es, {}), (i || !1) && e.jsx(o.Separator, {}), i && e.jsx(He, {}), !1]
        })
    },
    vs = () => F() ? e.jsx(_, {
        showPlanTypeBadge: !0
    }) : e.jsx(Ge, {
        className: "icon-lg"
    }),
    Is = () => {
        const s = S(),
            n = be(),
            {
                data: t
            } = P(),
            r = t && t.accountItems.length > 1,
            a = Y(),
            l = Z(),
            i = r && (!a || l),
            c = Ms(n),
            d = Ke(s),
            p = me(),
            h = p.pathname + p.search + (p.search ? "&" : "?") + "refresh_account=true",
            x = qe(s);
        return e.jsxs(e.Fragment, {
            children: [x.hasAccess ? e.jsxs(e.Fragment, {
                children: [e.jsx(Qe, {
                    currentAccount: n
                }), e.jsx(o.Separator, {})]
            }) : e.jsx(bs, {
                currentAccount: n
            }), i && e.jsxs(e.Fragment, {
                children: [e.jsx(xs, {
                    accountSwitcherRedirectUrl: h
                }), e.jsx(V, {
                    shouldShowPlusIcon: c
                }), e.jsx(o.Separator, {})]
            }), !i && e.jsx(V, {
                shouldShowPlusIcon: c
            }), e.jsx(As, {
                currentAccount: n
            }), e.jsx(Bs, {}), c && e.jsx(Cs, {}), e.jsx(ks, {
                currentAccount: n
            }), !1, d && e.jsx(Ve, {}), e.jsx(Ws, {})]
        })
    },
    ks = s => {
        "use forget";
        var C, R, z, H;
        const n = he.c(8),
            {
                currentAccount: t
            } = s,
            r = S(),
            a = (C = t == null ? void 0 : t.isWorkspaceAccount()) != null ? C : !1,
            l = t == null ? void 0 : t.id,
            {
                data: i,
                isLoading: c
            } = Be(a ? l : void 0),
            d = !!((R = i == null ? void 0 : i.beta_settings) != null && R.workspace_policy),
            p = d ? l : void 0;
        let h;
        n[0] !== d || n[1] !== p ? (h = {
            workspaceId: p,
            enabled: d
        }, n[0] = d, n[1] = p, n[2] = h) : h = n[2];
        const {
            data: x,
            isLoading: v
        } = is(h), I = (H = (z = x == null ? void 0 : x.workspace_policy) == null ? void 0 : z.trim()) != null ? H : "";
        if (!a || !d || (c || v) || !I) return null;
        let m;
        n[3] !== r ? (m = () => {
            w(r, gs)
        }, n[3] = r, n[4] = m) : m = n[4];
        let M;
        n[5] === Symbol.for("react.memo_cache_sentinel") ? (M = e.jsx(g, {
            id: "p8SaJb",
            defaultMessage: "AI Policy"
        }), n[5] = M) : M = n[5];
        let j;
        return n[6] !== m ? (j = e.jsx(o.Item, {
            icon: Fe,
            onSelect: m,
            children: M
        }), n[6] = m, n[7] = j) : j = n[7], j
    };

function bs({
    currentAccount: s
}) {
    var c;
    const n = k(),
        t = D(),
        r = A(),
        a = X();
    if (!t) return null;
    const l = s && s.isWorkspaceAccount() && !s.isEnterprisey(),
        i = n.formatMessage({
            id: "navigation.addWorkspaceTooltip",
            defaultMessage: "Create a Business workspace"
        });
    return e.jsx(Le, {
        as: "div",
        onClick: async d => {
            await Ae(t.id, a, d), a.success("Copied your User ID to clipboard")
        },
        icon: es,
        className: "text-token-text-tertiary bg-transparent!",
        trailing: l && e.jsx(Oe, {
            label: i,
            className: "leading-0",
            side: "right",
            children: e.jsx(B, {
                onClick: () => {
                    ne(r, "profile menu")
                },
                "aria-label": i,
                children: e.jsx(ss, {
                    className: "icon-sm"
                })
            })
        }),
        label: (c = t.email) != null ? c : t.name
    })
}
const Cs = () => {
        const s = b();
        return e.jsx(o.LinkItem, {
            to: "/admin",
            icon: ae,
            onClick: () => {
                f.logEventWithStatsig("Account: Open Workspace Settings", "chatgpt_account_open_workspace_settings", {
                    location: s
                })
            },
            children: e.jsx(g, {
                id: "workspacePopoverNavigation.myWorkspaceSettings",
                defaultMessage: "Workspace settings"
            })
        })
    },
    _s = () => e.jsx(o.LinkItem, {
        icon: cs,
        external: !0,
        to: "https://openai.com/chatgpt/download",
        children: e.jsx(g, {
            id: "mDFGM/",
            defaultMessage: "Download apps"
        })
    }),
    ys = () => {
        const s = b();
        return e.jsxs(o.Sub, {
            onOpenChange: n => {
                n && (f.logEventWithStatsig("Account: Open Help Menu", "chatgpt_account_help_menu_open", {
                    location: s
                }), Pe.count(we.DEFAULT, "chatgpt_account_help_menu_open", {
                    location: s
                }))
            },
            children: [e.jsx(o.SubMenuTrigger, {
                icon: Xe,
                children: e.jsx(g, {
                    defaultMessage: "Help",
                    id: "navigation.helpMenu"
                })
            }), e.jsx(o.Portal, {
                children: e.jsxs(o.SubContent, {
                    align: "end",
                    children: [e.jsx(se, {}), e.jsx(Ye, {}), e.jsx(_s, {}), e.jsx(ws, {})]
                })
            })]
        })
    },
    Ws = () => {
        const s = b(),
            n = A(),
            t = J();
        return e.jsx(o.Item, {
            onClick: () => {
                n("#settings/".concat(Te.Personalization)), f.logEventWithStatsig("Account: Click Customize ChatGPT", "chatgpt_account_open_customize_chatgpt", {
                    location: s
                })
            },
            icon: rs,
            onMouseOver: () => {
                t.prefetchQuery(ls())
            },
            children: e.jsx(g, {
                id: "S0v338",
                defaultMessage: "Personalization"
            })
        })
    },
    Ps = () => {
        const {
            openSettings: s
        } = Je(), n = b();
        return e.jsx(o.Item, {
            icon: Ce,
            onClick: () => {
                f.logEventWithStatsig("Account: Click Settings", "chatgpt_account_open_settings", {
                    location: n
                }), s()
            },
            "data-testid": "settings-menu-item",
            children: e.jsx(g, {
                defaultMessage: "Settings",
                id: "navigation.settings.0"
            })
        })
    },
    ws = () => e.jsx(o.Item, {
        className: "touch:hidden",
        icon: ds,
        onSelect: () => {
            us.set(!0)
        },
        children: e.jsx(g, {
            id: "thread.keyboardShortcutsMenu",
            defaultMessage: "Keyboard shortcuts"
        })
    }),
    Es = () => e.jsx(o.Item, {
        onSelect: () => {
            f.logEvent("Account: Click Log Out", {
                eventSource: "mouse"
            }), f.logLogOutButtonClicked({
                location: "profile_drop_down"
            }, Ee.ACCESS_LOGOUT_ACTION_LOCATION_PROFILE_DROP_DOWN), W.openModal(Ne.LogoutConfirm)
        },
        "data-testid": "log-out-menu-item",
        icon: Ze,
        children: e.jsx(g, {
            defaultMessage: "Log out",
            id: "navigation.logOut.0"
        })
    }),
    Ns = T(() => O(() =>
        import ("./k15yxxoybkkir2ou.js").then(s => s.Fa), __vite__mapDeps([0, 1, 2, 3, 4])).then(s => s.AdminInviteModal)),
    Ls = T(() => O(() =>
        import ("./k7bax4ffse9ora8u.js"), __vite__mapDeps([5, 1, 0, 2, 3, 4, 6, 7, 8])).then(s => s.default)),
    Os = T(() => O(() =>
        import ("./v9p9lvhz45nq9ivc.js"), __vite__mapDeps([9, 1, 2, 3, 0, 4])).then(s => s.ThreadReportConversationModal)),
    As = ({
        currentAccount: s
    }) => {
        var c, d, p;
        const n = S(),
            t = (c = s == null ? void 0 : s.canInviteMembers()) != null ? c : !1,
            r = (d = s == null ? void 0 : s.isSelfServeBusiness()) != null ? d : !1,
            a = (p = s == null ? void 0 : s.isK12()) != null ? p : !1,
            l = s == null ? void 0 : s.isFreeWorkspace(),
            i = r || a && t || l;
        return !s || !i ? null : e.jsx(o.Item, {
            "data-testid": "settings-menu-item-invite-teammates",
            onSelect: () => {
                f.logEvent("Account: Invite Member Button Clicked", {
                    eventSource: "mouse",
                    location: "profile_drop_down"
                }), De(n, "chatgpt_invite_users_to_workspace", 0, {
                    action: "OpenAdminInviteModal",
                    location: "dropdown-menu-click",
                    text: "AddTeammates",
                    step: "OpenModal"
                }), w(n, Ns, {
                    workspace: s
                })
            },
            icon: ns,
            children: e.jsx(g, {
                id: "inviteMemberButton.inviteMemberButton",
                defaultMessage: "Add teammates"
            })
        })
    },
    Ds = () => e.jsx(o.LinkItem, {
        icon: te,
        external: !0,
        to: "https://openai.com/chatgpt/pricing/",
        children: e.jsx(g, {
            id: "J1y7uV",
            defaultMessage: "See plans and pricing"
        })
    }),
    Bs = () => {
        const {
            showUpgradePlan: s,
            onUpgradeClick: n
        } = as("chatgpt_upgrade_in_settings_menu_clicked", "Upgrade In Settings Menu Clicked"), {
            enableUpgradeMenuSparkleIcon: t
        } = oe();
        return s ? e.jsx(o.Item, {
            icon: t ? e.jsx(os, {
                className: "icon-sm"
            }) : te,
            onSelect: () => n("Upper right settings menu"),
            children: e.jsx(g, {
                id: "navigation.upgradePlan",
                defaultMessage: "Upgrade plan"
            })
        }) : null
    },
    V = ({
        shouldShowPlusIcon: s
    }) => {
        const n = S(),
            t = b(),
            r = D(),
            {
                data: a
            } = P(),
            l = !!(a != null && a.accountItems.some(d => d.isEnterprisey())),
            i = (r == null ? void 0 : r.email_domain_type) === "professional";
        return !i || l || !(i && !l && ee(n).getLayer("3217430380").get("enable_workspace_discovery", !1)) ? null : e.jsx(o.Item, {
            onSelect: () => {
                f.logEventWithStatsig("Account: Open Workspace Discovery", "chatgpt_workspace_discovery_modal_shown", {
                    location: t
                }), w(n, Ls, {
                    mode: "dismissible",
                    section: "discoverable",
                    source: "find_workspaces"
                })
            },
            icon: s ? ts : ae,
            children: e.jsx(g, {
                defaultMessage: "Find workspaces",
                id: "navigation.findWorkspaces"
            })
        })
    },
    Ts = ({
        clientThreadId: s
    }) => {
        const n = S(),
            t = _e(s),
            r = ye();
        if (s && ee(n).checkGate("3376455464") && (t || r)) {
            const a = We(n, s);
            return e.jsx(o.Item, {
                icon: $e,
                onClick: () => w(n, Os, q(E({
                    clientThreadId: s
                }, r && (a != null && a.sharedConversationId) ? {
                    serverThreadId: a.sharedConversationId,
                    isSharedConversation: !0
                } : {}), {
                    isStaticSharedThread: !1
                })),
                children: e.jsx(g, {
                    id: "profileMenu.reportConversation",
                    defaultMessage: "Report conversation"
                })
            })
        }
        return null
    };
export {
    xs as A, bs as L, Gs as P, Ks as S
};
//# sourceMappingURL=jlu292yvnhcpthaw.js.map