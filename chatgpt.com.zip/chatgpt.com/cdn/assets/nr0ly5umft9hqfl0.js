const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/h3o82a1wehrfi3uz.js", "assets/fg33krlcm0qyi6yw.js", "assets/mq7uqtztbvim4zqv.js", "assets/me6bvgef3wcsdcxu.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css"]))) => i.map(i => d[i]);
var d = Object.defineProperty;
var e = Object.getOwnPropertySymbols;
var I = Object.prototype.hasOwnProperty,
    _ = Object.prototype.propertyIsEnumerable;
var r = (n, a, t) => a in n ? d(n, a, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : n[a] = t,
    i = (n, a) => {
        for (var t in a || (a = {})) I.call(a, t) && r(n, t, a[t]);
        if (e)
            for (var t of e(a)) _.call(a, t) && r(n, t, a[t]);
        return n
    };
import {
    _ as f,
    j as s
} from "./fg33krlcm0qyi6yw.js";
import {
    bh as u
} from "./dykg4ktvbu3mhmdo.js";
import {
    E as x
} from "./k15yxxoybkkir2ou.js";
const A = x(() => f(() =>
    import ("./h3o82a1wehrfi3uz.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5])).then(n => n.AnimatedIconImpl));

function P({
    animationLoader: n,
    StaticIcon: a,
    staticFrameIndex: t
}) {
    const m = ({
        className: o
    }) => s.jsx(a, {
        className: o
    });
    return u(async () => {
        const [o, c] = await Promise.all([n(), A()]), p = i({}, o);
        return l => s.jsx(c, i({
            animationData: p,
            StaticIcon: a,
            staticFrameIndex: t
        }, l))
    }, {
        loading: m,
        fallback: m
    })
}
export {
    P as c
};
//# sourceMappingURL=nr0ly5umft9hqfl0.js.map