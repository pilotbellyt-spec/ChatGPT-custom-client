import {
    c as t,
    jx as e,
    s
} from "./dykg4ktvbu3mhmdo.js";
const o = t(e, "8d88fc", 24, 24),
    r = t(s, "665fb5", 20, 20);
export {
    r as A, o as E
};
//# sourceMappingURL=gzhsdx8lam3386fv.js.map