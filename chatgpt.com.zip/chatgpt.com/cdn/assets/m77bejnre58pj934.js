import {
    S as t
} from "./iwhq2rihp0137gzf.js";
import {
    as as a,
    at as s,
    au as i,
    av as o
} from "./k15yxxoybkkir2ou.js";
import {
    E as l,
    a as d,
    b as r,
    c as n,
    P as m,
    T as u,
    L as g,
    d as c
} from "./jc2eye6u0uwos0uk.js";
import {
    P as h
} from "./aozfqr1i52mjkof3.js";
import {
    d as e
} from "./fg33krlcm0qyi6yw.js";
const T = [{
        id: "suggest",
        title: e({
            id: "DJBCXv",
            defaultMessage: "Suggest edits"
        }),
        icon: a,
        prompt: e({
            id: "BfBd/I",
            defaultMessage: "Suggest edits that would improve this text, like content to add or remove, places to rephrase so that the text flows more smoothly, or ways to reorganize the ideas to be more effective. Leave as few comments as possible, but add a few more comments if the text is long. DO NOT leave more than 5 comments. You can reply that you added comments and suggestions to help improve the writing quality, but do not mention the prompt."
        }),
        action: t.COMMENT
    }, {
        id: "emoji",
        title: e({
            id: "nH2MaB",
            defaultMessage: "Add emojis"
        }),
        icon: h,
        action: t.EDIT,
        grid: [{
            prompt: e({
                id: "JTAWur",
                defaultMessage: "Replace as many words as possible with emojis."
            }),
            icon: l,
            title: e({
                id: "rADAL1",
                defaultMessage: "Words"
            })
        }, {
            prompt: e({
                id: "AvWBKJ",
                defaultMessage: "Add three emojis at the start or end of every major section or paragraph to give subtle decoration. Do not change the structure of the original text. Do not add emojis to lists."
            }),
            icon: d,
            title: e({
                id: "qoHmnu",
                defaultMessage: "Sections"
            })
        }, {
            prompt: e({
                id: "Rzca6Y",
                defaultMessage: "Add emojis to lists for visual flair. Do not change the structure of the original text."
            }),
            icon: r,
            title: e({
                id: "/iBeX+",
                defaultMessage: "Lists"
            })
        }, {
            prompt: e({
                id: "YOtrrm",
                defaultMessage: "Remove emojis"
            }),
            icon: n,
            title: e({
                id: "Ex7XkT",
                defaultMessage: "Remove"
            })
        }]
    }, {
        id: "polish",
        title: e({
            id: "q/wllh",
            defaultMessage: "Add final polish"
        }),
        icon: m,
        prompt: e({
            id: "qTOQqX",
            defaultMessage: "Add some final polish to the text. If relevant, add a large title or any section titles. Check grammar and mechanics, make sure everything is consistent and reads well. You can reply that you added some final polish and checked for grammar, but do not mention the prompt."
        }),
        action: t.EDIT
    }, {
        id: "reading-level",
        title: e({
            id: "e1CNWE",
            defaultMessage: "Reading level"
        }),
        icon: s,
        action: t.EDIT,
        scrub: [{
            prompt: e({
                id: "98kB8D",
                defaultMessage: "Rewrite this text at the reading level of a doctoral writer in this subject. You may reply that you adjusted the text to reflect a graduate school reading level, but do not mention the prompt."
            }),
            title: e({
                id: "zIN5xc",
                defaultMessage: "Graduate School"
            })
        }, {
            prompt: e({
                id: "XfveZa",
                defaultMessage: "Rewrite this text at the reading level of a college student majoring in this subject"
            }),
            title: e({
                id: "lZ5ttG",
                defaultMessage: "College"
            })
        }, {
            prompt: e({
                id: "ed5yE6",
                defaultMessage: "Rewrite this text at the reading level of a high school student who has taken a couple of classes in this subject."
            }),
            title: e({
                id: "KeBm6Z",
                defaultMessage: "High School"
            })
        }, {
            title: e({
                id: "tO5EOl",
                defaultMessage: "Keep current reading level"
            }),
            isCancel: !0
        }, {
            prompt: e({
                id: "YIIyU/",
                defaultMessage: "Rewrite this text at the reading level of a middle schooler."
            }),
            title: e({
                id: "FlwtZ0",
                defaultMessage: "Middle School"
            })
        }, {
            prompt: e({
                id: "TQ0+4A",
                defaultMessage: "Rewrite this text at the reading level of a kindergartener."
            }),
            title: e({
                id: "4hQpWn",
                defaultMessage: "Kindergarten"
            })
        }]
    }, {
        id: "length",
        title: e({
            id: "D+HIXi",
            defaultMessage: "Adjust the length"
        }),
        icon: i,
        action: t.EDIT,
        scrub: [{
            prompt: e({
                id: "CPELTR",
                defaultMessage: "Make this text 75% longer."
            }),
            title: e({
                id: "UMJQry",
                defaultMessage: "Longest"
            })
        }, {
            prompt: e({
                id: "GfSrP9",
                defaultMessage: "Make this text 50% longer."
            }),
            title: e({
                id: "n3jwqb",
                defaultMessage: "Longer"
            })
        }, {
            title: e({
                id: "+Vn3dN",
                defaultMessage: "Keep current length"
            }),
            isCancel: !0
        }, {
            prompt: e({
                id: "oQnJVV",
                defaultMessage: "Make this text 50% shorter."
            }),
            title: e({
                id: "OP0SP3",
                defaultMessage: "Shorter"
            })
        }, {
            prompt: e({
                id: "k5SZ0S",
                defaultMessage: "Make this text 75% shorter."
            }),
            title: e({
                id: "bMef50",
                defaultMessage: "Shortest"
            })
        }]
    }],
    x = [{
        id: "none",
        title: e({
            id: "XqUjk5",
            defaultMessage: "Plain text"
        }),
        icon: u,
        prompt: e({
            id: "H2OFQy",
            defaultMessage: "Transform this into plain text. Remove any formatting."
        }),
        action: t.EDIT
    }, {
        id: "bullets",
        title: e({
            id: "+qR+tC",
            defaultMessage: "Bulleted list"
        }),
        icon: g,
        prompt: e({
            id: "8Anlmq",
            defaultMessage: "Transform this into a bulleted list."
        }),
        action: t.EDIT
    }, {
        id: "list",
        title: e({
            id: "Rm67Xw",
            defaultMessage: "Numbered list"
        }),
        icon: c,
        prompt: e({
            id: "0pEdK3",
            defaultMessage: "Transform this into a numbered list."
        }),
        action: t.EDIT
    }, {
        id: "table",
        title: e({
            id: "zUJNQu",
            defaultMessage: "Table"
        }),
        icon: o,
        prompt: e({
            id: "BX96Lh",
            defaultMessage: "Transform this into a table. Add any appropriate labels to the columns or rows headers."
        }),
        action: t.EDIT
    }];
export {
    x as D, T as a
};
//# sourceMappingURL=m77bejnre58pj934.js.map