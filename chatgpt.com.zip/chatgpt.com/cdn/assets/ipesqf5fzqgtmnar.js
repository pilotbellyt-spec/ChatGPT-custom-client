const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/fx752hlrp1ihkvln.js", "assets/fg33krlcm0qyi6yw.js", "assets/nru7ghjfumsslhdj.js", "assets/jwm2780gzkkhdmn4.js", "assets/k15yxxoybkkir2ou.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/conversation-small-332fs9rk.css", "assets/ia54sddtrl9qa2wj.js", "assets/bdob0mmccomv88dh.js", "assets/cdnrxzg58mayu5uf.js", "assets/gmop4abenl57iboh.js", "assets/jhvz2qkf3st8xisu.js", "assets/lts8z3c38wfynrxz.js", "assets/ccj0kc5w6drbfrlh.js", "assets/ef7gr7kimbtxrws9.js", "assets/nr0ly5umft9hqfl0.js", "assets/gjyisy9q1t8rz8p4.js", "assets/lqog7ixiwnif6sbp.js", "assets/nzl91iujqafxz8y1.js", "assets/ebc4iyfg14nu1gw4.js", "assets/gy1lpvuoewmzh42c.js", "assets/jed1ux7qibe55pmj.js", "assets/h1em0bjkpkjv8ykw.js", "assets/nfccle6oyncifphl.js", "assets/hu1bt0oauegdhua6.js", "assets/b5s349mvbdzayaxi.js", "assets/dbshkzvpochy4889.js", "assets/zdzro29lk5w2w085.js"]))) => i.map(i => d[i]);
var at = Object.defineProperty,
    nt = Object.defineProperties;
var it = Object.getOwnPropertyDescriptors;
var Te = Object.getOwnPropertySymbols;
var rt = Object.prototype.hasOwnProperty,
    lt = Object.prototype.propertyIsEnumerable;
var Re = (t, e, s) => e in t ? at(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : t[e] = s,
    k = (t, e) => {
        for (var s in e || (e = {})) rt.call(e, s) && Re(t, s, e[s]);
        if (Te)
            for (var s of Te(e)) lt.call(e, s) && Re(t, s, e[s]);
        return t
    },
    E = (t, e) => nt(t, it(e));
import {
    _ as ot,
    u as Ve,
    c as je,
    e as X,
    r as S,
    j as a,
    v as Ge,
    i as We,
    M as Ue
} from "./fg33krlcm0qyi6yw.js";
import {
    p as ct,
    m as ze,
    C as me,
    b as dt,
    P as ut,
    g as pt,
    D as mt,
    h as ht,
    R as gt,
    c as ft,
    d as Se,
    u as _t,
    e as xt,
    S as yt,
    f as Mt
} from "./bdob0mmccomv88dh.js";
import {
    l as vt,
    d as bt,
    m as kt,
    e as Ct,
    g as De,
    i as pe,
    v as $e,
    f as Qe,
    a as jt,
    h as St,
    s as wt,
    c as D,
    j as Ce,
    k as Pt,
    n as _e,
    o as ve,
    u as ae,
    b as be,
    p as Et
} from "./gjyisy9q1t8rz8p4.js";
import {
    g as Nt,
    c as It,
    u as fe
} from "./lqog7ixiwnif6sbp.js";
import {
    dI as At,
    P as V,
    iU as G,
    bh as Tt,
    R as He,
    M as Oe,
    C as Ze,
    _ as we,
    cU as Be,
    aU as Le,
    ag as ye,
    b as Pe,
    l as se,
    tc as Fe,
    fe as Rt,
    cS as Ut,
    y9 as Dt,
    o as Ot
} from "./dykg4ktvbu3mhmdo.js";
import {
    z as Bt,
    cL as Lt,
    cP as Ft,
    ao as qt,
    y as Vt,
    n5 as Gt
} from "./k15yxxoybkkir2ou.js";
import {
    a as Me,
    u as Ee,
    E as Wt,
    P as zt,
    A as Ye
} from "./cdnrxzg58mayu5uf.js";
import {
    a as $t,
    u as Qt
} from "./zdzro29lk5w2w085.js";
import {
    r as Ht
} from "./b5s349mvbdzayaxi.js";
import {
    M as Zt
} from "./ebc4iyfg14nu1gw4.js";
const Yt = async ({
        intl: t,
        store: e,
        clientThreadId: s
    }) => {
        var r, d, p, f;
        const n = window.location.href,
            i = n.includes("/share/");
        try {
            const o = At(s),
                c = await Nt(E(k({
                    items: e.items
                }, i ? {
                    sharedConversationUrl: n
                } : {
                    conversationId: o
                }), {
                    existing_customer_session_client_secret: e.preloadCustomerSessionClientSecret
                }));
            return e.setInitialCart(c), ((r = c.cart.errors) == null ? void 0 : r.length) > 0 ? (V.logEventWithStatsig("product_checkout", "product_checkout", E(k({}, G((d = e.cartMetadata) != null ? d : {})), {
                action: "cart_load_failed",
                reason: "error_response_from_endpoint",
                error_message: c.cart.errors[0].message
            })), {
                error: c.cart.errors[0].message
            }) : c.customer_session_client_secret && c.publishable_key ? (c.cart.shipping_option_id && vt(e, c.id, c.cart.shipping_options, c.cart.shipping_option_id, "prefill"), c.cart.shipping_address && bt(e, c.id, E(k({}, kt(c.cart.shipping_address)), {
                complete: !0
            }), "prefill"), {
                client_secret: c.customer_session_client_secret,
                publishable_key: c.publishable_key
            }) : (V.logEventWithStatsig("product_checkout", "product_checkout", E(k({}, G((p = e.cartMetadata) != null ? p : {})), {
                action: "cart_load_failed",
                reason: "error_response_from_endpoint",
                error_message: "Missing customer_session_client_secret or publishable_key"
            })), {
                error: t.formatMessage({
                    id: "imEcZX",
                    defaultMessage: "Failed to load cart session (1300)"
                })
            })
        } catch (o) {
            return V.logEventWithStatsig("product_checkout", "product_checkout", E(k({}, G((f = e.cartMetadata) != null ? f : {})), {
                action: "cart_load_failed",
                reason: "error_thrown_from_endpoint",
                error_message: o instanceof Error ? o.message : "Unknown error"
            })), {
                error: o instanceof Error ? o.message : t.formatMessage({
                    id: "S86mYy",
                    defaultMessage: "Failed to load cart session (1301)"
                })
            }
        }
    },
    Jt = Tt(() => ot(() =>
        import ("./fx752hlrp1ihkvln.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28])).then(t => t.ShoppingCheckoutPhoneNumberStartEnrollmentModal));

function Kt() {
    return Ve({
        mutationFn: ({
            phoneNumber: t,
            triggeringProduct: e,
            verificationExpiryWindowMs: s
        }) => He.safePost("/accounts/v1/phone_registry/enroll/start", {
            requestBody: {
                phone_number: t,
                triggering_product: e,
                verification_expiry_window_ms: s
            }
        })
    })
}

function Xt() {
    return Ve({
        mutationFn: ({
            phoneNumber: t,
            triggeringProduct: e,
            verificationCode: s
        }) => He.safePost("/accounts/v1/phone_registry/enroll/finish", {
            requestBody: {
                phone_number: t,
                triggering_product: e,
                verification_code: s
            }
        })
    })
}

function es(t) {
    "use forget";
    const e = je.c(94),
        {
            onClose: s,
            phoneNumber: n,
            triggeringProduct: i,
            logEvent: r,
            onSuccess: d,
            onBack: p,
            onCancel: f
        } = t,
        o = X(),
        [c, _] = S.useState(""),
        [v, u] = S.useState(null),
        [l, M] = S.useState(null),
        y = Xt(),
        b = Kt();
    let m, h;
    e[0] !== r ? (m = () => {
        r("sheet_shown", {
            step: "finish_enrollment"
        })
    }, h = [r], e[0] = r, e[1] = m, e[2] = h) : (m = e[1], h = e[2]), S.useEffect(m, h);
    let x;
    e[3] !== f || e[4] !== s ? (x = () => {
        f(), s()
    }, e[3] = f, e[4] = s, e[5] = x) : x = e[5];
    const g = x;
    let C;
    e[6] !== o ? (C = Y => {
        var Ie, Ae;
        const q = Y,
            J = typeof((Ie = q == null ? void 0 : q.json) == null ? void 0 : Ie.detail) == "string" ? q.json.detail : void 0;
        return (Ae = J != null ? J : q == null ? void 0 : q.message) != null ? Ae : o.formatMessage({
            id: "MbV2xj",
            defaultMessage: "Verification failed, please try again."
        })
    }, e[6] = o, e[7] = C) : C = e[7];
    const w = C;
    let T;
    e[8] !== c || e[9] !== y || e[10] !== r || e[11] !== s || e[12] !== d || e[13] !== n || e[14] !== w || e[15] !== i ? (T = async () => {
        if (r("verify_code_tapped", {
                step: "finish_enrollment"
            }), c.trim().length === 6) try {
            u(null), await y.mutateAsync({
                phoneNumber: n,
                verificationCode: c.trim(),
                triggeringProduct: i
            }), r("verify_code_succeeded", {
                step: "finish_enrollment"
            }), s(), d()
        } catch (Y) {
            const J = w(Y);
            r("verify_code_failed", {
                step: "finish_enrollment",
                reason: J
            }), u(J)
        }
    }, e[8] = c, e[9] = y, e[10] = r, e[11] = s, e[12] = d, e[13] = n, e[14] = w, e[15] = i, e[16] = T) : T = e[16];
    const R = T;
    let O;
    e[17] !== o || e[18] !== r || e[19] !== n || e[20] !== b || e[21] !== w || e[22] !== i ? (O = async () => {
        r("resend_code_tapped", {
            step: "finish_enrollment"
        });
        try {
            u(null), M(null), await b.mutateAsync({
                phoneNumber: n,
                triggeringProduct: i
            }), r("send_code_succeeded", {
                step: "finish_enrollment",
                resend: !0
            }), M(o.formatMessage({
                id: "6ZdNIT",
                defaultMessage: "Code sent, please check your phone."
            }))
        } catch (Y) {
            const J = w(Y);
            r("send_code_failed", {
                step: "finish_enrollment",
                resend: !0,
                reason: J
            }), u(J)
        }
    }, e[17] = o, e[18] = r, e[19] = n, e[20] = b, e[21] = w, e[22] = i, e[23] = O) : O = e[23];
    const j = O;
    let A;
    e[24] !== p || e[25] !== s ? (A = () => {
        s(), p()
    }, e[24] = p, e[25] = s, e[26] = A) : A = e[26];
    const N = A;
    let P;
    e[27] !== o ? (P = o.formatMessage({
        id: "Oq/uUi",
        defaultMessage: "Enter code"
    }), e[27] = o, e[28] = P) : P = e[28];
    let I;
    e[29] !== P ? (I = a.jsx("span", {
        className: "text-heading-3",
        children: P
    }), e[29] = P, e[30] = I) : I = e[30];
    let U;
    e[31] !== o ? (U = o.formatMessage({
        id: "LsrdZy",
        defaultMessage: "Back"
    }), e[31] = o, e[32] = U) : U = e[32];
    let B;
    e[33] !== N || e[34] !== U ? (B = a.jsx(Oe.Button, {
        color: "secondary",
        title: U,
        onClick: N
    }), e[33] = N, e[34] = U, e[35] = B) : B = e[35];
    let L;
    e[36] !== o ? (L = o.formatMessage({
        id: "Gjhl3C",
        defaultMessage: "Verify"
    }), e[36] = o, e[37] = L) : L = e[37];
    let ee;
    e[38] !== c || e[39] !== y.isPending ? (ee = c.trim().length !== 6 || y.isPending, e[38] = c, e[39] = y.isPending, e[40] = ee) : ee = e[40];
    let te;
    e[41] !== y.isPending || e[42] !== R || e[43] !== L || e[44] !== ee ? (te = a.jsx(Oe.Button, {
        "data-testid": "shopping-checkout-phone-verification-step-up-modal__verify",
        title: L,
        color: "primary",
        disabled: ee,
        loading: y.isPending,
        onClick: R
    }), e[41] = y.isPending, e[42] = R, e[43] = L, e[44] = ee, e[45] = te) : te = e[45];
    let W;
    e[46] !== R ? (W = Y => {
        Y.preventDefault(), R()
    }, e[46] = R, e[47] = W) : W = e[47];
    let z;
    e[48] !== o || e[49] !== n ? (z = o.formatMessage({
        id: "FH0uY0",
        defaultMessage: "Enter the 6-digit code we sent to {phoneNumber}."
    }, {
        phoneNumber: n
    }), e[48] = o, e[49] = n, e[50] = z) : z = e[50];
    let $;
    e[51] !== z ? ($ = a.jsx("p", {
        children: z
    }), e[51] = z, e[52] = $) : $ = e[52];
    let Q;
    e[53] !== o ? (Q = o.formatMessage({
        id: "ImwJZd",
        defaultMessage: "Enter code"
    }), e[53] = o, e[54] = Q) : Q = e[54];
    let H;
    e[55] !== v ? (H = Y => {
        const q = Y.target.value.replace(/\D/g, "").slice(0, 6);
        _(q), v && u(null)
    }, e[55] = v, e[56] = H) : H = e[56];
    let Z;
    e[57] !== c || e[58] !== Q || e[59] !== H ? (Z = a.jsx(Bt, {
        ariaLabel: !1,
        name: "shopping-checkout-phone-verification-code",
        value: c,
        inputMode: "numeric",
        maxLength: 6,
        autoComplete: "one-time-code",
        placeholder: Q,
        onChange: H
    }), e[57] = c, e[58] = Q, e[59] = H, e[60] = Z) : Z = e[60];
    let F;
    e[61] !== v ? (F = v && a.jsx("p", {
        className: "text-xs text-red-500",
        role: "alert",
        children: v
    }), e[61] = v, e[62] = F) : F = e[62];
    let ne;
    e[63] !== o ? (ne = o.formatMessage({
        id: "5hOqfV",
        defaultMessage: "Didn't get a code?"
    }), e[63] = o, e[64] = ne) : ne = e[64];
    let ie;
    e[65] !== ne ? (ie = a.jsx("span", {
        children: ne
    }), e[65] = ne, e[66] = ie) : ie = e[66];
    let re;
    e[67] !== o || e[68] !== b.isPending ? (re = b.isPending ? o.formatMessage({
        id: "GR93Ko",
        defaultMessage: "Sending..."
    }) : o.formatMessage({
        id: "enMU6z",
        defaultMessage: "Send again"
    }), e[67] = o, e[68] = b.isPending, e[69] = re) : re = e[69];
    let le;
    e[70] !== j || e[71] !== b.isPending || e[72] !== re ? (le = a.jsx("button", {
        type: "button",
        className: "ms-1 text-blue-400",
        onClick: j,
        disabled: b.isPending,
        children: re
    }), e[70] = j, e[71] = b.isPending, e[72] = re, e[73] = le) : le = e[73];
    let oe;
    e[74] !== l ? (oe = l && a.jsx("div", {
        className: "text-token-text-primary mt-1 text-xs",
        children: l
    }), e[74] = l, e[75] = oe) : oe = e[75];
    let ce;
    e[76] !== ie || e[77] !== le || e[78] !== oe ? (ce = a.jsxs("div", {
        className: "text-token-text-secondary text-xs",
        children: [ie, le, oe]
    }), e[76] = ie, e[77] = le, e[78] = oe, e[79] = ce) : ce = e[79];
    let de;
    e[80] !== $ || e[81] !== Z || e[82] !== F || e[83] !== ce ? (de = a.jsxs("div", {
        className: "flex flex-col gap-3",
        children: [$, Z, F, ce]
    }), e[80] = $, e[81] = Z, e[82] = F, e[83] = ce, e[84] = de) : de = e[84];
    let ue;
    e[85] !== W || e[86] !== de ? (ue = a.jsx("form", {
        onSubmit: W,
        className: "text-token-text-primary w-full text-sm",
        children: de
    }), e[85] = W, e[86] = de, e[87] = ue) : ue = e[87];
    let he;
    return e[88] !== g || e[89] !== B || e[90] !== te || e[91] !== ue || e[92] !== I ? (he = a.jsx(Ze, {
        testId: "modal-shopping-checkout-phone-verification-step-up",
        isOpen: !0,
        type: "success",
        noPadding: !0,
        contentClassName: "flex flex-col items-start gap-6 p-6",
        headerClassName: "!px-6 !py-0 !h-[76px] !items-center",
        showCloseButton: !0,
        hasSeparator: !0,
        onClose: g,
        title: I,
        secondaryButton: B,
        primaryButton: te,
        children: ue
    }), e[88] = g, e[89] = B, e[90] = te, e[91] = ue, e[92] = I, e[93] = he) : he = e[93], he
}
const Je = (t, e, s = {}, n) => {
        var r, d, p;
        const i = k(E(k(E(k({}, G((r = t.cartMetadata) != null ? r : {})), {
            checkout_id: t.cartId
        }), n ? {
            attempt_id: n
        } : {}), {
            action: e
        }), s);
        V.logEventWithStatsig("product_checkout", "product_checkout", i), we.addAction("shopping_checkout.".concat(e), k(k({
            merchant_id: (d = t.merchant) == null ? void 0 : d.externalId,
            merchant_network_id: (p = t.merchant) == null ? void 0 : p.networkId,
            cart_total: t.grandTotal.value
        }, "reason" in s ? {
            reason: s.reason
        } : {}), s))
    },
    qe = "COMMERCE";
class Ke extends Error {
    constructor(e = "Phone verification cancelled") {
        super(e), this.name = "PhoneStepUpCancelledError"
    }
}
async function ts(t, e, s) {
    const n = (i, r = {}) => Je(e, i, r, s);
    return await new Promise((i, r) => {
        let d = !1;
        const p = _ => {
                d || (d = !0, _())
            },
            f = _ => {
                n("flow_cancelled", _ ? {
                    step: _
                } : void 0), p(() => r(new Ke))
            },
            o = _ => {
                Be(t, Jt, {
                    triggeringProduct: qe,
                    logEvent: n,
                    onContinue: v => {
                        c(v)
                    },
                    onCancel: () => f("start_enrollment"),
                    onSkipVerification: () => {
                        p(() => i())
                    },
                    initialPhoneNumber: _
                })
            },
            c = _ => {
                Be(t, es, {
                    phoneNumber: _,
                    triggeringProduct: qe,
                    logEvent: n,
                    onBack: () => {
                        o(_)
                    },
                    onCancel: () => f("finish_enrollment"),
                    onSuccess: () => {
                        p(() => i())
                    }
                })
            };
        o()
    })
}
async function Xe({
    store: t,
    merchant: e,
    elements: s,
    stripe: n,
    ctx: i,
    userEmail: r,
    intl: d,
    finalShippingAddress: p,
    expressPaymentType: f,
    paymentAttemptId: o,
    onConfirm: c,
    onComplete: _
}) {
    var u, l, M, y, b;
    const v = performance.now();
    t.setCartStatus("submitting"), o || (o = Ge());
    try {
        if (ss({
                store: t,
                merchant: e,
                finalShippingAddress: p,
                expressPaymentType: f,
                paymentAttemptId: o
            }), !as({
                elements: s,
                stripe: n,
                userEmail: r,
                intl: d,
                store: t,
                paymentAttemptId: o
            })) return;
        const m = f !== void 0;
        let h = null;
        if (t.cachedPaymentDetailsResponse && !m) h = t.cachedPaymentDetailsResponse;
        else if (h = await ct({
                stripe: Le(n),
                elements: Le(s),
                intl: d,
                billingName: (M = (l = p == null ? void 0 : p.name) != null ? l : (u = t.billingAddress) == null ? void 0 : u.name) != null ? M : "",
                billingEmail: r != null ? r : "",
                isExpressCheckout: m
            }), h != null && h.isError) return K(E(k({}, h), {
            store: t,
            paymentAttemptId: o
        }));
        if (h) m || t.setCachedPaymentDetailsResponse(h);
        else return;
        c == null || c(), await et({
            store: t,
            paymentMethod: h,
            intl: d,
            onComplete: _,
            paymentAttemptId: o,
            finalShippingAddress: p,
            startMs: v,
            expressPaymentType: f,
            ctx: i
        })
    } catch (m) {
        const h = m;
        let x = "payment_failed_general_error";
        const {
            stripe_error_code: g,
            stripe_decline_code: C
        } = ((y = h == null ? void 0 : h.json) == null ? void 0 : y.detail) || {};
        let w = g && C ? await n.localizeError({
            code: g,
            decline_code: C
        }) : void 0;
        h.message === "Failed to fetch" && !w && (x = "payment_failed_network_error", w = d.formatMessage({
            id: "DPyhFG",
            defaultMessage: "Failed to submit payment (1347). Please refresh the page and try again."
        })), K({
            store: t,
            action: "payment_failed",
            reason: x,
            uiMessage: (b = w != null ? w : h.message) != null ? b : d.formatMessage({
                id: "nyG5lS",
                defaultMessage: "Failed to submit payment (1350)"
            }),
            internalMessage: (g != null ? g : C) ? "Stripe error code: ".concat(g, "  ::  Stripe decline code: ").concat(C) : h.message,
            paymentAttemptId: o
        })
    } finally {
        t.setCartStatus("idle")
    }
}

function ss({
    store: t,
    merchant: e,
    finalShippingAddress: s,
    expressPaymentType: n,
    paymentAttemptId: i
}) {
    var d, p, f, o, c, _, v, u;
    const r = t.shippingOptions.find(l => l.id === t.shippingMethodId);
    xe(t, {
        merchant_name: e == null ? void 0 : e.title,
        merchant_url: e == null ? void 0 : e.url,
        totals: t.totals,
        total_price: t.grandTotal.value,
        shipping_city: (p = s == null ? void 0 : s.city) != null ? p : (d = t.shippingAddress) == null ? void 0 : d.city,
        shipping_state: (o = s == null ? void 0 : s.state) != null ? o : (f = t.shippingAddress) == null ? void 0 : f.state,
        shipping_zip: (_ = s == null ? void 0 : s.postal_code) != null ? _ : (c = t.shippingAddress) == null ? void 0 : c.postalCode,
        shipping_country: (u = s == null ? void 0 : s.country) != null ? u : (v = t.shippingAddress) == null ? void 0 : v.country,
        payment_method: tt(t, n),
        shipping_method_name: r == null ? void 0 : r.title,
        shipping_method_price: r == null ? void 0 : r.subtotal,
        shipping_method_index: t.shippingOptions.findIndex(l => l.id === t.shippingMethodId),
        items: t.items.map(l => ({
            product_id: l.id,
            product_title: "title" in l ? l.title : void 0,
            variant: "variant" in l ? l.variant : void 0,
            quantity: l.quantity,
            price: "price" in l ? l.price : void 0
        })),
        action: "pay_button_clicked",
        attempt_id: i
    })
}

function as({
    elements: t,
    stripe: e,
    userEmail: s,
    intl: n,
    store: i,
    paymentAttemptId: r
}) {
    return !t || !e ? (K({
        store: i,
        action: "payment_failed",
        reason: "elements_or_stripe_null",
        uiMessage: n.formatMessage({
            id: "/MYGq8",
            defaultMessage: "Failed to submit payment (1340)"
        }),
        internalMessage: "elements or stripe is null",
        paymentAttemptId: r
    }), !1) : s ? !0 : (K({
        store: i,
        action: "payment_failed",
        reason: "user_email_empty",
        uiMessage: n.formatMessage({
            id: "Zs2vbs",
            defaultMessage: "Failed to submit payment (1346)"
        }),
        internalMessage: "userEmail is empty",
        paymentAttemptId: r
    }), !1)
}
async function et({
    store: t,
    paymentMethod: e,
    intl: s,
    onComplete: n,
    paymentAttemptId: i,
    finalShippingAddress: r,
    startMs: d,
    expressPaymentType: p,
    ctx: f,
    allowStepUpRetry: o = !0
}) {
    var v, u, l, M, y, b, m, h;
    const c = (v = e.billing_details) != null && v.address ? ze(e.billing_details.name, e.billing_details.address, e.billing_details.phone) : t.billingAddress ? Ct(t.billingAddress) : null;
    if (!e.id || !e.type || !c) {
        K({
            store: t,
            action: "payment_failed",
            reason: "missing_payment_method_or_billing_address",
            uiMessage: s.formatMessage({
                id: "xYuTJ8",
                defaultMessage: "Failed to submit payment (1344)"
            }),
            internalMessage: "Missing payment method or billing address",
            extraLogData: {
                error_message: "Missing payment method: ".concat(e.id, " with type: ").concat(e.type)
            },
            paymentAttemptId: i
        });
        return
    }
    const _ = await It(t.cartId, t.items, {
        id: e.id,
        type: e.type,
        billing_address: c
    }, i, r);
    if (_.step_up_action === "PhoneNumberVerification") {
        if (!o) {
            K({
                store: t,
                action: "payment_failed",
                reason: "phone_step_up_retry_failed",
                uiMessage: s.formatMessage({
                    id: "bKp2EC",
                    defaultMessage: "We couldn't verify your phone number. Please try again."
                }),
                internalMessage: "Step up requested more than once for the same checkout attempt",
                paymentAttemptId: i
            });
            return
        }
        try {
            await ts(f, t, i)
        } catch (x) {
            if (x instanceof Ke) {
                K({
                    store: t,
                    action: "payment_failed",
                    reason: "phone_step_up_cancelled",
                    uiMessage: s.formatMessage({
                        id: "ETPsrm",
                        defaultMessage: "Phone verification is required to complete checkout."
                    }),
                    internalMessage: "User cancelled phone verification flow",
                    paymentAttemptId: i
                });
                return
            }
            throw x
        }
        await et({
            store: t,
            paymentMethod: e,
            intl: s,
            onComplete: n,
            paymentAttemptId: i,
            finalShippingAddress: r,
            startMs: d,
            expressPaymentType: p,
            ctx: f,
            allowStepUpRetry: !1
        });
        return
    }
    if (Je(t, "flow_bypassed", {}, i), _.cart != null) {
        if ((u = _.cart.errors) != null && u.length) {
            t.setErrors(_.cart.errors), xe(t, {
                action: "payment_failed",
                reason: "openai_complete_shopping_cart_failed",
                error_message: _.cart.errors.map(x => x.message).join(", "),
                attempt_id: i
            });
            return
        }
        if ((l = _.order) != null && l.id && ((M = _.order) == null ? void 0 : M.status) === "placed") try {
            xe(t, {
                action: "payment_succeeded",
                attempt_id: i
            }), we.addAction("shopping_checkout.complete", {
                durationMs: performance.now() - d,
                merchant_id: (y = t.merchant) == null ? void 0 : y.externalId,
                merchant_network_id: (b = t.merchant) == null ? void 0 : b.networkId,
                cart_total: t.grandTotal.value,
                payment_method: tt(t, p)
            }), typeof n == "function" && await n(_.order), t.closeCheckout()
        } catch (x) {
            K({
                store: t,
                action: "refresh_convo_failed",
                uiMessage: s.formatMessage({
                    id: "d45UJa",
                    defaultMessage: "Failed to update conversation (1400)"
                }),
                internalMessage: x instanceof Error ? x.message : "Unknown error",
                paymentAttemptId: i
            })
        } else K({
            store: t,
            action: "payment_failed",
            reason: "openai_complete_shopping_cart_failed",
            uiMessage: s.formatMessage({
                id: "QJ9CZQ",
                defaultMessage: "Failed to create order (1345)"
            }),
            internalMessage: "Missing orderID",
            extraLogData: {
                error_message: "Missing orderID: ".concat((m = _.order) == null ? void 0 : m.id, " with status: ").concat((h = _.order) == null ? void 0 : h.status)
            },
            paymentAttemptId: i
        })
    }
}

function xe(t, e) {
    var s, n, i;
    V.logEventWithStatsig("product_checkout", "product_checkout", k(E(k({}, G((s = t.cartMetadata) != null ? s : {})), {
        checkout_id: t.cartId
    }), e)), we.addAction("shopping_checkout.".concat(e.action), {
        merchant_id: (n = t.merchant) == null ? void 0 : n.externalId,
        merchant_network_id: (i = t.merchant) == null ? void 0 : i.networkId,
        cart_total: t.grandTotal.value,
        reason: e.reason
    })
}

function K({
    store: t,
    action: e,
    reason: s,
    uiMessage: n,
    internalMessage: i,
    extraLogData: r,
    paymentAttemptId: d
}) {
    const p = n + "";
    t.setErrors([{
        group: "general",
        message: p
    }]), xe(t, k(k(k(k({
        action: e
    }, s ? {
        reason: s
    } : {}), i ? {
        error_message: i
    } : {}), r != null ? r : {}), (e === "payment_failed" || e === "payment_succeeded") && d ? {
        attempt_id: d
    } : {}))
}

function tt(t, e) {
    var s, n, i;
    return (i = e == null ? void 0 : e.toLocaleLowerCase()) != null ? i : (n = (s = t.paymentDetails) == null ? void 0 : s.label) == null ? void 0 : n.toLocaleLowerCase()
}
const st = ({
        store: t,
        optionOverrides: e,
        onConfirm: s,
        onReady: n,
        onComplete: i,
        surface: r
    }) => {
        var b;
        const d = Me(),
            p = Ee(),
            f = ye(),
            o = f == null ? void 0 : f.email,
            c = X(),
            _ = We(),
            v = Pe(),
            u = S.useRef(void 0),
            l = S.useRef(void 0),
            M = t.items,
            y = S.useMemo(() => {
                var h, x, g, C, w, T;
                const m = {
                    buttonHeight: 40,
                    shippingAddressRequired: !0,
                    billingAddressRequired: !0,
                    allowedShippingCountries: t.allowedCountries,
                    business: {
                        name: (x = (h = t.merchant) == null ? void 0 : h.title) != null ? x : ""
                    },
                    phoneNumberRequired: !0,
                    paymentMethods: {
                        applePay: (g = t == null ? void 0 : t.paymentTypes[r]) != null && g.includes("apple_pay") ? "always" : "never",
                        googlePay: (C = t == null ? void 0 : t.paymentTypes[r]) != null && C.includes("google_pay") ? "always" : "never",
                        shopPay: (w = t == null ? void 0 : t.paymentTypes[r]) != null && w.includes("shop_pay") ? "auto" : "never",
                        link: (T = t == null ? void 0 : t.paymentTypes[r]) != null && T.includes("link") ? "auto" : "never"
                    },
                    paymentMethodOrder: ["apple_pay", "google_pay", "shop_pay", "link"],
                    shippingRates: De(M, t.shippingOptions, c)
                };
                return k(k({}, m), e)
            }, [(b = t.merchant) == null ? void 0 : b.title, t.allowedCountries, e, r, t.paymentTypes, t.shippingOptions, c, M]);
        return a.jsx(Wt, {
            options: y,
            onConfirm: async m => {
                var x, g, C;
                const h = (x = m.shippingAddress) != null && x.address && ((g = m.shippingAddress) != null && g.name) ? ze(m.shippingAddress.name, m.shippingAddress.address, (C = m.billingDetails) == null ? void 0 : C.phone) : void 0;
                await Xe({
                    store: t,
                    merchant: t.merchant,
                    elements: d,
                    stripe: p,
                    ctx: v,
                    userEmail: o,
                    intl: c,
                    finalShippingAddress: h,
                    expressPaymentType: m.expressPaymentType,
                    paymentAttemptId: u.current,
                    onConfirm: s,
                    onComplete: async w => {
                        await Qe({
                            store: t,
                            order: w,
                            navigate: _
                        }), await (i == null ? void 0 : i(w))
                    }
                })
            },
            onReady: () => {
                n == null || n()
            },
            onClick: m => {
                var C;
                const {
                    expressPaymentType: h,
                    resolve: x,
                    reject: g
                } = m;
                if (l.current = t.shippingAddress, u.current = Ge(), V.logEventWithStatsig("product_checkout", "product_checkout", E(k({}, G((C = t.cartMetadata) != null ? C : {})), {
                        payment_method: h,
                        checkout_id: t.cartId,
                        action: "express_checkout_button_clicked",
                        attempt_id: u.current
                    })), $e(t, c)) return x();
                g()
            },
            onShippingAddressChange: async function({
                address: m,
                resolve: h,
                reject: x
            }) {
                try {
                    const g = await fe(t.cartId, {
                        items: M,
                        shippingAddress: {
                            name: null,
                            addressLine1: null,
                            addressLine2: null,
                            city: m.city,
                            state: m.state,
                            postalCode: m.postal_code,
                            country: m.country,
                            complete: !0
                        }
                    });
                    t.updateCart(g);
                    const C = De(M, g.cart.shipping_options, c);
                    if (C.length === 0) {
                        x();
                        return
                    }
                    d && d.update({
                        amount: g.cart.grand_total.value_minor
                    }), h({
                        shippingRates: C
                    })
                } catch (g) {
                    x()
                }
            },
            onCancel: async () => {
                try {
                    if (pe(t, l.current)) {
                        const m = await fe(t.cartId, {
                            items: M,
                            shippingAddress: l.current
                        });
                        t.updateCart(m), d && d.update({
                            amount: m.cart.grand_total.value_minor
                        })
                    }
                } catch (m) {}
            },
            onShippingRateChange: async function({
                shippingRate: m,
                resolve: h,
                reject: x
            }) {
                try {
                    const g = await fe(t.cartId, {
                        items: M,
                        shippingMethodId: m.id
                    });
                    t.updateCart(g), d && d.update({
                        amount: g.cart.grand_total.value_minor
                    }), h()
                } catch (g) {
                    x()
                }
            }
        })
    },
    ge = ({
        cartErrors: t,
        section: e
    }) => {
        var n;
        const s = (n = t == null ? void 0 : t.filter(i => e ? i.group === e : !0)) != null ? n : [];
        return s.length ? a.jsx("div", {
            className: "flex flex-col gap-1 pt-3",
            children: s.map(i => {
                var r;
                return a.jsx(me, {
                    message: i.message,
                    level: (r = i.level) != null ? r : "error"
                }, i.message)
            })
        }) : null
    };
let ke = 0;

function ns({
    store: t,
    pushPane: e,
    loadingCartSession: s,
    loadingPayment: n,
    loadingAddress: i,
    cartLoadError: r,
    stripeLoadingError: d,
    merchant: p,
    footerMessage: f,
    isCurrentPane: o
}) {
    var W, z, $, Q, H, Z;
    const c = ye(),
        _ = c == null ? void 0 : c.email,
        {
            cartStatus: v,
            paymentDetails: u,
            shippingAddress: l,
            shippingMethodId: M,
            shippingOptions: y,
            totals: b,
            grandTotal: m,
            errors: h,
            headerMessage: x
        } = t,
        g = jt(t.items),
        C = S.useMemo(() => y.find(F => F.id === M), [y, M]),
        w = !!(u != null && u.complete),
        T = !!(l != null && l.complete),
        R = (s || n || i) && !r,
        O = !R,
        j = O && !g,
        A = v === "complete",
        N = v === "updating",
        P = O && (w || n || i),
        I = !!(T && y.length > 0 && C),
        U = !!f && !R,
        B = X(),
        L = S.useCallback(() => {
            if (!St(t.agreements)) return wt(t, B), !1;
            e("paymentMethod")
        }, [e]),
        ee = S.useCallback(() => {
            e("shippingAddress")
        }, [e]),
        te = S.useCallback(() => {
            e("shippingMethod")
        }, [e]);
    return a.jsxs("div", {
        className: "relative flex h-full flex-col",
        children: [A && a.jsx("div", {
            className: "bg-token-bg-primary absolute inset-0 z-50 flex items-center justify-center",
            children: a.jsx(dt, {
                className: "h-44 w-44 text-green-400",
                loop: !1
            })
        }), a.jsxs("div", {
            className: "flex flex-col px-6 pb-6",
            children: [a.jsx("div", {
                className: "mb-4",
                children: a.jsx(rs, {
                    item: t.items[0],
                    store: t,
                    canUpdateQuantity: j,
                    isLoading: s && !r
                })
            }), d && a.jsx(me, {
                message: d
            }), r && a.jsx(me, {
                message: r
            }), x && a.jsx(me, {
                message: x,
                level: "info"
            }), O && a.jsxs(a.Fragment, {
                children: [P && a.jsxs("div", {
                    className: se(t.cartStatus === "submitting" && "pointer-events-none opacity-50"),
                    children: [a.jsxs("div", {
                        className: "border-token-border-light border-t",
                        children: [a.jsx(ut, {
                            onClick: L,
                            isComplete: (W = u == null ? void 0 : u.complete) != null ? W : !1,
                            label: (z = u == null ? void 0 : u.label) != null ? z : "",
                            sublabel: ($ = u == null ? void 0 : u.sublabel) != null ? $ : "",
                            icon: (Q = u == null ? void 0 : u.icon) != null ? Q : void 0,
                            isLoading: n
                        }), a.jsx(ge, {
                            cartErrors: h,
                            section: "payment_method"
                        })]
                    }), a.jsxs("div", {
                        className: "border-token-border-light border-t",
                        children: [a.jsx(pt, {
                            name: l == null ? void 0 : l.name,
                            addressLine1: l == null ? void 0 : l.addressLine1,
                            addressLine2: l == null ? void 0 : l.addressLine2,
                            city: l == null ? void 0 : l.city,
                            state: (H = l == null ? void 0 : l.state) != null ? H : void 0,
                            isComplete: (Z = l == null ? void 0 : l.complete) != null ? Z : !1,
                            isLoading: i,
                            onClick: ee
                        }), a.jsx(ge, {
                            cartErrors: h,
                            section: "shipping_address"
                        })]
                    }), g && a.jsx("div", {
                        className: "border-token-border-light border-t",
                        children: a.jsx(mt, {
                            emailAddress: _
                        })
                    }), I && C && a.jsxs(a.Fragment, {
                        children: [a.jsx("div", {
                            className: "border-token-border-light border-t",
                            children: a.jsx(ht, {
                                method: C,
                                onClick: te
                            })
                        }), a.jsx(ge, {
                            cartErrors: h,
                            section: "shipping_option"
                        })]
                    })]
                }), a.jsx(cs, {
                    totals: b,
                    grandTotal: m,
                    isLoading: N
                }), a.jsx(ds, {
                    store: t
                }), !r && a.jsx(ge, {
                    cartErrors: h,
                    section: P ? "general" : void 0
                }), !r && !s && a.jsx(is, {
                    store: t,
                    merchant: p,
                    hasValidPaymentMethod: w,
                    isCurrentPane: o,
                    pushPane: e
                })]
            })]
        }), U && a.jsx(Ne, {
            className: "bg-token-bg-elevated-secondary text-token-text-tertiary border-token-border-light h-full border-t p-6 text-xs",
            components: {
                a: F => a.jsx("a", E(k({}, F), {
                    className: se(F.className, "text-blue-400 underline"),
                    target: "_blank",
                    children: F.children
                }))
            },
            children: f
        })]
    })
}
const is = t => {
        "use forget";
        var w, T;
        const e = je.c(25),
            {
                store: s,
                merchant: n,
                hasValidPaymentMethod: i,
                isCurrentPane: r,
                pushPane: d
            } = t,
            p = X(),
            f = Ee(),
            o = Me(),
            c = We(),
            _ = (w = ye()) == null ? void 0 : w.email,
            v = Pe(),
            [u, l] = S.useState(!1);
        let M;
        e[0] !== s ? (M = $t(s), e[0] = s, e[1] = M) : M = e[1];
        const y = !M,
            b = s.cartStatus === "submitting",
            m = s.cartStatus === "updating",
            h = (T = n == null ? void 0 : n.title) != null ? T : "";
        let x;
        e[2] !== r || e[3] !== s ? (x = r && a.jsx(st, {
            store: s,
            surface: "payment_sheet",
            onReady: () => l(!0)
        }), e[2] = r, e[3] = s, e[4] = x) : x = e[4];
        let g;
        e[5] !== v || e[6] !== o || e[7] !== p || e[8] !== n || e[9] !== c || e[10] !== s || e[11] !== f || e[12] !== _ ? (g = async () => {
            $e(s, p) && await Xe({
                store: s,
                merchant: n,
                elements: o,
                stripe: f,
                ctx: v,
                userEmail: _,
                intl: p,
                onComplete: async R => await Qe({
                    store: s,
                    order: R,
                    navigate: c
                })
            })
        }, e[5] = v, e[6] = o, e[7] = p, e[8] = n, e[9] = c, e[10] = s, e[11] = f, e[12] = _, e[13] = g) : g = e[13];
        let C;
        return e[14] !== u || e[15] !== i || e[16] !== d || e[17] !== s.paymentSheetButtonCta || e[18] !== y || e[19] !== b || e[20] !== m || e[21] !== h || e[22] !== x || e[23] !== g ? (C = a.jsx(ft, {
            isDisabled: y,
            isSubmitting: b,
            isUpdating: m,
            merchantTitle: h,
            hasValidPaymentMethod: i,
            expressCheckoutElement: x,
            expressCheckoutElementReady: u,
            paymentSheetButtonCta: s.paymentSheetButtonCta,
            onClickPay: g,
            pushPane: d
        }), e[14] = u, e[15] = i, e[16] = d, e[17] = s.paymentSheetButtonCta, e[18] = y, e[19] = b, e[20] = m, e[21] = h, e[22] = x, e[23] = g, e[24] = C) : C = e[24], C
    },
    rs = ({
        item: t,
        store: e,
        canUpdateQuantity: s,
        isLoading: n
    }) => a.jsxs("div", {
        className: "flex gap-4",
        children: [a.jsx("div", {
            className: "bg-token-bg-tertiary dark:bg-token-main-surface-primary-inverse overflow-clip rounded-lg",
            children: n ? a.jsx("div", {
                className: "relative m-0 aspect-square h-32 w-32",
                children: a.jsx("div", {
                    className: "absolute inset-0 z-3 w-full overflow-hidden",
                    children: a.jsx("div", {
                        className: "absolute start-[-150%] top-[-150%] h-[400%] w-[400%]",
                        children: a.jsx("div", {
                            className: "diagonal-sweep-gradient h-full w-full"
                        })
                    })
                })
            }) : a.jsx("img", {
                className: "m-0 aspect-square h-32 w-32 object-cover mix-blend-darken",
                src: t.imageUrl,
                alt: t.title
            })
        }), a.jsxs("div", {
            className: "flex flex-1 flex-col",
            children: [a.jsx("div", {
                className: "text-normal line-clamp-2 min-h-6 leading-snug font-medium",
                title: t.title,
                children: n ? a.jsx(Fe, {
                    index: 1,
                    width: 80,
                    heightSize: "sm"
                }) : t.title
            }), a.jsx("div", {
                className: "text-token-text-secondary h-[18px] text-[13px]",
                children: n ? a.jsx(Fe, {
                    index: 2,
                    width: 60,
                    heightSize: "sm"
                }) : t.variant
            }), a.jsx("div", {
                className: "mt-2 flex flex-1 items-end",
                children: s && !n && a.jsx(os, {
                    quantity: t.quantity,
                    store: e,
                    itemId: t.id,
                    isDisabled: e.cartStatus === "submitting" || e.cartStatus === "updating"
                })
            })]
        })]
    }),
    ls = 600,
    os = ({
        quantity: t,
        store: e,
        itemId: s,
        isDisabled: n
    }) => {
        const i = X(),
            r = S.useRef(e);
        S.useEffect(() => {
            r.current = e
        }, [e]);
        const d = S.useCallback(Rt(async (f, o) => {
                var v, u, l, M, y, b, m;
                const c = r.current;
                if (!c) return;
                const _ = ++ke;
                c.setCartStatus("updating"), c.setErrors([]);
                try {
                    const h = await fe(f, {
                        items: o,
                        shippingMethodId: c.shippingMethodId,
                        shippingAddress: c.shippingAddress
                    });
                    if (_ === ke) {
                        c.updateCart(h);
                        const x = (y = (M = (u = (v = h.cart.line_items) == null ? void 0 : v[0]) == null ? void 0 : u.item.quantity) != null ? M : (l = o[0]) == null ? void 0 : l.quantity) != null ? y : 0;
                        V.logEventWithStatsig("product_checkout", "product_checkout", E(k({}, G((b = c.cartMetadata) != null ? b : {})), {
                            checkout_id: c.cartId,
                            product_id: s,
                            action: "quantity_changed",
                            new_quantity: x.toString()
                        }))
                    }
                } catch (h) {
                    _ === ke && (c.setErrors([{
                        group: "general",
                        message: i.formatMessage(D.cartUpdateQuantityErrorMessage)
                    }]), V.logEventWithStatsig("product_checkout", "product_checkout", E(k({}, G((m = c.cartMetadata) != null ? m : {})), {
                        action: "cart_update_failed",
                        reason: "error_response_from_endpoint",
                        error_message: h
                    })), c.setCartStatus("idle"))
                }
            }, ls), []),
            p = "bg-token-bg-tertiary hover:bg-token-bg-secondary text-token-text-primary flex items-center justify-center px-2 py-2 text-xl font-bold";
        return a.jsxs("div", {
            className: se("inline-flex items-center select-none", n && "pointer-events-none opacity-50"),
            children: [a.jsx("button", {
                className: se(p, "rounded-s-xl"),
                onClick: () => {
                    if (t === 1) {
                        confirm(i.formatMessage({
                            id: "XvhtH9",
                            defaultMessage: "Are you sure you want to remove this item?"
                        })) && Ce(e, "deleted_item");
                        return
                    }
                    const f = e.updateQuantity(s, Math.max(t - 1, 1));
                    d(e.cartId, f)
                },
                children: t === 1 ? a.jsx(Lt, {
                    className: "icon"
                }) : a.jsx(Ft, {
                    className: "icon"
                })
            }), a.jsx("span", {
                className: "bg-token-bg-tertiary text-token-text-primary flex h-9 w-6 items-center justify-center text-sm font-semibold",
                children: t
            }), a.jsx("button", {
                className: se(p, "rounded-e-xl"),
                onClick: () => {
                    const f = e.updateQuantity(s, t + 1);
                    d(e.cartId, f)
                },
                children: a.jsx(qt, {
                    className: "icon"
                })
            })]
        })
    },
    cs = ({
        totals: t,
        grandTotal: e,
        isLoading: s
    }) => e != null && e.value ? a.jsxs("div", {
        className: "flex flex-col gap-3 pt-3",
        children: [a.jsx("div", {
            children: t == null ? void 0 : t.map(n => a.jsxs("div", {
                className: "text-token-text-secondary flex items-end justify-between text-[13px]",
                children: [a.jsx("span", {
                    className: "font-medium",
                    children: n.title
                }), a.jsx(Ne, {
                    className: se("transition-opacity duration-200", s && "opacity-50"),
                    remarkPlugins: [
                        [Ht, {
                            singleTilde: !1
                        }]
                    ],
                    children: n.formatted_value
                })]
            }, n.title))
        }), a.jsxs("div", {
            className: "flex items-end justify-between",
            children: [a.jsxs("div", {
                className: "flex flex-col text-[13px]",
                children: [a.jsx("span", {
                    className: "font-medium",
                    children: e.title
                }), a.jsx("span", {
                    className: "text-token-text-secondary",
                    children: e.subtitle
                })]
            }), a.jsx("div", {
                className: "text-xl font-medium",
                children: e.value_minor > 0 ? a.jsx(gt, {
                    text: e.formatted_value,
                    className: se("transition-opacity duration-200", s && "opacity-50")
                }) : "-"
            })]
        })]
    }) : null,
    ds = t => {
        "use forget";
        const e = je.c(2),
            {
                store: s
            } = t;
        let n;
        return e[0] !== s ? (n = s.agreements && s.agreements.length > 0 && a.jsx("div", {
            className: "flex flex-col gap-2 pt-3",
            children: s.agreements.map(i => a.jsx(us, {
                store: s,
                agreement: i
            }, i.id))
        }), e[0] = s, e[1] = n) : n = e[1], n
    },
    us = ({
        agreement: t,
        store: e
    }) => {
        "use no forget";
        return S.useEffect(() => {
            var s;
            V.logEventWithStatsig("product_checkout", "product_checkout", E(k({}, G((s = e.cartMetadata) != null ? s : {})), {
                checkout_id: e.cartId,
                action: "agreement_shown",
                agreement_id: t.id
            }))
        }, []), a.jsx(Vt, {
            id: t.id,
            checked: t.is_checked,
            onChange: s => {
                var i;
                const n = s.currentTarget.checked;
                e.setHasAcceptedAgreement(t.id, n), V.logEventWithStatsig("product_checkout", "product_checkout", E(k({}, G((i = e.cartMetadata) != null ? i : {})), {
                    checkout_id: e.cartId,
                    action: "agreement_clicked",
                    agreement_id: t.id,
                    checked: n
                }))
            },
            labelClassName: "ps-3 text-[13px] font-medium select-none text-token",
            label: a.jsx(Ne, {
                components: {
                    a: s => a.jsx("a", E(k({}, s), {
                        className: se(s.className, "text-blue-400 underline"),
                        target: "_blank",
                        children: s.children
                    }))
                },
                children: t.content + (t.is_required ? " *" : "")
            })
        }, t.id)
    },
    Ne = S.memo(Zt),
    ps = 10 * 1e3,
    ms = ({
        store: t,
        pushPane: e,
        resetPanes: s,
        setLoadingPayment: n,
        loadingAddress: i,
        setStripeLoadingError: r,
        isCurrentPane: d
    }) => {
        var T, R, O;
        const p = X(),
            f = ye(),
            o = f == null ? void 0 : f.email,
            c = Me(),
            _ = Ee(),
            [v, u] = S.useState(null),
            [l, M] = S.useState(!1),
            [y, b] = S.useState((T = t.paymentDetails) != null && T.complete ? t.paymentDetails : null),
            [m, h] = S.useState(void 0),
            x = S.useRef(!0),
            g = S.useRef(!0),
            C = () => {
                x.current = !1, r(p.formatMessage(D.stripeLoadingPaymentMethodError)), n(!1)
            };
        S.useEffect(() => {
            const j = setTimeout(() => {
                x.current && C()
            }, ps);
            return () => clearTimeout(j)
        }, []);
        const w = async j => {
            var A, N, P, I, U, B;
            if (u(null), x.current) {
                if (x.current = !1, (A = t.paymentDetails) != null && A.complete && ((N = t.billingAddress) != null && N.complete) && t.cachedPaymentDetailsResponse) {
                    ve(t, (P = t.paymentDetails) == null ? void 0 : P.label, "prefill"), n(!1);
                    return
                }
                if (j.complete && ((I = j.value.payment_method) != null && I.id)) {
                    t.setPaymentDetails(E(k({}, be(j)), {
                        complete: !0
                    })), t.setCachedPaymentDetailsResponse({
                        id: j.value.payment_method.id,
                        type: j.value.payment_method.type,
                        billing_details: {
                            address: j.value.payment_method.billing_details.address,
                            name: (U = j.value.payment_method.billing_details.name) != null ? U : ""
                        }
                    });
                    const L = E(k({}, _e(j.value.payment_method.billing_details.address, j.value.payment_method.billing_details.name, j.value.payment_method.billing_details.phone)), {
                        complete: !0
                    });
                    t.setBillingAddress(L), b(E(k({}, be(j)), {
                        complete: j.complete
                    })), !i && t.isShippingAddressSameAsBilling && L.addressLine1 && !pe(t, t.shippingAddress) && await ae({
                        store: t,
                        fields: {
                            items: t.items,
                            shippingAddress: L
                        },
                        errorMessage: p.formatMessage(D.cartUpdateShippingAddressErrorMessage),
                        source: "prefill"
                    }), ve(t, (B = j.preview) == null ? void 0 : B.label, "prefill")
                }
                n(!1);
                return
            }
            j.complete && b(E(k({}, be(j)), {
                complete: !0
            }))
        };
        return a.jsxs("div", {
            className: "flex w-full flex-col gap-4 px-6 pb-6",
            children: [d && ((R = t.paymentDetails) == null ? void 0 : R.complete) && a.jsx("div", {
                className: "min-h-10",
                children: a.jsx(st, {
                    store: t,
                    surface: "payment_sheet",
                    optionOverrides: {
                        layout: {
                            maxRows: 1,
                            overflow: "auto"
                        }
                    },
                    onConfirm: () => {
                        t.setPaymentDetails(void 0), t.setShippingAddress(void 0), s()
                    }
                })
            }), !t.paymentTypes.payment_sheet.includes("card") && !((O = t.paymentDetails) != null && O.complete) && a.jsx("div", {
                className: "text-token-text-tertiary py-10 text-center text-sm",
                children: a.jsx(Ue, {
                    id: "7t8tjX",
                    defaultMessage: "No other payment methods available"
                })
            }), a.jsxs("div", {
                className: t.paymentTypes.payment_sheet.includes("card") ? "" : "hidden",
                children: [a.jsx(zt, {
                    id: "payment-element",
                    options: {
                        fields: {
                            billingDetails: {
                                email: "never",
                                phone: "never"
                            }
                        },
                        wallets: {
                            applePay: "never",
                            googlePay: "never"
                        },
                        defaultValues: {
                            billingDetails: {
                                email: o
                            }
                        },
                        business: {
                            name: "OpenAI"
                        },
                        layout: {
                            type: "accordion",
                            defaultCollapsed: !1
                        }
                    },
                    onLoadError: () => {
                        x.current && C()
                    },
                    onChange: w,
                    onSavedPaymentMethodRemove: j => {
                        var A, N, P, I;
                        ((A = t.paymentDetails) == null ? void 0 : A.paymentMethodId) === ((N = j.payment_method) == null ? void 0 : N.id) && (t.setPaymentDetails(void 0), b(null)), Pt(t, (I = (P = j.payment_method) == null ? void 0 : P.type) != null ? I : "")
                    }
                }), v && a.jsx("div", {
                    className: "mt-2",
                    children: a.jsx(me, {
                        message: v
                    })
                }), a.jsx("div", {
                    className: "mt-6 mb-2 text-sm font-medium",
                    children: a.jsx(Ue, {
                        id: "8pb7do",
                        defaultMessage: "Billing address"
                    })
                }), a.jsx(Ye, {
                    options: {
                        mode: "billing",
                        allowedCountries: t.allowedCountries,
                        fields: {
                            phone: "always"
                        },
                        validation: {
                            phone: {
                                required: "always"
                            }
                        }
                    },
                    onChange: j => {
                        if (u(null), g.current) {
                            g.current = !1;
                            return
                        }
                        h(E(k({}, _e(j.value.address, j.value.name, j.value.phone)), {
                            complete: !0
                        }))
                    }
                })]
            }), a.jsx(Se, {
                isSaving: l,
                isDisabled: l,
                onClick: async () => {
                    var j;
                    if (u(null), !c) {
                        u(p.formatMessage(D.cartUpdateGeneralErrorRetryMessage));
                        return
                    }
                    try {
                        if (!y) {
                            u(p.formatMessage(D.cartUpdateGeneralErrorMessage));
                            return
                        }
                        if (!(m != null && m.name)) {
                            u(p.formatMessage(D.stripeLoadingBillingAddressError));
                            return
                        }
                        M(!0);
                        const {
                            error: A,
                            paymentMethod: N
                        } = await _.preparePaymentMethod({
                            elements: c,
                            params: {
                                allow_redisplay: "always",
                                billing_details: {
                                    name: m.name,
                                    email: o
                                }
                            }
                        });
                        if (M(!1), A) {
                            const {
                                code: P,
                                decline_code: I
                            } = A || {}, U = P && I ? await _.localizeError({
                                code: P,
                                decline_code: I
                            }) : A.message;
                            u(U);
                            return
                        }
                        ve(t, y == null ? void 0 : y.label, "user"), t.setPaymentDetails(E(k({}, y), {
                            complete: !0,
                            paymentMethodId: N == null ? void 0 : N.id,
                            paymentMethodType: N == null ? void 0 : N.type,
                            label: y == null ? void 0 : y.label,
                            sublabel: y == null ? void 0 : y.sublabel
                        })), t.setBillingAddress(m), t.setCachedPaymentDetailsResponse(N)
                    } catch (A) {
                        u(p.formatMessage(D.cartUpdateGeneralErrorMessage)), M(!1);
                        return
                    }
                    t.isShippingAddressSameAsBilling && ae({
                        store: t,
                        fields: {
                            items: t.items,
                            shippingAddress: m
                        },
                        errorMessage: p.formatMessage(D.cartUpdateShippingAddressErrorMessage),
                        source: "prefill"
                    }), (j = t.shippingAddress) != null && j.addressLine1 ? s() : e("shippingAddress")
                }
            })]
        })
    },
    hs = 10 * 1e3;

function gs({
    store: t,
    resetPanes: e,
    setLoadingAddress: s,
    loadingPayment: n,
    setStripeLoadingError: i,
    isCurrentPane: r
}) {
    var v, u;
    const d = X(),
        p = S.useRef(!0),
        f = Me(),
        o = S.useRef(!1);
    S.useEffect(() => {
        pe(t, t.shippingAddress) && ae({
            store: t,
            fields: {
                items: t.items,
                shippingAddress: t.shippingAddress
            },
            errorMessage: d.formatMessage(D.cartUpdateShippingAddressErrorMessage),
            source: "prefill",
            skipLogging: !0
        });
        const l = setTimeout(() => {
            p.current && (p.current = !1, i(d.formatMessage(D.stripeLoadingShippingAddressError)), s(!1))
        }, hs);
        return () => clearTimeout(l)
    }, []);
    const c = async l => {
            var M;
            if (p.current) {
                if (p.current = !1, pe(t, t.shippingAddress)) {
                    s(!1);
                    return
                }
                l.complete && ((M = l.value.address) != null && M.line1) ? await ae({
                    store: t,
                    fields: {
                        items: t.items,
                        shippingAddress: E(k({}, _e(l.value.address, l.value.name, l.value.phone)), {
                            complete: l.complete
                        })
                    },
                    errorMessage: d.formatMessage(D.cartUpdateShippingAddressErrorMessage),
                    onLocalMutationComplete: () => {
                        s(!1)
                    },
                    source: "prefill"
                }) : !n && pe(t, t.billingAddress) && (t.setIsShippingAddressSameAsBilling(!0), await ae({
                    store: t,
                    fields: {
                        items: t.items,
                        shippingAddress: t.billingAddress
                    },
                    errorMessage: d.formatMessage(D.cartUpdateShippingAddressErrorMessage),
                    onLocalMutationComplete: () => {
                        s(!1)
                    },
                    source: "prefill"
                })), s(!1);
                return
            }
            r && (o.current = !0), t.setIsShippingAddressSameAsBilling(l.syncAddress)
        },
        _ = (v = t.additionalFields) == null ? void 0 : v.includes("shipping_address_phone_number");
    return a.jsxs("div", {
        className: "flex h-full flex-col gap-4 px-6 pb-6",
        children: [a.jsx(Ye, {
            id: "address-element",
            options: {
                mode: "shipping",
                allowedCountries: t.allowedCountries,
                defaultValues: (u = t.shippingAddress) != null && u.complete ? Et(t.shippingAddress, _) : void 0,
                fields: {
                    phone: _ ? "always" : "never"
                },
                validation: k({}, _ && {
                    phone: {
                        required: "always"
                    }
                })
            },
            onChange: c,
            onLoadError: () => {
                p.current && (p.current = !1, i(d.formatMessage(D.stripeLoadingShippingAddressError)), s(!1))
            }
        }), a.jsx(Se, {
            onClick: async () => {
                var M;
                const l = await ((M = f == null ? void 0 : f.getElement("address", {
                    mode: "shipping"
                })) == null ? void 0 : M.getValue());
                if (l != null && l.complete) {
                    if (o.current) {
                        const y = E(k({}, _e(l.value.address, l.value.name, l.value.phone)), {
                            complete: l.complete
                        });
                        ae({
                            store: t,
                            fields: {
                                items: t.items,
                                shippingAddress: y
                            },
                            errorMessage: d.formatMessage(D.cartUpdateShippingAddressErrorMessage),
                            source: "user"
                        })
                    }
                    e()
                }
            }
        })]
    })
}

function fs({
    shippingMethods: t,
    resetPanes: e,
    store: s
}) {
    const n = X(),
        [i, r] = S.useState(s.shippingMethodId);
    return a.jsxs("div", {
        className: "flex h-full flex-col gap-4 px-6 pb-6",
        children: [a.jsx("div", {
            className: "divide-token-border-light -mt-4 flex flex-col gap-2 divide-y",
            children: t.map(d => a.jsxs("button", {
                type: "button",
                onClick: () => {
                    r(d.id)
                },
                className: "flex w-full items-center gap-3 rounded-lg px-4 py-3 text-start",
                children: [i === d.id ? a.jsx(Ut, {
                    className: "text-token-text-primary h-6 w-6"
                }) : a.jsx(Dt, {
                    className: "text-token-text-primary h-6 w-6"
                }), a.jsxs("div", {
                    className: "flex flex-1 flex-col items-start",
                    children: [a.jsx("span", {
                        className: "text-token-text-primary flex items-center gap-2 text-base",
                        children: d.title
                    }), a.jsx("span", {
                        className: "text-token-text-secondary text-sm leading-tight font-normal",
                        children: d.subtitle
                    })]
                })]
            }, d.id))
        }), a.jsx(Se, {
            onClick: () => {
                i && (ae({
                    store: s,
                    fields: {
                        shippingMethodId: i,
                        items: s.items
                    },
                    errorMessage: n.formatMessage(D.cartUpdateShippingAddressErrorMessage),
                    source: "user"
                }), e())
            }
        })]
    })
}

function _s() {
    var v, u, l, M, y, b, m, h, x, g, C, w, T, R, O, j, A, N;
    const t = Pe(),
        e = Qt(t),
        s = !!e.items[0],
        n = _t("overview"),
        i = X(),
        {
            currentPane: r,
            pushPane: d,
            popPane: p,
            resetPanes: f
        } = n,
        o = Ot(t, "3375735072");
    S.useEffect(() => {
        e.isCheckoutOpen || f()
    }, [e.isCheckoutOpen, f]);
    const c = S.useMemo(() => {
            var P, I, U, B;
            return [...(I = (P = e.paymentTypes) == null ? void 0 : P.express_checkout) != null ? I : [], ...(B = (U = e.paymentTypes) == null ? void 0 : U.payment_sheet) != null ? B : []]
        }, [e.paymentTypes]),
        _ = (v = e.cartMetadata) == null ? void 0 : v.clientThreadId;
    return !o || !e.isCheckoutOpen || !s || !_ ? null : a.jsx(Ze, {
        testId: "modal-shopping-checkout",
        isOpen: !0,
        hideSeparator: !0,
        showCloseButton: e.cartStatus !== "submitting",
        size: "large",
        type: "success",
        className: "min-h-36 max-w-[550px]!",
        headerClassName: "sm:p-0 sm:px-6 sm:py-4 items-center sm:-me-1",
        contentClassName: "!p-0 pt-3",
        rootClassName: "z-40",
        shouldIgnoreClickOutside: !0,
        onEscapeKeyDown: P => {
            P.preventDefault(), Ce(e, "closed")
        },
        onClose: () => {
            Ce(e, "closed")
        },
        title: a.jsx(yt, {
            currentPane: r,
            popPane: p,
            url: (u = e.merchant) == null ? void 0 : u.url,
            faviconUrl: (l = e.merchant) == null ? void 0 : l.logoUrl,
            title: (y = (M = e.merchant) == null ? void 0 : M.title) != null ? y : "",
            subtitle: (m = (b = e.merchant) == null ? void 0 : b.subtitle) != null ? m : "",
            subtitlePrefix: (h = e.merchant) == null ? void 0 : h.subtitlePrefix,
            subtitleUrl: (x = e.merchant) == null ? void 0 : x.subtitleUrl,
            PANES: ys
        }),
        children: a.jsx(xt, {
            grandTotal: e.grandTotal.value_minor > 0 ? e.grandTotal.value_minor : (w = (C = (g = e.totals) == null ? void 0 : g.find(P => P.type === "subtotal")) == null ? void 0 : C.value_minor) != null ? w : 0,
            merchantExternalId: (R = (T = e.merchant) == null ? void 0 : T.externalId) != null ? R : "",
            merchantNetworkId: (j = (O = e.merchant) == null ? void 0 : O.networkId) != null ? j : "",
            merchantTitle: (N = (A = e.merchant) == null ? void 0 : A.title) != null ? N : "",
            paymentMethodTypes: c,
            clientThreadId: _,
            fetchSession: () => Yt({
                intl: i,
                store: e,
                clientThreadId: _
            }),
            children: ({
                loadingCartSession: P,
                cartLoadError: I
            }) => a.jsx(xs, {
                paneStack: n,
                pushPane: d,
                store: e,
                loadingCartSession: P,
                cartLoadError: I,
                resetPanes: f
            })
        })
    })
}

function xs({
    paneStack: t,
    pushPane: e,
    store: s,
    loadingCartSession: n,
    cartLoadError: i,
    resetPanes: r
}) {
    var l, M;
    const [d, p] = S.useState(!pe(s, s.shippingAddress)), [f, o] = S.useState(!((l = s.paymentDetails) != null && l.complete)), [c, _] = S.useState(null), v = Gt({
        namespace: "shopping_checkout"
    }), u = (n || f || d) && !i;
    return S.useEffect(() => {
        var y, b, m, h, x;
        if (s.isCheckoutOpen && !u && s.cartMetadata && s.cartId) {
            const g = s.items[0];
            V.logEventWithStatsig("product_checkout", "product_checkout", E(k({}, G(s.cartMetadata)), {
                checkout_id: s.cartId,
                merchant_name: (y = s.merchant) == null ? void 0 : y.title,
                merchant_url: (b = s.merchant) == null ? void 0 : b.url,
                hadSavedPaymentMethod: !!((m = s.paymentDetails) != null && m.complete),
                items: [{
                    quantity: g.quantity.toString(),
                    price: "price" in g ? g.price : void 0,
                    variants: "variant" in g ? g.variant : void 0,
                    product_id: g.id,
                    product_title: "title" in g ? g.title : void 0
                }],
                action: "shown"
            })), v.endBlock("shown", {
                context: {
                    merchant_id: (h = s.merchant) == null ? void 0 : h.externalId,
                    merchant_network_id: (x = s.merchant) == null ? void 0 : x.networkId,
                    cart_total: s.grandTotal.value,
                    product_id: "productId" in g ? g.productId : void 0
                }
            })
        }
    }, [(M = s.cartMetadata) == null ? void 0 : M.clientThreadId, s.isCheckoutOpen, s.cartId, u]), a.jsx("div", {
        className: "relative w-full",
        children: a.jsx(Mt, {
            className: "min-h-[755px] w-full",
            paneStack: t,
            useDelayedEnteringPane: !0,
            alwaysMountedPanes: ["paymentMethod", "overview", "shippingAddress"],
            renderPane: y => {
                switch (y) {
                    case "overview":
                        return a.jsx(ns, {
                            store: s,
                            pushPane: b => {
                                s.setErrors([]), _(null), e(b)
                            },
                            loadingCartSession: n,
                            loadingPayment: f,
                            loadingAddress: d,
                            cartLoadError: i,
                            stripeLoadingError: c,
                            merchant: s.merchant,
                            footerMessage: s.footerMessage,
                            isCurrentPane: t.currentPane === "overview"
                        });
                    case "paymentMethod":
                        return !n && !i && a.jsx(ms, {
                            store: s,
                            pushPane: e,
                            resetPanes: r,
                            loadingPayment: f,
                            setLoadingPayment: o,
                            loadingAddress: d,
                            setStripeLoadingError: _,
                            isCurrentPane: t.currentPane === "paymentMethod"
                        });
                    case "shippingAddress":
                        return !n && !i && a.jsx(gs, {
                            store: s,
                            resetPanes: r,
                            setLoadingAddress: p,
                            loadingPayment: f,
                            setStripeLoadingError: _,
                            isCurrentPane: t.currentPane === "shippingAddress"
                        });
                    case "shippingMethod":
                        return a.jsx(fs, {
                            shippingMethods: s.shippingOptions,
                            store: s,
                            resetPanes: r
                        })
                }
            }
        })
    })
}
const ys = {
        overview: {
            name: {
                id: "shopping-checkout.pane.overview.title",
                defaultMessage: "Overview",
                description: "Title for shopping checkout overview pane"
            }
        },
        shippingAddress: {
            name: {
                id: "shopping-checkout.pane.shippingAddress.title",
                defaultMessage: "Add Shipping Address",
                description: "Title for shopping checkout shipping address pane"
            }
        },
        shippingMethod: {
            name: {
                id: "shopping-checkout.pane.shippingMethod.title",
                defaultMessage: "Select Shipping Method",
                description: "Title for shopping checkout shipping method pane"
            }
        },
        paymentMethod: {
            name: {
                id: "shopping-checkout.pane.paymentMethod.title",
                defaultMessage: "Add payment method",
                description: "Title for shopping checkout payment method pane"
            }
        }
    },
    Is = Object.freeze(Object.defineProperty({
        __proto__: null,
        CheckoutModal: _s
    }, Symbol.toStringTag, {
        value: "Module"
    }));
export {
    Is as s, Kt as u
};
//# sourceMappingURL=ipesqf5fzqgtmnar.js.map