const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/be77pdhx09jbnbg6.js", "assets/fg33krlcm0qyi6yw.js"]))) => i.map(i => d[i]);
var E = Object.defineProperty,
    _ = Object.defineProperties;
var P = Object.getOwnPropertyDescriptors;
var u = Object.getOwnPropertySymbols;
var w = Object.prototype.hasOwnProperty,
    y = Object.prototype.propertyIsEnumerable;
var d = (a, e, n) => e in a ? E(a, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : a[e] = n,
    l = (a, e) => {
        for (var n in e || (e = {})) w.call(e, n) && d(a, n, e[n]);
        if (u)
            for (var n of u(e)) y.call(e, n) && d(a, n, e[n]);
        return a
    },
    s = (a, e) => _(a, P(e));
import {
    _ as C
} from "./fg33krlcm0qyi6yw.js";
import {
    g8 as v,
    gU as A,
    iR as I,
    R as V,
    _ as h
} from "./dykg4ktvbu3mhmdo.js";
const f = () => C(async () => {
        const {
            default: a
        } = await
        import ("./be77pdhx09jbnbg6.js").then(e => e.p);
        return {
            default: a
        }
    }, __vite__mapDeps([0, 1])).then(({
        default: a
    }) => a.Client),
    q = v(a => {
        const e = A(a);
        return I(a, {
            mutationFn: async () => {
                const n = {};
                return e && (n["Chatgpt-Account-Id"] = e.id), await V.safePost("/compliance/age_verification/persona/inquiries", {
                    additionalHeaders: n,
                    requestBody: {
                        enabled: !0
                    }
                })
            }
        })
    }),
    z = async a => {
        const e = await f(),
            n = new e(s(l({
                environmentId: "env_zetVzkozoWTNEz2HmxyPjJ1AH85w"
            }, a), {
                onError: t => {
                    var c;
                    h.addError(t, {
                        area: "persona.age_verification.flow",
                        action: "open"
                    }), (c = a.onError) == null || c.call(a, t)
                }
            }));
        return n.open(), m(n), n
    },
    L = (a, e) => {
        let n = null;

        function t() {
            n == null || n.destroy(), n = null
        }
        async function c() {
            f().catch(() => {});
            const i = await q(a).mutate();
            if (i.isError || !i.data) return;
            const {
                id: g
            } = i.data;
            n = await z(s(l({}, e), {
                inquiryId: g,
                onCancel: (...o) => {
                    var r;
                    t(), (r = e == null ? void 0 : e.onCancel) == null || r.call(e, ...o)
                },
                onComplete: (...o) => {
                    var r;
                    t(), (r = e == null ? void 0 : e.onComplete) == null || r.call(e, ...o)
                }
            })), n.open(), m(n)
        }
        return c(), () => t()
    };

function m(a) {
    let e = null;
    "containerElement" in a && a.containerElement instanceof HTMLElement && (e = a.containerElement), e && (e.style.pointerEvents = "auto", e.focus())
}
export {
    z as g, L as s
};
//# sourceMappingURL=flbjosd8n90k89o3.js.map