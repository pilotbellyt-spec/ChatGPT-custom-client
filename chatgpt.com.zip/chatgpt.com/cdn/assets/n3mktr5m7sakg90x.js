var y = Object.defineProperty;
var m = Object.getOwnPropertySymbols;
var M = Object.prototype.hasOwnProperty,
    R = Object.prototype.propertyIsEnumerable;
var b = (i, t, n) => t in i ? y(i, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : i[t] = n,
    h = (i, t) => {
        for (var n in t || (t = {})) M.call(t, n) && b(i, n, t[n]);
        if (m)
            for (var n of m(t)) R.call(t, n) && b(i, n, t[n]);
        return i
    };
import {
    j as _,
    e as j,
    r as E,
    M as S,
    L as T
} from "./fg33krlcm0qyi6yw.js";
import {
    aW as W,
    T as f,
    l as D,
    cX as O,
    iq as B,
    bc as F,
    bd as N,
    P as I,
    c as d
} from "./dykg4ktvbu3mhmdo.js";
import {
    x as U,
    h as V
} from "./jb9b7tatrnyq635u.js";
import {
    s as g
} from "./cmaobpdpreyiep8p.js";

function u(i) {
    var t;
    return (t = i == null ? void 0 : i.rate_limit) != null ? t : null
}

function k(i) {
    var t;
    return (t = i == null ? void 0 : i.credits) != null ? t : null
}

function A(i) {
    const t = u(i),
        n = [];
    return t != null && t.primary_window && n.push(t.primary_window), t != null && t.secondary_window && n.push(t.secondary_window), n
}

function v(i) {
    const t = A(i);
    return t.length === 0 ? null : t.reduce((n, a) => n ? a.used_percent > n.used_percent ? a : n : a)
}

function G(i) {
    var t, n;
    return (n = (t = v(i)) == null ? void 0 : t.reset_after_seconds) != null ? n : null
}

function H(i) {
    var t, n;
    return (n = (t = v(i)) == null ? void 0 : t.used_percent) != null ? n : null
}

function x(i) {
    var s;
    const t = u(i),
        n = k(i),
        a = !(n != null && n.unlimited) && !(Number((s = n == null ? void 0 : n.balance) != null ? s : 0) >= 20 || n != null && n.has_credits);
    return ((t == null ? void 0 : t.limit_reached) === !0 || (t == null ? void 0 : t.allowed) === !1) && a
}

function C(i, t = 80) {
    var l, o;
    if (!u(i)) return !1;
    if (x(i)) return !0;
    const a = k(i);
    if (Number((o = (l = k(i)) == null ? void 0 : l.balance) != null ? o : 0) > 0 || a != null && a.unlimited || a != null && a.has_credits) return !1;
    const s = H(i);
    return typeof s == "number" ? s >= t : !1
}

function X(i) {
    try {
        const {
            hourCycle: t,
            hour12: n
        } = new Intl.DateTimeFormat(i, {
            hour: "numeric"
        }).resolvedOptions(), a = {
            h23: !0,
            h24: !0,
            h11: !1,
            h12: !1
        };
        if (t && t in a) return a[t];
        if (typeof n == "boolean") return !n
    } catch (t) {}
    return null
}

function q(i, t) {
    const n = Math.max(t, 0),
        a = new Date,
        c = new Date(a.getTime() + n * 1e3),
        s = c.getFullYear() === a.getFullYear() && c.getMonth() === a.getMonth() && c.getDate() === a.getDate(),
        l = X(i.locale),
        o = {
            hour: "numeric",
            minute: "2-digit"
        };
    l != null && (o.hour12 = !l);
    const r = i.formatTime(c, o),
        p = i.formatDate(c, {
            dateStyle: "medium"
        });
    return s ? r : "".concat(p, " ").concat(r)
}

function K() {
    var c;
    const {
        data: i
    } = U(s => ({
        staleTime: 0,
        refetchInterval: C(s) ? 6e4 : void 0,
        refetchOnWindowFocus: !0
    })), t = V(s => !!s._forcedRateLimit), n = (c = i == null ? void 0 : i.rate_limit) != null ? c : null, a = C(i);
    return !n || !a ? null : _.jsx(z, {
        resetAfterSeconds: G(i),
        limitReached: x(i),
        hasForcedRateLimit: t
    })
}

function z({
    resetAfterSeconds: i,
    limitReached: t = !1,
    hasForcedRateLimit: n = !1
}) {
    const a = j(),
        c = W(),
        [s, l] = E.useState(!1),
        o = i != null ? a.formatMessage({
            id: "Vdw3Zf",
            defaultMessage: "Resets {time}"
        }, {
            time: q(a, i)
        }) : null;
    return _.jsx(f, {
        open: c ? s : void 0,
        onOpenChange: l,
        label: o != null ? o : a.formatMessage({
            id: "z90MsD",
            defaultMessage: "Usage resets soon"
        }),
        children: _.jsxs("div", {
            className: D("inline-flex items-center gap-1.5 rounded-full py-2 ps-3 pe-3.5 text-sm font-medium", t ? "bg-token-text-status-error/15 text-token-text-status-error" : "bg-token-text-status-warning/15 text-token-text-status-warning"),
            onClick: c ? () => l(r => !r) : void 0,
            children: [_.jsxs("div", {
                className: "flex items-center gap-1.5",
                children: [_.jsx(O, {
                    className: "icon"
                }), t ? _.jsx(S, {
                    id: "JH4ShQ",
                    defaultMessage: "Usage limit reached"
                }) : _.jsx(S, {
                    id: "k4kW93",
                    defaultMessage: "Usage nearing limit"
                })]
            }), location.pathname !== "/codex/settings/usage" && _.jsx(f, {
                label: a.formatMessage({
                    id: "jqcjgs",
                    defaultMessage: "Open usage settings"
                }),
                children: _.jsx(T, {
                    to: "/codex/settings/usage",
                    "aria-label": a.formatMessage({
                        id: "Xo2nko",
                        defaultMessage: "Open usage settings"
                    }),
                    children: _.jsx(B, {
                        className: "icon-sm"
                    })
                })
            }), !1]
        })
    })
}
class e {
    static countEventWithStatsC(t, n = [], a = 1) {
        F.count(N.CODEX, t, Object.fromEntries(Object.entries(n).map(([c, s]) => [c, String(s)])), a)
    }
    static logEventWithStatsig(t, n, a) {
        I.logEventWithStatsig(t, n, a)
    }
    static recordGitAction(t, n, a, c, s, l = "regular", o, r) {
        const p = h(h({
            action: t,
            mode: l,
            task_id: c,
            turn_id: s
        }, o ? {
            message_id: o
        } : {}), r ? {
            conversation_id: r
        } : {});
        e.logEventWithStatsig("chatgpt_wham_git_action", "chatgpt_wham_git_action", p);
        const w = [{
            key: "action",
            value: t
        }];
        e.countEventWithStatsC("chatgpt_wham_git_action", w, a), e.countEventWithStatsC("chatgpt_wham_git_action", w, n)
    }
    static recordWhamTileAction(t) {
        const n = {
            action: t
        };
        e.logEventWithStatsig("chatgpt_wham_tile_action", "chatgpt_wham_tile_action", n), e.countEventWithStatsC("chatgpt_wham_tile_action", [{
            key: "action",
            value: t
        }])
    }
    static recordWhamSystemHintAction(t, n) {
        const a = h({
            action: t
        }, n ? {
            conversation_id: n
        } : {});
        e.logEventWithStatsig("chatgpt_wham_system_hint_action", "chatgpt_wham_system_hint_action", a), e.countEventWithStatsC("chatgpt_wham_system_hint_action", [{
            key: "action",
            value: t
        }])
    }
    static recordConnectionsClickSetupMfa() {
        e.logEventWithStatsig("onboarding.connections.click_setup_mfa", "onboarding.connections.click_setup_mfa", {}), e.countEventWithStatsC("onboarding.connections.click_setup_mfa")
    }
    static recordConnectionsClickConnectGithub() {
        e.logEventWithStatsig("onboarding.connections.click_connect_github", "onboarding.connections.click_connect_github", {}), e.countEventWithStatsC("onboarding.connections.click_connect_github")
    }
    static recordClickUseEnvironment() {
        e.logEventWithStatsig("chatgpt_wham_click_use_environment", "chatgpt_wham_click_use_environment", {}), e.countEventWithStatsC("chatgpt_wham_click_use_environment")
    }
    static recordConnectionsView() {
        e.logEventWithStatsig("onboarding.connections.view", "onboarding.connections.view", {}), e.countEventWithStatsC("onboarding.connections.view")
    }
    static recordClickEnv() {
        e.logEventWithStatsig("onboarding.click_go_to_environment", "onboarding.click_go_to_environment", {}), e.countEventWithStatsC("onboarding.click_go_to_environment")
    }
    static recordDataCheckGoBack() {
        e.logEventWithStatsig("onboarding.data_check.click_go_back", "onboarding.data_check.click_go_back", {}), e.countEventWithStatsC("onboarding.data_check.click_go_back")
    }
    static recordDataCheckContinue() {
        e.logEventWithStatsig("onboarding.data_check.click_continue", "onboarding.data_check.click_continue", {}), e.countEventWithStatsC("onboarding.data_check.click_continue")
    }
    static recordDataCheckView() {
        e.logEventWithStatsig("onboarding.data_check.view", "onboarding.data_check.view", {}), e.countEventWithStatsC("onboarding.data_check.view")
    }
    static recordCreateEnvSuccess() {
        e.logEventWithStatsig("onboarding.environments.create_success", "onboarding.environments.create_success", {}), e.countEventWithStatsC("onboarding.environments.create_success")
    }
    static recordEnvironmentsView() {
        e.logEventWithStatsig("onboarding.environments.view", "onboarding.environments.view", {}), e.countEventWithStatsC("onboarding.environments.view")
    }
    static recordEnvironmentsSubmit() {
        e.logEventWithStatsig("onboarding.environments.submit", "onboarding.environments.submit", {}), e.countEventWithStatsC("onboarding.environments.submit")
    }
    static recordStarterTasksView() {
        e.logEventWithStatsig("onboarding.starter_tasks.view", "onboarding.starter_tasks.view", {}), e.countEventWithStatsC("onboarding.starter_tasks.view")
    }
    static recordStarterTasksClickComplete(t) {
        e.logEventWithStatsig("onboarding.starter_tasks.click_complete", "onboarding.starter_tasks.click_complete", {
            with_starter_tasks: String(t)
        }), e.countEventWithStatsC("onboarding.starter_tasks.click_complete", [{
            key: "with_starter_tasks",
            value: String(t)
        }])
    }
    static recordOnboardingView() {
        e.logEventWithStatsig("onboarding.view", "onboarding.view", {}), e.countEventWithStatsC("onboarding.view")
    }
    static recordClickGetStarted() {
        e.logEventWithStatsig("onboarding.click_get_started", "onboarding.click_get_started", {}), e.countEventWithStatsC("onboarding.click_get_started")
    }
    static recordDataCheckToggle(t) {
        e.logEventWithStatsig("onboarding.data_check.toggle_value", "onboarding.data_check.toggle_value", {
            enabled: String(t)
        }), e.countEventWithStatsC("onboarding.data_check.toggle_value", [{
            key: "enabled",
            value: String(t)
        }])
    }
    static recordProposedTaskClicked(t) {
        e.logEventWithStatsig("chatgpt_wham_proposed_task_clicked", "chatgpt_wham_proposed_task_clicked", {
            action: t
        }), e.countEventWithStatsC("chatgpt_wham_proposed_task_clicked", [{
            key: "action",
            value: t
        }])
    }
    static recordLandingPageShown() {
        e.logEventWithStatsig("chatgpt_wham_landing_page_shown", "chatgpt_wham_landing_page_shown", {}), e.countEventWithStatsC("chatgpt_wham_landing_page_shown")
    }
    static recordCodexCodeReviewLandingPageShown() {
        e.logEventWithStatsig("chatgpt_codex_code_review_landing_page_shown", "chatgpt_codex_code_review_landing_page_shown", {}), e.countEventWithStatsC("chatgpt_codex_code_review_landing_page_shown")
    }
    static recordComposerAction(t) {
        e.logEventWithStatsig("chatgpt_wham_composer_action", "chatgpt_wham_composer_action", {
            action: t
        }), e.countEventWithStatsC("chatgpt_wham_composer_action", [{
            key: "action",
            value: t
        }])
    }
    static recordCancel(t) {
        e.logEventWithStatsig("chatgpt_wham_composer_action", "chatgpt_wham_composer_action", {
            location: t
        }), e.countEventWithStatsC("chatgpt_wham_composer_action", [{
            key: "location",
            value: t
        }])
    }
    static recordUpgradeToTryItButtonClicked() {
        e.logEventWithStatsig("chatgpt_wham_upgrade_to_try_it_button_clicked", "chatgpt_wham_upgrade_to_try_it_button_clicked", {}), e.countEventWithStatsC("chatgpt_wham_upgrade_to_try_it_button_clicked")
    }
    static recordLogInButtonClicked() {
        e.logEventWithStatsig("chatgpt_wham_log_in_button_clicked", "chatgpt_wham_log_in_button_clicked", {}), e.countEventWithStatsC("chatgpt_wham_log_in_button_clicked")
    }
    static recordLearnMoreLinkClicked() {
        e.logEventWithStatsig("chatgpt_wham_learn_more_link_clicked", "chatgpt_wham_learn_more_link_clicked", {}), e.countEventWithStatsC("chatgpt_wham_learn_more_link_clicked")
    }
    static recordFollowUpsSeen(t, n, a) {
        e.logEventWithStatsig("chatgpt_wham_follow_ups_seen", "chatgpt_wham_follow_ups_seen", {
            count: String(a),
            task_id: t,
            turn_id: n
        }), e.countEventWithStatsC("chatgpt_wham_follow_ups_seen")
    }
    static recordFollowUpsExpanded(t, n) {
        e.logEventWithStatsig("chatgpt_wham_follow_ups_expanded", "chatgpt_wham_follow_ups_expanded", {
            task_id: t,
            turn_id: n
        }), e.countEventWithStatsC("chatgpt_wham_follow_ups_expanded")
    }
    static recordFollowUpsClicked(t, n, a, c) {
        e.logEventWithStatsig("chatgpt_wham_follow_ups_clicked", "chatgpt_wham_follow_ups_clicked", {
            task_id: t,
            turn_id: n,
            index: String(a),
            severity: c
        }), e.countEventWithStatsC("chatgpt_wham_follow_ups_clicked")
    }
    static recordSlackLinkClicked() {
        e.logEventWithStatsig("chatgpt_wham_slack_link_clicked", "chatgpt_wham_slack_link_clicked", {}), e.countEventWithStatsC("chatgpt_wham_slack_link_clicked")
    }
    static recordPreviewImagesCarouselNext() {
        e.countEventWithStatsC("wham.preview_images.click_next")
    }
    static recordPreviewImagesCarouselPrev() {
        e.countEventWithStatsC("wham.preview_images.click_prev")
    }
}
const P = d(g, "d3a21b", 16, 16),
    L = d(g, "6e38ac", 16, 16),
    tt = d(g, "2e166e", 16, 16),
    et = d(g, "48254b", 16, 16);
export {
    et as B, e as W, C as a, K as b, tt as c, L as d, P as e, q as f, G as g, x as i
};
//# sourceMappingURL=n3mktr5m7sakg90x.js.map