var E = Object.defineProperty;
var I = (r, n, a) => n in r ? E(r, n, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: a
}) : r[n] = a;
var f = (r, n, a) => I(r, typeof n != "symbol" ? n + "" : n, a);
import {
    gh as R,
    c3 as h,
    c4 as $,
    dQ as T,
    i_ as P,
    h as O,
    b7 as j,
    bc as B,
    bd as F,
    P as M,
    lx as N
} from "./dykg4ktvbu3mhmdo.js";
import {
    il as _,
    im as v
} from "./k15yxxoybkkir2ou.js";
import "./fg33krlcm0qyi6yw.js";
const Q = r => {
        const [n] = _(T(r), R({
            path: h,
            args: a => {
                const [c] = _(h(a), $);
                return c != null ? c : {}
            }
        }));
        return n
    },
    W = r => {
        var n;
        try {
            const a = T(r);
            return a && (n = JSON.parse(a)) != null ? n : void 0
        } catch (a) {
            return null
        }
    },
    S = r => {
        var n, a;
        return (a = (n = r.metadata) == null ? void 0 : n.chatgpt_sdk) == null ? void 0 : a.tool_response_metadata
    },
    V = (r, n) => {
        for (const a of r.values())
            for (const c of a)
                if (c.id === n) return c;
        return null
    };
class A {
    constructor(n) {
        f(this, "focusedMessageId$", O(null, {
            equals: () => !1
        }));
        f(this, "focusedMessages$", j(() => {
            const n = N(this.conversation),
                a = this.focusedMessageId$();
            if (!a) return [];
            const c = t => {
                    var e;
                    return t.author.role === "assistant" && !!((e = t.recipient) != null && e.startsWith("api_tool"))
                },
                p = t => t.author.role === "tool" && typeof t.author.name == "string",
                g = (t, e) => p(t) && typeof e.recipient == "string" && t.author.name === e.recipient,
                k = t => {
                    var i;
                    const e = W(t);
                    if ((((i = t.metadata) == null ? void 0 : i.chatgpt_sdk) != null ? v(t.metadata.chatgpt_sdk) : null) != null) return !0;
                    const o = S(t);
                    return o && typeof o == "object" && "elicitation" in o ? !0 : e != null
                },
                b = t => {
                    var o;
                    if ((((o = t.metadata) == null ? void 0 : o.chatgpt_sdk) != null ? v(t.metadata.chatgpt_sdk) : null) != null) return !0;
                    const s = S(t);
                    return !!(s && typeof s == "object" && "elicitation" in s)
                },
                C = (t, e) => {
                    const s = t[e];
                    for (let o = e + 1; o < t.length; o += 1) {
                        const i = t[o];
                        if (c(i)) break;
                        if (g(i, s) && k(i)) return o
                    }
                    return null
                },
                x = (t, e) => {
                    const s = t[e];
                    if (c(s)) return e;
                    if (p(s))
                        for (let o = e - 1; o >= 0; o -= 1) {
                            const i = t[o];
                            if (c(i) && g(s, i)) return o
                        }
                    for (let o = e; o >= 0; o -= 1)
                        if (c(t[o])) return o;
                    return null
                },
                w = (t, e) => {
                    for (let s = e + 1; s < t.length; s += 1)
                        if (c(t[s])) return s;
                    return t.length
                };
            for (const t of n) {
                const e = t.messages,
                    s = e.findIndex(l => l.id === a);
                if (s === -1) continue;
                const o = x(e, s);
                if (o == null) continue;
                const i = w(e, o);
                let m = 0,
                    u = s;
                for (; u >= 0 && !c(e[u]); u -= 1);
                for (let l = u; l >= 0; l -= 1) {
                    if (!c(e[l])) continue;
                    const d = C(e, l);
                    if (d == null) continue;
                    const y = e[d];
                    if (b(y)) {
                        m = d + 1;
                        break
                    }
                }
                return e.slice(m, i)
            }
            return []
        }));
        this.conversation = n
    }
    focusMessage$(n) {
        B.count(F.ECOSYSTEM, "dev_mode_inspector.opened"), M.logEventWithStatsig("Ecosystem app: Open dev mode inspector", "chatgpt_web_ecosystem_dev_mode_inspector_opened"), this.focusedMessageId$.set(n)
    }
    blur() {
        this.focusedMessageId$.set(null)
    }
}
const Y = P(r => new A(r));
export {
    V as a, W as b, S as c, Y as g, Q as p
};
//# sourceMappingURL=gry8j32h87k624fm.js.map