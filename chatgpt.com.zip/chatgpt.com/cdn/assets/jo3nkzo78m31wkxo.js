var oe = Object.defineProperty,
    ie = Object.defineProperties;
var ae = Object.getOwnPropertyDescriptors;
var Mt = Object.getOwnPropertySymbols;
var re = Object.prototype.hasOwnProperty,
    le = Object.prototype.propertyIsEnumerable;
var Wt = (e, t, s) => t in e ? oe(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : e[t] = s,
    Dt = (e, t) => {
        for (var s in t || (t = {})) re.call(t, s) && Wt(e, s, t[s]);
        if (Mt)
            for (var s of Mt(t)) le.call(t, s) && Wt(e, s, t[s]);
        return e
    },
    Ht = (e, t) => ie(e, ae(t));
import {
    r as p,
    n as ce,
    e as de,
    j as m,
    c as Yt
} from "./fg33krlcm0qyi6yw.js";
import {
    d as kt,
    b as Z,
    kq as me,
    Z as Ut,
    wp as ue,
    fN as $t,
    dF as J,
    kh as fe,
    h7 as he,
    kF as pe,
    mn as xe,
    kH as Xt,
    gF as ge,
    aK as Gt,
    bv as Ce,
    wq as Te,
    bg as I,
    qt as ve
} from "./dykg4ktvbu3mhmdo.js";
import {
    hl as jt,
    qF as be,
    qG as Jt,
    hm as _e,
    C as S,
    qH as ye,
    qI as Ie,
    l5 as Se,
    qJ as we,
    qK as Ee,
    qL as Ae,
    qM as Ne,
    qE as Re,
    qN as Fe,
    qO as qe,
    qP as De,
    qQ as zt,
    qR as Qt,
    qC as Oe,
    u as ke,
    hf as Lt,
    qS as Vt,
    qT as Kt,
    qU as je,
    qV as Le,
    qW as Pe
} from "./k15yxxoybkkir2ou.js";
import {
    L as Me
} from "./bxjmpsz2dryfouus.js";
import {
    T as We
} from "./kz8g43osloy7fyhi.js";
import {
    g as He
} from "./bj1ejin6tzi0v3v8.js";
import "./o589vqy9dgmjuag5.js";
import "./ce3hgmw4iyyhicud.js";
import "./mstl8wgfzorpgdoe.js";
import "./f2sn8zvpzei2915e.js";
import "./kfdkis1zwf4ccfgg.js";
import "./ol9d5wxhynx9q2is.js";
import "./mbmcx8v24u1ao1ke.js";
import "./ieglwgr2zyuektzv.js";
import "./coi95al0vrqe13ds.js";
import "./l09h2qppleubii6l.js";
import "./deakbbf27g8e7ba0.js";
import "./kwqlokvhsdnnmw9d.js";
import "./jsd0vs4cv2vks3ah.js";
import "./kl7c6054usfnqmd4.js";
import "./k97n0y6ba9c9h39c.js";
import "./jjqluv6nhf16nnr9.js";
import "./iwhq2rihp0137gzf.js";
import "./h1j5sazq8s0md41z.js";
import "./f76gy0b8ieo4s693.js";
import "./ovpdmx71kjznjdh8.js";
import "./nh559o9htk2jfyt0.js";
import "./nf79rzyd6jobmpxe.js";
import "./kyjerv6rln8oin0o.js";
import "./iv26jzbt1vvl49kt.js";
import "./eo73z75xc7fd61fn.js";
import "./ns51nblw8ziscsgd.js";
import "./b2l059fz4znz94nm.js";
import "./hzx735z33xljaym3.js";
import "./bx8o5u3qhj3ykfih.js";
import "./ktlrbeajo849nxci.js";
import "./loeoawlgsw5vcwar.js";
import "./m77bejnre58pj934.js";
import "./jc2eye6u0uwos0uk.js";
import "./aozfqr1i52mjkof3.js";
import "./eaak105t3h6pgvs1.js";
import "./i5kvudettvxsr7pw.js";
import "./hz9475nc5ndyfqsu.js";
import "./ou2xm3xmri21t4zm.js";
import "./irqko7c1s7qpl41n.js";
import "./e1qtg70ehhxpvvw9.js";
import "./l13qvsuc1mktoblg.js";
import "./jlu292yvnhcpthaw.js";
import "./k2oaaf8ac9lafsub.js";
import "./lans8a2ikbh9ax9r.js";
import "./f78b2oufkmgyeo1t.js";
import "./ew68kf01y1h7e4uk.js";
import "./ib78f9d5brp6znzf.js";
import "./njpaiih217owxm7n.js";
const Bt = "oai/apps/canmoreSidebarWidth",
    Ue = .25,
    Ge = 400,
    Zt = 400;

function te(e) {
    return e - Ge
}

function Tt(e, t) {
    return ue(Zt, te(e), t != null ? t : Ue * e)
}

function ze() {
    const e = Z(),
        t = kt(() => jt(e).width),
        s = Tt(t, me(Ut.DANGER_SECRET_FOLDERS_ONLY_getItem(Bt))),
        r = ee(),
        [n, a] = p.useState(s);
    p.useEffect(() => {
        (n < Zt || n > te(t)) && a(Tt(t, n))
    }, [t]);

    function o(d) {
        a(f => Tt(t, f += d.delta.x))
    }

    function i(d) {
        a(d), Ut.DANGER_SECRET_FOLDERS_ONLY_setItem(Bt, d)
    }

    function l() {
        const d = Tt(t, void 0);
        i(d)
    }
    const c = "calc(100vw - ".concat(n, "px)");
    return r ? {
        chatWidth: n,
        canvasWidth: t - n,
        canvasWidthCalc: c,
        viewportWidth: t,
        handleDrag: o,
        handleDoubleClick: l,
        persist: i
    } : {
        chatWidth: 0,
        canvasWidth: t,
        canvasWidthCalc: "100vw",
        viewportWidth: t,
        handleDrag: () => {},
        handleDoubleClick: () => {},
        persist: () => {}
    }
}

function ee(e) {
    const t = Z();
    return kt(() => (e != null ? e : jt(t).width) > 1e3)
}
const Ot = "sharedCanvas";

function Ve() {
    const [e, t] = ce(), s = e.get(Ot), r = de();
    p.useEffect(() => {
        const n = s && be.createRemixTempTextdoc(s, r);
        if (!n) return;
        requestAnimationFrame(() => {
            Jt(n)
        });
        const a = new URLSearchParams(e);
        a.delete(Ot), t(a);
        const o = new URL(window.location.href);
        o.searchParams.delete(Ot), history.replaceState(null, "", o)
    }, [s, e, t, r])
}
const Ke = "textdocId",
    Be = e => {
        const s = new URLSearchParams(window.location.search).get(Ke),
            r = $t(e, n => {
                var a, o, i;
                return (i = (o = (a = J.findNode(n, ({
                    message: l
                }) => {
                    var d;
                    const c = (d = l.metadata) == null ? void 0 : d.canvas;
                    return (c == null ? void 0 : c.create_source) === _e.HIVE && (s ? (c == null ? void 0 : c.textdoc_id) === s : !0)
                })) == null ? void 0 : a.message.metadata) == null ? void 0 : o.canvas) == null ? void 0 : i.textdoc_id
            });
        p.useEffect(() => {
            r && requestAnimationFrame(() => {
                Jt(r)
            })
        }, [r])
    };

function Ye(e, t) {
    let s;
    return (t == null ? void 0 : t.type) === S.Textdoc && (t.textdocId.startsWith(ye) || (s = {
        type: "canvas_textdoc",
        id: t.textdocId
    })), Ie(e, {
        promptMessage: {
            metadata: {
                open_in_canvas_view: s
            }
        }
    })
}
const se = ({
        isFullScreen: e = !1,
        clientThreadId: t,
        focusedObject: s,
        onClose: r,
        isAnimating: n = !1,
        width: a
    }) => {
        const {
            setTargetedContent: o
        } = Se(), i = p.useRef(!1);
        if (p.useEffect(() => (i.current && o(void 0), i.current = !0, () => {
                i.current = !1
            }), [s]), s == null) return null;
        switch (s.type) {
            case S.Textdoc:
                return m.jsx(We, {
                    isFullScreen: e,
                    onClose: r,
                    clientThreadId: t,
                    focusedTextdoc: s,
                    isAnimating: n,
                    width: a
                });
            case S.ADAVisualization:
                return null
        }
    },
    $e = 300,
    Xe = e => {
        switch (e == null ? void 0 : e.type) {
            case S.Textdoc:
                return e.textdocId;
            default:
                return null
        }
    };

function Je({
    clientThreadId: e,
    isDisabled: t,
    disabledTypes: s
}) {
    const [r, n, a, o, i] = $t(e, x => [J.getRequestId(x), J.getConversationLastTurn(x), J.isMessageTurnEnded(x), J.getVariantIds(x).length > 1, J.lastUserMessage(x)], {
        disablePerfDetector: !0
    }), l = fe(r), c = we(), [d, f] = p.useMemo(() => {
        if (n && o) return [void 0, null];
        if (t === !0) return [void 0, null];
        if (i != null) {
            const C = Ee(i);
            if (C) return [i.id, {
                type: S.Textdoc,
                textdocId: C
            }]
        }
        let x;
        return !a && n && (x = he(n.messageGroups, C => C.type !== pe)), Qe({
            groupedMessage: x,
            isRequestActive: l,
            latestTextdocId: c,
            disabledTypes: s
        })
    }, [a, n, o, t, l, c, s, i]), u = f != null, bt = Xe(f), _t = Ae("canvas");
    p.useEffect(() => {
        if (f && d && !xe() && (_t(), Ne(f, d), f.type === S.Textdoc)) {
            const {
                textdocId: x
            } = f, C = He(x);
            Re(document.getElementById(C))
        }
    }, [u, bt])
}

function Qe({
    groupedMessage: e,
    isRequestActive: t,
    latestTextdocId: s,
    disabledTypes: r
}) {
    var n, a;
    if (e != null && e.type && r.includes(e.type)) return [void 0, null];
    switch (e == null ? void 0 : e.type) {
        case Xt.Canmore:
            {
                const [o, i] = e.messages;
                if (!Fe(o)) break;
                const l = qe(t, o, i != null ? i : null),
                    c = (n = l.textdocId) != null ? n : s;
                if (c && (l.function === De.CreateTextdoc ? ((a = l.content) != null ? a : "").length > $e || l.status === zt.WAITING : l.status === zt.STREAMING)) return [l.messageId, {
                    type: S.Textdoc,
                    textdocId: c
                }];
                break
            }
    }
    return [void 0, null]
}
const vt = {
        type: "spring",
        bounce: .12
    },
    Ze = {
        type: "spring",
        bounce: 0
    },
    y = {
        duration: 0
    },
    ts = e => {
        "use forget";
        const t = Yt.c(112),
            {
                clientThreadId: s,
                focusedObject: r,
                onClose: n
            } = e,
            a = Z(),
            {
                chatWidth: o,
                canvasWidthCalc: i,
                handleDrag: l,
                handleDoubleClick: c,
                persist: d
            } = ze();
        let f;
        t[0] !== a ? (f = Lt(a), t[0] = a, t[1] = f) : f = t[1];
        const u = f,
            [bt, _t] = p.useState(!u),
            [x, C] = p.useState(!1),
            yt = u ? y : vt,
            It = u ? y : Ze,
            T = je(os);
        let tt;
        t[2] !== a ? (tt = () => jt(a), t[2] = a, t[3] = tt) : tt = t[3];
        const {
            height: v,
            width: w
        } = kt(tt);
        let et;
        t[4] !== o || t[5] !== v || t[6] !== T || t[7] !== w ? (et = T != null ? T : {
            top: 0,
            left: o,
            width: w - o,
            height: v
        }, t[4] = o, t[5] = v, t[6] = T, t[7] = w, t[8] = et) : et = t[8];
        let h = et,
            Pt = !1;
        if (T && (h.top < 0 || h.top + h.height > v)) {
            Pt = !0;
            const xt = (w - o) * .75,
                Q = v * .75;
            let gt;
            t[9] !== xt || t[10] !== Q ? (gt = {
                width: xt,
                height: Q
            }, t[9] = xt, t[10] = Q, t[11] = gt) : gt = t[11];
            const _ = gt,
                Ft = v / 2 - _.height / 2,
                qt = (w - o - _.width) / 2 + o;
            let Ct;
            t[12] !== _.height || t[13] !== _.width || t[14] !== Ft || t[15] !== qt ? (Ct = {
                top: Ft,
                left: qt,
                width: _.width,
                height: _.height
            }, t[12] = _.height, t[13] = _.width, t[14] = Ft, t[15] = qt, t[16] = Ct) : Ct = t[16], h = Ct
        }
        const g = T == null ? void 0 : T.borderRadius,
            b = Le(),
            St = (b == null ? void 0 : b.history) != null || (b == null ? void 0 : b.showChangesAtVersion) != null,
            ne = ve();
        let E;
        t[17] !== b || t[18] !== St ? (E = St && m.jsx(Me, {
            onClick: () => Pe(b.textdocId),
            zIndexKey: "chatOverlay"
        }), t[17] = b, t[18] = St, t[19] = E) : E = t[19];
        const wt = ne ? -260 : 0;
        let A;
        t[20] !== wt ? (A = {
            marginInlineEnd: wt
        }, t[20] = wt, t[21] = A) : A = t[21];
        let st;
        t[22] === Symbol.for("react.memo_cache_sentinel") ? (st = {
            marginInlineEnd: 0
        }, t[22] = st) : st = t[22];
        let nt, ot, it;
        t[23] === Symbol.for("react.memo_cache_sentinel") ? (ot = {
            opacity: 1
        }, it = {
            opacity: 0
        }, nt = {
            opacity: [1, 0]
        }, t[23] = nt, t[24] = ot, t[25] = it) : (nt = t[23], ot = t[24], it = t[25]);
        let N;
        t[26] !== u ? (N = u ? y : Ht(Dt({}, vt), {
            delay: .22
        }), t[26] = u, t[27] = N) : N = t[27];
        let R;
        t[28] !== N ? (R = m.jsx(I.div, {
            initial: ot,
            animate: it,
            exit: nt,
            transition: N,
            className: "bg-token-main-surface-primary pointer-events-none absolute start-0 top-0 z-20 h-full w-full"
        }), t[28] = N, t[29] = R) : R = t[29];
        let F;
        t[30] !== i ? (F = {
            width: i
        }, t[30] = i, t[31] = F) : F = t[31];
        let at;
        t[32] === Symbol.for("react.memo_cache_sentinel") ? (at = {
            width: 0
        }, t[32] = at) : at = t[32];
        let q;
        t[33] !== u ? (q = u ? y : {
            type: "spring",
            bounce: 0
        }, t[33] = u, t[34] = q) : q = t[34];
        let D;
        t[35] !== F || t[36] !== q ? (D = m.jsx(I.div, {
            className: "relative z-20 h-full",
            style: F,
            exit: at,
            transition: q
        }), t[35] = F, t[36] = q, t[37] = D) : D = t[37];
        let O;
        t[38] !== It || t[39] !== R || t[40] !== D || t[41] !== A ? (O = m.jsxs(I.div, {
            initial: A,
            animate: st,
            transition: It,
            children: [R, D]
        }), t[38] = It, t[39] = R, t[40] = D, t[41] = A, t[42] = O) : O = t[42];
        const Et = Pt ? 0 : 1;
        let k;
        t[43] !== g || t[44] !== h.height || t[45] !== h.left || t[46] !== h.top || t[47] !== h.width || t[48] !== Et ? (k = {
            borderRadius: g,
            opacity: Et,
            x: h.left,
            y: h.top,
            height: h.height,
            width: h.width
        }, t[43] = g, t[44] = h.height, t[45] = h.left, t[46] = h.top, t[47] = h.width, t[48] = Et, t[49] = k) : k = t[49];
        let j;
        t[50] !== i || t[51] !== o || t[52] !== v ? (j = {
            opacity: 1,
            x: o,
            y: 0,
            width: i,
            height: v,
            borderRadius: 0
        }, t[50] = i, t[51] = o, t[52] = v, t[53] = j) : j = t[53];
        let L;
        t[54] !== u ? (L = u ? y : {
            opacity: {
                type: "spring",
                bounce: .1
            }
        }, t[54] = u, t[55] = L) : L = t[55];
        let P;
        t[56] !== g || t[57] !== L ? (P = {
            scale: .64,
            opacity: 0,
            filter: "blur(12px)",
            transition: L,
            borderRadius: g
        }, t[56] = g, t[57] = L, t[58] = P) : P = t[58];
        const At = x || u ? y : vt;
        let rt;
        t[59] === Symbol.for("react.memo_cache_sentinel") ? (rt = () => _t(!1), t[59] = rt) : rt = t[59];
        let M;
        t[60] !== g ? (M = {
            borderRadius: g
        }, t[60] = g, t[61] = M) : M = t[61];
        let lt;
        t[62] === Symbol.for("react.memo_cache_sentinel") ? (lt = {
            borderRadius: 0
        }, t[62] = lt) : lt = t[62];
        let W;
        t[63] !== g ? (W = {
            borderRadius: g
        }, t[63] = g, t[64] = W) : W = t[64];
        let ct, dt;
        t[65] === Symbol.for("react.memo_cache_sentinel") ? (ct = {
            opacity: .5
        }, dt = {
            opacity: .75,
            width: "8px",
            left: "-4px"
        }, t[65] = ct, t[66] = dt) : (ct = t[65], dt = t[66]);
        let H;
        t[67] !== u ? (H = u ? y : {
            type: "tween",
            duration: .1
        }, t[67] = u, t[68] = H) : H = t[68];
        let mt;
        t[69] === Symbol.for("react.memo_cache_sentinel") ? (mt = {
            x: 0,
            y: 0,
            transform: "translateX(0px)"
        }, t[69] = mt) : mt = t[69];
        let ut, ft, ht;
        t[70] === Symbol.for("react.memo_cache_sentinel") ? (ut = {
            left: 0,
            right: 0,
            top: 0,
            bottom: 0
        }, ft = () => C(!0), ht = () => C(!1), t[70] = ut, t[71] = ft, t[72] = ht) : (ut = t[70], ft = t[71], ht = t[72]);
        let U;
        t[73] !== l ? (U = (xt, Q) => l(Q), t[73] = l, t[74] = U) : U = t[74];
        let G;
        t[75] !== o || t[76] !== d ? (G = () => {
            C(!1), d(o)
        }, t[75] = o, t[76] = d, t[77] = G) : G = t[77];
        let z;
        t[78] !== c ? (z = () => c(), t[78] = c, t[79] = z) : z = t[79];
        let V;
        t[80] !== H || t[81] !== U || t[82] !== G || t[83] !== z ? (V = m.jsx(I.div, {
            drag: "x",
            className: "bg-token-text-quaternary absolute start-[-2px] z-10 h-full w-[4px] cursor-ew-resize opacity-0",
            whileHover: ct,
            whileDrag: dt,
            transition: H,
            style: mt,
            dragMomentum: !1,
            dragSnapToOrigin: !1,
            dragElastic: !1,
            dragConstraints: ut,
            onPointerDown: ft,
            onPointerUp: ht,
            onDrag: U,
            onDragEnd: G,
            onDoubleClick: z
        }), t[80] = H, t[81] = U, t[82] = G, t[83] = z, t[84] = V) : V = t[84];
        let K;
        t[85] !== x ? (K = x && m.jsx("div", {
            className: "absolute inset-0 z-10"
        }), t[85] = x, t[86] = K) : K = t[86];
        const Nt = !u && bt,
            Rt = w - o;
        let B;
        t[87] !== s || t[88] !== r || t[89] !== n || t[90] !== Nt || t[91] !== Rt ? (B = m.jsx(se, {
            onClose: n,
            clientThreadId: s,
            isAnimating: Nt,
            focusedObject: r,
            width: Rt
        }), t[87] = s, t[88] = r, t[89] = n, t[90] = Nt, t[91] = Rt, t[92] = B) : B = t[92];
        let Y;
        t[93] !== V || t[94] !== K || t[95] !== B ? (Y = m.jsxs("div", {
            className: "h-full",
            children: [V, K, B]
        }), t[93] = V, t[94] = K, t[95] = B, t[96] = Y) : Y = t[96];
        let $;
        t[97] !== M || t[98] !== W || t[99] !== Y || t[100] !== yt ? ($ = m.jsx(I.div, {
            className: "dark:border-token-border-light border-token-border-medium h-full overflow-hidden border-s",
            initial: M,
            animate: lt,
            exit: W,
            transition: yt,
            children: Y
        }), t[97] = M, t[98] = W, t[99] = Y, t[100] = yt, t[101] = $) : $ = t[101];
        let X;
        t[102] !== k || t[103] !== j || t[104] !== P || t[105] !== At || t[106] !== $ ? (X = m.jsx(I.div, {
            className: "bg-token-bg-primary absolute start-0 z-20 h-full overflow-hidden shadow-[0_0_18px_rgba(0,0,0,0.12)] dark:shadow-[0_0_18px_rgba(0,0,0,0.48)]",
            initial: k,
            animate: j,
            exit: P,
            transition: At,
            onAnimationComplete: rt,
            children: $
        }), t[102] = k, t[103] = j, t[104] = P, t[105] = At, t[106] = $, t[107] = X) : X = t[107];
        let pt;
        return t[108] !== O || t[109] !== E || t[110] !== X ? (pt = m.jsxs(m.Fragment, {
            children: [E, O, X]
        }), t[108] = O, t[109] = E, t[110] = X, t[111] = pt) : pt = t[111], pt
    },
    es = p.memo(ts),
    ss = e => {
        "use forget";
        const t = Yt.c(9),
            {
                clientThreadId: s,
                focusedObject: r,
                onClose: n
            } = e,
            a = Z(),
            o = Lt(a);
        let i, l;
        t[0] === Symbol.for("react.memo_cache_sentinel") ? (i = {
            scale: .98
        }, l = {
            scale: 1
        }, t[0] = i, t[1] = l) : (i = t[0], l = t[1]);
        const c = o ? y : vt;
        let d;
        t[2] !== s || t[3] !== r || t[4] !== n ? (d = m.jsx(se, {
            isFullScreen: !0,
            clientThreadId: s,
            focusedObject: r,
            onClose: n
        }), t[2] = s, t[3] = r, t[4] = n, t[5] = d) : d = t[5];
        let f;
        return t[6] !== c || t[7] !== d ? (f = m.jsx(Te, {
            open: !0,
            className: "fixed inset-0 z-50 h-full w-full",
            children: m.jsx(I.div, {
                className: "z-40 h-full w-full overflow-hidden shadow-xl md:border-gray-100 md:dark:border-gray-700",
                initial: i,
                animate: l,
                transition: c,
                children: d
            })
        }), t[6] = c, t[7] = d, t[8] = f) : f = t[8], f
    },
    ns = ({
        clientThreadId: e,
        overrideWidth: t,
        isAutoFocusDisabled: s = !1
    }) => {
        const r = Z(),
            n = ke(),
            a = ee(t),
            o = Lt(r);
        Je({
            clientThreadId: e,
            isDisabled: s,
            disabledTypes: o ? [Xt.Canmore] : []
        }), Ve(), Be(e);
        const i = p.useRef(!1);
        p.useEffect(() => {
            i.current ? Qt() : i.current = !0
        }, [e]);
        const l = n && (a ? m.jsx(es, {
            clientThreadId: e,
            onClose: Kt,
            focusedObject: n
        }, "canvas-sidebar") : m.jsx(ss, {
            clientThreadId: e,
            onClose: Kt,
            focusedObject: n
        }, "canvas-modal"));
        p.useEffect(() => {
            if (n) return Vt(d => Ye(d, n)), () => Vt(null)
        }, [n]);
        const c = l != null;
        return p.useEffect(() => (Gt.setActiveStageSidebar(c), () => {
            c && Gt.setActiveStageSidebar(!1)
        }), [c]), o ? l : m.jsx(Ce, {
            children: l
        }, e)
    },
    rn = e => {
        const t = p.useRef(null);
        return m.jsx(ge, {
            ref: t,
            onError: (s, r) => {
                Qt(), setTimeout(() => {
                    var n;
                    (n = t.current) == null || n.resetErrorBoundary()
                }), Oe.logError("Error boundary hit", s, {
                    componentStack: r
                })
            },
            name: "canmore-focused-view",
            children: m.jsx(ns, Dt({}, e))
        })
    };

function os(e) {
    const {
        rect: t
    } = e;
    return t
}
export {
    rn as CanvasFocusedViewManager
};
//# sourceMappingURL=jo3nkzo78m31wkxo.js.map