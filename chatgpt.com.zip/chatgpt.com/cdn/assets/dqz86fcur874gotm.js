var P = Object.defineProperty,
    C = Object.defineProperties;
var H = Object.getOwnPropertyDescriptors;
var d = Object.getOwnPropertySymbols;
var V = Object.prototype.hasOwnProperty,
    v = Object.prototype.propertyIsEnumerable;
var T = (e, t, a) => t in e ? P(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: a
    }) : e[t] = a,
    n = (e, t) => {
        for (var a in t || (t = {})) V.call(t, a) && T(e, a, t[a]);
        if (d)
            for (var a of d(t)) v.call(t, a) && T(e, a, t[a]);
        return e
    },
    x = (e, t) => C(e, H(t));
import {
    c5 as w,
    gn as L
} from "./k15yxxoybkkir2ou.js";
import {
    u as U
} from "./jed1ux7qibe55pmj.js";
import {
    t as B
} from "./17v8usp0o68l1lsz.js";
import {
    t as F
} from "./hu1bt0oauegdhua6.js";

function G(e) {
    const t = this;
    t.compiler = a;

    function a(i) {
        return B(i, x(n(n({}, t.data("settings")), e), {
            extensions: t.data("toMarkdownExtensions") || []
        }))
    }
}
const D = "codex-file-citation",
    S = "codex-terminal-citation",
    W = "task-stub",
    y = "codex-image-citation",
    O = () => e => {
        w(e, t => {
            var i, c, o, _, l, u, m, p, h, g, E, b, I, f, M, k, A, N, R;
            if (!L(t)) return;
            const a = (i = t.data) != null ? i : t.data = {};
            switch (t.name) {
                case D:
                    {
                        a.hName = D;
                        const r = parseInt((o = (c = t.attributes) == null ? void 0 : c.line_range_start) != null ? o : "0", 10),
                            s = parseInt((m = (u = (_ = t.attributes) == null ? void 0 : _.line_range_end) != null ? u : (l = t.attributes) == null ? void 0 : l.line_range_start) != null ? m : "0", 10);a.hProperties = {
                            path: (p = t.attributes) == null ? void 0 : p.path,
                            lineRangeStart: r,
                            lineRangeEnd: s,
                            gitUrl: (h = t.attributes) == null ? void 0 : h.git_url
                        };
                        break
                    }
                case S:
                    {
                        a.hName = S;
                        const r = parseInt((E = (g = t.attributes) == null ? void 0 : g.line_range_start) != null ? E : "0", 10),
                            s = parseInt((M = (f = (b = t.attributes) == null ? void 0 : b.line_range_end) != null ? f : (I = t.attributes) == null ? void 0 : I.line_range_start) != null ? M : "0", 10);a.hProperties = {
                            chunkId: (k = t.attributes) == null ? void 0 : k.terminal_chunk_id,
                            lineRangeStart: r,
                            lineRangeEnd: s
                        };
                        break
                    }
                case W:
                    {
                        let r;
                        try {
                            r = U().use(G).stringify({
                                type: "root",
                                children: t.children
                            })
                        } catch (s) {
                            r = F({
                                type: "root",
                                children: (A = t.children) != null ? A : []
                            })
                        }
                        a.hName = W,
                        a.hProperties = {
                            title: (N = t.attributes) == null ? void 0 : N.title,
                            prompt: r
                        };
                        break
                    }
                case y:
                    {
                        a.hName = y,
                        a.hProperties = {
                            assetPointer: (R = t.attributes) == null ? void 0 : R.asset_pointer
                        };
                        break
                    }
            }
        })
    };
export {
    y as W, D as a, S as b, G as c, W as d, O as r
};
//# sourceMappingURL=dqz86fcur874gotm.js.map