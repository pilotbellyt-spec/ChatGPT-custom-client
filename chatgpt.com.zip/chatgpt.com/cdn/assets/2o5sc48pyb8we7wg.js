var m = Object.freeze,
    x = Object.defineProperty;
var t = (r, o) => m(x(r, "raw", {
    value: m(o || r.slice())
}));
import {
    j as e,
    M as b
} from "./fg33krlcm0qyi6yw.js";
import {
    cr as f,
    cs as p
} from "./k15yxxoybkkir2ou.js";
import {
    F as d,
    T as g,
    l as h,
    i6 as j
} from "./dykg4ktvbu3mhmdo.js";
var c;
const w = d.textarea(c || (c = t(["w-full text-sm overflow-y-auto rounded-lg border px-3 py-2 focus:ring-2 focus:ring-blue-400 border-token-border-medium bg-token-main-surface-primary h-32"])));
var l;
const F = d.div(l || (l = t(["mb-6"])));
var u;
const C = d.input(u || (u = t(["w-full resize-none overflow-y-auto rounded-lg px-3 py-2 text-sm outline-hidden focus:ring-2 border focus:ring-blue-400 border-token-border-medium h-9 bg-token-main-surface-primary"])));

function I({
    label: r,
    description: o,
    collapsed: s,
    onClick: i,
    htmlFor: n
}) {
    const a = e.jsx("label", {
        htmlFor: n,
        className: "text-token-text-primary block font-semibold",
        children: r
    });
    return e.jsxs("div", {
        className: "mb-1.5 flex items-center",
        onClick: i,
        children: [s !== void 0 && (s ? e.jsx(p, {
            className: "icon-sm"
        }) : e.jsx(f, {
            className: "icon-sm"
        })), o ? e.jsx(g, {
            label: o,
            side: "top",
            children: a
        }) : e.jsx(e.Fragment, {
            children: a
        })]
    })
}

function M({
    actionTool: r,
    onShowActionsEditor: o,
    isDisabled: s,
    className: i
}) {
    var a;
    const n = "metadata" in r ? (a = r.metadata) == null ? void 0 : a.domain : void 0;
    return e.jsxs("div", {
        className: h("border-token-border-medium flex rounded-lg border text-sm hover:cursor-pointer", s ? "bg-token-main-surface-secondary" : "", i),
        onClick: o,
        children: [e.jsx("div", {
            className: "h-9 grow px-3 py-2",
            children: n != null ? n : e.jsx("span", {
                className: "text-red-500",
                children: e.jsx(b, {
                    id: "TJYXrY",
                    defaultMessage: "Invalid action"
                })
            })
        }), e.jsx("div", {
            className: "bg-token-border-medium w-px"
        }), e.jsx("button", {
            disabled: s,
            className: "flex h-9 w-9 items-center justify-center rounded-lg rounded-s-none",
            children: e.jsx(j, {
                className: "icon-sm"
            })
        })]
    })
}
export {
    F,
    M as G,
    I as a,
    C as b,
    w as c
};
//# sourceMappingURL=2o5sc48pyb8we7wg.js.map