function h() {}
h.prototype = {
    diff: function(e, r) {
        var t, o = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {},
            u = o.callback;
        typeof o == "function" && (u = o, o = {});
        var i = this;

        function s(v) {
            return v = i.postProcess(v, o), u ? (setTimeout(function() {
                u(v)
            }, 0), !0) : v
        }
        e = this.castInput(e, o), r = this.castInput(r, o), e = this.removeEmpty(this.tokenize(e, o)), r = this.removeEmpty(this.tokenize(r, o));
        var f = r.length,
            a = e.length,
            l = 1,
            c = f + a;
        o.maxEditLength != null && (c = Math.min(c, o.maxEditLength));
        var C = (t = o.timeout) !== null && t !== void 0 ? t : 1 / 0,
            g = Date.now() + C,
            m = [{
                oldPos: -1,
                lastComponent: void 0
            }],
            p = this.extractCommon(m[0], r, e, 0, o);
        if (m[0].oldPos + 1 >= a && p + 1 >= f) return s(B(i, m[0].lastComponent, r, e, i.useLongestToken));
        var d = -1 / 0,
            T = 1 / 0;

        function D() {
            for (var v = Math.max(d, -l); v <= Math.min(T, l); v += 2) {
                var y = void 0,
                    w = m[v - 1],
                    E = m[v + 1];
                w && (m[v - 1] = void 0);
                var A = !1;
                if (E) {
                    var F = E.oldPos - v;
                    A = E && 0 <= F && F < f
                }
                var V = w && w.oldPos + 1 < a;
                if (!A && !V) {
                    m[v] = void 0;
                    continue
                }
                if (!V || A && w.oldPos < E.oldPos ? y = i.addToPath(E, !0, !1, 0, o) : y = i.addToPath(w, !1, !0, 1, o), p = i.extractCommon(y, r, e, v, o), y.oldPos + 1 >= a && p + 1 >= f) return s(B(i, y.lastComponent, r, e, i.useLongestToken));
                m[v] = y, y.oldPos + 1 >= a && (T = Math.min(T, v - 1)), p + 1 >= f && (d = Math.max(d, v + 1))
            }
            l++
        }
        if (u)(function v() {
            setTimeout(function() {
                if (l > c || Date.now() > g) return u();
                D() || v()
            }, 0)
        })();
        else
            for (; l <= c && Date.now() <= g;) {
                var x = D();
                if (x) return x
            }
    },
    addToPath: function(e, r, t, o, u) {
        var i = e.lastComponent;
        return i && !u.oneChangePerToken && i.added === r && i.removed === t ? {
            oldPos: e.oldPos + o,
            lastComponent: {
                count: i.count + 1,
                added: r,
                removed: t,
                previousComponent: i.previousComponent
            }
        } : {
            oldPos: e.oldPos + o,
            lastComponent: {
                count: 1,
                added: r,
                removed: t,
                previousComponent: i
            }
        }
    },
    extractCommon: function(e, r, t, o, u) {
        for (var i = r.length, s = t.length, f = e.oldPos, a = f - o, l = 0; a + 1 < i && f + 1 < s && this.equals(t[f + 1], r[a + 1], u);) a++, f++, l++, u.oneChangePerToken && (e.lastComponent = {
            count: 1,
            previousComponent: e.lastComponent,
            added: !1,
            removed: !1
        });
        return l && !u.oneChangePerToken && (e.lastComponent = {
            count: l,
            previousComponent: e.lastComponent,
            added: !1,
            removed: !1
        }), e.oldPos = f, a
    },
    equals: function(e, r, t) {
        return t.comparator ? t.comparator(e, r) : e === r || t.ignoreCase && e.toLowerCase() === r.toLowerCase()
    },
    removeEmpty: function(e) {
        for (var r = [], t = 0; t < e.length; t++) e[t] && r.push(e[t]);
        return r
    },
    castInput: function(e) {
        return e
    },
    tokenize: function(e) {
        return Array.from(e)
    },
    join: function(e) {
        return e.join("")
    },
    postProcess: function(e) {
        return e
    }
};

function B(n, e, r, t, o) {
    for (var u = [], i; e;) u.push(e), i = e.previousComponent, delete e.previousComponent, e = i;
    u.reverse();
    for (var s = 0, f = u.length, a = 0, l = 0; s < f; s++) {
        var c = u[s];
        if (c.removed) c.value = n.join(t.slice(l, l + c.count)), l += c.count;
        else {
            if (!c.added && o) {
                var C = r.slice(a, a + c.count);
                C = C.map(function(g, m) {
                    var p = t[l + m];
                    return p.length > g.length ? p : g
                }), c.value = n.join(C)
            } else c.value = n.join(r.slice(a, a + c.count));
            a += c.count, c.added || (l += c.count)
        }
    }
    return u
}

function Z(n, e) {
    var r;
    for (r = 0; r < n.length && r < e.length; r++)
        if (n[r] != e[r]) return n.slice(0, r);
    return n.slice(0, r)
}

function G(n, e) {
    var r;
    if (!n || !e || n[n.length - 1] != e[e.length - 1]) return "";
    for (r = 0; r < n.length && r < e.length; r++)
        if (n[n.length - (r + 1)] != e[e.length - (r + 1)]) return n.slice(-r);
    return n.slice(-r)
}

function N(n, e, r) {
    if (n.slice(0, e.length) != e) throw Error("string ".concat(JSON.stringify(n), " doesn't start with prefix ").concat(JSON.stringify(e), "; this is a bug"));
    return r + n.slice(e.length)
}

function J(n, e, r) {
    if (!e) return n + r;
    if (n.slice(-e.length) != e) throw Error("string ".concat(JSON.stringify(n), " doesn't end with suffix ").concat(JSON.stringify(e), "; this is a bug"));
    return n.slice(0, -e.length) + r
}

function L(n, e) {
    return N(n, e, "")
}

function O(n, e) {
    return J(n, e, "")
}

function H(n, e) {
    return e.slice(0, Q(n, e))
}

function Q(n, e) {
    var r = 0;
    n.length > e.length && (r = n.length - e.length);
    var t = e.length;
    n.length < e.length && (t = n.length);
    var o = Array(t),
        u = 0;
    o[0] = 0;
    for (var i = 1; i < t; i++) {
        for (e[i] == e[u] ? o[i] = o[u] : o[i] = u; u > 0 && e[i] != e[u];) u = o[u];
        e[i] == e[u] && u++
    }
    u = 0;
    for (var s = r; s < n.length; s++) {
        for (; u > 0 && n[s] != e[u];) u = o[u];
        n[s] == e[u] && u++
    }
    return u
}
var I = "a-zA-Z0-9_\\u{C0}-\\u{FF}\\u{D8}-\\u{F6}\\u{F8}-\\u{2C6}\\u{2C8}-\\u{2D7}\\u{2DE}-\\u{2FF}\\u{1E00}-\\u{1EFF}",
    U = new RegExp("[".concat(I, "]+|\\s+|[^").concat(I, "]"), "ug"),
    $ = new h;
$.equals = function(n, e, r) {
    return r.ignoreCase && (n = n.toLowerCase(), e = e.toLowerCase()), n.trim() === e.trim()
};
$.tokenize = function(n) {
    var e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {},
        r;
    if (e.intlSegmenter) {
        if (e.intlSegmenter.resolvedOptions().granularity != "word") throw new Error('The segmenter passed must have a granularity of "word"');
        r = Array.from(e.intlSegmenter.segment(n), function(u) {
            return u.segment
        })
    } else r = n.match(U) || [];
    var t = [],
        o = null;
    return r.forEach(function(u) {
        /\s/.test(u) ? o == null ? t.push(u) : t.push(t.pop() + u) : /\s/.test(o) ? t[t.length - 1] == o ? t.push(t.pop() + u) : t.push(o + u) : t.push(u), o = u
    }), t
};
$.join = function(n) {
    return n.map(function(e, r) {
        return r == 0 ? e : e.replace(/^\s+/, "")
    }).join("")
};
$.postProcess = function(n, e) {
    if (!n || e.oneChangePerToken) return n;
    var r = null,
        t = null,
        o = null;
    return n.forEach(function(u) {
        u.added ? t = u : u.removed ? o = u : ((t || o) && P(r, o, t, u), r = u, t = null, o = null)
    }), (t || o) && P(r, o, t, null), n
};

function P(n, e, r, t) {
    if (e && r) {
        var o = e.value.match(/^\s*/)[0],
            u = e.value.match(/\s*$/)[0],
            i = r.value.match(/^\s*/)[0],
            s = r.value.match(/\s*$/)[0];
        if (n) {
            var f = Z(o, i);
            n.value = J(n.value, i, f), e.value = L(e.value, f), r.value = L(r.value, f)
        }
        if (t) {
            var a = G(u, s);
            t.value = N(t.value, s, a), e.value = O(e.value, a), r.value = O(r.value, a)
        }
    } else if (r) n && (r.value = r.value.replace(/^\s*/, "")), t && (t.value = t.value.replace(/^\s*/, ""));
    else if (n && t) {
        var l = t.value.match(/^\s*/)[0],
            c = e.value.match(/^\s*/)[0],
            C = e.value.match(/\s*$/)[0],
            g = Z(l, c);
        e.value = L(e.value, g);
        var m = G(L(l, g), C);
        e.value = O(e.value, m), t.value = N(t.value, l, m), n.value = J(n.value, l, l.slice(0, l.length - m.length))
    } else if (t) {
        var p = t.value.match(/^\s*/)[0],
            d = e.value.match(/\s*$/)[0],
            T = H(d, p);
        e.value = O(e.value, T)
    } else if (n) {
        var D = n.value.match(/\s*$/)[0],
            x = e.value.match(/^\s*/)[0],
            v = H(D, x);
        e.value = L(e.value, v)
    }
}
var X = new h;
X.tokenize = function(n) {
    var e = new RegExp("(\\r?\\n)|[".concat(I, "]+|[^\\S\\n\\r]+|[^").concat(I, "]"), "ug");
    return n.match(e) || []
};
var q = new h;
q.tokenize = function(n, e) {
    e.stripTrailingCr && (n = n.replace(/\r\n/g, "\n"));
    var r = [],
        t = n.split(/(\n|\r\n)/);
    t[t.length - 1] || t.pop();
    for (var o = 0; o < t.length; o++) {
        var u = t[o];
        o % 2 && !e.newlineIsToken ? r[r.length - 1] += u : r.push(u)
    }
    return r
};
q.equals = function(n, e, r) {
    return r.ignoreWhitespace ? ((!r.newlineIsToken || !n.includes("\n")) && (n = n.trim()), (!r.newlineIsToken || !e.includes("\n")) && (e = e.trim())) : r.ignoreNewlineAtEof && !r.newlineIsToken && (n.endsWith("\n") && (n = n.slice(0, -1)), e.endsWith("\n") && (e = e.slice(0, -1))), h.prototype.equals.call(this, n, e, r)
};

function W(n, e, r) {
    return q.diff(n, e, r)
}
var Y = new h;
Y.tokenize = function(n) {
    return n.split(/(\S.+?[.!?])(?=\s+|$)/)
};
var _ = new h;
_.tokenize = function(n) {
    return n.split(/([{}:;,]|\s+)/)
};

function R(n) {
    "@babel/helpers - typeof";
    return R = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
        return typeof e
    } : function(e) {
        return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    }, R(n)
}
var z = new h;
z.useLongestToken = !0;
z.tokenize = q.tokenize;
z.castInput = function(n, e) {
    var r = e.undefinedReplacement,
        t = e.stringifyReplacer,
        o = t === void 0 ? function(u, i) {
            return typeof i > "u" ? r : i
        } : t;
    return typeof n == "string" ? n : JSON.stringify(M(n, null, null, o), o, "  ")
};
z.equals = function(n, e, r) {
    return h.prototype.equals.call(z, n.replace(/,([\r\n])/g, "$1"), e.replace(/,([\r\n])/g, "$1"), r)
};

function M(n, e, r, t, o) {
    e = e || [], r = r || [], t && (n = t(o, n));
    var u;
    for (u = 0; u < e.length; u += 1)
        if (e[u] === n) return r[u];
    var i;
    if (Object.prototype.toString.call(n) === "[object Array]") {
        for (e.push(n), i = new Array(n.length), r.push(i), u = 0; u < n.length; u += 1) i[u] = M(n[u], e, r, t, o);
        return e.pop(), r.pop(), i
    }
    if (n && n.toJSON && (n = n.toJSON()), R(n) === "object" && n !== null) {
        e.push(n), i = {}, r.push(i);
        var s = [],
            f;
        for (f in n) Object.prototype.hasOwnProperty.call(n, f) && s.push(f);
        for (s.sort(), u = 0; u < s.length; u += 1) f = s[u], i[f] = M(n[f], e, r, t, f);
        e.pop(), r.pop()
    } else i = n;
    return i
}
var k = new h;
k.tokenize = function(n) {
    return n.slice()
};
k.join = k.removeEmpty = function(n) {
    return n
};
export {
    W as d
};
//# sourceMappingURL=deakbbf27g8e7ba0.js.map