var as = Object.defineProperty,
    ls = Object.defineProperties;
var rs = Object.getOwnPropertyDescriptors;
var qn = Object.getOwnPropertySymbols;
var gl = Object.prototype.hasOwnProperty,
    hl = Object.prototype.propertyIsEnumerable;
var fl = (e, t, n) => t in e ? as(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : e[t] = n,
    y = (e, t) => {
        for (var n in t || (t = {})) gl.call(t, n) && fl(e, n, t[n]);
        if (qn)
            for (var n of qn(t)) hl.call(t, n) && fl(e, n, t[n]);
        return e
    },
    M = (e, t) => ls(e, rs(t));
var ue = (e, t) => {
    var n = {};
    for (var l in e) gl.call(e, l) && t.indexOf(l) < 0 && (n[l] = e[l]);
    if (e != null && qn)
        for (var l of qn(e)) t.indexOf(l) < 0 && hl.call(e, l) && (n[l] = e[l]);
    return n
};
import {
    E as ie,
    r as a,
    j as I,
    B as Fl
} from "./fg33krlcm0qyi6yw.js";
let vl, Nn, De = typeof window < "u" && window.document && window.document.createElement ? a.useLayoutEffect : a.useEffect,
    Sn = e => (t, n) => "calc(" + t + " + (" + n + " - " + t + ") * " + e + ")",
    Ze = typeof window < "u" ? window.navigator.userAgent : null,
    Ot = "unknown",
    Re = "unknown";
if (typeof window < "u" && navigator.userAgentData) {
    var Ea;
    !((Ea = navigator.userAgentData.brands) === null || Ea === void 0) && Ea.some(e => e.brand === "Chromium") && (Ot = "chromium"), navigator.userAgentData.platform === "Android" && (Re = "android")
}
if (Re === "unknown" && (Ze != null && Ze.match(/android/i)) && (Re = "android"), Ot === "unknown" && (Ze != null && Ze.match(/Chrome/i) ? Ot = "chromium" : Ze != null && Ze.match(/Firefox/i) ? Ot = "gecko" : Ze != null && Ze.match(/Safari|iPhone/i) && (Ot = "webkit")), Ot === "webkit") {
    if (Ze != null && Ze.match(/iPhone/i)) Re = "ios";
    else if (Ze != null && Ze.match(/iPad/i)) Re = "ipados";
    else if (Ze != null && Ze.match(/Macintosh/i)) try {
        document == null || document.createEvent("TouchEvent"), Re = "ipados"
    } catch (e) {
        Re = "macos"
    }
}
var Bl = {};
Bl = {
    mapping: {
        Sheet: {
            componentName: "a",
            elementNames: {
                root: 0,
                view: 1,
                backdrop: 2,
                backdropTrap: 3,
                primaryScrollTrapRoot: 4,
                secondaryScrollTrapRoot: 5,
                scrollContainer: 6,
                frontSpacer: 7,
                backSpacer: 8,
                detentMarker: 9,
                contentWrapper: 10,
                content: 11,
                bleedingBackground: 12,
                stickyContainer: 13,
                sticky: 14,
                leftEdge: 15,
                trigger: 16,
                handle: 17,
                outlet: 18
            },
            variationSetsNames: {
                openness: "A",
                staging: "B",
                opennessClosedStatus: "C",
                position: "D",
                positionCoveredStatus: "E",
                placement: "F",
                track: "G",
                swipeDisabled: "H",
                swipeOutDisabledWithDetent: "I",
                swipeOvershootDisabled: "J",
                bleedDisabled: "K",
                inertOutside: "L",
                backdropSwipeable: "M",
                scrollContainerShouldBePassThrough: "N",
                swipeTrap: "M"
            },
            variationValuesNames: {
                open: "a",
                opening: "b",
                closed: "c",
                closing: "d",
                none: "e",
                top: "f",
                bottom: "g",
                left: "h",
                right: "i",
                horizontal: "j",
                vertical: "k",
                front: "l",
                covered: "m",
                true: "o",
                false: "p",
                auto: "q",
                center: "r",
                pending: "s",
                "flushing-to-preparing-open": "t",
                "flushing-to-preparing-opening": "u",
                "preparing-open": "v",
                "preparing-opening": "x",
                "safe-to-unmount": "y",
                content: "z",
                root: "aa",
                "going-down": "ab",
                "going-up": "ac",
                indeterminate: "ad",
                idle: "ae",
                "come-back": "af",
                out: "ag",
                stepping: "ah",
                both: "ai",
                none: "aj"
            }
        },
        ScrollTrap: {
            componentName: "b",
            elementNames: {
                root: 0,
                stabiliser: 1
            },
            variationSetsNames: {
                active: "A",
                axis: "B",
                automaticallyDisabledForOptimisation: "C"
            },
            variationValuesNames: {
                true: "a",
                false: "b",
                horizontal: "e",
                vertical: "f",
                both: "g",
                none: "h"
            }
        },
        Scroll: {
            componentName: "c",
            elementNames: {
                root: 0,
                view: 1,
                scrollContainer: 2,
                content: 3,
                UAScrollbarMeasurer: 4,
                spy: 5,
                startSpacer: 6,
                endSpacer: 7
            },
            variationSetsNames: {
                axis: "A",
                contentPlacement: "B",
                scrollTrapX: "C",
                scrollTrapY: "D",
                scrollGestureOvershoot: "E",
                scrollDisabled: "F",
                side: "G",
                pageScroll: "H",
                overflowX: "I",
                overflowY: "J",
                skipScrollAnimation: "K",
                scrollAnchoring: "L",
                scrollSnapType: "M",
                scrollPadding: "N",
                scrollTimelineName: "O",
                nativeScrollbar: "P",
                scrollOngoing: "Q"
            },
            variationValuesNames: {
                true: "a",
                false: "b",
                x: "c",
                y: "d",
                both: "e",
                unset: "f",
                contain: "g",
                start: "h",
                end: "i",
                center: "j",
                auto: "k",
                default: "l",
                none: "m",
                mandatoryX: "n",
                mandatoryY: "o",
                proximityX: "p",
                proximityY: "q"
            }
        },
        SlideShow: {
            componentName: "d",
            elementNames: {},
            variationSetsNames: {},
            variationValuesNames: {}
        },
        VisuallyHidden: {
            componentName: "e",
            elementNames: {
                root: 0
            },
            variationSetsNames: {},
            variationValuesNames: {}
        },
        SpecialWrapper: {
            componentName: "f",
            elementNames: {
                root: 0,
                content: 1
            },
            variationSetsNames: {},
            variationValuesNames: {}
        },
        Fixed: {
            componentName: "g",
            elementNames: {
                root: 0
            },
            variationSetsNames: {},
            variationValuesNames: {}
        },
        SheetStack: {
            componentName: "h",
            elementNames: {
                root: 0,
                outlet: 1
            },
            variationSetsNames: {},
            variationValuesNames: {}
        },
        AutoFocusTarget: {
            componentName: "i",
            elementNames: {
                root: 0
            },
            variationSetsNames: {},
            variationValuesNames: {}
        }
    }
};
let ia = Bl.mapping,
    ss = e => {
        var t;
        return (t = ia[e].componentName) !== null && t !== void 0 ? t : null
    },
    is = (e, t) => {
        var n;
        return (n = ia[e].elementNames[t]) !== null && n !== void 0 ? n : null
    },
    os = (e, t) => {
        var n;
        return (n = ia[e].variationSetsNames[t]) !== null && n !== void 0 ? n : null
    },
    us = (e, t) => {
        var n;
        return (n = ia[e].variationValuesNames[t]) !== null && n !== void 0 ? n : null
    },
    Xe = (e, t) => a.useCallback((n, l = [], i) => {
        var r, s;
        let o, u, c = (s = i == null || (r = i.dataSilk) === null || r === void 0 ? void 0 : r.filter(Boolean).join(" ")) !== null && s !== void 0 ? s : ""; {
            let p = ss(e);
            if (o = p + is(e, n), t)
                for (let m = 0; m < l.length; m++) {
                    let d = l[m],
                        f = t[d],
                        h = os(e, d),
                        k = us(e, f);
                    o += f != null ? " " + p + h + k : ""
                }
            u = {
                className: i == null ? void 0 : i.className,
                "data-silk": o + " " + c
            }
        }
        return u
    }, [e, ...t ? Object.values(t) : []]),
    In = new WeakMap;
var cs = typeof Float32Array == "function";

function Jn(e, t, n) {
    return (((1 - 3 * n + 3 * t) * e + (3 * n - 6 * t)) * e + 3 * t) * e
}

function kl(e, t, n) {
    return 3 * (1 - 3 * n + 3 * t) * e * e + 2 * (3 * n - 6 * t) * e + 3 * t
}

function ds(e) {
    return e
}
var Vl = function(e, t, n, l) {
    if (!(0 <= e && e <= 1 && 0 <= n && n <= 1)) throw Error("bezier x values must be in [0, 1] range");
    if (e === t && n === l) return ds;
    for (var i = cs ? new Float32Array(11) : Array(11), r = 0; r < 11; ++r) i[r] = Jn(.1 * r, e, n);
    return function(s) {
        return s === 0 || s === 1 ? s : Jn((function(o) {
            for (var u = 0, c = 1; c !== 10 && i[c] <= o; ++c) u += .1;
            var p = u + (o - i[--c]) / (i[c + 1] - i[c]) * .1,
                m = kl(p, e, n);
            return m >= .001 ? (function(d, f, h, k) {
                for (var v = 0; v < 4; ++v) {
                    var b = kl(f, h, k);
                    if (b === 0) break;
                    var C = Jn(f, h, k) - d;
                    f -= C / b
                }
                return f
            })(o, p, e, n) : m === 0 ? p : (function(d, f, h, k, v) {
                var b, C, A = 0;
                do(b = Jn(C = f + (h - f) / 2, k, v) - d) > 0 ? h = C : f = C; while (Math.abs(b) > 1e-7 && ++A < 10);
                return C
            })(o, u, u + .1, e, n)
        })(s), t, l)
    }
};
let la = e => typeof e == "string" ? document.querySelector(e) : e == null ? void 0 : e(),
    Wl = (e, t) => Array.isArray(e) ? e.includes(t) : e === t,
    Ia = e => (e == null ? void 0 : e.getAttribute("data-silk-clone")) === "true",
    ms = new Set(["checkbox", "radio", "range", "color", "file", "image", "button", "submit", "reset"]),
    ln = e => e instanceof HTMLInputElement && !ms.has(e.type) || e instanceof HTMLTextAreaElement || e instanceof HTMLElement && e.isContentEditable,
    bl = e => e instanceof HTMLInputElement && e.type === "color" || e instanceof HTMLSelectElement,
    Ba = typeof window < "u" && window.matchMedia("(prefers-reduced-motion: reduce)").matches,
    ra = () => {
        var e;
        return window.innerHeight - 200 > ((e = window.visualViewport) === null || e === void 0 ? void 0 : e.height)
    };

function St({
    nativeEvent: e,
    defaultBehavior: t,
    handler: n
}) {
    let l = t;
    if (n)
        if (typeof n == "function") {
            let i = M(y({}, t), {
                nativeEvent: e,
                changeDefault: function(r) {
                    l = y(y({}, t), r), Object.assign(this, r)
                }
            });
            i.changeDefault = i.changeDefault.bind(i), n(i)
        } else l = y(y({}, t), n);
    return l
}

function jl(e) {
    return (e.startsWith("rgb(") || e.startsWith("rgba(")) && e.endsWith(")") ? e.substring(e.indexOf("(") + 1, e.indexOf(")")).split(",").map(l => l.trim()).slice(0, 3).map(l => parseFloat(l)) : null
}
let Sl = e => {
        let t = null;
        return e.startsWith("rgb(") || e.startsWith("rgba(") ? t = jl(e) : e.startsWith("#") && (t = (function(n) {
            let l = n.replace(/^#/, ""),
                i = l.length === 3 ? l.split("").map(u => u + u).join("") : l;
            if (!/^[0-9A-Fa-f]{6}$/.test(i)) return null;
            let r = parseInt(i.slice(0, 2), 16),
                s = parseInt(i.slice(2, 4), 16),
                o = parseInt(i.slice(4, 6), 16);
            return [r, s, o]
        })(e)), t
    },
    ps = ({
        color: e,
        overlays: t
    }) => {
        let n = [...e],
            l = t.length;
        for (let i = 0; i < l; i++) {
            let r = t[i],
                s = r.alpha;
            for (let o = 0; o < 3; o++) n[o] = (1 - s) * n[o] + s * r.color[o]
        }
        return "rgb(" + n.join(",") + ")"
    },
    fs = e => {
        a.useEffect(() => {
            let t = () => {
                ra() ? e(!0) : e(!1)
            };
            return t(), visualViewport.addEventListener("resize", t), () => {
                visualViewport.removeEventListener("resize", t)
            }
        }, [e])
    },
    gs = e => e.matches('[data-silk~="0ad"]:not([data-silk~="0ai"]) *, [data-silk~="0ab"] *'),
    Ul = e => {
        let [t, n] = a.useState(!1), l = a.useCallback(i => {
            e.current && n(!!i && !gs(e.current))
        }, [e]);
        return fs(l), t
    },
    Yl = () => Re === "android" && Ot === "chromium" && typeof window < "u" && !window.matchMedia("(display-mode: standalone), (display-mode: minimal-ui), (display-mode: fullscreen)").matches,
    Xl = () => {
        var e, t, n;
        return typeof window < "u" && window.navigator.standalone && ((e = document.querySelector("meta[name='viewport']")) === null || e === void 0 ? void 0 : e.content.includes("viewport-fit=cover")) && ((t = document.querySelector("meta[name='apple-mobile-web-app-capable']")) === null || t === void 0 ? void 0 : t.content) === "yes" && ((n = document.querySelector("meta[name='apple-mobile-web-app-status-bar-style']")) === null || n === void 0 ? void 0 : n.content) === "black-translucent"
    },
    Rt = () => Ot === "webkit",
    hs = () => typeof document < "u" ? document.querySelector('meta[name="theme-color"]') : null,
    _n = ({
        genericContext: e,
        customContext: t,
        value: n,
        children: l
    }) => t ? I.jsx(t.Provider, {
        value: n,
        children: I.jsx(e.Provider, {
            value: n,
            children: l
        })
    }) : I.jsx(e.Provider, {
        value: n,
        children: l
    });
_n.displayName = "CustomisableContext";
let vs = (e, {
        duration: t,
        cubicBezier: n
    } = {
        duration: 500,
        cubicBezier: [.25, .1, .25, 1]
    }) => {
        let l = Vl(...n),
            i = null,
            r = (s, o) => {
                i || (i = s);
                let u = s - i,
                    c = l(u / t);
                u < t ? (o(c), requestAnimationFrame(() => r(document.timeline.currentTime, o))) : o(1)
            };
        r(document.timeline.currentTime, e)
    },
    yl = e => {
        let t = a.useRef(null);
        return De(() => {
            t.current = e
        }), a.useCallback((...n) => {
            let l = t.current;
            return l(...n)
        }, [])
    };

function Da(e) {
    for (let t = 0; t < e.length; t++)
        if (!e[t].matches('[data-silk~="0ad"]')) return e[t];
    return e[0]
}
let Hl = (e, t) => {
        var n;
        let {
            safelyFocusableElements: l,
            safelyTabbableElements: i
        } = oa(t, ["[data-silk~='0ac']"]), r = K.autoFocusTargets.filter(m => m.layerId === "any" || m.layerId === e), s = r.filter(m => Wl(m.timing, "present")), o = l.filter(m => s.map(d => d.element).includes(m)), u = Da(o), c = Da(i);
        ((n = u != null ? u : c) !== null && n !== void 0 ? n : t).focus({
            preventScroll: !0
        })
    },
    Cl = (e, t, n) => {
        let {
            focus: l
        } = St({
            nativeEvent: null,
            defaultBehavior: {
                focus: !0
            },
            handler: n
        });
        l && Hl(e, t)
    },
    ks = (e, t, n, l) => {
        if (!t.contains(document.activeElement) && document.contains(document.activeElement)) return;
        let {
            focus: i
        } = St({
            nativeEvent: null,
            defaultBehavior: {
                focus: !0
            },
            handler: n
        });
        if (i) {
            var r;
            let s = K.autoFocusTargets.filter(d => d.layerId === "any" || d.layerId === e),
                o = s.filter(d => Wl(d.timing, "dismiss") && !t.contains(d.element)),
                {
                    safelyFocusableElements: u
                } = oa(document.body),
                c = u.filter(d => o.map(f => f.element).includes(d)),
                p = Da(c);
            ((r = p != null ? p : l) !== null && r !== void 0 ? r : document.body).focus({
                preventScroll: !0
            })
        }
    },
    Tl = e => {
        e.parentNode != null && e.parentNode.removeChild(e)
    },
    El = () => {
        let e = document.createElement("div");
        return e.tabIndex = 0, e.style.position = "fixed", e.setAttribute("aria-hidden", "true"), e.setAttribute("data-silk", "0aa"), e
    },
    bs = e => {
        let t = El(),
            n = El();
        return e.insertAdjacentElement("beforebegin", t), e.insertAdjacentElement("afterend", n), () => {
            Tl(t), Tl(n)
        }
    },
    Ss = e => !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length),
    oa = (e, t = []) => {
        let n = ["input:not([disabled]):not([type=hidden])", "select:not([disabled])", "textarea:not([disabled])", "button:not([disabled])", "a[href]", "area[href]", "summary", "iframe", "object", "embed", "audio[controls]", "video[controls]", "[contenteditable]", "[tabindex]:not([disabled])", ...t],
            l = n.join(","),
            i = e ? [...e.matches(l) ? [e] : [], ...e.querySelectorAll(l)] : [],
            r = [...t, "[aria-hidden='true']", "[aria-hidden='true'] *", "[inert]", "[inert] *"],
            s = i.map(d => ({
                element: d,
                tabbable: d.matches(':not([hidden]):not([tabindex^="-"])'),
                skippable: d.matches(r.join(",")) || !Ss(d)
            })),
            o = s.filter(d => !d.skippable),
            u = o.map(d => d.element),
            c = s.filter(d => d.tabbable),
            p = c.filter(d => !d.skippable),
            m = p.map(d => d.element);
        return {
            allFocusableElementsWithData: s,
            safelyFocusableElements: u,
            allTabbableElementsWithData: c,
            safelyTabbableElements: m
        }
    },
    zl = (e, t) => {
        let {
            safelyTabbableElements: n,
            allTabbableElementsWithData: l,
            allFocusableElementsWithData: i
        } = oa(e, ["[data-silk~='0ac']"]), r = [...l], s = [...i];
        return t && [r, s].forEach(o => {
            o.unshift({
                element: e.previousElementSibling,
                tabbable: !0,
                skippable: !0
            }), o.push({
                element: e.nextElementSibling,
                tabbable: !0,
                skippable: !0
            })
        }), {
            safelyTabbableElements: n,
            allTabbableElementsWithGuardsWithData: r,
            allFocusableElementsWithGuardsWithData: s
        }
    },
    ys = (e, t) => {
        let n;
        return (n = t.slice(0, e).reverse().find(l => l.skippable === !1)) || (n = t.slice(e + 1 - t.length).reverse().find(l => l.skippable === !1)), n
    },
    wl = (e, t) => {
        let n;
        return (n = t.slice(e + 1).find(l => l.skippable === !1)) || (n = t.slice(0, e).find(l => l.skippable === !1)), n
    },
    Cs = ({
        rootElements: e,
        e: t,
        fromElement: n,
        toElement: l,
        fallbackElement: i
    }) => {
        if (!l) return;
        let r = [],
            s = [],
            o = [];
        e.forEach(v => {
            let {
                safelyTabbableElements: b,
                allTabbableElementsWithGuardsWithData: C,
                allFocusableElementsWithGuardsWithData: A
            } = zl(v, !0);
            r = [...r, ...b], s = [...s, ...C], o = [...o, ...A]
        });
        let u = s.findIndex(v => v.element === n),
            c = s.findIndex(v => v.element === l),
            p = s[c],
            m = o.findIndex(v => v.element === l),
            d = !!l && e.includes(l) && l.getAttribute("tabindex") === "-1";
        if (m === -1 && !d) {
            let v = e.find(b => b.getAttribute("tabindex") === "-1");
            v == null || v.focus()
        }
        if (p != null && p.skippable) {
            var f, h, k;
            r.length ? r.length === 1 ? n === r[0] ? (t.preventDefault(), t.stopPropagation(), requestAnimationFrame(() => n.focus())) : r[0].focus() : u ? c < u ? (h = ys(c, s)) === null || h === void 0 || h.element.focus() : (k = wl(c, s)) === null || k === void 0 || k.element.focus() : (f = wl(c, s)) === null || f === void 0 || f.element.focus() : i == null || i.focus()
        }
    },
    Gl = (e, t, n, l, i) => {
        var r;
        if (!((r = e.target) === null || r === void 0) && r.matches("[data-silk-clone]")) return;
        let s = [],
            o = [];
        n.forEach(u => {
            let {
                safelyFocusableElements: c,
                safelyTabbableElements: p
            } = oa(u);
            s = [...s, ...c], o = [...o, ...p]
        }), n.includes(e.target) || s.includes(e.target) ? e.target && i(e.target) : l ? l.focus() : o.length ? o[0].focus() : t.focus()
    },
    Ts = (e, t) => {
        var n;
        if (!((n = e.relatedTarget) === null || n === void 0) && n.matches("[data-silk-clone]")) return;
        let l = ta != null ? ta : e.target,
            i = yn != null ? yn : e.relatedTarget;
        Cs({
            rootElements: t,
            e,
            fromElement: l,
            toElement: i
        }), ta = null, yn = null
    },
    Es = (e, t, n, l, i) => {
        let r = n.find(s => s.contains(e.target));
        e.key !== "Tab" || r || (e.preventDefault(), e.stopPropagation(), Gl(e, t, n, l, i))
    },
    ta = null,
    yn = null,
    ws = ({
        rootElements: e,
        viewElement: t,
        elementFocusedLast: n,
        setElementFocusedLast: l
    }) => {
        let i = [];
        e.forEach(c => {
            i.push(bs(c))
        });
        let r = (function(c, p = document) {
                let m = new Set(c),
                    d = new Set,
                    f = document.createTreeWalker(p, NodeFilter.SHOW_ELEMENT, {
                        acceptNode: b => (b instanceof HTMLElement && b.dataset.liveAnnouncer === "true" && m.add(b), b.tagName === "HEAD" || b.tagName === "SCRIPT" || m.has(b) || b.parentElement && d.has(b.parentElement) ? NodeFilter.FILTER_REJECT : b instanceof HTMLElement && b.getAttribute("role") === "row" || c.some(C => b.contains(C)) ? NodeFilter.FILTER_SKIP : NodeFilter.FILTER_ACCEPT)
                    }),
                    h = b => {
                        var C;
                        let A = (C = In.get(b)) !== null && C !== void 0 ? C : 0;
                        (b.getAttribute("aria-hidden") !== "true" || A !== 0) && (A === 0 && b.setAttribute("aria-hidden", "true"), d.add(b), In.set(b, A + 1))
                    },
                    k = f.nextNode();
                for (; k != null;) h(k), k = f.nextNode();
                let v = new MutationObserver(b => {
                    for (let C of b)
                        if (C.type === "childList" && C.addedNodes.length !== 0 && ![...m, ...d].some(A => A.contains(C.target)))
                            for (let A of C.addedNodes) A instanceof HTMLElement && A.dataset.liveAnnouncer === "true" ? m.add(A) : A instanceof Element && h(A)
                });
                return v.observe(p, {
                    childList: !0,
                    subtree: !0
                }), () => {
                    for (let b of (v.disconnect(), d)) {
                        let C = In.get(b);
                        C === 1 ? (b.removeAttribute("aria-hidden"), In.delete(b)) : C !== void 0 && In.set(b, C - 1)
                    }
                }
            })(e, document),
            s = c => Ts(c, e),
            o = c => Gl(c, t, e, n, l),
            u = c => Es(c, t, e, n, l);
        return document.addEventListener("keydown", u), document.addEventListener("focusout", s), document.addEventListener("focusin", o), () => {
            document.removeEventListener("focusout", s), document.removeEventListener("focusin", o), document.removeEventListener("keydown", u), r(), i.forEach(c => c())
        }
    },
    ua = new Set,
    As = e => {
        ua.add(e)
    },
    xs = e => {
        ua.delete(e)
    },
    $l = (e, t, n, l) => {
        let i = e[t],
            r = i.onClickOutside,
            s = i.dismissOverlayIfNotAlertDialog,
            o = i.viewElement,
            u = i.scrollContainerElement,
            c = i.backdropElement;
        if (u === l.target || c === l.target || !(o != null && o.contains(l.target)) && !n.find(p => p.element.contains(l.target)) && (function(p) {
                for (let m of K.automaticLayerElements)
                    if (m.contains(p)) return !1;
                return !0
            })(l.target)) {
            let p = !0,
                m = !0;
            if (r) {
                let {
                    dismiss: d,
                    stopOverlayPropagation: f
                } = St({
                    nativeEvent: l,
                    defaultBehavior: {
                        dismiss: !0,
                        stopOverlayPropagation: !0
                    },
                    handler: r
                });
                p = d, m = f
            }
            p && s && s(), t > 0 && !m && $l(e, t - 1, n, l)
        }
    },
    Na = null,
    Os = (e, t, n) => {
        var l;
        if (ua.size || !((l = e.target) === null || l === void 0) && l.matches('[data-silk~="0ak"] *') || e.target === document.body && Na !== document.body || !e.target || !e.target.isConnected) return;
        let i = t.length;
        $l(t, i - 1, n, e), Na = null
    },
    Rs = (e, t) => {
        let n = i => Na = i.target,
            l = i => Os(i, e, t);
        return document.addEventListener("pointerdown", n, {
            capture: !0
        }), document.addEventListener("click", l, {
            capture: !0
        }), () => {
            document.removeEventListener("pointerdown", n, {
                capture: !0
            }), document.removeEventListener("click", l, {
                capture: !0
            })
        }
    },
    Kl = (e, t, n) => {
        let l = e[t],
            i = l.onEscapeKeyDown,
            r = l.dismissOverlayIfNotAlertDialog,
            s = !0,
            o = !0,
            u = !0;
        if (i) {
            let {
                dismiss: c,
                nativePreventDefault: p,
                stopOverlayPropagation: m
            } = St({
                nativeEvent: n,
                defaultBehavior: {
                    nativePreventDefault: !0,
                    dismiss: !0,
                    stopOverlayPropagation: !0
                },
                handler: i
            });
            s = p, o = c, u = m
        }
        s && n.preventDefault(), o && r && r(), t > 0 && !u && Kl(e, t - 1, n)
    },
    Ps = (e, t) => {
        if (e.key !== "Escape" || ua.size) return;
        let n = t.length;
        Kl(t, n - 1, e)
    },
    Is = e => {
        let t = n => Ps(n, e);
        return document.addEventListener("keydown", t), () => {
            document.removeEventListener("keydown", t)
        }
    },
    Ds = e => (e.setAttribute("aria-hidden", "true"), () => e.removeAttribute("aria-hidden")),
    Ns = e => {
        let {
            allTabbableElementsWithGuardsWithData: t
        } = zl(e);
        t.forEach(n => {
            n.element.tabIndex = -1
        })
    },
    Ls = e => {
        var t;
        return e instanceof HTMLInputElement && (!!(e.type === "password" || e.type === "text" && e.autocomplete === "username" || !((t = e.closest("form")) === null || t === void 0) && t.querySelector('input[type="password"]')) || void 0)
    },
    Ms = e => {
        var t, n;
        let l = e.getBoundingClientRect(),
            i = l.height,
            r = (n = (t = window.visualViewport) === null || t === void 0 ? void 0 : t.height) !== null && n !== void 0 ? n : 0,
            s = r - l.bottom;
        return s > -i / 2 && s < i + 32
    },
    wa = e => {
        var t;
        return (t = e == null ? void 0 : e.closest('[data-silk~="0ab"], [data-silk~="0ad"]')) === null || t === void 0 ? void 0 : t.matches('[data-silk~="0ah"]')
    },
    _s = () => {
        let e = i => {
                let r = i.target;
                if (wa(r)) {
                    var s;
                    (s = r == null ? void 0 : r.closest('[data-silk~="0ah"]')) === null || s === void 0 || s.focus({
                        preventScroll: !0
                    }), document.removeEventListener("touchstart", e, {
                        capture: !0
                    })
                }
            },
            t = i => {
                let r = i.target,
                    s = i.relatedTarget;
                if (!s) return document.addEventListener("touchstart", e, {
                    capture: !0,
                    passive: !1
                });
                if (wa(s) && (bl(s) && document.addEventListener("touchstart", e, {
                        capture: !0,
                        passive: !1
                    }), !(!ln(s) && !bl(s) || Ia(r))))
                    if (!Ls(s) && ln(r) && Ms(r)) {
                        let o = r.cloneNode(!1);
                        o.removeAttribute("id"), o.setAttribute("data-silk-clone", "true"), o.style.setProperty("position", "fixed"), o.style.setProperty("left", "0"), o.style.setProperty("top", "0"), o.style.setProperty("transform", "translateY(-3000px) scale(0)"), document.documentElement.appendChild(o), yn = s, o == null || o.focus({
                            preventScroll: !0
                        }), setTimeout(() => {
                            ta = r, yn = s, s == null || s.focus({
                                preventScroll: !0
                            }), o.remove()
                        }, 32)
                    } else yn = s, s == null || s.focus({
                        preventScroll: !0
                    })
            },
            n = i => {
                var r;
                let s = i.target;
                !(s !== document.activeElement || !ln(s) || ra()) && wa(s) && ((r = s == null ? void 0 : s.closest('[data-silk~="0ab"], [data-silk~="0ad"]')) === null || r === void 0 || r.focus({
                    preventScroll: !0
                }))
            },
            l = i => {
                var r;
                let s = i.target;
                if (!s || !("setSelectionRange" in s) || !(["password", "search", "tel", "text", "url"].includes(s.type) || s instanceof HTMLTextAreaElement) || s._silk_focusedBefore === !0) return;
                let o = s.value.length;
                (r = s.setSelectionRange) === null || r === void 0 || r.call(s, o, o), s._silk_focusedBefore = !0
            };
        return document.addEventListener("blur", t, {
            capture: !0,
            passive: !1
        }), document.addEventListener("touchstart", e, {
            capture: !0,
            passive: !0
        }), document.addEventListener("touchend", n, {
            capture: !0,
            passive: !0
        }), document.addEventListener("focusin", l), () => {
            document.removeEventListener("blur", t, {
                capture: !0
            }), document.removeEventListener("touchend", n, {
                capture: !0
            }), document.removeEventListener("touchstart", e, {
                capture: !0
            }), document.removeEventListener("focusin", l)
        }
    },
    ql = ["translate", "translateX", "translateY", "translateZ", "scale", "scaleX", "scaleY", "scaleZ", "rotate", "rotateX", "rotateY", "rotateZ", "skew", "skewX", "skewY"],
    Jl = null,
    Zl = e => {
        Jl = e
    },
    Fs = {
        sheets: [],
        addSheet: function(e) {
            let t;
            if (!e.id) return;
            let n = this.findSheet(e.id);
            return n ? (e.stackId && (n.stackId = e.stackId), e.sendToOpennessMachine && (n.sendToOpennessMachine = e.sendToOpennessMachine), t = n) : (t = y({
                stackingIndex: -1,
                travelAnimations: [],
                aggregatedTravelCallback: function(l, i) {
                    let r = this.travelAnimations;
                    for (let s = 0, o = r.length; s < o; s++) r[s].callback(l, i)
                },
                stackingAnimations: [],
                aggregatedStackingCallback: function(l, i) {
                    let r = this.stackingAnimations;
                    for (let s = 0, o = r.length; s < o; s++) r[s].callback(l, i)
                },
                belowSheetsInStack: [],
                outlets: new Set
            }, e), this.sheets.push(t)), this.updateBelowSheetsInStackOfAllSheets(), t
        },
        attemptToRemoveSheet: function(e, t) {
            let n = this.findSheet(e);
            if (n)
                if (n.outlets.size === 0) {
                    var l;
                    let i = (l = this.findSheet(e)) === null || l === void 0 ? void 0 : l.stackId;
                    this.sheets = this.sheets.filter(r => r.id !== e), i && this.updateSelfAndAboveTravelProgressSumInStack(i)
                } else t && t(n)
        },
        attemptToRemoveSheetOrCleanup: function(e) {
            this.attemptToRemoveSheet(e, t => {
                t.sendToOpennessMachine = null
            })
        },
        findSheet: function(e) {
            return this.sheets.find(t => t.id === e)
        },
        addOutletToSheet: function(e, t) {
            let n = this.findSheet(e);
            n ? n.outlets.add(t) : this.addSheet({
                id: e,
                outlets: new Set([t])
            })
        },
        removeOutletFromSheet: function(e, t) {
            let n = this.findSheet(e);
            n == null || n.outlets.delete(t), this.attemptToRemoveSheet(e)
        },
        sheetStacks: [],
        addSheetStack: function(e) {
            let t;
            return this.findSheetStack(e.id) || (t = y({
                stackingAnimations: [],
                aggregatedStackingCallback: function(l, i) {
                    let r = this.stackingAnimations;
                    for (let s = 0, o = r.length; s < o; s++) r[s].callback(l, i)
                }
            }, e), this.sheetStacks.push(t)), this.updateBelowSheetsInStackOfAllSheets(), t
        },
        removeSheetStack: function(e) {
            e && (this.sheetStacks = this.sheetStacks.filter(t => t.id !== e), this.removeAllOutletPersistedStylesFromStack(e))
        },
        findSheetStack: function(e) {
            return this.sheetStacks.find(t => t.id === e)
        },
        updateBelowSheetsInStackOfAllSheets: function() {
            this.sheets.forEach(e => {
                let t, n = e.stackId;
                if (n) {
                    t = this.findSheetStack(n);
                    let l = this.sheets.filter(r => r.stackId === e.stackId),
                        i = l.filter(r => r.stackId === e.stackId && r.stackingIndex > e.stackingIndex);
                    t && (i.unshift(t), t.stackingIndex = l.length - 1), e.belowSheetsInStack = i, this.updateSelfAndAboveTravelProgressSumInStack(n)
                }
            })
        },
        updateSheetStackingIndex: function(e, t) {
            let n = this.findSheet(e);
            n && (n.stackingIndex = t), this.updateBelowSheetsInStackOfAllSheets()
        },
        updateSheetTravelProgress: function(e, t) {
            let n = this.findSheet(e);
            n && n.stackId && (n.travelProgress = t, this.updateSelfAndAboveTravelProgressSumInStack(n.stackId))
        },
        updateSelfAndAboveTravelProgressSumInStack: function(e) {
            let t = this.sheets.filter(i => i.stackId === e).sort((i, r) => r.stackingIndex - i.stackingIndex),
                n = this.findSheetStack(e);
            n && t.unshift(n);
            let l = t.length;
            for (let i = 0; i < l; i++) {
                let r = t[i];
                r.selfAndAboveTravelProgressSum = [];
                for (let s = 0; s < l; s++) s <= i ? r.selfAndAboveTravelProgressSum[s] = 0 : r.selfAndAboveTravelProgressSum[s] = t.slice(i + 1, s + 1).reduce((o, u) => o + u.travelProgress, 0)
            }
        },
        addAnimationToSheetOrStack: function({
            type: e,
            sheetId: t,
            stackId: n,
            element: l,
            config: i
        }) {
            let r = i.hasOwnProperty("properties") ? i.properties : i,
                s = [];
            Object.entries(r).forEach(([m, d]) => {
                if (d !== "ignore" && d && typeof d != "string")
                    if (typeof d == "function")
                        if (ql.includes(m)) {
                            let f = s.findIndex(k => k[0] === "transform"),
                                h = k => m + "(" + d(k) + ")";
                            if (f !== -1) {
                                let k = s[f][1];
                                s[f][1] = v => k(v) + " " + h(v)
                            } else s.push(["transform", h])
                        } else if (m === "transform") {
                    let f = s.findIndex(h => h[0] === "transform");
                    if (f !== -1) {
                        let h = s[f][1];
                        s[f][1] = k => h(k) + " " + d(k)
                    } else s.push(["transform", d])
                } else s.push([m, d]);
                else if (m === "opacity") {
                    let f = ["opacity", ({
                        tween: h
                    }) => h(d[0], d[1])];
                    s.push(f)
                } else {
                    if (!m.startsWith("scale") && (!isNaN(d[0]) || !isNaN(d[1]))) throw Error("Keyframe values used with a 'transform' property require a unit (e.g. 'px', 'em' or '%').");
                    let f = s.findIndex(k => k[0] === "transform"),
                        h = ({
                            tween: k
                        }) => m + "(" + k(d[0], d[1]) + ")";
                    if (f !== -1) {
                        let k = s[f][1];
                        s[f][1] = v => k(v) + " " + h(v)
                    } else s.push(["transform", h])
                }
            });
            let o = s.map(m => [(m[0].startsWith("webkit") || m[0].startsWith("moz") ? "-" : "") + m[0].replace(/[A-Z]/g, "-$&").toLowerCase(), m[1]]),
                u = o.length,
                c = {
                    target: l,
                    config: s,
                    dashedPropertiesAsArray: o,
                    callback: (m, d) => {
                        for (let f = 0; f < u; f++) {
                            let [h, k] = o[f];
                            l.style.setProperty(h, k({
                                progress: m,
                                tween: d
                            }))
                        }
                    }
                },
                p = n ? this.findSheetStack(n) : this.findSheet(t);
            p && (e === "travel" ? p.travelAnimations.push(c) : p.stackingAnimations.push(c))
        },
        removeAnimationFromSheetOrStack: function({
            sheetId: e,
            stackId: t,
            type: n,
            element: l
        }) {
            let i = t ? this.findSheetStack(t) : this.findSheet(e);
            if (i)
                if (n === "travel") {
                    let r = i.travelAnimations.filter(s => s.target !== l);
                    i.travelAnimations = r
                } else {
                    let r = i.stackingAnimations.filter(s => s.target !== l);
                    i.stackingAnimations = r
                }
        },
        removeAllOutletPersistedStylesFromSheet: function(e) {
            let t = this.findSheet(e);
            t && [...t.travelAnimations, ...t.stackingAnimations].forEach(n => {
                n.dashedPropertiesAsArray.forEach(([l]) => {
                    n.target.style.removeProperty(l)
                })
            })
        },
        removeAllOutletPersistedStylesFromStack: function(e) {
            let t = this.findSheetStack(e);
            t && t.stackingAnimations.forEach(n => {
                n.dashedPropertiesAsArray.forEach(([l]) => {
                    n.target.style.removeProperty(l)
                })
            })
        },
        getAggregatedStackingCallbackForSheetsBelow: function(e) {
            let t, n = this.findSheet(e);
            return n && (t = l => {
                let i = n.belowSheetsInStack,
                    r = i.length;
                for (let s = 0; s < r; s++) {
                    let o = i[s],
                        u = o.selfAndAboveTravelProgressSum[r - 1] + l,
                        c = Sn(u);
                    o.aggregatedStackingCallback(u, c)
                }
            }), t
        },
        automaticIslandElements: new Set([]),
        automaticLayerElements: new Set([]),
        automaticLayerAndIslandDetectionCleanup: null,
        focusContainmentRootElements: [],
        focusContainmentCleanup: () => {},
        escapeKeyDownListenerCleanup: null,
        clickOutsideListenerCleanup: null,
        processLayersAndIslandsChangesTimeout: null,
        setupAutomaticLayerAndIslandDetection: function(e) {
            let t = document.documentElement,
                n = document.body,
                l = () => {
                    let r, s = new Set([]),
                        o = new Set([]),
                        u = (function(v) {
                            let b = v.parentElement;
                            for (; b && b !== document.body;) {
                                if (b.parentElement === document.body) return b;
                                b = b.parentElement
                            }
                            return v.parentElement === document.body ? v : null
                        })(e);
                    r = u ? u.nextElementSibling : n.firstElementChild;
                    let c = v => v.matches('[data-silk~="0ag"], [data-silk~="0ab"], [data-silk~="0aa"], [data-silk-clone]'),
                        p = v => v.tagName !== "SCRIPT";
                    for (; r;) !c(r) && p(r) && s.add(r), r = r.nextElementSibling;
                    let m = t.children;
                    for (let v = 0; v < m.length; v++) {
                        let b = m[v];
                        b.tagName === "HEAD" || b.tagName === "BODY" || c(b) || o.add(b)
                    }
                    let d = new Set([...s].filter(v => !this.automaticLayerElements.has(v))),
                        f = new Set([...this.automaticLayerElements].filter(v => !s.has(v)));
                    this.automaticLayerElements = s;
                    let h = new Set([...o].filter(v => !this.automaticIslandElements.has(v))),
                        k = new Set([...this.automaticIslandElements].filter(v => !o.has(v)));
                    this.automaticIslandElements = o, d.forEach(v => {
                        this.updateLayer({
                            automatic: !0,
                            layerId: null,
                            viewElement: v,
                            inertOutside: !1,
                            onPresentAutoFocus: {
                                focus: !1
                            },
                            onDismissAutoFocus: {
                                focus: !1
                            },
                            dismissOverlayIfNotAlertDialog: () => {},
                            onClickOutside: {
                                stopOverlayPropagation: !1
                            },
                            onEscapeKeyDown: {
                                stopOverlayPropagation: !1
                            }
                        })
                    }), f.forEach(v => this.removeLayer(null, v)), h.forEach(v => this.addIsland({
                        element: v,
                        automatic: !0
                    })), k.forEach(v => this.removeIsland(null, v))
                };
            l();
            let i = new MutationObserver(() => {
                l()
            });
            i.observe(t, {
                childList: !0
            }), i.observe(n, {
                childList: !0
            }), this.automaticLayerAndIslandDetectionCleanup = function() {
                i.disconnect(), this.layers.forEach(r => {
                    r.automatic && this.removeLayer(null, r.viewElement)
                }), this.automaticLayerElements = new Set([]), this.islands.forEach(r => {
                    r.automatic && this.removeIsland(null, r.element)
                }), this.automaticIslandElements = new Set([]), this.automaticLayerAndIslandDetectionCleanup = null
            }
        },
        moveFocusIfNecessary: function(e, t, n, l, i, r) {
            let s = !1;
            for (let o = 0; o < t.length; o++)
                if (t[o].contains(document.activeElement)) {
                    s = !0;
                    break
                }
            if (n.length) {
                let o = n.filter(u => !u.automatic && !u.external);
                if (o.length) {
                    let u = o[o.length - 1];
                    return Cl(u.layerId, u.viewElement, u.onPresentAutoFocus)
                }
            }
            if (i.length && !s) {
                let o = e[e.length - 1];
                if (!o.external) return Cl(o.layerId, o.viewElement, o.onPresentAutoFocus)
            }
            if (l.length && l.find(u => u.focusWasInside)) {
                let u = l[0];
                if (!u.external) return ks(u.layerId, u.viewElement, u.onDismissAutoFocus, u.elementFocusedLastBeforeShowing)
            }
            if (r.length && r.find(u => u.focusWasInside)) {
                let u = e[e.length - 1];
                if (u) return Hl(u.layerId, u.viewElement)
            }
        },
        processLayersAndIslandsChanges: function() {
            var e;
            clearTimeout(this.processLayersAndIslandsChangesTimeout);
            let t = () => {
                let l = this.layers.length,
                    i = new Set([]),
                    r;
                if (this.layers.some(m => m.inertOutside)) {
                    this.islands.filter(d => !d.componentId || d.componentId.length === 0).forEach(d => i.add(d.element));
                    for (let d = l - 1; d >= 0; d--) {
                        let f = this.layers[d];
                        if (f.external && f.inertOutside) {
                            i = new Set([]);
                            break
                        }
                        i.add(f.viewElement);
                        let h = this.islands.filter(v => v.componentId && f.layerContextId && v.componentId.includes(f.layerContextId)),
                            k = this.islands.filter(v => v.componentId && f.layerStackContextId && v.componentId.includes(f.layerStackContextId));
                        if ([...h, ...k].forEach(v => {
                                i.add(v.element)
                            }), f.inertOutside) {
                            r = f;
                            break
                        }
                        r = f
                    }
                }
                let o = [...i],
                    u = !(function(m, d) {
                        if (m.length !== d.length) return !1;
                        let f = new Set;
                        for (let h of m) f.add(h);
                        for (let h of d)
                            if (!f.has(h)) return !1;
                        return !0
                    })(this.focusContainmentRootElements, o);
                if (this.focusContainmentRootElements = o, u) {
                    var c;
                    this.focusContainmentCleanup(), this.focusContainmentCleanup = () => {}, (c = this.automaticLayerAndIslandDetectionCleanup) === null || c === void 0 || c.call(this), r && (this.setupAutomaticLayerAndIslandDetection(r == null ? void 0 : r.viewElement), this.focusContainmentCleanup = ws({
                        rootElements: this.focusContainmentRootElements,
                        viewElement: r == null ? void 0 : r.viewElement,
                        elementFocusedLast: Jl,
                        setElementFocusedLast: Zl
                    }))
                }
                this.moveFocusIfNecessary(this.layers, this.focusContainmentRootElements, this.layersJustAdded, this.layersJustRemoved, this.layersJustWentToInertOutsideTrue, this.islandsJustRemoved), this.escapeKeyDownListenerCleanup && (this.escapeKeyDownListenerCleanup(), this.escapeKeyDownListenerCleanup = null), this.clickOutsideListenerCleanup && (this.clickOutsideListenerCleanup(), this.clickOutsideListenerCleanup = null), l > 0 && (this.escapeKeyDownListenerCleanup = Is(this.layers), this.clickOutsideListenerCleanup = Rs(this.layers, this.islands));
                let p = this.layersJustRemoved.length;
                if (p)
                    for (let m = 0; m < p; m++) {
                        let d = this.layersJustRemoved[m],
                            f = d.viewElement,
                            h = d.automatic;
                        f && !h && (Ds(f), Ns(f))
                    }
                this.islandsJustRemoved = [], this.layersJustAdded = [], this.layersJustRemoved = [], this.layersJustWentToInertOutsideTrue = []
            };
            ((e = this.layersJustAdded[this.layersJustAdded.length - 1]) === null || e === void 0 ? void 0 : e.external) ? t(): this.processLayersAndIslandsChangesTimeout = setTimeout(t, 16)
        },
        autoFocusTargets: [],
        addAutoFocusTarget: function({
            layerId: e,
            element: t,
            timing: n
        }) {
            this.autoFocusTargets.push({
                layerId: e,
                element: t,
                timing: n
            })
        },
        removeAutoFocusTarget: function(e) {
            this.autoFocusTargets = this.autoFocusTargets.filter(t => t.element !== e)
        },
        islands: [],
        islandsJustRemoved: [],
        addIsland: function(e) {
            var t;
            let n = this.islands[this.islands.length - 1],
                l = ((t = e.id) !== null && t !== void 0 ? t : n) ? n.id + 1 : 0;
            return this.islands.push(M(y({}, e), {
                id: l
            })), this.processLayersAndIslandsChanges(), l
        },
        removeIsland: function(e, t) {
            this.islands = this.islands.filter(n => {
                if (e && n.id && n.id !== e || t && n.element && n.element !== t) return !0; {
                    let l = n.element.contains(document.activeElement);
                    return this.islandsJustRemoved.push(M(y({}, n), {
                        focusWasInside: l
                    })), !1
                }
            }), this.processLayersAndIslandsChanges()
        },
        layers: [],
        layersJustAdded: [],
        layersJustRemoved: [],
        layersJustWentToInertOutsideTrue: [],
        updateLayer: function(e) {
            let t = e.layerId,
                n = e.viewElement,
                l = !1,
                i = this.layers;
            for (let s = 0; s < i.length; s++) {
                let o = i[s];
                if (t !== null ? o.layerId === t : o.viewElement === n) {
                    let c = y(y({}, o), e);
                    !o.inertOutside && e.inertOutside && this.layersJustWentToInertOutsideTrue.push(c), i[s] = c, l = !0;
                    break
                }
            }
            if (!l) {
                var r;
                let s = M(y({}, e), {
                    elementFocusedLastBeforeShowing: (r = e.elementFocusedLastBeforeShowing) !== null && r !== void 0 ? r : document.activeElement
                });
                i.push(s), this.layersJustAdded.push(s)
            }
            this.processLayersAndIslandsChanges()
        },
        removeLayer: function(e, t) {
            var n;
            this.layers = this.layers.filter(l => {
                if (e && l.layerId && l.layerId !== e || t && l.viewElement && l.viewElement !== t) return !0; {
                    var i;
                    let r = (i = l.viewElement) === null || i === void 0 ? void 0 : i.contains(document.activeElement);
                    return this.layersJustRemoved.push(M(y({}, l), {
                        focusWasInside: r
                    })), !1
                }
            }), this.layers.filter(l => !l.automatic).length === 0 && ((n = this.automaticLayerAndIslandDetectionCleanup) === null || n === void 0 || n.call(this)), this.processLayersAndIslandsChanges()
        },
        nativeFocusScrollPreventers: [],
        nativeFocusScrollPreventionCleanup: null,
        addNativeFocusScrollPreventer: function(e) {
            this.nativeFocusScrollPreventers.push({
                id: e
            }), this.processNativeFocusScrollPreventersChanges()
        },
        removeNativeFocusScrollPreventer: function(e) {
            this.nativeFocusScrollPreventers = this.nativeFocusScrollPreventers.filter(t => t.id !== e), this.processNativeFocusScrollPreventersChanges()
        },
        processNativeFocusScrollPreventersChanges: function() {
            let e = this.nativeFocusScrollPreventers.length;
            if (Rt() && (Re === "ios" || Re === "ipados"))
                if (e) this.nativeFocusScrollPreventionCleanup || (this.nativeFocusScrollPreventionCleanup = _s());
                else {
                    var t;
                    (t = this.nativeFocusScrollPreventionCleanup) === null || t === void 0 || t.call(this), this.nativeFocusScrollPreventionCleanup = null
                }
        },
        fixedComponents: [],
        addFixedComponent: function(e) {
            this.fixedComponents.push(e)
        },
        updateFixedComponent: function(e) {
            let t = this.fixedComponents.find(n => n.id === e.id);
            t && (e.element && (t.element = e.element), e.initialInlineCSSTransform && (t.initialInlineCSSTransform = e.initialInlineCSSTransform), typeof e.compensated == "boolean" && (t.compensated = e.compensated))
        },
        removeFixedComponent: function(e) {
            this.fixedComponents = this.fixedComponents.filter(t => t.id !== e)
        },
        findActualFixedComponentsInsideOutlet: function(e) {
            return this.fixedComponents.filter(t => {
                if (t.element && e) return e.contains(t.element) && window.getComputedStyle(t.element).getPropertyValue("position") === "fixed"
            })
        },
        themeColorMetaTag: null,
        underlyingThemeColor: null,
        themeColorDimmingOverlays: [],
        storeThemeColorMetaTag: function() {
            if (this.themeColorMetaTag = hs(), !this.themeColorMetaTag) {
                let e = document.createElement("meta");
                e.name = "theme-color", e.content = window.getComputedStyle(document.body).backgroundColor, document.head.appendChild(e), this.themeColorMetaTag = e
            }
        },
        getAndStoreUnderlyingThemeColorAsRGBArray: function() {
            let e;
            if (this.themeColorDimmingOverlays.length > 0) e = this.underlyingThemeColor;
            else {
                var t;
                this.themeColorMetaTag || this.storeThemeColorMetaTag();
                let n = (t = this.themeColorMetaTag) === null || t === void 0 ? void 0 : t.content;
                (e = Sl(n)) || (console.warn("`themeColorDimming` prop ignored: Only `theme-color` meta tag with a value in `rgb()`, `rgba()`, or hexadecimal format is supported."), e = [0, 0, 0]), this.underlyingThemeColor = e
            }
            return e
        },
        updateUnderlyingThemeColor: function(e) {
            let t = Sl(e);
            if (!t) throw Error("The color provided to `updateThemeColor` doesn't match `rgb()`, `rgba()`, or hexadecimal format.");
            this.underlyingThemeColor = t, this.setActualThemeColor()
        },
        setActualThemeColor: function() {
            var e;
            this.themeColorMetaTag || this.storeThemeColorMetaTag(), (e = this.themeColorMetaTag) === null || e === void 0 || e.setAttribute("content", ps({
                color: this.underlyingThemeColor,
                overlays: this.themeColorDimmingOverlays
            }))
        },
        findThemeColorDimmingOverlay: function(e) {
            return this.themeColorDimmingOverlays.find(t => t.dimmingOverlayId === e)
        },
        findIndexThemeColorDimmingOverlay: function(e) {
            return this.themeColorDimmingOverlays.findIndex(t => t.dimmingOverlayId === e)
        },
        updateThemeColorDimmingOverlay: function(e) {
            let t = e;
            t.color && (t = M(y({}, t), {
                color: jl(t.color)
            }));
            let n = this.findThemeColorDimmingOverlay(t.dimmingOverlayId);
            return n ? Object.assign(n, t) : (n = t, this.themeColorDimmingOverlays.push(t)), this.setActualThemeColor(), n
        },
        updateThemeColorDimmingOverlayAlphaValue: function(e, t) {
            e.alpha = t, this.setActualThemeColor()
        },
        removeThemeColorDimmingOverlay: function(e) {
            let t = this.findThemeColorDimmingOverlay(e);
            t && (t.abortRemoval = !1, setTimeout(() => {
                t != null && t.abortRemoval || (this.themeColorDimmingOverlays = this.themeColorDimmingOverlays.filter(n => n.dimmingOverlayId !== e), this.setActualThemeColor(), this.themeColorDimmingOverlays.length !== 0 || (this.underlyingThemeColor = null, this.themeColorMetaTag = null))
            }, 20))
        }
    };
var K = Fs;
let Ql = e => {
        let t = a.useRef(null);
        return De(() => {
            t.current = e
        }), a.useCallback((...n) => {
            let l = t.current;
            return l(...n)
        }, [])
    },
    Va = e => e === "layout" ? De : a.useEffect,
    La = e => {
        var t = e == null ? void 0 : e.lastIndexOf(":");
        return t === -1 ? "" : e == null ? void 0 : e.substring(t + 1)
    },
    Bs = e => {
        let t = [],
            n = [],
            l = (i, r, {
                partOfInitial: s
            }) => {
                Array.isArray(i) ? i.forEach(o => l(o, r, {
                    partOfInitial: s
                })) : (r += (r ? "." : "") + i.name, s && n.push(r + ":" + i.initial), Object.entries(i.states).forEach(([o, u]) => {
                    let c = r + ":" + o;
                    u.machine = r, u.path = c, u.reactive = !i.silentOnly, t.push(u), u.machines && l(u.machines, c, {
                        partOfInitial: s && i.initial === o
                    })
                }))
            };
        return l(e, "", {
            partOfInitial: !0
        }), [n, t]
    },
    Al = (e, t) => e.includes(":") ? e : t.substring(0, t.lastIndexOf(":") + 1) + e,
    xl = e => {
        let t = e.split("."),
            n = [];
        return t.forEach((l, i) => {
            let r = n[i - 1],
                s = (r ? r.full + "." : "") + l,
                o = s.substring(0, s.lastIndexOf(":")),
                u = s.substring(s.lastIndexOf(":") + 1);
            n.push({
                full: s,
                withoutState: o,
                state: u
            })
        }), n
    },
    Vs = ({
        checkedPoolOfStates: e,
        referencePoolOfStates: t,
        callbackOnExclusion: n,
        callbackOnPresent: l
    }) => e.filter(r => {
        let s = !0;
        return r.forEach(o => {
            t.forEach(u => {
                u.forEach(c => {
                    o.withoutState === c.withoutState && (o.state !== c.state ? (s = !1, n == null || n({
                        decomposedCheckedState: r,
                        checkedStatePiece: o,
                        decomposedReferenceState: u,
                        referenceStatePiece: c
                    })) : l({
                        decomposedCheckedState: r,
                        checkedStatePiece: o,
                        decomposedReferenceState: u,
                        referenceStatePiece: c
                    }))
                })
            })
        }), s
    }),
    Ws = e => {
        let [t, n] = Bs(e);
        return [t, (l, i) => {
            let r, s = typeof i == "string" ? i : i.type,
                o = [];
            n.forEach(x => {
                l.includes(x.path) && (!i.machine || i.machine === x.machine) && x.messages && Object.entries(x.messages).forEach(([B, X]) => {
                    if (B === s) {
                        if (typeof X == "string") r = B, o.push(Al(X, x.path));
                        else
                            for (let N of X)
                                if (!N.guard || N.guard(l, i)) {
                                    r = B, o.push(Al(N.target, x.path));
                                    break
                                }
                    }
                })
            });
            let u = l.map(x => xl(x)),
                c = o.map(x => xl(x)),
                p = [],
                m = Vs({
                    checkedPoolOfStates: u,
                    referencePoolOfStates: c,
                    callbackOnExclusion: ({
                        decomposedCheckedState: x
                    }) => {
                        p.push(x[x.length - 1].full)
                    },
                    callbackOnPresent: ({
                        referenceStatePiece: x
                    }) => {
                        x.unchanged = !0
                    }
                }),
                d = m.map(x => x[x.length - 1].full),
                f = [],
                h = [];
            c.forEach(x => {
                x.forEach((B, X) => {
                    if (!B.unchanged) {
                        var N, q;
                        X < x.length - 1 && f.push(B.full);
                        let O = n.find(_ => _.path === B.full);
                        (N = O.machines) === null || N === void 0 || (q = N.forEach) === null || q === void 0 || q.call(N, _ => {
                            let W = () => {
                                c.find(L => L.find(F => F.withoutState === "".concat(O.path, ".").concat(_.name))) || h.push("".concat(O.path, ".").concat(_.name, ":").concat(_.initial))
                            };
                            X < x.length - 1 ? O.path + _.name !== x[X + 1].withoutState && W() : W();
                            let D = L => {
                                var F, ee;
                                (F = n.find(H => H.path === L).machines) === null || F === void 0 || (ee = F.forEach) === null || ee === void 0 || ee.call(F, H => {
                                    c.find(ce => ce.find(Ne => Ne.withoutState === "".concat(O.path, ".").concat(H.name))) || h.push("".concat(L, ".").concat(H.name, ":").concat(H.initial)), D("".concat(L, ".").concat(H.name, ":").concat(H.initial))
                                })
                            };
                            D("".concat(O.path, ".").concat(_.name, ":").concat(_.initial))
                        })
                    }
                })
            });
            let k = [...o, ...f, ...h],
                v = [...d, ...k],
                b = [...p, ...k],
                C = n.filter(x => b.includes(x.path)),
                A = C.some(x => x.reactive);
            return {
                exitedStates: p,
                transitionTaken: r,
                enteredStates: k,
                nextStates: v,
                reactive: A
            }
        }]
    },
    na = (e, t) => e == null ? void 0 : e.toStrings().filter(n => n == null ? void 0 : n.startsWith(t)).filter(n => {
        var l;
        return !(!((l = n == null ? void 0 : n.slice(t.length)) === null || l === void 0) && l.includes("."))
    })[0],
    Ol = e => {
        let [t, n] = a.useMemo(() => Ws(e), [e]), l = a.useRef(), i = a.useRef([]), r = a.useRef([]), s = a.useRef([]), o = a.useRef([]), u = a.useRef(t), c = a.useRef({
            toStrings: () => t,
            matches: h => rn(t, h),
            lastMessageTreatedRef: l,
            exitActionsRef: i,
            transitionActionsRef: r,
            entryActionsRef: s,
            selectorsRef: o
        }), [p, m] = a.useState(M(y({}, c.current), {
            silent: c.current
        })), d = a.useRef([]), f = a.useCallback(h => {
            d.current.push(h);
            let k = v => {
                let {
                    nextStates: b,
                    exitedStates: C,
                    transitionTaken: A,
                    enteredStates: x,
                    reactive: B
                } = n(u.current, d.current[0]), X = u.current;
                if (u.current = b, i.current.forEach(N => {
                        C.includes(N.state) && (typeof N.guard == "function" ? N.guard(X, d.current[0]) : N.guard) && N.callback(d.current[0], N.params)
                    }), r.current.forEach(N => {
                        C.includes(N.state) && N.transition === A && (typeof N.guard == "function" ? N.guard(X, d.current[0]) : N.guard) && N.callback(d.current[0], N.params)
                    }), s.current.forEach(N => {
                        x.includes(N.state) && (typeof N.guard == "function" ? N.guard(X, d.current[0]) : N.guard) && N.callback(d.current[0], N.params)
                    }), l.current = typeof d.current[0] == "string" ? {
                        type: d.current[0]
                    } : d.current[0], d.current.shift(), d.current.length) k(B || v);
                else {
                    let N = b.slice();
                    c.current.toStrings = () => N, c.current.matches = q => rn(N, q), c.current.getValues = () => [La(N.toStrings)], o.current.forEach(q => {
                        let O = q.current.selection;
                        q.current.toStrings = () => [na(c.current, O)], q.current.matches = _ => rn([na(c.current, O)], _), q.current.getValues = () => [La(na(c.current, O))]
                    }), (v || B) && m(M(y({}, c.current), {
                        silent: c.current
                    }))
                }
            };
            d.current.length === 1 && k()
        }, [n]);
        return [p, f]
    },
    js = (e, t, n, s = {
        delay: null
    }) => {
        var o = s,
            {
                message: l = "",
                delay: i = null
            } = o,
            r = ue(o, ["message", "delay"]);
        a.useEffect(() => {
            let u;
            return t.matches(n) && (u = setTimeout(() => e(y({
                type: ""
            }, r)), i != null ? i : 0)), () => {
                u && clearTimeout(u)
            }
        }, [t, n, i, e, l, r])
    },
    gt = (e, t, {
        shallow: n = !0
    } = {}) => {
        let l = a.useMemo(() => na(e, t), [e, t]),
            i = a.useRef({
                lastMessageTreatedRef: e == null ? void 0 : e.lastMessageTreatedRef,
                exitActionsRef: e == null ? void 0 : e.exitActionsRef,
                transitionActionsRef: e == null ? void 0 : e.transitionActionsRef,
                entryActionsRef: e == null ? void 0 : e.entryActionsRef,
                toStrings: () => [l],
                matches: s => rn([l], s),
                selection: t,
                getValues: () => [La(l)]
            }),
            r = a.useRef(Symbol());
        return De(() => {
            e.selectorsRef.current.find(o => o.id === r.current) || e.selectorsRef.current.push(i)
        }, []), a.useMemo(() => M(y({}, i.current), {
            silent: i.current
        }), [l])
    },
    rn = (e, t) => Array.isArray(t) ? t.some(n => e.includes(n)) || e.some(n => t.some(l => (n == null ? void 0 : n.startsWith(l)) && (n == null ? void 0 : n.charAt(l.length)) === ".")) : e.includes(t) || e.some(n => (n == null ? void 0 : n.startsWith(t)) && (n == null ? void 0 : n.charAt(t.length)) === "."),
    j = (e, t, n) => {
        let {
            state: l,
            callback: i,
            params: r,
            empty: s = !1
        } = n, o = !n.hasOwnProperty("guard") || n.guard, u = a.useMemo(() => r ? Object.values(r) : [], [r]), c = a.useMemo(() => t.entryActionsRef, [t]), p = Va(e === "before-paint" ? "layout" : "normal"), m = Ql(f => {
            (f != null && f.matches && (f != null && f.matches(l)) || !(f != null && f.matches) && rn(f, l)) && (typeof o == "function" && o() || typeof o != "function" && o) && i(f.lastMessageTreatedRef.current, r)
        }), d = a.useRef(Symbol());
        p(() => {
            if (!s)
                if (e === "immediate") {
                    let f = {
                            id: d.current,
                            state: l,
                            guard: o,
                            callback: i,
                            params: r
                        },
                        h = c.current.findIndex(k => k.id === d.current);
                    h === -1 ? c.current.push(f) : c.current[h] = f
                } else m(t)
        }, e === "immediate" ? [e, l, o, i, c, ...u] : [e, m, t]), a.useEffect(() => () => {
            c.current = c.current.filter(f => f.id !== d.current)
        }, [])
    },
    se = (e, t) => {
        let {
            state: n,
            transition: l,
            callback: i,
            params: r
        } = t, s = !t.hasOwnProperty("guard") || t.guard, o = a.useMemo(() => r ? Object.values(r) : [], [r]), u = a.useMemo(() => e.transitionActionsRef, [e]), c = a.useRef(Symbol());
        a.useEffect(() => {
            let p = {
                    id: c.current,
                    state: n,
                    transition: l,
                    guard: s,
                    callback: i,
                    params: r
                },
                m = u.current.findIndex(d => d.id === c.current);
            m === -1 ? u.current.push(p) : u.current[m] = p
        }, [n, l, s, i, u, ...o]), a.useEffect(() => () => {
            u.current = u.current.filter(p => p.id !== c.current)
        }, [])
    },
    Ht = (e, t, n) => {
        let {
            state: l,
            callback: i,
            params: r
        } = n, s = !n.hasOwnProperty("guard") || n.guard, o = a.useMemo(() => r ? Object.values(r) : [], [r]), u = a.useMemo(() => t.exitActionsRef, [t]), c = Va("normal");
        Ql(m => {
            (m != null && m.matches && (m != null && m.matches(l)) || !(m != null && m.matches) && rn(m, l)) && (typeof s == "function" && s() || typeof s != "function" && s) && i(m.lastMessageTreatedRef.current, r)
        });
        let p = a.useRef(Symbol());
        c(() => {
            {
                let m = {
                        id: p.current,
                        state: l,
                        guard: s,
                        callback: i,
                        params: r
                    },
                    d = u.current.findIndex(f => f.id === p.current);
                d === -1 ? u.current.push(m) : u.current[d] = m
            }
            return () => {}
        }, [e, l, s, i, u, ...o]), a.useEffect(() => () => {
            u.current = u.current.filter(m => m.id !== p.current)
        }, [])
    },
    Qe = (e, t, n) => {
        let {
            state: l,
            callback: i,
            params: r,
            name: s
        } = n, o = !n.hasOwnProperty("guard") || n.guard, u = r ? Object.values(r) : [], c = typeof e == "string" ? e : e.start, p = typeof e == "string" ? e : e.update, m = a.useRef(null);
        j("immediate", t, {
            state: l,
            guard: o,
            callback: a.useCallback(() => {
                m.current = i(null, r)
            }, [i, r]),
            params: r,
            empty: c !== "immediate"
        });
        let d = Va(p === "before-paint" ? "layout" : "normal"),
            f = a.useRef(!1);
        d(() => {
            let h, k = (t == null ? void 0 : t.matches) && (t == null ? void 0 : t.matches(l)) || !(t != null && t.matches) && rn(t, l) || l === "",
                v = typeof o == "function" && o() || typeof o != "function" && o;
            return k && v && (h = c === "immediate" ? f.current ? i(null, r) : m.current : i(null, r)), k && !f.current && (f.current = !0), () => {
                var b;
                ((b = t.silent) === null || b === void 0 ? void 0 : b.matches(l)) || (f.current = !1, m.current = null), h == null || h()
            }
        }, [l !== "" ? t : null, l, o, i, ...u])
    },
    Us = e => {
        let t = a.useRef({
                value: e
            }),
            [n, l] = a.useState({
                value: e,
                silent: t.current
            }),
            i = a.useCallback(r => {
                let s = typeof r == "function" ? r(t.current.value) : r;
                t.current.value = s, l({
                    value: s,
                    silent: t.current
                })
            }, []);
        return [n, i]
    };

function er(...e) {
    return t => e.forEach(n => {
        typeof n == "function" ? n(t) : n != null && (n.current = t)
    })
}

function et(...e) {
    return a.useCallback(er(...e), e)
}
var Ys = (e, t) => {
    let n = () => {
            t == null || t()
        },
        l = r => {
            r.preventDefault(), window.addEventListener("touchend", n, {
                once: !0
            })
        },
        i = e.current;
    return i.addEventListener("touchstart", l, {
        passive: !1
    }), () => {
        i && (i.removeEventListener("touchstart", l, {
            passive: !1
        }), window.removeEventListener("touchend", n))
    }
};
let Aa = !1,
    Rl = 0;

function sn(e) {
    var t;
    if (a.useId !== void 0) return a.useId();
    let [n, l] = a.useState(Aa ? ++Rl : null);
    return De(() => {
        n === null && l(++Rl)
    }, []), a.useEffect(() => {
        Aa === !1 && (Aa = !0)
    }, []), (t = n) !== null && t !== void 0 ? t : void 0
}
let He = a.forwardRef((e, t) => {
    let s = e,
        {
            children: n
        } = s,
        l = ue(s, ["children"]),
        i = a.Children.toArray(n),
        r = i.find(Hs);
    if (r) {
        let o = r.props.children,
            u = i.map(c => c !== r ? c : a.Children.count(o) > 1 ? a.Children.only(null) : a.isValidElement(o) ? o.props.children : null);
        return I.jsx(Ma, M(y({}, l), {
            ref: t,
            children: a.isValidElement(o) ? a.cloneElement(o, void 0, u) : null
        }))
    }
    return I.jsx(Ma, M(y({}, l), {
        ref: t,
        children: n
    }))
});
He.displayName = "Slot.Root";
let Ma = a.forwardRef((e, t) => {
    let r = e,
        {
            children: n
        } = r,
        l = ue(r, ["children"]),
        i = (function(s) {
            var o, u;
            let c = (o = Object.getOwnPropertyDescriptor(s.props, "ref")) === null || o === void 0 ? void 0 : o.get,
                p = c && "isReactWarning" in c && c.isReactWarning;
            return p ? s.ref : (p = (c = (u = Object.getOwnPropertyDescriptor(s, "ref")) === null || u === void 0 ? void 0 : u.get) && "isReactWarning" in c && c.isReactWarning) ? s.props.ref : s.props.ref || s.ref
        })(n);
    return a.isValidElement(n) ? a.cloneElement(n, M(y({}, (function(s, o) {
        let u = y({}, o);
        for (let c in o) {
            let p = s[c],
                m = o[c];
            /^on[A-Z]/.test(c) ? p && m ? u[c] = (...f) => {
                m(...f), p(...f)
            } : p && (u[c] = p) : c === "style" ? u[c] = y(y({}, p), m) : c === "className" && (u[c] = [p, m].filter(Boolean).join(" "))
        }
        return y(y({}, s), u)
    })(l, n.props)), {
        ref: t ? er(t, i) : i
    })) : a.Children.count(n) > 1 ? a.Children.only(null) : null
});
Ma.displayName = "Slot.Anonymous";
let Xs = ({
    children: e
}) => I.jsx(I.Fragment, {
    children: e
});

function Hs(e) {
    return a.isValidElement(e) && e.type === Xs
}
let Zn = 0,
    tr = [0, 0],
    _a = !1,
    Pl = () => {
        clearTimeout(vl), _a = !0, vl = setTimeout(() => _a = !1, 50)
    },
    Il = () => {
        _a || window.scrollTo(...tr)
    },
    nr = ie.forwardRef((e, t) => {
        let b = e,
            {
                asChild: n,
                active: l = !0,
                automaticallyDisabledForOptimisation: i = !0,
                axis: r = "both",
                preventBodyScroll: s,
                children: o,
                "data-silk": u,
                className: c
            } = b,
            p = ue(b, ["asChild", "active", "automaticallyDisabledForOptimisation", "axis", "preventBodyScroll", "children", "data-silk", "className"]),
            m = u == null ? void 0 : u.includes("0ae"),
            d = a.useRef(null),
            f = et(d, t);
        De(() => {
            if (tr = [window.screenX, window.scrollY], l && s)
                if (Zn === 0) {
                    let C = window.innerWidth,
                        A = document.documentElement.clientWidth,
                        x = window.innerHeight,
                        B = document.documentElement.clientHeight;
                    document.body.style.setProperty("overflow", "hidden");
                    let X = "".concat(C - A, "px"),
                        N = "".concat(x - B, "px");
                    document.querySelectorAll("[data-silk~='0al']").forEach(O => {
                        O.style.setProperty("--x-collapsed-scrollbar-thickness", X), O.style.setProperty("--y-collapsed-scrollbar-thickness", N)
                    }), document.body.style.setProperty("padding-right", X), document.body.style.setProperty("padding-bottom", N), window.addEventListener("resize", Pl), window.addEventListener("scroll", Il, {
                        passive: !1
                    }), Zn++
                } else Zn++;
            return () => {
                if (l && s && --Zn == 0) {
                    let C = document.querySelectorAll("[data-silk~='0al']");
                    document.body.style.removeProperty("overflow"), C.forEach(A => {
                        A.style.removeProperty("--x-collapsed-scrollbar-thickness"), A.style.removeProperty("--y-collapsed-scrollbar-thickness")
                    }), document.body.style.removeProperty("padding-right"), document.body.style.removeProperty("padding-bottom"), window.removeEventListener("scroll", Il), window.removeEventListener("resize", Pl)
                }
            }
        }, [s, l]), a.useEffect(() => {
            let C, A = d.current;
            return !m && l && A && (C = new ResizeObserver(x => {
                x.forEach(() => {
                    A.scrollTo(300, 300)
                })
            })).observe(A, {
                box: "border-box"
            }), () => {
                !m && l && A && C && (C.unobserve(A), C.disconnect())
            }
        }, [l, m]);
        let h = a.useCallback(C => {
                let A = C.currentTarget;
                A.scrollTo(300, 300), Re !== "ios" && Re !== "ipados" || CSS.supports("overscroll-behavior: contain") || (A.style.setProperty("overflow", "hidden"), setTimeout(() => {
                    A.style.setProperty("overflow", "auto")
                }, 10))
            }, []),
            k = n ? He : "div",
            v = Xe("ScrollTrap", {
                active: l,
                automaticallyDisabledForOptimisation: i,
                axis: r
            });
        return I.jsx(k, M(y(M(y({}, v("root", ["active", "automaticallyDisabledForOptimisation", "axis"], {
            className: c,
            dataSilk: [u, "0ac", "0ae"]
        })), {
            onScroll: m ? void 0 : h
        }), p), {
            ref: f,
            children: o
        }))
    });
nr.displayName = "Sheet.Anonymous";
let ar = ie.forwardRef((e, t) => {
    let c = e,
        {
            asChild: n,
            className: l,
            dataSilk: i,
            children: r
        } = c,
        s = ue(c, ["asChild", "className", "dataSilk", "children"]),
        o = n ? He : "div",
        u = Xe("ScrollTrap", {});
    return I.jsx(o, M(y(y({}, u("stabiliser", [], {
        className: l,
        dataSilk: [i]
    })), s), {
        ref: t,
        children: r
    }))
});
ar.displayName = "Sheet.DDD";
let Pt = {
        Root: nr,
        Stabiliser: ar
    },
    lr = () => {
        let e = sn();
        return a.useCallback(n => {
            n ? K.addFixedComponent({
                id: e,
                element: n
            }) : K.removeFixedComponent(e)
        }, [e])
    },
    rr = ie.forwardRef((e, t) => {
        let p = e,
            {
                asChild: n,
                children: l,
                className: i,
                "data-silk": r
            } = p,
            s = ue(p, ["asChild", "children", "className", "data-silk"]),
            o = lr(),
            u = et(o, t),
            c = Xe("Fixed", {});
        return I.jsx(Pt.Root, M(y(M(y({}, c("root", [], {
            className: i,
            dataSilk: [r, "0al"]
        })), {
            asChild: n
        }), s), {
            ref: u,
            children: l
        }))
    });
rr.displayName = "Fixed.Root";
let sr = ie.forwardRef((e, t) => {
    let r = e,
        {
            asChild: n,
            children: l
        } = r,
        i = ue(r, ["asChild", "children"]);
    return I.jsx(Pt.Stabiliser, M(y({
        asChild: n
    }, i), {
        ref: t,
        children: l
    }))
});
sr.displayName = "Fixed.Content";
let hi = {
        Root: rr,
        Content: sr
    },
    zt = ie.createContext(null);
zt.displayName = "Sheet.GenericContext";
let ht = ie.createContext(null);
ht.displayName = "Sheet.Anonymous";
var ir = function(e) {
        let t = "cubic-bezier(";
        if (!e.startsWith(t)) return null;
        let n = e.slice(t.length, -1),
            l = n.split(",").map(i => parseFloat(i.trim()));
        return l.length !== 4 || l.some(isNaN) ? null : l
    },
    zs = ({
        mass: e,
        stiffness: t,
        damping: n,
        initialVelocity: l = 0,
        fromPosition: i,
        toPosition: r,
        precision: s
    }) => {
        let o = [],
            u = 0,
            c = Math.abs(r - i),
            p = 0,
            m = l,
            d = !1,
            f = !1,
            h = -(1e-6 * t),
            k = -(.001 * n),
            v = s / 22,
            b = 10 * s;
        for (; !(d && f);) {
            let A = h * (p - c),
                x = k * m,
                B = (A + x) / e;
            m += B, p += m, d = Math.abs(m) <= v, f = Math.abs(c - p) <= b;
            let X = p / c;
            o.push(X), u++
        }
        return {
            progressValuesArray: o,
            duration: u
        }
    };
let aa = () => CSS.supports("transition-timing-function", "linear(0, 1)") && !Rt(),
    Gs = ({
        origin: e = 0,
        destination: t = 1,
        animationConfig: n
    }) => {
        var l, i, r, s, o, u, c, p, m;
        let d = [],
            f;
        if (n && n.easing && n.easing !== "spring")
            if (n.easing === "linear") {
                f = (u = n.duration) !== null && u !== void 0 ? u : 250;
                let h = f,
                    k = 1 / (h - 1);
                for (let v = 0; v < h; v++) {
                    let b = v * k;
                    d.push(isNaN(b) ? 0 : b)
                }
            } else {
                let h;
                f = (c = n.duration) !== null && c !== void 0 ? c : 250;
                let k = f;
                h = n.easing === "ease" ? [.25, .1, .25, 1] : n.easing === "ease-in" ? [.42, 0, 1, 1] : n.easing === "ease-out" ? [0, 0, .58, 1] : n.easing === "ease-in-out" ? [.42, 0, .58, 1] : n.easing.startsWith("cubic-bezier") && (p = ir(n.easing)) !== null && p !== void 0 ? p : [.25, .1, .25, 1];
                let v = Vl(...h);
                for (let b = 0; b <= k; b++) d.push(v(b / k))
            }
        else {
            let h = zs({
                stiffness: (l = n == null ? void 0 : n.stiffness) !== null && l !== void 0 ? l : 300,
                damping: (i = n == null ? void 0 : n.damping) !== null && i !== void 0 ? i : 34,
                mass: (r = n == null ? void 0 : n.mass) !== null && r !== void 0 ? r : 1,
                initialVelocity: (s = n == null ? void 0 : n.initialVelocity) !== null && s !== void 0 ? s : 0,
                precision: (o = n == null ? void 0 : n.precision) !== null && o !== void 0 ? o : .1,
                fromPosition: e,
                toPosition: t
            });
            d = h.progressValuesArray, f = h.duration
        }
        return {
            progressValuesArray: d,
            easing: "linear",
            duration: f,
            delay: (m = n == null ? void 0 : n.delay) !== null && m !== void 0 ? m : 0
        }
    },
    xa = (e, t) => {
        let n = {};
        return e.forEach(([l, i]) => {
            let r = Sn(t);
            n[l] = i({
                progress: t,
                tween: r
            })
        }), n
    },
    Dl = ({
        type: e,
        progressValuesArray: t,
        target: n,
        templatesPerProperty: l,
        reversedStackingIndex: i,
        selfAndAboveTravelProgressSum: r
    }) => {
        let s = i != null,
            o = u => e === "travel" ? u : s && r ? (r == null ? void 0 : r[i]) + u : 0;
        return {
            target: n,
            keyframes: aa() ? [xa(l, o(t[0])), xa(l, o(t[t.length - 1]))] : t.map(u => xa(l, o(u)))
        }
    },
    $s = ({
        sheetId: e,
        destinationDetent: t,
        setSegment: n,
        viewElement: l,
        scrollContainer: i,
        travellingElement: r,
        contentPlacement: s,
        positionToScrollTo: o,
        scrollAxis: u,
        animationConfig: c,
        onTravel: p,
        onTravelStart: m,
        onTravelEnd: d,
        runOnTravelStart: f,
        rAFLoopEndCallback: h,
        dimensions: k,
        trackToTravelOn: v
    }) => {
        let b, C, A = K.findSheet(e);
        if (!A) return;
        let x = [],
            B = [];
        x = A.travelAnimations, A.belowSheetsInStack.forEach(R => {
            B.push(...R.stackingAnimations.map(we => M(y({}, we), {
                reversedStackingIndex: A.belowSheetsInStack.length - 1,
                selfAndAboveTravelProgressSum: R.selfAndAboveTravelProgressSum
            })))
        }), f && (m == null || m());
        let X = !(c.hasOwnProperty("contentMove") && !c.contentMove),
            N = k.current.view.travelAxis.unitless,
            q = k.current.content.travelAxis.unitless,
            O = l.getBoundingClientRect(),
            _ = r.getBoundingClientRect(),
            W = s !== "center" ? q : q + (N - q) / 2,
            D = _.top - O.top,
            L = _.left - O.left,
            F = 0;
        switch (v) {
            case "top":
                F = D + W;
                break;
            case "bottom":
                F = D - W;
                break;
            case "left":
                F = L + W;
                break;
            case "right":
                F = L - W
        }
        let ee = Math.max(Math.abs(F) / W, 0),
            ne = k.current.progressValueAtDetents[t].exact,
            H = ne * W,
            ce = v === "left" || v === "top" ? H : -H,
            {
                progressValuesArray: Ne,
                easing: Q,
                duration: ze,
                delay: Je
            } = Gs({
                origin: F,
                destination: ce,
                animationConfig: c
            }),
            mt = ne - ee,
            Le = (function(R, we) {
                let _e = [];
                for (let Pe = 0; Pe < R.length - 1; Pe += we) _e.push(R[Pe]);
                return R.length % we != 0 && _e.push(R[R.length - 1]), _e
            })(Ne, 8),
            Fe = Le.map(R => ee + mt * R),
            re = [];
        x.length && (re == null || re.push(...x.map(R => Dl({
            type: "travel",
            progressValuesArray: Fe,
            target: R.target,
            templatesPerProperty: R.config
        })))), B.length && (re == null || re.push(...B.map(R => Dl({
            type: "stacking",
            progressValuesArray: Fe,
            target: R.target,
            templatesPerProperty: R.config,
            reversedStackingIndex: R.reversedStackingIndex,
            selfAndAboveTravelProgressSum: R.selfAndAboveTravelProgressSum
        })))), b = u === "x" ? "X" : "Y";
        let xe = R => ({
            transform: "translate" + b + "(" + (F - ce) * (1 - R) + "px)"
        });
        C = aa() ? [xe(Le[0]), xe(Le[Le.length - 1])] : Le.map(R => ({
            transform: "translate" + b + "(" + (F - ce) * (1 - R) + "px)"
        }));
        let ge = () => {
                i.scrollTo({
                    left: u === "x" ? o : 0,
                    top: u === "y" ? o : 0
                })
            },
            Be = R => {
                let we;
                if (!X) return R();
                we = aa() ? r.animate(C, {
                    easing: "linear(" + Le.join(",") + ")",
                    duration: ze,
                    delay: Je
                }) : r.animate(C, {
                    easing: Q,
                    duration: ze,
                    delay: Je
                });
                let _e = () => {
                    R(), we.removeEventListener("finish", _e)
                };
                we.addEventListener("finish", _e)
            },
            me = R => {
                if (!re.length) return R();
                let we = [],
                    _e = aa();
                re == null || re.forEach(({
                    target: Pe,
                    keyframes: U
                }) => {
                    let w;
                    w = _e ? Pe.animate(U, {
                        easing: "linear(" + Le.join(",") + ")",
                        duration: ze,
                        delay: Je
                    }) : Pe.animate(U, {
                        easing: Q,
                        duration: ze,
                        delay: Je
                    });
                    let Ge = new Promise(he => {
                        let yt = () => {
                            Object.entries(U[U.length - 1]).forEach(([fe, Ie]) => {
                                Pe.style.setProperty((fe.startsWith("webkit") || fe.startsWith("moz") ? "-" : "") + fe.replace(/[A-Z]/g, "-$&").toLowerCase(), Ie)
                            }), w.removeEventListener("finish", yt), he()
                        };
                        w.addEventListener("finish", yt)
                    });
                    we.push(Ge)
                }), Promise.all(we).then(() => {
                    R()
                })
            },
            de = null,
            vt = R => {
                (function we(_e, Pe, U) {
                    let w = k.current.progressValueAtDetents,
                        Ge = w.length;
                    de || (de = _e);
                    let he = _e - de,
                        yt = Math.floor(he);
                    if (yt < Ne.length) {
                        let fe = ee + mt * Ne[yt];
                        if (fe < 0) Pe(fe, [0, 0]);
                        else if (fe > 1) Pe(fe, [1, 1]);
                        else
                            for (let Ie = 0; Ie < Ge; Ie++) {
                                let te = w[Ie],
                                    It = te.after;
                                fe > It && Ie + 1 < Ge && fe < w[Ie + 1].before ? Pe(fe, [Ie, Ie + 1]) : fe > te.before && fe < It && Pe(fe, [Ie, Ie])
                            }
                        requestAnimationFrame(() => we(document.timeline.currentTime, Pe, U))
                    } else {
                        let fe = Math.min(Ge - 1, t);
                        Pe(ne, [fe, fe]), X || re != null && re.length || h == null || h(), U()
                    }
                })(document.timeline.currentTime, (we, _e) => {
                    p == null || p({
                        progress: we,
                        range: {
                            start: _e[0],
                            end: _e[1]
                        },
                        progressAtDetents: k.current.exactProgressValueAtDetents
                    }), n(_e)
                }, R)
            },
            Ee = R => new Promise(we => {
                R(() => we())
            }),
            Me = () => {
                d == null || d()
            },
            ae = async () => {
                await Promise.all([Ee(Be), Ee(me), Ee(vt)]), Me()
            };
        requestAnimationFrame(() => {
            requestAnimationFrame(() => {
                (X || t !== 0) && ge(), ae()
            })
        })
    },
    Ks = ({
        desiredDestinationDetent: e,
        currentDetent: t
    }) => typeof e == "number" ? e : t,
    qs = ({
        trackToTravelOn: e,
        destinationDetent: t,
        detentCountExcludingZero: n,
        actualSwipeOutDisabledWithDetent: l,
        hasOppositeTracks: i,
        contentPlacement: r,
        elementsDimensions: s,
        snapBackAcceleratorTravelAxisSize: o
    }) => {
        var u;
        if (((u = s.detentMarkers) === null || u === void 0 ? void 0 : u.length) <= t - 1) return {
            positionToScrollTo: null,
            scrollAxis: null
        };
        let c = t === 0,
            p = t === 1,
            m = t === n,
            d = e === "right" || e === "bottom",
            f = s.view.travelAxis.unitless,
            h = s.content.travelAxis.unitless,
            k = s.snapOutAccelerator.travelAxis.unitless,
            v = s.detentMarkers,
            b = c ? 0 : v[t - 1].accumulatedOffsets.travelAxis.unitless,
            C = 0;
        if (i) m ? C = f - (f - h) / 2 + s.snapOutAccelerator.travelAxis.unitless : c && (C = d ? 0 : 1e4);
        else if (d) m ? C = 1e4 : l && p || c ? C = 0 : m || l && p || c || (C = l ? v[t - 1].accumulatedOffsets.travelAxis.unitless - v[0].travelAxis.unitless : b + k);
        else if (e === "left" || e === "top") {
            let A;
            A = l ? p ? 2 * o : m ? 0 : o : c ? k : m ? o : 0, C = r === "center" ? t === 0 ? h + (f - h) / 2 - b + A : 0 : h - b + A
        }
        return {
            positionToScrollTo: C,
            scrollAxis: e === "left" || e === "right" || e === "horizontal" ? "x" : "y"
        }
    };
var Js = ({
    destinationDetent: e,
    behavior: t = "instant",
    runTravelCallbacksAndAnimations: n = !0,
    runOnTravelStart: l,
    animationConfig: i,
    rAFLoopEndCallback: r,
    trackToTravelOn: s,
    contentPlacement: o,
    onTravel: u,
    onTravelStart: c,
    onTravelEnd: p,
    fullTravelCallback: m,
    setProgrammaticScrollOngoing: d,
    currentDetent: f,
    segment: h,
    setSegment: k,
    lastProgressValue: v,
    dimensions: b,
    viewRef: C,
    scrollContainerRef: A,
    contentWrapperRef: x,
    sheetId: B,
    stackId: X,
    actualSwipeOutDisabledWithDetent: N,
    hasOppositeTracks: q,
    snapBackAcceleratorTravelAxisSize: O
}) => {
    if (e === void 0 && f === null) return;
    let _ = b.current,
        W = A.current;
    if (W && _.content) {
        let D = Ks({
                desiredDestinationDetent: e,
                currentDetent: f
            }),
            L = b.current.detentMarkers.length,
            {
                positionToScrollTo: F,
                scrollAxis: ee
            } = qs({
                destinationDetent: D,
                detentCountExcludingZero: L,
                trackToTravelOn: s,
                actualSwipeOutDisabledWithDetent: N,
                hasOppositeTracks: q,
                contentPlacement: o,
                snapBackAcceleratorTravelAxisSize: O,
                elementsDimensions: _
            });
        if (F !== null && ee !== null) {
            if (d(!0), t === "smooth") $s({
                sheetId: B,
                destinationDetent: D,
                setSegment: k,
                viewElement: C.current,
                scrollContainer: W,
                travellingElement: x.current,
                positionToScrollTo: F,
                contentPlacement: o,
                scrollAxis: ee,
                animationConfig: i,
                onTravel: u,
                onTravelStart: c,
                onTravelEnd: p,
                runOnTravelStart: l,
                rAFLoopEndCallback: r,
                dimensions: b,
                trackToTravelOn: s
            });
            else if (n && l && (c == null || c()), ee === "x" ? (W.scrollTo(F, 0), W.scrollLeft = F) : (W.scrollTo(0, F), W.scrollTop = F), k([D, D]), n) {
                let ne = b.current.progressValueAtDetents[D].exact;
                m == null || m(ne, h), p == null || p()
            }
        }
    }
};
let Dn = e => {
        let t = a.useRef(null);
        return De(() => {
            t.current = e
        }), a.useCallback((...n) => {
            let l = t.current;
            return l(...n)
        }, [])
    },
    Zs = e => {
        let t, n = () => {
            e(), t = requestAnimationFrame(n)
        };
        return n(), () => {
            cancelAnimationFrame(t)
        }
    },
    Qs = (() => {
        let e = !0;
        typeof window > "u" || CSS.supports("scroll-snap-align: start") || (e = !1);
        let t = !0;
        return typeof window > "u" || "IntersectionObserver" in window && "IntersectionObserverEntry" in window && "intersectionRatio" in window.IntersectionObserverEntry.prototype || (t = !1), e && t
    })(),
    sa = {
        gentle: {
            stiffness: 560,
            damping: 68,
            mass: 1.85
        },
        smooth: {
            stiffness: 580,
            damping: 60,
            mass: 1.35
        },
        snappy: {
            stiffness: 350,
            damping: 34,
            mass: .9
        },
        brisk: {
            stiffness: 350,
            damping: 28,
            mass: .65
        },
        bouncy: {
            stiffness: 240,
            damping: 19,
            mass: .7
        },
        elastic: {
            stiffness: 260,
            damping: 20,
            mass: 1
        }
    },
    Oa = (e, t) => {
        var n;
        let l = typeof e == "string",
            i = l ? sa[e] : (n = sa[e == null ? void 0 : e.preset]) !== null && n !== void 0 ? n : null,
            r = i || (e == null ? void 0 : e.easing) === "spring" || ["ease", "ease-in", "ease-out", "ease-in-out", "linear"].includes(e == null ? void 0 : e.easing);
        return y(y(y({
            skip: Ba,
            easing: "spring"
        }, l ? {} : e), i != null ? i : {}), r ? {} : t)
    },
    ei = (e, t) => e.includes("skipOpening:true") || t.skipOpening,
    Nl = (e, t) => !e.includes("skipOpening:true") && !t.skipOpening,
    ti = (e, t) => e.includes("skipClosing:true") || t.skipClosing,
    ni = (e, t) => !e.includes("skipClosing:true") && !t.skipClosing,
    Ll = e => e.includes("openness:closed.status:safe-to-unmount"),
    ai = () => {
        let e = "false",
            [t, n] = Ol(a.useMemo(() => [{
                name: "staging",
                initial: "none",
                states: {
                    none: {
                        messages: {
                            OPEN: [{
                                guard: (h, k) => Ll(h) && Nl(h, k),
                                target: "opening"
                            }, {
                                guard: Ll,
                                target: "open"
                            }],
                            OPEN_PREPARED: [{
                                guard: Nl,
                                target: "opening"
                            }, {
                                target: "open"
                            }],
                            ACTUALLY_CLOSE: [{
                                guard: ni,
                                target: "closing"
                            }],
                            ACTUALLY_STEP: "stepping",
                            GO_DOWN: [{
                                guard: (h, k) => !k.skipOpening,
                                target: "going-down"
                            }, {
                                target: "go-down"
                            }],
                            GO_UP: "going-up"
                        }
                    },
                    open: {
                        messages: {
                            NEXT: "none"
                        }
                    },
                    opening: {
                        messages: {
                            NEXT: "none"
                        }
                    },
                    stepping: {
                        messages: {
                            NEXT: "none"
                        }
                    },
                    closing: {
                        messages: {
                            NEXT: "none"
                        }
                    },
                    "go-down": {
                        messages: {
                            NEXT: "none"
                        }
                    },
                    "going-down": {
                        messages: {
                            NEXT: "none"
                        }
                    },
                    "going-up": {
                        messages: {
                            NEXT: "none"
                        }
                    }
                }
            }, {
                name: "longRunning",
                initial: e,
                states: {
                    false: {
                        messages: {
                            TO_TRUE: "true"
                        }
                    },
                    true: {
                        messages: {
                            TO_FALSE: "false"
                        }
                    }
                }
            }, {
                name: "openness",
                initial: "closed",
                states: {
                    closed: {
                        messages: {
                            READY_TO_OPEN: [{
                                guard: (h, k) => !k.skipOpening,
                                target: "opening"
                            }, {
                                target: "open"
                            }]
                        },
                        machines: {
                            name: "status",
                            initial: "safe-to-unmount",
                            states: {
                                pending: {
                                    messages: {
                                        OPEN: [{
                                            guard: ei,
                                            target: "openness:closed.status:flushing-to-preparing-open"
                                        }, {
                                            target: "openness:closed.status:flushing-to-preparing-opening"
                                        }],
                                        "": "safe-to-unmount"
                                    }
                                },
                                "flushing-to-preparing-open": {
                                    messages: {
                                        "": "preparing-open"
                                    }
                                },
                                "flushing-to-preparing-opening": {
                                    messages: {
                                        "": "preparing-opening"
                                    }
                                },
                                "preparing-open": {},
                                "preparing-opening": {},
                                "safe-to-unmount": {}
                            }
                        }
                    },
                    opening: {
                        messages: {
                            NEXT: "open"
                        }
                    },
                    open: {
                        messages: {
                            ACTUALLY_CLOSE: [{
                                guard: ti,
                                target: "openness:closed.status:pending"
                            }],
                            SWIPED_OUT: "openness:closed.status:pending",
                            READY_TO_CLOSE: [{
                                guard: (h, k) => !k.skipClosing,
                                target: "closing"
                            }]
                        },
                        machines: [{
                            name: "scroll",
                            initial: "ended",
                            states: {
                                ended: {
                                    messages: {
                                        SCROLL_START: "ongoing"
                                    },
                                    machines: [{
                                        name: "afterPaintEffectsRun",
                                        initial: "false",
                                        states: {
                                            false: {
                                                messages: {
                                                    OCCURRED: "true"
                                                }
                                            },
                                            true: {}
                                        }
                                    }]
                                },
                                ongoing: {
                                    messages: {
                                        SCROLL_END: "ended"
                                    }
                                }
                            }
                        }, {
                            name: "move",
                            initial: "ended",
                            states: {
                                ended: {
                                    messages: {
                                        MOVE_START: "ongoing"
                                    }
                                },
                                ongoing: {
                                    messages: {
                                        MOVE_END: "ended"
                                    }
                                }
                            }
                        }, {
                            name: "swipe",
                            silentOnly: !0,
                            initial: "unstarted",
                            states: {
                                unstarted: {
                                    messages: {
                                        SWIPE_START: "ongoing"
                                    }
                                },
                                ongoing: {
                                    messages: {
                                        SWIPE_END: "ended"
                                    }
                                },
                                ended: {
                                    messages: {
                                        SWIPE_START: "ongoing",
                                        SWIPE_RESET: "unstarted"
                                    }
                                }
                            }
                        }, {
                            name: "evaluateCloseMessage",
                            silentOnly: !0,
                            initial: "false",
                            states: {
                                false: {
                                    messages: {
                                        CLOSE: "true"
                                    }
                                },
                                true: {
                                    messages: {
                                        CLOSE: "false"
                                    }
                                }
                            }
                        }, {
                            name: "evaluateStepMessage",
                            silentOnly: !0,
                            initial: "false",
                            states: {
                                false: {
                                    messages: {
                                        STEP: "true"
                                    }
                                },
                                true: {
                                    messages: {
                                        STEP: "false"
                                    }
                                }
                            }
                        }]
                    },
                    closing: {
                        messages: {
                            NEXT: "openness:closed.status:pending"
                        }
                    }
                }
            }, {
                name: "skipOpening",
                initial: "false",
                states: {
                    true: {
                        messages: {
                            TO_FALSE: "false"
                        }
                    },
                    false: {
                        messages: {
                            TO_TRUE: "true"
                        }
                    }
                }
            }, {
                name: "skipClosing",
                initial: "false",
                states: {
                    true: {
                        messages: {
                            TO_FALSE: "false"
                        }
                    },
                    false: {
                        messages: {
                            TO_TRUE: "true"
                        }
                    }
                }
            }, {
                name: "scrollContainerTouch",
                silentOnly: !0,
                initial: "ended",
                states: {
                    ended: {
                        messages: {
                            TOUCH_START: "ongoing"
                        }
                    },
                    ongoing: {
                        messages: {
                            TOUCH_END: "ended"
                        }
                    }
                }
            }, {
                name: "backStuck",
                silentOnly: !0,
                initial: "false",
                states: {
                    false: {
                        messages: {
                            STUCK_START: "true"
                        }
                    },
                    true: {
                        messages: {
                            STUCK_END: "false"
                        }
                    }
                }
            }, {
                name: "frontStuck",
                silentOnly: !0,
                initial: "false",
                states: {
                    false: {
                        messages: {
                            STUCK_START: "true"
                        }
                    },
                    true: {
                        messages: {
                            STUCK_END: "false"
                        }
                    }
                }
            }], [e])),
            [l, i] = Ol(a.useMemo(() => [{
                name: "active",
                initial: "false",
                states: {
                    false: {
                        messages: {
                            TO_TRUE: "true"
                        }
                    },
                    true: {
                        messages: {
                            TO_FALSE: "false"
                        }
                    }
                }
            }, {
                name: "position",
                initial: "out",
                states: {
                    out: {
                        messages: {
                            READY_TO_GO_FRONT: [{
                                guard: (h, k) => k.skipOpening,
                                target: "position:front.status:idle"
                            }, {
                                target: "position:front.status:opening"
                            }]
                        }
                    },
                    front: {
                        machines: [{
                            name: "status",
                            initial: "opening",
                            states: {
                                opening: {
                                    messages: {
                                        NEXT: "idle"
                                    }
                                },
                                closing: {
                                    messages: {
                                        NEXT: "position:out"
                                    }
                                },
                                idle: {
                                    messages: {
                                        READY_TO_GO_DOWN: [{
                                            guard: (h, k) => k.skipOpening,
                                            target: "position:covered.status:idle"
                                        }, {
                                            target: "position:covered.status:going-down"
                                        }],
                                        READY_TO_GO_OUT: "closing",
                                        GO_OUT: "position:out"
                                    }
                                }
                            }
                        }]
                    },
                    covered: {
                        machines: [{
                            name: "status",
                            initial: "going-down",
                            states: {
                                "going-down": {
                                    messages: {
                                        NEXT: "idle"
                                    }
                                },
                                "going-up": {
                                    messages: {
                                        NEXT: "indeterminate"
                                    }
                                },
                                indeterminate: {
                                    messages: {
                                        GOTO_idle: "idle",
                                        GOTO_front: "position:front.status:idle"
                                    }
                                },
                                idle: {
                                    messages: {
                                        READY_TO_GO_DOWN: [{
                                            guard: (h, k) => k.skipOpening,
                                            target: "come-back"
                                        }, {
                                            target: "going-down"
                                        }],
                                        READY_TO_GO_UP: "going-up",
                                        GO_UP: "indeterminate"
                                    }
                                },
                                "come-back": {
                                    messages: {
                                        "": "idle"
                                    }
                                }
                            }
                        }]
                    }
                }
            }], [])),
            r = a.useMemo(() => l.matches("position:out") ? "out" : l.matches("position:front") ? "front" : l.matches("position:covered") ? "covered" : void 0, [l]),
            s = a.useMemo(() => l.matches("position:covered.status:idle") ? "idle" : l.matches("position:covered.status:going-down") ? "going-down" : l.matches("position:covered.status:going-up") ? "going-up" : null, [l]),
            o = gt(t, "staging"),
            u = a.useMemo(() => o.getValues()[0], [o]),
            [c, p] = Us(-1),
            m = sn(),
            d = sn();
        return a.useMemo(() => ({
            titleId: m,
            descriptionId: d,
            staging: u,
            opennessState: t,
            sendToOpennessMachine: n,
            positionState: l,
            sendToPositionMachine: i,
            layerPosition: r,
            layerCovered: s,
            stackingIndex: c,
            assignStackingIndex: p
        }), [m, d, u, t, n, l, i, r, s, c, p])
    },
    or = ie.forwardRef((e, t) => {
        let n, ul = e,
            {
                forComponent: l,
                as: i,
                children: r,
                className: s,
                "data-silk": o,
                initialState: u,
                onPresentAutoFocus: c,
                onDismissAutoFocus: p,
                onTravelStatusChange: m,
                onTravelRangeChange: d,
                swipeDismissal: f = !0,
                swipe: h = !0,
                snapOutAcceleration: k = "auto",
                snapToEndDetentsAcceleration: v = "auto",
                onTravel: b,
                onTravelStart: C,
                onTravelEnd: A,
                detents: x,
                inertOutside: B = !0,
                nativeEdgeSwipePrevention: X = !1,
                onSwipeFromEdgeToGoBackAttempt: N,
                onClickOutside: q,
                onEscapeKeyDown: O,
                onFocusInside: _,
                nativeFocusScrollPrevention: W = !0,
                contentPlacement: D = null,
                tracks: L,
                swipeOvershoot: F = !0,
                swipeTrap: ee,
                enteringAnimationSettings: ne,
                exitingAnimationSettings: H,
                steppingAnimationSettings: ce,
                id: Ne
            } = ul,
            Q = ue(ul, ["forComponent", "as", "children", "className", "data-silk", "initialState", "onPresentAutoFocus", "onDismissAutoFocus", "onTravelStatusChange", "onTravelRangeChange", "swipeDismissal", "swipe", "snapOutAcceleration", "snapToEndDetentsAcceleration", "onTravel", "onTravelStart", "onTravelEnd", "detents", "inertOutside", "nativeEdgeSwipePrevention", "onSwipeFromEdgeToGoBackAttempt", "onClickOutside", "onEscapeKeyDown", "onFocusInside", "nativeFocusScrollPrevention", "contentPlacement", "tracks", "swipeOvershoot", "swipeTrap", "enteringAnimationSettings", "exitingAnimationSettings", "steppingAnimationSettings", "id"]),
            ze = l != null ? l : zt,
            Je = a.useContext(ze) || {},
            {
                license: mt,
                StackContext: Le,
                CustomSheetContext: Fe,
                sheetRole: re,
                open: xe,
                onOpenChange: ge,
                elementFocusedLastBeforeShowing: Be,
                onSafeToUnmountChange: me,
                setLongRunning: de,
                setStaging: vt,
                defaultActiveDetent: Ee,
                activeDetent: Me,
                onActiveDetentChange: ae,
                sheetId: R
            } = Je,
            {
                titleId: we,
                descriptionId: _e,
                staging: Pe,
                opennessState: U,
                sendToOpennessMachine: w,
                positionState: Ge,
                sendToPositionMachine: he,
                layerCovered: yt,
                stackingIndex: fe,
                assignStackingIndex: Ie
            } = ai(),
            te = gt(U, "staging"),
            {
                stackId: It,
                setSheetsCount: tt,
                updateSheetStagingDataInStack: Tn,
                removeSheetStagingDataInStack: on,
                updateSheetDataInStack: Dt,
                removeSheetDataFromStack: un,
                getPreviousSheetDataInStack: $t
            } = Le ? a.useContext(Le) : {},
            {
                ancestorPrimarySwipeTrapActiveOnYAxis: Nt
            } = a.useContext(ht) || {},
            nt = lr(),
            We = a.useRef(null),
            kt = et(We, nt, t),
            Kt = a.useRef(null),
            qt = a.useRef(null),
            Oe = a.useRef(null),
            cn = a.useRef(null),
            Ct = a.useRef(null),
            Lt = a.useRef(null),
            En = a.useRef(null),
            dn = a.useRef([]),
            at = a.useMemo(() => x ? typeof x == "string" ? [x, "var(--silk-aF)"] : [...x, "var(--silk-aF)"] : ["var(--silk-aF)"], [x]),
            Mt = a.useRef(null);
        a.useEffect(() => {
            Mt.current === null && Number.isInteger(Me) && Me > 0 && (Mt.current = Me)
        }, []);
        let Ye = a.useMemo(() => Number.isInteger(Ee) ? Ee : Number.isInteger(Me) && Me > 0 ? Me : Mt.current ? Mt.current : 1, [Me, Ee]),
            {
                actualTrack: z,
                actualPlacement: Ae
            } = a.useMemo(() => {
                let g = {
                    actualPlacement: null,
                    actualTrack: null
                };
                return D && !L ? (g.actualPlacement = D, D !== "center" ? g.actualTrack = D : g.actualTrack = "bottom") : L && !D ? Array.isArray(L) ? (g.actualPlacement = "center", g.actualTrack = L.includes("left") ? "horizontal" : "vertical") : (g.actualPlacement = L, g.actualTrack = L) : L || D ? L && D && (g.actualPlacement = D, Array.isArray(L) ? g.actualTrack = L.includes("left") ? "horizontal" : "vertical" : g.actualTrack = L) : (g.actualPlacement = "bottom", g.actualTrack = "bottom"), [{
                    state: "staging:opening",
                    configTrack: ne == null ? void 0 : ne.track
                }, {
                    state: "staging:closing",
                    configTrack: H == null ? void 0 : H.track
                }].forEach(({
                    state: T,
                    configTrack: E
                }) => {
                    U.matches(T) && E && (E === "top" && g.actualTrack === "bottom" || E === "bottom" && g.actualTrack === "top" ? g.actualTrack = "vertical" : (E === "left" && g.actualTrack === "right" || E === "right" && g.actualTrack === "left") && (g.actualTrack = "horizontal"))
                }), g
            }, [D, L, ne == null ? void 0 : ne.track, H == null ? void 0 : H.track, U]);
        a.useMemo(() => z === "horizontal", [z]);
        let pa = a.useMemo(() => z === "vertical", [z]);
        a.useEffect(() => {
            if (D != null && D.includes("top") && L && L !== "top" || D != null && D.includes("bottom") && L && L !== "bottom" || !(D != null && D.includes("center")) && L && L.includes("top") && L.includes("bottom") || D != null && D.includes("left") && L && L !== "left" || D != null && D.includes("right") && L && L !== "right" || !(D != null && D.includes("center")) && L && L.includes("left") && L.includes("right")) throw Error("'placement' prop value '".concat(D, "' cannot be used with 'tracks' prop value '").concat(L, "'."))
        }, [D, L]);
        let Tt = a.useMemo(() => (ne == null ? void 0 : ne.track) || (z === "horizontal" ? "right" : z === "vertical" ? "bottom" : z), [ne == null ? void 0 : ne.track, z]),
            lt = a.useMemo(() => Oa(ne, sa.smooth), [ne]),
            _t = a.useMemo(() => Oa(H, {
                easing: "spring",
                stiffness: 520,
                damping: 44,
                mass: 1
            }), [H]),
            P = a.useMemo(() => Oa(ce != null ? ce : ne, sa.smooth), [ce, ne]),
            oe = a.useMemo(() => re === "alertdialog" || !f, [f, re]),
            Z = (z !== "horizontal" && z !== "vertical" || !!oe) && !F,
            [ke, G, ve, ye] = a.useMemo(() => {
                let g = !1,
                    S = !1,
                    T = !1,
                    E = !1;
                return h && Qs ? oe && (x ? (T = !0, U.matches("openness:open") && !U.matches("staging:closing") && (S = !0)) : U.matches("openness:open") && !U.matches("staging:closing") && (Z === !1 && Rt() ? E = !0 : g = !0)) : U.matches("openness:closed") || (g = !0), [g, S, T, E]
            }, [h, U, oe, x, Z]),
            ot = a.useMemo(() => te.getValues()[0] !== "none", [te]),
            rt = ["right", "left", "horizontal"].includes(z) ? "horizontal" : "vertical",
            [Ft, Jt] = a.useState(!1),
            [Zt, Qt] = a.useState(!1),
            st = a.useMemo(() => !B && (B ? void 0 : Ft !== !0), [B, Ft]),
            Ke = a.useMemo(() => Z === !0 ? v === "auto" ? 10 : 1 : 0, [Z, v]),
            ut = a.useRef(null);
        a.useEffect(() => (R && (ut.current = K.addSheet({
            id: R,
            stackId: It,
            stackingIndex: -1,
            sendToOpennessMachine: w
        })), () => {
            R && K.attemptToRemoveSheetOrCleanup(R)
        }), [w, R, It]), a.useEffect(() => (W && K.addNativeFocusScrollPreventer(R), () => {
            W && K.removeNativeFocusScrollPreventer(R)
        }), [W, R]);
        let Y = a.useMemo(() => $t == null ? void 0 : $t(R), [$t, R]),
            [Bt, Nr] = a.useState(null),
            mn = a.useMemo(() => b && Bt ? g => {
                Bt(g), b(g)
            } : b && !Bt ? b : !b && Bt ? Bt : null, [b, Bt]),
            wn = a.useCallback(() => {
                A == null || A();
                let g = Ce.current.exactProgressValueAtDetents[pe.current[0]];
                jt.current = g, K.updateSheetTravelProgress(R, g)
            }, [A, R]),
            Et = a.useMemo(() => {
                let g;
                if (fe.value > 0) g = mn ? (S, T) => {
                    mn({
                        progress: S,
                        range: T,
                        progressAtDetents: Ce.current.exactProgressValueAtDetents
                    });
                    let E = Sn(S);
                    ut.current.aggregatedTravelCallback(S, E)
                } : S => {
                    let T = Sn(S);
                    ut.current.aggregatedTravelCallback(S, T)
                };
                else {
                    let S = K.getAggregatedStackingCallbackForSheetsBelow(R);
                    g = S ? mn ? (T, E) => {
                        mn({
                            progress: T,
                            range: E,
                            progressAtDetents: Ce.current.exactProgressValueAtDetents
                        });
                        let V = Sn(T);
                        ut.current.aggregatedTravelCallback(T, V), S(T, V)
                    } : T => {
                        let E = Sn(T);
                        ut.current.aggregatedTravelCallback(T, E), S(T, E)
                    } : () => {}
                }
                return g
            }, [fe.value, mn, R]),
            An = a.useRef(!1),
            Ya = a.useMemo(() => {
                let g;
                return z === "bottom" || z === "vertical" ? g = "translateY(-2px)" : z === "top" ? g = "translateY(2px)" : z === "right" || z === "horizontal" ? g = "translateX(-2px)" : z === "left" && (g = "translateX(2px)"), S => {
                    S > 0 && S < 1 && !An.current ? (Ct.current.style.setProperty("transform", g), An.current = !0) : (S > 1 || S <= 0) && An.current && (Ct.current.style.removeProperty("transform"), An.current = !1)
                }
            }, [z]),
            Fn = a.useMemo(() => ye ? g => Ya(g) : Et, [Ya, ye, Et]),
            [xn, Bn] = a.useState("both"),
            Xa = Ul(We);
        a.useEffect(() => {
            var g, S;
            let T, E, V;
            if (typeof ee == "boolean") T = {
                x: ee,
                y: ee
            };
            else {
                let {
                    x: Ue,
                    y: $e
                } = ee || {};
                T = {
                    x: Ue,
                    y: $e
                }
            }
            let $ = (Re === "ios" || Re === "ipados") && B && !Nt,
                le = Yl();
            rt === "vertical" && (E = T.x, V = !!$ || !le && ((g = T.y) === null || g === void 0 || g)), rt === "horizontal" && (V = !!$ || T.y, E = (S = T.x) === null || S === void 0 || S), V = !!V || Xa, Bn(E && !V ? "horizontal" : !E && V ? "vertical" : E && V ? "both" : "none")
        }, [Nt, B, ee, Xa, rt]);
        let Ce = a.useRef({}),
            [Ha, Lr] = a.useState(0),
            [Mr, _r] = a.useState(() => () => ({
                top: null,
                bottom: null
            })),
            fa = a.useRef([]),
            pe = a.useRef([0, 0]),
            Vn = a.useRef(0),
            je = a.useRef(null),
            ga = a.useRef(() => {}),
            Wn = a.useRef(!1),
            za = a.useRef(!1),
            ha = a.useCallback(g => za.current = g, []),
            qe = Dn(({
                destinationDetent: g,
                trackToTravelOn: S = z === "vertical" ? "bottom" : z === "horizontal" ? "right" : z,
                behavior: T = "instant",
                runTravelCallbacksAndAnimations: E = !0,
                runOnTravelStart: V = !0,
                animationConfig: $,
                rAFLoopEndCallback: le,
                travelEndCallback: Ue
            }) => {
                Js({
                    destinationDetent: g,
                    behavior: T,
                    runTravelCallbacksAndAnimations: E,
                    runOnTravelStart: V,
                    trackToTravelOn: S,
                    animationConfig: $,
                    rAFLoopEndCallback: le,
                    onTravel: mn,
                    onTravelStart: C,
                    onTravelEnd: () => {
                        Ue == null || Ue(), wn()
                    },
                    segment: pe,
                    fullTravelCallback: Et,
                    sheetId: R,
                    stackId: It,
                    dimensions: Ce,
                    snapBackAcceleratorTravelAxisSize: Ke,
                    actualSwipeOutDisabledWithDetent: G,
                    lastProgressValue: jt,
                    viewRef: We,
                    scrollContainerRef: Oe,
                    contentWrapperRef: Ct,
                    currentDetent: pe.current[0] === pe.current[1] ? pe.current[0] : null,
                    setSegment: At,
                    setProgrammaticScrollOngoing: ha,
                    contentPlacement: Ae,
                    hasOppositeTracks: z === "horizontal" || z === "vertical"
                })
            }),
            Fr = a.useCallback(() => {
                pe.current[0] === pe.current[1] && qe({
                    runTravelCallbacksAndAnimations: !1,
                    destinationDetent: pe.current[0]
                })
            }, [R, z, G, ye, Ke]),
            Br = a.useCallback(g => {
                Dt == null || Dt({
                    sheetId: R,
                    sendToOpennessMachine: w,
                    sendToPositionMachine: he
                })
            }, [Dt, R, w, he]),
            Ga = a.useCallback(() => {
                un == null || un(R)
            }, [un, R]),
            $a = a.useMemo(() => re === "alertdialog" ? () => {} : () => w({
                type: "CLOSE"
            }), [w, re]),
            Vr = a.useCallback(() => {
                K.updateLayer({
                    layerId: R,
                    layerContextId: Fe,
                    layerStackContextId: Le,
                    inertOutside: B,
                    onPresentAutoFocus: c,
                    onDismissAutoFocus: p,
                    dismissOverlayIfNotAlertDialog: $a,
                    onClickOutside: q,
                    onEscapeKeyDown: O,
                    viewElement: We.current,
                    backdropElement: qt.current,
                    scrollContainerElement: Oe.current,
                    elementFocusedLastBeforeShowing: Be.current
                })
            }, [R, Fe, Le, B, c, p, $a, q, O, Be]),
            Ka = a.useCallback(() => {
                K.removeLayer(R)
            }, [R]),
            Wr = a.useCallback(() => {
                let g = E => ["ArrowDown", "ArrowUp", "PageDown", "PageUp", "End", "Home", " "].includes(E.key),
                    S = E => {
                        if (g(E)) {
                            var V, $;
                            (V = Oe.current) === null || V === void 0 || V.style.setProperty("overflow", "hidden"), ($ = Oe.current) === null || $ === void 0 || $.style.setProperty("scroll-snap-type", "none")
                        }
                    },
                    T = E => {
                        if (g(E)) {
                            var V, $;
                            (V = Oe.current) === null || V === void 0 || V.style.removeProperty("overflow"), ($ = Oe.current) === null || $ === void 0 || $.style.removeProperty("scroll-snap-type")
                        }
                    };
                return document.addEventListener("keydown", S), document.addEventListener("keyup", T), () => {
                    document.removeEventListener("keydown", S), document.removeEventListener("keyup", T)
                }
            }, []),
            pn = a.useCallback(() => {
                Ie(g => g + 1), K.updateSheetStackingIndex(R, fe.silent.value)
            }, [Ie, fe.silent, R]),
            Vt = a.useCallback(() => {
                Ie(g => g - 1), K.updateSheetStackingIndex(R, fe.silent.value)
            }, [Ie, fe.silent, R]),
            jn = gt(Ge, "active");
        Qe("after-paint", jn, {
            state: "active:true",
            callback: Vr
        }), Qe("after-paint", jn, {
            state: "active:true",
            callback: Wr
        }), j("after-paint", jn, {
            state: "active:false",
            callback: Ka
        });
        let fn = gt(Ge, "position"),
            Wt = gt(Ge, "position:covered.status");
        se(fn, {
            state: "position:out",
            transition: "READY_TO_GO_FRONT",
            callback: a.useCallback(g => {
                Y == null || Y.sendToPositionMachine({
                    type: "READY_TO_GO_DOWN",
                    skipOpening: g.skipOpening
                }), pn()
            }, [pn, Y])
        }), se(Ge, {
            state: "position:front.status:opening",
            transition: "NEXT",
            callback: a.useCallback(() => {
                Y == null || Y.sendToPositionMachine("NEXT")
            }, [Y])
        }), se(Ge, {
            state: "position:front.status:idle",
            transition: "READY_TO_GO_OUT",
            callback: a.useCallback(() => {
                Y == null || Y.sendToPositionMachine("READY_TO_GO_UP")
            }, [Y])
        }), se(Ge, {
            state: "position:front.status:idle",
            transition: "GO_OUT",
            callback: a.useCallback(() => {
                Et == null || Et(0, {
                    start: 0,
                    end: 0
                }), wn(), Y == null || Y.sendToPositionMachine("GO_UP"), Vt()
            }, [Et, wn, Y, Vt])
        }), se(Ge, {
            state: "position:front.status:idle",
            transition: "READY_TO_GO_DOWN",
            callback: a.useCallback(g => {
                Y == null || Y.sendToPositionMachine({
                    type: "READY_TO_GO_DOWN",
                    skipOpening: g.skipOpening
                }), pn()
            }, [pn, Y])
        }), se(Ge, {
            state: "position:front.status:closing",
            transition: "NEXT",
            callback: a.useCallback(() => {
                Y == null || Y.sendToPositionMachine("NEXT"), Vt()
            }, [Y, Vt])
        }), se(Wt, {
            state: "position:covered.status:going-down",
            transition: "NEXT",
            callback: a.useCallback(() => {
                Y == null || Y.sendToPositionMachine("NEXT")
            }, [Y])
        }), se(Wt, {
            state: "position:covered.status:idle",
            transition: "READY_TO_GO_DOWN",
            callback: a.useCallback(g => {
                Y == null || Y.sendToPositionMachine({
                    type: "READY_TO_GO_DOWN",
                    skipOpening: g.skipOpening
                }), pn()
            }, [pn, Y])
        }), se(Wt, {
            state: "position:covered.status:idle",
            transition: "READY_TO_GO_UP",
            callback: a.useCallback(() => {
                Y == null || Y.sendToPositionMachine("READY_TO_GO_UP")
            }, [Y])
        }), se(Wt, {
            state: "position:covered.status:idle",
            transition: "GO_UP",
            callback: a.useCallback(() => {
                Y == null || Y.sendToPositionMachine("GO_UP"), Vt()
            }, [Vt, Y])
        }), j("immediate", Wt, {
            state: "position:covered.status:come-back",
            callback: a.useCallback(() => he(""), [he])
        }), se(Wt, {
            state: "position:covered.status:going-up",
            transition: "NEXT",
            callback: a.useCallback(() => {
                Y == null || Y.sendToPositionMachine("NEXT"), Vt()
            }, [Y, Vt])
        }), j("immediate", Wt, {
            state: "position:covered.status:indeterminate",
            callback: a.useCallback(() => {
                fe.silent.value === 0 ? he("GOTO_front") : he("GOTO_idle")
            }, [fe.silent, he])
        });
        let gn = a.useCallback(() => Y == null ? void 0 : Y.sendToOpennessMachine({
                machine: "staging",
                type: "NEXT"
            }), [Y]),
            wt = a.useCallback((g, {
                newState: S
            }) => {
                vt(S), Tn == null || Tn({
                    sheetId: R,
                    staging: S
                })
            }, [n, vt, Tn, R]),
            On = a.useCallback((g, {
                newState: S
            }) => {
                m == null || m(S)
            }, [m]),
            At = a.useMemo(() => {
                let g = S => {
                    Vn.current = S[1], queueMicrotask(() => {
                        let T = S[0],
                            E = S[1];
                        (T !== pe.current[0] || E !== pe.current[1]) && (pe.current = S, T === E && (je.current === null && ae ? ae(E) : T === je.current && (je.current = null)))
                    })
                };
                return d && Z === !1 ? g = S => {
                    Vn.current = S[1], queueMicrotask(() => {
                        let T = S[0],
                            E = S[1];
                        (T !== pe.current[0] || E !== pe.current[1]) && (pe.current = S, d({
                            start: T,
                            end: E
                        }), T === E && (je.current === null && ae ? ae(E) : T === je.current && (je.current = null)))
                    })
                } : Z === !0 && (g = ve ? S => {
                    Vn.current = S[1], queueMicrotask(() => {
                        let T = S[0],
                            E = S[1];
                        if (T !== pe.current[0] || E !== pe.current[1]) {
                            let V = at.length;
                            G && T === 1 && E === 1 ? w({
                                machine: "backStuck",
                                type: "STUCK_START"
                            }) : T === V && E === V ? w({
                                machine: "frontStuck",
                                type: "STUCK_START"
                            }) : Rn.current ? w({
                                machine: "frontStuck",
                                type: "STUCK_END"
                            }) : Yn.current && w({
                                machine: "backStuck",
                                type: "STUCK_END"
                            }), pe.current = S, d == null || d({
                                start: T,
                                end: E
                            }), T === E && (je.current === null && ae ? ae(E) : T === je.current && (je.current = null))
                        }
                    })
                } : S => {
                    Vn.current = S[1], queueMicrotask(() => {
                        let T = S[0],
                            E = S[1];
                        if (T !== pe.current[0] || E !== pe.current[1]) {
                            let V = at.length;
                            T === V && E === V ? w({
                                machine: "frontStuck",
                                type: "STUCK_START"
                            }) : Rn.current && w({
                                machine: "frontStuck",
                                type: "STUCK_END"
                            }), pe.current = S, d == null || d({
                                start: T,
                                end: E
                            }), T === E && (je.current === null && ae ? ae(E) : T === je.current && (je.current = null))
                        }
                    })
                }), g
            }, [d, Z, ae, ve, G, at.length, w]),
            en = a.useCallback(g => {
                let S = {
                    destinationDetent: g === "front" ? Ce.current.detentMarkers.length : 1,
                    runTravelCallbacksAndAnimations: !1
                };
                if (qe(S), Rt()) {
                    var T;
                    (T = Oe.current) === null || T === void 0 || T.style.setProperty("overflow", "hidden"), setTimeout(() => {
                        var E;
                        (E = Oe.current) === null || E === void 0 || E.style.removeProperty("overflow")
                    }, CSS.supports("overscroll-behavior", "none") ? 1 : 10)
                }
                Wn.current = !1
            }, [qe]),
            qa = a.useCallback((g, S) => {
                let T = pe.current[0],
                    E = S != null ? S : null;
                if (E === null) {
                    var V, $;
                    E = (g != null ? g : "up") === "up" ? (V = pe.current[0]) < at.length ? V + 1 : 1 : ($ = pe.current[0]) > 1 ? $ - 1 : at.length
                }
                return E === 0 || E === T ? null : E
            }, [at]),
            Ja = a.useCallback(({
                direction: g,
                detent: S,
                behavior: T
            }) => {
                let E = () => {
                    let V = qa(g, S);
                    V && w({
                        type: "ACTUALLY_STEP",
                        detent: V,
                        behavior: T
                    })
                };
                U.silent.matches("openness:open.scroll:ended.afterPaintEffectsRun:true") ? E() : Sa.current = E
            }, [U.silent, qa, w]),
            Za = a.useCallback((g, S) => {
                je.current = g, ae == null || ae(g), qe({
                    destinationDetent: g,
                    behavior: S != null ? S : P.skip ? "instant" : "smooth",
                    animationConfig: P,
                    travelEndCallback: () => w({
                        machine: "staging",
                        type: "NEXT"
                    })
                })
            }, [ae, qe, P, w]),
            Qa = a.useCallback((g, S, T, E) => {
                let V;
                if (g === "auto") {
                    let $ = E === "center" ? T + (S - T) / 2 : T;
                    V = Ot === "chromium" ? $ <= 1440 ? 70 + .25 * $ : .3 * $ : Rt() ? Re === "ios" || Re === "ipados" ? $ <= 716 ? 15 + .1 * $ : .12 * $ : .5 * $ : 10
                } else if (typeof g == "function") {
                    let $ = parseInt(g(T), 10);
                    V = $ < 1 ? 1 : $ > T / 2 ? T / 2 : $
                } else g === "initial" && (V = 1);
                return V
            }, []),
            el = a.useCallback(() => {
                if (We.current) {
                    let g = (S, T) => We.current.style.setProperty(S, T);
                    g("--silk-aD", Ce.current.view.travelAxis.px), g("--silk-aE", Ce.current.view.crossAxis.px), g("--silk-aF", Ce.current.content.travelAxis.px), g("--silk-aG", Ce.current.content.crossAxis.px), g("--silk-aH", Ce.current.frontSpacer.travelAxis.px), g("--silk-aI", Ce.current.backSpacer.travelAxis.px), g("--silk-aJ", Ce.current.snapOutAccelerator.travelAxis.px), g("--silk-aK", Ce.current.detentMarkers[0].travelAxis.px)
                }
            }, []),
            jr = a.useCallback(g => {
                let S = We.current,
                    T = Lt.current,
                    E = [];
                dn.current.forEach(Te => {
                    E.push(window.getComputedStyle(Te))
                });
                let V = Te => parseFloat(Te),
                    $ = Te => parseInt(Te, 10),
                    le = Te => z === "right" || z === "left" || z === "horizontal" ? Te === "travelAxis" ? "width" : "height" : Te === "travelAxis" ? "height" : "width",
                    Ue = Te => {
                        let xt, an, vn, bt, J, kn;
                        return an = V(xt = Te.getPropertyValue(le("travelAxis"))), vn = $(xt), J = $(bt = Te.getPropertyValue(le("crossAxis"))), kn = $(bt), {
                            travelAxis: {
                                px: xt,
                                unitless: an,
                                unitlessRoundedDown: vn
                            },
                            crossAxis: {
                                px: bt,
                                unitless: J,
                                unitlessRoundedDown: kn
                            }
                        }
                    },
                    $e = () => {
                        let Te, xt, an = window.getComputedStyle(We.current),
                            vn = window.getComputedStyle(Lt.current),
                            bt = 0;
                        Lr(Se => Se + 1), Ce.current = {
                            view: y({}, Ue(an)),
                            scroll: {},
                            snapOutAccelerator: {
                                travelAxis: {}
                            },
                            frontSpacer: {
                                travelAxis: {}
                            },
                            backSpacer: {
                                travelAxis: {}
                            },
                            content: y({}, Ue(vn)),
                            detentMarkers: [...E.map((Se, dt) => {
                                let ft = Ue(Se);
                                return dt !== E.length - 1 && (bt += ft.travelAxis.unitless), M(y({}, ft), {
                                    accumulatedOffsets: {
                                        travelAxis: {
                                            px: bt + "px",
                                            unitless: bt,
                                            unitlessRoundedDown: null
                                        }
                                    }
                                })
                            })],
                            progressValueAtDetents: []
                        };
                        let J = Ce.current;
                        J.scroll = J.view;
                        let kn = Qa(k, J.view.travelAxis.unitless, J.content.travelAxis.unitless, Ae);
                        J.snapOutAccelerator.travelAxis.px = kn + "px", J.snapOutAccelerator.travelAxis.unitless = kn, J.snapOutAccelerator.travelAxis.unitlessRoundedDown = $(kn);
                        let ns = J.detentMarkers.length,
                            zn = J.content.travelAxis.unitless - bt;
                        J.detentMarkers[ns - 1] = {
                            travelAxis: {
                                px: zn + "px",
                                unitless: zn,
                                unitlessRoundedDown: null
                            },
                            crossAxis: {
                                px: "1px",
                                unitless: 1,
                                unitlessRoundedDown: 1
                            },
                            accumulatedOffsets: {
                                travelAxis: {
                                    px: bt + zn + "px",
                                    unitless: bt + zn,
                                    unitlessRoundedDown: null
                                }
                            }
                        };
                        let Ta = Se => ({
                                before: Se(-2.1),
                                exact: Se(0),
                                after: Se(2.1)
                            }),
                            Gn = J.content.travelAxis.unitless,
                            bn = [Ta(Se => Se / Gn)],
                            cl;
                        J.detentMarkers.slice(0, -1).forEach(Se => {
                            let dt = Se.accumulatedOffsets.travelAxis.unitless;
                            bn.push(Ta(ft => (dt + ft) / Gn))
                        }), bn.push(Ta(Se => (Gn + Se) / Gn)), cl = bn[Ye];
                        let dl = fa.current.length > 0 ? fa.current[pe.current[1]] : 0,
                            ml = (function(Se, dt) {
                                let ft = 0;
                                for (let Xt = 1; Xt < dt.length; Xt++) {
                                    let Pn = dt[Xt];
                                    Math.abs(Pn - Se) < Math.abs(dt[ft] - Se) && (ft = Xt)
                                }
                                return ft
                            })(dl != null ? dl : 1, bn.map(Se => Se.exact));
                        At([ml, ml]), J.progressValueAtDetents = bn, J.exactProgressValueAtDetents = bn.map(Se => Se.exact), fa.current = J.progressValueAtDetents.map(Se => Se.exact), J.progressValueAtInitialDetent = cl, Te = ye ? z === "horizontal" || z === "vertical" ? J.view.travelAxis.unitless / 2 + 1 : 1 : G ? J.content.travelAxis.unitless - Ce.current.detentMarkers[0].travelAxis.unitless + Ke : z === "horizontal" || z === "vertical" ? J.view.travelAxis.unitless / 2 + J.view.travelAxis.unitless - (J.view.travelAxis.unitless - J.content.travelAxis.unitless) / 2 + J.snapOutAccelerator.travelAxis.unitless : Ae === "center" ? J.view.travelAxis.unitless - (J.view.travelAxis.unitless - J.content.travelAxis.unitless) / 2 + J.snapOutAccelerator.travelAxis.unitless : J.view.travelAxis.unitless - (J.view.travelAxis.unitless - J.content.travelAxis.unitless) + J.snapOutAccelerator.travelAxis.unitless, J.frontSpacer.travelAxis.unitless = Te, J.frontSpacer.travelAxis.px = Te + "px", xt = Z === !0 && v === "auto" ? J.view.travelAxis.unitless + Ke : z === "horizontal" || z === "vertical" ? ye ? J.view.travelAxis.unitless / 2 : J.view.travelAxis.unitless / 2 + J.view.travelAxis.unitless - (J.view.travelAxis.unitless - J.content.travelAxis.unitless) / 2 + J.snapOutAccelerator.travelAxis.unitless : J.view.travelAxis.unitless, J.backSpacer.travelAxis.unitless = xt, J.backSpacer.travelAxis.px = xt + "px", el(), _r(() => () => {
                            let Se, dt;
                            if (!We.current) return {
                                top: null,
                                bottom: null
                            };
                            let ft = We.current.getBoundingClientRect(),
                                Xt = ft.top,
                                Pn = ft.bottom,
                                pl = pa || z === "top" || z === "bottom",
                                $n = J.view[pl ? "travelAxis" : "crossAxis"].unitless,
                                Kn = J.content[pl ? "travelAxis" : "crossAxis"].unitless;
                            return Ae === "left" || Ae === "right" || Ae === "center" ? (Se = Xt + ($n - Kn) / 2, dt = Pn - ($n - Kn) / 2) : Ae === "top" ? (Se = Xt, dt = Pn - ($n - Kn)) : Ae === "bottom" && (Se = Xt + ($n - Kn), dt = Pn), {
                                top: Se,
                                bottom: dt
                            }
                        })
                    };
                $e();
                let tn = (Te, xt) => {
                        let an = new ResizeObserver(vn => {
                            vn.forEach(() => xt())
                        });
                        return an.observe(Te, {
                            box: "border-box"
                        }), an
                    },
                    Ut = () => {
                        $e(), qe({
                            runTravelCallbacksAndAnimations: !1
                        })
                    },
                    ct = !0,
                    Yt = tn(S, () => {
                        ct ? ct = !1 : Ut()
                    }),
                    nn = !0,
                    Ve = tn(T, () => {
                        nn ? ($e(), nn = !1) : Ut()
                    });
                return () => {
                    Yt && S && (Yt.unobserve(S), Yt.disconnect()), Ve && T && (Ve.unobserve(T), Ve.disconnect())
                }
            }, [z, Qa, k, Ye, Z, el, Ke, v, qe, At, Ae, G, ye, at]),
            tl = a.useCallback(g => {
                let S, T = 0,
                    E = g,
                    V = 0;
                return $ => {
                    S = $;
                    let le = E - $;
                    return T = le, (le === 0 || Math.abs(le) < Math.abs(V / 2)) && U.silent.matches("scrollContainerTouch:ongoing") && (S = E - V / 2, T = E - S), Math.abs(T) >= .1 && .35 > Math.abs(T) && (S = T >= 0 ? E - .1 : E + .1, T = T >= 0 ? .1 : -.1), $ <= 0 && (S = 0), E = S, V = T, S
                }
            }, [U.silent]),
            nl = a.useCallback(() => {
                var g;
                let S, T, E = z === "right" || z === "left" || z === "horizontal" ? "scrollLeft" : "scrollTop",
                    V = Oe.current,
                    $ = Ce.current.snapOutAccelerator.travelAxis.unitless,
                    le = Ce.current.content.travelAxis.unitless,
                    Ue = Ce.current.scroll.travelAxis.unitless,
                    $e = tl((g = jt.current) !== null && g !== void 0 ? g : Ce.current.progressValueAtDetents[pe.current[1]].exact),
                    tn = z === "right" || z === "bottom",
                    Ut = z === "left" || z === "top";
                if (tn || Ut) {
                    let ct;
                    if (ye) ct = Ut ? Ve => 1 - Ve / le : Ve => 1 + Ve / le;
                    else if (tn)
                        if (Ae !== "center") {
                            let Ve = G ? Ce.current.detentMarkers[0].travelAxis.unitless - Ke : -$;
                            ct = Te => (Te + Ve) / le
                        } else {
                            let Ve = le + (Ue - le) / 2;
                            ct = Te => (Te - $) / Ve
                        }
                    else if (Ut)
                        if (Ae !== "center") ct = Ve => (le + Ke - Ve) / le;
                        else {
                            let Ve = le + (Ue - le) / 2;
                            ct = Te => (Ve + Ke - Te) / Ve
                        }
                    let Yt = Z === !0 ? 1 : 10,
                        nn = Z === !0 && G ? Ce.current.progressValueAtDetents[1].exact : 0;
                    T = () => {
                        S = V[E];
                        let Ve = Math.min(Math.max(ct(S), nn), Yt);
                        return Math.min(Math.max($e(Ve), nn), Yt)
                    }
                } else if (z === "horizontal" || z === "vertical") {
                    let ct = (Ue - le) / 2,
                        Yt = ye ? 0 : $ + Ue - ct,
                        nn = le + ct;
                    T = () => {
                        S = V[E];
                        let Ve = 1 - Math.abs(S - Yt) / nn;
                        return Math.max($e(Math.max(Ve, 0)), 0)
                    }
                }
                return T
            }, [z, tl, Z, ye, Ae, G, Ke, Ha]),
            Un = a.useRef(),
            Ur = a.useCallback(() => {
                let g = Oe.current,
                    S = () => {
                        w({
                            machine: "openness:open.move",
                            type: "MOVE_END"
                        });
                        for (let E = 0; E < Ce.current.progressValueAtDetents.length; E++) {
                            let V = Ce.current.progressValueAtDetents[E].exact;
                            jt.current > V - .01 && jt.current < V + .01 && (w({
                                machine: "openness:open.scroll",
                                type: "SCROLL_END"
                            }), w({
                                machine: "openness:open.swipe",
                                type: "SWIPE_END"
                            }))
                        }
                    },
                    T = () => {
                        za.current ? ha(!1) : (ba.current || w({
                            machine: "openness:open.scroll",
                            type: "SCROLL_START"
                        }), Rn.current || Yn.current || (Ca.current || w({
                            machine: "openness:open.swipe",
                            type: "SWIPE_START"
                        }), ya.current || w({
                            machine: "openness:open.move",
                            type: "MOVE_START"
                        }))), clearTimeout(Un.current), Un.current = setTimeout(S, 200)
                    };
                return g.addEventListener("scroll", T), () => {
                    g.removeEventListener("scroll", T), clearTimeout(Un.current)
                }
            }, [w, ha]),
            jt = a.useRef(null),
            Yr = a.useCallback(() => {
                let g;
                if (Fn) {
                    let S = Ce.current.progressValueAtDetents,
                        T = S.length,
                        E = nl();
                    g = Zs(() => {
                        let V, $ = E();
                        if (jt.current !== $) {
                            for (let le = 0; le < T; le++) {
                                let Ue = S[le],
                                    $e = Ue.after;
                                $ > $e && le + 1 < T && $ < S[le + 1].before ? (V = {
                                    start: le,
                                    end: le + 1
                                }, At([le, le + 1])) : $ > Ue.before && $ < $e ? (V = {
                                    start: le,
                                    end: le
                                }, At([le, le])) : $ <= 0 && (V = {
                                    start: 0,
                                    end: 0
                                }, At([0, 0]))
                            }
                            ga.current($, V), jt.current = $
                        }
                    })
                }
                return () => {
                    g == null || g()
                }
            }, [At, Fn, nl]),
            al = a.useCallback(g => {
                let S = 1e5,
                    T = E => {
                        S < Math.abs(E.deltaY) ? window.removeEventListener("wheel", T, {
                            passive: !1
                        }) : E.preventDefault(), S = Math.abs(E.deltaY)
                    };
                return window.addEventListener("wheel", T, {
                    passive: !1
                }), setTimeout(() => {
                    g("SWIPED_OUT")
                }, 100), () => window.removeEventListener("wheel", T, {
                    passive: !1
                })
            }, []),
            Xr = a.useCallback((g, {
                send: S
            }) => {
                let T, E = We.current,
                    V = Lt.current,
                    $ = Oe.current,
                    le = !1,
                    Ue = () => le = !0;
                window.addEventListener("wheel", Ue, {
                    passive: !0,
                    once: !0
                });
                let $e = new IntersectionObserver(function(tn) {
                    for (let Ut of tn) Ut.isIntersecting || (E.style.setProperty("pointer-events", "none", "important"), E.style.setProperty("opacity", "0", "important"), E.style.setProperty("position", "fixed", "important"), E.style.setProperty("top", "-100px", "important"), E.style.setProperty("left", "-100px", "important"), V.style.setProperty("pointer-events", "none", "important"), $.style.setProperty("width", "1px", "important"), $.style.setProperty("height", "1px", "important"), $.style.setProperty("clip-path", "inset(0)", "important"), requestAnimationFrame(() => {
                        le ? T = al(S) : S("SWIPED_OUT")
                    }))
                }, {
                    root: E,
                    threshold: [0]
                });
                return $e.observe(V), () => {
                    T == null || T(), window.removeEventListener("wheel", Ue, {
                        passive: !0,
                        once: !0
                    }), $e && ($e.unobserve(V), $e.disconnect())
                }
            }, [al]),
            Hr = a.useRef(() => 0),
            zr = a.useCallback(() => {
                let g = We.current,
                    S = T => {
                        St({
                            nativeEvent: T,
                            defaultBehavior: {},
                            handler: _
                        })
                    };
                return g == null || g.addEventListener("focus", S, {
                    capture: !0
                }), () => {
                    g == null || g.removeEventListener("focus", S, {
                        capture: !0
                    })
                }
            }, [_]),
            Gr = a.useCallback(g => {
                Oe.current.contains(g.target) && w({
                    machine: "scrollContainerTouch",
                    type: "TOUCH_START"
                })
            }, [w]),
            $r = a.useCallback(g => {
                Oe.current.contains(g.target) && w({
                    machine: "scrollContainerTouch",
                    type: "TOUCH_END"
                })
            }, [w]);
        j("immediate", te, {
            state: "staging:none",
            callback: wt,
            params: {
                newState: "none"
            }
        }), se(te, {
            state: "staging:none",
            transition: "OPEN",
            callback: a.useCallback(() => Y == null ? void 0 : Y.sendToOpennessMachine({
                machine: "staging",
                type: "GO_DOWN",
                skipOpening: lt == null ? void 0 : lt.skip
            }), [Y, lt == null ? void 0 : lt.skip])
        }), se(te, {
            state: "staging:none",
            transition: "OPEN_PREPARED",
            callback: a.useCallback(g => Y == null ? void 0 : Y.sendToOpennessMachine({
                machine: "staging",
                type: "GO_DOWN",
                skipOpening: g.skipOpening
            }), [Y])
        }), se(te, {
            state: "staging:none",
            transition: "GO_DOWN",
            callback: a.useCallback(g => Y == null ? void 0 : Y.sendToOpennessMachine({
                machine: "staging",
                type: "GO_DOWN",
                skipOpening: g.skipOpening
            }), [Y])
        }), se(te, {
            state: "staging:none",
            transition: "ACTUALLY_CLOSE",
            callback: a.useCallback(() => Y == null ? void 0 : Y.sendToOpennessMachine({
                machine: "staging",
                type: "GO_UP"
            }), [Y])
        }), se(te, {
            state: "staging:none",
            transition: "GO_UP",
            callback: a.useCallback(g => Y == null ? void 0 : Y.sendToOpennessMachine({
                machine: "staging",
                type: "GO_UP",
                skipClosing: g.skipClosing
            }), [Y])
        }), j("immediate", te, {
            state: "staging:open",
            callback: wt,
            params: {
                newState: "open"
            }
        }), j("immediate", te, {
            state: "staging:open",
            callback: a.useCallback(() => {
                w({
                    machine: "longRunning",
                    type: "TO_TRUE"
                })
            }, [w])
        }), j("immediate", te, {
            state: "staging:open",
            callback: a.useCallback(() => {
                xe || ge == null || ge(!0)
            }, [xe, ge])
        }), j("after-paint", te, {
            state: "staging:open",
            callback: a.useCallback(() => {
                requestAnimationFrame(() => {
                    w({
                        machine: "openness",
                        type: "READY_TO_OPEN",
                        skipOpening: !0
                    }), w({
                        machine: "staging",
                        type: "NEXT"
                    })
                })
            }, [w])
        }), se(te, {
            state: "staging:open",
            transition: "NEXT",
            callback: gn
        }), j("immediate", te, {
            state: "staging:opening",
            callback: wt,
            params: {
                newState: "opening"
            }
        }), j("immediate", te, {
            state: "staging:opening",
            callback: a.useCallback(() => {
                w({
                    machine: "longRunning",
                    type: "TO_TRUE"
                })
            }, [w])
        }), j("immediate", te, {
            state: "staging:opening",
            callback: a.useCallback(() => {
                xe || ge == null || ge(!0)
            }, [xe, ge])
        }), j("before-paint", te, {
            state: "staging:opening",
            callback: a.useCallback(() => {
                C == null || C(), Et(0, {
                    start: 0,
                    end: 0
                })
            }, [Et, C])
        }), j("after-paint", te, {
            state: "staging:opening",
            callback: a.useCallback(() => {
                requestAnimationFrame(() => {
                    w({
                        machine: "openness",
                        type: "READY_TO_OPEN",
                        skipOpening: !1
                    })
                })
            }, [w])
        }), Qe("after-paint", te, {
            state: "staging:opening",
            callback: a.useCallback(() => (As(R), () => xs(R)), [R])
        }), se(te, {
            state: "staging:opening",
            transition: "NEXT",
            callback: gn
        }), j("immediate", te, {
            state: "staging:stepping",
            callback: wt,
            params: {
                newState: "stepping"
            }
        }), j("after-paint", te, {
            state: "staging:stepping",
            callback: a.useCallback(({
                detent: g,
                behavior: S
            }) => {
                m == null || m("stepping"), Za(g, S)
            }, [m, Za])
        }), Ht("immediate", te, {
            state: "staging:stepping",
            callback: a.useCallback(() => {
                m == null || m("idleInside")
            }, [m])
        }), j("immediate", te, {
            state: "staging:closing",
            callback: wt,
            params: {
                newState: "closing"
            }
        }), j("immediate", te, {
            state: "staging:closing",
            callback: a.useCallback(() => {
                xe && (ge == null || ge(!1))
            }, [xe, ge])
        }), j("after-paint", te, {
            state: "staging:closing",
            callback: a.useCallback(() => {
                w({
                    machine: "openness",
                    type: "READY_TO_CLOSE"
                })
            }, [w])
        }), se(te, {
            state: "staging:closing",
            transition: "NEXT",
            callback: gn
        }), j("immediate", te, {
            state: "staging:go-down",
            callback: wt,
            params: {
                newState: "go-down"
            }
        }), se(te, {
            state: "staging:go-down",
            transition: "NEXT",
            callback: gn
        }), j("immediate", te, {
            state: "staging:going-down",
            callback: wt,
            params: {
                newState: "going-down"
            }
        }), se(te, {
            state: "staging:going-down",
            transition: "NEXT",
            callback: gn
        }), j("immediate", te, {
            state: "staging:going-up",
            callback: wt,
            params: {
                newState: "going-up"
            }
        }), se(te, {
            state: "staging:going-up",
            transition: "NEXT",
            callback: gn
        });
        let it = gt(U, "longRunning");
        j("immediate", it, {
            state: "longRunning:true",
            callback: a.useCallback(() => {
                Be.current === null && (Be.current = document.activeElement)
            }, [Be])
        }), j("immediate", it, {
            state: "longRunning:true",
            callback: a.useCallback(() => {
                de(!0), tt == null || tt(g => g + 1)
            }, [de, tt])
        }), Qe("before-paint", it, {
            state: "longRunning:true",
            callback: jr
        }), j("before-paint", it, {
            state: "longRunning:true",
            guard: !lt.skip,
            callback: a.useCallback(() => {
                qe({
                    trackToTravelOn: Tt,
                    runTravelCallbacksAndAnimations: !1,
                    destinationDetent: 0
                })
            }, [qe, Tt])
        }), Qe("after-paint", it, {
            state: "longRunning:true",
            guard: X,
            callback: a.useCallback(() => Ys(Kt, N), [N])
        }), Qe("after-paint", it, {
            state: "longRunning:true",
            callback: Br
        }), j("immediate", it, {
            state: "longRunning:false",
            callback: a.useCallback(() => {
                de(!1), tt == null || tt(g => g - 1)
            }, [de, tt])
        }), j("immediate", it, {
            state: "longRunning:false",
            callback: a.useCallback(() => {
                Be.current = null
            }, [Be])
        }), j("before-paint", it, {
            state: "longRunning:false",
            callback: a.useCallback(() => {
                K.removeAllOutletPersistedStylesFromSheet(R)
            }, [R])
        }), j("after-paint", it, {
            state: "longRunning:false",
            callback: Ga
        }), Qe("before-paint", jn, {
            state: "active:true",
            callback: Fr
        });
        let be = gt(U, "openness"),
            pt = gt(U, "openness:closed.status");
        j("immediate", be, {
            state: "openness:closed",
            callback: On,
            params: {
                newState: "idleOutside"
            }
        }), j("immediate", be, {
            state: "openness:closed",
            callback: a.useCallback(() => {
                w({
                    machine: "longRunning",
                    type: "TO_FALSE"
                })
            }, [w])
        }), j("immediate", be, {
            state: "openness:closed",
            callback: a.useCallback(() => {
                xe && (ge == null || ge(!1))
            }, [xe, ge])
        }), j("immediate", be, {
            state: "openness:closed",
            callback: a.useCallback(() => {
                he({
                    machine: "active",
                    type: "TO_FALSE"
                })
            }, [he])
        }), j("after-paint", be, {
            state: "openness:closed",
            callback: a.useCallback(() => {
                clearTimeout(Un.current), jt.current = null, At([0, 0]), An.current = !1, Ie(-1), Wn.current = !1
            }, [Ie, At])
        }), se(be, {
            state: "openness:closed",
            transition: "READY_TO_OPEN",
            callback: a.useCallback(g => {
                he({
                    machine: "position",
                    type: "READY_TO_GO_FRONT",
                    skipOpening: g.skipOpening
                })
            }, [he])
        }), js(w, pt, "openness:closed.status:pending", {
            delay: 3e3
        }), Ht("immediate", pt, {
            state: "openness:closed.status:pending",
            callback: a.useCallback(() => {
                w("SWIPE_RESET")
            }, [w])
        }), j("before-paint", pt, {
            state: "openness:closed.status:flushing-to-preparing-opening",
            callback: a.useCallback(() => {
                w({
                    machine: "openness:closed.status",
                    type: ""
                })
            }, [w])
        }), j("before-paint", pt, {
            state: "openness:closed.status:flushing-to-preparing-open",
            callback: a.useCallback(() => {
                w({
                    machine: "openness:closed.status",
                    type: ""
                })
            }, [w])
        }), j("after-paint", pt, {
            state: "openness:closed.status:preparing-opening",
            callback: a.useCallback(() => {
                w({
                    machine: "staging",
                    type: "OPEN_PREPARED",
                    skipOpening: !1
                })
            }, [w])
        }), j("after-paint", pt, {
            state: "openness:closed.status:preparing-open",
            callback: a.useCallback(() => {
                w({
                    machine: "staging",
                    type: "OPEN_PREPARED",
                    skipOpening: !0
                })
            }, [w])
        }), j("immediate", pt, {
            state: "openness:closed.status:safe-to-unmount",
            callback: a.useCallback(() => {
                me == null || me(!0)
            }, [me])
        }), Ht("immediate", pt, {
            state: "openness:closed.status:safe-to-unmount",
            callback: a.useCallback(() => {
                me == null || me(!1)
            }, [me])
        }), j("immediate", be, {
            state: "openness:opening",
            callback: On,
            params: {
                newState: "entering"
            }
        }), j("before-paint", be, {
            state: "openness:opening",
            callback: a.useCallback(() => {
                je.current = Ye, ae == null || ae(Ye), qe({
                    trackToTravelOn: Tt,
                    destinationDetent: Ye,
                    behavior: "smooth",
                    animationConfig: lt,
                    travelEndCallback: () => w("NEXT"),
                    runOnTravelStart: !1
                })
            }, [Tt, ae, qe, Ye, lt, w])
        }), se(be, {
            state: "openness:opening",
            transition: "NEXT",
            callback: a.useCallback(() => {
                he("NEXT"), w({
                    machine: "staging",
                    type: "NEXT"
                })
            }, [he, w])
        }), j("immediate", be, {
            state: "openness:open",
            callback: On,
            params: {
                newState: "idleInside"
            }
        }), j("immediate", be, {
            state: "openness:open",
            callback: a.useCallback(() => {
                he({
                    machine: "active",
                    type: "TO_TRUE"
                })
            }, [he])
        }), j("before-paint", be, {
            state: "openness:open",
            guard: lt.skip,
            callback: a.useCallback(() => {
                je.current = Ye, ae == null || ae(Ye), qe({
                    trackToTravelOn: Tt,
                    destinationDetent: Ye
                })
            }, [Ye, ae, qe, Tt])
        }), Qe("before-paint", be, {
            state: "openness:open",
            callback: a.useCallback(() => {
                if (Rt() && oe) {
                    var g;
                    (g = Oe.current) === null || g === void 0 || g.style.setProperty("will-change", "transform"), requestAnimationFrame(() => {
                        var S;
                        return (S = Oe.current) === null || S === void 0 ? void 0 : S.style.removeProperty("will-change", "transform")
                    })
                }
            }, [oe]),
            params: {
                unusedDep: Ha
            }
        }), Qe("before-paint", be, {
            state: "openness:open",
            guard: !ke,
            callback: Ur
        }), j("after-paint", te, {
            state: "staging:open",
            guard: Z === !0 && v === "auto",
            callback: a.useCallback(() => {
                Ye === at.length ? w({
                    machine: "frontStuck",
                    type: "STUCK_START"
                }) : oe && Ye === 1 && w({
                    machine: "backStuck",
                    type: "STUCK_START"
                })
            }, [w, Ye, at, oe])
        }), Qe("after-paint", be, {
            state: "openness:open",
            guard: !ke && !ye && !G,
            callback: Xr,
            params: {
                send: w
            }
        }), Qe("after-paint", be, {
            state: "openness:open",
            callback: zr
        }), se(be, {
            state: "openness:open",
            transition: "READY_TO_CLOSE",
            callback: a.useCallback(() => he("READY_TO_GO_OUT"), [he])
        }), se(be, {
            state: "openness:open",
            transition: "ACTUALLY_CLOSE",
            callback: a.useCallback(() => {
                je.current = null, ae == null || ae(0), C == null || C(), he("GO_OUT")
            }, [ae, C, he])
        }), se(be, {
            state: "openness:open",
            transition: "SWIPED_OUT",
            callback: a.useCallback(() => {
                var g;
                (g = Oe.current) === null || g === void 0 || g.style.setProperty("scroll-snap-type", "none", "important"), je.current = null, ae == null || ae(0), he("GO_OUT")
            }, [ae, he])
        }), Ht("immediate", be, {
            state: "openness:open",
            callback: a.useCallback(() => {
                w("SWIPE_END")
            }, [w])
        });
        let va = gt(U, "backStuck"),
            Yn = a.useRef(!1);
        se(va, {
            state: "backStuck:false",
            transition: "STUCK_START",
            callback: a.useCallback(() => Yn.current = !0, [])
        }), se(va, {
            state: "backStuck:true",
            transition: "STUCK_END",
            callback: a.useCallback(() => Yn.current = !1, [])
        }), se(va, {
            state: "backStuck:false",
            transition: "STUCK_START",
            guard: Z === !0 && v === "auto",
            callback: a.useCallback(() => {
                U.silent.matches("scrollContainerTouch:ended") && en("back")
            }, [U.silent, en])
        });
        let ka = gt(U, "frontStuck"),
            Rn = a.useRef(!1);
        se(ka, {
            state: "frontStuck:false",
            transition: "STUCK_START",
            callback: a.useCallback(() => Rn.current = !0, [])
        }), se(ka, {
            state: "frontStuck:true",
            transition: "STUCK_END",
            callback: a.useCallback(() => Rn.current = !1, [])
        }), se(ka, {
            state: "frontStuck:false",
            transition: "STUCK_START",
            guard: Z === !0 && v === "auto",
            callback: a.useCallback(() => {
                U.silent.matches("openness:open") && U.silent.matches("scrollContainerTouch:ended") && en("front")
            }, [U.silent, en])
        }), j("immediate", U, {
            state: "scrollContainerTouch:ended",
            guard: Z === !0 && v === "auto",
            callback: a.useCallback(() => {
                Wn.current && setTimeout(() => {
                    requestAnimationFrame(() => {
                        U.silent.matches("openness:open") && (U.silent.matches("backStuck:true") ? en("back") : U.silent.matches("frontStuck:true") && en("front"))
                    })
                }, 80)
            }, [U.silent, en])
        });
        let hn = gt(U, "openness:open.scroll"),
            ba = a.useRef(!1);
        j("immediate", hn, {
            state: "openness:open.scroll:ongoing",
            callback: a.useCallback(() => ba.current = !0, [])
        }), Ht("immediate", hn, {
            state: "openness:open.scroll:ongoing",
            callback: a.useCallback(() => ba.current = !1, [])
        }), j("immediate", hn, {
            state: "openness:open.scroll:ongoing",
            callback: a.useCallback(() => {
                Wn.current = !0
            }, [])
        }), Qe({
            start: "immediate",
            update: "before-paint"
        }, hn, {
            state: "openness:open.scroll:ongoing",
            callback: Yr
        });
        let Sa = a.useRef(() => {});
        j("after-paint", hn, {
            state: "openness:open.scroll:ended",
            callback: a.useCallback(() => {
                w({
                    machine: "openness:open.scroll:ended.afterPaintEffectsRun",
                    type: "OCCURRED"
                }), Sa.current(), Sa.current = () => {}
            }, [w])
        }), Ht("immediate", hn, {
            state: "openness:open.scroll:ended",
            callback: a.useCallback(() => {
                w({
                    machine: "openness:open.scroll:ended.afterPaintEffectsRun",
                    type: "RESET"
                })
            }, [w])
        });
        let ya = a.useRef(!1);
        j("immediate", U, {
            state: "openness:open.move:ongoing",
            callback: a.useCallback(() => {
                ya.current = !0, ga.current = Fn
            }, [Fn])
        }), Ht("immediate", U, {
            state: "openness:open.move:ongoing",
            callback: a.useCallback(() => {
                ya.current = !1, ga.current = () => {}
            }, [])
        });
        let Ca = a.useRef(!1);
        j("immediate", U, {
            state: "openness:open.swipe:ongoing",
            callback: a.useCallback(() => Ca.current = !0, [])
        }), Ht("immediate", U, {
            state: "openness:open.swipe:ongoing",
            callback: a.useCallback(() => Ca.current = !1, [])
        }), j("immediate", U, {
            state: "openness:open.swipe:ongoing",
            callback: a.useCallback(() => C == null ? void 0 : C(), [C])
        }), j("immediate", U, {
            state: "openness:open.swipe:ongoing",
            callback: On,
            params: {
                newState: "stepping"
            }
        }), j("immediate", U, {
            state: "openness:open.swipe:ended",
            callback: a.useCallback(() => wn(), [wn])
        }), j("immediate", U, {
            state: "openness:open.swipe:ended",
            guard: typeof m == "function",
            callback: a.useCallback(() => {
                U.silent.matches("openness:open") && m("idleInside")
            }, [U.silent, m])
        });
        let ll = a.useCallback(() => {
            !fn.matches("position:front") || pe.current[0] === 0 && pe.current[1] === 0 || oe && pe.current[0] !== pe.current[1] ? xe === !1 && (ge == null || ge(!0)) : w("ACTUALLY_CLOSE")
        }, [fn, w, xe, ge, oe]);
        se(U, {
            state: "openness:open.evaluateCloseMessage:true",
            transition: "CLOSE",
            callback: ll
        }), se(U, {
            state: "openness:open.evaluateCloseMessage:false",
            transition: "CLOSE",
            callback: ll
        }), se(U, {
            state: "openness:open.evaluateStepMessage:true",
            transition: "STEP",
            callback: Ja
        }), se(U, {
            state: "openness:open.evaluateStepMessage:false",
            transition: "STEP",
            callback: Ja
        }), j("immediate", be, {
            state: "openness:closing",
            callback: On,
            params: {
                newState: "exiting"
            }
        }), j("before-paint", be, {
            state: "openness:closing",
            callback: a.useCallback(() => {
                je.current = 0, ae == null || ae(0), qe({
                    trackToTravelOn: _t.track,
                    destinationDetent: 0,
                    behavior: "smooth",
                    animationConfig: _t,
                    travelEndCallback: () => w("NEXT")
                })
            }, [ae, qe, _t, w])
        }), se(be, {
            state: "openness:closing",
            transition: "NEXT",
            callback: a.useCallback(() => {
                he("NEXT"), w({
                    machine: "staging",
                    type: "NEXT"
                })
            }, [he, w])
        });
        let Kr = a.useCallback(() => w({
            machine: "skipOpening",
            type: lt.skip ? "TO_TRUE" : "TO_FALSE"
        }), [w, lt.skip]);
        Qe("after-paint", U, {
            state: "",
            callback: Kr
        });
        let qr = a.useCallback(() => w({
            machine: "skipClosing",
            type: _t.skip ? "TO_TRUE" : "TO_FALSE"
        }), [w, _t.skip]);
        Qe("after-paint", U, {
            state: "",
            callback: qr
        }), a.useEffect(() => {
            xe !== void 0 && w(xe ? "OPEN" : "CLOSE")
        }, [xe, w]);
        let Jr = Dn(() => {
                Ga(), on == null || on(R), K.removeAllOutletPersistedStylesFromSheet(R)
            }),
            rl = a.useRef(!0),
            Zr = Dn(() => {
                xe && (ge == null || ge(!1))
            });
        a.useEffect(() => () => {
            !rl.current && (Zr(), wt(null, {
                newState: "none"
            }), Jr(), de(!1), it.silent.matches("longRunning:true") && (tt == null || tt(g => g - 1)))
        }, []), a.useEffect(() => () => rl.current = !1), a.useEffect(() => {
            Me !== void 0 && pe.current[0] !== Me && pe.current[1] !== Me && je.current !== Me && w({
                type: "STEP",
                activeDetent: Me
            })
        }, [Me, w]), a.useEffect(() => {
            let g = () => {
                var S;
                return (S = Oe.current) === null || S === void 0 ? void 0 : S.scrollTo(0, 0)
            };
            return window.addEventListener("unload", g), () => window.removeEventListener("unload", g)
        }, []);
        let sl = Dn((g, S) => {
                ut.current && !be.matches("openness:closed") && Et(g, S)
            }),
            il = Dn(Ka);
        a.useEffect(() => () => {
            sl(0, {
                start: 0,
                end: 0
            }), ut.current && il(), Zl(null)
        }, [it.silent, tt, sl, il]);
        let Xn = Xe("Sheet", {
                staging: te.getValues()[0],
                openness: be.getValues()[0],
                opennessClosedStatus: pt.getValues()[0],
                position: fn.getValues()[0],
                positionCoveredStatus: Wt.getValues()[0],
                placement: Ae,
                track: z,
                swipeDisabled: ke,
                swipeOutDisabledWithDetent: G,
                swipeOvershootDisabled: Z,
                swipeTrap: xn,
                scrollContainerShouldBePassThrough: st
            }),
            Hn = a.useMemo(() => !pt.matches(["openness:closed.status:flushing-to-preparing-open", "openness:closed.status:flushing-to-preparing-opening", "openness:closed.status:safe-to-unmount"]), [pt]),
            Qr = a.useMemo(() => be.matches("openness:closed") && Hn, [Hn, be]),
            ol = a.useMemo(() => te.matches(["staging:opening", "staging:open"]), [te]),
            es = a.useMemo(() => Hn || ol, [Hn, ol]),
            ts = a.useMemo(() => B && (fn.matches(["position:front", "position:covered"]) || Pe !== "none"), [B, fn, Pe]);
        return I.jsx(_n, {
            genericContext: zt,
            customContext: Fe,
            value: Je,
            children: I.jsx(ht.Provider, {
                value: {
                    sheetContext: ze,
                    titleId: we,
                    descriptionId: _e,
                    styleAttributes: Xn,
                    backdropRef: qt,
                    scrollContainerRef: Oe,
                    frontSpacerRef: cn,
                    contentWrapperRef: Ct,
                    contentRef: Lt,
                    backSpacerRef: En,
                    detentMarkersRefs: dn,
                    leftEdgeRef: Kt,
                    setBackdropSwipeable: Jt,
                    setBleedingBackgroundPresent: Qt,
                    detents: at,
                    longRunningState: it,
                    staging: Pe,
                    layerCovered: yt,
                    placement: Ae,
                    track: z,
                    travelAxis: rt,
                    nativeEdgeSwipePrevention: X,
                    bleedingBackgroundPresent: Zt,
                    setBackdropTravelHandler: Nr,
                    ancestorPrimarySwipeTrapActiveOnYAxis: xn === "vertical" || xn === "both",
                    scrollContainerTouchStartHandler: Gr,
                    scrollContainerTouchEndHandler: $r,
                    getContentCoordinatesWhenRestingOnLastDetent: Mr,
                    getOffsetFromCurrentToNextDetent: Hr
                },
                children: es && I.jsxs("div", M(y(M(y({
                    id: R
                }, Xn("view", ["track", "staging", "openness", "opennessClosedStatus", "scrollContainerShouldBePassThrough"], {
                    className: s,
                    dataSilk: [o, "0ab", W && "0ah", ot && "0aj", Qr && "0ak", "0al"]
                })), {
                    ref: kt,
                    "aria-labelledby": we,
                    "aria-describedby": _e
                }), Q), {
                    role: re,
                    tabIndex: -1,
                    children: [I.jsx(Pt.Root, M(y({}, Xn("primaryScrollTrapRoot", ["track", "scrollContainerShouldBePassThrough"])), {
                        active: xn !== "none",
                        axis: xn,
                        children: I.jsx(Pt.Stabiliser, {
                            children: r
                        })
                    })), I.jsx(Pt.Root, M(y({}, Xn("secondaryScrollTrapRoot", ["scrollContainerShouldBePassThrough"])), {
                        automaticallyDisabledForOptimisation: !1,
                        preventBodyScroll: ts
                    }))]
                }))
            })
        })
    });
or.displayName = "Sheet.Anonymous";
class Cn extends ie.Component {
    static getDerivedStateFromError(t) {
        return {
            hasError: !0
        }
    }
    componentDidCatch(t) {
        console.error(t)
    }
    render() {
        return this.state.hasError ? I.jsx("h1", {
            children: "Something went wrong."
        }) : this.props.children
    }
    constructor(t) {
        super(t), this.state = {
            hasError: !1
        }
    }
}
let ur = ie.forwardRef((e, t) => {
    let c = e,
        {
            asChild: n,
            children: l,
            className: i,
            "data-silk": r
        } = c,
        s = ue(c, ["asChild", "children", "className", "data-silk"]),
        o = n ? He : "span",
        u = Xe("VisuallyHidden", {});
    return I.jsx(o, M(y(y({}, u("root", [], {
        className: i,
        dataSilk: [r]
    })), s), {
        ref: t,
        children: l
    }))
});
ur.displayName = "VisuallyHidden.Root";
let li = {
        Root: ur
    },
    ca = ie.createContext(null);
ca.displayName = "SheetStack.GenericContext";
let Ln = [],
    ri = (e, t) => {
        let n = () => {
            let [l, i] = (function(o) {
                let u = 0,
                    c = 0;
                for (; o;) u += o.offsetLeft, c += o.offsetTop, o = o.offsetParent;
                return [u, c]
            })(e), r = {
                top: i + scrollY,
                bottom: Math.max(e.offsetHeight - (i + scrollY + innerHeight), 0),
                left: l + scrollX,
                right: Math.max(e.offsetWidth - (l + scrollX + innerWidth), 0),
                height: innerHeight,
                width: innerWidth
            }, s = r.top <= 0 && r.bottom <= 0 && r.left <= 0 && r.right <= 0 ? null : r;
            t(s)
        };
        Ln.push({
            element: e,
            callback: n
        }), n(), Ln.length === 1 && (Nn = (function(l, i) {
            let r;
            return function() {
                clearTimeout(r), r = window.setTimeout(() => {
                    clearTimeout(r), l()
                }, 100)
            }
        })(() => {
            Ln.forEach(l => l.callback())
        }), window.addEventListener("scroll", Nn), window.addEventListener("resize", Nn))
    },
    si = e => {
        (Ln = Ln.filter(t => t.element !== e)).length || (window.removeEventListener("scroll", Nn), window.removeEventListener("resize", Nn))
    },
    Wa = (e, t) => {
        let n = a.useId(),
            l = a.useRef(null),
            i = et(l, t),
            {
                sheetId: r,
                stackId: s,
                sheetsCount: o,
                travelAnimation: u,
                stackingAnimation: c,
                style: p
            } = e,
            {
                sheetId: m,
                longRunning: d
            } = da(r),
            [f, h] = a.useState(null),
            {
                willChangesValuesString: k,
                outletTransformedOnAnimation: v,
                nonAnimatedTravelStyles: b,
                nonAnimatedStackingStyles: C,
                clippedToViewport: A
            } = a.useMemo(() => {
                let O = [],
                    _ = {},
                    W = {},
                    D = !1,
                    L = !1;
                return [u, c].forEach((F, ee) => {
                    if (F) {
                        let ne = F.hasOwnProperty("properties") ? F.properties : F;
                        Object.entries(ne).forEach(([H, ce]) => {
                            !ce || (H === "clipBoundary" && (L = !0), typeof ce == "string" && (ee === 0 ? _[H] = ce : W[H] = ce), ql.includes(H) || H === "transform" ? O.includes("transform") || (O.push("transform"), D = !0) : H !== "opacity" || O.includes("opacity") || O.push("opacity"))
                        })
                    }
                }), {
                    willChangesValuesString: O.join(", "),
                    outletTransformedOnAnimation: D,
                    nonAnimatedTravelStyles: _,
                    nonAnimatedStackingStyles: W,
                    clippedToViewport: L
                }
            }, [c, u]),
            {
                modifiedTravelAnimation: x,
                modifiedNonAnimatedTravelStyles: B,
                modifiedStackingAnimation: X,
                modifiedNonAnimatedStackingStyles: N
            } = a.useMemo(() => {
                let O;
                if (f) {
                    let {
                        top: ee,
                        bottom: ne,
                        left: H,
                        right: ce
                    } = f;
                    O = "".concat(ee - .1, "px ").concat(ce, "px ").concat(ne, "px ").concat(H, "px")
                }
                let _ = (ee, ne) => {
                        let H, ce, Ne;
                        if (!ee) return [];
                        let {
                            top: Q,
                            left: ze,
                            height: Je,
                            width: mt
                        } = f || {}, Le = ee.hasOwnProperty("properties") ? ee.properties : ee, Fe = Le.clipBoundary, re = Le.clipBorderRadius, xe = Le.clipTransformOrigin;
                        if (Fe && (xe || (xe = "50% 50% 0"), Ne = xe.split(" ").map(Ee => Ee === "top" || Ee === "left" ? "0%" : Ee === "bottom" || Ee === "right" ? "100%" : Ee).map((Ee, Me) => {
                                if (Me === 0) {
                                    let ae = Ee;
                                    return Ee.includes("%") ? ae = Ee.replace(/\b\d+%/, R => parseFloat(R) / 100 * mt + "px") : Ee === "0" && (ae = "0px"), "calc(" + ze + "px + " + ae + ")"
                                }
                                if (Me === 1) {
                                    let ae = Ee;
                                    return Ee.includes("%") ? ae = Ee.replace(/\b\d+%/, R => parseFloat(R) / 100 * Je + "px") : Ee === "0" && (ae = "0px"), "calc(" + Q + "px + " + ae + ")"
                                }
                            }).join(" ")), Fe)
                            if (Fe === "layout-viewport")
                                if (O) {
                                    if (typeof re == "string") H = "inset(".concat(O, " round ").concat(re, ")");
                                    else if (Array.isArray(re)) {
                                        let me = "inset(".concat(O, " round ");
                                        H = ({
                                            tween: de
                                        }) => me + de(...re) + ")"
                                    } else if (typeof re == "function") {
                                        let me = "inset(".concat(O, " round ");
                                        H = de => me + re(de) + ")"
                                    } else H = "inset(".concat(O, ")");
                                    ce = "0.001px"
                                } else ce = re != null ? re : null;
                        else if (typeof Fe == "function")
                            if (O) {
                                if (typeof re == "string") H = me => Fe(me) !== "none" ? "inset(".concat(O, " round ").concat(re, ")") : "none";
                                else if (Array.isArray(re)) {
                                    let me = "inset(".concat(O, " round ");
                                    H = de => Fe(de) !== "none" ? me + de.tween(...re) + ")" : "none"
                                } else if (typeof re == "function") {
                                    let me = "inset(".concat(O, " round ");
                                    H = de => Fe(de) !== "none" ? me + re(de) + ")" : "none"
                                } else H = me => Fe(me) !== "none" ? "inset(".concat(O, ")") : "none";
                                ce = "0.001px"
                            } else re && (ce = me => {
                                if (Fe(me) === "layout-viewport") return re
                            });
                        else Fe === "none" && (H = "none", ce = re != null ? re : null);
                        else {
                            let me = y({}, Le),
                                de = y({}, ne);
                            return delete me.clipBoundary, delete me.clipBorderRadius, delete me.clipTransformOrigin, delete de.clipBoundary, delete de.clipBorderRadius, delete de.clipTransformOrigin, [me, de]
                        }
                        let ge = y({}, Le),
                            Be = y({}, ne);
                        return delete ge.clipBoundary, delete ge.clipBorderRadius, delete ge.clipTransformOrigin, delete Be.clipBoundary, delete Be.clipBorderRadius, delete Be.clipTransformOrigin, typeof H == "string" ? Be.clipPath = H : ge.clipPath = H, typeof ce == "string" ? Be.borderRadius = ce : ge.borderRadius = ce, typeof Ne == "string" && (Be.transformOrigin = Ne), [ge, Be]
                    },
                    [W, D] = _(u, b),
                    [L, F] = _(c, C);
                return {
                    modifiedTravelAnimation: W,
                    modifiedNonAnimatedTravelStyles: D,
                    modifiedStackingAnimation: L,
                    modifiedNonAnimatedStackingStyles: F
                }
            }, [f, C, b, c, u]);
        De(() => {
            let O = l.current,
                _ = n && A && (!s && d || s && o >= 1);
            if (_) return ri(O, h), () => {
                _ && si(O)
            }
        }, [n, A, d, s, o]);
        let q = a.useMemo(() => s ? M(y(y({}, p), o >= 1 ? N : {}), {
            willChange: o >= 1 ? k + (p != null && p.willChange ? ", " + (p == null ? void 0 : p.willChange) : "") : p == null ? void 0 : p.willChange
        }) : M(y(y(y({}, p), d ? B : {}), o >= 1 ? N : {}), {
            willChange: d ? k + (p != null && p.willChange ? ", " + (p == null ? void 0 : p.willChange) : "") : p == null ? void 0 : p.willChange
        }), [s, p, B, N, d, o, k]);
        return De(() => {
            let O, _ = K.findActualFixedComponentsInsideOutlet(l.current);
            if (_.length) return v && (O = (W => {
                let D = () => {
                        _.forEach(F => {
                            if (!F.element || F.compensated) return;
                            let ee = 0,
                                ne = 0,
                                H = F.element.style.transform,
                                ce = window.getComputedStyle(F.element),
                                Ne = ce.getPropertyValue("--silk-fixed-side"),
                                Q = ce.getPropertyValue("transform");
                            K.updateFixedComponent({
                                id: F.id,
                                initialInlineCSSTransform: H,
                                compensated: !0
                            }), ee = Ne.includes("bottom") ? -1 * (l.current.offsetHeight - (scrollY + window.innerHeight)) : scrollY, ne = Ne.includes("right") ? -1 * (l.current.offsetWidth - (scrollX + window.innerWidth)) : scrollX, (Math.abs(ee) !== 0 || Math.abs(ne) !== 0) && F.element.style.setProperty("transform", (Q !== "none" ? Q + " " : "") + "translateX(" + ne + "px) translateY(" + ee + "px)")
                        })
                    },
                    L = () => {
                        window.removeEventListener("resize", D), window.removeEventListener("scroll", D), _.forEach(F => {
                            F.element && F.compensated && (F.initialInlineCSSTransform ? (F.element.style.setProperty("transform", F.initialInlineCSSTransform), K.updateFixedComponent({
                                id: F.id,
                                initialInlineCSSTransform: void 0,
                                compensated: !1
                            })) : (F.element.style.removeProperty("transform"), K.updateFixedComponent({
                                id: F.id,
                                compensated: !1
                            })))
                        })
                    };
                return W ? (D(), window.addEventListener("resize", D), window.addEventListener("scroll", D)) : L(), L
            })(s ? o > 0 : d)), O
        }, [d, n, v, o, s]), De(() => (K.addOutletToSheet(m, n), () => K.removeOutletFromSheet(m, n)), [n, m]), De(() => {
            let O = l.current;
            return x && K.addAnimationToSheetOrStack({
                sheetId: m,
                type: "travel",
                element: O,
                config: x
            }), X && K.addAnimationToSheetOrStack({
                sheetId: s ? null : m,
                stackId: s,
                type: "stacking",
                element: O,
                config: X
            }), () => {
                x && K.removeAnimationFromSheetOrStack({
                    sheetId: m,
                    type: "travel",
                    element: O
                }), X && K.removeAnimationFromSheetOrStack({
                    sheetId: s ? null : m,
                    stackId: s,
                    type: "stacking",
                    element: O
                })
            }
        }, [m, s, x, X]), {
            ref: l,
            outletId: n,
            styleValue: q,
            composedRef: i
        }
    },
    da = e => a.useContext(e != null ? e : zt) || {};
Cn.displayName = "Sheet.ErrorBoundary", He.displayName = "Sheet.Slot.Root";
let Gt = ie.forwardRef((e, t) => {
    let C = e,
        {
            asChild: n,
            forComponent: l,
            travelAnimation: i,
            stackingAnimation: r,
            style: s,
            className: o
        } = C,
        u = ue(C, ["asChild", "forComponent", "travelAnimation", "stackingAnimation", "style", "className"]),
        {
            staging: c,
            StackContext: p
        } = da(l),
        m = p != null ? p : ie.createContext(null),
        {
            sheetsCount: d
        } = a.useContext(m) || {},
        {
            styleValue: f,
            composedRef: h
        } = Wa({
            sheetId: l,
            sheetsCount: d,
            travelAnimation: i,
            stackingAnimation: r,
            style: s
        }, t),
        k = a.useMemo(() => c !== "none", [c]),
        v = n ? He : "div",
        b = Xe("Sheet", {});
    return I.jsx(v, M(y(y({
        style: f
    }, b("outlet", [], {
        className: o,
        dataSilk: [k && "0aj"]
    })), u), {
        ref: h
    }))
});
Gt.displayName = "Sheet.Outlet";
let ja = ie.forwardRef((l, n) => {
    var i = l,
        {
            asChild: e
        } = i,
        t = ue(i, ["asChild"]);
    let r = e ? He : "button",
        W = t,
        {
            forComponent: s,
            className: o,
            "data-silk": u,
            onPress: c,
            onClick: p,
            children: m,
            action: d = "present",
            travelAnimation: f,
            stackingAnimation: h
        } = W,
        k = ue(W, ["forComponent", "className", "data-silk", "onPress", "onClick", "children", "action", "travelAnimation", "stackingAnimation"]),
        {
            sheetRole: v,
            sheetId: b,
            open: C,
            onOpenChange: A,
            elementFocusedLastBeforeShowing: x
        } = da(s),
        B = K.findSheet(b),
        X = a.useRef(null),
        N = et(X, n),
        q = a.useMemo(() => (v === "dialog" || v === "alertdialog") && d === "present" ? "dialog" : void 0, [d, v]),
        O = a.useMemo(() => d === "present" || d === "dismiss" ? C : void 0, [d, C]),
        _ = Xe("Sheet", {});
    return I.jsx(Gt, {
        forComponent: s,
        asChild: !0,
        travelAnimation: f,
        stackingAnimation: h,
        children: I.jsx(r, M(y(M(y({}, _("trigger", [], {
            className: o,
            dataSilk: [u]
        })), {
            onClick: D => {
                var L, F;
                let {
                    forceFocus: ee,
                    runAction: ne
                } = St({
                    nativeEvent: D,
                    defaultBehavior: {
                        forceFocus: !0,
                        runAction: !0
                    },
                    handler: c
                });
                ee && ((L = X.current) === null || L === void 0 || L.focus({
                    preventScroll: !0
                })), ne && (d === "present" ? (x.current = X.current, A(!0)) : d === "dismiss" ? A(!1) : (d === "step" || d.type === "step") && (B == null || (F = B.sendToOpennessMachine) === null || F === void 0 || F.call(B, {
                    type: "STEP",
                    direction: d === "step" ? "up" : d.direction,
                    detent: d === "step" ? null : d.detent
                }))), p == null || p(D)
            },
            "aria-haspopup": q,
            "aria-controls": b,
            "aria-expanded": O,
            ref: N
        }), k), {
            children: m
        }))
    })
});
ja.displayName = "Sheet.Trigger";
let cr = ie.forwardRef((e, t) => {
    let c = e,
        {
            children: n,
            className: l,
            action: i = "step"
        } = c,
        r = ue(c, ["children", "className", "action"]),
        {
            detents: s
        } = a.useContext(ht) || {},
        o = s.length === 1 && i !== "dismiss",
        u = Xe("Sheet", {});
    return I.jsx(ja, M(y(M(y({}, u("handle", [], {
        className: l
    })), {
        action: i,
        disabled: o
    }), r), {
        ref: t,
        children: I.jsx(li.Root, {
            children: n != null ? n : i === "dismiss" ? "Dismiss" : "Cycle"
        })
    }))
});
cr.displayName = "Sheet.Handle";
let dr = e => {
    var t;
    let [n, l] = a.useState(!1);
    return a.useEffect(() => (l(!0), () => l(!1)), []), n ? Fl.createPortal(e.children, (t = e.container) !== null && t !== void 0 ? t : document.body) : null
};
dr.displayName = "Sheet.Portal";
let ii = ({
        rootRef: e
    }) => (a.useEffect(() => {
        let t = e.current;
        if (!t) return;
        getComputedStyle(t).getPropertyValue("--silk-aY").trim() !== "1" && console.warn("The CSS styles for Silk are not found. Please refer to the documentation on how to import them.")
    }, [e]), null),
    mr = ie.forwardRef((e, t) => {
        let Q = e,
            {
                className: n,
                "data-silk": l,
                license: i,
                sheetRole: r,
                componentId: s,
                forComponent: o,
                defaultPresented: u,
                presented: c,
                onPresentedChange: p,
                defaultActiveDetent: m,
                activeDetent: d,
                onActiveDetentChange: f,
                onSafeToUnmountChange: h
            } = Q,
            k = ue(Q, ["className", "data-silk", "license", "sheetRole", "componentId", "forComponent", "defaultPresented", "presented", "onPresentedChange", "defaultActiveDetent", "activeDetent", "onActiveDetentChange", "onSafeToUnmountChange"]),
            v = a.useRef(null),
            b = et(v, t),
            C = u != null && u,
            [A, x] = a.useState(C),
            B = c !== void 0 && p !== void 0,
            X = a.useMemo(() => B ? c : A, [B, c, A]),
            N = a.useMemo(() => B ? p : x, [B, p, x]),
            q = a.useRef(null),
            [O, _] = a.useState(!C),
            W = a.useCallback(ze => {
                h == null || h(ze), _(ze)
            }, [h]),
            [D, L] = a.useState(X),
            [F, ee] = a.useState("none"),
            ne = o === "closest" ? ca : o,
            H = sn(),
            ce = y({
                license: i,
                StackContext: ne,
                CustomSheetContext: s,
                sheetId: H,
                sheetRole: r,
                open: X,
                onOpenChange: N,
                onSafeToUnmountChange: W,
                defaultActiveDetent: m,
                activeDetent: d,
                onActiveDetentChange: f,
                safeToUnmount: O,
                longRunning: D,
                setLongRunning: L,
                staging: F,
                setStaging: ee,
                elementFocusedLastBeforeShowing: q
            }, k),
            Ne = Xe("Sheet");
        return I.jsxs(Cn, {
            children: [I.jsx(ii, {
                rootRef: v
            }), I.jsx(_n, {
                genericContext: zt,
                customContext: s,
                value: ce,
                children: I.jsx(Gt, y(M(y({}, Ne("root", [], {
                    className: n,
                    dataSilk: [l]
                })), {
                    ref: b
                }), k))
            })]
        })
    });
mr.displayName = "Sheet.Root";
let pr = ie.forwardRef((e, t) => {
    let {
        forComponent: n
    } = e, {
        open: l,
        safeToUnmount: i
    } = da(n);
    return (l || !i) && I.jsx(or, M(y({}, e), {
        ref: t
    }))
});
pr.displayName = "Sheet.View";
let fr = ie.forwardRef((i, l) => {
    var r = i,
        {
            asChild: e,
            swipeable: t = !0
        } = r,
        n = ue(r, ["asChild", "swipeable"]);
    let {
        longRunningState: s,
        backdropRef: o,
        styleAttributes: u,
        setBackdropSwipeable: c,
        setBackdropTravelHandler: p
    } = a.useContext(ht) || {}, q = n, {
        className: m,
        "data-silk": d,
        children: f,
        travelAnimation: h,
        stackingAnimation: k,
        themeColorDimming: v = !1
    } = q, b = ue(q, ["className", "data-silk", "children", "travelAnimation", "stackingAnimation", "themeColorDimming"]), C = et(o, l);
    a.useEffect(() => (c(t), () => {
        c(!1)
    }), [c, t]);
    let A = a.useMemo(() => y({
            opacity: ({
                progress: O
            }) => Math.min(.33 * O, .33)
        }, h), [h]),
        [x, B] = a.useState(A),
        X = sn(),
        N = a.useRef(0);
    return De(() => {
        let O = !1,
            _ = () => {
                O && K.removeThemeColorDimmingOverlay(X)
            };
        if (s.matches("longRunning:true")) {
            let D;
            if (!(O = !!(Rt() && !Xl() && v === "auto" && A.opacity && K.getAndStoreUnderlyingThemeColorAsRGBArray()))) return;
            let W = A,
                {
                    opacity: L
                } = W,
                F = ue(W, ["opacity"]);
            if (B(y({
                    opacity: "ignore"
                }, F)), Array.isArray(L)) {
                let [ee, ne] = L;
                D = ({
                    progress: H
                }) => ee + (ne - ee) * H
            } else typeof L == "function" && (D = L, B(y({
                opacity: "ignore"
            }, F)));
            if (D && o && p) {
                let ee = window.getComputedStyle(o.current).backgroundColor,
                    ne = K.updateThemeColorDimmingOverlay({
                        abortRemoval: !0,
                        dimmingOverlayId: X,
                        color: ee,
                        alpha: N.current
                    }),
                    H = ce => {
                        var Ne;
                        let Q = D(ce);
                        K.updateThemeColorDimmingOverlayAlphaValue(ne, Q), (Ne = o.current) === null || Ne === void 0 || Ne.style.setProperty("opacity", Q), N.current = Q
                    };
                p(() => H)
            }
        }
        return s.matches("longRunning:false") && _(), () => {
            _()
        }
    }, [s, X, o, p, v, h, A]), I.jsx(Gt, M(y(M(y({}, u("backdrop", ["scrollContainerShouldBePassThrough"], {
        className: m,
        dataSilk: [d]
    })), {
        travelAnimation: x,
        stackingAnimation: k
    }), b), {
        ref: C,
        asChild: e,
        children: f
    }))
});
fr.displayName = "Sheet.Backdrop";
let gr = ie.forwardRef((e, t) => {
    var n;
    let ee = e,
        {
            asChild: l,
            children: i,
            className: r,
            "data-silk": s,
            travelAnimation: o,
            stackingAnimation: u,
            style: c
        } = ee,
        p = ue(ee, ["asChild", "children", "className", "data-silk", "travelAnimation", "stackingAnimation", "style"]),
        m = l ? He : "div",
        {
            StackContext: d
        } = a.useContext(zt) || {},
        f = d != null ? d : ie.createContext(null),
        {
            sheetsCount: h
        } = a.useContext(f) || {},
        {
            styleValue: k,
            composedRef: v
        } = Wa({
            sheetId: zt,
            sheetsCount: h,
            travelAnimation: o,
            stackingAnimation: u,
            style: c
        }, t),
        {
            scrollContainerRef: b,
            frontSpacerRef: C,
            contentWrapperRef: A,
            contentRef: x,
            backSpacerRef: B,
            detentMarkersRefs: X,
            leftEdgeRef: N,
            nativeEdgeSwipePrevention: q,
            scrollContainerTouchStartHandler: O,
            scrollContainerTouchEndHandler: _,
            styleAttributes: W,
            detents: D,
            bleedingBackgroundPresent: L
        } = a.useContext(ht) || {},
        F = et(x, v);
    return I.jsxs("div", M(y({}, W("scrollContainer", ["track", "swipeDisabled", "swipeOvershootDisabled", "staging", "positionCoveredStatus", "scrollContainerShouldBePassThrough", "swipeTrap"], {
        dataSilk: ["0ac"]
    })), {
        ref: b,
        onTouchStart: O,
        onTouchEnd: _,
        children: [I.jsx("div", M(y({}, W("frontSpacer", ["track"])), {
            ref: C
        })), I.jsxs("div", M(y({}, W("contentWrapper", ["placement", "track", "swipeOvershootDisabled", "swipeOutDisabledWithDetent", "staging", "position"])), {
            ref: A,
            children: [I.jsx(m, M(y(M(y({}, W("content", ["track", "placement", "scrollContainerShouldBePassThrough"], {
                className: r,
                dataSilk: [s, L && "0af"]
            })), {
                style: k
            }), p), {
                ref: F,
                children: i
            })), q && I.jsx("div", M(y({}, W("leftEdge", ["track"])), {
                ref: N
            }))]
        })), I.jsx("div", M(y({}, W("backSpacer", ["track"])), {
            ref: B,
            children: D.map((ne, H) => I.jsx("div", M(y({
                ref: ce => {
                    X.current.length > D.length && (X.current = X.current.slice(0, D.length)), X.current[H] = ce
                }
            }, W("detentMarker", ["track", "swipeOutDisabledWithDetent"])), {
                style: {
                    "--silk-aA": (n = D[H - 1]) !== null && n !== void 0 ? n : "0px",
                    "--silk-aB": ne,
                    "--silk-aC": H
                }
            }), H))
        }))]
    }))
});
gr.displayName = "Sheet.Content";
let hr = ie.forwardRef((l, n) => {
    var i = l,
        {
            asChild: e
        } = i,
        t = ue(i, ["asChild"]);
    let h = t,
        {
            className: r,
            "data-silk": s
        } = h,
        o = ue(h, ["className", "data-silk"]),
        {
            staging: u,
            placement: c,
            track: p,
            setBleedingBackgroundPresent: m
        } = a.useContext(ht) || {};
    a.useEffect(() => (m(!0), () => {
        m(!1)
    }), [m]);
    let d = p === "horizontal" || p === "vertical",
        f = Xe("Sheet", {
            staging: u,
            placement: c,
            track: p,
            bleedDisabled: d
        });
    return I.jsx(Gt, M(y(y({
        asChild: e
    }, f("bleedingBackground", ["staging", "placement", "track", "bleedDisabled"], {
        className: r,
        dataSilk: [s]
    })), o), {
        ref: n
    }))
});
hr.displayName = "Sheet.BleedingBackground";
let vr = ie.forwardRef((e, t) => {
    let p = e,
        {
            className: n,
            "data-silk": l
        } = p,
        i = ue(p, ["className", "data-silk"]),
        {
            travelAxis: r
        } = a.useContext(ht) || {},
        s = a.useMemo(() => r === "vertical" ? "horizontal" : "vertical", [r]),
        [o, u] = a.useState(!1);
    a.useEffect(() => u(Rt()), []);
    let c = Xe("SpecialWrapper");
    return I.jsx(Pt.Root, M(y(M(y({}, c("root", [], {
        className: n,
        dataSilk: [l]
    })), {
        active: o,
        axis: s
    }), i), {
        ref: t
    }))
});
vr.displayName = "Sheet.SpecialWrapper.Root";
let kr = ie.forwardRef((e, t) => I.jsx(Pt.Stabiliser, M(y({}, e), {
    ref: t
})));
kr.displayName = "Sheet.SpecialWrapper.Content";
let br = ie.forwardRef((e, t) => {
    let u = e,
        {
            asChild: n,
            travelAnimation: l,
            stackingAnimation: i
        } = u,
        r = ue(u, ["asChild", "travelAnimation", "stackingAnimation"]),
        s = n ? He : "h2",
        {
            titleId: o
        } = a.useContext(ht);
    return I.jsx(Gt, {
        asChild: !0,
        travelAnimation: l,
        stackingAnimation: i,
        children: I.jsx(s, y({
            id: o,
            ref: t
        }, r))
    })
});
br.displayName = "Sheet.Title";
let Sr = ie.forwardRef((e, t) => {
    let u = e,
        {
            asChild: n,
            travelAnimation: l,
            stackingAnimation: i
        } = u,
        r = ue(u, ["asChild", "travelAnimation", "stackingAnimation"]),
        {
            descriptionId: s
        } = a.useContext(ht),
        o = n ? He : "p";
    return I.jsx(Gt, {
        asChild: !0,
        travelAnimation: l,
        stackingAnimation: i,
        children: I.jsx(o, M(y({
            id: s
        }, r), {
            ref: t
        }))
    })
});
Sr.displayName = "Sheet.Description";
let vi = {
    Root: mr,
    Trigger: ja,
    View: pr,
    Backdrop: fr,
    Content: gr,
    BleedingBackground: hr,
    Handle: cr,
    SpecialWrapper: {
        Root: vr,
        Content: kr
    },
    Outlet: Gt,
    Portal: dr,
    Title: br,
    Description: Sr
};
Cn.displayName = "SheetStack.ErrorBoundary";
let yr = ie.forwardRef((e, t) => {
    let N = e,
        {
            componentId: n,
            className: l,
            "data-silk": i,
            asChild: r
        } = N,
        s = ue(N, ["componentId", "className", "data-silk", "asChild"]),
        o = a.useId();
    De(() => (K.addSheetStack({
        id: o
    }), () => K.removeSheetStack(o)), [o]);
    let [u, c] = a.useState([]), p = a.useCallback(q => {
        c(O => {
            let _, W = O.findIndex(D => D.sheetId === q.sheetId);
            return W !== -1 ? (_ = [...O])[W] = q : _ = [...O, q], _
        })
    }, []), m = a.useCallback(q => {
        c(O => O.filter(_ => _.sheetId !== q))
    }, []), d = a.useCallback(q => {
        let O = u.findIndex(_ => _.sheetId === q);
        return O === -1 ? u[u.length - 1] : u[O - 1]
    }, [u]), [f, h] = a.useState(0);
    De(() => {
        f === 0 && K.removeAllOutletPersistedStylesFromStack(o)
    }, [f, o]);
    let [k, v] = a.useState([]), b = a.useCallback(q => {
        v(O => {
            let _ = O.findIndex(W => W.sheetId === q.sheetId);
            if (_ === -1) return [...O, q]; {
                let W = [...O];
                return W[_] = q, W
            }
        })
    }, []), C = a.useCallback(q => {
        v(O => O.filter(_ => _.sheetId !== q))
    }, []), A = a.useMemo(() => k.some(q => q.staging !== "none") ? "not-none" : "none", [k]), x = a.useMemo(() => ({
        stackId: o,
        sheetsCount: f,
        setSheetsCount: h,
        updateSheetStagingDataInStack: b,
        removeSheetStagingDataInStack: C,
        sheetsInStackMergedStaging: A,
        updateSheetDataInStack: p,
        removeSheetDataFromStack: m,
        getPreviousSheetDataInStack: d
    }), [o, f, b, C, A, p, m, d]), B = r ? He : "div", X = Xe("SheetStack");
    return I.jsx(Cn, {
        children: I.jsx(_n, {
            genericContext: ca,
            customContext: n,
            value: x,
            children: I.jsx(B, y(M(y({}, X("root", [], {
                className: l,
                dataSilk: [i]
            })), {
                ref: t
            }), s))
        })
    })
});
yr.displayName = "SheetStack.Root";
let Cr = ie.forwardRef((e, t) => {
    let b = e,
        {
            forComponent: n = "closest",
            asChild: l,
            stackingAnimation: i,
            style: r,
            className: s
        } = b,
        o = ue(b, ["forComponent", "asChild", "stackingAnimation", "style", "className"]),
        u = n === "closest" ? ca : n,
        {
            stackId: c,
            sheetsCount: p,
            sheetsInStackMergedStaging: m
        } = a.useContext(u);
    De(() => {
        K.addSheetStack({
            id: c
        })
    }, [c]);
    let {
        styleValue: d,
        composedRef: f
    } = Wa({
        sheetsCount: p,
        stackId: c,
        stackingAnimation: i,
        style: r
    }, t), h = a.useMemo(() => m !== "none", [m]), k = Xe("SheetStack", {}), v = l ? He : "div";
    return I.jsx(v, M(y(y({
        style: d
    }, k("outlet", [], {
        className: s,
        dataSilk: [h && "0aj"]
    })), o), {
        ref: f
    }))
});
Cr.displayName = "SheetStack.Outlet";
let ki = {
        Root: yr,
        Outlet: Cr
    },
    Ua = ie.createContext(null);
Ua.displayName = "Scroll.GenericContext";
let ma = ie.createContext({
    contentRef: null
});
ma.displayName = "Scroll.Anonymous";
let Mn = {
        nativePageScrollReplaced: void 0,
        pageScrollContainer: void 0
    },
    Tr = e => a.useContext(e != null ? e : Ua) || {},
    oi = Re === "android" ? 102 : 54,
    Ra = Ba || Re === "android" ? "instant" : "smooth",
    ui = (e, t, n = 300) => {
        let l, i = e.scrollTop,
            r = () => {
                clearTimeout(l), e.removeEventListener("scroll", s), t()
            },
            s = () => {
                let o = e.scrollTop;
                if (o > i) {
                    r();
                    return
                }
                i = o, clearTimeout(l), l = setTimeout(r, n)
            };
        l = setTimeout(r, n), e.addEventListener("scroll", s)
    },
    Pa = e => {
        if (!e) return {
            top: 0,
            bottom: 0
        };
        let t = e.getBoundingClientRect(),
            n = window.getComputedStyle(e),
            l = t.top + parseFloat(n.borderTopWidth),
            i = t.bottom - parseFloat(n.borderBottomWidth);
        return {
            top: l,
            bottom: i
        }
    },
    Ml = () => {
        let e = window.visualViewport.height,
            t = window.visualViewport.offsetTop;
        return {
            top: t,
            bottom: t + e
        }
    },
    ci = (e, t) => Math.abs(Math.min(e + t, 0)),
    di = (e, t) => Math.max(e - t, 0),
    _l = (e, t, n) => {
        e.style.setProperty("height", t + "px"), n.current = t
    },
    mi = ({
        scrollContainer: e,
        elementTop: t,
        elementBottom: n,
        behavior: l,
        scrollMarginTop: i,
        scrollMarginBottom: r,
        scrollPortTop: s,
        scrollPortBottom: o,
        visualViewportTop: u,
        visualViewportBottom: c,
        beforeScrollCallback: p
    }) => {
        if (!e) return;
        let m = t - Math.max(s, u),
            d = Math.min(o, c) - n;
        if (m < i) {
            let f = Math.max(-e.scrollTop, m - i);
            f !== 0 && (p(), e.scrollBy({
                top: f,
                behavior: l
            }))
        } else if (d < r) {
            let f = e.scrollHeight - e.clientHeight - e.scrollTop,
                h = Math.min(f, r - d);
            h !== 0 && (p(), e.scrollBy({
                top: h,
                behavior: l
            }))
        }
    };
Cn.displayName = "Scroll.ErrorBoundary";
let Er = ie.forwardRef((e, t) => {
    let k = e,
        {
            asChild: n,
            className: l,
            componentId: i,
            componentRef: r,
            "data-silk": s
        } = k,
        o = ue(k, ["asChild", "className", "componentId", "componentRef", "data-silk"]),
        u = n ? He : "div",
        c = a.useRef(() => {}),
        p = a.useCallback((...v) => {
            let b = c.current;
            return b(...v)
        }, []),
        m = a.useRef(() => {}),
        d = a.useCallback((...v) => {
            let b = m.current;
            return b(...v)
        }, []),
        f = a.useMemo(() => ({
            componentRef: r,
            scrollToRef: c,
            scrollTo: p,
            scrollByRef: m,
            scrollBy: d
        }), [r, d, p]),
        h = Xe("Scroll", {});
    return I.jsx(Cn, {
        children: I.jsx(_n, {
            genericContext: Ua,
            customContext: i,
            value: f,
            children: I.jsx(u, M(y(y({}, h("root", [], {
                className: l,
                dataSilk: [s]
            })), o), {
                ref: t
            }))
        })
    })
});
Er.displayName = "Scroll.Root";
let Qn = null,
    wr = () => {
        let e = a.useRef(null);
        De(() => {
            Qn === null && e.current && (Qn = e.current.offsetWidth - e.current.clientWidth, document.body.style.setProperty("--ua-scrollbar-thickness", Qn + "px"))
        }, []);
        let t = Xe("Scroll"),
            n = I.jsx("div", M(y({}, t("UAScrollbarMeasurer")), {
                ref: e
            }));
        return Qn === null ? typeof window < "u" ? Fl.createPortal(n, document.body) : I.jsx(I.Fragment, {
            children: n
        }) : null
    };
wr.displayName = "Scroll.Anonymous";
let ea = (e, t, n, l = !1) => typeof e == "boolean" ? e : typeof(e == null ? void 0 : e[t]) == "boolean" ? e[t] : typeof(e == null ? void 0 : e[n]) == "boolean" ? e[n] : l,
    Ar = ie.forwardRef((e, t) => {
        let _t = e,
            {
                asChild: n,
                children: l,
                className: i,
                "data-silk": r,
                forComponent: s,
                axis: o = "y",
                pageScroll: u = !1,
                nativePageScrollReplacement: c = !1,
                safeArea: p = "visual-viewport",
                scrollGestureTrap: m = !1,
                scrollGestureOvershoot: d = !0,
                scrollGesture: f = "auto",
                onScrollStart: h,
                onScroll: k,
                onScrollEnd: v,
                onFocusInside: b,
                nativeFocusScrollPrevention: C = !0,
                scrollAnimationSettings: A = {
                    skip: "auto"
                },
                scrollAnchoring: x = !0,
                scrollSnapType: B = "none",
                scrollPadding: X = "auto",
                scrollTimelineName: N = "none",
                nativeScrollbar: q = !0
            } = _t,
            O = ue(_t, ["asChild", "children", "className", "data-silk", "forComponent", "axis", "pageScroll", "nativePageScrollReplacement", "safeArea", "scrollGestureTrap", "scrollGestureOvershoot", "scrollGesture", "onScrollStart", "onScroll", "onScrollEnd", "onFocusInside", "nativeFocusScrollPrevention", "scrollAnimationSettings", "scrollAnchoring", "scrollSnapType", "scrollPadding", "scrollTimelineName", "nativeScrollbar"]),
            [_, W, D, L] = a.useMemo(() => {
                let P = ea(m, "xStart", "x"),
                    oe = ea(m, "xEnd", "x"),
                    Z = ea(m, "yStart", "y"),
                    ke = ea(m, "yEnd", "y"),
                    G = P,
                    ve = oe,
                    ye = Z,
                    ot = ke;
                return o === "y" ? ve = G = P !== oe || P : ot = ye = Z !== ke || Z, [G, ve, ye, ot]
            }, [m, o]),
            F = a.useMemo(() => _ !== W, [W, _]),
            ee = a.useMemo(() => D !== L, [L, D]),
            ne = a.useMemo(() => {
                if (B === "proximity") {
                    if (o === "y") return "proximityY";
                    if (o === "x") return "proximityX"
                } else {
                    if (B !== "mandatory") return "none";
                    if (o === "y") return "mandatoryY";
                    if (o === "x") return "mandatoryX"
                }
            }, [o, B]),
            H = n ? He : "div",
            ce = a.useRef(null),
            Ne = et(ce, t),
            Q = a.useRef(null),
            ze = a.useRef(null),
            Je = a.useRef(null),
            mt = a.useRef(null),
            Le = a.useRef(null),
            Fe = a.useRef(null),
            re = sn(),
            {
                componentRef: xe,
                scrollToRef: ge,
                scrollByRef: Be
            } = Tr(s) || {},
            {
                getContentCoordinatesWhenRestingOnLastDetent: me,
                contentRef: de
            } = a.useContext(ht) || {},
            vt = a.useMemo(() => f === !1 || f !== "auto", [f]),
            [Ee, Me] = a.useState(!1),
            [ae, R] = a.useState(!1);
        De(() => {
            u && (P => {
                let oe = "data-silk-native-page-scroll-replaced",
                    Z = document.documentElement.getAttribute(oe);
                if (!u && Z !== "true") return;
                let ke = window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone;
                if (P !== !0 && (P !== "auto" || (Re === "android" || Re === "ios" || Re === "ipados") && !ke)) {
                    var ve, ye;
                    R(!1), Mn = {
                        nativePageScrollReplaced: !1,
                        pageScrollContainer: document.body
                    };
                    let ot = new Event("silk-page-scroll-data-change");
                    if (document.dispatchEvent(ot), Z === "false") return;
                    let rt = (ye = (ve = Q.current) === null || ve === void 0 ? void 0 : ve.scrollTop) !== null && ye !== void 0 ? ye : 0;
                    document.documentElement.setAttribute(oe, "false"), Z === "true" && window.scrollTo(0, rt)
                } else {
                    R(!0), Mn = {
                        nativePageScrollReplaced: !0,
                        pageScrollContainer: Q.current
                    };
                    let ot = new Event("silk-page-scroll-data-change");
                    if (document.dispatchEvent(ot), Z === "true") return;
                    let rt = window.pageYOffset;
                    if (document.documentElement.setAttribute(oe, "true"), !Q.current) return;
                    Q.current.scrollTop = rt
                }
            })(c)
        }, [u, c]);
        let [we, _e] = a.useState(!0), [Pe, U] = a.useState(!0);
        De(() => {
            let P = Q.current,
                oe = ze.current,
                Z = Je.current,
                ke = mt.current,
                G = new ResizeObserver(() => {
                    P && (o === "y" && P.scrollHeight > P.clientHeight ? _e(!0) : _e(!1), o === "x" && P.scrollWidth > P.clientWidth ? U(!0) : U(!1))
                });
            return P && oe && Z && ke && (G.observe(P, {
                box: "border-box"
            }), G.observe(oe, {
                box: "border-box"
            }), G.observe(Z, {
                box: "border-box"
            }), G.observe(ke, {
                box: "border-box"
            })), () => {
                G && G.disconnect()
            }
        }, [o, vt]);
        let [w, Ge] = a.useState(!1);
        De(() => {
            Ge(we || Pe ? !0 : () => !1)
        }, [we, Pe]);
        let [he, yt] = a.useState(!1);
        a.useEffect(() => {
            yt(Yl())
        }, []);
        let fe = a.useRef(!1),
            Ie = a.useRef(!1),
            te = F || ee,
            [It, tt] = a.useState(_),
            [Tn, on] = a.useState(D);
        a.useEffect(() => {
            let P;
            if (te) {
                let oe = Le.current,
                    Z = Fe.current;
                if (!oe || !Z) return;
                (P = new IntersectionObserver(ke => {
                    for (let G of ke) G.target === oe ? G.isIntersecting ? (fe.current = !0, o === "x" ? tt(_) : on(D)) : fe.current = !1 : G.target === Z && (G.isIntersecting ? (Ie.current = !0, o === "x" ? tt(W) : on(L)) : Ie.current = !1), fe.current && Ie.current && (o === "x" ? tt(!1) : on(!1))
                }, {
                    root: Q.current,
                    rootMargin: "0px",
                    threshold: [1]
                })).observe(oe), P.observe(Z)
            }
            return () => {
                P && P.disconnect()
            }
        }, [W, _, L, D, o, te]);
        let Dt = a.useRef(!1),
            un = a.useRef(),
            $t = a.useRef(""),
            Nt = a.useRef(void 0);
        a.useEffect(() => {
            let P = Q.current;
            if (!P) return;
            let oe = ke => {
                    Ye.current = !1, St({
                        nativeEvent: ke,
                        defaultBehavior: {},
                        handler: v
                    });
                    let G = document.activeElement;
                    (Re == "ios" || Re == "ipados") && G && ln(G) && (Nt.current === void 0 && ($t.current = G.style.getPropertyValue("opacity"), G.style.setProperty("opacity", "0.9999", "important")), clearTimeout(Nt.current), Nt.current = void 0, Nt.current = setTimeout(() => {
                        $t.current === "" ? G.style.removeProperty("opacity") : G.style.setProperty("opacity", $t.current), Nt.current = void 0
                    }, 55))
                },
                Z = ke => {
                    if (!Dt.current) {
                        let {
                            dismissKeyboard: G
                        } = St({
                            nativeEvent: ke,
                            defaultBehavior: {
                                dismissKeyboard: !1
                            },
                            handler: h
                        });
                        G && !Dt.current && !Ye.current && ra() && P.focus({
                            preventScroll: !0
                        })
                    }
                    clearTimeout(un.current), un.current = setTimeout(() => {
                        Dt.current = !1, Me(!1), "onscrollend" in window || oe(null)
                    }, 90), Dt.current = !0, Me(!0)
                };
            return P.addEventListener("scroll", Z), "onscrollend" in window && P.addEventListener("scrollend", oe), () => {
                P.removeEventListener("scroll", Z), "onscrollend" in window && P.removeEventListener("scrollend", oe)
            }
        }, [v, h]), a.useEffect(() => (C && K.addNativeFocusScrollPreventer(re), () => {
            C && K.removeNativeFocusScrollPreventer(re)
        }), [C, re]);
        let nt = a.useMemo(() => u && !ae, [ae, u]),
            We = a.useMemo(() => o === "y" ? nt ? () => window.scrollY : () => {
                var P;
                return (P = Q.current) === null || P === void 0 ? void 0 : P.scrollTop
            } : nt ? () => window.scrollX : () => {
                var P;
                return (P = Q.current) === null || P === void 0 ? void 0 : P.scrollLeft
            }, [o, nt]),
            kt = a.useMemo(() => o === "y" ? nt ? () => document.body.scrollHeight - window.innerHeight : () => {
                let P = Q.current;
                return (P == null ? void 0 : P.scrollHeight) - (P == null ? void 0 : P.offsetHeight)
            } : nt ? () => document.body.scrollWidth - window.innerWidth : () => {
                let P = Q.current;
                return (P == null ? void 0 : P.scrollWidth) - (P == null ? void 0 : P.offsetWidth)
            }, [o, nt]),
            Kt = a.useCallback(() => We() / kt(), [We, kt]),
            qt = a.useCallback(P => {
                k == null || k({
                    progress: Kt(),
                    distance: We(),
                    availableDistance: kt(),
                    nativeEvent: P
                })
            }, [Kt, We, kt, k]);
        a.useEffect(() => (nt && k && document.addEventListener("scroll", qt), () => {
            nt && k && document.removeEventListener("scroll", qt)
        }), [nt, k, qt]);
        let Oe = a.useCallback((P, {
                progress: oe,
                distance: Z,
                animationSettings: ke = {
                    skip: "default"
                }
            }) => {
                let G = Z != null ? Z : (oe != null ? oe : NaN) * kt();
                if (isNaN(G)) return;
                let ve = ke == null ? void 0 : ke.skip,
                    ye = nt ? window : Q.current;
                ye == null || ye[P === "to" ? "scrollTo" : "scrollBy"]({
                    [o === "y" ? "top" : "left"]: G,
                    behavior: ve === !0 ? "instant" : ve === !1 ? "smooth" : ve === "default" ? "auto" : Ba ? "instant" : "smooth"
                })
            }, [o, kt, nt]),
            cn = a.useCallback(P => Oe("to", P), [Oe]),
            Ct = a.useCallback(P => Oe("by", P), [Oe]);
        a.useEffect(() => {
            ge.current = cn, Be.current = Ct
        }, [Ct, Be, cn, ge]), a.useImperativeHandle(xe, () => ({
            getProgress: Kt,
            getDistance: We,
            getAvailableDistance: kt,
            scrollTo: cn,
            scrollBy: Ct
        }), [kt, We, Kt, cn, Ct]);
        let Lt = a.useRef(!1),
            En = a.useRef(),
            dn = a.useRef(),
            at = a.useRef(0),
            Mt = a.useRef(0),
            Ye = a.useRef(!1),
            z = a.useCallback(({
                scrollIntoPlace: P = !0,
                scrollBehavior: oe,
                safeViewport: Z = "visual-viewport"
            }) => {
                let ke, G;
                if (!Q.current || !ze.current || !mt.current || !Je.current || o !== "y" || Z === "none" || de != null && de.current && me().top === null || !(de != null && de.current) && me) return;
                if (de != null && de.current) {
                    let {
                        top: st,
                        bottom: Ke
                    } = Pa(Q.current), ut = de.current.getBoundingClientRect(), Y = ut.top, Bt = ut.bottom;
                    ke = me().top + (st - Y), G = me().bottom - (Bt - Ke)
                } else {
                    let {
                        top: st,
                        bottom: Ke
                    } = Pa(Q.current);
                    ke = st, G = Ke
                }
                let {
                    top: ve,
                    bottom: ye
                } = Ml(), ot = Math.min(G, Z === "visual-viewport" ? ye : window.innerHeight), rt = ci(ke, Z === "visual-viewport" ? ve : 0), Ft = di(G, Z === "visual-viewport" ? ye : window.innerHeight);
                if (1 > Math.abs(at.current - rt) && 1 > Math.abs(Mt.current - Ft)) return;
                let Jt = -1 * (ot - mt.current.getBoundingClientRect().top),
                    Zt = Q.current.offsetHeight - ze.current.offsetHeight >= 0,
                    Qt = () => {
                        _l(Je.current, rt, at), _l(mt.current, Ft, Mt)
                    };
                if (oe === "smooth" && (Jt < 0 || Zt) ? P && (Ye.current = !0, Zt ? Q.current.scrollTo({
                        top: 0,
                        behavior: oe
                    }) : Q.current.scrollBy({
                        top: Jt,
                        behavior: oe
                    }), Mt.current = Ft, ui(Q.current, () => {
                        Q.current && Zt && Q.current.scrollTo({
                            top: 0,
                            behavior: "instant"
                        }), Qt()
                    })) : Qt(), !P) return {
                    spacersHeightSetter: Qt,
                    verticalScrollOffsetRequired: Jt
                }
            }, [o, me, de]),
            Ae = a.useCallback(() => z({
                scrollBehavior: Ra,
                safeViewport: p
            }), [p, z]);
        De(() => {
            Ae()
        }, [Ae]), a.useEffect(() => {
            let P = Q.current,
                oe = G => {
                    clearTimeout(En.current), clearTimeout(dn.current);
                    let ve = G.target;
                    if (ve === P) return;
                    let {
                        scrollIntoView: ye
                    } = St({
                        nativeEvent: G,
                        defaultBehavior: {
                            scrollIntoView: !0
                        },
                        handler: b
                    });
                    if (!ln(ve) || Ia(ve)) return;
                    let ot = ve.getBoundingClientRect().top - 0,
                        rt = ve.getBoundingClientRect().bottom - 0,
                        {
                            top: Ft,
                            bottom: Jt
                        } = Pa(Q.current),
                        Zt = Ft - 0,
                        Qt = Jt - 0,
                        st = () => {
                            if (clearTimeout(En.current), clearTimeout(dn.current), !ra()) return;
                            Lt.current = !0;
                            let {
                                top: Ke,
                                bottom: ut
                            } = Ml(), {
                                spacersHeightSetter: Y = () => {}
                            } = z({
                                scrollIntoPlace: !1,
                                scrollBehavior: "smooth",
                                safeViewport: p
                            }) || {};
                            Y(), ye && mi({
                                scrollContainer: Q.current,
                                behavior: Ra,
                                scrollMarginTop: 64,
                                scrollMarginBottom: oi,
                                elementTop: ot,
                                elementBottom: rt,
                                scrollPortTop: Zt,
                                scrollPortBottom: Qt,
                                visualViewportTop: Ke,
                                visualViewportBottom: ut,
                                beforeScrollCallback: () => Ye.current = !0
                            }), visualViewport.removeEventListener("resize", st)
                        };
                    Lt.current ? (st(), visualViewport.addEventListener("resize", st), En.current = setTimeout(() => {
                        visualViewport.removeEventListener("resize", st)
                    }, 900)) : (visualViewport.addEventListener("resize", st), dn.current = setTimeout(() => {
                        visualViewport.removeEventListener("resize", st), st()
                    }, 900))
                },
                Z = G => {
                    let ve = G.target;
                    !ln(ve) || Ia(ve) || ln(G.relatedTarget) || (Lt.current = !1, z({
                        scrollBehavior: Ra,
                        safeViewport: p === "none" ? "none" : "layout-viewport"
                    }))
                },
                ke = () => {
                    var G;
                    (G = Q.current) === null || G === void 0 || G.removeEventListener("scroll", Ae), setTimeout(() => {
                        Ae(), setTimeout(() => {
                            var ve;
                            (ve = Q.current) === null || ve === void 0 || ve.addEventListener("scroll", Ae, {
                                once: !0
                            })
                        }, 200)
                    }, 1), setTimeout(() => Ae, 350)
                };
            return P == null || P.addEventListener("focus", oe, {
                capture: !0
            }), P == null || P.addEventListener("blur", Z, {
                capture: !0
            }), visualViewport.addEventListener("resize", ke), P == null || P.addEventListener("scroll", Ae, {
                once: !0
            }), () => {
                P == null || P.removeEventListener("focus", oe, {
                    capture: !0
                }), P == null || P.removeEventListener("blur", Z, {
                    capture: !0
                }), visualViewport.removeEventListener("resize", ke), P == null || P.removeEventListener("scroll", Ae)
            }
        }, [b, p, z, Ae]);
        let pa = Ul(Q),
            Tt = a.useMemo(() => u && !ae, [ae, u]),
            lt = Xe("Scroll", {
                axis: o,
                scrollTrapX: It,
                scrollTrapY: !he && Tn || pa && !Tt,
                scrollGestureOvershoot: d,
                scrollDisabled: vt,
                pageScroll: u,
                nativePageScrollReplacement: c,
                overflowX: Pe,
                overflowY: we,
                skipScrollAnimation: A == null ? void 0 : A.skip,
                scrollAnchoring: x,
                scrollSnapType: ne,
                nativeScrollbar: q,
                scrollOngoing: Ee
            });
        return I.jsxs(ma.Provider, {
            value: {
                contentRef: ze,
                axis: o,
                styleAttributes: lt,
                nativeFocusScrollPrevention: C,
                swipeTrapIncapable: Tt,
                focusable: w,
                pageScroll: u,
                nativePageScrollReplacement: c,
                scrollContainerRef: Q,
                swipeTrapObserverRequired: te,
                startScrollSpyRef: Le,
                endScrollSpyRef: Fe,
                startSpacerRef: Je,
                endSpacerRef: mt,
                scrollHandler: qt,
                scrollPadding: X,
                scrollTimelineName: N
            },
            children: [u && c !== !0 && I.jsx("style", {
                dangerouslySetInnerHTML: {
                    __html: '\n                            html[data-silk-native-page-scroll-replaced="false"] > body {\n                                scroll-padding: '.concat(X, ";\n                                scroll-timeline-axis: ").concat(N, " ").concat(o, ";\n                            }\n                        ")
                }
            }), u && c === !0 && I.jsx("script", {
                id: "silk-scroll-nativePageScrollReplacement-true",
                dangerouslySetInnerHTML: {
                    __html: '\n                            document.documentElement.setAttribute("data-silk-native-page-scroll-replaced", "true");\n                        '
                }
            }), u && c === !1 && I.jsx("script", {
                id: "silk-scroll-nativePageScrollReplacement-false",
                dangerouslySetInnerHTML: {
                    __html: '\n                            document.documentElement.setAttribute("data-silk-native-page-scroll-replaced", "false");\n                        '
                }
            }), u && c === "auto" && I.jsx("script", {
                id: "silk-scroll-nativePageScrollReplacement-auto",
                dangerouslySetInnerHTML: {
                    __html: '\n                            const standalone =\n                                window.matchMedia(\'(display-mode: standalone)\').matches || window.navigator.standalone;\n                            const mobile = window.navigator.userAgent?.match(/android|iPhone|iPad/i);\n\n                            document.documentElement.setAttribute("data-standalone", !!standalone);\n                            document.documentElement.setAttribute("data-silk-native-page-scroll-replaced", !(mobile && !standalone));\n                        '
                }
            }), I.jsx(wr, {}), I.jsx(H, M(y(y({}, lt("view", ["axis", "pageScroll", "skipScrollAnimation", "scrollOngoing"], {
                className: i,
                dataSilk: [r]
            })), O), {
                ref: Ne,
                children: l
            }))]
        })
    });
Ar.displayName = "Scroll.View";
let Fa = ie.forwardRef((l, n) => {
    var i = l,
        {
            side: e
        } = i,
        t = ue(i, ["side"]);
    let {
        axis: r
    } = a.useContext(ma) || {}, s = Xe("Scroll", {
        side: e,
        axis: r
    });
    return I.jsx("div", y(M(y({}, s("spy", ["side", "axis"])), {
        ref: n
    }), t))
});
Fa.displayName = "Scroll.Anonymous";
let xr = ie.forwardRef((e, t) => {
    let O = e,
        {
            asChild: n,
            className: l,
            "data-silk": i
        } = O,
        r = ue(O, ["asChild", "className", "data-silk"]),
        s = n ? He : "div",
        {
            contentRef: o,
            styleAttributes: u,
            nativeFocusScrollPrevention: c,
            swipeTrapIncapable: p,
            focusable: m,
            axis: d,
            pageScroll: f,
            nativePageScrollReplacement: h,
            scrollContainerRef: k,
            swipeTrapObserverRequired: v,
            startScrollSpyRef: b,
            endScrollSpyRef: C,
            startSpacerRef: A,
            endSpacerRef: x,
            scrollHandler: B,
            scrollPadding: X,
            scrollTimelineName: N
        } = a.useContext(ma) || {},
        q = et(o, t);
    return I.jsxs("div", M(y({}, u("scrollContainer", ["axis", "pageScroll", "scrollTrapX", "scrollTrapY", "scrollGestureOvershoot", "scrollDisabled", "overflowX", "overflowY", "skipScrollAnimation", "scrollAnchoring", "scrollSnapType", "nativeScrollbar"], {
        dataSilk: [i, "0ad", c && "0ah", p && "0ai"]
    })), {
        style: {
            scrollPadding: X,
            scrollTimeline: N + " " + d
        },
        tabIndex: m ? 0 : c ? -1 : void 0,
        role: f && !h ? void 0 : "region",
        onScroll: B,
        ref: k,
        children: [v && I.jsx(Fa, {
            side: "start",
            ref: b
        }), d === "y" && I.jsx("div", y({
            ref: A
        }, u("startSpacer", ["axis", "pageScroll"]))), I.jsx(s, M(y(y({}, u("content", ["axis", "scrollTrapX", "scrollTrapY", "overflowX", "overflowY"], {
            className: l,
            dataSilk: [i]
        })), r), {
            ref: q
        })), d === "y" && I.jsx("div", y({
            ref: x
        }, u("endSpacer", ["axis", "pageScroll"]))), v && I.jsx(Fa, {
            side: "end",
            ref: C
        })]
    }))
});
xr.displayName = "Scroll.Content";
let Or = ie.forwardRef((l, n) => {
    var i = l,
        {
            asChild: e
        } = i,
        t = ue(i, ["asChild"]);
    let r = e ? He : "button",
        C = t,
        {
            forComponent: s,
            onPress: o,
            onClick: u,
            children: c,
            action: p
        } = C,
        m = ue(C, ["forComponent", "onPress", "onClick", "children", "action"]),
        A = p || {},
        {
            type: d
        } = A,
        f = ue(A, ["type"]),
        {
            scrollTo: h,
            scrollBy: k
        } = Tr(s),
        v = a.useRef(null),
        b = et(v, n);
    return I.jsx(r, M(y({
        onClick: x => {
            var B;
            let {
                forceFocus: X,
                runAction: N
            } = St({
                nativeEvent: x,
                defaultBehavior: {
                    forceFocus: !0,
                    runAction: !0
                },
                handler: o
            });
            if (X && ((B = v.current) === null || B === void 0 || B.focus({
                    preventScroll: !0
                })), N) {
                if (d === "scroll-to") return h(f);
                if (d === "scroll-by") return k(f)
            }
            u == null || u(x)
        },
        ref: b
    }, m), {
        children: c
    }))
});
Or.displayName = "Sheet.Trigger";
let bi = {
        Root: Er,
        Trigger: Or,
        View: Ar,
        Content: xr
    },
    pi = e => a.useContext(e != null ? e : zt) || {},
    Rr = ie.forwardRef((e, t) => {
        let A = e,
            {
                asChild: n,
                className: l,
                "data-silk": i,
                timing: r,
                forComponent: s,
                tabIndex: o
            } = A,
            u = ue(A, ["asChild", "className", "data-silk", "timing", "forComponent", "tabIndex"]),
            c = n ? He : "div",
            {
                sheetId: p
            } = s ? pi(s) : {},
            m = p != null ? p : "any",
            d = a.useCallback(x => {
                K.addAutoFocusTarget({
                    layerId: m,
                    element: x,
                    timing: r
                })
            }, [m, r]),
            f = a.useCallback(x => {
                K.removeAutoFocusTarget(x)
            }, []),
            h = a.useRef(null),
            k = a.useCallback(x => {
                x ? d(x) : f(h.current), h.current = x
            }, [d, f]),
            v = a.useRef(!0);
        a.useEffect(() => (h.current && !v.current && d(h.current), v.current = !1, () => {
            h.current && f(h.current)
        }), [d, f]);
        let b = et(k, t),
            C = Xe("AutoFocusTarget", {});
        return I.jsx(c, M(y(y(y({}, C("root", [], {
            className: l,
            dataSilk: [i]
        })), n || Number.isInteger(o) ? {} : {
            tabIndex: -1
        }), u), {
            ref: b
        }))
    });
Rr.displayName = "AutoFocusTarget.Root";
let Si = {
        Root: Rr
    },
    Pr = ie.forwardRef((e, t) => {
        let m = e,
            {
                asChild: n,
                disabled: l = !1,
                children: i,
                contentGetter: r,
                forComponent: s
            } = m,
            o = ue(m, ["asChild", "disabled", "children", "contentGetter", "forComponent"]),
            u = a.useRef(null),
            c = et(u, t),
            p = a.useMemo(() => !!i, [i]);
        return a.useEffect(() => {
            let d, f;
            if (!l) {
                let h, k = !1;
                if (p && u.current ? h = u.current : r && (h = la(r)) && (k = !0), h) {
                    let v = Array.isArray(s) ? s : s ? [s] : [];
                    d = K.addIsland({
                        componentId: v,
                        element: h
                    }), k && (f = new MutationObserver(() => {
                        la(r) || (K.removeIsland(d), f.disconnect())
                    })).observe(h.parentElement, {
                        childList: !0
                    })
                }
            }
            return () => {
                l || (K.removeIsland(d), f == null || f.disconnect())
            }
        }, [t, l, p, r, s]), i ? I.jsx(Pt.Root, M(y({
            active: !l,
            asChild: n,
            "data-silk": "0ag"
        }, o), {
            ref: c,
            children: i
        })) : null
    });
Pr.displayName = "Island.Root";
let Ir = ie.forwardRef((e, t) => {
    let r = e,
        {
            asChild: n,
            children: l
        } = r,
        i = ue(r, ["asChild", "children"]);
    return I.jsx(Pt.Stabiliser, M(y({
        asChild: n
    }, i), {
        ref: t,
        children: l
    }))
});
Ir.displayName = "Island.Content";
let yi = {
        Root: Pr,
        Content: Ir
    },
    Dr = ie.forwardRef((o, s) => {
        var u = o,
            {
                asChild: e,
                children: t,
                contentGetter: n,
                disabled: l = !1,
                selfManagedInertOutside: i = !0
            } = u,
            r = ue(u, ["asChild", "children", "contentGetter", "disabled", "selfManagedInertOutside"]);
        let c = sn(),
            p = a.useRef(null),
            m = et(p, s),
            d = e ? He : "div",
            f = a.useMemo(() => !!t, [t]);
        return De(() => {
            let h;
            if (!l && c) {
                let k, v = !1;
                f && p.current ? k = p.current : n && (k = la(n)) && (v = !0), k && (K.updateLayer({
                    external: !0,
                    layerId: c,
                    viewElement: k,
                    inertOutside: i,
                    onPresentAutoFocus: {
                        focus: !1
                    },
                    onDismissAutoFocus: {
                        focus: !1
                    },
                    defaultClickOutsideAction: () => {},
                    defaultEscapeKeyDownAction: () => {}
                }), v && (h = new MutationObserver(() => {
                    la(n) || (K.removeLayer(c), h.disconnect())
                })).observe(k.parentElement, {
                    childList: !0
                }))
            }
            return () => {
                !l && c && (K.removeLayer(c), h == null || h.disconnect())
            }
        }, [f, n, l, c, i]), I.jsx(d, M(y({
            ref: m
        }, r), {
            children: t
        }))
    });
Dr.displayName = "ExternalOverlay.Root";
let Ci = {
        Root: Dr
    },
    Ti = () => {
        let e = ie.createContext(null);
        return e.displayName = "ComponentIdContext", e
    },
    Ei = e => {
        let [t, n] = a.useState(typeof window < "u" && window.matchMedia(e).matches);
        return a.useEffect(() => {
            let l = window.matchMedia(e),
                i = r => {
                    n(r.matches)
                };
            return l.addEventListener("change", i), () => l.removeEventListener("change", i)
        }, [e]), t
    },
    wi = e => {
        K.updateUnderlyingThemeColor(e)
    },
    Ai = ({
        elementRef: e,
        dimmingColor: t
    }) => {
        let n = a.useId(),
            l = a.useRef(0),
            [i, r] = a.useState(null),
            [s, o] = a.useState(!1),
            u = yl(p => {
                var m;
                s && K.updateThemeColorDimmingOverlayAlphaValue(i, p), e == null || (m = e.current) === null || m === void 0 || m.style.setProperty("opacity", p), l.current = p
            }),
            c = yl(({
                keyframes: p,
                duration: m = 500,
                easing: d = "cubic-bezier(0.25, 0.1, 0.25, 1)"
            }) => {
                let f, [h, k] = p,
                    v = C => h + (k - h) * C;
                f = s ? C => {
                    var A;
                    let x = v(C);
                    K.updateThemeColorDimmingOverlayAlphaValue(i, x), e == null || (A = e.current) === null || A === void 0 || A.style.setProperty("opacity", x)
                } : C => {
                    var A;
                    let x = v(C);
                    e == null || (A = e.current) === null || A === void 0 || A.style.setProperty("opacity", x)
                };
                let b = ir(d);
                vs(f, {
                    duration: m,
                    cubicBezier: b
                })
            });
        return De(() => {
            let p = !!(Rt() && !Xl() && K.getAndStoreUnderlyingThemeColorAsRGBArray());
            if (o(p), !p) return;
            let m = K.updateThemeColorDimmingOverlay({
                abortRemoval: !0,
                dimmingOverlayId: n,
                color: t,
                alpha: l.current
            });
            return r(m), () => {
                p && K.removeThemeColorDimmingOverlay(n)
            }
        }, [t, n]), {
            setDimmingOverlayOpacity: u,
            animateDimmingOverlayOpacity: c
        }
    },
    xi = () => {
        let [e, t] = a.useState(Mn);
        return a.useEffect(() => {
            t(Mn);
            let n = () => {
                t(Mn)
            };
            return document.addEventListener("silk-page-scroll-data-change", n), () => document.removeEventListener("silk-page-scroll-data-change", n)
        }, []), e
    },
    Oi = (e, t, n) => {
        if (!e || !t) return;
        let {
            duration: l = 500,
            easing: i = "cubic-bezier(0.25, 0.1, 0.25, 1)"
        } = n || {}, r = e.animate(t, {
            duration: l,
            easing: i,
            fill: "forwards"
        });
        r.onfinish = () => {
            r.commitStyles(), r.cancel()
        }
    };
export {
    Si as AutoFocusTarget, Ci as ExternalOverlay, hi as Fixed, yi as Island, bi as Scroll, vi as Sheet, ki as SheetStack, li as VisuallyHidden, Oi as animate, Ti as createComponentId, wi as updateThemeColor, Ei as useClientMediaQuery, xi as usePageScrollData, Ai as useThemeColorDimmingOverlay
};
//# sourceMappingURL=csyhgpw8szcoz725.js.map