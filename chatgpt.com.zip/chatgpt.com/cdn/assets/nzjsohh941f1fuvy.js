var c = Object.defineProperty,
    l = Object.defineProperties;
var u = Object.getOwnPropertyDescriptors;
var r = Object.getOwnPropertySymbols;
var d = Object.prototype.hasOwnProperty,
    f = Object.prototype.propertyIsEnumerable;
var p = (e, n, t) => n in e ? c(e, n, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : e[n] = t,
    o = (e, n) => {
        for (var t in n || (n = {})) d.call(n, t) && p(e, t, n[t]);
        if (r)
            for (var t of r(n)) f.call(n, t) && p(e, t, n[t]);
        return e
    },
    a = (e, n) => l(e, u(n));
import {
    c as S
} from "./fg33krlcm0qyi6yw.js";
import {
    de as M
} from "./dykg4ktvbu3mhmdo.js";
const i = M(() => ({
        isOpen: !1,
        focusedWalnutId: null,
        presentationMap: {},
        walnutReaderPromise: null
    })),
    W = e => {
        i.setState({
            isOpen: !0,
            focusedWalnutId: e
        })
    },
    m = () => {
        i.setState({
            isOpen: !1
        })
    },
    I = () => {
        i.setState({
            isOpen: !1,
            focusedWalnutId: null,
            presentationMap: {},
            walnutReaderPromise: null
        })
    },
    x = (e, n) => {
        i.setState(t => {
            const s = t.presentationMap[e];
            return s ? (s.selectedSlideIdx = typeof n == "function" ? n(s.selectedSlideIdx) : n, a(o({}, t), {
                presentationMap: a(o({}, t.presentationMap), {
                    [e]: s
                })
            })) : t
        })
    },
    O = (e, n) => {
        i.setState(t => a(o({}, t), {
            presentationMap: a(o({}, t.presentationMap), {
                [e]: n
            })
        }))
    },
    h = (e, n) => {
        i.setState(t => {
            const s = t.presentationMap[e];
            return s ? (s.selectedSheetIdx = typeof n == "function" ? n(s.selectedSheetIdx) : n, a(o({}, t), {
                presentationMap: a(o({}, t.presentationMap), {
                    [e]: s
                })
            })) : t
        })
    };

function b() {
    "use forget";
    const e = S.c(2),
        n = i(P);
    let t;
    return e[0] !== n ? (t = a(o({}, n), {
        open: W,
        close: m,
        reset: I,
        setSelectedSlideIdx: x,
        setSelectedSheetIdx: h,
        updatePresentationMap: O
    }), e[0] = n, e[1] = t) : t = e[1], t
}

function P(e) {
    return {
        isOpen: e.isOpen,
        focusedWalnutId: e.focusedWalnutId,
        presentationMap: e.presentationMap
    }
}
export {
    I as r, b as u
};
//# sourceMappingURL=nzjsohh941f1fuvy.js.map