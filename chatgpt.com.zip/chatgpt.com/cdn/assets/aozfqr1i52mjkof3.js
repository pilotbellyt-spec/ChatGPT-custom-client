import {
    c as e,
    s as o
} from "./dykg4ktvbu3mhmdo.js";
const r = e(o, "863841", 20, 20);
export {
    r as P
};
//# sourceMappingURL=aozfqr1i52mjkof3.js.map