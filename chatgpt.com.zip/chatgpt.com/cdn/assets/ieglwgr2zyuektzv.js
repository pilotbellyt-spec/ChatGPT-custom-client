import {
    u as n
} from "./f2sn8zvpzei2915e.js";

function u() {
    var o = n(),
        t = o.scrollToBottom;
    return t
}
export {
    u
};
//# sourceMappingURL=ieglwgr2zyuektzv.js.map