import {
    j as t,
    M as H,
    c as Ie,
    e as _e
} from "./fg33krlcm0qyi6yw.js";
import {
    iZ as Pe,
    fx as K,
    i_ as Be,
    i$ as He,
    j0 as Oe,
    j1 as Ve,
    j2 as ze,
    j3 as Ke,
    er as Ue
} from "./k15yxxoybkkir2ou.js";
import {
    id as $e,
    l as O,
    gK as Je,
    g2 as X,
    gJ as Ge,
    _ as Ye,
    P as Ze,
    d as qe,
    gm as be,
    b as Fe,
    dJ as ge,
    bv as Ne,
    bg as Me,
    p7 as Xe
} from "./dykg4ktvbu3mhmdo.js";
import {
    C as Qe
} from "./tjmll0bdtco26rsw.js";
import {
    L as We
} from "./jnh7gh80gtj0452q.js";
const et = ({
        conversation: f,
        isExpanded: e,
        agentVisualMode: d,
        setAgentVisualMode: o,
        isStreaming: x,
        isStopping: m,
        isKAUR1BR5: l
    }) => {
        const p = e || x,
            r = $e(),
            {
                open: u
            } = Pe(),
            c = l == !0 && !x || r;
        return t.jsxs("div", {
            className: O("flex flex-1 flex-row items-center gap-2 px-1", x ? "justify-end" : "justify-between"),
            children: [!x && t.jsx(K, {
                className: O("icon-sm text-token-text-secondary inline align-middle transition-transform", e && "rotate-90")
            }), !m && p && t.jsx("div", {
                className: "flex flex-row items-center justify-center gap-2",
                children: t.jsxs(Je, {
                    side: "bottom",
                    size: "small",
                    contentClassName: "text-sm",
                    triggerButton: t.jsx("button", {
                        onPointerDown: i => i.stopPropagation(),
                        onClick: i => i.stopPropagation(),
                        className: "hover:bg-token-bg-tertiary flex max-h-6 items-center justify-center overflow-visible rounded-md p-1",
                        children: t.jsx(Ge, {
                            className: "text-token-text-secondary size-5"
                        })
                    }),
                    children: [d === "visual-cot" && t.jsxs(X.Item, {
                        onClick: i => {
                            i.stopPropagation(), o == null || o("list-cot"), Ee("list-cot")
                        },
                        children: [t.jsx(Be, {
                            className: "icon"
                        }), t.jsx(H, {
                            id: "cot.listView",
                            defaultMessage: "Activity"
                        })]
                    }), d === "list-cot" && t.jsxs(X.Item, {
                        onClick: i => {
                            i.stopPropagation(), o == null || o("visual-cot"), Ee("visual-cot")
                        },
                        children: [t.jsx(We, {
                            className: "icon"
                        }), t.jsx(H, {
                            id: "cot.desktopView",
                            defaultMessage: "Desktop view"
                        })]
                    }), !c && t.jsxs(X.Item, {
                        onClick: i => {
                            i.stopPropagation(), u()
                        },
                        children: [t.jsx(He, {
                            className: "icon"
                        }), l ? t.jsx(H, {
                            id: "qMkIYk",
                            defaultMessage: "Open tabs"
                        }) : t.jsx(H, {
                            id: "cot.takeOverBrowser",
                            defaultMessage: "Take over browser"
                        })]
                    }), !r && x && t.jsxs(X.Item, {
                        onClick: () => Oe(f.id, void 0, {
                            clientInitiated: !0,
                            reason: "agent_cot_stop",
                            isLastTurnAgent: !0
                        }),
                        children: [t.jsx(Ve, {
                            className: "icon"
                        }), t.jsx(H, {
                            id: "cot.stop",
                            defaultMessage: "Stop"
                        })]
                    })]
                })
            })]
        })
    },
    Ee = f => {
        Ye.addAction("agent.cot_view_change", {
            cot_view: f
        }), Ze.logEvent("Agent CoT View Change", {
            cot_view: f
        })
    },
    ct = f => {
        "use forget";
        var Te;
        const e = Ie.c(80),
            {
                conversation: d,
                isExpanded: o,
                isExpandDisabled: x,
                showChunkIcon: m,
                isComplete: l,
                latestHeadline: p,
                latestChunk: r,
                onToggleExpanded: u,
                onSkip: c,
                shouldDisplayVisualCoT: i,
                agentVisualMode: g,
                setAgentVisualMode: h,
                isStreaming: j,
                interruptionInProgress: Q,
                isAgentVisualCoT: he,
                isKAUR1BR5: je,
                wasInterrupted: ve,
                isAgentTurn: Ae,
                isGlauxTurn: ke,
                taskType: U,
                activeTask: ye,
                showTitle: Ce,
                title: $,
                isTitleClickable: we,
                onTitleClick: Re
            } = f,
            k = o === void 0 ? !1 : o,
            y = x === void 0 ? !1 : x,
            W = m === void 0 ? !0 : m,
            V = i === void 0 ? !1 : i,
            J = he === void 0 ? !1 : he,
            ee = je === void 0 ? !1 : je,
            Se = ve === void 0 ? !1 : ve,
            De = Ce === void 0 ? !1 : Ce,
            z = we === void 0 ? !1 : we,
            a = _e(),
            te = Fe(),
            se = qe(st);
        let G;
        e[0] !== a || e[1] !== se || e[2] !== U ? (G = se ? U === be.PRO_MODE ? a.formatMessage({
            id: "wOEgCa",
            defaultMessage: "Pro thinking"
        }) : U === be.RESEARCH ? a.formatMessage({
            id: "oNdsTH",
            defaultMessage: "Researching"
        }) : void 0 : void 0, e[0] = a, e[1] = se, e[2] = U, e[3] = G) : G = e[3];
        const v = G;
        let n;
        if (p && p.length > 0) n = p;
        else if (l)
            if (Se) {
                let s;
                e[4] !== a ? (s = a.formatMessage({
                    id: "tD55er",
                    defaultMessage: "Stopped thinking"
                }), e[4] = a, e[5] = s) : s = e[5], n = s
            } else {
                let s;
                e[6] !== a ? (s = a.formatMessage({
                    id: "nkvZJE",
                    defaultMessage: "Thought"
                }), e[6] = a, e[7] = s) : s = e[7], n = s
            }
        else if (ke) {
            let s;
            e[8] !== a ? (s = a.formatMessage({
                id: "4XsLlK",
                defaultMessage: "Searching internal apps"
            }), e[8] = a, e[9] = s) : s = e[9], n = s
        } else if (ye && v) n = ye.title;
        else {
            let s;
            e[10] !== a ? (s = a.formatMessage({
                id: "hgnsat",
                defaultMessage: "Thinking"
            }), e[10] = a, e[11] = s) : s = e[11], n = s
        }
        const ie = !!Ae;
        let Y;
        e[12] !== te || e[13] !== ie ? (Y = ze(te, ie), e[12] = te, e[13] = ie, e[14] = Y) : Y = e[14];
        const C = Y,
            ae = (Te = Ke(d.id)) == null ? void 0 : Te.value,
            ne = !(ae == ge.REALTIME || ae == ge.REALTIME_BACKGROUND || ae == ge.REALTIME_BUSY) && !l && (!k || C && k) && c && !ke;
        let oe;
        e: {
            if (y) {
                oe = !1;
                break e
            }
            oe = C && !J && u
        }
        const le = oe,
            re = z ? Re : u,
            ce = z ? !1 : y,
            de = De && $,
            xe = (k || j) && V && "justify-between";
        let w;
        e[15] !== xe ? (w = O("flex min-w-0 shrink-1 items-center gap-0.5", xe), e[15] = xe, e[16] = w) : w = e[16];
        const pe = !l && "loading-shimmer",
            fe = !v && "font-medium";
        let T;
        e[17] !== pe || e[18] !== fe ? (T = O(pe, fe, "w-full"), e[17] = pe, e[18] = fe, e[19] = T) : T = e[19];
        const Le = n,
            me = v && j && "text-token-text-tertiary",
            ue = l && (y ? "text-token-text-secondary dark:text-[var(--interactive-label-tertiary-default)]" : "text-token-text-secondary hover:text-token-text-primary dark:hover:text-token-text-primary dark:text-[var(--interactive-label-tertiary-default)]");
        let b;
        e[20] !== me || e[21] !== ue ? (b = O("flex items-center gap-1 truncate text-start align-middle", me, ue), e[20] = me, e[21] = ue, e[22] = b) : b = e[22];
        let Z, q;
        e[23] === Symbol.for("react.memo_cache_sentinel") ? (Z = {
            opacity: 1
        }, q = {
            type: "spring",
            duration: .3
        }, e[23] = Z, e[24] = q) : (Z = e[23], q = e[24]);
        let N;
        e[25] !== l || e[26] !== r || e[27] !== W ? (N = W && (r == null ? void 0 : r.type) !== Ue.Recap && t.jsx(Qe, {
            chunk: r,
            isAnimated: !l,
            size: "medium",
            className: "text-token-text-tertiary",
            isHeadline: !0
        }), e[25] = l, e[26] = r, e[27] = W, e[28] = N) : N = e[28];
        let M;
        e[29] !== n || e[30] !== j || e[31] !== v ? (M = v && j && t.jsxs("span", {
            className: "text-token-text-primary font-medium",
            children: [v, n.length > 0 ? " • " : ""]
        }), e[29] = n, e[30] = j, e[31] = v, e[32] = M) : M = e[32];
        let E;
        e[33] !== z || e[34] !== de || e[35] !== $ ? (E = de && t.jsxs("span", {
            className: "inline-flex items-center gap-1",
            children: [t.jsx("span", {
                "aria-hidden": !0,
                className: "text-token-text-tertiary ms-1",
                children: " • "
            }), t.jsx("span", {
                className: "text-token-text-tertiary",
                children: $
            }), z && t.jsx(K, {
                className: "icon-xs text-token-text-tertiary"
            })]
        }), e[33] = z, e[34] = de, e[35] = $, e[36] = E) : E = e[36];
        let I;
        e[37] !== n || e[38] !== M || e[39] !== E ? (I = t.jsxs("span", {
            className: "min-w-0 truncate",
            children: [M, n, E]
        }), e[37] = n, e[38] = M, e[39] = E, e[40] = I) : I = e[40];
        let A;
        e[41] !== N || e[42] !== I ? (A = t.jsxs("span", {
            className: "flex min-w-0 items-center gap-1",
            children: [N, I]
        }), e[41] = N, e[42] = I, e[43] = A) : A = e[43];
        let R;
        e[44] !== le ? (R = le && t.jsx(K, {
            className: "icon-xs"
        }), e[44] = le, e[45] = R) : R = e[45];
        let S;
        e[46] !== n || e[47] !== b || e[48] !== A || e[49] !== R ? (S = t.jsx(Ne, {
            mode: "popLayout",
            children: t.jsxs(Me.span, {
                className: b,
                initial: !1,
                animate: Z,
                transition: q,
                children: [A, R]
            }, Le)
        }), e[46] = n, e[47] = b, e[48] = A, e[49] = R, e[50] = S) : S = e[50];
        let D;
        e[51] !== T || e[52] !== S ? (D = t.jsx("span", {
            className: T,
            children: S
        }), e[51] = T, e[52] = S, e[53] = D) : D = e[53];
        let L;
        e[54] !== g || e[55] !== d || e[56] !== Q || e[57] !== J || e[58] !== y || e[59] !== k || e[60] !== ee || e[61] !== j || e[62] !== h || e[63] !== V ? (L = (!y || V) && J && t.jsx(tt, {
            conversation: d,
            isExpanded: k,
            shouldDisplayVisualCoT: V,
            agentVisualMode: g,
            setAgentVisualMode: h,
            isStreaming: j,
            isStopping: !!Q,
            isKAUR1BR5: ee
        }), e[54] = g, e[55] = d, e[56] = Q, e[57] = J, e[58] = y, e[59] = k, e[60] = ee, e[61] = j, e[62] = h, e[63] = V, e[64] = L) : L = e[64];
        let _;
        e[65] !== ce || e[66] !== re || e[67] !== w || e[68] !== D || e[69] !== L ? (_ = t.jsxs("button", {
            disabled: ce,
            onClick: re,
            className: w,
            children: [D, L]
        }), e[65] = ce, e[66] = re, e[67] = w, e[68] = D, e[69] = L, e[70] = _) : _ = e[70];
        let P;
        e[71] !== C || e[72] !== c || e[73] !== ne ? (P = ne && t.jsx(Me.div, {
            initial: {
                opacity: 0
            },
            exit: {
                opacity: 0
            },
            animate: {
                opacity: 1
            },
            transition: {
                type: "spring",
                duration: .3
            },
            children: t.jsx("button", {
                onClick: s => {
                    c == null || c(s), s.stopPropagation()
                },
                className: "text-token-text-tertiary hover:text-token-text-primary whitespace-nowrap",
                children: t.jsxs("span", {
                    className: C ? "underline decoration-dotted" : "flex items-center gap-0.5",
                    children: [t.jsx(H, {
                        id: "xMM6dg",
                        defaultMessage: "Answer now"
                    }), !C && t.jsx(K, {
                        className: "icon-xs"
                    })]
                })
            })
        }), e[71] = C, e[72] = c, e[73] = ne, e[74] = P) : P = e[74];
        let B;
        e[75] !== P ? (B = t.jsx(Ne, {
            mode: "popLayout",
            children: P
        }), e[75] = P, e[76] = B) : B = e[76];
        let F;
        return e[77] !== _ || e[78] !== B ? (F = t.jsx("div", {
            className: "relative w-full text-start",
            children: t.jsxs("div", {
                className: "flex w-full flex-row items-start justify-between gap-4 text-start",
                children: [_, B]
            })
        }), e[77] = _, e[78] = B, e[79] = F) : F = e[79], F
    },
    tt = f => {
        "use forget";
        const e = Ie.c(12),
            {
                conversation: d,
                isExpanded: o,
                shouldDisplayVisualCoT: x,
                agentVisualMode: m,
                setAgentVisualMode: l,
                isStreaming: p,
                isStopping: r,
                isKAUR1BR5: u
            } = f;
        if (x) {
            let h;
            return e[0] !== m || e[1] !== d || e[2] !== o || e[3] !== u || e[4] !== r || e[5] !== p || e[6] !== l ? (h = t.jsx(et, {
                conversation: d,
                isExpanded: o,
                agentVisualMode: m,
                setAgentVisualMode: l,
                isStreaming: p,
                isStopping: r,
                isKAUR1BR5: u
            }), e[0] = m, e[1] = d, e[2] = o, e[3] = u, e[4] = r, e[5] = p, e[6] = l, e[7] = h) : h = e[7], h
        }
        const c = o && "rotate-90";
        let i;
        e[8] !== c ? (i = O("icon-sm text-token-text-secondary inline align-middle transition-transform", c), e[8] = c, e[9] = i) : i = e[9];
        let g;
        return e[10] !== i ? (g = t.jsx(K, {
            className: i
        }), e[10] = i, e[11] = g) : g = e[11], g
    };

function st() {
    return Xe()
}
export {
    ct as C
};
//# sourceMappingURL=bzqbnv68e5p19ax6.js.map