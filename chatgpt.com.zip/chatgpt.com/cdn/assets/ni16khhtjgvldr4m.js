import {
    c as t,
    s as e
} from "./dykg4ktvbu3mhmdo.js";
const r = t(e, "a88f67", 20, 20);
export {
    r as S
};
//# sourceMappingURL=ni16khhtjgvldr4m.js.map