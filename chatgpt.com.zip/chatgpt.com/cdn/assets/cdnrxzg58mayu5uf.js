import {
    E as s
} from "./fg33krlcm0qyi6yw.js";
import {
    sS as l
} from "./dykg4ktvbu3mhmdo.js";

function ie(r, e) {
    var t = Object.keys(r);
    if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(r);
        e && (n = n.filter(function(a) {
            return Object.getOwnPropertyDescriptor(r, a).enumerable
        })), t.push.apply(t, n)
    }
    return t
}

function se(r) {
    for (var e = 1; e < arguments.length; e++) {
        var t = arguments[e] != null ? arguments[e] : {};
        e % 2 ? ie(Object(t), !0).forEach(function(n) {
            ve(r, n, t[n])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(t)) : ie(Object(t)).forEach(function(n) {
            Object.defineProperty(r, n, Object.getOwnPropertyDescriptor(t, n))
        })
    }
    return r
}

function F(r) {
    "@babel/helpers - typeof";
    return typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? F = function(e) {
        return typeof e
    } : F = function(e) {
        return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    }, F(r)
}

function ve(r, e, t) {
    return e in r ? Object.defineProperty(r, e, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : r[e] = t, r
}

function Oe(r, e) {
    if (r == null) return {};
    var t = {},
        n = Object.keys(r),
        a, o;
    for (o = 0; o < n.length; o++) a = n[o], !(e.indexOf(a) >= 0) && (t[a] = r[a]);
    return t
}

function me(r, e) {
    if (r == null) return {};
    var t = Oe(r, e),
        n, a;
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(r);
        for (a = 0; a < o.length; a++) n = o[a], !(e.indexOf(n) >= 0) && Object.prototype.propertyIsEnumerable.call(r, n) && (t[n] = r[n])
    }
    return t
}

function Y(r, e) {
    return we(r) || je(r, e) || Re(r, e) || Ae()
}

function we(r) {
    if (Array.isArray(r)) return r
}

function je(r, e) {
    var t = r && (typeof Symbol < "u" && r[Symbol.iterator] || r["@@iterator"]);
    if (t != null) {
        var n = [],
            a = !0,
            o = !1,
            c, d;
        try {
            for (t = t.call(r); !(a = (c = t.next()).done) && (n.push(c.value), !(e && n.length === e)); a = !0);
        } catch (i) {
            o = !0, d = i
        } finally {
            try {
                !a && t.return != null && t.return()
            } finally {
                if (o) throw d
            }
        }
        return n
    }
}

function Re(r, e) {
    if (r) {
        if (typeof r == "string") return ue(r, e);
        var t = Object.prototype.toString.call(r).slice(8, -1);
        if (t === "Object" && r.constructor && (t = r.constructor.name), t === "Map" || t === "Set") return Array.from(r);
        if (t === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)) return ue(r, e)
    }
}

function ue(r, e) {
    (e == null || e > r.length) && (e = r.length);
    for (var t = 0, n = new Array(e); t < e; t++) n[t] = r[t];
    return n
}

function Ae() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
}
var y = function(e, t, n) {
        var a = !!n,
            o = s.useRef(n);
        s.useEffect(function() {
            o.current = n
        }, [n]), s.useEffect(function() {
            if (!a || !e) return function() {};
            var c = function() {
                o.current && o.current.apply(o, arguments)
            };
            return e.on(t, c),
                function() {
                    e.off(t, c)
                }
        }, [a, t, e, o])
    },
    _ = function(e) {
        var t = s.useRef(e);
        return s.useEffect(function() {
            t.current = e
        }, [e]), t.current
    },
    T = function(e) {
        return e !== null && F(e) === "object"
    },
    Le = function(e) {
        return T(e) && typeof e.then == "function"
    },
    Ie = function(e) {
        return T(e) && typeof e.elements == "function" && typeof e.createToken == "function" && typeof e.createPaymentMethod == "function" && typeof e.confirmCardPayment == "function"
    },
    ce = "[object Object]",
    Q = function r(e, t) {
        if (!T(e) || !T(t)) return e === t;
        var n = Array.isArray(e),
            a = Array.isArray(t);
        if (n !== a) return !1;
        var o = Object.prototype.toString.call(e) === ce,
            c = Object.prototype.toString.call(t) === ce;
        if (o !== c) return !1;
        if (!o && !n) return e === t;
        var d = Object.keys(e),
            i = Object.keys(t);
        if (d.length !== i.length) return !1;
        for (var S = {}, C = 0; C < d.length; C += 1) S[d[C]] = !0;
        for (var E = 0; E < i.length; E += 1) S[i[E]] = !0;
        var u = Object.keys(S);
        if (u.length !== d.length) return !1;
        var A = e,
            P = t,
            g = function(b) {
                return r(A[b], P[b])
            };
        return u.every(g)
    },
    he = function(e, t, n) {
        return T(e) ? Object.keys(e).reduce(function(a, o) {
            var c = !T(t) || !Q(e[o], t[o]);
            return n.includes(o) ? (c && console.warn("Unsupported prop change: options.".concat(o, " is not a mutable property.")), a) : c ? se(se({}, a || {}), {}, ve({}, o, e[o])) : a
        }, null) : null
    },
    ye = "Invalid prop `stripe` supplied to `Elements`. We recommend using the `loadStripe` utility from `@stripe/stripe-js`. See https://stripe.com/docs/stripe-js/react#elements-props-stripe for details.",
    le = function(e) {
        var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : ye;
        if (e === null || Ie(e)) return e;
        throw new Error(t)
    },
    Se = function(e) {
        var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : ye;
        if (Le(e)) return {
            tag: "async",
            stripePromise: Promise.resolve(e).then(function(a) {
                return le(a, t)
            })
        };
        var n = le(e, t);
        return n === null ? {
            tag: "empty"
        } : {
            tag: "sync",
            stripe: n
        }
    },
    Ce = function(e) {
        !e || !e._registerWrapper || !e.registerAppInfo || (e._registerWrapper({
            name: "react-stripe-js",
            version: "3.10.0"
        }), e.registerAppInfo({
            name: "react-stripe-js",
            version: "3.10.0",
            url: "https://stripe.com/docs/stripe-js/react"
        }))
    },
    D = s.createContext(null);
D.displayName = "ElementsContext";
var ge = function(e, t) {
        if (!e) throw new Error("Could not find Elements context; You need to wrap the part of your app that ".concat(t, " in an <Elements> provider."));
        return e
    },
    _e = function(e) {
        var t = e.stripe,
            n = e.options,
            a = e.children,
            o = s.useMemo(function() {
                return Se(t)
            }, [t]),
            c = s.useState(function() {
                return {
                    stripe: o.tag === "sync" ? o.stripe : null,
                    elements: o.tag === "sync" ? o.stripe.elements(n) : null
                }
            }),
            d = Y(c, 2),
            i = d[0],
            S = d[1];
        s.useEffect(function() {
            var u = !0,
                A = function(g) {
                    S(function(O) {
                        return O.stripe ? O : {
                            stripe: g,
                            elements: g.elements(n)
                        }
                    })
                };
            return o.tag === "async" && !i.stripe ? o.stripePromise.then(function(P) {
                    P && u && A(P)
                }) : o.tag === "sync" && !i.stripe && A(o.stripe),
                function() {
                    u = !1
                }
        }, [o, i, n]);
        var C = _(t);
        s.useEffect(function() {
            C !== null && C !== t && console.warn("Unsupported prop change on Elements: You cannot change the `stripe` prop after setting it.")
        }, [C, t]);
        var E = _(n);
        return s.useEffect(function() {
            if (i.elements) {
                var u = he(n, E, ["clientSecret", "fonts"]);
                u && i.elements.update(u)
            }
        }, [n, E, i.elements]), s.useEffect(function() {
            Ce(i.stripe)
        }, [i.stripe]), s.createElement(D.Provider, {
            value: i
        }, a)
    };
_e.propTypes = {
    stripe: l.any,
    options: l.object
};
var Te = function(e) {
        var t = s.useContext(D);
        return ge(t, e)
    },
    nt = function() {
        var e = Te("calls useElements()"),
            t = e.elements;
        return t
    };
l.func.isRequired;
var Ue = ["on", "session"],
    J = s.createContext(null);
J.displayName = "CheckoutSdkContext";
var Ee = function(e, t) {
        if (!e) throw new Error("Could not find CheckoutProvider context; You need to wrap the part of your app that ".concat(t, " in an <CheckoutProvider> provider."));
        return e
    },
    te = s.createContext(null);
te.displayName = "CheckoutContext";
var Ne = function(e, t) {
        if (!e) return null;
        e.on, e.session;
        var n = me(e, Ue);
        return Object.assign(t || e.session(), n)
    },
    Me = "Invalid prop `stripe` supplied to `CheckoutProvider`. We recommend using the `loadStripe` utility from `@stripe/stripe-js`. See https://stripe.com/docs/stripe-js/react#elements-props-stripe for details.",
    We = function(e) {
        var t = e.stripe,
            n = e.options,
            a = e.children,
            o = s.useMemo(function() {
                return Se(t, Me)
            }, [t]),
            c = s.useState(null),
            d = Y(c, 2),
            i = d[0],
            S = d[1],
            C = s.useState(function() {
                return {
                    stripe: o.tag === "sync" ? o.stripe : null,
                    checkoutSdk: null
                }
            }),
            E = Y(C, 2),
            u = E[0],
            A = E[1],
            P = function(h, k) {
                A(function(j) {
                    return j.stripe && j.checkoutSdk ? j : {
                        stripe: h,
                        checkoutSdk: k
                    }
                })
            },
            g = s.useRef(!1);
        s.useEffect(function() {
            var w = !0;
            return o.tag === "async" && !u.stripe ? o.stripePromise.then(function(h) {
                    h && w && !g.current && (g.current = !0, h.initCheckout(n).then(function(k) {
                        k && (P(h, k), k.on("change", S))
                    }))
                }) : o.tag === "sync" && o.stripe && !g.current && (g.current = !0, o.stripe.initCheckout(n).then(function(h) {
                    h && (P(o.stripe, h), h.on("change", S))
                })),
                function() {
                    w = !1
                }
        }, [o, u, n, S]);
        var O = _(t);
        s.useEffect(function() {
            O !== null && O !== t && console.warn("Unsupported prop change on CheckoutProvider: You cannot change the `stripe` prop after setting it.")
        }, [O, t]);
        var b = _(n),
            M = _(u.checkoutSdk);
        s.useEffect(function() {
            var w, h, k, j;
            if (u.checkoutSdk) {
                var W = !!(!M && u.checkoutSdk),
                    K = b == null || (w = b.elementsOptions) === null || w === void 0 ? void 0 : w.appearance,
                    U = n == null || (h = n.elementsOptions) === null || h === void 0 ? void 0 : h.appearance,
                    z = !Q(U, K);
                U && (z || W) && u.checkoutSdk.changeAppearance(U);
                var I = b == null || (k = b.elementsOptions) === null || k === void 0 ? void 0 : k.fonts,
                    L = n == null || (j = n.elementsOptions) === null || j === void 0 ? void 0 : j.fonts,
                    x = !Q(I, L);
                L && (x || W) && u.checkoutSdk.loadFonts(L)
            }
        }, [n, b, u.checkoutSdk, M]), s.useEffect(function() {
            Ce(u.stripe)
        }, [u.stripe]);
        var G = s.useMemo(function() {
            return Ne(u.checkoutSdk, i)
        }, [u.checkoutSdk, i]);
        return u.checkoutSdk ? s.createElement(J.Provider, {
            value: u
        }, s.createElement(te.Provider, {
            value: G
        }, a)) : null
    };
We.propTypes = {
    stripe: l.any,
    options: l.shape({
        fetchClientSecret: l.func.isRequired,
        elementsOptions: l.object
    }).isRequired
};
var $e = function(e) {
        var t = s.useContext(J);
        return Ee(t, e)
    },
    Z = function(e) {
        var t = s.useContext(J),
            n = s.useContext(D);
        if (t && n) throw new Error("You cannot wrap the part of your app that ".concat(e, " in both <CheckoutProvider> and <Elements> providers."));
        return t ? Ee(t, e) : ge(n, e)
    },
    ot = function() {
        $e("calls useCheckout()");
        var e = s.useContext(te);
        if (!e) throw new Error("Could not find Checkout Context; You need to wrap the part of your app that calls useCheckout() in an <CheckoutProvider> provider.");
        return e
    },
    Be = ["mode"],
    Fe = function(e) {
        return e.charAt(0).toUpperCase() + e.slice(1)
    },
    p = function(e, t) {
        var n = "".concat(Fe(e), "Element"),
            a = function(i) {
                var S = i.id,
                    C = i.className,
                    E = i.options,
                    u = E === void 0 ? {} : E,
                    A = i.onBlur,
                    P = i.onFocus,
                    g = i.onReady,
                    O = i.onChange,
                    b = i.onEscape,
                    M = i.onClick,
                    G = i.onLoadError,
                    w = i.onLoaderStart,
                    h = i.onNetworksChange,
                    k = i.onConfirm,
                    j = i.onCancel,
                    W = i.onShippingAddressChange,
                    K = i.onShippingRateChange,
                    U = i.onSavedPaymentMethodRemove,
                    z = i.onSavedPaymentMethodUpdate,
                    I = Z("mounts <".concat(n, ">")),
                    L = "elements" in I ? I.elements : null,
                    x = "checkoutSdk" in I ? I.checkoutSdk : null,
                    xe = s.useState(null),
                    re = Y(xe, 2),
                    v = re[0],
                    Pe = re[1],
                    R = s.useRef(null),
                    X = s.useRef(null);
                y(v, "blur", A), y(v, "focus", P), y(v, "escape", b), y(v, "click", M), y(v, "loaderror", G), y(v, "loaderstart", w), y(v, "networkschange", h), y(v, "confirm", k), y(v, "cancel", j), y(v, "shippingaddresschange", W), y(v, "shippingratechange", K), y(v, "savedpaymentmethodremove", U), y(v, "savedpaymentmethodupdate", z), y(v, "change", O);
                var H;
                g && (e === "expressCheckout" ? H = g : H = function() {
                    g(v)
                }), y(v, "ready", H), s.useLayoutEffect(function() {
                    if (R.current === null && X.current !== null && (L || x)) {
                        var m = null;
                        if (x) switch (e) {
                            case "payment":
                                m = x.createPaymentElement(u);
                                break;
                            case "address":
                                if ("mode" in u) {
                                    var oe = u.mode,
                                        ae = me(u, Be);
                                    if (oe === "shipping") m = x.createShippingAddressElement(ae);
                                    else if (oe === "billing") m = x.createBillingAddressElement(ae);
                                    else throw new Error("Invalid options.mode. mode must be 'billing' or 'shipping'.")
                                } else throw new Error("You must supply options.mode. mode must be 'billing' or 'shipping'.");
                                break;
                            case "expressCheckout":
                                m = x.createExpressCheckoutElement(u);
                                break;
                            case "currencySelector":
                                m = x.createCurrencySelectorElement();
                                break;
                            case "taxId":
                                m = x.createTaxIdElement(u);
                                break;
                            default:
                                throw new Error("Invalid Element type ".concat(n, ". You must use either the <PaymentElement />, <AddressElement options={{mode: 'shipping'}} />, <AddressElement options={{mode: 'billing'}} />, or <ExpressCheckoutElement />."))
                        } else L && (m = L.create(e, u));
                        R.current = m, Pe(m), m && m.mount(X.current)
                    }
                }, [L, x, u]);
                var ne = _(u);
                return s.useEffect(function() {
                    if (R.current) {
                        var m = he(u, ne, ["paymentRequest"]);
                        m && "update" in R.current && R.current.update(m)
                    }
                }, [u, ne]), s.useLayoutEffect(function() {
                    return function() {
                        if (R.current && typeof R.current.destroy == "function") try {
                            R.current.destroy(), R.current = null
                        } catch (m) {}
                    }
                }, []), s.createElement("div", {
                    id: S,
                    className: C,
                    ref: X
                })
            },
            o = function(i) {
                Z("mounts <".concat(n, ">"));
                var S = i.id,
                    C = i.className;
                return s.createElement("div", {
                    id: S,
                    className: C
                })
            },
            c = t ? o : a;
        return c.propTypes = {
            id: l.string,
            className: l.string,
            onChange: l.func,
            onBlur: l.func,
            onFocus: l.func,
            onReady: l.func,
            onEscape: l.func,
            onClick: l.func,
            onLoadError: l.func,
            onLoaderStart: l.func,
            onNetworksChange: l.func,
            onConfirm: l.func,
            onCancel: l.func,
            onShippingAddressChange: l.func,
            onShippingRateChange: l.func,
            onSavedPaymentMethodRemove: l.func,
            onSavedPaymentMethodUpdate: l.func,
            options: l.object
        }, c.displayName = n, c.__elementType = e, c
    },
    f = typeof window > "u",
    qe = s.createContext(null);
qe.displayName = "EmbeddedCheckoutProviderContext";
var at = function() {
    var e = Z("calls useStripe()"),
        t = e.stripe;
    return t
};
p("auBankAccount", f);
p("card", f);
p("cardNumber", f);
p("cardExpiry", f);
p("cardCvc", f);
p("fpxBank", f);
p("iban", f);
p("idealBank", f);
p("p24Bank", f);
p("epsBank", f);
var it = p("payment", f),
    st = p("expressCheckout", f);
p("currencySelector", f);
p("paymentRequestButton", f);
p("linkAuthentication", f);
var ut = p("address", f);
p("shippingAddress", f);
p("paymentMethodMessaging", f);
p("affirmMessage", f);
p("afterpayClearpayMessage", f);
p("taxId", f);

function q(r) {
    "@babel/helpers - typeof";
    return typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? q = function(e) {
        return typeof e
    } : q = function(e) {
        return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    }, q(r)
}
var be = "basil",
    Ve = function(e) {
        return e === 3 ? "v3" : e
    },
    ke = "https://js.stripe.com",
    Ye = "".concat(ke, "/").concat(be, "/stripe.js"),
    De = /^https:\/\/js\.stripe\.com\/v3\/?(\?.*)?$/,
    Je = /^https:\/\/js\.stripe\.com\/(v3|[a-z]+)\/stripe\.js(\?.*)?$/,
    pe = "loadStripe.setLoadParameters was called but an existing Stripe.js script already exists in the document; existing script parameters will be used",
    Ge = function(e) {
        return De.test(e) || Je.test(e)
    },
    Ke = function() {
        for (var e = document.querySelectorAll('script[src^="'.concat(ke, '"]')), t = 0; t < e.length; t++) {
            var n = e[t];
            if (Ge(n.src)) return n
        }
        return null
    },
    fe = function(e) {
        var t = e && !e.advancedFraudSignals ? "?advancedFraudSignals=false" : "",
            n = document.createElement("script");
        n.src = "".concat(Ye).concat(t);
        var a = document.head || document.body;
        if (!a) throw new Error("Expected document.body not to be null. Stripe.js requires a <body> element.");
        return a.appendChild(n), n
    },
    ze = function(e, t) {
        !e || !e._registerWrapper || e._registerWrapper({
            name: "stripe-js",
            version: "7.9.0",
            startTime: t
        })
    },
    N = null,
    $ = null,
    B = null,
    Xe = function(e) {
        return function(t) {
            e(new Error("Failed to load Stripe.js", {
                cause: t
            }))
        }
    },
    He = function(e, t) {
        return function() {
            window.Stripe ? e(window.Stripe) : t(new Error("Stripe.js not available"))
        }
    },
    Qe = function(e) {
        return N !== null ? N : (N = new Promise(function(t, n) {
            if (typeof window > "u" || typeof document > "u") {
                t(null);
                return
            }
            if (window.Stripe && e && console.warn(pe), window.Stripe) {
                t(window.Stripe);
                return
            }
            try {
                var a = Ke();
                if (a && e) console.warn(pe);
                else if (!a) a = fe(e);
                else if (a && B !== null && $ !== null) {
                    var o;
                    a.removeEventListener("load", B), a.removeEventListener("error", $), (o = a.parentNode) === null || o === void 0 || o.removeChild(a), a = fe(e)
                }
                B = He(t, n), $ = Xe(n), a.addEventListener("load", B), a.addEventListener("error", $)
            } catch (c) {
                n(c);
                return
            }
        }), N.catch(function(t) {
            return N = null, Promise.reject(t)
        }))
    },
    Ze = function(e, t, n) {
        if (e === null) return null;
        var a = t[0],
            o = a.match(/^pk_test/),
            c = Ve(e.version),
            d = be;
        o && c !== d && console.warn("Stripe.js@".concat(c, " was loaded on the page, but @stripe/stripe-js@").concat("7.9.0", " expected Stripe.js@").concat(d, ". This may result in unexpected behavior. For more information, see https://docs.stripe.com/sdks/stripejs-versioning"));
        var i = e.apply(void 0, t);
        return ze(i, n), i
    },
    de = function(e) {
        var t = "invalid load parameters; expected object of shape\n\n    {advancedFraudSignals: boolean}\n\nbut received\n\n    ".concat(JSON.stringify(e), "\n");
        if (e === null || q(e) !== "object") throw new Error(t);
        if (Object.keys(e).length === 1 && typeof e.advancedFraudSignals == "boolean") return e;
        throw new Error(t)
    },
    V, ee = !1,
    et = function() {
        for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
        ee = !0;
        var a = Date.now();
        return Qe(V).then(function(o) {
            return Ze(o, t, a)
        })
    };
et.setLoadParameters = function(r) {
    if (ee && V) {
        var e = de(r),
            t = Object.keys(e),
            n = t.reduce(function(a, o) {
                var c;
                return a && r[o] === ((c = V) === null || c === void 0 ? void 0 : c[o])
            }, !0);
        if (n) return
    }
    if (ee) throw new Error("You cannot change load parameters after calling loadStripe");
    V = de(r)
};
export {
    ut as A, We as C, st as E, it as P, nt as a, _e as b, ot as c, et as l, at as u
};
//# sourceMappingURL=cdnrxzg58mayu5uf.js.map