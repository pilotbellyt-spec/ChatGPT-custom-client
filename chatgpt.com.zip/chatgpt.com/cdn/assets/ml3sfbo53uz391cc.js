var C = Object.defineProperty;
var f = Object.getOwnPropertySymbols;
var E = Object.prototype.hasOwnProperty,
    S = Object.prototype.propertyIsEnumerable;
var p = (e, a, s) => a in e ? C(e, a, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : e[a] = s,
    M = (e, a) => {
        for (var s in a || (a = {})) E.call(a, s) && p(e, s, a[s]);
        if (f)
            for (var s of f(a)) S.call(a, s) && p(e, s, a[s]);
        return e
    };
import {
    e as N,
    i as V,
    f as A,
    j as i,
    M as F
} from "./fg33krlcm0qyi6yw.js";
import {
    rs as O,
    w as I,
    rt as L,
    mS as _,
    b as z,
    es as D
} from "./dykg4ktvbu3mhmdo.js";
import {
    d4 as G,
    cV as Q
} from "./k15yxxoybkkir2ou.js";
const R = ({
    theme: e,
    name: a
}) => i.jsxs("div", {
    className: "flex items-center gap-1.5",
    children: [i.jsx("div", {
        className: "flex h-3.5 w-3.5 items-center justify-center",
        "data-chat-theme": e,
        children: i.jsx("div", {
            className: "h-2.5 w-2.5 rounded-full bg-(--theme-submit-btn-bg) [[data-chat-theme=black]>&]:bg-black [[data-chat-theme=default]>&]:bg-gray-400 [[data-chat-theme=default]>&]:dark:bg-gray-500"
        })
    }), a]
});

function U({
    account: e
}) {
    var m;
    const {
        isLoading: a,
        value: s,
        setValue: b
    } = O(), n = N(), {
        data: u
    } = I(), T = (m = u == null ? void 0 : u.accountItems) != null ? m : [e], g = e.isFree(), k = e.isPlus(), c = e.isPro(), v = T.some(t => t.isSelfServeBusiness() || t.isEnterprisey()), x = !e.isEdu() && !g && (k || c || v), w = c, h = z(), y = V(), j = L(h), P = s && _(j, s) ? s : "default";

    function o(t, d) {
        return i.jsx(R, {
            theme: t,
            name: d
        })
    }
    const r = [{
        label: o("default", n.formatMessage(l.default)),
        value: "default"
    }, {
        label: o("blue", n.formatMessage(l.blue)),
        value: "blue"
    }, {
        label: o("green", n.formatMessage(l.green)),
        value: "green"
    }, {
        label: o("yellow", n.formatMessage(l.yellow)),
        value: "yellow"
    }, {
        label: o("pink", n.formatMessage(l.pink)),
        value: "pink"
    }, {
        label: o("orange", n.formatMessage(l.orange)),
        value: "orange"
    }];
    x && r.push({
        label: o("purple", n.formatMessage(l.purple)),
        value: "purple"
    }), w && r.push({
        label: o("black", n.formatMessage(l.black)),
        value: "black"
    });
    const B = t => {
        const d = () => Q(y, "accent_color_upsell");
        if (t !== "default" && D(h, "chatgpt-change-theme-accent-color"), t === "purple" && g) {
            d();
            return
        }
        if (t === "black" && !c) {
            d();
            return
        }
        b(t)
    };
    return i.jsxs("div", {
        className: "flex items-center justify-between",
        children: [i.jsx("div", {
            children: i.jsx(F, M({}, l.chatTheme))
        }), i.jsx(G, {
            value: P,
            onValueChange: B,
            disabled: a,
            options: r
        })]
    })
}
const l = A({
    chatTheme: {
        id: "settingsModal.chatTheme",
        defaultMessage: "Accent color"
    },
    default: {
        id: "settingsModal.chatTheme.default",
        defaultMessage: "Default"
    },
    blue: {
        id: "settingsModal.chatTheme.blue",
        defaultMessage: "Blue"
    },
    green: {
        id: "settingsModal.chatTheme.green",
        defaultMessage: "Green"
    },
    yellow: {
        id: "settingsModal.chatTheme.yellow",
        defaultMessage: "Yellow"
    },
    purple: {
        id: "settingsModal.chatTheme.purple",
        defaultMessage: "Purple"
    },
    pink: {
        id: "settingsModal.chatTheme.pink",
        defaultMessage: "Pink"
    },
    orange: {
        id: "settingsModal.chatTheme.orange",
        defaultMessage: "Orange"
    },
    black: {
        id: "settingsModal.chatTheme.black",
        defaultMessage: "Black"
    },
    plus: {
        id: "settingsModal.chatTheme.plusBadge",
        defaultMessage: "Plus"
    },
    pro: {
        id: "settingsModal.chatTheme.proBadge",
        defaultMessage: "Pro"
    }
});
export {
    R as C, U as a, l as m
};
//# sourceMappingURL=ml3sfbo53uz391cc.js.map