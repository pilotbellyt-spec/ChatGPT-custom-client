import {
    jw as b,
    l as O,
    bg as E
} from "./dykg4ktvbu3mhmdo.js";
import {
    hj as a,
    hk as n,
    j_ as D
} from "./k15yxxoybkkir2ou.js";
import {
    c as k,
    j as v
} from "./fg33krlcm0qyi6yw.js";
var _ = (s => (s.javascript = "javascript", s.typescript = "typescript", s.bash = "bash", s.zsh = "zsh", s.html = "html", s.css = "css", s.python = "python", s.json = "json", s.sql = "sql", s.go = "go", s.yaml = "yaml", s.java = "java", s.rust = "rust", s.cpp = "cpp", s.swift = "swift", s.php = "php", s.xml = "xml", s.ruby = "ruby", s.haskell = "haskell", s.kotlin = "kotlin", s.csharp = "csharp", s.c = "c", s.objectivec = "objectivec", s.r = "r", s.lua = "lua", s.dart = "dart", s.scala = "scala", s.perl = "perl", s.commonlisp = "commonlisp", s.clojure = "clojure", s.ocaml = "ocaml", s.powershell = "powershell", s.verilog = "verilog", s.dockerfile = "dockerfile", s.vue = "vue", s.other = "other", s))(_ || {});

function M(s) {
    if (a(s)) switch (s) {
        case n.CODE_REACT:
            return "typescript";
        default:
            return b(s.replace(/^code\//, ""), Object.values(_), "other")
    }
}
const S = s => {
        "use forget";
        const l = k.c(9),
            {
                gap: h,
                padding: f,
                size: j
            } = s,
            c = f === void 0 ? 4 : f,
            t = j === void 0 ? 3 : j;
        let p;
        l[0] === Symbol.for("react.memo_cache_sentinel") ? (p = O("grid h-full max-w-full flex-1 grid-cols-3 items-center"), l[0] = p) : p = l[0];
        let r;
        l[1] !== h || l[2] !== c ? (r = {
            gap: h,
            padding: c
        }, l[1] = h, l[2] = c, l[3] = r) : r = l[3];
        let i;
        l[4] !== t ? (i = D(3, y => v.jsx(E.div, {
            className: "dark:bg-white-400 aspect-square rounded-full bg-gray-400",
            animate: {
                translateY: ["0%", "-50%", "0%", "0%", "0%"]
            },
            style: {
                translateX: .5,
                width: t,
                height: t
            },
            transition: {
                repeat: 1 / 0,
                type: "keyframes",
                delay: y / 10,
                duration: .7
            }
        }, y)), l[4] = t, l[5] = i) : i = l[5];
        let m;
        return l[6] !== r || l[7] !== i ? (m = v.jsx(E.div, {
            className: p,
            style: r,
            children: i
        }), l[6] = r, l[7] = i, l[8] = m) : m = l[8], m
    },
    w = 36,
    z = -24,
    I = 280,
    H = I + w,
    q = 40;
var N = (s => (s.COLLAPSED = "collapsed", s.EXPANDED = "expanded", s))(N || {});
export {
    q as C, I as E, N as G, S as T, H as a, z as b, w as c, _ as d, M as g
};
//# sourceMappingURL=coi95al0vrqe13ds.js.map