import {
    a0 as o
} from "./fg33krlcm0qyi6yw.js";
const r = o(function() {
    return null
});
export {
    r as
    default
};
//# sourceMappingURL=hifffzrs0dd2gemt.js.map