import {
    r as n,
    P as t,
    j as r,
    a8 as d
} from "./fg33krlcm0qyi6yw.js";
import {
    qU as a
} from "./dykg4ktvbu3mhmdo.js";
window.__oai_SSR_HTML ? a.instance.addFirstTiming("composer.html", {
    time: window.__oai_SSR_HTML,
    serialTimingGroup: "pageLoad"
}) : window.__oai_logHTML = () => {
    a.instance.addFirstTiming("composer.html", {
        serialTimingGroup: "pageLoad"
    })
};
window.__oai_SSR_TTI ? a.instance.addFirstTiming("composer.visible", {
    time: window.__oai_SSR_TTI,
    serialTimingGroup: "pageLoad"
}) : window.__oai_logTTI = () => {
    a.instance.addFirstTiming("composer.visible", {
        serialTimingGroup: "pageLoad"
    })
};
a.instance.addTiming("entry.client", {
    serialTimingGroup: "pageLoad"
});
n.startTransition(() => {
    t.hydrateRoot(document, r.jsx(n.StrictMode, {
        children: r.jsx(d, {})
    }), {
        onRecoverableError(i, s) {
            var e;
            const o = new Error("".concat(i instanceof Error ? i.message : String(i)));
            o.name = "RecoverableError", o.stack = (e = s.componentStack) != null ? e : i instanceof Error ? i.stack : String(i), o.cause = i, a.instance.addError(o)
        }
    })
});
//# sourceMappingURL=g1sdxuwla2ddlep0.js.map