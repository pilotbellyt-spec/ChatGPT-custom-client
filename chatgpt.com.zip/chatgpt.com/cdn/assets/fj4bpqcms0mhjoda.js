import {
    c as M,
    j as d
} from "./fg33krlcm0qyi6yw.js";
import {
    dB as B,
    b as D,
    qw as G,
    ot as L,
    bI as V,
    qx as k
} from "./dykg4ktvbu3mhmdo.js";
import {
    bQ as N,
    bR as Q,
    bS as U,
    bT as $,
    bU as z
} from "./k15yxxoybkkir2ou.js";
import {
    P as J
} from "./eejiqzdptzp07q5y.js";

function ee(E) {
    "use forget";
    const e = M.c(33),
        {
            clientThreadId: x,
            currentModelId: g,
            onRequestCompletion: o,
            activeImage: l,
            currentDrawnShape: q,
            getImageData: C,
            onCancelInpaint: P,
            onClose: b
        } = E,
        v = q === void 0 ? null : q,
        T = D();
    let c;
    e[0] !== x || e[1] !== T ? (c = B(T, x), e[0] = x, e[1] = T, e[2] = c) : c = e[2];
    const t = c;
    let m;
    e[3] !== l ? (m = l != null ? l : {}, e[3] = l, e[4] = m) : m = e[4];
    const {
        assetPointer: S,
        transformationId: p,
        height: H,
        width: A
    } = m, j = H === void 0 ? 0 : H, w = A === void 0 ? 0 : A, y = S != null ? S : "";
    let u;
    e[5] !== p ? (u = {
        dalle: {
            gen_id: p
        },
        generation: {
            gen_id: p
        }
    }, e[5] = p, e[6] = u) : u = e[6];
    const F = u;
    let s;
    e[7] !== j || e[8] !== y || e[9] !== F || e[10] !== w ? (s = {
        asset_pointer: y,
        metadata: F,
        height: j,
        width: w
    }, e[7] = j, e[8] = y, e[9] = F, e[10] = w, e[11] = s) : s = e[11];
    const I = P != null ? P : O,
        R = C != null ? C : K;
    let f;
    e[12] !== v || e[13] !== I || e[14] !== R || e[15] !== s ? (f = {
        image: s,
        currentDrawnShape: v,
        onCleared: I,
        getImageData: R
    }, e[12] = v, e[13] = I, e[14] = R, e[15] = s, e[16] = f) : f = e[16], N(f);
    let r;
    e[17] !== o ? (r = _ => o($(_)), e[17] = o, e[18] = r) : r = e[18];
    let n;
    e[19] !== b || e[20] !== o ? (n = async _ => {
        o(await z(_)), b()
    }, e[19] = b, e[20] = o, e[21] = n) : n = e[21];
    let i;
    e[22] !== t || e[23] !== g || e[24] !== r || e[25] !== n ? (i = d.jsx(Q, {
        children: d.jsx(J, {
            conversation: t,
            isNewThread: !0,
            currentModelId: g,
            onContinueGenerating: r,
            onRequestCompletion: n,
            hideHeader: !0,
            disableAdvancedVoiceMode: !0,
            plusButtonAddsFiles: !0,
            placeholder: U.imagesAppLightboxPlaceholder
        })
    }), e[22] = t, e[23] = g, e[24] = r, e[25] = n, e[26] = i) : i = e[26];
    let a;
    e[27] !== t || e[28] !== i ? (a = d.jsx(G, {
        children: d.jsx(L, {
            conversation: t,
            forcedSystemHintType: V.PictureV2,
            children: i
        })
    }), e[27] = t, e[28] = i, e[29] = a) : a = e[29];
    let h;
    return e[30] !== t || e[31] !== a ? (h = d.jsx(k, {
        conversation: t,
        children: a
    }), e[30] = t, e[31] = a, e[32] = h) : h = e[32], h
}

function K() {}

function O() {}
export {
    ee as I
};
//# sourceMappingURL=fj4bpqcms0mhjoda.js.map