import {
    h as Ue
} from "./fg33krlcm0qyi6yw.js";
import {
    r as Ve
} from "./lad8yx56mqsdspc9.js";

function Lt(e) {
    const n = e.regex.either(...["(?:NeedsTeXFormat|RequirePackage|GetIdInfo)", "Provides(?:Expl)?(?:Package|Class|File)", "(?:DeclareOption|ProcessOptions)", "(?:documentclass|usepackage|input|include)", "makeat(?:letter|other)", "ExplSyntax(?:On|Off)", "(?:new|renew|provide)?command", "(?:re)newenvironment", "(?:New|Renew|Provide|Declare)(?:Expandable)?DocumentCommand", "(?:New|Renew|Provide|Declare)DocumentEnvironment", "(?:(?:e|g|x)?def|let)", "(?:begin|end)", "(?:part|chapter|(?:sub){0,2}section|(?:sub)?paragraph)", "caption", "(?:label|(?:eq|page|name)?ref|(?:paren|foot|super)?cite)", "(?:alpha|beta|[Gg]amma|[Dd]elta|(?:var)?epsilon|zeta|eta|[Tt]heta|vartheta)", "(?:iota|(?:var)?kappa|[Ll]ambda|mu|nu|[Xx]i|[Pp]i|varpi|(?:var)rho)", "(?:[Ss]igma|varsigma|tau|[Uu]psilon|[Pp]hi|varphi|chi|[Pp]si|[Oo]mega)", "(?:frac|sum|prod|lim|infty|times|sqrt|leq|geq|left|right|middle|[bB]igg?)", "(?:[lr]angle|q?quad|[lcvdi]?dots|d?dot|hat|tilde|bar)"].map(R => R + "(?![a-zA-Z@:_])")),
        i = new RegExp(["(?:__)?[a-zA-Z]{2,}_[a-zA-Z](?:_?[a-zA-Z])+:[a-zA-Z]*", "[lgc]__?[a-zA-Z](?:_?[a-zA-Z])*_[a-zA-Z]{2,}", "[qs]__?[a-zA-Z](?:_?[a-zA-Z])+", "use(?:_i)?:[a-zA-Z]*", "(?:else|fi|or):", "(?:if|cs|exp):w", "(?:hbox|vbox):n", "::[a-zA-Z]_unbraced", "::[a-zA-Z:]"].map(R => R + "(?![a-zA-Z:_])").join("|")),
        a = [{
            begin: /[a-zA-Z@]+/
        }, {
            begin: /[^a-zA-Z@]?/
        }],
        u = [{
            begin: /\^{6}[0-9a-f]{6}/
        }, {
            begin: /\^{5}[0-9a-f]{5}/
        }, {
            begin: /\^{4}[0-9a-f]{4}/
        }, {
            begin: /\^{3}[0-9a-f]{3}/
        }, {
            begin: /\^{2}[0-9a-f]{2}/
        }, {
            begin: /\^{2}[\u0000-\u007f]/
        }],
        s = {
            className: "keyword",
            begin: /\\/,
            relevance: 0,
            contains: [{
                endsParent: !0,
                begin: n
            }, {
                endsParent: !0,
                begin: i
            }, {
                endsParent: !0,
                variants: u
            }, {
                endsParent: !0,
                relevance: 0,
                variants: a
            }]
        },
        o = {
            className: "params",
            relevance: 0,
            begin: /#+\d?/
        },
        c = {
            variants: u
        },
        r = {
            className: "built_in",
            relevance: 0,
            begin: /[$&^_]/
        },
        l = {
            className: "meta",
            begin: /% ?!(T[eE]X|tex|BIB|bib)/,
            end: "$",
            relevance: 10
        },
        p = e.COMMENT("%", "$", {
            relevance: 0
        }),
        d = [s, o, c, r, l, p],
        m = {
            begin: /\{/,
            end: /\}/,
            relevance: 0,
            contains: ["self", ...d]
        },
        b = e.inherit(m, {
            relevance: 0,
            endsParent: !0,
            contains: [m, ...d]
        }),
        g = {
            begin: /\[/,
            end: /\]/,
            endsParent: !0,
            relevance: 0,
            contains: [m, ...d]
        },
        E = {
            begin: /\s+/,
            relevance: 0
        },
        S = [b],
        N = [g],
        _ = function(R, f) {
            return {
                contains: [E],
                starts: {
                    relevance: 0,
                    contains: R,
                    starts: f
                }
            }
        },
        T = function(R, f) {
            return {
                begin: "\\\\" + R + "(?![a-zA-Z@:_])",
                keywords: {
                    $pattern: /\\[a-zA-Z]+/,
                    keyword: "\\" + R
                },
                relevance: 0,
                contains: [E],
                starts: f
            }
        },
        A = function(R, f) {
            return e.inherit({
                begin: "\\\\begin(?=[ 	]*(\\r?\\n[ 	]*)?\\{" + R + "\\})",
                keywords: {
                    $pattern: /\\[a-zA-Z]+/,
                    keyword: "\\begin"
                },
                relevance: 0
            }, _(S, f))
        },
        C = (R = "string") => e.END_SAME_AS_BEGIN({
            className: R,
            begin: /(.|\r?\n)/,
            end: /(.|\r?\n)/,
            excludeBegin: !0,
            excludeEnd: !0,
            endsParent: !0
        }),
        O = function(R) {
            return {
                className: "string",
                end: "(?=\\\\end\\{" + R + "\\})"
            }
        },
        D = (R = "string") => ({
            relevance: 0,
            begin: /\{/,
            starts: {
                endsParent: !0,
                contains: [{
                    className: R,
                    end: /(?=\})/,
                    endsParent: !0,
                    contains: [{
                        begin: /\{/,
                        end: /\}/,
                        relevance: 0,
                        contains: ["self"]
                    }]
                }]
            }
        }),
        L = [...["verb", "lstinline"].map(R => T(R, {
            contains: [C()]
        })), T("mint", _(S, {
            contains: [C()]
        })), T("mintinline", _(S, {
            contains: [D(), C()]
        })), T("url", {
            contains: [D("link"), D("link")]
        }), T("hyperref", {
            contains: [D("link")]
        }), T("href", _(N, {
            contains: [D("link")]
        })), ...[].concat(...["", "\\*"].map(R => [A("verbatim" + R, O("verbatim" + R)), A("filecontents" + R, _(S, O("filecontents" + R))), ...["", "B", "L"].map(f => A(f + "Verbatim" + R, _(N, O(f + "Verbatim" + R))))])), A("minted", _(N, _(S, O("minted"))))];
    return {
        name: "LaTeX",
        aliases: ["tex"],
        contains: [...L, ...d]
    }
}
const He = ["AASTriangle", "AbelianGroup", "Abort", "AbortKernels", "AbortProtect", "AbortScheduledTask", "Above", "Abs", "AbsArg", "AbsArgPlot", "Absolute", "AbsoluteCorrelation", "AbsoluteCorrelationFunction", "AbsoluteCurrentValue", "AbsoluteDashing", "AbsoluteFileName", "AbsoluteOptions", "AbsolutePointSize", "AbsoluteThickness", "AbsoluteTime", "AbsoluteTiming", "AcceptanceThreshold", "AccountingForm", "Accumulate", "Accuracy", "AccuracyGoal", "AcousticAbsorbingValue", "AcousticImpedanceValue", "AcousticNormalVelocityValue", "AcousticPDEComponent", "AcousticPressureCondition", "AcousticRadiationValue", "AcousticSoundHardValue", "AcousticSoundSoftCondition", "ActionDelay", "ActionMenu", "ActionMenuBox", "ActionMenuBoxOptions", "Activate", "Active", "ActiveClassification", "ActiveClassificationObject", "ActiveItem", "ActivePrediction", "ActivePredictionObject", "ActiveStyle", "AcyclicGraphQ", "AddOnHelpPath", "AddSides", "AddTo", "AddToSearchIndex", "AddUsers", "AdjacencyGraph", "AdjacencyList", "AdjacencyMatrix", "AdjacentMeshCells", "Adjugate", "AdjustmentBox", "AdjustmentBoxOptions", "AdjustTimeSeriesForecast", "AdministrativeDivisionData", "AffineHalfSpace", "AffineSpace", "AffineStateSpaceModel", "AffineTransform", "After", "AggregatedEntityClass", "AggregationLayer", "AircraftData", "AirportData", "AirPressureData", "AirSoundAttenuation", "AirTemperatureData", "AiryAi", "AiryAiPrime", "AiryAiZero", "AiryBi", "AiryBiPrime", "AiryBiZero", "AlgebraicIntegerQ", "AlgebraicNumber", "AlgebraicNumberDenominator", "AlgebraicNumberNorm", "AlgebraicNumberPolynomial", "AlgebraicNumberTrace", "AlgebraicRules", "AlgebraicRulesData", "Algebraics", "AlgebraicUnitQ", "Alignment", "AlignmentMarker", "AlignmentPoint", "All", "AllowAdultContent", "AllowChatServices", "AllowedCloudExtraParameters", "AllowedCloudParameterExtensions", "AllowedDimensions", "AllowedFrequencyRange", "AllowedHeads", "AllowGroupClose", "AllowIncomplete", "AllowInlineCells", "AllowKernelInitialization", "AllowLooseGrammar", "AllowReverseGroupClose", "AllowScriptLevelChange", "AllowVersionUpdate", "AllTrue", "Alphabet", "AlphabeticOrder", "AlphabeticSort", "AlphaChannel", "AlternateImage", "AlternatingFactorial", "AlternatingGroup", "AlternativeHypothesis", "Alternatives", "AltitudeMethod", "AmbientLight", "AmbiguityFunction", "AmbiguityList", "Analytic", "AnatomyData", "AnatomyForm", "AnatomyPlot3D", "AnatomySkinStyle", "AnatomyStyling", "AnchoredSearch", "And", "AndersonDarlingTest", "AngerJ", "AngleBisector", "AngleBracket", "AnglePath", "AnglePath3D", "AngleVector", "AngularGauge", "Animate", "AnimatedImage", "AnimationCycleOffset", "AnimationCycleRepetitions", "AnimationDirection", "AnimationDisplayTime", "AnimationRate", "AnimationRepetitions", "AnimationRunning", "AnimationRunTime", "AnimationTimeIndex", "AnimationVideo", "Animator", "AnimatorBox", "AnimatorBoxOptions", "AnimatorElements", "Annotate", "Annotation", "AnnotationDelete", "AnnotationKeys", "AnnotationRules", "AnnotationValue", "Annuity", "AnnuityDue", "Annulus", "AnomalyDetection", "AnomalyDetector", "AnomalyDetectorFunction", "Anonymous", "Antialiasing", "Antihermitian", "AntihermitianMatrixQ", "Antisymmetric", "AntisymmetricMatrixQ", "Antonyms", "AnyOrder", "AnySubset", "AnyTrue", "Apart", "ApartSquareFree", "APIFunction", "Appearance", "AppearanceElements", "AppearanceRules", "AppellF1", "Append", "AppendCheck", "AppendLayer", "AppendTo", "Application", "Apply", "ApplyReaction", "ApplySides", "ApplyTo", "ArcCos", "ArcCosh", "ArcCot", "ArcCoth", "ArcCsc", "ArcCsch", "ArcCurvature", "ARCHProcess", "ArcLength", "ArcSec", "ArcSech", "ArcSin", "ArcSinDistribution", "ArcSinh", "ArcTan", "ArcTanh", "Area", "Arg", "ArgMax", "ArgMin", "ArgumentCountQ", "ArgumentsOptions", "ARIMAProcess", "ArithmeticGeometricMean", "ARMAProcess", "Around", "AroundReplace", "ARProcess", "Array", "ArrayComponents", "ArrayDepth", "ArrayFilter", "ArrayFlatten", "ArrayMesh", "ArrayPad", "ArrayPlot", "ArrayPlot3D", "ArrayQ", "ArrayReduce", "ArrayResample", "ArrayReshape", "ArrayRules", "Arrays", "Arrow", "Arrow3DBox", "ArrowBox", "Arrowheads", "ASATriangle", "Ask", "AskAppend", "AskConfirm", "AskDisplay", "AskedQ", "AskedValue", "AskFunction", "AskState", "AskTemplateDisplay", "AspectRatio", "AspectRatioFixed", "Assert", "AssessmentFunction", "AssessmentResultObject", "AssociateTo", "Association", "AssociationFormat", "AssociationMap", "AssociationQ", "AssociationThread", "AssumeDeterministic", "Assuming", "Assumptions", "AstroAngularSeparation", "AstroBackground", "AstroCenter", "AstroDistance", "AstroGraphics", "AstroGridLines", "AstroGridLinesStyle", "AstronomicalData", "AstroPosition", "AstroProjection", "AstroRange", "AstroRangePadding", "AstroReferenceFrame", "AstroStyling", "AstroZoomLevel", "Asymptotic", "AsymptoticDSolveValue", "AsymptoticEqual", "AsymptoticEquivalent", "AsymptoticExpectation", "AsymptoticGreater", "AsymptoticGreaterEqual", "AsymptoticIntegrate", "AsymptoticLess", "AsymptoticLessEqual", "AsymptoticOutputTracker", "AsymptoticProbability", "AsymptoticProduct", "AsymptoticRSolveValue", "AsymptoticSolve", "AsymptoticSum", "Asynchronous", "AsynchronousTaskObject", "AsynchronousTasks", "Atom", "AtomCoordinates", "AtomCount", "AtomDiagramCoordinates", "AtomLabels", "AtomLabelStyle", "AtomList", "AtomQ", "AttachCell", "AttachedCell", "AttentionLayer", "Attributes", "Audio", "AudioAmplify", "AudioAnnotate", "AudioAnnotationLookup", "AudioBlockMap", "AudioCapture", "AudioChannelAssignment", "AudioChannelCombine", "AudioChannelMix", "AudioChannels", "AudioChannelSeparate", "AudioData", "AudioDelay", "AudioDelete", "AudioDevice", "AudioDistance", "AudioEncoding", "AudioFade", "AudioFrequencyShift", "AudioGenerator", "AudioIdentify", "AudioInputDevice", "AudioInsert", "AudioInstanceQ", "AudioIntervals", "AudioJoin", "AudioLabel", "AudioLength", "AudioLocalMeasurements", "AudioLooping", "AudioLoudness", "AudioMeasurements", "AudioNormalize", "AudioOutputDevice", "AudioOverlay", "AudioPad", "AudioPan", "AudioPartition", "AudioPause", "AudioPitchShift", "AudioPlay", "AudioPlot", "AudioQ", "AudioRecord", "AudioReplace", "AudioResample", "AudioReverb", "AudioReverse", "AudioSampleRate", "AudioSpectralMap", "AudioSpectralTransformation", "AudioSplit", "AudioStop", "AudioStream", "AudioStreams", "AudioTimeStretch", "AudioTrackApply", "AudioTrackSelection", "AudioTrim", "AudioType", "AugmentedPolyhedron", "AugmentedSymmetricPolynomial", "Authenticate", "Authentication", "AuthenticationDialog", "AutoAction", "Autocomplete", "AutocompletionFunction", "AutoCopy", "AutocorrelationTest", "AutoDelete", "AutoEvaluateEvents", "AutoGeneratedPackage", "AutoIndent", "AutoIndentSpacings", "AutoItalicWords", "AutoloadPath", "AutoMatch", "Automatic", "AutomaticImageSize", "AutoMultiplicationSymbol", "AutoNumberFormatting", "AutoOpenNotebooks", "AutoOpenPalettes", "AutoOperatorRenderings", "AutoQuoteCharacters", "AutoRefreshed", "AutoRemove", "AutorunSequencing", "AutoScaling", "AutoScroll", "AutoSpacing", "AutoStyleOptions", "AutoStyleWords", "AutoSubmitting", "Axes", "AxesEdge", "AxesLabel", "AxesOrigin", "AxesStyle", "AxiomaticTheory", "Axis", "Axis3DBox", "Axis3DBoxOptions", "AxisBox", "AxisBoxOptions", "AxisLabel", "AxisObject", "AxisStyle", "BabyMonsterGroupB", "Back", "BackFaceColor", "BackFaceGlowColor", "BackFaceOpacity", "BackFaceSpecularColor", "BackFaceSpecularExponent", "BackFaceSurfaceAppearance", "BackFaceTexture", "Background", "BackgroundAppearance", "BackgroundTasksSettings", "Backslash", "Backsubstitution", "Backward", "Ball", "Band", "BandpassFilter", "BandstopFilter", "BarabasiAlbertGraphDistribution", "BarChart", "BarChart3D", "BarcodeImage", "BarcodeRecognize", "BaringhausHenzeTest", "BarLegend", "BarlowProschanImportance", "BarnesG", "BarOrigin", "BarSpacing", "BartlettHannWindow", "BartlettWindow", "BaseDecode", "BaseEncode", "BaseForm", "Baseline", "BaselinePosition", "BaseStyle", "BasicRecurrentLayer", "BatchNormalizationLayer", "BatchSize", "BatesDistribution", "BattleLemarieWavelet", "BayesianMaximization", "BayesianMaximizationObject", "BayesianMinimization", "BayesianMinimizationObject", "Because", "BeckmannDistribution", "Beep", "Before", "Begin", "BeginDialogPacket", "BeginPackage", "BellB", "BellY", "Below", "BenfordDistribution", "BeniniDistribution", "BenktanderGibratDistribution", "BenktanderWeibullDistribution", "BernoulliB", "BernoulliDistribution", "BernoulliGraphDistribution", "BernoulliProcess", "BernsteinBasis", "BesagL", "BesselFilterModel", "BesselI", "BesselJ", "BesselJZero", "BesselK", "BesselY", "BesselYZero", "Beta", "BetaBinomialDistribution", "BetaDistribution", "BetaNegativeBinomialDistribution", "BetaPrimeDistribution", "BetaRegularized", "Between", "BetweennessCentrality", "Beveled", "BeveledPolyhedron", "BezierCurve", "BezierCurve3DBox", "BezierCurve3DBoxOptions", "BezierCurveBox", "BezierCurveBoxOptions", "BezierFunction", "BilateralFilter", "BilateralLaplaceTransform", "BilateralZTransform", "Binarize", "BinaryDeserialize", "BinaryDistance", "BinaryFormat", "BinaryImageQ", "BinaryRead", "BinaryReadList", "BinarySerialize", "BinaryWrite", "BinCounts", "BinLists", "BinnedVariogramList", "Binomial", "BinomialDistribution", "BinomialPointProcess", "BinomialProcess", "BinormalDistribution", "BiorthogonalSplineWavelet", "BioSequence", "BioSequenceBackTranslateList", "BioSequenceComplement", "BioSequenceInstances", "BioSequenceModify", "BioSequencePlot", "BioSequenceQ", "BioSequenceReverseComplement", "BioSequenceTranscribe", "BioSequenceTranslate", "BipartiteGraphQ", "BiquadraticFilterModel", "BirnbaumImportance", "BirnbaumSaundersDistribution", "BitAnd", "BitClear", "BitGet", "BitLength", "BitNot", "BitOr", "BitRate", "BitSet", "BitShiftLeft", "BitShiftRight", "BitXor", "BiweightLocation", "BiweightMidvariance", "Black", "BlackmanHarrisWindow", "BlackmanNuttallWindow", "BlackmanWindow", "Blank", "BlankForm", "BlankNullSequence", "BlankSequence", "Blend", "Block", "BlockchainAddressData", "BlockchainBase", "BlockchainBlockData", "BlockchainContractValue", "BlockchainData", "BlockchainGet", "BlockchainKeyEncode", "BlockchainPut", "BlockchainTokenData", "BlockchainTransaction", "BlockchainTransactionData", "BlockchainTransactionSign", "BlockchainTransactionSubmit", "BlockDiagonalMatrix", "BlockLowerTriangularMatrix", "BlockMap", "BlockRandom", "BlockUpperTriangularMatrix", "BlomqvistBeta", "BlomqvistBetaTest", "Blue", "Blur", "Blurring", "BodePlot", "BohmanWindow", "Bold", "Bond", "BondCount", "BondLabels", "BondLabelStyle", "BondList", "BondQ", "Bookmarks", "Boole", "BooleanConsecutiveFunction", "BooleanConvert", "BooleanCountingFunction", "BooleanFunction", "BooleanGraph", "BooleanMaxterms", "BooleanMinimize", "BooleanMinterms", "BooleanQ", "BooleanRegion", "Booleans", "BooleanStrings", "BooleanTable", "BooleanVariables", "BorderDimensions", "BorelTannerDistribution", "Bottom", "BottomHatTransform", "BoundaryDiscretizeGraphics", "BoundaryDiscretizeRegion", "BoundaryMesh", "BoundaryMeshRegion", "BoundaryMeshRegionQ", "BoundaryStyle", "BoundedRegionQ", "BoundingRegion", "Bounds", "Box", "BoxBaselineShift", "BoxData", "BoxDimensions", "Boxed", "Boxes", "BoxForm", "BoxFormFormatTypes", "BoxFrame", "BoxID", "BoxMargins", "BoxMatrix", "BoxObject", "BoxRatios", "BoxRotation", "BoxRotationPoint", "BoxStyle", "BoxWhiskerChart", "Bra", "BracketingBar", "BraKet", "BrayCurtisDistance", "BreadthFirstScan", "Break", "BridgeData", "BrightnessEqualize", "BroadcastStationData", "Brown", "BrownForsytheTest", "BrownianBridgeProcess", "BrowserCategory", "BSplineBasis", "BSplineCurve", "BSplineCurve3DBox", "BSplineCurve3DBoxOptions", "BSplineCurveBox", "BSplineCurveBoxOptions", "BSplineFunction", "BSplineSurface", "BSplineSurface3DBox", "BSplineSurface3DBoxOptions", "BubbleChart", "BubbleChart3D", "BubbleScale", "BubbleSizes", "BuckyballGraph", "BuildCompiledComponent", "BuildingData", "BulletGauge", "BusinessDayQ", "ButterflyGraph", "ButterworthFilterModel", "Button", "ButtonBar", "ButtonBox", "ButtonBoxOptions", "ButtonCell", "ButtonContents", "ButtonData", "ButtonEvaluator", "ButtonExpandable", "ButtonFrame", "ButtonFunction", "ButtonMargins", "ButtonMinHeight", "ButtonNote", "ButtonNotebook", "ButtonSource", "ButtonStyle", "ButtonStyleMenuListing", "Byte", "ByteArray", "ByteArrayFormat", "ByteArrayFormatQ", "ByteArrayQ", "ByteArrayToString", "ByteCount", "ByteOrdering", "C", "CachedValue", "CacheGraphics", "CachePersistence", "CalendarConvert", "CalendarData", "CalendarType", "Callout", "CalloutMarker", "CalloutStyle", "CallPacket", "CanberraDistance", "Cancel", "CancelButton", "CandlestickChart", "CanonicalGraph", "CanonicalizePolygon", "CanonicalizePolyhedron", "CanonicalizeRegion", "CanonicalName", "CanonicalWarpingCorrespondence", "CanonicalWarpingDistance", "CantorMesh", "CantorStaircase", "Canvas", "Cap", "CapForm", "CapitalDifferentialD", "Capitalize", "CapsuleShape", "CaptureRunning", "CaputoD", "CardinalBSplineBasis", "CarlemanLinearize", "CarlsonRC", "CarlsonRD", "CarlsonRE", "CarlsonRF", "CarlsonRG", "CarlsonRJ", "CarlsonRK", "CarlsonRM", "CarmichaelLambda", "CaseOrdering", "Cases", "CaseSensitive", "Cashflow", "Casoratian", "Cast", "Catalan", "CatalanNumber", "Catch", "CategoricalDistribution", "Catenate", "CatenateLayer", "CauchyDistribution", "CauchyMatrix", "CauchyPointProcess", "CauchyWindow", "CayleyGraph", "CDF", "CDFDeploy", "CDFInformation", "CDFWavelet", "Ceiling", "CelestialSystem", "Cell", "CellAutoOverwrite", "CellBaseline", "CellBoundingBox", "CellBracketOptions", "CellChangeTimes", "CellContents", "CellContext", "CellDingbat", "CellDingbatMargin", "CellDynamicExpression", "CellEditDuplicate", "CellElementsBoundingBox", "CellElementSpacings", "CellEpilog", "CellEvaluationDuplicate", "CellEvaluationFunction", "CellEvaluationLanguage", "CellEventActions", "CellFrame", "CellFrameColor", "CellFrameLabelMargins", "CellFrameLabels", "CellFrameMargins", "CellFrameStyle", "CellGroup", "CellGroupData", "CellGrouping", "CellGroupingRules", "CellHorizontalScrolling", "CellID", "CellInsertionPointCell", "CellLabel", "CellLabelAutoDelete", "CellLabelMargins", "CellLabelPositioning", "CellLabelStyle", "CellLabelTemplate", "CellMargins", "CellObject", "CellOpen", "CellPrint", "CellProlog", "Cells", "CellSize", "CellStyle", "CellTags", "CellTrayPosition", "CellTrayWidgets", "CellularAutomaton", "CensoredDistribution", "Censoring", "Center", "CenterArray", "CenterDot", "CenteredInterval", "CentralFeature", "CentralMoment", "CentralMomentGeneratingFunction", "Cepstrogram", "CepstrogramArray", "CepstrumArray", "CForm", "ChampernowneNumber", "ChangeOptions", "ChannelBase", "ChannelBrokerAction", "ChannelDatabin", "ChannelHistoryLength", "ChannelListen", "ChannelListener", "ChannelListeners", "ChannelListenerWait", "ChannelObject", "ChannelPreSendFunction", "ChannelReceiverFunction", "ChannelSend", "ChannelSubscribers", "ChanVeseBinarize", "Character", "CharacterCounts", "CharacterEncoding", "CharacterEncodingsPath", "CharacteristicFunction", "CharacteristicPolynomial", "CharacterName", "CharacterNormalize", "CharacterRange", "Characters", "ChartBaseStyle", "ChartElementData", "ChartElementDataFunction", "ChartElementFunction", "ChartElements", "ChartLabels", "ChartLayout", "ChartLegends", "ChartStyle", "Chebyshev1FilterModel", "Chebyshev2FilterModel", "ChebyshevDistance", "ChebyshevT", "ChebyshevU", "Check", "CheckAbort", "CheckAll", "CheckArguments", "Checkbox", "CheckboxBar", "CheckboxBox", "CheckboxBoxOptions", "ChemicalConvert", "ChemicalData", "ChemicalFormula", "ChemicalInstance", "ChemicalReaction", "ChessboardDistance", "ChiDistribution", "ChineseRemainder", "ChiSquareDistribution", "ChoiceButtons", "ChoiceDialog", "CholeskyDecomposition", "Chop", "ChromaticityPlot", "ChromaticityPlot3D", "ChromaticPolynomial", "Circle", "CircleBox", "CircleDot", "CircleMinus", "CirclePlus", "CirclePoints", "CircleThrough", "CircleTimes", "CirculantGraph", "CircularArcThrough", "CircularOrthogonalMatrixDistribution", "CircularQuaternionMatrixDistribution", "CircularRealMatrixDistribution", "CircularSymplecticMatrixDistribution", "CircularUnitaryMatrixDistribution", "Circumsphere", "CityData", "ClassifierFunction", "ClassifierInformation", "ClassifierMeasurements", "ClassifierMeasurementsObject", "Classify", "ClassPriors", "Clear", "ClearAll", "ClearAttributes", "ClearCookies", "ClearPermissions", "ClearSystemCache", "ClebschGordan", "ClickPane", "ClickToCopy", "ClickToCopyEnabled", "Clip", "ClipboardNotebook", "ClipFill", "ClippingStyle", "ClipPlanes", "ClipPlanesStyle", "ClipRange", "Clock", "ClockGauge", "ClockwiseContourIntegral", "Close", "Closed", "CloseKernels", "ClosenessCentrality", "Closing", "ClosingAutoSave", "ClosingEvent", "CloudAccountData", "CloudBase", "CloudConnect", "CloudConnections", "CloudDeploy", "CloudDirectory", "CloudDisconnect", "CloudEvaluate", "CloudExport", "CloudExpression", "CloudExpressions", "CloudFunction", "CloudGet", "CloudImport", "CloudLoggingData", "CloudObject", "CloudObjectInformation", "CloudObjectInformationData", "CloudObjectNameFormat", "CloudObjects", "CloudObjectURLType", "CloudPublish", "CloudPut", "CloudRenderingMethod", "CloudSave", "CloudShare", "CloudSubmit", "CloudSymbol", "CloudUnshare", "CloudUserID", "ClusterClassify", "ClusterDissimilarityFunction", "ClusteringComponents", "ClusteringMeasurements", "ClusteringTree", "CMYKColor", "Coarse", "CodeAssistOptions", "Coefficient", "CoefficientArrays", "CoefficientDomain", "CoefficientList", "CoefficientRules", "CoifletWavelet", "Collect", "CollinearPoints", "Colon", "ColonForm", "ColorBalance", "ColorCombine", "ColorConvert", "ColorCoverage", "ColorData", "ColorDataFunction", "ColorDetect", "ColorDistance", "ColorFunction", "ColorFunctionBinning", "ColorFunctionScaling", "Colorize", "ColorNegate", "ColorOutput", "ColorProfileData", "ColorQ", "ColorQuantize", "ColorReplace", "ColorRules", "ColorSelectorSettings", "ColorSeparate", "ColorSetter", "ColorSetterBox", "ColorSetterBoxOptions", "ColorSlider", "ColorsNear", "ColorSpace", "ColorToneMapping", "Column", "ColumnAlignments", "ColumnBackgrounds", "ColumnForm", "ColumnLines", "ColumnsEqual", "ColumnSpacings", "ColumnWidths", "CombinatorB", "CombinatorC", "CombinatorI", "CombinatorK", "CombinatorS", "CombinatorW", "CombinatorY", "CombinedEntityClass", "CombinerFunction", "CometData", "CommonDefaultFormatTypes", "Commonest", "CommonestFilter", "CommonName", "CommonUnits", "CommunityBoundaryStyle", "CommunityGraphPlot", "CommunityLabels", "CommunityRegionStyle", "CompanyData", "CompatibleUnitQ", "CompilationOptions", "CompilationTarget", "Compile", "Compiled", "CompiledCodeFunction", "CompiledComponent", "CompiledExpressionDeclaration", "CompiledFunction", "CompiledLayer", "CompilerCallback", "CompilerEnvironment", "CompilerEnvironmentAppend", "CompilerEnvironmentAppendTo", "CompilerEnvironmentObject", "CompilerOptions", "Complement", "ComplementedEntityClass", "CompleteGraph", "CompleteGraphQ", "CompleteIntegral", "CompleteKaryTree", "CompletionsListPacket", "Complex", "ComplexArrayPlot", "ComplexContourPlot", "Complexes", "ComplexExpand", "ComplexInfinity", "ComplexityFunction", "ComplexListPlot", "ComplexPlot", "ComplexPlot3D", "ComplexRegionPlot", "ComplexStreamPlot", "ComplexVectorPlot", "ComponentMeasurements", "ComponentwiseContextMenu", "Compose", "ComposeList", "ComposeSeries", "CompositeQ", "Composition", "CompoundElement", "CompoundExpression", "CompoundPoissonDistribution", "CompoundPoissonProcess", "CompoundRenewalProcess", "Compress", "CompressedData", "CompressionLevel", "ComputeUncertainty", "ConcaveHullMesh", "Condition", "ConditionalExpression", "Conditioned", "Cone", "ConeBox", "ConfidenceLevel", "ConfidenceRange", "ConfidenceTransform", "ConfigurationPath", "Confirm", "ConfirmAssert", "ConfirmBy", "ConfirmMatch", "ConfirmQuiet", "ConformationMethod", "ConformAudio", "ConformImages", "Congruent", "ConicGradientFilling", "ConicHullRegion", "ConicHullRegion3DBox", "ConicHullRegion3DBoxOptions", "ConicHullRegionBox", "ConicHullRegionBoxOptions", "ConicOptimization", "Conjugate", "ConjugateTranspose", "Conjunction", "Connect", "ConnectedComponents", "ConnectedGraphComponents", "ConnectedGraphQ", "ConnectedMeshComponents", "ConnectedMoleculeComponents", "ConnectedMoleculeQ", "ConnectionSettings", "ConnectLibraryCallbackFunction", "ConnectSystemModelComponents", "ConnectSystemModelController", "ConnesWindow", "ConoverTest", "ConservativeConvectionPDETerm", "ConsoleMessage", "Constant", "ConstantArray", "ConstantArrayLayer", "ConstantImage", "ConstantPlusLayer", "ConstantRegionQ", "Constants", "ConstantTimesLayer", "ConstellationData", "ConstrainedMax", "ConstrainedMin", "Construct", "Containing", "ContainsAll", "ContainsAny", "ContainsExactly", "ContainsNone", "ContainsOnly", "ContentDetectorFunction", "ContentFieldOptions", "ContentLocationFunction", "ContentObject", "ContentPadding", "ContentsBoundingBox", "ContentSelectable", "ContentSize", "Context", "ContextMenu", "Contexts", "ContextToFileName", "Continuation", "Continue", "ContinuedFraction", "ContinuedFractionK", "ContinuousAction", "ContinuousMarkovProcess", "ContinuousTask", "ContinuousTimeModelQ", "ContinuousWaveletData", "ContinuousWaveletTransform", "ContourDetect", "ContourGraphics", "ContourIntegral", "ContourLabels", "ContourLines", "ContourPlot", "ContourPlot3D", "Contours", "ContourShading", "ContourSmoothing", "ContourStyle", "ContraharmonicMean", "ContrastiveLossLayer", "Control", "ControlActive", "ControlAlignment", "ControlGroupContentsBox", "ControllabilityGramian", "ControllabilityMatrix", "ControllableDecomposition", "ControllableModelQ", "ControllerDuration", "ControllerInformation", "ControllerInformationData", "ControllerLinking", "ControllerManipulate", "ControllerMethod", "ControllerPath", "ControllerState", "ControlPlacement", "ControlsRendering", "ControlType", "ConvectionPDETerm", "Convergents", "ConversionOptions", "ConversionRules", "ConvertToPostScript", "ConvertToPostScriptPacket", "ConvexHullMesh", "ConvexHullRegion", "ConvexOptimization", "ConvexPolygonQ", "ConvexPolyhedronQ", "ConvexRegionQ", "ConvolutionLayer", "Convolve", "ConwayGroupCo1", "ConwayGroupCo2", "ConwayGroupCo3", "CookieFunction", "Cookies", "CoordinateBoundingBox", "CoordinateBoundingBoxArray", "CoordinateBounds", "CoordinateBoundsArray", "CoordinateChartData", "CoordinatesToolOptions", "CoordinateTransform", "CoordinateTransformData", "CoplanarPoints", "CoprimeQ", "Coproduct", "CopulaDistribution", "Copyable", "CopyDatabin", "CopyDirectory", "CopyFile", "CopyFunction", "CopyTag", "CopyToClipboard", "CoreNilpotentDecomposition", "CornerFilter", "CornerNeighbors", "Correlation", "CorrelationDistance", "CorrelationFunction", "CorrelationTest", "Cos", "Cosh", "CoshIntegral", "CosineDistance", "CosineWindow", "CosIntegral", "Cot", "Coth", "CoulombF", "CoulombG", "CoulombH1", "CoulombH2", "Count", "CountDistinct", "CountDistinctBy", "CounterAssignments", "CounterBox", "CounterBoxOptions", "CounterClockwiseContourIntegral", "CounterEvaluator", "CounterFunction", "CounterIncrements", "CounterStyle", "CounterStyleMenuListing", "CountRoots", "CountryData", "Counts", "CountsBy", "Covariance", "CovarianceEstimatorFunction", "CovarianceFunction", "CoxianDistribution", "CoxIngersollRossProcess", "CoxModel", "CoxModelFit", "CramerVonMisesTest", "CreateArchive", "CreateCellID", "CreateChannel", "CreateCloudExpression", "CreateCompilerEnvironment", "CreateDatabin", "CreateDataStructure", "CreateDataSystemModel", "CreateDialog", "CreateDirectory", "CreateDocument", "CreateFile", "CreateIntermediateDirectories", "CreateLicenseEntitlement", "CreateManagedLibraryExpression", "CreateNotebook", "CreatePacletArchive", "CreatePalette", "CreatePermissionsGroup", "CreateScheduledTask", "CreateSearchIndex", "CreateSystemModel", "CreateTemporary", "CreateTypeInstance", "CreateUUID", "CreateWindow", "CriterionFunction", "CriticalityFailureImportance", "CriticalitySuccessImportance", "CriticalSection", "Cross", "CrossEntropyLossLayer", "CrossingCount", "CrossingDetect", "CrossingPolygon", "CrossMatrix", "Csc", "Csch", "CSGRegion", "CSGRegionQ", "CSGRegionTree", "CTCLossLayer", "Cube", "CubeRoot", "Cubics", "Cuboid", "CuboidBox", "CuboidBoxOptions", "Cumulant", "CumulantGeneratingFunction", "CumulativeFeatureImpactPlot", "Cup", "CupCap", "Curl", "CurlyDoubleQuote", "CurlyQuote", "CurrencyConvert", "CurrentDate", "CurrentImage", "CurrentNotebookImage", "CurrentScreenImage", "CurrentValue", "Curry", "CurryApplied", "CurvatureFlowFilter", "CurveClosed", "Cyan", "CycleGraph", "CycleIndexPolynomial", "Cycles", "CyclicGroup", "Cyclotomic", "Cylinder", "CylinderBox", "CylinderBoxOptions", "CylindricalDecomposition", "CylindricalDecompositionFunction", "D", "DagumDistribution", "DamData", "DamerauLevenshteinDistance", "DampingFactor", "Darker", "Dashed", "Dashing", "DatabaseConnect", "DatabaseDisconnect", "DatabaseReference", "Databin", "DatabinAdd", "DatabinRemove", "Databins", "DatabinSubmit", "DatabinUpload", "DataCompression", "DataDistribution", "DataRange", "DataReversed", "Dataset", "DatasetDisplayPanel", "DatasetTheme", "DataStructure", "DataStructureQ", "Date", "DateBounds", "Dated", "DateDelimiters", "DateDifference", "DatedUnit", "DateFormat", "DateFunction", "DateGranularity", "DateHistogram", "DateInterval", "DateList", "DateListLogPlot", "DateListPlot", "DateListStepPlot", "DateObject", "DateObjectQ", "DateOverlapsQ", "DatePattern", "DatePlus", "DateRange", "DateReduction", "DateScale", "DateSelect", "DateString", "DateTicksFormat", "DateValue", "DateWithinQ", "DaubechiesWavelet", "DavisDistribution", "DawsonF", "DayCount", "DayCountConvention", "DayHemisphere", "DaylightQ", "DayMatchQ", "DayName", "DayNightTerminator", "DayPlus", "DayRange", "DayRound", "DeBruijnGraph", "DeBruijnSequence", "Debug", "DebugTag", "Decapitalize", "Decimal", "DecimalForm", "DeclareCompiledComponent", "DeclareKnownSymbols", "DeclarePackage", "Decompose", "DeconvolutionLayer", "Decrement", "Decrypt", "DecryptFile", "DedekindEta", "DeepSpaceProbeData", "Default", "Default2DTool", "Default3DTool", "DefaultAttachedCellStyle", "DefaultAxesStyle", "DefaultBaseStyle", "DefaultBoxStyle", "DefaultButton", "DefaultColor", "DefaultControlPlacement", "DefaultDockedCellStyle", "DefaultDuplicateCellStyle", "DefaultDuration", "DefaultElement", "DefaultFaceGridsStyle", "DefaultFieldHintStyle", "DefaultFont", "DefaultFontProperties", "DefaultFormatType", "DefaultFrameStyle", "DefaultFrameTicksStyle", "DefaultGridLinesStyle", "DefaultInlineFormatType", "DefaultInputFormatType", "DefaultLabelStyle", "DefaultMenuStyle", "DefaultNaturalLanguage", "DefaultNewCellStyle", "DefaultNewInlineCellStyle", "DefaultNotebook", "DefaultOptions", "DefaultOutputFormatType", "DefaultPrintPrecision", "DefaultStyle", "DefaultStyleDefinitions", "DefaultTextFormatType", "DefaultTextInlineFormatType", "DefaultTicksStyle", "DefaultTooltipStyle", "DefaultValue", "DefaultValues", "Defer", "DefineExternal", "DefineInputStreamMethod", "DefineOutputStreamMethod", "DefineResourceFunction", "Definition", "Degree", "DegreeCentrality", "DegreeGraphDistribution", "DegreeLexicographic", "DegreeReverseLexicographic", "DEigensystem", "DEigenvalues", "Deinitialization", "Del", "DelaunayMesh", "Delayed", "Deletable", "Delete", "DeleteAdjacentDuplicates", "DeleteAnomalies", "DeleteBorderComponents", "DeleteCases", "DeleteChannel", "DeleteCloudExpression", "DeleteContents", "DeleteDirectory", "DeleteDuplicates", "DeleteDuplicatesBy", "DeleteElements", "DeleteFile", "DeleteMissing", "DeleteObject", "DeletePermissionsKey", "DeleteSearchIndex", "DeleteSmallComponents", "DeleteStopwords", "DeleteWithContents", "DeletionWarning", "DelimitedArray", "DelimitedSequence", "Delimiter", "DelimiterAutoMatching", "DelimiterFlashTime", "DelimiterMatching", "Delimiters", "DeliveryFunction", "Dendrogram", "Denominator", "DensityGraphics", "DensityHistogram", "DensityPlot", "DensityPlot3D", "DependentVariables", "Deploy", "Deployed", "Depth", "DepthFirstScan", "Derivative", "DerivativeFilter", "DerivativePDETerm", "DerivedKey", "DescriptorStateSpace", "DesignMatrix", "DestroyAfterEvaluation", "Det", "DeviceClose", "DeviceConfigure", "DeviceExecute", "DeviceExecuteAsynchronous", "DeviceObject", "DeviceOpen", "DeviceOpenQ", "DeviceRead", "DeviceReadBuffer", "DeviceReadLatest", "DeviceReadList", "DeviceReadTimeSeries", "Devices", "DeviceStreams", "DeviceWrite", "DeviceWriteBuffer", "DGaussianWavelet", "DiacriticalPositioning", "Diagonal", "DiagonalizableMatrixQ", "DiagonalMatrix", "DiagonalMatrixQ", "Dialog", "DialogIndent", "DialogInput", "DialogLevel", "DialogNotebook", "DialogProlog", "DialogReturn", "DialogSymbols", "Diamond", "DiamondMatrix", "DiceDissimilarity", "DictionaryLookup", "DictionaryWordQ", "DifferenceDelta", "DifferenceOrder", "DifferenceQuotient", "DifferenceRoot", "DifferenceRootReduce", "Differences", "DifferentialD", "DifferentialRoot", "DifferentialRootReduce", "DifferentiatorFilter", "DiffusionPDETerm", "DiggleGatesPointProcess", "DiggleGrattonPointProcess", "DigitalSignature", "DigitBlock", "DigitBlockMinimum", "DigitCharacter", "DigitCount", "DigitQ", "DihedralAngle", "DihedralGroup", "Dilation", "DimensionalCombinations", "DimensionalMeshComponents", "DimensionReduce", "DimensionReducerFunction", "DimensionReduction", "Dimensions", "DiracComb", "DiracDelta", "DirectedEdge", "DirectedEdges", "DirectedGraph", "DirectedGraphQ", "DirectedInfinity", "Direction", "DirectionalLight", "Directive", "Directory", "DirectoryName", "DirectoryQ", "DirectoryStack", "DirichletBeta", "DirichletCharacter", "DirichletCondition", "DirichletConvolve", "DirichletDistribution", "DirichletEta", "DirichletL", "DirichletLambda", "DirichletTransform", "DirichletWindow", "DisableConsolePrintPacket", "DisableFormatting", "DiscreteAsymptotic", "DiscreteChirpZTransform", "DiscreteConvolve", "DiscreteDelta", "DiscreteHadamardTransform", "DiscreteIndicator", "DiscreteInputOutputModel", "DiscreteLimit", "DiscreteLQEstimatorGains", "DiscreteLQRegulatorGains", "DiscreteLyapunovSolve", "DiscreteMarkovProcess", "DiscreteMaxLimit", "DiscreteMinLimit", "DiscretePlot", "DiscretePlot3D", "DiscreteRatio", "DiscreteRiccatiSolve", "DiscreteShift", "DiscreteTimeModelQ", "DiscreteUniformDistribution", "DiscreteVariables", "DiscreteWaveletData", "DiscreteWaveletPacketTransform", "DiscreteWaveletTransform", "DiscretizeGraphics", "DiscretizeRegion", "Discriminant", "DisjointQ", "Disjunction", "Disk", "DiskBox", "DiskBoxOptions", "DiskMatrix", "DiskSegment", "Dispatch", "DispatchQ", "DispersionEstimatorFunction", "Display", "DisplayAllSteps", "DisplayEndPacket", "DisplayForm", "DisplayFunction", "DisplayPacket", "DisplayRules", "DisplayString", "DisplayTemporary", "DisplayWith", "DisplayWithRef", "DisplayWithVariable", "DistanceFunction", "DistanceMatrix", "DistanceTransform", "Distribute", "Distributed", "DistributedContexts", "DistributeDefinitions", "DistributionChart", "DistributionDomain", "DistributionFitTest", "DistributionParameterAssumptions", "DistributionParameterQ", "Dithering", "Div", "Divergence", "Divide", "DivideBy", "Dividers", "DivideSides", "Divisible", "Divisors", "DivisorSigma", "DivisorSum", "DMSList", "DMSString", "Do", "DockedCell", "DockedCells", "DocumentGenerator", "DocumentGeneratorInformation", "DocumentGeneratorInformationData", "DocumentGenerators", "DocumentNotebook", "DocumentWeightingRules", "Dodecahedron", "DomainRegistrationInformation", "DominantColors", "DominatorTreeGraph", "DominatorVertexList", "DOSTextFormat", "Dot", "DotDashed", "DotEqual", "DotLayer", "DotPlusLayer", "Dotted", "DoubleBracketingBar", "DoubleContourIntegral", "DoubleDownArrow", "DoubleLeftArrow", "DoubleLeftRightArrow", "DoubleLeftTee", "DoubleLongLeftArrow", "DoubleLongLeftRightArrow", "DoubleLongRightArrow", "DoubleRightArrow", "DoubleRightTee", "DoubleUpArrow", "DoubleUpDownArrow", "DoubleVerticalBar", "DoublyInfinite", "Down", "DownArrow", "DownArrowBar", "DownArrowUpArrow", "DownLeftRightVector", "DownLeftTeeVector", "DownLeftVector", "DownLeftVectorBar", "DownRightTeeVector", "DownRightVector", "DownRightVectorBar", "Downsample", "DownTee", "DownTeeArrow", "DownValues", "DownValuesFunction", "DragAndDrop", "DrawBackFaces", "DrawEdges", "DrawFrontFaces", "DrawHighlighted", "DrazinInverse", "Drop", "DropoutLayer", "DropShadowing", "DSolve", "DSolveChangeVariables", "DSolveValue", "Dt", "DualLinearProgramming", "DualPlanarGraph", "DualPolyhedron", "DualSystemsModel", "DumpGet", "DumpSave", "DuplicateFreeQ", "Duration", "Dynamic", "DynamicBox", "DynamicBoxOptions", "DynamicEvaluationTimeout", "DynamicGeoGraphics", "DynamicImage", "DynamicLocation", "DynamicModule", "DynamicModuleBox", "DynamicModuleBoxOptions", "DynamicModuleParent", "DynamicModuleValues", "DynamicName", "DynamicNamespace", "DynamicReference", "DynamicSetting", "DynamicUpdating", "DynamicWrapper", "DynamicWrapperBox", "DynamicWrapperBoxOptions", "E", "EarthImpactData", "EarthquakeData", "EccentricityCentrality", "Echo", "EchoEvaluation", "EchoFunction", "EchoLabel", "EchoTiming", "EclipseType", "EdgeAdd", "EdgeBetweennessCentrality", "EdgeCapacity", "EdgeCapForm", "EdgeChromaticNumber", "EdgeColor", "EdgeConnectivity", "EdgeContract", "EdgeCost", "EdgeCount", "EdgeCoverQ", "EdgeCycleMatrix", "EdgeDashing", "EdgeDelete", "EdgeDetect", "EdgeForm", "EdgeIndex", "EdgeJoinForm", "EdgeLabeling", "EdgeLabels", "EdgeLabelStyle", "EdgeList", "EdgeOpacity", "EdgeQ", "EdgeRenderingFunction", "EdgeRules", "EdgeShapeFunction", "EdgeStyle", "EdgeTaggedGraph", "EdgeTaggedGraphQ", "EdgeTags", "EdgeThickness", "EdgeTransitiveGraphQ", "EdgeValueRange", "EdgeValueSizes", "EdgeWeight", "EdgeWeightedGraphQ", "Editable", "EditButtonSettings", "EditCellTagsSettings", "EditDistance", "EffectiveInterest", "Eigensystem", "Eigenvalues", "EigenvectorCentrality", "Eigenvectors", "Element", "ElementData", "ElementwiseLayer", "ElidedForms", "Eliminate", "EliminationOrder", "Ellipsoid", "EllipticE", "EllipticExp", "EllipticExpPrime", "EllipticF", "EllipticFilterModel", "EllipticK", "EllipticLog", "EllipticNomeQ", "EllipticPi", "EllipticReducedHalfPeriods", "EllipticTheta", "EllipticThetaPrime", "EmbedCode", "EmbeddedHTML", "EmbeddedService", "EmbeddedSQLEntityClass", "EmbeddedSQLExpression", "EmbeddingLayer", "EmbeddingObject", "EmitSound", "EmphasizeSyntaxErrors", "EmpiricalDistribution", "Empty", "EmptyGraphQ", "EmptyRegion", "EmptySpaceF", "EnableConsolePrintPacket", "Enabled", "Enclose", "Encode", "Encrypt", "EncryptedObject", "EncryptFile", "End", "EndAdd", "EndDialogPacket", "EndOfBuffer", "EndOfFile", "EndOfLine", "EndOfString", "EndPackage", "EngineEnvironment", "EngineeringForm", "Enter", "EnterExpressionPacket", "EnterTextPacket", "Entity", "EntityClass", "EntityClassList", "EntityCopies", "EntityFunction", "EntityGroup", "EntityInstance", "EntityList", "EntityPrefetch", "EntityProperties", "EntityProperty", "EntityPropertyClass", "EntityRegister", "EntityStore", "EntityStores", "EntityTypeName", "EntityUnregister", "EntityValue", "Entropy", "EntropyFilter", "Environment", "Epilog", "EpilogFunction", "Equal", "EqualColumns", "EqualRows", "EqualTilde", "EqualTo", "EquatedTo", "Equilibrium", "EquirippleFilterKernel", "Equivalent", "Erf", "Erfc", "Erfi", "ErlangB", "ErlangC", "ErlangDistribution", "Erosion", "ErrorBox", "ErrorBoxOptions", "ErrorNorm", "ErrorPacket", "ErrorsDialogSettings", "EscapeRadius", "EstimatedBackground", "EstimatedDistribution", "EstimatedPointNormals", "EstimatedPointProcess", "EstimatedProcess", "EstimatedVariogramModel", "EstimatorGains", "EstimatorRegulator", "EuclideanDistance", "EulerAngles", "EulerCharacteristic", "EulerE", "EulerGamma", "EulerianGraphQ", "EulerMatrix", "EulerPhi", "Evaluatable", "Evaluate", "Evaluated", "EvaluatePacket", "EvaluateScheduledTask", "EvaluationBox", "EvaluationCell", "EvaluationCompletionAction", "EvaluationData", "EvaluationElements", "EvaluationEnvironment", "EvaluationMode", "EvaluationMonitor", "EvaluationNotebook", "EvaluationObject", "EvaluationOrder", "EvaluationPrivileges", "EvaluationRateLimit", "Evaluator", "EvaluatorNames", "EvenQ", "EventData", "EventEvaluator", "EventHandler", "EventHandlerTag", "EventLabels", "EventSeries", "ExactBlackmanWindow", "ExactNumberQ", "ExactRootIsolation", "ExampleData", "Except", "ExcludedContexts", "ExcludedForms", "ExcludedLines", "ExcludedPhysicalQuantities", "ExcludePods", "Exclusions", "ExclusionsStyle", "Exists", "Exit", "ExitDialog", "ExoplanetData", "Exp", "Expand", "ExpandAll", "ExpandDenominator", "ExpandFileName", "ExpandNumerator", "Expectation", "ExpectationE", "ExpectedValue", "ExpGammaDistribution", "ExpIntegralE", "ExpIntegralEi", "ExpirationDate", "Exponent", "ExponentFunction", "ExponentialDistribution", "ExponentialFamily", "ExponentialGeneratingFunction", "ExponentialMovingAverage", "ExponentialPowerDistribution", "ExponentPosition", "ExponentStep", "Export", "ExportAutoReplacements", "ExportByteArray", "ExportForm", "ExportPacket", "ExportString", "Expression", "ExpressionCell", "ExpressionGraph", "ExpressionPacket", "ExpressionTree", "ExpressionUUID", "ExpToTrig", "ExtendedEntityClass", "ExtendedGCD", "Extension", "ExtentElementFunction", "ExtentMarkers", "ExtentSize", "ExternalBundle", "ExternalCall", "ExternalDataCharacterEncoding", "ExternalEvaluate", "ExternalFunction", "ExternalFunctionName", "ExternalIdentifier", "ExternalObject", "ExternalOptions", "ExternalSessionObject", "ExternalSessions", "ExternalStorageBase", "ExternalStorageDownload", "ExternalStorageGet", "ExternalStorageObject", "ExternalStoragePut", "ExternalStorageUpload", "ExternalTypeSignature", "ExternalValue", "Extract", "ExtractArchive", "ExtractLayer", "ExtractPacletArchive", "ExtremeValueDistribution", "FaceAlign", "FaceForm", "FaceGrids", "FaceGridsStyle", "FaceRecognize", "FacialFeatures", "Factor", "FactorComplete", "Factorial", "Factorial2", "FactorialMoment", "FactorialMomentGeneratingFunction", "FactorialPower", "FactorInteger", "FactorList", "FactorSquareFree", "FactorSquareFreeList", "FactorTerms", "FactorTermsList", "Fail", "Failure", "FailureAction", "FailureDistribution", "FailureQ", "False", "FareySequence", "FARIMAProcess", "FeatureDistance", "FeatureExtract", "FeatureExtraction", "FeatureExtractor", "FeatureExtractorFunction", "FeatureImpactPlot", "FeatureNames", "FeatureNearest", "FeatureSpacePlot", "FeatureSpacePlot3D", "FeatureTypes", "FeatureValueDependencyPlot", "FeatureValueImpactPlot", "FEDisableConsolePrintPacket", "FeedbackLinearize", "FeedbackSector", "FeedbackSectorStyle", "FeedbackType", "FEEnableConsolePrintPacket", "FetalGrowthData", "Fibonacci", "Fibonorial", "FieldCompletionFunction", "FieldHint", "FieldHintStyle", "FieldMasked", "FieldSize", "File", "FileBaseName", "FileByteCount", "FileConvert", "FileDate", "FileExistsQ", "FileExtension", "FileFormat", "FileFormatProperties", "FileFormatQ", "FileHandler", "FileHash", "FileInformation", "FileName", "FileNameDepth", "FileNameDialogSettings", "FileNameDrop", "FileNameForms", "FileNameJoin", "FileNames", "FileNameSetter", "FileNameSplit", "FileNameTake", "FileNameToFormatList", "FilePrint", "FileSize", "FileSystemMap", "FileSystemScan", "FileSystemTree", "FileTemplate", "FileTemplateApply", "FileType", "FilledCurve", "FilledCurveBox", "FilledCurveBoxOptions", "FilledTorus", "FillForm", "Filling", "FillingStyle", "FillingTransform", "FilteredEntityClass", "FilterRules", "FinancialBond", "FinancialData", "FinancialDerivative", "FinancialIndicator", "Find", "FindAnomalies", "FindArgMax", "FindArgMin", "FindChannels", "FindClique", "FindClusters", "FindCookies", "FindCurvePath", "FindCycle", "FindDevices", "FindDistribution", "FindDistributionParameters", "FindDivisions", "FindEdgeColoring", "FindEdgeCover", "FindEdgeCut", "FindEdgeIndependentPaths", "FindEquationalProof", "FindEulerianCycle", "FindExternalEvaluators", "FindFaces", "FindFile", "FindFit", "FindFormula", "FindFundamentalCycles", "FindGeneratingFunction", "FindGeoLocation", "FindGeometricConjectures", "FindGeometricTransform", "FindGraphCommunities", "FindGraphIsomorphism", "FindGraphPartition", "FindHamiltonianCycle", "FindHamiltonianPath", "FindHiddenMarkovStates", "FindImageText", "FindIndependentEdgeSet", "FindIndependentVertexSet", "FindInstance", "FindIntegerNullVector", "FindIsomers", "FindIsomorphicSubgraph", "FindKClan", "FindKClique", "FindKClub", "FindKPlex", "FindLibrary", "FindLinearRecurrence", "FindList", "FindMatchingColor", "FindMaximum", "FindMaximumCut", "FindMaximumFlow", "FindMaxValue", "FindMeshDefects", "FindMinimum", "FindMinimumCostFlow", "FindMinimumCut", "FindMinValue", "FindMoleculeSubstructure", "FindPath", "FindPeaks", "FindPermutation", "FindPlanarColoring", "FindPointProcessParameters", "FindPostmanTour", "FindProcessParameters", "FindRegionTransform", "FindRepeat", "FindRoot", "FindSequenceFunction", "FindSettings", "FindShortestPath", "FindShortestTour", "FindSpanningTree", "FindSubgraphIsomorphism", "FindSystemModelEquilibrium", "FindTextualAnswer", "FindThreshold", "FindTransientRepeat", "FindVertexColoring", "FindVertexCover", "FindVertexCut", "FindVertexIndependentPaths", "Fine", "FinishDynamic", "FiniteAbelianGroupCount", "FiniteGroupCount", "FiniteGroupData", "First", "FirstCase", "FirstPassageTimeDistribution", "FirstPosition", "FischerGroupFi22", "FischerGroupFi23", "FischerGroupFi24Prime", "FisherHypergeometricDistribution", "FisherRatioTest", "FisherZDistribution", "Fit", "FitAll", "FitRegularization", "FittedModel", "FixedOrder", "FixedPoint", "FixedPointList", "FlashSelection", "Flat", "FlatShading", "Flatten", "FlattenAt", "FlattenLayer", "FlatTopWindow", "FlightData", "FlipView", "Floor", "FlowPolynomial", "Fold", "FoldList", "FoldPair", "FoldPairList", "FoldWhile", "FoldWhileList", "FollowRedirects", "Font", "FontColor", "FontFamily", "FontForm", "FontName", "FontOpacity", "FontPostScriptName", "FontProperties", "FontReencoding", "FontSize", "FontSlant", "FontSubstitutions", "FontTracking", "FontVariations", "FontWeight", "For", "ForAll", "ForAllType", "ForceVersionInstall", "Format", "FormatRules", "FormatType", "FormatTypeAutoConvert", "FormatValues", "FormBox", "FormBoxOptions", "FormControl", "FormFunction", "FormLayoutFunction", "FormObject", "FormPage", "FormProtectionMethod", "FormTheme", "FormulaData", "FormulaLookup", "FortranForm", "Forward", "ForwardBackward", "ForwardCloudCredentials", "Fourier", "FourierCoefficient", "FourierCosCoefficient", "FourierCosSeries", "FourierCosTransform", "FourierDCT", "FourierDCTFilter", "FourierDCTMatrix", "FourierDST", "FourierDSTMatrix", "FourierMatrix", "FourierParameters", "FourierSequenceTransform", "FourierSeries", "FourierSinCoefficient", "FourierSinSeries", "FourierSinTransform", "FourierTransform", "FourierTrigSeries", "FoxH", "FoxHReduce", "FractionalBrownianMotionProcess", "FractionalD", "FractionalGaussianNoiseProcess", "FractionalPart", "FractionBox", "FractionBoxOptions", "FractionLine", "Frame", "FrameBox", "FrameBoxOptions", "Framed", "FrameInset", "FrameLabel", "Frameless", "FrameListVideo", "FrameMargins", "FrameRate", "FrameStyle", "FrameTicks", "FrameTicksStyle", "FRatioDistribution", "FrechetDistribution", "FreeQ", "FrenetSerretSystem", "FrequencySamplingFilterKernel", "FresnelC", "FresnelF", "FresnelG", "FresnelS", "Friday", "FrobeniusNumber", "FrobeniusSolve", "FromAbsoluteTime", "FromCharacterCode", "FromCoefficientRules", "FromContinuedFraction", "FromDate", "FromDateString", "FromDigits", "FromDMS", "FromEntity", "FromJulianDate", "FromLetterNumber", "FromPolarCoordinates", "FromRawPointer", "FromRomanNumeral", "FromSphericalCoordinates", "FromUnixTime", "Front", "FrontEndDynamicExpression", "FrontEndEventActions", "FrontEndExecute", "FrontEndObject", "FrontEndResource", "FrontEndResourceString", "FrontEndStackSize", "FrontEndToken", "FrontEndTokenExecute", "FrontEndValueCache", "FrontEndVersion", "FrontFaceColor", "FrontFaceGlowColor", "FrontFaceOpacity", "FrontFaceSpecularColor", "FrontFaceSpecularExponent", "FrontFaceSurfaceAppearance", "FrontFaceTexture", "Full", "FullAxes", "FullDefinition", "FullForm", "FullGraphics", "FullInformationOutputRegulator", "FullOptions", "FullRegion", "FullSimplify", "Function", "FunctionAnalytic", "FunctionBijective", "FunctionCompile", "FunctionCompileExport", "FunctionCompileExportByteArray", "FunctionCompileExportLibrary", "FunctionCompileExportString", "FunctionContinuous", "FunctionConvexity", "FunctionDeclaration", "FunctionDiscontinuities", "FunctionDomain", "FunctionExpand", "FunctionInjective", "FunctionInterpolation", "FunctionLayer", "FunctionMeromorphic", "FunctionMonotonicity", "FunctionPeriod", "FunctionPoles", "FunctionRange", "FunctionSign", "FunctionSingularities", "FunctionSpace", "FunctionSurjective", "FussellVeselyImportance", "GaborFilter", "GaborMatrix", "GaborWavelet", "GainMargins", "GainPhaseMargins", "GalaxyData", "GalleryView", "Gamma", "GammaDistribution", "GammaRegularized", "GapPenalty", "GARCHProcess", "GatedRecurrentLayer", "Gather", "GatherBy", "GaugeFaceElementFunction", "GaugeFaceStyle", "GaugeFrameElementFunction", "GaugeFrameSize", "GaugeFrameStyle", "GaugeLabels", "GaugeMarkers", "GaugeStyle", "GaussianFilter", "GaussianIntegers", "GaussianMatrix", "GaussianOrthogonalMatrixDistribution", "GaussianSymplecticMatrixDistribution", "GaussianUnitaryMatrixDistribution", "GaussianWindow", "GCD", "GegenbauerC", "General", "GeneralizedLinearModelFit", "GenerateAsymmetricKeyPair", "GenerateConditions", "GeneratedAssetFormat", "GeneratedAssetLocation", "GeneratedCell", "GeneratedCellStyles", "GeneratedDocumentBinding", "GenerateDerivedKey", "GenerateDigitalSignature", "GenerateDocument", "GeneratedParameters", "GeneratedQuantityMagnitudes", "GenerateFileSignature", "GenerateHTTPResponse", "GenerateSecuredAuthenticationKey", "GenerateSymmetricKey", "GeneratingFunction", "GeneratorDescription", "GeneratorHistoryLength", "GeneratorOutputType", "Generic", "GenericCylindricalDecomposition", "GenomeData", "GenomeLookup", "GeoAntipode", "GeoArea", "GeoArraySize", "GeoBackground", "GeoBoundary", "GeoBoundingBox", "GeoBounds", "GeoBoundsRegion", "GeoBoundsRegionBoundary", "GeoBubbleChart", "GeoCenter", "GeoCircle", "GeoContourPlot", "GeoDensityPlot", "GeodesicClosing", "GeodesicDilation", "GeodesicErosion", "GeodesicOpening", "GeodesicPolyhedron", "GeoDestination", "GeodesyData", "GeoDirection", "GeoDisk", "GeoDisplacement", "GeoDistance", "GeoDistanceList", "GeoElevationData", "GeoEntities", "GeoGraphics", "GeoGraphPlot", "GeoGraphValuePlot", "GeogravityModelData", "GeoGridDirectionDifference", "GeoGridLines", "GeoGridLinesStyle", "GeoGridPosition", "GeoGridRange", "GeoGridRangePadding", "GeoGridUnitArea", "GeoGridUnitDistance", "GeoGridVector", "GeoGroup", "GeoHemisphere", "GeoHemisphereBoundary", "GeoHistogram", "GeoIdentify", "GeoImage", "GeoLabels", "GeoLength", "GeoListPlot", "GeoLocation", "GeologicalPeriodData", "GeomagneticModelData", "GeoMarker", "GeometricAssertion", "GeometricBrownianMotionProcess", "GeometricDistribution", "GeometricMean", "GeometricMeanFilter", "GeometricOptimization", "GeometricScene", "GeometricStep", "GeometricStylingRules", "GeometricTest", "GeometricTransformation", "GeometricTransformation3DBox", "GeometricTransformation3DBoxOptions", "GeometricTransformationBox", "GeometricTransformationBoxOptions", "GeoModel", "GeoNearest", "GeoOrientationData", "GeoPath", "GeoPolygon", "GeoPosition", "GeoPositionENU", "GeoPositionXYZ", "GeoProjection", "GeoProjectionData", "GeoRange", "GeoRangePadding", "GeoRegionValuePlot", "GeoResolution", "GeoScaleBar", "GeoServer", "GeoSmoothHistogram", "GeoStreamPlot", "GeoStyling", "GeoStylingImageFunction", "GeoVariant", "GeoVector", "GeoVectorENU", "GeoVectorPlot", "GeoVectorXYZ", "GeoVisibleRegion", "GeoVisibleRegionBoundary", "GeoWithinQ", "GeoZoomLevel", "GestureHandler", "GestureHandlerTag", "Get", "GetContext", "GetEnvironment", "GetFileName", "GetLinebreakInformationPacket", "GibbsPointProcess", "Glaisher", "GlobalClusteringCoefficient", "GlobalPreferences", "GlobalSession", "Glow", "GoldenAngle", "GoldenRatio", "GompertzMakehamDistribution", "GoochShading", "GoodmanKruskalGamma", "GoodmanKruskalGammaTest", "Goto", "GouraudShading", "Grad", "Gradient", "GradientFilter", "GradientFittedMesh", "GradientOrientationFilter", "GrammarApply", "GrammarRules", "GrammarToken", "Graph", "Graph3D", "GraphAssortativity", "GraphAutomorphismGroup", "GraphCenter", "GraphComplement", "GraphData", "GraphDensity", "GraphDiameter", "GraphDifference", "GraphDisjointUnion", "GraphDistance", "GraphDistanceMatrix", "GraphEmbedding", "GraphHighlight", "GraphHighlightStyle", "GraphHub", "Graphics", "Graphics3D", "Graphics3DBox", "Graphics3DBoxOptions", "GraphicsArray", "GraphicsBaseline", "GraphicsBox", "GraphicsBoxOptions", "GraphicsColor", "GraphicsColumn", "GraphicsComplex", "GraphicsComplex3DBox", "GraphicsComplex3DBoxOptions", "GraphicsComplexBox", "GraphicsComplexBoxOptions", "GraphicsContents", "GraphicsData", "GraphicsGrid", "GraphicsGridBox", "GraphicsGroup", "GraphicsGroup3DBox", "GraphicsGroup3DBoxOptions", "GraphicsGroupBox", "GraphicsGroupBoxOptions", "GraphicsGrouping", "GraphicsHighlightColor", "GraphicsRow", "GraphicsSpacing", "GraphicsStyle", "GraphIntersection", "GraphJoin", "GraphLayerLabels", "GraphLayers", "GraphLayerStyle", "GraphLayout", "GraphLinkEfficiency", "GraphPeriphery", "GraphPlot", "GraphPlot3D", "GraphPower", "GraphProduct", "GraphPropertyDistribution", "GraphQ", "GraphRadius", "GraphReciprocity", "GraphRoot", "GraphStyle", "GraphSum", "GraphTree", "GraphUnion", "Gray", "GrayLevel", "Greater", "GreaterEqual", "GreaterEqualLess", "GreaterEqualThan", "GreaterFullEqual", "GreaterGreater", "GreaterLess", "GreaterSlantEqual", "GreaterThan", "GreaterTilde", "GreekStyle", "Green", "GreenFunction", "Grid", "GridBaseline", "GridBox", "GridBoxAlignment", "GridBoxBackground", "GridBoxDividers", "GridBoxFrame", "GridBoxItemSize", "GridBoxItemStyle", "GridBoxOptions", "GridBoxSpacings", "GridCreationSettings", "GridDefaultElement", "GridElementStyleOptions", "GridFrame", "GridFrameMargins", "GridGraph", "GridLines", "GridLinesStyle", "GridVideo", "GroebnerBasis", "GroupActionBase", "GroupBy", "GroupCentralizer", "GroupElementFromWord", "GroupElementPosition", "GroupElementQ", "GroupElements", "GroupElementToWord", "GroupGenerators", "Groupings", "GroupMultiplicationTable", "GroupOpenerColor", "GroupOpenerInsideFrame", "GroupOrbits", "GroupOrder", "GroupPageBreakWithin", "GroupSetwiseStabilizer", "GroupStabilizer", "GroupStabilizerChain", "GroupTogetherGrouping", "GroupTogetherNestedGrouping", "GrowCutComponents", "Gudermannian", "GuidedFilter", "GumbelDistribution", "HaarWavelet", "HadamardMatrix", "HalfLine", "HalfNormalDistribution", "HalfPlane", "HalfSpace", "HalftoneShading", "HamiltonianGraphQ", "HammingDistance", "HammingWindow", "HandlerFunctions", "HandlerFunctionsKeys", "HankelH1", "HankelH2", "HankelMatrix", "HankelTransform", "HannPoissonWindow", "HannWindow", "HaradaNortonGroupHN", "HararyGraph", "HardcorePointProcess", "HarmonicMean", "HarmonicMeanFilter", "HarmonicNumber", "Hash", "HatchFilling", "HatchShading", "Haversine", "HazardFunction", "Head", "HeadCompose", "HeaderAlignment", "HeaderBackground", "HeaderDisplayFunction", "HeaderLines", "Headers", "HeaderSize", "HeaderStyle", "Heads", "HeatFluxValue", "HeatInsulationValue", "HeatOutflowValue", "HeatRadiationValue", "HeatSymmetryValue", "HeatTemperatureCondition", "HeatTransferPDEComponent", "HeatTransferValue", "HeavisideLambda", "HeavisidePi", "HeavisideTheta", "HeldGroupHe", "HeldPart", "HelmholtzPDEComponent", "HelpBrowserLookup", "HelpBrowserNotebook", "HelpBrowserSettings", "HelpViewerSettings", "Here", "HermiteDecomposition", "HermiteH", "Hermitian", "HermitianMatrixQ", "HessenbergDecomposition", "Hessian", "HeunB", "HeunBPrime", "HeunC", "HeunCPrime", "HeunD", "HeunDPrime", "HeunG", "HeunGPrime", "HeunT", "HeunTPrime", "HexadecimalCharacter", "Hexahedron", "HexahedronBox", "HexahedronBoxOptions", "HiddenItems", "HiddenMarkovProcess", "HiddenSurface", "Highlighted", "HighlightGraph", "HighlightImage", "HighlightMesh", "HighlightString", "HighpassFilter", "HigmanSimsGroupHS", "HilbertCurve", "HilbertFilter", "HilbertMatrix", "Histogram", "Histogram3D", "HistogramDistribution", "HistogramList", "HistogramPointDensity", "HistogramTransform", "HistogramTransformInterpolation", "HistoricalPeriodData", "HitMissTransform", "HITSCentrality", "HjorthDistribution", "HodgeDual", "HoeffdingD", "HoeffdingDTest", "Hold", "HoldAll", "HoldAllComplete", "HoldComplete", "HoldFirst", "HoldForm", "HoldPattern", "HoldRest", "HolidayCalendar", "HomeDirectory", "HomePage", "Horizontal", "HorizontalForm", "HorizontalGauge", "HorizontalScrollPosition", "HornerForm", "HostLookup", "HotellingTSquareDistribution", "HoytDistribution", "HTMLSave", "HTTPErrorResponse", "HTTPRedirect", "HTTPRequest", "HTTPRequestData", "HTTPResponse", "Hue", "HumanGrowthData", "HumpDownHump", "HumpEqual", "HurwitzLerchPhi", "HurwitzZeta", "HyperbolicDistribution", "HypercubeGraph", "HyperexponentialDistribution", "Hyperfactorial", "Hypergeometric0F1", "Hypergeometric0F1Regularized", "Hypergeometric1F1", "Hypergeometric1F1Regularized", "Hypergeometric2F1", "Hypergeometric2F1Regularized", "HypergeometricDistribution", "HypergeometricPFQ", "HypergeometricPFQRegularized", "HypergeometricU", "Hyperlink", "HyperlinkAction", "HyperlinkCreationSettings", "Hyperplane", "Hyphenation", "HyphenationOptions", "HypoexponentialDistribution", "HypothesisTestData", "I", "IconData", "Iconize", "IconizedObject", "IconRules", "Icosahedron", "Identity", "IdentityMatrix", "If", "IfCompiled", "IgnoreCase", "IgnoreDiacritics", "IgnoreIsotopes", "IgnorePunctuation", "IgnoreSpellCheck", "IgnoreStereochemistry", "IgnoringInactive", "Im", "Image", "Image3D", "Image3DProjection", "Image3DSlices", "ImageAccumulate", "ImageAdd", "ImageAdjust", "ImageAlign", "ImageApply", "ImageApplyIndexed", "ImageAspectRatio", "ImageAssemble", "ImageAugmentationLayer", "ImageBoundingBoxes", "ImageCache", "ImageCacheValid", "ImageCapture", "ImageCaptureFunction", "ImageCases", "ImageChannels", "ImageClip", "ImageCollage", "ImageColorSpace", "ImageCompose", "ImageContainsQ", "ImageContents", "ImageConvolve", "ImageCooccurrence", "ImageCorners", "ImageCorrelate", "ImageCorrespondingPoints", "ImageCrop", "ImageData", "ImageDeconvolve", "ImageDemosaic", "ImageDifference", "ImageDimensions", "ImageDisplacements", "ImageDistance", "ImageEditMode", "ImageEffect", "ImageExposureCombine", "ImageFeatureTrack", "ImageFileApply", "ImageFileFilter", "ImageFileScan", "ImageFilter", "ImageFocusCombine", "ImageForestingComponents", "ImageFormattingWidth", "ImageForwardTransformation", "ImageGraphics", "ImageHistogram", "ImageIdentify", "ImageInstanceQ", "ImageKeypoints", "ImageLabels", "ImageLegends", "ImageLevels", "ImageLines", "ImageMargins", "ImageMarker", "ImageMarkers", "ImageMeasurements", "ImageMesh", "ImageMultiply", "ImageOffset", "ImagePad", "ImagePadding", "ImagePartition", "ImagePeriodogram", "ImagePerspectiveTransformation", "ImagePosition", "ImagePreviewFunction", "ImagePyramid", "ImagePyramidApply", "ImageQ", "ImageRangeCache", "ImageRecolor", "ImageReflect", "ImageRegion", "ImageResize", "ImageResolution", "ImageRestyle", "ImageRotate", "ImageRotated", "ImageSaliencyFilter", "ImageScaled", "ImageScan", "ImageSize", "ImageSizeAction", "ImageSizeCache", "ImageSizeMultipliers", "ImageSizeRaw", "ImageStitch", "ImageSubtract", "ImageTake", "ImageTransformation", "ImageTrim", "ImageType", "ImageValue", "ImageValuePositions", "ImageVectorscopePlot", "ImageWaveformPlot", "ImagingDevice", "ImplicitD", "ImplicitRegion", "Implies", "Import", "ImportAutoReplacements", "ImportByteArray", "ImportedObject", "ImportOptions", "ImportString", "ImprovementImportance", "In", "Inactivate", "Inactive", "InactiveStyle", "IncidenceGraph", "IncidenceList", "IncidenceMatrix", "IncludeAromaticBonds", "IncludeConstantBasis", "IncludedContexts", "IncludeDefinitions", "IncludeDirectories", "IncludeFileExtension", "IncludeGeneratorTasks", "IncludeHydrogens", "IncludeInflections", "IncludeMetaInformation", "IncludePods", "IncludeQuantities", "IncludeRelatedTables", "IncludeSingularSolutions", "IncludeSingularTerm", "IncludeWindowTimes", "Increment", "IndefiniteMatrixQ", "Indent", "IndentingNewlineSpacings", "IndentMaxFraction", "IndependenceTest", "IndependentEdgeSetQ", "IndependentPhysicalQuantity", "IndependentUnit", "IndependentUnitDimension", "IndependentVertexSetQ", "Indeterminate", "IndeterminateThreshold", "IndexCreationOptions", "Indexed", "IndexEdgeTaggedGraph", "IndexGraph", "IndexTag", "Inequality", "InertEvaluate", "InertExpression", "InexactNumberQ", "InexactNumbers", "InfiniteFuture", "InfiniteLine", "InfiniteLineThrough", "InfinitePast", "InfinitePlane", "Infinity", "Infix", "InflationAdjust", "InflationMethod", "Information", "InformationData", "InformationDataGrid", "Inherited", "InheritScope", "InhomogeneousPoissonPointProcess", "InhomogeneousPoissonProcess", "InitialEvaluationHistory", "Initialization", "InitializationCell", "InitializationCellEvaluation", "InitializationCellWarning", "InitializationObject", "InitializationObjects", "InitializationValue", "Initialize", "InitialSeeding", "InlineCounterAssignments", "InlineCounterIncrements", "InlineRules", "Inner", "InnerPolygon", "InnerPolyhedron", "Inpaint", "Input", "InputAliases", "InputAssumptions", "InputAutoReplacements", "InputField", "InputFieldBox", "InputFieldBoxOptions", "InputForm", "InputGrouping", "InputNamePacket", "InputNotebook", "InputPacket", "InputPorts", "InputSettings", "InputStream", "InputString", "InputStringPacket", "InputToBoxFormPacket", "Insert", "InsertionFunction", "InsertionPointObject", "InsertLinebreaks", "InsertResults", "Inset", "Inset3DBox", "Inset3DBoxOptions", "InsetBox", "InsetBoxOptions", "Insphere", "Install", "InstallService", "InstanceNormalizationLayer", "InString", "Integer", "IntegerDigits", "IntegerExponent", "IntegerLength", "IntegerName", "IntegerPart", "IntegerPartitions", "IntegerQ", "IntegerReverse", "Integers", "IntegerString", "Integral", "Integrate", "IntegrateChangeVariables", "Interactive", "InteractiveTradingChart", "InterfaceSwitched", "Interlaced", "Interleaving", "InternallyBalancedDecomposition", "InterpolatingFunction", "InterpolatingPolynomial", "Interpolation", "InterpolationOrder", "InterpolationPoints", "InterpolationPrecision", "Interpretation", "InterpretationBox", "InterpretationBoxOptions", "InterpretationFunction", "Interpreter", "InterpretTemplate", "InterquartileRange", "Interrupt", "InterruptSettings", "IntersectedEntityClass", "IntersectingQ", "Intersection", "Interval", "IntervalIntersection", "IntervalMarkers", "IntervalMarkersStyle", "IntervalMemberQ", "IntervalSlider", "IntervalUnion", "Into", "Inverse", "InverseBetaRegularized", "InverseBilateralLaplaceTransform", "InverseBilateralZTransform", "InverseCDF", "InverseChiSquareDistribution", "InverseContinuousWaveletTransform", "InverseDistanceTransform", "InverseEllipticNomeQ", "InverseErf", "InverseErfc", "InverseFourier", "InverseFourierCosTransform", "InverseFourierSequenceTransform", "InverseFourierSinTransform", "InverseFourierTransform", "InverseFunction", "InverseFunctions", "InverseGammaDistribution", "InverseGammaRegularized", "InverseGaussianDistribution", "InverseGudermannian", "InverseHankelTransform", "InverseHaversine", "InverseImagePyramid", "InverseJacobiCD", "InverseJacobiCN", "InverseJacobiCS", "InverseJacobiDC", "InverseJacobiDN", "InverseJacobiDS", "InverseJacobiNC", "InverseJacobiND", "InverseJacobiNS", "InverseJacobiSC", "InverseJacobiSD", "InverseJacobiSN", "InverseLaplaceTransform", "InverseMellinTransform", "InversePermutation", "InverseRadon", "InverseRadonTransform", "InverseSeries", "InverseShortTimeFourier", "InverseSpectrogram", "InverseSurvivalFunction", "InverseTransformedRegion", "InverseWaveletTransform", "InverseWeierstrassP", "InverseWishartMatrixDistribution", "InverseZTransform", "Invisible", "InvisibleApplication", "InvisibleTimes", "IPAddress", "IrreduciblePolynomialQ", "IslandData", "IsolatingInterval", "IsomorphicGraphQ", "IsomorphicSubgraphQ", "IsotopeData", "Italic", "Item", "ItemAspectRatio", "ItemBox", "ItemBoxOptions", "ItemDisplayFunction", "ItemSize", "ItemStyle", "ItoProcess", "JaccardDissimilarity", "JacobiAmplitude", "Jacobian", "JacobiCD", "JacobiCN", "JacobiCS", "JacobiDC", "JacobiDN", "JacobiDS", "JacobiEpsilon", "JacobiNC", "JacobiND", "JacobiNS", "JacobiP", "JacobiSC", "JacobiSD", "JacobiSN", "JacobiSymbol", "JacobiZeta", "JacobiZN", "JankoGroupJ1", "JankoGroupJ2", "JankoGroupJ3", "JankoGroupJ4", "JarqueBeraALMTest", "JohnsonDistribution", "Join", "JoinAcross", "Joined", "JoinedCurve", "JoinedCurveBox", "JoinedCurveBoxOptions", "JoinForm", "JordanDecomposition", "JordanModelDecomposition", "JulianDate", "JuliaSetBoettcher", "JuliaSetIterationCount", "JuliaSetPlot", "JuliaSetPoints", "K", "KagiChart", "KaiserBesselWindow", "KaiserWindow", "KalmanEstimator", "KalmanFilter", "KarhunenLoeveDecomposition", "KaryTree", "KatzCentrality", "KCoreComponents", "KDistribution", "KEdgeConnectedComponents", "KEdgeConnectedGraphQ", "KeepExistingVersion", "KelvinBei", "KelvinBer", "KelvinKei", "KelvinKer", "KendallTau", "KendallTauTest", "KernelConfiguration", "KernelExecute", "KernelFunction", "KernelMixtureDistribution", "KernelObject", "Kernels", "Ket", "Key", "KeyCollisionFunction", "KeyComplement", "KeyDrop", "KeyDropFrom", "KeyExistsQ", "KeyFreeQ", "KeyIntersection", "KeyMap", "KeyMemberQ", "KeypointStrength", "Keys", "KeySelect", "KeySort", "KeySortBy", "KeyTake", "KeyUnion", "KeyValueMap", "KeyValuePattern", "Khinchin", "KillProcess", "KirchhoffGraph", "KirchhoffMatrix", "KleinInvariantJ", "KnapsackSolve", "KnightTourGraph", "KnotData", "KnownUnitQ", "KochCurve", "KolmogorovSmirnovTest", "KroneckerDelta", "KroneckerModelDecomposition", "KroneckerProduct", "KroneckerSymbol", "KuiperTest", "KumaraswamyDistribution", "Kurtosis", "KuwaharaFilter", "KVertexConnectedComponents", "KVertexConnectedGraphQ", "LABColor", "Label", "Labeled", "LabeledSlider", "LabelingFunction", "LabelingSize", "LabelStyle", "LabelVisibility", "LaguerreL", "LakeData", "LambdaComponents", "LambertW", "LameC", "LameCPrime", "LameEigenvalueA", "LameEigenvalueB", "LameS", "LameSPrime", "LaminaData", "LanczosWindow", "LandauDistribution", "Language", "LanguageCategory", "LanguageData", "LanguageIdentify", "LanguageOptions", "LaplaceDistribution", "LaplaceTransform", "Laplacian", "LaplacianFilter", "LaplacianGaussianFilter", "LaplacianPDETerm", "Large", "Larger", "Last", "Latitude", "LatitudeLongitude", "LatticeData", "LatticeReduce", "Launch", "LaunchKernels", "LayeredGraphPlot", "LayeredGraphPlot3D", "LayerSizeFunction", "LayoutInformation", "LCHColor", "LCM", "LeaderSize", "LeafCount", "LeapVariant", "LeapYearQ", "LearnDistribution", "LearnedDistribution", "LearningRate", "LearningRateMultipliers", "LeastSquares", "LeastSquaresFilterKernel", "Left", "LeftArrow", "LeftArrowBar", "LeftArrowRightArrow", "LeftDownTeeVector", "LeftDownVector", "LeftDownVectorBar", "LeftRightArrow", "LeftRightVector", "LeftTee", "LeftTeeArrow", "LeftTeeVector", "LeftTriangle", "LeftTriangleBar", "LeftTriangleEqual", "LeftUpDownVector", "LeftUpTeeVector", "LeftUpVector", "LeftUpVectorBar", "LeftVector", "LeftVectorBar", "LegendAppearance", "Legended", "LegendFunction", "LegendLabel", "LegendLayout", "LegendMargins", "LegendMarkers", "LegendMarkerSize", "LegendreP", "LegendreQ", "LegendreType", "Length", "LengthWhile", "LerchPhi", "Less", "LessEqual", "LessEqualGreater", "LessEqualThan", "LessFullEqual", "LessGreater", "LessLess", "LessSlantEqual", "LessThan", "LessTilde", "LetterCharacter", "LetterCounts", "LetterNumber", "LetterQ", "Level", "LeveneTest", "LeviCivitaTensor", "LevyDistribution", "Lexicographic", "LexicographicOrder", "LexicographicSort", "LibraryDataType", "LibraryFunction", "LibraryFunctionDeclaration", "LibraryFunctionError", "LibraryFunctionInformation", "LibraryFunctionLoad", "LibraryFunctionUnload", "LibraryLoad", "LibraryUnload", "LicenseEntitlementObject", "LicenseEntitlements", "LicenseID", "LicensingSettings", "LiftingFilterData", "LiftingWaveletTransform", "LightBlue", "LightBrown", "LightCyan", "Lighter", "LightGray", "LightGreen", "Lighting", "LightingAngle", "LightMagenta", "LightOrange", "LightPink", "LightPurple", "LightRed", "LightSources", "LightYellow", "Likelihood", "Limit", "LimitsPositioning", "LimitsPositioningTokens", "LindleyDistribution", "Line", "Line3DBox", "Line3DBoxOptions", "LinearFilter", "LinearFractionalOptimization", "LinearFractionalTransform", "LinearGradientFilling", "LinearGradientImage", "LinearizingTransformationData", "LinearLayer", "LinearModelFit", "LinearOffsetFunction", "LinearOptimization", "LinearProgramming", "LinearRecurrence", "LinearSolve", "LinearSolveFunction", "LineBox", "LineBoxOptions", "LineBreak", "LinebreakAdjustments", "LineBreakChart", "LinebreakSemicolonWeighting", "LineBreakWithin", "LineColor", "LineGraph", "LineIndent", "LineIndentMaxFraction", "LineIntegralConvolutionPlot", "LineIntegralConvolutionScale", "LineLegend", "LineOpacity", "LineSpacing", "LineWrapParts", "LinkActivate", "LinkClose", "LinkConnect", "LinkConnectedQ", "LinkCreate", "LinkError", "LinkFlush", "LinkFunction", "LinkHost", "LinkInterrupt", "LinkLaunch", "LinkMode", "LinkObject", "LinkOpen", "LinkOptions", "LinkPatterns", "LinkProtocol", "LinkRankCentrality", "LinkRead", "LinkReadHeld", "LinkReadyQ", "Links", "LinkService", "LinkWrite", "LinkWriteHeld", "LiouvilleLambda", "List", "Listable", "ListAnimate", "ListContourPlot", "ListContourPlot3D", "ListConvolve", "ListCorrelate", "ListCurvePathPlot", "ListDeconvolve", "ListDensityPlot", "ListDensityPlot3D", "Listen", "ListFormat", "ListFourierSequenceTransform", "ListInterpolation", "ListLineIntegralConvolutionPlot", "ListLinePlot", "ListLinePlot3D", "ListLogLinearPlot", "ListLogLogPlot", "ListLogPlot", "ListPicker", "ListPickerBox", "ListPickerBoxBackground", "ListPickerBoxOptions", "ListPlay", "ListPlot", "ListPlot3D", "ListPointPlot3D", "ListPolarPlot", "ListQ", "ListSliceContourPlot3D", "ListSliceDensityPlot3D", "ListSliceVectorPlot3D", "ListStepPlot", "ListStreamDensityPlot", "ListStreamPlot", "ListStreamPlot3D", "ListSurfacePlot3D", "ListVectorDensityPlot", "ListVectorDisplacementPlot", "ListVectorDisplacementPlot3D", "ListVectorPlot", "ListVectorPlot3D", "ListZTransform", "Literal", "LiteralSearch", "LiteralType", "LoadCompiledComponent", "LocalAdaptiveBinarize", "LocalCache", "LocalClusteringCoefficient", "LocalEvaluate", "LocalizeDefinitions", "LocalizeVariables", "LocalObject", "LocalObjects", "LocalResponseNormalizationLayer", "LocalSubmit", "LocalSymbol", "LocalTime", "LocalTimeZone", "LocationEquivalenceTest", "LocationTest", "Locator", "LocatorAutoCreate", "LocatorBox", "LocatorBoxOptions", "LocatorCentering", "LocatorPane", "LocatorPaneBox", "LocatorPaneBoxOptions", "LocatorRegion", "Locked", "Log", "Log10", "Log2", "LogBarnesG", "LogGamma", "LogGammaDistribution", "LogicalExpand", "LogIntegral", "LogisticDistribution", "LogisticSigmoid", "LogitModelFit", "LogLikelihood", "LogLinearPlot", "LogLogisticDistribution", "LogLogPlot", "LogMultinormalDistribution", "LogNormalDistribution", "LogPlot", "LogRankTest", "LogSeriesDistribution", "LongEqual", "Longest", "LongestCommonSequence", "LongestCommonSequencePositions", "LongestCommonSubsequence", "LongestCommonSubsequencePositions", "LongestMatch", "LongestOrderedSequence", "LongForm", "Longitude", "LongLeftArrow", "LongLeftRightArrow", "LongRightArrow", "LongShortTermMemoryLayer", "Lookup", "Loopback", "LoopFreeGraphQ", "Looping", "LossFunction", "LowerCaseQ", "LowerLeftArrow", "LowerRightArrow", "LowerTriangularize", "LowerTriangularMatrix", "LowerTriangularMatrixQ", "LowpassFilter", "LQEstimatorGains", "LQGRegulator", "LQOutputRegulatorGains", "LQRegulatorGains", "LUBackSubstitution", "LucasL", "LuccioSamiComponents", "LUDecomposition", "LunarEclipse", "LUVColor", "LyapunovSolve", "LyonsGroupLy", "MachineID", "MachineName", "MachineNumberQ", "MachinePrecision", "MacintoshSystemPageSetup", "Magenta", "Magnification", "Magnify", "MailAddressValidation", "MailExecute", "MailFolder", "MailItem", "MailReceiverFunction", "MailResponseFunction", "MailSearch", "MailServerConnect", "MailServerConnection", "MailSettings", "MainSolve", "MaintainDynamicCaches", "Majority", "MakeBoxes", "MakeExpression", "MakeRules", "ManagedLibraryExpressionID", "ManagedLibraryExpressionQ", "MandelbrotSetBoettcher", "MandelbrotSetDistance", "MandelbrotSetIterationCount", "MandelbrotSetMemberQ", "MandelbrotSetPlot", "MangoldtLambda", "ManhattanDistance", "Manipulate", "Manipulator", "MannedSpaceMissionData", "MannWhitneyTest", "MantissaExponent", "Manual", "Map", "MapAll", "MapApply", "MapAt", "MapIndexed", "MAProcess", "MapThread", "MarchenkoPasturDistribution", "MarcumQ", "MardiaCombinedTest", "MardiaKurtosisTest", "MardiaSkewnessTest", "MarginalDistribution", "MarkovProcessProperties", "Masking", "MassConcentrationCondition", "MassFluxValue", "MassImpermeableBoundaryValue", "MassOutflowValue", "MassSymmetryValue", "MassTransferValue", "MassTransportPDEComponent", "MatchingDissimilarity", "MatchLocalNameQ", "MatchLocalNames", "MatchQ", "Material", "MaterialShading", "MaternPointProcess", "MathematicalFunctionData", "MathematicaNotation", "MathieuC", "MathieuCharacteristicA", "MathieuCharacteristicB", "MathieuCharacteristicExponent", "MathieuCPrime", "MathieuGroupM11", "MathieuGroupM12", "MathieuGroupM22", "MathieuGroupM23", "MathieuGroupM24", "MathieuS", "MathieuSPrime", "MathMLForm", "MathMLText", "Matrices", "MatrixExp", "MatrixForm", "MatrixFunction", "MatrixLog", "MatrixNormalDistribution", "MatrixPlot", "MatrixPower", "MatrixPropertyDistribution", "MatrixQ", "MatrixRank", "MatrixTDistribution", "Max", "MaxBend", "MaxCellMeasure", "MaxColorDistance", "MaxDate", "MaxDetect", "MaxDisplayedChildren", "MaxDuration", "MaxExtraBandwidths", "MaxExtraConditions", "MaxFeatureDisplacement", "MaxFeatures", "MaxFilter", "MaximalBy", "Maximize", "MaxItems", "MaxIterations", "MaxLimit", "MaxMemoryUsed", "MaxMixtureKernels", "MaxOverlapFraction", "MaxPlotPoints", "MaxPoints", "MaxRecursion", "MaxStableDistribution", "MaxStepFraction", "MaxSteps", "MaxStepSize", "MaxTrainingRounds", "MaxValue", "MaxwellDistribution", "MaxWordGap", "McLaughlinGroupMcL", "Mean", "MeanAbsoluteLossLayer", "MeanAround", "MeanClusteringCoefficient", "MeanDegreeConnectivity", "MeanDeviation", "MeanFilter", "MeanGraphDistance", "MeanNeighborDegree", "MeanPointDensity", "MeanShift", "MeanShiftFilter", "MeanSquaredLossLayer", "Median", "MedianDeviation", "MedianFilter", "MedicalTestData", "Medium", "MeijerG", "MeijerGReduce", "MeixnerDistribution", "MellinConvolve", "MellinTransform", "MemberQ", "MemoryAvailable", "MemoryConstrained", "MemoryConstraint", "MemoryInUse", "MengerMesh", "Menu", "MenuAppearance", "MenuCommandKey", "MenuEvaluator", "MenuItem", "MenuList", "MenuPacket", "MenuSortingValue", "MenuStyle", "MenuView", "Merge", "MergeDifferences", "MergingFunction", "MersennePrimeExponent", "MersennePrimeExponentQ", "Mesh", "MeshCellCentroid", "MeshCellCount", "MeshCellHighlight", "MeshCellIndex", "MeshCellLabel", "MeshCellMarker", "MeshCellMeasure", "MeshCellQuality", "MeshCells", "MeshCellShapeFunction", "MeshCellStyle", "MeshConnectivityGraph", "MeshCoordinates", "MeshFunctions", "MeshPrimitives", "MeshQualityGoal", "MeshRange", "MeshRefinementFunction", "MeshRegion", "MeshRegionQ", "MeshShading", "MeshStyle", "Message", "MessageDialog", "MessageList", "MessageName", "MessageObject", "MessageOptions", "MessagePacket", "Messages", "MessagesNotebook", "MetaCharacters", "MetaInformation", "MeteorShowerData", "Method", "MethodOptions", "MexicanHatWavelet", "MeyerWavelet", "Midpoint", "MIMETypeToFormatList", "Min", "MinColorDistance", "MinDate", "MinDetect", "MineralData", "MinFilter", "MinimalBy", "MinimalPolynomial", "MinimalStateSpaceModel", "Minimize", "MinimumTimeIncrement", "MinIntervalSize", "MinkowskiQuestionMark", "MinLimit", "MinMax", "MinorPlanetData", "Minors", "MinPointSeparation", "MinRecursion", "MinSize", "MinStableDistribution", "Minus", "MinusPlus", "MinValue", "Missing", "MissingBehavior", "MissingDataMethod", "MissingDataRules", "MissingQ", "MissingString", "MissingStyle", "MissingValuePattern", "MissingValueSynthesis", "MittagLefflerE", "MixedFractionParts", "MixedGraphQ", "MixedMagnitude", "MixedRadix", "MixedRadixQuantity", "MixedUnit", "MixtureDistribution", "Mod", "Modal", "Mode", "ModelPredictiveController", "Modular", "ModularInverse", "ModularLambda", "Module", "Modulus", "MoebiusMu", "Molecule", "MoleculeAlign", "MoleculeContainsQ", "MoleculeDraw", "MoleculeEquivalentQ", "MoleculeFreeQ", "MoleculeGraph", "MoleculeMatchQ", "MoleculeMaximumCommonSubstructure", "MoleculeModify", "MoleculeName", "MoleculePattern", "MoleculePlot", "MoleculePlot3D", "MoleculeProperty", "MoleculeQ", "MoleculeRecognize", "MoleculeSubstructureCount", "MoleculeValue", "Moment", "MomentConvert", "MomentEvaluate", "MomentGeneratingFunction", "MomentOfInertia", "Monday", "Monitor", "MonomialList", "MonomialOrder", "MonsterGroupM", "MoonPhase", "MoonPosition", "MorletWavelet", "MorphologicalBinarize", "MorphologicalBranchPoints", "MorphologicalComponents", "MorphologicalEulerNumber", "MorphologicalGraph", "MorphologicalPerimeter", "MorphologicalTransform", "MortalityData", "Most", "MountainData", "MouseAnnotation", "MouseAppearance", "MouseAppearanceTag", "MouseButtons", "Mouseover", "MousePointerNote", "MousePosition", "MovieData", "MovingAverage", "MovingMap", "MovingMedian", "MoyalDistribution", "MultiaxisArrangement", "Multicolumn", "MultiedgeStyle", "MultigraphQ", "MultilaunchWarning", "MultiLetterItalics", "MultiLetterStyle", "MultilineFunction", "Multinomial", "MultinomialDistribution", "MultinormalDistribution", "MultiplicativeOrder", "Multiplicity", "MultiplySides", "MultiscriptBoxOptions", "Multiselection", "MultivariateHypergeometricDistribution", "MultivariatePoissonDistribution", "MultivariateTDistribution", "N", "NakagamiDistribution", "NameQ", "Names", "NamespaceBox", "NamespaceBoxOptions", "Nand", "NArgMax", "NArgMin", "NBernoulliB", "NBodySimulation", "NBodySimulationData", "NCache", "NCaputoD", "NDEigensystem", "NDEigenvalues", "NDSolve", "NDSolveValue", "Nearest", "NearestFunction", "NearestMeshCells", "NearestNeighborG", "NearestNeighborGraph", "NearestTo", "NebulaData", "NeedlemanWunschSimilarity", "Needs", "Negative", "NegativeBinomialDistribution", "NegativeDefiniteMatrixQ", "NegativeIntegers", "NegativelyOrientedPoints", "NegativeMultinomialDistribution", "NegativeRationals", "NegativeReals", "NegativeSemidefiniteMatrixQ", "NeighborhoodData", "NeighborhoodGraph", "Nest", "NestedGreaterGreater", "NestedLessLess", "NestedScriptRules", "NestGraph", "NestList", "NestTree", "NestWhile", "NestWhileList", "NetAppend", "NetArray", "NetArrayLayer", "NetBidirectionalOperator", "NetChain", "NetDecoder", "NetDelete", "NetDrop", "NetEncoder", "NetEvaluationMode", "NetExternalObject", "NetExtract", "NetFlatten", "NetFoldOperator", "NetGANOperator", "NetGraph", "NetInformation", "NetInitialize", "NetInsert", "NetInsertSharedArrays", "NetJoin", "NetMapOperator", "NetMapThreadOperator", "NetMeasurements", "NetModel", "NetNestOperator", "NetPairEmbeddingOperator", "NetPort", "NetPortGradient", "NetPrepend", "NetRename", "NetReplace", "NetReplacePart", "NetSharedArray", "NetStateObject", "NetTake", "NetTrain", "NetTrainResultsObject", "NetUnfold", "NetworkPacketCapture", "NetworkPacketRecording", "NetworkPacketRecordingDuring", "NetworkPacketTrace", "NeumannValue", "NevilleThetaC", "NevilleThetaD", "NevilleThetaN", "NevilleThetaS", "NewPrimitiveStyle", "NExpectation", "Next", "NextCell", "NextDate", "NextPrime", "NextScheduledTaskTime", "NeymanScottPointProcess", "NFractionalD", "NHoldAll", "NHoldFirst", "NHoldRest", "NicholsGridLines", "NicholsPlot", "NightHemisphere", "NIntegrate", "NMaximize", "NMaxValue", "NMinimize", "NMinValue", "NominalScale", "NominalVariables", "NonAssociative", "NoncentralBetaDistribution", "NoncentralChiSquareDistribution", "NoncentralFRatioDistribution", "NoncentralStudentTDistribution", "NonCommutativeMultiply", "NonConstants", "NondimensionalizationTransform", "None", "NoneTrue", "NonlinearModelFit", "NonlinearStateSpaceModel", "NonlocalMeansFilter", "NonNegative", "NonNegativeIntegers", "NonNegativeRationals", "NonNegativeReals", "NonPositive", "NonPositiveIntegers", "NonPositiveRationals", "NonPositiveReals", "Nor", "NorlundB", "Norm", "Normal", "NormalDistribution", "NormalGrouping", "NormalizationLayer", "Normalize", "Normalized", "NormalizedSquaredEuclideanDistance", "NormalMatrixQ", "NormalsFunction", "NormFunction", "Not", "NotCongruent", "NotCupCap", "NotDoubleVerticalBar", "Notebook", "NotebookApply", "NotebookAutoSave", "NotebookBrowseDirectory", "NotebookClose", "NotebookConvertSettings", "NotebookCreate", "NotebookDefault", "NotebookDelete", "NotebookDirectory", "NotebookDynamicExpression", "NotebookEvaluate", "NotebookEventActions", "NotebookFileName", "NotebookFind", "NotebookGet", "NotebookImport", "NotebookInformation", "NotebookInterfaceObject", "NotebookLocate", "NotebookObject", "NotebookOpen", "NotebookPath", "NotebookPrint", "NotebookPut", "NotebookRead", "Notebooks", "NotebookSave", "NotebookSelection", "NotebooksMenu", "NotebookTemplate", "NotebookWrite", "NotElement", "NotEqualTilde", "NotExists", "NotGreater", "NotGreaterEqual", "NotGreaterFullEqual", "NotGreaterGreater", "NotGreaterLess", "NotGreaterSlantEqual", "NotGreaterTilde", "Nothing", "NotHumpDownHump", "NotHumpEqual", "NotificationFunction", "NotLeftTriangle", "NotLeftTriangleBar", "NotLeftTriangleEqual", "NotLess", "NotLessEqual", "NotLessFullEqual", "NotLessGreater", "NotLessLess", "NotLessSlantEqual", "NotLessTilde", "NotNestedGreaterGreater", "NotNestedLessLess", "NotPrecedes", "NotPrecedesEqual", "NotPrecedesSlantEqual", "NotPrecedesTilde", "NotReverseElement", "NotRightTriangle", "NotRightTriangleBar", "NotRightTriangleEqual", "NotSquareSubset", "NotSquareSubsetEqual", "NotSquareSuperset", "NotSquareSupersetEqual", "NotSubset", "NotSubsetEqual", "NotSucceeds", "NotSucceedsEqual", "NotSucceedsSlantEqual", "NotSucceedsTilde", "NotSuperset", "NotSupersetEqual", "NotTilde", "NotTildeEqual", "NotTildeFullEqual", "NotTildeTilde", "NotVerticalBar", "Now", "NoWhitespace", "NProbability", "NProduct", "NProductFactors", "NRoots", "NSolve", "NSolveValues", "NSum", "NSumTerms", "NuclearExplosionData", "NuclearReactorData", "Null", "NullRecords", "NullSpace", "NullWords", "Number", "NumberCompose", "NumberDecompose", "NumberDigit", "NumberExpand", "NumberFieldClassNumber", "NumberFieldDiscriminant", "NumberFieldFundamentalUnits", "NumberFieldIntegralBasis", "NumberFieldNormRepresentatives", "NumberFieldRegulator", "NumberFieldRootsOfUnity", "NumberFieldSignature", "NumberForm", "NumberFormat", "NumberLinePlot", "NumberMarks", "NumberMultiplier", "NumberPadding", "NumberPoint", "NumberQ", "NumberSeparator", "NumberSigns", "NumberString", "Numerator", "NumeratorDenominator", "NumericalOrder", "NumericalSort", "NumericArray", "NumericArrayQ", "NumericArrayType", "NumericFunction", "NumericQ", "NuttallWindow", "NValues", "NyquistGridLines", "NyquistPlot", "O", "ObjectExistsQ", "ObservabilityGramian", "ObservabilityMatrix", "ObservableDecomposition", "ObservableModelQ", "OceanData", "Octahedron", "OddQ", "Off", "Offset", "OLEData", "On", "ONanGroupON", "Once", "OneIdentity", "Opacity", "OpacityFunction", "OpacityFunctionScaling", "Open", "OpenAppend", "Opener", "OpenerBox", "OpenerBoxOptions", "OpenerView", "OpenFunctionInspectorPacket", "Opening", "OpenRead", "OpenSpecialOptions", "OpenTemporary", "OpenWrite", "Operate", "OperatingSystem", "OperatorApplied", "OptimumFlowData", "Optional", "OptionalElement", "OptionInspectorSettings", "OptionQ", "Options", "OptionsPacket", "OptionsPattern", "OptionValue", "OptionValueBox", "OptionValueBoxOptions", "Or", "Orange", "Order", "OrderDistribution", "OrderedQ", "Ordering", "OrderingBy", "OrderingLayer", "Orderless", "OrderlessPatternSequence", "OrdinalScale", "OrnsteinUhlenbeckProcess", "Orthogonalize", "OrthogonalMatrixQ", "Out", "Outer", "OuterPolygon", "OuterPolyhedron", "OutputAutoOverwrite", "OutputControllabilityMatrix", "OutputControllableModelQ", "OutputForm", "OutputFormData", "OutputGrouping", "OutputMathEditExpression", "OutputNamePacket", "OutputPorts", "OutputResponse", "OutputSizeLimit", "OutputStream", "Over", "OverBar", "OverDot", "Overflow", "OverHat", "Overlaps", "Overlay", "OverlayBox", "OverlayBoxOptions", "OverlayVideo", "Overscript", "OverscriptBox", "OverscriptBoxOptions", "OverTilde", "OverVector", "OverwriteTarget", "OwenT", "OwnValues", "Package", "PackingMethod", "PackPaclet", "PacletDataRebuild", "PacletDirectoryAdd", "PacletDirectoryLoad", "PacletDirectoryRemove", "PacletDirectoryUnload", "PacletDisable", "PacletEnable", "PacletFind", "PacletFindRemote", "PacletInformation", "PacletInstall", "PacletInstallSubmit", "PacletNewerQ", "PacletObject", "PacletObjectQ", "PacletSite", "PacletSiteObject", "PacletSiteRegister", "PacletSites", "PacletSiteUnregister", "PacletSiteUpdate", "PacletSymbol", "PacletUninstall", "PacletUpdate", "PaddedForm", "Padding", "PaddingLayer", "PaddingSize", "PadeApproximant", "PadLeft", "PadRight", "PageBreakAbove", "PageBreakBelow", "PageBreakWithin", "PageFooterLines", "PageFooters", "PageHeaderLines", "PageHeaders", "PageHeight", "PageRankCentrality", "PageTheme", "PageWidth", "Pagination", "PairCorrelationG", "PairedBarChart", "PairedHistogram", "PairedSmoothHistogram", "PairedTTest", "PairedZTest", "PaletteNotebook", "PalettePath", "PalettesMenuSettings", "PalindromeQ", "Pane", "PaneBox", "PaneBoxOptions", "Panel", "PanelBox", "PanelBoxOptions", "Paneled", "PaneSelector", "PaneSelectorBox", "PaneSelectorBoxOptions", "PaperWidth", "ParabolicCylinderD", "ParagraphIndent", "ParagraphSpacing", "ParallelArray", "ParallelAxisPlot", "ParallelCombine", "ParallelDo", "Parallelepiped", "ParallelEvaluate", "Parallelization", "Parallelize", "ParallelKernels", "ParallelMap", "ParallelNeeds", "Parallelogram", "ParallelProduct", "ParallelSubmit", "ParallelSum", "ParallelTable", "ParallelTry", "Parameter", "ParameterEstimator", "ParameterMixtureDistribution", "ParameterVariables", "ParametricConvexOptimization", "ParametricFunction", "ParametricNDSolve", "ParametricNDSolveValue", "ParametricPlot", "ParametricPlot3D", "ParametricRampLayer", "ParametricRegion", "ParentBox", "ParentCell", "ParentConnect", "ParentDirectory", "ParentEdgeLabel", "ParentEdgeLabelFunction", "ParentEdgeLabelStyle", "ParentEdgeShapeFunction", "ParentEdgeStyle", "ParentEdgeStyleFunction", "ParentForm", "Parenthesize", "ParentList", "ParentNotebook", "ParetoDistribution", "ParetoPickandsDistribution", "ParkData", "Part", "PartBehavior", "PartialCorrelationFunction", "PartialD", "ParticleAcceleratorData", "ParticleData", "Partition", "PartitionGranularity", "PartitionsP", "PartitionsQ", "PartLayer", "PartOfSpeech", "PartProtection", "ParzenWindow", "PascalDistribution", "PassEventsDown", "PassEventsUp", "Paste", "PasteAutoQuoteCharacters", "PasteBoxFormInlineCells", "PasteButton", "Path", "PathGraph", "PathGraphQ", "Pattern", "PatternFilling", "PatternReaction", "PatternSequence", "PatternTest", "PauliMatrix", "PaulWavelet", "Pause", "PausedTime", "PDF", "PeakDetect", "PeanoCurve", "PearsonChiSquareTest", "PearsonCorrelationTest", "PearsonDistribution", "PenttinenPointProcess", "PercentForm", "PerfectNumber", "PerfectNumberQ", "PerformanceGoal", "Perimeter", "PeriodicBoundaryCondition", "PeriodicInterpolation", "Periodogram", "PeriodogramArray", "Permanent", "Permissions", "PermissionsGroup", "PermissionsGroupMemberQ", "PermissionsGroups", "PermissionsKey", "PermissionsKeys", "PermutationCycles", "PermutationCyclesQ", "PermutationGroup", "PermutationLength", "PermutationList", "PermutationListQ", "PermutationMatrix", "PermutationMax", "PermutationMin", "PermutationOrder", "PermutationPower", "PermutationProduct", "PermutationReplace", "Permutations", "PermutationSupport", "Permute", "PeronaMalikFilter", "Perpendicular", "PerpendicularBisector", "PersistenceLocation", "PersistenceTime", "PersistentObject", "PersistentObjects", "PersistentSymbol", "PersistentValue", "PersonData", "PERTDistribution", "PetersenGraph", "PhaseMargins", "PhaseRange", "PhongShading", "PhysicalSystemData", "Pi", "Pick", "PickedElements", "PickMode", "PIDData", "PIDDerivativeFilter", "PIDFeedforward", "PIDTune", "Piecewise", "PiecewiseExpand", "PieChart", "PieChart3D", "PillaiTrace", "PillaiTraceTest", "PingTime", "Pink", "PitchRecognize", "Pivoting", "PixelConstrained", "PixelValue", "PixelValuePositions", "Placed", "Placeholder", "PlaceholderLayer", "PlaceholderReplace", "Plain", "PlanarAngle", "PlanarFaceList", "PlanarGraph", "PlanarGraphQ", "PlanckRadiationLaw", "PlaneCurveData", "PlanetaryMoonData", "PlanetData", "PlantData", "Play", "PlaybackSettings", "PlayRange", "Plot", "Plot3D", "Plot3Matrix", "PlotDivision", "PlotJoined", "PlotLabel", "PlotLabels", "PlotLayout", "PlotLegends", "PlotMarkers", "PlotPoints", "PlotRange", "PlotRangeClipping", "PlotRangeClipPlanesStyle", "PlotRangePadding", "PlotRegion", "PlotStyle", "PlotTheme", "Pluralize", "Plus", "PlusMinus", "Pochhammer", "PodStates", "PodWidth", "Point", "Point3DBox", "Point3DBoxOptions", "PointBox", "PointBoxOptions", "PointCountDistribution", "PointDensity", "PointDensityFunction", "PointFigureChart", "PointLegend", "PointLight", "PointProcessEstimator", "PointProcessFitTest", "PointProcessParameterAssumptions", "PointProcessParameterQ", "PointSize", "PointStatisticFunction", "PointValuePlot", "PoissonConsulDistribution", "PoissonDistribution", "PoissonPDEComponent", "PoissonPointProcess", "PoissonProcess", "PoissonWindow", "PolarAxes", "PolarAxesOrigin", "PolarGridLines", "PolarPlot", "PolarTicks", "PoleZeroMarkers", "PolyaAeppliDistribution", "PolyGamma", "Polygon", "Polygon3DBox", "Polygon3DBoxOptions", "PolygonalNumber", "PolygonAngle", "PolygonBox", "PolygonBoxOptions", "PolygonCoordinates", "PolygonDecomposition", "PolygonHoleScale", "PolygonIntersections", "PolygonScale", "Polyhedron", "PolyhedronAngle", "PolyhedronBox", "PolyhedronBoxOptions", "PolyhedronCoordinates", "PolyhedronData", "PolyhedronDecomposition", "PolyhedronGenus", "PolyLog", "PolynomialExpressionQ", "PolynomialExtendedGCD", "PolynomialForm", "PolynomialGCD", "PolynomialLCM", "PolynomialMod", "PolynomialQ", "PolynomialQuotient", "PolynomialQuotientRemainder", "PolynomialReduce", "PolynomialRemainder", "Polynomials", "PolynomialSumOfSquaresList", "PoolingLayer", "PopupMenu", "PopupMenuBox", "PopupMenuBoxOptions", "PopupView", "PopupWindow", "Position", "PositionIndex", "PositionLargest", "PositionSmallest", "Positive", "PositiveDefiniteMatrixQ", "PositiveIntegers", "PositivelyOrientedPoints", "PositiveRationals", "PositiveReals", "PositiveSemidefiniteMatrixQ", "PossibleZeroQ", "Postfix", "PostScript", "Power", "PowerDistribution", "PowerExpand", "PowerMod", "PowerModList", "PowerRange", "PowerSpectralDensity", "PowersRepresentations", "PowerSymmetricPolynomial", "Precedence", "PrecedenceForm", "Precedes", "PrecedesEqual", "PrecedesSlantEqual", "PrecedesTilde", "Precision", "PrecisionGoal", "PreDecrement", "Predict", "PredictionRoot", "PredictorFunction", "PredictorInformation", "PredictorMeasurements", "PredictorMeasurementsObject", "PreemptProtect", "PreferencesPath", "PreferencesSettings", "Prefix", "PreIncrement", "Prepend", "PrependLayer", "PrependTo", "PreprocessingRules", "PreserveColor", "PreserveImageOptions", "Previous", "PreviousCell", "PreviousDate", "PriceGraphDistribution", "PrimaryPlaceholder", "Prime", "PrimeNu", "PrimeOmega", "PrimePi", "PrimePowerQ", "PrimeQ", "Primes", "PrimeZetaP", "PrimitivePolynomialQ", "PrimitiveRoot", "PrimitiveRootList", "PrincipalComponents", "PrincipalValue", "Print", "PrintableASCIIQ", "PrintAction", "PrintForm", "PrintingCopies", "PrintingOptions", "PrintingPageRange", "PrintingStartingPageNumber", "PrintingStyleEnvironment", "Printout3D", "Printout3DPreviewer", "PrintPrecision", "PrintTemporary", "Prism", "PrismBox", "PrismBoxOptions", "PrivateCellOptions", "PrivateEvaluationOptions", "PrivateFontOptions", "PrivateFrontEndOptions", "PrivateKey", "PrivateNotebookOptions", "PrivatePaths", "Probability", "ProbabilityDistribution", "ProbabilityPlot", "ProbabilityPr", "ProbabilityScalePlot", "ProbitModelFit", "ProcessConnection", "ProcessDirectory", "ProcessEnvironment", "Processes", "ProcessEstimator", "ProcessInformation", "ProcessObject", "ProcessParameterAssumptions", "ProcessParameterQ", "ProcessStateDomain", "ProcessStatus", "ProcessTimeDomain", "Product", "ProductDistribution", "ProductLog", "ProgressIndicator", "ProgressIndicatorBox", "ProgressIndicatorBoxOptions", "ProgressReporting", "Projection", "Prolog", "PromptForm", "ProofObject", "PropagateAborts", "Properties", "Property", "PropertyList", "PropertyValue", "Proportion", "Proportional", "Protect", "Protected", "ProteinData", "Pruning", "PseudoInverse", "PsychrometricPropertyData", "PublicKey", "PublisherID", "PulsarData", "PunctuationCharacter", "Purple", "Put", "PutAppend", "Pyramid", "PyramidBox", "PyramidBoxOptions", "QBinomial", "QFactorial", "QGamma", "QHypergeometricPFQ", "QnDispersion", "QPochhammer", "QPolyGamma", "QRDecomposition", "QuadraticIrrationalQ", "QuadraticOptimization", "Quantile", "QuantilePlot", "Quantity", "QuantityArray", "QuantityDistribution", "QuantityForm", "QuantityMagnitude", "QuantityQ", "QuantityUnit", "QuantityVariable", "QuantityVariableCanonicalUnit", "QuantityVariableDimensions", "QuantityVariableIdentifier", "QuantityVariablePhysicalQuantity", "Quartics", "QuartileDeviation", "Quartiles", "QuartileSkewness", "Query", "QuestionGenerator", "QuestionInterface", "QuestionObject", "QuestionSelector", "QueueingNetworkProcess", "QueueingProcess", "QueueProperties", "Quiet", "QuietEcho", "Quit", "Quotient", "QuotientRemainder", "RadialAxisPlot", "RadialGradientFilling", "RadialGradientImage", "RadialityCentrality", "RadicalBox", "RadicalBoxOptions", "RadioButton", "RadioButtonBar", "RadioButtonBox", "RadioButtonBoxOptions", "Radon", "RadonTransform", "RamanujanTau", "RamanujanTauL", "RamanujanTauTheta", "RamanujanTauZ", "Ramp", "Random", "RandomArrayLayer", "RandomChoice", "RandomColor", "RandomComplex", "RandomDate", "RandomEntity", "RandomFunction", "RandomGeneratorState", "RandomGeoPosition", "RandomGraph", "RandomImage", "RandomInstance", "RandomInteger", "RandomPermutation", "RandomPoint", "RandomPointConfiguration", "RandomPolygon", "RandomPolyhedron", "RandomPrime", "RandomReal", "RandomSample", "RandomSeed", "RandomSeeding", "RandomTime", "RandomTree", "RandomVariate", "RandomWalkProcess", "RandomWord", "Range", "RangeFilter", "RangeSpecification", "RankedMax", "RankedMin", "RarerProbability", "Raster", "Raster3D", "Raster3DBox", "Raster3DBoxOptions", "RasterArray", "RasterBox", "RasterBoxOptions", "Rasterize", "RasterSize", "Rational", "RationalExpressionQ", "RationalFunctions", "Rationalize", "Rationals", "Ratios", "RawArray", "RawBoxes", "RawData", "RawMedium", "RayleighDistribution", "Re", "ReactionBalance", "ReactionBalancedQ", "ReactionPDETerm", "Read", "ReadByteArray", "ReadLine", "ReadList", "ReadProtected", "ReadString", "Real", "RealAbs", "RealBlockDiagonalForm", "RealDigits", "RealExponent", "Reals", "RealSign", "Reap", "RebuildPacletData", "RecalibrationFunction", "RecognitionPrior", "RecognitionThreshold", "ReconstructionMesh", "Record", "RecordLists", "RecordSeparators", "Rectangle", "RectangleBox", "RectangleBoxOptions", "RectangleChart", "RectangleChart3D", "RectangularRepeatingElement", "RecurrenceFilter", "RecurrenceTable", "RecurringDigitsForm", "Red", "Reduce", "RefBox", "ReferenceLineStyle", "ReferenceMarkers", "ReferenceMarkerStyle", "Refine", "ReflectionMatrix", "ReflectionTransform", "Refresh", "RefreshRate", "Region", "RegionBinarize", "RegionBoundary", "RegionBoundaryStyle", "RegionBounds", "RegionCentroid", "RegionCongruent", "RegionConvert", "RegionDifference", "RegionDilation", "RegionDimension", "RegionDisjoint", "RegionDistance", "RegionDistanceFunction", "RegionEmbeddingDimension", "RegionEqual", "RegionErosion", "RegionFillingStyle", "RegionFit", "RegionFunction", "RegionImage", "RegionIntersection", "RegionMeasure", "RegionMember", "RegionMemberFunction", "RegionMoment", "RegionNearest", "RegionNearestFunction", "RegionPlot", "RegionPlot3D", "RegionProduct", "RegionQ", "RegionResize", "RegionSimilar", "RegionSize", "RegionSymmetricDifference", "RegionUnion", "RegionWithin", "RegisterExternalEvaluator", "RegularExpression", "Regularization", "RegularlySampledQ", "RegularPolygon", "ReIm", "ReImLabels", "ReImPlot", "ReImStyle", "Reinstall", "RelationalDatabase", "RelationGraph", "Release", "ReleaseHold", "ReliabilityDistribution", "ReliefImage", "ReliefPlot", "RemoteAuthorizationCaching", "RemoteBatchJobAbort", "RemoteBatchJobObject", "RemoteBatchJobs", "RemoteBatchMapSubmit", "RemoteBatchSubmissionEnvironment", "RemoteBatchSubmit", "RemoteConnect", "RemoteConnectionObject", "RemoteEvaluate", "RemoteFile", "RemoteInputFiles", "RemoteKernelObject", "RemoteProviderSettings", "RemoteRun", "RemoteRunProcess", "RemovalConditions", "Remove", "RemoveAlphaChannel", "RemoveAsynchronousTask", "RemoveAudioStream", "RemoveBackground", "RemoveChannelListener", "RemoveChannelSubscribers", "Removed", "RemoveDiacritics", "RemoveInputStreamMethod", "RemoveOutputStreamMethod", "RemoveProperty", "RemoveScheduledTask", "RemoveUsers", "RemoveVideoStream", "RenameDirectory", "RenameFile", "RenderAll", "RenderingOptions", "RenewalProcess", "RenkoChart", "RepairMesh", "Repeated", "RepeatedNull", "RepeatedString", "RepeatedTiming", "RepeatingElement", "Replace", "ReplaceAll", "ReplaceAt", "ReplaceHeldPart", "ReplaceImageValue", "ReplaceList", "ReplacePart", "ReplacePixelValue", "ReplaceRepeated", "ReplicateLayer", "RequiredPhysicalQuantities", "Resampling", "ResamplingAlgorithmData", "ResamplingMethod", "Rescale", "RescalingTransform", "ResetDirectory", "ResetScheduledTask", "ReshapeLayer", "Residue", "ResidueSum", "ResizeLayer", "Resolve", "ResolveContextAliases", "ResourceAcquire", "ResourceData", "ResourceFunction", "ResourceObject", "ResourceRegister", "ResourceRemove", "ResourceSearch", "ResourceSubmissionObject", "ResourceSubmit", "ResourceSystemBase", "ResourceSystemPath", "ResourceUpdate", "ResourceVersion", "ResponseForm", "Rest", "RestartInterval", "Restricted", "Resultant", "ResumePacket", "Return", "ReturnCreatesNewCell", "ReturnEntersInput", "ReturnExpressionPacket", "ReturnInputFormPacket", "ReturnPacket", "ReturnReceiptFunction", "ReturnTextPacket", "Reverse", "ReverseApplied", "ReverseBiorthogonalSplineWavelet", "ReverseElement", "ReverseEquilibrium", "ReverseGraph", "ReverseSort", "ReverseSortBy", "ReverseUpEquilibrium", "RevolutionAxis", "RevolutionPlot3D", "RGBColor", "RiccatiSolve", "RiceDistribution", "RidgeFilter", "RiemannR", "RiemannSiegelTheta", "RiemannSiegelZ", "RiemannXi", "Riffle", "Right", "RightArrow", "RightArrowBar", "RightArrowLeftArrow", "RightComposition", "RightCosetRepresentative", "RightDownTeeVector", "RightDownVector", "RightDownVectorBar", "RightTee", "RightTeeArrow", "RightTeeVector", "RightTriangle", "RightTriangleBar", "RightTriangleEqual", "RightUpDownVector", "RightUpTeeVector", "RightUpVector", "RightUpVectorBar", "RightVector", "RightVectorBar", "RipleyK", "RipleyRassonRegion", "RiskAchievementImportance", "RiskReductionImportance", "RobustConvexOptimization", "RogersTanimotoDissimilarity", "RollPitchYawAngles", "RollPitchYawMatrix", "RomanNumeral", "Root", "RootApproximant", "RootIntervals", "RootLocusPlot", "RootMeanSquare", "RootOfUnityQ", "RootReduce", "Roots", "RootSum", "RootTree", "Rotate", "RotateLabel", "RotateLeft", "RotateRight", "RotationAction", "RotationBox", "RotationBoxOptions", "RotationMatrix", "RotationTransform", "Round", "RoundImplies", "RoundingRadius", "Row", "RowAlignments", "RowBackgrounds", "RowBox", "RowHeights", "RowLines", "RowMinHeight", "RowReduce", "RowsEqual", "RowSpacings", "RSolve", "RSolveValue", "RudinShapiro", "RudvalisGroupRu", "Rule", "RuleCondition", "RuleDelayed", "RuleForm", "RulePlot", "RulerUnits", "RulesTree", "Run", "RunProcess", "RunScheduledTask", "RunThrough", "RuntimeAttributes", "RuntimeOptions", "RussellRaoDissimilarity", "SameAs", "SameQ", "SameTest", "SameTestProperties", "SampledEntityClass", "SampleDepth", "SampledSoundFunction", "SampledSoundList", "SampleRate", "SamplingPeriod", "SARIMAProcess", "SARMAProcess", "SASTriangle", "SatelliteData", "SatisfiabilityCount", "SatisfiabilityInstances", "SatisfiableQ", "Saturday", "Save", "Saveable", "SaveAutoDelete", "SaveConnection", "SaveDefinitions", "SavitzkyGolayMatrix", "SawtoothWave", "Scale", "Scaled", "ScaleDivisions", "ScaledMousePosition", "ScaleOrigin", "ScalePadding", "ScaleRanges", "ScaleRangeStyle", "ScalingFunctions", "ScalingMatrix", "ScalingTransform", "Scan", "ScheduledTask", "ScheduledTaskActiveQ", "ScheduledTaskInformation", "ScheduledTaskInformationData", "ScheduledTaskObject", "ScheduledTasks", "SchurDecomposition", "ScientificForm", "ScientificNotationThreshold", "ScorerGi", "ScorerGiPrime", "ScorerHi", "ScorerHiPrime", "ScreenRectangle", "ScreenStyleEnvironment", "ScriptBaselineShifts", "ScriptForm", "ScriptLevel", "ScriptMinSize", "ScriptRules", "ScriptSizeMultipliers", "Scrollbars", "ScrollingOptions", "ScrollPosition", "SearchAdjustment", "SearchIndexObject", "SearchIndices", "SearchQueryString", "SearchResultObject", "Sec", "Sech", "SechDistribution", "SecondOrderConeOptimization", "SectionGrouping", "SectorChart", "SectorChart3D", "SectorOrigin", "SectorSpacing", "SecuredAuthenticationKey", "SecuredAuthenticationKeys", "SecurityCertificate", "SeedRandom", "Select", "Selectable", "SelectComponents", "SelectedCells", "SelectedNotebook", "SelectFirst", "Selection", "SelectionAnimate", "SelectionCell", "SelectionCellCreateCell", "SelectionCellDefaultStyle", "SelectionCellParentStyle", "SelectionCreateCell", "SelectionDebuggerTag", "SelectionEvaluate", "SelectionEvaluateCreateCell", "SelectionMove", "SelectionPlaceholder", "SelectWithContents", "SelfLoops", "SelfLoopStyle", "SemanticImport", "SemanticImportString", "SemanticInterpretation", "SemialgebraicComponentInstances", "SemidefiniteOptimization", "SendMail", "SendMessage", "Sequence", "SequenceAlignment", "SequenceAttentionLayer", "SequenceCases", "SequenceCount", "SequenceFold", "SequenceFoldList", "SequenceForm", "SequenceHold", "SequenceIndicesLayer", "SequenceLastLayer", "SequenceMostLayer", "SequencePosition", "SequencePredict", "SequencePredictorFunction", "SequenceReplace", "SequenceRestLayer", "SequenceReverseLayer", "SequenceSplit", "Series", "SeriesCoefficient", "SeriesData", "SeriesTermGoal", "ServiceConnect", "ServiceDisconnect", "ServiceExecute", "ServiceObject", "ServiceRequest", "ServiceResponse", "ServiceSubmit", "SessionSubmit", "SessionTime", "Set", "SetAccuracy", "SetAlphaChannel", "SetAttributes", "Setbacks", "SetCloudDirectory", "SetCookies", "SetDelayed", "SetDirectory", "SetEnvironment", "SetFileDate", "SetFileFormatProperties", "SetOptions", "SetOptionsPacket", "SetPermissions", "SetPrecision", "SetProperty", "SetSecuredAuthenticationKey", "SetSelectedNotebook", "SetSharedFunction", "SetSharedVariable", "SetStreamPosition", "SetSystemModel", "SetSystemOptions", "Setter", "SetterBar", "SetterBox", "SetterBoxOptions", "Setting", "SetUsers", "Shading", "Shallow", "ShannonWavelet", "ShapiroWilkTest", "Share", "SharingList", "Sharpen", "ShearingMatrix", "ShearingTransform", "ShellRegion", "ShenCastanMatrix", "ShiftedGompertzDistribution", "ShiftRegisterSequence", "Short", "ShortDownArrow", "Shortest", "ShortestMatch", "ShortestPathFunction", "ShortLeftArrow", "ShortRightArrow", "ShortTimeFourier", "ShortTimeFourierData", "ShortUpArrow", "Show", "ShowAutoConvert", "ShowAutoSpellCheck", "ShowAutoStyles", "ShowCellBracket", "ShowCellLabel", "ShowCellTags", "ShowClosedCellArea", "ShowCodeAssist", "ShowContents", "ShowControls", "ShowCursorTracker", "ShowGroupOpenCloseIcon", "ShowGroupOpener", "ShowInvisibleCharacters", "ShowPageBreaks", "ShowPredictiveInterface", "ShowSelection", "ShowShortBoxForm", "ShowSpecialCharacters", "ShowStringCharacters", "ShowSyntaxStyles", "ShrinkingDelay", "ShrinkWrapBoundingBox", "SiderealTime", "SiegelTheta", "SiegelTukeyTest", "SierpinskiCurve", "SierpinskiMesh", "Sign", "Signature", "SignedRankTest", "SignedRegionDistance", "SignificanceLevel", "SignPadding", "SignTest", "SimilarityRules", "SimpleGraph", "SimpleGraphQ", "SimplePolygonQ", "SimplePolyhedronQ", "Simplex", "Simplify", "Sin", "Sinc", "SinghMaddalaDistribution", "SingleEvaluation", "SingleLetterItalics", "SingleLetterStyle", "SingularValueDecomposition", "SingularValueList", "SingularValuePlot", "SingularValues", "Sinh", "SinhIntegral", "SinIntegral", "SixJSymbol", "Skeleton", "SkeletonTransform", "SkellamDistribution", "Skewness", "SkewNormalDistribution", "SkinStyle", "Skip", "SliceContourPlot3D", "SliceDensityPlot3D", "SliceDistribution", "SliceVectorPlot3D", "Slider", "Slider2D", "Slider2DBox", "Slider2DBoxOptions", "SliderBox", "SliderBoxOptions", "SlideShowVideo", "SlideView", "Slot", "SlotSequence", "Small", "SmallCircle", "Smaller", "SmithDecomposition", "SmithDelayCompensator", "SmithWatermanSimilarity", "SmoothDensityHistogram", "SmoothHistogram", "SmoothHistogram3D", "SmoothKernelDistribution", "SmoothPointDensity", "SnDispersion", "Snippet", "SnippetsVideo", "SnubPolyhedron", "SocialMediaData", "Socket", "SocketConnect", "SocketListen", "SocketListener", "SocketObject", "SocketOpen", "SocketReadMessage", "SocketReadyQ", "Sockets", "SocketWaitAll", "SocketWaitNext", "SoftmaxLayer", "SokalSneathDissimilarity", "SolarEclipse", "SolarSystemFeatureData", "SolarTime", "SolidAngle", "SolidBoundaryLoadValue", "SolidData", "SolidDisplacementCondition", "SolidFixedCondition", "SolidMechanicsPDEComponent", "SolidMechanicsStrain", "SolidMechanicsStress", "SolidRegionQ", "Solve", "SolveAlways", "SolveDelayed", "SolveValues", "Sort", "SortBy", "SortedBy", "SortedEntityClass", "Sound", "SoundAndGraphics", "SoundNote", "SoundVolume", "SourceLink", "SourcePDETerm", "Sow", "Space", "SpaceCurveData", "SpaceForm", "Spacer", "Spacings", "Span", "SpanAdjustments", "SpanCharacterRounding", "SpanFromAbove", "SpanFromBoth", "SpanFromLeft", "SpanLineThickness", "SpanMaxSize", "SpanMinSize", "SpanningCharacters", "SpanSymmetric", "SparseArray", "SparseArrayQ", "SpatialBinnedPointData", "SpatialBoundaryCorrection", "SpatialEstimate", "SpatialEstimatorFunction", "SpatialGraphDistribution", "SpatialJ", "SpatialMedian", "SpatialNoiseLevel", "SpatialObservationRegionQ", "SpatialPointData", "SpatialPointSelect", "SpatialRandomnessTest", "SpatialTransformationLayer", "SpatialTrendFunction", "Speak", "SpeakerMatchQ", "SpearmanRankTest", "SpearmanRho", "SpeciesData", "SpecificityGoal", "SpectralLineData", "Spectrogram", "SpectrogramArray", "Specularity", "SpeechCases", "SpeechInterpreter", "SpeechRecognize", "SpeechSynthesize", "SpellingCorrection", "SpellingCorrectionList", "SpellingDictionaries", "SpellingDictionariesPath", "SpellingOptions", "Sphere", "SphereBox", "SphereBoxOptions", "SpherePoints", "SphericalBesselJ", "SphericalBesselY", "SphericalHankelH1", "SphericalHankelH2", "SphericalHarmonicY", "SphericalPlot3D", "SphericalRegion", "SphericalShell", "SpheroidalEigenvalue", "SpheroidalJoiningFactor", "SpheroidalPS", "SpheroidalPSPrime", "SpheroidalQS", "SpheroidalQSPrime", "SpheroidalRadialFactor", "SpheroidalS1", "SpheroidalS1Prime", "SpheroidalS2", "SpheroidalS2Prime", "Splice", "SplicedDistribution", "SplineClosed", "SplineDegree", "SplineKnots", "SplineWeights", "Split", "SplitBy", "SpokenString", "SpotLight", "Sqrt", "SqrtBox", "SqrtBoxOptions", "Square", "SquaredEuclideanDistance", "SquareFreeQ", "SquareIntersection", "SquareMatrixQ", "SquareRepeatingElement", "SquaresR", "SquareSubset", "SquareSubsetEqual", "SquareSuperset", "SquareSupersetEqual", "SquareUnion", "SquareWave", "SSSTriangle", "StabilityMargins", "StabilityMarginsStyle", "StableDistribution", "Stack", "StackBegin", "StackComplete", "StackedDateListPlot", "StackedListPlot", "StackInhibit", "StadiumShape", "StandardAtmosphereData", "StandardDeviation", "StandardDeviationFilter", "StandardForm", "Standardize", "Standardized", "StandardOceanData", "StandbyDistribution", "Star", "StarClusterData", "StarData", "StarGraph", "StartAsynchronousTask", "StartExternalSession", "StartingStepSize", "StartOfLine", "StartOfString", "StartProcess", "StartScheduledTask", "StartupSound", "StartWebSession", "StateDimensions", "StateFeedbackGains", "StateOutputEstimator", "StateResponse", "StateSpaceModel", "StateSpaceRealization", "StateSpaceTransform", "StateTransformationLinearize", "StationaryDistribution", "StationaryWaveletPacketTransform", "StationaryWaveletTransform", "StatusArea", "StatusCentrality", "StepMonitor", "StereochemistryElements", "StieltjesGamma", "StippleShading", "StirlingS1", "StirlingS2", "StopAsynchronousTask", "StoppingPowerData", "StopScheduledTask", "StrataVariables", "StratonovichProcess", "StraussHardcorePointProcess", "StraussPointProcess", "StreamColorFunction", "StreamColorFunctionScaling", "StreamDensityPlot", "StreamMarkers", "StreamPlot", "StreamPlot3D", "StreamPoints", "StreamPosition", "Streams", "StreamScale", "StreamStyle", "StrictInequalities", "String", "StringBreak", "StringByteCount", "StringCases", "StringContainsQ", "StringCount", "StringDelete", "StringDrop", "StringEndsQ", "StringExpression", "StringExtract", "StringForm", "StringFormat", "StringFormatQ", "StringFreeQ", "StringInsert", "StringJoin", "StringLength", "StringMatchQ", "StringPadLeft", "StringPadRight", "StringPart", "StringPartition", "StringPosition", "StringQ", "StringRepeat", "StringReplace", "StringReplaceList", "StringReplacePart", "StringReverse", "StringRiffle", "StringRotateLeft", "StringRotateRight", "StringSkeleton", "StringSplit", "StringStartsQ", "StringTake", "StringTakeDrop", "StringTemplate", "StringToByteArray", "StringToStream", "StringTrim", "StripBoxes", "StripOnInput", "StripStyleOnPaste", "StripWrapperBoxes", "StrokeForm", "Struckthrough", "StructuralImportance", "StructuredArray", "StructuredArrayHeadQ", "StructuredSelection", "StruveH", "StruveL", "Stub", "StudentTDistribution", "Style", "StyleBox", "StyleBoxAutoDelete", "StyleData", "StyleDefinitions", "StyleForm", "StyleHints", "StyleKeyMapping", "StyleMenuListing", "StyleNameDialogSettings", "StyleNames", "StylePrint", "StyleSheetPath", "Subdivide", "Subfactorial", "Subgraph", "SubMinus", "SubPlus", "SubresultantPolynomialRemainders", "SubresultantPolynomials", "Subresultants", "Subscript", "SubscriptBox", "SubscriptBoxOptions", "Subscripted", "Subsequences", "Subset", "SubsetCases", "SubsetCount", "SubsetEqual", "SubsetMap", "SubsetPosition", "SubsetQ", "SubsetReplace", "Subsets", "SubStar", "SubstitutionSystem", "Subsuperscript", "SubsuperscriptBox", "SubsuperscriptBoxOptions", "SubtitleEncoding", "SubtitleTrackSelection", "Subtract", "SubtractFrom", "SubtractSides", "SubValues", "Succeeds", "SucceedsEqual", "SucceedsSlantEqual", "SucceedsTilde", "Success", "SuchThat", "Sum", "SumConvergence", "SummationLayer", "Sunday", "SunPosition", "Sunrise", "Sunset", "SuperDagger", "SuperMinus", "SupernovaData", "SuperPlus", "Superscript", "SuperscriptBox", "SuperscriptBoxOptions", "Superset", "SupersetEqual", "SuperStar", "Surd", "SurdForm", "SurfaceAppearance", "SurfaceArea", "SurfaceColor", "SurfaceData", "SurfaceGraphics", "SurvivalDistribution", "SurvivalFunction", "SurvivalModel", "SurvivalModelFit", "SuspendPacket", "SuzukiDistribution", "SuzukiGroupSuz", "SwatchLegend", "Switch", "Symbol", "SymbolName", "SymletWavelet", "Symmetric", "SymmetricDifference", "SymmetricGroup", "SymmetricKey", "SymmetricMatrixQ", "SymmetricPolynomial", "SymmetricReduction", "Symmetrize", "SymmetrizedArray", "SymmetrizedArrayRules", "SymmetrizedDependentComponents", "SymmetrizedIndependentComponents", "SymmetrizedReplacePart", "SynchronousInitialization", "SynchronousUpdating", "Synonyms", "Syntax", "SyntaxForm", "SyntaxInformation", "SyntaxLength", "SyntaxPacket", "SyntaxQ", "SynthesizeMissingValues", "SystemCredential", "SystemCredentialData", "SystemCredentialKey", "SystemCredentialKeys", "SystemCredentialStoreObject", "SystemDialogInput", "SystemException", "SystemGet", "SystemHelpPath", "SystemInformation", "SystemInformationData", "SystemInstall", "SystemModel", "SystemModeler", "SystemModelExamples", "SystemModelLinearize", "SystemModelMeasurements", "SystemModelParametricSimulate", "SystemModelPlot", "SystemModelProgressReporting", "SystemModelReliability", "SystemModels", "SystemModelSimulate", "SystemModelSimulateSensitivity", "SystemModelSimulationData", "SystemOpen", "SystemOptions", "SystemProcessData", "SystemProcesses", "SystemsConnectionsModel", "SystemsModelControllerData", "SystemsModelDelay", "SystemsModelDelayApproximate", "SystemsModelDelete", "SystemsModelDimensions", "SystemsModelExtract", "SystemsModelFeedbackConnect", "SystemsModelLabels", "SystemsModelLinearity", "SystemsModelMerge", "SystemsModelOrder", "SystemsModelParallelConnect", "SystemsModelSeriesConnect", "SystemsModelStateFeedbackConnect", "SystemsModelVectorRelativeOrders", "SystemStub", "SystemTest", "Tab", "TabFilling", "Table", "TableAlignments", "TableDepth", "TableDirections", "TableForm", "TableHeadings", "TableSpacing", "TableView", "TableViewBox", "TableViewBoxAlignment", "TableViewBoxBackground", "TableViewBoxHeaders", "TableViewBoxItemSize", "TableViewBoxItemStyle", "TableViewBoxOptions", "TabSpacings", "TabView", "TabViewBox", "TabViewBoxOptions", "TagBox", "TagBoxNote", "TagBoxOptions", "TaggingRules", "TagSet", "TagSetDelayed", "TagStyle", "TagUnset", "Take", "TakeDrop", "TakeLargest", "TakeLargestBy", "TakeList", "TakeSmallest", "TakeSmallestBy", "TakeWhile", "Tally", "Tan", "Tanh", "TargetDevice", "TargetFunctions", "TargetSystem", "TargetUnits", "TaskAbort", "TaskExecute", "TaskObject", "TaskRemove", "TaskResume", "Tasks", "TaskSuspend", "TaskWait", "TautologyQ", "TelegraphProcess", "TemplateApply", "TemplateArgBox", "TemplateBox", "TemplateBoxOptions", "TemplateEvaluate", "TemplateExpression", "TemplateIf", "TemplateObject", "TemplateSequence", "TemplateSlot", "TemplateSlotSequence", "TemplateUnevaluated", "TemplateVerbatim", "TemplateWith", "TemporalData", "TemporalRegularity", "Temporary", "TemporaryVariable", "TensorContract", "TensorDimensions", "TensorExpand", "TensorProduct", "TensorQ", "TensorRank", "TensorReduce", "TensorSymmetry", "TensorTranspose", "TensorWedge", "TerminatedEvaluation", "TernaryListPlot", "TernaryPlotCorners", "TestID", "TestReport", "TestReportObject", "TestResultObject", "Tetrahedron", "TetrahedronBox", "TetrahedronBoxOptions", "TeXForm", "TeXSave", "Text", "Text3DBox", "Text3DBoxOptions", "TextAlignment", "TextBand", "TextBoundingBox", "TextBox", "TextCases", "TextCell", "TextClipboardType", "TextContents", "TextData", "TextElement", "TextForm", "TextGrid", "TextJustification", "TextLine", "TextPacket", "TextParagraph", "TextPosition", "TextRecognize", "TextSearch", "TextSearchReport", "TextSentences", "TextString", "TextStructure", "TextStyle", "TextTranslation", "Texture", "TextureCoordinateFunction", "TextureCoordinateScaling", "TextWords", "Therefore", "ThermodynamicData", "ThermometerGauge", "Thick", "Thickness", "Thin", "Thinning", "ThisLink", "ThomasPointProcess", "ThompsonGroupTh", "Thread", "Threaded", "ThreadingLayer", "ThreeJSymbol", "Threshold", "Through", "Throw", "ThueMorse", "Thumbnail", "Thursday", "TickDirection", "TickLabelOrientation", "TickLabelPositioning", "TickLabels", "TickLengths", "TickPositions", "Ticks", "TicksStyle", "TideData", "Tilde", "TildeEqual", "TildeFullEqual", "TildeTilde", "TimeConstrained", "TimeConstraint", "TimeDirection", "TimeFormat", "TimeGoal", "TimelinePlot", "TimeObject", "TimeObjectQ", "TimeRemaining", "Times", "TimesBy", "TimeSeries", "TimeSeriesAggregate", "TimeSeriesForecast", "TimeSeriesInsert", "TimeSeriesInvertibility", "TimeSeriesMap", "TimeSeriesMapThread", "TimeSeriesModel", "TimeSeriesModelFit", "TimeSeriesResample", "TimeSeriesRescale", "TimeSeriesShift", "TimeSeriesThread", "TimeSeriesWindow", "TimeSystem", "TimeSystemConvert", "TimeUsed", "TimeValue", "TimeWarpingCorrespondence", "TimeWarpingDistance", "TimeZone", "TimeZoneConvert", "TimeZoneOffset", "Timing", "Tiny", "TitleGrouping", "TitsGroupT", "ToBoxes", "ToCharacterCode", "ToColor", "ToContinuousTimeModel", "ToDate", "Today", "ToDiscreteTimeModel", "ToEntity", "ToeplitzMatrix", "ToExpression", "ToFileName", "Together", "Toggle", "ToggleFalse", "Toggler", "TogglerBar", "TogglerBox", "TogglerBoxOptions", "ToHeldExpression", "ToInvertibleTimeSeries", "TokenWords", "Tolerance", "ToLowerCase", "Tomorrow", "ToNumberField", "TooBig", "Tooltip", "TooltipBox", "TooltipBoxOptions", "TooltipDelay", "TooltipStyle", "ToonShading", "Top", "TopHatTransform", "ToPolarCoordinates", "TopologicalSort", "ToRadicals", "ToRawPointer", "ToRules", "Torus", "TorusGraph", "ToSphericalCoordinates", "ToString", "Total", "TotalHeight", "TotalLayer", "TotalVariationFilter", "TotalWidth", "TouchPosition", "TouchscreenAutoZoom", "TouchscreenControlPlacement", "ToUpperCase", "TourVideo", "Tr", "Trace", "TraceAbove", "TraceAction", "TraceBackward", "TraceDepth", "TraceDialog", "TraceForward", "TraceInternal", "TraceLevel", "TraceOff", "TraceOn", "TraceOriginal", "TracePrint", "TraceScan", "TrackCellChangeTimes", "TrackedSymbols", "TrackingFunction", "TracyWidomDistribution", "TradingChart", "TraditionalForm", "TraditionalFunctionNotation", "TraditionalNotation", "TraditionalOrder", "TrainImageContentDetector", "TrainingProgressCheckpointing", "TrainingProgressFunction", "TrainingProgressMeasurements", "TrainingProgressReporting", "TrainingStoppingCriterion", "TrainingUpdateSchedule", "TrainTextContentDetector", "TransferFunctionCancel", "TransferFunctionExpand", "TransferFunctionFactor", "TransferFunctionModel", "TransferFunctionPoles", "TransferFunctionTransform", "TransferFunctionZeros", "TransformationClass", "TransformationFunction", "TransformationFunctions", "TransformationMatrix", "TransformedDistribution", "TransformedField", "TransformedProcess", "TransformedRegion", "TransitionDirection", "TransitionDuration", "TransitionEffect", "TransitiveClosureGraph", "TransitiveReductionGraph", "Translate", "TranslationOptions", "TranslationTransform", "Transliterate", "Transparent", "TransparentColor", "Transpose", "TransposeLayer", "TrapEnterKey", "TrapSelection", "TravelDirections", "TravelDirectionsData", "TravelDistance", "TravelDistanceList", "TravelMethod", "TravelTime", "Tree", "TreeCases", "TreeChildren", "TreeCount", "TreeData", "TreeDelete", "TreeDepth", "TreeElementCoordinates", "TreeElementLabel", "TreeElementLabelFunction", "TreeElementLabelStyle", "TreeElementShape", "TreeElementShapeFunction", "TreeElementSize", "TreeElementSizeFunction", "TreeElementStyle", "TreeElementStyleFunction", "TreeExpression", "TreeExtract", "TreeFold", "TreeForm", "TreeGraph", "TreeGraphQ", "TreeInsert", "TreeLayout", "TreeLeafCount", "TreeLeafQ", "TreeLeaves", "TreeLevel", "TreeMap", "TreeMapAt", "TreeOutline", "TreePlot", "TreePosition", "TreeQ", "TreeReplacePart", "TreeRules", "TreeScan", "TreeSelect", "TreeSize", "TreeTraversalOrder", "TrendStyle", "Triangle", "TriangleCenter", "TriangleConstruct", "TriangleMeasurement", "TriangleWave", "TriangularDistribution", "TriangulateMesh", "Trig", "TrigExpand", "TrigFactor", "TrigFactorList", "Trigger", "TrigReduce", "TrigToExp", "TrimmedMean", "TrimmedVariance", "TropicalStormData", "True", "TrueQ", "TruncatedDistribution", "TruncatedPolyhedron", "TsallisQExponentialDistribution", "TsallisQGaussianDistribution", "TTest", "Tube", "TubeBezierCurveBox", "TubeBezierCurveBoxOptions", "TubeBox", "TubeBoxOptions", "TubeBSplineCurveBox", "TubeBSplineCurveBoxOptions", "Tuesday", "TukeyLambdaDistribution", "TukeyWindow", "TunnelData", "Tuples", "TuranGraph", "TuringMachine", "TuttePolynomial", "TwoWayRule", "Typed", "TypeDeclaration", "TypeEvaluate", "TypeHint", "TypeOf", "TypeSpecifier", "UnateQ", "Uncompress", "UnconstrainedParameters", "Undefined", "UnderBar", "Underflow", "Underlined", "Underoverscript", "UnderoverscriptBox", "UnderoverscriptBoxOptions", "Underscript", "UnderscriptBox", "UnderscriptBoxOptions", "UnderseaFeatureData", "UndirectedEdge", "UndirectedGraph", "UndirectedGraphQ", "UndoOptions", "UndoTrackedVariables", "Unequal", "UnequalTo", "Unevaluated", "UniformDistribution", "UniformGraphDistribution", "UniformPolyhedron", "UniformSumDistribution", "Uninstall", "Union", "UnionedEntityClass", "UnionPlus", "Unique", "UniqueElements", "UnitaryMatrixQ", "UnitBox", "UnitConvert", "UnitDimensions", "Unitize", "UnitRootTest", "UnitSimplify", "UnitStep", "UnitSystem", "UnitTriangle", "UnitVector", "UnitVectorLayer", "UnityDimensions", "UniverseModelData", "UniversityData", "UnixTime", "UnlabeledTree", "UnmanageObject", "Unprotect", "UnregisterExternalEvaluator", "UnsameQ", "UnsavedVariables", "Unset", "UnsetShared", "Until", "UntrackedVariables", "Up", "UpArrow", "UpArrowBar", "UpArrowDownArrow", "Update", "UpdateDynamicObjects", "UpdateDynamicObjectsSynchronous", "UpdateInterval", "UpdatePacletSites", "UpdateSearchIndex", "UpDownArrow", "UpEquilibrium", "UpperCaseQ", "UpperLeftArrow", "UpperRightArrow", "UpperTriangularize", "UpperTriangularMatrix", "UpperTriangularMatrixQ", "Upsample", "UpSet", "UpSetDelayed", "UpTee", "UpTeeArrow", "UpTo", "UpValues", "URL", "URLBuild", "URLDecode", "URLDispatcher", "URLDownload", "URLDownloadSubmit", "URLEncode", "URLExecute", "URLExpand", "URLFetch", "URLFetchAsynchronous", "URLParse", "URLQueryDecode", "URLQueryEncode", "URLRead", "URLResponseTime", "URLSave", "URLSaveAsynchronous", "URLShorten", "URLSubmit", "UseEmbeddedLibrary", "UseGraphicsRange", "UserDefinedWavelet", "Using", "UsingFrontEnd", "UtilityFunction", "V2Get", "ValenceErrorHandling", "ValenceFilling", "ValidationLength", "ValidationSet", "ValueBox", "ValueBoxOptions", "ValueDimensions", "ValueForm", "ValuePreprocessingFunction", "ValueQ", "Values", "ValuesData", "VandermondeMatrix", "Variables", "Variance", "VarianceEquivalenceTest", "VarianceEstimatorFunction", "VarianceGammaDistribution", "VarianceGammaPointProcess", "VarianceTest", "VariogramFunction", "VariogramModel", "VectorAngle", "VectorAround", "VectorAspectRatio", "VectorColorFunction", "VectorColorFunctionScaling", "VectorDensityPlot", "VectorDisplacementPlot", "VectorDisplacementPlot3D", "VectorGlyphData", "VectorGreater", "VectorGreaterEqual", "VectorLess", "VectorLessEqual", "VectorMarkers", "VectorPlot", "VectorPlot3D", "VectorPoints", "VectorQ", "VectorRange", "Vectors", "VectorScale", "VectorScaling", "VectorSizes", "VectorStyle", "Vee", "Verbatim", "Verbose", "VerificationTest", "VerifyConvergence", "VerifyDerivedKey", "VerifyDigitalSignature", "VerifyFileSignature", "VerifyInterpretation", "VerifySecurityCertificates", "VerifySolutions", "VerifyTestAssumptions", "VersionedPreferences", "VertexAdd", "VertexCapacity", "VertexChromaticNumber", "VertexColors", "VertexComponent", "VertexConnectivity", "VertexContract", "VertexCoordinateRules", "VertexCoordinates", "VertexCorrelationSimilarity", "VertexCosineSimilarity", "VertexCount", "VertexCoverQ", "VertexDataCoordinates", "VertexDegree", "VertexDelete", "VertexDiceSimilarity", "VertexEccentricity", "VertexInComponent", "VertexInComponentGraph", "VertexInDegree", "VertexIndex", "VertexJaccardSimilarity", "VertexLabeling", "VertexLabels", "VertexLabelStyle", "VertexList", "VertexNormals", "VertexOutComponent", "VertexOutComponentGraph", "VertexOutDegree", "VertexQ", "VertexRenderingFunction", "VertexReplace", "VertexShape", "VertexShapeFunction", "VertexSize", "VertexStyle", "VertexTextureCoordinates", "VertexTransitiveGraphQ", "VertexWeight", "VertexWeightedGraphQ", "Vertical", "VerticalBar", "VerticalForm", "VerticalGauge", "VerticalSeparator", "VerticalSlider", "VerticalTilde", "Video", "VideoCapture", "VideoCombine", "VideoDelete", "VideoEncoding", "VideoExtractFrames", "VideoFrameList", "VideoFrameMap", "VideoGenerator", "VideoInsert", "VideoIntervals", "VideoJoin", "VideoMap", "VideoMapList", "VideoMapTimeSeries", "VideoPadding", "VideoPause", "VideoPlay", "VideoQ", "VideoRecord", "VideoReplace", "VideoScreenCapture", "VideoSplit", "VideoStop", "VideoStream", "VideoStreams", "VideoTimeStretch", "VideoTrackSelection", "VideoTranscode", "VideoTransparency", "VideoTrim", "ViewAngle", "ViewCenter", "ViewMatrix", "ViewPoint", "ViewPointSelectorSettings", "ViewPort", "ViewProjection", "ViewRange", "ViewVector", "ViewVertical", "VirtualGroupData", "Visible", "VisibleCell", "VoiceStyleData", "VoigtDistribution", "VolcanoData", "Volume", "VonMisesDistribution", "VoronoiMesh", "WaitAll", "WaitAsynchronousTask", "WaitNext", "WaitUntil", "WakebyDistribution", "WalleniusHypergeometricDistribution", "WaringYuleDistribution", "WarpingCorrespondence", "WarpingDistance", "WatershedComponents", "WatsonUSquareTest", "WattsStrogatzGraphDistribution", "WaveletBestBasis", "WaveletFilterCoefficients", "WaveletImagePlot", "WaveletListPlot", "WaveletMapIndexed", "WaveletMatrixPlot", "WaveletPhi", "WaveletPsi", "WaveletScale", "WaveletScalogram", "WaveletThreshold", "WavePDEComponent", "WeaklyConnectedComponents", "WeaklyConnectedGraphComponents", "WeaklyConnectedGraphQ", "WeakStationarity", "WeatherData", "WeatherForecastData", "WebAudioSearch", "WebColumn", "WebElementObject", "WeberE", "WebExecute", "WebImage", "WebImageSearch", "WebItem", "WebPageMetaInformation", "WebRow", "WebSearch", "WebSessionObject", "WebSessions", "WebWindowObject", "Wedge", "Wednesday", "WeibullDistribution", "WeierstrassE1", "WeierstrassE2", "WeierstrassE3", "WeierstrassEta1", "WeierstrassEta2", "WeierstrassEta3", "WeierstrassHalfPeriods", "WeierstrassHalfPeriodW1", "WeierstrassHalfPeriodW2", "WeierstrassHalfPeriodW3", "WeierstrassInvariantG2", "WeierstrassInvariantG3", "WeierstrassInvariants", "WeierstrassP", "WeierstrassPPrime", "WeierstrassSigma", "WeierstrassZeta", "WeightedAdjacencyGraph", "WeightedAdjacencyMatrix", "WeightedData", "WeightedGraphQ", "Weights", "WelchWindow", "WheelGraph", "WhenEvent", "Which", "While", "White", "WhiteNoiseProcess", "WhitePoint", "Whitespace", "WhitespaceCharacter", "WhittakerM", "WhittakerW", "WholeCellGroupOpener", "WienerFilter", "WienerProcess", "WignerD", "WignerSemicircleDistribution", "WikidataData", "WikidataSearch", "WikipediaData", "WikipediaSearch", "WilksW", "WilksWTest", "WindDirectionData", "WindingCount", "WindingPolygon", "WindowClickSelect", "WindowElements", "WindowFloating", "WindowFrame", "WindowFrameElements", "WindowMargins", "WindowMovable", "WindowOpacity", "WindowPersistentStyles", "WindowSelected", "WindowSize", "WindowStatusArea", "WindowTitle", "WindowToolbars", "WindowWidth", "WindSpeedData", "WindVectorData", "WinsorizedMean", "WinsorizedVariance", "WishartMatrixDistribution", "With", "WithCleanup", "WithLock", "WolframAlpha", "WolframAlphaDate", "WolframAlphaQuantity", "WolframAlphaResult", "WolframCloudSettings", "WolframLanguageData", "Word", "WordBoundary", "WordCharacter", "WordCloud", "WordCount", "WordCounts", "WordData", "WordDefinition", "WordFrequency", "WordFrequencyData", "WordList", "WordOrientation", "WordSearch", "WordSelectionFunction", "WordSeparators", "WordSpacings", "WordStem", "WordTranslation", "WorkingPrecision", "WrapAround", "Write", "WriteLine", "WriteString", "Wronskian", "XMLElement", "XMLObject", "XMLTemplate", "Xnor", "Xor", "XYZColor", "Yellow", "Yesterday", "YuleDissimilarity", "ZernikeR", "ZeroSymmetric", "ZeroTest", "ZeroWidthTimes", "Zeta", "ZetaZero", "ZIPCodeData", "ZipfDistribution", "ZoomCenter", "ZoomFactor", "ZTest", "ZTransform", "$Aborted", "$ActivationGroupID", "$ActivationKey", "$ActivationUserRegistered", "$AddOnsDirectory", "$AllowDataUpdates", "$AllowExternalChannelFunctions", "$AllowInternet", "$AssertFunction", "$Assumptions", "$AsynchronousTask", "$AudioDecoders", "$AudioEncoders", "$AudioInputDevices", "$AudioOutputDevices", "$BaseDirectory", "$BasePacletsDirectory", "$BatchInput", "$BatchOutput", "$BlockchainBase", "$BoxForms", "$ByteOrdering", "$CacheBaseDirectory", "$Canceled", "$ChannelBase", "$CharacterEncoding", "$CharacterEncodings", "$CloudAccountName", "$CloudBase", "$CloudConnected", "$CloudConnection", "$CloudCreditsAvailable", "$CloudEvaluation", "$CloudExpressionBase", "$CloudObjectNameFormat", "$CloudObjectURLType", "$CloudRootDirectory", "$CloudSymbolBase", "$CloudUserID", "$CloudUserUUID", "$CloudVersion", "$CloudVersionNumber", "$CloudWolframEngineVersionNumber", "$CommandLine", "$CompilationTarget", "$CompilerEnvironment", "$ConditionHold", "$ConfiguredKernels", "$Context", "$ContextAliases", "$ContextPath", "$ControlActiveSetting", "$Cookies", "$CookieStore", "$CreationDate", "$CryptographicEllipticCurveNames", "$CurrentLink", "$CurrentTask", "$CurrentWebSession", "$DataStructures", "$DateStringFormat", "$DefaultAudioInputDevice", "$DefaultAudioOutputDevice", "$DefaultFont", "$DefaultFrontEnd", "$DefaultImagingDevice", "$DefaultKernels", "$DefaultLocalBase", "$DefaultLocalKernel", "$DefaultMailbox", "$DefaultNetworkInterface", "$DefaultPath", "$DefaultProxyRules", "$DefaultRemoteBatchSubmissionEnvironment", "$DefaultRemoteKernel", "$DefaultSystemCredentialStore", "$Display", "$DisplayFunction", "$DistributedContexts", "$DynamicEvaluation", "$Echo", "$EmbedCodeEnvironments", "$EmbeddableServices", "$EntityStores", "$Epilog", "$EvaluationCloudBase", "$EvaluationCloudObject", "$EvaluationEnvironment", "$ExportFormats", "$ExternalIdentifierTypes", "$ExternalStorageBase", "$Failed", "$FinancialDataSource", "$FontFamilies", "$FormatType", "$FrontEnd", "$FrontEndSession", "$GeneratedAssetLocation", "$GeoEntityTypes", "$GeoLocation", "$GeoLocationCity", "$GeoLocationCountry", "$GeoLocationPrecision", "$GeoLocationSource", "$HistoryLength", "$HomeDirectory", "$HTMLExportRules", "$HTTPCookies", "$HTTPRequest", "$IgnoreEOF", "$ImageFormattingWidth", "$ImageResolution", "$ImagingDevice", "$ImagingDevices", "$ImportFormats", "$IncomingMailSettings", "$InitialDirectory", "$Initialization", "$InitializationContexts", "$Input", "$InputFileName", "$InputStreamMethods", "$Inspector", "$InstallationDate", "$InstallationDirectory", "$InterfaceEnvironment", "$InterpreterTypes", "$IterationLimit", "$KernelCount", "$KernelID", "$Language", "$LaunchDirectory", "$LibraryPath", "$LicenseExpirationDate", "$LicenseID", "$LicenseProcesses", "$LicenseServer", "$LicenseSubprocesses", "$LicenseType", "$Line", "$Linked", "$LinkSupported", "$LoadedFiles", "$LocalBase", "$LocalSymbolBase", "$MachineAddresses", "$MachineDomain", "$MachineDomains", "$MachineEpsilon", "$MachineID", "$MachineName", "$MachinePrecision", "$MachineType", "$MaxDisplayedChildren", "$MaxExtraPrecision", "$MaxLicenseProcesses", "$MaxLicenseSubprocesses", "$MaxMachineNumber", "$MaxNumber", "$MaxPiecewiseCases", "$MaxPrecision", "$MaxRootDegree", "$MessageGroups", "$MessageList", "$MessagePrePrint", "$Messages", "$MinMachineNumber", "$MinNumber", "$MinorReleaseNumber", "$MinPrecision", "$MobilePhone", "$ModuleNumber", "$NetworkConnected", "$NetworkInterfaces", "$NetworkLicense", "$NewMessage", "$NewSymbol", "$NotebookInlineStorageLimit", "$Notebooks", "$NoValue", "$NumberMarks", "$Off", "$OperatingSystem", "$Output", "$OutputForms", "$OutputSizeLimit", "$OutputStreamMethods", "$Packages", "$ParentLink", "$ParentProcessID", "$PasswordFile", "$PatchLevelID", "$Path", "$PathnameSeparator", "$PerformanceGoal", "$Permissions", "$PermissionsGroupBase", "$PersistenceBase", "$PersistencePath", "$PipeSupported", "$PlotTheme", "$Post", "$Pre", "$PreferencesDirectory", "$PreInitialization", "$PrePrint", "$PreRead", "$PrintForms", "$PrintLiteral", "$Printout3DPreviewer", "$ProcessID", "$ProcessorCount", "$ProcessorType", "$ProductInformation", "$ProgramName", "$ProgressReporting", "$PublisherID", "$RandomGeneratorState", "$RandomState", "$RecursionLimit", "$RegisteredDeviceClasses", "$RegisteredUserName", "$ReleaseNumber", "$RequesterAddress", "$RequesterCloudUserID", "$RequesterCloudUserUUID", "$RequesterWolframID", "$RequesterWolframUUID", "$ResourceSystemBase", "$ResourceSystemPath", "$RootDirectory", "$ScheduledTask", "$ScriptCommandLine", "$ScriptInputString", "$SecuredAuthenticationKeyTokens", "$ServiceCreditsAvailable", "$Services", "$SessionID", "$SetParentLink", "$SharedFunctions", "$SharedVariables", "$SoundDisplay", "$SoundDisplayFunction", "$SourceLink", "$SSHAuthentication", "$SubtitleDecoders", "$SubtitleEncoders", "$SummaryBoxDataSizeLimit", "$SuppressInputFormHeads", "$SynchronousEvaluation", "$SyntaxHandler", "$System", "$SystemCharacterEncoding", "$SystemCredentialStore", "$SystemID", "$SystemMemory", "$SystemShell", "$SystemTimeZone", "$SystemWordLength", "$TargetSystems", "$TemplatePath", "$TemporaryDirectory", "$TemporaryPrefix", "$TestFileName", "$TextStyle", "$TimedOut", "$TimeUnit", "$TimeZone", "$TimeZoneEntity", "$TopDirectory", "$TraceOff", "$TraceOn", "$TracePattern", "$TracePostAction", "$TracePreAction", "$UnitSystem", "$Urgent", "$UserAddOnsDirectory", "$UserAgentLanguages", "$UserAgentMachine", "$UserAgentName", "$UserAgentOperatingSystem", "$UserAgentString", "$UserAgentVersion", "$UserBaseDirectory", "$UserBasePacletsDirectory", "$UserDocumentsDirectory", "$Username", "$UserName", "$UserURLBase", "$Version", "$VersionNumber", "$VideoDecoders", "$VideoEncoders", "$VoiceStyles", "$WolframDocumentsDirectory", "$WolframID", "$WolframUUID"];

function ft(e) {
    const t = e.regex,
        n = /([2-9]|[1-2]\d|[3][0-5])\^\^/,
        i = /(\w*\.\w+|\w+\.\w*|\w+)/,
        a = /(\d*\.\d+|\d+\.\d*|\d+)/,
        u = t.either(t.concat(n, i), a),
        s = /``[+-]?(\d*\.\d+|\d+\.\d*|\d+)/,
        o = /`([+-]?(\d*\.\d+|\d+\.\d*|\d+))?/,
        c = t.either(s, o),
        r = /\*\^[+-]?\d+/,
        p = {
            className: "number",
            relevance: 0,
            begin: t.concat(u, t.optional(c), t.optional(r))
        },
        d = /[a-zA-Z$][a-zA-Z0-9$]*/,
        m = new Set(He),
        b = {
            variants: [{
                className: "builtin-symbol",
                begin: d,
                "on:begin": (A, C) => {
                    m.has(A[0]) || C.ignoreMatch()
                }
            }, {
                className: "symbol",
                relevance: 0,
                begin: d
            }]
        },
        g = {
            className: "named-character",
            begin: /\\\[[$a-zA-Z][$a-zA-Z0-9]+\]/
        },
        E = {
            className: "operator",
            relevance: 0,
            begin: /[+\-*/,;.:@~=><&|_`'^?!%]+/
        },
        S = {
            className: "pattern",
            relevance: 0,
            begin: /([a-zA-Z$][a-zA-Z0-9$]*)?_+([a-zA-Z$][a-zA-Z0-9$]*)?/
        },
        N = {
            className: "slot",
            relevance: 0,
            begin: /#[a-zA-Z$][a-zA-Z0-9$]*|#+[0-9]?/
        },
        _ = {
            className: "brace",
            relevance: 0,
            begin: /[[\](){}]/
        },
        T = {
            className: "message-name",
            relevance: 0,
            begin: t.concat("::", d)
        };
    return {
        name: "Mathematica",
        aliases: ["mma", "wl"],
        classNameAliases: {
            brace: "punctuation",
            pattern: "type",
            slot: "type",
            symbol: "variable",
            "named-character": "variable",
            "builtin-symbol": "built_in",
            "message-name": "string"
        },
        contains: [e.COMMENT(/\(\*/, /\*\)/, {
            contains: ["self"]
        }), S, N, T, b, g, e.QUOTE_STRING_MODE, p, E, _]
    }
}

function Mt(e) {
    const t = "('|\\.')+",
        n = {
            relevance: 0,
            contains: [{
                begin: t
            }]
        };
    return {
        name: "Matlab",
        keywords: {
            keyword: "arguments break case catch classdef continue else elseif end enumeration events for function global if methods otherwise parfor persistent properties return spmd switch try while",
            built_in: "sin sind sinh asin asind asinh cos cosd cosh acos acosd acosh tan tand tanh atan atand atan2 atanh sec secd sech asec asecd asech csc cscd csch acsc acscd acsch cot cotd coth acot acotd acoth hypot exp expm1 log log1p log10 log2 pow2 realpow reallog realsqrt sqrt nthroot nextpow2 abs angle complex conj imag real unwrap isreal cplxpair fix floor ceil round mod rem sign airy besselj bessely besselh besseli besselk beta betainc betaln ellipj ellipke erf erfc erfcx erfinv expint gamma gammainc gammaln psi legendre cross dot factor isprime primes gcd lcm rat rats perms nchoosek factorial cart2sph cart2pol pol2cart sph2cart hsv2rgb rgb2hsv zeros ones eye repmat rand randn linspace logspace freqspace meshgrid accumarray size length ndims numel disp isempty isequal isequalwithequalnans cat reshape diag blkdiag tril triu fliplr flipud flipdim rot90 find sub2ind ind2sub bsxfun ndgrid permute ipermute shiftdim circshift squeeze isscalar isvector ans eps realmax realmin pi i|0 inf nan isnan isinf isfinite j|0 why compan gallery hadamard hankel hilb invhilb magic pascal rosser toeplitz vander wilkinson max min nanmax nanmin mean nanmean type table readtable writetable sortrows sort figure plot plot3 scatter scatter3 cellfun legend intersect ismember procrustes hold num2cell "
        },
        illegal: '(//|"|#|/\\*|\\s+/\\w+)',
        contains: [{
            className: "function",
            beginKeywords: "function",
            end: "$",
            contains: [e.UNDERSCORE_TITLE_MODE, {
                className: "params",
                variants: [{
                    begin: "\\(",
                    end: "\\)"
                }, {
                    begin: "\\[",
                    end: "\\]"
                }]
            }]
        }, {
            className: "built_in",
            begin: /true|false/,
            relevance: 0,
            starts: n
        }, {
            begin: "[a-zA-Z][a-zA-Z_0-9]*" + t,
            relevance: 0
        }, {
            className: "number",
            begin: e.C_NUMBER_RE,
            relevance: 0,
            starts: n
        }, {
            className: "string",
            begin: "'",
            end: "'",
            contains: [{
                begin: "''"
            }]
        }, {
            begin: /\]|\}|\)/,
            relevance: 0,
            starts: n
        }, {
            className: "string",
            begin: '"',
            end: '"',
            contains: [{
                begin: '""'
            }],
            starts: n
        }, e.COMMENT("^\\s*%\\{\\s*$", "^\\s*%\\}\\s*$"), e.COMMENT("%", "$")]
    }
}

function Pt(e) {
    const t = e.regex,
        n = {
            className: "variable",
            variants: [{
                begin: /\$\d+/
            }, {
                begin: /\$\{\w+\}/
            }, {
                begin: t.concat(/[$@]/, e.UNDERSCORE_IDENT_RE)
            }]
        },
        a = {
            endsWithParent: !0,
            keywords: {
                $pattern: /[a-z_]{2,}|\/dev\/poll/,
                literal: ["on", "off", "yes", "no", "true", "false", "none", "blocked", "debug", "info", "notice", "warn", "error", "crit", "select", "break", "last", "permanent", "redirect", "kqueue", "rtsig", "epoll", "poll", "/dev/poll"]
            },
            relevance: 0,
            illegal: "=>",
            contains: [e.HASH_COMMENT_MODE, {
                className: "string",
                contains: [e.BACKSLASH_ESCAPE, n],
                variants: [{
                    begin: /"/,
                    end: /"/
                }, {
                    begin: /'/,
                    end: /'/
                }]
            }, {
                begin: "([a-z]+):/",
                end: "\\s",
                endsWithParent: !0,
                excludeEnd: !0,
                contains: [n]
            }, {
                className: "regexp",
                contains: [e.BACKSLASH_ESCAPE, n],
                variants: [{
                    begin: "\\s\\^",
                    end: "\\s|\\{|;",
                    returnEnd: !0
                }, {
                    begin: "~\\*?\\s+",
                    end: "\\s|\\{|;",
                    returnEnd: !0
                }, {
                    begin: "\\*(\\.[a-z\\-]+)+"
                }, {
                    begin: "([a-z\\-]+\\.)+\\*"
                }]
            }, {
                className: "number",
                begin: "\\b\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}(:\\d{1,5})?\\b"
            }, {
                className: "number",
                begin: "\\b\\d+[kKmMgGdshdwy]?\\b",
                relevance: 0
            }, n]
        };
    return {
        name: "Nginx config",
        aliases: ["nginxconf"],
        contains: [e.HASH_COMMENT_MODE, {
            beginKeywords: "upstream location",
            end: /;|\{/,
            contains: a.contains,
            keywords: {
                section: "upstream location"
            }
        }, {
            className: "section",
            begin: t.concat(e.UNDERSCORE_IDENT_RE + t.lookahead(/\s+\{/)),
            relevance: 0
        }, {
            begin: t.lookahead(e.UNDERSCORE_IDENT_RE + "\\s"),
            end: ";|\\{",
            contains: [{
                className: "attribute",
                begin: e.UNDERSCORE_IDENT_RE,
                starts: a
            }],
            relevance: 0
        }],
        illegal: "[^\\s\\}\\{]"
    }
}

function vt(e) {
    const t = e.COMMENT("--", "$"),
        n = "[a-zA-Z_][a-zA-Z_0-9$]*",
        i = "\\$([a-zA-Z_]?|[a-zA-Z_][a-zA-Z_0-9]*)\\$",
        a = "<<\\s*" + n + "\\s*>>",
        u = "ABORT ALTER ANALYZE BEGIN CALL CHECKPOINT|10 CLOSE CLUSTER COMMENT COMMIT COPY CREATE DEALLOCATE DECLARE DELETE DISCARD DO DROP END EXECUTE EXPLAIN FETCH GRANT IMPORT INSERT LISTEN LOAD LOCK MOVE NOTIFY PREPARE REASSIGN|10 REFRESH REINDEX RELEASE RESET REVOKE ROLLBACK SAVEPOINT SECURITY SELECT SET SHOW START TRUNCATE UNLISTEN|10 UPDATE VACUUM|10 VALUES AGGREGATE COLLATION CONVERSION|10 DATABASE DEFAULT PRIVILEGES DOMAIN TRIGGER EXTENSION FOREIGN WRAPPER|10 TABLE FUNCTION GROUP LANGUAGE LARGE OBJECT MATERIALIZED VIEW OPERATOR CLASS FAMILY POLICY PUBLICATION|10 ROLE RULE SCHEMA SEQUENCE SERVER STATISTICS SUBSCRIPTION SYSTEM TABLESPACE CONFIGURATION DICTIONARY PARSER TEMPLATE TYPE USER MAPPING PREPARED ACCESS METHOD CAST AS TRANSFORM TRANSACTION OWNED TO INTO SESSION AUTHORIZATION INDEX PROCEDURE ASSERTION ALL ANALYSE AND ANY ARRAY ASC ASYMMETRIC|10 BOTH CASE CHECK COLLATE COLUMN CONCURRENTLY|10 CONSTRAINT CROSS DEFERRABLE RANGE DESC DISTINCT ELSE EXCEPT FOR FREEZE|10 FROM FULL HAVING ILIKE IN INITIALLY INNER INTERSECT IS ISNULL JOIN LATERAL LEADING LIKE LIMIT NATURAL NOT NOTNULL NULL OFFSET ON ONLY OR ORDER OUTER OVERLAPS PLACING PRIMARY REFERENCES RETURNING SIMILAR SOME SYMMETRIC TABLESAMPLE THEN TRAILING UNION UNIQUE USING VARIADIC|10 VERBOSE WHEN WHERE WINDOW WITH BY RETURNS INOUT OUT SETOF|10 IF STRICT CURRENT CONTINUE OWNER LOCATION OVER PARTITION WITHIN BETWEEN ESCAPE EXTERNAL INVOKER DEFINER WORK RENAME VERSION CONNECTION CONNECT TABLES TEMP TEMPORARY FUNCTIONS SEQUENCES TYPES SCHEMAS OPTION CASCADE RESTRICT ADD ADMIN EXISTS VALID VALIDATE ENABLE DISABLE REPLICA|10 ALWAYS PASSING COLUMNS PATH REF VALUE OVERRIDING IMMUTABLE STABLE VOLATILE BEFORE AFTER EACH ROW PROCEDURAL ROUTINE NO HANDLER VALIDATOR OPTIONS STORAGE OIDS|10 WITHOUT INHERIT DEPENDS CALLED INPUT LEAKPROOF|10 COST ROWS NOWAIT SEARCH UNTIL ENCRYPTED|10 PASSWORD CONFLICT|10 INSTEAD INHERITS CHARACTERISTICS WRITE CURSOR ALSO STATEMENT SHARE EXCLUSIVE INLINE ISOLATION REPEATABLE READ COMMITTED SERIALIZABLE UNCOMMITTED LOCAL GLOBAL SQL PROCEDURES RECURSIVE SNAPSHOT ROLLUP CUBE TRUSTED|10 INCLUDE FOLLOWING PRECEDING UNBOUNDED RANGE GROUPS UNENCRYPTED|10 SYSID FORMAT DELIMITER HEADER QUOTE ENCODING FILTER OFF FORCE_QUOTE FORCE_NOT_NULL FORCE_NULL COSTS BUFFERS TIMING SUMMARY DISABLE_PAGE_SKIPPING RESTART CYCLE GENERATED IDENTITY DEFERRED IMMEDIATE LEVEL LOGGED UNLOGGED OF NOTHING NONE EXCLUDE ATTRIBUTE USAGE ROUTINES TRUE FALSE NAN INFINITY ",
        s = "SUPERUSER NOSUPERUSER CREATEDB NOCREATEDB CREATEROLE NOCREATEROLE INHERIT NOINHERIT LOGIN NOLOGIN REPLICATION NOREPLICATION BYPASSRLS NOBYPASSRLS ",
        o = "ALIAS BEGIN CONSTANT DECLARE END EXCEPTION RETURN PERFORM|10 RAISE GET DIAGNOSTICS STACKED|10 FOREACH LOOP ELSIF EXIT WHILE REVERSE SLICE DEBUG LOG INFO NOTICE WARNING ASSERT OPEN ",
        c = "BIGINT INT8 BIGSERIAL SERIAL8 BIT VARYING VARBIT BOOLEAN BOOL BOX BYTEA CHARACTER CHAR VARCHAR CIDR CIRCLE DATE DOUBLE PRECISION FLOAT8 FLOAT INET INTEGER INT INT4 INTERVAL JSON JSONB LINE LSEG|10 MACADDR MACADDR8 MONEY NUMERIC DEC DECIMAL PATH POINT POLYGON REAL FLOAT4 SMALLINT INT2 SMALLSERIAL|10 SERIAL2|10 SERIAL|10 SERIAL4|10 TEXT TIME ZONE TIMETZ|10 TIMESTAMP TIMESTAMPTZ|10 TSQUERY|10 TSVECTOR|10 TXID_SNAPSHOT|10 UUID XML NATIONAL NCHAR INT4RANGE|10 INT8RANGE|10 NUMRANGE|10 TSRANGE|10 TSTZRANGE|10 DATERANGE|10 ANYELEMENT ANYARRAY ANYNONARRAY ANYENUM ANYRANGE CSTRING INTERNAL RECORD PG_DDL_COMMAND VOID UNKNOWN OPAQUE REFCURSOR NAME OID REGPROC|10 REGPROCEDURE|10 REGOPER|10 REGOPERATOR|10 REGCLASS|10 REGTYPE|10 REGROLE|10 REGNAMESPACE|10 REGCONFIG|10 REGDICTIONARY|10 ",
        r = c.trim().split(" ").map(function(g) {
            return g.split("|")[0]
        }).join("|"),
        l = "CURRENT_TIME CURRENT_TIMESTAMP CURRENT_USER CURRENT_CATALOG|10 CURRENT_DATE LOCALTIME LOCALTIMESTAMP CURRENT_ROLE|10 CURRENT_SCHEMA|10 SESSION_USER PUBLIC ",
        p = "FOUND NEW OLD TG_NAME|10 TG_WHEN|10 TG_LEVEL|10 TG_OP|10 TG_RELID|10 TG_RELNAME|10 TG_TABLE_NAME|10 TG_TABLE_SCHEMA|10 TG_NARGS|10 TG_ARGV|10 TG_EVENT|10 TG_TAG|10 ROW_COUNT RESULT_OID|10 PG_CONTEXT|10 RETURNED_SQLSTATE COLUMN_NAME CONSTRAINT_NAME PG_DATATYPE_NAME|10 MESSAGE_TEXT TABLE_NAME SCHEMA_NAME PG_EXCEPTION_DETAIL|10 PG_EXCEPTION_HINT|10 PG_EXCEPTION_CONTEXT|10 ",
        d = "SQLSTATE SQLERRM|10 SUCCESSFUL_COMPLETION WARNING DYNAMIC_RESULT_SETS_RETURNED IMPLICIT_ZERO_BIT_PADDING NULL_VALUE_ELIMINATED_IN_SET_FUNCTION PRIVILEGE_NOT_GRANTED PRIVILEGE_NOT_REVOKED STRING_DATA_RIGHT_TRUNCATION DEPRECATED_FEATURE NO_DATA NO_ADDITIONAL_DYNAMIC_RESULT_SETS_RETURNED SQL_STATEMENT_NOT_YET_COMPLETE CONNECTION_EXCEPTION CONNECTION_DOES_NOT_EXIST CONNECTION_FAILURE SQLCLIENT_UNABLE_TO_ESTABLISH_SQLCONNECTION SQLSERVER_REJECTED_ESTABLISHMENT_OF_SQLCONNECTION TRANSACTION_RESOLUTION_UNKNOWN PROTOCOL_VIOLATION TRIGGERED_ACTION_EXCEPTION FEATURE_NOT_SUPPORTED INVALID_TRANSACTION_INITIATION LOCATOR_EXCEPTION INVALID_LOCATOR_SPECIFICATION INVALID_GRANTOR INVALID_GRANT_OPERATION INVALID_ROLE_SPECIFICATION DIAGNOSTICS_EXCEPTION STACKED_DIAGNOSTICS_ACCESSED_WITHOUT_ACTIVE_HANDLER CASE_NOT_FOUND CARDINALITY_VIOLATION DATA_EXCEPTION ARRAY_SUBSCRIPT_ERROR CHARACTER_NOT_IN_REPERTOIRE DATETIME_FIELD_OVERFLOW DIVISION_BY_ZERO ERROR_IN_ASSIGNMENT ESCAPE_CHARACTER_CONFLICT INDICATOR_OVERFLOW INTERVAL_FIELD_OVERFLOW INVALID_ARGUMENT_FOR_LOGARITHM INVALID_ARGUMENT_FOR_NTILE_FUNCTION INVALID_ARGUMENT_FOR_NTH_VALUE_FUNCTION INVALID_ARGUMENT_FOR_POWER_FUNCTION INVALID_ARGUMENT_FOR_WIDTH_BUCKET_FUNCTION INVALID_CHARACTER_VALUE_FOR_CAST INVALID_DATETIME_FORMAT INVALID_ESCAPE_CHARACTER INVALID_ESCAPE_OCTET INVALID_ESCAPE_SEQUENCE NONSTANDARD_USE_OF_ESCAPE_CHARACTER INVALID_INDICATOR_PARAMETER_VALUE INVALID_PARAMETER_VALUE INVALID_REGULAR_EXPRESSION INVALID_ROW_COUNT_IN_LIMIT_CLAUSE INVALID_ROW_COUNT_IN_RESULT_OFFSET_CLAUSE INVALID_TABLESAMPLE_ARGUMENT INVALID_TABLESAMPLE_REPEAT INVALID_TIME_ZONE_DISPLACEMENT_VALUE INVALID_USE_OF_ESCAPE_CHARACTER MOST_SPECIFIC_TYPE_MISMATCH NULL_VALUE_NOT_ALLOWED NULL_VALUE_NO_INDICATOR_PARAMETER NUMERIC_VALUE_OUT_OF_RANGE SEQUENCE_GENERATOR_LIMIT_EXCEEDED STRING_DATA_LENGTH_MISMATCH STRING_DATA_RIGHT_TRUNCATION SUBSTRING_ERROR TRIM_ERROR UNTERMINATED_C_STRING ZERO_LENGTH_CHARACTER_STRING FLOATING_POINT_EXCEPTION INVALID_TEXT_REPRESENTATION INVALID_BINARY_REPRESENTATION BAD_COPY_FILE_FORMAT UNTRANSLATABLE_CHARACTER NOT_AN_XML_DOCUMENT INVALID_XML_DOCUMENT INVALID_XML_CONTENT INVALID_XML_COMMENT INVALID_XML_PROCESSING_INSTRUCTION INTEGRITY_CONSTRAINT_VIOLATION RESTRICT_VIOLATION NOT_NULL_VIOLATION FOREIGN_KEY_VIOLATION UNIQUE_VIOLATION CHECK_VIOLATION EXCLUSION_VIOLATION INVALID_CURSOR_STATE INVALID_TRANSACTION_STATE ACTIVE_SQL_TRANSACTION BRANCH_TRANSACTION_ALREADY_ACTIVE HELD_CURSOR_REQUIRES_SAME_ISOLATION_LEVEL INAPPROPRIATE_ACCESS_MODE_FOR_BRANCH_TRANSACTION INAPPROPRIATE_ISOLATION_LEVEL_FOR_BRANCH_TRANSACTION NO_ACTIVE_SQL_TRANSACTION_FOR_BRANCH_TRANSACTION READ_ONLY_SQL_TRANSACTION SCHEMA_AND_DATA_STATEMENT_MIXING_NOT_SUPPORTED NO_ACTIVE_SQL_TRANSACTION IN_FAILED_SQL_TRANSACTION IDLE_IN_TRANSACTION_SESSION_TIMEOUT INVALID_SQL_STATEMENT_NAME TRIGGERED_DATA_CHANGE_VIOLATION INVALID_AUTHORIZATION_SPECIFICATION INVALID_PASSWORD DEPENDENT_PRIVILEGE_DESCRIPTORS_STILL_EXIST DEPENDENT_OBJECTS_STILL_EXIST INVALID_TRANSACTION_TERMINATION SQL_ROUTINE_EXCEPTION FUNCTION_EXECUTED_NO_RETURN_STATEMENT MODIFYING_SQL_DATA_NOT_PERMITTED PROHIBITED_SQL_STATEMENT_ATTEMPTED READING_SQL_DATA_NOT_PERMITTED INVALID_CURSOR_NAME EXTERNAL_ROUTINE_EXCEPTION CONTAINING_SQL_NOT_PERMITTED MODIFYING_SQL_DATA_NOT_PERMITTED PROHIBITED_SQL_STATEMENT_ATTEMPTED READING_SQL_DATA_NOT_PERMITTED EXTERNAL_ROUTINE_INVOCATION_EXCEPTION INVALID_SQLSTATE_RETURNED NULL_VALUE_NOT_ALLOWED TRIGGER_PROTOCOL_VIOLATED SRF_PROTOCOL_VIOLATED EVENT_TRIGGER_PROTOCOL_VIOLATED SAVEPOINT_EXCEPTION INVALID_SAVEPOINT_SPECIFICATION INVALID_CATALOG_NAME INVALID_SCHEMA_NAME TRANSACTION_ROLLBACK TRANSACTION_INTEGRITY_CONSTRAINT_VIOLATION SERIALIZATION_FAILURE STATEMENT_COMPLETION_UNKNOWN DEADLOCK_DETECTED SYNTAX_ERROR_OR_ACCESS_RULE_VIOLATION SYNTAX_ERROR INSUFFICIENT_PRIVILEGE CANNOT_COERCE GROUPING_ERROR WINDOWING_ERROR INVALID_RECURSION INVALID_FOREIGN_KEY INVALID_NAME NAME_TOO_LONG RESERVED_NAME DATATYPE_MISMATCH INDETERMINATE_DATATYPE COLLATION_MISMATCH INDETERMINATE_COLLATION WRONG_OBJECT_TYPE GENERATED_ALWAYS UNDEFINED_COLUMN UNDEFINED_FUNCTION UNDEFINED_TABLE UNDEFINED_PARAMETER UNDEFINED_OBJECT DUPLICATE_COLUMN DUPLICATE_CURSOR DUPLICATE_DATABASE DUPLICATE_FUNCTION DUPLICATE_PREPARED_STATEMENT DUPLICATE_SCHEMA DUPLICATE_TABLE DUPLICATE_ALIAS DUPLICATE_OBJECT AMBIGUOUS_COLUMN AMBIGUOUS_FUNCTION AMBIGUOUS_PARAMETER AMBIGUOUS_ALIAS INVALID_COLUMN_REFERENCE INVALID_COLUMN_DEFINITION INVALID_CURSOR_DEFINITION INVALID_DATABASE_DEFINITION INVALID_FUNCTION_DEFINITION INVALID_PREPARED_STATEMENT_DEFINITION INVALID_SCHEMA_DEFINITION INVALID_TABLE_DEFINITION INVALID_OBJECT_DEFINITION WITH_CHECK_OPTION_VIOLATION INSUFFICIENT_RESOURCES DISK_FULL OUT_OF_MEMORY TOO_MANY_CONNECTIONS CONFIGURATION_LIMIT_EXCEEDED PROGRAM_LIMIT_EXCEEDED STATEMENT_TOO_COMPLEX TOO_MANY_COLUMNS TOO_MANY_ARGUMENTS OBJECT_NOT_IN_PREREQUISITE_STATE OBJECT_IN_USE CANT_CHANGE_RUNTIME_PARAM LOCK_NOT_AVAILABLE OPERATOR_INTERVENTION QUERY_CANCELED ADMIN_SHUTDOWN CRASH_SHUTDOWN CANNOT_CONNECT_NOW DATABASE_DROPPED SYSTEM_ERROR IO_ERROR UNDEFINED_FILE DUPLICATE_FILE SNAPSHOT_TOO_OLD CONFIG_FILE_ERROR LOCK_FILE_EXISTS FDW_ERROR FDW_COLUMN_NAME_NOT_FOUND FDW_DYNAMIC_PARAMETER_VALUE_NEEDED FDW_FUNCTION_SEQUENCE_ERROR FDW_INCONSISTENT_DESCRIPTOR_INFORMATION FDW_INVALID_ATTRIBUTE_VALUE FDW_INVALID_COLUMN_NAME FDW_INVALID_COLUMN_NUMBER FDW_INVALID_DATA_TYPE FDW_INVALID_DATA_TYPE_DESCRIPTORS FDW_INVALID_DESCRIPTOR_FIELD_IDENTIFIER FDW_INVALID_HANDLE FDW_INVALID_OPTION_INDEX FDW_INVALID_OPTION_NAME FDW_INVALID_STRING_LENGTH_OR_BUFFER_LENGTH FDW_INVALID_STRING_FORMAT FDW_INVALID_USE_OF_NULL_POINTER FDW_TOO_MANY_HANDLES FDW_OUT_OF_MEMORY FDW_NO_SCHEMAS FDW_OPTION_NAME_NOT_FOUND FDW_REPLY_HANDLE FDW_SCHEMA_NOT_FOUND FDW_TABLE_NOT_FOUND FDW_UNABLE_TO_CREATE_EXECUTION FDW_UNABLE_TO_CREATE_REPLY FDW_UNABLE_TO_ESTABLISH_CONNECTION PLPGSQL_ERROR RAISE_EXCEPTION NO_DATA_FOUND TOO_MANY_ROWS ASSERT_FAILURE INTERNAL_ERROR DATA_CORRUPTED INDEX_CORRUPTED ",
        b = "ARRAY_AGG AVG BIT_AND BIT_OR BOOL_AND BOOL_OR COUNT EVERY JSON_AGG JSONB_AGG JSON_OBJECT_AGG JSONB_OBJECT_AGG MAX MIN MODE STRING_AGG SUM XMLAGG CORR COVAR_POP COVAR_SAMP REGR_AVGX REGR_AVGY REGR_COUNT REGR_INTERCEPT REGR_R2 REGR_SLOPE REGR_SXX REGR_SXY REGR_SYY STDDEV STDDEV_POP STDDEV_SAMP VARIANCE VAR_POP VAR_SAMP PERCENTILE_CONT PERCENTILE_DISC ROW_NUMBER RANK DENSE_RANK PERCENT_RANK CUME_DIST NTILE LAG LEAD FIRST_VALUE LAST_VALUE NTH_VALUE NUM_NONNULLS NUM_NULLS ABS CBRT CEIL CEILING DEGREES DIV EXP FLOOR LN LOG MOD PI POWER RADIANS ROUND SCALE SIGN SQRT TRUNC WIDTH_BUCKET RANDOM SETSEED ACOS ACOSD ASIN ASIND ATAN ATAND ATAN2 ATAN2D COS COSD COT COTD SIN SIND TAN TAND BIT_LENGTH CHAR_LENGTH CHARACTER_LENGTH LOWER OCTET_LENGTH OVERLAY POSITION SUBSTRING TREAT TRIM UPPER ASCII BTRIM CHR CONCAT CONCAT_WS CONVERT CONVERT_FROM CONVERT_TO DECODE ENCODE INITCAP LEFT LENGTH LPAD LTRIM MD5 PARSE_IDENT PG_CLIENT_ENCODING QUOTE_IDENT|10 QUOTE_LITERAL|10 QUOTE_NULLABLE|10 REGEXP_MATCH REGEXP_MATCHES REGEXP_REPLACE REGEXP_SPLIT_TO_ARRAY REGEXP_SPLIT_TO_TABLE REPEAT REPLACE REVERSE RIGHT RPAD RTRIM SPLIT_PART STRPOS SUBSTR TO_ASCII TO_HEX TRANSLATE OCTET_LENGTH GET_BIT GET_BYTE SET_BIT SET_BYTE TO_CHAR TO_DATE TO_NUMBER TO_TIMESTAMP AGE CLOCK_TIMESTAMP|10 DATE_PART DATE_TRUNC ISFINITE JUSTIFY_DAYS JUSTIFY_HOURS JUSTIFY_INTERVAL MAKE_DATE MAKE_INTERVAL|10 MAKE_TIME MAKE_TIMESTAMP|10 MAKE_TIMESTAMPTZ|10 NOW STATEMENT_TIMESTAMP|10 TIMEOFDAY TRANSACTION_TIMESTAMP|10 ENUM_FIRST ENUM_LAST ENUM_RANGE AREA CENTER DIAMETER HEIGHT ISCLOSED ISOPEN NPOINTS PCLOSE POPEN RADIUS WIDTH BOX BOUND_BOX CIRCLE LINE LSEG PATH POLYGON ABBREV BROADCAST HOST HOSTMASK MASKLEN NETMASK NETWORK SET_MASKLEN TEXT INET_SAME_FAMILY INET_MERGE MACADDR8_SET7BIT ARRAY_TO_TSVECTOR GET_CURRENT_TS_CONFIG NUMNODE PLAINTO_TSQUERY PHRASETO_TSQUERY WEBSEARCH_TO_TSQUERY QUERYTREE SETWEIGHT STRIP TO_TSQUERY TO_TSVECTOR JSON_TO_TSVECTOR JSONB_TO_TSVECTOR TS_DELETE TS_FILTER TS_HEADLINE TS_RANK TS_RANK_CD TS_REWRITE TSQUERY_PHRASE TSVECTOR_TO_ARRAY TSVECTOR_UPDATE_TRIGGER TSVECTOR_UPDATE_TRIGGER_COLUMN XMLCOMMENT XMLCONCAT XMLELEMENT XMLFOREST XMLPI XMLROOT XMLEXISTS XML_IS_WELL_FORMED XML_IS_WELL_FORMED_DOCUMENT XML_IS_WELL_FORMED_CONTENT XPATH XPATH_EXISTS XMLTABLE XMLNAMESPACES TABLE_TO_XML TABLE_TO_XMLSCHEMA TABLE_TO_XML_AND_XMLSCHEMA QUERY_TO_XML QUERY_TO_XMLSCHEMA QUERY_TO_XML_AND_XMLSCHEMA CURSOR_TO_XML CURSOR_TO_XMLSCHEMA SCHEMA_TO_XML SCHEMA_TO_XMLSCHEMA SCHEMA_TO_XML_AND_XMLSCHEMA DATABASE_TO_XML DATABASE_TO_XMLSCHEMA DATABASE_TO_XML_AND_XMLSCHEMA XMLATTRIBUTES TO_JSON TO_JSONB ARRAY_TO_JSON ROW_TO_JSON JSON_BUILD_ARRAY JSONB_BUILD_ARRAY JSON_BUILD_OBJECT JSONB_BUILD_OBJECT JSON_OBJECT JSONB_OBJECT JSON_ARRAY_LENGTH JSONB_ARRAY_LENGTH JSON_EACH JSONB_EACH JSON_EACH_TEXT JSONB_EACH_TEXT JSON_EXTRACT_PATH JSONB_EXTRACT_PATH JSON_OBJECT_KEYS JSONB_OBJECT_KEYS JSON_POPULATE_RECORD JSONB_POPULATE_RECORD JSON_POPULATE_RECORDSET JSONB_POPULATE_RECORDSET JSON_ARRAY_ELEMENTS JSONB_ARRAY_ELEMENTS JSON_ARRAY_ELEMENTS_TEXT JSONB_ARRAY_ELEMENTS_TEXT JSON_TYPEOF JSONB_TYPEOF JSON_TO_RECORD JSONB_TO_RECORD JSON_TO_RECORDSET JSONB_TO_RECORDSET JSON_STRIP_NULLS JSONB_STRIP_NULLS JSONB_SET JSONB_INSERT JSONB_PRETTY CURRVAL LASTVAL NEXTVAL SETVAL COALESCE NULLIF GREATEST LEAST ARRAY_APPEND ARRAY_CAT ARRAY_NDIMS ARRAY_DIMS ARRAY_FILL ARRAY_LENGTH ARRAY_LOWER ARRAY_POSITION ARRAY_POSITIONS ARRAY_PREPEND ARRAY_REMOVE ARRAY_REPLACE ARRAY_TO_STRING ARRAY_UPPER CARDINALITY STRING_TO_ARRAY UNNEST ISEMPTY LOWER_INC UPPER_INC LOWER_INF UPPER_INF RANGE_MERGE GENERATE_SERIES GENERATE_SUBSCRIPTS CURRENT_DATABASE CURRENT_QUERY CURRENT_SCHEMA|10 CURRENT_SCHEMAS|10 INET_CLIENT_ADDR INET_CLIENT_PORT INET_SERVER_ADDR INET_SERVER_PORT ROW_SECURITY_ACTIVE FORMAT_TYPE TO_REGCLASS TO_REGPROC TO_REGPROCEDURE TO_REGOPER TO_REGOPERATOR TO_REGTYPE TO_REGNAMESPACE TO_REGROLE COL_DESCRIPTION OBJ_DESCRIPTION SHOBJ_DESCRIPTION TXID_CURRENT TXID_CURRENT_IF_ASSIGNED TXID_CURRENT_SNAPSHOT TXID_SNAPSHOT_XIP TXID_SNAPSHOT_XMAX TXID_SNAPSHOT_XMIN TXID_VISIBLE_IN_SNAPSHOT TXID_STATUS CURRENT_SETTING SET_CONFIG BRIN_SUMMARIZE_NEW_VALUES BRIN_SUMMARIZE_RANGE BRIN_DESUMMARIZE_RANGE GIN_CLEAN_PENDING_LIST SUPPRESS_REDUNDANT_UPDATES_TRIGGER LO_FROM_BYTEA LO_PUT LO_GET LO_CREAT LO_CREATE LO_UNLINK LO_IMPORT LO_EXPORT LOREAD LOWRITE GROUPING CAST ".trim().split(" ").map(function(g) {
            return g.split("|")[0]
        }).join("|");
    return {
        name: "PostgreSQL",
        aliases: ["postgres", "postgresql"],
        supersetOf: "sql",
        case_insensitive: !0,
        keywords: {
            keyword: u + o + s,
            built_in: l + p + d
        },
        illegal: /:==|\W\s*\(\*|(^|\s)\$[a-z]|\{\{|[a-z]:\s*$|\.\.\.|TO:|DO:/,
        contains: [{
            className: "keyword",
            variants: [{
                begin: /\bTEXT\s*SEARCH\b/
            }, {
                begin: /\b(PRIMARY|FOREIGN|FOR(\s+NO)?)\s+KEY\b/
            }, {
                begin: /\bPARALLEL\s+(UNSAFE|RESTRICTED|SAFE)\b/
            }, {
                begin: /\bSTORAGE\s+(PLAIN|EXTERNAL|EXTENDED|MAIN)\b/
            }, {
                begin: /\bMATCH\s+(FULL|PARTIAL|SIMPLE)\b/
            }, {
                begin: /\bNULLS\s+(FIRST|LAST)\b/
            }, {
                begin: /\bEVENT\s+TRIGGER\b/
            }, {
                begin: /\b(MAPPING|OR)\s+REPLACE\b/
            }, {
                begin: /\b(FROM|TO)\s+(PROGRAM|STDIN|STDOUT)\b/
            }, {
                begin: /\b(SHARE|EXCLUSIVE)\s+MODE\b/
            }, {
                begin: /\b(LEFT|RIGHT)\s+(OUTER\s+)?JOIN\b/
            }, {
                begin: /\b(FETCH|MOVE)\s+(NEXT|PRIOR|FIRST|LAST|ABSOLUTE|RELATIVE|FORWARD|BACKWARD)\b/
            }, {
                begin: /\bPRESERVE\s+ROWS\b/
            }, {
                begin: /\bDISCARD\s+PLANS\b/
            }, {
                begin: /\bREFERENCING\s+(OLD|NEW)\b/
            }, {
                begin: /\bSKIP\s+LOCKED\b/
            }, {
                begin: /\bGROUPING\s+SETS\b/
            }, {
                begin: /\b(BINARY|INSENSITIVE|SCROLL|NO\s+SCROLL)\s+(CURSOR|FOR)\b/
            }, {
                begin: /\b(WITH|WITHOUT)\s+HOLD\b/
            }, {
                begin: /\bWITH\s+(CASCADED|LOCAL)\s+CHECK\s+OPTION\b/
            }, {
                begin: /\bEXCLUDE\s+(TIES|NO\s+OTHERS)\b/
            }, {
                begin: /\bFORMAT\s+(TEXT|XML|JSON|YAML)\b/
            }, {
                begin: /\bSET\s+((SESSION|LOCAL)\s+)?NAMES\b/
            }, {
                begin: /\bIS\s+(NOT\s+)?UNKNOWN\b/
            }, {
                begin: /\bSECURITY\s+LABEL\b/
            }, {
                begin: /\bSTANDALONE\s+(YES|NO|NO\s+VALUE)\b/
            }, {
                begin: /\bWITH\s+(NO\s+)?DATA\b/
            }, {
                begin: /\b(FOREIGN|SET)\s+DATA\b/
            }, {
                begin: /\bSET\s+(CATALOG|CONSTRAINTS)\b/
            }, {
                begin: /\b(WITH|FOR)\s+ORDINALITY\b/
            }, {
                begin: /\bIS\s+(NOT\s+)?DOCUMENT\b/
            }, {
                begin: /\bXML\s+OPTION\s+(DOCUMENT|CONTENT)\b/
            }, {
                begin: /\b(STRIP|PRESERVE)\s+WHITESPACE\b/
            }, {
                begin: /\bNO\s+(ACTION|MAXVALUE|MINVALUE)\b/
            }, {
                begin: /\bPARTITION\s+BY\s+(RANGE|LIST|HASH)\b/
            }, {
                begin: /\bAT\s+TIME\s+ZONE\b/
            }, {
                begin: /\bGRANTED\s+BY\b/
            }, {
                begin: /\bRETURN\s+(QUERY|NEXT)\b/
            }, {
                begin: /\b(ATTACH|DETACH)\s+PARTITION\b/
            }, {
                begin: /\bFORCE\s+ROW\s+LEVEL\s+SECURITY\b/
            }, {
                begin: /\b(INCLUDING|EXCLUDING)\s+(COMMENTS|CONSTRAINTS|DEFAULTS|IDENTITY|INDEXES|STATISTICS|STORAGE|ALL)\b/
            }, {
                begin: /\bAS\s+(ASSIGNMENT|IMPLICIT|PERMISSIVE|RESTRICTIVE|ENUM|RANGE)\b/
            }]
        }, {
            begin: /\b(FORMAT|FAMILY|VERSION)\s*\(/
        }, {
            begin: /\bINCLUDE\s*\(/,
            keywords: "INCLUDE"
        }, {
            begin: /\bRANGE(?!\s*(BETWEEN|UNBOUNDED|CURRENT|[-0-9]+))/
        }, {
            begin: /\b(VERSION|OWNER|TEMPLATE|TABLESPACE|CONNECTION\s+LIMIT|PROCEDURE|RESTRICT|JOIN|PARSER|COPY|START|END|COLLATION|INPUT|ANALYZE|STORAGE|LIKE|DEFAULT|DELIMITER|ENCODING|COLUMN|CONSTRAINT|TABLE|SCHEMA)\s*=/
        }, {
            begin: /\b(PG_\w+?|HAS_[A-Z_]+_PRIVILEGE)\b/,
            relevance: 10
        }, {
            begin: /\bEXTRACT\s*\(/,
            end: /\bFROM\b/,
            returnEnd: !0,
            keywords: {
                type: "CENTURY DAY DECADE DOW DOY EPOCH HOUR ISODOW ISOYEAR MICROSECONDS MILLENNIUM MILLISECONDS MINUTE MONTH QUARTER SECOND TIMEZONE TIMEZONE_HOUR TIMEZONE_MINUTE WEEK YEAR"
            }
        }, {
            begin: /\b(XMLELEMENT|XMLPI)\s*\(\s*NAME/,
            keywords: {
                keyword: "NAME"
            }
        }, {
            begin: /\b(XMLPARSE|XMLSERIALIZE)\s*\(\s*(DOCUMENT|CONTENT)/,
            keywords: {
                keyword: "DOCUMENT CONTENT"
            }
        }, {
            beginKeywords: "CACHE INCREMENT MAXVALUE MINVALUE",
            end: e.C_NUMBER_RE,
            returnEnd: !0,
            keywords: "BY CACHE INCREMENT MAXVALUE MINVALUE"
        }, {
            className: "type",
            begin: /\b(WITH|WITHOUT)\s+TIME\s+ZONE\b/
        }, {
            className: "type",
            begin: /\bINTERVAL\s+(YEAR|MONTH|DAY|HOUR|MINUTE|SECOND)(\s+TO\s+(MONTH|HOUR|MINUTE|SECOND))?\b/
        }, {
            begin: /\bRETURNS\s+(LANGUAGE_HANDLER|TRIGGER|EVENT_TRIGGER|FDW_HANDLER|INDEX_AM_HANDLER|TSM_HANDLER)\b/,
            keywords: {
                keyword: "RETURNS",
                type: "LANGUAGE_HANDLER TRIGGER EVENT_TRIGGER FDW_HANDLER INDEX_AM_HANDLER TSM_HANDLER"
            }
        }, {
            begin: "\\b(" + b + ")\\s*\\("
        }, {
            begin: "\\.(" + r + ")\\b"
        }, {
            begin: "\\b(" + r + ")\\s+PATH\\b",
            keywords: {
                keyword: "PATH",
                type: c.replace("PATH ", "")
            }
        }, {
            className: "type",
            begin: "\\b(" + r + ")\\b"
        }, {
            className: "string",
            begin: "'",
            end: "'",
            contains: [{
                begin: "''"
            }]
        }, {
            className: "string",
            begin: "(e|E|u&|U&)'",
            end: "'",
            contains: [{
                begin: "\\\\."
            }],
            relevance: 10
        }, e.END_SAME_AS_BEGIN({
            begin: i,
            end: i,
            contains: [{
                subLanguage: ["pgsql", "perl", "python", "tcl", "r", "lua", "java", "php", "ruby", "bash", "scheme", "xml", "json"],
                endsWithParent: !0
            }]
        }), {
            begin: '"',
            end: '"',
            contains: [{
                begin: '""'
            }]
        }, e.C_NUMBER_MODE, e.C_BLOCK_COMMENT_MODE, t, {
            className: "meta",
            variants: [{
                begin: "%(ROW)?TYPE",
                relevance: 10
            }, {
                begin: "\\$\\d+"
            }, {
                begin: "^#\\w",
                end: "$"
            }]
        }, {
            className: "symbol",
            begin: a,
            relevance: 10
        }]
    }
}

function xt(e) {
    const t = ["string", "char", "byte", "int", "long", "bool", "decimal", "single", "double", "DateTime", "xml", "array", "hashtable", "void"],
        n = "Add|Clear|Close|Copy|Enter|Exit|Find|Format|Get|Hide|Join|Lock|Move|New|Open|Optimize|Pop|Push|Redo|Remove|Rename|Reset|Resize|Search|Select|Set|Show|Skip|Split|Step|Switch|Undo|Unlock|Watch|Backup|Checkpoint|Compare|Compress|Convert|ConvertFrom|ConvertTo|Dismount|Edit|Expand|Export|Group|Import|Initialize|Limit|Merge|Mount|Out|Publish|Restore|Save|Sync|Unpublish|Update|Approve|Assert|Build|Complete|Confirm|Deny|Deploy|Disable|Enable|Install|Invoke|Register|Request|Restart|Resume|Start|Stop|Submit|Suspend|Uninstall|Unregister|Wait|Debug|Measure|Ping|Repair|Resolve|Test|Trace|Connect|Disconnect|Read|Receive|Send|Write|Block|Grant|Protect|Revoke|Unblock|Unprotect|Use|ForEach|Sort|Tee|Where",
        i = "-and|-as|-band|-bnot|-bor|-bxor|-casesensitive|-ccontains|-ceq|-cge|-cgt|-cle|-clike|-clt|-cmatch|-cne|-cnotcontains|-cnotlike|-cnotmatch|-contains|-creplace|-csplit|-eq|-exact|-f|-file|-ge|-gt|-icontains|-ieq|-ige|-igt|-ile|-ilike|-ilt|-imatch|-in|-ine|-inotcontains|-inotlike|-inotmatch|-ireplace|-is|-isnot|-isplit|-join|-le|-like|-lt|-match|-ne|-not|-notcontains|-notin|-notlike|-notmatch|-or|-regex|-replace|-shl|-shr|-split|-wildcard|-xor",
        a = {
            $pattern: /-?[A-z\.\-]+\b/,
            keyword: "if else foreach return do while until elseif begin for trap data dynamicparam end break throw param continue finally in switch exit filter try process catch hidden static parameter",
            built_in: "ac asnp cat cd CFS chdir clc clear clhy cli clp cls clv cnsn compare copy cp cpi cpp curl cvpa dbp del diff dir dnsn ebp echo|0 epal epcsv epsn erase etsn exsn fc fhx fl ft fw gal gbp gc gcb gci gcm gcs gdr gerr ghy gi gin gjb gl gm gmo gp gps gpv group gsn gsnp gsv gtz gu gv gwmi h history icm iex ihy ii ipal ipcsv ipmo ipsn irm ise iwmi iwr kill lp ls man md measure mi mount move mp mv nal ndr ni nmo npssc nsn nv ogv oh popd ps pushd pwd r rbp rcjb rcsn rd rdr ren ri rjb rm rmdir rmo rni rnp rp rsn rsnp rujb rv rvpa rwmi sajb sal saps sasv sbp sc scb select set shcm si sl sleep sls sort sp spjb spps spsv start stz sujb sv swmi tee trcm type wget where wjb write"
        },
        u = /\w[\w\d]*((-)[\w\d]+)*/,
        s = {
            begin: "`[\\s\\S]",
            relevance: 0
        },
        o = {
            className: "variable",
            variants: [{
                begin: /\$\B/
            }, {
                className: "keyword",
                begin: /\$this/
            }, {
                begin: /\$[\w\d][\w\d_:]*/
            }]
        },
        c = {
            className: "literal",
            begin: /\$(null|true|false)\b/
        },
        r = {
            className: "string",
            variants: [{
                begin: /"/,
                end: /"/
            }, {
                begin: /@"/,
                end: /^"@/
            }],
            contains: [s, o, {
                className: "variable",
                begin: /\$[A-z]/,
                end: /[^A-z]/
            }]
        },
        l = {
            className: "string",
            variants: [{
                begin: /'/,
                end: /'/
            }, {
                begin: /@'/,
                end: /^'@/
            }]
        },
        p = {
            className: "doctag",
            variants: [{
                begin: /\.(synopsis|description|example|inputs|outputs|notes|link|component|role|functionality)/
            }, {
                begin: /\.(parameter|forwardhelptargetname|forwardhelpcategory|remotehelprunspace|externalhelp)\s+\S+/
            }]
        },
        d = e.inherit(e.COMMENT(null, null), {
            variants: [{
                begin: /#/,
                end: /$/
            }, {
                begin: /<#/,
                end: /#>/
            }],
            contains: [p]
        }),
        m = {
            className: "built_in",
            variants: [{
                begin: "(".concat(n, ")+(-)[\\w\\d]+")
            }]
        },
        b = {
            className: "class",
            beginKeywords: "class enum",
            end: /\s*[{]/,
            excludeEnd: !0,
            relevance: 0,
            contains: [e.TITLE_MODE]
        },
        g = {
            className: "function",
            begin: /function\s+/,
            end: /\s*\{|$/,
            excludeEnd: !0,
            returnBegin: !0,
            relevance: 0,
            contains: [{
                begin: "function",
                relevance: 0,
                className: "keyword"
            }, {
                className: "title",
                begin: u,
                relevance: 0
            }, {
                begin: /\(/,
                end: /\)/,
                className: "params",
                relevance: 0,
                contains: [o]
            }]
        },
        E = {
            begin: /using\s/,
            end: /$/,
            returnBegin: !0,
            contains: [r, l, {
                className: "keyword",
                begin: /(using|assembly|command|module|namespace|type)/
            }]
        },
        S = {
            variants: [{
                className: "operator",
                begin: "(".concat(i, ")\\b")
            }, {
                className: "literal",
                begin: /(-){1,2}[\w\d-]+/,
                relevance: 0
            }]
        },
        N = {
            className: "selector-tag",
            begin: /@\B/,
            relevance: 0
        },
        _ = {
            className: "function",
            begin: /\[.*\]\s*[\w]+[ ]??\(/,
            end: /$/,
            returnBegin: !0,
            relevance: 0,
            contains: [{
                className: "keyword",
                begin: "(".concat(a.keyword.toString().replace(/\s/g, "|"), ")\\b"),
                endsParent: !0,
                relevance: 0
            }, e.inherit(e.TITLE_MODE, {
                endsParent: !0
            })]
        },
        T = [_, d, s, e.NUMBER_MODE, r, l, m, o, c, N],
        A = {
            begin: /\[/,
            end: /\]/,
            excludeBegin: !0,
            excludeEnd: !0,
            relevance: 0,
            contains: [].concat("self", T, {
                begin: "(" + t.join("|") + ")",
                className: "built_in",
                relevance: 0
            }, {
                className: "type",
                begin: /[\.\w\d]+/,
                relevance: 0
            })
        };
    return _.contains.unshift(A), {
        name: "PowerShell",
        aliases: ["pwsh", "ps", "ps1"],
        case_insensitive: !0,
        keywords: a,
        contains: T.concat(b, g, E, S, A)
    }
}

function $e(e) {
    const t = e.regex,
        n = e.COMMENT("//", "$", {
            contains: [{
                begin: /\\\n/
            }]
        }),
        i = "decltype\\(auto\\)",
        a = "[a-zA-Z_]\\w*::",
        s = "(?!struct)(" + i + "|" + t.optional(a) + "[a-zA-Z_]\\w*" + t.optional("<[^<>]+>") + ")",
        o = {
            className: "type",
            begin: "\\b[a-z\\d_]*_t\\b"
        },
        r = {
            className: "string",
            variants: [{
                begin: '(u8?|U|L)?"',
                end: '"',
                illegal: "\\n",
                contains: [e.BACKSLASH_ESCAPE]
            }, {
                begin: "(u8?|U|L)?'(" + "\\\\(x[0-9A-Fa-f]{2}|u[0-9A-Fa-f]{4,8}|[0-7]{3}|\\S)" + "|.)",
                end: "'",
                illegal: "."
            }, e.END_SAME_AS_BEGIN({
                begin: /(?:u8?|U|L)?R"([^()\\ ]{0,16})\(/,
                end: /\)([^()\\ ]{0,16})"/
            })]
        },
        l = {
            className: "number",
            variants: [{
                begin: "[+-]?(?:(?:[0-9](?:'?[0-9])*\\.(?:[0-9](?:'?[0-9])*)?|\\.[0-9](?:'?[0-9])*)(?:[Ee][+-]?[0-9](?:'?[0-9])*)?|[0-9](?:'?[0-9])*[Ee][+-]?[0-9](?:'?[0-9])*|0[Xx](?:[0-9A-Fa-f](?:'?[0-9A-Fa-f])*(?:\\.(?:[0-9A-Fa-f](?:'?[0-9A-Fa-f])*)?)?|\\.[0-9A-Fa-f](?:'?[0-9A-Fa-f])*)[Pp][+-]?[0-9](?:'?[0-9])*)(?:[Ff](?:16|32|64|128)?|(BF|bf)16|[Ll]|)"
            }, {
                begin: "[+-]?\\b(?:0[Bb][01](?:'?[01])*|0[Xx][0-9A-Fa-f](?:'?[0-9A-Fa-f])*|0(?:'?[0-7])*|[1-9](?:'?[0-9])*)(?:[Uu](?:LL?|ll?)|[Uu][Zz]?|(?:LL?|ll?)[Uu]?|[Zz][Uu]|)"
            }],
            relevance: 0
        },
        p = {
            className: "meta",
            begin: /#\s*[a-z]+\b/,
            end: /$/,
            keywords: {
                keyword: "if else elif endif define undef warning error line pragma _Pragma ifdef ifndef include"
            },
            contains: [{
                begin: /\\\n/,
                relevance: 0
            }, e.inherit(r, {
                className: "string"
            }), {
                className: "string",
                begin: /<.*?>/
            }, n, e.C_BLOCK_COMMENT_MODE]
        },
        d = {
            className: "title",
            begin: t.optional(a) + e.IDENT_RE,
            relevance: 0
        },
        m = t.optional(a) + e.IDENT_RE + "\\s*\\(",
        b = ["alignas", "alignof", "and", "and_eq", "asm", "atomic_cancel", "atomic_commit", "atomic_noexcept", "auto", "bitand", "bitor", "break", "case", "catch", "class", "co_await", "co_return", "co_yield", "compl", "concept", "const_cast|10", "consteval", "constexpr", "constinit", "continue", "decltype", "default", "delete", "do", "dynamic_cast|10", "else", "enum", "explicit", "export", "extern", "false", "final", "for", "friend", "goto", "if", "import", "inline", "module", "mutable", "namespace", "new", "noexcept", "not", "not_eq", "nullptr", "operator", "or", "or_eq", "override", "private", "protected", "public", "reflexpr", "register", "reinterpret_cast|10", "requires", "return", "sizeof", "static_assert", "static_cast|10", "struct", "switch", "synchronized", "template", "this", "thread_local", "throw", "transaction_safe", "transaction_safe_dynamic", "true", "try", "typedef", "typeid", "typename", "union", "using", "virtual", "volatile", "while", "xor", "xor_eq"],
        g = ["bool", "char", "char16_t", "char32_t", "char8_t", "double", "float", "int", "long", "short", "void", "wchar_t", "unsigned", "signed", "const", "static"],
        E = ["any", "auto_ptr", "barrier", "binary_semaphore", "bitset", "complex", "condition_variable", "condition_variable_any", "counting_semaphore", "deque", "false_type", "flat_map", "flat_set", "future", "imaginary", "initializer_list", "istringstream", "jthread", "latch", "lock_guard", "multimap", "multiset", "mutex", "optional", "ostringstream", "packaged_task", "pair", "promise", "priority_queue", "queue", "recursive_mutex", "recursive_timed_mutex", "scoped_lock", "set", "shared_future", "shared_lock", "shared_mutex", "shared_timed_mutex", "shared_ptr", "stack", "string_view", "stringstream", "timed_mutex", "thread", "true_type", "tuple", "unique_lock", "unique_ptr", "unordered_map", "unordered_multimap", "unordered_multiset", "unordered_set", "variant", "vector", "weak_ptr", "wstring", "wstring_view"],
        S = ["abort", "abs", "acos", "apply", "as_const", "asin", "atan", "atan2", "calloc", "ceil", "cerr", "cin", "clog", "cos", "cosh", "cout", "declval", "endl", "exchange", "exit", "exp", "fabs", "floor", "fmod", "forward", "fprintf", "fputs", "free", "frexp", "fscanf", "future", "invoke", "isalnum", "isalpha", "iscntrl", "isdigit", "isgraph", "islower", "isprint", "ispunct", "isspace", "isupper", "isxdigit", "labs", "launder", "ldexp", "log", "log10", "make_pair", "make_shared", "make_shared_for_overwrite", "make_tuple", "make_unique", "malloc", "memchr", "memcmp", "memcpy", "memset", "modf", "move", "pow", "printf", "putchar", "puts", "realloc", "scanf", "sin", "sinh", "snprintf", "sprintf", "sqrt", "sscanf", "std", "stderr", "stdin", "stdout", "strcat", "strchr", "strcmp", "strcpy", "strcspn", "strlen", "strncat", "strncmp", "strncpy", "strpbrk", "strrchr", "strspn", "strstr", "swap", "tan", "tanh", "terminate", "to_underlying", "tolower", "toupper", "vfprintf", "visit", "vprintf", "vsprintf"],
        T = {
            type: g,
            keyword: b,
            literal: ["NULL", "false", "nullopt", "nullptr", "true"],
            built_in: ["_Pragma"],
            _type_hints: E
        },
        A = {
            className: "function.dispatch",
            relevance: 0,
            keywords: {
                _hint: S
            },
            begin: t.concat(/\b/, /(?!decltype)/, /(?!if)/, /(?!for)/, /(?!switch)/, /(?!while)/, e.IDENT_RE, t.lookahead(/(<[^<>]+>|)\s*\(/))
        },
        C = [A, p, o, n, e.C_BLOCK_COMMENT_MODE, l, r],
        O = {
            variants: [{
                begin: /=/,
                end: /;/
            }, {
                begin: /\(/,
                end: /\)/
            }, {
                beginKeywords: "new throw return else",
                end: /;/
            }],
            keywords: T,
            contains: C.concat([{
                begin: /\(/,
                end: /\)/,
                keywords: T,
                contains: C.concat(["self"]),
                relevance: 0
            }]),
            relevance: 0
        },
        D = {
            className: "function",
            begin: "(" + s + "[\\*&\\s]+)+" + m,
            returnBegin: !0,
            end: /[{;=]/,
            excludeEnd: !0,
            keywords: T,
            illegal: /[^\w\s\*&:<>.]/,
            contains: [{
                begin: i,
                keywords: T,
                relevance: 0
            }, {
                begin: m,
                returnBegin: !0,
                contains: [d],
                relevance: 0
            }, {
                begin: /::/,
                relevance: 0
            }, {
                begin: /:/,
                endsWithParent: !0,
                contains: [r, l]
            }, {
                relevance: 0,
                match: /,/
            }, {
                className: "params",
                begin: /\(/,
                end: /\)/,
                keywords: T,
                relevance: 0,
                contains: [n, e.C_BLOCK_COMMENT_MODE, r, l, o, {
                    begin: /\(/,
                    end: /\)/,
                    keywords: T,
                    relevance: 0,
                    contains: ["self", n, e.C_BLOCK_COMMENT_MODE, r, l, o]
                }]
            }, o, n, e.C_BLOCK_COMMENT_MODE, p]
        };
    return {
        name: "C++",
        aliases: ["cc", "c++", "h++", "hpp", "hh", "hxx", "cxx"],
        keywords: T,
        illegal: "</",
        classNameAliases: {
            "function.dispatch": "built_in"
        },
        contains: [].concat(O, D, A, C, [p, {
            begin: "\\b(deque|list|queue|priority_queue|pair|stack|vector|map|set|bitset|multiset|multimap|unordered_map|unordered_set|unordered_multiset|unordered_multimap|array|tuple|optional|variant|function|flat_map|flat_set)\\s*<(?!<)",
            end: ">",
            keywords: T,
            contains: ["self", o]
        }, {
            begin: e.IDENT_RE + "::",
            keywords: T
        }, {
            match: [/\b(?:enum(?:\s+(?:class|struct))?|class|struct|union)/, /\s+/, /\w+/],
            className: {
                1: "keyword",
                3: "title.class"
            }
        }])
    }
}

function Ft(e) {
    const t = {
            type: ["boolean", "byte", "word", "String"],
            built_in: ["KeyboardController", "MouseController", "SoftwareSerial", "EthernetServer", "EthernetClient", "LiquidCrystal", "RobotControl", "GSMVoiceCall", "EthernetUDP", "EsploraTFT", "HttpClient", "RobotMotor", "WiFiClient", "GSMScanner", "FileSystem", "Scheduler", "GSMServer", "YunClient", "YunServer", "IPAddress", "GSMClient", "GSMModem", "Keyboard", "Ethernet", "Console", "GSMBand", "Esplora", "Stepper", "Process", "WiFiUDP", "GSM_SMS", "Mailbox", "USBHost", "Firmata", "PImage", "Client", "Server", "GSMPIN", "FileIO", "Bridge", "Serial", "EEPROM", "Stream", "Mouse", "Audio", "Servo", "File", "Task", "GPRS", "WiFi", "Wire", "TFT", "GSM", "SPI", "SD"],
            _hints: ["setup", "loop", "runShellCommandAsynchronously", "analogWriteResolution", "retrieveCallingNumber", "printFirmwareVersion", "analogReadResolution", "sendDigitalPortPair", "noListenOnLocalhost", "readJoystickButton", "setFirmwareVersion", "readJoystickSwitch", "scrollDisplayRight", "getVoiceCallStatus", "scrollDisplayLeft", "writeMicroseconds", "delayMicroseconds", "beginTransmission", "getSignalStrength", "runAsynchronously", "getAsynchronously", "listenOnLocalhost", "getCurrentCarrier", "readAccelerometer", "messageAvailable", "sendDigitalPorts", "lineFollowConfig", "countryNameWrite", "runShellCommand", "readStringUntil", "rewindDirectory", "readTemperature", "setClockDivider", "readLightSensor", "endTransmission", "analogReference", "detachInterrupt", "countryNameRead", "attachInterrupt", "encryptionType", "readBytesUntil", "robotNameWrite", "readMicrophone", "robotNameRead", "cityNameWrite", "userNameWrite", "readJoystickY", "readJoystickX", "mouseReleased", "openNextFile", "scanNetworks", "noInterrupts", "digitalWrite", "beginSpeaker", "mousePressed", "isActionDone", "mouseDragged", "displayLogos", "noAutoscroll", "addParameter", "remoteNumber", "getModifiers", "keyboardRead", "userNameRead", "waitContinue", "processInput", "parseCommand", "printVersion", "readNetworks", "writeMessage", "blinkVersion", "cityNameRead", "readMessage", "setDataMode", "parsePacket", "isListening", "setBitOrder", "beginPacket", "isDirectory", "motorsWrite", "drawCompass", "digitalRead", "clearScreen", "serialEvent", "rightToLeft", "setTextSize", "leftToRight", "requestFrom", "keyReleased", "compassRead", "analogWrite", "interrupts", "WiFiServer", "disconnect", "playMelody", "parseFloat", "autoscroll", "getPINUsed", "setPINUsed", "setTimeout", "sendAnalog", "readSlider", "analogRead", "beginWrite", "createChar", "motorsStop", "keyPressed", "tempoWrite", "readButton", "subnetMask", "debugPrint", "macAddress", "writeGreen", "randomSeed", "attachGPRS", "readString", "sendString", "remotePort", "releaseAll", "mouseMoved", "background", "getXChange", "getYChange", "answerCall", "getResult", "voiceCall", "endPacket", "constrain", "getSocket", "writeJSON", "getButton", "available", "connected", "findUntil", "readBytes", "exitValue", "readGreen", "writeBlue", "startLoop", "IPAddress", "isPressed", "sendSysex", "pauseMode", "gatewayIP", "setCursor", "getOemKey", "tuneWrite", "noDisplay", "loadImage", "switchPIN", "onRequest", "onReceive", "changePIN", "playFile", "noBuffer", "parseInt", "overflow", "checkPIN", "knobRead", "beginTFT", "bitClear", "updateIR", "bitWrite", "position", "writeRGB", "highByte", "writeRed", "setSpeed", "readBlue", "noStroke", "remoteIP", "transfer", "shutdown", "hangCall", "beginSMS", "endWrite", "attached", "maintain", "noCursor", "checkReg", "checkPUK", "shiftOut", "isValid", "shiftIn", "pulseIn", "connect", "println", "localIP", "pinMode", "getIMEI", "display", "noBlink", "process", "getBand", "running", "beginSD", "drawBMP", "lowByte", "setBand", "release", "bitRead", "prepare", "pointTo", "readRed", "setMode", "noFill", "remove", "listen", "stroke", "detach", "attach", "noTone", "exists", "buffer", "height", "bitSet", "circle", "config", "cursor", "random", "IRread", "setDNS", "endSMS", "getKey", "micros", "millis", "begin", "print", "write", "ready", "flush", "width", "isPIN", "blink", "clear", "press", "mkdir", "rmdir", "close", "point", "yield", "image", "BSSID", "click", "delay", "read", "text", "move", "peek", "beep", "rect", "line", "open", "seek", "fill", "size", "turn", "stop", "home", "find", "step", "tone", "sqrt", "RSSI", "SSID", "end", "bit", "tan", "cos", "sin", "pow", "map", "abs", "max", "min", "get", "run", "put"],
            literal: ["DIGITAL_MESSAGE", "FIRMATA_STRING", "ANALOG_MESSAGE", "REPORT_DIGITAL", "REPORT_ANALOG", "INPUT_PULLUP", "SET_PIN_MODE", "INTERNAL2V56", "SYSTEM_RESET", "LED_BUILTIN", "INTERNAL1V1", "SYSEX_START", "INTERNAL", "EXTERNAL", "DEFAULT", "OUTPUT", "INPUT", "HIGH", "LOW"]
        },
        n = $e(e),
        i = n.keywords;
    return i.type = [...i.type, ...t.type], i.literal = [...i.literal, ...t.literal], i.built_in = [...i.built_in, ...t.built_in], i._hints = t._hints, n.name = "Arduino", n.aliases = ["ino"], n.supersetOf = "cpp", n
}

function Bt(e) {
    const t = e.regex,
        n = {},
        i = {
            begin: /\$\{/,
            end: /\}/,
            contains: ["self", {
                begin: /:-/,
                contains: [n]
            }]
        };
    Object.assign(n, {
        className: "variable",
        variants: [{
            begin: t.concat(/\$[\w\d#@][\w\d_]*/, "(?![\\w\\d])(?![$])")
        }, i]
    });
    const a = {
            className: "subst",
            begin: /\$\(/,
            end: /\)/,
            contains: [e.BACKSLASH_ESCAPE]
        },
        u = e.inherit(e.COMMENT(), {
            match: [/(^|\s)/, /#.*$/],
            scope: {
                2: "comment"
            }
        }),
        s = {
            begin: /<<-?\s*(?=\w+)/,
            starts: {
                contains: [e.END_SAME_AS_BEGIN({
                    begin: /(\w+)/,
                    end: /(\w+)/,
                    className: "string"
                })]
            }
        },
        o = {
            className: "string",
            begin: /"/,
            end: /"/,
            contains: [e.BACKSLASH_ESCAPE, n, a]
        };
    a.contains.push(o);
    const c = {
            match: /\\"/
        },
        r = {
            className: "string",
            begin: /'/,
            end: /'/
        },
        l = {
            match: /\\'/
        },
        p = {
            begin: /\$?\(\(/,
            end: /\)\)/,
            contains: [{
                begin: /\d+#[0-9a-f]+/,
                className: "number"
            }, e.NUMBER_MODE, n]
        },
        d = ["fish", "bash", "zsh", "sh", "csh", "ksh", "tcsh", "dash", "scsh"],
        m = e.SHEBANG({
            binary: "(".concat(d.join("|"), ")"),
            relevance: 10
        }),
        b = {
            className: "function",
            begin: /\w[\w\d_]*\s*\(\s*\)\s*\{/,
            returnBegin: !0,
            contains: [e.inherit(e.TITLE_MODE, {
                begin: /\w[\w\d_]*/
            })],
            relevance: 0
        },
        g = ["if", "then", "else", "elif", "fi", "time", "for", "while", "until", "in", "do", "done", "case", "esac", "coproc", "function", "select"],
        E = ["true", "false"],
        S = {
            match: /(\/[a-z._-]+)+/
        },
        N = ["break", "cd", "continue", "eval", "exec", "exit", "export", "getopts", "hash", "pwd", "readonly", "return", "shift", "test", "times", "trap", "umask", "unset"],
        _ = ["alias", "bind", "builtin", "caller", "command", "declare", "echo", "enable", "help", "let", "local", "logout", "mapfile", "printf", "read", "readarray", "source", "sudo", "type", "typeset", "ulimit", "unalias"],
        T = ["autoload", "bg", "bindkey", "bye", "cap", "chdir", "clone", "comparguments", "compcall", "compctl", "compdescribe", "compfiles", "compgroups", "compquote", "comptags", "comptry", "compvalues", "dirs", "disable", "disown", "echotc", "echoti", "emulate", "fc", "fg", "float", "functions", "getcap", "getln", "history", "integer", "jobs", "kill", "limit", "log", "noglob", "popd", "print", "pushd", "pushln", "rehash", "sched", "setcap", "setopt", "stat", "suspend", "ttyctl", "unfunction", "unhash", "unlimit", "unsetopt", "vared", "wait", "whence", "where", "which", "zcompile", "zformat", "zftp", "zle", "zmodload", "zparseopts", "zprof", "zpty", "zregexparse", "zsocket", "zstyle", "ztcp"],
        A = ["chcon", "chgrp", "chown", "chmod", "cp", "dd", "df", "dir", "dircolors", "ln", "ls", "mkdir", "mkfifo", "mknod", "mktemp", "mv", "realpath", "rm", "rmdir", "shred", "sync", "touch", "truncate", "vdir", "b2sum", "base32", "base64", "cat", "cksum", "comm", "csplit", "cut", "expand", "fmt", "fold", "head", "join", "md5sum", "nl", "numfmt", "od", "paste", "ptx", "pr", "sha1sum", "sha224sum", "sha256sum", "sha384sum", "sha512sum", "shuf", "sort", "split", "sum", "tac", "tail", "tr", "tsort", "unexpand", "uniq", "wc", "arch", "basename", "chroot", "date", "dirname", "du", "echo", "env", "expr", "factor", "groups", "hostid", "id", "link", "logname", "nice", "nohup", "nproc", "pathchk", "pinky", "printenv", "printf", "pwd", "readlink", "runcon", "seq", "sleep", "stat", "stdbuf", "stty", "tee", "test", "timeout", "tty", "uname", "unlink", "uptime", "users", "who", "whoami", "yes"];
    return {
        name: "Bash",
        aliases: ["sh", "zsh"],
        keywords: {
            $pattern: /\b[a-z][a-z0-9._-]+\b/,
            keyword: g,
            literal: E,
            built_in: [...N, ..._, "set", "shopt", ...T, ...A]
        },
        contains: [m, e.SHEBANG(), b, p, u, s, S, o, c, r, l, n]
    }
}

function kt(e) {
    const t = e.regex,
        n = e.COMMENT("//", "$", {
            contains: [{
                begin: /\\\n/
            }]
        }),
        i = "decltype\\(auto\\)",
        a = "[a-zA-Z_]\\w*::",
        s = "(" + i + "|" + t.optional(a) + "[a-zA-Z_]\\w*" + t.optional("<[^<>]+>") + ")",
        o = {
            className: "type",
            variants: [{
                begin: "\\b[a-z\\d_]*_t\\b"
            }, {
                match: /\batomic_[a-z]{3,6}\b/
            }]
        },
        r = {
            className: "string",
            variants: [{
                begin: '(u8?|U|L)?"',
                end: '"',
                illegal: "\\n",
                contains: [e.BACKSLASH_ESCAPE]
            }, {
                begin: "(u8?|U|L)?'(" + "\\\\(x[0-9A-Fa-f]{2}|u[0-9A-Fa-f]{4,8}|[0-7]{3}|\\S)" + "|.)",
                end: "'",
                illegal: "."
            }, e.END_SAME_AS_BEGIN({
                begin: /(?:u8?|U|L)?R"([^()\\ ]{0,16})\(/,
                end: /\)([^()\\ ]{0,16})"/
            })]
        },
        l = {
            className: "number",
            variants: [{
                match: /\b(0b[01']+)/
            }, {
                match: /(-?)\b([\d']+(\.[\d']*)?|\.[\d']+)((ll|LL|l|L)(u|U)?|(u|U)(ll|LL|l|L)?|f|F|b|B)/
            }, {
                match: /(-?)\b(0[xX][a-fA-F0-9]+(?:'[a-fA-F0-9]+)*(?:\.[a-fA-F0-9]*(?:'[a-fA-F0-9]*)*)?(?:[pP][-+]?[0-9]+)?(l|L)?(u|U)?)/
            }, {
                match: /(-?)\b\d+(?:'\d+)*(?:\.\d*(?:'\d*)*)?(?:[eE][-+]?\d+)?/
            }],
            relevance: 0
        },
        p = {
            className: "meta",
            begin: /#\s*[a-z]+\b/,
            end: /$/,
            keywords: {
                keyword: "if else elif endif define undef warning error line pragma _Pragma ifdef ifndef elifdef elifndef include"
            },
            contains: [{
                begin: /\\\n/,
                relevance: 0
            }, e.inherit(r, {
                className: "string"
            }), {
                className: "string",
                begin: /<.*?>/
            }, n, e.C_BLOCK_COMMENT_MODE]
        },
        d = {
            className: "title",
            begin: t.optional(a) + e.IDENT_RE,
            relevance: 0
        },
        m = t.optional(a) + e.IDENT_RE + "\\s*\\(",
        E = {
            keyword: ["asm", "auto", "break", "case", "continue", "default", "do", "else", "enum", "extern", "for", "fortran", "goto", "if", "inline", "register", "restrict", "return", "sizeof", "typeof", "typeof_unqual", "struct", "switch", "typedef", "union", "volatile", "while", "_Alignas", "_Alignof", "_Atomic", "_Generic", "_Noreturn", "_Static_assert", "_Thread_local", "alignas", "alignof", "noreturn", "static_assert", "thread_local", "_Pragma"],
            type: ["float", "double", "signed", "unsigned", "int", "short", "long", "char", "void", "_Bool", "_BitInt", "_Complex", "_Imaginary", "_Decimal32", "_Decimal64", "_Decimal96", "_Decimal128", "_Decimal64x", "_Decimal128x", "_Float16", "_Float32", "_Float64", "_Float128", "_Float32x", "_Float64x", "_Float128x", "const", "static", "constexpr", "complex", "bool", "imaginary"],
            literal: "true false NULL",
            built_in: "std string wstring cin cout cerr clog stdin stdout stderr stringstream istringstream ostringstream auto_ptr deque list queue stack vector map set pair bitset multiset multimap unordered_set unordered_map unordered_multiset unordered_multimap priority_queue make_pair array shared_ptr abort terminate abs acos asin atan2 atan calloc ceil cosh cos exit exp fabs floor fmod fprintf fputs free frexp fscanf future isalnum isalpha iscntrl isdigit isgraph islower isprint ispunct isspace isupper isxdigit tolower toupper labs ldexp log10 log malloc realloc memchr memcmp memcpy memset modf pow printf putchar puts scanf sinh sin snprintf sprintf sqrt sscanf strcat strchr strcmp strcpy strcspn strlen strncat strncmp strncpy strpbrk strrchr strspn strstr tanh tan vfprintf vprintf vsprintf endl initializer_list unique_ptr"
        },
        S = [p, o, n, e.C_BLOCK_COMMENT_MODE, l, r],
        N = {
            variants: [{
                begin: /=/,
                end: /;/
            }, {
                begin: /\(/,
                end: /\)/
            }, {
                beginKeywords: "new throw return else",
                end: /;/
            }],
            keywords: E,
            contains: S.concat([{
                begin: /\(/,
                end: /\)/,
                keywords: E,
                contains: S.concat(["self"]),
                relevance: 0
            }]),
            relevance: 0
        },
        _ = {
            begin: "(" + s + "[\\*&\\s]+)+" + m,
            returnBegin: !0,
            end: /[{;=]/,
            excludeEnd: !0,
            keywords: E,
            illegal: /[^\w\s\*&:<>.]/,
            contains: [{
                begin: i,
                keywords: E,
                relevance: 0
            }, {
                begin: m,
                returnBegin: !0,
                contains: [e.inherit(d, {
                    className: "title.function"
                })],
                relevance: 0
            }, {
                relevance: 0,
                match: /,/
            }, {
                className: "params",
                begin: /\(/,
                end: /\)/,
                keywords: E,
                relevance: 0,
                contains: [n, e.C_BLOCK_COMMENT_MODE, r, l, o, {
                    begin: /\(/,
                    end: /\)/,
                    keywords: E,
                    relevance: 0,
                    contains: ["self", n, e.C_BLOCK_COMMENT_MODE, r, l, o]
                }]
            }, o, n, e.C_BLOCK_COMMENT_MODE, p]
        };
    return {
        name: "C",
        aliases: ["h"],
        keywords: E,
        disableAutodetect: !0,
        illegal: "</",
        contains: [].concat(N, _, S, [p, {
            begin: e.IDENT_RE + "::",
            keywords: E
        }, {
            className: "class",
            beginKeywords: "enum class struct union",
            end: /[{;:<>=]/,
            contains: [{
                beginKeywords: "final class struct"
            }, e.TITLE_MODE]
        }]),
        exports: {
            preprocessor: p,
            strings: r,
            keywords: E
        }
    }
}

function wt(e) {
    const t = e.regex,
        n = e.COMMENT("//", "$", {
            contains: [{
                begin: /\\\n/
            }]
        }),
        i = "decltype\\(auto\\)",
        a = "[a-zA-Z_]\\w*::",
        s = "(?!struct)(" + i + "|" + t.optional(a) + "[a-zA-Z_]\\w*" + t.optional("<[^<>]+>") + ")",
        o = {
            className: "type",
            begin: "\\b[a-z\\d_]*_t\\b"
        },
        r = {
            className: "string",
            variants: [{
                begin: '(u8?|U|L)?"',
                end: '"',
                illegal: "\\n",
                contains: [e.BACKSLASH_ESCAPE]
            }, {
                begin: "(u8?|U|L)?'(" + "\\\\(x[0-9A-Fa-f]{2}|u[0-9A-Fa-f]{4,8}|[0-7]{3}|\\S)" + "|.)",
                end: "'",
                illegal: "."
            }, e.END_SAME_AS_BEGIN({
                begin: /(?:u8?|U|L)?R"([^()\\ ]{0,16})\(/,
                end: /\)([^()\\ ]{0,16})"/
            })]
        },
        l = {
            className: "number",
            variants: [{
                begin: "[+-]?(?:(?:[0-9](?:'?[0-9])*\\.(?:[0-9](?:'?[0-9])*)?|\\.[0-9](?:'?[0-9])*)(?:[Ee][+-]?[0-9](?:'?[0-9])*)?|[0-9](?:'?[0-9])*[Ee][+-]?[0-9](?:'?[0-9])*|0[Xx](?:[0-9A-Fa-f](?:'?[0-9A-Fa-f])*(?:\\.(?:[0-9A-Fa-f](?:'?[0-9A-Fa-f])*)?)?|\\.[0-9A-Fa-f](?:'?[0-9A-Fa-f])*)[Pp][+-]?[0-9](?:'?[0-9])*)(?:[Ff](?:16|32|64|128)?|(BF|bf)16|[Ll]|)"
            }, {
                begin: "[+-]?\\b(?:0[Bb][01](?:'?[01])*|0[Xx][0-9A-Fa-f](?:'?[0-9A-Fa-f])*|0(?:'?[0-7])*|[1-9](?:'?[0-9])*)(?:[Uu](?:LL?|ll?)|[Uu][Zz]?|(?:LL?|ll?)[Uu]?|[Zz][Uu]|)"
            }],
            relevance: 0
        },
        p = {
            className: "meta",
            begin: /#\s*[a-z]+\b/,
            end: /$/,
            keywords: {
                keyword: "if else elif endif define undef warning error line pragma _Pragma ifdef ifndef include"
            },
            contains: [{
                begin: /\\\n/,
                relevance: 0
            }, e.inherit(r, {
                className: "string"
            }), {
                className: "string",
                begin: /<.*?>/
            }, n, e.C_BLOCK_COMMENT_MODE]
        },
        d = {
            className: "title",
            begin: t.optional(a) + e.IDENT_RE,
            relevance: 0
        },
        m = t.optional(a) + e.IDENT_RE + "\\s*\\(",
        b = ["alignas", "alignof", "and", "and_eq", "asm", "atomic_cancel", "atomic_commit", "atomic_noexcept", "auto", "bitand", "bitor", "break", "case", "catch", "class", "co_await", "co_return", "co_yield", "compl", "concept", "const_cast|10", "consteval", "constexpr", "constinit", "continue", "decltype", "default", "delete", "do", "dynamic_cast|10", "else", "enum", "explicit", "export", "extern", "false", "final", "for", "friend", "goto", "if", "import", "inline", "module", "mutable", "namespace", "new", "noexcept", "not", "not_eq", "nullptr", "operator", "or", "or_eq", "override", "private", "protected", "public", "reflexpr", "register", "reinterpret_cast|10", "requires", "return", "sizeof", "static_assert", "static_cast|10", "struct", "switch", "synchronized", "template", "this", "thread_local", "throw", "transaction_safe", "transaction_safe_dynamic", "true", "try", "typedef", "typeid", "typename", "union", "using", "virtual", "volatile", "while", "xor", "xor_eq"],
        g = ["bool", "char", "char16_t", "char32_t", "char8_t", "double", "float", "int", "long", "short", "void", "wchar_t", "unsigned", "signed", "const", "static"],
        E = ["any", "auto_ptr", "barrier", "binary_semaphore", "bitset", "complex", "condition_variable", "condition_variable_any", "counting_semaphore", "deque", "false_type", "flat_map", "flat_set", "future", "imaginary", "initializer_list", "istringstream", "jthread", "latch", "lock_guard", "multimap", "multiset", "mutex", "optional", "ostringstream", "packaged_task", "pair", "promise", "priority_queue", "queue", "recursive_mutex", "recursive_timed_mutex", "scoped_lock", "set", "shared_future", "shared_lock", "shared_mutex", "shared_timed_mutex", "shared_ptr", "stack", "string_view", "stringstream", "timed_mutex", "thread", "true_type", "tuple", "unique_lock", "unique_ptr", "unordered_map", "unordered_multimap", "unordered_multiset", "unordered_set", "variant", "vector", "weak_ptr", "wstring", "wstring_view"],
        S = ["abort", "abs", "acos", "apply", "as_const", "asin", "atan", "atan2", "calloc", "ceil", "cerr", "cin", "clog", "cos", "cosh", "cout", "declval", "endl", "exchange", "exit", "exp", "fabs", "floor", "fmod", "forward", "fprintf", "fputs", "free", "frexp", "fscanf", "future", "invoke", "isalnum", "isalpha", "iscntrl", "isdigit", "isgraph", "islower", "isprint", "ispunct", "isspace", "isupper", "isxdigit", "labs", "launder", "ldexp", "log", "log10", "make_pair", "make_shared", "make_shared_for_overwrite", "make_tuple", "make_unique", "malloc", "memchr", "memcmp", "memcpy", "memset", "modf", "move", "pow", "printf", "putchar", "puts", "realloc", "scanf", "sin", "sinh", "snprintf", "sprintf", "sqrt", "sscanf", "std", "stderr", "stdin", "stdout", "strcat", "strchr", "strcmp", "strcpy", "strcspn", "strlen", "strncat", "strncmp", "strncpy", "strpbrk", "strrchr", "strspn", "strstr", "swap", "tan", "tanh", "terminate", "to_underlying", "tolower", "toupper", "vfprintf", "visit", "vprintf", "vsprintf"],
        T = {
            type: g,
            keyword: b,
            literal: ["NULL", "false", "nullopt", "nullptr", "true"],
            built_in: ["_Pragma"],
            _type_hints: E
        },
        A = {
            className: "function.dispatch",
            relevance: 0,
            keywords: {
                _hint: S
            },
            begin: t.concat(/\b/, /(?!decltype)/, /(?!if)/, /(?!for)/, /(?!switch)/, /(?!while)/, e.IDENT_RE, t.lookahead(/(<[^<>]+>|)\s*\(/))
        },
        C = [A, p, o, n, e.C_BLOCK_COMMENT_MODE, l, r],
        O = {
            variants: [{
                begin: /=/,
                end: /;/
            }, {
                begin: /\(/,
                end: /\)/
            }, {
                beginKeywords: "new throw return else",
                end: /;/
            }],
            keywords: T,
            contains: C.concat([{
                begin: /\(/,
                end: /\)/,
                keywords: T,
                contains: C.concat(["self"]),
                relevance: 0
            }]),
            relevance: 0
        },
        D = {
            className: "function",
            begin: "(" + s + "[\\*&\\s]+)+" + m,
            returnBegin: !0,
            end: /[{;=]/,
            excludeEnd: !0,
            keywords: T,
            illegal: /[^\w\s\*&:<>.]/,
            contains: [{
                begin: i,
                keywords: T,
                relevance: 0
            }, {
                begin: m,
                returnBegin: !0,
                contains: [d],
                relevance: 0
            }, {
                begin: /::/,
                relevance: 0
            }, {
                begin: /:/,
                endsWithParent: !0,
                contains: [r, l]
            }, {
                relevance: 0,
                match: /,/
            }, {
                className: "params",
                begin: /\(/,
                end: /\)/,
                keywords: T,
                relevance: 0,
                contains: [n, e.C_BLOCK_COMMENT_MODE, r, l, o, {
                    begin: /\(/,
                    end: /\)/,
                    keywords: T,
                    relevance: 0,
                    contains: ["self", n, e.C_BLOCK_COMMENT_MODE, r, l, o]
                }]
            }, o, n, e.C_BLOCK_COMMENT_MODE, p]
        };
    return {
        name: "C++",
        aliases: ["cc", "c++", "h++", "hpp", "hh", "hxx", "cxx"],
        keywords: T,
        illegal: "</",
        classNameAliases: {
            "function.dispatch": "built_in"
        },
        contains: [].concat(O, D, A, C, [p, {
            begin: "\\b(deque|list|queue|priority_queue|pair|stack|vector|map|set|bitset|multiset|multimap|unordered_map|unordered_set|unordered_multiset|unordered_multimap|array|tuple|optional|variant|function|flat_map|flat_set)\\s*<(?!<)",
            end: ">",
            keywords: T,
            contains: ["self", o]
        }, {
            begin: e.IDENT_RE + "::",
            keywords: T
        }, {
            match: [/\b(?:enum(?:\s+(?:class|struct))?|class|struct|union)/, /\s+/, /\w+/],
            className: {
                1: "keyword",
                3: "title.class"
            }
        }])
    }
}

function Gt(e) {
    const t = ["bool", "byte", "char", "decimal", "delegate", "double", "dynamic", "enum", "float", "int", "long", "nint", "nuint", "object", "sbyte", "short", "string", "ulong", "uint", "ushort"],
        n = ["public", "private", "protected", "static", "internal", "protected", "abstract", "async", "extern", "override", "unsafe", "virtual", "new", "sealed", "partial"],
        i = ["default", "false", "null", "true"],
        a = ["abstract", "as", "base", "break", "case", "catch", "class", "const", "continue", "do", "else", "event", "explicit", "extern", "finally", "fixed", "for", "foreach", "goto", "if", "implicit", "in", "interface", "internal", "is", "lock", "namespace", "new", "operator", "out", "override", "params", "private", "protected", "public", "readonly", "record", "ref", "return", "scoped", "sealed", "sizeof", "stackalloc", "static", "struct", "switch", "this", "throw", "try", "typeof", "unchecked", "unsafe", "using", "virtual", "void", "volatile", "while"],
        u = ["add", "alias", "and", "ascending", "args", "async", "await", "by", "descending", "dynamic", "equals", "file", "from", "get", "global", "group", "init", "into", "join", "let", "nameof", "not", "notnull", "on", "or", "orderby", "partial", "record", "remove", "required", "scoped", "select", "set", "unmanaged", "value|0", "var", "when", "where", "with", "yield"],
        s = {
            keyword: a.concat(u),
            built_in: t,
            literal: i
        },
        o = e.inherit(e.TITLE_MODE, {
            begin: "[a-zA-Z](\\.?\\w)*"
        }),
        c = {
            className: "number",
            variants: [{
                begin: "\\b(0b[01']+)"
            }, {
                begin: "(-?)\\b([\\d']+(\\.[\\d']*)?|\\.[\\d']+)(u|U|l|L|ul|UL|f|F|b|B)"
            }, {
                begin: "(-?)(\\b0[xX][a-fA-F0-9']+|(\\b[\\d']+(\\.[\\d']*)?|\\.[\\d']+)([eE][-+]?[\\d']+)?)"
            }],
            relevance: 0
        },
        r = {
            className: "string",
            begin: /"""("*)(?!")(.|\n)*?"""\1/,
            relevance: 1
        },
        l = {
            className: "string",
            begin: '@"',
            end: '"',
            contains: [{
                begin: '""'
            }]
        },
        p = e.inherit(l, {
            illegal: /\n/
        }),
        d = {
            className: "subst",
            begin: /\{/,
            end: /\}/,
            keywords: s
        },
        m = e.inherit(d, {
            illegal: /\n/
        }),
        b = {
            className: "string",
            begin: /\$"/,
            end: '"',
            illegal: /\n/,
            contains: [{
                begin: /\{\{/
            }, {
                begin: /\}\}/
            }, e.BACKSLASH_ESCAPE, m]
        },
        g = {
            className: "string",
            begin: /\$@"/,
            end: '"',
            contains: [{
                begin: /\{\{/
            }, {
                begin: /\}\}/
            }, {
                begin: '""'
            }, d]
        },
        E = e.inherit(g, {
            illegal: /\n/,
            contains: [{
                begin: /\{\{/
            }, {
                begin: /\}\}/
            }, {
                begin: '""'
            }, m]
        });
    d.contains = [g, b, l, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, c, e.C_BLOCK_COMMENT_MODE], m.contains = [E, b, p, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, c, e.inherit(e.C_BLOCK_COMMENT_MODE, {
        illegal: /\n/
    })];
    const S = {
            variants: [r, g, b, l, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE]
        },
        N = {
            begin: "<",
            end: ">",
            contains: [{
                beginKeywords: "in out"
            }, o]
        },
        _ = e.IDENT_RE + "(<" + e.IDENT_RE + "(\\s*,\\s*" + e.IDENT_RE + ")*>)?(\\[\\])?",
        T = {
            begin: "@" + e.IDENT_RE,
            relevance: 0
        };
    return {
        name: "C#",
        aliases: ["cs", "c#"],
        keywords: s,
        illegal: /::/,
        contains: [e.COMMENT("///", "$", {
            returnBegin: !0,
            contains: [{
                className: "doctag",
                variants: [{
                    begin: "///",
                    relevance: 0
                }, {
                    begin: "<!--|-->"
                }, {
                    begin: "</?",
                    end: ">"
                }]
            }]
        }), e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, {
            className: "meta",
            begin: "#",
            end: "$",
            keywords: {
                keyword: "if else elif endif define undef warning error line region endregion pragma checksum"
            }
        }, S, c, {
            beginKeywords: "class interface",
            relevance: 0,
            end: /[{;=]/,
            illegal: /[^\s:,]/,
            contains: [{
                beginKeywords: "where class"
            }, o, N, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
        }, {
            beginKeywords: "namespace",
            relevance: 0,
            end: /[{;=]/,
            illegal: /[^\s:]/,
            contains: [o, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
        }, {
            beginKeywords: "record",
            relevance: 0,
            end: /[{;=]/,
            illegal: /[^\s:]/,
            contains: [o, N, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
        }, {
            className: "meta",
            begin: "^\\s*\\[(?=[\\w])",
            excludeBegin: !0,
            end: "\\]",
            excludeEnd: !0,
            contains: [{
                className: "string",
                begin: /"/,
                end: /"/
            }]
        }, {
            beginKeywords: "new return throw await else",
            relevance: 0
        }, {
            className: "function",
            begin: "(" + _ + "\\s+)+" + e.IDENT_RE + "\\s*(<[^=]+>\\s*)?\\(",
            returnBegin: !0,
            end: /\s*[{;=]/,
            excludeEnd: !0,
            keywords: s,
            contains: [{
                beginKeywords: n.join(" "),
                relevance: 0
            }, {
                begin: e.IDENT_RE + "\\s*(<[^=]+>\\s*)?\\(",
                returnBegin: !0,
                contains: [e.TITLE_MODE, N],
                relevance: 0
            }, {
                match: /\(\)/
            }, {
                className: "params",
                begin: /\(/,
                end: /\)/,
                excludeBegin: !0,
                excludeEnd: !0,
                keywords: s,
                relevance: 0,
                contains: [S, c, e.C_BLOCK_COMMENT_MODE]
            }, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
        }, T]
    }
}
const We = e => ({
        IMPORTANT: {
            scope: "meta",
            begin: "!important"
        },
        BLOCK_COMMENT: e.C_BLOCK_COMMENT_MODE,
        HEXCOLOR: {
            scope: "number",
            begin: /#(([0-9a-fA-F]{3,4})|(([0-9a-fA-F]{2}){3,4}))\b/
        },
        FUNCTION_DISPATCH: {
            className: "built_in",
            begin: /[\w-]+(?=\()/
        },
        ATTRIBUTE_SELECTOR_MODE: {
            scope: "selector-attr",
            begin: /\[/,
            end: /\]/,
            illegal: "$",
            contains: [e.APOS_STRING_MODE, e.QUOTE_STRING_MODE]
        },
        CSS_NUMBER_MODE: {
            scope: "number",
            begin: e.NUMBER_RE + "(%|em|ex|ch|rem|vw|vh|vmin|vmax|cm|mm|in|pt|pc|px|deg|grad|rad|turn|s|ms|Hz|kHz|dpi|dpcm|dppx)?",
            relevance: 0
        },
        CSS_VARIABLE: {
            className: "attr",
            begin: /--[A-Za-z_][A-Za-z0-9_-]*/
        }
    }),
    ze = ["a", "abbr", "address", "article", "aside", "audio", "b", "blockquote", "body", "button", "canvas", "caption", "cite", "code", "dd", "del", "details", "dfn", "div", "dl", "dt", "em", "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "header", "hgroup", "html", "i", "iframe", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "mark", "menu", "nav", "object", "ol", "optgroup", "option", "p", "picture", "q", "quote", "samp", "section", "select", "source", "span", "strong", "summary", "sup", "table", "tbody", "td", "textarea", "tfoot", "th", "thead", "time", "tr", "ul", "var", "video"],
    Ke = ["defs", "g", "marker", "mask", "pattern", "svg", "switch", "symbol", "feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feFlood", "feGaussianBlur", "feImage", "feMerge", "feMorphology", "feOffset", "feSpecularLighting", "feTile", "feTurbulence", "linearGradient", "radialGradient", "stop", "circle", "ellipse", "image", "line", "path", "polygon", "polyline", "rect", "text", "use", "textPath", "tspan", "foreignObject", "clipPath"],
    Qe = [...ze, ...Ke],
    qe = ["any-hover", "any-pointer", "aspect-ratio", "color", "color-gamut", "color-index", "device-aspect-ratio", "device-height", "device-width", "display-mode", "forced-colors", "grid", "height", "hover", "inverted-colors", "monochrome", "orientation", "overflow-block", "overflow-inline", "pointer", "prefers-color-scheme", "prefers-contrast", "prefers-reduced-motion", "prefers-reduced-transparency", "resolution", "scan", "scripting", "update", "width", "min-width", "max-width", "min-height", "max-height"].sort().reverse(),
    Ye = ["active", "any-link", "blank", "checked", "current", "default", "defined", "dir", "disabled", "drop", "empty", "enabled", "first", "first-child", "first-of-type", "fullscreen", "future", "focus", "focus-visible", "focus-within", "has", "host", "host-context", "hover", "indeterminate", "in-range", "invalid", "is", "lang", "last-child", "last-of-type", "left", "link", "local-link", "not", "nth-child", "nth-col", "nth-last-child", "nth-last-col", "nth-last-of-type", "nth-of-type", "only-child", "only-of-type", "optional", "out-of-range", "past", "placeholder-shown", "read-only", "read-write", "required", "right", "root", "scope", "target", "target-within", "user-invalid", "valid", "visited", "where"].sort().reverse(),
    Xe = ["after", "backdrop", "before", "cue", "cue-region", "first-letter", "first-line", "grammar-error", "marker", "part", "placeholder", "selection", "slotted", "spelling-error"].sort().reverse(),
    Ze = ["accent-color", "align-content", "align-items", "align-self", "alignment-baseline", "all", "anchor-name", "animation", "animation-composition", "animation-delay", "animation-direction", "animation-duration", "animation-fill-mode", "animation-iteration-count", "animation-name", "animation-play-state", "animation-range", "animation-range-end", "animation-range-start", "animation-timeline", "animation-timing-function", "appearance", "aspect-ratio", "backdrop-filter", "backface-visibility", "background", "background-attachment", "background-blend-mode", "background-clip", "background-color", "background-image", "background-origin", "background-position", "background-position-x", "background-position-y", "background-repeat", "background-size", "baseline-shift", "block-size", "border", "border-block", "border-block-color", "border-block-end", "border-block-end-color", "border-block-end-style", "border-block-end-width", "border-block-start", "border-block-start-color", "border-block-start-style", "border-block-start-width", "border-block-style", "border-block-width", "border-bottom", "border-bottom-color", "border-bottom-left-radius", "border-bottom-right-radius", "border-bottom-style", "border-bottom-width", "border-collapse", "border-color", "border-end-end-radius", "border-end-start-radius", "border-image", "border-image-outset", "border-image-repeat", "border-image-slice", "border-image-source", "border-image-width", "border-inline", "border-inline-color", "border-inline-end", "border-inline-end-color", "border-inline-end-style", "border-inline-end-width", "border-inline-start", "border-inline-start-color", "border-inline-start-style", "border-inline-start-width", "border-inline-style", "border-inline-width", "border-left", "border-left-color", "border-left-style", "border-left-width", "border-radius", "border-right", "border-right-color", "border-right-style", "border-right-width", "border-spacing", "border-start-end-radius", "border-start-start-radius", "border-style", "border-top", "border-top-color", "border-top-left-radius", "border-top-right-radius", "border-top-style", "border-top-width", "border-width", "bottom", "box-align", "box-decoration-break", "box-direction", "box-flex", "box-flex-group", "box-lines", "box-ordinal-group", "box-orient", "box-pack", "box-shadow", "box-sizing", "break-after", "break-before", "break-inside", "caption-side", "caret-color", "clear", "clip", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "color-scheme", "column-count", "column-fill", "column-gap", "column-rule", "column-rule-color", "column-rule-style", "column-rule-width", "column-span", "column-width", "columns", "contain", "contain-intrinsic-block-size", "contain-intrinsic-height", "contain-intrinsic-inline-size", "contain-intrinsic-size", "contain-intrinsic-width", "container", "container-name", "container-type", "content", "content-visibility", "counter-increment", "counter-reset", "counter-set", "cue", "cue-after", "cue-before", "cursor", "cx", "cy", "direction", "display", "dominant-baseline", "empty-cells", "enable-background", "field-sizing", "fill", "fill-opacity", "fill-rule", "filter", "flex", "flex-basis", "flex-direction", "flex-flow", "flex-grow", "flex-shrink", "flex-wrap", "float", "flood-color", "flood-opacity", "flow", "font", "font-display", "font-family", "font-feature-settings", "font-kerning", "font-language-override", "font-optical-sizing", "font-palette", "font-size", "font-size-adjust", "font-smooth", "font-smoothing", "font-stretch", "font-style", "font-synthesis", "font-synthesis-position", "font-synthesis-small-caps", "font-synthesis-style", "font-synthesis-weight", "font-variant", "font-variant-alternates", "font-variant-caps", "font-variant-east-asian", "font-variant-emoji", "font-variant-ligatures", "font-variant-numeric", "font-variant-position", "font-variation-settings", "font-weight", "forced-color-adjust", "gap", "glyph-orientation-horizontal", "glyph-orientation-vertical", "grid", "grid-area", "grid-auto-columns", "grid-auto-flow", "grid-auto-rows", "grid-column", "grid-column-end", "grid-column-start", "grid-gap", "grid-row", "grid-row-end", "grid-row-start", "grid-template", "grid-template-areas", "grid-template-columns", "grid-template-rows", "hanging-punctuation", "height", "hyphenate-character", "hyphenate-limit-chars", "hyphens", "icon", "image-orientation", "image-rendering", "image-resolution", "ime-mode", "initial-letter", "initial-letter-align", "inline-size", "inset", "inset-area", "inset-block", "inset-block-end", "inset-block-start", "inset-inline", "inset-inline-end", "inset-inline-start", "isolation", "justify-content", "justify-items", "justify-self", "kerning", "left", "letter-spacing", "lighting-color", "line-break", "line-height", "line-height-step", "list-style", "list-style-image", "list-style-position", "list-style-type", "margin", "margin-block", "margin-block-end", "margin-block-start", "margin-bottom", "margin-inline", "margin-inline-end", "margin-inline-start", "margin-left", "margin-right", "margin-top", "margin-trim", "marker", "marker-end", "marker-mid", "marker-start", "marks", "mask", "mask-border", "mask-border-mode", "mask-border-outset", "mask-border-repeat", "mask-border-slice", "mask-border-source", "mask-border-width", "mask-clip", "mask-composite", "mask-image", "mask-mode", "mask-origin", "mask-position", "mask-repeat", "mask-size", "mask-type", "masonry-auto-flow", "math-depth", "math-shift", "math-style", "max-block-size", "max-height", "max-inline-size", "max-width", "min-block-size", "min-height", "min-inline-size", "min-width", "mix-blend-mode", "nav-down", "nav-index", "nav-left", "nav-right", "nav-up", "none", "normal", "object-fit", "object-position", "offset", "offset-anchor", "offset-distance", "offset-path", "offset-position", "offset-rotate", "opacity", "order", "orphans", "outline", "outline-color", "outline-offset", "outline-style", "outline-width", "overflow", "overflow-anchor", "overflow-block", "overflow-clip-margin", "overflow-inline", "overflow-wrap", "overflow-x", "overflow-y", "overlay", "overscroll-behavior", "overscroll-behavior-block", "overscroll-behavior-inline", "overscroll-behavior-x", "overscroll-behavior-y", "padding", "padding-block", "padding-block-end", "padding-block-start", "padding-bottom", "padding-inline", "padding-inline-end", "padding-inline-start", "padding-left", "padding-right", "padding-top", "page", "page-break-after", "page-break-before", "page-break-inside", "paint-order", "pause", "pause-after", "pause-before", "perspective", "perspective-origin", "place-content", "place-items", "place-self", "pointer-events", "position", "position-anchor", "position-visibility", "print-color-adjust", "quotes", "r", "resize", "rest", "rest-after", "rest-before", "right", "rotate", "row-gap", "ruby-align", "ruby-position", "scale", "scroll-behavior", "scroll-margin", "scroll-margin-block", "scroll-margin-block-end", "scroll-margin-block-start", "scroll-margin-bottom", "scroll-margin-inline", "scroll-margin-inline-end", "scroll-margin-inline-start", "scroll-margin-left", "scroll-margin-right", "scroll-margin-top", "scroll-padding", "scroll-padding-block", "scroll-padding-block-end", "scroll-padding-block-start", "scroll-padding-bottom", "scroll-padding-inline", "scroll-padding-inline-end", "scroll-padding-inline-start", "scroll-padding-left", "scroll-padding-right", "scroll-padding-top", "scroll-snap-align", "scroll-snap-stop", "scroll-snap-type", "scroll-timeline", "scroll-timeline-axis", "scroll-timeline-name", "scrollbar-color", "scrollbar-gutter", "scrollbar-width", "shape-image-threshold", "shape-margin", "shape-outside", "shape-rendering", "speak", "speak-as", "src", "stop-color", "stop-opacity", "stroke", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke-width", "tab-size", "table-layout", "text-align", "text-align-all", "text-align-last", "text-anchor", "text-combine-upright", "text-decoration", "text-decoration-color", "text-decoration-line", "text-decoration-skip", "text-decoration-skip-ink", "text-decoration-style", "text-decoration-thickness", "text-emphasis", "text-emphasis-color", "text-emphasis-position", "text-emphasis-style", "text-indent", "text-justify", "text-orientation", "text-overflow", "text-rendering", "text-shadow", "text-size-adjust", "text-transform", "text-underline-offset", "text-underline-position", "text-wrap", "text-wrap-mode", "text-wrap-style", "timeline-scope", "top", "touch-action", "transform", "transform-box", "transform-origin", "transform-style", "transition", "transition-behavior", "transition-delay", "transition-duration", "transition-property", "transition-timing-function", "translate", "unicode-bidi", "user-modify", "user-select", "vector-effect", "vertical-align", "view-timeline", "view-timeline-axis", "view-timeline-inset", "view-timeline-name", "view-transition-name", "visibility", "voice-balance", "voice-duration", "voice-family", "voice-pitch", "voice-range", "voice-rate", "voice-stress", "voice-volume", "white-space", "white-space-collapse", "widows", "width", "will-change", "word-break", "word-spacing", "word-wrap", "writing-mode", "x", "y", "z-index", "zoom"].sort().reverse();

function Ut(e) {
    const t = e.regex,
        n = We(e),
        i = {
            begin: /-(webkit|moz|ms|o)-(?=[a-z])/
        },
        a = "and or not only",
        u = /@-?\w[\w]*(-\w+)*/,
        s = "[a-zA-Z-][a-zA-Z0-9_-]*",
        o = [e.APOS_STRING_MODE, e.QUOTE_STRING_MODE];
    return {
        name: "CSS",
        case_insensitive: !0,
        illegal: /[=|'\$]/,
        keywords: {
            keyframePosition: "from to"
        },
        classNameAliases: {
            keyframePosition: "selector-tag"
        },
        contains: [n.BLOCK_COMMENT, i, n.CSS_NUMBER_MODE, {
            className: "selector-id",
            begin: /#[A-Za-z0-9_-]+/,
            relevance: 0
        }, {
            className: "selector-class",
            begin: "\\." + s,
            relevance: 0
        }, n.ATTRIBUTE_SELECTOR_MODE, {
            className: "selector-pseudo",
            variants: [{
                begin: ":(" + Ye.join("|") + ")"
            }, {
                begin: ":(:)?(" + Xe.join("|") + ")"
            }]
        }, n.CSS_VARIABLE, {
            className: "attribute",
            begin: "\\b(" + Ze.join("|") + ")\\b"
        }, {
            begin: /:/,
            end: /[;}{]/,
            contains: [n.BLOCK_COMMENT, n.HEXCOLOR, n.IMPORTANT, n.CSS_NUMBER_MODE, ...o, {
                begin: /(url|data-uri)\(/,
                end: /\)/,
                relevance: 0,
                keywords: {
                    built_in: "url data-uri"
                },
                contains: [...o, {
                    className: "string",
                    begin: /[^)]/,
                    endsWithParent: !0,
                    excludeEnd: !0
                }]
            }, n.FUNCTION_DISPATCH]
        }, {
            begin: t.lookahead(/@/),
            end: "[{;]",
            relevance: 0,
            illegal: /:/,
            contains: [{
                className: "keyword",
                begin: u
            }, {
                begin: /\s/,
                endsWithParent: !0,
                excludeEnd: !0,
                relevance: 0,
                keywords: {
                    $pattern: /[a-z-]+/,
                    keyword: a,
                    attribute: qe.join(" ")
                },
                contains: [{
                    begin: /[a-z-]+(?=:)/,
                    className: "attribute"
                }, ...o, n.CSS_NUMBER_MODE]
            }]
        }, {
            className: "selector-tag",
            begin: "\\b(" + Qe.join("|") + ")\\b"
        }]
    }
}

function Vt(e) {
    const t = e.regex;
    return {
        name: "Diff",
        aliases: ["patch"],
        contains: [{
            className: "meta",
            relevance: 10,
            match: t.either(/^@@ +-\d+,\d+ +\+\d+,\d+ +@@/, /^\*\*\* +\d+,\d+ +\*\*\*\*$/, /^--- +\d+,\d+ +----$/)
        }, {
            className: "comment",
            variants: [{
                begin: t.either(/Index: /, /^index/, /={3,}/, /^-{3}/, /^\*{3} /, /^\+{3}/, /^diff --git/),
                end: /$/
            }, {
                match: /^\*{15}$/
            }]
        }, {
            className: "addition",
            begin: /^\+/,
            end: /$/
        }, {
            className: "deletion",
            begin: /^-/,
            end: /$/
        }, {
            className: "addition",
            begin: /^!/,
            end: /$/
        }]
    }
}

function Ht(e) {
    const u = {
        keyword: ["break", "case", "chan", "const", "continue", "default", "defer", "else", "fallthrough", "for", "func", "go", "goto", "if", "import", "interface", "map", "package", "range", "return", "select", "struct", "switch", "type", "var"],
        type: ["bool", "byte", "complex64", "complex128", "error", "float32", "float64", "int8", "int16", "int32", "int64", "string", "uint8", "uint16", "uint32", "uint64", "int", "uint", "uintptr", "rune"],
        literal: ["true", "false", "iota", "nil"],
        built_in: ["append", "cap", "close", "complex", "copy", "imag", "len", "make", "new", "panic", "print", "println", "real", "recover", "delete"]
    };
    return {
        name: "Go",
        aliases: ["golang"],
        keywords: u,
        illegal: "</",
        contains: [e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, {
            className: "string",
            variants: [e.QUOTE_STRING_MODE, e.APOS_STRING_MODE, {
                begin: "`",
                end: "`"
            }]
        }, {
            className: "number",
            variants: [{
                match: /-?\b0[xX]\.[a-fA-F0-9](_?[a-fA-F0-9])*[pP][+-]?\d(_?\d)*i?/,
                relevance: 0
            }, {
                match: /-?\b0[xX](_?[a-fA-F0-9])+((\.([a-fA-F0-9](_?[a-fA-F0-9])*)?)?[pP][+-]?\d(_?\d)*)?i?/,
                relevance: 0
            }, {
                match: /-?\b0[oO](_?[0-7])*i?/,
                relevance: 0
            }, {
                match: /-?\.\d(_?\d)*([eE][+-]?\d(_?\d)*)?i?/,
                relevance: 0
            }, {
                match: /-?\b\d(_?\d)*(\.(\d(_?\d)*)?)?([eE][+-]?\d(_?\d)*)?i?/,
                relevance: 0
            }]
        }, {
            begin: /:=/
        }, {
            className: "function",
            beginKeywords: "func",
            end: "\\s*(\\{|$)",
            excludeEnd: !0,
            contains: [e.TITLE_MODE, {
                className: "params",
                begin: /\(/,
                end: /\)/,
                endsParent: !0,
                keywords: u,
                illegal: /["']/
            }]
        }]
    }
}

function $t(e) {
    const t = e.regex,
        n = /[_A-Za-z][_0-9A-Za-z]*/;
    return {
        name: "GraphQL",
        aliases: ["gql"],
        case_insensitive: !0,
        disableAutodetect: !1,
        keywords: {
            keyword: ["query", "mutation", "subscription", "type", "input", "schema", "directive", "interface", "union", "scalar", "fragment", "enum", "on"],
            literal: ["true", "false", "null"]
        },
        contains: [e.HASH_COMMENT_MODE, e.QUOTE_STRING_MODE, e.NUMBER_MODE, {
            scope: "punctuation",
            match: /[.]{3}/,
            relevance: 0
        }, {
            scope: "punctuation",
            begin: /[\!\(\)\:\=\[\]\{\|\}]{1}/,
            relevance: 0
        }, {
            scope: "variable",
            begin: /\$/,
            end: /\W/,
            excludeEnd: !0,
            relevance: 0
        }, {
            scope: "meta",
            match: /@\w+/,
            excludeEnd: !0
        }, {
            scope: "symbol",
            begin: t.concat(n, t.lookahead(/\s*:/)),
            relevance: 0
        }],
        illegal: [/[;<']/, /BEGIN/]
    }
}

function Wt(e) {
    const t = e.regex,
        n = {
            className: "number",
            relevance: 0,
            variants: [{
                begin: /([+-]+)?[\d]+_[\d_]+/
            }, {
                begin: e.NUMBER_RE
            }]
        },
        i = e.COMMENT();
    i.variants = [{
        begin: /;/,
        end: /$/
    }, {
        begin: /#/,
        end: /$/
    }];
    const a = {
            className: "variable",
            variants: [{
                begin: /\$[\w\d"][\w\d_]*/
            }, {
                begin: /\$\{(.*?)\}/
            }]
        },
        u = {
            className: "literal",
            begin: /\bon|off|true|false|yes|no\b/
        },
        s = {
            className: "string",
            contains: [e.BACKSLASH_ESCAPE],
            variants: [{
                begin: "'''",
                end: "'''",
                relevance: 10
            }, {
                begin: '"""',
                end: '"""',
                relevance: 10
            }, {
                begin: '"',
                end: '"'
            }, {
                begin: "'",
                end: "'"
            }]
        },
        o = {
            begin: /\[/,
            end: /\]/,
            contains: [i, u, a, s, n, "self"],
            relevance: 0
        },
        c = /[A-Za-z0-9_-]+/,
        r = /"(\\"|[^"])*"/,
        l = /'[^']*'/,
        p = t.either(c, r, l),
        d = t.concat(p, "(\\s*\\.\\s*", p, ")*", t.lookahead(/\s*=\s*[^#\s]/));
    return {
        name: "TOML, also INI",
        aliases: ["toml"],
        case_insensitive: !0,
        illegal: /\S/,
        contains: [i, {
            className: "section",
            begin: /\[+/,
            end: /\]+/
        }, {
            begin: d,
            className: "attr",
            starts: {
                end: /$/,
                contains: [i, o, u, a, s, n]
            }
        }]
    }
}
var W = "[0-9](_*[0-9])*",
    Y = "\\.(".concat(W, ")"),
    X = "[0-9a-fA-F](_*[0-9a-fA-F])*",
    le = {
        className: "number",
        variants: [{
            begin: "(\\b(".concat(W, ")((").concat(Y, ")|\\.)?|(").concat(Y, "))") + "[eE][+-]?(".concat(W, ")[fFdD]?\\b")
        }, {
            begin: "\\b(".concat(W, ")((").concat(Y, ")[fFdD]?\\b|\\.([fFdD]\\b)?)")
        }, {
            begin: "(".concat(Y, ")[fFdD]?\\b")
        }, {
            begin: "\\b(".concat(W, ")[fFdD]\\b")
        }, {
            begin: "\\b0[xX]((".concat(X, ")\\.?|(").concat(X, ")?\\.(").concat(X, "))") + "[pP][+-]?(".concat(W, ")[fFdD]?\\b")
        }, {
            begin: "\\b(0|[1-9](_*[0-9])*)[lL]?\\b"
        }, {
            begin: "\\b0[xX](".concat(X, ")[lL]?\\b")
        }, {
            begin: "\\b0(_*[0-7])*[lL]?\\b"
        }, {
            begin: "\\b0[bB][01](_*[01])*[lL]?\\b"
        }],
        relevance: 0
    };

function pe(e, t, n) {
    return n === -1 ? "" : e.replace(t, i => pe(e, t, n - 1))
}

function zt(e) {
    const t = e.regex,
        n = "[À-ʸa-zA-Z_$][À-ʸa-zA-Z_$0-9]*",
        i = n + pe("(?:<" + n + "~~~(?:\\s*,\\s*" + n + "~~~)*>)?", /~~~/g, 2),
        c = {
            keyword: ["synchronized", "abstract", "private", "var", "static", "if", "const ", "for", "while", "strictfp", "finally", "protected", "import", "native", "final", "void", "enum", "else", "break", "transient", "catch", "instanceof", "volatile", "case", "assert", "package", "default", "public", "try", "switch", "continue", "throws", "protected", "public", "private", "module", "requires", "exports", "do", "sealed", "yield", "permits", "goto", "when"],
            literal: ["false", "true", "null"],
            type: ["char", "boolean", "long", "float", "int", "byte", "short", "double"],
            built_in: ["super", "this"]
        },
        r = {
            className: "meta",
            begin: "@" + n,
            contains: [{
                begin: /\(/,
                end: /\)/,
                contains: ["self"]
            }]
        },
        l = {
            className: "params",
            begin: /\(/,
            end: /\)/,
            keywords: c,
            relevance: 0,
            contains: [e.C_BLOCK_COMMENT_MODE],
            endsParent: !0
        };
    return {
        name: "Java",
        aliases: ["jsp"],
        keywords: c,
        illegal: /<\/|#/,
        contains: [e.COMMENT("/\\*\\*", "\\*/", {
            relevance: 0,
            contains: [{
                begin: /\w+@/,
                relevance: 0
            }, {
                className: "doctag",
                begin: "@[A-Za-z]+"
            }]
        }), {
            begin: /import java\.[a-z]+\./,
            keywords: "import",
            relevance: 2
        }, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, {
            begin: /"""/,
            end: /"""/,
            className: "string",
            contains: [e.BACKSLASH_ESCAPE]
        }, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, {
            match: [/\b(?:class|interface|enum|extends|implements|new)/, /\s+/, n],
            className: {
                1: "keyword",
                3: "title.class"
            }
        }, {
            match: /non-sealed/,
            scope: "keyword"
        }, {
            begin: [t.concat(/(?!else)/, n), /\s+/, n, /\s+/, /=(?!=)/],
            className: {
                1: "type",
                3: "variable",
                5: "operator"
            }
        }, {
            begin: [/record/, /\s+/, n],
            className: {
                1: "keyword",
                3: "title.class"
            },
            contains: [l, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
        }, {
            beginKeywords: "new throw return else",
            relevance: 0
        }, {
            begin: ["(?:" + i + "\\s+)", e.UNDERSCORE_IDENT_RE, /\s*(?=\()/],
            className: {
                2: "title.function"
            },
            keywords: c,
            contains: [{
                className: "params",
                begin: /\(/,
                end: /\)/,
                keywords: c,
                relevance: 0,
                contains: [r, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, le, e.C_BLOCK_COMMENT_MODE]
            }, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
        }, le, r]
    }
}
const ce = "[A-Za-z$_][0-9A-Za-z$_]*",
    Je = ["as", "in", "of", "if", "for", "while", "finally", "var", "new", "function", "do", "return", "void", "else", "break", "catch", "instanceof", "with", "throw", "case", "default", "try", "switch", "continue", "typeof", "delete", "let", "yield", "const", "class", "debugger", "async", "await", "static", "import", "from", "export", "extends", "using"],
    je = ["true", "false", "null", "undefined", "NaN", "Infinity"],
    ge = ["Object", "Function", "Boolean", "Symbol", "Math", "Date", "Number", "BigInt", "String", "RegExp", "Array", "Float32Array", "Float64Array", "Int8Array", "Uint8Array", "Uint8ClampedArray", "Int16Array", "Int32Array", "Uint16Array", "Uint32Array", "BigInt64Array", "BigUint64Array", "Set", "Map", "WeakSet", "WeakMap", "ArrayBuffer", "SharedArrayBuffer", "Atomics", "DataView", "JSON", "Promise", "Generator", "GeneratorFunction", "AsyncFunction", "Reflect", "Proxy", "Intl", "WebAssembly"],
    Ee = ["Error", "EvalError", "InternalError", "RangeError", "ReferenceError", "SyntaxError", "TypeError", "URIError"],
    Se = ["setInterval", "setTimeout", "clearInterval", "clearTimeout", "require", "exports", "eval", "isFinite", "isNaN", "parseFloat", "parseInt", "decodeURI", "decodeURIComponent", "encodeURI", "encodeURIComponent", "escape", "unescape"],
    et = ["arguments", "this", "super", "console", "window", "document", "localStorage", "sessionStorage", "module", "global"],
    tt = [].concat(Se, ge, Ee);

function Kt(e) {
    const t = e.regex,
        n = (y, {
            after: v
        }) => {
            const w = "</" + y[0].slice(1);
            return y.input.indexOf(w, v) !== -1
        },
        i = ce,
        a = {
            begin: "<>",
            end: "</>"
        },
        u = /<[A-Za-z0-9\\._:-]+\s*\/>/,
        s = {
            begin: /<[A-Za-z0-9\\._:-]+/,
            end: /\/[A-Za-z0-9\\._:-]+>|\/>/,
            isTrulyOpeningTag: (y, v) => {
                const w = y[0].length + y.index,
                    B = y.input[w];
                if (B === "<" || B === ",") {
                    v.ignoreMatch();
                    return
                }
                B === ">" && (n(y, {
                    after: w
                }) || v.ignoreMatch());
                let x;
                const $ = y.input.substring(w);
                if (x = $.match(/^\s*=/)) {
                    v.ignoreMatch();
                    return
                }
                if ((x = $.match(/^\s+extends\s+/)) && x.index === 0) {
                    v.ignoreMatch();
                    return
                }
            }
        },
        o = {
            $pattern: ce,
            keyword: Je,
            literal: je,
            built_in: tt,
            "variable.language": et
        },
        c = "[0-9](_?[0-9])*",
        r = "\\.(".concat(c, ")"),
        l = "0|[1-9](_?[0-9])*|0[0-7]*[89][0-9]*",
        p = {
            className: "number",
            variants: [{
                begin: "(\\b(".concat(l, ")((").concat(r, ")|\\.)?|(").concat(r, "))") + "[eE][+-]?(".concat(c, ")\\b")
            }, {
                begin: "\\b(".concat(l, ")\\b((").concat(r, ")\\b|\\.)?|(").concat(r, ")\\b")
            }, {
                begin: "\\b(0|[1-9](_?[0-9])*)n\\b"
            }, {
                begin: "\\b0[xX][0-9a-fA-F](_?[0-9a-fA-F])*n?\\b"
            }, {
                begin: "\\b0[bB][0-1](_?[0-1])*n?\\b"
            }, {
                begin: "\\b0[oO][0-7](_?[0-7])*n?\\b"
            }, {
                begin: "\\b0[0-7]+n?\\b"
            }],
            relevance: 0
        },
        d = {
            className: "subst",
            begin: "\\$\\{",
            end: "\\}",
            keywords: o,
            contains: []
        },
        m = {
            begin: ".?html`",
            end: "",
            starts: {
                end: "`",
                returnEnd: !1,
                contains: [e.BACKSLASH_ESCAPE, d],
                subLanguage: "xml"
            }
        },
        b = {
            begin: ".?css`",
            end: "",
            starts: {
                end: "`",
                returnEnd: !1,
                contains: [e.BACKSLASH_ESCAPE, d],
                subLanguage: "css"
            }
        },
        g = {
            begin: ".?gql`",
            end: "",
            starts: {
                end: "`",
                returnEnd: !1,
                contains: [e.BACKSLASH_ESCAPE, d],
                subLanguage: "graphql"
            }
        },
        E = {
            className: "string",
            begin: "`",
            end: "`",
            contains: [e.BACKSLASH_ESCAPE, d]
        },
        N = {
            className: "comment",
            variants: [e.COMMENT(/\/\*\*(?!\/)/, "\\*/", {
                relevance: 0,
                contains: [{
                    begin: "(?=@[A-Za-z]+)",
                    relevance: 0,
                    contains: [{
                        className: "doctag",
                        begin: "@[A-Za-z]+"
                    }, {
                        className: "type",
                        begin: "\\{",
                        end: "\\}",
                        excludeEnd: !0,
                        excludeBegin: !0,
                        relevance: 0
                    }, {
                        className: "variable",
                        begin: i + "(?=\\s*(-)|$)",
                        endsParent: !0,
                        relevance: 0
                    }, {
                        begin: /(?=[^\n])\s/,
                        relevance: 0
                    }]
                }]
            }), e.C_BLOCK_COMMENT_MODE, e.C_LINE_COMMENT_MODE]
        },
        _ = [e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, m, b, g, E, {
            match: /\$\d+/
        }, p];
    d.contains = _.concat({
        begin: /\{/,
        end: /\}/,
        keywords: o,
        contains: ["self"].concat(_)
    });
    const T = [].concat(N, d.contains),
        A = T.concat([{
            begin: /(\s*)\(/,
            end: /\)/,
            keywords: o,
            contains: ["self"].concat(T)
        }]),
        C = {
            className: "params",
            begin: /(\s*)\(/,
            end: /\)/,
            excludeBegin: !0,
            excludeEnd: !0,
            keywords: o,
            contains: A
        },
        O = {
            variants: [{
                match: [/class/, /\s+/, i, /\s+/, /extends/, /\s+/, t.concat(i, "(", t.concat(/\./, i), ")*")],
                scope: {
                    1: "keyword",
                    3: "title.class",
                    5: "keyword",
                    7: "title.class.inherited"
                }
            }, {
                match: [/class/, /\s+/, i],
                scope: {
                    1: "keyword",
                    3: "title.class"
                }
            }]
        },
        D = {
            relevance: 0,
            match: t.either(/\bJSON/, /\b[A-Z][a-z]+([A-Z][a-z]*|\d)*/, /\b[A-Z]{2,}([A-Z][a-z]+|\d)+([A-Z][a-z]*)*/, /\b[A-Z]{2,}[a-z]+([A-Z][a-z]+|\d)*([A-Z][a-z]*)*/),
            className: "title.class",
            keywords: {
                _: [...ge, ...Ee]
            }
        },
        L = {
            label: "use_strict",
            className: "meta",
            relevance: 10,
            begin: /^\s*['"]use (strict|asm)['"]/
        },
        R = {
            variants: [{
                match: [/function/, /\s+/, i, /(?=\s*\()/]
            }, {
                match: [/function/, /\s*(?=\()/]
            }],
            className: {
                1: "keyword",
                3: "title.function"
            },
            label: "func.def",
            contains: [C],
            illegal: /%/
        },
        f = {
            relevance: 0,
            match: /\b[A-Z][A-Z_0-9]+\b/,
            className: "variable.constant"
        };

    function G(y) {
        return t.concat("(?!", y.join("|"), ")")
    }
    const V = {
            match: t.concat(/\b/, G([...Se, "super", "import"].map(y => "".concat(y, "\\s*\\("))), i, t.lookahead(/\s*\(/)),
            className: "title.function",
            relevance: 0
        },
        P = {
            begin: t.concat(/\./, t.lookahead(t.concat(i, /(?![0-9A-Za-z$_(])/))),
            end: i,
            excludeBegin: !0,
            keywords: "prototype",
            className: "property",
            relevance: 0
        },
        M = {
            match: [/get|set/, /\s+/, i, /(?=\()/],
            className: {
                1: "keyword",
                3: "title.function"
            },
            contains: [{
                begin: /\(\)/
            }, C]
        },
        k = "(\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)|" + e.UNDERSCORE_IDENT_RE + ")\\s*=>",
        H = {
            match: [/const|var|let/, /\s+/, i, /\s*/, /=\s*/, /(async\s*)?/, t.lookahead(k)],
            keywords: "async",
            className: {
                1: "keyword",
                3: "title.function"
            },
            contains: [C]
        };
    return {
        name: "JavaScript",
        aliases: ["js", "jsx", "mjs", "cjs"],
        keywords: o,
        exports: {
            PARAMS_CONTAINS: A,
            CLASS_REFERENCE: D
        },
        illegal: /#(?![$_A-z])/,
        contains: [e.SHEBANG({
            label: "shebang",
            binary: "node",
            relevance: 5
        }), L, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, m, b, g, E, N, {
            match: /\$\d+/
        }, p, D, {
            scope: "attr",
            match: i + t.lookahead(":"),
            relevance: 0
        }, H, {
            begin: "(" + e.RE_STARTERS_RE + "|\\b(case|return|throw)\\b)\\s*",
            keywords: "return throw case",
            relevance: 0,
            contains: [N, e.REGEXP_MODE, {
                className: "function",
                begin: k,
                returnBegin: !0,
                end: "\\s*=>",
                contains: [{
                    className: "params",
                    variants: [{
                        begin: e.UNDERSCORE_IDENT_RE,
                        relevance: 0
                    }, {
                        className: null,
                        begin: /\(\s*\)/,
                        skip: !0
                    }, {
                        begin: /(\s*)\(/,
                        end: /\)/,
                        excludeBegin: !0,
                        excludeEnd: !0,
                        keywords: o,
                        contains: A
                    }]
                }]
            }, {
                begin: /,/,
                relevance: 0
            }, {
                match: /\s+/,
                relevance: 0
            }, {
                variants: [{
                    begin: a.begin,
                    end: a.end
                }, {
                    match: u
                }, {
                    begin: s.begin,
                    "on:begin": s.isTrulyOpeningTag,
                    end: s.end
                }],
                subLanguage: "xml",
                contains: [{
                    begin: s.begin,
                    end: s.end,
                    skip: !0,
                    contains: ["self"]
                }]
            }]
        }, R, {
            beginKeywords: "while if switch catch for"
        }, {
            begin: "\\b(?!function)" + e.UNDERSCORE_IDENT_RE + "\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)\\s*\\{",
            returnBegin: !0,
            label: "func.def",
            contains: [C, e.inherit(e.TITLE_MODE, {
                begin: i,
                className: "title.function"
            })]
        }, {
            match: /\.\.\./,
            relevance: 0
        }, P, {
            match: "\\$" + i,
            relevance: 0
        }, {
            match: [/\bconstructor(?=\s*\()/],
            className: {
                1: "title.function"
            },
            contains: [C]
        }, V, f, O, M, {
            match: /\$[(.]/
        }]
    }
}

function Qt(e) {
    const t = {
            className: "attr",
            begin: /"(\\.|[^\\"\r\n])*"(?=\s*:)/,
            relevance: 1.01
        },
        n = {
            match: /[{}[\],:]/,
            className: "punctuation",
            relevance: 0
        },
        i = ["true", "false", "null"],
        a = {
            scope: "literal",
            beginKeywords: i.join(" ")
        };
    return {
        name: "JSON",
        aliases: ["jsonc"],
        keywords: {
            literal: i
        },
        contains: [t, n, e.QUOTE_STRING_MODE, a, e.C_NUMBER_MODE, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE],
        illegal: "\\S"
    }
}
var z = "[0-9](_*[0-9])*",
    Z = "\\.(".concat(z, ")"),
    J = "[0-9a-fA-F](_*[0-9a-fA-F])*",
    nt = {
        className: "number",
        variants: [{
            begin: "(\\b(".concat(z, ")((").concat(Z, ")|\\.)?|(").concat(Z, "))") + "[eE][+-]?(".concat(z, ")[fFdD]?\\b")
        }, {
            begin: "\\b(".concat(z, ")((").concat(Z, ")[fFdD]?\\b|\\.([fFdD]\\b)?)")
        }, {
            begin: "(".concat(Z, ")[fFdD]?\\b")
        }, {
            begin: "\\b(".concat(z, ")[fFdD]\\b")
        }, {
            begin: "\\b0[xX]((".concat(J, ")\\.?|(").concat(J, ")?\\.(").concat(J, "))") + "[pP][+-]?(".concat(z, ")[fFdD]?\\b")
        }, {
            begin: "\\b(0|[1-9](_*[0-9])*)[lL]?\\b"
        }, {
            begin: "\\b0[xX](".concat(J, ")[lL]?\\b")
        }, {
            begin: "\\b0(_*[0-7])*[lL]?\\b"
        }, {
            begin: "\\b0[bB][01](_*[01])*[lL]?\\b"
        }],
        relevance: 0
    };

function qt(e) {
    const t = {
            keyword: "abstract as val var vararg get set class object open private protected public noinline crossinline dynamic final enum if else do while for when throw try catch finally import package is in fun override companion reified inline lateinit init interface annotation data sealed internal infix operator out by constructor super tailrec where const inner suspend typealias external expect actual",
            built_in: "Byte Short Char Int Long Boolean Float Double Void Unit Nothing",
            literal: "true false null"
        },
        n = {
            className: "keyword",
            begin: /\b(break|continue|return|this)\b/,
            starts: {
                contains: [{
                    className: "symbol",
                    begin: /@\w+/
                }]
            }
        },
        i = {
            className: "symbol",
            begin: e.UNDERSCORE_IDENT_RE + "@"
        },
        a = {
            className: "subst",
            begin: /\$\{/,
            end: /\}/,
            contains: [e.C_NUMBER_MODE]
        },
        u = {
            className: "variable",
            begin: "\\$" + e.UNDERSCORE_IDENT_RE
        },
        s = {
            className: "string",
            variants: [{
                begin: '"""',
                end: '"""(?=[^"])',
                contains: [u, a]
            }, {
                begin: "'",
                end: "'",
                illegal: /\n/,
                contains: [e.BACKSLASH_ESCAPE]
            }, {
                begin: '"',
                end: '"',
                illegal: /\n/,
                contains: [e.BACKSLASH_ESCAPE, u, a]
            }]
        };
    a.contains.push(s);
    const o = {
            className: "meta",
            begin: "@(?:file|property|field|get|set|receiver|param|setparam|delegate)\\s*:(?:\\s*" + e.UNDERSCORE_IDENT_RE + ")?"
        },
        c = {
            className: "meta",
            begin: "@" + e.UNDERSCORE_IDENT_RE,
            contains: [{
                begin: /\(/,
                end: /\)/,
                contains: [e.inherit(s, {
                    className: "string"
                }), "self"]
            }]
        },
        r = nt,
        l = e.COMMENT("/\\*", "\\*/", {
            contains: [e.C_BLOCK_COMMENT_MODE]
        }),
        p = {
            variants: [{
                className: "type",
                begin: e.UNDERSCORE_IDENT_RE
            }, {
                begin: /\(/,
                end: /\)/,
                contains: []
            }]
        },
        d = p;
    return d.variants[1].contains = [p], p.variants[1].contains = [d], {
        name: "Kotlin",
        aliases: ["kt", "kts"],
        keywords: t,
        contains: [e.COMMENT("/\\*\\*", "\\*/", {
            relevance: 0,
            contains: [{
                className: "doctag",
                begin: "@[A-Za-z]+"
            }]
        }), e.C_LINE_COMMENT_MODE, l, n, i, o, c, {
            className: "function",
            beginKeywords: "fun",
            end: "[(]|$",
            returnBegin: !0,
            excludeEnd: !0,
            keywords: t,
            relevance: 5,
            contains: [{
                begin: e.UNDERSCORE_IDENT_RE + "\\s*\\(",
                returnBegin: !0,
                relevance: 0,
                contains: [e.UNDERSCORE_TITLE_MODE]
            }, {
                className: "type",
                begin: /</,
                end: />/,
                keywords: "reified",
                relevance: 0
            }, {
                className: "params",
                begin: /\(/,
                end: /\)/,
                endsParent: !0,
                keywords: t,
                relevance: 0,
                contains: [{
                    begin: /:/,
                    end: /[=,\/]/,
                    endsWithParent: !0,
                    contains: [p, e.C_LINE_COMMENT_MODE, l],
                    relevance: 0
                }, e.C_LINE_COMMENT_MODE, l, o, c, s, e.C_NUMBER_MODE]
            }, l]
        }, {
            begin: [/class|interface|trait/, /\s+/, e.UNDERSCORE_IDENT_RE],
            beginScope: {
                3: "title.class"
            },
            keywords: "class interface trait",
            end: /[:\{(]|$/,
            excludeEnd: !0,
            illegal: "extends implements",
            contains: [{
                beginKeywords: "public protected internal private constructor"
            }, e.UNDERSCORE_TITLE_MODE, {
                className: "type",
                begin: /</,
                end: />/,
                excludeBegin: !0,
                excludeEnd: !0,
                relevance: 0
            }, {
                className: "type",
                begin: /[,:]\s*/,
                end: /[<\(,){\s]|$/,
                excludeBegin: !0,
                returnEnd: !0
            }, o, c]
        }, s, {
            className: "meta",
            begin: "^#!/usr/bin/env",
            end: "$",
            illegal: "\n"
        }, r]
    }
}
const it = e => ({
        IMPORTANT: {
            scope: "meta",
            begin: "!important"
        },
        BLOCK_COMMENT: e.C_BLOCK_COMMENT_MODE,
        HEXCOLOR: {
            scope: "number",
            begin: /#(([0-9a-fA-F]{3,4})|(([0-9a-fA-F]{2}){3,4}))\b/
        },
        FUNCTION_DISPATCH: {
            className: "built_in",
            begin: /[\w-]+(?=\()/
        },
        ATTRIBUTE_SELECTOR_MODE: {
            scope: "selector-attr",
            begin: /\[/,
            end: /\]/,
            illegal: "$",
            contains: [e.APOS_STRING_MODE, e.QUOTE_STRING_MODE]
        },
        CSS_NUMBER_MODE: {
            scope: "number",
            begin: e.NUMBER_RE + "(%|em|ex|ch|rem|vw|vh|vmin|vmax|cm|mm|in|pt|pc|px|deg|grad|rad|turn|s|ms|Hz|kHz|dpi|dpcm|dppx)?",
            relevance: 0
        },
        CSS_VARIABLE: {
            className: "attr",
            begin: /--[A-Za-z_][A-Za-z0-9_-]*/
        }
    }),
    at = ["a", "abbr", "address", "article", "aside", "audio", "b", "blockquote", "body", "button", "canvas", "caption", "cite", "code", "dd", "del", "details", "dfn", "div", "dl", "dt", "em", "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "header", "hgroup", "html", "i", "iframe", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "mark", "menu", "nav", "object", "ol", "optgroup", "option", "p", "picture", "q", "quote", "samp", "section", "select", "source", "span", "strong", "summary", "sup", "table", "tbody", "td", "textarea", "tfoot", "th", "thead", "time", "tr", "ul", "var", "video"],
    ot = ["defs", "g", "marker", "mask", "pattern", "svg", "switch", "symbol", "feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feFlood", "feGaussianBlur", "feImage", "feMerge", "feMorphology", "feOffset", "feSpecularLighting", "feTile", "feTurbulence", "linearGradient", "radialGradient", "stop", "circle", "ellipse", "image", "line", "path", "polygon", "polyline", "rect", "text", "use", "textPath", "tspan", "foreignObject", "clipPath"],
    rt = [...at, ...ot],
    st = ["any-hover", "any-pointer", "aspect-ratio", "color", "color-gamut", "color-index", "device-aspect-ratio", "device-height", "device-width", "display-mode", "forced-colors", "grid", "height", "hover", "inverted-colors", "monochrome", "orientation", "overflow-block", "overflow-inline", "pointer", "prefers-color-scheme", "prefers-contrast", "prefers-reduced-motion", "prefers-reduced-transparency", "resolution", "scan", "scripting", "update", "width", "min-width", "max-width", "min-height", "max-height"].sort().reverse(),
    be = ["active", "any-link", "blank", "checked", "current", "default", "defined", "dir", "disabled", "drop", "empty", "enabled", "first", "first-child", "first-of-type", "fullscreen", "future", "focus", "focus-visible", "focus-within", "has", "host", "host-context", "hover", "indeterminate", "in-range", "invalid", "is", "lang", "last-child", "last-of-type", "left", "link", "local-link", "not", "nth-child", "nth-col", "nth-last-child", "nth-last-col", "nth-last-of-type", "nth-of-type", "only-child", "only-of-type", "optional", "out-of-range", "past", "placeholder-shown", "read-only", "read-write", "required", "right", "root", "scope", "target", "target-within", "user-invalid", "valid", "visited", "where"].sort().reverse(),
    Te = ["after", "backdrop", "before", "cue", "cue-region", "first-letter", "first-line", "grammar-error", "marker", "part", "placeholder", "selection", "slotted", "spelling-error"].sort().reverse(),
    lt = ["accent-color", "align-content", "align-items", "align-self", "alignment-baseline", "all", "anchor-name", "animation", "animation-composition", "animation-delay", "animation-direction", "animation-duration", "animation-fill-mode", "animation-iteration-count", "animation-name", "animation-play-state", "animation-range", "animation-range-end", "animation-range-start", "animation-timeline", "animation-timing-function", "appearance", "aspect-ratio", "backdrop-filter", "backface-visibility", "background", "background-attachment", "background-blend-mode", "background-clip", "background-color", "background-image", "background-origin", "background-position", "background-position-x", "background-position-y", "background-repeat", "background-size", "baseline-shift", "block-size", "border", "border-block", "border-block-color", "border-block-end", "border-block-end-color", "border-block-end-style", "border-block-end-width", "border-block-start", "border-block-start-color", "border-block-start-style", "border-block-start-width", "border-block-style", "border-block-width", "border-bottom", "border-bottom-color", "border-bottom-left-radius", "border-bottom-right-radius", "border-bottom-style", "border-bottom-width", "border-collapse", "border-color", "border-end-end-radius", "border-end-start-radius", "border-image", "border-image-outset", "border-image-repeat", "border-image-slice", "border-image-source", "border-image-width", "border-inline", "border-inline-color", "border-inline-end", "border-inline-end-color", "border-inline-end-style", "border-inline-end-width", "border-inline-start", "border-inline-start-color", "border-inline-start-style", "border-inline-start-width", "border-inline-style", "border-inline-width", "border-left", "border-left-color", "border-left-style", "border-left-width", "border-radius", "border-right", "border-right-color", "border-right-style", "border-right-width", "border-spacing", "border-start-end-radius", "border-start-start-radius", "border-style", "border-top", "border-top-color", "border-top-left-radius", "border-top-right-radius", "border-top-style", "border-top-width", "border-width", "bottom", "box-align", "box-decoration-break", "box-direction", "box-flex", "box-flex-group", "box-lines", "box-ordinal-group", "box-orient", "box-pack", "box-shadow", "box-sizing", "break-after", "break-before", "break-inside", "caption-side", "caret-color", "clear", "clip", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "color-scheme", "column-count", "column-fill", "column-gap", "column-rule", "column-rule-color", "column-rule-style", "column-rule-width", "column-span", "column-width", "columns", "contain", "contain-intrinsic-block-size", "contain-intrinsic-height", "contain-intrinsic-inline-size", "contain-intrinsic-size", "contain-intrinsic-width", "container", "container-name", "container-type", "content", "content-visibility", "counter-increment", "counter-reset", "counter-set", "cue", "cue-after", "cue-before", "cursor", "cx", "cy", "direction", "display", "dominant-baseline", "empty-cells", "enable-background", "field-sizing", "fill", "fill-opacity", "fill-rule", "filter", "flex", "flex-basis", "flex-direction", "flex-flow", "flex-grow", "flex-shrink", "flex-wrap", "float", "flood-color", "flood-opacity", "flow", "font", "font-display", "font-family", "font-feature-settings", "font-kerning", "font-language-override", "font-optical-sizing", "font-palette", "font-size", "font-size-adjust", "font-smooth", "font-smoothing", "font-stretch", "font-style", "font-synthesis", "font-synthesis-position", "font-synthesis-small-caps", "font-synthesis-style", "font-synthesis-weight", "font-variant", "font-variant-alternates", "font-variant-caps", "font-variant-east-asian", "font-variant-emoji", "font-variant-ligatures", "font-variant-numeric", "font-variant-position", "font-variation-settings", "font-weight", "forced-color-adjust", "gap", "glyph-orientation-horizontal", "glyph-orientation-vertical", "grid", "grid-area", "grid-auto-columns", "grid-auto-flow", "grid-auto-rows", "grid-column", "grid-column-end", "grid-column-start", "grid-gap", "grid-row", "grid-row-end", "grid-row-start", "grid-template", "grid-template-areas", "grid-template-columns", "grid-template-rows", "hanging-punctuation", "height", "hyphenate-character", "hyphenate-limit-chars", "hyphens", "icon", "image-orientation", "image-rendering", "image-resolution", "ime-mode", "initial-letter", "initial-letter-align", "inline-size", "inset", "inset-area", "inset-block", "inset-block-end", "inset-block-start", "inset-inline", "inset-inline-end", "inset-inline-start", "isolation", "justify-content", "justify-items", "justify-self", "kerning", "left", "letter-spacing", "lighting-color", "line-break", "line-height", "line-height-step", "list-style", "list-style-image", "list-style-position", "list-style-type", "margin", "margin-block", "margin-block-end", "margin-block-start", "margin-bottom", "margin-inline", "margin-inline-end", "margin-inline-start", "margin-left", "margin-right", "margin-top", "margin-trim", "marker", "marker-end", "marker-mid", "marker-start", "marks", "mask", "mask-border", "mask-border-mode", "mask-border-outset", "mask-border-repeat", "mask-border-slice", "mask-border-source", "mask-border-width", "mask-clip", "mask-composite", "mask-image", "mask-mode", "mask-origin", "mask-position", "mask-repeat", "mask-size", "mask-type", "masonry-auto-flow", "math-depth", "math-shift", "math-style", "max-block-size", "max-height", "max-inline-size", "max-width", "min-block-size", "min-height", "min-inline-size", "min-width", "mix-blend-mode", "nav-down", "nav-index", "nav-left", "nav-right", "nav-up", "none", "normal", "object-fit", "object-position", "offset", "offset-anchor", "offset-distance", "offset-path", "offset-position", "offset-rotate", "opacity", "order", "orphans", "outline", "outline-color", "outline-offset", "outline-style", "outline-width", "overflow", "overflow-anchor", "overflow-block", "overflow-clip-margin", "overflow-inline", "overflow-wrap", "overflow-x", "overflow-y", "overlay", "overscroll-behavior", "overscroll-behavior-block", "overscroll-behavior-inline", "overscroll-behavior-x", "overscroll-behavior-y", "padding", "padding-block", "padding-block-end", "padding-block-start", "padding-bottom", "padding-inline", "padding-inline-end", "padding-inline-start", "padding-left", "padding-right", "padding-top", "page", "page-break-after", "page-break-before", "page-break-inside", "paint-order", "pause", "pause-after", "pause-before", "perspective", "perspective-origin", "place-content", "place-items", "place-self", "pointer-events", "position", "position-anchor", "position-visibility", "print-color-adjust", "quotes", "r", "resize", "rest", "rest-after", "rest-before", "right", "rotate", "row-gap", "ruby-align", "ruby-position", "scale", "scroll-behavior", "scroll-margin", "scroll-margin-block", "scroll-margin-block-end", "scroll-margin-block-start", "scroll-margin-bottom", "scroll-margin-inline", "scroll-margin-inline-end", "scroll-margin-inline-start", "scroll-margin-left", "scroll-margin-right", "scroll-margin-top", "scroll-padding", "scroll-padding-block", "scroll-padding-block-end", "scroll-padding-block-start", "scroll-padding-bottom", "scroll-padding-inline", "scroll-padding-inline-end", "scroll-padding-inline-start", "scroll-padding-left", "scroll-padding-right", "scroll-padding-top", "scroll-snap-align", "scroll-snap-stop", "scroll-snap-type", "scroll-timeline", "scroll-timeline-axis", "scroll-timeline-name", "scrollbar-color", "scrollbar-gutter", "scrollbar-width", "shape-image-threshold", "shape-margin", "shape-outside", "shape-rendering", "speak", "speak-as", "src", "stop-color", "stop-opacity", "stroke", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke-width", "tab-size", "table-layout", "text-align", "text-align-all", "text-align-last", "text-anchor", "text-combine-upright", "text-decoration", "text-decoration-color", "text-decoration-line", "text-decoration-skip", "text-decoration-skip-ink", "text-decoration-style", "text-decoration-thickness", "text-emphasis", "text-emphasis-color", "text-emphasis-position", "text-emphasis-style", "text-indent", "text-justify", "text-orientation", "text-overflow", "text-rendering", "text-shadow", "text-size-adjust", "text-transform", "text-underline-offset", "text-underline-position", "text-wrap", "text-wrap-mode", "text-wrap-style", "timeline-scope", "top", "touch-action", "transform", "transform-box", "transform-origin", "transform-style", "transition", "transition-behavior", "transition-delay", "transition-duration", "transition-property", "transition-timing-function", "translate", "unicode-bidi", "user-modify", "user-select", "vector-effect", "vertical-align", "view-timeline", "view-timeline-axis", "view-timeline-inset", "view-timeline-name", "view-transition-name", "visibility", "voice-balance", "voice-duration", "voice-family", "voice-pitch", "voice-range", "voice-rate", "voice-stress", "voice-volume", "white-space", "white-space-collapse", "widows", "width", "will-change", "word-break", "word-spacing", "word-wrap", "writing-mode", "x", "y", "z-index", "zoom"].sort().reverse(),
    ct = be.concat(Te).sort().reverse();

function Yt(e) {
    const t = it(e),
        n = ct,
        i = "and or not only",
        a = "[\\w-]+",
        u = "(" + a + "|@\\{" + a + "\\})",
        s = [],
        o = [],
        c = function(_) {
            return {
                className: "string",
                begin: "~?" + _ + ".*?" + _
            }
        },
        r = function(_, T, A) {
            return {
                className: _,
                begin: T,
                relevance: A
            }
        },
        l = {
            $pattern: /[a-z-]+/,
            keyword: i,
            attribute: st.join(" ")
        },
        p = {
            begin: "\\(",
            end: "\\)",
            contains: o,
            keywords: l,
            relevance: 0
        };
    o.push(e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, c("'"), c('"'), t.CSS_NUMBER_MODE, {
        begin: "(url|data-uri)\\(",
        starts: {
            className: "string",
            end: "[\\)\\n]",
            excludeEnd: !0
        }
    }, t.HEXCOLOR, p, r("variable", "@@?" + a, 10), r("variable", "@\\{" + a + "\\}"), r("built_in", "~?`[^`]*?`"), {
        className: "attribute",
        begin: a + "\\s*:",
        end: ":",
        returnBegin: !0,
        excludeEnd: !0
    }, t.IMPORTANT, {
        beginKeywords: "and not"
    }, t.FUNCTION_DISPATCH);
    const d = o.concat({
            begin: /\{/,
            end: /\}/,
            contains: s
        }),
        m = {
            beginKeywords: "when",
            endsWithParent: !0,
            contains: [{
                beginKeywords: "and not"
            }].concat(o)
        },
        b = {
            begin: u + "\\s*:",
            returnBegin: !0,
            end: /[;}]/,
            relevance: 0,
            contains: [{
                begin: /-(webkit|moz|ms|o)-/
            }, t.CSS_VARIABLE, {
                className: "attribute",
                begin: "\\b(" + lt.join("|") + ")\\b",
                end: /(?=:)/,
                starts: {
                    endsWithParent: !0,
                    illegal: "[<=$]",
                    relevance: 0,
                    contains: o
                }
            }]
        },
        g = {
            className: "keyword",
            begin: "@(import|media|charset|font-face|(-[a-z]+-)?keyframes|supports|document|namespace|page|viewport|host)\\b",
            starts: {
                end: "[;{}]",
                keywords: l,
                returnEnd: !0,
                contains: o,
                relevance: 0
            }
        },
        E = {
            className: "variable",
            variants: [{
                begin: "@" + a + "\\s*:",
                relevance: 15
            }, {
                begin: "@" + a
            }],
            starts: {
                end: "[;}]",
                returnEnd: !0,
                contains: d
            }
        },
        S = {
            variants: [{
                begin: "[\\.#:&\\[>]",
                end: "[;{}]"
            }, {
                begin: u,
                end: /\{/
            }],
            returnBegin: !0,
            returnEnd: !0,
            illegal: "[<='$\"]",
            relevance: 0,
            contains: [e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, m, r("keyword", "all\\b"), r("variable", "@\\{" + a + "\\}"), {
                begin: "\\b(" + rt.join("|") + ")\\b",
                className: "selector-tag"
            }, t.CSS_NUMBER_MODE, r("selector-tag", u, 0), r("selector-id", "#" + u), r("selector-class", "\\." + u, 0), r("selector-tag", "&", 0), t.ATTRIBUTE_SELECTOR_MODE, {
                className: "selector-pseudo",
                begin: ":(" + be.join("|") + ")"
            }, {
                className: "selector-pseudo",
                begin: ":(:)?(" + Te.join("|") + ")"
            }, {
                begin: /\(/,
                end: /\)/,
                relevance: 0,
                contains: d
            }, {
                begin: "!important"
            }, t.FUNCTION_DISPATCH]
        },
        N = {
            begin: a + ":(:)?" + "(".concat(n.join("|"), ")"),
            returnBegin: !0,
            contains: [S]
        };
    return s.push(e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, g, E, N, b, S, m, t.FUNCTION_DISPATCH), {
        name: "Less",
        case_insensitive: !0,
        illegal: "[=>'/<($\"]",
        contains: s
    }
}

function Xt(e) {
    const t = "\\[=*\\[",
        n = "\\]=*\\]",
        i = {
            begin: t,
            end: n,
            contains: ["self"]
        },
        a = [e.COMMENT("--(?!" + t + ")", "$"), e.COMMENT("--" + t, n, {
            contains: [i],
            relevance: 10
        })];
    return {
        name: "Lua",
        aliases: ["pluto"],
        keywords: {
            $pattern: e.UNDERSCORE_IDENT_RE,
            literal: "true false nil",
            keyword: "and break do else elseif end for goto if in local not or repeat return then until while",
            built_in: "_G _ENV _VERSION __index __newindex __mode __call __metatable __tostring __len __gc __add __sub __mul __div __mod __pow __concat __unm __eq __lt __le assert collectgarbage dofile error getfenv getmetatable ipairs load loadfile loadstring module next pairs pcall print rawequal rawget rawset require select setfenv setmetatable tonumber tostring type unpack xpcall arg self coroutine resume yield status wrap create running debug getupvalue debug sethook getmetatable gethook setmetatable setlocal traceback setfenv getinfo setupvalue getlocal getregistry getfenv io lines write close flush open output type read stderr stdin input stdout popen tmpfile math log max acos huge ldexp pi cos tanh pow deg tan cosh sinh random randomseed frexp ceil floor rad abs sqrt modf asin min mod fmod log10 atan2 exp sin atan os exit setlocale date getenv difftime remove time clock tmpname rename execute package preload loadlib loaded loaders cpath config path seeall string sub upper len gfind rep find match char dump gmatch reverse byte format gsub lower table setn insert getn foreachi maxn foreach concat sort remove"
        },
        contains: a.concat([{
            className: "function",
            beginKeywords: "function",
            end: "\\)",
            contains: [e.inherit(e.TITLE_MODE, {
                begin: "([_a-zA-Z]\\w*\\.)*([_a-zA-Z]\\w*:)?[_a-zA-Z]\\w*"
            }), {
                className: "params",
                begin: "\\(",
                endsWithParent: !0,
                contains: a
            }].concat(a)
        }, e.C_NUMBER_MODE, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, {
            className: "string",
            begin: t,
            end: n,
            contains: [i],
            relevance: 5
        }])
    }
}

function Zt(e) {
    const t = {
            className: "variable",
            variants: [{
                begin: "\\$\\(" + e.UNDERSCORE_IDENT_RE + "\\)",
                contains: [e.BACKSLASH_ESCAPE]
            }, {
                begin: /\$[@%<?\^\+\*]/
            }]
        },
        n = {
            className: "string",
            begin: /"/,
            end: /"/,
            contains: [e.BACKSLASH_ESCAPE, t]
        },
        i = {
            className: "variable",
            begin: /\$\([\w-]+\s/,
            end: /\)/,
            keywords: {
                built_in: "subst patsubst strip findstring filter filter-out sort word wordlist firstword lastword dir notdir suffix basename addsuffix addprefix join wildcard realpath abspath error warning shell origin flavor foreach if or and call eval file value"
            },
            contains: [t, n]
        },
        a = {
            begin: "^" + e.UNDERSCORE_IDENT_RE + "\\s*(?=[:+?]?=)"
        },
        u = {
            className: "meta",
            begin: /^\.PHONY:/,
            end: /$/,
            keywords: {
                $pattern: /[\.\w]+/,
                keyword: ".PHONY"
            }
        },
        s = {
            className: "section",
            begin: /^[^\s]+:/,
            end: /$/,
            contains: [t]
        };
    return {
        name: "Makefile",
        aliases: ["mk", "mak", "make"],
        keywords: {
            $pattern: /[\w-]+/,
            keyword: "define endef undefine ifdef ifndef ifeq ifneq else endif include -include sinclude override export unexport private vpath"
        },
        contains: [e.HASH_COMMENT_MODE, t, n, i, a, u, s]
    }
}

function Jt(e) {
    const t = e.regex,
        n = {
            begin: /<\/?[A-Za-z_]/,
            end: ">",
            subLanguage: "xml",
            relevance: 0
        },
        i = {
            begin: "^[-\\*]{3,}",
            end: "$"
        },
        a = {
            className: "code",
            variants: [{
                begin: "(`{3,})[^`](.|\\n)*?\\1`*[ ]*"
            }, {
                begin: "(~{3,})[^~](.|\\n)*?\\1~*[ ]*"
            }, {
                begin: "```",
                end: "```+[ ]*$"
            }, {
                begin: "~~~",
                end: "~~~+[ ]*$"
            }, {
                begin: "`.+?`"
            }, {
                begin: "(?=^( {4}|\\t))",
                contains: [{
                    begin: "^( {4}|\\t)",
                    end: "(\\n)$"
                }],
                relevance: 0
            }]
        },
        u = {
            className: "bullet",
            begin: "^[ 	]*([*+-]|(\\d+\\.))(?=\\s+)",
            end: "\\s+",
            excludeEnd: !0
        },
        s = {
            begin: /^\[[^\n]+\]:/,
            returnBegin: !0,
            contains: [{
                className: "symbol",
                begin: /\[/,
                end: /\]/,
                excludeBegin: !0,
                excludeEnd: !0
            }, {
                className: "link",
                begin: /:\s*/,
                end: /$/,
                excludeBegin: !0
            }]
        },
        o = /[A-Za-z][A-Za-z0-9+.-]*/,
        c = {
            variants: [{
                begin: /\[.+?\]\[.*?\]/,
                relevance: 0
            }, {
                begin: /\[.+?\]\(((data|javascript|mailto):|(?:http|ftp)s?:\/\/).*?\)/,
                relevance: 2
            }, {
                begin: t.concat(/\[.+?\]\(/, o, /:\/\/.*?\)/),
                relevance: 2
            }, {
                begin: /\[.+?\]\([./?&#].*?\)/,
                relevance: 1
            }, {
                begin: /\[.*?\]\(.*?\)/,
                relevance: 0
            }],
            returnBegin: !0,
            contains: [{
                match: /\[(?=\])/
            }, {
                className: "string",
                relevance: 0,
                begin: "\\[",
                end: "\\]",
                excludeBegin: !0,
                returnEnd: !0
            }, {
                className: "link",
                relevance: 0,
                begin: "\\]\\(",
                end: "\\)",
                excludeBegin: !0,
                excludeEnd: !0
            }, {
                className: "symbol",
                relevance: 0,
                begin: "\\]\\[",
                end: "\\]",
                excludeBegin: !0,
                excludeEnd: !0
            }]
        },
        r = {
            className: "strong",
            contains: [],
            variants: [{
                begin: /_{2}(?!\s)/,
                end: /_{2}/
            }, {
                begin: /\*{2}(?!\s)/,
                end: /\*{2}/
            }]
        },
        l = {
            className: "emphasis",
            contains: [],
            variants: [{
                begin: /\*(?![*\s])/,
                end: /\*/
            }, {
                begin: /_(?![_\s])/,
                end: /_/,
                relevance: 0
            }]
        },
        p = e.inherit(r, {
            contains: []
        }),
        d = e.inherit(l, {
            contains: []
        });
    r.contains.push(d), l.contains.push(p);
    let m = [n, c];
    return [r, l, p, d].forEach(S => {
        S.contains = S.contains.concat(m)
    }), m = m.concat(r, l), {
        name: "Markdown",
        aliases: ["md", "mkdown", "mkd"],
        contains: [{
            className: "section",
            variants: [{
                begin: "^#{1,6}",
                end: "$",
                contains: m
            }, {
                begin: "(?=^.+?\\n[=-]{2,}$)",
                contains: [{
                    begin: "^[=-]*$"
                }, {
                    begin: "^",
                    end: "\\n",
                    contains: m
                }]
            }]
        }, n, u, r, l, {
            className: "quote",
            begin: "^>\\s+",
            contains: m,
            end: "$"
        }, a, i, c, s, {
            scope: "literal",
            match: /&([a-zA-Z0-9]+|#[0-9]{1,7}|#[Xx][0-9a-fA-F]{1,6});/
        }]
    }
}

function jt(e) {
    const t = {
            className: "built_in",
            begin: "\\b(AV|CA|CF|CG|CI|CL|CM|CN|CT|MK|MP|MTK|MTL|NS|SCN|SK|UI|WK|XC)\\w+"
        },
        n = /[a-zA-Z@][a-zA-Z0-9_]*/,
        o = {
            "variable.language": ["this", "super"],
            $pattern: n,
            keyword: ["while", "export", "sizeof", "typedef", "const", "struct", "for", "union", "volatile", "static", "mutable", "if", "do", "return", "goto", "enum", "else", "break", "extern", "asm", "case", "default", "register", "explicit", "typename", "switch", "continue", "inline", "readonly", "assign", "readwrite", "self", "@synchronized", "id", "typeof", "nonatomic", "IBOutlet", "IBAction", "strong", "weak", "copy", "in", "out", "inout", "bycopy", "byref", "oneway", "__strong", "__weak", "__block", "__autoreleasing", "@private", "@protected", "@public", "@try", "@property", "@end", "@throw", "@catch", "@finally", "@autoreleasepool", "@synthesize", "@dynamic", "@selector", "@optional", "@required", "@encode", "@package", "@import", "@defs", "@compatibility_alias", "__bridge", "__bridge_transfer", "__bridge_retained", "__bridge_retain", "__covariant", "__contravariant", "__kindof", "_Nonnull", "_Nullable", "_Null_unspecified", "__FUNCTION__", "__PRETTY_FUNCTION__", "__attribute__", "getter", "setter", "retain", "unsafe_unretained", "nonnull", "nullable", "null_unspecified", "null_resettable", "class", "instancetype", "NS_DESIGNATED_INITIALIZER", "NS_UNAVAILABLE", "NS_REQUIRES_SUPER", "NS_RETURNS_INNER_POINTER", "NS_INLINE", "NS_AVAILABLE", "NS_DEPRECATED", "NS_ENUM", "NS_OPTIONS", "NS_SWIFT_UNAVAILABLE", "NS_ASSUME_NONNULL_BEGIN", "NS_ASSUME_NONNULL_END", "NS_REFINED_FOR_SWIFT", "NS_SWIFT_NAME", "NS_SWIFT_NOTHROW", "NS_DURING", "NS_HANDLER", "NS_ENDHANDLER", "NS_VALUERETURN", "NS_VOIDRETURN"],
            literal: ["false", "true", "FALSE", "TRUE", "nil", "YES", "NO", "NULL"],
            built_in: ["dispatch_once_t", "dispatch_queue_t", "dispatch_sync", "dispatch_async", "dispatch_once"],
            type: ["int", "float", "char", "unsigned", "signed", "short", "long", "double", "wchar_t", "unichar", "void", "bool", "BOOL", "id|0", "_Bool"]
        },
        c = {
            $pattern: n,
            keyword: ["@interface", "@class", "@protocol", "@implementation"]
        };
    return {
        name: "Objective-C",
        aliases: ["mm", "objc", "obj-c", "obj-c++", "objective-c++"],
        keywords: o,
        illegal: "</",
        contains: [t, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, e.C_NUMBER_MODE, e.QUOTE_STRING_MODE, e.APOS_STRING_MODE, {
            className: "string",
            variants: [{
                begin: '@"',
                end: '"',
                illegal: "\\n",
                contains: [e.BACKSLASH_ESCAPE]
            }]
        }, {
            className: "meta",
            begin: /#\s*[a-z]+\b/,
            end: /$/,
            keywords: {
                keyword: "if else elif endif define undef warning error line pragma ifdef ifndef include"
            },
            contains: [{
                begin: /\\\n/,
                relevance: 0
            }, e.inherit(e.QUOTE_STRING_MODE, {
                className: "string"
            }), {
                className: "string",
                begin: /<.*?>/,
                end: /$/,
                illegal: "\\n"
            }, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
        }, {
            className: "class",
            begin: "(" + c.keyword.join("|") + ")\\b",
            end: /(\{|$)/,
            excludeEnd: !0,
            keywords: c,
            contains: [e.UNDERSCORE_TITLE_MODE]
        }, {
            begin: "\\." + e.UNDERSCORE_IDENT_RE,
            relevance: 0
        }]
    }
}

function en(e) {
    const t = e.regex,
        n = ["abs", "accept", "alarm", "and", "atan2", "bind", "binmode", "bless", "break", "caller", "chdir", "chmod", "chomp", "chop", "chown", "chr", "chroot", "class", "close", "closedir", "connect", "continue", "cos", "crypt", "dbmclose", "dbmopen", "defined", "delete", "die", "do", "dump", "each", "else", "elsif", "endgrent", "endhostent", "endnetent", "endprotoent", "endpwent", "endservent", "eof", "eval", "exec", "exists", "exit", "exp", "fcntl", "field", "fileno", "flock", "for", "foreach", "fork", "format", "formline", "getc", "getgrent", "getgrgid", "getgrnam", "gethostbyaddr", "gethostbyname", "gethostent", "getlogin", "getnetbyaddr", "getnetbyname", "getnetent", "getpeername", "getpgrp", "getpriority", "getprotobyname", "getprotobynumber", "getprotoent", "getpwent", "getpwnam", "getpwuid", "getservbyname", "getservbyport", "getservent", "getsockname", "getsockopt", "given", "glob", "gmtime", "goto", "grep", "gt", "hex", "if", "index", "int", "ioctl", "join", "keys", "kill", "last", "lc", "lcfirst", "length", "link", "listen", "local", "localtime", "log", "lstat", "lt", "ma", "map", "method", "mkdir", "msgctl", "msgget", "msgrcv", "msgsnd", "my", "ne", "next", "no", "not", "oct", "open", "opendir", "or", "ord", "our", "pack", "package", "pipe", "pop", "pos", "print", "printf", "prototype", "push", "q|0", "qq", "quotemeta", "qw", "qx", "rand", "read", "readdir", "readline", "readlink", "readpipe", "recv", "redo", "ref", "rename", "require", "reset", "return", "reverse", "rewinddir", "rindex", "rmdir", "say", "scalar", "seek", "seekdir", "select", "semctl", "semget", "semop", "send", "setgrent", "sethostent", "setnetent", "setpgrp", "setpriority", "setprotoent", "setpwent", "setservent", "setsockopt", "shift", "shmctl", "shmget", "shmread", "shmwrite", "shutdown", "sin", "sleep", "socket", "socketpair", "sort", "splice", "split", "sprintf", "sqrt", "srand", "stat", "state", "study", "sub", "substr", "symlink", "syscall", "sysopen", "sysread", "sysseek", "system", "syswrite", "tell", "telldir", "tie", "tied", "time", "times", "tr", "truncate", "uc", "ucfirst", "umask", "undef", "unless", "unlink", "unpack", "unshift", "untie", "until", "use", "utime", "values", "vec", "wait", "waitpid", "wantarray", "warn", "when", "while", "write", "x|0", "xor", "y|0"],
        i = /[dualxmsipngr]{0,12}/,
        a = {
            $pattern: /[\w.]+/,
            keyword: n.join(" ")
        },
        u = {
            className: "subst",
            begin: "[$@]\\{",
            end: "\\}",
            keywords: a
        },
        s = {
            begin: /->\{/,
            end: /\}/
        },
        o = {
            scope: "attr",
            match: /\s+:\s*\w+(\s*\(.*?\))?/
        },
        c = {
            scope: "variable",
            variants: [{
                begin: /\$\d/
            }, {
                begin: t.concat(/[$%@](?!")(\^\w\b|#\w+(::\w+)*|\{\w+\}|\w+(::\w*)*)/, "(?![A-Za-z])(?![@$%])")
            }, {
                begin: /[$%@](?!")[^\s\w{=]|\$=/,
                relevance: 0
            }],
            contains: [o]
        },
        r = {
            className: "number",
            variants: [{
                match: /0?\.[0-9][0-9_]+\b/
            }, {
                match: /\bv?(0|[1-9][0-9_]*(\.[0-9_]+)?|[1-9][0-9_]*)\b/
            }, {
                match: /\b0[0-7][0-7_]*\b/
            }, {
                match: /\b0x[0-9a-fA-F][0-9a-fA-F_]*\b/
            }, {
                match: /\b0b[0-1][0-1_]*\b/
            }],
            relevance: 0
        },
        l = [e.BACKSLASH_ESCAPE, u, c],
        p = [/!/, /\//, /\|/, /\?/, /'/, /"/, /#/],
        d = (g, E, S = "\\1") => {
            const N = S === "\\1" ? S : t.concat(S, E);
            return t.concat(t.concat("(?:", g, ")"), E, /(?:\\.|[^\\\/])*?/, N, /(?:\\.|[^\\\/])*?/, S, i)
        },
        m = (g, E, S) => t.concat(t.concat("(?:", g, ")"), E, /(?:\\.|[^\\\/])*?/, S, i),
        b = [c, e.HASH_COMMENT_MODE, e.COMMENT(/^=\w/, /=cut/, {
            endsWithParent: !0
        }), s, {
            className: "string",
            contains: l,
            variants: [{
                begin: "q[qwxr]?\\s*\\(",
                end: "\\)",
                relevance: 5
            }, {
                begin: "q[qwxr]?\\s*\\[",
                end: "\\]",
                relevance: 5
            }, {
                begin: "q[qwxr]?\\s*\\{",
                end: "\\}",
                relevance: 5
            }, {
                begin: "q[qwxr]?\\s*\\|",
                end: "\\|",
                relevance: 5
            }, {
                begin: "q[qwxr]?\\s*<",
                end: ">",
                relevance: 5
            }, {
                begin: "qw\\s+q",
                end: "q",
                relevance: 5
            }, {
                begin: "'",
                end: "'",
                contains: [e.BACKSLASH_ESCAPE]
            }, {
                begin: '"',
                end: '"'
            }, {
                begin: "`",
                end: "`",
                contains: [e.BACKSLASH_ESCAPE]
            }, {
                begin: /\{\w+\}/,
                relevance: 0
            }, {
                begin: "-?\\w+\\s*=>",
                relevance: 0
            }]
        }, r, {
            begin: "(\\/\\/|" + e.RE_STARTERS_RE + "|\\b(split|return|print|reverse|grep)\\b)\\s*",
            keywords: "split return print reverse grep",
            relevance: 0,
            contains: [e.HASH_COMMENT_MODE, {
                className: "regexp",
                variants: [{
                    begin: d("s|tr|y", t.either(...p, {
                        capture: !0
                    }))
                }, {
                    begin: d("s|tr|y", "\\(", "\\)")
                }, {
                    begin: d("s|tr|y", "\\[", "\\]")
                }, {
                    begin: d("s|tr|y", "\\{", "\\}")
                }],
                relevance: 2
            }, {
                className: "regexp",
                variants: [{
                    begin: /(m|qr)\/\//,
                    relevance: 0
                }, {
                    begin: m("(?:m|qr)?", /\//, /\//)
                }, {
                    begin: m("m|qr", t.either(...p, {
                        capture: !0
                    }), /\1/)
                }, {
                    begin: m("m|qr", /\(/, /\)/)
                }, {
                    begin: m("m|qr", /\[/, /\]/)
                }, {
                    begin: m("m|qr", /\{/, /\}/)
                }]
            }]
        }, {
            className: "function",
            beginKeywords: "sub method",
            end: "(\\s*\\(.*?\\))?[;{]",
            excludeEnd: !0,
            relevance: 5,
            contains: [e.TITLE_MODE, o]
        }, {
            className: "class",
            beginKeywords: "class",
            end: "[;{]",
            excludeEnd: !0,
            relevance: 5,
            contains: [e.TITLE_MODE, o, r]
        }, {
            begin: "-\\w\\b",
            relevance: 0
        }, {
            begin: "^__DATA__$",
            end: "^__END__$",
            subLanguage: "mojolicious",
            contains: [{
                begin: "^@@.*",
                end: "$",
                className: "comment"
            }]
        }];
    return u.contains = b, s.contains = b, {
        name: "Perl",
        aliases: ["pl", "pm"],
        keywords: a,
        contains: b
    }
}

function tn(e) {
    const t = e.regex,
        n = /(?![A-Za-z0-9])(?![$])/,
        i = t.concat(/[a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*/, n),
        a = t.concat(/(\\?[A-Z][a-z0-9_\x7f-\xff]+|\\?[A-Z]+(?=[A-Z][a-z0-9_\x7f-\xff])){1,}/, n),
        u = t.concat(/[A-Z]+/, n),
        s = {
            scope: "variable",
            match: "\\$+" + i
        },
        o = {
            scope: "meta",
            variants: [{
                begin: /<\?php/,
                relevance: 10
            }, {
                begin: /<\?=/
            }, {
                begin: /<\?/,
                relevance: .1
            }, {
                begin: /\?>/
            }]
        },
        c = {
            scope: "subst",
            variants: [{
                begin: /\$\w+/
            }, {
                begin: /\{\$/,
                end: /\}/
            }]
        },
        r = e.inherit(e.APOS_STRING_MODE, {
            illegal: null
        }),
        l = e.inherit(e.QUOTE_STRING_MODE, {
            illegal: null,
            contains: e.QUOTE_STRING_MODE.contains.concat(c)
        }),
        p = {
            begin: /<<<[ \t]*(?:(\w+)|"(\w+)")\n/,
            end: /[ \t]*(\w+)\b/,
            contains: e.QUOTE_STRING_MODE.contains.concat(c),
            "on:begin": (P, M) => {
                M.data._beginMatch = P[1] || P[2]
            },
            "on:end": (P, M) => {
                M.data._beginMatch !== P[1] && M.ignoreMatch()
            }
        },
        d = e.END_SAME_AS_BEGIN({
            begin: /<<<[ \t]*'(\w+)'\n/,
            end: /[ \t]*(\w+)\b/
        }),
        m = "[ 	\n]",
        b = {
            scope: "string",
            variants: [l, r, p, d]
        },
        g = {
            scope: "number",
            variants: [{
                begin: "\\b0[bB][01]+(?:_[01]+)*\\b"
            }, {
                begin: "\\b0[oO][0-7]+(?:_[0-7]+)*\\b"
            }, {
                begin: "\\b0[xX][\\da-fA-F]+(?:_[\\da-fA-F]+)*\\b"
            }, {
                begin: "(?:\\b\\d+(?:_\\d+)*(\\.(?:\\d+(?:_\\d+)*))?|\\B\\.\\d+)(?:[eE][+-]?\\d+)?"
            }],
            relevance: 0
        },
        E = ["false", "null", "true"],
        S = ["__CLASS__", "__DIR__", "__FILE__", "__FUNCTION__", "__COMPILER_HALT_OFFSET__", "__LINE__", "__METHOD__", "__NAMESPACE__", "__TRAIT__", "die", "echo", "exit", "include", "include_once", "print", "require", "require_once", "array", "abstract", "and", "as", "binary", "bool", "boolean", "break", "callable", "case", "catch", "class", "clone", "const", "continue", "declare", "default", "do", "double", "else", "elseif", "empty", "enddeclare", "endfor", "endforeach", "endif", "endswitch", "endwhile", "enum", "eval", "extends", "final", "finally", "float", "for", "foreach", "from", "global", "goto", "if", "implements", "instanceof", "insteadof", "int", "integer", "interface", "isset", "iterable", "list", "match|0", "mixed", "new", "never", "object", "or", "private", "protected", "public", "readonly", "real", "return", "string", "switch", "throw", "trait", "try", "unset", "use", "var", "void", "while", "xor", "yield"],
        N = ["Error|0", "AppendIterator", "ArgumentCountError", "ArithmeticError", "ArrayIterator", "ArrayObject", "AssertionError", "BadFunctionCallException", "BadMethodCallException", "CachingIterator", "CallbackFilterIterator", "CompileError", "Countable", "DirectoryIterator", "DivisionByZeroError", "DomainException", "EmptyIterator", "ErrorException", "Exception", "FilesystemIterator", "FilterIterator", "GlobIterator", "InfiniteIterator", "InvalidArgumentException", "IteratorIterator", "LengthException", "LimitIterator", "LogicException", "MultipleIterator", "NoRewindIterator", "OutOfBoundsException", "OutOfRangeException", "OuterIterator", "OverflowException", "ParentIterator", "ParseError", "RangeException", "RecursiveArrayIterator", "RecursiveCachingIterator", "RecursiveCallbackFilterIterator", "RecursiveDirectoryIterator", "RecursiveFilterIterator", "RecursiveIterator", "RecursiveIteratorIterator", "RecursiveRegexIterator", "RecursiveTreeIterator", "RegexIterator", "RuntimeException", "SeekableIterator", "SplDoublyLinkedList", "SplFileInfo", "SplFileObject", "SplFixedArray", "SplHeap", "SplMaxHeap", "SplMinHeap", "SplObjectStorage", "SplObserver", "SplPriorityQueue", "SplQueue", "SplStack", "SplSubject", "SplTempFileObject", "TypeError", "UnderflowException", "UnexpectedValueException", "UnhandledMatchError", "ArrayAccess", "BackedEnum", "Closure", "Fiber", "Generator", "Iterator", "IteratorAggregate", "Serializable", "Stringable", "Throwable", "Traversable", "UnitEnum", "WeakReference", "WeakMap", "Directory", "__PHP_Incomplete_Class", "parent", "php_user_filter", "self", "static", "stdClass"],
        T = {
            keyword: S,
            literal: (P => {
                const M = [];
                return P.forEach(k => {
                    M.push(k), k.toLowerCase() === k ? M.push(k.toUpperCase()) : M.push(k.toLowerCase())
                }), M
            })(E),
            built_in: N
        },
        A = P => P.map(M => M.replace(/\|\d+$/, "")),
        C = {
            variants: [{
                match: [/new/, t.concat(m, "+"), t.concat("(?!", A(N).join("\\b|"), "\\b)"), a],
                scope: {
                    1: "keyword",
                    4: "title.class"
                }
            }]
        },
        O = t.concat(i, "\\b(?!\\()"),
        D = {
            variants: [{
                match: [t.concat(/::/, t.lookahead(/(?!class\b)/)), O],
                scope: {
                    2: "variable.constant"
                }
            }, {
                match: [/::/, /class/],
                scope: {
                    2: "variable.language"
                }
            }, {
                match: [a, t.concat(/::/, t.lookahead(/(?!class\b)/)), O],
                scope: {
                    1: "title.class",
                    3: "variable.constant"
                }
            }, {
                match: [a, t.concat("::", t.lookahead(/(?!class\b)/))],
                scope: {
                    1: "title.class"
                }
            }, {
                match: [a, /::/, /class/],
                scope: {
                    1: "title.class",
                    3: "variable.language"
                }
            }]
        },
        L = {
            scope: "attr",
            match: t.concat(i, t.lookahead(":"), t.lookahead(/(?!::)/))
        },
        R = {
            relevance: 0,
            begin: /\(/,
            end: /\)/,
            keywords: T,
            contains: [L, s, D, e.C_BLOCK_COMMENT_MODE, b, g, C]
        },
        f = {
            relevance: 0,
            match: [/\b/, t.concat("(?!fn\\b|function\\b|", A(S).join("\\b|"), "|", A(N).join("\\b|"), "\\b)"), i, t.concat(m, "*"), t.lookahead(/(?=\()/)],
            scope: {
                3: "title.function.invoke"
            },
            contains: [R]
        };
    R.contains.push(f);
    const G = [L, D, e.C_BLOCK_COMMENT_MODE, b, g, C],
        V = {
            begin: t.concat(/#\[\s*\\?/, t.either(a, u)),
            beginScope: "meta",
            end: /]/,
            endScope: "meta",
            keywords: {
                literal: E,
                keyword: ["new", "array"]
            },
            contains: [{
                begin: /\[/,
                end: /]/,
                keywords: {
                    literal: E,
                    keyword: ["new", "array"]
                },
                contains: ["self", ...G]
            }, ...G, {
                scope: "meta",
                variants: [{
                    match: a
                }, {
                    match: u
                }]
            }]
        };
    return {
        case_insensitive: !1,
        keywords: T,
        contains: [V, e.HASH_COMMENT_MODE, e.COMMENT("//", "$"), e.COMMENT("/\\*", "\\*/", {
            contains: [{
                scope: "doctag",
                match: "@[A-Za-z]+"
            }]
        }), {
            match: /__halt_compiler\(\);/,
            keywords: "__halt_compiler",
            starts: {
                scope: "comment",
                end: e.MATCH_NOTHING_RE,
                contains: [{
                    match: /\?>/,
                    scope: "meta",
                    endsParent: !0
                }]
            }
        }, o, {
            scope: "variable.language",
            match: /\$this\b/
        }, s, f, D, {
            match: [/const/, /\s/, i],
            scope: {
                1: "keyword",
                3: "variable.constant"
            }
        }, C, {
            scope: "function",
            relevance: 0,
            beginKeywords: "fn function",
            end: /[;{]/,
            excludeEnd: !0,
            illegal: "[$%\\[]",
            contains: [{
                beginKeywords: "use"
            }, e.UNDERSCORE_TITLE_MODE, {
                begin: "=>",
                endsParent: !0
            }, {
                scope: "params",
                begin: "\\(",
                end: "\\)",
                excludeBegin: !0,
                excludeEnd: !0,
                keywords: T,
                contains: ["self", V, s, D, e.C_BLOCK_COMMENT_MODE, b, g]
            }]
        }, {
            scope: "class",
            variants: [{
                beginKeywords: "enum",
                illegal: /[($"]/
            }, {
                beginKeywords: "class interface trait",
                illegal: /[:($"]/
            }],
            relevance: 0,
            end: /\{/,
            excludeEnd: !0,
            contains: [{
                beginKeywords: "extends implements"
            }, e.UNDERSCORE_TITLE_MODE]
        }, {
            beginKeywords: "namespace",
            relevance: 0,
            end: ";",
            illegal: /[.']/,
            contains: [e.inherit(e.UNDERSCORE_TITLE_MODE, {
                scope: "title.class"
            })]
        }, {
            beginKeywords: "use",
            relevance: 0,
            end: ";",
            contains: [{
                match: /\b(as|const|function)\b/,
                scope: "keyword"
            }, e.UNDERSCORE_TITLE_MODE]
        }, b, g]
    }
}

function nn(e) {
    return {
        name: "PHP template",
        subLanguage: "xml",
        contains: [{
            begin: /<\?(php|=)?/,
            end: /\?>/,
            subLanguage: "php",
            contains: [{
                begin: "/\\*",
                end: "\\*/",
                skip: !0
            }, {
                begin: 'b"',
                end: '"',
                skip: !0
            }, {
                begin: "b'",
                end: "'",
                skip: !0
            }, e.inherit(e.APOS_STRING_MODE, {
                illegal: null,
                className: null,
                contains: null,
                skip: !0
            }), e.inherit(e.QUOTE_STRING_MODE, {
                illegal: null,
                className: null,
                contains: null,
                skip: !0
            })]
        }]
    }
}

function an(e) {
    return {
        name: "Plain text",
        aliases: ["text", "txt"],
        disableAutodetect: !0
    }
}

function on(e) {
    const t = e.regex,
        n = new RegExp("[\\p{XID_Start}_]\\p{XID_Continue}*", "u"),
        i = ["and", "as", "assert", "async", "await", "break", "case", "class", "continue", "def", "del", "elif", "else", "except", "finally", "for", "from", "global", "if", "import", "in", "is", "lambda", "match", "nonlocal|10", "not", "or", "pass", "raise", "return", "try", "while", "with", "yield"],
        o = {
            $pattern: /[A-Za-z]\w+|__\w+__/,
            keyword: i,
            built_in: ["__import__", "abs", "all", "any", "ascii", "bin", "bool", "breakpoint", "bytearray", "bytes", "callable", "chr", "classmethod", "compile", "complex", "delattr", "dict", "dir", "divmod", "enumerate", "eval", "exec", "filter", "float", "format", "frozenset", "getattr", "globals", "hasattr", "hash", "help", "hex", "id", "input", "int", "isinstance", "issubclass", "iter", "len", "list", "locals", "map", "max", "memoryview", "min", "next", "object", "oct", "open", "ord", "pow", "print", "property", "range", "repr", "reversed", "round", "set", "setattr", "slice", "sorted", "staticmethod", "str", "sum", "super", "tuple", "type", "vars", "zip"],
            literal: ["__debug__", "Ellipsis", "False", "None", "NotImplemented", "True"],
            type: ["Any", "Callable", "Coroutine", "Dict", "List", "Literal", "Generic", "Optional", "Sequence", "Set", "Tuple", "Type", "Union"]
        },
        c = {
            className: "meta",
            begin: /^(>>>|\.\.\.) /
        },
        r = {
            className: "subst",
            begin: /\{/,
            end: /\}/,
            keywords: o,
            illegal: /#/
        },
        l = {
            begin: /\{\{/,
            relevance: 0
        },
        p = {
            className: "string",
            contains: [e.BACKSLASH_ESCAPE],
            variants: [{
                begin: /([uU]|[bB]|[rR]|[bB][rR]|[rR][bB])?'''/,
                end: /'''/,
                contains: [e.BACKSLASH_ESCAPE, c],
                relevance: 10
            }, {
                begin: /([uU]|[bB]|[rR]|[bB][rR]|[rR][bB])?"""/,
                end: /"""/,
                contains: [e.BACKSLASH_ESCAPE, c],
                relevance: 10
            }, {
                begin: /([fF][rR]|[rR][fF]|[fF])'''/,
                end: /'''/,
                contains: [e.BACKSLASH_ESCAPE, c, l, r]
            }, {
                begin: /([fF][rR]|[rR][fF]|[fF])"""/,
                end: /"""/,
                contains: [e.BACKSLASH_ESCAPE, c, l, r]
            }, {
                begin: /([uU]|[rR])'/,
                end: /'/,
                relevance: 10
            }, {
                begin: /([uU]|[rR])"/,
                end: /"/,
                relevance: 10
            }, {
                begin: /([bB]|[bB][rR]|[rR][bB])'/,
                end: /'/
            }, {
                begin: /([bB]|[bB][rR]|[rR][bB])"/,
                end: /"/
            }, {
                begin: /([fF][rR]|[rR][fF]|[fF])'/,
                end: /'/,
                contains: [e.BACKSLASH_ESCAPE, l, r]
            }, {
                begin: /([fF][rR]|[rR][fF]|[fF])"/,
                end: /"/,
                contains: [e.BACKSLASH_ESCAPE, l, r]
            }, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE]
        },
        d = "[0-9](_?[0-9])*",
        m = "(\\b(".concat(d, "))?\\.(").concat(d, ")|\\b(").concat(d, ")\\."),
        b = "\\b|".concat(i.join("|")),
        g = {
            className: "number",
            relevance: 0,
            variants: [{
                begin: "(\\b(".concat(d, ")|(").concat(m, "))[eE][+-]?(").concat(d, ")[jJ]?(?=").concat(b, ")")
            }, {
                begin: "(".concat(m, ")[jJ]?")
            }, {
                begin: "\\b([1-9](_?[0-9])*|0+(_?0)*)[lLjJ]?(?=".concat(b, ")")
            }, {
                begin: "\\b0[bB](_?[01])+[lL]?(?=".concat(b, ")")
            }, {
                begin: "\\b0[oO](_?[0-7])+[lL]?(?=".concat(b, ")")
            }, {
                begin: "\\b0[xX](_?[0-9a-fA-F])+[lL]?(?=".concat(b, ")")
            }, {
                begin: "\\b(".concat(d, ")[jJ](?=").concat(b, ")")
            }]
        },
        E = {
            className: "comment",
            begin: t.lookahead(/# type:/),
            end: /$/,
            keywords: o,
            contains: [{
                begin: /# type:/
            }, {
                begin: /#/,
                end: /\b\B/,
                endsWithParent: !0
            }]
        },
        S = {
            className: "params",
            variants: [{
                className: "",
                begin: /\(\s*\)/,
                skip: !0
            }, {
                begin: /\(/,
                end: /\)/,
                excludeBegin: !0,
                excludeEnd: !0,
                keywords: o,
                contains: ["self", c, g, p, e.HASH_COMMENT_MODE]
            }]
        };
    return r.contains = [p, g, c], {
        name: "Python",
        aliases: ["py", "gyp", "ipython"],
        unicodeRegex: !0,
        keywords: o,
        illegal: /(<\/|\?)|=>/,
        contains: [c, g, {
            scope: "variable.language",
            match: /\bself\b/
        }, {
            beginKeywords: "if",
            relevance: 0
        }, {
            match: /\bor\b/,
            scope: "keyword"
        }, p, E, e.HASH_COMMENT_MODE, {
            match: [/\bdef/, /\s+/, n],
            scope: {
                1: "keyword",
                3: "title.function"
            },
            contains: [S]
        }, {
            variants: [{
                match: [/\bclass/, /\s+/, n, /\s*/, /\(\s*/, n, /\s*\)/]
            }, {
                match: [/\bclass/, /\s+/, n]
            }],
            scope: {
                1: "keyword",
                3: "title.class",
                6: "title.class.inherited"
            }
        }, {
            className: "meta",
            begin: /^[\t ]*@/,
            end: /(?=#)|$/,
            contains: [g, S, p]
        }]
    }
}

function rn(e) {
    return {
        aliases: ["pycon"],
        contains: [{
            className: "meta.prompt",
            starts: {
                end: / |$/,
                starts: {
                    end: "$",
                    subLanguage: "python"
                }
            },
            variants: [{
                begin: /^>>>(?=[ ]|$)/
            }, {
                begin: /^\.\.\.(?=[ ]|$)/
            }]
        }]
    }
}

function sn(e) {
    const t = e.regex,
        n = /(?:(?:[a-zA-Z]|\.[._a-zA-Z])[._a-zA-Z0-9]*)|\.(?!\d)/,
        i = t.either(/0[xX][0-9a-fA-F]+\.[0-9a-fA-F]*[pP][+-]?\d+i?/, /0[xX][0-9a-fA-F]+(?:[pP][+-]?\d+)?[Li]?/, /(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?[Li]?/),
        a = /[=!<>:]=|\|\||&&|:::?|<-|<<-|->>|->|\|>|[-+*\/?!$&|:<=>@^~]|\*\*/,
        u = t.either(/[()]/, /[{}]/, /\[\[/, /[[\]]/, /\\/, /,/);
    return {
        name: "R",
        keywords: {
            $pattern: n,
            keyword: "function if in break next repeat else for while",
            literal: "NULL NA TRUE FALSE Inf NaN NA_integer_|10 NA_real_|10 NA_character_|10 NA_complex_|10",
            built_in: "LETTERS letters month.abb month.name pi T F abs acos acosh all any anyNA Arg as.call as.character as.complex as.double as.environment as.integer as.logical as.null.default as.numeric as.raw asin asinh atan atanh attr attributes baseenv browser c call ceiling class Conj cos cosh cospi cummax cummin cumprod cumsum digamma dim dimnames emptyenv exp expression floor forceAndCall gamma gc.time globalenv Im interactive invisible is.array is.atomic is.call is.character is.complex is.double is.environment is.expression is.finite is.function is.infinite is.integer is.language is.list is.logical is.matrix is.na is.name is.nan is.null is.numeric is.object is.pairlist is.raw is.recursive is.single is.symbol lazyLoadDBfetch length lgamma list log max min missing Mod names nargs nzchar oldClass on.exit pos.to.env proc.time prod quote range Re rep retracemem return round seq_along seq_len seq.int sign signif sin sinh sinpi sqrt standardGeneric substitute sum switch tan tanh tanpi tracemem trigamma trunc unclass untracemem UseMethod xtfrm"
        },
        contains: [e.COMMENT(/#'/, /$/, {
            contains: [{
                scope: "doctag",
                match: /@examples/,
                starts: {
                    end: t.lookahead(t.either(/\n^#'\s*(?=@[a-zA-Z]+)/, /\n^(?!#')/)),
                    endsParent: !0
                }
            }, {
                scope: "doctag",
                begin: "@param",
                end: /$/,
                contains: [{
                    scope: "variable",
                    variants: [{
                        match: n
                    }, {
                        match: /`(?:\\.|[^`\\])+`/
                    }],
                    endsParent: !0
                }]
            }, {
                scope: "doctag",
                match: /@[a-zA-Z]+/
            }, {
                scope: "keyword",
                match: /\\[a-zA-Z]+/
            }]
        }), e.HASH_COMMENT_MODE, {
            scope: "string",
            contains: [e.BACKSLASH_ESCAPE],
            variants: [e.END_SAME_AS_BEGIN({
                begin: /[rR]"(-*)\(/,
                end: /\)(-*)"/
            }), e.END_SAME_AS_BEGIN({
                begin: /[rR]"(-*)\{/,
                end: /\}(-*)"/
            }), e.END_SAME_AS_BEGIN({
                begin: /[rR]"(-*)\[/,
                end: /\](-*)"/
            }), e.END_SAME_AS_BEGIN({
                begin: /[rR]'(-*)\(/,
                end: /\)(-*)'/
            }), e.END_SAME_AS_BEGIN({
                begin: /[rR]'(-*)\{/,
                end: /\}(-*)'/
            }), e.END_SAME_AS_BEGIN({
                begin: /[rR]'(-*)\[/,
                end: /\](-*)'/
            }), {
                begin: '"',
                end: '"',
                relevance: 0
            }, {
                begin: "'",
                end: "'",
                relevance: 0
            }]
        }, {
            relevance: 0,
            variants: [{
                scope: {
                    1: "operator",
                    2: "number"
                },
                match: [a, i]
            }, {
                scope: {
                    1: "operator",
                    2: "number"
                },
                match: [/%[^%]*%/, i]
            }, {
                scope: {
                    1: "punctuation",
                    2: "number"
                },
                match: [u, i]
            }, {
                scope: {
                    2: "number"
                },
                match: [/[^a-zA-Z0-9._]|^/, i]
            }]
        }, {
            scope: {
                3: "operator"
            },
            match: [n, /\s+/, /<-/, /\s+/]
        }, {
            scope: "operator",
            relevance: 0,
            variants: [{
                match: a
            }, {
                match: /%[^%]*%/
            }]
        }, {
            scope: "punctuation",
            relevance: 0,
            match: u
        }, {
            begin: "`",
            end: "`",
            contains: [{
                begin: /\\./
            }]
        }]
    }
}

function ln(e) {
    const t = e.regex,
        n = "([a-zA-Z_]\\w*[!?=]?|[-+~]@|<<|>>|=~|===?|<=>|[<>]=?|\\*\\*|[-/+%^&*~`|]|\\[\\]=?)",
        i = t.either(/\b([A-Z]+[a-z0-9]+)+/, /\b([A-Z]+[a-z0-9]+)+[A-Z]+/),
        a = t.concat(i, /(::\w+)*/),
        s = {
            "variable.constant": ["__FILE__", "__LINE__", "__ENCODING__"],
            "variable.language": ["self", "super"],
            keyword: ["alias", "and", "begin", "BEGIN", "break", "case", "class", "defined", "do", "else", "elsif", "end", "END", "ensure", "for", "if", "in", "module", "next", "not", "or", "redo", "require", "rescue", "retry", "return", "then", "undef", "unless", "until", "when", "while", "yield", ...["include", "extend", "prepend", "public", "private", "protected", "raise", "throw"]],
            built_in: ["proc", "lambda", "attr_accessor", "attr_reader", "attr_writer", "define_method", "private_constant", "module_function"],
            literal: ["true", "false", "nil"]
        },
        o = {
            className: "doctag",
            begin: "@[A-Za-z]+"
        },
        c = {
            begin: "#<",
            end: ">"
        },
        r = [e.COMMENT("#", "$", {
            contains: [o]
        }), e.COMMENT("^=begin", "^=end", {
            contains: [o],
            relevance: 10
        }), e.COMMENT("^__END__", e.MATCH_NOTHING_RE)],
        l = {
            className: "subst",
            begin: /#\{/,
            end: /\}/,
            keywords: s
        },
        p = {
            className: "string",
            contains: [e.BACKSLASH_ESCAPE, l],
            variants: [{
                begin: /'/,
                end: /'/
            }, {
                begin: /"/,
                end: /"/
            }, {
                begin: /`/,
                end: /`/
            }, {
                begin: /%[qQwWx]?\(/,
                end: /\)/
            }, {
                begin: /%[qQwWx]?\[/,
                end: /\]/
            }, {
                begin: /%[qQwWx]?\{/,
                end: /\}/
            }, {
                begin: /%[qQwWx]?</,
                end: />/
            }, {
                begin: /%[qQwWx]?\//,
                end: /\//
            }, {
                begin: /%[qQwWx]?%/,
                end: /%/
            }, {
                begin: /%[qQwWx]?-/,
                end: /-/
            }, {
                begin: /%[qQwWx]?\|/,
                end: /\|/
            }, {
                begin: /\B\?(\\\d{1,3})/
            }, {
                begin: /\B\?(\\x[A-Fa-f0-9]{1,2})/
            }, {
                begin: /\B\?(\\u\{?[A-Fa-f0-9]{1,6}\}?)/
            }, {
                begin: /\B\?(\\M-\\C-|\\M-\\c|\\c\\M-|\\M-|\\C-\\M-)[\x20-\x7e]/
            }, {
                begin: /\B\?\\(c|C-)[\x20-\x7e]/
            }, {
                begin: /\B\?\\?\S/
            }, {
                begin: t.concat(/<<[-~]?'?/, t.lookahead(/(\w+)(?=\W)[^\n]*\n(?:[^\n]*\n)*?\s*\1\b/)),
                contains: [e.END_SAME_AS_BEGIN({
                    begin: /(\w+)/,
                    end: /(\w+)/,
                    contains: [e.BACKSLASH_ESCAPE, l]
                })]
            }]
        },
        d = "[1-9](_?[0-9])*|0",
        m = "[0-9](_?[0-9])*",
        b = {
            className: "number",
            relevance: 0,
            variants: [{
                begin: "\\b(".concat(d, ")(\\.(").concat(m, "))?([eE][+-]?(").concat(m, ")|r)?i?\\b")
            }, {
                begin: "\\b0[dD][0-9](_?[0-9])*r?i?\\b"
            }, {
                begin: "\\b0[bB][0-1](_?[0-1])*r?i?\\b"
            }, {
                begin: "\\b0[oO][0-7](_?[0-7])*r?i?\\b"
            }, {
                begin: "\\b0[xX][0-9a-fA-F](_?[0-9a-fA-F])*r?i?\\b"
            }, {
                begin: "\\b0(_?[0-7])+r?i?\\b"
            }]
        },
        g = {
            variants: [{
                match: /\(\)/
            }, {
                className: "params",
                begin: /\(/,
                end: /(?=\))/,
                excludeBegin: !0,
                endsParent: !0,
                keywords: s
            }]
        },
        C = [p, {
            variants: [{
                match: [/class\s+/, a, /\s+<\s+/, a]
            }, {
                match: [/\b(class|module)\s+/, a]
            }],
            scope: {
                2: "title.class",
                4: "title.class.inherited"
            },
            keywords: s
        }, {
            match: [/(include|extend)\s+/, a],
            scope: {
                2: "title.class"
            },
            keywords: s
        }, {
            relevance: 0,
            match: [a, /\.new[. (]/],
            scope: {
                1: "title.class"
            }
        }, {
            relevance: 0,
            match: /\b[A-Z][A-Z_0-9]+\b/,
            className: "variable.constant"
        }, {
            relevance: 0,
            match: i,
            scope: "title.class"
        }, {
            match: [/def/, /\s+/, n],
            scope: {
                1: "keyword",
                3: "title.function"
            },
            contains: [g]
        }, {
            begin: e.IDENT_RE + "::"
        }, {
            className: "symbol",
            begin: e.UNDERSCORE_IDENT_RE + "(!|\\?)?:",
            relevance: 0
        }, {
            className: "symbol",
            begin: ":(?!\\s)",
            contains: [p, {
                begin: n
            }],
            relevance: 0
        }, b, {
            className: "variable",
            begin: "(\\$\\W)|((\\$|@@?)(\\w+))(?=[^@$?])(?![A-Za-z])(?![@$?'])"
        }, {
            className: "params",
            begin: /\|(?!=)/,
            end: /\|/,
            excludeBegin: !0,
            excludeEnd: !0,
            relevance: 0,
            keywords: s
        }, {
            begin: "(" + e.RE_STARTERS_RE + "|unless)\\s*",
            keywords: "unless",
            contains: [{
                className: "regexp",
                contains: [e.BACKSLASH_ESCAPE, l],
                illegal: /\n/,
                variants: [{
                    begin: "/",
                    end: "/[a-z]*"
                }, {
                    begin: /%r\{/,
                    end: /\}[a-z]*/
                }, {
                    begin: "%r\\(",
                    end: "\\)[a-z]*"
                }, {
                    begin: "%r!",
                    end: "![a-z]*"
                }, {
                    begin: "%r\\[",
                    end: "\\][a-z]*"
                }]
            }].concat(c, r),
            relevance: 0
        }].concat(c, r);
    l.contains = C, g.contains = C;
    const R = [{
        begin: /^\s*=>/,
        starts: {
            end: "$",
            contains: C
        }
    }, {
        className: "meta.prompt",
        begin: "^(" + "[>?]>" + "|" + "[\\w#]+\\(\\w+\\):\\d+:\\d+[>*]" + "|" + "(\\w+-)?\\d+\\.\\d+\\.\\d+(p\\d+)?[^\\d][^>]+>" + ")(?=[ ])",
        starts: {
            end: "$",
            keywords: s,
            contains: C
        }
    }];
    return r.unshift(c), {
        name: "Ruby",
        aliases: ["rb", "gemspec", "podspec", "thor", "irb"],
        keywords: s,
        illegal: /\/\*/,
        contains: [e.SHEBANG({
            binary: "ruby"
        })].concat(R).concat(r).concat(C)
    }
}

function cn(e) {
    const t = e.regex,
        n = /(r#)?/,
        i = t.concat(n, e.UNDERSCORE_IDENT_RE),
        a = t.concat(n, e.IDENT_RE),
        u = {
            className: "title.function.invoke",
            relevance: 0,
            begin: t.concat(/\b/, /(?!let|for|while|if|else|match\b)/, a, t.lookahead(/\s*\(/))
        },
        s = "([ui](8|16|32|64|128|size)|f(32|64))?",
        o = ["abstract", "as", "async", "await", "become", "box", "break", "const", "continue", "crate", "do", "dyn", "else", "enum", "extern", "false", "final", "fn", "for", "if", "impl", "in", "let", "loop", "macro", "match", "mod", "move", "mut", "override", "priv", "pub", "ref", "return", "self", "Self", "static", "struct", "super", "trait", "true", "try", "type", "typeof", "union", "unsafe", "unsized", "use", "virtual", "where", "while", "yield"],
        c = ["true", "false", "Some", "None", "Ok", "Err"],
        r = ["drop ", "Copy", "Send", "Sized", "Sync", "Drop", "Fn", "FnMut", "FnOnce", "ToOwned", "Clone", "Debug", "PartialEq", "PartialOrd", "Eq", "Ord", "AsRef", "AsMut", "Into", "From", "Default", "Iterator", "Extend", "IntoIterator", "DoubleEndedIterator", "ExactSizeIterator", "SliceConcatExt", "ToString", "assert!", "assert_eq!", "bitflags!", "bytes!", "cfg!", "col!", "concat!", "concat_idents!", "debug_assert!", "debug_assert_eq!", "env!", "eprintln!", "panic!", "file!", "format!", "format_args!", "include_bytes!", "include_str!", "line!", "local_data_key!", "module_path!", "option_env!", "print!", "println!", "select!", "stringify!", "try!", "unimplemented!", "unreachable!", "vec!", "write!", "writeln!", "macro_rules!", "assert_ne!", "debug_assert_ne!"],
        l = ["i8", "i16", "i32", "i64", "i128", "isize", "u8", "u16", "u32", "u64", "u128", "usize", "f32", "f64", "str", "char", "bool", "Box", "Option", "Result", "String", "Vec"];
    return {
        name: "Rust",
        aliases: ["rs"],
        keywords: {
            $pattern: e.IDENT_RE + "!?",
            type: l,
            keyword: o,
            literal: c,
            built_in: r
        },
        illegal: "</",
        contains: [e.C_LINE_COMMENT_MODE, e.COMMENT("/\\*", "\\*/", {
            contains: ["self"]
        }), e.inherit(e.QUOTE_STRING_MODE, {
            begin: /b?"/,
            illegal: null
        }), {
            className: "symbol",
            begin: /'[a-zA-Z_][a-zA-Z0-9_]*(?!')/
        }, {
            scope: "string",
            variants: [{
                begin: /b?r(#*)"(.|\n)*?"\1(?!#)/
            }, {
                begin: /b?'/,
                end: /'/,
                contains: [{
                    scope: "char.escape",
                    match: /\\('|\w|x\w{2}|u\w{4}|U\w{8})/
                }]
            }]
        }, {
            className: "number",
            variants: [{
                begin: "\\b0b([01_]+)" + s
            }, {
                begin: "\\b0o([0-7_]+)" + s
            }, {
                begin: "\\b0x([A-Fa-f0-9_]+)" + s
            }, {
                begin: "\\b(\\d[\\d_]*(\\.[0-9_]+)?([eE][+-]?[0-9_]+)?)" + s
            }],
            relevance: 0
        }, {
            begin: [/fn/, /\s+/, i],
            className: {
                1: "keyword",
                3: "title.function"
            }
        }, {
            className: "meta",
            begin: "#!?\\[",
            end: "\\]",
            contains: [{
                className: "string",
                begin: /"/,
                end: /"/,
                contains: [e.BACKSLASH_ESCAPE]
            }]
        }, {
            begin: [/let/, /\s+/, /(?:mut\s+)?/, i],
            className: {
                1: "keyword",
                3: "keyword",
                4: "variable"
            }
        }, {
            begin: [/for/, /\s+/, i, /\s+/, /in/],
            className: {
                1: "keyword",
                3: "variable",
                5: "keyword"
            }
        }, {
            begin: [/type/, /\s+/, i],
            className: {
                1: "keyword",
                3: "title.class"
            }
        }, {
            begin: [/(?:trait|enum|struct|union|impl|for)/, /\s+/, i],
            className: {
                1: "keyword",
                3: "title.class"
            }
        }, {
            begin: e.IDENT_RE + "::",
            keywords: {
                keyword: "Self",
                built_in: r,
                type: l
            }
        }, {
            className: "punctuation",
            begin: "->"
        }, u]
    }
}
const dt = e => ({
        IMPORTANT: {
            scope: "meta",
            begin: "!important"
        },
        BLOCK_COMMENT: e.C_BLOCK_COMMENT_MODE,
        HEXCOLOR: {
            scope: "number",
            begin: /#(([0-9a-fA-F]{3,4})|(([0-9a-fA-F]{2}){3,4}))\b/
        },
        FUNCTION_DISPATCH: {
            className: "built_in",
            begin: /[\w-]+(?=\()/
        },
        ATTRIBUTE_SELECTOR_MODE: {
            scope: "selector-attr",
            begin: /\[/,
            end: /\]/,
            illegal: "$",
            contains: [e.APOS_STRING_MODE, e.QUOTE_STRING_MODE]
        },
        CSS_NUMBER_MODE: {
            scope: "number",
            begin: e.NUMBER_RE + "(%|em|ex|ch|rem|vw|vh|vmin|vmax|cm|mm|in|pt|pc|px|deg|grad|rad|turn|s|ms|Hz|kHz|dpi|dpcm|dppx)?",
            relevance: 0
        },
        CSS_VARIABLE: {
            className: "attr",
            begin: /--[A-Za-z_][A-Za-z0-9_-]*/
        }
    }),
    ut = ["a", "abbr", "address", "article", "aside", "audio", "b", "blockquote", "body", "button", "canvas", "caption", "cite", "code", "dd", "del", "details", "dfn", "div", "dl", "dt", "em", "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "header", "hgroup", "html", "i", "iframe", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "mark", "menu", "nav", "object", "ol", "optgroup", "option", "p", "picture", "q", "quote", "samp", "section", "select", "source", "span", "strong", "summary", "sup", "table", "tbody", "td", "textarea", "tfoot", "th", "thead", "time", "tr", "ul", "var", "video"],
    mt = ["defs", "g", "marker", "mask", "pattern", "svg", "switch", "symbol", "feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feFlood", "feGaussianBlur", "feImage", "feMerge", "feMorphology", "feOffset", "feSpecularLighting", "feTile", "feTurbulence", "linearGradient", "radialGradient", "stop", "circle", "ellipse", "image", "line", "path", "polygon", "polyline", "rect", "text", "use", "textPath", "tspan", "foreignObject", "clipPath"],
    pt = [...ut, ...mt],
    gt = ["any-hover", "any-pointer", "aspect-ratio", "color", "color-gamut", "color-index", "device-aspect-ratio", "device-height", "device-width", "display-mode", "forced-colors", "grid", "height", "hover", "inverted-colors", "monochrome", "orientation", "overflow-block", "overflow-inline", "pointer", "prefers-color-scheme", "prefers-contrast", "prefers-reduced-motion", "prefers-reduced-transparency", "resolution", "scan", "scripting", "update", "width", "min-width", "max-width", "min-height", "max-height"].sort().reverse(),
    Et = ["active", "any-link", "blank", "checked", "current", "default", "defined", "dir", "disabled", "drop", "empty", "enabled", "first", "first-child", "first-of-type", "fullscreen", "future", "focus", "focus-visible", "focus-within", "has", "host", "host-context", "hover", "indeterminate", "in-range", "invalid", "is", "lang", "last-child", "last-of-type", "left", "link", "local-link", "not", "nth-child", "nth-col", "nth-last-child", "nth-last-col", "nth-last-of-type", "nth-of-type", "only-child", "only-of-type", "optional", "out-of-range", "past", "placeholder-shown", "read-only", "read-write", "required", "right", "root", "scope", "target", "target-within", "user-invalid", "valid", "visited", "where"].sort().reverse(),
    St = ["after", "backdrop", "before", "cue", "cue-region", "first-letter", "first-line", "grammar-error", "marker", "part", "placeholder", "selection", "slotted", "spelling-error"].sort().reverse(),
    bt = ["accent-color", "align-content", "align-items", "align-self", "alignment-baseline", "all", "anchor-name", "animation", "animation-composition", "animation-delay", "animation-direction", "animation-duration", "animation-fill-mode", "animation-iteration-count", "animation-name", "animation-play-state", "animation-range", "animation-range-end", "animation-range-start", "animation-timeline", "animation-timing-function", "appearance", "aspect-ratio", "backdrop-filter", "backface-visibility", "background", "background-attachment", "background-blend-mode", "background-clip", "background-color", "background-image", "background-origin", "background-position", "background-position-x", "background-position-y", "background-repeat", "background-size", "baseline-shift", "block-size", "border", "border-block", "border-block-color", "border-block-end", "border-block-end-color", "border-block-end-style", "border-block-end-width", "border-block-start", "border-block-start-color", "border-block-start-style", "border-block-start-width", "border-block-style", "border-block-width", "border-bottom", "border-bottom-color", "border-bottom-left-radius", "border-bottom-right-radius", "border-bottom-style", "border-bottom-width", "border-collapse", "border-color", "border-end-end-radius", "border-end-start-radius", "border-image", "border-image-outset", "border-image-repeat", "border-image-slice", "border-image-source", "border-image-width", "border-inline", "border-inline-color", "border-inline-end", "border-inline-end-color", "border-inline-end-style", "border-inline-end-width", "border-inline-start", "border-inline-start-color", "border-inline-start-style", "border-inline-start-width", "border-inline-style", "border-inline-width", "border-left", "border-left-color", "border-left-style", "border-left-width", "border-radius", "border-right", "border-right-color", "border-right-style", "border-right-width", "border-spacing", "border-start-end-radius", "border-start-start-radius", "border-style", "border-top", "border-top-color", "border-top-left-radius", "border-top-right-radius", "border-top-style", "border-top-width", "border-width", "bottom", "box-align", "box-decoration-break", "box-direction", "box-flex", "box-flex-group", "box-lines", "box-ordinal-group", "box-orient", "box-pack", "box-shadow", "box-sizing", "break-after", "break-before", "break-inside", "caption-side", "caret-color", "clear", "clip", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "color-scheme", "column-count", "column-fill", "column-gap", "column-rule", "column-rule-color", "column-rule-style", "column-rule-width", "column-span", "column-width", "columns", "contain", "contain-intrinsic-block-size", "contain-intrinsic-height", "contain-intrinsic-inline-size", "contain-intrinsic-size", "contain-intrinsic-width", "container", "container-name", "container-type", "content", "content-visibility", "counter-increment", "counter-reset", "counter-set", "cue", "cue-after", "cue-before", "cursor", "cx", "cy", "direction", "display", "dominant-baseline", "empty-cells", "enable-background", "field-sizing", "fill", "fill-opacity", "fill-rule", "filter", "flex", "flex-basis", "flex-direction", "flex-flow", "flex-grow", "flex-shrink", "flex-wrap", "float", "flood-color", "flood-opacity", "flow", "font", "font-display", "font-family", "font-feature-settings", "font-kerning", "font-language-override", "font-optical-sizing", "font-palette", "font-size", "font-size-adjust", "font-smooth", "font-smoothing", "font-stretch", "font-style", "font-synthesis", "font-synthesis-position", "font-synthesis-small-caps", "font-synthesis-style", "font-synthesis-weight", "font-variant", "font-variant-alternates", "font-variant-caps", "font-variant-east-asian", "font-variant-emoji", "font-variant-ligatures", "font-variant-numeric", "font-variant-position", "font-variation-settings", "font-weight", "forced-color-adjust", "gap", "glyph-orientation-horizontal", "glyph-orientation-vertical", "grid", "grid-area", "grid-auto-columns", "grid-auto-flow", "grid-auto-rows", "grid-column", "grid-column-end", "grid-column-start", "grid-gap", "grid-row", "grid-row-end", "grid-row-start", "grid-template", "grid-template-areas", "grid-template-columns", "grid-template-rows", "hanging-punctuation", "height", "hyphenate-character", "hyphenate-limit-chars", "hyphens", "icon", "image-orientation", "image-rendering", "image-resolution", "ime-mode", "initial-letter", "initial-letter-align", "inline-size", "inset", "inset-area", "inset-block", "inset-block-end", "inset-block-start", "inset-inline", "inset-inline-end", "inset-inline-start", "isolation", "justify-content", "justify-items", "justify-self", "kerning", "left", "letter-spacing", "lighting-color", "line-break", "line-height", "line-height-step", "list-style", "list-style-image", "list-style-position", "list-style-type", "margin", "margin-block", "margin-block-end", "margin-block-start", "margin-bottom", "margin-inline", "margin-inline-end", "margin-inline-start", "margin-left", "margin-right", "margin-top", "margin-trim", "marker", "marker-end", "marker-mid", "marker-start", "marks", "mask", "mask-border", "mask-border-mode", "mask-border-outset", "mask-border-repeat", "mask-border-slice", "mask-border-source", "mask-border-width", "mask-clip", "mask-composite", "mask-image", "mask-mode", "mask-origin", "mask-position", "mask-repeat", "mask-size", "mask-type", "masonry-auto-flow", "math-depth", "math-shift", "math-style", "max-block-size", "max-height", "max-inline-size", "max-width", "min-block-size", "min-height", "min-inline-size", "min-width", "mix-blend-mode", "nav-down", "nav-index", "nav-left", "nav-right", "nav-up", "none", "normal", "object-fit", "object-position", "offset", "offset-anchor", "offset-distance", "offset-path", "offset-position", "offset-rotate", "opacity", "order", "orphans", "outline", "outline-color", "outline-offset", "outline-style", "outline-width", "overflow", "overflow-anchor", "overflow-block", "overflow-clip-margin", "overflow-inline", "overflow-wrap", "overflow-x", "overflow-y", "overlay", "overscroll-behavior", "overscroll-behavior-block", "overscroll-behavior-inline", "overscroll-behavior-x", "overscroll-behavior-y", "padding", "padding-block", "padding-block-end", "padding-block-start", "padding-bottom", "padding-inline", "padding-inline-end", "padding-inline-start", "padding-left", "padding-right", "padding-top", "page", "page-break-after", "page-break-before", "page-break-inside", "paint-order", "pause", "pause-after", "pause-before", "perspective", "perspective-origin", "place-content", "place-items", "place-self", "pointer-events", "position", "position-anchor", "position-visibility", "print-color-adjust", "quotes", "r", "resize", "rest", "rest-after", "rest-before", "right", "rotate", "row-gap", "ruby-align", "ruby-position", "scale", "scroll-behavior", "scroll-margin", "scroll-margin-block", "scroll-margin-block-end", "scroll-margin-block-start", "scroll-margin-bottom", "scroll-margin-inline", "scroll-margin-inline-end", "scroll-margin-inline-start", "scroll-margin-left", "scroll-margin-right", "scroll-margin-top", "scroll-padding", "scroll-padding-block", "scroll-padding-block-end", "scroll-padding-block-start", "scroll-padding-bottom", "scroll-padding-inline", "scroll-padding-inline-end", "scroll-padding-inline-start", "scroll-padding-left", "scroll-padding-right", "scroll-padding-top", "scroll-snap-align", "scroll-snap-stop", "scroll-snap-type", "scroll-timeline", "scroll-timeline-axis", "scroll-timeline-name", "scrollbar-color", "scrollbar-gutter", "scrollbar-width", "shape-image-threshold", "shape-margin", "shape-outside", "shape-rendering", "speak", "speak-as", "src", "stop-color", "stop-opacity", "stroke", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke-width", "tab-size", "table-layout", "text-align", "text-align-all", "text-align-last", "text-anchor", "text-combine-upright", "text-decoration", "text-decoration-color", "text-decoration-line", "text-decoration-skip", "text-decoration-skip-ink", "text-decoration-style", "text-decoration-thickness", "text-emphasis", "text-emphasis-color", "text-emphasis-position", "text-emphasis-style", "text-indent", "text-justify", "text-orientation", "text-overflow", "text-rendering", "text-shadow", "text-size-adjust", "text-transform", "text-underline-offset", "text-underline-position", "text-wrap", "text-wrap-mode", "text-wrap-style", "timeline-scope", "top", "touch-action", "transform", "transform-box", "transform-origin", "transform-style", "transition", "transition-behavior", "transition-delay", "transition-duration", "transition-property", "transition-timing-function", "translate", "unicode-bidi", "user-modify", "user-select", "vector-effect", "vertical-align", "view-timeline", "view-timeline-axis", "view-timeline-inset", "view-timeline-name", "view-transition-name", "visibility", "voice-balance", "voice-duration", "voice-family", "voice-pitch", "voice-range", "voice-rate", "voice-stress", "voice-volume", "white-space", "white-space-collapse", "widows", "width", "will-change", "word-break", "word-spacing", "word-wrap", "writing-mode", "x", "y", "z-index", "zoom"].sort().reverse();

function dn(e) {
    const t = dt(e),
        n = St,
        i = Et,
        a = "@[a-z-]+",
        u = "and or not only",
        o = {
            className: "variable",
            begin: "(\\$" + "[a-zA-Z-][a-zA-Z0-9_-]*" + ")\\b",
            relevance: 0
        };
    return {
        name: "SCSS",
        case_insensitive: !0,
        illegal: "[=/|']",
        contains: [e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, t.CSS_NUMBER_MODE, {
            className: "selector-id",
            begin: "#[A-Za-z0-9_-]+",
            relevance: 0
        }, {
            className: "selector-class",
            begin: "\\.[A-Za-z0-9_-]+",
            relevance: 0
        }, t.ATTRIBUTE_SELECTOR_MODE, {
            className: "selector-tag",
            begin: "\\b(" + pt.join("|") + ")\\b",
            relevance: 0
        }, {
            className: "selector-pseudo",
            begin: ":(" + i.join("|") + ")"
        }, {
            className: "selector-pseudo",
            begin: ":(:)?(" + n.join("|") + ")"
        }, o, {
            begin: /\(/,
            end: /\)/,
            contains: [t.CSS_NUMBER_MODE]
        }, t.CSS_VARIABLE, {
            className: "attribute",
            begin: "\\b(" + bt.join("|") + ")\\b"
        }, {
            begin: "\\b(whitespace|wait|w-resize|visible|vertical-text|vertical-ideographic|uppercase|upper-roman|upper-alpha|underline|transparent|top|thin|thick|text|text-top|text-bottom|tb-rl|table-header-group|table-footer-group|sw-resize|super|strict|static|square|solid|small-caps|separate|se-resize|scroll|s-resize|rtl|row-resize|ridge|right|repeat|repeat-y|repeat-x|relative|progress|pointer|overline|outside|outset|oblique|nowrap|not-allowed|normal|none|nw-resize|no-repeat|no-drop|newspaper|ne-resize|n-resize|move|middle|medium|ltr|lr-tb|lowercase|lower-roman|lower-alpha|loose|list-item|line|line-through|line-edge|lighter|left|keep-all|justify|italic|inter-word|inter-ideograph|inside|inset|inline|inline-block|inherit|inactive|ideograph-space|ideograph-parenthesis|ideograph-numeric|ideograph-alpha|horizontal|hidden|help|hand|groove|fixed|ellipsis|e-resize|double|dotted|distribute|distribute-space|distribute-letter|distribute-all-lines|disc|disabled|default|decimal|dashed|crosshair|collapse|col-resize|circle|char|center|capitalize|break-word|break-all|bottom|both|bolder|bold|block|bidi-override|below|baseline|auto|always|all-scroll|absolute|table|table-cell)\\b"
        }, {
            begin: /:/,
            end: /[;}{]/,
            relevance: 0,
            contains: [t.BLOCK_COMMENT, o, t.HEXCOLOR, t.CSS_NUMBER_MODE, e.QUOTE_STRING_MODE, e.APOS_STRING_MODE, t.IMPORTANT, t.FUNCTION_DISPATCH]
        }, {
            begin: "@(page|font-face)",
            keywords: {
                $pattern: a,
                keyword: "@page @font-face"
            }
        }, {
            begin: "@",
            end: "[{;]",
            returnBegin: !0,
            keywords: {
                $pattern: /[a-z-]+/,
                keyword: u,
                attribute: gt.join(" ")
            },
            contains: [{
                begin: a,
                className: "keyword"
            }, {
                begin: /[a-z-]+(?=:)/,
                className: "attribute"
            }, o, e.QUOTE_STRING_MODE, e.APOS_STRING_MODE, t.HEXCOLOR, t.CSS_NUMBER_MODE]
        }, t.FUNCTION_DISPATCH]
    }
}

function un(e) {
    return {
        name: "Shell Session",
        aliases: ["console", "shellsession"],
        contains: [{
            className: "meta.prompt",
            begin: /^\s{0,3}[/~\w\d[\]()@-]*[>%$#][ ]?/,
            starts: {
                end: /[^\\](?=\s*$)/,
                subLanguage: "bash"
            }
        }]
    }
}

function mn(e) {
    const t = e.regex,
        n = e.COMMENT("--", "$"),
        i = {
            scope: "string",
            variants: [{
                begin: /'/,
                end: /'/,
                contains: [{
                    match: /''/
                }]
            }]
        },
        a = {
            begin: /"/,
            end: /"/,
            contains: [{
                match: /""/
            }]
        },
        u = ["true", "false", "unknown"],
        s = ["double precision", "large object", "with timezone", "without timezone"],
        o = ["bigint", "binary", "blob", "boolean", "char", "character", "clob", "date", "dec", "decfloat", "decimal", "float", "int", "integer", "interval", "nchar", "nclob", "national", "numeric", "real", "row", "smallint", "time", "timestamp", "varchar", "varying", "varbinary"],
        c = ["add", "asc", "collation", "desc", "final", "first", "last", "view"],
        r = ["abs", "acos", "all", "allocate", "alter", "and", "any", "are", "array", "array_agg", "array_max_cardinality", "as", "asensitive", "asin", "asymmetric", "at", "atan", "atomic", "authorization", "avg", "begin", "begin_frame", "begin_partition", "between", "bigint", "binary", "blob", "boolean", "both", "by", "call", "called", "cardinality", "cascaded", "case", "cast", "ceil", "ceiling", "char", "char_length", "character", "character_length", "check", "classifier", "clob", "close", "coalesce", "collate", "collect", "column", "commit", "condition", "connect", "constraint", "contains", "convert", "copy", "corr", "corresponding", "cos", "cosh", "count", "covar_pop", "covar_samp", "create", "cross", "cube", "cume_dist", "current", "current_catalog", "current_date", "current_default_transform_group", "current_path", "current_role", "current_row", "current_schema", "current_time", "current_timestamp", "current_path", "current_role", "current_transform_group_for_type", "current_user", "cursor", "cycle", "date", "day", "deallocate", "dec", "decimal", "decfloat", "declare", "default", "define", "delete", "dense_rank", "deref", "describe", "deterministic", "disconnect", "distinct", "double", "drop", "dynamic", "each", "element", "else", "empty", "end", "end_frame", "end_partition", "end-exec", "equals", "escape", "every", "except", "exec", "execute", "exists", "exp", "external", "extract", "false", "fetch", "filter", "first_value", "float", "floor", "for", "foreign", "frame_row", "free", "from", "full", "function", "fusion", "get", "global", "grant", "group", "grouping", "groups", "having", "hold", "hour", "identity", "in", "indicator", "initial", "inner", "inout", "insensitive", "insert", "int", "integer", "intersect", "intersection", "interval", "into", "is", "join", "json_array", "json_arrayagg", "json_exists", "json_object", "json_objectagg", "json_query", "json_table", "json_table_primitive", "json_value", "lag", "language", "large", "last_value", "lateral", "lead", "leading", "left", "like", "like_regex", "listagg", "ln", "local", "localtime", "localtimestamp", "log", "log10", "lower", "match", "match_number", "match_recognize", "matches", "max", "member", "merge", "method", "min", "minute", "mod", "modifies", "module", "month", "multiset", "national", "natural", "nchar", "nclob", "new", "no", "none", "normalize", "not", "nth_value", "ntile", "null", "nullif", "numeric", "octet_length", "occurrences_regex", "of", "offset", "old", "omit", "on", "one", "only", "open", "or", "order", "out", "outer", "over", "overlaps", "overlay", "parameter", "partition", "pattern", "per", "percent", "percent_rank", "percentile_cont", "percentile_disc", "period", "portion", "position", "position_regex", "power", "precedes", "precision", "prepare", "primary", "procedure", "ptf", "range", "rank", "reads", "real", "recursive", "ref", "references", "referencing", "regr_avgx", "regr_avgy", "regr_count", "regr_intercept", "regr_r2", "regr_slope", "regr_sxx", "regr_sxy", "regr_syy", "release", "result", "return", "returns", "revoke", "right", "rollback", "rollup", "row", "row_number", "rows", "running", "savepoint", "scope", "scroll", "search", "second", "seek", "select", "sensitive", "session_user", "set", "show", "similar", "sin", "sinh", "skip", "smallint", "some", "specific", "specifictype", "sql", "sqlexception", "sqlstate", "sqlwarning", "sqrt", "start", "static", "stddev_pop", "stddev_samp", "submultiset", "subset", "substring", "substring_regex", "succeeds", "sum", "symmetric", "system", "system_time", "system_user", "table", "tablesample", "tan", "tanh", "then", "time", "timestamp", "timezone_hour", "timezone_minute", "to", "trailing", "translate", "translate_regex", "translation", "treat", "trigger", "trim", "trim_array", "true", "truncate", "uescape", "union", "unique", "unknown", "unnest", "update", "upper", "user", "using", "value", "values", "value_of", "var_pop", "var_samp", "varbinary", "varchar", "varying", "versioning", "when", "whenever", "where", "width_bucket", "window", "with", "within", "without", "year"],
        l = ["abs", "acos", "array_agg", "asin", "atan", "avg", "cast", "ceil", "ceiling", "coalesce", "corr", "cos", "cosh", "count", "covar_pop", "covar_samp", "cume_dist", "dense_rank", "deref", "element", "exp", "extract", "first_value", "floor", "json_array", "json_arrayagg", "json_exists", "json_object", "json_objectagg", "json_query", "json_table", "json_table_primitive", "json_value", "lag", "last_value", "lead", "listagg", "ln", "log", "log10", "lower", "max", "min", "mod", "nth_value", "ntile", "nullif", "percent_rank", "percentile_cont", "percentile_disc", "position", "position_regex", "power", "rank", "regr_avgx", "regr_avgy", "regr_count", "regr_intercept", "regr_r2", "regr_slope", "regr_sxx", "regr_sxy", "regr_syy", "row_number", "sin", "sinh", "sqrt", "stddev_pop", "stddev_samp", "substring", "substring_regex", "sum", "tan", "tanh", "translate", "translate_regex", "treat", "trim", "trim_array", "unnest", "upper", "value_of", "var_pop", "var_samp", "width_bucket"],
        p = ["current_catalog", "current_date", "current_default_transform_group", "current_path", "current_role", "current_schema", "current_transform_group_for_type", "current_user", "session_user", "system_time", "system_user", "current_time", "localtime", "current_timestamp", "localtimestamp"],
        d = ["create table", "insert into", "primary key", "foreign key", "not null", "alter table", "add constraint", "grouping sets", "on overflow", "character set", "respect nulls", "ignore nulls", "nulls first", "nulls last", "depth first", "breadth first"],
        m = l,
        b = [...r, ...c].filter(A => !l.includes(A)),
        g = {
            scope: "variable",
            match: /@[a-z0-9][a-z0-9_]*/
        },
        E = {
            scope: "operator",
            match: /[-+*/=%^~]|&&?|\|\|?|!=?|<(?:=>?|<|>)?|>[>=]?/,
            relevance: 0
        },
        S = {
            match: t.concat(/\b/, t.either(...m), /\s*\(/),
            relevance: 0,
            keywords: {
                built_in: m
            }
        };

    function N(A) {
        return t.concat(/\b/, t.either(...A.map(C => C.replace(/\s+/, "\\s+"))), /\b/)
    }
    const _ = {
        scope: "keyword",
        match: N(d),
        relevance: 0
    };

    function T(A, {
        exceptions: C,
        when: O
    } = {}) {
        const D = O;
        return C = C || [], A.map(L => L.match(/\|\d+$/) || C.includes(L) ? L : D(L) ? "".concat(L, "|0") : L)
    }
    return {
        name: "SQL",
        case_insensitive: !0,
        illegal: /[{}]|<\//,
        keywords: {
            $pattern: /\b[\w\.]+/,
            keyword: T(b, {
                when: A => A.length < 3
            }),
            literal: u,
            type: o,
            built_in: p
        },
        contains: [{
            scope: "type",
            match: N(s)
        }, _, S, g, i, a, e.C_NUMBER_MODE, e.C_BLOCK_COMMENT_MODE, n, E]
    }
}

function _e(e) {
    return e ? typeof e == "string" ? e : e.source : null
}

function Q(e) {
    return I("(?=", e, ")")
}

function I(...e) {
    return e.map(n => _e(n)).join("")
}

function Tt(e) {
    const t = e[e.length - 1];
    return typeof t == "object" && t.constructor === Object ? (e.splice(e.length - 1, 1), t) : {}
}

function F(...e) {
    return "(" + (Tt(e).capture ? "" : "?:") + e.map(i => _e(i)).join("|") + ")"
}
const oe = e => I(/\b/, e, /\w$/.test(e) ? /\b/ : /\B/),
    _t = ["Protocol", "Type"].map(oe),
    de = ["init", "self"].map(oe),
    Ct = ["Any", "Self"],
    ie = ["actor", "any", "associatedtype", "async", "await", /as\?/, /as!/, "as", "borrowing", "break", "case", "catch", "class", "consume", "consuming", "continue", "convenience", "copy", "default", "defer", "deinit", "didSet", "distributed", "do", "dynamic", "each", "else", "enum", "extension", "fallthrough", /fileprivate\(set\)/, "fileprivate", "final", "for", "func", "get", "guard", "if", "import", "indirect", "infix", /init\?/, /init!/, "inout", /internal\(set\)/, "internal", "in", "is", "isolated", "nonisolated", "lazy", "let", "macro", "mutating", "nonmutating", /open\(set\)/, "open", "operator", "optional", "override", "package", "postfix", "precedencegroup", "prefix", /private\(set\)/, "private", "protocol", /public\(set\)/, "public", "repeat", "required", "rethrows", "return", "set", "some", "static", "struct", "subscript", "super", "switch", "throws", "throw", /try\?/, /try!/, "try", "typealias", /unowned\(safe\)/, /unowned\(unsafe\)/, "unowned", "var", "weak", "where", "while", "willSet"],
    ue = ["false", "nil", "true"],
    Nt = ["assignment", "associativity", "higherThan", "left", "lowerThan", "none", "right"],
    At = ["#colorLiteral", "#column", "#dsohandle", "#else", "#elseif", "#endif", "#error", "#file", "#fileID", "#fileLiteral", "#filePath", "#function", "#if", "#imageLiteral", "#keyPath", "#line", "#selector", "#sourceLocation", "#warning"],
    me = ["abs", "all", "any", "assert", "assertionFailure", "debugPrint", "dump", "fatalError", "getVaList", "isKnownUniquelyReferenced", "max", "min", "numericCast", "pointwiseMax", "pointwiseMin", "precondition", "preconditionFailure", "print", "readLine", "repeatElement", "sequence", "stride", "swap", "swift_unboxFromSwiftValueWithType", "transcode", "type", "unsafeBitCast", "unsafeDowncast", "withExtendedLifetime", "withUnsafeMutablePointer", "withUnsafePointer", "withVaList", "withoutActuallyEscaping", "zip"],
    Ce = F(/[/=\-+!*%<>&|^~?]/, /[\u00A1-\u00A7]/, /[\u00A9\u00AB]/, /[\u00AC\u00AE]/, /[\u00B0\u00B1]/, /[\u00B6\u00BB\u00BF\u00D7\u00F7]/, /[\u2016-\u2017]/, /[\u2020-\u2027]/, /[\u2030-\u203E]/, /[\u2041-\u2053]/, /[\u2055-\u205E]/, /[\u2190-\u23FF]/, /[\u2500-\u2775]/, /[\u2794-\u2BFF]/, /[\u2E00-\u2E7F]/, /[\u3001-\u3003]/, /[\u3008-\u3020]/, /[\u3030]/),
    Ne = F(Ce, /[\u0300-\u036F]/, /[\u1DC0-\u1DFF]/, /[\u20D0-\u20FF]/, /[\uFE00-\uFE0F]/, /[\uFE20-\uFE2F]/),
    ae = I(Ce, Ne, "*"),
    Ae = F(/[a-zA-Z_]/, /[\u00A8\u00AA\u00AD\u00AF\u00B2-\u00B5\u00B7-\u00BA]/, /[\u00BC-\u00BE\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u00FF]/, /[\u0100-\u02FF\u0370-\u167F\u1681-\u180D\u180F-\u1DBF]/, /[\u1E00-\u1FFF]/, /[\u200B-\u200D\u202A-\u202E\u203F-\u2040\u2054\u2060-\u206F]/, /[\u2070-\u20CF\u2100-\u218F\u2460-\u24FF\u2776-\u2793]/, /[\u2C00-\u2DFF\u2E80-\u2FFF]/, /[\u3004-\u3007\u3021-\u302F\u3031-\u303F\u3040-\uD7FF]/, /[\uF900-\uFD3D\uFD40-\uFDCF\uFDF0-\uFE1F\uFE30-\uFE44]/, /[\uFE47-\uFEFE\uFF00-\uFFFD]/),
    ee = F(Ae, /\d/, /[\u0300-\u036F\u1DC0-\u1DFF\u20D0-\u20FF\uFE20-\uFE2F]/),
    U = I(Ae, ee, "*"),
    j = I(/[A-Z]/, ee, "*"),
    Rt = ["attached", "autoclosure", I(/convention\(/, F("swift", "block", "c"), /\)/), "discardableResult", "dynamicCallable", "dynamicMemberLookup", "escaping", "freestanding", "frozen", "GKInspectable", "IBAction", "IBDesignable", "IBInspectable", "IBOutlet", "IBSegueAction", "inlinable", "main", "nonobjc", "NSApplicationMain", "NSCopying", "NSManaged", I(/objc\(/, U, /\)/), "objc", "objcMembers", "propertyWrapper", "requires_stored_property_inits", "resultBuilder", "Sendable", "testable", "UIApplicationMain", "unchecked", "unknown", "usableFromInline", "warn_unqualified_access"],
    Dt = ["iOS", "iOSApplicationExtension", "macOS", "macOSApplicationExtension", "macCatalyst", "macCatalystApplicationExtension", "watchOS", "watchOSApplicationExtension", "tvOS", "tvOSApplicationExtension", "swift"];

function pn(e) {
    const t = {
            match: /\s+/,
            relevance: 0
        },
        n = e.COMMENT("/\\*", "\\*/", {
            contains: ["self"]
        }),
        i = [e.C_LINE_COMMENT_MODE, n],
        a = {
            match: [/\./, F(..._t, ...de)],
            className: {
                2: "keyword"
            }
        },
        u = {
            match: I(/\./, F(...ie)),
            relevance: 0
        },
        s = ie.filter(h => typeof h == "string").concat(["_|0"]),
        o = ie.filter(h => typeof h != "string").concat(Ct).map(oe),
        c = {
            variants: [{
                className: "keyword",
                match: F(...o, ...de)
            }]
        },
        r = {
            $pattern: F(/\b\w+/, /#\w+/),
            keyword: s.concat(At),
            literal: ue
        },
        l = [a, u, c],
        p = {
            match: I(/\./, F(...me)),
            relevance: 0
        },
        d = {
            className: "built_in",
            match: I(/\b/, F(...me), /(?=\()/)
        },
        m = [p, d],
        b = {
            match: /->/,
            relevance: 0
        },
        g = {
            className: "operator",
            relevance: 0,
            variants: [{
                match: ae
            }, {
                match: "\\.(\\.|".concat(Ne, ")+")
            }]
        },
        E = [b, g],
        S = "([0-9]_*)+",
        N = "([0-9a-fA-F]_*)+",
        _ = {
            className: "number",
            relevance: 0,
            variants: [{
                match: "\\b(".concat(S, ")(\\.(").concat(S, "))?") + "([eE][+-]?(".concat(S, "))?\\b")
            }, {
                match: "\\b0x(".concat(N, ")(\\.(").concat(N, "))?") + "([pP][+-]?(".concat(S, "))?\\b")
            }, {
                match: /\b0o([0-7]_*)+\b/
            }, {
                match: /\b0b([01]_*)+\b/
            }]
        },
        T = (h = "") => ({
            className: "subst",
            variants: [{
                match: I(/\\/, h, /[0\\tnr"']/)
            }, {
                match: I(/\\/, h, /u\{[0-9a-fA-F]{1,8}\}/)
            }]
        }),
        A = (h = "") => ({
            className: "subst",
            match: I(/\\/, h, /[\t ]*(?:[\r\n]|\r\n)/)
        }),
        C = (h = "") => ({
            className: "subst",
            label: "interpol",
            begin: I(/\\/, h, /\(/),
            end: /\)/
        }),
        O = (h = "") => ({
            begin: I(h, /"""/),
            end: I(/"""/, h),
            contains: [T(h), A(h), C(h)]
        }),
        D = (h = "") => ({
            begin: I(h, /"/),
            end: I(/"/, h),
            contains: [T(h), C(h)]
        }),
        L = {
            className: "string",
            variants: [O(), O("#"), O("##"), O("###"), D(), D("#"), D("##"), D("###")]
        },
        R = [e.BACKSLASH_ESCAPE, {
            begin: /\[/,
            end: /\]/,
            relevance: 0,
            contains: [e.BACKSLASH_ESCAPE]
        }],
        f = {
            begin: /\/[^\s](?=[^/\n]*\/)/,
            end: /\//,
            contains: R
        },
        G = h => {
            const q = I(h, /\//),
                K = I(/\//, h);
            return {
                begin: q,
                end: K,
                contains: [...R, {
                    scope: "comment",
                    begin: "#(?!.*".concat(K, ")"),
                    end: /$/
                }]
            }
        },
        V = {
            scope: "regexp",
            variants: [G("###"), G("##"), G("#"), f]
        },
        P = {
            match: I(/`/, U, /`/)
        },
        M = {
            className: "variable",
            match: /\$\d+/
        },
        k = {
            className: "variable",
            match: "\\$".concat(ee, "+")
        },
        H = [P, M, k],
        y = {
            match: /(@|#(un)?)available/,
            scope: "keyword",
            starts: {
                contains: [{
                    begin: /\(/,
                    end: /\)/,
                    keywords: Dt,
                    contains: [...E, _, L]
                }]
            }
        },
        v = {
            scope: "keyword",
            match: I(/@/, F(...Rt), Q(F(/\(/, /\s+/)))
        },
        w = {
            scope: "meta",
            match: I(/@/, U)
        },
        B = [y, v, w],
        x = {
            match: Q(/\b[A-Z]/),
            relevance: 0,
            contains: [{
                className: "type",
                match: I(/(AV|CA|CF|CG|CI|CL|CM|CN|CT|MK|MP|MTK|MTL|NS|SCN|SK|UI|WK|XC)/, ee, "+")
            }, {
                className: "type",
                match: j,
                relevance: 0
            }, {
                match: /[?!]+/,
                relevance: 0
            }, {
                match: /\.\.\./,
                relevance: 0
            }, {
                match: I(/\s+&\s+/, Q(j)),
                relevance: 0
            }]
        },
        $ = {
            begin: /</,
            end: />/,
            keywords: r,
            contains: [...i, ...l, ...B, b, x]
        };
    x.contains.push($);
    const fe = {
            match: I(U, /\s*:/),
            keywords: "_|0",
            relevance: 0
        },
        re = {
            begin: /\(/,
            end: /\)/,
            relevance: 0,
            keywords: r,
            contains: ["self", fe, ...i, V, ...l, ...m, ...E, _, L, ...H, ...B, x]
        },
        ne = {
            begin: /</,
            end: />/,
            keywords: "repeat each",
            contains: [...i, x]
        },
        Me = {
            begin: F(Q(I(U, /\s*:/)), Q(I(U, /\s+/, U, /\s*:/))),
            end: /:/,
            relevance: 0,
            contains: [{
                className: "keyword",
                match: /\b_\b/
            }, {
                className: "params",
                match: U
            }]
        },
        se = {
            begin: /\(/,
            end: /\)/,
            keywords: r,
            contains: [Me, ...i, ...l, ...E, _, L, ...B, x, re],
            endsParent: !0,
            illegal: /["']/
        },
        Pe = {
            match: [/(func|macro)/, /\s+/, F(P.match, U, ae)],
            className: {
                1: "keyword",
                3: "title.function"
            },
            contains: [ne, se, t],
            illegal: [/\[/, /%/]
        },
        ve = {
            match: [/\b(?:subscript|init[?!]?)/, /\s*(?=[<(])/],
            className: {
                1: "keyword"
            },
            contains: [ne, se, t],
            illegal: /\[|%/
        },
        xe = {
            match: [/operator/, /\s+/, ae],
            className: {
                1: "keyword",
                3: "title"
            }
        },
        Fe = {
            begin: [/precedencegroup/, /\s+/, j],
            className: {
                1: "keyword",
                3: "title"
            },
            contains: [x],
            keywords: [...Nt, ...ue],
            end: /}/
        },
        Be = {
            match: [/class\b/, /\s+/, /func\b/, /\s+/, /\b[A-Za-z_][A-Za-z0-9_]*\b/],
            scope: {
                1: "keyword",
                3: "keyword",
                5: "title.function"
            }
        },
        ke = {
            match: [/class\b/, /\s+/, /var\b/],
            scope: {
                1: "keyword",
                3: "keyword"
            }
        },
        we = {
            begin: [/(struct|protocol|class|extension|enum|actor)/, /\s+/, U, /\s*/],
            beginScope: {
                1: "keyword",
                3: "title.class"
            },
            keywords: r,
            contains: [ne, ...l, {
                begin: /:/,
                end: /\{/,
                keywords: r,
                contains: [{
                    scope: "title.class.inherited",
                    match: j
                }, ...l],
                relevance: 0
            }]
        };
    for (const h of L.variants) {
        const q = h.contains.find(Ge => Ge.label === "interpol");
        q.keywords = r;
        const K = [...l, ...m, ...E, _, L, ...H];
        q.contains = [...K, {
            begin: /\(/,
            end: /\)/,
            contains: ["self", ...K]
        }]
    }
    return {
        name: "Swift",
        keywords: r,
        contains: [...i, Pe, ve, Be, ke, we, xe, Fe, {
            beginKeywords: "import",
            end: /$/,
            contains: [...i],
            relevance: 0
        }, V, ...l, ...m, ...E, _, L, ...H, ...B, x, re]
    }
}
const te = "[A-Za-z$_][0-9A-Za-z$_]*",
    Re = ["as", "in", "of", "if", "for", "while", "finally", "var", "new", "function", "do", "return", "void", "else", "break", "catch", "instanceof", "with", "throw", "case", "default", "try", "switch", "continue", "typeof", "delete", "let", "yield", "const", "class", "debugger", "async", "await", "static", "import", "from", "export", "extends", "using"],
    De = ["true", "false", "null", "undefined", "NaN", "Infinity"],
    Ie = ["Object", "Function", "Boolean", "Symbol", "Math", "Date", "Number", "BigInt", "String", "RegExp", "Array", "Float32Array", "Float64Array", "Int8Array", "Uint8Array", "Uint8ClampedArray", "Int16Array", "Int32Array", "Uint16Array", "Uint32Array", "BigInt64Array", "BigUint64Array", "Set", "Map", "WeakSet", "WeakMap", "ArrayBuffer", "SharedArrayBuffer", "Atomics", "DataView", "JSON", "Promise", "Generator", "GeneratorFunction", "AsyncFunction", "Reflect", "Proxy", "Intl", "WebAssembly"],
    ye = ["Error", "EvalError", "InternalError", "RangeError", "ReferenceError", "SyntaxError", "TypeError", "URIError"],
    he = ["setInterval", "setTimeout", "clearInterval", "clearTimeout", "require", "exports", "eval", "isFinite", "isNaN", "parseFloat", "parseInt", "decodeURI", "decodeURIComponent", "encodeURI", "encodeURIComponent", "escape", "unescape"],
    Oe = ["arguments", "this", "super", "console", "window", "document", "localStorage", "sessionStorage", "module", "global"],
    Le = [].concat(he, Ie, ye);

function It(e) {
    const t = e.regex,
        n = (y, {
            after: v
        }) => {
            const w = "</" + y[0].slice(1);
            return y.input.indexOf(w, v) !== -1
        },
        i = te,
        a = {
            begin: "<>",
            end: "</>"
        },
        u = /<[A-Za-z0-9\\._:-]+\s*\/>/,
        s = {
            begin: /<[A-Za-z0-9\\._:-]+/,
            end: /\/[A-Za-z0-9\\._:-]+>|\/>/,
            isTrulyOpeningTag: (y, v) => {
                const w = y[0].length + y.index,
                    B = y.input[w];
                if (B === "<" || B === ",") {
                    v.ignoreMatch();
                    return
                }
                B === ">" && (n(y, {
                    after: w
                }) || v.ignoreMatch());
                let x;
                const $ = y.input.substring(w);
                if (x = $.match(/^\s*=/)) {
                    v.ignoreMatch();
                    return
                }
                if ((x = $.match(/^\s+extends\s+/)) && x.index === 0) {
                    v.ignoreMatch();
                    return
                }
            }
        },
        o = {
            $pattern: te,
            keyword: Re,
            literal: De,
            built_in: Le,
            "variable.language": Oe
        },
        c = "[0-9](_?[0-9])*",
        r = "\\.(".concat(c, ")"),
        l = "0|[1-9](_?[0-9])*|0[0-7]*[89][0-9]*",
        p = {
            className: "number",
            variants: [{
                begin: "(\\b(".concat(l, ")((").concat(r, ")|\\.)?|(").concat(r, "))") + "[eE][+-]?(".concat(c, ")\\b")
            }, {
                begin: "\\b(".concat(l, ")\\b((").concat(r, ")\\b|\\.)?|(").concat(r, ")\\b")
            }, {
                begin: "\\b(0|[1-9](_?[0-9])*)n\\b"
            }, {
                begin: "\\b0[xX][0-9a-fA-F](_?[0-9a-fA-F])*n?\\b"
            }, {
                begin: "\\b0[bB][0-1](_?[0-1])*n?\\b"
            }, {
                begin: "\\b0[oO][0-7](_?[0-7])*n?\\b"
            }, {
                begin: "\\b0[0-7]+n?\\b"
            }],
            relevance: 0
        },
        d = {
            className: "subst",
            begin: "\\$\\{",
            end: "\\}",
            keywords: o,
            contains: []
        },
        m = {
            begin: ".?html`",
            end: "",
            starts: {
                end: "`",
                returnEnd: !1,
                contains: [e.BACKSLASH_ESCAPE, d],
                subLanguage: "xml"
            }
        },
        b = {
            begin: ".?css`",
            end: "",
            starts: {
                end: "`",
                returnEnd: !1,
                contains: [e.BACKSLASH_ESCAPE, d],
                subLanguage: "css"
            }
        },
        g = {
            begin: ".?gql`",
            end: "",
            starts: {
                end: "`",
                returnEnd: !1,
                contains: [e.BACKSLASH_ESCAPE, d],
                subLanguage: "graphql"
            }
        },
        E = {
            className: "string",
            begin: "`",
            end: "`",
            contains: [e.BACKSLASH_ESCAPE, d]
        },
        N = {
            className: "comment",
            variants: [e.COMMENT(/\/\*\*(?!\/)/, "\\*/", {
                relevance: 0,
                contains: [{
                    begin: "(?=@[A-Za-z]+)",
                    relevance: 0,
                    contains: [{
                        className: "doctag",
                        begin: "@[A-Za-z]+"
                    }, {
                        className: "type",
                        begin: "\\{",
                        end: "\\}",
                        excludeEnd: !0,
                        excludeBegin: !0,
                        relevance: 0
                    }, {
                        className: "variable",
                        begin: i + "(?=\\s*(-)|$)",
                        endsParent: !0,
                        relevance: 0
                    }, {
                        begin: /(?=[^\n])\s/,
                        relevance: 0
                    }]
                }]
            }), e.C_BLOCK_COMMENT_MODE, e.C_LINE_COMMENT_MODE]
        },
        _ = [e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, m, b, g, E, {
            match: /\$\d+/
        }, p];
    d.contains = _.concat({
        begin: /\{/,
        end: /\}/,
        keywords: o,
        contains: ["self"].concat(_)
    });
    const T = [].concat(N, d.contains),
        A = T.concat([{
            begin: /(\s*)\(/,
            end: /\)/,
            keywords: o,
            contains: ["self"].concat(T)
        }]),
        C = {
            className: "params",
            begin: /(\s*)\(/,
            end: /\)/,
            excludeBegin: !0,
            excludeEnd: !0,
            keywords: o,
            contains: A
        },
        O = {
            variants: [{
                match: [/class/, /\s+/, i, /\s+/, /extends/, /\s+/, t.concat(i, "(", t.concat(/\./, i), ")*")],
                scope: {
                    1: "keyword",
                    3: "title.class",
                    5: "keyword",
                    7: "title.class.inherited"
                }
            }, {
                match: [/class/, /\s+/, i],
                scope: {
                    1: "keyword",
                    3: "title.class"
                }
            }]
        },
        D = {
            relevance: 0,
            match: t.either(/\bJSON/, /\b[A-Z][a-z]+([A-Z][a-z]*|\d)*/, /\b[A-Z]{2,}([A-Z][a-z]+|\d)+([A-Z][a-z]*)*/, /\b[A-Z]{2,}[a-z]+([A-Z][a-z]+|\d)*([A-Z][a-z]*)*/),
            className: "title.class",
            keywords: {
                _: [...Ie, ...ye]
            }
        },
        L = {
            label: "use_strict",
            className: "meta",
            relevance: 10,
            begin: /^\s*['"]use (strict|asm)['"]/
        },
        R = {
            variants: [{
                match: [/function/, /\s+/, i, /(?=\s*\()/]
            }, {
                match: [/function/, /\s*(?=\()/]
            }],
            className: {
                1: "keyword",
                3: "title.function"
            },
            label: "func.def",
            contains: [C],
            illegal: /%/
        },
        f = {
            relevance: 0,
            match: /\b[A-Z][A-Z_0-9]+\b/,
            className: "variable.constant"
        };

    function G(y) {
        return t.concat("(?!", y.join("|"), ")")
    }
    const V = {
            match: t.concat(/\b/, G([...he, "super", "import"].map(y => "".concat(y, "\\s*\\("))), i, t.lookahead(/\s*\(/)),
            className: "title.function",
            relevance: 0
        },
        P = {
            begin: t.concat(/\./, t.lookahead(t.concat(i, /(?![0-9A-Za-z$_(])/))),
            end: i,
            excludeBegin: !0,
            keywords: "prototype",
            className: "property",
            relevance: 0
        },
        M = {
            match: [/get|set/, /\s+/, i, /(?=\()/],
            className: {
                1: "keyword",
                3: "title.function"
            },
            contains: [{
                begin: /\(\)/
            }, C]
        },
        k = "(\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)|" + e.UNDERSCORE_IDENT_RE + ")\\s*=>",
        H = {
            match: [/const|var|let/, /\s+/, i, /\s*/, /=\s*/, /(async\s*)?/, t.lookahead(k)],
            keywords: "async",
            className: {
                1: "keyword",
                3: "title.function"
            },
            contains: [C]
        };
    return {
        name: "JavaScript",
        aliases: ["js", "jsx", "mjs", "cjs"],
        keywords: o,
        exports: {
            PARAMS_CONTAINS: A,
            CLASS_REFERENCE: D
        },
        illegal: /#(?![$_A-z])/,
        contains: [e.SHEBANG({
            label: "shebang",
            binary: "node",
            relevance: 5
        }), L, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, m, b, g, E, N, {
            match: /\$\d+/
        }, p, D, {
            scope: "attr",
            match: i + t.lookahead(":"),
            relevance: 0
        }, H, {
            begin: "(" + e.RE_STARTERS_RE + "|\\b(case|return|throw)\\b)\\s*",
            keywords: "return throw case",
            relevance: 0,
            contains: [N, e.REGEXP_MODE, {
                className: "function",
                begin: k,
                returnBegin: !0,
                end: "\\s*=>",
                contains: [{
                    className: "params",
                    variants: [{
                        begin: e.UNDERSCORE_IDENT_RE,
                        relevance: 0
                    }, {
                        className: null,
                        begin: /\(\s*\)/,
                        skip: !0
                    }, {
                        begin: /(\s*)\(/,
                        end: /\)/,
                        excludeBegin: !0,
                        excludeEnd: !0,
                        keywords: o,
                        contains: A
                    }]
                }]
            }, {
                begin: /,/,
                relevance: 0
            }, {
                match: /\s+/,
                relevance: 0
            }, {
                variants: [{
                    begin: a.begin,
                    end: a.end
                }, {
                    match: u
                }, {
                    begin: s.begin,
                    "on:begin": s.isTrulyOpeningTag,
                    end: s.end
                }],
                subLanguage: "xml",
                contains: [{
                    begin: s.begin,
                    end: s.end,
                    skip: !0,
                    contains: ["self"]
                }]
            }]
        }, R, {
            beginKeywords: "while if switch catch for"
        }, {
            begin: "\\b(?!function)" + e.UNDERSCORE_IDENT_RE + "\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)\\s*\\{",
            returnBegin: !0,
            label: "func.def",
            contains: [C, e.inherit(e.TITLE_MODE, {
                begin: i,
                className: "title.function"
            })]
        }, {
            match: /\.\.\./,
            relevance: 0
        }, P, {
            match: "\\$" + i,
            relevance: 0
        }, {
            match: [/\bconstructor(?=\s*\()/],
            className: {
                1: "title.function"
            },
            contains: [C]
        }, V, f, O, M, {
            match: /\$[(.]/
        }]
    }
}

function gn(e) {
    const t = e.regex,
        n = It(e),
        i = te,
        a = ["any", "void", "number", "boolean", "string", "object", "never", "symbol", "bigint", "unknown"],
        u = {
            begin: [/namespace/, /\s+/, e.IDENT_RE],
            beginScope: {
                1: "keyword",
                3: "title.class"
            }
        },
        s = {
            beginKeywords: "interface",
            end: /\{/,
            excludeEnd: !0,
            keywords: {
                keyword: "interface extends",
                built_in: a
            },
            contains: [n.exports.CLASS_REFERENCE]
        },
        o = {
            className: "meta",
            relevance: 10,
            begin: /^\s*['"]use strict['"]/
        },
        c = ["type", "interface", "public", "private", "protected", "implements", "declare", "abstract", "readonly", "enum", "override", "satisfies"],
        r = {
            $pattern: te,
            keyword: Re.concat(c),
            literal: De,
            built_in: Le.concat(a),
            "variable.language": Oe
        },
        l = {
            className: "meta",
            begin: "@" + i
        },
        p = (g, E, S) => {
            const N = g.contains.findIndex(_ => _.label === E);
            if (N === -1) throw new Error("can not find mode to replace");
            g.contains.splice(N, 1, S)
        };
    Object.assign(n.keywords, r), n.exports.PARAMS_CONTAINS.push(l);
    const d = n.contains.find(g => g.scope === "attr"),
        m = Object.assign({}, d, {
            match: t.concat(i, t.lookahead(/\s*\?:/))
        });
    n.exports.PARAMS_CONTAINS.push([n.exports.CLASS_REFERENCE, d, m]), n.contains = n.contains.concat([l, u, s, m]), p(n, "shebang", e.SHEBANG()), p(n, "use_strict", o);
    const b = n.contains.find(g => g.label === "func.def");
    return b.relevance = 0, Object.assign(n, {
        name: "TypeScript",
        aliases: ["ts", "tsx", "mts", "cts"]
    }), n
}

function En(e) {
    const t = e.regex,
        n = {
            className: "string",
            begin: /"(""|[^/n])"C\b/
        },
        i = {
            className: "string",
            begin: /"/,
            end: /"/,
            illegal: /\n/,
            contains: [{
                begin: /""/
            }]
        },
        a = /\d{1,2}\/\d{1,2}\/\d{4}/,
        u = /\d{4}-\d{1,2}-\d{1,2}/,
        s = /(\d|1[012])(:\d+){0,2} *(AM|PM)/,
        o = /\d{1,2}(:\d{1,2}){1,2}/,
        c = {
            className: "literal",
            variants: [{
                begin: t.concat(/# */, t.either(u, a), / *#/)
            }, {
                begin: t.concat(/# */, o, / *#/)
            }, {
                begin: t.concat(/# */, s, / *#/)
            }, {
                begin: t.concat(/# */, t.either(u, a), / +/, t.either(s, o), / *#/)
            }]
        },
        r = {
            className: "number",
            relevance: 0,
            variants: [{
                begin: /\b\d[\d_]*((\.[\d_]+(E[+-]?[\d_]+)?)|(E[+-]?[\d_]+))[RFD@!#]?/
            }, {
                begin: /\b\d[\d_]*((U?[SIL])|[%&])?/
            }, {
                begin: /&H[\dA-F_]+((U?[SIL])|[%&])?/
            }, {
                begin: /&O[0-7_]+((U?[SIL])|[%&])?/
            }, {
                begin: /&B[01_]+((U?[SIL])|[%&])?/
            }]
        },
        l = {
            className: "label",
            begin: /^\w+:/
        },
        p = e.COMMENT(/'''/, /$/, {
            contains: [{
                className: "doctag",
                begin: /<\/?/,
                end: />/
            }]
        }),
        d = e.COMMENT(null, /$/, {
            variants: [{
                begin: /'/
            }, {
                begin: /([\t ]|^)REM(?=\s)/
            }]
        });
    return {
        name: "Visual Basic .NET",
        aliases: ["vb"],
        case_insensitive: !0,
        classNameAliases: {
            label: "symbol"
        },
        keywords: {
            keyword: "addhandler alias aggregate ansi as async assembly auto binary by byref byval call case catch class compare const continue custom declare default delegate dim distinct do each equals else elseif end enum erase error event exit explicit finally for friend from function get global goto group handles if implements imports in inherits interface into iterator join key let lib loop me mid module mustinherit mustoverride mybase myclass namespace narrowing new next notinheritable notoverridable of off on operator option optional order overloads overridable overrides paramarray partial preserve private property protected public raiseevent readonly redim removehandler resume return select set shadows shared skip static step stop structure strict sub synclock take text then throw to try unicode until using when where while widening with withevents writeonly yield",
            built_in: "addressof and andalso await directcast gettype getxmlnamespace is isfalse isnot istrue like mod nameof new not or orelse trycast typeof xor cbool cbyte cchar cdate cdbl cdec cint clng cobj csbyte cshort csng cstr cuint culng cushort",
            type: "boolean byte char date decimal double integer long object sbyte short single string uinteger ulong ushort",
            literal: "true false nothing"
        },
        illegal: "//|\\{|\\}|endif|gosub|variant|wend|^\\$ ",
        contains: [n, i, c, r, l, p, d, {
            className: "meta",
            begin: /[\t ]*#(const|disable|else|elseif|enable|end|externalsource|if|region)\b/,
            end: /$/,
            keywords: {
                keyword: "const disable else elseif enable end externalsource if region then"
            },
            contains: [d]
        }]
    }
}

function Sn(e) {
    e.regex;
    const t = e.COMMENT(/\(;/, /;\)/);
    t.contains.push("self");
    const n = e.COMMENT(/;;/, /$/),
        i = ["anyfunc", "block", "br", "br_if", "br_table", "call", "call_indirect", "data", "drop", "elem", "else", "end", "export", "func", "global.get", "global.set", "local.get", "local.set", "local.tee", "get_global", "get_local", "global", "if", "import", "local", "loop", "memory", "memory.grow", "memory.size", "module", "mut", "nop", "offset", "param", "result", "return", "select", "set_global", "set_local", "start", "table", "tee_local", "then", "type", "unreachable"],
        a = {
            begin: [/(?:func|call|call_indirect)/, /\s+/, /\$[^\s)]+/],
            className: {
                1: "keyword",
                3: "title.function"
            }
        },
        u = {
            className: "variable",
            begin: /\$[\w_]+/
        },
        s = {
            match: /(\((?!;)|\))+/,
            className: "punctuation",
            relevance: 0
        },
        o = {
            className: "number",
            relevance: 0,
            match: /[+-]?\b(?:\d(?:_?\d)*(?:\.\d(?:_?\d)*)?(?:[eE][+-]?\d(?:_?\d)*)?|0x[\da-fA-F](?:_?[\da-fA-F])*(?:\.[\da-fA-F](?:_?[\da-fA-D])*)?(?:[pP][+-]?\d(?:_?\d)*)?)\b|\binf\b|\bnan(?::0x[\da-fA-F](?:_?[\da-fA-D])*)?\b/
        },
        c = {
            match: /(i32|i64|f32|f64)(?!\.)/,
            className: "type"
        },
        r = {
            className: "keyword",
            match: /\b(f32|f64|i32|i64)(?:\.(?:abs|add|and|ceil|clz|const|convert_[su]\/i(?:32|64)|copysign|ctz|demote\/f64|div(?:_[su])?|eqz?|extend_[su]\/i32|floor|ge(?:_[su])?|gt(?:_[su])?|le(?:_[su])?|load(?:(?:8|16|32)_[su])?|lt(?:_[su])?|max|min|mul|nearest|neg?|or|popcnt|promote\/f32|reinterpret\/[fi](?:32|64)|rem_[su]|rot[lr]|shl|shr_[su]|store(?:8|16|32)?|sqrt|sub|trunc(?:_[su]\/f(?:32|64))?|wrap\/i64|xor))\b/
        };
    return {
        name: "WebAssembly",
        keywords: {
            $pattern: /[\w.]+/,
            keyword: i
        },
        contains: [n, t, {
            match: [/(?:offset|align)/, /\s*/, /=/],
            className: {
                1: "keyword",
                3: "operator"
            }
        }, u, s, a, e.QUOTE_STRING_MODE, c, r, o]
    }
}

function bn(e) {
    const t = e.regex,
        n = t.concat(new RegExp("[\\p{L}_]", "u"), t.optional(new RegExp("[\\p{L}0-9_.-]*:", "u")), new RegExp("[\\p{L}0-9_.-]*", "u")),
        i = new RegExp("[\\p{L}0-9._:-]+", "u"),
        a = {
            className: "symbol",
            begin: /&[a-z]+;|&#[0-9]+;|&#x[a-f0-9]+;/
        },
        u = {
            begin: /\s/,
            contains: [{
                className: "keyword",
                begin: /#?[a-z_][a-z1-9_-]+/,
                illegal: /\n/
            }]
        },
        s = e.inherit(u, {
            begin: /\(/,
            end: /\)/
        }),
        o = e.inherit(e.APOS_STRING_MODE, {
            className: "string"
        }),
        c = e.inherit(e.QUOTE_STRING_MODE, {
            className: "string"
        }),
        r = {
            endsWithParent: !0,
            illegal: /</,
            relevance: 0,
            contains: [{
                className: "attr",
                begin: i,
                relevance: 0
            }, {
                begin: /=\s*/,
                relevance: 0,
                contains: [{
                    className: "string",
                    endsParent: !0,
                    variants: [{
                        begin: /"/,
                        end: /"/,
                        contains: [a]
                    }, {
                        begin: /'/,
                        end: /'/,
                        contains: [a]
                    }, {
                        begin: /[^\s"'=<>`]+/
                    }]
                }]
            }]
        };
    return {
        name: "HTML, XML",
        aliases: ["html", "xhtml", "rss", "atom", "xjb", "xsd", "xsl", "plist", "wsf", "svg"],
        case_insensitive: !0,
        unicodeRegex: !0,
        contains: [{
            className: "meta",
            begin: /<![a-z]/,
            end: />/,
            relevance: 10,
            contains: [u, c, o, s, {
                begin: /\[/,
                end: /\]/,
                contains: [{
                    className: "meta",
                    begin: /<![a-z]/,
                    end: />/,
                    contains: [u, s, c, o]
                }]
            }]
        }, e.COMMENT(/<!--/, /-->/, {
            relevance: 10
        }), {
            begin: /<!\[CDATA\[/,
            end: /\]\]>/,
            relevance: 10
        }, a, {
            className: "meta",
            end: /\?>/,
            variants: [{
                begin: /<\?xml/,
                relevance: 10,
                contains: [c]
            }, {
                begin: /<\?[a-z][a-z0-9]+/
            }]
        }, {
            className: "tag",
            begin: /<style(?=\s|>)/,
            end: />/,
            keywords: {
                name: "style"
            },
            contains: [r],
            starts: {
                end: /<\/style>/,
                returnEnd: !0,
                subLanguage: ["css", "xml"]
            }
        }, {
            className: "tag",
            begin: /<script(?=\s|>)/,
            end: />/,
            keywords: {
                name: "script"
            },
            contains: [r],
            starts: {
                end: /<\/script>/,
                returnEnd: !0,
                subLanguage: ["javascript", "handlebars", "xml"]
            }
        }, {
            className: "tag",
            begin: /<>|<\/>/
        }, {
            className: "tag",
            begin: t.concat(/</, t.lookahead(t.concat(n, t.either(/\/>/, />/, /\s/)))),
            end: /\/?>/,
            contains: [{
                className: "name",
                begin: n,
                relevance: 0,
                starts: r
            }]
        }, {
            className: "tag",
            begin: t.concat(/<\//, t.lookahead(t.concat(n, />/))),
            contains: [{
                className: "name",
                begin: n,
                relevance: 0
            }, {
                begin: />/,
                relevance: 0,
                endsParent: !0
            }]
        }]
    }
}

function Tn(e) {
    const t = "true false yes no null",
        n = "[\\w#;/?:@&=+$,.~*'()[\\]]+",
        i = {
            className: "attr",
            variants: [{
                begin: /[\w*@][\w*@ :()\./-]*:(?=[ \t]|$)/
            }, {
                begin: /"[\w*@][\w*@ :()\./-]*":(?=[ \t]|$)/
            }, {
                begin: /'[\w*@][\w*@ :()\./-]*':(?=[ \t]|$)/
            }]
        },
        a = {
            className: "template-variable",
            variants: [{
                begin: /\{\{/,
                end: /\}\}/
            }, {
                begin: /%\{/,
                end: /\}/
            }]
        },
        u = {
            className: "string",
            relevance: 0,
            begin: /'/,
            end: /'/,
            contains: [{
                match: /''/,
                scope: "char.escape",
                relevance: 0
            }]
        },
        s = {
            className: "string",
            relevance: 0,
            variants: [{
                begin: /"/,
                end: /"/
            }, {
                begin: /\S+/
            }],
            contains: [e.BACKSLASH_ESCAPE, a]
        },
        o = e.inherit(s, {
            variants: [{
                begin: /'/,
                end: /'/,
                contains: [{
                    begin: /''/,
                    relevance: 0
                }]
            }, {
                begin: /"/,
                end: /"/
            }, {
                begin: /[^\s,{}[\]]+/
            }]
        }),
        d = {
            className: "number",
            begin: "\\b" + "[0-9]{4}(-[0-9][0-9]){0,2}" + "([Tt \\t][0-9][0-9]?(:[0-9][0-9]){2})?" + "(\\.[0-9]*)?" + "([ \\t])*(Z|[-+][0-9][0-9]?(:[0-9][0-9])?)?" + "\\b"
        },
        m = {
            end: ",",
            endsWithParent: !0,
            excludeEnd: !0,
            keywords: t,
            relevance: 0
        },
        b = {
            begin: /\{/,
            end: /\}/,
            contains: [m],
            illegal: "\\n",
            relevance: 0
        },
        g = {
            begin: "\\[",
            end: "\\]",
            contains: [m],
            illegal: "\\n",
            relevance: 0
        },
        E = [i, {
            className: "meta",
            begin: "^---\\s*$",
            relevance: 10
        }, {
            className: "string",
            begin: "[\\|>]([1-9]?[+-])?[ ]*\\n( +)[^ ][^\\n]*\\n(\\2[^\\n]+\\n?)*"
        }, {
            begin: "<%[%=-]?",
            end: "[%-]?%>",
            subLanguage: "ruby",
            excludeBegin: !0,
            excludeEnd: !0,
            relevance: 0
        }, {
            className: "type",
            begin: "!\\w+!" + n
        }, {
            className: "type",
            begin: "!<" + n + ">"
        }, {
            className: "type",
            begin: "!" + n
        }, {
            className: "type",
            begin: "!!" + n
        }, {
            className: "meta",
            begin: "&" + e.UNDERSCORE_IDENT_RE + "$"
        }, {
            className: "meta",
            begin: "\\*" + e.UNDERSCORE_IDENT_RE + "$"
        }, {
            className: "bullet",
            begin: "-(?=[ ]|$)",
            relevance: 0
        }, e.HASH_COMMENT_MODE, {
            beginKeywords: t,
            keywords: {
                literal: t
            }
        }, d, {
            className: "number",
            begin: e.C_NUMBER_RE + "\\b",
            relevance: 0
        }, b, g, u, s],
        S = [...E];
    return S.pop(), S.push(o), m.contains = S, {
        name: "YAML",
        case_insensitive: !0,
        aliases: ["yml"],
        contains: E
    }
}
var yt = Ve();
const _n = Ue(yt);
export {
    Zt as A, Xt as B, Yt as C, qt as D, Qt as E, Kt as F, zt as G, _n as H, Wt as I, $t as J, Ht as K, Vt as L, Ut as M, Gt as N, wt as O, kt as P, Bt as Q, Ft as R, ft as a, mn as b, un as c, dn as d, ln as e, sn as f, rn as g, on as h, xt as i, an as j, nn as k, Lt as l, Mt as m, Pt as n, tn as o, vt as p, en as q, cn as r, pn as s, gn as t, jt as u, En as v, Sn as w, bn as x, Tn as y, Jt as z
};
//# sourceMappingURL=j37p94g6trtb4j3z.js.map