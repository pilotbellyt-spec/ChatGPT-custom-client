import {
    c as e,
    s
} from "./dykg4ktvbu3mhmdo.js";
const o = e(s, "52bdce", 20, 20);
export {
    o as S
};
//# sourceMappingURL=kyjerv6rln8oin0o.js.map