var ft = Object.freeze,
    gt = Object.defineProperty,
    Zt = Object.defineProperties;
var zt = Object.getOwnPropertyDescriptors;
var Fe = Object.getOwnPropertySymbols;
var pt = Object.prototype.hasOwnProperty,
    yt = Object.prototype.propertyIsEnumerable;
var xt = (s, e, n) => e in s ? gt(s, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : s[e] = n,
    o = (s, e) => {
        for (var n in e || (e = {})) pt.call(e, n) && xt(s, n, e[n]);
        if (Fe)
            for (var n of Fe(e)) yt.call(e, n) && xt(s, n, e[n]);
        return s
    },
    T = (s, e) => Zt(s, zt(e));
var ht = (s, e) => {
    var n = {};
    for (var r in s) pt.call(s, r) && e.indexOf(r) < 0 && (n[r] = s[r]);
    if (s != null && Fe)
        for (var r of Fe(s)) e.indexOf(r) < 0 && yt.call(s, r) && (n[r] = s[r]);
    return n
};
var Ie = (s, e) => ft(gt(s, "raw", {
    value: ft(e || s.slice())
}));
import {
    c as z,
    e as Me,
    j as t,
    M as m,
    f as kt,
    L as He,
    r as bt
} from "./fg33krlcm0qyi6yw.js";
import {
    cb as Jt,
    ko as Qt,
    e7 as Xt,
    ir as _t,
    is as vt,
    kp as es,
    iu as ts,
    it as ss,
    kq as ns,
    kr as Tt,
    ks as rs,
    kt as is,
    aP as as,
    gp as ls
} from "./k15yxxoybkkir2ou.js";
import {
    T as os
} from "./gf03dbmrlccb2uqq.js";
import {
    V as ke,
    e as cs,
    L as F,
    l as R,
    d as jt,
    oO as us,
    oU as ds,
    b as ms,
    im as Mt,
    u7 as fs,
    F as Ye,
    u8 as xs
} from "./dykg4ktvbu3mhmdo.js";
import {
    c as gs
} from "./jd9zt1u141h04j00.js";
import {
    b as ps,
    T as Ct,
    t as Ae
} from "./n7nqkdn53j3o5j6k.js";
import {
    P as ys
} from "./mtdf3zn500avq96a.js";
var Ke = (s => (s.standard = "standard", s.promo = "promo", s.highlight = "highlight", s))(Ke || {});

function hs(s) {
    return "percentage" in s
}
const bs = "ms-1 rounded-4xl px-2 pt-1.5 pb-1.25 text-[11px] font-semibold",
    _s = "border border-none bg-[#DCDBFF] text-[#615EEB] dark:bg-[#444378] dark:text-[#B9B7FF]";

function E(s) {
    "use forget";
    const e = z.c(6),
        {
            children: n,
            className: r,
            hasIcon: i
        } = s,
        d = r === void 0 ? _s : r,
        f = i === void 0 ? !1 : i,
        p = "".concat(bs, " ").concat(d),
        x = f && "flex";
    let c;
    e[0] !== p || e[1] !== x ? (c = R(p, x), e[0] = p, e[1] = x, e[2] = c) : c = e[2];
    let h;
    return e[3] !== n || e[4] !== c ? (h = t.jsx("span", {
        className: c,
        children: n
    }), e[3] = n, e[4] = c, e[5] = h) : h = e[5], h
}

function vs(s) {
    return s === "clock" || s === "sparkle"
}

function Ts(s) {
    "use forget";
    const e = z.c(10),
        {
            iconType: n,
            badgeWording: r
        } = s,
        i = n === "clock" ? Jt : n === "sparkle" ? Qt : null,
        d = !!i;
    let f;
    e[0] !== i ? (f = i && t.jsx(i, {
        "aria-hidden": !0,
        className: "h-3 w-3"
    }), e[0] = i, e[1] = f) : f = e[1];
    const p = Cs[r];
    let x;
    e[2] !== p ? (x = t.jsx(m, o({}, p)), e[2] = p, e[3] = x) : x = e[3];
    let c;
    e[4] !== f || e[5] !== x ? (c = t.jsxs("span", {
        className: "inline-flex items-center gap-1",
        children: [f, x]
    }), e[4] = f, e[5] = x, e[6] = c) : c = e[6];
    let h;
    return e[7] !== d || e[8] !== c ? (h = t.jsx(E, {
        hasIcon: d,
        children: c
    }), e[7] = d, e[8] = c, e[9] = h) : h = e[9], h
}

function js(s) {
    "use forget";
    const e = z.c(36),
        {
            useRecommendedBadge: n,
            activeDiscountMetadata: r,
            promoMetadata: i,
            type: d,
            planType: f,
            customBadgeLabel: p,
            welcomeOfferLabel: x,
            currencySymbol: c,
            isScheduledPromo: h
        } = s,
        g = Me();
    let M;
    if (e[0] !== i) {
        M = Symbol.for("react.early_return_sentinel");
        e: {
            const a = cs(),
                y = i && "percentage" in i.discount && i.discount.percentage === 100,
                S = ke(a, "503993189");
            if (y && S.get("is_variant", !1)) {
                const I = S.get("cta", "special_offer"),
                    J = S.get("icon_type", null),
                    O = vs(J) ? J : null;
                let P;
                e[2] !== I || e[3] !== O ? (P = t.jsx(Ts, {
                    iconType: O,
                    badgeWording: I
                }), e[2] = I, e[3] = O, e[4] = P) : P = e[4], M = P;
                break e
            }
        }
        e[0] = i, e[1] = M
    } else M = e[1];
    if (M !== Symbol.for("react.early_return_sentinel")) return M;
    const $ = p && f === F.FREE_WORKSPACE ? "border border-[#0D0D0D1A] bg-transparent text-[#5856D6] dark:text-[#B9B7FF]" : void 0;
    if (p) {
        let a;
        e[5] !== p ? (a = t.jsx(m, o({}, p)), e[5] = p, e[6] = a) : a = e[6];
        let y;
        return e[7] !== $ || e[8] !== a ? (y = t.jsx(E, {
            className: $,
            children: a
        }), e[7] = $, e[8] = a, e[9] = y) : y = e[9], y
    }
    const X = d === Ke.highlight && f === F.GO,
        ee = d === Ke.highlight,
        te = r && "percentage" in r.discount && r.discount.percentage === 100,
        w = r && !te;
    if (x) {
        let a;
        return e[10] !== x ? (a = t.jsx(E, {
            children: t.jsx(m, o({}, x))
        }), e[10] = x, e[11] = a) : a = e[11], a
    }
    if (!h && (i != null && i.promotion_type_label)) {
        let a;
        return e[12] !== i.promotion_type_label ? (a = t.jsx(E, {
            children: i.promotion_type_label
        }), e[12] = i.promotion_type_label, e[13] = a) : a = e[13], a
    }
    if (!h && (i != null && i.duration)) {
        if (hs(i.discount)) {
            let S;
            e[14] !== i.discount.percentage ? (S = Math.round(i.discount.percentage), e[14] = i.discount.percentage, e[15] = S) : S = e[15];
            let I;
            return e[16] !== S ? (I = t.jsx(E, {
                children: t.jsx(m, T(o({}, k.percentageDiscount), {
                    values: {
                        discount_percentage: S
                    }
                }))
            }), e[16] = S, e[17] = I) : I = e[17], I
        }
        let a;
        e[18] !== g || e[19] !== i.discount.currency_code || e[20] !== i.discount.value ? (a = g.formatNumber(i.discount.value, {
            style: "currency",
            currency: i.discount.currency_code,
            minimumFractionDigits: 0,
            maximumFractionDigits: 2
        }), e[18] = g, e[19] = i.discount.currency_code, e[20] = i.discount.value, e[21] = a) : a = e[21];
        let y;
        return e[22] !== a ? (y = t.jsx(E, {
            children: t.jsx(m, T(o({}, k.flatDiscount), {
                values: {
                    discounted_cost: a
                }
            }))
        }), e[22] = a, e[23] = y) : y = e[23], y
    }
    if (!h && i) {
        let a;
        return e[24] === Symbol.for("react.memo_cache_sentinel") ? (a = t.jsx(E, {
            children: t.jsx(m, o({}, k.promo))
        }), e[24] = a) : a = e[24], a
    }
    if (w && r) {
        if ("percentage" in r.discount) {
            const a = r == null ? void 0 : r.discount.percentage;
            let y;
            return e[25] !== a ? (y = t.jsx(E, {
                children: t.jsx(m, T(o({}, k.percentageDiscount), {
                    values: {
                        discount_percentage: a
                    }
                }))
            }), e[25] = a, e[26] = y) : y = e[26], y
        } else if ("value" in r.discount) {
            let a;
            e[27] !== r.discount.value || e[28] !== c.code || e[29] !== g ? (a = g.formatNumber(r.discount.value, {
                style: "currency",
                currency: g.formatMessage(c.code),
                minimumFractionDigits: 0,
                maximumFractionDigits: 2
            }), e[27] = r.discount.value, e[28] = c.code, e[29] = g, e[30] = a) : a = e[30];
            let y;
            return e[31] !== a ? (y = t.jsx(E, {
                children: t.jsx(m, T(o({}, k.flatDiscount), {
                    values: {
                        discounted_cost: a
                    }
                }))
            }), e[31] = a, e[32] = y) : y = e[32], y
        }
    }
    if (X) {
        let a;
        return e[33] === Symbol.for("react.memo_cache_sentinel") ? (a = t.jsx(E, {
            children: t.jsx(m, o({}, k.new))
        }), e[33] = a) : a = e[33], a
    }
    if (n) {
        let a;
        return e[34] === Symbol.for("react.memo_cache_sentinel") ? (a = t.jsx(E, {
            children: t.jsx(m, o({}, k.recommended))
        }), e[34] = a) : a = e[34], a
    }
    if (ee) {
        let a;
        return e[35] === Symbol.for("react.memo_cache_sentinel") ? (a = t.jsx(E, {
            children: t.jsx(m, o({}, k.popular))
        }), e[35] = a) : a = e[35], a
    }
    return null
}
const k = kt({
        percentageDiscount: {
            id: "percentageDiscount",
            defaultMessage: "{discount_percentage}% OFF"
        },
        flatDiscount: {
            id: "flatDiscount",
            defaultMessage: "{discounted_cost} OFF"
        },
        promo: {
            id: "promo",
            defaultMessage: "PROMO"
        },
        popular: {
            id: "popular",
            defaultMessage: "POPULAR"
        },
        recommended: {
            id: "recommended",
            defaultMessage: "RECOMMENDED"
        },
        new: {
            id: "new",
            defaultMessage: "NEW"
        },
        specialOffer: {
            id: "pricingPlanBadgeConstants.specialOffer",
            defaultMessage: "SPECIAL OFFER"
        },
        limitedTime: {
            id: "pricingPlanBadgeConstants.limitedTime",
            defaultMessage: "LIMITED TIME"
        }
    }),
    Cs = {
        special_offer: k.specialOffer,
        limited_time: k.limitedTime
    },
    Ss = {
        standard: "border-s border-e border-t border-b border-token-border-default md:min-h-[30rem] md:max-w-96 md:rounded-none md:border-e-0 md:pb-6 md:first:rounded-ss-xl md:first:rounded-es-xl md:last:rounded-se-xl md:last:rounded-ee-xl md:last:border-e",
        promo: "shadow-lg md:min-h-[30rem] md:max-w-96 md:pb-6",
        highlight: "border-s border-e border-t border-b md:-mt-4 md:-mb-4 md:min-h-[20rem] md:max-w-96 md:pb-6 md:first:rounded-ss-xl md:first:rounded-es-xl md:last:rounded-se-xl md:last:rounded-ee-xl"
    };

function Ds(s) {
    "use forget";
    var c;
    const e = z.c(14);
    let n, r, i, d;
    e[0] !== s ? (c = s, {
        children: n,
        className: r,
        type: d
    } = c, i = ht(c, ["children", "className", "type"]), e[0] = s, e[1] = n, e[2] = r, e[3] = i, e[4] = d) : (n = e[1], r = e[2], i = e[3], d = e[4]);
    let f, p;
    if (e[5] !== r || e[6] !== i || e[7] !== d) {
        const h = R("border-[#CFCEFC] bg-[#F5F5FF] dark:bg-[#282841] dark:border-[#484777] md:mt-0 md:mb-0", d === "promo" && "border-token-border-light");
        f = i, p = R(Ss[d], ["highlight", "promo"].includes(d) && h, "relative flex flex-1 flex-col justify-center gap-4 rounded-xl px-6 py-6.5 text-sm md:rounded-2xl! md:border-e-1 md:border-b-1 md:border-t-1 md:border-s-1", r), e[5] = r, e[6] = i, e[7] = d, e[8] = f, e[9] = p
    } else f = e[8], p = e[9];
    let x;
    return e[10] !== n || e[11] !== f || e[12] !== p ? (x = t.jsx("div", T(o({}, f), {
        className: p,
        children: n
    })), e[10] = n, e[11] = f, e[12] = p, e[13] = x) : x = e[13], x
}
var Ft;
const St = Ye.div(Ft || (Ft = Ie(["\n  relative flex flex-col ", "\n"])), s => ["highlight", "promo"].includes(s.type) ? "mt-4" : "bg-token-main-surface-primary");
var It;
const Ns = Ye.div(It || (It = Ie(["flex flex-col grow gap-2"])));
var At;
const Dt = Ye.div(At || (At = Ie(["\n  relative flex flex-col text-xs text-token-text-secondary ", "\n"])), s => ["highlight", "promo"].includes(s.type) ? "" : "bg-token-main-surface-primary"),
    Es = 50;

function Fs(s) {
    "use forget";
    const e = z.c(12),
        {
            summaryText: n,
            startDelayMs: r
        } = s,
        [i, d] = bt.useState(r <= 0);
    let f, p;
    if (e[0] !== r || e[1] !== n ? (f = () => {
            if (!n) {
                d(!1);
                return
            }
            if (r <= 0) {
                d(!0);
                return
            }
            d(!1);
            const g = setTimeout(() => {
                d(!0)
            }, r);
            return () => clearTimeout(g)
        }, p = [r, n], e[0] = r, e[1] = n, e[2] = f, e[3] = p) : (f = e[2], p = e[3]), bt.useEffect(f, p), !n) return null;
    let x;
    e[4] !== i || e[5] !== n ? (x = t.jsx("span", {
        "aria-hidden": "true",
        children: i ? t.jsx(os, {
            value: n,
            speed: Es,
            typing: !0,
            chunk: !0
        }) : t.jsx(as, {})
    }), e[4] = i, e[5] = n, e[6] = x) : x = e[6];
    let c;
    e[7] !== n ? (c = t.jsx("span", {
        className: "sr-only",
        "aria-live": "polite",
        "aria-atomic": "true",
        children: n
    }), e[7] = n, e[8] = c) : c = e[8];
    let h;
    return e[9] !== x || e[10] !== c ? (h = t.jsxs("span", {
        children: [x, c]
    }), e[9] = x, e[10] = c, e[11] = h) : h = e[11], h
}

function Is(s) {
    return "referrer_name" in s
}
var As = (s => (s.standard = "standard", s.promo = "promo", s.highlight = "highlight", s))(As || {});
const Js = s => {
    "use forget";
    var nt, rt, it, at, lt, ot, ct, ut, dt, mt;
    const e = z.c(81),
        {
            planType: n,
            pricingPlan: r,
            callToActionButton: i,
            secondaryCallToActionButton: d,
            className: f,
            elementId: p,
            additionalLinks: x,
            promoMetadata: c,
            activeDiscountMetadata: h,
            billingDetails: g,
            promoData: M,
            type: $,
            isBusinessUpgradeV2CopyEnabled: X,
            useRecommendedBadge: ee,
            shouldUseComparisonSpacing: te,
            paymentsOverrideString: w,
            badgeLabel: a,
            isCheckoutPricingConfigLoading: y,
            checkoutPricingConfigError: S,
            hasEnabledTeamFreeTrialCoupon: I,
            enableComposerLoadPricingLayer: J
        } = s,
        O = d === void 0 ? null : d;
    let P;
    e[0] !== x ? (P = x === void 0 ? [] : x, e[0] = x, e[1] = P) : P = e[1];
    const se = P,
        _ = c === void 0 ? null : c,
        B = h === void 0 ? null : h,
        A = M === void 0 ? null : M,
        j = $ === void 0 ? "standard" : $,
        we = X === void 0 ? !1 : X,
        wt = ee === void 0 ? !1 : ee,
        ne = te === void 0 ? !1 : te,
        Ze = I === void 0 ? !1 : I,
        re = J === void 0 ? !1 : J,
        Pt = jt(us),
        Bt = jt(ds),
        {
            costTitle: V,
            costSubtitle: ze,
            currencySymbol: W
        } = Rs(r, g.currency),
        v = Me(),
        D = ms(),
        Lt = ke(D, "3768341700").get("is_sku_info_code_enabled", !1);
    let q, ie;
    if (e[2] !== D || e[3] !== re) {
        const l = re ? ke(D, "3343315239") : null,
            u = (nt = l == null ? void 0 : l.get("average_latency_ms", 0)) != null ? nt : 0;
        q = typeof u == "number" && Number.isFinite(u) ? Math.max(0, u) : 0, ie = (rt = l == null ? void 0 : l.get("applicable_plan_type", "highlighted")) != null ? rt : "highlighted", e[2] = D, e[3] = re, e[4] = q, e[5] = ie
    } else q = e[4], ie = e[5];
    const Je = ie === "highlighted" ? "highlighted" : "paid_plans";
    let Pe;
    e: {
        if (!r.summary) {
            Pe = "";
            break e
        }
        let l;e[6] !== v || e[7] !== r.summary ? (l = v.formatMessage(r.summary), e[6] = v, e[7] = r.summary, e[8] = l) : l = e[8],
        Pe = l
    }
    const ae = Pe,
        Be = re && !Bt && q > 0 && ae !== "" && (Je === "paid_plans" && n !== F.FREE || Je === "highlighted" && j === "highlight"),
        le = Os,
        oe = !w && Lt && A == null && _ == null && ((it = r.cost) == null ? void 0 : it.costDuration) == null && B == null;
    let ce;
    e[9] !== g.country || e[10] !== g.currency || e[11] !== D ? (ce = {
        countryCode: g.country,
        currency: g.currency,
        ctx: D
    }, e[9] = g.country, e[10] = g.currency, e[11] = D, e[12] = ce) : ce = e[12];
    const {
        data: b,
        error: Rt,
        isLoading: Ot
    } = Xt(ce);
    let G;
    e[13] !== g.country || e[14] !== b ? (G = ws(b, g.country), e[13] = g.country, e[14] = b, e[15] = G) : G = e[15];
    let H;
    e[16] !== g.currency || e[17] !== D ? (H = Ps(D, g.currency), e[16] = g.currency, e[17] = D, e[18] = H) : H = e[18];
    let ue;
    e[19] !== G || e[20] !== H ? (ue = o(o({}, G), H), e[19] = G, e[20] = H, e[21] = ue) : ue = e[21];
    const de = ue,
        Wt = de.inclusiveTaxDisplay === "tax_name_only",
        Ut = de.inclusiveTaxDisplay === "with_amount",
        Vt = de.showReverseChargeDisclaimer,
        qt = n === F.SELF_SERVE_BUSINESS;
    let me;
    e[22] !== D ? (me = ls(), e[22] = D, e[23] = me) : me = e[23];
    const $t = me,
        Le = Wt && n !== F.FREE,
        Re = Ut && n !== F.FREE,
        Qe = Vt && n === F.SELF_SERVE_BUSINESS,
        Gt = !!(r.disclaimer || r.disclaimer2 || Qe);
    let Oe = V,
        K;
    if (!y && !S && b) {
        if (Ze || _ && n === F.SELF_SERVE_BUSINESS) K = _t(b, es, vt.Month);
        else if (n === F.PLUS || n === F.GO) {
            const l = n === F.PLUS ? ts : ss;
            K = _t(b, l, vt.Month)
        }
    }
    K && (Oe = {
        id: "defaultCost",
        defaultMessage: ns(K.amount).toString()
    });
    const Xe = ((lt = (at = _ == null ? void 0 : _.schedule) == null ? void 0 : at.start_after_num_periods) != null ? lt : 0) > 0,
        et = !!B || !!_ && !Xe;
    let fe;
    e: {
        if (!oe || !b) {
            let l;
            e[24] === Symbol.for("react.memo_cache_sentinel") ? (l = {
                info: null,
                hadError: !1
            }, e[24] = l) : l = e[24], fe = l;
            break e
        }
        try {
            let l;
            e[25] !== g || e[26] !== b || e[27] !== n ? (l = gs(b, n, g), e[25] = g, e[26] = b, e[27] = n, e[28] = l) : l = e[28];
            let u;
            e[29] !== l ? (u = {
                info: l,
                hadError: !1
            }, e[29] = l, e[30] = u) : u = e[30], fe = u
        } catch (l) {
            let u;
            e[31] === Symbol.for("react.memo_cache_sentinel") ? (u = {
                info: null,
                hadError: !0
            }, e[31] = u) : u = e[31], fe = u
        }
    }
    const tt = fe,
        L = tt.info;
    let We;
    e: {
        if (!oe && S != null || oe && (Rt || tt.hadError)) {
            We = C.pricingConfigFallback;
            break e
        }
        We = null
    }
    const Q = We;
    let xe;
    e[32] !== Q ? (xe = Q ? t.jsx("div", {
        role: "alert",
        className: "border-token-border-warning bg-token-background-warning text-token-text-warning mb-3 w-full rounded border text-xs",
        children: t.jsx(m, o({}, Q))
    }) : null, e[32] = Q, e[33] = xe) : xe = e[33];
    const Ht = xe;
    let ge;
    e[34] === Symbol.for("react.memo_cache_sentinel") ? (ge = t.jsxs("div", {
        className: "mb-4 flex gap-2",
        children: [t.jsx("div", {
            className: "text-secondary text-xl text-gray-500",
            children: t.jsx("div", {
                className: "h-6 w-4 animate-pulse rounded bg-gray-200 dark:bg-gray-700"
            })
        }), t.jsx("div", {
            className: "h-10 w-24 animate-pulse rounded bg-gray-200 dark:bg-gray-700"
        })]
    }), e[34] = ge) : ge = e[34];
    let pe;
    e[35] === Symbol.for("react.memo_cache_sentinel") ? (pe = t.jsxs(t.Fragment, {
        children: [ge, t.jsx("div", {
            className: "mt-4 flex items-baseline gap-1.5",
            children: t.jsx("div", {
                className: "mt-auto mb-0.5 flex h-full flex-col items-start",
                children: t.jsx("p", {
                    className: "text-token-text-secondary w-full text-[11px]",
                    children: t.jsx("span", {
                        className: "inline-block h-3 w-32 animate-pulse rounded bg-gray-200 dark:bg-gray-700"
                    })
                })
            })
        })]
    }), e[35] = pe) : pe = e[35];
    const Kt = pe,
        ye = Q != null || (oe ? Ot : y),
        {
            shouldHide: Ue
        } = ps(),
        Yt = A == null ? void 0 : A.coupon;
    let Ve;
    e: {
        if (Yt === Ct) {
            let l;
            e[36] === Symbol.for("react.memo_cache_sentinel") ? (l = {
                welcomeOffer: Ae.teamFreeTrialWelcomeOffer,
                notEligible: Ae.teamFreeTrialNotEligible,
                temporarilyDisabled: Ae.teamFreeTrialTemporarilyDisabled,
                offline: Ae.teamFreeTrialOffline
            }, e[36] = l) : l = e[36], Ve = l;
            break e
        }
        Ve = null
    }
    const N = Ve;
    let he = null,
        st = null;
    if (!_ && (A == null ? void 0 : A.coupon) === Ct) {
        if (A.state === "eligible") st = N == null ? void 0 : N.welcomeOffer;
        else if (A.state === "not_eligible" && !Ue) {
            const l = N == null ? void 0 : N.notEligible;
            let u;
            e[37] !== l ? (u = t.jsx("div", {
                className: "mb-3 w-full",
                "data-testid": "pricing-modal-promo-banner",
                children: t.jsx("div", {
                    className: "rounded bg-gray-50 px-3 py-2 text-sm text-gray-900",
                    children: t.jsx(m, o({}, l))
                })
            }), e[37] = l, e[38] = u) : u = e[38], he = u
        } else if (A.state === "temporary_disabled" && !Ue) {
            const l = N == null ? void 0 : N.temporarilyDisabled;
            let u;
            e[39] !== l ? (u = t.jsx("div", {
                className: "mb-3 w-full",
                "data-testid": "pricing-modal-promo-banner",
                children: t.jsx("div", {
                    className: "rounded bg-gray-50 px-3 py-2 text-sm text-gray-500",
                    children: t.jsx(m, o({}, l))
                })
            }), e[39] = l, e[40] = u) : u = e[40], he = u
        } else if (A.state === "offline" && !Ue) {
            const l = N == null ? void 0 : N.offline;
            let u;
            e[41] !== l ? (u = t.jsx("div", {
                className: "mb-3 w-full",
                "data-testid": "pricing-modal-promo-banner",
                children: t.jsx("div", {
                    className: "rounded bg-gray-50 px-3 py-2 text-sm text-gray-900",
                    children: t.jsx(m, o({}, l))
                })
            }), e[41] = l, e[42] = u) : u = e[42], he = u
        }
    }
    let Y;
    e[43] !== j ? (Y = !["promo", "highlight"].includes(j) && "bg-token-main-surface-primary", e[43] = j, e[44] = Y) : Y = e[44];
    const qe = ne && "md:max-w-117";
    let be;
    e[45] !== f || e[46] !== Y || e[47] !== qe ? (be = R(Y, qe, f), e[45] = f, e[46] = Y, e[47] = qe, e[48] = be) : be = e[48];
    let _e;
    e[49] !== r.name ? (_e = t.jsx(m, o({}, r.name)), e[49] = r.name, e[50] = _e) : _e = e[50];
    let ve;
    e[51] !== v || e[52] !== w ? (ve = w && t.jsx("span", {
        className: "text-token-text-primary text-base text-[42px] leading-[48px]",
        children: v.formatMessage(w)
    }), e[51] = v, e[52] = w, e[53] = ve) : ve = e[53];
    let Te;
    e[54] !== n || e[55] !== ye ? (Te = ye && t.jsx("div", {
        "data-testid": "".concat(n, "-pricing-column-cost-skeleton"),
        children: Kt
    }), e[54] = n, e[55] = ye, e[56] = Te) : Te = e[56];
    let je;
    e[57] !== n || e[58] !== r.summary || e[59] !== Be || e[60] !== ne || e[61] !== q || e[62] !== ae ? (je = r.summary ? t.jsx("p", {
        className: R("text-token-text-primary mt-4 text-base font-medium", ne && "md:min-h-12"),
        "data-testid": "".concat(n, "-pricing-column-cost-summary"),
        children: Be ? t.jsx(Fs, {
            summaryText: ae,
            startDelayMs: q
        }) : t.jsx(m, o({}, r.summary))
    }) : null, e[57] = n, e[58] = r.summary, e[59] = Be, e[60] = ne, e[61] = q, e[62] = ae, e[63] = je) : je = e[63];
    let Ce;
    e[64] !== i ? (Ce = t.jsx("div", {
        className: "mb-2.5 w-full",
        children: i
    }), e[64] = i, e[65] = Ce) : Ce = e[65];
    let Se;
    e[66] !== O || e[67] !== j ? (Se = O && t.jsx(St, {
        type: j,
        className: "-mt-2",
        children: O
    }), e[66] = O, e[67] = j, e[68] = Se) : Se = e[68];
    const $e = n === F.SELF_SERVE_BUSINESS;
    let De;
    e[69] !== we || e[70] !== r.advertisedFeatures || e[71] !== $e ? (De = t.jsx(Ns, {
        children: t.jsx(ys, {
            advertisedFeatures: r.advertisedFeatures,
            isTeamColumn: $e,
            isBusinessUpgradeV2CopyEnabled: we
        })
    }), e[69] = we, e[70] = r.advertisedFeatures, e[71] = $e, e[72] = De) : De = e[72];
    let Ne;
    e[73] !== _ ? (Ne = _ && Is(_) && (_ == null ? void 0 : _.referrer_name) && t.jsx("div", {
        className: "flex w-full items-center justify-center rounded-md border-[1px] border-[#AF52DE] bg-[#8C43A00D] py-2 text-center",
        children: t.jsx("span", {
            className: "text-l text-[#AF52DE]",
            children: t.jsx(m, {
                id: "PricingModalColumn.referredBy",
                defaultMessage: "{referrer_name} gave you 1 month of free Plus",
                values: {
                    referrer_name: _ == null ? void 0 : _.referrer_name
                }
            })
        })
    }), e[73] = _, e[74] = Ne) : Ne = e[74];
    const Ge = Gt && t.jsxs(Dt, {
        type: j,
        className: "mt-3 px-1",
        children: [r.disclaimer && r.cost && t.jsx("div", {
            children: t.jsx(m, T(o({}, r.disclaimer), {
                values: {
                    link: l => {
                        var u, U;
                        return t.jsx(He, {
                            className: "font-medium underline",
                            target: "_blank",
                            rel: "noreferrer",
                            to: (U = (u = r.disclaimer) == null ? void 0 : u.link) != null ? U : "",
                            children: l
                        })
                    },
                    minSeats: $t,
                    article: l => {
                        var u, U;
                        return t.jsx(He, {
                            className: "font-medium underline",
                            target: "_blank",
                            rel: "noreferrer",
                            to: (U = (u = r == null ? void 0 : r.disclaimer) == null ? void 0 : u.article) != null ? U : "",
                            children: l
                        })
                    },
                    amount: v.formatNumber(r.cost.costValue, {
                        style: "currency",
                        currency: g.currency,
                        trailingZeroDisplay: "stripIfInteger"
                    }),
                    currencySign: v.formatMessage(W.sign),
                    postTrialSeatPrice: Ze && qt && K ? v.formatNumber(K.amount, {
                        style: "currency",
                        currency: g.currency,
                        trailingZeroDisplay: "stripIfInteger"
                    }) : void 0
                }
            }))
        }), r.disclaimer2 && t.jsx("div", {
            children: t.jsx(m, T(o({}, r.disclaimer2), {
                values: {
                    link: l => {
                        var u, U;
                        return t.jsx(He, {
                            className: "font-medium underline",
                            target: "_blank",
                            rel: "noreferrer",
                            to: (U = (u = r.disclaimer2) == null ? void 0 : u.link) != null ? U : "",
                            children: l
                        })
                    }
                }
            }))
        }), Qe && (L ? ((ot = L.taxDetails) == null ? void 0 : ot.reverseChargeEligible) && t.jsx("div", {
            children: t.jsx(m, T(o({}, C.reverseChargeTaxDisclaimer), {
                values: {
                    tax_type: L.taxDetails.taxName
                }
            }))
        }) : t.jsx("div", {
            children: t.jsx(m, o({}, C.teamPricingVATDisclaimer))
        }))]
    });
    let Z;
    e[75] !== se || e[76] !== j ? (Z = se.length > 0 && t.jsx(Dt, {
        type: j,
        className: "gap-0.5 pt-1",
        children: se.map(Ws)
    }), e[75] = se, e[76] = j, e[77] = Z) : Z = e[77];
    let Ee;
    return e[78] !== Ge || e[79] !== Z ? (Ee = t.jsxs("div", {
        children: [Ge, Z]
    }), e[78] = Ge, e[79] = Z, e[80] = Ee) : Ee = e[80], t.jsxs(Ds, {
        className: be,
        "data-testid": "".concat(n, "-pricing-modal-column"),
        id: p,
        type: j,
        children: [Ht, he, t.jsxs(St, {
            type: j,
            className: "mt-0",
            children: [t.jsxs("div", {
                className: "flex flex-col gap-5 rounded-2xl",
                children: [t.jsxs("p", {
                    className: "flex items-center justify-between gap-2 text-[28px] font-medium",
                    children: [_e, t.jsx(js, {
                        useRecommendedBadge: wt,
                        activeDiscountMetadata: B,
                        promoMetadata: _,
                        type: j,
                        planType: n,
                        customBadgeLabel: a,
                        welcomeOfferLabel: st,
                        currencySymbol: W,
                        isScheduledPromo: Xe
                    })]
                }), ve, Te, !w && t.jsxs("div", {
                    className: "flex items-end gap-1.5",
                    hidden: ye,
                    "data-testid": "".concat(n, "-pricing-column-cost"),
                    children: [Oe && t.jsx(Nt, {
                        costTitle: Oe,
                        currencySymbol: W,
                        isStrikethrough: et,
                        priceDetail: L == null ? void 0 : L.priceDetails
                    }), et && V ? t.jsx(Nt, {
                        costTitle: V,
                        currencySymbol: W
                    }) : null, t.jsx("div", {
                        className: "flex items-baseline gap-1.5",
                        children: t.jsxs("div", {
                            className: "mt-auto mb-0.5 flex h-full flex-col items-start",
                            children: [t.jsx("p", {
                                className: "text-token-text-secondary w-full text-[11px]",
                                children: (ct = r.cost) != null && ct.costDuration ? t.jsx(m, T(o({}, C.currencyWithDuration), {
                                    values: {
                                        currency: v.formatMessage(W.code),
                                        duration: v.formatMessage(r.cost.costDuration)
                                    }
                                })) : t.jsxs(t.Fragment, {
                                    children: [t.jsx(m, {
                                        id: "PricingModalColumn.currencyCodeWithSlash",
                                        defaultMessage: "{currencyCode} / ",
                                        values: {
                                            currencyCode: v.formatMessage(W.code)
                                        }
                                    }), _ && !B && (Le ? t.jsx(m, T(o({}, C.frequencyWithTaxInformation), {
                                        values: {
                                            tax_type: le(b == null ? void 0 : b.currencyConfig.tax_type)
                                        }
                                    })) : Re && V ? t.jsx(m, T(o({}, C.frequencyWithTaxInformationIncludingAmount), {
                                        values: {
                                            tax_type: le(b == null ? void 0 : b.currencyConfig.tax_type),
                                            vat_amount: v.formatNumber(Tt(Number((ut = V.defaultMessage) == null ? void 0 : ut.toString().replaceAll("*", "")), g.country), {
                                                style: "currency",
                                                currency: v.formatMessage(W.code),
                                                minimumFractionDigits: 2,
                                                maximumFractionDigits: 2
                                            })
                                        }
                                    })) : t.jsx(m, o({}, C.frequency))), (!B || Le || Re) && t.jsx("br", {}), _ && !B && ((dt = r.cost) != null && dt.costDuration) ? t.jsx(m, o({}, r.cost.costDuration)) : L ? t.jsx(Bs, {
                                        priceDetails: L.priceDetails,
                                        taxDetails: L.taxDetails,
                                        priceDisplayOptions: de
                                    }) : Le ? t.jsx(m, T(o({}, C.frequencyWithTaxInformation), {
                                        values: {
                                            tax_type: le(b == null ? void 0 : b.currencyConfig.tax_type)
                                        }
                                    })) : Re && V ? t.jsx(m, T(o({}, C.frequencyWithTaxInformationIncludingAmount), {
                                        values: {
                                            tax_type: le(b == null ? void 0 : b.currencyConfig.tax_type),
                                            vat_amount: v.formatNumber(Tt(Number((mt = V.defaultMessage) == null ? void 0 : mt.toString().replaceAll("*", "")), g.country), {
                                                style: "currency",
                                                currency: v.formatMessage(W.code),
                                                minimumFractionDigits: 2,
                                                maximumFractionDigits: 2
                                            })
                                        }
                                    })) : t.jsx(m, o({}, C.frequency))]
                                })
                            }), t.jsx("p", {
                                className: "text-token-text-secondary text-xs",
                                children: B && B.discount.expires_at && t.jsx(m, T(o({}, C.remainingDiscountDate), {
                                    values: {
                                        remaining_discount_date: B.discount.expires_at
                                    }
                                }))
                            })]
                        })
                    })]
                })]
            }), !w && ze && Pt ? t.jsx("p", {
                className: "text-token-text-tertiary mt-6 mb-3 text-sm",
                "data-testid": "".concat(n, "-pricing-column-cost-subtitle"),
                children: t.jsx(m, o({}, ze))
            }) : null, je]
        }), Ce, Se, De, Ne, Ee]
    })
};

function Nt({
    costTitle: s,
    currencySymbol: e,
    isStrikethrough: n = !1,
    priceDetail: r
}) {
    return r ? t.jsx(Ms, {
        priceDetail: r,
        isStrikethrough: n
    }) : t.jsxs("div", {
        className: R("flex", {
            "text-token-text-primary": !n,
            "text-token-text-tertiary": n
        }),
        children: [t.jsx("div", {
            className: "text-secondary text-xl text-gray-500",
            children: t.jsx(m, o({}, e.sign))
        }), t.jsx("div", {
            className: R("text-5xl", {
                "line-through": n
            }),
            children: t.jsx(m, o({}, s))
        })]
    })
}

function ks(s, e) {
    return s === xs ? "id-ID" : e
}

function Ms({
    priceDetail: s,
    isStrikethrough: e = !1
}) {
    var x;
    const n = Me(),
        r = {
            style: "currency",
            currency: s.currency,
            currencyDisplay: "narrowSymbol",
            trailingZeroDisplay: "stripIfInteger"
        },
        i = ks(s.currency, n.locale),
        d = new Intl.NumberFormat(i, r).formatToParts(s.amount);
    let f = (x = d.find(c => c.type === "currency")) == null ? void 0 : x.value;
    (!f || f.toUpperCase() === s.currency) && (f = n.formatMessage(Mt(s.currency).sign));
    const p = d.filter(c => c.type !== "currency").map(c => c.value).join("");
    return t.jsxs("div", {
        className: R("flex", {
            "text-token-text-primary": !e,
            "text-token-text-tertiary": e
        }),
        children: [t.jsx("div", {
            className: "text-secondary text-xl text-gray-500",
            children: f
        }), t.jsx("div", {
            className: R("text-5xl", {
                "line-through": e
            }),
            children: p
        })]
    })
}

function Et(s) {
    switch (s) {
        case "tax_name_only":
        case "with_amount":
            return s;
        default:
            return "none"
    }
}

function ws(s, e) {
    if (!s || s.currencyConfig.symbol_code === "GBP" && rs(e)) return {
        inclusiveTaxDisplay: "none",
        exclusiveTaxDisplay: "none",
        showReverseChargeDisclaimer: !1
    };
    const n = s.currencyConfig.vat_display;
    return {
        inclusiveTaxDisplay: Et(n.inclusive_tax_display),
        exclusiveTaxDisplay: Et(n.exclusive_tax_display),
        showReverseChargeDisclaimer: n.show_reverse_charge_disclaimer
    }
}

function Ps(s, e) {
    const n = ke(s, "3768341700"),
        r = n.get("is_vat_information_enabled", !1),
        i = n.get("is_vat_information_with_amount_enabled", !0),
        d = n.get("is_team_pricing_vat_disclaimer_enabled", !1);
    return e === fs ? r ? {
        inclusiveTaxDisplay: "tax_name_only",
        exclusiveTaxDisplay: "tax_name_only",
        showReverseChargeDisclaimer: d
    } : i ? {
        inclusiveTaxDisplay: "with_amount",
        exclusiveTaxDisplay: "tax_name_only",
        showReverseChargeDisclaimer: d
    } : {
        inclusiveTaxDisplay: "none",
        exclusiveTaxDisplay: "none",
        showReverseChargeDisclaimer: d
    } : {}
}

function Bs({
    priceDetails: s,
    taxDetails: e,
    priceDisplayOptions: n
}) {
    var f;
    const r = Me(),
        i = {
            tax_type: (f = e == null ? void 0 : e.taxName) != null ? f : "tax",
            tax_behavior: s.amountTaxBehavior,
            tax_amount: (e == null ? void 0 : e.taxAmount) && r.formatNumber(e.taxAmount, {
                style: "currency",
                currency: s.currency,
                currencyDisplay: "narrowSymbol",
                trailingZeroDisplay: "stripIfInteger"
            })
        };
    let d;
    return e == null || e.taxAmount === 0 ? d = "none" : d = s.amountTaxBehavior === is.Inclusive ? n.inclusiveTaxDisplay : n.exclusiveTaxDisplay, t.jsx(m, T(o({}, Ls({
        displayOption: d
    })), {
        values: i
    }))
}

function Ls({
    displayOption: s
}) {
    switch (s) {
        case "none":
            return C.frequency;
        case "tax_name_only":
            return C.subscriptionFrequencyTaxInformation;
        case "with_amount":
            return C.subscriptionFrequencyTaxInformationWithAmount
    }
}

function Rs(s, e) {
    var n, r, i;
    return {
        costValue: (n = s.cost) == null ? void 0 : n.costValue,
        costTitle: (r = s.cost) == null ? void 0 : r.costTitle,
        costSubtitle: (i = s.cost) == null ? void 0 : i.costSubtitle,
        currencySymbol: Mt(e)
    }
}
const C = kt({
    frequency: {
        id: "frequency",
        defaultMessage: "month"
    },
    currencyWithDuration: {
        id: "PricingModalColumn.currencyWithDuration",
        defaultMessage: "{currency} {duration}"
    },
    frequencyWithTaxInformation: {
        id: "frequencyWithTaxInformation",
        defaultMessage: "month (including {tax_type})"
    },
    frequencyWithTaxInformationIncludingAmount: {
        id: "frequencyWithTaxInformationIncludingAmount",
        defaultMessage: "month (includes {vat_amount} of {tax_type})"
    },
    teamPricingVATDisclaimer: {
        id: "pricingPlanConstants.teams.teamPricingVATDisclaimer",
        defaultMessage: "VAT excluded at checkout with valid VAT ID"
    },
    pricingConfigFallback: {
        id: "PricingModalColumn.pricingConfigFallback",
        defaultMessage: "Please reload page, checkout pricing not available."
    },
    remainingDiscountDate: {
        id: "remainingDiscountDate",
        defaultMessage: "until {remaining_discount_date}"
    },
    subscriptionFrequencyTaxInformation: {
        id: "PricingModalColumn.subscriptionFrequencyTaxInformation",
        defaultMessage: "month ({tax_behavior, select, inclusive {inclusive of} exclusive {exclusive of} other {exclusive of} } {tax_type, select, gst {GST} vat {VAT} other {tax} })"
    },
    subscriptionFrequencyTaxInformationWithAmount: {
        id: "PricingModalColumn.subscriptionFrequencyTaxInformationWithAmount",
        defaultMessage: "month ({tax_behavior, select, inclusive {includes} exclusive {plus} other {plus} } {tax_amount} of {tax_type, select, gst {GST} vat {VAT} other {tax} })"
    },
    reverseChargeTaxDisclaimer: {
        id: "PricingModalColumn.reverseChargeTaxDisclaimer",
        defaultMessage: "{tax_type, select, gst {GST} vat {VAT} other {Tax} } excluded at checkout with a valid {tax_type, select, gst {GST} vat {VAT} other {tax} } ID"
    }
});

function Os(s) {
    if (!s) return "VAT";
    const e = s.toLowerCase();
    return e === "vat" || e === "gst" ? e.toUpperCase() : s
}

function Ws(s, e) {
    return t.jsx("div", {
        children: s
    }, e)
}
export {
    Ms as P, Js as a, As as b, Rs as g
};
//# sourceMappingURL=kk75394dp7aj1ofk.js.map