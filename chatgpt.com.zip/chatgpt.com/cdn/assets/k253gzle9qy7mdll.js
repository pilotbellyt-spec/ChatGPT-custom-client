import {
    c as e,
    s as r
} from "./dykg4ktvbu3mhmdo.js";
const o = e(r, "ba9b0d", 16, 16, !0);
export {
    o as M
};
//# sourceMappingURL=k253gzle9qy7mdll.js.map