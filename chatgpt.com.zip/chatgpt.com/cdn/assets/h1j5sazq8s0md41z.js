import {
    c as t,
    s as e
} from "./dykg4ktvbu3mhmdo.js";
const a = t(e, "d74cb8", 20, 20),
    o = t(e, "5d3542", 20, 20);
export {
    o as C, a
};
//# sourceMappingURL=h1j5sazq8s0md41z.js.map