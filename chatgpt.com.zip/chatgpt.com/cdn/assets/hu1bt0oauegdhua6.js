const f = {};

function p(t, n) {
    const e = f,
        o = typeof e.includeImageAlt == "boolean" ? e.includeImageAlt : !0,
        r = typeof e.includeHtml == "boolean" ? e.includeHtml : !0;
    return d(t, o, r)
}

function d(t, n, e) {
    if (s(t)) {
        if ("value" in t) return t.type === "html" && !e ? "" : t.value;
        if (n && "alt" in t && t.alt) return t.alt;
        if ("children" in t) return i(t.children, n, e)
    }
    return Array.isArray(t) ? i(t, n, e) : ""
}

function i(t, n, e) {
    const o = [];
    let r = -1;
    for (; ++r < t.length;) o[r] = d(t[r], n, e);
    return o.join("")
}

function s(t) {
    return !!(t && typeof t == "object")
}
const a = document.createElement("i");

function u(t) {
    const n = "&" + t + ";";
    a.innerHTML = n;
    const e = a.textContent;
    return e.charCodeAt(e.length - 1) === 59 && t !== "semi" || e === n ? !1 : e
}

function h(t, n) {
    const e = Number.parseInt(t, n);
    return e < 9 || e === 11 || e > 13 && e < 32 || e > 126 && e < 160 || e > 55295 && e < 57344 || e > 64975 && e < 65008 || (e & 65535) === 65535 || (e & 65535) === 65534 || e > 1114111 ? "�" : String.fromCodePoint(e)
}
const l = /\\([!-/:-@[-`{-~])|&(#(?:\d{1,7}|x[\da-f]{1,6})|[\da-z]{1,31});/gi;

function _(t) {
    return t.replace(l, m)
}

function m(t, n, e) {
    if (n) return n;
    if (e.charCodeAt(0) === 35) {
        const r = e.charCodeAt(1),
            c = r === 120 || r === 88;
        return h(e.slice(c ? 2 : 1), c ? 16 : 10)
    }
    return u(e) || t
}
export {
    u as a, h as b, _ as d, p as t
};
//# sourceMappingURL=hu1bt0oauegdhua6.js.map