var Vt = Object.defineProperty,
    Nt = Object.defineProperties;
var Ot = Object.getOwnPropertyDescriptors;
var pe = Object.getOwnPropertySymbols;
var Ge = Object.prototype.hasOwnProperty,
    Qe = Object.prototype.propertyIsEnumerable;
var qe = (e, n, t) => n in e ? Vt(e, n, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : e[n] = t,
    C = (e, n) => {
        for (var t in n || (n = {})) Ge.call(n, t) && qe(e, t, n[t]);
        if (pe)
            for (var t of pe(n)) Qe.call(n, t) && qe(e, t, n[t]);
        return e
    },
    Q = (e, n) => Nt(e, Ot(n));
var Se = (e, n) => {
    var t = {};
    for (var s in e) Ge.call(e, s) && n.indexOf(s) < 0 && (t[s] = e[s]);
    if (e != null && pe)
        for (var s of pe(e)) n.indexOf(s) < 0 && Qe.call(e, s) && (t[s] = e[s]);
    return t
};
import {
    r as i,
    i as jt,
    a as ct,
    _ as Ft,
    j as h,
    e as ie,
    f as rt
} from "./fg33krlcm0qyi6yw.js";
import {
    jN as z,
    pM as Ie,
    Ah as ye,
    sQ as Xe,
    nK as lt,
    uQ as Ve,
    Ai as Ne,
    uS as x,
    uR as dt,
    sI as Ce,
    Aj as Te,
    Ak as ut,
    nI as se,
    nE as R,
    i as Ut,
    sD as Y,
    sH as $,
    Al as $t,
    Am as ft,
    df as gt,
    An as Bt,
    Ao as X,
    Ap as Ht,
    Aq as Kt,
    sM as Je,
    sN as Ye,
    sL as Ze,
    sK as et,
    Ar as Wt,
    As as zt,
    At as qt,
    Au as Gt,
    Av as Qt,
    Aw as Xt,
    nH as mt,
    Ax as Jt,
    Ay as vt,
    Az as Yt,
    AA as Oe,
    AB as pt,
    AC as Zt,
    AD as en,
    nC as tn,
    rj as nn,
    AE as sn,
    eC as on,
    jM as an,
    jf as cn,
    jg as rn
} from "./k15yxxoybkkir2ou.js";
import {
    c as ln,
    $ as dn,
    C as un,
    _ as W,
    y as fn,
    W as gn,
    O as St,
    N as mn,
    I as vn,
    R as pn,
    Y as Sn,
    F as hn,
    S as he,
    d as Z,
    a as bn,
    e as yn,
    T as kn,
    L as Cn,
    u as Tn,
    g as _n
} from "./fz8xw1971c2kf2eb.js";
import {
    k_ as T,
    A7 as Mn,
    ec as En,
    m as wn,
    eX as ht,
    hh as _e,
    A8 as In,
    sb as xn,
    b2 as An,
    b as je,
    nm as bt,
    fP as Dn,
    o1 as Ln,
    ee as Pn,
    eh as Rn,
    eY as Vn,
    dF as ke,
    dH as Ae,
    e_ as Nn,
    o3 as De,
    hu as On,
    d as jn,
    nj as Fe,
    en as te,
    o0 as Fn,
    A9 as Un,
    P as tt,
    Aa as $n,
    of as Bn,
    fT as Hn,
    bX as yt,
    eW as Kn,
    dB as Wn,
    bg as Le,
    l as Pe,
    T as zn,
    c0 as Ue,
    i9 as qn,
    a9 as Gn
} from "./dykg4ktvbu3mhmdo.js";
import {
    b as Qn,
    R as P,
    M as Xn,
    C as J,
    T as be,
    c as Jn,
    d as Yn,
    a as ve,
    e as Zn,
    E as es
} from "./ftef8970ba1zoykr.js";
import {
    L as ts
} from "./iiok29s29bpdre61.js";
import {
    M as ns
} from "./k253gzle9qy7mdll.js";
import {
    M as ss,
    a as os,
    V as is,
    S as as
} from "./nm0so544a95lw6u3.js";
import {
    g as cs,
    D as le
} from "./cu0e6szsqsyduwov.js";
import {
    u as rs,
    s as ls
} from "./enojslb0kkkm419z.js";
import {
    V as ds
} from "./e9kbgh7j5o6g3dr6.js";

function us() {
    const e = z(),
        n = ln(),
        t = i.useCallback(() => {
            Ie.debug("disconnected from room"), ye(e)
        }, [e]),
        s = i.useCallback(r => {
            n.danger("Something went wrong", {
                toastId: "livekit_room_error"
            }), Ie.error("an error occurred within the room", r);
            const c = Xe(e.getState());
            T.voiceMode.error(Q(C({}, c), {
                error: r.message
            })), e.setState(a => {
                a.metrics.livekitConnectSuccessTime || (a.metrics.livekitConnectFailTime = new Date)
            }), ye(e)
        }, [n, e]),
        o = i.useCallback(r => {
            n.danger("Something went wrong", {
                toastId: "livekit_room_error",
                loggingTitle: "Encryption error",
                loggingDescription: r.message
            }), Ie.error("an encryption error occurred within the room", r);
            const c = Xe(e.getState());
            T.voiceMode.error(C({
                encryptionError: r.message,
                eventSource: "voice-session"
            }, c)), e.setState(a => {
                a.metrics.livekitConnectSuccessTime || (a.metrics.livekitConnectFailTime = new Date)
            }), ye(e)
        }, [n, e]);
    return {
        onDisconnected: t,
        onError: s,
        onEncryptionError: o
    }
}
const nt = async (e, n) => {
    var s;
    n || (n = await lt.getLocalDevices());
    const t = (s = n.find(o => o.deviceId === e)) == null ? void 0 : s.label;
    return t != null ? t : e
};

function kt(e) {
    var n, t, s = "";
    if (typeof e == "string" || typeof e == "number") s += e;
    else if (typeof e == "object")
        if (Array.isArray(e)) {
            var o = e.length;
            for (n = 0; n < o; n++) e[n] && (t = kt(e[n])) && (s && (s += " "), s += t)
        } else
            for (t in e) e[t] && (s && (s += " "), s += t);
    return s
}

function fs() {
    for (var e, n, t = 0, s = "", o = arguments.length; t < o; t++)(e = arguments[t]) && (n = kt(e)) && (s && (s += " "), s += n);
    return s
}

function gs(...e) {
    return (...n) => {
        for (const t of e)
            if (typeof t == "function") try {
                t(...n)
            } catch (s) {
                console.error(s)
            }
    }
}

function Ct(...e) {
    const n = C({}, e[0]);
    for (let t = 1; t < e.length; t++) {
        const s = e[t];
        for (const o in s) {
            const r = n[o],
                c = s[o];
            typeof r == "function" && typeof c == "function" && o[0] === "o" && o[1] === "n" && o.charCodeAt(2) >= 65 && o.charCodeAt(2) <= 90 ? n[o] = gs(r, c) : (o === "className" || o === "UNSAFE_className") && typeof r == "string" && typeof c == "string" ? n[o] = fs(r, c) : n[o] = c !== void 0 ? c : r
        }
    }
    return n
}
const ms = {
    connect: !0,
    audio: !1,
    video: !1
};

function vs(e) {
    const w = C(C({}, ms), e),
        {
            token: n,
            serverUrl: t,
            options: s,
            room: o,
            connectOptions: r,
            connect: c,
            audio: a,
            video: l,
            screen: f,
            onConnected: b,
            onDisconnected: v,
            onError: d,
            onMediaDeviceFailure: y,
            onEncryptionError: m,
            simulateParticipants: k
        } = w,
        _ = Se(w, ["token", "serverUrl", "options", "room", "connectOptions", "connect", "audio", "video", "screen", "onConnected", "onDisconnected", "onError", "onMediaDeviceFailure", "onEncryptionError", "simulateParticipants"]);
    s && o && W.warn("when using a manually created room, the options object will be ignored. set the desired options directly when creating the room instead.");
    const [u, L] = i.useState();
    i.useEffect(() => {
        L(o != null ? o : new Qn(s))
    }, [o]);
    const O = i.useMemo(() => {
        const {
            className: E
        } = fn();
        return Ct(_, {
            className: E
        })
    }, [_]);
    return i.useEffect(() => {
        if (!u) return;
        const E = () => {
                const H = u.localParticipant;
                W.debug("trying to publish local tracks"), Promise.all([H.setMicrophoneEnabled(!!a, typeof a != "boolean" ? a : void 0), H.setCameraEnabled(!!l, typeof l != "boolean" ? l : void 0), H.setScreenShareEnabled(!!f, typeof f != "boolean" ? f : void 0)]).catch(K => {
                    W.warn(K), d == null || d(K)
                })
            },
            B = H => {
                const K = Xn.getFailure(H);
                y == null || y(K)
            },
            V = H => {
                m == null || m(H)
            };
        return u.on(P.SignalConnected, E).on(P.MediaDevicesError, B).on(P.EncryptionError, V), () => {
            u.off(P.SignalConnected, E).off(P.MediaDevicesError, B).off(P.EncryptionError, V)
        }
    }, [u, a, l, f, d, m, y]), i.useEffect(() => {
        if (u) {
            if (k) {
                u.simulateParticipants({
                    participants: {
                        count: k
                    },
                    publish: {
                        audio: !0,
                        useRealTracks: !0
                    }
                });
                return
            }
            if (!n) {
                W.debug("no token yet");
                return
            }
            if (!t) {
                W.warn("no livekit url provided"), d == null || d(Error("no livekit url provided"));
                return
            }
            c ? (W.debug("connecting"), u.connect(t, n, r).catch(E => {
                W.warn(E), d == null || d(E)
            })) : (W.debug("disconnecting because connect is false"), u.disconnect())
        }
    }, [c, n, JSON.stringify(r), u, d, t, k]), i.useEffect(() => {
        if (!u) return;
        const E = B => {
            switch (B) {
                case J.Disconnected:
                    v && v();
                    break;
                case J.Connected:
                    b && b();
                    break
            }
        };
        return u.on(P.ConnectionStateChanged, E), () => {
            u.off(P.ConnectionStateChanged, E)
        }
    }, [n, b, v, u]), i.useEffect(() => {
        if (u) return () => {
            W.info("disconnecting on onmount"), u.disconnect()
        }
    }, [u]), {
        room: u,
        htmlProps: O
    }
}
const ps = i.forwardRef(function(e, n) {
    const {
        room: t,
        htmlProps: s
    } = vs(e);
    return i.createElement("div", C({
        ref: n
    }, s), t && i.createElement(dn.Provider, {
        value: t
    }, i.createElement(un.Provider, {
        value: e.featureFlags
    }, e.children)))
});

function Ss(e) {
    return e !== void 0
}

function hs(...e) {
    return Ct(...e.filter(Ss))
}

function bs(e, n = {}) {
    var k;
    const [t, s] = i.useState(pn(e)), [o, r] = i.useState(t == null ? void 0 : t.isMuted), [c, a] = i.useState(t == null ? void 0 : t.isSubscribed), [l, f] = i.useState(t == null ? void 0 : t.track), [b, v] = i.useState("landscape"), d = i.useRef(), {
        className: y,
        trackObserver: m
    } = i.useMemo(() => Sn(e), [(k = e.participant.sid) != null ? k : e.participant.identity, e.source, hn(e) && e.publication.trackSid]);
    return i.useEffect(() => {
        const _ = m.subscribe(u => {
            W.debug("update track", u), s(u), r(u == null ? void 0 : u.isMuted), a(u == null ? void 0 : u.isSubscribed), f(u == null ? void 0 : u.track)
        });
        return () => _ == null ? void 0 : _.unsubscribe()
    }, [m]), i.useEffect(() => {
        var _, u;
        return l && (d.current && l.detach(d.current), (_ = n.element) != null && _.current && !(St(e.participant) && (l == null ? void 0 : l.kind) === "audio") && l.attach(n.element.current)), d.current = (u = n.element) == null ? void 0 : u.current, () => {
            d.current && (l == null || l.detach(d.current))
        }
    }, [l, n.element]), i.useEffect(() => {
        var _, u;
        if (typeof((_ = t == null ? void 0 : t.dimensions) == null ? void 0 : _.width) == "number" && typeof((u = t == null ? void 0 : t.dimensions) == null ? void 0 : u.height) == "number") {
            const L = t.dimensions.width > t.dimensions.height ? "landscape" : "portrait";
            v(L)
        }
    }, [t]), {
        publication: t,
        isMuted: o,
        isSubscribed: c,
        track: l,
        elementProps: hs(n.props, C({
            className: y,
            "data-lk-local-participant": e.participant.isLocal,
            "data-lk-source": t == null ? void 0 : t.source
        }, (t == null ? void 0 : t.kind) === "video" && {
            "data-lk-orientation": b
        }))
    }
}
var ys = typeof he == "object" && he && he.Object === Object && he,
    ks = typeof self == "object" && self && self.Object === Object && self;
ys || ks || Function("return this")();
const Cs = i.forwardRef(function(c, r) {
    var a = c,
        {
            trackRef: e,
            onSubscriptionStatusChanged: n,
            volume: t,
            muted: s
        } = a,
        o = Se(a, ["trackRef", "onSubscriptionStatusChanged", "volume", "muted"]);
    const l = vn(e),
        f = i.useRef(null);
    i.useImperativeHandle(r, () => f.current);
    const {
        elementProps: b,
        isSubscribed: v,
        track: d,
        publication: y
    } = bs(l, {
        element: f,
        props: o
    });
    return i.useEffect(() => {
        n == null || n(!!v)
    }, [v, n]), i.useEffect(() => {
        d === void 0 || t === void 0 || (d instanceof Jn ? d.setVolume(t) : W.warn("Volume can only be set on remote audio tracks."))
    }, [t, d]), i.useEffect(() => {
        y === void 0 || s === void 0 || (y instanceof Yn ? y.setEnabled(!s) : W.warn("Can only call setEnabled on remote track publications."))
    }, [s, y, d]), i.createElement("audio", C({
        ref: f
    }, b))
});

function Ts({
    volume: e,
    muted: n
}) {
    const t = gn([be.Source.Microphone, be.Source.ScreenShareAudio, be.Source.Unknown], {
        updateOnlyOn: [],
        onlySubscribed: !0
    }).filter(s => !St(s.participant) && s.publication.kind === be.Kind.Audio);
    return i.createElement("div", {
        style: {
            display: "none"
        }
    }, t.map(s => i.createElement(Cs, {
        key: mn(s),
        trackRef: s,
        volume: e,
        muted: n
    })))
}

function _s() {
    Es(), ws(), Is(), Ms()
}

function Ms() {
    const {
        room: e,
        debug: n
    } = Z(), {
        cameraTrackState: t
    } = Ve(), o = Ne().video, r = i.useMemo(() => {
        const c = ["audioinput", "audiooutput"];
        return o && c.push("videoinput"), c
    }, [o]);
    i.useEffect(() => {
        function c() {
            Promise.all(r.map(async a => {
                if (t !== x.Started && a === "videoinput") return;
                const l = await lt.getLocalDevices(a),
                    f = e == null ? void 0 : e.getActiveDevice(a),
                    b = await Ce(a);
                if (!(f === (b == null ? void 0 : b.deviceId))) {
                    let d = null;
                    if (b ? d = b.deviceId : l[0] && (d = l[0].deviceId), d) {
                        const y = await nt(d, l),
                            m = await nt(f, l);
                        n("Current active ".concat(a, ' device "').concat(m, '" doesn\'t match default "').concat(y, '", switching to that instead')), await (e == null ? void 0 : e.switchActiveDevice(a, d)), T.defaultMediaDeviceChanged.success({
                            kind: a
                        })
                    }
                }
            })).catch(a => {
                T.defaultMediaDeviceChanged.failure(a)
            })
        }
        if (navigator) return navigator.mediaDevices.addEventListener("devicechange", c), () => {
            navigator.mediaDevices.removeEventListener("devicechange", c)
        }
    }, [e, n, r, t])
}

function Es() {
    const {
        room: e,
        debug: n
    } = Z(), t = e == null ? void 0 : e.getActiveDevice("audioinput"), s = e == null ? void 0 : e.getActiveDevice("audiooutput");
    i.useEffect(() => {
        async function o() {
            var f, b;
            const r = (f = await Ce("audioinput")) == null ? void 0 : f.deviceId,
                c = (b = await Ce("audiooutput")) == null ? void 0 : b.deviceId,
                a = async () => {
                    r && t !== r && (n("switching audio input to default"), await (e == null ? void 0 : e.switchActiveDevice("audioinput", r)))
                },
                l = async () => {
                    if (c && s !== c) {
                        n("switching audio output to default");
                        try {
                            await (e == null ? void 0 : e.switchActiveDevice("audiooutput", c))
                        } catch (v) {
                            n("failed to switch audio output", v)
                        }
                    }
                };
            await Promise.all([a(), l()])
        }
        o()
    }, [t, s, n, e])
}

function ws() {
    const {
        cameraTrackState: e,
        finalizeCameraState: n
    } = Ve(), {
        room: t,
        debug: s
    } = Z(), o = z(), c = Ne().video, a = c ? t == null ? void 0 : t.getActiveDevice("videoinput") : void 0;
    i.useEffect(() => {
        async function l() {
            if (t)
                if (e === x.Starting) try {
                    await t.localParticipant.setCameraEnabled(!0), Te(t, o, "camera_front", "live"), n(x.Started)
                } catch (f) {
                    n(x.Stopped)
                } else e === x.Stopping && (await t.localParticipant.setCameraEnabled(!1), Te(t, o, "camera_front", "ended"), n(x.Stopped))
        }
        l()
    }, [e, n, t, o]), i.useEffect(() => {
        async function l() {
            var v;
            const f = (v = await Ce("videoinput")) == null ? void 0 : v.deviceId;
            await (async () => {
                f && a !== f && (s("switching video input to default"), await (t == null ? void 0 : t.switchActiveDevice("videoinput", f)))
            })()
        }
        c && e === x.Started && l()
    }, [a, s, t, c, e])
}

function Is() {
    const {
        room: e
    } = Z(), {
        screenshareTrackState: n,
        finalizeScreenshareState: t
    } = dt(), s = z();
    i.useEffect(() => {
        async function o() {
            if (e)
                if (n === x.Starting) try {
                    await e.localParticipant.setScreenShareEnabled(!0, {
                        video: {
                            displaySurface: "monitor"
                        }
                    }), Te(e, s, "screen_share", "live"), t(x.Started)
                } catch (r) {
                    t(x.Stopped)
                } else n === x.Stopping && (await e.localParticipant.setScreenShareEnabled(!1), Te(e, s, "screen_share", "ended"), t(x.Stopped))
        }
        o()
    }, [e, n, t, s])
}
const xs = async ({
    serverThreadId: e,
    message: n
}) => {
    const t = await ut(Mn);
    if (t) switch (n.type) {
        case "full_chat_message":
            {
                const s = En(n.payload.message);t.handleResponse({
                    type: "message",
                    message: s,
                    conversationId: e
                });
                break
            }
        case se.ConversationUpdate:
            {
                t.handleConversationUpdate(n.payload.conversation_id);
                break
            }
    }
};

function Tt() {
    const {
        debug: e
    } = Z(), n = R(s => s.conversationId), t = wn();
    return i.useCallback(async ({
        optimistic: s,
        serverThreadId: o
    }) => {
        const r = o,
            c = n && !ht(n) ? n : void 0,
            a = r != null ? r : c;
        if (a) {
            e("refetch conversationId ".concat(a));
            try {
                await Ut(a)
            } catch (l) {
                const f = "Failed to update conversation";
                e(f, l), s || t.danger(f, {
                    toastId: "refetch_conversation"
                })
            }
        }
    }, [n, e, t])
}
var _t = (e => (e.EXCELLENT = "excellent", e.GOOD = "good", e.POOR = "poor", e.LOST = "lost", e.UNKNOWN = "unknown", e))(_t || {});
const As = {
    [ve.Excellent]: "excellent",
    [ve.Good]: "good",
    [ve.Poor]: "poor",
    [ve.Lost]: "lost",
    [ve.Unknown]: "unknown"
};

function Ds(e) {
    if (performance.getEntriesByName(Y.SessionCreateStart).length > 0) {
        performance.mark(Y.SessionCreateEnd);
        const t = performance.measure(Y.SessionCreateMeasure, Y.SessionCreateStart, Y.SessionCreateEnd).duration.toFixed(0);
        T.voiceMode.connect({
            durationMs: t
        }), e.metrics.sessionConnectedTime = new Date
    } else T.voiceMode.loggingError({
        reason: "No start mark found"
    })
}
const Ls = 5e3,
    Ps = 3e3,
    Me = e => {
        var _;
        const n = z(),
            {
                room: t
            } = Z(),
            s = R(u => u.disconnectPending),
            o = R(u => u.server.remoteState === $.Speaking),
            r = (_ = R(u => u.conversationId)) != null ? _ : void 0,
            c = R(u => u.earlyServerThreadId),
            a = _e(r),
            l = i.useRef(!1),
            f = Tt(),
            b = jt(),
            v = ct(),
            d = R(u => u.server.connectionState);
        l.current = o || l.current;
        const y = i.useCallback(async u => {
                clearTimeout(s), n.setState(O => {
                    O.disconnectPending = void 0
                }), t == null || t.disconnect(), await f({
                    serverThreadId: a
                }), n.setState($t);
                const L = a != null ? a : u;
                L ? ft(b, v, L) : c && l.current && gt("/c/".concat(c)), In(), e != null && e.refetchLater && window.setTimeout(() => {
                    f(!a && c ? {
                        serverThreadId: c,
                        optimistic: !0
                    } : {
                        serverThreadId: a
                    })
                }, Ps), xn.set(!1)
            }, [s, t, f, a, e == null ? void 0 : e.refetchLater, b, v, n, c]),
            m = l.current && !a && !c && d === J.Connected,
            k = i.useCallback(() => {
                n.setState(u => {
                    u.disconnectPending = window.setTimeout(y, Ls)
                })
            }, [y, n]);
        return {
            disconnectPending: s !== void 0,
            shouldDelayDisconnect: m,
            delayDisconnect: k,
            immediateDisconnect: y
        }
    };

function Rs() {
    var w, E, B;
    const e = je(),
        n = ct(),
        t = z(),
        {
            room: s,
            debug: o,
            decoder: r
        } = Z(),
        {
            disconnectPending: c,
            shouldDelayDisconnect: a,
            delayDisconnect: l,
            immediateDisconnect: f
        } = Me(),
        b = Tt(),
        v = i.useRef(!1),
        d = i.useRef(!1),
        y = i.useRef(!1),
        {
            session: m
        } = An(e),
        k = bt(),
        _ = (w = R(V => V.conversationId)) != null ? w : void 0,
        u = _e(_),
        L = Dn(V => V.lastVoiceSessionStartTime),
        O = Ln() === "livekit";
    i.useEffect(() => {
        const V = async I => {
                const {
                    new_state: g
                } = I;
                t.setState(p => {
                    (p.voiceMode !== "advanced" || g !== $.Thinking) && (p.server.remoteState = g)
                });
                const A = t.getState().metrics.sessionConnectedTime;
                if ((g === $.Listening || g === $.Speaking) && !(A !== void 0) && t.setState(p => {
                        Ds(p)
                    }), g === $.Listening && !v.current && L instanceof Date) {
                    const D = new Date().getTime() - L.getTime();
                    T.firstListeningLatency.success({
                        durationMs: D
                    }), v.current = !0
                }
                if (g === $.ListeningIntently) T.voiceSessionListeningIntently.stateChange();
                else if (g === $.Listening) {
                    if (t.setState(p => {
                            p.metrics.numListening += 1
                        }), !d.current) {
                        const p = t.getState().voiceSessionId;
                        T.voiceSessionFirstListening.stateChange({
                            voice_session_id: p != null ? p : "unknown"
                        }), d.current = !0
                    }
                    d.current = !0, T.voiceSessionListening.stateChange()
                } else if (g === $.Thinking) t.setState(p => {
                    p.metrics.numThinking += 1
                }), T.voiceSessionThinking.stateChange();
                else if (g === $.Speaking) {
                    if (t.setState(p => {
                            p.metrics.numSpeaking += 1
                        }), !y.current) {
                        const p = t.getState().voiceSessionId;
                        T.voiceSessionFirstSpeaking.stateChange({
                            voice_session_id: p != null ? p : "unknown"
                        }), y.current = !0
                    }
                    T.voiceSessionSpeaking.stateChange()
                } else g === $.Halted && T.voiceSessionHalted.stateChange()
            },
            H = async I => {
                t.setState(g => {
                    g.server.usage = I
                })
            },
            K = async I => {
                if (t.setState(g => {
                        g.server.toolUpdate = C({}, I)
                    }), I.update_type === "hangup") a ? l() : f();
                else if (I.update_type === "mute") {
                    const g = t.getState().dev.room,
                        A = g == null ? void 0 : g.localParticipant;
                    if (!g || !A) {
                        o("mute update received without active room/local participant");
                        return
                    }
                    if (!A.isMicrophoneEnabled) return;
                    try {
                        await A.setMicrophoneEnabled(!1), Bt(g, t, "microphone", "muted"), T.toggleMuteButton.click({
                            toggleTo: "mute",
                            source: "tool"
                        })
                    } catch (G) {
                        o("mute update failed to mute microphone", G), T.toggleMuteButton.error(G, {
                            toggleTo: "mute",
                            source: "tool"
                        })
                    }
                }
            },
            ae = async I => {
                var A, G, ge;
                let g;
                try {
                    g = JSON.parse(r.decode(I)), o("data received", g)
                } catch (p) {
                    o("error parsing data", p);
                    return
                }
                switch (t.setState(p => (p.server.messages.push(Q(C({}, g), {
                    timestamp: new Date,
                    source: "remote"
                })), p)), g.type) {
                    case se.StateUpdate:
                        {
                            o("state update", g.payload);
                            const {
                                new_state: p,
                                delay_s: D
                            } = g.payload;
                            [$.Thinking, $.Speaking].includes(p) && t.getState().server.turnContext.clear(),
                            p === $.Thinking && D && (o("".concat(s == null ? void 0 : s.name, " delay thinking state by ").concat(D, " seconds")), V({
                                new_state: $.ListeningIntently
                            }), await new Promise(M => setTimeout(M, D * 1e3))),
                            V(g.payload);
                            break
                        }
                    case se.ConversationUpdate:
                        {
                            o("conversation update", g.payload);
                            const p = t.getState().conversationId,
                                {
                                    conversation_id: D
                                } = g.payload;
                            if (p && ht(p)) {
                                if (t.setState(q => {
                                        q.conversationId = D
                                    }), k) break;
                                Pn.initThread({
                                    clientThreadId: p,
                                    conversationMode: {
                                        kind: Rn.PrimaryAssistant
                                    },
                                    userId: (A = m == null ? void 0 : m.user) == null ? void 0 : A.id,
                                    accountId: (G = m == null ? void 0 : m.account) == null ? void 0 : G.id
                                });
                                const M = t.getState().conversationId;
                                M != null && Vn(e, M, D), ft(gt, n, D);
                                const F = ke.getGizmoId(Ae(p));
                                Nn(n, F)
                            }
                            k || await b({
                                serverThreadId: D
                            }),
                            c && f(D);
                            break
                        }
                    case se.UsageUpdate:
                        H(g.payload);
                        break;
                    case se.ToolUpdate:
                        K(g.payload);
                        break;
                    case se.Performance:
                        {
                            const p = g.payload.metrics;t.setState(D => {
                                p.forEach(M => {
                                    M.name === "total_latency_ms" ? D.metrics.totalLatencyMs.push(M.ms) : M.name === "current_rtt_ms" && D.metrics.currentRttMs.push(M.ms)
                                })
                            });
                            break
                        }
                    case se.StartupTelemetry:
                        {
                            const [p] = g.payload.metrics,
                            D = g.payload.success;o("conversation loaded (startup telemetry)"),
                            t.setState(M => {
                                var F;
                                D ? (M.server.relayReady = !0, M.metrics.conversationStartSuccessTime = new Date) : M.metrics.conversationStartFailTime = new Date, M.metrics.conversationLatency = (F = p == null ? void 0 : p.ms) != null ? F : -1, g.payload.conversation_id && (M.earlyServerThreadId = g.payload.conversation_id)
                            }),
                            T.conversationStart.latency({
                                durationMs: (ge = p == null ? void 0 : p.ms) != null ? ge : -1,
                                success: D
                            });
                            break
                        }
                }
                xs({
                    serverThreadId: u,
                    message: g
                })
            },
            ue = (I, g) => {
                o("track published", I, g)
            },
            oe = () => {
                o("disconnected"), ye(t), T.voiceSessionDisconnected.stateChange()
            },
            j = (I, g) => {
                o("Connection quality changed for participant ".concat(g == null ? void 0 : g.identity, ": ").concat(I)), t.setState(A => {
                    A.server.voiceConnectionQuality = As[I]
                })
            },
            fe = () => {
                t.setState(I => {
                    o("WebRTC connection established"), I.metrics.livekitConnectSuccessTime || (I.metrics.livekitConnectSuccessTime = new Date), I.hasConnectedOnce = !0
                })
            };
        return s == null || s.on(P.Connected, fe), s == null || s.on(P.DataReceived, ae), s == null || s.on(P.TrackPublished, ue), s == null || s.on(P.ConnectionQualityChanged, j), s == null || s.on(P.Disconnected, oe), () => {
            s == null || s.off(P.Connected, fe), s == null || s.off(P.DataReceived, ae), s == null || s.off(P.TrackPublished, ue), s == null || s.off(P.ConnectionQualityChanged, j), s == null || s.off(P.Disconnected, oe)
        }
    }, [e, o, r, l, c, f, L, n, b, s, (E = m == null ? void 0 : m.account) == null ? void 0 : E.id, (B = m == null ? void 0 : m.user) == null ? void 0 : B.id, a, t, O, u, k])
}

function Vs() {
    Ns(), Os(), js(), Fs(), Us()
}

function Ns() {
    const {
        room: e
    } = Z(), n = z();
    i.useEffect(() => {
        n.setState(t => {
            t.dev.room = e
        })
    }, [e, n])
}

function Os() {
    const {
        getConnectionState: e
    } = bn(), n = e(), t = z();
    i.useEffect(() => {
        t.setState(s => {
            s.server.connectionState = n
        })
    }, [n, t])
}

function js() {
    const {
        room: e,
        debug: n,
        encoder: t
    } = Z(), s = z();
    i.useEffect(() => {
        const o = !!s.getState().server.actions;
        if (e && !o) {
            const r = async c => {
                n("publishing action", c);
                const a = {
                    type: se.ActionRequest,
                    payload: {
                        action: c
                    }
                };
                await e.localParticipant.publishData(t.encode(JSON.stringify(a)), {
                    reliable: !0
                }), s.setState(l => {
                    l.server.messages.push(Q(C({}, a), {
                        timestamp: new Date,
                        source: "local"
                    }))
                })
            };
            s.setState(c => {
                c.server.actions = {
                    [X.StartListeningIntently]: () => r(X.StartListeningIntently),
                    [X.StopListeningIntently]: () => r(X.StopListeningIntently),
                    [X.HaltAllActivity]: () => r(X.HaltAllActivity),
                    [X.ResumeListening]: () => r(X.ResumeListening),
                    [X.RelayMessage]: () => r(X.RelayMessage)
                }
            })
        }
    }, [e, n, t, s])
}

function Fs() {
    const n = z()(o => o.isVoiceModeActive),
        t = bt();
    i.useEffect(() => (De({
        isVoiceActive: n
    }), () => {
        De({
            isVoiceActive: !1
        })
    }), [n]);
    const s = je();
    i.useEffect(() => {
        if (n && !t) return On(s).limitActionGroups([])
    }, [s, n, t])
}

function Us() {
    const e = z(),
        {
            room: n,
            encoder: t
        } = Z(),
        s = i.useCallback(async o => {
            await (n == null ? void 0 : n.localParticipant.publishData(t.encode(JSON.stringify(o)), {
                reliable: !0
            })), e.setState(r => {
                r.server.messages.push(Q(C({}, o), {
                    timestamp: new Date,
                    source: "local"
                }))
            })
        }, [n, t, e]);
    i.useEffect(() => {
        e.setState(o => {
            o.server.turnContext.setPublisher(s)
        })
    }, [s, e])
}
const $s = i.memo(function() {
    return Rs(), Vs(), _s(), null
});

function Bs(e = {}) {
    const [n, t] = i.useState(!1), [s, o] = i.useState(!1), [r, c] = i.useState(!1);
    let a = yn().microphoneTrack;
    const [l, f] = i.useState();
    e.trackRef && (a = e.trackRef.publication);
    const b = i.useCallback(async v => {
        if (v) {
            const {
                KrispNoiseFilter: d,
                isKrispNoiseFilterSupported: y
            } = await Ft(async () => {
                const {
                    KrispNoiseFilter: m,
                    isKrispNoiseFilterSupported: k
                } = await
                import ("./iveu78zecg5unjye.js");
                return {
                    KrispNoiseFilter: m,
                    isKrispNoiseFilterSupported: k
                }
            }, []);
            if (!y()) {
                console.warn("Krisp noise filter is not supported in this browser");
                return
            }
            l || f(d(e.filterOptions))
        }
        t(d => (d !== v && o(!0), v))
    }, []);
    return i.useEffect(() => {
        var v;
        if (a && a.track instanceof Zn && l) {
            const d = a.track.getProcessor();
            d && d.name === "livekit-noise-filter" ? (o(!0), d.setEnabled(n).finally(() => {
                o(!1), c(n)
            })) : !d && n && (o(!0), (v = a == null ? void 0 : a.track) == null || v.setProcessor(l).then(() => l.setEnabled(n)).then(() => {
                c(!0)
            }).catch(y => {
                c(!1), console.error(y)
            }).finally(() => {
                o(!1)
            }))
        }
    }, [n, a, l]), {
        setNoiseFilterEnabled: b,
        isNoiseFilterEnabled: r,
        isNoiseFilterPending: s,
        processor: l
    }
}
const Hs = i.memo(function() {
        const {
            setNoiseFilterEnabled: n
        } = Bs();
        return i.useEffect(() => {
            n(!0)
        }, [n]), null
    }),
    Ks = () => jn(() => Fe()) === "transceiver",
    Ws = new ts(new URL("/cdn/assets/livekit-client.e2ee.worker-CnFd6278.js",
        import.meta.url), {
        type: "module"
    }),
    po = i.memo(function({
        children: n,
        executors: t
    }) {
        const s = i.useRef({
                keyProvider: new es
            }).current,
            [o, r] = i.useState(!1),
            {
                token: c,
                url: a,
                e2eeKey: l
            } = R(m => m.credentials),
            f = us(),
            b = R(m => m.isVoiceModeActive),
            v = R(m => {
                var k;
                return (k = m.audioInputDevice) == null ? void 0 : k.deviceId
            }),
            d = Ks(),
            y = d ? kn : Cn;
        return i.useEffect(() => {
            const m = c && a && l;
            !o && m ? s.keyProvider.setKey(l).then(() => {
                r(!0)
            }) : o && !m && r(!1)
        }, [c, a, l, o, s]), b ? h.jsx(ps, Q(C({}, f), {
            connect: !0,
            token: c != null ? c : void 0,
            serverUrl: a != null ? a : void 0,
            audio: {
                deviceId: {
                    ideal: v,
                    exact: v
                },
                noiseSuppression: !0,
                echoCancellation: !0
            },
            options: {
                e2ee: {
                    keyProvider: s.keyProvider,
                    worker: Ws
                }
            },
            children: h.jsxs(y, {
                children: [n, d || o && c && a ? h.jsx($s, {}) : null, o && c && a && h.jsx(Ts, {}), o && c && a && h.jsx(Hs, {}), !1, t]
            })
        })) : t
    }),
    de = new Map,
    Mt = 100,
    zs = Mt * .9;

function qs(e, n) {
    return e.trim().length === 0 ? (T.voiceMode.emptySessionId(n), !1) : de.has(e) ? (T.voiceMode.duplicateSessionId(n), !1) : (de.set(e, new Date().getTime()), ut(() => {
        if (de.size > Mt) {
            const t = Array.from(de.entries()).sort(([, o], [, r]) => o - r),
                s = Math.max(0, Math.floor(de.size - zs));
            for (let o = 0; o < s && o < t.length; o += 1) {
                const [r] = t[o];
                de.delete(r)
            }
        }
    }), !0)
}
const st = e => e.length > 0 ? Wt(e) : null,
    N = e => {
        var n;
        return (n = e == null ? void 0 : e.toISOString()) != null ? n : null
    };

function Gs({
    voiceStore: e
}) {
    const {
        metrics: n
    } = e.getState(), t = te(() => zt()), s = qt(), o = Gt(), r = Qt(), c = Xt(), a = te(() => mt()), l = Jt();
    return {
        session_create_time: N(a),
        get_status_sent_time: N(n.getStatusSentTime),
        get_status_success_time: N(n.getStatusSuccessTime),
        get_status_failed_time: N(n.getStatusFailedTime),
        proof_of_work_start_time: N(n.proofOfWorkStartTime),
        proof_of_work_end_time: N(n.proofOfWorkEndTime),
        get_token_sent_time: N(n.getTokenSentTime),
        get_token_success_time: N(n.getTokenSuccessTime),
        get_token_failed_time: N(n.getTokenFailedTime),
        conversation_start_success_time: N(n.conversationStartSuccessTime),
        conversation_start_fail_time: N(n.conversationStartFailTime),
        livekit_connect_time: N(n.livekitConnectTime),
        livekit_connect_success_time: N(n.livekitConnectSuccessTime),
        livekit_connect_fail_time: N(n.livekitConnectFailTime),
        session_connected_time: N(n.sessionConnectedTime),
        data_channel_open_time: N(n.dataChannelOpenTime),
        conversation_latency_ms: n.conversationLatency,
        get_token: C({}, t),
        peer_connection: C({}, s),
        pre_connect: C({}, o),
        connect: C({}, c),
        post_connect: C({}, r),
        microphone_permissions: C({}, l)
    }
}

function Qs({
    voiceStore: e,
    reason: n,
    voiceSessionId: t,
    sessionEndTime: s
}) {
    const {
        metrics: o
    } = e.getState();
    return te(() => Q(C(C(C(C({
        session_end_time: N(s),
        avg_total_latency_ms: st(o.totalLatencyMs),
        avg_rtt_ms: st(o.currentRttMs),
        num_of_turns_speaking: o.numSpeaking,
        num_of_turns_thinking: o.numThinking,
        num_of_turns_listening: o.numListening,
        protocol: Fe(),
        voice_session_id: t,
        reason: n,
        conversation_latency_ms: o.conversationLatency
    }, et().length > 0 ? {
        status_prefetch_failed_reasons: et().join(",")
    } : {}), Ze().length > 0 ? {
        status_prefetch_ineligible_reasons: Ze().join(",")
    } : {}), Ye() ? {
        status_cache_skipped_reason: Ye()
    } : {}), Je().length > 0 ? {
        status_prefetch_eligible_reasons: Je().join(",")
    } : {}), {
        microphone_permission_state: Kt(),
        surface: Ht()
    }))
}

function Xs({
    conversationId: e
}) {
    const {
        shouldDelayDisconnect: n,
        delayDisconnect: t,
        immediateDisconnect: s
    } = Me({
        refetchLater: !0
    }), {
        toggleMute: o
    } = vt(), r = _e(e), c = z();
    return i.useCallback(async a => {
        T.voiceSessionEndedByUser.click({
            reason: a
        }), Yt.set(!0);
        const l = new Date,
            f = te(() => Fn());
        De({
            voiceFeedbackThread: r,
            lastVoiceSessionEndTime: l
        });
        const b = cs({
                voiceStore: c,
                reason: a
            }),
            v = Qs({
                voiceStore: c,
                reason: a,
                voiceSessionId: f,
                sessionEndTime: l
            }),
            d = Gs({
                voiceStore: c
            }),
            {
                metrics: {
                    sessionConnectedTime: y,
                    numSpeaking: m,
                    numThinking: k,
                    numListening: _
                },
                server: {
                    connectionState: u
                }
            } = c.getState(),
            L = te(() => mt()),
            O = L == null ? void 0 : L.getTime(),
            w = l == null ? void 0 : l.getTime(),
            E = y == null ? void 0 : y.getTime(),
            B = O !== void 0 && w !== void 0 ? w - O : void 0,
            V = Q(C(C({}, v), d), {
                voice_mode: b,
                integratedMode: te(() => Un())
            });
        qs(f, V) && (tt.logStructuredEvent($n, {
            voiceMode: b,
            voiceSessionId: f || void 0,
            protocol: Fe(),
            sessionStartTsMs: O,
            sessionEndTsMs: w,
            sessionConnectedTsMs: E,
            sessionDurationMs: B,
            numOfTurnsSpeaking: m,
            numOfTurnsThinking: k,
            numOfTurnsListening: _,
            sessionEndReason: a,
            wasConnectedAtTimeOfExit: u === J.Connected,
            timeToVisuallyConnectedMs: te(() => pt()),
            visuallyConnectedTsMs: te(() => Oe())
        }), tt.logEvent("Voice Session End Summary", V)), Zt(), n ? (c.setState(K => {
            K.video = x.Stopping, K.screenshare = x.Stopping
        }), await o(), t()) : (await s(), en())
    }, [t, s, r, n, o, c])
}
const Et = "inline-flex items-center bg-transparent text-token-text-secondary hover:text-token-text-primary",
    ot = ({
        message: e,
        onClick: n,
        type: t
    }) => {
        const s = ie(),
            o = Bn() && Hn;
        switch (t) {
            case "microphone_denied":
                return o ? h.jsxs("a", {
                    href: "ms-settings:privacy-microphone",
                    className: Et,
                    children: [e, h.jsx(yt, {
                        className: "icon-sm ms-1"
                    })]
                }) : h.jsx(it, {
                    onClick: n,
                    message: e
                });
            case "disconnected":
                return h.jsxs("div", {
                    className: "inline-flex items-center",
                    children: [s.formatMessage(Re.lostConnection), h.jsx("button", {
                        onClick: n,
                        className: "ms-1",
                        children: h.jsx("strong", {
                            children: s.formatMessage(Re.retry)
                        })
                    })]
                });
            case "normal":
                return h.jsx(it, {
                    onClick: n,
                    message: e
                })
        }
    },
    it = ({
        message: e,
        onClick: n
    }) => {
        const t = ie();
        return h.jsxs("button", {
            onClick: n,
            className: Et,
            "aria-label": t.formatMessage(Re.openInfoModal),
            children: [e, h.jsx(yt, {
                className: "icon-sm ms-1"
            })]
        })
    },
    Re = rt({
        openInfoModal: {
            id: "hintMessage.openInfoModal",
            defaultMessage: "Open info modal"
        },
        retry: {
            id: "hintMessage.retry",
            defaultMessage: "Retry"
        },
        lostConnection: {
            id: "hintMessage.lostConnection",
            defaultMessage: "Lost connection."
        }
    });

function So({
    conversationId: e
}) {
    var Be, He, Ke, We, ze;
    const n = je(),
        t = ie(),
        s = z(),
        o = Xs({
            conversationId: e
        }),
        r = R(S => S.server.usage),
        c = R(S => S.server.voiceConnectionQuality),
        a = S => S === _t.LOST,
        l = tn(),
        {
            voiceName: f
        } = nn(),
        [b, v] = i.useState(!1),
        d = R(S => S.server.toolUpdate),
        [y, m] = i.useState(!1),
        [k, _] = i.useState(!0),
        u = rs(),
        [L, O] = i.useState(null),
        [w, E] = i.useState(null),
        [B, V] = i.useState(null),
        H = i.useRef(!1),
        K = _e(e),
        {
            startVoiceMode: ae,
            stopVoiceMode: ue,
            isVoiceModeActive: oe
        } = Tn(),
        j = R(S => S.server.connectionState),
        fe = i.useRef(!1),
        I = i.useRef(!1),
        {
            requestMicrophonePermissions: g,
            userDeclinedMicrophonePermissions: A,
            microphoneAvailable: G,
            microphoneLabel: ge
        } = sn(),
        p = i.useCallback(async () => {
            if (fe.current) return;
            fe.current = !0;
            let S;
            const U = await on();
            U === "prompt" ? S = le.IgnoredMicrophonePrompt : U === "denied" ? S = le.DeniedMicrophonePrompt : I.current ? S = le.LimitReached : j == null || j === J.Connecting || j === J.Reconnecting || j === J.SignalReconnecting ? S = le.UserAbort : j === J.Connected ? S = le.UserRequest : S = le.NetworkDisconnected, o(S)
        }, [j, o]);
    i.useEffect(() => {
        g()
    }, [g]), i.useEffect(() => {
        oe && A && (v(!1), V(null), O(t.formatMessage(xe.hint)), E({
            title: t.formatMessage(xe.title),
            description_markdown: t.formatMessage(xe.description_markdown),
            buttons: []
        }))
    }, [t, oe, A]), i.useEffect(() => {
        var S;
        if (G && !j && !H.current) {
            H.current = !0, O(null), E(null);
            const U = Ae(e);
            let ee;
            u !== void 0 ? (ee = u, ls.set(void 0)) : (ee = _n({
                serverThreadId: K,
                parentMessageId: (S = ke.getCurrentNode(U)) == null ? void 0 : S.id,
                isAdvancedMode: !0,
                eventSource: "composer_speech_button",
                clientThreadId: e,
                gizmoId: ke.getGizmoId(U)
            }), T.voiceSessionStarted.click({
                voice: f
            }), ee.requested_default_model = Kn(Wn(n, e)).id), ae(ee)
        }
    }, [n, j, e, G, K, ae, f, u]);
    const D = R(S => S.hasConnectedOnce),
        {
            reaching_limit_disclosure: M,
            exceed_limit_message: F
        } = (Be = r == null ? void 0 : r.rate_limit_message) != null ? Be : {},
        q = l == null ? void 0 : l.modes.find(S => S.mode === (l == null ? void 0 : l.default_voice_mode)),
        me = q == null ? void 0 : q.disclosure_message,
        ne = q == null ? void 0 : q.info_message,
        wt = i.useMemo(() => j !== J.Connected ? !0 : !!a(c), [j, c]),
        [It, $e] = i.useState(!1);
    i.useEffect(() => {
        j === J.Connected && $e(!1)
    }, [j]);
    const we = (We = (Ke = (He = M == null ? void 0 : M.hint) != null ? He : F == null ? void 0 : F.title) != null ? Ke : me == null ? void 0 : me.hint) != null ? We : null;
    i.useEffect(() => {
        var S, U;
        q && !A && O((U = (S = q.disclosure_message) == null ? void 0 : S.hint) != null ? U : null)
    }, [q, A]), i.useEffect(() => {
        const S = d == null ? void 0 : d.text;
        let U, ee, re;
        return S && (_(!1), U = setTimeout(() => {
            m(!0), ee = setTimeout(() => {
                m(!1), re = setTimeout(() => {
                    _(!0), s.setState(Rt => {
                        Rt.server.toolUpdate = null
                    })
                }, 750)
            }, 3e3)
        }, 750)), () => {
            clearTimeout(U), clearTimeout(ee), clearTimeout(re)
        }
    }, [d, s]), i.useEffect(() => {
        if (!A) {
            if (we && O(we), F && oe) {
                I.current = !0, ue();
                const S = {
                    title: F.title,
                    description_markdown: F.description_markdown,
                    buttons: F.buttons
                };
                b ? V(S) : (E(S), v(!0));
                const U = F.buttons.some(re => re.action === "upgrade_to_plus"),
                    ee = F.buttons.some(re => re.action === "upgrade_to_pro");
                T.rateLimitReached.success({
                    upgrade_to_plus: U,
                    upgrade_to_pro: ee
                })
            } else if (!w) {
                const S = M != null ? M : me;
                S && E({
                    title: S.title,
                    description_markdown: S.message_markdown,
                    buttons: S.buttons
                })
            }
        }
    }, [me, F, we, b, oe, w, M, ue, A, ne]);
    const xt = i.useCallback(() => {
            B && (E(B), V(null)), v(!0)
        }, [B]),
        At = i.useCallback(() => {
            ne && E({
                title: ne.title,
                description_markdown: ne.message_markdown,
                buttons: ne.buttons
            }), v(!0)
        }, [ne]),
        Dt = i.useCallback(() => {
            v(!1)
        }, []),
        Lt = R(S => S.voiceMode),
        Pt = async () => {
            cn(rn.Retry);
            try {
                O(null), $e(!0), await ae({
                    conversation_id: K,
                    eventSource: "lost_connection_hint_message",
                    voice_mode: Lt,
                    voice: f,
                    clientThreadId: e,
                    gizmo_id: ke.getGizmoId(Ae(e)),
                    skipCacheReason: "lost-connection-retry",
                    forceDisconnect: !0
                })
            } catch (S) {
                const U = S instanceof Error ? S.message : String(S);
                T.voiceMode.error({
                    error: U,
                    eventSource: "lost_connection_hint_message"
                })
            }
        };
    let ce = "normal";
    return A ? ce = "microphone_denied" : L ? ce = "normal" : wt && !It && D && (ce = "disconnected"), h.jsxs("div", {
        className: "flex w-full flex-col items-center",
        children: [h.jsxs("div", {
            className: "text-token-text-secondary relative mb-6 flex min-h-5 w-full items-center justify-center text-xs",
            children: [(d == null ? void 0 : d.text) && h.jsx(Le.div, {
                initial: {
                    opacity: 0
                },
                animate: {
                    opacity: y ? 1 : 0
                },
                transition: {
                    duration: .5
                },
                style: {
                    position: "absolute",
                    left: "50%",
                    transform: "translateX(-50%)",
                    textAlign: "center"
                },
                children: h.jsxs("div", {
                    className: "flex items-center",
                    children: [(d == null ? void 0 : d.text) && h.jsx(ns, {
                        className: "icon-sm me-1"
                    }), d == null ? void 0 : d.text]
                })
            }), h.jsx(Le.div, {
                initial: {
                    opacity: 0
                },
                animate: {
                    opacity: k ? 1 : 0
                },
                transition: {
                    duration: .5
                },
                style: {
                    position: "absolute",
                    left: "50%",
                    transform: "translateX(-50%)",
                    textAlign: "center",
                    pointerEvents: d != null && d.text ? "none" : "auto",
                    cursor: d != null && d.text ? "default" : "pointer"
                },
                children: h.jsx("div", {
                    className: "flex items-center",
                    children: L || ce === "disconnected" ? h.jsx(ot, {
                        type: ce,
                        message: L,
                        onClick: ce === "disconnected" ? Pt : xt
                    }) : ne ? h.jsx(ot, {
                        type: "normal",
                        message: ne.title,
                        onClick: At
                    }) : null
                })
            })]
        }), h.jsxs("div", {
            className: Pe("flex flex-row items-center gap-6", "rounded-full px-3 py-1", "transition-width duration-200 ease-in-out"),
            children: [h.jsx(at, {
                capability: "video",
                children: h.jsx(Js, {})
            }), h.jsx(Ys, {
                hideTooltip: A,
                microphoneLabel: ge,
                isMicrophoneEnabled: G
            }), h.jsx(at, {
                capability: "screenshare",
                children: h.jsx(Zs, {})
            }), h.jsx(eo, {
                onClick: p
            })]
        }), h.jsx(ds, {
            conversationId: e,
            isOpen: b,
            onClose: Dt,
            title: w == null ? void 0 : w.title,
            description_markdown: w == null ? void 0 : w.description_markdown,
            buttons: (ze = w == null ? void 0 : w.buttons) != null ? ze : []
        }), !1]
    })
}

function at({
    children: e,
    capability: n
}) {
    return Ne()[n] ? e : null
}

function Js() {
    const {
        cameraTrackState: e,
        toggleCamera: n
    } = Ve(), t = ie();
    let s = null;
    const o = [x.Starting, x.Stopping].includes(e),
        r = e === x.Started;
    o ? s = Ue : s = is;
    const c = r ? "bg-gray-900 hover:bg-gray-800 active:bg-gray-700" : "bg-black/5 hover:bg-black/10 active:bg-black/20 dark:bg-[rgba(255,255,255,0.04)] dark:hover:bg-white/5 dark:active:bg-white/10",
        a = r ? "text-token-main-surface-primary" : void 0,
        l = t.formatMessage({
            id: "SRVwhB",
            defaultMessage: "Toggle video"
        });
    return h.jsx(Ee, {
        "aria-label": l,
        onClick: () => n("ControlButton"),
        disabled: o,
        icon: s,
        className: c,
        iconColor: a
    })
}

function Ys({
    hideTooltip: e,
    microphoneLabel: n,
    isMicrophoneEnabled: t
}) {
    const {
        isMuting: s,
        toggleMute: o
    } = vt(), r = ie(), {
        disconnectPending: c
    } = Me(), a = !!R(m => {
        var k;
        return (k = m.dev.room) == null ? void 0 : k.localParticipant.isMicrophoneEnabled
    }), l = !!R(m => {
        var k;
        return (k = m.dev.room) == null ? void 0 : k.localParticipant.isMicrophoneForceMuted
    }), f = t && a, b = f ? ss : os, v = f ? "bg-black/5 hover:bg-black/10 active:bg-black/20 dark:bg-[rgba(255,255,255,0.04)] dark:hover:bg-white/5 dark:active:bg-white/10" : "bg-red-500/10 hover:bg-red-500/15 active:bg-red-500/20 dark:bg-red-500/10 dark:hover:bg-red-500/15 dark:active:bg-red-500/20", d = f ? void 0 : "text-danger", y = l ? r.formatMessage({
        id: "bVgTcp",
        defaultMessage: "Microphone muted in system settings / hardware switch"
    }) : f ? r.formatMessage({
        id: "FI36QI",
        defaultMessage: "Turn off microphone"
    }) : r.formatMessage({
        id: "j3oMt1",
        defaultMessage: "Turn on microphone"
    });
    return h.jsx(Ee, {
        "aria-label": y,
        onClick: o,
        icon: b,
        disabled: s || c || l,
        className: v,
        iconColor: d,
        tooltipPrimaryLabel: !e && n ? y : "",
        tooltipSecondaryLabel: n
    })
}

function Zs() {
    const {
        screenshareTrackState: e,
        toggleScreenShare: n
    } = dt(), t = ie();
    let s = null;
    const o = [x.Starting, x.Stopping].includes(e),
        r = e === x.Started;
    o ? s = Ue : s = as;
    const c = r ? "bg-gray-900 hover:bg-gray-800 active:bg-gray-700" : "bg-black/5 hover:bg-black/10 active:bg-black/20 dark:bg-[rgba(255,255,255,0.04)] dark:hover:bg-white/5 dark:active:bg-white/10",
        a = r ? "text-token-main-surface-primary" : void 0,
        l = t.formatMessage({
            id: "ShdqyW",
            defaultMessage: "Toggle screenshare"
        });
    return h.jsx(Ee, {
        "aria-label": l,
        onClick: () => n("ControlButton"),
        disabled: o,
        icon: s,
        className: c,
        iconColor: a
    })
}

function eo({
    className: e,
    onClick: n
}) {
    const t = ie(),
        {
            disconnectPending: s
        } = Me(),
        o = "bg-black/5 hover:bg-black/10 active:bg-black/20 dark:bg-[rgba(255,255,255,0.04)] dark:hover:bg-white/5 dark:active:bg-white/10",
        r = t.formatMessage({
            id: "9Mto0a",
            defaultMessage: "End"
        });
    return h.jsx(Ee, {
        disabled: s,
        onClick: n,
        icon: s ? Ue : qn,
        className: e != null ? e : o,
        "aria-label": t.formatMessage({
            id: "7/8k4Y",
            defaultMessage: "End voice mode"
        }),
        tooltipPrimaryLabel: r
    })
}

function Ee(e) {
    const _ = e,
        {
            icon: n,
            disabled: t,
            className: s,
            iconColor: o = "fill-token-text-primary group-hover:fill-token-text-inverted",
            iconSize: r = "icon-xl",
            buttonSize: c = "h-16 w-16",
            tooltipPrimaryLabel: a,
            tooltipSecondaryLabel: l
        } = _,
        f = Se(_, ["icon", "disabled", "className", "iconColor", "iconSize", "buttonSize", "tooltipPrimaryLabel", "tooltipSecondaryLabel"]),
        [b, v] = i.useState(!1),
        d = i.useRef(void 0),
        y = i.useCallback(() => {
            clearTimeout(d.current);
            const u = window.setTimeout(() => {
                v(!0)
            }, an);
            d.current = u
        }, []),
        m = i.useCallback(() => {
            clearTimeout(d.current), v(!1)
        }, []);
    i.useEffect(() => () => {
        clearTimeout(d.current)
    }, []);
    const k = h.jsx(no, Q(C({
        className: Pe(s, c, "group text-token-text-primary hover:text-token-text-secondary overflow-hidden rounded-full border-none p-0.5 transition-colors duration-200 ease-in-out"),
        disabled: t
    }, f), {
        children: h.jsx(n, {
            className: Pe(r, o)
        })
    }));
    return a ? h.jsx(zn, {
        sideOffset: 14,
        label: a,
        secondaryLabel: l,
        contentClassName: "flex flex-col items-center justify-center",
        className: "flex",
        open: b,
        side: "top",
        children: h.jsx("span", {
            onPointerEnter: y,
            onPointerLeave: m,
            children: k
        })
    }) : k
}
const to = i.forwardRef(function(n, t) {
        return h.jsx(Gn, Q(C({}, n), {
            ref: t
        }))
    }),
    no = Le.create(to),
    xe = rt({
        hint: {
            id: "micMessages.hint",
            defaultMessage: "Enable microphone access in Settings"
        },
        title: {
            id: "micMessages.title",
            defaultMessage: "Microphone access required"
        },
        description_markdown: {
            id: "micMessages.description_markdown",
            defaultMessage: "To use voice mode, you'll need to enable your microphone and try again."
        }
    });

function ho() {
    if (performance.getEntriesByName(Y.SessionCreateStart).length > 0) {
        performance.mark(Y.VisuallyConnectedEnd);
        const n = performance.measure(Y.VisuallyConnectedMeasure, Y.SessionCreateStart, Y.VisuallyConnectedEnd);
        T.visuallyConnected.timing({
            durationMs: n.duration
        }), pt.set(n.duration), Oe.set(Date.now())
    } else T.visuallyConnected.loggingError({
        reason: "No start mark found"
    })
}

function bo() {
    return te(() => Oe()) !== void 0
}
export {
    Ee as C, eo as S, po as V, at as W, Xs as a, So as b, _t as c, Me as d, Gs as g, bo as i, ho as m, Ks as u
};
//# sourceMappingURL=s8d7t6m9lmrag91y.js.map