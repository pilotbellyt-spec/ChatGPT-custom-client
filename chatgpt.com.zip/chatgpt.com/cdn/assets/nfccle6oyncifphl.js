var kt = Object.defineProperty,
    dt = Object.defineProperties;
var bt = Object.getOwnPropertyDescriptors;
var qn = Object.getOwnPropertySymbols;
var St = Object.prototype.hasOwnProperty,
    yt = Object.prototype.propertyIsEnumerable;
var Rn = (n, r, t) => r in n ? kt(n, r, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : n[r] = t,
    Cn = (n, r) => {
        for (var t in r || (r = {})) St.call(r, t) && Rn(n, t, r[t]);
        if (qn)
            for (var t of qn(r)) yt.call(r, t) && Rn(n, t, r[t]);
        return n
    },
    jn = (n, r) => dt(n, bt(r));
import {
    a as Kn,
    t as It,
    d as wt,
    b as zt
} from "./hu1bt0oauegdhua6.js";
import {
    s as yn
} from "./h1em0bjkpkjv8ykw.js";
const nn = on(/[A-Za-z]/),
    v = on(/[\dA-Za-z]/),
    Ct = on(/[#-'*+\--9=?A-Z^-~]/);

function Fn(n) {
    return n !== null && (n < 32 || n === 127)
}
const On = on(/\d/),
    Et = on(/[\dA-Fa-f]/),
    Tt = on(/[!-/:-@[-`{-~]/);

function w(n) {
    return n !== null && n < -2
}

function Y(n) {
    return n !== null && (n < 0 || n === 32)
}

function F(n) {
    return n === -2 || n === -1 || n === 32
}
const Ft = on(new RegExp("\\p{P}|\\p{S}", "u")),
    Ot = on(/\s/);

function on(n) {
    return r;

    function r(t) {
        return t !== null && t > -1 && n.test(String.fromCharCode(t))
    }
}

function _(n, r, t, e) {
    const u = e ? e - 1 : Number.POSITIVE_INFINITY;
    let i = 0;
    return a;

    function a(m) {
        return F(m) ? (n.enter(t), l(m)) : r(m)
    }

    function l(m) {
        return F(m) && i++ < u ? (n.consume(m), l) : (n.exit(t), r(m))
    }
}

function Sn(n, r) {
    let t;
    return e;

    function e(u) {
        return w(u) ? (n.enter("lineEnding"), n.consume(u), n.exit("lineEnding"), t = !0, e) : F(u) ? _(n, e, t ? "linePrefix" : "lineSuffix")(u) : r(u)
    }
}

function gn(n) {
    return n.replace(/[\t\n\r ]+/g, " ").replace(/^ | $/g, "").toLowerCase().toUpperCase()
}

function an(n, r, t, e) {
    const u = n.length;
    let i = 0,
        a;
    if (r < 0 ? r = -r > u ? 0 : u + r : r = r > u ? u : r, t = t > 0 ? t : 0, e.length < 1e4) a = Array.from(e), a.unshift(r, t), n.splice(...a);
    else
        for (t && n.splice(r, t); i < e.length;) a = e.slice(i, i + 1e4), a.unshift(r, 0), n.splice(...a), i += 1e4, r += 1e4
}

function Z(n, r) {
    return n.length > 0 ? (an(n, n.length, 0, r), n) : r
}
const Hn = {}.hasOwnProperty;

function Bt(n) {
    const r = {};
    let t = -1;
    for (; ++t < n.length;) At(r, n[t]);
    return r
}

function At(n, r) {
    let t;
    for (t in r) {
        const u = (Hn.call(n, t) ? n[t] : void 0) || (n[t] = {}),
            i = r[t];
        let a;
        if (i)
            for (a in i) {
                Hn.call(u, a) || (u[a] = []);
                const l = i[a];
                Pt(u[a], Array.isArray(l) ? l : l ? [l] : [])
            }
    }
}

function Pt(n, r) {
    let t = -1;
    const e = [];
    for (; ++t < r.length;)(r[t].add === "after" ? n : e).push(r[t]);
    an(n, 0, 0, e)
}

function Vn(n) {
    if (n === null || Y(n) || Ot(n)) return 1;
    if (Ft(n)) return 2
}

function An(n, r, t) {
    const e = [];
    let u = -1;
    for (; ++u < n.length;) {
        const i = n[u].resolveAll;
        i && !e.includes(i) && (r = i(r, t), e.push(i))
    }
    return r
}
const Bn = {
    name: "attention",
    tokenize: Lt,
    resolveAll: _t
};

function _t(n, r) {
    let t = -1,
        e, u, i, a, l, m, h, f;
    for (; ++t < n.length;)
        if (n[t][0] === "enter" && n[t][1].type === "attentionSequence" && n[t][1]._close) {
            for (e = t; e--;)
                if (n[e][0] === "exit" && n[e][1].type === "attentionSequence" && n[e][1]._open && r.sliceSerialize(n[e][1]).charCodeAt(0) === r.sliceSerialize(n[t][1]).charCodeAt(0)) {
                    if ((n[e][1]._close || n[t][1]._open) && (n[t][1].end.offset - n[t][1].start.offset) % 3 && !((n[e][1].end.offset - n[e][1].start.offset + n[t][1].end.offset - n[t][1].start.offset) % 3)) continue;
                    m = n[e][1].end.offset - n[e][1].start.offset > 1 && n[t][1].end.offset - n[t][1].start.offset > 1 ? 2 : 1;
                    const p = Object.assign({}, n[e][1].end),
                        g = Object.assign({}, n[t][1].start);
                    Qn(p, -m), Qn(g, m), a = {
                        type: m > 1 ? "strongSequence" : "emphasisSequence",
                        start: p,
                        end: Object.assign({}, n[e][1].end)
                    }, l = {
                        type: m > 1 ? "strongSequence" : "emphasisSequence",
                        start: Object.assign({}, n[t][1].start),
                        end: g
                    }, i = {
                        type: m > 1 ? "strongText" : "emphasisText",
                        start: Object.assign({}, n[e][1].end),
                        end: Object.assign({}, n[t][1].start)
                    }, u = {
                        type: m > 1 ? "strong" : "emphasis",
                        start: Object.assign({}, a.start),
                        end: Object.assign({}, l.end)
                    }, n[e][1].end = Object.assign({}, a.start), n[t][1].start = Object.assign({}, l.end), h = [], n[e][1].end.offset - n[e][1].start.offset && (h = Z(h, [
                        ["enter", n[e][1], r],
                        ["exit", n[e][1], r]
                    ])), h = Z(h, [
                        ["enter", u, r],
                        ["enter", a, r],
                        ["exit", a, r],
                        ["enter", i, r]
                    ]), h = Z(h, An(r.parser.constructs.insideSpan.null, n.slice(e + 1, t), r)), h = Z(h, [
                        ["exit", i, r],
                        ["enter", l, r],
                        ["exit", l, r],
                        ["exit", u, r]
                    ]), n[t][1].end.offset - n[t][1].start.offset ? (f = 2, h = Z(h, [
                        ["enter", n[t][1], r],
                        ["exit", n[t][1], r]
                    ])) : f = 0, an(n, e - 1, t - e + 3, h), t = e + h.length - f - 2;
                    break
                }
        }
    for (t = -1; ++t < n.length;) n[t][1].type === "attentionSequence" && (n[t][1].type = "data");
    return n
}

function Lt(n, r) {
    const t = this.parser.constructs.attentionMarkers.null,
        e = this.previous,
        u = Vn(e);
    let i;
    return a;

    function a(m) {
        return i = m, n.enter("attentionSequence"), l(m)
    }

    function l(m) {
        if (m === i) return n.consume(m), l;
        const h = n.exit("attentionSequence"),
            f = Vn(m),
            p = !f || f === 2 && u || t.includes(m),
            g = !u || u === 2 && f || t.includes(e);
        return h._open = !!(i === 42 ? p : p && (u || !g)), h._close = !!(i === 42 ? g : g && (f || !p)), r(m)
    }
}

function Qn(n, r) {
    n.column += r, n.offset += r, n._bufferIndex += r
}
const Mt = {
    name: "autolink",
    tokenize: Nt
};

function Nt(n, r, t) {
    let e = 0;
    return u;

    function u(c) {
        return n.enter("autolink"), n.enter("autolinkMarker"), n.consume(c), n.exit("autolinkMarker"), n.enter("autolinkProtocol"), i
    }

    function i(c) {
        return nn(c) ? (n.consume(c), a) : c === 64 ? t(c) : h(c)
    }

    function a(c) {
        return c === 43 || c === 45 || c === 46 || v(c) ? (e = 1, l(c)) : h(c)
    }

    function l(c) {
        return c === 58 ? (n.consume(c), e = 0, m) : (c === 43 || c === 45 || c === 46 || v(c)) && e++ < 32 ? (n.consume(c), l) : (e = 0, h(c))
    }

    function m(c) {
        return c === 62 ? (n.exit("autolinkProtocol"), n.enter("autolinkMarker"), n.consume(c), n.exit("autolinkMarker"), n.exit("autolink"), r) : c === null || c === 32 || c === 60 || Fn(c) ? t(c) : (n.consume(c), m)
    }

    function h(c) {
        return c === 64 ? (n.consume(c), f) : Ct(c) ? (n.consume(c), h) : t(c)
    }

    function f(c) {
        return v(c) ? p(c) : t(c)
    }

    function p(c) {
        return c === 46 ? (n.consume(c), e = 0, f) : c === 62 ? (n.exit("autolinkProtocol").type = "autolinkEmail", n.enter("autolinkMarker"), n.consume(c), n.exit("autolinkMarker"), n.exit("autolink"), r) : g(c)
    }

    function g(c) {
        if ((c === 45 || v(c)) && e++ < 63) {
            const T = c === 45 ? g : p;
            return n.consume(c), T
        }
        return t(c)
    }
}
const wn = {
    tokenize: Dt,
    partial: !0
};

function Dt(n, r, t) {
    return e;

    function e(i) {
        return F(i) ? _(n, u, "linePrefix")(i) : u(i)
    }

    function u(i) {
        return i === null || w(i) ? r(i) : t(i)
    }
}
const Xn = {
    name: "blockQuote",
    tokenize: qt,
    continuation: {
        tokenize: Rt
    },
    exit: jt
};

function qt(n, r, t) {
    const e = this;
    return u;

    function u(a) {
        if (a === 62) {
            const l = e.containerState;
            return l.open || (n.enter("blockQuote", {
                _container: !0
            }), l.open = !0), n.enter("blockQuotePrefix"), n.enter("blockQuoteMarker"), n.consume(a), n.exit("blockQuoteMarker"), i
        }
        return t(a)
    }

    function i(a) {
        return F(a) ? (n.enter("blockQuotePrefixWhitespace"), n.consume(a), n.exit("blockQuotePrefixWhitespace"), n.exit("blockQuotePrefix"), r) : (n.exit("blockQuotePrefix"), r(a))
    }
}

function Rt(n, r, t) {
    const e = this;
    return u;

    function u(a) {
        return F(a) ? _(n, i, "linePrefix", e.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(a) : i(a)
    }

    function i(a) {
        return n.attempt(Xn, r, t)(a)
    }
}

function jt(n) {
    n.exit("blockQuote")
}
const vn = {
    name: "characterEscape",
    tokenize: Ht
};

function Ht(n, r, t) {
    return e;

    function e(i) {
        return n.enter("characterEscape"), n.enter("escapeMarker"), n.consume(i), n.exit("escapeMarker"), u
    }

    function u(i) {
        return Tt(i) ? (n.enter("characterEscapeValue"), n.consume(i), n.exit("characterEscapeValue"), n.exit("characterEscape"), r) : t(i)
    }
}
const nt = {
    name: "characterReference",
    tokenize: Vt
};

function Vt(n, r, t) {
    const e = this;
    let u = 0,
        i, a;
    return l;

    function l(p) {
        return n.enter("characterReference"), n.enter("characterReferenceMarker"), n.consume(p), n.exit("characterReferenceMarker"), m
    }

    function m(p) {
        return p === 35 ? (n.enter("characterReferenceMarkerNumeric"), n.consume(p), n.exit("characterReferenceMarkerNumeric"), h) : (n.enter("characterReferenceValue"), i = 31, a = v, f(p))
    }

    function h(p) {
        return p === 88 || p === 120 ? (n.enter("characterReferenceMarkerHexadecimal"), n.consume(p), n.exit("characterReferenceMarkerHexadecimal"), n.enter("characterReferenceValue"), i = 6, a = Et, f) : (n.enter("characterReferenceValue"), i = 7, a = On, f(p))
    }

    function f(p) {
        if (p === 59 && u) {
            const g = n.exit("characterReferenceValue");
            return a === v && !Kn(e.sliceSerialize(g)) ? t(p) : (n.enter("characterReferenceMarker"), n.consume(p), n.exit("characterReferenceMarker"), n.exit("characterReference"), r)
        }
        return a(p) && u++ < i ? (n.consume(p), f) : t(p)
    }
}
const Un = {
        tokenize: Ut,
        partial: !0
    },
    Wn = {
        name: "codeFenced",
        tokenize: Qt,
        concrete: !0
    };

function Qt(n, r, t) {
    const e = this,
        u = {
            tokenize: D,
            partial: !0
        };
    let i = 0,
        a = 0,
        l;
    return m;

    function m(k) {
        return h(k)
    }

    function h(k) {
        const B = e.events[e.events.length - 1];
        return i = B && B[1].type === "linePrefix" ? B[2].sliceSerialize(B[1], !0).length : 0, l = k, n.enter("codeFenced"), n.enter("codeFencedFence"), n.enter("codeFencedFenceSequence"), f(k)
    }

    function f(k) {
        return k === l ? (a++, n.consume(k), f) : a < 3 ? t(k) : (n.exit("codeFencedFenceSequence"), F(k) ? _(n, p, "whitespace")(k) : p(k))
    }

    function p(k) {
        return k === null || w(k) ? (n.exit("codeFencedFence"), e.interrupt ? r(k) : n.check(Un, O, M)(k)) : (n.enter("codeFencedFenceInfo"), n.enter("chunkString", {
            contentType: "string"
        }), g(k))
    }

    function g(k) {
        return k === null || w(k) ? (n.exit("chunkString"), n.exit("codeFencedFenceInfo"), p(k)) : F(k) ? (n.exit("chunkString"), n.exit("codeFencedFenceInfo"), _(n, c, "whitespace")(k)) : k === 96 && k === l ? t(k) : (n.consume(k), g)
    }

    function c(k) {
        return k === null || w(k) ? p(k) : (n.enter("codeFencedFenceMeta"), n.enter("chunkString", {
            contentType: "string"
        }), T(k))
    }

    function T(k) {
        return k === null || w(k) ? (n.exit("chunkString"), n.exit("codeFencedFenceMeta"), p(k)) : k === 96 && k === l ? t(k) : (n.consume(k), T)
    }

    function O(k) {
        return n.attempt(u, M, q)(k)
    }

    function q(k) {
        return n.enter("lineEnding"), n.consume(k), n.exit("lineEnding"), b
    }

    function b(k) {
        return i > 0 && F(k) ? _(n, R, "linePrefix", i + 1)(k) : R(k)
    }

    function R(k) {
        return k === null || w(k) ? n.check(Un, O, M)(k) : (n.enter("codeFlowValue"), S(k))
    }

    function S(k) {
        return k === null || w(k) ? (n.exit("codeFlowValue"), R(k)) : (n.consume(k), S)
    }

    function M(k) {
        return n.exit("codeFenced"), r(k)
    }

    function D(k, B, j) {
        let P = 0;
        return L;

        function L(E) {
            return k.enter("lineEnding"), k.consume(E), k.exit("lineEnding"), I
        }

        function I(E) {
            return k.enter("codeFencedFence"), F(E) ? _(k, y, "linePrefix", e.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(E) : y(E)
        }

        function y(E) {
            return E === l ? (k.enter("codeFencedFenceSequence"), N(E)) : j(E)
        }

        function N(E) {
            return E === l ? (P++, k.consume(E), N) : P >= a ? (k.exit("codeFencedFenceSequence"), F(E) ? _(k, H, "whitespace")(E) : H(E)) : j(E)
        }

        function H(E) {
            return E === null || w(E) ? (k.exit("codeFencedFence"), B(E)) : j(E)
        }
    }
}

function Ut(n, r, t) {
    const e = this;
    return u;

    function u(a) {
        return a === null ? t(a) : (n.enter("lineEnding"), n.consume(a), n.exit("lineEnding"), i)
    }

    function i(a) {
        return e.parser.lazy[e.now().line] ? t(a) : r(a)
    }
}
const En = {
        name: "codeIndented",
        tokenize: Yt
    },
    Wt = {
        tokenize: $t,
        partial: !0
    };

function Yt(n, r, t) {
    const e = this;
    return u;

    function u(h) {
        return n.enter("codeIndented"), _(n, i, "linePrefix", 5)(h)
    }

    function i(h) {
        const f = e.events[e.events.length - 1];
        return f && f[1].type === "linePrefix" && f[2].sliceSerialize(f[1], !0).length >= 4 ? a(h) : t(h)
    }

    function a(h) {
        return h === null ? m(h) : w(h) ? n.attempt(Wt, a, m)(h) : (n.enter("codeFlowValue"), l(h))
    }

    function l(h) {
        return h === null || w(h) ? (n.exit("codeFlowValue"), a(h)) : (n.consume(h), l)
    }

    function m(h) {
        return n.exit("codeIndented"), r(h)
    }
}

function $t(n, r, t) {
    const e = this;
    return u;

    function u(a) {
        return e.parser.lazy[e.now().line] ? t(a) : w(a) ? (n.enter("lineEnding"), n.consume(a), n.exit("lineEnding"), u) : _(n, i, "linePrefix", 5)(a)
    }

    function i(a) {
        const l = e.events[e.events.length - 1];
        return l && l[1].type === "linePrefix" && l[2].sliceSerialize(l[1], !0).length >= 4 ? r(a) : w(a) ? u(a) : t(a)
    }
}
const Zt = {
    name: "codeText",
    tokenize: Kt,
    resolve: Gt,
    previous: Jt
};

function Gt(n) {
    let r = n.length - 4,
        t = 3,
        e, u;
    if ((n[t][1].type === "lineEnding" || n[t][1].type === "space") && (n[r][1].type === "lineEnding" || n[r][1].type === "space")) {
        for (e = t; ++e < r;)
            if (n[e][1].type === "codeTextData") {
                n[t][1].type = "codeTextPadding", n[r][1].type = "codeTextPadding", t += 2, r -= 2;
                break
            }
    }
    for (e = t - 1, r++; ++e <= r;) u === void 0 ? e !== r && n[e][1].type !== "lineEnding" && (u = e) : (e === r || n[e][1].type === "lineEnding") && (n[u][1].type = "codeTextData", e !== u + 2 && (n[u][1].end = n[e - 1][1].end, n.splice(u + 2, e - u - 2), r -= e - u - 2, e = u + 2), u = void 0);
    return n
}

function Jt(n) {
    return n !== 96 || this.events[this.events.length - 1][1].type === "characterEscape"
}

function Kt(n, r, t) {
    let e = 0,
        u, i;
    return a;

    function a(p) {
        return n.enter("codeText"), n.enter("codeTextSequence"), l(p)
    }

    function l(p) {
        return p === 96 ? (n.consume(p), e++, l) : (n.exit("codeTextSequence"), m(p))
    }

    function m(p) {
        return p === null ? t(p) : p === 32 ? (n.enter("space"), n.consume(p), n.exit("space"), m) : p === 96 ? (i = n.enter("codeTextSequence"), u = 0, f(p)) : w(p) ? (n.enter("lineEnding"), n.consume(p), n.exit("lineEnding"), m) : (n.enter("codeTextData"), h(p))
    }

    function h(p) {
        return p === null || p === 32 || p === 96 || w(p) ? (n.exit("codeTextData"), m(p)) : (n.consume(p), h)
    }

    function f(p) {
        return p === 96 ? (n.consume(p), u++, f) : u === e ? (n.exit("codeTextSequence"), n.exit("codeText"), r(p)) : (i.type = "codeTextData", h(p))
    }
}
class Xt {
    constructor(r) {
        this.left = r ? [...r] : [], this.right = []
    }
    get(r) {
        if (r < 0 || r >= this.left.length + this.right.length) throw new RangeError("Cannot access index `" + r + "` in a splice buffer of size `" + (this.left.length + this.right.length) + "`");
        return r < this.left.length ? this.left[r] : this.right[this.right.length - r + this.left.length - 1]
    }
    get length() {
        return this.left.length + this.right.length
    }
    shift() {
        return this.setCursor(0), this.right.pop()
    }
    slice(r, t) {
        const e = t == null ? Number.POSITIVE_INFINITY : t;
        return e < this.left.length ? this.left.slice(r, e) : r > this.left.length ? this.right.slice(this.right.length - e + this.left.length, this.right.length - r + this.left.length).reverse() : this.left.slice(r).concat(this.right.slice(this.right.length - e + this.left.length).reverse())
    }
    splice(r, t, e) {
        const u = t || 0;
        this.setCursor(Math.trunc(r));
        const i = this.right.splice(this.right.length - u, Number.POSITIVE_INFINITY);
        return e && bn(this.left, e), i.reverse()
    }
    pop() {
        return this.setCursor(Number.POSITIVE_INFINITY), this.left.pop()
    }
    push(r) {
        this.setCursor(Number.POSITIVE_INFINITY), this.left.push(r)
    }
    pushMany(r) {
        this.setCursor(Number.POSITIVE_INFINITY), bn(this.left, r)
    }
    unshift(r) {
        this.setCursor(0), this.right.push(r)
    }
    unshiftMany(r) {
        this.setCursor(0), bn(this.right, r.reverse())
    }
    setCursor(r) {
        if (!(r === this.left.length || r > this.left.length && this.right.length === 0 || r < 0 && this.left.length === 0))
            if (r < this.left.length) {
                const t = this.left.splice(r, Number.POSITIVE_INFINITY);
                bn(this.right, t.reverse())
            } else {
                const t = this.right.splice(this.left.length + this.right.length - r, Number.POSITIVE_INFINITY);
                bn(this.left, t.reverse())
            }
    }
}

function bn(n, r) {
    let t = 0;
    if (r.length < 1e4) n.push(...r);
    else
        for (; t < r.length;) n.push(...r.slice(t, t + 1e4)), t += 1e4
}

function tt(n) {
    const r = {};
    let t = -1,
        e, u, i, a, l, m, h;
    const f = new Xt(n);
    for (; ++t < f.length;) {
        for (; t in r;) t = r[t];
        if (e = f.get(t), t && e[1].type === "chunkFlow" && f.get(t - 1)[1].type === "listItemPrefix" && (m = e[1]._tokenizer.events, i = 0, i < m.length && m[i][1].type === "lineEndingBlank" && (i += 2), i < m.length && m[i][1].type === "content"))
            for (; ++i < m.length && m[i][1].type !== "content";) m[i][1].type === "chunkText" && (m[i][1]._isInFirstContentOfListItem = !0, i++);
        if (e[0] === "enter") e[1].contentType && (Object.assign(r, vt(f, t)), t = r[t], h = !0);
        else if (e[1]._container) {
            for (i = t, u = void 0; i-- && (a = f.get(i), a[1].type === "lineEnding" || a[1].type === "lineEndingBlank");) a[0] === "enter" && (u && (f.get(u)[1].type = "lineEndingBlank"), a[1].type = "lineEnding", u = i);
            u && (e[1].end = Object.assign({}, f.get(u)[1].start), l = f.slice(u, t), l.unshift(e), f.splice(u, t - u + 1, l))
        }
    }
    return an(n, 0, Number.POSITIVE_INFINITY, f.slice(0)), !h
}

function vt(n, r) {
    const t = n.get(r)[1],
        e = n.get(r)[2];
    let u = r - 1;
    const i = [],
        a = t._tokenizer || e.parser[t.contentType](t.start),
        l = a.events,
        m = [],
        h = {};
    let f, p, g = -1,
        c = t,
        T = 0,
        O = 0;
    const q = [O];
    for (; c;) {
        for (; n.get(++u)[1] !== c;);
        i.push(u), c._tokenizer || (f = e.sliceStream(c), c.next || f.push(null), p && a.defineSkip(c.start), c._isInFirstContentOfListItem && (a._gfmTasklistFirstContentOfListItem = !0), a.write(f), c._isInFirstContentOfListItem && (a._gfmTasklistFirstContentOfListItem = void 0)), p = c, c = c.next
    }
    for (c = t; ++g < l.length;) l[g][0] === "exit" && l[g - 1][0] === "enter" && l[g][1].type === l[g - 1][1].type && l[g][1].start.line !== l[g][1].end.line && (O = g + 1, q.push(O), c._tokenizer = void 0, c.previous = void 0, c = c.next);
    for (a.events = [], c ? (c._tokenizer = void 0, c.previous = void 0) : q.pop(), g = q.length; g--;) {
        const b = l.slice(q[g], q[g + 1]),
            R = i.pop();
        m.push([R, R + b.length - 1]), n.splice(R, 2, b)
    }
    for (m.reverse(), g = -1; ++g < m.length;) h[T + m[g][0]] = T + m[g][1], T += m[g][1] - m[g][0] - 1;
    return h
}
const ne = {
        tokenize: re,
        resolve: ee
    },
    te = {
        tokenize: ie,
        partial: !0
    };

function ee(n) {
    return tt(n), n
}

function re(n, r) {
    let t;
    return e;

    function e(l) {
        return n.enter("content"), t = n.enter("chunkContent", {
            contentType: "content"
        }), u(l)
    }

    function u(l) {
        return l === null ? i(l) : w(l) ? n.check(te, a, i)(l) : (n.consume(l), u)
    }

    function i(l) {
        return n.exit("chunkContent"), n.exit("content"), r(l)
    }

    function a(l) {
        return n.consume(l), n.exit("chunkContent"), t.next = n.enter("chunkContent", {
            contentType: "content",
            previous: t
        }), t = t.next, u
    }
}

function ie(n, r, t) {
    const e = this;
    return u;

    function u(a) {
        return n.exit("chunkContent"), n.enter("lineEnding"), n.consume(a), n.exit("lineEnding"), _(n, i, "linePrefix")
    }

    function i(a) {
        if (a === null || w(a)) return t(a);
        const l = e.events[e.events.length - 1];
        return !e.parser.constructs.disable.null.includes("codeIndented") && l && l[1].type === "linePrefix" && l[2].sliceSerialize(l[1], !0).length >= 4 ? r(a) : n.interrupt(e.parser.constructs.flow, t, r)(a)
    }
}

function et(n, r, t, e, u, i, a, l, m) {
    const h = m || Number.POSITIVE_INFINITY;
    let f = 0;
    return p;

    function p(b) {
        return b === 60 ? (n.enter(e), n.enter(u), n.enter(i), n.consume(b), n.exit(i), g) : b === null || b === 32 || b === 41 || Fn(b) ? t(b) : (n.enter(e), n.enter(a), n.enter(l), n.enter("chunkString", {
            contentType: "string"
        }), O(b))
    }

    function g(b) {
        return b === 62 ? (n.enter(i), n.consume(b), n.exit(i), n.exit(u), n.exit(e), r) : (n.enter(l), n.enter("chunkString", {
            contentType: "string"
        }), c(b))
    }

    function c(b) {
        return b === 62 ? (n.exit("chunkString"), n.exit(l), g(b)) : b === null || b === 60 || w(b) ? t(b) : (n.consume(b), b === 92 ? T : c)
    }

    function T(b) {
        return b === 60 || b === 62 || b === 92 ? (n.consume(b), c) : c(b)
    }

    function O(b) {
        return !f && (b === null || b === 41 || Y(b)) ? (n.exit("chunkString"), n.exit(l), n.exit(a), n.exit(e), r(b)) : f < h && b === 40 ? (n.consume(b), f++, O) : b === 41 ? (n.consume(b), f--, O) : b === null || b === 32 || b === 40 || Fn(b) ? t(b) : (n.consume(b), b === 92 ? q : O)
    }

    function q(b) {
        return b === 40 || b === 41 || b === 92 ? (n.consume(b), O) : O(b)
    }
}

function rt(n, r, t, e, u, i) {
    const a = this;
    let l = 0,
        m;
    return h;

    function h(c) {
        return n.enter(e), n.enter(u), n.consume(c), n.exit(u), n.enter(i), f
    }

    function f(c) {
        return l > 999 || c === null || c === 91 || c === 93 && !m || c === 94 && !l && "_hiddenFootnoteSupport" in a.parser.constructs ? t(c) : c === 93 ? (n.exit(i), n.enter(u), n.consume(c), n.exit(u), n.exit(e), r) : w(c) ? (n.enter("lineEnding"), n.consume(c), n.exit("lineEnding"), f) : (n.enter("chunkString", {
            contentType: "string"
        }), p(c))
    }

    function p(c) {
        return c === null || c === 91 || c === 93 || w(c) || l++ > 999 ? (n.exit("chunkString"), f(c)) : (n.consume(c), m || (m = !F(c)), c === 92 ? g : p)
    }

    function g(c) {
        return c === 91 || c === 92 || c === 93 ? (n.consume(c), l++, p) : p(c)
    }
}

function it(n, r, t, e, u, i) {
    let a;
    return l;

    function l(g) {
        return g === 34 || g === 39 || g === 40 ? (n.enter(e), n.enter(u), n.consume(g), n.exit(u), a = g === 40 ? 41 : g, m) : t(g)
    }

    function m(g) {
        return g === a ? (n.enter(u), n.consume(g), n.exit(u), n.exit(e), r) : (n.enter(i), h(g))
    }

    function h(g) {
        return g === a ? (n.exit(i), m(a)) : g === null ? t(g) : w(g) ? (n.enter("lineEnding"), n.consume(g), n.exit("lineEnding"), _(n, h, "linePrefix")) : (n.enter("chunkString", {
            contentType: "string"
        }), f(g))
    }

    function f(g) {
        return g === a || g === null || w(g) ? (n.exit("chunkString"), h(g)) : (n.consume(g), g === 92 ? p : f)
    }

    function p(g) {
        return g === a || g === 92 ? (n.consume(g), f) : f(g)
    }
}
const ue = {
        name: "definition",
        tokenize: le
    },
    ae = {
        tokenize: se,
        partial: !0
    };

function le(n, r, t) {
    const e = this;
    let u;
    return i;

    function i(c) {
        return n.enter("definition"), a(c)
    }

    function a(c) {
        return rt.call(e, n, l, t, "definitionLabel", "definitionLabelMarker", "definitionLabelString")(c)
    }

    function l(c) {
        return u = gn(e.sliceSerialize(e.events[e.events.length - 1][1]).slice(1, -1)), c === 58 ? (n.enter("definitionMarker"), n.consume(c), n.exit("definitionMarker"), m) : t(c)
    }

    function m(c) {
        return Y(c) ? Sn(n, h)(c) : h(c)
    }

    function h(c) {
        return et(n, f, t, "definitionDestination", "definitionDestinationLiteral", "definitionDestinationLiteralMarker", "definitionDestinationRaw", "definitionDestinationString")(c)
    }

    function f(c) {
        return n.attempt(ae, p, p)(c)
    }

    function p(c) {
        return F(c) ? _(n, g, "whitespace")(c) : g(c)
    }

    function g(c) {
        return c === null || w(c) ? (n.exit("definition"), e.parser.defined.push(u), r(c)) : t(c)
    }
}

function se(n, r, t) {
    return e;

    function e(l) {
        return Y(l) ? Sn(n, u)(l) : t(l)
    }

    function u(l) {
        return it(n, i, t, "definitionTitle", "definitionTitleMarker", "definitionTitleString")(l)
    }

    function i(l) {
        return F(l) ? _(n, a, "whitespace")(l) : a(l)
    }

    function a(l) {
        return l === null || w(l) ? r(l) : t(l)
    }
}
const oe = {
    name: "hardBreakEscape",
    tokenize: ce
};

function ce(n, r, t) {
    return e;

    function e(i) {
        return n.enter("hardBreakEscape"), n.consume(i), u
    }

    function u(i) {
        return w(i) ? (n.exit("hardBreakEscape"), r(i)) : t(i)
    }
}
const he = {
    name: "headingAtx",
    tokenize: me,
    resolve: pe
};

function pe(n, r) {
    let t = n.length - 2,
        e = 3,
        u, i;
    return n[e][1].type === "whitespace" && (e += 2), t - 2 > e && n[t][1].type === "whitespace" && (t -= 2), n[t][1].type === "atxHeadingSequence" && (e === t - 1 || t - 4 > e && n[t - 2][1].type === "whitespace") && (t -= e + 1 === t ? 2 : 4), t > e && (u = {
        type: "atxHeadingText",
        start: n[e][1].start,
        end: n[t][1].end
    }, i = {
        type: "chunkText",
        start: n[e][1].start,
        end: n[t][1].end,
        contentType: "text"
    }, an(n, e, t - e + 1, [
        ["enter", u, r],
        ["enter", i, r],
        ["exit", i, r],
        ["exit", u, r]
    ])), n
}

function me(n, r, t) {
    let e = 0;
    return u;

    function u(f) {
        return n.enter("atxHeading"), i(f)
    }

    function i(f) {
        return n.enter("atxHeadingSequence"), a(f)
    }

    function a(f) {
        return f === 35 && e++ < 6 ? (n.consume(f), a) : f === null || Y(f) ? (n.exit("atxHeadingSequence"), l(f)) : t(f)
    }

    function l(f) {
        return f === 35 ? (n.enter("atxHeadingSequence"), m(f)) : f === null || w(f) ? (n.exit("atxHeading"), r(f)) : F(f) ? _(n, l, "whitespace")(f) : (n.enter("atxHeadingText"), h(f))
    }

    function m(f) {
        return f === 35 ? (n.consume(f), m) : (n.exit("atxHeadingSequence"), l(f))
    }

    function h(f) {
        return f === null || f === 35 || Y(f) ? (n.exit("atxHeadingText"), l(f)) : (n.consume(f), h)
    }
}
const fe = ["address", "article", "aside", "base", "basefont", "blockquote", "body", "caption", "center", "col", "colgroup", "dd", "details", "dialog", "dir", "div", "dl", "dt", "fieldset", "figcaption", "figure", "footer", "form", "frame", "frameset", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hr", "html", "iframe", "legend", "li", "link", "main", "menu", "menuitem", "nav", "noframes", "ol", "optgroup", "option", "p", "param", "search", "section", "summary", "table", "tbody", "td", "tfoot", "th", "thead", "title", "tr", "track", "ul"],
    Yn = ["pre", "script", "style", "textarea"],
    ge = {
        name: "htmlFlow",
        tokenize: be,
        resolveTo: de,
        concrete: !0
    },
    xe = {
        tokenize: ye,
        partial: !0
    },
    ke = {
        tokenize: Se,
        partial: !0
    };

function de(n) {
    let r = n.length;
    for (; r-- && !(n[r][0] === "enter" && n[r][1].type === "htmlFlow"););
    return r > 1 && n[r - 2][1].type === "linePrefix" && (n[r][1].start = n[r - 2][1].start, n[r + 1][1].start = n[r - 2][1].start, n.splice(r - 2, 2)), n
}

function be(n, r, t) {
    const e = this;
    let u, i, a, l, m;
    return h;

    function h(o) {
        return f(o)
    }

    function f(o) {
        return n.enter("htmlFlow"), n.enter("htmlFlowData"), n.consume(o), p
    }

    function p(o) {
        return o === 33 ? (n.consume(o), g) : o === 47 ? (n.consume(o), i = !0, O) : o === 63 ? (n.consume(o), u = 3, e.interrupt ? r : s) : nn(o) ? (n.consume(o), a = String.fromCharCode(o), q) : t(o)
    }

    function g(o) {
        return o === 45 ? (n.consume(o), u = 2, c) : o === 91 ? (n.consume(o), u = 5, l = 0, T) : nn(o) ? (n.consume(o), u = 4, e.interrupt ? r : s) : t(o)
    }

    function c(o) {
        return o === 45 ? (n.consume(o), e.interrupt ? r : s) : t(o)
    }

    function T(o) {
        const K = "CDATA[";
        return o === K.charCodeAt(l++) ? (n.consume(o), l === K.length ? e.interrupt ? r : y : T) : t(o)
    }

    function O(o) {
        return nn(o) ? (n.consume(o), a = String.fromCharCode(o), q) : t(o)
    }

    function q(o) {
        if (o === null || o === 47 || o === 62 || Y(o)) {
            const K = o === 47,
                cn = a.toLowerCase();
            return !K && !i && Yn.includes(cn) ? (u = 1, e.interrupt ? r(o) : y(o)) : fe.includes(a.toLowerCase()) ? (u = 6, K ? (n.consume(o), b) : e.interrupt ? r(o) : y(o)) : (u = 7, e.interrupt && !e.parser.lazy[e.now().line] ? t(o) : i ? R(o) : S(o))
        }
        return o === 45 || v(o) ? (n.consume(o), a += String.fromCharCode(o), q) : t(o)
    }

    function b(o) {
        return o === 62 ? (n.consume(o), e.interrupt ? r : y) : t(o)
    }

    function R(o) {
        return F(o) ? (n.consume(o), R) : L(o)
    }

    function S(o) {
        return o === 47 ? (n.consume(o), L) : o === 58 || o === 95 || nn(o) ? (n.consume(o), M) : F(o) ? (n.consume(o), S) : L(o)
    }

    function M(o) {
        return o === 45 || o === 46 || o === 58 || o === 95 || v(o) ? (n.consume(o), M) : D(o)
    }

    function D(o) {
        return o === 61 ? (n.consume(o), k) : F(o) ? (n.consume(o), D) : S(o)
    }

    function k(o) {
        return o === null || o === 60 || o === 61 || o === 62 || o === 96 ? t(o) : o === 34 || o === 39 ? (n.consume(o), m = o, B) : F(o) ? (n.consume(o), k) : j(o)
    }

    function B(o) {
        return o === m ? (n.consume(o), m = null, P) : o === null || w(o) ? t(o) : (n.consume(o), B)
    }

    function j(o) {
        return o === null || o === 34 || o === 39 || o === 47 || o === 60 || o === 61 || o === 62 || o === 96 || Y(o) ? D(o) : (n.consume(o), j)
    }

    function P(o) {
        return o === 47 || o === 62 || F(o) ? S(o) : t(o)
    }

    function L(o) {
        return o === 62 ? (n.consume(o), I) : t(o)
    }

    function I(o) {
        return o === null || w(o) ? y(o) : F(o) ? (n.consume(o), I) : t(o)
    }

    function y(o) {
        return o === 45 && u === 2 ? (n.consume(o), U) : o === 60 && u === 1 ? (n.consume(o), V) : o === 62 && u === 4 ? (n.consume(o), J) : o === 63 && u === 3 ? (n.consume(o), s) : o === 93 && u === 5 ? (n.consume(o), tn) : w(o) && (u === 6 || u === 7) ? (n.exit("htmlFlowData"), n.check(xe, en, N)(o)) : o === null || w(o) ? (n.exit("htmlFlowData"), N(o)) : (n.consume(o), y)
    }

    function N(o) {
        return n.check(ke, H, en)(o)
    }

    function H(o) {
        return n.enter("lineEnding"), n.consume(o), n.exit("lineEnding"), E
    }

    function E(o) {
        return o === null || w(o) ? N(o) : (n.enter("htmlFlowData"), y(o))
    }

    function U(o) {
        return o === 45 ? (n.consume(o), s) : y(o)
    }

    function V(o) {
        return o === 47 ? (n.consume(o), a = "", G) : y(o)
    }

    function G(o) {
        if (o === 62) {
            const K = a.toLowerCase();
            return Yn.includes(K) ? (n.consume(o), J) : y(o)
        }
        return nn(o) && a.length < 8 ? (n.consume(o), a += String.fromCharCode(o), G) : y(o)
    }

    function tn(o) {
        return o === 93 ? (n.consume(o), s) : y(o)
    }

    function s(o) {
        return o === 62 ? (n.consume(o), J) : o === 45 && u === 2 ? (n.consume(o), s) : y(o)
    }

    function J(o) {
        return o === null || w(o) ? (n.exit("htmlFlowData"), en(o)) : (n.consume(o), J)
    }

    function en(o) {
        return n.exit("htmlFlow"), r(o)
    }
}

function Se(n, r, t) {
    const e = this;
    return u;

    function u(a) {
        return w(a) ? (n.enter("lineEnding"), n.consume(a), n.exit("lineEnding"), i) : t(a)
    }

    function i(a) {
        return e.parser.lazy[e.now().line] ? t(a) : r(a)
    }
}

function ye(n, r, t) {
    return e;

    function e(u) {
        return n.enter("lineEnding"), n.consume(u), n.exit("lineEnding"), n.attempt(wn, r, t)
    }
}
const Ie = {
    name: "htmlText",
    tokenize: we
};

function we(n, r, t) {
    const e = this;
    let u, i, a;
    return l;

    function l(s) {
        return n.enter("htmlText"), n.enter("htmlTextData"), n.consume(s), m
    }

    function m(s) {
        return s === 33 ? (n.consume(s), h) : s === 47 ? (n.consume(s), D) : s === 63 ? (n.consume(s), S) : nn(s) ? (n.consume(s), j) : t(s)
    }

    function h(s) {
        return s === 45 ? (n.consume(s), f) : s === 91 ? (n.consume(s), i = 0, T) : nn(s) ? (n.consume(s), R) : t(s)
    }

    function f(s) {
        return s === 45 ? (n.consume(s), c) : t(s)
    }

    function p(s) {
        return s === null ? t(s) : s === 45 ? (n.consume(s), g) : w(s) ? (a = p, V(s)) : (n.consume(s), p)
    }

    function g(s) {
        return s === 45 ? (n.consume(s), c) : p(s)
    }

    function c(s) {
        return s === 62 ? U(s) : s === 45 ? g(s) : p(s)
    }

    function T(s) {
        const J = "CDATA[";
        return s === J.charCodeAt(i++) ? (n.consume(s), i === J.length ? O : T) : t(s)
    }

    function O(s) {
        return s === null ? t(s) : s === 93 ? (n.consume(s), q) : w(s) ? (a = O, V(s)) : (n.consume(s), O)
    }

    function q(s) {
        return s === 93 ? (n.consume(s), b) : O(s)
    }

    function b(s) {
        return s === 62 ? U(s) : s === 93 ? (n.consume(s), b) : O(s)
    }

    function R(s) {
        return s === null || s === 62 ? U(s) : w(s) ? (a = R, V(s)) : (n.consume(s), R)
    }

    function S(s) {
        return s === null ? t(s) : s === 63 ? (n.consume(s), M) : w(s) ? (a = S, V(s)) : (n.consume(s), S)
    }

    function M(s) {
        return s === 62 ? U(s) : S(s)
    }

    function D(s) {
        return nn(s) ? (n.consume(s), k) : t(s)
    }

    function k(s) {
        return s === 45 || v(s) ? (n.consume(s), k) : B(s)
    }

    function B(s) {
        return w(s) ? (a = B, V(s)) : F(s) ? (n.consume(s), B) : U(s)
    }

    function j(s) {
        return s === 45 || v(s) ? (n.consume(s), j) : s === 47 || s === 62 || Y(s) ? P(s) : t(s)
    }

    function P(s) {
        return s === 47 ? (n.consume(s), U) : s === 58 || s === 95 || nn(s) ? (n.consume(s), L) : w(s) ? (a = P, V(s)) : F(s) ? (n.consume(s), P) : U(s)
    }

    function L(s) {
        return s === 45 || s === 46 || s === 58 || s === 95 || v(s) ? (n.consume(s), L) : I(s)
    }

    function I(s) {
        return s === 61 ? (n.consume(s), y) : w(s) ? (a = I, V(s)) : F(s) ? (n.consume(s), I) : P(s)
    }

    function y(s) {
        return s === null || s === 60 || s === 61 || s === 62 || s === 96 ? t(s) : s === 34 || s === 39 ? (n.consume(s), u = s, N) : w(s) ? (a = y, V(s)) : F(s) ? (n.consume(s), y) : (n.consume(s), H)
    }

    function N(s) {
        return s === u ? (n.consume(s), u = void 0, E) : s === null ? t(s) : w(s) ? (a = N, V(s)) : (n.consume(s), N)
    }

    function H(s) {
        return s === null || s === 34 || s === 39 || s === 60 || s === 61 || s === 96 ? t(s) : s === 47 || s === 62 || Y(s) ? P(s) : (n.consume(s), H)
    }

    function E(s) {
        return s === 47 || s === 62 || Y(s) ? P(s) : t(s)
    }

    function U(s) {
        return s === 62 ? (n.consume(s), n.exit("htmlTextData"), n.exit("htmlText"), r) : t(s)
    }

    function V(s) {
        return n.exit("htmlTextData"), n.enter("lineEnding"), n.consume(s), n.exit("lineEnding"), G
    }

    function G(s) {
        return F(s) ? _(n, tn, "linePrefix", e.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(s) : tn(s)
    }

    function tn(s) {
        return n.enter("htmlTextData"), a(s)
    }
}
const Pn = {
        name: "labelEnd",
        tokenize: Oe,
        resolveTo: Fe,
        resolveAll: Te
    },
    ze = {
        tokenize: Be
    },
    Ce = {
        tokenize: Ae
    },
    Ee = {
        tokenize: Pe
    };

function Te(n) {
    let r = -1;
    for (; ++r < n.length;) {
        const t = n[r][1];
        (t.type === "labelImage" || t.type === "labelLink" || t.type === "labelEnd") && (n.splice(r + 1, t.type === "labelImage" ? 4 : 2), t.type = "data", r++)
    }
    return n
}

function Fe(n, r) {
    let t = n.length,
        e = 0,
        u, i, a, l;
    for (; t--;)
        if (u = n[t][1], i) {
            if (u.type === "link" || u.type === "labelLink" && u._inactive) break;
            n[t][0] === "enter" && u.type === "labelLink" && (u._inactive = !0)
        } else if (a) {
        if (n[t][0] === "enter" && (u.type === "labelImage" || u.type === "labelLink") && !u._balanced && (i = t, u.type !== "labelLink")) {
            e = 2;
            break
        }
    } else u.type === "labelEnd" && (a = t);
    const m = {
            type: n[i][1].type === "labelLink" ? "link" : "image",
            start: Object.assign({}, n[i][1].start),
            end: Object.assign({}, n[n.length - 1][1].end)
        },
        h = {
            type: "label",
            start: Object.assign({}, n[i][1].start),
            end: Object.assign({}, n[a][1].end)
        },
        f = {
            type: "labelText",
            start: Object.assign({}, n[i + e + 2][1].end),
            end: Object.assign({}, n[a - 2][1].start)
        };
    return l = [
        ["enter", m, r],
        ["enter", h, r]
    ], l = Z(l, n.slice(i + 1, i + e + 3)), l = Z(l, [
        ["enter", f, r]
    ]), l = Z(l, An(r.parser.constructs.insideSpan.null, n.slice(i + e + 4, a - 3), r)), l = Z(l, [
        ["exit", f, r], n[a - 2], n[a - 1],
        ["exit", h, r]
    ]), l = Z(l, n.slice(a + 1)), l = Z(l, [
        ["exit", m, r]
    ]), an(n, i, n.length, l), n
}

function Oe(n, r, t) {
    const e = this;
    let u = e.events.length,
        i, a;
    for (; u--;)
        if ((e.events[u][1].type === "labelImage" || e.events[u][1].type === "labelLink") && !e.events[u][1]._balanced) {
            i = e.events[u][1];
            break
        }
    return l;

    function l(g) {
        return i ? i._inactive ? p(g) : (a = e.parser.defined.includes(gn(e.sliceSerialize({
            start: i.end,
            end: e.now()
        }))), n.enter("labelEnd"), n.enter("labelMarker"), n.consume(g), n.exit("labelMarker"), n.exit("labelEnd"), m) : t(g)
    }

    function m(g) {
        return g === 40 ? n.attempt(ze, f, a ? f : p)(g) : g === 91 ? n.attempt(Ce, f, a ? h : p)(g) : a ? f(g) : p(g)
    }

    function h(g) {
        return n.attempt(Ee, f, p)(g)
    }

    function f(g) {
        return r(g)
    }

    function p(g) {
        return i._balanced = !0, t(g)
    }
}

function Be(n, r, t) {
    return e;

    function e(p) {
        return n.enter("resource"), n.enter("resourceMarker"), n.consume(p), n.exit("resourceMarker"), u
    }

    function u(p) {
        return Y(p) ? Sn(n, i)(p) : i(p)
    }

    function i(p) {
        return p === 41 ? f(p) : et(n, a, l, "resourceDestination", "resourceDestinationLiteral", "resourceDestinationLiteralMarker", "resourceDestinationRaw", "resourceDestinationString", 32)(p)
    }

    function a(p) {
        return Y(p) ? Sn(n, m)(p) : f(p)
    }

    function l(p) {
        return t(p)
    }

    function m(p) {
        return p === 34 || p === 39 || p === 40 ? it(n, h, t, "resourceTitle", "resourceTitleMarker", "resourceTitleString")(p) : f(p)
    }

    function h(p) {
        return Y(p) ? Sn(n, f)(p) : f(p)
    }

    function f(p) {
        return p === 41 ? (n.enter("resourceMarker"), n.consume(p), n.exit("resourceMarker"), n.exit("resource"), r) : t(p)
    }
}

function Ae(n, r, t) {
    const e = this;
    return u;

    function u(l) {
        return rt.call(e, n, i, a, "reference", "referenceMarker", "referenceString")(l)
    }

    function i(l) {
        return e.parser.defined.includes(gn(e.sliceSerialize(e.events[e.events.length - 1][1]).slice(1, -1))) ? r(l) : t(l)
    }

    function a(l) {
        return t(l)
    }
}

function Pe(n, r, t) {
    return e;

    function e(i) {
        return n.enter("reference"), n.enter("referenceMarker"), n.consume(i), n.exit("referenceMarker"), u
    }

    function u(i) {
        return i === 93 ? (n.enter("referenceMarker"), n.consume(i), n.exit("referenceMarker"), n.exit("reference"), r) : t(i)
    }
}
const _e = {
    name: "labelStartImage",
    tokenize: Le,
    resolveAll: Pn.resolveAll
};

function Le(n, r, t) {
    const e = this;
    return u;

    function u(l) {
        return n.enter("labelImage"), n.enter("labelImageMarker"), n.consume(l), n.exit("labelImageMarker"), i
    }

    function i(l) {
        return l === 91 ? (n.enter("labelMarker"), n.consume(l), n.exit("labelMarker"), n.exit("labelImage"), a) : t(l)
    }

    function a(l) {
        return l === 94 && "_hiddenFootnoteSupport" in e.parser.constructs ? t(l) : r(l)
    }
}
const Me = {
    name: "labelStartLink",
    tokenize: Ne,
    resolveAll: Pn.resolveAll
};

function Ne(n, r, t) {
    const e = this;
    return u;

    function u(a) {
        return n.enter("labelLink"), n.enter("labelMarker"), n.consume(a), n.exit("labelMarker"), n.exit("labelLink"), i
    }

    function i(a) {
        return a === 94 && "_hiddenFootnoteSupport" in e.parser.constructs ? t(a) : r(a)
    }
}
const Tn = {
    name: "lineEnding",
    tokenize: De
};

function De(n, r) {
    return t;

    function t(e) {
        return n.enter("lineEnding"), n.consume(e), n.exit("lineEnding"), _(n, r, "linePrefix")
    }
}
const In = {
    name: "thematicBreak",
    tokenize: qe
};

function qe(n, r, t) {
    let e = 0,
        u;
    return i;

    function i(h) {
        return n.enter("thematicBreak"), a(h)
    }

    function a(h) {
        return u = h, l(h)
    }

    function l(h) {
        return h === u ? (n.enter("thematicBreakSequence"), m(h)) : e >= 3 && (h === null || w(h)) ? (n.exit("thematicBreak"), r(h)) : t(h)
    }

    function m(h) {
        return h === u ? (n.consume(h), e++, m) : (n.exit("thematicBreakSequence"), F(h) ? _(n, l, "whitespace")(h) : l(h))
    }
}
const W = {
        name: "list",
        tokenize: He,
        continuation: {
            tokenize: Ve
        },
        exit: Ue
    },
    Re = {
        tokenize: We,
        partial: !0
    },
    je = {
        tokenize: Qe,
        partial: !0
    };

function He(n, r, t) {
    const e = this,
        u = e.events[e.events.length - 1];
    let i = u && u[1].type === "linePrefix" ? u[2].sliceSerialize(u[1], !0).length : 0,
        a = 0;
    return l;

    function l(c) {
        const T = e.containerState.type || (c === 42 || c === 43 || c === 45 ? "listUnordered" : "listOrdered");
        if (T === "listUnordered" ? !e.containerState.marker || c === e.containerState.marker : On(c)) {
            if (e.containerState.type || (e.containerState.type = T, n.enter(T, {
                    _container: !0
                })), T === "listUnordered") return n.enter("listItemPrefix"), c === 42 || c === 45 ? n.check(In, t, h)(c) : h(c);
            if (!e.interrupt || c === 49) return n.enter("listItemPrefix"), n.enter("listItemValue"), m(c)
        }
        return t(c)
    }

    function m(c) {
        return On(c) && ++a < 10 ? (n.consume(c), m) : (!e.interrupt || a < 2) && (e.containerState.marker ? c === e.containerState.marker : c === 41 || c === 46) ? (n.exit("listItemValue"), h(c)) : t(c)
    }

    function h(c) {
        return n.enter("listItemMarker"), n.consume(c), n.exit("listItemMarker"), e.containerState.marker = e.containerState.marker || c, n.check(wn, e.interrupt ? t : f, n.attempt(Re, g, p))
    }

    function f(c) {
        return e.containerState.initialBlankLine = !0, i++, g(c)
    }

    function p(c) {
        return F(c) ? (n.enter("listItemPrefixWhitespace"), n.consume(c), n.exit("listItemPrefixWhitespace"), g) : t(c)
    }

    function g(c) {
        return e.containerState.size = i + e.sliceSerialize(n.exit("listItemPrefix"), !0).length, r(c)
    }
}

function Ve(n, r, t) {
    const e = this;
    return e.containerState._closeFlow = void 0, n.check(wn, u, i);

    function u(l) {
        return e.containerState.furtherBlankLines = e.containerState.furtherBlankLines || e.containerState.initialBlankLine, _(n, r, "listItemIndent", e.containerState.size + 1)(l)
    }

    function i(l) {
        return e.containerState.furtherBlankLines || !F(l) ? (e.containerState.furtherBlankLines = void 0, e.containerState.initialBlankLine = void 0, a(l)) : (e.containerState.furtherBlankLines = void 0, e.containerState.initialBlankLine = void 0, n.attempt(je, r, a)(l))
    }

    function a(l) {
        return e.containerState._closeFlow = !0, e.interrupt = void 0, _(n, n.attempt(W, r, t), "linePrefix", e.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(l)
    }
}

function Qe(n, r, t) {
    const e = this;
    return _(n, u, "listItemIndent", e.containerState.size + 1);

    function u(i) {
        const a = e.events[e.events.length - 1];
        return a && a[1].type === "listItemIndent" && a[2].sliceSerialize(a[1], !0).length === e.containerState.size ? r(i) : t(i)
    }
}

function Ue(n) {
    n.exit(this.containerState.type)
}

function We(n, r, t) {
    const e = this;
    return _(n, u, "listItemPrefixWhitespace", e.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 5);

    function u(i) {
        const a = e.events[e.events.length - 1];
        return !F(i) && a && a[1].type === "listItemPrefixWhitespace" ? r(i) : t(i)
    }
}
const $n = {
    name: "setextUnderline",
    tokenize: $e,
    resolveTo: Ye
};

function Ye(n, r) {
    let t = n.length,
        e, u, i;
    for (; t--;)
        if (n[t][0] === "enter") {
            if (n[t][1].type === "content") {
                e = t;
                break
            }
            n[t][1].type === "paragraph" && (u = t)
        } else n[t][1].type === "content" && n.splice(t, 1), !i && n[t][1].type === "definition" && (i = t);
    const a = {
        type: "setextHeading",
        start: Object.assign({}, n[u][1].start),
        end: Object.assign({}, n[n.length - 1][1].end)
    };
    return n[u][1].type = "setextHeadingText", i ? (n.splice(u, 0, ["enter", a, r]), n.splice(i + 1, 0, ["exit", n[e][1], r]), n[e][1].end = Object.assign({}, n[i][1].end)) : n[e][1] = a, n.push(["exit", a, r]), n
}

function $e(n, r, t) {
    const e = this;
    let u;
    return i;

    function i(h) {
        let f = e.events.length,
            p;
        for (; f--;)
            if (e.events[f][1].type !== "lineEnding" && e.events[f][1].type !== "linePrefix" && e.events[f][1].type !== "content") {
                p = e.events[f][1].type === "paragraph";
                break
            }
        return !e.parser.lazy[e.now().line] && (e.interrupt || p) ? (n.enter("setextHeadingLine"), u = h, a(h)) : t(h)
    }

    function a(h) {
        return n.enter("setextHeadingLineSequence"), l(h)
    }

    function l(h) {
        return h === u ? (n.consume(h), l) : (n.exit("setextHeadingLineSequence"), F(h) ? _(n, m, "lineSuffix")(h) : m(h))
    }

    function m(h) {
        return h === null || w(h) ? (n.exit("setextHeadingLine"), r(h)) : t(h)
    }
}
const Ze = {
    tokenize: Ge
};

function Ge(n) {
    const r = n.attempt(this.parser.constructs.contentInitial, e, u);
    let t;
    return r;

    function e(l) {
        if (l === null) {
            n.consume(l);
            return
        }
        return n.enter("lineEnding"), n.consume(l), n.exit("lineEnding"), _(n, r, "linePrefix")
    }

    function u(l) {
        return n.enter("paragraph"), i(l)
    }

    function i(l) {
        const m = n.enter("chunkText", {
            contentType: "text",
            previous: t
        });
        return t && (t.next = m), t = m, a(l)
    }

    function a(l) {
        if (l === null) {
            n.exit("chunkText"), n.exit("paragraph"), n.consume(l);
            return
        }
        return w(l) ? (n.consume(l), n.exit("chunkText"), i) : (n.consume(l), a)
    }
}
const Je = {
        tokenize: Ke
    },
    Zn = {
        tokenize: Xe
    };

function Ke(n) {
    const r = this,
        t = [];
    let e = 0,
        u, i, a;
    return l;

    function l(S) {
        if (e < t.length) {
            const M = t[e];
            return r.containerState = M[1], n.attempt(M[0].continuation, m, h)(S)
        }
        return h(S)
    }

    function m(S) {
        if (e++, r.containerState._closeFlow) {
            r.containerState._closeFlow = void 0, u && R();
            const M = r.events.length;
            let D = M,
                k;
            for (; D--;)
                if (r.events[D][0] === "exit" && r.events[D][1].type === "chunkFlow") {
                    k = r.events[D][1].end;
                    break
                }
            b(e);
            let B = M;
            for (; B < r.events.length;) r.events[B][1].end = Object.assign({}, k), B++;
            return an(r.events, D + 1, 0, r.events.slice(M)), r.events.length = B, h(S)
        }
        return l(S)
    }

    function h(S) {
        if (e === t.length) {
            if (!u) return g(S);
            if (u.currentConstruct && u.currentConstruct.concrete) return T(S);
            r.interrupt = !!(u.currentConstruct && !u._gfmTableDynamicInterruptHack)
        }
        return r.containerState = {}, n.check(Zn, f, p)(S)
    }

    function f(S) {
        return u && R(), b(e), g(S)
    }

    function p(S) {
        return r.parser.lazy[r.now().line] = e !== t.length, a = r.now().offset, T(S)
    }

    function g(S) {
        return r.containerState = {}, n.attempt(Zn, c, T)(S)
    }

    function c(S) {
        return e++, t.push([r.currentConstruct, r.containerState]), g(S)
    }

    function T(S) {
        if (S === null) {
            u && R(), b(0), n.consume(S);
            return
        }
        return u = u || r.parser.flow(r.now()), n.enter("chunkFlow", {
            contentType: "flow",
            previous: i,
            _tokenizer: u
        }), O(S)
    }

    function O(S) {
        if (S === null) {
            q(n.exit("chunkFlow"), !0), b(0), n.consume(S);
            return
        }
        return w(S) ? (n.consume(S), q(n.exit("chunkFlow")), e = 0, r.interrupt = void 0, l) : (n.consume(S), O)
    }

    function q(S, M) {
        const D = r.sliceStream(S);
        if (M && D.push(null), S.previous = i, i && (i.next = S), i = S, u.defineSkip(S.start), u.write(D), r.parser.lazy[S.start.line]) {
            let k = u.events.length;
            for (; k--;)
                if (u.events[k][1].start.offset < a && (!u.events[k][1].end || u.events[k][1].end.offset > a)) return;
            const B = r.events.length;
            let j = B,
                P, L;
            for (; j--;)
                if (r.events[j][0] === "exit" && r.events[j][1].type === "chunkFlow") {
                    if (P) {
                        L = r.events[j][1].end;
                        break
                    }
                    P = !0
                }
            for (b(e), k = B; k < r.events.length;) r.events[k][1].end = Object.assign({}, L), k++;
            an(r.events, j + 1, 0, r.events.slice(B)), r.events.length = k
        }
    }

    function b(S) {
        let M = t.length;
        for (; M-- > S;) {
            const D = t[M];
            r.containerState = D[1], D[0].exit.call(r, n)
        }
        t.length = S
    }

    function R() {
        u.write([null]), i = void 0, u = void 0, r.containerState._closeFlow = void 0
    }
}

function Xe(n, r, t) {
    return _(n, n.attempt(this.parser.constructs.document, r, t), "linePrefix", this.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)
}
const ve = {
    tokenize: nr
};

function nr(n) {
    const r = this,
        t = n.attempt(wn, e, n.attempt(this.parser.constructs.flowInitial, u, _(n, n.attempt(this.parser.constructs.flow, u, n.attempt(ne, u)), "linePrefix")));
    return t;

    function e(i) {
        if (i === null) {
            n.consume(i);
            return
        }
        return n.enter("lineEndingBlank"), n.consume(i), n.exit("lineEndingBlank"), r.currentConstruct = void 0, t
    }

    function u(i) {
        if (i === null) {
            n.consume(i);
            return
        }
        return n.enter("lineEnding"), n.consume(i), n.exit("lineEnding"), r.currentConstruct = void 0, t
    }
}
const tr = {
        resolveAll: at()
    },
    er = ut("string"),
    rr = ut("text");

function ut(n) {
    return {
        tokenize: r,
        resolveAll: at(n === "text" ? ir : void 0)
    };

    function r(t) {
        const e = this,
            u = this.parser.constructs[n],
            i = t.attempt(u, a, l);
        return a;

        function a(f) {
            return h(f) ? i(f) : l(f)
        }

        function l(f) {
            if (f === null) {
                t.consume(f);
                return
            }
            return t.enter("data"), t.consume(f), m
        }

        function m(f) {
            return h(f) ? (t.exit("data"), i(f)) : (t.consume(f), m)
        }

        function h(f) {
            if (f === null) return !0;
            const p = u[f];
            let g = -1;
            if (p)
                for (; ++g < p.length;) {
                    const c = p[g];
                    if (!c.previous || c.previous.call(e, e.previous)) return !0
                }
            return !1
        }
    }
}

function at(n) {
    return r;

    function r(t, e) {
        let u = -1,
            i;
        for (; ++u <= t.length;) i === void 0 ? t[u] && t[u][1].type === "data" && (i = u, u++) : (!t[u] || t[u][1].type !== "data") && (u !== i + 2 && (t[i][1].end = t[u - 1][1].end, t.splice(i + 2, u - i - 2), u = i + 2), i = void 0);
        return n ? n(t, e) : t
    }
}

function ir(n, r) {
    let t = 0;
    for (; ++t <= n.length;)
        if ((t === n.length || n[t][1].type === "lineEnding") && n[t - 1][1].type === "data") {
            const e = n[t - 1][1],
                u = r.sliceStream(e);
            let i = u.length,
                a = -1,
                l = 0,
                m;
            for (; i--;) {
                const h = u[i];
                if (typeof h == "string") {
                    for (a = h.length; h.charCodeAt(a - 1) === 32;) l++, a--;
                    if (a) break;
                    a = -1
                } else if (h === -2) m = !0, l++;
                else if (h !== -1) {
                    i++;
                    break
                }
            }
            if (l) {
                const h = {
                    type: t === n.length || m || l < 2 ? "lineSuffix" : "hardBreakTrailing",
                    start: {
                        line: e.end.line,
                        column: e.end.column - l,
                        offset: e.end.offset - l,
                        _index: e.start._index + i,
                        _bufferIndex: i ? a : e.start._bufferIndex + a
                    },
                    end: Object.assign({}, e.end)
                };
                e.end = Object.assign({}, h.start), e.start.offset === e.end.offset ? Object.assign(e, h) : (n.splice(t, 0, ["enter", h, r], ["exit", h, r]), t += 2)
            }
            t++
        }
    return n
}

function ur(n, r, t) {
    let e = Object.assign(t ? Object.assign({}, t) : {
        line: 1,
        column: 1,
        offset: 0
    }, {
        _index: 0,
        _bufferIndex: -1
    });
    const u = {},
        i = [];
    let a = [],
        l = [];
    const m = {
            consume: R,
            enter: S,
            exit: M,
            attempt: B(D),
            check: B(k),
            interrupt: B(k, {
                interrupt: !0
            })
        },
        h = {
            previous: null,
            code: null,
            containerState: {},
            events: [],
            parser: n,
            sliceStream: c,
            sliceSerialize: g,
            now: T,
            defineSkip: O,
            write: p
        };
    let f = r.tokenize.call(h, m);
    return r.resolveAll && i.push(r), h;

    function p(I) {
        return a = Z(a, I), q(), a[a.length - 1] !== null ? [] : (j(r, 0), h.events = An(i, h.events, h), h.events)
    }

    function g(I, y) {
        return lr(c(I), y)
    }

    function c(I) {
        return ar(a, I)
    }

    function T() {
        const {
            line: I,
            column: y,
            offset: N,
            _index: H,
            _bufferIndex: E
        } = e;
        return {
            line: I,
            column: y,
            offset: N,
            _index: H,
            _bufferIndex: E
        }
    }

    function O(I) {
        u[I.line] = I.column, L()
    }

    function q() {
        let I;
        for (; e._index < a.length;) {
            const y = a[e._index];
            if (typeof y == "string")
                for (I = e._index, e._bufferIndex < 0 && (e._bufferIndex = 0); e._index === I && e._bufferIndex < y.length;) b(y.charCodeAt(e._bufferIndex));
            else b(y)
        }
    }

    function b(I) {
        f = f(I)
    }

    function R(I) {
        w(I) ? (e.line++, e.column = 1, e.offset += I === -3 ? 2 : 1, L()) : I !== -1 && (e.column++, e.offset++), e._bufferIndex < 0 ? e._index++ : (e._bufferIndex++, e._bufferIndex === a[e._index].length && (e._bufferIndex = -1, e._index++)), h.previous = I
    }

    function S(I, y) {
        const N = y || {};
        return N.type = I, N.start = T(), h.events.push(["enter", N, h]), l.push(N), N
    }

    function M(I) {
        const y = l.pop();
        return y.end = T(), h.events.push(["exit", y, h]), y
    }

    function D(I, y) {
        j(I, y.from)
    }

    function k(I, y) {
        y.restore()
    }

    function B(I, y) {
        return N;

        function N(H, E, U) {
            let V, G, tn, s;
            return Array.isArray(H) ? en(H) : "tokenize" in H ? en([H]) : J(H);

            function J(Q) {
                return xn;

                function xn(ln) {
                    const mn = ln !== null && Q[ln],
                        hn = ln !== null && Q.null,
                        zn = [...Array.isArray(mn) ? mn : mn ? [mn] : [], ...Array.isArray(hn) ? hn : hn ? [hn] : []];
                    return en(zn)(ln)
                }
            }

            function en(Q) {
                return V = Q, G = 0, Q.length === 0 ? U : o(Q[G])
            }

            function o(Q) {
                return xn;

                function xn(ln) {
                    return s = P(), tn = Q, Q.partial || (h.currentConstruct = Q), Q.name && h.parser.constructs.disable.null.includes(Q.name) ? cn() : Q.tokenize.call(y ? Object.assign(Object.create(h), y) : h, m, K, cn)(ln)
                }
            }

            function K(Q) {
                return I(tn, s), E
            }

            function cn(Q) {
                return s.restore(), ++G < V.length ? o(V[G]) : U
            }
        }
    }

    function j(I, y) {
        I.resolveAll && !i.includes(I) && i.push(I), I.resolve && an(h.events, y, h.events.length - y, I.resolve(h.events.slice(y), h)), I.resolveTo && (h.events = I.resolveTo(h.events, h))
    }

    function P() {
        const I = T(),
            y = h.previous,
            N = h.currentConstruct,
            H = h.events.length,
            E = Array.from(l);
        return {
            restore: U,
            from: H
        };

        function U() {
            e = I, h.previous = y, h.currentConstruct = N, h.events.length = H, l = E, L()
        }
    }

    function L() {
        e.line in u && e.column < 2 && (e.column = u[e.line], e.offset += u[e.line] - 1)
    }
}

function ar(n, r) {
    const t = r.start._index,
        e = r.start._bufferIndex,
        u = r.end._index,
        i = r.end._bufferIndex;
    let a;
    if (t === u) a = [n[t].slice(e, i)];
    else {
        if (a = n.slice(t, u), e > -1) {
            const l = a[0];
            typeof l == "string" ? a[0] = l.slice(e) : a.shift()
        }
        i > 0 && a.push(n[u].slice(0, i))
    }
    return a
}

function lr(n, r) {
    let t = -1;
    const e = [];
    let u;
    for (; ++t < n.length;) {
        const i = n[t];
        let a;
        if (typeof i == "string") a = i;
        else switch (i) {
            case -5:
                {
                    a = "\r";
                    break
                }
            case -4:
                {
                    a = "\n";
                    break
                }
            case -3:
                {
                    a = "\r\n";
                    break
                }
            case -2:
                {
                    a = r ? " " : "	";
                    break
                }
            case -1:
                {
                    if (!r && u) continue;a = " ";
                    break
                }
            default:
                a = String.fromCharCode(i)
        }
        u = i === -2, e.push(a)
    }
    return e.join("")
}
const sr = {
        42: W,
        43: W,
        45: W,
        48: W,
        49: W,
        50: W,
        51: W,
        52: W,
        53: W,
        54: W,
        55: W,
        56: W,
        57: W,
        62: Xn
    },
    or = {
        91: ue
    },
    cr = {
        [-2]: En,
        [-1]: En,
        32: En
    },
    hr = {
        35: he,
        42: In,
        45: [$n, In],
        60: ge,
        61: $n,
        95: In,
        96: Wn,
        126: Wn
    },
    pr = {
        38: nt,
        92: vn
    },
    mr = {
        [-5]: Tn,
        [-4]: Tn,
        [-3]: Tn,
        33: _e,
        38: nt,
        42: Bn,
        60: [Mt, Ie],
        91: Me,
        92: [oe, vn],
        93: Pn,
        95: Bn,
        96: Zt
    },
    fr = {
        null: [Bn, tr]
    },
    gr = {
        null: [42, 95]
    },
    xr = {
        null: []
    },
    kr = Object.freeze(Object.defineProperty({
        __proto__: null,
        attentionMarkers: gr,
        contentInitial: or,
        disable: xr,
        document: sr,
        flow: hr,
        flowInitial: cr,
        insideSpan: fr,
        string: pr,
        text: mr
    }, Symbol.toStringTag, {
        value: "Module"
    }));

function dr(n) {
    const t = Bt([kr, ...(n || {}).extensions || []]),
        e = {
            defined: [],
            lazy: {},
            constructs: t,
            content: u(Ze),
            document: u(Je),
            flow: u(ve),
            string: u(er),
            text: u(rr)
        };
    return e;

    function u(i) {
        return a;

        function a(l) {
            return ur(e, i, l)
        }
    }
}

function br(n) {
    for (; !tt(n););
    return n
}
const Gn = /[\0\t\n\r]/g;

function Sr() {
    let n = 1,
        r = "",
        t = !0,
        e;
    return u;

    function u(i, a, l) {
        const m = [];
        let h, f, p, g, c;
        for (i = r + (typeof i == "string" ? i.toString() : new TextDecoder(a || void 0).decode(i)), p = 0, r = "", t && (i.charCodeAt(0) === 65279 && p++, t = void 0); p < i.length;) {
            if (Gn.lastIndex = p, h = Gn.exec(i), g = h && h.index !== void 0 ? h.index : i.length, c = i.charCodeAt(g), !h) {
                r = i.slice(p);
                break
            }
            if (c === 10 && p === g && e) m.push(-3), e = void 0;
            else switch (e && (m.push(-5), e = void 0), p < g && (m.push(i.slice(p, g)), n += g - p), c) {
                case 0:
                    {
                        m.push(65533),
                        n++;
                        break
                    }
                case 9:
                    {
                        for (f = Math.ceil(n / 4) * 4, m.push(-2); n++ < f;) m.push(-1);
                        break
                    }
                case 10:
                    {
                        m.push(-4),
                        n = 1;
                        break
                    }
                default:
                    e = !0, n = 1
            }
            p = g + 1
        }
        return l && (e && m.push(-5), r && m.push(r), m.push(null)), m
    }
}
const lt = {}.hasOwnProperty;

function yr(n, r, t) {
    return typeof r != "string" && (t = r, r = void 0), Ir(t)(br(dr(t).document().write(Sr()(n, r, !0))))
}

function Ir(n) {
    const r = {
        transforms: [],
        canContainEols: ["emphasis", "fragment", "heading", "paragraph", "strong"],
        enter: {
            autolink: i(Nn),
            autolinkProtocol: P,
            autolinkEmail: P,
            atxHeading: i(_n),
            blockQuote: i(mn),
            characterEscape: P,
            characterReference: P,
            codeFenced: i(hn),
            codeFencedFenceInfo: a,
            codeFencedFenceMeta: a,
            codeIndented: i(hn, a),
            codeText: i(zn, a),
            codeTextData: P,
            data: P,
            codeFlowValue: P,
            definition: i(ot),
            definitionDestinationString: a,
            definitionLabelString: a,
            definitionTitleString: a,
            emphasis: i(ct),
            hardBreakEscape: i(Ln),
            hardBreakTrailing: i(Ln),
            htmlFlow: i(Mn, a),
            htmlFlowData: P,
            htmlText: i(Mn, a),
            htmlTextData: P,
            image: i(ht),
            label: a,
            link: i(Nn),
            listItem: i(pt),
            listItemValue: g,
            listOrdered: i(Dn, p),
            listUnordered: i(Dn),
            paragraph: i(mt),
            reference: o,
            referenceString: a,
            resourceDestinationString: a,
            resourceTitleString: a,
            setextHeading: i(_n),
            strong: i(ft),
            thematicBreak: i(xt)
        },
        exit: {
            atxHeading: m(),
            atxHeadingSequence: D,
            autolink: m(),
            autolinkEmail: ln,
            autolinkProtocol: xn,
            blockQuote: m(),
            characterEscapeValue: L,
            characterReferenceMarkerHexadecimal: cn,
            characterReferenceMarkerNumeric: cn,
            characterReferenceValue: Q,
            codeFenced: m(q),
            codeFencedFence: O,
            codeFencedFenceInfo: c,
            codeFencedFenceMeta: T,
            codeFlowValue: L,
            codeIndented: m(b),
            codeText: m(E),
            codeTextData: L,
            data: L,
            definition: m(),
            definitionDestinationString: M,
            definitionLabelString: R,
            definitionTitleString: S,
            emphasis: m(),
            hardBreakEscape: m(y),
            hardBreakTrailing: m(y),
            htmlFlow: m(N),
            htmlFlowData: L,
            htmlText: m(H),
            htmlTextData: L,
            image: m(V),
            label: tn,
            labelText: G,
            lineEnding: I,
            link: m(U),
            listItem: m(),
            listOrdered: m(),
            listUnordered: m(),
            paragraph: m(),
            referenceString: K,
            resourceDestinationString: s,
            resourceTitleString: J,
            resource: en,
            setextHeading: m(j),
            setextHeadingLineSequence: B,
            setextHeadingText: k,
            strong: m(),
            thematicBreak: m()
        }
    };
    st(r, (n || {}).mdastExtensions || []);
    const t = {};
    return e;

    function e(x) {
        let d = {
            type: "root",
            children: []
        };
        const z = {
                stack: [d],
                tokenStack: [],
                config: r,
                enter: l,
                exit: h,
                buffer: a,
                resume: f,
                data: t
            },
            C = [];
        let A = -1;
        for (; ++A < x.length;)
            if (x[A][1].type === "listOrdered" || x[A][1].type === "listUnordered")
                if (x[A][0] === "enter") C.push(A);
                else {
                    const X = C.pop();
                    A = u(x, X, A)
                }
        for (A = -1; ++A < x.length;) {
            const X = r[x[A][0]];
            lt.call(X, x[A][1].type) && X[x[A][1].type].call(Object.assign({
                sliceSerialize: x[A][2].sliceSerialize
            }, z), x[A][1])
        }
        if (z.tokenStack.length > 0) {
            const X = z.tokenStack[z.tokenStack.length - 1];
            (X[1] || Jn).call(z, void 0, X[0])
        }
        for (d.position = {
                start: sn(x.length > 0 ? x[0][1].start : {
                    line: 1,
                    column: 1,
                    offset: 0
                }),
                end: sn(x.length > 0 ? x[x.length - 2][1].end : {
                    line: 1,
                    column: 1,
                    offset: 0
                })
            }, A = -1; ++A < r.transforms.length;) d = r.transforms[A](d) || d;
        return d
    }

    function u(x, d, z) {
        let C = d - 1,
            A = -1,
            X = !1,
            pn, rn, kn, dn;
        for (; ++C <= z;) {
            const $ = x[C];
            switch ($[1].type) {
                case "listUnordered":
                case "listOrdered":
                case "blockQuote":
                    {
                        $[0] === "enter" ? A++ : A--,
                        dn = void 0;
                        break
                    }
                case "lineEndingBlank":
                    {
                        $[0] === "enter" && (pn && !dn && !A && !kn && (kn = C), dn = void 0);
                        break
                    }
                case "linePrefix":
                case "listItemValue":
                case "listItemMarker":
                case "listItemPrefix":
                case "listItemPrefixWhitespace":
                    break;
                default:
                    dn = void 0
            }
            if (!A && $[0] === "enter" && $[1].type === "listItemPrefix" || A === -1 && $[0] === "exit" && ($[1].type === "listUnordered" || $[1].type === "listOrdered")) {
                if (pn) {
                    let fn = C;
                    for (rn = void 0; fn--;) {
                        const un = x[fn];
                        if (un[1].type === "lineEnding" || un[1].type === "lineEndingBlank") {
                            if (un[0] === "exit") continue;
                            rn && (x[rn][1].type = "lineEndingBlank", X = !0), un[1].type = "lineEnding", rn = fn
                        } else if (!(un[1].type === "linePrefix" || un[1].type === "blockQuotePrefix" || un[1].type === "blockQuotePrefixWhitespace" || un[1].type === "blockQuoteMarker" || un[1].type === "listItemIndent")) break
                    }
                    kn && (!rn || kn < rn) && (pn._spread = !0), pn.end = Object.assign({}, rn ? x[rn][1].start : $[1].end), x.splice(rn || C, 0, ["exit", pn, $[2]]), C++, z++
                }
                if ($[1].type === "listItemPrefix") {
                    const fn = {
                        type: "listItem",
                        _spread: !1,
                        start: Object.assign({}, $[1].start),
                        end: void 0
                    };
                    pn = fn, x.splice(C, 0, ["enter", fn, $[2]]), C++, z++, kn = void 0, dn = !0
                }
            }
        }
        return x[d][1]._spread = X, z
    }

    function i(x, d) {
        return z;

        function z(C) {
            l.call(this, x(C), C), d && d.call(this, C)
        }
    }

    function a() {
        this.stack.push({
            type: "fragment",
            children: []
        })
    }

    function l(x, d, z) {
        this.stack[this.stack.length - 1].children.push(x), this.stack.push(x), this.tokenStack.push([d, z]), x.position = {
            start: sn(d.start),
            end: void 0
        }
    }

    function m(x) {
        return d;

        function d(z) {
            x && x.call(this, z), h.call(this, z)
        }
    }

    function h(x, d) {
        const z = this.stack.pop(),
            C = this.tokenStack.pop();
        if (C) C[0].type !== x.type && (d ? d.call(this, x, C[0]) : (C[1] || Jn).call(this, x, C[0]));
        else throw new Error("Cannot close `" + x.type + "` (" + yn({
            start: x.start,
            end: x.end
        }) + "): it’s not open");
        z.position.end = sn(x.end)
    }

    function f() {
        return It(this.stack.pop())
    }

    function p() {
        this.data.expectingFirstListItemValue = !0
    }

    function g(x) {
        if (this.data.expectingFirstListItemValue) {
            const d = this.stack[this.stack.length - 2];
            d.start = Number.parseInt(this.sliceSerialize(x), 10), this.data.expectingFirstListItemValue = void 0
        }
    }

    function c() {
        const x = this.resume(),
            d = this.stack[this.stack.length - 1];
        d.lang = x
    }

    function T() {
        const x = this.resume(),
            d = this.stack[this.stack.length - 1];
        d.meta = x
    }

    function O() {
        this.data.flowCodeInside || (this.buffer(), this.data.flowCodeInside = !0)
    }

    function q() {
        const x = this.resume(),
            d = this.stack[this.stack.length - 1];
        d.value = x.replace(/^(\r?\n|\r)|(\r?\n|\r)$/g, ""), this.data.flowCodeInside = void 0
    }

    function b() {
        const x = this.resume(),
            d = this.stack[this.stack.length - 1];
        d.value = x.replace(/(\r?\n|\r)$/g, "")
    }

    function R(x) {
        const d = this.resume(),
            z = this.stack[this.stack.length - 1];
        z.label = d, z.identifier = gn(this.sliceSerialize(x)).toLowerCase()
    }

    function S() {
        const x = this.resume(),
            d = this.stack[this.stack.length - 1];
        d.title = x
    }

    function M() {
        const x = this.resume(),
            d = this.stack[this.stack.length - 1];
        d.url = x
    }

    function D(x) {
        const d = this.stack[this.stack.length - 1];
        if (!d.depth) {
            const z = this.sliceSerialize(x).length;
            d.depth = z
        }
    }

    function k() {
        this.data.setextHeadingSlurpLineEnding = !0
    }

    function B(x) {
        const d = this.stack[this.stack.length - 1];
        d.depth = this.sliceSerialize(x).codePointAt(0) === 61 ? 1 : 2
    }

    function j() {
        this.data.setextHeadingSlurpLineEnding = void 0
    }

    function P(x) {
        const z = this.stack[this.stack.length - 1].children;
        let C = z[z.length - 1];
        (!C || C.type !== "text") && (C = gt(), C.position = {
            start: sn(x.start),
            end: void 0
        }, z.push(C)), this.stack.push(C)
    }

    function L(x) {
        const d = this.stack.pop();
        d.value += this.sliceSerialize(x), d.position.end = sn(x.end)
    }

    function I(x) {
        const d = this.stack[this.stack.length - 1];
        if (this.data.atHardBreak) {
            const z = d.children[d.children.length - 1];
            z.position.end = sn(x.end), this.data.atHardBreak = void 0;
            return
        }!this.data.setextHeadingSlurpLineEnding && r.canContainEols.includes(d.type) && (P.call(this, x), L.call(this, x))
    }

    function y() {
        this.data.atHardBreak = !0
    }

    function N() {
        const x = this.resume(),
            d = this.stack[this.stack.length - 1];
        d.value = x
    }

    function H() {
        const x = this.resume(),
            d = this.stack[this.stack.length - 1];
        d.value = x
    }

    function E() {
        const x = this.resume(),
            d = this.stack[this.stack.length - 1];
        d.value = x
    }

    function U() {
        const x = this.stack[this.stack.length - 1];
        if (this.data.inReference) {
            const d = this.data.referenceType || "shortcut";
            x.type += "Reference", x.referenceType = d, delete x.url, delete x.title
        } else delete x.identifier, delete x.label;
        this.data.referenceType = void 0
    }

    function V() {
        const x = this.stack[this.stack.length - 1];
        if (this.data.inReference) {
            const d = this.data.referenceType || "shortcut";
            x.type += "Reference", x.referenceType = d, delete x.url, delete x.title
        } else delete x.identifier, delete x.label;
        this.data.referenceType = void 0
    }

    function G(x) {
        const d = this.sliceSerialize(x),
            z = this.stack[this.stack.length - 2];
        z.label = wt(d), z.identifier = gn(d).toLowerCase()
    }

    function tn() {
        const x = this.stack[this.stack.length - 1],
            d = this.resume(),
            z = this.stack[this.stack.length - 1];
        if (this.data.inReference = !0, z.type === "link") {
            const C = x.children;
            z.children = C
        } else z.alt = d
    }

    function s() {
        const x = this.resume(),
            d = this.stack[this.stack.length - 1];
        d.url = x
    }

    function J() {
        const x = this.resume(),
            d = this.stack[this.stack.length - 1];
        d.title = x
    }

    function en() {
        this.data.inReference = void 0
    }

    function o() {
        this.data.referenceType = "collapsed"
    }

    function K(x) {
        const d = this.resume(),
            z = this.stack[this.stack.length - 1];
        z.label = d, z.identifier = gn(this.sliceSerialize(x)).toLowerCase(), this.data.referenceType = "full"
    }

    function cn(x) {
        this.data.characterReferenceType = x.type
    }

    function Q(x) {
        const d = this.sliceSerialize(x),
            z = this.data.characterReferenceType;
        let C;
        z ? (C = zt(d, z === "characterReferenceMarkerNumeric" ? 10 : 16), this.data.characterReferenceType = void 0) : C = Kn(d);
        const A = this.stack.pop();
        A.value += C, A.position.end = sn(x.end)
    }

    function xn(x) {
        L.call(this, x);
        const d = this.stack[this.stack.length - 1];
        d.url = this.sliceSerialize(x)
    }

    function ln(x) {
        L.call(this, x);
        const d = this.stack[this.stack.length - 1];
        d.url = "mailto:" + this.sliceSerialize(x)
    }

    function mn() {
        return {
            type: "blockquote",
            children: []
        }
    }

    function hn() {
        return {
            type: "code",
            lang: null,
            meta: null,
            value: ""
        }
    }

    function zn() {
        return {
            type: "inlineCode",
            value: ""
        }
    }

    function ot() {
        return {
            type: "definition",
            identifier: "",
            label: null,
            title: null,
            url: ""
        }
    }

    function ct() {
        return {
            type: "emphasis",
            children: []
        }
    }

    function _n() {
        return {
            type: "heading",
            depth: 0,
            children: []
        }
    }

    function Ln() {
        return {
            type: "break"
        }
    }

    function Mn() {
        return {
            type: "html",
            value: ""
        }
    }

    function ht() {
        return {
            type: "image",
            title: null,
            url: "",
            alt: null
        }
    }

    function Nn() {
        return {
            type: "link",
            title: null,
            url: "",
            children: []
        }
    }

    function Dn(x) {
        return {
            type: "list",
            ordered: x.type === "listOrdered",
            start: null,
            spread: x._spread,
            children: []
        }
    }

    function pt(x) {
        return {
            type: "listItem",
            spread: x._spread,
            checked: null,
            children: []
        }
    }

    function mt() {
        return {
            type: "paragraph",
            children: []
        }
    }

    function ft() {
        return {
            type: "strong",
            children: []
        }
    }

    function gt() {
        return {
            type: "text",
            value: ""
        }
    }

    function xt() {
        return {
            type: "thematicBreak"
        }
    }
}

function sn(n) {
    return {
        line: n.line,
        column: n.column,
        offset: n.offset
    }
}

function st(n, r) {
    let t = -1;
    for (; ++t < r.length;) {
        const e = r[t];
        Array.isArray(e) ? st(n, e) : wr(n, e)
    }
}

function wr(n, r) {
    let t;
    for (t in r)
        if (lt.call(r, t)) switch (t) {
            case "canContainEols":
                {
                    const e = r[t];e && n[t].push(...e);
                    break
                }
            case "transforms":
                {
                    const e = r[t];e && n[t].push(...e);
                    break
                }
            case "enter":
            case "exit":
                {
                    const e = r[t];e && Object.assign(n[t], e);
                    break
                }
        }
}

function Jn(n, r) {
    throw n ? new Error("Cannot close `" + n.type + "` (" + yn({
        start: n.start,
        end: n.end
    }) + "): a different token (`" + r.type + "`, " + yn({
        start: r.start,
        end: r.end
    }) + ") is open") : new Error("Cannot close document, a token (`" + r.type + "`, " + yn({
        start: r.start,
        end: r.end
    }) + ") is still open")
}

function Tr(n) {
    const r = this;
    r.parser = t;

    function t(e) {
        return yr(e, jn(Cn(Cn({}, r.data("settings")), n), {
            extensions: r.data("micromarkExtensions") || [],
            mdastExtensions: r.data("fromMarkdownExtensions") || []
        }))
    }
}
export {
    Ft as a, v as b, nn as c, Fn as d, wn as e, _ as f, An as g, Vn as h, w as i, F as j, Bt as k, Sn as l, Y as m, gn as n, Tr as r, an as s, Ot as u
};
//# sourceMappingURL=nfccle6oyncifphl.js.map