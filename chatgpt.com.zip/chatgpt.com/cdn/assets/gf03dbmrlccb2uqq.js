import {
    r as a,
    j as t
} from "./fg33krlcm0qyi6yw.js";
import {
    bb as j,
    l as k
} from "./dykg4ktvbu3mhmdo.js";
import {
    l as w
} from "./k15yxxoybkkir2ou.js";

function b(m) {
    const {
        speed: f = 100,
        value: e = "",
        typing: c,
        onTyped: s,
        initTyped: h,
        chunk: x
    } = m, [r, i] = a.useState(0), u = a.useRef(void 0), d = w(), g = j();

    function p(n, l, o) {
        u.current = d(function() {
            n >= l.length || (i(n + o), s == null || s(), p(n + o, l, o))
        }, f)
    }
    return a.useEffect(() => (i(h ? e.length : 0), c && p(0, e, x ? 4 : 1), () => {
        clearTimeout(u.current)
    }), [c, e]), t.jsxs(t.Fragment, {
        children: [t.jsx("span", {
            className: k("whitespace-pre-wrap", r < e.length && "result-streaming no-flow", g ? "dark" : "light"),
            children: t.jsx("span", {
                children: e.slice(0, r)
            })
        }), t.jsx("span", {
            className: "whitespace-pre-wrap text-transparent",
            children: e.slice(r)
        })]
    })
}
export {
    b as T
};
//# sourceMappingURL=gf03dbmrlccb2uqq.js.map