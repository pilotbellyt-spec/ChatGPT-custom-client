var Ke = Object.defineProperty,
    Xe = Object.defineProperties;
var Je = Object.getOwnPropertyDescriptors;
var xe = Object.getOwnPropertySymbols;
var Ze = Object.prototype.hasOwnProperty,
    et = Object.prototype.propertyIsEnumerable;
var ye = t => {
    throw TypeError(t)
};
var ie = (t, e, s) => e in t ? Ke(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : t[e] = s,
    A = (t, e) => {
        for (var s in e || (e = {})) Ze.call(e, s) && ie(t, s, e[s]);
        if (xe)
            for (var s of xe(e)) et.call(e, s) && ie(t, s, e[s]);
        return t
    },
    K = (t, e) => Xe(t, Je(e));
var T = (t, e, s) => ie(t, typeof e != "symbol" ? e + "" : e, s),
    _e = (t, e, s) => e.has(t) || ye("Cannot " + s);
var M = (t, e, s) => (_e(t, e, "read from private field"), s ? s.call(t) : e.get(t)),
    E = (t, e, s) => e.has(t) ? ye("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(t) : e.set(t, s),
    F = (t, e, s, n) => (_e(t, e, "write to private field"), n ? n.call(t, s) : e.set(t, s), s);
import {
    E as tt,
    c as y,
    r as v,
    j as g,
    M as fe,
    v as U,
    e as H,
    Q as st
} from "./fg33krlcm0qyi6yw.js";
import {
    c as nt,
    a as ot,
    i as it,
    m as at,
    C as $e,
    d as rt,
    W as ct,
    V as lt
} from "./s8d7t6m9lmrag91y.js";
import {
    nE as I,
    rj as Be,
    jf as dt,
    jg as ut,
    og as me,
    eB as he,
    nC as ft,
    AE as mt,
    pM as ne,
    jN as De,
    Bu as ht,
    Ao as gt,
    nI as pt,
    Ak as je,
    Bv as Te,
    Bw as Ie,
    tW as vt,
    Am as bt,
    n as Mt,
    Bx as St,
    By as ae,
    Bz as X,
    Ae as Ct,
    BA as xt,
    sH as Ae,
    Ay as yt,
    uR as _t,
    uS as re,
    BB as Tt
} from "./k15yxxoybkkir2ou.js";
import {
    C as oe
} from "./ftef8970ba1zoykr.js";
import {
    d as Re,
    e as z,
    h as It,
    m as we,
    t as ke,
    r as ce,
    a as Pe,
    b as Ee,
    i as Fe,
    c as At,
    u as Rt
} from "./k488bo5tj9qgdrgq.js";
import {
    hh as ze,
    Ai as qe,
    dF as V,
    dH as ee,
    k_ as Se,
    Aj as Ce,
    of as wt,
    fT as kt,
    bX as Et,
    Ak as Ge,
    dD as Ft,
    s9 as ge,
    Al as pe,
    sa as ve,
    e2 as J,
    dL as q,
    e4 as Nt,
    fh as Vt,
    dR as Z,
    fc as Ne,
    dB as Ve,
    dJ as Oe,
    ef as Le,
    eX as Ot,
    dI as Lt,
    eY as Ut,
    c_ as $t,
    e_ as Bt,
    fe as Dt,
    nm as jt,
    Am as Pt,
    A9 as We,
    sb as zt,
    l as Q,
    d as He,
    c0 as be,
    mI as qt,
    nR as Ue,
    lg as Gt,
    fV as Wt
} from "./dykg4ktvbu3mhmdo.js";
import {
    D as Ht,
    a as Qt
} from "./cu0e6szsqsyduwov.js";
import {
    M as Yt
} from "./k253gzle9qy7mdll.js";
import {
    d as Kt,
    u as Xt,
    g as Jt,
    a as Zt,
    A as es
} from "./fz8xw1971c2kf2eb.js";
import {
    s as Qe,
    u as ts
} from "./enojslb0kkkm419z.js";
import {
    C as ss,
    S as ns
} from "./kwq03wk6n8w9089k.js";
import {
    B as os,
    G as is,
    u as as
} from "./dapgo43htqk76ir6.js";
import {
    M as rs,
    a as cs,
    S as ls
} from "./nm0so544a95lw6u3.js";
import "./iiok29s29bpdre61.js";
import "./e9kbgh7j5o6g3dr6.js";
import "./ebc4iyfg14nu1gw4.js";
import "./gy1lpvuoewmzh42c.js";
import "./jed1ux7qibe55pmj.js";
import "./h1em0bjkpkjv8ykw.js";
import "./nfccle6oyncifphl.js";
import "./hu1bt0oauegdhua6.js";

function ds(t, e) {
    if (Object.is(t, e)) return !0;
    if (typeof t != "object" || t === null || typeof e != "object" || e === null) return !1;
    if (t instanceof Map && e instanceof Map) {
        if (t.size !== e.size) return !1;
        for (const [n, i] of t)
            if (!Object.is(i, e.get(n))) return !1;
        return !0
    }
    if (t instanceof Set && e instanceof Set) {
        if (t.size !== e.size) return !1;
        for (const n of t)
            if (!e.has(n)) return !1;
        return !0
    }
    const s = Object.keys(t);
    if (s.length !== Object.keys(e).length) return !1;
    for (const n of s)
        if (!Object.prototype.hasOwnProperty.call(e, n) || !Object.is(t[n], e[n])) return !1;
    return !0
}
const {
    useRef: us
} = tt;

function Ye(t) {
    const e = us();
    return s => {
        const n = t(s);
        return ds(e.current, n) ? e.current : e.current = n
    }
}

function fs(t) {
    return t === nt.LOST
}
const ms = t => {
    "use forget";
    const e = y.c(13),
        {
            clientThreadId: s
        } = t,
        n = ze(s),
        i = I(hs),
        {
            voiceName: o
        } = Be(),
        [a, r] = v.useState(!1),
        {
            connectionState: c,
            voiceConnectionQuality: l,
            hasConnectedOnce: d
        } = I(Ye(gs)),
        f = qe();
    let u;
    e[0] !== s || e[1] !== n || e[2] !== i || e[3] !== o ? (u = async () => {
        dt(ut.Retry), r(!0), await me(async () => {
            const w = {
                conversation_id: n,
                eventSource: "lost_connection_hint_message",
                voice_mode: i,
                voice: o,
                clientThreadId: s,
                gizmo_id: V.getGizmoId(ee(s)),
                skipCacheReason: "lost-connection-retry",
                forceDisconnect: !0
            };
            await he({
                type: "STOP",
                reason: Ht.Failed
            }), await he({
                type: "START",
                args: w
            })
        }, ps, () => {
            r(!1)
        })
    }, e[0] = s, e[1] = n, e[2] = i, e[3] = o, e[4] = u) : u = e[4];
    const m = u;
    let h;
    e[5] === Symbol.for("react.memo_cache_sentinel") ? (h = g.jsx(fe, {
        id: "QaPbww",
        defaultMessage: "Lost connection."
    }), e[5] = h) : h = e[5];
    let p;
    e[6] === Symbol.for("react.memo_cache_sentinel") ? (p = g.jsx("strong", {
        children: g.jsx(fe, {
            id: "oyHr3m",
            defaultMessage: "Retry"
        })
    }), e[6] = p) : p = e[6];
    let b;
    e[7] !== m ? (b = g.jsxs("div", {
        className: "inline-flex items-center",
        children: [h, g.jsx("button", {
            onClick: m,
            className: "ms-1",
            children: p
        })]
    }), e[7] = m, e[8] = b) : b = e[8];
    const S = b;
    let C;
    e: {
        if (!d || a || f) {
            C = !1;
            break e
        } else if (c !== oe.Connected) {
            C = !0;
            break e
        } else if (fs(l)) {
            C = !0;
            break e
        }
        C = !1
    }
    const x = C;
    let _, R;
    return e[9] !== x || e[10] !== S ? (_ = () => {
        x ? Re.set({
            id: U(),
            hintMessage: S,
            modalMessage: null
        }) : Re.set(z())
    }, R = [x, S], e[9] = x, e[10] = S, e[11] = _, e[12] = R) : (_ = e[11], R = e[12]), v.useEffect(_, R), null
};

function hs(t) {
    return t.voiceMode
}

function gs(t) {
    return {
        connectionState: t.server.connectionState,
        voiceConnectionQuality: t.server.voiceConnectionQuality,
        hasConnectedOnce: t.hasConnectedOnce
    }
}

function ps(t) {
    const e = t instanceof Error ? t.message : String(t);
    Se.voiceMode.error({
        error: e,
        eventSource: "lost_connection_hint_message"
    })
}
const vs = () => {
        "use forget";
        const t = y.c(10),
            e = H(),
            {
                type: s,
                granted: n
            } = Ce();
        let i;
        t[0] === Symbol.for("react.memo_cache_sentinel") ? (i = wt() && kt, t[0] = i) : i = t[0];
        const o = i,
            a = s === "requested" && !n;
        let r;
        t[1] !== e ? (r = e.formatMessage(le.hint), t[1] = e, t[2] = r) : r = t[2];
        const c = r;
        let l;
        t[3] !== c ? (l = o ? g.jsxs("a", {
            href: "ms-settings:privacy-microphone",
            className: It,
            children: [c, g.jsx(Et, {
                className: "icon-sm ms-1"
            })]
        }) : c, t[3] = c, t[4] = l) : l = t[4];
        const d = l;
        let f, u;
        return t[5] !== d || t[6] !== e || t[7] !== a ? (f = () => {
            a ? we.set({
                id: U(),
                hintMessage: d,
                modalMessage: {
                    title: e.formatMessage(le.title),
                    description_markdown: e.formatMessage(le.description_markdown),
                    buttons: []
                }
            }) : we.set(z())
        }, u = [a, e, d], t[5] = d, t[6] = e, t[7] = a, t[8] = f, t[9] = u) : (f = t[8], u = t[9]), v.useEffect(f, u), null
    },
    le = {
        hint: {
            id: "micMessages.hint",
            defaultMessage: "Enable microphone access in Settings",
            description: "Hint to the user to manually enable microphone access for voice mode"
        },
        title: {
            id: "micMessages.title",
            defaultMessage: "Microphone access required",
            description: "Title for modal that informs the user that microphone access is required for voice mode"
        },
        description_markdown: {
            id: "micMessages.description_markdown",
            defaultMessage: "To use voice mode, you'll need to enable your microphone and try again.",
            description: "Description for modal that informs the user that microphone access is required for voice mode"
        }
    },
    bs = () => {
        "use forget";
        const t = y.c(8),
            e = I(Ms);
        let s;
        if (e) {
            let a;
            t[0] === Symbol.for("react.memo_cache_sentinel") ? (a = g.jsx(Yt, {
                className: "icon-sm me-1"
            }), t[0] = a) : a = t[0];
            let r;
            t[1] !== e.text ? (r = g.jsxs("div", {
                className: "flex items-center",
                children: [a, e.text]
            }), t[1] = e.text, t[2] = r) : r = t[2], s = r
        } else s = null;
        const n = s;
        let i;
        t[3] !== n ? (i = () => {
            n ? ke.set({
                id: U(),
                hintMessage: n,
                modalMessage: null
            }) : ke.set(z())
        }, t[3] = n, t[4] = i) : i = t[4];
        let o;
        return t[5] !== n || t[6] !== e ? (o = [e, n], t[5] = n, t[6] = e, t[7] = o) : o = t[7], v.useEffect(i, o), null
    };

function Ms(t) {
    return t.server.toolUpdate
}
const Ss = () => {
    "use forget";
    var l;
    const t = y.c(8),
        e = I(Cs);
    let s;
    t[0] !== (e == null ? void 0 : e.rate_limit_message) ? (s = (l = e == null ? void 0 : e.rate_limit_message) != null ? l : {}, t[0] = e == null ? void 0 : e.rate_limit_message, t[1] = s) : s = t[1];
    const {
        reaching_limit_disclosure: n,
        exceed_limit_message: i
    } = s;
    let o, a;
    t[2] !== n ? (o = () => {
        if (n) {
            const d = ce().hintMessage;
            if (n.hint === d) return;
            ce.set({
                id: U(),
                hintMessage: n.hint,
                modalMessage: {
                    title: n.title,
                    description_markdown: n.message_markdown,
                    buttons: n.buttons
                }
            })
        } else ce.set(z())
    }, a = [n], t[2] = n, t[3] = o, t[4] = a) : (o = t[3], a = t[4]), v.useEffect(o, a);
    let r, c;
    return t[5] !== i ? (r = () => {
        if (i) {
            Pe.set({
                id: U(),
                hintMessage: i.title,
                modalMessage: {
                    title: i.title,
                    description_markdown: i.description_markdown,
                    buttons: i.buttons
                }
            });
            const d = i.buttons.some(xs),
                f = i.buttons.some(ys);
            Se.rateLimitReached.success({
                upgrade_to_plus: d,
                upgrade_to_pro: f
            })
        }
    }, c = [i], t[5] = i, t[6] = r, t[7] = c) : (r = t[6], c = t[7]), v.useEffect(r, c), null
};

function Cs(t) {
    return t.server.usage
}

function xs(t) {
    return t.action === "upgrade_to_plus"
}

function ys(t) {
    return t.action === "upgrade_to_pro"
}
const _s = () => {
        "use forget";
        const t = y.c(9),
            e = ft();
        let s;
        t[0] !== (e == null ? void 0 : e.default_voice_mode) || t[1] !== (e == null ? void 0 : e.modes) ? (s = e == null ? void 0 : e.modes.find(d => d.mode === (e == null ? void 0 : e.default_voice_mode)), t[0] = e == null ? void 0 : e.default_voice_mode, t[1] = e == null ? void 0 : e.modes, t[2] = s) : s = t[2];
        const n = s,
            i = n == null ? void 0 : n.disclosure_message,
            o = n == null ? void 0 : n.info_message;
        let a, r;
        t[3] !== i ? (a = () => {
            i ? Ee.set({
                id: U(),
                hintMessage: i.hint,
                modalMessage: {
                    title: i.title,
                    description_markdown: i.message_markdown,
                    buttons: i.buttons
                }
            }) : Ee.set(z())
        }, r = [i], t[3] = i, t[4] = a, t[5] = r) : (a = t[4], r = t[5]), v.useEffect(a, r);
        let c, l;
        return t[6] !== o ? (c = () => {
            o ? Fe.set({
                id: U(),
                hintMessage: o.title,
                modalMessage: {
                    title: o.title,
                    description_markdown: o.message_markdown,
                    buttons: o.buttons
                }
            }) : Fe.set(z())
        }, l = [o], t[6] = o, t[7] = c, t[8] = l) : (c = t[7], l = t[8]), v.useEffect(c, l), null
    },
    Ts = t => {
        "use forget";
        const e = y.c(9),
            {
                clientThreadId: s
            } = t;
        let n;
        e[0] === Symbol.for("react.memo_cache_sentinel") ? (n = [], e[0] = n) : n = e[0], v.useEffect(As, n);
        let i;
        e[1] !== s ? (i = g.jsx(ms, {
            clientThreadId: s
        }), e[1] = s, e[2] = i) : i = e[2];
        let o, a, r, c;
        e[3] === Symbol.for("react.memo_cache_sentinel") ? (o = g.jsx(vs, {}), a = g.jsx(bs, {}), r = g.jsx(Ss, {}), c = g.jsx(_s, {}), e[3] = o, e[4] = a, e[5] = r, e[6] = c) : (o = e[3], a = e[4], r = e[5], c = e[6]);
        let l;
        return e[7] !== i ? (l = g.jsxs(g.Fragment, {
            children: [i, o, a, r, c]
        }), e[7] = i, e[8] = l) : l = e[8], l
    };

function Is() {
    At()
}

function As() {
    return Is
}
const Rs = () => {
    "use forget";
    const t = y.c(11),
        {
            permissionsRequested: e,
            requestMicrophonePermissions: s,
            userDeclinedMicrophonePermissions: n,
            microphoneAvailable: i,
            microphoneLabel: o
        } = mt(),
        {
            active: a,
            forceMuted: r
        } = I(Ye(ws));
    let c, l;
    t[0] !== a || t[1] !== r || t[2] !== i || t[3] !== o || t[4] !== e || t[5] !== n ? (c = () => {
        e && Ge.set({
            type: "requested",
            granted: i,
            active: a,
            forceMuted: r,
            label: !n && o ? o : ""
        })
    }, l = [n, i, o, e, a, r], t[0] = a, t[1] = r, t[2] = i, t[3] = o, t[4] = e, t[5] = n, t[6] = c, t[7] = l) : (c = t[6], l = t[7]), v.useEffect(c, l);
    const d = v.useRef(!1);
    let f, u;
    return t[8] !== s ? (f = () => (d.current || (d.current = !0, s()), ks), u = [s], t[8] = s, t[9] = f, t[10] = u) : (f = t[9], u = t[10]), v.useEffect(f, u), null
};

function ws(t) {
    var e, s;
    return {
        active: !!((e = t.dev.room) != null && e.localParticipant.isMicrophoneEnabled),
        forceMuted: !!((s = t.dev.room) != null && s.localParticipant.isMicrophoneForceMuted)
    }
}

function ks() {
    Ge.set({
        type: "unrequested",
        granted: !1,
        active: !1,
        forceMuted: !1,
        label: ""
    })
}
const Es = "/cdn/assets/hangup_0db-gkj9zamd.ogg";
let B = null;

function Fs() {
    try {
        B ? (B.pause(), B.currentTime = 0) : (B = new Audio(Es), B.volume = 1), B.play()
    } catch (t) {
        ne.debug("Failed to play hangup sound", t)
    }
}

function Ns() {
    const t = De(),
        {
            room: e
        } = Kt();
    return async s => {
        e && await ht({
            room: e,
            voiceStore: t,
            event: {
                type: pt.RelayMessage,
                payload: {
                    type: gt.RelayMessage,
                    message: s
                }
            }
        })
    }
}

function Vs({
    clientThreadId: t,
    parentMessageId: e,
    prependMessages: s,
    promptMessage: n,
    appendMessages: i,
    intl: o
}) {
    const a = t.startsWith("WEB:"),
        r = new Us({
            ctx: Ft(),
            clientThreadId: t,
            isHistoryAndTrainingDisabled: !1,
            isFirstCompletionInThread: a,
            queryClient: new st,
            isSnorlaxEnabledForGizmo: !1,
            intl: o
        });
    r.startOrContinueConversation({
        parentMessageId: e,
        prependMessages: s,
        promptMessage: n,
        appendMessages: i
    }), ge.set(r), pe.set(!1)
}

function Os() {
    je(() => {
        const t = ge();
        t == null || t.endCompletion(), ge.set(null), ve.set(null)
    })
}
const Ls = 500;
class Us {
    constructor({
        ctx: e,
        clientThreadId: s,
        isHistoryAndTrainingDisabled: n,
        isFirstCompletionInThread: i,
        queryClient: o,
        isSnorlaxEnabledForGizmo: a,
        intl: r
    }) {
        T(this, "messageIdsReceived", []);
        T(this, "fullChatMessageStreaming", !1);
        T(this, "ctx");
        T(this, "clientThreadId");
        T(this, "isHistoryAndTrainingDisabled");
        T(this, "isFirstCompletionInThread");
        T(this, "queryClient");
        T(this, "isSnorlaxEnabledForGizmo");
        T(this, "intl");
        T(this, "messagesToUpdate", {});
        T(this, "allIncompleteMessageIds", new Set);
        T(this, "responseThreadId");
        T(this, "treatCompletionAsAsync", !1);
        T(this, "placeholderNodeId");
        T(this, "debouncedUpdateExistingMessages", Dt(() => {
            const e = Object.values(this.messagesToUpdate);
            e.length !== 0 && (q(this.clientThreadId, s => {
                Z.updateTree(s, n => {
                    for (const i of e) n.updateNodeMessage(i.id, i), i.status !== "in_progress" && (n.updateNodeMetadata(i.id, {
                        completionSampleFinishTime: Date.now()
                    }), this.allIncompleteMessageIds.delete(i.id))
                })
            }), this.messagesToUpdate = {})
        }, 50, {
            leading: !0,
            maxWait: 50
        }));
        this.ctx = e, this.clientThreadId = s, this.isHistoryAndTrainingDisabled = n, this.isFirstCompletionInThread = i, this.queryClient = o, this.isSnorlaxEnabledForGizmo = a, this.intl = r
    }
    scrollToIfUserMessage(e) {
        e.author.role === J.User && je(() => {
            q(this.clientThreadId, s => {
                s.scrollToMessageId = e.id
            })
        }, Ls)
    }
    handleMessage({
        message: e,
        conversationId: s
    }) {
        this.messageIdsReceived.includes(e.id) || this.messageIdsReceived.push(e.id);
        const n = this.messageIdsReceived.indexOf(e.id);
        if (n !== -1 && e.metadata) {
            const i = this.messageIdsReceived[n - 1];
            e.metadata.parent_id = i
        }
        if (e.author.role === J.User && e.content.content_type === Nt.MultimodalText && e.content.parts.length === 0 && (e.content.parts = [{
                content_type: Vt.AudioTranscription,
                text: this.intl.formatMessage({
                    id: "voice-completion-request.transcribing",
                    defaultMessage: "Transcribing…"
                }),
                direction: "in"
            }]), this.scrollToIfUserMessage(e), V.getTree(ee(s)).containsNodeOrMessageId(e.id)) {
            this.messagesToUpdate[e.id] = e, this.debouncedUpdateExistingMessages();
            return
        }
        this.debouncedUpdateExistingMessages.flush(), q(this.clientThreadId, i => {
            Z.updateTree(i, (o, a) => {
                var d;
                const r = {
                    requestId: e.id
                };
                e.status !== "in_progress" ? r.completionSampleFinishTime = Date.now() : this.allIncompleteMessageIds.add(e.id);
                const c = K(A({}, e), {
                        clientMetadata: r
                    }),
                    l = (d = e.metadata) == null ? void 0 : d.parent_id;
                if (l) {
                    if (this.placeholderNodeId && o.getParent(this.placeholderNodeId).id === o.getNodeByIdOrMessageId(l).id)
                        if (Ne(c)) {
                            o.prependNode(this.placeholderNodeId, c);
                            return
                        } else o.deleteNode(this.placeholderNodeId), this.placeholderNodeId = void 0;
                    return o.addMessageNode(l, c)
                } else {
                    const f = o.findFirst(u => !Ne(u.message));
                    if (f) o.prependNode(f.id, c);
                    else return o.addMessageNode(a, c)
                }
            })
        })
    }
    beginAssistantResponse() {
        Te.set(Ve(this.ctx, this.clientThreadId), !0), Ie(this.clientThreadId, {
            source: Le.CLIENT,
            value: Oe.STREAMING
        }), pe.set(!0)
    }
    addOptimisticUserMessages({
        parentMessageId: e,
        promptMessage: s
    }) {
        this.beginAssistantResponse(), this.messageIdsReceived.push(s.id), q(this.clientThreadId, n => {
            Z.updateTree(n, (i, o) => (e && (o = V.getNode(n, e).id), s && (r => {
                i.containsNodeOrMessageId(r.id) || (r.clientMetadata = K(A({}, r.clientMetadata), {
                    isOptimistic: !0
                }), o = i.addMessageNode(o, r))
            })(s), o))
        })
    }
    startOrContinueConversation({
        parentMessageId: e,
        prependMessages: s,
        promptMessage: n,
        appendMessages: i
    }) {
        q(this.clientThreadId, o => {
            Z.updateTree(o, (a, r) => {
                if (e && (r = V.getNode(o, e).id), s)
                    for (const c of s) r = a.addMessageNode(r, c);
                if (n && (r = a.addMessageNode(r, n)), i)
                    for (const c of i) r = a.addMessageNode(r, c);
                return r
            })
        })
    }
    endAssistantResponse() {
        Te.set(Ve(this.ctx, this.clientThreadId), !1), Ie(this.clientThreadId, {
            source: Le.CLIENT,
            value: Oe.UNREAD
        }), pe.set(!1)
    }
    handleConversationUpdate(e) {
        if (this.responseThreadId === void 0) {
            const s = e;
            this.responseThreadId = s;
            const n = Ot(this.clientThreadId),
                i = Lt(this.clientThreadId) !== s;
            if (ne.debug("Init new thread", {
                    isNewClientThread: n,
                    responseHasServerThreadId: i
                }), n && i && Ut(this.ctx, this.clientThreadId, s), this.isFirstCompletionInThread) {
                const o = ee(this.clientThreadId);
                !this.isHistoryAndTrainingDisabled && vt(o == null ? void 0 : o.mode) && $t(this.ctx) && (Bt(this.queryClient, V.getGizmoId(o)), o != null && o.disableConversationNavigation || bt(Mt, this.queryClient, s, this.isSnorlaxEnabledForGizmo))
            }
        }
    }
    handleResponse(e) {
        const s = e.message.author,
            n = e.message.status;
        (s.role === J.Assistant || s.role === J.Tool) && (n === "in_progress" && !this.fullChatMessageStreaming ? (this.fullChatMessageStreaming = !0, this.beginAssistantResponse()) : n !== "in_progress" && this.fullChatMessageStreaming && (this.fullChatMessageStreaming = !1, this.endAssistantResponse())), this.responseThreadId === void 0 && e.conversationId && this.handleConversationUpdate(e.conversationId), this.handleMessage({
            message: e.message,
            conversationId: this.clientThreadId
        })
    }
    endCompletion() {
        this.fullChatMessageStreaming && this.endAssistantResponse()
    }
}
const $s = t => {
    "use forget";
    const e = y.c(20),
        {
            clientThreadId: s
        } = t,
        n = St(),
        i = De(),
        o = H(),
        a = I(Bs);
    let r;
    e[0] !== s ? (r = {
        conversationId: s
    }, e[0] = s, e[1] = r) : r = e[1];
    const c = ot(r),
        l = jt(),
        d = I(Ds),
        f = Ns(),
        u = Pt();
    let m, h;
    e[2] !== s || e[3] !== o || e[4] !== n || e[5] !== i ? (m = () => {
        if ((n == null ? void 0 : n.command.type) === "START") {
            const x = n.command.oldConversationId;
            if (x && x === s || !ae(n.id)) return;
            Qe.set(n.command.args), i.setState(_ => (_.isVoiceModeActive = !0, _.conversationId = s, _)), We.set(!0), Vs({
                clientThreadId: s,
                intl: o
            }), X(n.id)
        }
    }, h = [s, o, n, i], e[2] = s, e[3] = o, e[4] = n, e[5] = i, e[6] = m, e[7] = h) : (m = e[6], h = e[7]), v.useEffect(m, h);
    let p, b;
    e[8] !== c || e[9] !== l || e[10] !== n ? (p = () => {
        if ((n == null ? void 0 : n.command.type) === "STOP" && ae(n.id)) {
            if (!l) return X(n.id);
            zt.set(!0);
            const x = n.command.reason;
            me(async () => {
                await c(x)
            }, js, () => {
                Os(), Fs(), Ct(), X(n.id)
            })
        }
    }, b = [c, l, n], e[8] = c, e[9] = l, e[10] = n, e[11] = p, e[12] = b) : (p = e[11], b = e[12]), v.useEffect(p, b);
    let S, C;
    return e[13] !== a || e[14] !== n || e[15] !== f || e[16] !== d || e[17] !== u ? (S = () => {
        if ((n == null ? void 0 : n.command.type) === "RELAY" && a === oe.Connected && d && u && ae(n.id)) {
            const {
                id: x,
                command: _
            } = n, {
                message: R,
                parentMessageId: w
            } = _;
            me(async () => {
                u.addOptimisticUserMessages({
                    parentMessageId: w,
                    promptMessage: R
                }), await f(R)
            }, Ps, () => {
                X(x)
            })
        }
    }, C = [a, n, f, d, u], e[13] = a, e[14] = n, e[15] = f, e[16] = d, e[17] = u, e[18] = S, e[19] = C) : (S = e[18], C = e[19]), v.useEffect(S, C), null
};

function Bs(t) {
    return t.server.connectionState
}

function Ds(t) {
    return t.server.relayReady
}

function js(t) {
    ne.error("Error exiting voice state", t)
}

function Ps(t) {
    ne.error("Error relaying message", t)
}
const zs = t => {
    "use forget";
    const e = y.c(9),
        {
            clientThreadId: s
        } = t,
        {
            startVoiceMode: n
        } = Xt(),
        i = ze(s),
        o = v.useRef(!1),
        {
            granted: a
        } = Ce(),
        r = ts(),
        {
            voiceName: c
        } = Be(),
        l = xt(s);
    let d, f;
    return e[0] !== s || e[1] !== a || e[2] !== l || e[3] !== i || e[4] !== n || e[5] !== r || e[6] !== c ? (d = () => {
        var u;
        if (!o.current && a) {
            o.current = !0;
            const m = ee(s);
            let h;
            r !== void 0 ? (h = r, Qe.set(void 0)) : (h = Jt({
                serverThreadId: i,
                parentMessageId: (u = V.getCurrentNode(m)) == null ? void 0 : u.id,
                isAdvancedMode: !0,
                eventSource: "integrated_ux_composer_speech_button",
                clientThreadId: s,
                gizmoId: V.getGizmoId(m)
            }), Se.voiceSessionStarted.click({
                voice: c
            }), h.requested_default_model = l != null ? l : void 0), n(h)
        }
    }, f = [s, a, l, i, n, r, c], e[0] = s, e[1] = a, e[2] = l, e[3] = i, e[4] = n, e[5] = r, e[6] = c, e[7] = d, e[8] = f) : (d = e[7], f = e[8]), v.useEffect(d, f), null
};
var D, W, k, j, P, O, L, te;
const se = class se {
    constructor(e, s) {
        E(this, D);
        E(this, W);
        E(this, k);
        E(this, j, []);
        E(this, P, {});
        E(this, O);
        E(this, L);
        F(this, k, e);
        const n = e.getUniformBlockIndex(s, M(se, te)),
            i = e.getActiveUniformBlockParameter(s, n, e.UNIFORM_BLOCK_DATA_SIZE);
        F(this, O, e.createBuffer()), e.bindBuffer(e.UNIFORM_BUFFER, M(this, O)), e.bufferData(e.UNIFORM_BUFFER, i, e.DYNAMIC_DRAW);
        const o = 0;
        e.bindBufferBase(e.UNIFORM_BUFFER, o, M(this, O)), e.uniformBlockBinding(s, n, o);
        const a = e.getActiveUniformBlockParameter(s, n, e.UNIFORM_BLOCK_ACTIVE_UNIFORM_INDICES);
        F(this, j, []), F(this, P, {});
        for (let r = 0; r < a.length; r++) {
            const c = a[r];
            if (c == null) continue;
            const l = e.getActiveUniform(s, c);
            if (!l) throw new Error("No uniformInfo for index " + c);
            let d = l.name;
            d = d.replace(/\[0\]$/, "");
            const f = e.getActiveUniforms(s, [c], e.UNIFORM_OFFSET),
                u = Array.isArray(f) && f.length > 0 ? f[0] : 0;
            M(this, j).push(d), M(this, P)[d] = u
        }
        F(this, L, new ArrayBuffer(i)), F(this, D, new Float32Array(M(this, L))), F(this, W, new Int32Array(M(this, L)))
    }
    setVariablesAndRender(e) {
        for (const s of M(this, j)) {
            const [, n] = s.split("."), o = M(this, P)[s] / 4, a = e[n];
            typeof a == "number" ? M(this, D)[o] = a : typeof a == "boolean" ? M(this, W)[o] = a ? 1 : 0 : Array.isArray(a) && M(this, D).set(a, o)
        }
        M(this, k).bindBuffer(M(this, k).UNIFORM_BUFFER, M(this, O)), M(this, k).bufferSubData(M(this, k).UNIFORM_BUFFER, 0, M(this, L)), M(this, k).drawArrays(M(this, k).TRIANGLE_STRIP, 0, 6)
    }
};
D = new WeakMap, W = new WeakMap, k = new WeakMap, j = new WeakMap, P = new WeakMap, O = new WeakMap, L = new WeakMap, te = new WeakMap, E(se, te, "BlorbUniformsObject");
let Me = se;
var qs = "#version 300 es\n#define E (2.71828182846)\n#define pi (3.14159265358979323844)\n\nprecision highp float;\n\nstruct ColoredSDF {\n  float distance;\n  vec4 color;\n};\n\nstruct SDFArgs {\n  vec2 st;\n  float amount;\n  float duration;\n  float time;\n  float mainRadius;\n};\n\n/* ----------------------- Utilities actually used ----------------------- */\n\nfloat scaled(float edge0, float edge1, float x) {\n  return clamp((x - edge0) / (edge1 - edge0), float(0), float(1));\n}\n\nfloat spring(float t, float d) {\n  return 1.0 - exp(-E * 2.0 * t) * cos((1.0 - d) * 115.0 * t);\n}\n\nfloat bounce(float t, float d) {\n  return -sin(pi * (1.0 - d) * t) * (1.0 - t) * exp(-E * 2.0 * t) * t * 10.0;\n}\n\nfloat opSmoothUnion(float d1, float d2, float k) {\n  if (k <= 0.0) k = 0.000001;\n  float h = clamp(0.5 + 0.5 * (d2 - d1) / k, 0.0, 1.0);\n  return mix(d2, d1, h) - k * h * (1.0 - h);\n}\n\nfloat sdRoundedBox(vec2 p, vec2 b, vec4 r) {\n  r.xy = p.x > 0.0 ? r.xy : r.zw;\n  r.x = p.y > 0.0 ? r.x : r.y;\n  vec2 q = abs(p) - b + r.x;\n  return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r.x;\n}\n\n/* --------------------------- Active states ----------------------------- */\n\nColoredSDF applyIdleState(\n  ColoredSDF sdf,\n  SDFArgs args,\n  bool isWhiteForeground\n) {\n  float midRadius = 0.12;\n  float maxRadius = 0.3;\n  float t1 = 1.0;\n  float gamma = 3.0;\n  float omega = pi / 2.0;\n\n  float k = exp(-gamma) * omega;\n\n  float radius;\n  if (args.time <= t1) {\n    float t_prime = args.time / t1;\n    float springValue = 1.0 - exp(-gamma * t_prime) * cos(omega * t_prime);\n    radius = midRadius * springValue;\n  } else {\n    float adjustedTime = args.time - t1;\n    radius =\n      midRadius + (maxRadius - midRadius) * (1.0 - exp(-k * adjustedTime));\n  }\n\n  float distance = length(args.st) - radius;\n  sdf.distance = mix(sdf.distance, distance, args.amount);\n\n  \n  float alpha = sin(pi / 0.7 * args.time) * 0.3 + 0.7;\n  vec4 color = vec4(isWhiteForeground ? vec3(1.0) : vec3(0.0), alpha);\n  sdf.color = mix(sdf.color, color, args.amount);\n\n  return sdf;\n}\n\nColoredSDF applySpeakState(\n  ColoredSDF sdf,\n  SDFArgs args,\n  vec4 avgMag,\n  float silenceAmount,\n  float silenceDuration\n) {\n  float d = 1000.0;\n  const int barCount = 4;\n\n  float totalSpan = args.mainRadius * 1.9;\n  float slotWidth = totalSpan / float(barCount);\n  float gapRatio = clamp(0.35, 0.0, 0.9);\n  float baseBarHalfWidth = slotWidth * (1.0 - gapRatio) * 0.5;\n\n  for (int i = 0; i < barCount; i++) {\n    float f = (float(i) + 0.5) / float(barCount);\n\n    float w = baseBarHalfWidth;\n    float h = w;\n\n    float wave = sin(f * pi * 0.8 + args.time) * 0.5 + 0.5;\n    float entryAnimation = spring(\n      scaled(0.1 + wave * 0.4, 1.0 + wave * 0.4, args.duration),\n      0.98\n    );\n\n    vec2 pos = vec2(f - 0.5, 0.0) * totalSpan;\n    pos.y = 0.25 * (1.0 - entryAnimation);\n\n    \n    if (silenceAmount > 0.0) {\n      float bounceStagger = f / 5.0;\n      float bounceDelay = 0.6;\n      float bounceTimer = scaled(\n        bounceDelay,\n        bounceDelay + 1.0,\n        fract((silenceDuration + bounceStagger) / 2.0) * 2.0\n      );\n      pos.y +=\n        bounce(bounceTimer, 6.0) *\n        w *\n        0.25 *\n        silenceAmount *\n        pow(entryAnimation, 4.0) *\n        pow(args.amount, 4.0);\n    }\n\n    \n    h += avgMag[i] * (0.1 + (1.0 - abs(f - 0.5) * 2.0) * 0.1);\n\n    float dd = sdRoundedBox(args.st - pos, vec2(w, h), vec4(w));\n    d = opSmoothUnion(d, dd, 0.2 * (1.0 - args.amount));\n  }\n\n  sdf.distance = mix(sdf.distance, d, args.amount);\n  sdf.color.a = 1.0;\n  return sdf;\n}\n\n/* ------------------------------ I/O & UBO ------------------------------ */\n\nin vec2 out_uv;\nout vec4 fragColor;\n\nlayout(std140) uniform BlorbUniformsObject {\n  float time;\n  float speakTimestamp;\n  vec4 avgMag;\n  vec2 viewport;\n  float screenScaleFactor;\n  float silenceAmount;\n  float silenceTimestamp;\n  bool isWhiteForeground;\n} ubo; \n\n/* -------------------------------- main --------------------------------- */\n\nvoid main() {\n  vec2 st = out_uv - 0.5;\n  float viewRatio = ubo.viewport.y / ubo.viewport.x;\n  st.y *= viewRatio;\n\n  ColoredSDF sdf;\n  sdf.distance = 1000.0;\n  sdf.color = vec4(1.0);\n\n  SDFArgs args;\n  args.st = st;\n  args.time = ubo.time;\n  args.mainRadius = 0.49;\n  args.amount = 1.0;\n  args.duration = ubo.time - ubo.speakTimestamp;\n\n  \n  SDFArgs idleArgs = args;\n  idleArgs.amount = 1.0;\n  sdf = applyIdleState(sdf, idleArgs, ubo.isWhiteForeground);\n\n  float silenceDuration = ubo.time - ubo.silenceTimestamp;\n  sdf = applySpeakState(\n    sdf,\n    args,\n    ubo.avgMag,\n    ubo.silenceAmount,\n    silenceDuration\n  );\n\n  float clampingTolerance = 0.0075 / max(ubo.screenScaleFactor, 0.0001);\n  float clampedShape = smoothstep(clampingTolerance, 0.0, sdf.distance);\n  float alpha = sdf.color.a * clampedShape;\n  fragColor = vec4(sdf.color.rgb * alpha, alpha);\n}",
    Gs = "#version 300 es\n\nout vec4 out_position;\nout vec2 out_uv;\n\nconst vec4 blitFullscreenTrianglePositions[6] = vec4[](\n  vec4(-1.0, -1.0, 0.0, 1.0),\n  vec4(3.0, -1.0, 0.0, 1.0),\n  vec4(-1.0, 3.0, 0.0, 1.0),\n  vec4(-1.0, -1.0, 0.0, 1.0),\n  vec4(3.0, -1.0, 0.0, 1.0),\n  vec4(-1.0, 3.0, 0.0, 1.0)\n);\n\nvoid main() {\n  out_position = blitFullscreenTrianglePositions[gl_VertexID];\n  out_uv = out_position.xy * 0.5 + 0.5;\n  out_uv.y = 1.0 - out_uv.y;\n  gl_Position = out_position;\n}";
const Ws = [300, 300];

function Hs({
    className: t,
    staticConfig: e,
    onDynamicConfigSetterReady: s,
    onRenderComplete: n
}) {
    "use no forget";
    const i = v.useRef(performance.now() / 1e3),
        o = v.useRef({
            viewport: Ws,
            time: i.current
        }).current,
        a = v.useRef(void 0),
        r = v.useRef(K(A(A({}, o), e), {
            speakTimestamp: 0,
            avgMag: [0, 0, 0, 0],
            silenceAmount: 0,
            silenceTimestamp: 0
        })),
        c = v.useCallback(d => {
            r.current = A(A(A({}, o), e), d), a.current = d
        }, [o, e]);
    v.useEffect(() => {
        a.current && (r.current = A(A(A({}, o), e), a.current))
    }, [e, o]), v.useEffect(() => {
        s(c)
    }, [s, c]);
    const l = d => {
        o.viewport = [d.width, d.height]
    };
    return v.useEffect(() => {
        const d = setInterval(() => {
            o.time = performance.now() / 1e3
        }, os);
        return () => clearInterval(d)
    }, [o]), g.jsx(is, {
        className: Q("flex items-center justify-center", t),
        variablesRef: r,
        onViewportUpdate: l,
        onGlAvailable: void 0,
        onCanvasSizeUpdate: void 0,
        onRenderComplete: n,
        scale: 1,
        GLUniformsSetter: Me,
        vert: Gs,
        frag: qs
    })
}
const Qs = 1.4,
    Ys = {
        bands: 4,
        loPass: 0,
        hiPass: 400
    },
    Ks = t => {
        "use forget";
        const e = y.c(12),
            {
                className: s
            } = t,
            [n, i] = v.useState(void 0),
            {
                getTracks: o
            } = Zt();
        let a;
        e[0] !== o ? (a = o([es.Microphone]).find(Xs), e[0] = o, e[1] = a) : a = e[1];
        const r = a,
            c = as(r == null ? void 0 : r.track, Ys);
        let l;
        e[2] !== c ? (l = c.map(Js), e[2] = c, e[3] = l) : l = e[3];
        const d = l,
            f = Zs;
        let u, m;
        e[4] !== d || e[5] !== n ? (u = () => {
            n && n({
                speakTimestamp: 0,
                avgMag: d,
                silenceAmount: 0,
                silenceTimestamp: 0
            })
        }, m = [d, n], e[4] = d, e[5] = n, e[6] = u, e[7] = m) : (u = e[6], m = e[7]), v.useEffect(u, m);
        let h;
        e[8] === Symbol.for("react.memo_cache_sentinel") ? (h = {
            screenScaleFactor: window.devicePixelRatio,
            isWhiteForeground: !0
        }, e[8] = h) : h = e[8];
        const p = h;
        let b;
        e[9] === Symbol.for("react.memo_cache_sentinel") ? (b = x => {
            i(() => x)
        }, e[9] = b) : b = e[9];
        const S = b;
        let C;
        return e[10] !== s ? (C = g.jsx(Hs, {
            className: s,
            staticConfig: p,
            onDynamicConfigSetterReady: S,
            onRenderComplete: f
        }), e[10] = s, e[11] = C) : C = e[11], C
    };

function Xs(t) {
    return t.origin === "local"
}

function Js(t) {
    return t * Qs
}

function Zs() {
    it() || at()
}
const G = {
        buttonLayout: "rounded-full overflow-hidden h-9 px-3",
        buttonContents: "flex flex-row items-center justify-center gap-2",
        buttonColors: "hover:opacity-80 font-semibold transition-colors transition-width duration-500 ease-in-out",
        loadingColor: "bg-token-icon-primary text-token-text-inverted px-0",
        loadedColor: "bg-token-bg-accent-static text-token-text-inverted-static"
    },
    en = t => {
        "use forget";
        const e = y.c(7),
            {
                className: s,
                Icon: n
            } = t;
        let i;
        e[0] !== s ? (i = Q(s, "relative"), e[0] = s, e[1] = i) : i = e[1];
        let o;
        e[2] !== n ? (o = g.jsx(n, {
            className: "absolute start-1/2 top-1/2 h-5 w-5 -translate-x-1/2 -translate-y-1/2"
        }), e[2] = n, e[3] = o) : o = e[3];
        let a;
        return e[4] !== i || e[5] !== o ? (a = g.jsx("div", {
            className: i,
            children: o
        }), e[4] = i, e[5] = o, e[6] = a) : a = e[6], a
    },
    tn = () => {
        const [t, e] = v.useState(!0), s = I(i => i.server.connectionState === oe.Connected), n = I(i => i.server.remoteState === Ae.Listening || i.server.remoteState === Ae.Speaking);
        return v.useEffect(() => {
            s && n && t ? e(!1) : s || e(!0)
        }, [s, n, t]), t
    },
    sn = t => {
        "use forget";
        const e = y.c(21),
            {
                onClick: s
            } = t,
            n = tn(),
            i = H(),
            o = qe(),
            a = He(nn),
            r = (a == null ? void 0 : a.id) != null,
            [c, l] = v.useState(!1);
        let d, f;
        o ? (d = be, f = N.endingVoiceSessionLabel) : n && !r ? (d = c ? ss : be, f = c ? N.cancelLoadingAriaLabel : N.startingVoiceAriaLabel) : (d = Ks, f = N.endVoiceAriaLabel);
        let u;
        e[0] !== d ? (u = g.jsx(en, {
            Icon: d,
            className: "h-3 w-3"
        }), e[0] = d, e[1] = u) : u = e[1];
        let m;
        e[2] !== f || e[3] !== u ? (m = [u, f], e[2] = f, e[3] = u, e[4] = m) : m = e[4];
        const [h, p] = m;
        let b;
        o ? b = N.endingVoiceSessionLabel : n && !r ? b = N.cancelLoadingButtonLabel : b = N.endVoiceButtonLabel;
        const S = b;
        let C, x;
        e[5] === Symbol.for("react.memo_cache_sentinel") ? (C = () => l(!0), x = () => l(!1), e[5] = C, e[6] = x) : (C = e[5], x = e[6]);
        let _;
        e[7] !== p || e[8] !== i ? (_ = i.formatMessage(p), e[7] = p, e[8] = i, e[9] = _) : _ = e[9];
        const R = n || o ? G.loadingColor : G.loadedColor;
        let w;
        e[10] !== R ? (w = Q(G.buttonLayout, G.buttonContents, G.buttonColors, R), e[10] = R, e[11] = w) : w = e[11];
        let $;
        e[12] !== S ? ($ = g.jsx(fe, A({}, S)), e[12] = S, e[13] = $) : $ = e[13];
        let Y;
        return e[14] !== h || e[15] !== o || e[16] !== s || e[17] !== _ || e[18] !== w || e[19] !== $ ? (Y = g.jsxs("button", {
            onMouseOver: C,
            onMouseOut: x,
            "aria-label": _,
            type: "button",
            className: w,
            onClick: s,
            disabled: o,
            children: [h, $]
        }), e[14] = h, e[15] = o, e[16] = s, e[17] = _, e[18] = w, e[19] = $, e[20] = Y) : Y = e[20], Y
    },
    N = {
        endVoiceButtonLabel: {
            id: "integratedux.endVoiceMode",
            defaultMessage: "End",
            description: "Button label for ending voice mode"
        },
        cancelLoadingButtonLabel: {
            id: "integratedux.cancelLoading",
            defaultMessage: "Cancel",
            description: "Button label to cancel loading of voice mode"
        },
        endVoiceAriaLabel: {
            id: "integratedux.endVoiceAriaLabel",
            defaultMessage: "End voice mode",
            description: "Screen reader text that tells user that the button ends voice mode"
        },
        cancelLoadingAriaLabel: {
            id: "integratedux.cancelLoading",
            defaultMessage: "Cancel loading",
            description: "Screen reader text that tells user that the button cancels loading"
        },
        startingVoiceAriaLabel: {
            id: "integratedux.startingVoiceMode",
            defaultMessage: "Starting voice mode",
            description: "Screen reader text that tells users a loading state is in progress"
        },
        endingVoiceSessionLabel: {
            id: "integratedux.endingVoiceSession",
            defaultMessage: "Ending…",
            description: "Button label text telling the user that the process of ending the voice session is in progress"
        }
    };

function nn() {
    return Pe()
}
const on = {
        ON: {
            colorClass: "bg-black/5 hover:bg-black/10 active:bg-black/20 dark:bg-[rgba(255,255,255,0.04)] dark:hover:bg-white/5 dark:active:bg-white/10",
            sizeClass: "max-h-9 max-w-9",
            iconColorClass: "text-token-main-surface-primary-inverse hover:text-token-text-inverted"
        },
        OFF: {
            colorClass: "bg-red-500/10 hover:bg-red-500/15 active:bg-red-500/20 dark:bg-red-500/10 dark:hover:bg-red-500/15 dark:active:bg-red-500/20",
            sizeClass: "max-h-9 max-w-9",
            iconColorClass: "text-danger"
        }
    },
    an = {
        ON: {
            colorClass: "bg-gray-900 hover:bg-gray-800 active:bg-gray-700",
            sizeClass: "max-h-9 max-w-9",
            iconColorClass: "text-token-main-surface-primary hover:text-token-text-inverted"
        },
        OFF: {
            colorClass: "bg-black/5 hover:bg-black/10 active:bg-black/20 dark:bg-[rgba(255,255,255,0.04)] dark:hover:bg-white/5 dark:active:bg-white/10",
            sizeClass: "max-h-9 max-w-9",
            iconColorClass: "hover:text-token-text-inverted"
        }
    },
    rn = t => {
        "use forget";
        const e = y.c(15),
            {
                disabled: s,
                onClick: n,
                microphoneLabel: i,
                microphoneActive: o,
                microphoneForceMuted: a
            } = t,
            r = H(),
            c = o ? rs : cs,
            {
                colorClass: l,
                sizeClass: d,
                iconColorClass: f
            } = on[o ? "ON" : "OFF"];
        let u;
        e[0] !== r || e[1] !== o || e[2] !== a ? (u = a ? r.formatMessage(de.microphoneMuted) : o ? r.formatMessage(de.microphoneOff) : r.formatMessage(de.microphoneOn), e[0] = r, e[1] = o, e[2] = a, e[3] = u) : u = e[3];
        const m = u;
        let h;
        e[4] !== l || e[5] !== d ? (h = Q(l, d), e[4] = l, e[5] = d, e[6] = h) : h = e[6];
        let p;
        return e[7] !== c || e[8] !== s || e[9] !== f || e[10] !== i || e[11] !== n || e[12] !== m || e[13] !== h ? (p = g.jsx($e, {
            "aria-label": m,
            onClick: n,
            icon: c,
            iconSize: "icon-md",
            disabled: s,
            className: h,
            iconColor: f,
            tooltipPrimaryLabel: m,
            tooltipSecondaryLabel: i
        }), e[7] = c, e[8] = s, e[9] = f, e[10] = i, e[11] = n, e[12] = m, e[13] = h, e[14] = p) : p = e[14], p
    },
    de = {
        microphoneMuted: {
            id: "integrated-ux.mute-button.microphone-muted",
            defaultMessage: "Microphone muted in system settings / hardware switch",
            description: "Tooltip label shown when the user's microphone is hardware disabled into a muted state, and the toggle will not work"
        },
        microphoneOff: {
            id: "integrated-ux.mute-button.microphone-off",
            defaultMessage: "Turn off microphone",
            description: "Tooltip shown when the microphone is on. Clicking the button for this tooltip mutes the microphone."
        },
        microphoneOn: {
            id: "integrated-ux.mute-button.microphone-on",
            defaultMessage: "Turn on microphone",
            description: "Tooltip shown when the microphone is off. Clicking this button for this tooltip unmutes the microphone."
        }
    },
    cn = () => {
        "use forget";
        const t = y.c(6),
            {
                isMuting: e,
                toggleMute: s
            } = yt(),
            {
                disconnectPending: n
            } = rt(),
            {
                forceMuted: i,
                active: o,
                label: a,
                granted: r
            } = Ce(),
            c = e || n || i || !r,
            l = r && o;
        let d;
        return t[0] !== i || t[1] !== a || t[2] !== c || t[3] !== l || t[4] !== s ? (d = g.jsx(rn, {
            disabled: c,
            onClick: s,
            microphoneActive: l,
            microphoneForceMuted: i,
            microphoneLabel: a
        }), t[0] = i, t[1] = a, t[2] = c, t[3] = l, t[4] = s, t[5] = d) : d = t[5], d
    },
    ln = t => {
        "use forget";
        const e = y.c(14),
            {
                waiting: s,
                started: n,
                onClick: i
            } = t,
            o = H();
        let a;
        e[0] !== o || e[1] !== n || e[2] !== s ? (a = s ? o.formatMessage(ue.screensharePending) : n ? o.formatMessage(ue.screenshareOn) : o.formatMessage(ue.screenshareOff), e[0] = o, e[1] = n, e[2] = s, e[3] = a) : a = e[3];
        const r = a,
            {
                colorClass: c,
                sizeClass: l,
                iconColorClass: d
            } = an[n ? "ON" : "OFF"],
            f = s ? be : n ? ls : ns;
        let u;
        e[4] !== c || e[5] !== l ? (u = Q(c, l), e[4] = c, e[5] = l, e[6] = u) : u = e[6];
        let m;
        return e[7] !== f || e[8] !== d || e[9] !== i || e[10] !== r || e[11] !== u || e[12] !== s ? (m = g.jsx($e, {
            "aria-label": r,
            onClick: i,
            disabled: s,
            icon: f,
            iconSize: "icon-md",
            className: u,
            iconColor: d
        }), e[7] = f, e[8] = d, e[9] = i, e[10] = r, e[11] = u, e[12] = s, e[13] = m) : m = e[13], m
    },
    ue = {
        screenshareOff: {
            id: "integrated-ux.screenshare-button.screenshare-off",
            defaultMessage: "Activate screenshare",
            description: "Tooltip shown when the screenshare is off. Clicking the button for this tooltip activates the screenshare."
        },
        screenshareOn: {
            id: "integrated-ux.screenshare-button.screenshare-on",
            defaultMessage: "Turn off screenshare",
            description: "Tooltip shown when the screenshare is on. Clicking this button for this tooltip deactivates the screenshare."
        },
        screensharePending: {
            id: "integrated-ux.screenshare-button.pending",
            defaultMessage: "Pending screenshare activation",
            description: "Tooltip shown when the screenshare is pending"
        }
    },
    dn = () => {
        "use forget";
        const t = y.c(7),
            {
                screenshareTrackState: e,
                toggleScreenShare: s
            } = _t();
        let n;
        t[0] === Symbol.for("react.memo_cache_sentinel") ? (n = [re.Starting, re.Stopping], t[0] = n) : n = t[0];
        const i = n.includes(e),
            o = e === re.Started;
        let a;
        t[1] !== s ? (a = () => s("ControlButton"), t[1] = s, t[2] = a) : a = t[2];
        let r;
        return t[3] !== o || t[4] !== a || t[5] !== i ? (r = g.jsx(ln, {
            waiting: i,
            started: o,
            onClick: a
        }), t[3] = o, t[4] = a, t[5] = i, t[6] = r) : r = t[6], r
    },
    un = t => {
        "use forget";
        const e = y.c(15),
            {
                onComposerSubmit: s
            } = t,
            n = Rt(),
            i = qt();
        let o;
        e[0] !== i ? (o = () => Wt(i), e[0] = i, e[1] = o) : o = e[1];
        const a = !He(o),
            r = Ue(Gt.hasUploadInProgress),
            c = Ue(fn),
            l = a || r || c,
            d = I(mn);
        let f;
        e[2] !== d || e[3] !== n ? (f = async () => {
            const b = await Qt({
                connectionState: d,
                isLimitExceeded: n
            });
            he({
                type: "STOP",
                reason: b
            })
        }, e[2] = d, e[3] = n, e[4] = f) : f = e[4];
        const u = f;
        let m;
        e[5] !== l ? (m = !l && g.jsxs(g.Fragment, {
            children: [g.jsx(ct, {
                capability: "screenshare",
                children: g.jsx(dn, {})
            }), g.jsx(cn, {})]
        }), e[5] = l, e[6] = m) : m = e[6];
        let h;
        e[7] !== i || e[8] !== l || e[9] !== u || e[10] !== s ? (h = l ? g.jsx(Tt, {
            onSubmit: s,
            composerController: i,
            isStreaming: !1,
            isDisabled: !1,
            showSpinner: !1
        }) : g.jsx(sn, {
            onClick: u
        }), e[7] = i, e[8] = l, e[9] = u, e[10] = s, e[11] = h) : h = e[11];
        let p;
        return e[12] !== m || e[13] !== h ? (p = g.jsxs("div", {
            className: "flex flex-row gap-2",
            children: [m, h]
        }), e[12] = m, e[13] = h, e[14] = p) : p = e[14], p
    };

function fn(t) {
    return t.files.length > 0
}

function mn(t) {
    return t.server.connectionState
}
const Bn = t => {
    "use forget";
    const e = y.c(24),
        {
            clientThreadId: s,
            isFocused: n,
            onComposerSubmit: i
        } = t,
        o = I(hn),
        a = I(gn),
        r = I(pn);
    let c, l;
    e[0] !== o ? (c = () => {
        We.set(o)
    }, l = [o], e[0] = o, e[1] = c, e[2] = l) : (c = e[1], l = e[2]), v.useEffect(c, l);
    let d, f;
    e[3] !== a || e[4] !== r || e[5] !== o ? (d = () => {
        o && !a ? ve.set(oe.Connecting) : ve.set(r)
    }, f = [a, r, o], e[3] = a, e[4] = r, e[5] = o, e[6] = d, e[7] = f) : (d = e[6], f = e[7]), v.useEffect(d, f);
    let u, m;
    e[8] !== s ? (u = g.jsx($s, {
        clientThreadId: s
    }), m = g.jsx(zs, {
        clientThreadId: s
    }), e[8] = s, e[9] = u, e[10] = m) : (u = e[9], m = e[10]);
    let h;
    e[11] === Symbol.for("react.memo_cache_sentinel") ? (h = g.jsx(Rs, {}), e[11] = h) : h = e[11];
    let p;
    e[12] !== s ? (p = g.jsx(Ts, {
        clientThreadId: s
    }), e[12] = s, e[13] = p) : p = e[13];
    let b;
    e[14] !== s || e[15] !== n || e[16] !== i ? (b = g.jsx(un, {
        clientThreadId: s,
        composerIsFocused: n,
        onComposerSubmit: i
    }), e[14] = s, e[15] = n, e[16] = i, e[17] = b) : b = e[17];
    let S;
    return e[18] !== s || e[19] !== u || e[20] !== m || e[21] !== p || e[22] !== b ? (S = g.jsxs(lt, {
        conversationId: s,
        executors: u,
        children: [m, h, p, b]
    }), e[18] = s, e[19] = u, e[20] = m, e[21] = p, e[22] = b, e[23] = S) : S = e[23], S
};

function hn(t) {
    return t.isVoiceModeActive
}

function gn(t) {
    return t.hasConnectedOnce
}

function pn(t) {
    return t.server.remoteState
}
export {
    Bn as SpeechActiveContainer
};
//# sourceMappingURL=okkr0n9nan5kh2yn.js.map