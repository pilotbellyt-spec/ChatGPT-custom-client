var Cn = Object.defineProperty,
    Sn = Object.defineProperties;
var xn = Object.getOwnPropertyDescriptors;
var Zt = Object.getOwnPropertySymbols;
var bn = Object.prototype.hasOwnProperty,
    yn = Object.prototype.propertyIsEnumerable;
var en = (i, e, n) => e in i ? Cn(i, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : i[e] = n,
    L = (i, e) => {
        for (var n in e || (e = {})) bn.call(e, n) && en(i, n, e[n]);
        if (Zt)
            for (var n of Zt(e)) yn.call(e, n) && en(i, n, e[n]);
        return i
    },
    z = (i, e) => Sn(i, xn(e));
import {
    c as ce,
    e as mt,
    f as Vt,
    j as o,
    M as le,
    r as G,
    i as _n
} from "./fg33krlcm0qyi6yw.js";
import {
    a9 as $t,
    bg as be,
    bb as kn,
    l as tn,
    bv as nn,
    b as dn,
    d as un,
    mN as En,
    bp as Nn,
    bT as vn,
    d3 as Tn,
    bc as oe,
    bd as ie,
    bn as wn,
    C as In,
    cU as Pn
} from "./dykg4ktvbu3mhmdo.js";
import {
    nL as On,
    nM as jn,
    nN as Ln,
    mY as Mn,
    nO as Rn,
    nP as Gn,
    nQ as Bn,
    nR as $n,
    nS as Vn,
    nT as sn,
    nU as Un,
    mj as pn,
    nV as Dn,
    nW as zn,
    nX as Hn,
    nY as on,
    nZ as An,
    n_ as Fn,
    n$ as ln,
    o0 as Kn,
    o1 as Yn,
    mm as Wn,
    n as qn
} from "./k15yxxoybkkir2ou.js";
const Ee = Vt({
    stepIndicator: {
        id: "pulse.onboarding.modal.connector.stepIndicator",
        defaultMessage: "Step {current} of {total}"
    },
    connectorsTitle: {
        id: "pulse.onboarding.modal.connector.title",
        defaultMessage: "Give Pulse even more to work with"
    },
    connectorsBody: {
        id: "pulse.onboarding.modal.connector.body",
        defaultMessage: "Connecting your calendar and email helps ChatGPT craft more accurate updates."
    },
    connectorsDataTitle: {
        id: "pulse.onboarding.modal.connector.dataTitle",
        defaultMessage: "You’re in control of your data"
    },
    connectorsDataDescription: {
        id: "pulse.onboarding.modal.connector.dataDescription",
        defaultMessage: "You can delete your conversations, which will also delete any Gmail data used in those conversations. <link>Learn more</link>"
    },
    connectorsPrivacyTitle: {
        id: "pulse.onboarding.modal.connector.privacyTitle",
        defaultMessage: "Private and secure"
    },
    connectorsPrivacyDescription: {
        id: "pulse.onboarding.modal.connector.privacyDescription",
        defaultMessage: "Data accessed from Gmail may be used to reply to prompts. We do not train generalized models on this data or derivations of it, unless you choose to submit it as feedback. <link>Learn more</link>"
    },
    connectorsSkipCta: {
        id: "pulse.onboarding.modal.connector.skipCta",
        defaultMessage: "Skip for now"
    },
    connectorsConnectCta: {
        id: "pulse.onboarding.modal.connector.connectCta",
        defaultMessage: "Connect with Google"
    }
});

function Qn(i) {
    "use forget";
    var F, v;
    const e = ce.c(33),
        {
            config: n,
            headingId: l,
            descriptionId: u,
            onSkip: s,
            onConnect: c,
            stepIndex: m,
            totalSteps: h,
            isSkipLoading: C,
            isConnectLoading: r,
            disableSkip: x,
            disableConnect: p,
            connectorCards: g,
            connectCta: t
        } = i,
        d = mt();
    let b;
    e[0] !== d ? (b = (F = d.formatMessage(Ee.connectorsSkipCta)) != null ? F : "Skip for now", e[0] = d, e[1] = b) : b = e[1];
    const E = b;
    let k;
    e[2] !== t || e[3] !== d ? (k = (v = t != null ? t : d.formatMessage(Ee.connectorsConnectCta)) != null ? v : "Connect with Google", e[2] = t, e[3] = d, e[4] = k) : k = e[4];
    const w = k;
    if (!n) return null;
    let _;
    e[5] !== m || e[6] !== h ? (_ = o.jsx("p", {
        className: "text-token-text-secondary",
        children: o.jsx(le, z(L({}, Ee.stepIndicator), {
            values: {
                current: m,
                total: h
            }
        }))
    }), e[5] = m, e[6] = h, e[7] = _) : _ = e[7];
    const I = _;
    let y;
    e[8] !== n || e[9] !== g || e[10] !== u || e[11] !== l ? (y = o.jsx(Jn, {
        config: n,
        headingId: l,
        descriptionId: u,
        cards: g
    }), e[8] = n, e[9] = g, e[10] = u, e[11] = l, e[12] = y) : y = e[12];
    let T;
    e[13] !== w ? (T = o.jsx("p", {
        children: w
    }), e[13] = w, e[14] = T) : T = e[14];
    let P;
    e[15] === Symbol.for("react.memo_cache_sentinel") ? (P = o.jsx(On, {
        className: "ms-1 h-5 w-5"
    }), e[15] = P) : P = e[15];
    let M;
    e[16] !== p || e[17] !== r || e[18] !== c || e[19] !== T ? (M = o.jsxs($t, {
        color: "primary",
        size: "large",
        className: "rounded-full px-6",
        onClick: c,
        loading: r,
        disabled: p,
        children: [T, P]
    }, "connectors-google-button-key"), e[16] = p, e[17] = r, e[18] = c, e[19] = T, e[20] = M) : M = e[20];
    let B;
    e[21] !== E ? (B = o.jsx("p", {
        children: E
    }), e[21] = E, e[22] = B) : B = e[22];
    let a;
    e[23] !== x || e[24] !== C || e[25] !== s || e[26] !== B ? (a = o.jsx($t, {
        color: "secondary",
        size: "large",
        className: "rounded-full border-none px-6",
        onClick: s,
        loading: C,
        disabled: x,
        children: B
    }, "connectors-skip-button-key"), e[23] = x, e[24] = C, e[25] = s, e[26] = B, e[27] = a) : a = e[27];
    let O;
    return e[28] !== I || e[29] !== y || e[30] !== M || e[31] !== a ? (O = {
        content: y,
        footerContent: I,
        primaryButton: M,
        secondaryButton: a
    }, e[28] = I, e[29] = y, e[30] = M, e[31] = a, e[32] = O) : O = e[32], O
}

function Jn(i) {
    "use forget";
    var d, b;
    const e = ce.c(21),
        {
            config: n,
            headingId: l,
            descriptionId: u,
            cards: s
        } = i;
    let c;
    e[0] !== s ? (c = o.jsx("div", {
        className: "relative flex h-full min-h-[364px] flex-1 overflow-x-clip bg-[#4285F4]",
        children: o.jsx("div", {
            className: "pointer-events-none absolute inset-0 flex w-full items-center justify-center",
            children: o.jsx("div", {
                className: "pointer-events-auto",
                children: o.jsx(jn, {
                    cards: s
                })
            })
        })
    }), e[0] = s, e[1] = c) : c = e[1];
    let m;
    e[2] !== n.title ? (m = (d = n.title) != null ? d : o.jsx(le, L({}, Ee.connectorsTitle)), e[2] = n.title, e[3] = m) : m = e[3];
    let h;
    e[4] !== l || e[5] !== m ? (h = o.jsx("p", {
        id: l,
        className: "text-token-text-primary text-[28px] font-normal",
        children: m
    }), e[4] = l, e[5] = m, e[6] = h) : h = e[6];
    let C;
    e[7] !== n.body ? (C = (b = n.body) != null ? b : o.jsx(le, L({}, Ee.connectorsBody)), e[7] = n.body, e[8] = C) : C = e[8];
    let r;
    e[9] !== u || e[10] !== C ? (r = o.jsx("p", {
        id: u,
        className: "text-token-text-primary mt-4 text-base",
        children: C
    }), e[9] = u, e[10] = C, e[11] = r) : r = e[11];
    let x;
    e[12] !== h || e[13] !== r ? (x = o.jsxs("div", {
        className: "text-start",
        children: [h, r]
    }), e[12] = h, e[13] = r, e[14] = x) : x = e[14];
    let p;
    e[15] === Symbol.for("react.memo_cache_sentinel") ? (p = o.jsx("div", {
        className: "mt-18 flex w-full",
        "aria-hidden": "true"
    }), e[15] = p) : p = e[15];
    let g;
    e[16] !== x ? (g = o.jsxs("div", {
        className: "flex grow flex-col px-9 pt-9 pb-12",
        children: [x, p]
    }), e[16] = x, e[17] = g) : g = e[17];
    let t;
    return e[18] !== c || e[19] !== g ? (t = o.jsxs("div", {
        className: "bg-token-interactive-bg-tertiary-hover no-scrollbar flex h-full flex-col overflow-y-auto pb-6",
        children: [c, g]
    }), e[18] = c, e[19] = g, e[20] = t) : t = e[20], t
}
const Xn = be.create(Ln);

function Zn(i) {
    "use forget";
    var B;
    const e = ce.c(40),
        {
            suggestion: n,
            selected: l,
            promptValue: u,
            promptPlaceholder: s,
            onToggle: c,
            onPromptChange: m
        } = i,
        h = kn(),
        C = h ? "bg-black" : "bg-white";
    let r;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (r = {
        layout: {
            type: "spring",
            stiffness: 500,
            damping: 40
        }
    }, e[0] = r) : r = e[0];
    const x = l ? "".concat(C, " shadow-[0px_6px_24px_rgba(0,0,0,0.12)]") : "".concat(C, "/90 shadow-[0px_4px_16px_rgba(0,0,0,0.05)]");
    let p;
    e[1] !== x ? (p = tn("border-token-border-default rounded-[24px] border px-5 text-start transition-shadow", x), e[1] = x, e[2] = p) : p = e[2];
    let g;
    e[3] !== c || e[4] !== n.id ? (g = () => c(n.id), e[3] = c, e[4] = n.id, e[5] = g) : g = e[5];
    let t;
    e[6] !== n.emoji ? (t = n.emoji && o.jsx("span", {
        className: "text-xl",
        children: n.emoji
    }), e[6] = n.emoji, e[7] = t) : t = e[7];
    let d;
    e[8] !== n.title ? (d = o.jsx("span", {
        className: "text-token-text-primary text-base font-medium",
        children: n.title
    }), e[8] = n.title, e[9] = d) : d = e[9];
    let b;
    e[10] !== t || e[11] !== d ? (b = o.jsxs("div", {
        className: "flex min-h-7 items-center gap-3 text-start",
        children: [t, d]
    }), e[10] = t, e[11] = d, e[12] = b) : b = e[12];
    const E = l ? h ? "white" : "black" : "var(--token-bg-primary)";
    let k;
    e[13] !== E ? (k = {
        backgroundColor: E
    }, e[13] = E, e[14] = k) : k = e[14];
    let w;
    e[15] === Symbol.for("react.memo_cache_sentinel") ? (w = {
        type: "spring",
        stiffness: 400,
        damping: 35
    }, e[15] = w) : w = e[15];
    let _;
    e[16] !== h || e[17] !== l ? (_ = o.jsx(nn, {
        mode: "wait",
        initial: !1,
        children: l ? o.jsx(be.span, {
            initial: {
                rotate: -90,
                scale: .5,
                opacity: 0
            },
            animate: {
                rotate: 0,
                scale: 1,
                opacity: 1
            },
            exit: {
                rotate: 90,
                scale: .5,
                opacity: 0
            },
            transition: {
                duration: .2,
                ease: "easeOut"
            },
            children: o.jsx(Mn, {
                className: tn("h-4 w-4", h ? "text-black" : "text-white")
            })
        }, "check") : o.jsx(be.span, {
            initial: {
                rotate: 90,
                scale: .5,
                opacity: 0
            },
            animate: {
                rotate: 0,
                scale: 1,
                opacity: 1
            },
            exit: {
                rotate: -90,
                scale: .5,
                opacity: 0
            },
            transition: {
                duration: .2,
                ease: "easeOut"
            },
            className: "text-token-text-tertiary",
            children: o.jsx(Rn, {
                className: "h-4 w-4"
            })
        }, "plus")
    }), e[16] = h, e[17] = l, e[18] = _) : _ = e[18];
    let I;
    e[19] !== _ || e[20] !== k ? (I = o.jsx(be.div, {
        layout: "position",
        className: "flex h-6 w-6 items-center justify-center rounded-full",
        animate: k,
        transition: w,
        children: _
    }), e[19] = _, e[20] = k, e[21] = I) : I = e[21];
    let y;
    e[22] !== l || e[23] !== I || e[24] !== g || e[25] !== b ? (y = o.jsxs("button", {
        type: "button",
        className: "flex w-full items-center justify-between gap-3 py-3 text-start",
        onClick: g,
        "aria-pressed": l,
        children: [b, I]
    }), e[22] = l, e[23] = I, e[24] = g, e[25] = b, e[26] = y) : y = e[26];
    let T;
    e[27] !== m || e[28] !== s || e[29] !== u || e[30] !== l || e[31] !== n.id || e[32] !== n.prompt ? (T = l && o.jsx(be.div, {
        layout: !0,
        initial: {
            height: 0,
            opacity: 0,
            marginTop: 0
        },
        animate: {
            height: "auto",
            opacity: 1,
            marginTop: 6
        },
        exit: {
            height: 0,
            opacity: 0,
            marginTop: 0
        },
        transition: {
            duration: .2,
            ease: "easeInOut"
        },
        className: "overflow-hidden pb-3",
        children: o.jsx(Xn, {
            layout: !0,
            initial: {
                opacity: 0,
                y: 0
            },
            animate: {
                opacity: 1,
                y: 0
            },
            exit: {
                opacity: 0,
                y: 0
            },
            transition: {
                duration: .2
            },
            className: "text-token-text-primary placeholder:text-token-text-tertiary bg-token-bg-elevated-secondary w-full rounded-[20px] border-none px-5 py-3 text-base focus:ring-0 focus:outline-none focus-visible:ring-0 focus-visible:outline-none",
            placeholder: (B = n.prompt) != null ? B : s,
            value: u,
            onChange: a => m(n.id, a.currentTarget.value),
            minRows: 1,
            maxRows: 3,
            style: {
                resize: "none"
            }
        })
    }, "prompt"), e[27] = m, e[28] = s, e[29] = u, e[30] = l, e[31] = n.id, e[32] = n.prompt, e[33] = T) : T = e[33];
    let P;
    e[34] !== T ? (P = o.jsx(nn, {
        initial: !1,
        children: T
    }), e[34] = T, e[35] = P) : P = e[35];
    let M;
    return e[36] !== y || e[37] !== P || e[38] !== p ? (M = o.jsxs(be.div, {
        layout: !0,
        transition: r,
        className: p,
        children: [y, P]
    }), e[36] = y, e[37] = P, e[38] = p, e[39] = M) : M = e[39], M
}
const re = Vt({
    focusTitle: {
        id: "pulse.onboarding.modal.interests.title",
        defaultMessage: "What would you like Pulse to keep track of?"
    },
    focusBody: {
        id: "pulse.onboarding.modal.interests.body",
        defaultMessage: "Choose a few focus areas to start. Pulse will evolve based on your chats and interests."
    },
    stepIndicator: {
        id: "pulse.onboarding.modal.interests.stepIndicator",
        defaultMessage: "Step {current} of {total}"
    },
    nextCta: {
        id: "pulse.onboarding.modal.interests.nextCta",
        defaultMessage: "Next"
    },
    basedOnYouLabel: {
        id: "pulse.onboarding.modal.interests.sectionBasedOnYou",
        defaultMessage: "Based on you"
    },
    moreIdeasLabel: {
        id: "pulse.onboarding.modal.interests.sectionMoreIdeas",
        defaultMessage: "More ideas"
    },
    suggestionPromptPlaceholder: {
        id: "pulse.onboarding.modal.interests.promptPlaceholder",
        defaultMessage: "Do you want to share anything else?"
    }
});

function cn(i, e) {
    var u;
    const n = new Map(e.map(s => {
            var c;
            return [s.id, (c = s.prompt) != null ? c : ""]
        })),
        l = {};
    for (const s of i) {
        const c = n.get(s.id);
        l[s.id] = {
            selected: n.has(s.id),
            promptValue: (u = c != null ? c : s.prompt) != null ? u : ""
        }
    }
    return l
}

function es(i, e) {
    return i.length !== e.length ? !1 : i.every((n, l) => {
        var u, s, c, m;
        return n.id === ((u = e[l]) == null ? void 0 : u.id) && ((s = n.prompt) != null ? s : "") === ((m = (c = e[l]) == null ? void 0 : c.prompt) != null ? m : "")
    })
}

function ts(i, e) {
    const n = Object.keys(i),
        l = Object.keys(e);
    if (n.length !== l.length) return !1;
    for (const u of n) {
        const s = i[u],
            c = e[u];
        if (!c || s.selected !== c.selected || s.promptValue !== c.promptValue) return !1
    }
    return !0
}

function ns(i) {
    "use forget";
    var M;
    const e = ce.c(25),
        {
            headingId: n,
            descriptionId: l,
            onNext: u,
            stepIndex: s,
            totalSteps: c,
            hasSelection: m,
            selectedSuggestions: h,
            onSelectionChange: C,
            personalizedSuggestions: r,
            genericSuggestions: x,
            isSubmitting: p
        } = i,
        g = p === void 0 ? !1 : p,
        t = mt();
    let d;
    e[0] !== t ? (d = (M = t.formatMessage(re.nextCta)) != null ? M : "Next", e[0] = t, e[1] = d) : d = e[1];
    const b = d;
    let E;
    e[2] !== s || e[3] !== c ? (E = c > 1 ? o.jsx("p", {
        className: "text-token-text-secondary",
        children: o.jsx(le, z(L({}, re.stepIndicator), {
            values: {
                current: s,
                total: c
            }
        }))
    }) : null, e[2] = s, e[3] = c, e[4] = E) : E = e[4];
    const k = E;
    let w;
    e[5] !== l || e[6] !== x || e[7] !== n || e[8] !== C || e[9] !== r || e[10] !== h ? (w = o.jsx(ss, {
        headingId: n,
        descriptionId: l,
        onSelectionChange: C,
        selectedSuggestions: h,
        personalizedSuggestions: r,
        genericSuggestions: x
    }), e[5] = l, e[6] = x, e[7] = n, e[8] = C, e[9] = r, e[10] = h, e[11] = w) : w = e[11];
    let _;
    e[12] !== u ? (_ = () => void u(), e[12] = u, e[13] = _) : _ = e[13];
    const I = !m || g;
    let y;
    e[14] !== b ? (y = o.jsx("p", {
        children: b
    }), e[14] = b, e[15] = y) : y = e[15];
    let T;
    e[16] !== g || e[17] !== _ || e[18] !== I || e[19] !== y ? (T = o.jsx($t, {
        color: "primary",
        size: "large",
        className: "rounded-full px-6",
        onClick: _,
        disabled: I,
        loading: g,
        children: y
    }, "interests-next-button-key"), e[16] = g, e[17] = _, e[18] = I, e[19] = y, e[20] = T) : T = e[20];
    let P;
    return e[21] !== k || e[22] !== w || e[23] !== T ? (P = {
        content: w,
        footerContent: k,
        primaryButton: T
    }, e[21] = k, e[22] = w, e[23] = T, e[24] = P) : P = e[24], P
}

function ss(i) {
    "use forget";
    const e = ce.c(58),
        {
            headingId: n,
            descriptionId: l,
            onSelectionChange: u,
            selectedSuggestions: s,
            personalizedSuggestions: c,
            genericSuggestions: m
        } = i,
        h = mt();
    let C;
    e[0] !== c ? (C = c != null ? c : [], e[0] = c, e[1] = C) : C = e[1];
    const r = C;
    let x;
    e[2] !== m ? (x = m != null ? m : [], e[2] = m, e[3] = x) : x = e[3];
    const p = x;
    let g;
    e[4] !== p || e[5] !== r ? (g = [...r, ...p], e[4] = p, e[5] = r, e[6] = g) : g = e[6];
    const t = g;
    let d;
    e[7] !== p || e[8] !== r ? (d = JSON.stringify({
        personalizedIds: r.map(is),
        genericIds: p.map(os)
    }), e[7] = p, e[8] = r, e[9] = d) : d = e[9];
    const b = d;
    let E;
    e[10] !== s || e[11] !== t ? (E = () => cn(t, s), e[10] = s, e[11] = t, e[12] = E) : E = e[12];
    const [k, w] = G.useState(E);
    let _;
    e[13] !== p || e[14] !== r || e[15] !== s ? (_ = () => {
        const j = cn([...r, ...p], s);
        w(D => ts(D, j) ? D : j)
    }, e[13] = p, e[14] = r, e[15] = s, e[16] = _) : _ = e[16];
    let I;
    e[17] !== p || e[18] !== r || e[19] !== s || e[20] !== b ? (I = [b, s, r, p], e[17] = p, e[18] = r, e[19] = s, e[20] = b, e[21] = I) : I = e[21], G.useEffect(_, I);
    let y;
    e[22] === Symbol.for("react.memo_cache_sentinel") ? (y = j => {
        Gn(), w(D => {
            const A = D[j];
            return z(L({}, D), {
                [j]: z(L({}, A), {
                    selected: !A.selected
                })
            })
        })
    }, e[22] = y) : y = e[22];
    const T = y;
    let P;
    e[23] === Symbol.for("react.memo_cache_sentinel") ? (P = (j, D) => {
        w(A => z(L({}, A), {
            [j]: z(L({}, A[j]), {
                promptValue: D
            })
        }))
    }, e[23] = P) : P = e[23];
    const M = P;
    let B;
    if (e[24] !== k || e[25] !== t) {
        B = [];
        for (const j of t) {
            const D = k[j.id];
            if (D != null && D.selected) {
                const A = D.promptValue || j.prompt || "";
                if (typeof j.id == "string" && j.id.toLowerCase().startsWith("other-") && !A.trim()) continue;
                B.push(z(L({}, j), {
                    prompt: A
                }))
            }
        }
        e[24] = k, e[25] = t, e[26] = B
    } else B = e[26];
    const a = B,
        O = a.length > 0;
    let F, v;
    e[27] !== O || e[28] !== u || e[29] !== s || e[30] !== a ? (F = () => {
        if (O === s.length > 0 && es(a, s)) return;
        const j = window.setTimeout(() => {
            u(O, a)
        }, 100);
        return () => window.clearTimeout(j)
    }, v = [O, u, s, a], e[27] = O, e[28] = u, e[29] = s, e[30] = a, e[31] = F, e[32] = v) : (F = e[31], v = e[32]), G.useEffect(F, v);
    let te;
    e[33] !== h ? (te = h.formatMessage(re.suggestionPromptPlaceholder), e[33] = h, e[34] = te) : te = e[34];
    const K = te;
    let Y;
    e[35] === Symbol.for("react.memo_cache_sentinel") ? (Y = {
        maxHeight: "min(calc(100vh - 124px), 700px)"
    }, e[35] = Y) : Y = e[35];
    let ne;
    e[36] === Symbol.for("react.memo_cache_sentinel") ? (ne = o.jsx(le, L({}, re.focusTitle)), e[36] = ne) : ne = e[36];
    let q;
    e[37] !== n ? (q = o.jsx("p", {
        id: n,
        className: "text-token-text-primary text-[28px] font-normal",
        children: ne
    }), e[37] = n, e[38] = q) : q = e[38];
    let Q;
    e[39] === Symbol.for("react.memo_cache_sentinel") ? (Q = o.jsx(le, L({}, re.focusBody)), e[39] = Q) : Q = e[39];
    let N;
    e[40] !== l ? (N = o.jsx("p", {
        id: l,
        className: "text-token-text-primary mt-3 text-base",
        children: Q
    }), e[40] = l, e[41] = N) : N = e[41];
    let se;
    e[42] === Symbol.for("react.memo_cache_sentinel") ? (se = o.jsx(le, L({}, re.basedOnYouLabel)), e[42] = se) : se = e[42];
    let S;
    e[43] !== r || e[44] !== K || e[45] !== k ? (S = o.jsx(an, {
        label: se,
        suggestions: r,
        selectionState: k,
        onToggle: T,
        onPromptChange: M,
        promptPlaceholder: K
    }), e[43] = r, e[44] = K, e[45] = k, e[46] = S) : S = e[46];
    let $;
    e[47] !== p || e[48] !== K || e[49] !== k ? ($ = p.length > 0 && o.jsx(an, {
        label: o.jsx(le, L({}, re.moreIdeasLabel)),
        suggestions: p,
        selectionState: k,
        onToggle: T,
        onPromptChange: M,
        promptPlaceholder: K
    }), e[47] = p, e[48] = K, e[49] = k, e[50] = $) : $ = e[50];
    let W;
    e[51] !== S || e[52] !== $ ? (W = o.jsxs("div", {
        className: "mt-6 flex flex-col gap-5 pb-6",
        children: [S, $]
    }), e[51] = S, e[52] = $, e[53] = W) : W = e[53];
    let U;
    return e[54] !== q || e[55] !== N || e[56] !== W ? (U = o.jsxs("div", {
        className: "bg-token-interactive-bg-tertiary-hover no-scrollbar flex h-full flex-col overflow-y-auto px-9 pt-[120px] pb-12",
        style: Y,
        children: [q, N, W]
    }), e[54] = q, e[55] = N, e[56] = W, e[57] = U) : U = e[57], U
}

function os(i) {
    return i.id
}

function is(i) {
    return i.id
}

function an(i) {
    "use forget";
    const e = ce.c(18),
        {
            label: n,
            suggestions: l,
            selectionState: u,
            onToggle: s,
            onPromptChange: c,
            promptPlaceholder: m
        } = i;
    let h;
    e[0] !== n ? (h = o.jsx("p", {
        className: "text-token-text-secondary text-sm",
        children: n
    }), e[0] = n, e[1] = h) : h = e[1];
    let C;
    if (e[2] !== c || e[3] !== s || e[4] !== m || e[5] !== u || e[6] !== l) {
        let p;
        e[8] !== c || e[9] !== s || e[10] !== m || e[11] !== u ? (p = g => {
            var t, d, b, E, k;
            return o.jsx(Zn, {
                suggestion: g,
                selected: (d = (t = u[g.id]) == null ? void 0 : t.selected) != null ? d : !1,
                promptValue: (E = (b = u[g.id]) == null ? void 0 : b.promptValue) != null ? E : "",
                onToggle: s,
                onPromptChange: c,
                promptPlaceholder: (k = g.hint) != null ? k : m
            }, g.id)
        }, e[8] = c, e[9] = s, e[10] = m, e[11] = u, e[12] = p) : p = e[12], C = l.map(p), e[2] = c, e[3] = s, e[4] = m, e[5] = u, e[6] = l, e[7] = C
    } else C = e[7];
    let r;
    e[13] !== C ? (r = o.jsx("div", {
        className: "mt-4 space-y-2",
        children: C
    }), e[13] = C, e[14] = r) : r = e[14];
    let x;
    return e[15] !== h || e[16] !== r ? (x = o.jsxs("div", {
        children: [h, r]
    }), e[15] = h, e[16] = r, e[17] = x) : x = e[17], x
}
const rn = Vt({
        backLabel: {
            id: "pulse.onboarding.modal.backLabel",
            defaultMessage: "Go back"
        },
        modalClose: {
            id: "pulse.onboarding.modal.close",
            defaultMessage: "Close onboarding"
        }
    }),
    fn = {
        step: "hero",
        hasInterestsSelection: !1,
        selectedSuggestions: [],
        isCompleting: !1,
        isCheckingConnector: !1,
        isConnecting: !1,
        hasCompletedConnection: !1,
        isSkipping: !1
    };

function ls(i, e) {
    switch (e.type) {
        case "SET_STEP":
            return z(L({}, i), {
                step: e.step
            });
        case "SET_SELECTIONS":
            return z(L({}, i), {
                hasInterestsSelection: e.hasSelection,
                selectedSuggestions: e.selectedSuggestions
            });
        case "SET_COMPLETING":
            return z(L({}, i), {
                isCompleting: e.value
            });
        case "SET_SKIPPING":
            return z(L({}, i), {
                isSkipping: e.value
            });
        case "SET_CHECKING_CONNECTOR":
            return z(L({}, i), {
                isCheckingConnector: e.value
            });
        case "SET_CONNECTING":
            return z(L({}, i), {
                isConnecting: e.value
            });
        case "RESET_CONNECTOR_PROGRESS":
            return z(L({}, i), {
                hasCompletedConnection: !1,
                isCheckingConnector: !1,
                isConnecting: !1,
                isSkipping: !1
            });
        case "MARK_CONNECTION_COMPLETE":
            return z(L({}, i), {
                hasCompletedConnection: e.value
            });
        case "RESET":
            return L({}, fn);
        default:
            return i
    }
}

function cs(i) {
    "use forget";
    var zt, Ht, At, Ft, Kt, Yt, Wt, qt, Qt, Jt, Xt;
    const e = ce.c(205),
        {
            isOpen: n,
            onClose: l,
            onComplete: u,
            entrypointData: s,
            source: c
        } = i,
        m = dn();
    let h;
    e[0] !== m ? (h = () => Vn(m), e[0] = m, e[1] = h) : h = e[1];
    const C = un(h),
        r = En();
    let x;
    e[2] === Symbol.for("react.memo_cache_sentinel") ? (x = {
        fetchValidLinksOnly: !0,
        productSku: Nn.CONNECTOR_SETTING
    }, e[2] = x) : x = e[2];
    const {
        connectorLinks: p,
        refetch: g
    } = vn(x), [t, d] = G.useReducer(ls, fn), b = G.useId(), E = G.useId(), {
        mutate: k
    } = Tn(!0);
    let w;
    e[3] === Symbol.for("react.memo_cache_sentinel") ? (w = [], e[3] = w) : w = e[3];
    const [_, I] = G.useState(w), y = s == null ? void 0 : s.onboarding_config, [T, P] = G.useState(y);
    let M, B;
    e[4] !== n || e[5] !== y ? (M = () => {
        P(n ? f => y != null ? y : f : y)
    }, B = [n, y], e[4] = n, e[5] = y, e[6] = M, e[7] = B) : (M = e[6], B = e[7]), G.useEffect(M, B);
    const a = y != null ? y : T,
        O = a == null ? void 0 : a.connectors_config;
    O == null || O.connector_ids;
    let F;
    e[8] !== (O == null ? void 0 : O.connector_ids) ? (F = (zt = O == null ? void 0 : O.connector_ids) != null ? zt : [], e[8] = O == null ? void 0 : O.connector_ids, e[9] = F) : F = e[9];
    const v = F,
        te = v[0],
        K = v.length > 0,
        Y = mt(),
        ne = _n(),
        q = c != null ? c : "unknown";
    let Q;
    e[10] !== K ? (Q = ["hero", "interests"], K && Q.push("connect"), e[10] = K, e[11] = Q) : Q = e[11];
    const N = Q;
    let se;
    e: {
        if (!N.length) {
            se = "hero";
            break e
        }
        se = N.includes(t.step) ? t.step : N[0]
    }
    const S = se,
        $ = N.indexOf(S);
    let W;
    e[12] !== q ? (W = [{
        key: "source",
        value: q
    }], e[12] = q, e[13] = W) : W = e[13];
    const U = W,
        j = G.useRef(null);
    let D, A;
    e[14] !== S || e[15] !== n ? (A = () => {
        if (!n) {
            j.current && (sn(j.current), j.current = null);
            return
        }
        j.current !== S && (j.current && sn(j.current), Un(S), j.current = S)
    }, D = [S, n], e[14] = S, e[15] = n, e[16] = D, e[17] = A) : (D = e[16], A = e[17]), G.useEffect(A, D);
    let ye;
    e[18] !== l || e[19] !== U ? (ye = f => {
        f && oe.count(ie.PULSE, "chatgpt_pulse_onboarding_modal_closed", U), l(f)
    }, e[18] = l, e[19] = U, e[20] = ye) : ye = e[20];
    const X = ye;
    let Ne, ve;
    e[21] !== n || e[22] !== U ? (Ne = () => {
        n && oe.count(ie.PULSE, "chatgpt_pulse_onboarding_modal_shown", U)
    }, ve = [n, U], e[21] = n, e[22] = U, e[23] = Ne, e[24] = ve) : (Ne = e[23], ve = e[24]), G.useEffect(Ne, ve);
    let Te, we;
    e[25] !== n ? (Te = () => {
        n || d({
            type: "RESET"
        })
    }, we = [n], e[25] = n, e[26] = Te, e[27] = we) : (Te = e[26], we = e[27]), G.useEffect(Te, we);
    let Ie, Pe;
    e[28] !== N || e[29] !== t.step ? (Ie = () => {
        N.length && (N.includes(t.step) || d({
            type: "SET_STEP",
            step: N[0]
        }))
    }, Pe = [N, t.step], e[28] = N, e[29] = t.step, e[30] = Ie, e[31] = Pe) : (Ie = e[30], Pe = e[31]), G.useEffect(Ie, Pe);
    let Oe;
    e[32] !== N ? (Oe = N.filter(us), e[32] = N, e[33] = Oe) : Oe = e[33];
    const _e = Oe,
        de = _e.length;
    let je;
    e[34] !== _e ? (je = f => {
        const R = _e.indexOf(f);
        return R === -1 ? _e.length : R + 1
    }, e[34] = _e, e[35] = je) : je = e[35];
    const Ut = je;
    let Le;
    e[36] !== m || e[37] !== t.isCompleting || e[38] !== t.selectedSuggestions || e[39] !== X || e[40] !== ne || e[41] !== u || e[42] !== U || e[43] !== C ? (Le = async f => {
        t.isCompleting || (oe.count(ie.PULSE, "chatgpt_pulse_onboarding_completed", [...U, {
            key: "reason",
            value: f
        }]), d({
            type: "SET_COMPLETING",
            value: !0
        }), await C.mutate(t.selectedSuggestions).catch(ds), await pn.refetch(m, {
            useCache: !1
        }).catch(rs), u == null || u(), d({
            type: "SET_COMPLETING",
            value: !1
        }), X(!0), ne("/pulse"))
    }, e[36] = m, e[37] = t.isCompleting, e[38] = t.selectedSuggestions, e[39] = X, e[40] = ne, e[41] = u, e[42] = U, e[43] = C, e[44] = Le) : Le = e[44];
    const V = Le;
    let Me;
    e[45] !== N ? (Me = f => {
        N.includes(f) && d({
            type: "SET_STEP",
            step: f
        })
    }, e[45] = N, e[46] = Me) : Me = e[46];
    const ht = Me;
    let Re;
    e[47] !== N || e[48] !== $ || e[49] !== V ? (Re = async () => {
        if ($ === -1) return;
        if ($ === N.length - 1) {
            await V("flow_end");
            return
        }
        const R = N[$ + 1];
        R === "connect" && d({
            type: "RESET_CONNECTOR_PROGRESS"
        }), d({
            type: "SET_STEP",
            step: R
        })
    }, e[47] = N, e[48] = $, e[49] = V, e[50] = Re) : Re = e[50];
    const Ct = Re;
    let Ge;
    e[51] !== N || e[52] !== $ ? (Ge = () => {
        if ($ <= 0) return;
        const f = N[$ - 1];
        d({
            type: "SET_STEP",
            step: f
        })
    }, e[51] = N, e[52] = $, e[53] = Ge) : Ge = e[53];
    const gn = Ge;
    let Be;
    e[54] !== ht ? (Be = () => {
        Dn(), oe.count(ie.PULSE, "chatgpt_pulse_onboarding_hero_get_started_clicked"), ht("interests")
    }, e[54] = ht, e[55] = Be) : Be = e[55];
    const St = Be;
    let $e;
    e[56] !== N.length || e[57] !== $ || e[58] !== Ct || e[59] !== U ? ($e = async () => {
        $ === N.length - 1 ? zn() : Hn(), oe.count(ie.PULSE, "chatgpt_pulse_onboarding_interests_next_clicked", U), await Ct()
    }, e[56] = N.length, e[57] = $, e[58] = Ct, e[59] = U, e[60] = $e) : $e = e[60];
    const xt = $e,
        Ve = $ > 0 ? gn : void 0;
    let Ue, De;
    e[61] !== S || e[62] !== t.isCheckingConnector || e[63] !== t.isConnecting ? (Ue = () => {
        S !== "connect" && (t.isCheckingConnector || t.isConnecting) && d({
            type: "RESET_CONNECTOR_PROGRESS"
        })
    }, De = [S, t.isCheckingConnector, t.isConnecting], e[61] = S, e[62] = t.isCheckingConnector, e[63] = t.isConnecting, e[64] = Ue, e[65] = De) : (Ue = e[64], De = e[65]), G.useEffect(Ue, De);
    const bt = !!Ve,
        yt = S === "interests" ? "!bg-[#F3F3F3]" : "!bg-white",
        _t = a == null ? void 0 : a.onboarding_preview_items;
    let ze;
    e[66] !== E || e[67] !== St || e[68] !== b || e[69] !== _t ? (ze = {
        headingId: b,
        descriptionId: E,
        onGetStarted: St,
        previewItems: _t
    }, e[66] = E, e[67] = St, e[68] = b, e[69] = _t, e[70] = ze) : ze = e[70];
    const mn = Bn(ze),
        kt = Ut("interests");
    let He;
    e[71] === Symbol.for("react.memo_cache_sentinel") ? (He = (f, R) => {
        d({
            type: "SET_SELECTIONS",
            hasSelection: f,
            selectedSuggestions: R
        })
    }, e[71] = He) : He = e[71];
    let ue;
    e[72] !== (a == null ? void 0 : a.personalized_suggestions) ? (ue = (Ht = a == null ? void 0 : a.personalized_suggestions) != null ? Ht : [], e[72] = a == null ? void 0 : a.personalized_suggestions, e[73] = ue) : ue = e[73];
    let pe;
    e[74] !== (a == null ? void 0 : a.generic_suggestions) ? (pe = (At = a == null ? void 0 : a.generic_suggestions) != null ? At : [], e[74] = a == null ? void 0 : a.generic_suggestions, e[75] = pe) : pe = e[75];
    let Ae;
    e[76] !== E || e[77] !== t.hasInterestsSelection || e[78] !== t.isCompleting || e[79] !== t.selectedSuggestions || e[80] !== xt || e[81] !== b || e[82] !== kt || e[83] !== ue || e[84] !== pe || e[85] !== de ? (Ae = {
        headingId: b,
        descriptionId: E,
        onNext: xt,
        stepIndex: kt,
        totalSteps: de,
        isSubmitting: t.isCompleting,
        hasSelection: t.hasInterestsSelection,
        selectedSuggestions: t.selectedSuggestions,
        onSelectionChange: He,
        personalizedSuggestions: ue,
        genericSuggestions: pe
    }, e[76] = E, e[77] = t.hasInterestsSelection, e[78] = t.isCompleting, e[79] = t.selectedSuggestions, e[80] = xt, e[81] = b, e[82] = kt, e[83] = ue, e[84] = pe, e[85] = de, e[86] = Ae) : Ae = e[86];
    const Dt = ns(Ae);
    let Fe;
    e[87] !== p ? (Fe = f => p.has(f), e[87] = p, e[88] = Fe) : Fe = e[88];
    const H = Fe;
    let Ke;
    if (e[89] !== v || e[90] !== p) {
        let f;
        e[92] !== p ? (f = R => p.has(R), e[92] = p, e[93] = f) : f = e[93], Ke = v.some(f), e[89] = v, e[90] = p, e[91] = Ke
    } else Ke = e[91];
    const J = Ke;
    let Ye;
    e[94] !== k ? (Ye = f => {
        const R = on[f];
        R && k({
            setting: R,
            value: !0
        })
    }, e[94] = k, e[95] = Ye) : Ye = e[95];
    const ae = Ye;
    let We;
    e[96] !== k ? (We = f => {
        const R = on[f];
        R && k({
            setting: R,
            value: !1
        })
    }, e[96] = k, e[97] = We) : We = e[97];
    const Et = We;
    let qe;
    e[98] !== v || e[99] !== H ? (qe = f => ({
        connectorIds: v.filter(H),
        connectFlow: f
    }), e[98] = v, e[99] = H, e[100] = qe) : qe = e[100];
    const Z = qe;
    let Qe;
    e[101] !== v || e[102] !== Et || e[103] !== t.isCheckingConnector || e[104] !== t.isCompleting || e[105] !== t.isConnecting || e[106] !== t.isSkipping || e[107] !== V || e[108] !== H ? (Qe = async () => {
        if (t.isConnecting || t.isCompleting || t.isSkipping || t.isCheckingConnector) return;
        An(), oe.count(ie.PULSE, "chatgpt_pulse_onboarding_connectors_skip_clicked"), v.filter(H).forEach(Et), I([]), d({
            type: "SET_SKIPPING",
            value: !0
        }), await V("connectors_skipped"), d({
            type: "SET_SKIPPING",
            value: !1
        })
    }, e[101] = v, e[102] = Et, e[103] = t.isCheckingConnector, e[104] = t.isCompleting, e[105] = t.isConnecting, e[106] = t.isSkipping, e[107] = V, e[108] = H, e[109] = Qe) : Qe = e[109];
    const Nt = Qe;
    let Je;
    e[110] !== Z || e[111] !== v || e[112] !== ae || e[113] !== t.isCompleting || e[114] !== t.isConnecting || e[115] !== V || e[116] !== H || e[117] !== r || e[118] !== g ? (Je = async () => {
        if (!v.length || t.isCompleting || t.isConnecting) return;
        Fn(), oe.count(ie.PULSE, "chatgpt_pulse_onboarding_connectors_connect_clicked");
        const f = v.filter(H),
            R = v.filter(hn => !H(hn));
        if (f.forEach(ae), I(R), R.length === 0) {
            ln(Z(!1)), await V("connector_linked");
            return
        }
        d({
            type: "RESET_CONNECTOR_PROGRESS"
        }), d({
            type: "SET_STEP",
            step: "connect"
        }), d({
            type: "SET_CHECKING_CONNECTOR",
            value: !0
        });
        const gt = R[0];
        gt && r({
            referrer: wn.PulseOnboarding,
            connectorId: gt,
            showSettingsBehindConnectorLink: !1,
            noRedirect: !0
        }), await g()
    }, e[110] = Z, e[111] = v, e[112] = ae, e[113] = t.isCompleting, e[114] = t.isConnecting, e[115] = V, e[116] = H, e[117] = r, e[118] = g, e[119] = Je) : Je = e[119];
    const vt = Je;
    let Xe, Ze;
    e[120] !== v.length || e[121] !== t.isCheckingConnector || e[122] !== g ? (Xe = () => {
        if (!t.isCheckingConnector || !v.length) return;
        const f = window.setInterval(() => {
            g()
        }, 1e3);
        return () => window.clearInterval(f)
    }, Ze = [v.length, t.isCheckingConnector, g], e[120] = v.length, e[121] = t.isCheckingConnector, e[122] = g, e[123] = Xe, e[124] = Ze) : (Xe = e[123], Ze = e[124]), G.useEffect(Xe, Ze);
    let et, tt;
    e[125] !== S || e[126] !== t.isCheckingConnector || e[127] !== g ? (et = () => {
        if (!t.isCheckingConnector || S !== "connect") return;
        const f = () => {
            g()
        };
        return window.addEventListener("focus", f), () => window.removeEventListener("focus", f)
    }, tt = [t.isCheckingConnector, S, g], e[125] = S, e[126] = t.isCheckingConnector, e[127] = g, e[128] = et, e[129] = tt) : (et = e[128], tt = e[129]), G.useEffect(et, tt);
    let nt;
    e[130] !== Z || e[131] !== J || e[132] !== S || e[133] !== t.hasCompletedConnection || e[134] !== V || e[135] !== _.length ? (nt = () => {
        if (!J || t.hasCompletedConnection || S !== "connect" || _.length === 0) return;
        let f = !1;
        return (async () => (ln(Z(!0)), oe.count(ie.PULSE, "chatgpt_pulse_onboarding_connector_linked"), d({
            type: "SET_CONNECTING",
            value: !0
        }), await V("connector_linked"), !f && (d({
            type: "MARK_CONNECTION_COMPLETE",
            value: !0
        }), d({
            type: "SET_CHECKING_CONNECTOR",
            value: !1
        }), d({
            type: "SET_CONNECTING",
            value: !1
        }))))(), () => {
            f = !0
        }
    }, e[130] = Z, e[131] = J, e[132] = S, e[133] = t.hasCompletedConnection, e[134] = V, e[135] = _.length, e[136] = nt) : nt = e[136];
    let st;
    e[137] !== Z || e[138] !== te || e[139] !== J || e[140] !== S || e[141] !== t.hasCompletedConnection || e[142] !== V || e[143] !== _.length ? (st = [J, te, Z, t.hasCompletedConnection, V, S, _.length], e[137] = Z, e[138] = te, e[139] = J, e[140] = S, e[141] = t.hasCompletedConnection, e[142] = V, e[143] = _.length, e[144] = st) : st = e[144], G.useEffect(nt, st);
    let ot, it;
    e[145] !== J || e[146] !== S || e[147] !== t.isCheckingConnector ? (ot = () => {
        if (!t.isCheckingConnector || S !== "connect" || J) return;
        const f = window.setTimeout(() => {
            d({
                type: "SET_CHECKING_CONNECTOR",
                value: !1
            }), d({
                type: "SET_CONNECTING",
                value: !1
            })
        }, 3e3);
        return () => window.clearTimeout(f)
    }, it = [t.isCheckingConnector, S, J], e[145] = J, e[146] = S, e[147] = t.isCheckingConnector, e[148] = ot, e[149] = it) : (ot = e[148], it = e[149]), G.useEffect(ot, it);
    let lt, ct;
    e[150] !== ae || e[151] !== H || e[152] !== _ ? (lt = () => {
        if (!_.length) return;
        const f = _.filter(H);
        if (!f.length) return;
        f.forEach(ae);
        const R = _.filter(gt => !f.includes(gt));
        I(R)
    }, ct = [_, H, ae, I], e[150] = ae, e[151] = H, e[152] = _, e[153] = lt, e[154] = ct) : (lt = e[153], ct = e[154]), G.useEffect(lt, ct);
    let fe;
    e[155] !== ((Ft = a == null ? void 0 : a.connectors_config) == null ? void 0 : Ft.connectors_preview_items) ? (fe = (Yt = (Kt = a == null ? void 0 : a.connectors_config) == null ? void 0 : Kt.connectors_preview_items) != null ? Yt : [], e[155] = (Wt = a == null ? void 0 : a.connectors_config) == null ? void 0 : Wt.connectors_preview_items, e[156] = fe) : fe = e[156];
    let at;
    e[157] !== fe ? (at = fe.map(as), e[157] = fe, e[158] = at) : at = e[158];
    const Tt = at,
        wt = K ? O : null,
        It = Ut("connect"),
        Pt = t.isSkipping && !t.isConnecting && !t.isCheckingConnector,
        Ot = t.isCheckingConnector || t.isConnecting,
        jt = t.isConnecting || t.isCompleting || t.isCheckingConnector || t.isSkipping,
        Lt = t.isCompleting || t.isConnecting || t.isCheckingConnector || t.isSkipping || !v.length,
        Mt = (Qt = (qt = a == null ? void 0 : a.connectors_config) == null ? void 0 : qt.cta_text) != null ? Qt : void 0;
    let rt;
    e[159] !== Tt || e[160] !== E || e[161] !== Nt || e[162] !== vt || e[163] !== b || e[164] !== wt || e[165] !== It || e[166] !== Pt || e[167] !== Ot || e[168] !== jt || e[169] !== Lt || e[170] !== Mt || e[171] !== de ? (rt = {
        connectorCards: Tt,
        config: wt,
        headingId: b,
        descriptionId: E,
        onConnect: vt,
        onSkip: Nt,
        stepIndex: It,
        totalSteps: de,
        isSkipLoading: Pt,
        isConnectLoading: Ot,
        disableSkip: jt,
        disableConnect: Lt,
        connectCta: Mt
    }, e[159] = Tt, e[160] = E, e[161] = Nt, e[162] = vt, e[163] = b, e[164] = wt, e[165] = It, e[166] = Pt, e[167] = Ot, e[168] = jt, e[169] = Lt, e[170] = Mt, e[171] = de, e[172] = rt) : rt = e[172];
    const ge = Qn(rt);
    let dt, ut;
    e[173] !== ge || e[174] !== S || e[175] !== V ? (dt = () => {
        S === "connect" && !ge && V("connectors_step_missing")
    }, ut = [ge, V, S], e[173] = ge, e[174] = S, e[175] = V, e[176] = dt, e[177] = ut) : (dt = e[176], ut = e[177]), G.useEffect(dt, ut);
    let ke;
    e: {
        if (S === "hero") {
            ke = mn;
            break e
        }
        if (S === "interests") {
            ke = Dt;
            break e
        }
        if (S === "connect" && ge) {
            ke = ge;
            break e
        }
        ke = Dt
    }
    const ee = ke;
    let pt;
    e[178] !== ee.footerContent ? (pt = ee.footerContent ? o.jsx("div", {
        className: "flex w-full flex-row justify-start",
        children: ee.footerContent
    }) : null, e[178] = ee.footerContent, e[179] = pt) : pt = e[179];
    const Rt = pt,
        Gt = (Jt = ee.primaryButton) != null ? Jt : null,
        Bt = (Xt = ee.secondaryButton) != null ? Xt : null;
    let me;
    e[180] !== X ? (me = () => X(!0), e[180] = X, e[181] = me) : me = e[181];
    let he;
    e[182] !== Y ? (he = Y.formatMessage(rn.backLabel), e[182] = Y, e[183] = he) : he = e[183];
    let Ce;
    e[184] !== Y ? (Ce = Y.formatMessage(rn.modalClose), e[184] = Y, e[185] = Ce) : Ce = e[185];
    let Se;
    e[186] !== Ve || e[187] !== yt || e[188] !== bt || e[189] !== me || e[190] !== he || e[191] !== Ce ? (Se = o.jsx(Kn, {
        onClose: me,
        onBack: Ve,
        backAriaLabel: he,
        closeAriaLabel: Ce,
        showBack: bt,
        showClose: !0,
        buttonBackgroundClassName: yt
    }), e[186] = Ve, e[187] = yt, e[188] = bt, e[189] = me, e[190] = he, e[191] = Ce, e[192] = Se) : Se = e[192];
    let xe;
    e[193] !== ee.content || e[194] !== Se ? (xe = o.jsxs("div", {
        className: "bg-token-bg-primary relative flex max-h-[724px] min-h-[400px] flex-col rounded-2xl",
        children: [Se, ee.content]
    }), e[193] = ee.content, e[194] = Se, e[195] = xe) : xe = e[195];
    let ft;
    return e[196] !== E || e[197] !== Rt || e[198] !== X || e[199] !== b || e[200] !== n || e[201] !== Gt || e[202] !== Bt || e[203] !== xe ? (ft = o.jsx(In, {
        testId: "modal-pulse-onboarding",
        isOpen: n,
        onClose: X,
        contentClassName: "!p-0",
        className: "max-w-[680px]!",
        ariaLabelledBy: b,
        ariaDescribedBy: E,
        footerClassName: "border-token-border-subtle border-t px-9 py-5 text-sm gap-4",
        footerIsSpacedBetween: !1,
        footerHasTopMargin: !1,
        footerContent: Rt,
        primaryButton: Gt,
        secondaryButton: Bt,
        shouldIgnoreClickOutside: !0,
        isScrollable: !0,
        children: xe
    }), e[196] = E, e[197] = Rt, e[198] = X, e[199] = b, e[200] = n, e[201] = Gt, e[202] = Bt, e[203] = xe, e[204] = ft) : ft = e[204], ft
}

function as(i, e) {
    var l, u, s;
    let n = (u = (l = i.preview) != null ? l : i.title) != null ? u : "";
    return n.endsWith(".") && (n = n.slice(0, -1)), o.jsx($n, {
        title: n,
        imageUrl: i.image_url
    }, (s = i.id) != null ? s : "".concat(i.title, "-").concat(e))
}

function rs() {
    return null
}

function ds() {
    return null
}

function us(i) {
    return i !== "hero"
}

function ps(i) {
    "use forget";
    const e = ce.c(14),
        {
            onClose: n,
            source: l,
            entrypointData: u
        } = i,
        s = dn();
    let c;
    e[0] !== s || e[1] !== u ? (c = () => {
        var x;
        if (u) return u;
        if (Yn(s)) return (x = pn(s).data) != null ? x : void 0
    }, e[0] = s, e[1] = u, e[2] = c) : c = e[2];
    const m = un(c);
    if (!m) return null;
    let h;
    e[3] !== n ? (h = x => {
        x && n()
    }, e[3] = n, e[4] = h) : h = e[4];
    let C;
    e[5] !== s || e[6] !== n || e[7] !== l ? (C = () => {
        l !== "unknown" && Wn.set(s, l), qn("/pulse"), n()
    }, e[5] = s, e[6] = n, e[7] = l, e[8] = C) : C = e[8];
    let r;
    return e[9] !== m || e[10] !== l || e[11] !== h || e[12] !== C ? (r = o.jsx(cs, {
        isOpen: !0,
        entrypointData: m,
        source: l,
        onClose: h,
        onComplete: C
    }), e[9] = m, e[10] = l, e[11] = h, e[12] = C, e[13] = r) : r = e[13], r
}

function Cs(i, {
    source: e,
    entrypointData: n
}) {
    Pn(i, ps, {
        source: e,
        entrypointData: n
    })
}
export {
    Cs as o
};
//# sourceMappingURL=ew68kf01y1h7e4uk.js.map