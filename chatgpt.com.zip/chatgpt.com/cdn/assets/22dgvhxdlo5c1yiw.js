import {
    r as _,
    e as w,
    j as e,
    M as g,
    u as F
} from "./fg33krlcm0qyi6yw.js";
import {
    H as S,
    C as U,
    m as R,
    a9 as N,
    dv as D,
    gL as f,
    g2 as b,
    l as E,
    gJ as L,
    c0 as O
} from "./dykg4ktvbu3mhmdo.js";
import {
    A as z
} from "./cehclh0a60ppuuvu.js";
import {
    A as X
} from "./cjybewlxcr1rdyw3.js";
import {
    z as q,
    cP as K
} from "./k15yxxoybkkir2ou.js";

function ee({
    accountId: n,
    connectionId: a,
    isOpen: t,
    objectType: s,
    onClose: r
}) {
    var P;
    const [l, o] = _.useState(null), [h, m] = _.useState([]), [u, x] = _.useState(!1), [i, d] = _.useState(!1), c = S(), p = w(), k = (P = c == null ? void 0 : c.isPersonalAccount()) != null ? P : !1, j = async v => {
        var C;
        x(!0), d(!1);
        try {
            const y = k ? await f.user_connection_list_item_scopes(a, s, v) : await f.admin_connection_list_item_scopes(n, a, s, v);
            o((C = y.page_token) != null ? C : null), m(A => [...A, ...y.object_selections.map(B => B.object_handle)])
        } catch (y) {
            d(!0)
        } finally {
            x(!1)
        }
    }, M = () => {
        o(null), x(!1), m([]), d(!1), j(null)
    }, I = _.useRef(!1);
    return _.useEffect(() => {
        I.current || (I.current = !0, M())
    }, []), e.jsx(U, {
        testId: "modal-connection-blocked-items",
        isOpen: t,
        onClose: r,
        type: "success",
        size: "custom",
        className: "max-w-xl",
        showCloseButton: !0,
        title: p.formatMessage({
            id: "BVUVRc",
            defaultMessage: "Block items"
        }),
        children: e.jsxs("div", {
            className: "flex flex-col gap-4",
            children: [e.jsx("p", {
                className: "text-token-text-secondary text-sm",
                children: e.jsx(g, {
                    id: "LYXIh1",
                    defaultMessage: "Found something that shouldn't be synced? You can block items here to prevent them from being synced or shown in search results."
                })
            }), e.jsx(Z, {
                accountId: n,
                connectionId: a,
                objectType: s,
                onItemBlocked: M
            }), e.jsx(V, {
                accountId: n,
                connectionId: a,
                hasError: i,
                hasMoreItems: l != null,
                isLoading: u,
                loadMoreItems: () => j(l),
                objectHandles: h,
                objectType: s,
                onItemUnblocked: M
            })]
        })
    })
}

function V({
    connectionId: n,
    accountId: a,
    objectHandles: t,
    isLoading: s,
    hasError: r,
    hasMoreItems: l,
    loadMoreItems: o,
    onItemUnblocked: h,
    objectType: m
}) {
    return e.jsxs("div", {
        children: [e.jsx("h3", {
            className: "mb-2 font-medium",
            children: e.jsx(g, {
                id: "gimLZo",
                defaultMessage: "Currently blocked items"
            })
        }), r ? e.jsxs("div", {
            className: "flex flex-col items-center justify-center gap-2",
            children: [e.jsx("div", {
                className: "text-token-text-error",
                children: e.jsx(g, {
                    id: "3BZzpX",
                    defaultMessage: "Something went wrong"
                })
            }), e.jsx("div", {
                children: e.jsx(N, {
                    color: "secondary",
                    icon: X,
                    onClick: o,
                    children: e.jsx(g, {
                        id: "fFd9RR",
                        defaultMessage: "Try again"
                    })
                })
            })]
        }) : e.jsxs(e.Fragment, {
            children: [t.length > 0 || s ? e.jsx("ul", {
                className: "flex flex-col gap-1",
                children: t.map(u => e.jsx(Q, {
                    connectionId: n,
                    accountId: a,
                    objectType: m,
                    objectHandle: u,
                    onItemUnblocked: h
                }, u))
            }) : e.jsx("p", {
                className: "text-token-text-secondary text-sm",
                children: e.jsx(g, {
                    id: "IGg+fh",
                    defaultMessage: "No items are currently being blocked."
                })
            }), s ? e.jsx(D, {
                lines: 1
            }) : l && e.jsx(N, {
                color: "ghost",
                icon: z,
                onClick: o,
                children: e.jsx(g, {
                    id: "g+Tw+y",
                    defaultMessage: "See more"
                })
            })]
        })]
    })
}

function Q({
    connectionId: n,
    accountId: a,
    objectHandle: t,
    onItemUnblocked: s,
    objectType: r
}) {
    const l = R(),
        o = w();
    return e.jsx(Y, {
        scopeChangeIcon: K,
        scopeChangeLabel: o.formatMessage({
            id: "yaj/om",
            defaultMessage: "Unblock item"
        }),
        scopeChangeTarget: "include",
        objectHandle: t,
        objectType: r,
        onError: () => {
            l.danger(o.formatMessage({
                id: "yRm6yX",
                defaultMessage: "Failed to unblock item. Please try again later."
            }), {
                loggingTitle: "Failed to unblock item. Please try again later.",
                toastId: "blocked_items_modal",
                loggingDescription: "Failed to unblock item"
            })
        },
        onScopeUpdated: () => {
            l.success(o.formatMessage({
                id: "Xot/uQ",
                defaultMessage: "Item successfully unblocked."
            })), s()
        },
        connectionId: n,
        accountId: a
    })
}

function Y({
    connectionId: n,
    accountId: a,
    objectType: t,
    objectHandle: s,
    scopeChangeTarget: r,
    scopeChangeLabel: l,
    scopeChangeIcon: o,
    onScopeUpdated: h,
    onError: m
}) {
    var k;
    const u = S(),
        x = (k = u == null ? void 0 : u.isPersonalAccount()) != null ? k : !1,
        [i, d] = _.useState(!1),
        {
            isPending: c,
            mutate: p
        } = F({
            mutationFn: async () => r === "exclude" ? x ? await f.user_connection_block_items(n, t, [s]) : await f.admin_connection_block_items(a, n, t, [s]) : x ? await f.user_connection_unblock_items(n, t, [s]) : await f.admin_connection_unblock_items(a, n, t, [s]),
            mutationKey: ["admin_connection_update_item_scope", n, t, r, s],
            onSuccess: () => {
                h(), d(!1)
            },
            onError: () => {
                d(!1), m()
            }
        });
    return e.jsxs("li", {
        className: "group hover:bg-token-surface-hover flex w-full flex-row rounded-xl px-4 py-1 text-sm",
        children: [e.jsx("span", {
            className: "flex-1",
            children: s
        }), e.jsxs(b.Root, {
            open: i || c,
            onOpenChange: d,
            children: [e.jsx(b.Trigger, {
                className: E("h-6 flex-0 group-hover:visible", !i && "invisible"),
                children: e.jsx(L, {
                    className: "icon-sm"
                })
            }), e.jsx(b.Portal, {
                children: e.jsx(b.Content, {
                    size: "small",
                    children: e.jsx(b.Item, {
                        icon: c ? O : o,
                        onSelect: () => p(),
                        disabled: c,
                        children: l
                    })
                })
            })]
        })]
    })
}

function Z({
    accountId: n,
    connectionId: a,
    objectType: t,
    onItemBlocked: s
}) {
    const r = R(),
        l = w();
    return e.jsxs("div", {
        className: "flex flex-col gap-2",
        children: [e.jsx("h3", {
            className: "font-medium",
            children: e.jsx(g, {
                id: "dU+IPT",
                defaultMessage: "Block an item"
            })
        }), e.jsx("p", {
            className: "text-token-text-secondary text-sm",
            children: e.jsx(g, {
                id: "y6yn/t",
                defaultMessage: "Enter the ID or URL of the item you want to block."
            })
        }), e.jsx(G, {
            accountId: n,
            connectionId: a,
            objectType: t,
            onSuccess: () => {
                r.success(l.formatMessage({
                    id: "Q+KnAh",
                    defaultMessage: "Item successfully blocked."
                })), s()
            },
            onError: () => {
                r.danger(l.formatMessage({
                    id: "UH92LU",
                    defaultMessage: "Failed to block item. Please try again later."
                }), {
                    toastId: "blocked_items_modal",
                    loggingTitle: "Failed to block item. Please try again later.",
                    loggingDescription: "Toast message shown when an item (e.g. file, channel, document, etc.) that the admin requested to block from syncing was unable to be blocked."
                })
            },
            targetScopeSelection: "exclude",
            buttonLabel: e.jsx(g, {
                id: "5FIVI9",
                defaultMessage: "Block"
            })
        })]
    })
}

function G({
    accountId: n,
    buttonLabel: a,
    connectionId: t,
    objectType: s,
    onError: r,
    onSuccess: l,
    placeholder: o,
    targetScopeSelection: h
}) {
    var k;
    const m = S(),
        u = w(),
        x = (k = m == null ? void 0 : m.isPersonalAccount()) != null ? k : !1,
        [i, d] = _.useState(""),
        {
            isPending: c,
            mutate: p
        } = F({
            mutationFn: async () => {
                if (i.trim()) return h === "exclude" ? x ? await f.user_connection_block_items(t, s, [i]) : await f.admin_connection_block_items(n, t, s, [i]) : x ? await f.user_connection_unblock_items(t, s, [i]) : await f.admin_connection_unblock_items(n, t, s, [i])
            },
            mutationKey: ["admin_connection_update_item_scope", t, s, h, i],
            onSuccess: () => {
                l(), d("")
            },
            onError: r
        });
    return e.jsx("form", {
        onSubmit: j => {
            j.preventDefault(), i.trim() && p()
        },
        children: e.jsxs("div", {
            className: "flex w-full flex-row gap-2",
            children: [e.jsx(q, {
                type: "text",
                className: "flex-1",
                name: "objectHandle",
                ariaLabel: "object handle",
                value: i,
                onChange: j => d(j.target.value),
                placeholder: o != null ? o : u.formatMessage({
                    id: "sPUyj/",
                    defaultMessage: "ID or URL"
                }),
                disabled: c
            }), e.jsx(N, {
                color: "primary",
                type: "button",
                onClick: () => p(),
                loading: c,
                disabled: c || !i.trim(),
                className: "flex-0",
                children: a
            })]
        })
    })
}
export {
    ee as C, Y as I, G as U
};
//# sourceMappingURL=22dgvhxdlo5c1yiw.js.map