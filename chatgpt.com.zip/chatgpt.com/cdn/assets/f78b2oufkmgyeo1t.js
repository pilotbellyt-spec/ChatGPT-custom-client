const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/bo2v113kbgrh2zlp.js", "assets/o4n6pqcoqgw7owdr.js", "assets/dykg4ktvbu3mhmdo.js", "assets/fg33krlcm0qyi6yw.js", "assets/root-ipvq9zhe.css", "assets/k15yxxoybkkir2ou.js", "assets/conversation-small-332fs9rk.css"]))) => i.map(i => d[i]);
var Ie = Object.defineProperty,
    Te = Object.defineProperties;
var Re = Object.getOwnPropertyDescriptors;
var X = Object.getOwnPropertySymbols;
var re = Object.prototype.hasOwnProperty,
    le = Object.prototype.propertyIsEnumerable;
var oe = (t, e, s) => e in t ? Ie(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : t[e] = s,
    z = (t, e) => {
        for (var s in e || (e = {})) re.call(e, s) && oe(t, s, e[s]);
        if (X)
            for (var s of X(e)) le.call(e, s) && oe(t, s, e[s]);
        return t
    },
    Y = (t, e) => Te(t, Re(e));
var ce = (t, e) => {
    var s = {};
    for (var o in t) re.call(t, o) && e.indexOf(o) < 0 && (s[o] = t[o]);
    if (t != null && X)
        for (var o of X(t)) e.indexOf(o) < 0 && le.call(t, o) && (s[o] = t[o]);
    return s
};
import {
    c as k,
    j as a,
    e as J,
    r as F,
    _ as de,
    i as Be,
    M as pe
} from "./fg33krlcm0qyi6yw.js";
import {
    f as ge,
    ep as De,
    S as $e,
    b as M,
    d as E,
    o as ze,
    j3 as Fe,
    eo as he,
    h as Le,
    e$ as ie,
    dz as Ue,
    l as N,
    _ as We,
    hA as He,
    P as L,
    e as Ve,
    H as Ge,
    ad as Ke,
    af as qe,
    cU as Xe,
    oZ as Ye,
    T as Ze,
    r2 as ve,
    fP as ee,
    i as Se,
    aK as U,
    f$ as Qe,
    qt as Je,
    bg as se,
    oO as et,
    ak as tt,
    ao as st,
    az as at,
    aq as it,
    ar as nt,
    bc as xe,
    bd as ye,
    es as _e,
    aj as ot,
    bv as rt,
    ai as lt
} from "./dykg4ktvbu3mhmdo.js";
import {
    mg as je,
    mh as ct,
    mi as ue,
    mj as dt,
    mk as ut,
    e2 as fe,
    ml as be,
    mm as ft,
    mn as we,
    mo as bt,
    ij as mt,
    mp as pt,
    mq as Oe,
    mr as gt,
    ms as ht,
    gx as Ne,
    a6 as vt,
    du as St,
    gN as ae,
    mt as xt,
    a9 as yt,
    mu as _t,
    aa as jt,
    gE as wt,
    mv as Ot,
    cV as Nt,
    gF as kt,
    gC as Pt,
    mw as At,
    mx as Ct,
    Z as Mt,
    P as Z,
    my as Et,
    i_ as It,
    mz as Tt,
    ik as ke,
    mA as Q,
    ad as Rt
} from "./k15yxxoybkkir2ou.js";
import {
    S as Bt
} from "./jlu292yvnhcpthaw.js";
import {
    o as Dt
} from "./ew68kf01y1h7e4uk.js";
const me = ge(() => De($e.HasSeenPulseOnboardingModal, () => !1));

function Pe(t) {
    "use forget";
    const e = k.c(4),
        {
            iconOnly: s
        } = t,
        o = M();
    let d;
    if (e[0] !== o ? (d = () => je(o), e[0] = o, e[1] = d) : d = e[1], !E(d)) return null;
    let c;
    return e[2] !== s ? (c = a.jsx($t, {
        iconOnly: s
    }), e[2] = s, e[3] = c) : c = e[3], c
}

function $t(t) {
    "use forget";
    const e = k.c(28),
        {
            iconOnly: s
        } = t,
        o = J(),
        d = ct(),
        n = M();
    let c;
    e[0] !== n ? (c = () => he(n), e[0] = n, e[1] = c) : c = e[1];
    const r = E(c);
    let l;
    e[2] !== o ? (l = o.formatMessage({
        id: "zEGHd1",
        defaultMessage: "Pulse"
    }), e[2] = o, e[3] = l) : l = e[3];
    const u = l;
    let b;
    e[4] !== o ? (b = o.formatMessage({
        id: "D2jrss",
        defaultMessage: "New"
    }), e[4] = o, e[5] = b) : b = e[5];
    const f = b;
    let g;
    e[6] !== n ? (g = ze(n, "4087025484"), e[6] = n, e[7] = g) : g = e[7];
    const m = g;
    let h;
    e[8] !== n || e[9] !== m ? (h = () => dt(n, {
        useCache: !m
    }), e[8] = n, e[9] = m, e[10] = h) : h = e[10];
    const {
        data: p
    } = E(h), v = p == null ? void 0 : p.onboarding_status, j = m && v === ue.NOT_STARTED;
    let y;
    e[11] !== n ? (y = () => me(n), e[11] = n, e[12] = y) : y = e[12];
    const P = E(y),
        x = m && v === ue.NOT_STARTED && !P && !s;
    let S;
    e[13] !== f || e[14] !== x ? (S = x ? a.jsxs("span", {
        className: "flex items-center gap-1.5 text-[14px] font-medium text-blue-500",
        children: [f, a.jsx(ut, {
            color: "blue"
        })]
    }) : void 0, e[13] = f, e[14] = x, e[15] = S) : S = e[15];
    const _ = S;
    let w;
    e[16] === Symbol.for("react.memo_cache_sentinel") ? (w = Fe("/pulse"), e[16] = w) : w = e[16];
    let O;
    e[17] !== n || e[18] !== r || e[19] !== p || e[20] !== j ? (O = C => {
        j ? (C.preventDefault(), r && C.stopPropagation(), fe(n).logEventWithStatsig("(Web) Onboarding Opened From Sidebar", "chatgpt_web_fyp_onboarding_opened_from_sidebar"), Dt(n, {
            source: be.Sidebar,
            entrypointData: p != null ? p : void 0
        }), me.set(n, !0)) : (p || !j) && (fe(n).logEventWithStatsig("(Web) Feed Opened From Sidebar", "chatgpt_web_fyp_feed_opened_from_sidebar"), ft.set(n, be.Sidebar))
    }, e[17] = n, e[18] = r, e[19] = p, e[20] = j, e[21] = O) : O = e[21];
    let A;
    return e[22] !== s || e[23] !== d || e[24] !== u || e[25] !== _ || e[26] !== O ? (A = a.jsx(a.Fragment, {
        children: a.jsx(we, {
            "data-testid": "sidebar-item-pulse",
            icon: bt,
            trailing: _,
            to: w,
            onClick: O,
            label: u,
            active: d,
            iconOnly: s
        })
    }), e[22] = s, e[23] = d, e[24] = u, e[25] = _, e[26] = O, e[27] = A) : A = e[27], A
}
const zt = ge(() => Le(null)),
    cs = () => {
        "use forget";
        const t = k.c(14),
            e = M();
        let s;
        t[0] !== e ? (s = ie(e) && Ue(), t[0] = e, t[1] = s) : s = t[1];
        const o = s,
            d = F.useRef(null);
        let n, c;
        t[2] === Symbol.for("react.memo_cache_sentinel") ? (n = () => {
            if (d.current) return mt({
                axis: "height",
                target: d.current,
                onChange: Ft
            })
        }, c = [], t[2] = n, t[3] = c) : (n = t[2], c = t[3]), F.useEffect(n, c);
        let i, r, l, u, b;
        t[4] === Symbol.for("react.memo_cache_sentinel") ? (i = a.jsx(Ae, {}), r = a.jsx(Ce, {}), l = a.jsx(pt, {}), u = a.jsx(Pe, {}), b = a.jsx(Oe, {}), t[4] = i, t[5] = r, t[6] = l, t[7] = u, t[8] = b) : (i = t[4], r = t[5], l = t[6], u = t[7], b = t[8]);
        let f;
        t[9] !== o ? (f = o && a.jsx(gt, {}), t[9] = o, t[10] = f) : f = t[10];
        let g;
        t[11] === Symbol.for("react.memo_cache_sentinel") ? (g = a.jsx("div", {
            "aria-hidden": !0,
            className: N("pointer-events-none absolute start-0 end-0", "-bottom-(--sticky-spacer) h-(--sticky-spacer)", "opacity-0 will-change-[opacity] group-data-scrolled-from-top/scrollport:opacity-100", "bg-(--sidebar-mask-bg,var(--bg-elevated-secondary))")
        }), t[11] = g) : g = t[11];
        let m;
        return t[12] !== f ? (m = a.jsxs(ht, {
            first: !0,
            ref: d,
            className: "tall:sticky tall:top-header-height tall:z-20 not-tall:relative bg-(--sidebar-mask-bg,var(--bg-elevated-secondary)) [--sticky-spacer:6px]",
            children: [i, r, l, u, b, f, g]
        }), t[12] = f, t[13] = m) : m = t[13], m
    },
    Ae = t => {
        "use forget";
        const e = k.c(10),
            {
                iconOnly: s
            } = t,
            o = M(),
            d = J(),
            n = Ne();
        let c;
        e[0] !== o || e[1] !== n ? (c = f => {
            L.logEvent("Sidebar Click Gizmo", {
                gizmo_id: "primary"
            }), yt(o, f, {
                location: n != null ? n : "Sidebar gizmo list"
            })
        }, e[0] = o, e[1] = n, e[2] = c) : c = e[2];
        const i = c;
        let r;
        e[3] !== d ? (r = d.formatMessage({
            id: "6Abeg/",
            defaultMessage: "New chat"
        }), e[3] = d, e[4] = r) : r = e[4];
        const l = r,
            u = vt();
        let b;
        return e[5] !== i || e[6] !== s || e[7] !== l || e[8] !== u ? (b = a.jsx(we, {
            "data-testid": "create-new-chat-button",
            to: "/",
            state: u,
            onClick: i,
            icon: jt,
            label: l,
            keyBinding: _t,
            iconOnly: s
        }), e[5] = i, e[6] = s, e[7] = l, e[8] = u, e[9] = b) : b = e[9], b
    },
    Ce = ({
        iconOnly: t
    }) => {
        "use no forget";
        const e = M(),
            s = J(),
            {
                isFannyPackEnabled: o
            } = St(e),
            d = Ne(),
            c = E(() => he(e));
        if (F.useEffect(() => {
                o && (We.addAction("fannypack.web.action_seen"), de(() =>
                    import ("./bo2v113kbgrh2zlp.js").then(r => r.a), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6])))
            }, [o]), !o) return null;
        const i = s.formatMessage({
            id: "bDEsvT",
            defaultMessage: "Search chats"
        });
        return a.jsx(ae, {
            onClick: r => {
                c && (r.preventDefault(), r.stopPropagation()), de(() =>
                    import ("./bo2v113kbgrh2zlp.js").then(l => l.a), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6])).then(l => l.openFannyPackSearch()), L.logEventWithStatsig("chatgpt_web_search_sidebar_item_clicked", "chatgpt_web_search_sidebar_item_clicked", {
                    location: d
                })
            },
            icon: He,
            label: i,
            keyBinding: xt,
            iconOnly: t
        })
    };

function Ft(t) {
    const {
        height: e
    } = t;
    F.startTransition(() => {
        zt.set(Ve(), e)
    })
}

function Me(t) {
    "use forget";
    var te;
    const e = k.c(58);
    let s, o, d, n;
    e[0] !== t ? (te = t, {
        onOpen: d,
        className: s,
        isSidebarOpen: o
    } = te, n = ce(te, ["onOpen", "className", "isSidebarOpen"]), e[0] = t, e[1] = s, e[2] = o, e[3] = d, e[4] = n) : (s = e[1], o = e[2], d = e[3], n = e[4]);
    const c = Be(),
        i = J(),
        r = M(),
        l = Ge();
    let u;
    e[5] !== l ? (u = l == null ? void 0 : l.isSelfServeBusiness(), e[5] = l, e[6] = u) : u = e[6];
    const b = u,
        {
            enableTinybarUpgradeBtn: f
        } = wt(),
        g = Ot();
    let m;
    e[7] !== r ? (m = () => je(r), e[7] = r, e[8] = m) : m = e[8];
    const h = E(m),
        p = !!b,
        v = !o,
        j = g && f && !p;
    let y;
    e[9] !== r || e[10] !== l ? (y = () => {
        l && (L.logEvent("Account: Invite Member Button Clicked", {
            eventSource: "mouse",
            location: "tiny-bar"
        }), qe(r).logEvent("chatgpt_invite_users_to_workspace", 0, {
            action: "OpenAdminInviteModal",
            location: "tiny-bar",
            text: "AddTeammates",
            step: "OpenModal"
        }), Xe(r, At, {
            workspace: l
        }))
    }, e[9] = r, e[10] = l, e[11] = y) : y = e[11];
    const P = y;
    let x;
    e[12] !== s ? (x = N("group/tiny-bar flex h-full w-(--sidebar-rail-width) cursor-e-resize flex-col items-start bg-transparent pb-1.5 motion-safe:transition-colors rtl:cursor-w-resize", s), e[12] = s, e[13] = x) : x = e[13];
    let S;
    e[14] !== d ? (S = ne => {
        ne.target === ne.currentTarget && d()
    }, e[14] = d, e[15] = S) : S = e[15];
    let _;
    e[16] !== i ? (_ = i.formatMessage({
        id: "GpHrv5",
        defaultMessage: "Open sidebar"
    }), e[16] = i, e[17] = _) : _ = e[17];
    let w;
    e[18] !== i ? (w = i.formatMessage({
        id: "IaY18K",
        defaultMessage: "Open sidebar"
    }), e[18] = i, e[19] = w) : w = e[19];
    let O, A;
    e[20] === Symbol.for("react.memo_cache_sentinel") ? (O = a.jsx(Ye, {
        className: "icon-lg -m-1 group-hover/tiny-bar:hidden group-focus-visible:hidden"
    }), A = a.jsx(Ct, {
        className: "icon hidden group-hover/tiny-bar:block group-focus-visible:block"
    }), e[20] = O, e[21] = A) : (O = e[20], A = e[21]);
    let C;
    e[22] !== d || e[23] !== w ? (C = a.jsxs(Mt, {
        as: "button",
        className: "mx-2 cursor-e-resize rtl:cursor-w-resize",
        "aria-label": w,
        "aria-expanded": !1,
        "aria-controls": "stage-slideover-sidebar",
        onClick: d,
        children: [O, A]
    }), e[22] = d, e[23] = w, e[24] = C) : C = e[24];
    let I;
    e[25] !== C || e[26] !== _ ? (I = a.jsx("div", {
        className: "h-header-height flex items-center justify-center",
        children: a.jsx(Ze, {
            label: _,
            side: "right",
            children: C
        })
    }), e[25] = C, e[26] = _, e[27] = I) : I = e[27];
    let W, H;
    e[28] === Symbol.for("react.memo_cache_sentinel") ? (W = a.jsx(Ae, {
        iconOnly: !0
    }), H = a.jsx(Ce, {
        iconOnly: !0
    }), e[28] = W, e[29] = H) : (W = e[28], H = e[29]);
    let T;
    e[30] !== r ? (T = null, e[30] = r, e[31] = T) : T = e[31];
    let R;
    e[32] !== h ? (R = h && a.jsx(Pe, {
        iconOnly: !0
    }), e[32] = h, e[33] = R) : R = e[33];
    let V;
    e[34] === Symbol.for("react.memo_cache_sentinel") ? (V = a.jsx(Oe, {
        iconOnly: !0
    }), e[34] = V) : V = e[34];
    let B;
    e[35] !== T || e[36] !== R ? (B = a.jsxs("div", {
        className: "mt-(--sidebar-section-first-margin-top)",
        children: [W, H, T, R, V]
    }), e[35] = T, e[36] = R, e[37] = B) : B = e[37];
    let G;
    e[38] === Symbol.for("react.memo_cache_sentinel") ? (G = a.jsx("div", {
        className: "pointer-events-none flex-grow"
    }), e[38] = G) : G = e[38];
    let D;
    e[39] !== i || e[40] !== v || e[41] !== c || e[42] !== j ? (D = j && a.jsx(ae, {
        icon: a.jsx(kt, {
            className: "icon-sm"
        }),
        iconOnly: !0,
        className: N("motion-safe:transition-opacity motion-safe:duration-200 motion-safe:ease-out", v ? "opacity-100 motion-safe:delay-[175ms]" : "opacity-0 motion-safe:delay-0"),
        label: i.formatMessage(Ke.upgrade),
        onClick: () => Nt(c, "tiny bar")
    }), e[39] = i, e[40] = v, e[41] = c, e[42] = j, e[43] = D) : D = e[43];
    let $;
    e[44] !== i || e[45] !== P || e[46] !== p || e[47] !== v ? ($ = p && a.jsx(ae, {
        icon: a.jsx(Pt, {
            className: "icon-sm"
        }),
        onClick: P,
        iconOnly: !0,
        className: N("motion-safe:transition-opacity motion-safe:duration-200 motion-safe:ease-out", v ? "opacity-100 motion-safe:delay-[175ms]" : "opacity-0 motion-safe:delay-0"),
        label: i.formatMessage({
            id: "C4qYL7",
            defaultMessage: "Invite team members"
        })
    }), e[44] = i, e[45] = P, e[46] = p, e[47] = v, e[48] = $) : $ = e[48];
    let K;
    e[49] === Symbol.for("react.memo_cache_sentinel") ? (K = a.jsx("div", {
        className: "mb-1",
        children: a.jsx(Bt, {})
    }), e[49] = K) : K = e[49];
    let q;
    return e[50] !== n || e[51] !== I || e[52] !== B || e[53] !== D || e[54] !== $ || e[55] !== x || e[56] !== S ? (q = a.jsxs("div", Y(z({
        id: "stage-sidebar-tiny-bar",
        className: x,
        onClick: S
    }, n), {
        children: [I, B, G, D, $, K]
    })), e[50] = n, e[51] = I, e[52] = B, e[53] = D, e[54] = $, e[55] = x, e[56] = S, e[57] = q) : q = e[57], q
}

function ds() {
    "use forget";
    const t = k.c(12),
        e = M(),
        s = Et(Tt, It, !1, !0),
        o = ee(Wt),
        d = Se(e) && ie(e);
    if (!ve()) return null;
    const c = d ? "hover:bg-token-bg-tertiary text-token-text-secondary focus-visible:ring-token-ring rounded-lg focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:outline-none active:opacity-100" : "hover:text-token-text-primary rounded-md focus:ring-2 focus:ring-white focus:ring-inset active:opacity-50";
    let i;
    t[0] !== c ? (i = N("touch:h-10 touch:w-10 inline-flex h-9 w-9 items-center justify-center rounded-md focus:outline-hidden", c), t[0] = c, t[1] = i) : i = t[1];
    let r;
    t[2] === Symbol.for("react.memo_cache_sentinel") ? (r = a.jsx("span", {
        className: "sr-only",
        children: a.jsx(pe, {
            id: "navigation.openSidebar",
            defaultMessage: "Open sidebar"
        })
    }), t[2] = r) : r = t[2];
    const l = d ? "icon" : "icon-lg mx-2";
    let u;
    t[3] !== l ? (u = N("text-token-text-secondary", l), t[3] = l, t[4] = u) : u = t[4];
    let b;
    t[5] !== s || t[6] !== u ? (b = a.jsx(s, {
        className: u
    }), t[5] = s, t[6] = u, t[7] = b) : b = t[7];
    let f;
    return t[8] !== o || t[9] !== i || t[10] !== b ? (f = a.jsxs("button", {
        type: "button",
        className: i,
        onClick: Lt,
        "data-testid": "open-sidebar-button",
        "aria-expanded": o,
        "aria-controls": "stage-popover-sidebar",
        children: [r, b]
    }), t[8] = o, t[9] = i, t[10] = b, t[11] = f) : f = t[11], f
}

function Lt() {
    F.startTransition(Ut)
}

function Ut() {
    U.setSidebarOpen(!0)
}

function Wt(t) {
    return t.isPopoverSidebarOpen
}
const us = t => {
    "use forget";
    const e = k.c(10),
        {
            children: s,
            rightContent: o
        } = t,
        n = ee(Zt) ? "[box-shadow:var(--sharp-edge-top-shadow)]" : "[box-shadow:var(--sharp-edge-top-shadow-placeholder)]";
    let c;
    e[0] !== n ? (c = N("draggable h-header-height bg-token-bg-primary sticky top-0 z-10 flex items-center justify-between gap-2 border-transparent px-2 md:hidden print:hidden", n), e[0] = n, e[1] = c) : c = e[1];
    let i;
    e[2] !== s ? (i = a.jsx("div", {
        className: "no-draggable flex items-center",
        children: s
    }), e[2] = s, e[3] = i) : i = e[3];
    let r;
    e[4] !== o ? (r = o && a.jsx("div", {
        className: "no-draggable flex items-center justify-center",
        children: o
    }), e[4] = o, e[5] = r) : r = e[5];
    let l;
    return e[6] !== c || e[7] !== i || e[8] !== r ? (l = a.jsxs("div", {
        className: c,
        children: [i, r]
    }), e[6] = c, e[7] = i, e[8] = r, e[9] = l) : l = e[9], l
};

function fs(t) {
    "use forget";
    const e = k.c(6),
        {
            children: s,
            nonCollapsable: o,
            insetBg: d
        } = t;
    Z.markStart("StageNavigationSidebar"), Z.markRendered("StageNavigationSidebar");
    const n = ve(),
        c = ee(Ht);
    let i;
    return e[0] !== s || e[1] !== d || e[2] !== n || e[3] !== c || e[4] !== o ? (i = n ? a.jsx(qt, {
        insetBg: d,
        children: s
    }) : a.jsx(Kt, {
        disableAnimations: c,
        nonCollapsable: o,
        children: s
    }), e[0] = s, e[1] = d, e[2] = n, e[3] = c, e[4] = o, e[5] = i) : i = e[5], i
}

function Ht(t) {
    return t.isSidebarAnimationDisabled
}
const Ee = {
        bounce: .1,
        duration: .35,
        type: "spring"
    },
    Vt = Y(z({}, Ee), {
        duration: .4
    }),
    Gt = {
        type: "spring",
        stiffness: 438,
        damping: 38,
        mass: 1,
        restDelta: .01
    },
    Kt = t => {
        "use forget";
        const e = k.c(25),
            {
                children: s,
                nonCollapsable: o,
                disableAnimations: d
            } = t,
            n = M();
        let c;
        e[0] !== n ? (c = () => {
            xe.count(ye.DEFAULT, "chatgpt_sidebar_show", {
                key: "type",
                value: "slideover"
            }), L.logEvent("Sidebar Show", {
                type: "slideover"
            }), _e(n, "chatgpt_web_sidebar_shown", void 0, {
                type: "slideover"
            })
        }, e[0] = n, e[1] = c) : c = e[1], ke(c), Z.trackNamespace(Z.NS_SIDEBAR);
        const i = Qe(),
            r = Je() || o,
            l = d || i ? Rt : Ee,
            u = r ? "var(--sidebar-width)" : "var(--sidebar-rail-width)",
            b = r ? "var(--sidebar-bg, var(--bg-elevated-secondary))" : "var(--sidebar-bg, var(--bg-primary))";
        let f;
        e[2] !== u || e[3] !== b ? (f = {
            width: u,
            backgroundColor: b
        }, e[2] = u, e[3] = b, e[4] = f) : f = e[4];
        const g = r ? "pointer-events-none opacity-0" : "opacity-100",
            m = r ? "motion-safe:ease-[steps(1,end)]" : "motion-safe:ease-[steps(1,start)]";
        let h;
        e[5] !== g || e[6] !== m ? (h = N("absolute inset-0", g, m, "motion-safe:transition-opacity motion-safe:duration-150"), e[5] = g, e[6] = m, e[7] = h) : h = e[7];
        const p = !!r;
        let v;
        e[8] !== r || e[9] !== h || e[10] !== p ? (v = a.jsx(Q.Provider, {
            value: "tiny_bar",
            children: a.jsx(Me, {
                className: h,
                inert: r,
                isSidebarOpen: p,
                onOpen: Qt
            })
        }), e[8] = r, e[9] = h, e[10] = p, e[11] = v) : v = e[11];
        const j = r ? "opacity-100" : "pointer-events-none opacity-0";
        let y;
        e[12] !== j ? (y = N(j, "motion-safe:transition-opacity motion-safe:duration-150 motion-safe:ease-linear", "h-full w-(--sidebar-width) overflow-x-clip overflow-y-auto text-clip whitespace-nowrap", "bg-(--sidebar-bg,var(--bg-elevated-secondary))"), e[12] = j, e[13] = y) : y = e[13];
        const P = !r;
        let x;
        e[14] !== s || e[15] !== y || e[16] !== P ? (x = a.jsx(Q.Provider, {
            value: "expanded_sidebar",
            children: a.jsx("div", {
                className: y,
                inert: P,
                children: s
            })
        }), e[14] = s, e[15] = y, e[16] = P, e[17] = x) : x = e[17];
        let S;
        e[18] !== x || e[19] !== v ? (S = a.jsxs("div", {
            className: "relative flex h-full flex-col",
            children: [v, x]
        }), e[18] = x, e[19] = v, e[20] = S) : S = e[20];
        let _;
        return e[21] !== S || e[22] !== f || e[23] !== l ? (_ = a.jsx(se.div, {
            className: "border-token-border-light relative z-21 h-full shrink-0 overflow-hidden border-e max-md:hidden print:hidden",
            transition: l,
            initial: !1,
            animate: f,
            id: "stage-slideover-sidebar",
            children: S
        }), e[21] = S, e[22] = f, e[23] = l, e[24] = _) : _ = e[24], _
    },
    qt = t => {
        "use forget";
        const e = k.c(24),
            {
                children: s,
                insetBg: o
            } = t,
            d = M();
        let n;
        e[0] !== d ? (n = () => {
            xe.count(ye.DEFAULT, "chatgpt_sidebar_show", {
                key: "type",
                value: "popover"
            }), L.logEvent("Sidebar Show", {
                type: "popover"
            }), _e(d, "chatgpt_web_sidebar_shown", void 0, {
                type: "popover"
            })
        }, e[0] = d, e[1] = n) : n = e[1], ke(n);
        const c = E(et),
            i = ee(Jt);
        let r;
        e[2] !== d ? (r = Se(d) && ie(d), e[2] = d, e[3] = r) : r = e[3];
        const l = r,
            u = l ? Gt : Vt,
            b = (c || i) && !l;
        let f;
        e[4] !== i || e[5] !== b ? (f = b && a.jsx("div", {
            className: "border-token-border-light relative z-21 h-full w-(--sidebar-rail-width) shrink-0 overflow-hidden border-e max-md:hidden",
            children: a.jsx(Q.Provider, {
                value: "tiny_bar",
                children: a.jsx(Me, {
                    className: N("absolute inset-0", i ? "pointer-events-none opacity-0" : "opacity-100", i ? "motion-safe:ease-[steps(1,end)]" : "motion-safe:ease-[steps(1,start)]", "motion-safe:transition-opacity motion-safe:duration-150"),
                    inert: i,
                    isSidebarOpen: !!i,
                    onOpen: ts
                })
            })
        }), e[4] = i, e[5] = b, e[6] = f) : f = e[6];
        let g;
        e[7] !== u || e[8] !== l || e[9] !== i ? (g = i && a.jsx(tt, {
            asChild: !0,
            children: a.jsx(se.div, z({
                className: "fixed inset-0 z-10 bg-gray-50/50 dark:bg-black/50",
                transition: u,
                initial: {
                    opacity: 0
                },
                animate: {
                    opacity: 1
                }
            }, !l && {
                exit: {
                    opacity: 0,
                    transition: {
                        duration: .12
                    }
                }
            }))
        }, "stage-popover-overlay"), e[7] = u, e[8] = l, e[9] = i, e[10] = g) : g = e[10];
        let m;
        e[11] !== s || e[12] !== u || e[13] !== o || e[14] !== l || e[15] !== i ? (m = i && a.jsx(st, {
            asChild: !0,
            onOpenAutoFocus: v => {
                l || v.preventDefault()
            },
            onClick: ss,
            children: a.jsxs(se.div, Y(z({
                className: N("fixed start-0 top-0 z-50 h-full w-[var(--sidebar-width)] max-w-xs border-e border-gray-200 bg-(--sidebar-moweb-bg,var(--sidebar-surface-primary)) shadow-[0_0_64px_0_rgba(0,0,0,0.07)] [view-transition-name:var(--sidebar-popover)] focus:outline-hidden dark:border-gray-800 print:hidden", "pb-[env(safe-area-inset-bottom,0px)]"),
                transition: u,
                id: "stage-popover-sidebar",
                initial: {
                    translateX: "-100%"
                },
                animate: {
                    translateX: "0"
                }
            }, !l && {
                exit: {
                    translateX: "-100%",
                    transition: {
                        duration: .12
                    }
                }
            }), {
                children: [o, a.jsx(at, {
                    asChild: !0,
                    children: a.jsxs(it, {
                        children: [a.jsx(pe, {
                            id: "navigation.sidebarTitle",
                            defaultMessage: "Sidebar"
                        }), a.jsx(nt, {})]
                    })
                }), a.jsx(Q.Provider, {
                    value: "popover",
                    children: s
                })]
            }))
        }, "stage-popover-content"), e[11] = s, e[12] = u, e[13] = o, e[14] = l, e[15] = i, e[16] = m) : m = e[16];
        let h;
        e[17] !== g || e[18] !== m ? (h = a.jsx(ot, {
            forceMount: !0,
            children: a.jsxs(rt, {
                children: [g, m]
            })
        }), e[17] = g, e[18] = m, e[19] = h) : h = e[19];
        let p;
        return e[20] !== i || e[21] !== f || e[22] !== h ? (p = a.jsxs(lt, {
            open: i,
            onOpenChange: es,
            children: [f, h]
        }), e[20] = i, e[21] = f, e[22] = h, e[23] = p) : p = e[23], p
    };

function Xt(t, e) {
    let s = t;
    for (; s != null;) {
        if (e(s)) return s;
        s = s.parentElement
    }
}

function Yt(t) {
    return t.hasAttribute("data-sidebar-item") || t.role === "menuitem" && !t.hasAttribute("data-has-submenu")
}

function Zt(t) {
    return t.isConversationScrolledFromTop
}

function Qt() {
    return U.setSidebarOpen(!0)
}

function Jt(t) {
    return t.isPopoverSidebarOpen
}

function es(t) {
    U.setPopoverSidebarOpen(t)
}

function ts() {
    return U.setPopoverSidebarOpen(!0)
}

function ss(t) {
    t.target instanceof Element && Xt(t.target, Yt) && U.setPopoverSidebarOpen(!1)
}
export {
    cs as P, ds as S, fs as a, us as b, zt as f
};
//# sourceMappingURL=f78b2oufkmgyeo1t.js.map