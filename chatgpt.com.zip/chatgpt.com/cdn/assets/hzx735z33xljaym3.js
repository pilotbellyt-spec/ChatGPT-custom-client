var Ge = Object.freeze,
    Xe = Object.defineProperty,
    Ut = Object.defineProperties;
var Ht = Object.getOwnPropertyDescriptors;
var We = Object.getOwnPropertySymbols;
var Ft = Object.prototype.hasOwnProperty,
    qt = Object.prototype.propertyIsEnumerable;
var Ie = (t, e) => (e = Symbol[t]) ? e : Symbol.for("Symbol." + t);
var ze = (t, e, n) => e in t ? Xe(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : t[e] = n,
    E = (t, e) => {
        for (var n in e || (e = {})) Ft.call(e, n) && ze(t, n, e[n]);
        if (We)
            for (var n of We(e)) qt.call(e, n) && ze(t, n, e[n]);
        return t
    },
    ee = (t, e) => Ut(t, Ht(e));
var H = (t, e) => Ge(Xe(t, "raw", {
    value: Ge(e || t.slice())
}));
var de = function(t, e) {
        this[0] = t, this[1] = e
    },
    Ve = (t, e, n) => {
        var a = (c, l, u, i) => {
                try {
                    var d = n[c](l),
                        m = (l = d.value) instanceof de,
                        x = d.done;
                    Promise.resolve(m ? l[0] : l).then(f => m ? a(c === "return" ? c : "next", l[1] ? {
                        done: f.done,
                        value: f.value
                    } : f, u, i) : u({
                        value: f,
                        done: x
                    })).catch(f => a("throw", f, u, i))
                } catch (f) {
                    i(f)
                }
            },
            r = c => o[c] = l => new Promise((u, i) => a(c, l, u, i)),
            o = {};
        return n = n.apply(t, e), o[Ie("asyncIterator")] = () => o, r("next"), r("throw"), r("return"), o
    };
var ke = (t, e, n) => (e = t[Ie("asyncIterator")]) ? e.call(t) : (t = t[Ie("iterator")](), e = {}, n = (a, r) => (r = t[a]) && (e[a] = o => new Promise((c, l, u) => (o = r.call(t, o), u = o.done, Promise.resolve(o.value).then(i => c({
    value: i,
    done: u
}), l)))), n("next"), n("return"), e);
import {
    j as s,
    r as p,
    e as ce,
    f as Te,
    M as R,
    aq as Gt,
    c as Wt,
    v as Ae,
    b as De
} from "./fg33krlcm0qyi6yw.js";
import {
    g as zt,
    i as Xt,
    b as Vt
} from "./eo73z75xc7fd61fn.js";
import {
    s as Yt,
    r as Kt,
    t as Zt,
    S as ue
} from "./iwhq2rihp0137gzf.js";
import {
    l as L,
    T as _e,
    a9 as le,
    i9 as Be,
    mS as Qt,
    bg as A,
    bv as be,
    c3 as Oe,
    gd as Le,
    hR as Jt,
    R as ve,
    se as es,
    aU as xt,
    oH as ts,
    kA as ss,
    fD as ns,
    C as ht,
    M as Ye,
    bX as as,
    cS as rs,
    _ as Pe,
    bc as ae,
    bd as re,
    m as os,
    Z as $e,
    S as Ue,
    lu as is,
    gj as ls,
    kq as cs,
    h as ds,
    b as gt,
    hg as us,
    es as yt,
    hr as ms,
    of as fs,
    aV as ps,
    oe as xs,
    kg as hs,
    An as gs,
    gb as ys,
    F as W,
    da as bs,
    xo as vs,
    aP as ws,
    aY as Es,
    g3 as js,
    o as Ns
} from "./dykg4ktvbu3mhmdo.js";
import {
    M as S,
    E as te
} from "./ns51nblw8ziscsgd.js";
import {
    ib as Ss,
    kS as Ts,
    ca as _s,
    ab as Rs,
    ac as Is,
    fx as ks,
    BC as Ms,
    cL as As,
    Bh as U,
    hj as bt,
    hO as Ls,
    hR as Cs,
    kZ as vt,
    qC as Ds,
    qD as Bs,
    uN as Os,
    cx as wt,
    Z as Ke
} from "./k15yxxoybkkir2ou.js";
import {
    L as Ps
} from "./bx8o5u3qhj3ykfih.js";
import {
    T as He
} from "./coi95al0vrqe13ds.js";
import {
    u as $s
} from "./l09h2qppleubii6l.js";
import {
    b as Us,
    i as Hs,
    L as Fs
} from "./ktlrbeajo849nxci.js";
import {
    u as Se,
    f as qs,
    n as Et
} from "./loeoawlgsw5vcwar.js";
const Gs = ({
        onClose: t,
        title: e,
        actions: n,
        showBorder: a = !1
    }) => s.jsxs("div", {
        className: L("bg-token-bg-primary flex items-center justify-between border-b py-2 ps-2 pe-2.5", {
            "border-token-border-light": a,
            "border-transparent": !a
        }),
        children: [s.jsx("div", {
            className: "text-token-text-primary flex items-center gap-2 ps-4 text-sm select-none",
            children: e
        }), s.jsxs("div", {
            className: "flex items-center gap-2",
            children: [n.map(({
                tooltip: r,
                icon: o,
                onClick: c
            }, l) => {
                const u = s.jsx(le, {
                    size: "small",
                    color: "ghost",
                    as: "button",
                    className: "text-token-text-primary aspect-square p-1!",
                    icon: o,
                    onClick: c
                }, l);
                return r ? s.jsx(_e, {
                    label: r,
                    children: u
                }, l) : u
            }), s.jsx(le, {
                size: "small",
                color: "ghost",
                as: "button",
                className: "text-token-text-primary aspect-square p-1!",
                onClick: t,
                icon: Be
            })]
        })]
    }),
    jt = t => Qt([S.ERROR, S.LOG, S.OUTPUT], t.type),
    Nt = t => t.type === S.OUTPUT && St(t.output),
    St = t => typeof t == "string" && t.startsWith("data:image/png;"),
    xe = ({
        as: t = "li",
        contentBefore: e,
        contentAfter: n,
        disableEntryAnimation: a = !1,
        hasHint: r = !1,
        bottomBorder: o = !1,
        isHintOpen: c = !1,
        isSticky: l = !1,
        onClick: u,
        children: i
    }) => {
        const d = !!u,
            m = t === "div" ? A.div : A.li;
        return s.jsxs(m, {
            initial: a ? !1 : {
                opacity: 0
            },
            animate: {
                opacity: 1
            },
            transition: {
                duration: .32
            },
            role: d ? "button" : void 0,
            className: L("bg-token-bg-primary flex items-start justify-between py-1.5 ps-6 pe-4 font-mono text-sm whitespace-pre", o && "border-token-border-xlight border-b", l && "sticky top-0 z-10", d && "cursor-pointer", d && r && "hover:bg-red-500/10", d && !r && "hover:bg-gray-50 dark:hover:bg-gray-700", r && c && "bg-red-500/10"),
            onClick: d ? u : void 0,
            children: [e && s.jsx("div", {
                className: "me-3 flex h-6 w-5 items-start",
                children: e
            }), s.jsx("div", {
                className: "flex min-h-6 min-w-0 flex-1 items-start justify-start gap-2 leading-6",
                children: i
            }), n && s.jsx("div", {
                className: "ms-3 flex min-h-6 items-start leading-6",
                children: n
            })]
        })
    };
var ne = (t => (t.LOADING = "loading", t.READY = "ready", t.RESOLVED = "resolved", t))(ne || {});
const Tt = ({
        hint: t,
        onClickFix: e,
        isOpen: n,
        onOpenChange: a
    }) => {
        var c;
        const r = p.useRef(null),
            o = ce();
        return t ? s.jsx("div", {
            className: "relative flex items-center font-sans",
            onClick: l => l.stopPropagation(),
            children: s.jsxs(Ss, {
                open: n,
                onOpenChange: a,
                children: [s.jsx(Ts, {
                    asChild: !0,
                    ref: r,
                    children: t.status === "resolved" ? s.jsx("div", {
                        className: "flex h-5 w-5 items-center",
                        children: s.jsx(_s, {
                            className: "text-token-text-tertiary",
                            size: 16
                        })
                    }) : s.jsx("button", {
                        className: "h-5 w-5",
                        disabled: t.status === "loading",
                        children: t.status === "loading" ? s.jsx(Yt, {}) : s.jsx(Kt, {
                            position: "static",
                            isError: !0,
                            count: 1,
                            offsetY: 0
                        })
                    })
                }), s.jsx(be, {
                    children: n && s.jsx(Rs, {
                        forceMount: !0,
                        container: (c = r.current) == null ? void 0 : c.ownerDocument.body,
                        children: s.jsx(Is, {
                            side: "top",
                            align: "start",
                            alignOffset: -4,
                            sideOffset: 10,
                            children: s.jsx(Zt, {
                                position: "static",
                                translateY: 0,
                                right: 0,
                                isFocused: !0,
                                onDismiss: () => a == null ? void 0 : a(!1),
                                onAccept: l => {
                                    a == null || a(!1), e == null || e(l)
                                },
                                comment: t,
                                acceptButtonLabel: o.formatMessage({
                                    id: "Dl9vBh",
                                    defaultMessage: "Fix bug"
                                })
                            })
                        })
                    })
                })]
            })
        }) : s.jsx("div", {
            className: "w-5"
        })
    },
    Ws = "module:",
    Ce = ({
        log: t,
        isDisabled: e = !1,
        onClick: n
    }) => s.jsx("div", {
        className: "flex items-center",
        children: "line" in t && t.line != null && s.jsxs("button", {
            onClick: () => t.line != null && (n == null ? void 0 : n(t.line)),
            className: "text-token-text-tertiary select-none enabled:hover:underline",
            disabled: e,
            children: [Ws, t.line]
        })
    }),
    zs = ({
        isPreview: t = !1,
        log: e,
        level: n
    }) => s.jsxs("span", {
        className: L("text-token-text-primary flex min-w-0 flex-wrap gap-1", t ? "shrink truncate" : "whitespace-pre-wrap", n === "warn" && "text-yellow-600"),
        children: [n === "warn" && "[warn]: ", typeof e == "string" ? e : e.map((a, r) => s.jsx(Ps, {
            isPreview: t,
            value: a
        }, r))]
    }),
    _t = ({
        error: t,
        isPreview: e = !1,
        isResolved: n = !1
    }) => {
        const a = t.name + ":";
        return s.jsxs("span", {
            className: L("whitespace-pre-wrap", n ? "text-token-text-primary" : "text-red-500"),
            children: [s.jsx("span", {
                className: "font-semibold",
                children: a
            }), " ", t.message, s.jsx("div", {
                children: t.stack.length > 0 && !e ? t.stack.join("\n") : ""
            })]
        })
    },
    Xs = ({
        output: t,
        isPreview: e = !1
    }) => {
        const n = ce();
        return t == null ? null : St(t) ? s.jsx("img", {
            alt: n.formatMessage(Ys.imgAlt),
            className: L(e && "border-token-border-xlight h-6 rounded-lg border"),
            src: t
        }) : s.jsx("span", {
            className: "flex items-center gap-2",
            children: Oe(t)
        })
    },
    Fe = ({
        log: t,
        isHintResolved: e,
        isPreview: n = !1
    }) => {
        switch (t.type) {
            case S.LOG:
                return s.jsx(zs, E({
                    isPreview: n
                }, t));
            case S.ERROR:
                return s.jsx(_t, E({
                    isPreview: n,
                    isResolved: e
                }, t));
            case S.OUTPUT:
                return s.jsx(Xs, E({
                    isPreview: n
                }, t));
            default:
                return null
        }
    },
    Vs = ({
        log: t,
        isStale: e = !1,
        onClickFix: n,
        onClickLineNumber: a,
        hint: r
    }) => {
        const [o, c] = p.useState(!1);
        if (t.type === S.RUN_COMPLETE) return null;
        const l = (r == null ? void 0 : r.status) === ne.RESOLVED,
            u = t.type === S.ERROR && (r == null ? void 0 : r.status) === ne.READY;
        return s.jsx(xe, {
            hasHint: u,
            isHintOpen: o,
            bottomBorder: !0,
            onClick: r && !l && (() => c(!0)),
            contentBefore: s.jsx(Tt, {
                hint: r,
                isOpen: o,
                onOpenChange: c,
                onClickFix: i => t.type === S.ERROR && r && (n == null ? void 0 : n(i, r.id, t.error))
            }),
            contentAfter: s.jsx(Ce, {
                log: t,
                isDisabled: e,
                onClick: a
            }),
            children: s.jsx(Fe, {
                log: t,
                isHintResolved: l
            })
        })
    },
    Ys = Te({
        imgAlt: {
            id: "L6t7Yb",
            defaultMessage: "Plot"
        },
        ranCode: {
            id: "ffa9Nt",
            defaultMessage: "Ran code"
        },
        askForHelp: {
            id: "wMZco9",
            defaultMessage: "Ask ChatGPT for help"
        },
        askForFix: {
            id: "A9pxgT",
            defaultMessage: "Fix it for me"
        }
    }),
    Ks = ({
        timestamp: t,
        duration: e
    }) => {
        const [, n] = p.useState(0);
        p.useEffect(() => {
            setInterval(() => {
                n(o => o + 1)
            }, 5e3)
        }, []);
        const a = Date.now(),
            r = Math.round((a - t) / 1e3);
        return s.jsx(_e, {
            label: s.jsx(R, {
                id: "bFO21A",
                defaultMessage: "Code ran {count, plural, =0 {instantly} one {in # second} other {in # seconds}}",
                values: {
                    count: Math.floor(e / 1e3)
                }
            }),
            children: s.jsx("span", {
                className: "text-token-text-tertiary",
                children: r >= 60 ? s.jsx(Gt, {
                    value: -r,
                    updateIntervalInSeconds: 60,
                    numeric: "auto"
                }) : s.jsx(R, {
                    id: "bRCEFN",
                    defaultMessage: "Just now"
                })
            })
        })
    },
    Rt = ({
        isComplete: t,
        timestamp: e,
        duration: n
    }) => t && e != null && n != null ? s.jsx(Ks, {
        timestamp: e,
        duration: n
    }) : t && n == null ? s.jsx("span", {
        className: "text-token-text-tertiary",
        children: s.jsx(R, {
            id: "EMebM9",
            defaultMessage: "Stopped"
        })
    }) : s.jsx(He, {
        gap: 2
    }),
    Zs = t => {
        switch (t) {
            case te.INITIALIZING:
                return s.jsx(R, {
                    id: "J183Z0",
                    defaultMessage: "initializing environment"
                });
            case te.INSTALLING_PACKAGES:
                return s.jsx(R, {
                    id: "21sQ8o",
                    defaultMessage: "installing packages"
                });
            case te.RUNNING_CODE:
                return s.jsx(R, {
                    id: "nHITHk",
                    defaultMessage: "running code"
                })
        }
    },
    je = t => {
        "use forget";
        const e = Wt.c(6),
            {
                message: n,
                isComplete: a,
                statusLogs: r
            } = t;
        let o;
        if (e[0] !== a || e[1] !== n || e[2] !== r) {
            const c = Le(r);
            let l;
            e[4] !== n ? (l = s.jsx("span", {
                className: "text-token-text-secondary font-semibold",
                children: s.jsx(R, E({}, n))
            }), e[4] = n, e[5] = l) : l = e[5], o = s.jsxs("span", {
                className: "flex items-center",
                children: [l, !a && c && s.jsxs(A.span, {
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    exit: {
                        opacity: 0
                    },
                    transition: {
                        delay: .3,
                        duration: .1
                    },
                    className: "text-token-text-tertiary ms-2 flex items-baseline",
                    children: [Zs(c.status), s.jsx(He, {
                        gap: 2,
                        size: 2
                    })]
                })]
            }), e[0] = a, e[1] = n, e[2] = r, e[3] = o
        } else o = e[3];
        return o
    },
    Qs = ({
        children: t,
        firstLog: e,
        lastLog: n,
        isHintResolved: a,
        duration: r,
        isComplete: o = !1,
        isLast: c = !1,
        statusLogs: l
    }) => {
        const [u, i] = p.useState(!0), [d, m] = p.useState(!1), x = () => {
            i(!u)
        }, f = p.useCallback(v => {
            if (!v) return;
            const g = new IntersectionObserver(j => {
                m(j[0].intersectionRatio === 0)
            }, {
                threshold: 0
            });
            return g.observe(v), () => {
                g.disconnect()
            }
        }, []);
        return s.jsxs("li", {
            className: "relative flex flex-col",
            children: [s.jsx("div", {
                "aria-hidden": "true",
                className: "pointer-events-none absolute h-[1px] bg-transparent",
                ref: f
            }), s.jsxs(xe, {
                as: "div",
                disableEntryAnimation: !0,
                isSticky: !0,
                bottomBorder: d || !c && !u,
                contentAfter: s.jsx(Rt, {
                    isComplete: o,
                    duration: r,
                    timestamp: e == null ? void 0 : e.timestamp
                }),
                contentBefore: s.jsx("button", {
                    className: "text-token-text-tertiary",
                    onClick: () => x(),
                    children: s.jsx(ks, {
                        className: L("icon transition-transform", u && "rotate-90")
                    })
                }),
                onClick: () => x(),
                children: [s.jsx(je, {
                    isComplete: o,
                    message: Ne.run,
                    statusLogs: l
                }), !u && n && s.jsx(Fe, {
                    isPreview: !0,
                    isHintResolved: a,
                    log: n
                })]
            }), u && t]
        })
    },
    Js = ({
        runMessages: t,
        onClickFix: e,
        onClickLineNumber: n,
        hints: a,
        isLast: r,
        includeContentBefore: o = !1
    }) => {
        var N;
        const [c, l] = p.useState(!1), u = t.filter(y => y.type === S.ENVIRONMENT_STATUS), i = t.filter(jt), d = Le(t), m = (d == null ? void 0 : d.type) === S.RUN_COMPLETE, x = m ? d.duration : null, f = i[0];
        if (m) {
            if (i.length === 0) return s.jsx(xe, {
                isHintOpen: c,
                bottomBorder: !0,
                contentBefore: o,
                contentAfter: s.jsx(Rt, {
                    isComplete: m,
                    duration: x,
                    timestamp: f == null ? void 0 : f.timestamp
                }),
                children: s.jsx(je, {
                    isComplete: m,
                    message: Ne.success,
                    statusLogs: u
                })
            });
            if (i.length === 1 && (f == null ? void 0 : f.type) === S.ERROR) {
                const y = a.get(f.id);
                return s.jsxs(xe, {
                    hasHint: !!y,
                    isHintOpen: c,
                    bottomBorder: !0,
                    contentBefore: (o || !!y) && s.jsx(Tt, {
                        hint: y,
                        isOpen: c,
                        onOpenChange: l,
                        onClickFix: h => e == null ? void 0 : e(h, f.id, f.error)
                    }),
                    contentAfter: s.jsx(Ce, {
                        log: f,
                        onClick: n
                    }),
                    onClick: y && y.status !== ne.RESOLVED && (() => l(!0)),
                    children: [s.jsx(je, {
                        isComplete: m,
                        message: Ne.run,
                        statusLogs: u
                    }), s.jsx(_t, E({
                        isResolved: (y == null ? void 0 : y.status) === ne.RESOLVED
                    }, f))]
                })
            } else if (i.length === 1 && f && !Nt(i[0])) return s.jsxs(xe, {
                bottomBorder: !0,
                contentBefore: o,
                contentAfter: s.jsx(Ce, {
                    log: f,
                    onClick: n
                }),
                children: [s.jsx(je, {
                    isComplete: m,
                    message: Ne.run,
                    statusLogs: u
                }), s.jsx(Fe, {
                    log: f
                })]
            })
        }
        const v = Le(i.filter(y => y.type !== S.RUN_COMPLETE)),
            g = v && a.get(v.id),
            j = (g == null ? void 0 : g.status) === ne.RESOLVED;
        return s.jsx(Qs, {
            statusLogs: u,
            firstLog: (N = t[0]) != null ? N : null,
            lastLog: v != null ? v : null,
            duration: x,
            isComplete: m,
            isHintResolved: j,
            isLast: r,
            children: s.jsx("ol", {
                children: i.map(y => s.jsx(Vs, {
                    log: y,
                    onClickLineNumber: n,
                    onClickFix: e,
                    hint: a.get(y.id)
                }, y.id))
            })
        })
    },
    Ne = Te({
        success: {
            id: "laZI5H",
            defaultMessage: "Run successfully"
        },
        run: {
            id: "o7dgBT",
            defaultMessage: "Run"
        }
    }),
    en = ({
        messages: t,
        scrollRef: e,
        onClose: n,
        onClickLineNumber: a,
        onClickFix: r,
        title: o,
        headerActions: c,
        hints: l,
        paddingBottom: u
    }) => {
        const i = l.size > 0,
            d = p.useMemo(() => Object.entries(Jt(t, "runId")), [t]),
            m = d.some(([, x]) => {
                const f = x.filter(jt);
                return f.length > 1 || f.length === 1 && Nt(f[0])
            });
        return s.jsxs(s.Fragment, {
            children: [s.jsx(Gs, {
                title: o,
                actions: c,
                onClose: n,
                showBorder: t.length > 0
            }), s.jsx("div", {
                ref: e,
                className: "bg-token-bg-primary flex flex-1 flex-col-reverse overflow-auto",
                children: s.jsx("ol", {
                    className: "flex flex-1 flex-col justify-start pb-4",
                    style: {
                        paddingBottom: u
                    },
                    children: s.jsx(be, {
                        children: d.map(([x, f], v) => s.jsx(Js, {
                            runMessages: f,
                            includeContentBefore: m || i,
                            onClickFix: r,
                            onClickLineNumber: a,
                            hints: l,
                            isLast: v === d.length - 1
                        }, x))
                    })
                })
            })]
        })
    },
    tn = ({
        onDrag: t,
        onDragEnd: e,
        onDoubleClick: n
    }) => s.jsx(A.div, {
        drag: "y",
        className: "bg-token-text-quaternary absolute top-[-2px] z-10 h-[4px] w-full cursor-ns-resize opacity-0",
        whileHover: {
            opacity: .5
        },
        whileDrag: {
            opacity: .75,
            height: "8px",
            top: "-4px"
        },
        transition: {
            type: "tween",
            duration: .1
        },
        style: {
            x: 0,
            y: 0,
            transform: "translateY(0px)"
        },
        dragMomentum: !1,
        dragSnapToOrigin: !1,
        dragElastic: !1,
        dragConstraints: {
            left: 0,
            right: 0,
            top: 0,
            bottom: 0
        },
        onDrag: (a, r) => {
            t == null || t(r)
        },
        onDragEnd: e,
        onDoubleClick: n
    }),
    sn = ({
        textdocTitle: t,
        onClickViewConsole: e,
        onClickFix: n,
        onDismiss: a
    }) => s.jsxs(A.div, {
        initial: {
            scale: .95,
            opacity: 0
        },
        exit: {
            scale: .95,
            opacity: 0
        },
        animate: {
            scale: 1,
            opacity: 1
        },
        transition: {
            type: "spring",
            bounce: .12,
            duration: .3
        },
        className: "border-token-border-default bg-token-main-surface-primary absolute end-2 bottom-2 flex w-fit max-w-80 flex-col gap-4 rounded-xl border px-4 py-4 shadow-xl",
        children: [s.jsxs("div", {
            className: "flex items-start",
            children: [s.jsxs("div", {
                className: "flex flex-col gap-1",
                children: [s.jsx("div", {
                    className: "text-sm font-semibold",
                    children: s.jsx(R, {
                        id: "ObCQBq",
                        defaultMessage: "Cannot preview your code"
                    })
                }), s.jsx("div", {
                    className: "text-sm",
                    children: s.jsx(R, {
                        id: "3ZeoP8",
                        defaultMessage: "An error occured while trying to run {name}",
                        values: {
                            name: t
                        }
                    })
                })]
            }), s.jsx(le, {
                size: "small",
                color: "ghost",
                as: "button",
                className: "text-token-text-tertiary -m-1! aspect-square p-0!",
                onClick: a,
                icon: Be
            })]
        }), s.jsxs("div", {
            className: "flex items-center justify-end gap-2",
            children: [s.jsx(le, {
                size: "small",
                color: "secondary",
                onClick: e,
                children: s.jsx(R, {
                    id: "Fch32I",
                    defaultMessage: "View console"
                })
            }), s.jsx(le, {
                size: "small",
                color: "primary",
                onClick: n,
                children: s.jsx(R, {
                    id: "HRfYX0",
                    defaultMessage: "Fix bug"
                })
            })]
        })]
    }),
    It = (t, {
        name: e,
        message: n,
        line: a,
        stack: r
    }) => {
        const o = a != null ? "\n\nError occured in:\n".concat(t.split("\n").slice(a - 1, a + 1).join("\n")) : "";
        return "".concat(e, ": ").concat(n, "\n\nStack:\n").concat(r.join("")).concat(o)
    },
    Me = new Ms({
        capacity: 5
    }),
    nn = async (t, e, n) => {
        var c;
        const a = It(e, n.error),
            r = Oe(Me.get(a));
        if (Me.get(a)) return r;
        const {
            hint: o
        } = await ve.safePost("/textdoc/{textdoc_id}/code/hint", {
            parameters: {
                path: {
                    textdoc_id: t
                }
            },
            requestBody: {
                error: a,
                line: (c = n.error.line) != null ? c : -1
            }
        });
        return Me.set(a, o), o
    },
    an = "You're a professional developer highly skilled in debugging. The user ran the textdoc's code, and an error was thrown.\nPlease think carefully about how to fix the error",
    rn = (t, e, n) => {
        const a = It(t, n);
        return "\n".concat(an, ", and then rewrite the textdoc to fix it.\n\n- NEVER change existing test cases unless they're clearly wrong.\n- ALWAYS add more test cases if there aren't any yet.\n- ALWAYS ask the user what the expected behavior is in the chat if the code is not clear.\n\n").concat(e ? "# Hint\n\n".concat(e, "\n\n") : "", "\n# Error\n\n").concat(a).trim()
    },
    la = ({
        sandboxRef: t,
        textdocContent: e,
        textdocTitle: n,
        textdocId: a,
        isOpen: r,
        isTextdocAttachedPending: o,
        headerActions: c = [],
        highlightLine: l,
        createTextdocTurn: u,
        onOpenChange: i,
        ref: d
    }) => {
        "use no forget";
        const [m, x] = p.useState(!1), [f, v] = p.useState(!1), [g, j] = p.useState([]), [N, y] = p.useState(0), [h, M] = p.useState(null), [T, C] = p.useState(null), [B, O] = p.useState(() => new Map), [se, z] = p.useState(320), X = p.useRef(null), V = ce();
        p.useEffect(() => C(null), [e]);
        const Z = g.filter(w => [S.LOG, S.ERROR, S.OUTPUT].includes(w.type)).length,
            P = p.useEffectEvent(() => {
                y(Z)
            });
        p.useEffect(() => {
            r && P()
        }, [r]);
        const F = p.useMemo(() => {
                for (let w = g.length - 1; w >= 0; w--) {
                    const k = g[w];
                    if (k.runId !== T) return null;
                    if (k.type === S.ERROR) return k
                }
                return null
            }, [g, T]),
            Q = (w, k, Y) => {
                var K;
                const D = B.get(k);
                if (D) {
                    const {
                        id: fe,
                        content: Re
                    } = D;
                    O($t => {
                        const $ = new Map($t);
                        return $.set(fe, {
                            id: fe,
                            content: Re,
                            status: ne.RESOLVED
                        }), $
                    })
                }
                M(k), u({
                    sourceEvent: w,
                    action: ue.EDIT,
                    userMessageType: U.CONSOLE,
                    content: rn(e, (K = D == null ? void 0 : D.content) != null ? K : null, Y)
                })
            },
            I = async (w, k) => {
                if (!o) {
                    O(Y => {
                        const D = new Map(Y);
                        return D.set(w, {
                            id: w,
                            status: ne.LOADING,
                            content: ""
                        }), D
                    });
                    try {
                        const Y = await nn(a, e, k);
                        O(D => {
                            const K = new Map(D);
                            return K.set(w, {
                                id: w,
                                status: ne.READY,
                                content: Y
                            }), K
                        })
                    } catch (Y) {
                        O(D => {
                            const K = new Map(D);
                            return K.delete(w), K
                        })
                    }
                }
            },
            _ = async (w, k) => {
                const Y = zt(w, k),
                    D = Xt(w, k),
                    K = Vt(w);
                if (!Y || !K && !D) return;
                K && (i == null || i(!0)), v(!0), j(J => J.map(oe => ee(E({}, oe), {
                    isStale: !0
                })));
                let fe = !1;
                const Re = xt(t.current).evalAsync({
                    code: k,
                    language: Y
                });
                try {
                    for (var $t = ke(Re), $, we, xa; $ = !(we = await $t.next()).done; $ = !1) {
                        const J = we.value;
                        if (J.type === S.RUN_START && requestAnimationFrame(() => {
                                var oe;
                                (oe = X.current) == null || oe.scrollTo({
                                    top: 0,
                                    behavior: "smooth"
                                })
                            }), J.type === S.ERROR) {
                            if (J.line != null) {
                                const {
                                    line: oe
                                } = J;
                                requestAnimationFrame(() => l(oe))
                            }
                            fe = !0, I(J.id, J)
                        }
                        C(J.runId), j(oe => [...oe, ee(E({}, J), {
                            isStale: !1
                        })])
                    }
                } catch (we) {
                    xa = [we]
                } finally {
                    try {
                        $ && (we = $t.return) && await we.call($t)
                    } finally {
                        if (xa) throw xa[0]
                    }
                }
                fe && (i == null || i(!0)), v(!1)
            };
        p.useImperativeHandle(d, () => ({
            runCode: _,
            stopCode: () => {
                var w;
                return (w = t.current) == null ? void 0 : w.stop()
            }
        }));
        const b = !r && f,
            q = b && F && F.id !== h,
            G = !q && b && Z > N;
        return s.jsxs(be, {
            children: [m && s.jsx("div", {
                className: "pointer-events-auto absolute inset-0 bg-transparent"
            }, "drag-overlay"), G && s.jsx(A.button, {
                initial: {
                    scale: .95,
                    opacity: 0
                },
                exit: {
                    scale: .95,
                    opacity: 0
                },
                animate: {
                    scale: 1,
                    opacity: 1
                },
                transition: {
                    type: "spring",
                    bounce: .12,
                    duration: .3
                },
                className: "bg-token-bg-primary hover:bg-token-bg-secondary absolute end-2 bottom-2 flex items-center gap-2 rounded-full px-3 py-1.5 shadow-lg",
                onClick: () => i == null ? void 0 : i(!0),
                children: s.jsxs("span", {
                    className: "text-token-text-secondary flex items-center gap-1 text-sm",
                    children: [s.jsx(es, {
                        className: "icon-sm"
                    }), s.jsx(R, {
                        id: "etzFTa",
                        defaultMessage: "{numLogs, plural, one {{numLogs} message} other {{numLogs} messages}}",
                        values: {
                            numLogs: Z
                        }
                    })]
                })
            }, "view-console"), q && s.jsx(sn, {
                textdocTitle: n,
                onClickViewConsole: () => i == null ? void 0 : i(!0),
                onDismiss: () => M(F.id),
                onClickFix: w => {
                    Q(w, F.id, F.error)
                }
            }, "error-modal"), r && s.jsxs(A.div, {
                initial: {
                    translateY: "100%",
                    opacity: 0
                },
                animate: {
                    translateY: "0%",
                    opacity: 1
                },
                exit: {
                    translateY: "100%",
                    opacity: 0
                },
                transition: {
                    type: "spring",
                    bounce: 0,
                    duration: .48
                },
                className: "border-token-border-default relative z-10 w-full border-t shadow-[0px_0px_32px_rgba(0,0,0,0.08)]",
                children: [s.jsx(tn, {
                    onDragEnd: () => x(!1),
                    onDrag: ({
                        delta: {
                            y: w
                        }
                    }) => {
                        x(!0), z(k => k - w)
                    }
                }), s.jsx("div", {
                    className: "flex flex-col",
                    style: {
                        height: se
                    },
                    children: s.jsx(en, {
                        scrollRef: X,
                        messages: g,
                        onClose: () => i == null ? void 0 : i(!1),
                        onClickLineNumber: l,
                        onClickFix: Q,
                        title: V.formatMessage({
                            id: "P9VJDk",
                            defaultMessage: "Console"
                        }),
                        headerActions: [...c, {
                            tooltip: V.formatMessage({
                                id: "gAICYK",
                                defaultMessage: "Clear console"
                            }),
                            icon: As,
                            onClick: () => {
                                y(0), j([]), O(new Map)
                            }
                        }],
                        hints: B
                    })
                })]
            }, "console")]
        })
    },
    on = /\s/,
    ln = 30;

function Ze(t, e) {
    const n = t.indexOf(e);
    return n === -1 ? !1 : t.indexOf(e, n + e.length) === -1
}

function ie(t, e) {
    return on.test(t[e])
}

function Qe(t, e, n = !1) {
    if (e === 0 || n && ie(t, e - 1)) return e;
    for (; e > 0 && ie(t, e - 1);) e--;
    for (; e > 0 && !ie(t, e - 1);) e--;
    return ie(t, e) && e++, e
}

function Je(t, e, n = !1) {
    if (e === t.length || n && ie(t, e)) return e;
    for (; e < t.length && ie(t, e);) e++;
    for (; e < t.length && !ie(t, e);) e++;
    return ie(t, e - 1) && e--, e
}

function cn(t, e, n = !0, a = ln) {
    if (t.start < 0 || t.end > e.length || t.start > t.end) throw new Error("Invalid commentSourceRange provided.");
    const r = e.substring(t.start, t.end);
    let o = t.start,
        c = t.end;
    n && (o = Qe(e, o, !0), c = Je(e, c, !0));
    let l = e.substring(o, t.start),
        u = e.substring(t.end, c),
        i = "".concat(l).concat(r).concat(u);
    if (Ze(e, i) && (a == null || i.length >= a)) return {
        before: l,
        after: u,
        allSurrounding: i
    };
    let d = o,
        m = c,
        x = !0;
    for (; x && (a == null || i.length < a);) {
        let f = !1;
        const v = d > 0 ? Qe(e, d) : d;
        v < d && (d = v, f = !0);
        const g = m < e.length ? Je(e, m) : m;
        if (g > m && (m = g, f = !0), f) {
            const j = e.substring(d, t.start),
                N = e.substring(t.end, m),
                y = "".concat(j).concat(r).concat(N);
            if (Ze(e, y) && (a == null || y.length >= a)) return {
                before: j,
                after: N,
                allSurrounding: y
            };
            l = j, u = N, i = y
        } else x = !1
    }
    return {
        before: l,
        after: u,
        allSurrounding: i
    }
}
const he = "# Context",
    ge = "# Instructions";

function ye(t, e, n) {
    if (e == null || n == null) return 'The user is referring to the entire text of "'.concat(t, '".');
    const a = '\n## Selected Text\nThe user has selected this text in "'.concat(t, '" in particular:\n').concat(e, "\n").trim();
    return n.allSurrounding === e ? a : "\n".concat(a, "\n\n## Surrounding Context\nHere is the surrounding context:\n").concat(n.allSurrounding, "\n").trim()
}

function kt(t, e) {
    return t == null || e == null ? "entire document" : t === e.allSurrounding ? "selected text" : "surrounding context"
}

function Mt(t) {
    return "For the update pattern, create a regex which exactly matches the ".concat(t, ". Edit just this string in order to fullfill the user's request. NEVER rewrite the entire document. Instead, ALWAYS edit ONLY the ").concat(t, ". The only exception to this rule is if the ").concat(t, ' includes markdown lists or tables. In that case, fully rewrite the document using ".*" as the regex update pattern.').trim()
}

function dn(t, e, n, a) {
    if (!bt(e) && n && a) {
        const r = kt(n, a);
        return "\n".concat(he, "\nThe user requests that you directly edit the document.\n\n").concat(ye(t, n, a), "\n\n").concat(ge, "\nUse the update_textdoc tool to make this edit. ").concat(Mt(r)).trim()
    }
    return "\n".concat(he, "\nThe user requests that you directly edit the document.\n\n").concat(ye(t, n, a), "\n\n").concat(ge, '\nUse the update_textdoc tool to make this edit. You MUST fully rewrite the entire document by using ".*" as the update regex pattern.').trim()
}

function un(t, e, n) {
    return "\n".concat(he, "\nThe user requests that you add comments about some text.\n\n").concat(ye(t, e, n), "\n\n").concat(ge, "\nDo not respond to the user's question directly, just leave comments.").trim()
}

function mn(t, e) {
    return bt(t) ? e === "entire document" ? " If you choose to update the ".concat(e, ", you MUST fully rewrite the ").concat(e, ' by using ".*" as the update regex pattern.') : " If you choose to update the ".concat(e, ', you MUST fully rewrite the entire document by using ".*" as the update regex pattern. When you do so, ONLY modify the ').concat(e, " and rewrite other sections exactly as is, except for parts that must change based on this update") : e === "entire document" ? "" : " If you choose to update the ".concat(e, ", follow these instructions: ").concat(Mt(e))
}

function fn(t, e, n, a) {
    const r = kt(n, a),
        o = mn(e, r);
    return "\n".concat(he, "\n").concat(ye(t, n, a), "\n\n").concat(ge, "\nThe user would like you perform one of the following actions:\n- Update the ").concat(r, " via the `update_textdoc` tool.").concat(o, "\n- Explain the selected text via chat, or answer a general question about the selected text (no tool call required).\n- Comment on the ").concat(r, " with feedback via the `comment_textdoc` tool. This should only be used if the user very explicitly asks for feedback, critique, or comments.\n\nBased on the user's request, choose the appropriate action.\n").trim()
}

function pn(t, e, n) {
    return "\n".concat(he, "\n").concat(ye(t, e, n), "\n\n").concat(ge, "\nThe user would like you to create a new textdoc.\n").trim()
}

function xn(t, e, n, a = null, r = null) {
    switch (n) {
        case ue.ASK:
            return fn(t, e, a, r);
        case ue.CREATE_TEXTDOC:
            return pn(t, a, r);
        case ue.EDIT:
            return dn(t, e, a, r);
        case ue.COMMENT:
            return un(t, a, r)
    }
}

function hn(t) {
    switch (t) {
        case U.ACCELERATOR:
        case U.CONSOLE:
        case U.ACCEPT_COMMENT:
        case U.HIVE_SPEAKER_EDIT:
            return !0;
        case U.ASK_CHATGPT:
        case U.FULL_SCREEN_SUBMIT:
            return !1
    }
}

function gn(t, e) {
    switch (e) {
        case U.ASK_CHATGPT:
        case U.ACCEPT_COMMENT:
        case U.FULL_SCREEN_SUBMIT:
            return t.formatMessage(bn.askChatGPT);
        case U.ACCELERATOR:
        case U.CONSOLE:
        case U.HIVE_SPEAKER_EDIT:
            return
    }
}
const yn = (t, e) => {
        const n = ce(),
            a = Ls(t),
            r = Cs(t),
            o = ts();
        return p.useCallback(async ({
            content: c,
            sourceRange: l,
            action: u,
            userMessageType: i,
            acceleratorMetadata: d,
            selectionMetadata: m,
            sourceEvent: x
        }) => {
            if ((e == null ? void 0 : e.versionInt) == null || o) return;
            const {
                textdocId: f,
                type: v,
                versionInt: g,
                content: j
            } = e;
            let N, y = null;
            l && l.start !== l.end && (N = j.slice(l.start, l.end), y = cn(l, j));
            const h = xn(f, v, u, N, y),
                T = ss(h, {
                    exclude_after_next_user_message: !0
                });
            r({
                sourceEvent: x,
                promptMessage: ns(c, {
                    canvas: {
                        textdoc_id: f,
                        textdoc_type: v,
                        version: g,
                        textdoc_content_length: j.length,
                        user_message_type: i,
                        accelerator_metadata: d,
                        selection_metadata: m
                    },
                    is_visually_hidden_from_conversation: hn(i),
                    targeted_reply: N,
                    targeted_reply_label: gn(n, i),
                    open_in_canvas_view: {
                        type: "canvas_textdoc",
                        id: f
                    }
                }),
                completionMetadata: a ? {
                    conversationMode: a
                } : void 0,
                appendMessages: [T]
            })
        }, [e, o, r, a, n])
    },
    bn = Te({
        askChatGPT: {
            id: "h5ANdM",
            defaultMessage: "Asked ChatGPT"
        }
    }),
    At = ({
        size: t = 60,
        thickness: e = 1 / 16,
        checkpoints: n,
        activeCheckpointId: a,
        isComplete: r = !1,
        onTransitionComplete: o,
        color: c
    }) => {
        const [l, u] = p.useState(0), i = n.findIndex(f => f.id === a), d = p.useRef(null), m = n[i];
        p.useEffect(() => {
            if (!m || r) return;
            const f = n.length,
                v = i * 100 / f,
                g = (i + 1) * 100 / f;
            u(v);
            let j = null,
                N = null;
            const y = 5 / m.estimatedTime,
                h = M => {
                    N == null && (N = M);
                    const T = M - N;
                    if (T !== 0) {
                        const C = g - v,
                            B = v + C * (1 - Math.exp(-y * T));
                        u(Math.min(B, g - 1e-4))
                    }
                    j = window.setTimeout(() => {
                        d.current = requestAnimationFrame(h)
                    }, 16)
                };
            return d.current = requestAnimationFrame(h), () => {
                j != null && window.clearTimeout(j), d.current != null && cancelAnimationFrame(d.current)
            }
        }, [i, r]);
        const x = () => {
            r && (o == null || o())
        };
        return s.jsx(vt, {
            sizeOverride: t,
            className: L(c == null && "text-primary", c === "dark" && "text-back", c === "light" && "text-white"),
            thickness: e,
            backgroundStrokeClassName: L(c == null && "stroke-[rgba(0,0,0,0.1)] dark:stroke-[rgba(0,0,0,0.32)]", c === "dark" && "stroke-[rgba(0,0,0,0.32)]", c === "light" && "stroke-[rgba(0,0,0,0.1)] "),
            percentage: r ? 100 : l,
            onTransitionEnd: x,
            transitionDuration: "50ms",
            transitionTimingFunction: "cubic-bezier(0.55, 0, 1, 1)"
        })
    },
    vn = "https://persistent.oaistatic.com/canvas/loop-swirl.mp4",
    wn = "https://persistent.oaistatic.com/canvas/loop-swirl-poster.jpg",
    pe = 90,
    En = ({
        title: t,
        checkpoints: e,
        activeCheckpointId: n,
        isComplete: a,
        onTransitionComplete: r
    }) => {
        const [o, c] = p.useState(!1), l = e.findIndex(d => d.id === n), u = e[l], i = () => {
            r == null || r(), c(!0)
        };
        return s.jsx(A.div, {
            className: "relative flex h-full w-full items-center justify-center",
            transition: {
                type: "spring",
                bounce: 0
            },
            children: s.jsxs(A.div, {
                className: "flex -translate-y-12 flex-col items-center gap-3",
                style: {
                    minWidth: pe,
                    height: pe
                },
                initial: {
                    opacity: 0
                },
                animate: {
                    opacity: 1
                },
                transition: {
                    type: "spring",
                    duration: .5,
                    bounce: 0
                },
                children: [s.jsxs(A.div, {
                    className: "bg-token-main-surface-primary absolute overflow-hidden rounded-3xl shadow-2xl",
                    initial: !1,
                    animate: {
                        width: pe,
                        height: pe,
                        opacity: o ? 0 : 1
                    },
                    transition: {
                        type: "spring",
                        duration: .56,
                        bounce: 0
                    },
                    children: [s.jsx("video", {
                        muted: !0,
                        loop: !0,
                        autoPlay: !0,
                        playsInline: !0,
                        src: vn,
                        poster: wn,
                        className: L("absolute inset-0 z-0 h-full w-full object-cover transition-opacity duration-200")
                    }), s.jsx("div", {
                        className: L("relative z-10 flex h-full w-full items-center justify-center", o ? "opacity-0" : "opacity-100"),
                        children: s.jsx(At, {
                            color: "light",
                            checkpoints: e,
                            activeCheckpointId: n,
                            isComplete: a,
                            onTransitionComplete: i,
                            thickness: 1 / 12
                        })
                    })]
                }), s.jsxs(A.div, {
                    className: L("flex flex-col items-center transition-opacity duration-200", a ? "opacity-0" : "opacity-100"),
                    style: {
                        translateY: pe + 20
                    },
                    children: [s.jsx("span", {
                        className: "text-token-text-primary font-semibold",
                        children: t
                    }), u && s.jsx(A.span, {
                        className: "text-token-text-secondary flex items-baseline",
                        children: s.jsx("span", {
                            className: "loading-shimmer",
                            children: u.label
                        })
                    })]
                })]
            })
        })
    },
    Lt = ({
        origin: t,
        url: e
    }) => s.jsxs("div", {
        "aria-label": e,
        className: "w-full min-w-0 pe-4 text-start whitespace-nowrap",
        children: [s.jsx("span", {
            "aria-hidden": !0,
            className: "text-token-text-primary",
            children: t
        }), s.jsx("span", {
            "aria-hidden": !0,
            className: "text-token-text-tertiary",
            children: e.replace(t, "")
        })]
    }),
    jn = ({
        request: t,
        isDenied: e = !1,
        onClick: n
    }) => {
        const [{
            width: a
        }, r] = $s();
        return s.jsxs("button", {
            ref: r,
            className: "group relative z-0 my-1 flex w-full items-center",
            onClick: n,
            children: [s.jsx("div", {
                className: "sticky start-0 z-[-1] w-0",
                children: s.jsx("div", {
                    className: "absolute top-0 hidden h-8 -translate-y-1/2 bg-gray-100 group-hover:block",
                    style: {
                        width: a
                    }
                })
            }), s.jsx("div", {
                className: "bg-token-main-surface-primary text-token-text-secondary sticky start-0 z-10 flex h-8 shrink-0 items-center px-2 group-hover:bg-gray-100",
                children: e ? s.jsx(Os, {
                    className: "icon text-red-500"
                }) : s.jsx(rs, {
                    className: "icon text-green-500"
                })
            }), s.jsx(Lt, E({}, t))]
        })
    },
    Nn = ({
        title: t,
        requests: e,
        onConfirm: n
    }) => {
        const a = ce(),
            [r, o] = p.useState(() => new Set),
            c = () => {
                for (const {
                        requestId: d,
                        approve: m,
                        deny: x
                    } of e) r.has(d) ? x() : m();
                n == null || n()
            },
            l = () => {
                for (const d of e) d.deny()
            },
            u = d => {
                o(m => {
                    const x = new Set(m);
                    return x.has(d) ? x.delete(d) : x.add(d), x
                })
            },
            i = e.length - r.size;
        return s.jsx(ht, {
            testId: "modal-confirm-fetch-request",
            isOpen: !0,
            shouldIgnoreClickOutside: !0,
            onClose: c,
            type: "success",
            title: s.jsxs("div", {
                className: "flex justify-between",
                children: [s.jsx("span", {
                    className: "text-xl",
                    children: s.jsx(R, {
                        id: "VmMpF1",
                        defaultMessage: "Allow network access?"
                    })
                }), s.jsx(_e, {
                    side: "top",
                    contentClassName: "max-w-2xs!",
                    label: s.jsx(R, {
                        id: "WT7tgj",
                        defaultMessage: "Learn more about network requests in canvas"
                    }),
                    children: s.jsx(le, {
                        icon: as,
                        openNewTab: !0,
                        onClick: () => Ds.logButtonClick(Bs.LEARN_MODE_ABOUT_NETWORK_REQUESTS),
                        as: "a",
                        color: "ghost",
                        size: "small",
                        className: "text-token-text-secondary aspect-square p-1!",
                        to: "https://help.openai.com/en/articles/9930697-what-is-the-canvas-feature-in-chatgpt-and-how-do-i-use-it#h_cd52fdbc16"
                    })
                })]
            }),
            description: s.jsxs("div", {
                className: "mt-3 flex flex-col gap-3",
                children: [s.jsx("span", {
                    className: "text-token-text-primary block",
                    children: s.jsx(R, {
                        id: "qk11AX",
                        defaultMessage: "{title} is trying to connect to the network. If you don’t recognize {numRequests, plural, one {this request} other {any of these requests}}, don’t allow this app access to the network.",
                        values: {
                            title: '"'.concat(t, '"'),
                            numRequests: e.length
                        }
                    })
                }), s.jsx("div", {
                    className: "flex max-w-full flex-col",
                    children: e.length > 1 ? s.jsx("ul", {
                        className: "border-token-border-default relative flex max-h-48 flex-col overflow-x-auto overflow-y-auto rounded-lg border",
                        children: e.map(d => {
                            const {
                                requestId: m
                            } = d;
                            return s.jsx("li", {
                                children: s.jsx(jn, {
                                    request: d,
                                    isDenied: r.has(m),
                                    onClick: () => u(m)
                                })
                            }, m)
                        })
                    }) : s.jsx("div", {
                        className: "no-scrollbar bg-token-main-surface-secondary overflow-x-auto rounded-lg p-2",
                        children: s.jsx(Lt, E({}, e[0]))
                    })
                })]
            }),
            primaryButton: s.jsx(Ye.Button, {
                disabled: i === 0,
                title: e.length > 1 ? a.formatMessage({
                    id: "xpKkWv",
                    defaultMessage: "Allow selected ({count})"
                }, {
                    count: i
                }) : a.formatMessage({
                    id: "ZeMrpd",
                    defaultMessage: "Allow"
                }),
                color: "primary",
                onClick: c
            }),
            secondaryButton: s.jsx(Ye.Button, {
                title: a.formatMessage({
                    id: "TjJzqR",
                    defaultMessage: "{count, plural, one {Deny} other {Deny all}}"
                }, {
                    count: e.length
                }),
                color: "secondary",
                onClick: l
            })
        })
    },
    Sn = t => {
        switch (t.type) {
            case "hist":
                return ae.hist(re.WEB_SANDBOX, t.label, t.tags, t.value);
            case "count":
                return ae.count(re.WEB_SANDBOX, t.label, t.tags, t.count);
            case "error":
                return Pe.addError(t.error)
        }
    },
    Tn = ({
        checkpoints: t,
        activeCheckpointId: e,
        isIndeterminate: n = !1,
        isComplete: a
    }) => {
        const [r, o] = p.useState(a);
        return p.useEffect(() => {
            o(a)
        }, [e]), s.jsx(be, {
            children: (e != null && !r || n) && s.jsxs(A.div, {
                initial: {
                    opacity: 0
                },
                exit: {
                    opacity: 0
                },
                animate: {
                    opacity: 1
                },
                className: "bg-token-bg-primary absolute end-2 bottom-2 flex items-center gap-2 rounded-full px-3 py-1.5 shadow-lg",
                children: [n ? s.jsx(vt, {
                    percentage: 30,
                    thickness: 1 / 12,
                    className: "text-primary animate-spin",
                    backgroundStrokeClassName: "dark:stroke-[rgba(255,255,255,0.4)] stroke-[rgba(0,0,0,0.1)]",
                    sizeOverride: 12
                }) : e && s.jsx(At, {
                    size: 12,
                    thickness: 1 / 12,
                    checkpoints: t,
                    activeCheckpointId: e,
                    isComplete: a,
                    onTransitionComplete: () => o(!0)
                }), s.jsxs("span", {
                    className: "text-token-text-secondary flex items-baseline text-sm",
                    children: [s.jsx(R, {
                        id: "zfcWbe",
                        defaultMessage: "Updating"
                    }), s.jsx(He, {
                        gap: 1.5,
                        padding: 2,
                        size: 2
                    })]
                })]
            })
        })
    },
    qe = () => is($e.getItem(Ue.CODE_EXECUTION_DOMAIN_ALLOW_LIST), e => ls(e, {
        origin: Oe,
        expiresAt: cs
    }), []).filter(({
        expiresAt: e
    }) => e >= Date.now()),
    _n = () => {
        $e.removeItem(Ue.CODE_EXECUTION_DOMAIN_ALLOW_LIST)
    },
    Rn = (t, e) => {
        const {
            origin: n
        } = new URL(t);
        let a = [...Us];
        const r = qe().map(({
            origin: o
        }) => o);
        return e && (a = a.concat(r)), a.includes(n)
    },
    In = ({
        networkAccessDeniedMessage: t,
        disableNetworkRequests: e
    }) => {
        const n = os(),
            a = ce(),
            [r, o] = p.useState([]);
        return {
            onViolation: p.useCallback(l => {
                const {
                    blockedURI: u
                } = l;
                try {
                    if (e) return n.danger(t != null ? t : a.formatMessage({
                        id: "Lp7cKY",
                        defaultMessage: "Network access is disabled."
                    }), {
                        loggingTitle: "Network access is disabled.",
                        toastId: "network_access_denied"
                    });
                    ae.count(re.WEB_SANDBOX, "network_access_requested");
                    const {
                        origin: i
                    } = new URL(u), d = x => {
                        ae.count(re.WEB_SANDBOX, "network_access_request.".concat(x ? "allow" : "deny")), o(f => f.filter(v => !Rn(v.url, !e) && v.url !== u))
                    }, m = () => {
                        $e.setItem(Ue.CODE_EXECUTION_DOMAIN_ALLOW_LIST, [...qe(), {
                            origin: i,
                            expiresAt: Date.now() + 2160 * 60 * 60 * 1e3
                        }]), d(!0)
                    };
                    o(x => [...x, {
                        requestId: Ae(),
                        url: u,
                        origin: i,
                        approve: m,
                        deny: () => d(!1)
                    }])
                } catch (i) {
                    Pe.addError(i)
                }
            }, [e, n, t, a]),
            pendingFetchRequests: r
        }
    },
    kn = () => "?" + [""].filter(Boolean).join("&"),
    et = [{
        id: te.INITIALIZING,
        label: "Initializing environment",
        estimatedTime: 1e3
    }, {
        id: te.INSTALLING_PACKAGES,
        label: "Installing packages",
        estimatedTime: 2e3
    }, {
        id: te.RUNNING_CODE,
        label: "Ready",
        estimatedTime: 1
    }],
    Mn = () => ms() ? "ios" : fs() ? "windows" : ps() ? "android" : xs() ? "safari" : hs() || gs() ? "chrome" : "unknown",
    An = (t, e) => {
        ae.count(re.WEB_SANDBOX, "".concat(e, ".eval")), yt(t, "chatgpt_web_sandbox_code_run", "".concat(e))
    },
    Ln = (t, e) => {
        var n, a;
        yt(t, "chatgpt_web_sandbox_environment_error", "".concat(e.error.name, ": ").concat(e.error.message)), Pe.addError("Code execution environment error", ee(E({}, e.error), {
            errorMessage: "".concat(e.error.name, ": ").concat(e.error.message)
        })), e.error.name === "ServiceWorker" && ae.count(re.WEB_SANDBOX, "service_worker_connection_failure", [{
            key: "agent",
            value: Mn()
        }, {
            key: "is_share",
            value: String(e.isShare)
        }]), ((n = e.activeRun) == null ? void 0 : n.runId) != null && e.activeRun.runId === ((a = e.activeRun) == null ? void 0 : a.runId) && ae.count(re.WEB_SANDBOX, "".concat(e.activeRun.language, ".environment_error"))
    },
    ca = ({
        ref: t,
        id: e,
        title: n,
        visuallyHidden: a,
        disablePermissions: r,
        isCodeUpdating: o,
        onCodeRunComplete: c,
        disableNetworkRequests: l = !1,
        networkAccessDeniedMessage: u,
        unsafeAllowAllNetworkRequests: i,
        enableTransition: d,
        onChangeBackgroundColor: m,
        onRetryCodeRun: x
    }) => {
        const [f, v] = p.useState(0), [g] = p.useState(() => ds(null)), j = p.useRef(null), N = p.useRef(null), y = p.useRef(!1), [h, M] = p.useState(null), [T, C] = p.useState(!1), {
            onViolation: B,
            pendingFetchRequests: O
        } = In({
            disableNetworkRequests: l,
            networkAccessDeniedMessage: u
        }), se = p.useRef(B);
        se.current = B, p.useEffect(() => {
            const _ = N.current;
            if (_) return y.current = !0, Hs(_, {
                sendInstrument: Sn,
                notifyEnvironmentError: b => {
                    Ln(V, {
                        error: b,
                        isShare: !1,
                        activeRun: j.current
                    }), _n(), v(q => q + 1), X()
                },
                notifyBackgroundColor: m,
                notifySecurityPolicyViolation: b => {
                    se.current(b)
                }
            }, ["runUserCode"]).then(b => {
                g.set(b)
            }), () => {
                g.set(null), y.current = !1
            }
        }, [f]);
        const z = async () => (await ys(() => g() != null), xt(g())),
            X = () => {
                j.current = null, M(null), C(!1), c == null || c()
            },
            V = gt(),
            Z = function(q) {
                return Ve(this, arguments, function*({
                    code: _,
                    language: b
                }) {
                    var D;
                    M(te.INITIALIZING), An(V, b);
                    const G = yield new de(z()), w = Ae();
                    j.current = {
                        runId: w,
                        language: b
                    };
                    const k = qe().map(({
                            origin: $
                        }) => $),
                        Y = i ? null : l ? {
                            resourceDomains: [],
                            connectDomains: [],
                            isTrusted: !1
                        } : {
                            connectDomains: k,
                            resourceDomains: k,
                            isTrusted: !1
                        };
                    try {
                        for (var K = ke(yield new de(G.runUserCode({
                                code: _,
                                id: e,
                                language: b,
                                csp: Y
                            }))), fe, Re, $t; fe = !(Re = yield new de(K.next())).done; fe = !1) {
                            const $ = Re.value;
                            const we = {
                                timestamp: Date.now(),
                                id: Ae(),
                                runId: w
                            };
                            switch ($.type) {
                                case S.ERROR:
                                    ae.count(re.WEB_SANDBOX, "".concat(b, ".error")), yield E(E({}, $), we);
                                    break;
                                case S.ENVIRONMENT_STATUS:
                                    M($.status), d || C($.status === te.RUNNING_CODE), yield E(E({}, $), we);
                                    break;
                                case S.RUN_COMPLETE:
                                    $.type === S.RUN_COMPLETE && $.wasFatalError && ae.count(re.WEB_SANDBOX, "".concat(b, ".fatal_runtime_error")), yield E(E({}, $), we), ((D = j.current) == null ? void 0 : D.runId) === w && X();
                                    break;
                                case S.LOG:
                                    yield E(E({}, $), we);
                                    break;
                                default:
                                    continue
                            }
                        }
                    } catch (Re) {
                        $t = [Re]
                    } finally {
                        try {
                            fe && (Re = K.return) && (yield new de(Re.call(K)))
                        } finally {
                            if ($t) throw $t[0]
                        }
                    }
                })
            },
            P = async (_, b) => {
                (await z()).prepareEnvironment({
                    code: _,
                    language: b,
                    id: e
                })
            },
            F = async () => {
                (await z()).stop()
            };
        p.useImperativeHandle(t, () => ({
            stop: F,
            evalAsync: Z,
            prepareEnvironment: P
        }));
        const Q = T && d ? {
                type: "spring",
                bounce: 0,
                delay: .12
            } : {
                type: "spring",
                bounce: 0
            },
            I = r ? "" : "midi";
        return s.jsxs(us, {
            children: [s.jsxs("div", {
                className: L("relative flex", a ? "fixed h-0 w-0" : "h-full w-full"),
                children: [!a && h != null && d && s.jsx(En, {
                    isComplete: h === te.RUNNING_CODE,
                    onTransitionComplete: () => C(!0),
                    activeCheckpointId: h,
                    title: n,
                    checkpoints: et
                }), s.jsx(A.div, {
                    className: L("bg-token-main-surface-primary absolute inset-0 m-auto origin-center overflow-hidden", T ? "pointer-events-auto" : "pointer-events-none"),
                    animate: E({
                        opacity: T ? 1 : 0
                    }, T ? {
                        scale: 1
                    } : {
                        scale: .95
                    }),
                    transition: Q,
                    children: s.jsx(A.iframe, {
                        title: n,
                        className: "h-full w-full overflow-hidden",
                        transition: Q,
                        "aria-hidden": a ? "true" : void 0,
                        allow: I,
                        src: "".concat(Fs).concat(kn()),
                        sandbox: "allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox allow-forms",
                        ref: N,
                        tabIndex: -1
                    }, "sandbox-".concat(f))
                }), T && s.jsx(Tn, {
                    isIndeterminate: o,
                    isComplete: h === te.RUNNING_CODE,
                    activeCheckpointId: h,
                    checkpoints: et
                })]
            }), O.length > 0 && s.jsx(Nn, {
                title: n,
                requests: O,
                onConfirm: () => {
                    v(_ => _ + 1), M(null), C(!1), setTimeout(() => {
                        x == null || x()
                    })
                }
            })]
        })
    },
    Cn = (t, e, n = 1) => {
        vs(t.scrollTop, e, {
            duration: n,
            ease: "easeInOut",
            onUpdate: a => {
                t.scrollTop = a
            }
        })
    };
var nt;
const Ct = W.div(nt || (nt = H(["flex w-full grow flex-col gap-1 rounded-xl p-2 pe-5 text-sm"])));
var at;
const Dn = W.input(at || (at = H(["ms-[-2px] w-auto rounded-none border-none bg-[#E5F3FF] p-0 px-0.5 text-sm font-semibold outline-none focus:outline-none"])));
var rt;
const Bn = W(A.span)(rt || (rt = H(["start border-token-text-tertiary absolute -bottom-0.5 w-full origin-start border-b border-solid"])));
var ot;
const On = W(A.span)(ot || (ot = H(["start border-token-text-tertiary absolute -bottom-0.5 w-full border-b border-dashed"])));
var it;
const Ee = W.div(it || (it = H(["w-full loading-results-shimmer bg-token-bg-secondary h-2 rounded-full"]))),
    Pn = () => s.jsxs(Ct, {
        className: "gap-2",
        children: [" ", s.jsx(Ee, {
            className: "w-[48px]"
        }), " ", s.jsx(Ee, {}), " ", s.jsx(Ee, {}), " ", s.jsx(Ee, {
            className: "w-1/2"
        })]
    }),
    $n = {
        initial: {
            scaleX: 0,
            opacity: 1
        },
        animate: {
            scaleX: 1,
            opacity: 0,
            transition: {
                scaleX: {
                    duration: .85,
                    ease: [.65, 0, .35, 1]
                },
                opacity: {
                    delay: .85,
                    duration: .1
                }
            }
        }
    },
    Un = {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1,
            transition: {
                delay: .85,
                duration: .1
            }
        }
    };
var lt;
W.div(lt || (lt = H(["ms-2 rounded-full px-2 py-0.5 text-xs font-medium"])));
const Dt = ({
        speakerId: t,
        content: e,
        range: n,
        filterDecision: a,
        isEditing: r,
        isSaving: o,
        containerRef: c,
        measuredTextContainerRef: l,
        isEditingEnabled: u
    }) => {
        var F, Q, I, _;
        const i = p.useRef(null),
            {
                setSpeakers: d,
                setEditingSpeaker: m,
                hoveringSpeakerId: x,
                setHoveringSpeakerId: f,
                speakers: v,
                editingSpeaker: g,
                enableDebugger: j
            } = Se.getState(),
            N = Se(b => b.currentTime),
            y = n.max == null ? N === n.min : N >= n.min && N <= n.max;
        p.useEffect(() => {
            if (y && i.current && c.current) {
                const b = c.current,
                    q = i.current,
                    G = b.getBoundingClientRect().top,
                    k = q.getBoundingClientRect().top - G + b.scrollTop - 20;
                Cn(b, k, .3)
            }
        }, [n.min, n.max, y, c]);
        const h = v.get(t),
            M = !!(h != null && h.storedName) && h.storedName !== (h == null ? void 0 : h.placeholderName) || ((F = h == null ? void 0 : h.isEdited) != null ? F : !1),
            T = (_ = (I = (Q = h == null ? void 0 : h.name) != null ? Q : h == null ? void 0 : h.storedName) != null ? I : h == null ? void 0 : h.placeholderName) != null ? _ : "Unidentified Speaker",
            C = p.useRef(null),
            B = t === (g == null ? void 0 : g.id),
            O = t === x,
            [se, z] = p.useState(!1),
            [X, V] = p.useState(!1);
        p.useEffect(() => {
            var b;
            C.current && (!B || !X || ((b = C.current) == null || b.focus(), M && (C.current.value = T)))
        }, [M, B, X, T]), bs(() => {
            if (l != null && l.current && C.current) {
                const b = l.current.offsetWidth;
                C.current.style.width = "".concat(b, "px")
            }
        }, [g == null ? void 0 : g.name]);
        const Z = p.useCallback(() => {
                if (!g || !h) return;
                m(null), V(!1), z(!1), f(null);
                const b = v.set(t, ee(E({}, h), {
                    name: g.name ? g.name : h.placeholderName,
                    isEdited: !!g.name
                }));
                d(b)
            }, [g, h, m, f, v, t, d]),
            P = !r || o;
        return s.jsxs(Ct, {
            ref: i,
            className: L(y && "animate-[hive-log-fadeout_0.3s_1.5s_forwards] bg-blue-500/10", !1, !1),
            children: [!1, s.jsxs("div", {
                className: "mb-[1px] flex w-full items-center justify-between",
                children: [u && (B ? s.jsx(Dn, {
                    ref: C,
                    disabled: !X,
                    onBlur: Z,
                    className: L(!B && "hidden w-0"),
                    placeholder: h != null && h.isEdited || h == null ? void 0 : h.placeholderName,
                    value: g == null ? void 0 : g.name,
                    onKeyDown: b => {
                        b.key === "Enter" && Z()
                    },
                    onChange: b => m({
                        id: t,
                        name: b.target.value
                    })
                }) : s.jsxs("div", {
                    className: "flex items-center gap-1",
                    children: [s.jsxs("div", {
                        onClick: () => {
                            P || (m({
                                id: t,
                                name: M ? T : ""
                            }), V(!0))
                        },
                        onMouseEnter: () => {
                            P || (f(t), z(!0))
                        },
                        onMouseLeave: () => {
                            P || (f(null), z(!1))
                        },
                        className: L("relative flex font-semibold transition-colors", {
                            "text-blue-400!": O && !P
                        }, {
                            "cursor-pointer": !P
                        }, {
                            "text-token-text-tertiary": !P && !M
                        }),
                        children: [T, !P && !M && s.jsxs(s.Fragment, {
                            children: [s.jsx(Bn, E({}, $n)), s.jsx(On, ee(E({}, Un), {
                                className: L(O && !P && "border-blue-400!")
                            }))]
                        })]
                    }), se && !P && s.jsx(wt, {
                        className: "h-4 w-4 text-blue-400"
                    }), !1]
                })), s.jsx("div", {
                    className: "text-xs text-[#5D5D5D]",
                    children: qs(n.min)
                })]
            }), s.jsx("div", {
                className: "flex",
                children: e
            })]
        })
    },
    Hn = t => De({
        queryKey: ["sharedHiveLog", t],
        queryFn: () => ve.safeGet("/hive/textdoc/shared/{shared_textdoc_id}/transcript", {
            parameters: {
                path: {
                    shared_textdoc_id: t
                }
            }
        }),
        select: Et
    }),
    Fn = t => De({
        queryKey: ["hiveLog", t],
        queryFn: () => ve.safeGet("/hive/{hive_id}/transcript", {
            parameters: {
                path: {
                    hive_id: t
                }
            }
        }),
        enabled: !!t,
        select: Et
    }),
    qn = () => De({
        queryKey: ["hiveLogPrompts"],
        queryFn: () => ve.safeGet("/hive/prompts"),
        enabled: !0
    }),
    Gn = (t, e) => ve.safePost("/hive/{hive_id}/speakers", {
        parameters: {
            path: {
                hive_id: t
            }
        },
        requestBody: {
            speakers: e
        }
    });
var ct;
const Wn = W.div(ct || (ct = H(["invisible absolute start-0 top-0 rounded-md border px-0.5 text-sm font-semibold whitespace-pre"]))),
    zn = (t, e) => !e || !t ? "" : e.isEdited || t.name && t.name !== e.placeholderName ? t.name : e.placeholderName,
    Bt = () => s.jsx(js, {
        children: s.jsx(R, E({}, me.researchPreview))
    });
var dt;
const Xn = W.div(dt || (dt = H(["flex h-full w-full max-w-[360px] min-w-[240px] flex-col border-s border-gray-200"])));
var ut;
const Vn = W.div(ut || (ut = H(["flex w-full max-w-[360px] min-w-[240px] flex-col border-s border-gray-200"])));
var mt;
const Yn = W.div(mt || (mt = H(["bg-token-bg-primary mt-[0.5px] flex h-18 w-full items-center justify-between border-b-[0.5px] border-gray-200 p-4"])));
var ft;
const Ot = W.div(ft || (ft = H(["flex h-full w-full flex-col gap-2 overflow-y-auto p-2"])));
var pt;
const tt = W(A.div)(pt || (pt = H(["flex items-center gap-2"]))),
    st = {
        initial: {
            opacity: 0,
            y: -4
        },
        animate: {
            opacity: 1,
            y: 0,
            transition: {
                duration: .2
            }
        },
        exit: {
            opacity: 0,
            y: -4,
            transition: {
                duration: .2
            }
        }
    },
    da = "ts",
    ua = ({
        sharedTextDocId: t
    }) => {
        const e = Hn(t),
            n = p.useRef(null),
            a = ws(),
            {
                selectedFilters: r,
                isOpen: o,
                currentTime: c,
                closeSidebar: l
            } = Se(),
            u = p.useMemo(() => {
                var m;
                return (m = e.data) == null ? void 0 : m.filter(({
                    filterDecision: x
                }) => !x || (r == null ? void 0 : r.includes(x)))
            }, [e.data, r]);
        if (e.isError) return null;
        const i = s.jsxs("div", {
                className: "text-token-text-secondary flex items-center gap-1.5 px-2 py-2 text-base font-medium md:px-0",
                children: [s.jsx(R, E({}, me.transcript)), s.jsx(Bt, {})]
            }),
            d = s.jsxs(s.Fragment, {
                children: [e.isLoading && Array.from({
                    length: 16
                }).map((m, x) => s.jsx(Pn, {}, "loading-".concat(x))), u == null ? void 0 : u.map(m => s.jsx(Dt, E({
                    isEditingEnabled: !1,
                    containerRef: n
                }, m), Pt(m)))]
            });
        return !o || !c ? null : a ? s.jsxs(Vn, {
            children: [s.jsxs(Yn, {
                children: [i, s.jsx(Es, {
                    onClick: l
                })]
            }), s.jsx(Ot, {
                ref: n,
                children: d
            })]
        }) : s.jsx(ht, {
            contentRef: n,
            testId: "modal-shared-canvas-transcript-modal",
            isOpen: o,
            title: i,
            contentClassName: "overflow-y-auto gap-2 p-2 flex flex-col",
            showCloseButton: !0,
            onClose: l,
            children: d
        })
    },
    ma = ({
        hiveId: t,
        clientThreadId: e,
        ts: n,
        textdocVersion: a
    }) => {
        const r = Fn(t),
            o = qn(),
            c = ce(),
            [l, u] = p.useState(!1),
            i = p.useRef(null),
            d = gt(),
            m = Ns(d, "2986567482"),
            {
                isOpen: x,
                closeSidebar: f,
                openSidebar: v,
                setCurrentTime: g,
                speakers: j,
                setSpeakers: N,
                editingSpeaker: y,
                enableDebugger: h,
                setEnableDebugger: M,
                selectedFilters: T,
                setSelectedFilters: C
            } = Se();
        p.useEffect(() => {
            n !== void 0 && (v(), g(n))
        }, [n, v, g]);
        const B = p.useRef(null),
            [O, se] = p.useState(!1),
            z = yn(e, a);
        if (r.isLoading || o.isLoading || r.isError || o.isError || !r.data || !o.data) return null;
        const X = y ? j.get(y.id) : null,
            V = Array.from(j.values()).some(({
                isEdited: I
            }) => I),
            Z = () => {
                const I = new Map(Array.from(j.entries()).map(([_, b]) => [_, ee(E({}, b), {
                    name: void 0,
                    isEdited: !1
                })]));
                N(I), u(!1)
            },
            P = I => {
                if (!o.data.speaker_edits) return;
                const _ = o.data.speaker_edits.replace("{speakers}", JSON.stringify(Array.from(j.entries())));
                return z({
                    sourceEvent: I,
                    action: ue.EDIT,
                    content: _,
                    userMessageType: U.HIVE_SPEAKER_EDIT,
                    selectionMetadata: void 0
                })
            },
            F = async I => {
                if (V) {
                    se(!0);
                    try {
                        const _ = [];
                        Array.from(j.entries()).forEach(([G, w]) => {
                            !w.isEdited || !w.name || _.push({
                                id: G,
                                updated_name: w.name
                            })
                        });
                        const b = await Gn(t, _);
                        if (!b) throw new Error("Failed to update hive content");
                        const q = new Map(j);
                        for (const G of b.updated_speakers) {
                            if (!q.has(G.id)) continue;
                            const w = q.get(G.id);
                            w && q.set(G.id, ee(E({}, w), {
                                storedName: G.updated_name,
                                isEdited: !1
                            }))
                        }
                        await P(I), N(q), u(!1)
                    } catch (_) {} finally {
                        se(!1)
                    }
                }
            },
            Q = r.data.filter(({
                filterDecision: I
            }) => !I || (T == null ? void 0 : T.includes(I)));
        return s.jsxs(Xn, {
            className: L(x ? "visible" : "invisible hidden"),
            children: [s.jsxs("div", {
                className: "flex h-14 w-full items-center justify-between border-b border-gray-200 p-4",
                children: [s.jsxs("div", {
                    className: "text-token-text-secondary group/debug flex items-center gap-1.5 py-2 text-base font-medium",
                    children: [s.jsx(R, E({}, me[l ? "edit" : "transcript"])), s.jsx(Bt, {}), !1]
                }), s.jsx("div", {
                    className: "flex h-10 items-center gap-2",
                    children: s.jsx(be, {
                        mode: "wait",
                        children: l ? s.jsxs(tt, ee(E({}, st), {
                            children: [s.jsx(le, {
                                onClick: Z,
                                color: "secondary",
                                disabled: O,
                                children: s.jsx(R, E({}, me.cancelButton))
                            }), s.jsx(le, {
                                color: "primary",
                                onClick: F,
                                disabled: !V,
                                loading: O,
                                children: s.jsx(R, E({}, me.saveButton))
                            })]
                        }), "edit-buttons") : s.jsxs(tt, ee(E({}, st), {
                            children: [m && s.jsx(_e, {
                                className: "h-10",
                                label: c.formatMessage(me.editButtonTooltip),
                                children: s.jsx(Ke, {
                                    icon: wt,
                                    onClick: () => u(!0)
                                })
                            }), s.jsx(Ke, {
                                icon: Be,
                                onClick: () => f()
                            })]
                        }), "non-edit-buttons")
                    })
                })]
            }), !1, s.jsxs(Ot, {
                ref: i,
                children: [m && y && s.jsx(Wn, {
                    ref: B,
                    children: zn(y, X)
                }), Q.map(I => s.jsx(Dt, E({
                    isEditingEnabled: m,
                    measuredTextContainerRef: B,
                    containerRef: i,
                    isEditing: l,
                    isSaving: O
                }, I), Pt(I)))]
            })]
        })
    },
    Pt = t => {
        const {
            speakerId: e,
            content: n,
            range: a
        } = t;
        return "".concat(e, "-").concat(a.min, "-").concat(a.max, "-").concat(n.slice(0, 2))
    },
    me = Te({
        researchPreview: {
            id: "HiveLogSidebar.researchPreview",
            defaultMessage: "Research Preview"
        },
        edit: {
            id: "HiveLogSidebar.edit",
            defaultMessage: "Edit"
        },
        transcript: {
            id: "HiveLogSidebar.transcript",
            defaultMessage: "Transcript"
        },
        editButtonTooltip: {
            id: "HiveLogSidebar.editButtonTooltip",
            defaultMessage: "Edit speakers"
        },
        cancelButton: {
            id: "HiveLogSidebar.cancelButton",
            defaultMessage: "Cancel"
        },
        saveButton: {
            id: "HiveLogSidebar.saveButton",
            defaultMessage: "Save"
        }
    });
export {
    ca as C, da as H, ua as S, ma as T, la as a, yn as u
};
//# sourceMappingURL=hzx735z33xljaym3.js.map