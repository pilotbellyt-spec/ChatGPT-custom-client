const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/kfozsua9bqnntmw9.js", "assets/fg33krlcm0qyi6yw.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/k15yxxoybkkir2ou.js", "assets/conversation-small-332fs9rk.css", "assets/k253gzle9qy7mdll.js", "assets/jjruw0pg8h58hov8.js", "assets/ni16khhtjgvldr4m.js", "assets/hn5e71c3hkpkv00z.js", "assets/cgt1h5qo3k52ojx3.js", "assets/v9p9lvhz45nq9ivc.js", "assets/gh0bqurnaw4e38cn.js", "assets/h21g9slzr4ujv9kj.js", "assets/hdvj2l707w8wzq5m.js", "assets/k9ntkzgra750487m.js", "assets/f8zwc22xu46enu24.js", "assets/c1lw0j14sexsyj33.js", "assets/obmzp3ebe8x6w67a.js", "assets/kwnt5gec5u9yguq4.js", "assets/huyvl5jhsuxofll4.js", "assets/kuvu1ok8vnzveb23.js"]))) => i.map(i => d[i]);
var wn = Object.freeze,
    Pn = Object.defineProperty,
    ai = Object.defineProperties;
var oi = Object.getOwnPropertyDescriptors;
var Ps = Object.getOwnPropertySymbols;
var kn = Object.prototype.hasOwnProperty,
    Rn = Object.prototype.propertyIsEnumerable;
var En = (i, e, t) => e in i ? Pn(i, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : i[e] = t,
    oe = (i, e) => {
        for (var t in e || (e = {})) kn.call(e, t) && En(i, t, e[t]);
        if (Ps)
            for (var t of Ps(e)) Rn.call(e, t) && En(i, t, e[t]);
        return i
    },
    Ve = (i, e) => ai(i, oi(e));
var jn = (i, e) => {
    var t = {};
    for (var s in i) kn.call(i, s) && e.indexOf(s) < 0 && (t[s] = i[s]);
    if (i != null && Ps)
        for (var s of Ps(i)) e.indexOf(s) < 0 && Rn.call(i, s) && (t[s] = i[s]);
    return t
};
var Js = (i, e) => wn(Pn(i, "raw", {
    value: wn(e || i.slice())
}));
import {
    _ as es,
    r as I,
    j as n,
    M as He,
    f as ii,
    c as ss,
    a as ga,
    e as js,
    E as ri,
    n as li
} from "./fg33krlcm0qyi6yw.js";
import {
    bh as ze,
    F as ma,
    dH as bs,
    gd as D,
    kh as ha,
    dF as $,
    e2 as ee,
    l as Se,
    v9 as pa,
    bb as di,
    pV as ci,
    fN as Ce,
    dL as We,
    dR as it,
    dI as Ze,
    ql as ui,
    a9 as fa,
    kM as va,
    R as gi,
    A as mi,
    aU as Fn,
    _ as st,
    dZ as ba,
    m as xa,
    b as xs,
    va as hi,
    ba as Ia,
    k as rt,
    c_ as _a,
    nm as Ca,
    eO as pi,
    aW as fi,
    hj as vi,
    gy as Sa,
    d as Le,
    gr as tt,
    vb as Nn,
    V as lt,
    o as je,
    cU as Ta,
    pz as bi,
    gU as xi,
    aK as Ii,
    kz as _i,
    e as Ci,
    c0 as Si,
    P as Fe,
    $ as Ti,
    ag as yi,
    i as Mi,
    gP as Ai,
    n as Bn,
    W as Dn,
    h7 as Un,
    kl as wi,
    kH as Ei,
    kF as Xs,
    dP as Pi,
    bI as vs,
    dp as ki,
    mx as Ri,
    hG as ji,
    ed as Gn,
    eW as Fi,
    pW as Ni,
    pU as Bi,
    id as ya,
    dC as Di,
    dJ as ls,
    e4 as Ui,
    es as Rs,
    hh as Gi,
    vc as Oi,
    d6 as Ma,
    mO as Vi,
    eJ as Li,
    dQ as Ys,
    q1 as Hi,
    vd as On,
    fP as Wi,
    ve as zi,
    e7 as Vn,
    vf as $i,
    kw as qi,
    kx as Ki,
    bj as Qi,
    bJ as Ln,
    m3 as ks,
    hX as Ji,
    f8 as Xi,
    lX as Yi,
    bv as Zi,
    en as er,
    sm as sr,
    pr as tr,
    gG as Hn,
    vg as nr,
    eo as ar,
    gF as or,
    hg as ir,
    kI as rr,
    qu as lr
} from "./dykg4ktvbu3mhmdo.js";
import {
    o2 as dr,
    o3 as nt,
    d6 as cr,
    o4 as Wn,
    o5 as ur,
    o6 as zn,
    o7 as gr,
    fJ as ds,
    dP as mr,
    o8 as hr,
    o9 as pr,
    nf as fr,
    gc as vr,
    ng as br,
    ge as xr,
    oa as Ir,
    a8 as _r,
    Y as Aa,
    ob as wa,
    oc as Ea,
    od as Cr,
    oe as Sr,
    of as Tr,
    fp as yr,
    ca as Mr,
    c$ as Ar,
    fY as wr,
    og as Er,
    oh as Pr,
    mK as Pa,
    e$ as kr,
    f0 as Rr,
    f1 as jr,
    oi as Fr,
    dr as Nr,
    bq as Br,
    k_ as Dr,
    e0 as ka,
    oj as Ur,
    ok as Gr,
    f3 as Or,
    ol as Vr,
    om as Lr,
    j3 as Hr,
    on as $n,
    a$ as Wr,
    oo as zr,
    eJ as at,
    op as $r,
    bB as qr,
    oq as Kr,
    aA as Qr,
    or as Jr,
    os as Xr,
    ot as Yr,
    ou as Zr,
    ov as el,
    ow as qn,
    ox as sl,
    b1 as Kn,
    oy as tl,
    oz as nl,
    oA as al,
    oB as ol,
    oC as il,
    oD as rl,
    em as ll,
    oE as dl,
    oF as cl,
    oG as ul,
    oH as gl,
    oI as ml,
    oJ as hl,
    oK as pl,
    oL as fl,
    oM as vl,
    oN as bl,
    oO as xl,
    oP as Il,
    oQ as _l,
    af as Cl,
    oR as Sl,
    ag as Ra,
    oS as Tl,
    oT as yl,
    oU as Ml,
    oV as Al,
    oW as Qn,
    oX as wl,
    oY as El,
    oZ as Pl,
    o_ as kl,
    o$ as Jn,
    p0 as Rl,
    p1 as jl,
    p2 as Fl,
    p3 as Nl,
    p4 as Bl,
    p5 as Dl,
    p6 as Ul,
    p7 as Gl,
    ah as Ol,
    p8 as Vl,
    p9 as Ll,
    pa as Hl,
    pb as Wl,
    a7 as zl,
    pc as $l,
    pd as ql,
    pe as Kl,
    pf as Ql,
    pg as Jl,
    ph as Xl,
    pi as Yl,
    mM as Zl,
    jt as ed,
    pj as sd,
    mg as td,
    pk as nd,
    pl as ad,
    pm as od,
    pn as id,
    po as rd,
    pp as ld
} from "./k15yxxoybkkir2ou.js";
import {
    b as dd
} from "./o67bv4dtwt5l98l7.js";
import {
    C as ot
} from "./i5kvudettvxsr7pw.js";
import "./jlu292yvnhcpthaw.js";
import "./f78b2oufkmgyeo1t.js";
import {
    a as cd,
    b as ud
} from "./ib78f9d5brp6znzf.js";
const Xn = ze(() => es(() =>
    import ("./kfozsua9bqnntmw9.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10])).then(i => i.MemoryActionResult));

function Yn(i, e, t) {
    We(i, s => {
        it.updateTree(s, r => {
            r.updateNodeMetadata(e, {
                inlineComparisonRating: t
            })
        })
    })
}
const Zn = ({
    messages: i
}) => {
    for (const {
            metadata: e
        } of i) {
        const {
            paragen_display_label: t
        } = e != null ? e : {};
        if (t) return t;
        const {
            augmented_paragen_prompt_label: s
        } = e != null ? e : {};
        if (s) return s
    }
};

function ea({
    displayedMessages: i,
    message: e,
    conversationTurnMountTime: t,
    visibilityState: s
}) {
    var d, u;
    const r = {},
        o = ((d = e.clientMetadata) == null ? void 0 : d.variantsInStreamInfo) == null && ((u = e.metadata) == null ? void 0 : u.paragen_variants_info) != null;
    return i.forEach((h, b) => {
        const l = o ? {
                load_first_token_time: t,
                load_end_time: t
            } : {
                load_first_token_time: h.loadFirstTokenTime,
                load_end_time: h.loadEndTime
            },
            S = b === 0 ? {
                rendered_height: s.left_rendered_height
            } : {
                rendered_height: s.right_rendered_height
            };
        r[h.messageId] = oe(oe({}, l), S)
    }), r
}

function gd(i) {
    const e = I.useRef({
            left_visibility_initial: null,
            left_visibility_max: null,
            right_visibility_initial: null,
            right_visibility_max: null,
            left_rendered_height: null,
            right_rendered_height: null
        }),
        t = I.useRef({
            left: null,
            right: null
        });
    return i.variantIds.length < 2 ? n.jsx(ja, oe({
        setPreferredFeedback: () => {},
        leftVariantId: "left-placeholder",
        rightVariantId: "right-placeholder",
        leftTurn: null,
        rightTurn: null,
        originalTurn: null,
        hasActiveRequest: !0,
        visibilityStateRef: e,
        firstVisibleTokenTimestampsRef: t
    }, i)) : n.jsx(md, Ve(oe({}, i), {
        visibilityStateRef: e,
        firstVisibleTokenTimestampsRef: t
    }))
}

function md(i) {
    const {
        conversation: e,
        variantIds: t,
        turnIndex: s,
        firstVisibleTokenTimestampsRef: r
    } = i;
    if (t.length !== 2) throw new Error("ConversationTurnSideBySideFeedback requires exactly two variant IDs");
    const o = pa(),
        d = di(),
        [u, h] = t,
        b = I.useMemo(() => ci(u + h)() >= .5, [u, h]),
        [l, S] = b ? [h, u] : [u, h],
        [_, x, f] = Ce(e.id, k => {
            var M, N, j, B, c, V, q, H, ce, X, me, K, he, y, J, W, w, ue, de, se;
            const P = Fn(k).tree.getLeafFromNode(l).id,
                F = Fn(k).tree.getLeafFromNode(S).id,
                g = $.getConversationTurns(k, P),
                O = $.getConversationTurns(k, F),
                U = s < g.length ? g[s] : null,
                R = s < O.length ? O[s] : null;
            return U || st.addError("Paragen Left turn index ".concat(s, " out of bounds"), {
                turnIndex: s,
                turnCount: g.length,
                lastTurnRole: (M = D(g)) == null ? void 0 : M.role,
                lastMessageAuthor: (j = D((N = D(g)) == null ? void 0 : N.messages)) == null ? void 0 : j.author,
                lastMessageContentType: (c = D((B = D(g)) == null ? void 0 : B.messages)) == null ? void 0 : c.content.content_type,
                lastMessageMetadata: (q = D((V = D(g)) == null ? void 0 : V.messages)) == null ? void 0 : q.metadata,
                altTurnCount: O.length,
                altLastTurnRole: (H = D(O)) == null ? void 0 : H.role,
                altLastMessageRole: (X = D((ce = D(O)) == null ? void 0 : ce.messages)) == null ? void 0 : X.author.role
            }), R || st.addError("Paragen Right turn index ".concat(s, " out of bounds"), {
                turnIndex: s,
                turnCount: O.length,
                lastTurnRole: (me = D(O)) == null ? void 0 : me.role,
                lastMessageAuthor: (he = D((K = D(O)) == null ? void 0 : K.messages)) == null ? void 0 : he.author,
                lastMessageContentType: (J = D((y = D(O)) == null ? void 0 : y.messages)) == null ? void 0 : J.content.content_type,
                lastMessageMetadata: (w = D((W = D(O)) == null ? void 0 : W.messages)) == null ? void 0 : w.metadata,
                altTurnCount: g.length,
                altLastTurnRole: (ue = D(g)) == null ? void 0 : ue.role,
                altLastMessageRole: (se = D((de = D(g)) == null ? void 0 : de.messages)) == null ? void 0 : se.author.role
            }), [P, U, R]
        }),
        [p, T] = b ? [f, x] : [x, f],
        v = "skippable_parallel_2_in_stream:a:1.5";
    I.useEffect(() => (zn.setState({
        displayingSideBySideFeedback: !0
    }), () => {
        zn.setState({
            displayingSideBySideFeedback: !1
        })
    }), []);
    const C = I.useRef({
            left_visibility_initial: null,
            left_visibility_max: null,
            right_visibility_initial: null,
            right_visibility_max: null,
            left_rendered_height: null,
            right_rendered_height: null
        }),
        G = I.useCallback((k, {
            shouldSubmitParagenFeedback: P = !0
        } = {}) => {
            if (!x || !f || !p || !T) throw new Error("Expected both turns to exist");
            We(e.id, j => {
                it.setCurrentBranch(j, k)
            });
            const F = k === l,
                g = k === u;
            p.messages.length > 0 && Yn(e.id, p.messages[p.messages.length - 1].id, g ? "original" : "new"), T.messages.length > 0 && Yn(e.id, T.messages[T.messages.length - 1].id, g ? "original" : "new");
            const O = Ze(e.id),
                U = [x, f].map((j, B) => {
                    var c, V, q;
                    return {
                        messageId: j.messages[j.messages.length - 1].id,
                        loadFirstTokenTime: B === 0 ? r.current.left : r.current.right,
                        loadEndTime: (q = (V = (c = D(j.messages)) == null ? void 0 : c.clientMetadata) == null ? void 0 : V.completionSampleFinishTime) != null ? q : null
                    }
                }),
                R = F ? U[0].messageId : U[1].messageId,
                M = $.getParentPromptNode(bs(e.id), _);
            if (!M) throw new Error("Expected prompt for side by side feedback");
            const N = ea({
                displayedMessages: U,
                message: M.message,
                conversationTurnMountTime: i.conversationTurnMountTime,
                visibilityState: C.current
            });
            P && oa({
                params: {
                    conversation_id: O,
                    displayed_message_ids: U.map(j => j.messageId),
                    message_metadatas: N,
                    rating: "selected",
                    selected_message_id: R,
                    source_timestamp: Date.now(),
                    ui_variant: 1,
                    user_prompt_message_id: M.message.id
                }
            })
        }, [e.id, l, u, p, T, x, f, _, r, i.conversationTurnMountTime, C]);
    return I.useEffect(() => ui(ba, {
        requestCompletion: k => {
            const P = Ze(e.id),
                F = $.getParentPromptNode(bs(e.id), _);
            if (!F) throw new Error("Expected prompt for side by side feedback");
            if (!x || !f) throw new Error("Expected both turns to exist");
            const g = [x, f].map((R, M) => {
                    var N, j, B;
                    return {
                        messageId: R.messages[R.messages.length - 1].id,
                        loadFirstTokenTime: M === 0 ? r.current.left : r.current.right,
                        loadEndTime: (B = (j = (N = D(R.messages)) == null ? void 0 : N.clientMetadata) == null ? void 0 : j.completionSampleFinishTime) != null ? B : null
                    }
                }),
                O = ea({
                    displayedMessages: g,
                    message: F.message,
                    conversationTurnMountTime: i.conversationTurnMountTime,
                    visibilityState: C.current
                }),
                U = k.isForSkippingParagen;
            oa({
                params: {
                    conversation_id: P,
                    displayed_message_ids: g.map(R => R.messageId),
                    message_metadatas: O,
                    rating: U ? "explicit_skipped" : "skipped",
                    selected_message_id: null,
                    source_timestamp: Date.now(),
                    ui_variant: U ? 3 : 1,
                    user_prompt_message_id: F.message.id
                }
            }), U && G(l, {
                shouldSubmitParagenFeedback: !1
            })
        }
    }), [x, f, _, e.id, i.conversationTurnMountTime, v, p == null ? void 0 : p.messages, T == null ? void 0 : T.messages, d, r, G, l, C]), n.jsx(ja, Ve(oe({}, i), {
        setPreferredFeedback: G,
        leftVariantId: l,
        rightVariantId: S,
        leftTurn: x,
        rightTurn: f,
        hasActiveRequest: o,
        originalTurn: p,
        visibilityStateRef: C
    }))
}

function ja(b) {
    var l = b,
        {
            setPreferredFeedback: i,
            leftVariantId: e,
            rightVariantId: t,
            leftTurn: s,
            rightTurn: r,
            hasActiveRequest: o,
            originalTurn: d,
            visibilityStateRef: u
        } = l,
        h = jn(l, ["setPreferredFeedback", "leftVariantId", "rightVariantId", "leftTurn", "rightTurn", "hasActiveRequest", "originalTurn", "visibilityStateRef"]);
    var me, K, he;
    const S = (me = s && Zn(s)) != null ? me : null,
        _ = (K = r && Zn(r)) != null ? K : null,
        x = I.useMemo(() => {
            var y;
            return (y = s == null ? void 0 : s.messages) != null ? y : []
        }, [s == null ? void 0 : s.messages]),
        f = I.useMemo(() => {
            var y;
            return (y = r == null ? void 0 : r.messages) != null ? y : []
        }, [r == null ? void 0 : r.messages]),
        {
            avatarClassName: p,
            firstVisibleTokenTimestampsRef: T
        } = h,
        v = I.useMemo(() => {
            var y;
            return (y = s == null ? void 0 : s.messageGroups) != null ? y : []
        }, [s == null ? void 0 : s.messageGroups]),
        C = I.useMemo(() => {
            var y;
            return (y = r == null ? void 0 : r.messageGroups) != null ? y : []
        }, [r == null ? void 0 : r.messageGroups]),
        G = dr(),
        k = bs(h.conversation.id),
        P = D(s == null ? void 0 : s.messages),
        F = D(r == null ? void 0 : r.messages),
        g = ha($.getRequestId(k, (he = P == null ? void 0 : P.id) != null ? he : F == null ? void 0 : F.id)),
        O = g && !(P != null && P.end_turn),
        U = g && !(F != null && F.end_turn),
        R = P != null && nt(P),
        M = F != null && nt(F),
        N = R != null ? R : M,
        j = (s == null ? void 0 : s.role) === ee.User,
        B = (r == null ? void 0 : r.role) === ee.User,
        c = I.useRef(null),
        V = I.useRef(null),
        q = I.useRef(null),
        H = s != null,
        ce = r != null;
    !H && T.current.left == null && (T.current.left = Date.now()), !ce && T.current.right == null && (T.current.right = Date.now()), I.useEffect(() => {
        if (c.current && V.current && q.current) {
            const y = Array(11).fill(0).map((W, w) => w / 10),
                J = new IntersectionObserver(W => W.forEach(w => {
                    var ue, de, se, Ee, be, cs;
                    w.target === V.current ? ((de = (ue = u.current).left_visibility_initial) != null || (ue.left_visibility_initial = w.intersectionRatio), u.current.left_visibility_max = Math.max((se = u.current.left_visibility_max) != null ? se : 0, w.intersectionRatio)) : w.target === q.current && ((be = (Ee = u.current).right_visibility_initial) != null || (Ee.right_visibility_initial = w.intersectionRatio), u.current.right_visibility_max = Math.max((cs = u.current.right_visibility_max) != null ? cs : 0, w.intersectionRatio))
                }), {
                    root: c.current,
                    threshold: y
                });
            return J.observe(V.current), J.observe(q.current), () => J.disconnect()
        }
    }, [u]), I.useEffect(() => {
        const y = V.current,
            J = q.current;
        if (!y || !J) return;
        let W = null;
        const w = () => {
                W != null && cancelAnimationFrame(W), W = requestAnimationFrame(() => {
                    if (y.isConnected) {
                        const de = Math.round(y.getBoundingClientRect().height);
                        u.current.left_rendered_height = de
                    }
                    if (J.isConnected) {
                        const de = Math.round(J.getBoundingClientRect().height);
                        u.current.right_rendered_height = de
                    }
                })
            },
            ue = new ResizeObserver(w);
        return ue.observe(y), ue.observe(J), w(), () => {
            W != null && cancelAnimationFrame(W), ue.disconnect()
        }
    }, [u]);
    const {
        data: X
    } = cr({
        includeMemoryEntries: !1,
        enabled: G
    });
    return n.jsxs("div", {
        className: "relative flex flex-col",
        children: [n.jsx("div", {
            className: "bg-token-main-surface-primary sticky z-1 px-(--thread-content-margin) text-center text-lg text-pretty max-md:top-(--header-height)",
            "data-testid": "paragen-feedback-title",
            children: n.jsx(He, {
                id: "KKeSJV",
                defaultMessage: "You're giving feedback on a new version of ChatGPT."
            })
        }), n.jsx("div", {
            className: "text-token-text-secondary px-(--thread-content-margin) pt-1 pb-5 text-center text-sm text-pretty",
            children: n.jsx(He, {
                id: "TK934w",
                defaultMessage: "Which response do you prefer? Responses may take a moment to load."
            })
        }), n.jsx("div", {
            className: Se(ur(), "horzScrollShadows relative -mb-2 snap-x snap-mandatory overflow-x-auto overflow-y-clip pb-4"),
            ref: c,
            children: n.jsxs("div", {
                className: Se("mx-auto box-content max-w-[calc(2*var(--thread-content-max-width))] min-w-min px-(--thread-content-margin)", "flex items-start gap-4 sm:gap-6"),
                children: [n.jsxs(sa, {
                    rootElementRef: V,
                    onClick: () => {
                        i(e)
                    },
                    hasActiveRequest: o,
                    isImageGenInProgress: N,
                    children: [n.jsxs(na, {
                        children: [n.jsx(Wn, {
                            messages: x,
                            isUserTurn: j,
                            avatarClassName: p
                        }), n.jsx(ta, {
                            children: n.jsx(He, Ve(oe({}, ia.responseNumber), {
                                values: {
                                    responseIndex: 1,
                                    display_label: S ? " ".concat(S) : ""
                                }
                            }))
                        })]
                    }), n.jsxs(n.Fragment, {
                        children: [X != null && !j && n.jsx(Xn, {
                            clientThreadId: h.conversation.id,
                            messages: x,
                            isParagen: !0
                        }), n.jsx(ot, Ve(oe({}, h), {
                            allMessages: x,
                            groupedMessagesToRender: v,
                            allGroupedMessages: v,
                            isUserTurn: j,
                            isFinalUserTurn: !1,
                            isFinalAssistantTurn: !1,
                            isCompletionRequestInProgress: O,
                            hasActiveRequest: o,
                            shouldGrowContainer: !1,
                            isParagen: !0
                        })), n.jsx(aa, {
                            clientThreadId: h.conversation.id,
                            conversationTurnMountTime: h.conversationTurnMountTime,
                            turn: s,
                            originalTurn: d
                        })]
                    })]
                }), n.jsxs(sa, {
                    rootElementRef: q,
                    onClick: () => {
                        i(t)
                    },
                    hasActiveRequest: o,
                    isImageGenInProgress: N,
                    children: [n.jsxs(na, {
                        children: [n.jsx(Wn, {
                            messages: f,
                            isUserTurn: B,
                            avatarClassName: p
                        }), n.jsx(ta, {
                            children: n.jsx(He, Ve(oe({}, ia.responseNumber), {
                                values: {
                                    responseIndex: 2,
                                    display_label: _ ? " ".concat(_) : ""
                                }
                            }))
                        })]
                    }), n.jsxs(n.Fragment, {
                        children: [X != null && !B && n.jsx(Xn, {
                            clientThreadId: h.conversation.id,
                            messages: f,
                            isParagen: !0
                        }), n.jsx(ot, Ve(oe({}, h), {
                            allMessages: f,
                            groupedMessagesToRender: C,
                            allGroupedMessages: C,
                            isFinalUserTurn: !1,
                            isFinalAssistantTurn: !1,
                            isUserTurn: B,
                            isCompletionRequestInProgress: U,
                            hasActiveRequest: o,
                            shouldGrowContainer: !1,
                            isParagen: !0
                        })), n.jsx(aa, {
                            clientThreadId: h.conversation.id,
                            conversationTurnMountTime: h.conversationTurnMountTime,
                            turn: r,
                            originalTurn: d
                        })]
                    })]
                })]
            })
        })]
    })
}

function sa({
    rootElementRef: i,
    onClick: e,
    children: t,
    hasActiveRequest: s,
    isImageGenInProgress: r
}) {
    const o = I.useRef(null),
        d = I.useRef(null),
        u = I.useRef(null);
    return n.jsx("div", {
        "data-paragen-root": !0,
        className: "border-token-border-tertiary @container relative flex min-w-[min(450px,80cqw,80vw)] flex-1 snap-center flex-col gap-1 rounded-xl border text-start shadow-lg shadow-black/3",
        ref: i,
        children: n.jsxs("div", {
            className: Se(gr, "px-(--thread-content-margin) py-4"),
            children: [n.jsx("div", {
                className: Se("absolute top-48 right-0! left-0! h-px", "invisible"),
                ref: o
            }), n.jsx("div", {
                className: Se("absolute top-48 right-0! bottom-0 left-0!", "invisible"),
                ref: d
            }), n.jsx("div", {
                className: Se("absolute right-0! bottom-0 left-0! h-px", "invisible"),
                ref: u
            }), t, s || r ? null : n.jsx(fa, {
                className: "mt-4 self-start",
                onClick: e,
                "data-testid": "paragen-prefer-response-button",
                children: n.jsx(He, {
                    id: "U2EAH6",
                    defaultMessage: "I prefer this response"
                })
            })]
        })
    })
}
var ca;
const ta = ma.div(ca || (ca = Js(["text-sm text-token-text-secondary font-semibold"])));
var ua;
const na = ma.div(ua || (ua = Js(["flex gap-4 items-center mb-1"])));

function aa({
    clientThreadId: i,
    conversationTurnMountTime: e,
    turn: t,
    originalTurn: s
}) {
    var S, _, x, f, p, T;
    const r = va();
    if (!r.showParagenMetadata || !r.showDebugConversationTurns && !r.forceParagen || t == null) return null;
    let o = t === s ? "ORIGINAL" : "NEW";
    const d = t.messages[t.messages.length - 1],
        u = (S = d == null ? void 0 : d.metadata) == null ? void 0 : S.__internal,
        h = (_ = d == null ? void 0 : d.metadata) == null ? void 0 : _.paragen_display_label;
    if (u) {
        const {
            model_id: v,
            model_definition_slug: C,
            model_definition_virtual_model_id: G,
            alternative_model_selection_rule: k,
            augmented_paragen_prompt_group_id: P,
            augmented_paragen_prompt_id: F,
            augmented_paragen_prompt: g
        } = u;
        v && (o += "\nModel ID: ".concat(v)), C && (o += "\nModel Slug: ".concat(C)), G && (o += "\nVirtual Model ID: ".concat(G)), k && (o += "\nAlternative Model Rule: ".concat(k)), P && (o += "\nPrompt Group ID: ".concat(P)), F && (o += "\nPrompt ID: ".concat(F)), g && (o += "\nPrompt: ".concat(g)), h && (o += "\nDisplay Label: ".concat(h))
    }
    o += "\nMessage ID: ".concat(d.id);
    const b = $.getParentPromptNode(bs(i), t.messages[0].id);
    if (!b) throw new Error("Expected prompt for side by side feedback");
    const l = ((x = b.message.clientMetadata) == null ? void 0 : x.variantsInStreamInfo) == null && ((f = b.message.metadata) == null ? void 0 : f.paragen_variants_info) != null;
    return o += "\nUser prompt message ID: ".concat(b.message.id), o += "\nIs Persisted Paragen? ".concat(l), o += "\nCompletion Sample Finish Time: ".concat(l ? "".concat(e, " (persisted)") : (T = (p = D(t.messages)) == null ? void 0 : p.clientMetadata) == null ? void 0 : T.completionSampleFinishTime), n.jsx("div", {
        className: "text-sm whitespace-pre-wrap text-red-500",
        children: o
    })
}
async function oa({
    params: i
}) {
    await gi.safePost("/paragen_submission", {
        requestBody: i,
        authOption: mi.SendIfAvailable
    })
}
const ia = ii({
    responseNumber: {
        id: "ConversationTurnTwoUpFeedback.responseNumber",
        defaultMessage: "Response {responseIndex, number}{display_label}"
    }
});

function Fa({
    ctx: i,
    clientThreadId: e,
    messageId: t,
    isSharedConversation: s,
    isAuthoredByCurrentUser: r,
    serverThreadId: o
}) {
    const d = o != null ? o : Ze(e),
        u = t != null ? t : null,
        h = lt(i, "1030729005").get("chatgpt_message_feedback_consolidation_enabled", !1);
    return {
        canReportMessage: !!(u && d) && je(i, "3376455464") && !h && !r && !s,
        handleReportMessage: () => {
            u && Ta(i, hd, {
                clientThreadId: e,
                serverThreadId: d != null ? d : void 0,
                messageId: u
            })
        }
    }
}
const hd = ze(() => es(() =>
        import ("./v9p9lvhz45nq9ivc.js"), __vite__mapDeps([11, 1, 2, 3, 4, 5])).then(i => i.ThreadReportMessageModal)),
    pd = ze(async () => () => null),
    fd = i => {
        "use forget";
        const e = ss.c(19),
            {
                alwaysShow: t,
                isUserTurn: s,
                children: r
            } = i,
            o = I.useRef(null);
        let d, u;
        e[0] !== t ? (d = () => {
            const v = o.current;
            v && (t ? requestAnimationFrame(() => {
                v && (v.style.maskPosition = t ? "0% 0%" : "")
            }) : v.style.maskPosition = "")
        }, u = [t], e[0] = t, e[1] = d, e[2] = u) : (d = e[1], u = e[2]), I.useEffect(d, u);
        const h = !t && "absolute start-0 end-0 flex",
            b = s ? "justify-end" : "min-h-[46px] justify-start";
        let l;
        e[3] !== h || e[4] !== b ? (l = Se("z-0 flex", h, b), e[3] = h, e[4] = b, e[5] = l) : l = e[5];
        const S = !s && "touch:w-[calc(100%+--spacing(3.5))] -mt-1 w-[calc(100%+--spacing(2.5))]",
            _ = t && !s && "duration-[1.5s]",
            x = !(t || s) && "duration-500 group-hover/turn-messages:delay-300";
        let f;
        if (e[6] !== s || e[7] !== S || e[8] !== _ || e[9] !== x) {
            let v;
            e[11] !== s ? (v = s && ["touch:pointer-events-auto touch:opacity-100", "duration-300 group-hover/turn-messages:delay-300", "pointer-events-none opacity-0 motion-safe:transition-opacity", "group-hover/turn-messages:pointer-events-auto group-hover/turn-messages:opacity-100", "group-focus-within/turn-messages:pointer-events-auto group-focus-within/turn-messages:opacity-100", "has-data-[state=open]:pointer-events-auto has-data-[state=open]:opacity-100"], e[11] = s, e[12] = v) : v = e[12], f = Se("touch:-me-2 touch:-ms-3.5 -ms-2.5 -me-1 flex flex-wrap items-center gap-y-4 p-1 select-none", S, _, "focus-within:transition-none hover:transition-none", x, !s && ["touch:pointer-events-auto", "pointer-events-none [mask-image:linear-gradient(to_right,black_33%,transparent_66%)] [mask-size:300%_100%] [mask-position:100%_0%] motion-safe:transition-[mask-position]", "group-hover/turn-messages:pointer-events-auto group-hover/turn-messages:[mask-position:0_0]", "group-focus-within/turn-messages:pointer-events-auto group-focus-within/turn-messages:[mask-position:0_0]", "has-data-[state=open]:pointer-events-auto has-data-[state=open]:[mask-position:0_0]"], v), e[6] = s, e[7] = S, e[8] = _, e[9] = x, e[10] = f
        } else f = e[10];
        let p;
        e[13] !== r || e[14] !== f ? (p = n.jsx("div", {
            ref: o,
            className: f,
            children: r
        }), e[13] = r, e[14] = f, e[15] = p) : p = e[15];
        let T;
        return e[16] !== p || e[17] !== l ? (T = n.jsx("div", {
            className: l,
            children: p
        }), e[16] = p, e[17] = l, e[18] = T) : T = e[18], T
    },
    vd = i => {
        "use forget";
        var ms, Ss, hs, as, pe, Qe;
        const e = ss.c(106),
            {
                activeVariantIndex: t,
                clientThreadId: s,
                conversationMode: r,
                lastMessage: o,
                messages: d,
                numVariants: u,
                onChangeIndex: h,
                onRate: b,
                showCanvasButton: l,
                showCopyButton: S,
                showPagination: _,
                showPlayButton: x,
                showRatingButtons: f,
                showRegenerateButton: p,
                turn: T,
                turnIndex: v,
                parentPrompt: C,
                isAgentTurn: G,
                isKAUR1BR5: k,
                reportableMessageId: P,
                isSharedConversation: F,
                serverThreadIdForReporting: g,
                projectConversationId: O
            } = i,
            U = F === void 0 ? !1 : F,
            R = xs(),
            M = js(),
            N = xa(),
            j = ga(),
            B = Ia(rt);
        let c;
        e[0] !== R ? (c = _a(), e[0] = R, e[1] = c) : c = e[1];
        const V = c;
        let q;
        e[2] !== R ? (q = !1, e[2] = R, e[3] = q) : q = e[3];
        const H = q,
            ce = Ca(),
            X = (ms = o == null ? void 0 : o.clientMetadata) == null ? void 0 : ms.rating,
            me = (Ss = o == null ? void 0 : o.clientMetadata) == null ? void 0 : Ss.requestId;
        let K, he;
        e[4] !== s || e[5] !== R || e[6] !== U || e[7] !== (o == null ? void 0 : o.id) || e[8] !== P || e[9] !== g ? (K = Ze(s), he = Fa({
            ctx: R,
            clientThreadId: s,
            messageId: (hs = P != null ? P : o == null ? void 0 : o.id) != null ? hs : null,
            isSharedConversation: U,
            isAuthoredByCurrentUser: !1,
            serverThreadId: (as = g != null ? g : K) != null ? as : null
        }), e[4] = s, e[5] = R, e[6] = U, e[7] = o == null ? void 0 : o.id, e[8] = P, e[9] = g, e[10] = K, e[11] = he) : (K = e[10], he = e[11]);
        const {
            canReportMessage: y,
            handleReportMessage: J
        } = he, {
            imageGenMessages: W,
            enableImageGenPostSharing: w,
            enableMessageSliceSharing: ue,
            hasErrorInTurn: de,
            isIncomplete: se
        } = hr(d), Ee = pr.useSelectedIndex();
        let be;
        e[12] !== d ? (be = d.filter(pi).filter(Sd), e[12] = d, e[13] = be) : be = e[13];
        const Pe = be.length > 0,
            ie = W.length > 0,
            Is = fi(),
            _s = vi(),
            Cs = Sa();
        let ts;
        e[14] !== R ? (ts = () => bi(xi(R)), e[14] = R, e[15] = ts) : ts = e[15];
        const z = Le(ts);
        let Ne;
        e[16] !== o ? (Ne = o != null && tt.getAudioAssetPointers(o).length > 0, e[16] = o, e[17] = Ne) : Ne = e[17];
        const ke = Ne;
        let ge;
        e[18] !== (o == null ? void 0 : o.id) ? (ge = Y => _r(Y, o == null ? void 0 : o.id), e[18] = o == null ? void 0 : o.id, e[19] = ge) : ge = e[19];
        const $e = Ce(s, ge);
        let Be;
        e[20] !== ie || e[21] !== Pe || e[22] !== W ? (Be = ie && !Pe && W.some(Nn), e[20] = ie, e[21] = Pe, e[22] = W, e[23] = Be) : Be = e[23];
        const us = Be,
            ns = K != null && !de && !se && !G && V && !_s && !B && !z && !ce,
            qe = K != null && !de && !se && !G && V && !_s && !B && !$e && !Cs && !ce;
        let Ke = null;
        if (ns) {
            if (w || ue) {
                const Y = (pe = W[Ee]) == null ? void 0 : pe.id,
                    fe = C == null ? void 0 : C.id;
                let ne;
                e[24] !== s || e[25] !== d || e[26] !== Y || e[27] !== fe ? (ne = n.jsx(Id, {
                    clientThreadId: s,
                    imageGenMessageId: Y,
                    messages: d,
                    parentPromptId: fe
                }), e[24] = s, e[25] = d, e[26] = Y, e[27] = fe, e[28] = ne) : ne = e[28], Ke = ne
            } else if (Is && lt(R, "1547743984").get("show_share_button_inline", !1)) {
                let Y;
                e[29] !== K ? (Y = () => {
                    K && Ii.openSharingModal(K)
                }, e[29] = K, e[30] = Y) : Y = e[30];
                let fe;
                e[31] !== M ? (fe = M.formatMessage({
                    id: "ConversationTurn.shareButtonTooltip",
                    defaultMessage: "Share conversation"
                }), e[31] = M, e[32] = fe) : fe = e[32];
                let ne;
                e[33] !== Y || e[34] !== fe ? (ne = n.jsx(ds, {
                    onClick: Y,
                    label: fe,
                    className: "sm:hidden",
                    icon: Aa
                }), e[33] = Y, e[34] = fe, e[35] = ne) : ne = e[35], Ke = ne
            }
        }
        if (o && nt(o) && !Nn(o)) return null;
        const re = B ? "small" : "med",
            gs = !!(x && o && K && (ke || !Cs));
        let Te;
        e[36] !== t || e[37] !== u || e[38] !== h || e[39] !== _ ? (Te = _ && n.jsx(wa, {
            currentPage: t,
            onChangeIndex: h,
            length: u
        }), e[36] = t, e[37] = u, e[38] = h, e[39] = _, e[40] = Te) : Te = e[40];
        let te;
        e[41] !== re || e[42] !== s || e[43] !== R || e[44] !== us || e[45] !== j || e[46] !== S || e[47] !== N || e[48] !== v ? (te = S && !us && n.jsx(Na, {
            size: re,
            onClick: Y => {
                Ea(R, s, v, N, Y, "mouse", j)
            }
        }), e[41] = re, e[42] = s, e[43] = R, e[44] = us, e[45] = j, e[46] = S, e[47] = N, e[48] = v, e[49] = te) : te = e[49];
        let De;
        e[50] !== re || e[51] !== X || e[52] !== ie || e[53] !== M || e[54] !== b || e[55] !== f ? (De = f && !ie && n.jsxs(n.Fragment, {
            children: [X !== "thumbsDown" && n.jsx(ds, {
                size: re,
                onClick: () => b("thumbsUp"),
                selected: X === "thumbsUp",
                icon: X === "thumbsUp" ? fr : vr,
                label: M.formatMessage({
                    id: "ConversationTurn.goodResponseTooltip",
                    defaultMessage: "Good response"
                }),
                testId: "good-response-turn-action-button"
            }), X !== "thumbsUp" && n.jsx(ds, {
                size: re,
                onClick: () => b("thumbsDown"),
                selected: X === "thumbsDown",
                icon: X === "thumbsDown" ? br : xr,
                label: M.formatMessage({
                    id: "ConversationTurn.badResponseTooltip",
                    defaultMessage: "Bad response"
                }),
                testId: "bad-response-turn-action-button"
            })]
        }), e[50] = re, e[51] = X, e[52] = ie, e[53] = M, e[54] = b, e[55] = f, e[56] = De) : De = e[56];
        let Ue;
        e[57] !== o || e[58] !== O ? (Ue = !1, e[57] = o, e[58] = O, e[59] = Ue) : Ue = e[59];
        let Re;
        e[60] !== s || e[61] !== H || e[62] !== v ? (Re = !1, e[60] = s, e[61] = H, e[62] = v, e[63] = Re) : Re = e[63];
        let ye;
        e[64] !== re || e[65] !== s || e[66] !== r || e[67] !== ie || e[68] !== o || e[69] !== d || e[70] !== C || e[71] !== p ? (ye = p && o && n.jsx(xd, {
            clientThreadId: s,
            conversationMode: r,
            lastMessage: o,
            messages: d,
            hasImageGenMessage: ie,
            parentPrompt: C,
            size: re
        }), e[64] = re, e[65] = s, e[66] = r, e[67] = ie, e[68] = o, e[69] = d, e[70] = C, e[71] = p, e[72] = ye) : ye = e[72];
        let Ge;
        e[73] !== y || e[74] !== qe || e[75] !== s || e[76] !== J || e[77] !== ie || e[78] !== Pe || e[79] !== W || e[80] !== ce || e[81] !== B || e[82] !== k || e[83] !== ke || e[84] !== o || e[85] !== d || e[86] !== (C == null ? void 0 : C.id) || e[87] !== me || e[88] !== Ee || e[89] !== l || e[90] !== x || e[91] !== T || e[92] !== v ? (Ge = !B && n.jsx(Ir, {
            showPlayButton: !!(x && o && (Pe || ke)),
            showCanvasButton: !ie && l,
            showBranchButton: qe,
            canShowScheduleButton: !k && !ce,
            turnIndex: v,
            clientThreadId: s,
            messages: d,
            imageGenMessageId: (Qe = W[Ee]) == null ? void 0 : Qe.id,
            lastMessage: o,
            turn: T,
            requestId: me,
            parentPromptId: C == null ? void 0 : C.id,
            showReportMessageButton: y,
            onReportMessage: J
        }), e[73] = y, e[74] = qe, e[75] = s, e[76] = J, e[77] = ie, e[78] = Pe, e[79] = W, e[80] = ce, e[81] = B, e[82] = k, e[83] = ke, e[84] = o, e[85] = d, e[86] = C == null ? void 0 : C.id, e[87] = me, e[88] = Ee, e[89] = l, e[90] = x, e[91] = T, e[92] = v, e[93] = Ge) : Ge = e[93];
        let Me;
        return e[94] !== o || e[95] !== K || e[96] !== Ke || e[97] !== gs || e[98] !== Te || e[99] !== te || e[100] !== De || e[101] !== Ue || e[102] !== Re || e[103] !== ye || e[104] !== Ge ? (Me = n.jsxs(Cr, {
            enable: gs,
            lastMessage: o,
            serverThreadId: K,
            children: [Te, te, De, Ue, Ke, Re, ye, Ge]
        }), e[94] = o, e[95] = K, e[96] = Ke, e[97] = gs, e[98] = Te, e[99] = te, e[100] = De, e[101] = Ue, e[102] = Re, e[103] = ye, e[104] = Ge, e[105] = Me) : Me = e[105], Me
    },
    bd = i => {
        "use forget";
        const e = ss.c(35),
            {
                activeVariantIndex: t,
                clientThreadId: s,
                numVariants: r,
                onAnticipateEdit: o,
                onChangeIndex: d,
                onEnterEdit: u,
                showCopyButton: h,
                showEditMessageButton: b,
                showPagination: l,
                turnIndex: S,
                reportableMessageId: _,
                reportableMessageAuthoredByCurrentUser: x,
                isSharedConversation: f,
                serverThreadIdForReporting: p
            } = i,
            T = f === void 0 ? !1 : f,
            v = xs(),
            C = xa(),
            G = ga(),
            k = js(),
            P = x != null ? x : !1,
            F = p != null ? p : null;
        let g;
        e[0] !== s || e[1] !== v || e[2] !== T || e[3] !== _ || e[4] !== P || e[5] !== F ? (g = Fa({
            ctx: v,
            clientThreadId: s,
            messageId: _,
            isSharedConversation: T,
            isAuthoredByCurrentUser: P,
            serverThreadId: F
        }), e[0] = s, e[1] = v, e[2] = T, e[3] = _, e[4] = P, e[5] = F, e[6] = g) : g = e[6];
        const {
            canReportMessage: O,
            handleReportMessage: U
        } = g;
        let R;
        e[7] !== v ? (R = hi(v), e[7] = v, e[8] = R) : R = e[8];
        const M = R;
        let N;
        e[9] !== s || e[10] !== v || e[11] !== G || e[12] !== h || e[13] !== M || e[14] !== C || e[15] !== S ? (N = h && n.jsxs(n.Fragment, {
            children: [M && !1, n.jsx(Na, {
                onClick: q => {
                    Ea(v, s, S, C, q, "mouse", G)
                }
            })]
        }), e[9] = s, e[10] = v, e[11] = G, e[12] = h, e[13] = M, e[14] = C, e[15] = S, e[16] = N) : N = e[16];
        let j;
        e[17] !== O || e[18] !== U || e[19] !== k ? (j = O && n.jsx(ds, {
            icon: mr,
            onClick: q => {
                q.stopPropagation(), U()
            },
            label: k.formatMessage({
                id: "ConversationTurn.reportMessageTooltip",
                defaultMessage: "Report message"
            }),
            testId: "report-message-turn-action-button"
        }), e[17] = O, e[18] = U, e[19] = k, e[20] = j) : j = e[20];
        let B;
        e[21] !== o || e[22] !== u || e[23] !== b ? (B = b && n.jsx(Sr, {
            onAnticipateEdit: o,
            onEnterEdit: u
        }), e[21] = o, e[22] = u, e[23] = b, e[24] = B) : B = e[24];
        let c;
        e[25] !== t || e[26] !== r || e[27] !== d || e[28] !== l ? (c = l && n.jsx(wa, {
            currentPage: t,
            onChangeIndex: d,
            length: r
        }), e[25] = t, e[26] = r, e[27] = d, e[28] = l, e[29] = c) : c = e[29];
        let V;
        return e[30] !== N || e[31] !== j || e[32] !== B || e[33] !== c ? (V = n.jsxs(n.Fragment, {
            children: [N, j, B, c]
        }), e[30] = N, e[31] = j, e[32] = B, e[33] = c, e[34] = V) : V = e[34], V
    },
    xd = i => {
        "use forget";
        const e = ss.c(16),
            {
                clientThreadId: t,
                conversationMode: s,
                messages: r,
                hasImageGenMessage: o,
                lastMessage: d,
                parentPrompt: u,
                size: h
            } = i,
            b = h === void 0 ? "med" : h,
            l = Ci();
        let S;
        e[0] !== t || e[1] !== s ? (S = {
            clientThreadId: t,
            conversationMode: s
        }, e[0] = t, e[1] = s, e[2] = S) : S = e[2];
        const _ = _i(S),
            x = Tr(t, d),
            f = je(l, "633080887");
        let p;
        e[3] !== d || e[4] !== _ ? (p = C => {
            const {
                sourceEvent: G,
                requestedModelId: k,
                appendMessages: P,
                extraStreamParams: F
            } = C;
            d && _({
                sourceEvent: G,
                nodeId: d.id,
                requestedModelId: k,
                appendMessages: P,
                extraStreamParams: F
            })
        }, e[3] = d, e[4] = _, e[5] = p) : p = e[5];
        const T = p;
        let v;
        return e[6] !== x || e[7] !== t || e[8] !== o || e[9] !== d || e[10] !== r || e[11] !== T || e[12] !== u || e[13] !== f || e[14] !== b ? (v = o && !f ? n.jsx(pd, {
            messages: r,
            onModelSelect: T
        }) : n.jsx(Pr, {
            className: "text-token-text-secondary hover:bg-token-bg-secondary touch:px-2.5 h-[30px] rounded-md px-1.5",
            clientThreadId: t,
            lastMessage: d,
            onModelSelect: T,
            canRegenerateResponse: x,
            parentPrompt: u,
            size: b,
            hasImageGenMessage: o,
            messages: r
        }), e[6] = x, e[7] = t, e[8] = o, e[9] = d, e[10] = r, e[11] = T, e[12] = u, e[13] = f, e[14] = b, e[15] = v) : v = e[15], v
    },
    Na = i => {
        "use forget";
        const e = ss.c(10),
            {
                onClick: t,
                size: s
            } = i,
            r = s === void 0 ? "med" : s,
            [o, d] = I.useState(!1),
            u = yr(),
            h = js();
        let b;
        e[0] !== u || e[1] !== t ? (b = f => {
            f.stopPropagation(), Fe.logEvent("ChatGPT Turn Action Copy Clicked"), t(f), d(!0), setTimeout(() => {
                u() && d(!1)
            }, 2e3), Ti.logEvent("chatgpt_turn_action_copy")
        }, e[0] = u, e[1] = t, e[2] = b) : b = e[2];
        const l = b,
            S = o ? Mr : Ar;
        let _;
        e[3] !== h ? (_ = h.formatMessage({
            id: "CopyButton.copyTooltip",
            defaultMessage: "Copy"
        }), e[3] = h, e[4] = _) : _ = e[4];
        let x;
        return e[5] !== l || e[6] !== r || e[7] !== S || e[8] !== _ ? (x = n.jsx(ds, {
            icon: S,
            onClick: l,
            label: _,
            testId: "copy-turn-action-button",
            size: r
        }), e[5] = l, e[6] = r, e[7] = S, e[8] = _, e[9] = x) : x = e[9], x
    };

function Id(i) {
    "use forget";
    var P;
    const e = ss.c(21),
        {
            clientThreadId: t,
            imageGenMessageId: s,
            messages: r,
            parentPromptId: o
        } = i,
        [d, u] = I.useState(!1),
        h = js();
    let b;
    e: {
        if (s) {
            b = "media_generation";
            break e
        }
        b = "message_slice"
    }
    const l = b;
    let S;
    e[0] !== r ? (S = (P = r == null ? void 0 : r.map(Cd)) != null ? P : void 0, e[0] = r, e[1] = S) : S = e[1];
    const _ = S;
    let x;
    e[2] !== t || e[3] !== s || e[4] !== _ || e[5] !== o ? (x = {
        clientThreadId: t,
        imageGenMessageId: s,
        messageSliceIds: _,
        parentPromptId: o
    }, e[2] = t, e[3] = s, e[4] = _, e[5] = o, e[6] = x) : x = e[6];
    const f = wr(x);
    let p, T;
    e[7] !== l ? (p = () => {
        Fe.logEvent("Share Post: Share Button Shown", {
            source: "turn_action",
            attachment_type: l
        })
    }, T = [l], e[7] = l, e[8] = p, e[9] = T) : (p = e[8], T = e[9]), I.useEffect(p, T);
    let v;
    e[10] !== l || e[11] !== s || e[12] !== f ? (v = () => {
        u(!0), Er(async () => {
            await f()
        }, _d, () => {
            u(!1)
        }), Fe.logEventWithStatsig("Share Post: Share Button Clicked", "chatgpt_post_share_button_clicked", oe({
            source: "turn_action",
            attachment_type: l
        }, s ? {
            message_id: s
        } : {}))
    }, e[10] = l, e[11] = s, e[12] = f, e[13] = v) : v = e[13];
    let C;
    e[14] !== h ? (C = h.formatMessage({
        id: "ConversationTurn.sharePostButtonTooltip",
        defaultMessage: "Share"
    }), e[14] = h, e[15] = C) : C = e[15];
    const G = d ? Si : Aa;
    let k;
    return e[16] !== d || e[17] !== v || e[18] !== C || e[19] !== G ? (k = n.jsx(ds, {
        onClick: v,
        label: C,
        icon: G,
        disabled: d
    }), e[16] = d, e[17] = v, e[18] = C, e[19] = G, e[20] = k) : k = e[20], k
}

function _d() {}

function Cd(i) {
    return i.id
}

function Sd(i) {
    return i.recipient === "all"
}
const Td = ze(() => es(() =>
        import ("./kfozsua9bqnntmw9.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10])).then(i => i.MemoryActionResult)),
    yd = ze(() => es(() =>
        import ("./gh0bqurnaw4e38cn.js"), __vite__mapDeps([12, 1, 2, 3, 13, 4, 5])).then(i => i.AutomationSourceHeader)),
    ra = ze(() => es(() =>
        import ("./hdvj2l707w8wzq5m.js"), __vite__mapDeps([14, 1, 2, 3, 15, 4, 5])).then(i => i.TextMessageEditor)),
    Md = ze(() => es(() =>
        import ("./f8zwc22xu46enu24.js"), __vite__mapDeps([16, 1, 2, 3, 4, 5, 17, 18, 19, 20, 21])).then(i => i.ChatScreenRetrievalResultsFlyoutContent)),
    la = 80,
    Zs = 16;

function et() {
    return {
        minHeight: "calc(100dvh - ".concat(Wl, "px - 120px)")
    }
}

function Ad(i) {
    "use no forget";
    var Ft, Nt, Bt, Dt, Ut, Gt, Ot, Vt, Lt, Ht, Wt, zt, $t, qt, Kt, Qt, Jt, Xt, Yt, Zt, en, sn, tn, nn, an, on, rn, ln, dn, cn, un, gn, mn, hn, pn, fn, vn, bn, xn, In;
    const {
        turnIndex: e,
        isFinalTurn: t,
        conversation: s,
        onRequestCompletion: r,
        scrollToMessageId: o,
        scrollToMessageIsAssistant: d,
        dateHeaderType: u,
        hideUserActions: h,
        disableHorizontalPadding: b
    } = i, l = xs(), S = Pa(l), _ = yi(), x = Ca(), f = Ia(a => rt(a)), p = Mi(l), T = !!_ && Ai(_), v = Bn(Dn.isBusinessWorkspace), C = kr(), G = Rr(l) || C, k = jr(l), P = Fr(l), {
        eligible: F
    } = Nr(Br.hasSeenAudioParagenPrompt), [g, O, U, R] = Ce(s.id, a => {
        const m = $.getConversationTurnAtIndex(a, e),
            A = e > 0 ? $.getConversationTurnAtIndex(a, e - 1) : null,
            E = (A == null ? void 0 : A.role) === ee.User && A.messages.some(Z => {
                var Q;
                return (Q = Z.metadata) == null ? void 0 : Q.visually_hide_response_from_conversation
            });
        let ae = !1;
        if (m.role === ee.Assistant) {
            const Z = $.getConversationTurns(a);
            e + 1 < Z.length && $.getConversationTurnAtIndex(a, e + 1).isAsyncCorrection && (ae = !0)
        }
        return [m, E, A, ae]
    }, {
        disablePerfDetector: t
    }), {
        messages: M,
        messageGroups: N
    } = g, j = Dr(a => a.size === 0 ? -1 : N.findIndex(m => m.type === Xs ? m.groups.some(A => A.messages.some(E => a.has(E == null ? void 0 : E.id))) : m.messages.some(A => a.has(A == null ? void 0 : A.id)))), B = M[0], c = D(M), V = I.useMemo(() => Un(M, a => wi(a).length > 0), [M]), q = I.useMemo(() => N.some(a => a.type === Ei.SearchGPTQuery), [N]), H = I.useMemo(() => M.some(a => {
        var m;
        return (m = a.metadata) == null ? void 0 : m.n7jupd_message
    }), [M]), ce = I.useMemo(() => {
        var a, m;
        return (m = (a = D(M)) == null ? void 0 : a.metadata) == null ? void 0 : m.chatgpt_sdk_suppressed_response
    }, [M]), X = I.useMemo(() => H ? Un(M, a => a.author.name === "n7jupd.metadata") : null, [M, H]), me = !!((Ft = X == null ? void 0 : X.metadata) != null && Ft.kaur1br5_mode), K = Ce(s.id, a => !!(a != null && a.pulseCardId)), he = Le(() => ka(l).isFeedbackViewOpen$() || K && e === 1), {
        messages: y,
        visibleMessages: J,
        messageGroups: W,
        lastMessageToRender: w
    } = I.useMemo(() => {
        const a = j !== -1 && j + 1 < N.length,
            m = a ? N.slice(0, j + 1) : N,
            A = a ? m.flatMap(E => E.type === Xs ? E.groups.flatMap(ae => ae.messages) : E.messages) : M;
        return {
            messages: A,
            visibleMessages: A.filter(Pi),
            messageGroups: m,
            lastMessageToRender: D(A)
        }
    }, [M, N, j]), ue = j !== -1, de = je(l, "1887864177"), se = Ce(s.id, a => $.getLastMessageSystemHints(a)), Ee = Ce(s.id, a => {
        var m;
        return (m = a == null ? void 0 : a.hasIKConvo) != null ? m : !1
    }), be = (se == null ? void 0 : se.includes(vs.Tatertot)) && je(l, "28816792") && ki(l), {
        capabilitySuggestionsEnabled: cs
    } = Ur(be), Pe = I.useMemo(() => ({
        clientThreadId: s.id,
        turnIndex: e,
        messageId: c == null ? void 0 : c.id
    }), [s.id, e, c == null ? void 0 : c.id]), [ie, Is] = I.useState(!1), [_s, Cs] = I.useState(!1), ts = I.useContext(Gr) != null, z = g.role === ee.User, Ne = Sa(), ke = Ri(s.id), ge = (Nt = g.gizmoId) != null ? Nt : ke, $e = ji(ge).data, Be = ge && !Gn(ge) ? $e : void 0, us = Be && g.gizmoId != null && g.gizmoId !== ke && je(l, "1418300125"), ns = Le(() => Fi(s)), qe = ns.id, Ke = Ni(s.id), re = Or(ns), gs = Vr(ns, Ke), Te = Bi(l), [te, De, Ue, Re, ye, Ge, Me, ms, Ss, hs, as, pe, Qe, Y, fe, ne, L, Ba] = Ce(s.id, a => {
        var _n, Cn, Sn, Tn, yn;
        const m = $.getParentPromptNode(a, B.id),
            A = (Tn = (_n = m == null ? void 0 : m.message.clientMetadata) == null ? void 0 : _n.variantsInStreamInfo) != null ? Tn : (Cn = m == null ? void 0 : m.message.metadata) != null && Cn.paragen_variant_choice || (Sn = m == null ? void 0 : m.message.metadata) == null ? void 0 : Sn.paragen_variants_info,
            E = $.getVariantIds(a, B.id),
            ae = $.getCurrentVariantId(a, B.id),
            Z = ae ? E.indexOf(ae) : 0,
            Q = A && (a == null ? void 0 : a.tree) != null && E.some(_e => {
                var An;
                const {
                    errType: Mn
                } = (An = a.tree.getLeafFromNode(_e).message.clientMetadata) != null ? An : {};
                return Mn != null && Mn !== "info"
            }),
            le = $.getConversationTurns(a),
            we = le.findIndex(_e => _e.role === ee.Assistant),
            Qs = Hn(le, _e => _e.role === ee.Assistant),
            ni = le.slice(we, e + 1).every(_e => _e.role === ee.Assistant);
        return [m, c != null && !nr(c.id) && $.isMessageTurnEnded(a, c.id), Q, zl(a == null ? void 0 : a.mode, $e == null ? void 0 : $e.gizmo.id), le.findIndex(_e => _e.role === ee.User) === e, Hn(le, _e => _e.role === ee.User) === e, we === e, Qs === e, ni, $.getRequestId(a, c == null ? void 0 : c.id), A, E, Z, !!(a != null && a.continuingFromSharedPostId), a == null ? void 0 : a.currentLeafId, $.getSuperWidgetMessages(a, e)[0], $.lastUserMessage(a), (yn = a == null ? void 0 : a.continuingFromSharedProjectConversationId) != null ? yn : null]
    }, {
        disablePerfDetector: t
    }), Je = ya(), Ts = Le(() => {
        const a = Di(s);
        return (a == null ? void 0 : a.value) === ls.STREAMING || (a == null ? void 0 : a.value) === ls.REALTIME || (a == null ? void 0 : a.value) === ls.REALTIME_BUSY
    }), Da = y.some(a => a.content.content_type === Ui.MultimodalText), Ua = lt(l, "3119715334").get("should-enable-skip", !1), dt = !_a(), ct = g.messages.map(a => a.id), xe = I.useRef(null);
    wd({
        clientThreadId: s.id,
        turn: g,
        turnIndex: e,
        conversationTurnWrapperRef: xe
    });
    const Fs = !S && ((Bt = o == null ? void 0 : o.length) != null ? Bt : 0) > 2 && o !== "finalAgentTurn" && t,
        ve = z ? D(J) : void 0,
        Ns = ve == null ? void 0 : ve.id,
        Ga = I.useCallback(() => {
            Ns && (Fe.logEvent("Edit Prompt", {
                id: Ns,
                threadId: Ze(s.id)
            }), Rs(l, "chatgpt_edit_prompt"), Is(!0))
        }, [l, Ns, s.id]),
        Oa = I.useCallback(() => {
            Is(!1)
        }, []),
        {
            onChangeRating: Va
        } = Lr({
            clientThreadId: s.id,
            currentModelConfig: ns
        }),
        La = a => {
            var ae;
            if (!c) return;
            const m = (ae = c.clientMetadata) == null ? void 0 : ae.rating,
                E = (m === "thumbs_up" ? "thumbsUp" : m === "thumbs_down" ? "thumbsDown" : m) === a ? null : a;
            if (Va({
                    nodeId: c.id,
                    messageId: c.id,
                    rating: E
                }), E) {
                const Z = er(() => sr(l)),
                    Q = Z && N.some(le => {
                        var we;
                        return le.type !== Xs && ((we = le.messages) == null ? void 0 : we.some(tr))
                    });
                Fe.logEventWithStatsig(E === "thumbsDown" ? "Message Feedback Thumbs Down Clicked" : "Message Feedback Thumbs Up Clicked", "chatgpt_thumb_feedback", oe(oe({
                    id: c.id,
                    threadId: Ze(s.id),
                    model: qe,
                    rating: E
                }, Z ? {
                    isCATriggered: Q
                } : {}), f ? {
                    isSidebar: !0
                } : {}))
            }
            Cs(E === "thumbsDown")
        },
        [Ha] = I.useState(() => Date.now()),
        Ae = Gi(s.id),
        Wa = Ae != null ? Ae : null,
        ut = (Ut = Ae != null ? Ae : Ba) != null ? Ut : Je && (Dt = s.sharedConversationId) != null ? Dt : null,
        Bs = (Gt = Hr(s.id)) == null ? void 0 : Gt.value,
        gt = Bs === ls.STREAMING,
        za = Bs === ls.REALTIME || Bs === ls.REALTIME_BUSY,
        $a = hs != null,
        qa = ha(hs),
        Ka = $n.useState(a => $n.isReplayInProgress(a, fe)),
        Ie = !De && qa || ue || gt || za || Ka && t || M.some(a => Wr(a)),
        Qa = pa(),
        Ds = I.useRef(!1),
        mt = I.useRef(void 0),
        Ja = Oi({
            clientThreadId: s.id
        }),
        Xa = zr(s.id, c) && !Ja && !!Ae,
        [, Ya] = li(),
        {
            isOpen: ys
        } = at(),
        ht = Ma(),
        os = D(U == null ? void 0 : U.messages.filter(Vi)),
        pt = Le(() => Li(l)),
        Us = $r({
            conversation: s,
            threadContent: (Ot = ne == null ? void 0 : ne.content) != null ? Ot : null,
            query: os ? Ys(os) : null,
            triggeredSearch: q,
            messageGroups: W,
            allMessages: M,
            isAdultSearchEnabled: pt
        }),
        {
            isClassifiedAdult: ft,
            isSafeSearchOff: Za
        } = Us,
        [eo, Gs] = Le(() => [Hi(l) && Me && (!se || se.length === 0 || se.includes(vs.Search)) && !ft, p && g.role === ee.Assistant && ft && Za && pt]),
        Xe = (eo || Gs) && Us.showNavlinksWidget,
        Os = y.filter(On),
        so = Xe && Os.length === 0 && !H,
        vt = ((Vt = L == null ? void 0 : L.author.metadata) == null ? void 0 : Vt.real_author) === "onboarding";
    I.useEffect(() => {
        const m = new URLSearchParams(window.location.search).get("message");
        !(m != null && ct.includes(m)) || !xe.current || (xe.current.scrollIntoView({
            behavior: "instant"
        }), Ya(E => (E.delete("message"), E), {
            replace: !0,
            preventScrollReset: !0
        }))
    }, []), I.useEffect(() => {
        o !== mt.current && (Ds.current = !1, mt.current = o)
    }, [o]), I.useEffect(() => {
        if (S) return;
        const A = new URLSearchParams(window.location.search).get("message") != null;
        if (Ds.current || A || o === void 0 || !xe.current || ht || vt || p && Me) {
            o === "finalAgentTurn" && t && We(s.id, E => {
                E.scrollToMessageId = void 0
            });
            return
        }(ct.includes(o) || o === "finalAgentTurn" && t) && (Ds.current = !0, requestAnimationFrame(() => {
            requestAnimationFrame(() => {
                var E, ae;
                if (xe.current)
                    if (o === "finalAgentTurn" && t) {
                        const Z = bs(s.id),
                            Q = (E = Z == null ? void 0 : Z.tree.getNodeIfExists(Z.currentLeafId)) == null ? void 0 : E.message,
                            we = !!((Q == null ? void 0 : Q.channel) == "final" && ((ae = Q.metadata) != null && ae.mercury_message)) ? "start" : "end";
                        xe.current.scrollIntoView({
                            behavior: "instant",
                            block: we
                        }), We(s.id, Qs => {
                            Qs.scrollToMessageId = void 0
                        })
                    } else {
                        const Z = xe.current.offsetHeight;
                        let Q = 0;
                        ys ? Q = -8 : p ? Q = -1 * Zs : d ? Q = -8 : Z > la && (Q = la - Z);
                        const le = qr(s).pinnedWidgetHeight$();
                        le != null && (Q += le + Zs), xe.current.style.scrollMarginTop = "".concat(Q + Zs, "px"), xe.current.scrollIntoView({
                            behavior: "smooth"
                        })
                    }
            })
        }))
    }, [o, d, xe.current, ys, ht, vt, p, Me]);
    const {
        showDebugConversationTurns: to
    } = va(), no = !Je && !Y && !Ne && !z, ao = (w == null ? void 0 : w.author.role) === ee.Assistant ? w : null, oo = (Ht = (Lt = w == null ? void 0 : w.metadata) == null ? void 0 : Lt.system_hints) == null ? void 0 : Ht.includes(vs.Research), io = (zt = (Wt = w == null ? void 0 : w.metadata) == null ? void 0 : Wt.system_hints) == null ? void 0 : zt.includes(vs.Agent);
    Kr({
        isCompletionRequestInProgress: Ie,
        isUserTurn: z,
        message: ao
    });
    const {
        isOpen: ro
    } = at(), lo = Qr(l), Ms = Jr(Re), co = Wi(a => a.voiceFeedbackThread), bt = Ae === co, uo = ($t = c == null ? void 0 : c.metadata) == null ? void 0 : $t.async_source, As = t && $a, Oe = Ts || Ie || gt, go = J.length === 0 && y.some(zi), mo = ((qt = Xr(J)) == null ? void 0 : qt.author.name) === Vn.A8KM123 && Yr(J, a => a.author.name === Vn.A8KM123 || a.channel === "commentary" || a.author.role === ee.Developer), ho = Zr.useIsMultigenParagenVotingActive(), po = I.useMemo(() => y.some(a => {
        var m, A, E;
        return a.author.name === "api_tool.call_tool" && ((E = (A = (m = a.metadata) == null ? void 0 : m.chatgpt_sdk) == null ? void 0 : A.resource_name) == null ? void 0 : E.includes("cocoon"))
    }), [y]), Vs = !ie && !po && !y.every($i) && !Je && !Y && !Ms && !ro && g.role !== ee.Developer && !(g.role === ee.User && h) && !(t && bt && Oe) && !(As && Oe) && !(t && Ts && uo) && !(Oe && H) && !(mo && !t) && !((Kt = c == null ? void 0 : c.metadata) != null && Kt.is_auto_proceed_message) && !((Qt = c == null ? void 0 : c.metadata) != null && Qt.is_takeover_ended_message) && !((Jt = c == null ? void 0 : c.metadata) != null && Jt.disable_turn_actions) && !((Xt = c == null ? void 0 : c.clientMetadata) != null && Xt.isOptimisticPlaceholder) && !so && !g.userContinuationSuccessorTurnId && !ce && !ho, fo = !Vs && !(As && Oe) && (Je || Y) && !f, vo = y.some(a => qi(a) === Ki.l1239dk1), Ls = Ce(s.id, a => {
        var E, ae;
        const m = new Set,
            A = $.getParentPromptNode(a, B.id);
        return (ae = (E = A == null ? void 0 : A.message.metadata) == null ? void 0 : E.attachments) == null || ae.forEach(Z => {
            var Q, le, we;
            (Q = Z.mime_type) != null && Q.startsWith("image/") || m.add((we = (le = Z.context_connector_info) == null ? void 0 : le.context_connector) != null ? we : "file")
        }), m
    }), Hs = Qi(), Ws = Ln(l, "110789670");
    let Ye;
    Hs.isLoading ? Ye = void 0 : Hs.canUpgradeGDrive && Ls.has(ks.GDRIVE) && Ws.get("enabled", !1) ? Ye = ks.GDRIVE : Hs.canUpgradeSharepoint && Ls.has(ks.O365_BUSINESS) && Ws.get("enabled", !1) ? Ye = ks.O365_BUSINESS : Ls.has("file") && Ws.get("enabled", !1) && (Ye = "general");
    const bo = (w == null ? void 0 : w.author.role) === ee.Assistant && ((en = (Zt = (Yt = w == null ? void 0 : w.metadata) == null ? void 0 : Yt.content_references) == null ? void 0 : Zt.length) != null ? en : 0) > 0 || Ee,
        xo = As && !Ie && !f && !Je && !Y && !vo && (de || el(l) || cs || be || !!Ye),
        ps = c != null && (!v || gs || T || Te) && !Ms && !dt && !Ne && !((sn = c.metadata) != null && sn.b1de6e2_s),
        xt = Ts || Ie,
        [Io, _o] = I.useState(!1),
        Co = !!((tn = L == null ? void 0 : L.metadata) != null && tn.dictation && ((nn = L == null ? void 0 : L.metadata) != null && nn.dictation_asset_pointer) && !((an = L == null ? void 0 : L.metadata) != null && an.dictation_edited)),
        So = !!(!F || Io || (on = L == null ? void 0 : L.metadata) != null && on.audio_paragen_result || qn(L == null ? void 0 : L.id)),
        It = Co && !So,
        _t = It && (!v || Te) && ps && !xt && !f && !ys && L != null && Me && je(l, "51772912"),
        To = sl(L == null ? void 0 : L.id, _t),
        Ct = _t && To,
        fs = !Ms && no && t && (as == null ? void 0 : as.num_variants_in_stream) === 2 && pe.length <= 2 && !((rn = c == null ? void 0 : c.clientMetadata) != null && rn.inlineComparisonRating) && !Ue && !It && !qn(L == null ? void 0 : L.id),
        yo = !Ct && (!v || Te) && ps && (As || t && bt) && !xt && !f && !ys && !H && !ce,
        St = !((Ie || Ts) && t) && pe.length > 1 && !fs,
        Tt = z && y.some(a => {
            var m;
            return (m = Kn(a)) == null ? void 0 : m.shouldHideContent
        }),
        Mo = z && ve != null && !((ln = ve == null ? void 0 : ve.metadata) != null && ln.async_task_id) && Ae != null && !Ms && !Da && !Tt && !dt && !oo && !io && !f,
        Ao = c != null && tt.getAudioAssetPointers(c).length > 0,
        wo = c != null && ((cn = (dn = c.clientMetadata) == null ? void 0 : dn.disclaimers) != null ? cn : []).length === 0 && !f && (!Ne || Ao) && !x,
        yt = I.useCallback(a => {
            var m;
            We(s.id, A => {
                it.setCurrentBranch(A, pe[a])
            }), Fe.logEvent("Change Active Node", {
                intent: "toggle_between"
            }), je(l, "4126691920") && tl({
                parent_prompt_id: (m = te == null ? void 0 : te.id) != null ? m : "",
                prev_branch_id: pe[Qe],
                next_branch_id: pe[a]
            }, Ze(s.id))
        }, [s.id, pe, Qe, te == null ? void 0 : te.id, l]),
        Eo = Bn(Dn.accountUserId),
        ws = Ce(s.id, a => a == null ? void 0 : a.sharedProjectConversationOwner),
        Po = !Ji(l, ge) || (ws == null ? void 0 : ws.id) != null && ws.id === Eo,
        Mt = nl(g, y, to),
        At = H && al(y, t),
        Es = c == null ? void 0 : c.id,
        zs = I.useCallback(() => {
            Es && ol(s, {
                type: "retrievalResults",
                turnIndex: e,
                messageId: Es
            })
        }, [s, Es, e]),
        is = y.some(a => {
            var m, A, E;
            return ((m = a == null ? void 0 : a.metadata) == null ? void 0 : m.api_tool_type) === "glaux" || Xi({
                id: (E = (A = a == null ? void 0 : a.metadata) == null ? void 0 : A.model_slug) != null ? E : ""
            }, l)
        }),
        $s = I.useMemo(() => il(g, re, ge), [g, re, ge]),
        ko = I.useMemo(() => $s && !is, [$s, is]),
        Ro = I.useMemo(() => rl(g, ge, k), [k, ge, g]),
        wt = je(l, "2137702454"),
        jo = I.useMemo(() => g.role !== ee.User && re && wt && !is, [g, re, wt, is]),
        Fo = Yi() && CSS.supports("content-visibility: auto") && !z && Ln(l, "1011775750").get("enabled", !1) && (o == null || o === "finalAgentTurn") && !ll(y),
        No = I.useMemo(() => y.some(a => {
            var m;
            return ((m = Kn(a)) == null ? void 0 : m.canRetry) === !1
        }), [y]),
        Bo = (un = c == null ? void 0 : c.metadata) == null ? void 0 : un.n7jupd_button_type,
        Do = H && c != null && c.id != null && !Bo,
        Uo = H && t && Oe,
        Go = H && t;
    if (!Mt && !fs && !Xe) return Fs ? n.jsx("div", {
        style: et()
    }) : null;
    if (At || O) return null;
    const Oo = (gn = w == null ? void 0 : w.metadata) != null && gn.followup_prompts ? w.metadata.followup_prompts.map(a => ({
            text: a,
            type: dl.Reply
        })) : [],
        Vo = (mn = w == null ? void 0 : w.metadata) == null ? void 0 : mn.category_suggestions,
        Lo = (hn = w == null ? void 0 : w.metadata) == null ? void 0 : hn.action_suggestions,
        Ho = !y.some(a => tt.getAudioAssetPointers(a).length > 0) && (!ke || Gn(ke)) && !No && !x && !he && !!Ae,
        Wo = !Ie && y.some(a => {
            var m, A;
            return a.author.role === ee.Assistant && ((A = (m = a.metadata) == null ? void 0 : m.onboarding) == null ? void 0 : A.main_usages)
        });
    te == null || te.message.id;
    const qs = y.find(a => {
            var m, A;
            return !!((A = (m = a.metadata) == null ? void 0 : m.onboarding) != null && A.examples)
        }),
        Ks = (fn = (pn = qs == null ? void 0 : qs.metadata) == null ? void 0 : pn.onboarding) == null ? void 0 : fn.examples,
        Et = !Tt && (!t || !Ie);
    if (!t && Os.length === 0 && !H && !Xe) return null;
    let rs = "none";
    z && ye && (rs = "first");
    const zo = U == null ? void 0 : U.messages.some(On);
    if (z && !ye && (zo ? rs = "large" : rs = "none"), R && (rs = "large-bottom"), t && (rs = "last"), !Mt && !fs && !Xe) return Fs ? n.jsx("div", {
        style: et()
    }) : null;
    if (At || O) return null;
    const Pt = p ? cl(M) : void 0;
    if (!t && Os.length === 0 && !H && !Xe) return null;
    const $o = (() => {
            if (g.userContinuationSuccessorTurnId) return "mb-1";
            if (z && !Vs && !f) return "mb-10";
            if (!z && f && t) return "pb-[40px]"
        })(),
        kt = ul(M),
        qo = gl(M),
        Ko = ml(M),
        Qo = M.some(hl),
        Jo = M.some(pl),
        Xo = M.some(fl),
        Yo = !!kt,
        Rt = ms && Qo && !Xo,
        jt = Rt && !Jo && !Yo,
        Zo = Rt && !!kt,
        ei = je(l, "1480635292"),
        si = jt && ei && Ko.length > 0,
        ti = jt && qo.length > 0 || Zo;
    return n.jsx(vl.Provider, {
        value: Me,
        children: n.jsxs(bl, {
            children: [n.jsx(xl, {
                dateHeaderType: u,
                turn: g
            }), n.jsxs("article", {
                className: Se("text-token-text-primary w-full focus:outline-none", "[--shadow-height:45px] has-data-writing-block:pointer-events-none has-data-writing-block:-mt-(--shadow-height) has-data-writing-block:pt-(--shadow-height) [&:has([data-writing-block])>*]:pointer-events-auto", Fo && "[content-visibility:auto] supports-[content-visibility:auto]:[contain-intrinsic-size:auto_100lvh]", !S && o === "finalAgentTurn" ? "opacity-0" : "", {
                    hidden: ts && ye
                }, z ? "scroll-mt-(--header-height)" : "scroll-mt-[calc(var(--header-height)+min(200px,max(70px,20svh)))]"),
                tabIndex: -1,
                style: Fs ? et() : void 0,
                ref: xe,
                dir: "auto",
                "data-turn-id": g.id,
                "data-testid": "conversation-turn-".concat(e),
                "data-scroll-anchor": !S && t,
                "data-turn": z ? "user" : "assistant",
                children: [n.jsx(Il, {
                    role: g.role,
                    gizmo: Be
                }), n.jsx(_l, {
                    role: g.role,
                    children: n.jsxs(Cl, {
                        horizontalPadding: fs || b ? "none" : "standard",
                        verticalPadding: rs,
                        children: [fs ? n.jsxs(n.Fragment, {
                            children: [n.jsx(gd, oe({
                                isFeedbackEnabled: ps,
                                variantIds: pe,
                                conversationTurnMountTime: Ha,
                                currentModelId: qe
                            }, i)), Ua && n.jsx("div", {
                                className: "mt-4 flex w-full justify-center",
                                children: n.jsxs(fa, {
                                    color: "secondary",
                                    className: "text-token-text-primary",
                                    "data-testid": "paragen-skip-button",
                                    onClick: () => {
                                        ba.publish({
                                            kind: "requestCompletion",
                                            isForSkippingParagen: !0
                                        })
                                    },
                                    children: [n.jsx(Sl, {
                                        className: "text-token-text-secondary me-1"
                                    }), n.jsx(He, {
                                        id: "IuTr+b",
                                        defaultMessage: "Skip"
                                    })]
                                })
                            })]
                        }) : n.jsxs(Ra, {
                            tabIndex: -1,
                            className: Se("group/turn-messages focus-visible:outline-hidden", Xe && "super-widget-visible", $o, Ol({
                                isUserTurn: z
                            })),
                            children: [us && n.jsx(Tl, {
                                gizmo: Be
                            }), Xe && n.jsx(yl, {
                                clientThreadId: s.id,
                                query: os ? Ys(os) : null,
                                state: Us,
                                isAssistantResponseSuppressed: !!Gs
                            }), jo && n.jsx(Ml, {
                                handleShowRetrievalResults: zs,
                                clientThreadId: s.id,
                                turnIndex: e,
                                responseComplete: !Oe,
                                className: "mb-6"
                            }), !z && n.jsx(Td, {
                                messages: y,
                                clientThreadId: s.id,
                                gizmoResource: $e
                            }), y.some(a => {
                                var m, A, E;
                                return (E = (m = a.metadata) == null ? void 0 : m.async_completion_id) != null ? E : z && ((A = a.metadata) == null ? void 0 : A.async_task_title)
                            }) && n.jsx(Al, {
                                message: y.find(a => {
                                    var m, A, E;
                                    return (E = (m = a.metadata) == null ? void 0 : m.async_completion_id) != null ? E : z && a.author.role === ee.User && ((A = a.metadata) == null ? void 0 : A.async_task_title)
                                }),
                                clientThreadId: s.id,
                                isUserTurn: z
                            }), lo && z && n.jsx(yd, {
                                clientThreadId: s.id,
                                messages: y
                            }), ie && ve ? n.jsx(ra, {
                                message: ve,
                                clientThreadId: s.id,
                                onRequestCompletion: r,
                                onExitEdit: Oa,
                                disabled: !1
                            }) : !Gs && n.jsx(ot, Ve(oe({
                                allMessages: M,
                                groupedMessagesToRender: W,
                                allGroupedMessages: N
                            }, i), {
                                isUserTurn: z,
                                isFinalUserTurn: Ge,
                                isFinalAssistantTurn: ms,
                                isWithinFirstAssistantTurns: Ss,
                                isCompletionRequestInProgress: Ie,
                                isFeedbackEnabled: ps,
                                isFinalTurn: t,
                                isGlauxTurn: is,
                                hasActiveRequest: Qa,
                                isAgentTurn: H,
                                isAsyncCorrectionTurn: g.isAsyncCorrection,
                                isKAUR1BR5: me,
                                query: os ? Ys(os) : null,
                                wasInterrupted: go,
                                superWidgetContent: (vn = ne == null ? void 0 : ne.content) != null ? vn : null,
                                lastAgentMetadataNode: X,
                                hasSearchSystemHint: (bn = se == null ? void 0 : se.includes(vs.Search)) != null ? bn : !1
                            })), ko && (G && Ro ? n.jsx(Md, {
                                turnIndex: e,
                                clientThreadId: s.id,
                                variant: "bottom"
                            }) : n.jsx(Qn, {
                                handleShowRetrievalResults: zs,
                                clientThreadId: s.id,
                                turnIndex: e,
                                responseComplete: !Oe
                            })), Do && n.jsx(wl, {
                                message: c,
                                clientThreadId: s.id,
                                turnIndex: e,
                                referenceMessageId: c.id,
                                responseComplete: !t || !Ie
                            }), Wo && n.jsx(El, {
                                clientThreadId: s.id
                            }), Ks && Ks.length > 0 && !Ie && n.jsx(Pl, {
                                clientThreadId: s.id,
                                examples: Ks
                            }), Pt && n.jsx(kl, {
                                message: Pt,
                                className: "mt-4"
                            }), Vs && n.jsx(fd, {
                                isUserTurn: z,
                                alwaysShow: !0,
                                children: z ? f ? null : n.jsx(bd, {
                                    activeVariantIndex: Qe,
                                    clientThreadId: s.id,
                                    numVariants: pe.length,
                                    onAnticipateEdit: ra.prefetch,
                                    onChangeIndex: yt,
                                    onEnterEdit: Ga,
                                    showCopyButton: Et,
                                    showEditMessageButton: Mo,
                                    showPagination: St,
                                    turnIndex: e,
                                    reportableMessageId: (xn = ve == null ? void 0 : ve.id) != null ? xn : null,
                                    reportableMessageAuthoredByCurrentUser: Po,
                                    isSharedConversation: Je,
                                    serverThreadIdForReporting: ut
                                }) : n.jsxs(n.Fragment, {
                                    children: [n.jsx(vd, {
                                        activeVariantIndex: Qe,
                                        clientThreadId: s.id,
                                        conversationMode: Re,
                                        lastMessage: c,
                                        messages: y,
                                        numVariants: pe.length,
                                        onChangeIndex: yt,
                                        onRate: La,
                                        showCanvasButton: Xa,
                                        showCopyButton: Et,
                                        showPagination: St,
                                        showPlayButton: wo,
                                        showRatingButtons: ps,
                                        showRegenerateButton: Ho,
                                        turn: g,
                                        turnIndex: e,
                                        parentPrompt: te,
                                        isAgentTurn: H,
                                        isKAUR1BR5: me,
                                        reportableMessageId: (In = c == null ? void 0 : c.id) != null ? In : null,
                                        isSharedConversation: Je,
                                        serverThreadIdForReporting: ut,
                                        projectConversationId: Wa
                                    }), is && $s ? n.jsx(Qn, {
                                        handleShowRetrievalResults: zs,
                                        clientThreadId: s.id,
                                        turnIndex: e,
                                        responseComplete: !Oe
                                    }) : n.jsx(n.Fragment, {
                                        children: !P && n.jsx(Jn, {
                                            clientThreadId: s.id,
                                            message: V != null ? V : c,
                                            turnIndex: e,
                                            isAgentTurn: H
                                        })
                                    }), !1, si && n.jsx(Rl, {
                                        conversation: s,
                                        messages: M
                                    })]
                                })
                            }), ti && n.jsx(jl, {
                                isCompletionRequestInProgress: Ie,
                                conversation: s,
                                messages: M
                            }), Uo && n.jsx(Fl, {
                                clientThreadId: s.id
                            }), Go && n.jsx(Nl, {
                                clientThreadId: s.id,
                                messages: y
                            }), fo && n.jsx(Jn, {
                                clientThreadId: s.id,
                                message: V != null ? V : c,
                                turnIndex: e,
                                isAgentTurn: H
                            }), !1, yo && n.jsx(Bl, {
                                canShowInlineMessageFeedback: _s,
                                clientThreadId: s.id,
                                messageForRating: c,
                                allGroupedMessages: N,
                                currentModelId: qe
                            }), n.jsx(Zi, {
                                mode: "wait",
                                children: Ct && n.jsx(Dl, {
                                    lastUserMessageId: L.id,
                                    setIsDismissed: _o
                                })
                            }), xo && (Ye ? n.jsx(Ul, {
                                clientThreadId: s.id,
                                connectorToUpsell: Ye,
                                analyticsMetadata: Pe
                            }) : n.jsx(Gl, {
                                followups: Oo,
                                actionSuggestions: Lo,
                                categorySuggestions: Vo,
                                clientThreadId: s.id,
                                lastMessageId: Es,
                                analyticsMetadata: Pe,
                                isTatertotFollowupsEnabled: be,
                                shouldHideFollowups: bo
                            }))]
                        }), n.jsx(Vl, {
                            clientThreadId: s.id,
                            turn: g,
                            isFinalTurn: t
                        }), n.jsx(Ll, {
                            clientThreadId: s.id,
                            turn: g
                        })]
                    })
                })]
            })]
        })
    })
}
const wd = ({
        clientThreadId: i,
        turn: e,
        turnIndex: t,
        conversationTurnWrapperRef: s
    }) => {
        const r = Hl();
        I.useEffect(() => {
            if (!r) return;
            const o = new IntersectionObserver(d => {
                d.forEach(u => {
                    u.isIntersecting ? We(i, h => {
                        var b;
                        h.turnIdsInViewpoint = [...(b = h.turnIdsInViewpoint) != null ? b : [], {
                            turnId: e.id,
                            turnIndex: t,
                            role: e.role
                        }]
                    }) : We(i, h => {
                        var b;
                        h.turnIdsInViewpoint = (b = h.turnIdsInViewpoint) == null ? void 0 : b.filter(({
                            turnId: l
                        }) => l !== e.id)
                    })
                })
            }, {
                root: null,
                threshold: .1
            });
            return s.current && o.observe(s.current), () => {
                We(i, d => {
                    var u;
                    d.turnIdsInViewpoint = (u = d.turnIdsInViewpoint) == null ? void 0 : u.filter(({
                        turnId: h
                    }) => h !== e.id)
                }), o.disconnect()
            }
        }, [i, s, r, e.id, e.role, t])
    },
    Ed = ri.memo(Ad),
    Pd = I.memo(function(e) {
        "use forget";
        const t = ss.c(22),
            {
                conversation: s,
                onRequestCompletion: r,
                disableScrollToMessage: o,
                hideUserActions: d,
                disableHorizontalPadding: u
            } = e;
        let h;
        t[0] !== o ? (h = p => [$.getConversationTurnIds(p), o || p == null ? void 0 : p.scrollToMessageId, o || p == null ? void 0 : p.scrollToMessageIsAssistant], t[0] = o, t[1] = h) : h = t[1];
        const [b, l, S] = Ce(s.id, h), _ = $l(s.id);
        let x;
        if (t[2] !== s || t[3] !== b || t[4] !== u || t[5] !== _ || t[6] !== d || t[7] !== r || t[8] !== l || t[9] !== S) {
            let p;
            t[11] !== s || t[12] !== b.length || t[13] !== u || t[14] !== _ || t[15] !== d || t[16] !== r || t[17] !== l || t[18] !== S ? (p = (T, v) => n.jsx(Ed, {
                isFinalTurn: v === b.length - 1,
                turnIndex: v,
                conversation: s,
                onRequestCompletion: r,
                scrollToMessageId: l,
                scrollToMessageIsAssistant: S,
                dateHeaderType: _(v),
                hideUserActions: d,
                disableHorizontalPadding: u
            }, T), t[11] = s, t[12] = b.length, t[13] = u, t[14] = _, t[15] = d, t[16] = r, t[17] = l, t[18] = S, t[19] = p) : p = t[19], x = b.map(p), t[2] = s, t[3] = b, t[4] = u, t[5] = _, t[6] = d, t[7] = r, t[8] = l, t[9] = S, t[10] = x
        } else x = t[10];
        let f;
        return t[20] !== x ? (f = n.jsx(n.Fragment, {
            children: x
        }), t[20] = x, t[21] = f) : f = t[21], f
    }),
    da = ze(() => es(() =>
        import ("./v9p9lvhz45nq9ivc.js"), __vite__mapDeps([11, 1, 2, 3, 4, 5])).then(i => i.ThreadReportConversationModal));

function $d(i) {
    const {
        prefetchNavlink: e,
        clearPrefetchNavlink: t,
        conversation: s,
        pageLoadSearchQuery: r
    } = i, o = xs(), d = Pa(o), u = ql(s.id), h = Kl(), b = Ql(), [l, S] = Le(() => [ar(o), rt(o)]), [_] = Jl(), {
        isOpen: x
    } = at(), f = b.store.useContentAreaDimensions(Xl.Header, C => C != null && C.height ? C.height : void 0);
    let p = null;
    f || (p = !d && x ? "max-sm:pb-25" : "pb-25", l ? p = _ === Yl.Chat ? "pb-12" : "pb-13" : S && (p = "pb-0"));
    let T = n.jsx(kd, oe({
        isNewScrollEnabled: d
    }, i));
    const v = Zl();
    return v && (T = n.jsx(sd, {
        conversation: s,
        children: T
    })), T = n.jsx(ed, {
        clientThreadId: s.id,
        children: T
    }), n.jsxs("div", {
        onCopy: u,
        className: Se("flex flex-col text-sm", v && "pt-4", h && "keyboard-open:pb-[calc(var(--composer-height,100px)+var(--screen-keyboard-height,0))]", p),
        style: {
            paddingBottom: f
        },
        children: [r && n.jsx("div", {
            children: n.jsx(cd, {
                query: r
            })
        }), e ? n.jsx(or, {
            name: "prefetch-navlink",
            onError: C => {
                st.addError("Error with prefetch navlink", {
                    error: C
                }), t()
            },
            children: n.jsx(I.Suspense, {
                fallback: null,
                children: n.jsx(ud, {
                    clientThreadId: s.id,
                    prefetchNavlink: e,
                    clearPrefetchNavlink: t
                })
            })
        }) : null, n.jsx(ir, {
            children: T
        })]
    })
}

function kd({
    onRequestCompletion: i,
    conversation: e,
    scrollContainerRef: t,
    isNewScrollEnabled: s = !1
}) {
    var C, G, k, P, F;
    const r = xs(),
        [o, d, u] = Ce(e.id, g => [g == null ? void 0 : g.pulseCardId, $.hasUserMessage(g), $.isMessageTurnEnded(g)]),
        h = ka(r),
        b = Le(() => td(r) && h.isCardViewOpen$()),
        {
            data: l
        } = nd(o),
        S = o != null && !d,
        _ = ya(),
        x = Ma(),
        f = rr();
    ad({
        isSharedConversation: _,
        clientThreadId: e.id
    }), I.useEffect(() => {
        _ && (Rs(r, "chatgpt_continue_conversation_page_loaded"), Fe.logEvent("Continue Conversation: Page Loaded"), Rs(r, "chatgpt_conversation_share_page_loaded"), Fe.logEvent("Share Public Chat: Shared Conversation Loaded"))
    }, [r, _]);
    const [p, T] = I.useState(!1), v = x && !f;
    return n.jsxs(n.Fragment, {
        children: [v && n.jsx(dd, {}), _ && n.jsxs(n.Fragment, {
            children: [n.jsx(Ra, {
                children: n.jsx("p", {
                    className: "text-xs text-gray-500",
                    children: n.jsx(He, {
                        id: "threadLayout.sharedConversationCopyDisclaimer",
                        defaultMessage: "This is a copy of a conversation between ChatGPT & Anonymous."
                    })
                })
            }), n.jsx("div", {
                className: "text-token-text-primary mb-5 text-center text-xs font-semibold",
                children: n.jsx("button", {
                    onPointerOver: () => da.prefetch(),
                    onClick: () => {
                        Ta(r, da, {
                            clientThreadId: e.id,
                            serverThreadId: e.sharedConversationId,
                            isSharedConversation: !0,
                            isStaticSharedThread: !1
                        }), Rs(r, "chatgpt_conversation_share_report_content_clicked", void 0, {
                            location: "Static Shared Thread Page"
                        }), Fe.logEvent("Share Public Chat: Report Content Clicked", {
                            location: "Dynamic Shared Thread Page"
                        })
                    },
                    children: n.jsx(He, {
                        id: "thread.reportSharedConversation",
                        defaultMessage: "Report conversation"
                    })
                })
            })]
        }), l && n.jsx(od, {
            imageSrc: (G = (C = l.image) == null ? void 0 : C.url) != null ? G : "",
            fallbackSrc: (P = (k = l.image) == null ? void 0 : k.fallback_url) != null ? P : "",
            title: (F = l.title) != null ? F : "",
            cardId: o,
            hideImage: id(l) === "light"
        }), n.jsx(rd, {
            children: n.jsx(Pd, {
                conversation: e,
                onRequestCompletion: i,
                disableScrollToMessage: s || S
            })
        }), !s && n.jsxs(n.Fragment, {
            children: [b && (t == null ? void 0 : t.current) && n.jsx(lr, {
                setIsScrolledToEdge: g => {
                    T(!g)
                },
                options: {
                    root: t.current,
                    threshold: 0,
                    rootMargin: "-30px 0px"
                }
            }, "pulseCardModalEdgeScrollObserver"), b && n.jsx(ld, {
                show: p && u
            })]
        })]
    })
}
export {
    Na as C, $d as T, Pd as a
};
//# sourceMappingURL=omy347b79inqzbaj.js.map