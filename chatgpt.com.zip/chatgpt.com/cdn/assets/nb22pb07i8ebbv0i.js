import {
    B as v,
    T as Gi,
    C as Xi,
    I as Wi,
    a as l,
    b as N,
    c as A,
    F as O,
    d as Zi,
    e as Ki,
    L as B,
    P as zi
} from "./f96c6fguu1kcw0go.js";
var lo = (i => (i[i.CELL_DATA_TYPE_UNSPECIFIED = 0] = "CELL_DATA_TYPE_UNSPECIFIED", i[i.CELL_DATA_TYPE_SHARED_STRING = 1] = "CELL_DATA_TYPE_SHARED_STRING", i[i.CELL_DATA_TYPE_INLINE_STRING = 2] = "CELL_DATA_TYPE_INLINE_STRING", i[i.CELL_DATA_TYPE_STRING = 3] = "CELL_DATA_TYPE_STRING", i[i.CELL_DATA_TYPE_BOOLEAN = 4] = "CELL_DATA_TYPE_BOOLEAN", i[i.CELL_DATA_TYPE_NUMBER = 5] = "CELL_DATA_TYPE_NUMBER", i[i.CELL_DATA_TYPE_ERROR = 6] = "CELL_DATA_TYPE_ERROR", i[i.CELL_DATA_TYPE_DATE = 7] = "CELL_DATA_TYPE_DATE", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(lo || {});

function uo(i) {
    switch (i) {
        case 0:
        case "CELL_DATA_TYPE_UNSPECIFIED":
            return 0;
        case 1:
        case "CELL_DATA_TYPE_SHARED_STRING":
            return 1;
        case 2:
        case "CELL_DATA_TYPE_INLINE_STRING":
            return 2;
        case 3:
        case "CELL_DATA_TYPE_STRING":
            return 3;
        case 4:
        case "CELL_DATA_TYPE_BOOLEAN":
            return 4;
        case 5:
        case "CELL_DATA_TYPE_NUMBER":
            return 5;
        case 6:
        case "CELL_DATA_TYPE_ERROR":
            return 6;
        case 7:
        case "CELL_DATA_TYPE_DATE":
            return 7;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function fo(i) {
    switch (i) {
        case 0:
            return "CELL_DATA_TYPE_UNSPECIFIED";
        case 1:
            return "CELL_DATA_TYPE_SHARED_STRING";
        case 2:
            return "CELL_DATA_TYPE_INLINE_STRING";
        case 3:
            return "CELL_DATA_TYPE_STRING";
        case 4:
            return "CELL_DATA_TYPE_BOOLEAN";
        case 5:
            return "CELL_DATA_TYPE_NUMBER";
        case 6:
            return "CELL_DATA_TYPE_ERROR";
        case 7:
            return "CELL_DATA_TYPE_DATE";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function co(i) {
    switch (i) {
        case 0:
        case "CELL_FORMULA_TYPE_UNSPECIFIED":
            return 0;
        case 1:
        case "CELL_FORMULA_TYPE_NORMAL":
            return 1;
        case 2:
        case "CELL_FORMULA_TYPE_ARRAY":
            return 2;
        case 3:
        case "CELL_FORMULA_TYPE_DATA_TABLE":
            return 3;
        case 4:
        case "CELL_FORMULA_TYPE_SHARED":
            return 4;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function vo(i) {
    switch (i) {
        case 0:
            return "CELL_FORMULA_TYPE_UNSPECIFIED";
        case 1:
            return "CELL_FORMULA_TYPE_NORMAL";
        case 2:
            return "CELL_FORMULA_TYPE_ARRAY";
        case 3:
            return "CELL_FORMULA_TYPE_DATA_TABLE";
        case 4:
            return "CELL_FORMULA_TYPE_SHARED";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function so(i) {
    switch (i) {
        case 0:
        case "SLICER_SORT_BY_UNSPECIFIED":
            return 0;
        case 1:
        case "SLICER_SORT_BY_DATA_SOURCE_ORDER":
            return 1;
        case 2:
        case "SLICER_SORT_BY_ASCENDING":
            return 2;
        case 3:
        case "SLICER_SORT_BY_DESCENDING":
            return 3;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function ho(i) {
    switch (i) {
        case 0:
            return "SLICER_SORT_BY_UNSPECIFIED";
        case 1:
            return "SLICER_SORT_BY_DATA_SOURCE_ORDER";
        case 2:
            return "SLICER_SORT_BY_ASCENDING";
        case 3:
            return "SLICER_SORT_BY_DESCENDING";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function po(i) {
    switch (i) {
        case 0:
        case "SLICER_CACHE_TYPE_UNSPECIFIED":
            return 0;
        case 1:
        case "SLICER_CACHE_TYPE_PIVOT":
            return 1;
        case 2:
        case "SLICER_CACHE_TYPE_TABLE":
            return 2;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function mo(i) {
    switch (i) {
        case 0:
            return "SLICER_CACHE_TYPE_UNSPECIFIED";
        case 1:
            return "SLICER_CACHE_TYPE_PIVOT";
        case 2:
            return "SLICER_CACHE_TYPE_TABLE";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function So(i) {
    switch (i) {
        case 0:
        case "SLICER_CROSS_FILTER_UNSPECIFIED":
            return 0;
        case 1:
        case "SLICER_CROSS_FILTER_NONE":
            return 1;
        case 2:
        case "SLICER_CROSS_FILTER_SHOW_ITEMS_WITH_DATA_AT_TOP":
            return 2;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Io(i) {
    switch (i) {
        case 0:
            return "SLICER_CROSS_FILTER_UNSPECIFIED";
        case 1:
            return "SLICER_CROSS_FILTER_NONE";
        case 2:
            return "SLICER_CROSS_FILTER_SHOW_ITEMS_WITH_DATA_AT_TOP";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function No(i) {
    switch (i) {
        case 0:
        case "PIVOT_AXIS_UNSPECIFIED":
            return 0;
        case 1:
        case "PIVOT_AXIS_ROW":
            return 1;
        case 2:
        case "PIVOT_AXIS_COLUMN":
            return 2;
        case 3:
        case "PIVOT_AXIS_PAGE":
            return 3;
        case 4:
        case "PIVOT_AXIS_VALUES":
            return 4;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function yo(i) {
    switch (i) {
        case 0:
            return "PIVOT_AXIS_UNSPECIFIED";
        case 1:
            return "PIVOT_AXIS_ROW";
        case 2:
            return "PIVOT_AXIS_COLUMN";
        case 3:
            return "PIVOT_AXIS_PAGE";
        case 4:
            return "PIVOT_AXIS_VALUES";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function ko(i) {
    switch (i) {
        case 0:
        case "FIELD_SORT_UNSPECIFIED":
            return 0;
        case 1:
        case "FIELD_SORT_MANUAL":
            return 1;
        case 2:
        case "FIELD_SORT_ASCENDING":
            return 2;
        case 3:
        case "FIELD_SORT_DESCENDING":
            return 3;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function To(i) {
    switch (i) {
        case 0:
            return "FIELD_SORT_UNSPECIFIED";
        case 1:
            return "FIELD_SORT_MANUAL";
        case 2:
            return "FIELD_SORT_ASCENDING";
        case 3:
            return "FIELD_SORT_DESCENDING";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function Ao(i) {
    switch (i) {
        case 0:
        case "DATA_CONSOLIDATE_FUNCTION_UNSPECIFIED":
            return 0;
        case 1:
        case "DATA_CONSOLIDATE_FUNCTION_SUM":
            return 1;
        case 2:
        case "DATA_CONSOLIDATE_FUNCTION_AVERAGE":
            return 2;
        case 3:
        case "DATA_CONSOLIDATE_FUNCTION_COUNT":
            return 3;
        case 4:
        case "DATA_CONSOLIDATE_FUNCTION_COUNT_NUMBERS":
            return 4;
        case 5:
        case "DATA_CONSOLIDATE_FUNCTION_MAXIMUM":
            return 5;
        case 6:
        case "DATA_CONSOLIDATE_FUNCTION_MINIMUM":
            return 6;
        case 7:
        case "DATA_CONSOLIDATE_FUNCTION_PRODUCT":
            return 7;
        case 8:
        case "DATA_CONSOLIDATE_FUNCTION_STD_DEV":
            return 8;
        case 9:
        case "DATA_CONSOLIDATE_FUNCTION_STD_DEVP":
            return 9;
        case 10:
        case "DATA_CONSOLIDATE_FUNCTION_VARIANCE":
            return 10;
        case 11:
        case "DATA_CONSOLIDATE_FUNCTION_VARIANCEP":
            return 11;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Oo(i) {
    switch (i) {
        case 0:
            return "DATA_CONSOLIDATE_FUNCTION_UNSPECIFIED";
        case 1:
            return "DATA_CONSOLIDATE_FUNCTION_SUM";
        case 2:
            return "DATA_CONSOLIDATE_FUNCTION_AVERAGE";
        case 3:
            return "DATA_CONSOLIDATE_FUNCTION_COUNT";
        case 4:
            return "DATA_CONSOLIDATE_FUNCTION_COUNT_NUMBERS";
        case 5:
            return "DATA_CONSOLIDATE_FUNCTION_MAXIMUM";
        case 6:
            return "DATA_CONSOLIDATE_FUNCTION_MINIMUM";
        case 7:
            return "DATA_CONSOLIDATE_FUNCTION_PRODUCT";
        case 8:
            return "DATA_CONSOLIDATE_FUNCTION_STD_DEV";
        case 9:
            return "DATA_CONSOLIDATE_FUNCTION_STD_DEVP";
        case 10:
            return "DATA_CONSOLIDATE_FUNCTION_VARIANCE";
        case 11:
            return "DATA_CONSOLIDATE_FUNCTION_VARIANCEP";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function Co(i) {
    switch (i) {
        case 0:
        case "PIVOT_FILTER_TYPE_UNSPECIFIED":
            return 0;
        case 1:
        case "PIVOT_FILTER_TYPE_UNKNOWN":
            return 1;
        case 2:
        case "PIVOT_FILTER_TYPE_COUNT":
            return 2;
        case 3:
        case "PIVOT_FILTER_TYPE_PERCENT":
            return 3;
        case 4:
        case "PIVOT_FILTER_TYPE_SUM":
            return 4;
        case 5:
        case "PIVOT_FILTER_TYPE_CAPTION_EQUAL":
            return 5;
        case 6:
        case "PIVOT_FILTER_TYPE_CAPTION_NOT_EQUAL":
            return 6;
        case 7:
        case "PIVOT_FILTER_TYPE_CAPTION_BEGINS_WITH":
            return 7;
        case 8:
        case "PIVOT_FILTER_TYPE_CAPTION_ENDS_WITH":
            return 8;
        case 9:
        case "PIVOT_FILTER_TYPE_CAPTION_CONTAINS":
            return 9;
        case 10:
        case "PIVOT_FILTER_TYPE_VALUE_EQUAL":
            return 10;
        case 11:
        case "PIVOT_FILTER_TYPE_VALUE_NOT_EQUAL":
            return 11;
        case 12:
        case "PIVOT_FILTER_TYPE_VALUE_GREATER_THAN":
            return 12;
        case 13:
        case "PIVOT_FILTER_TYPE_VALUE_LESS_THAN":
            return 13;
        case 14:
        case "PIVOT_FILTER_TYPE_DATE_EQUAL":
            return 14;
        case 15:
        case "PIVOT_FILTER_TYPE_TODAY":
            return 15;
        case 16:
        case "PIVOT_FILTER_TYPE_YESTERDAY":
            return 16;
        case 17:
        case "PIVOT_FILTER_TYPE_TOMORROW":
            return 17;
        case 18:
        case "PIVOT_FILTER_TYPE_THIS_MONTH":
            return 18;
        case 19:
        case "PIVOT_FILTER_TYPE_LAST_MONTH":
            return 19;
        case 20:
        case "PIVOT_FILTER_TYPE_NEXT_MONTH":
            return 20;
        case 21:
        case "PIVOT_FILTER_TYPE_THIS_YEAR":
            return 21;
        case 22:
        case "PIVOT_FILTER_TYPE_LAST_YEAR":
            return 22;
        case 23:
        case "PIVOT_FILTER_TYPE_NEXT_YEAR":
            return 23;
        case 24:
        case "PIVOT_FILTER_TYPE_YEAR_TO_DATE":
            return 24;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Eo(i) {
    switch (i) {
        case 0:
            return "PIVOT_FILTER_TYPE_UNSPECIFIED";
        case 1:
            return "PIVOT_FILTER_TYPE_UNKNOWN";
        case 2:
            return "PIVOT_FILTER_TYPE_COUNT";
        case 3:
            return "PIVOT_FILTER_TYPE_PERCENT";
        case 4:
            return "PIVOT_FILTER_TYPE_SUM";
        case 5:
            return "PIVOT_FILTER_TYPE_CAPTION_EQUAL";
        case 6:
            return "PIVOT_FILTER_TYPE_CAPTION_NOT_EQUAL";
        case 7:
            return "PIVOT_FILTER_TYPE_CAPTION_BEGINS_WITH";
        case 8:
            return "PIVOT_FILTER_TYPE_CAPTION_ENDS_WITH";
        case 9:
            return "PIVOT_FILTER_TYPE_CAPTION_CONTAINS";
        case 10:
            return "PIVOT_FILTER_TYPE_VALUE_EQUAL";
        case 11:
            return "PIVOT_FILTER_TYPE_VALUE_NOT_EQUAL";
        case 12:
            return "PIVOT_FILTER_TYPE_VALUE_GREATER_THAN";
        case 13:
            return "PIVOT_FILTER_TYPE_VALUE_LESS_THAN";
        case 14:
            return "PIVOT_FILTER_TYPE_DATE_EQUAL";
        case 15:
            return "PIVOT_FILTER_TYPE_TODAY";
        case 16:
            return "PIVOT_FILTER_TYPE_YESTERDAY";
        case 17:
            return "PIVOT_FILTER_TYPE_TOMORROW";
        case 18:
            return "PIVOT_FILTER_TYPE_THIS_MONTH";
        case 19:
            return "PIVOT_FILTER_TYPE_LAST_MONTH";
        case 20:
            return "PIVOT_FILTER_TYPE_NEXT_MONTH";
        case 21:
            return "PIVOT_FILTER_TYPE_THIS_YEAR";
        case 22:
            return "PIVOT_FILTER_TYPE_LAST_YEAR";
        case 23:
            return "PIVOT_FILTER_TYPE_NEXT_YEAR";
        case 24:
            return "PIVOT_FILTER_TYPE_YEAR_TO_DATE";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function Po(i) {
    switch (i) {
        case 0:
        case "PERSON_TYPE_UNSPECIFIED":
            return 0;
        case 1:
        case "PERSON_TYPE_LIST":
            return 1;
        case 2:
        case "PERSON_TYPE_COMMENTS_AUTHOR":
            return 2;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function _o(i) {
    switch (i) {
        case 0:
            return "PERSON_TYPE_UNSPECIFIED";
        case 1:
            return "PERSON_TYPE_LIST";
        case 2:
            return "PERSON_TYPE_COMMENTS_AUTHOR";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function qi() {
    return {
        id: void 0,
        sheets: [],
        styles: void 0,
        theme: void 0,
        contentReferences: [],
        images: [],
        people: [],
        threads: [],
        notes: [],
        slicerCaches: [],
        pivotCaches: [],
        timelineCaches: [],
        definedNames: void 0,
        metadata: void 0
    }
}
const Fo = {
    encode(i, n = new v) {
        i.id !== void 0 && n.uint32(82).string(i.id);
        for (const o of i.sheets) q.encode(o, n.uint32(10).fork()).join();
        i.styles !== void 0 && ri.encode(i.styles, n.uint32(18).fork()).join(), i.theme !== void 0 && Gi.encode(i.theme, n.uint32(26).fork()).join();
        for (const o of i.contentReferences) Xi.encode(o, n.uint32(34).fork()).join();
        for (const o of i.images) Wi.encode(o, n.uint32(42).fork()).join();
        for (const o of i.people) di.encode(o, n.uint32(162).fork()).join();
        for (const o of i.threads) li.encode(o, n.uint32(170).fork()).join();
        for (const o of i.notes) ui.encode(o, n.uint32(178).fork()).join();
        for (const o of i.slicerCaches) xi.encode(o, n.uint32(186).fork()).join();
        for (const o of i.pivotCaches) Ji.encode(o, n.uint32(194).fork()).join();
        for (const o of i.timelineCaches) Ai.encode(o, n.uint32(202).fork()).join();
        return i.definedNames !== void 0 && z.encode(i.definedNames, n.uint32(210).fork()).join(), i.metadata !== void 0 && U.encode(i.metadata, n.uint32(218).fork()).join(), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = qi();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 10:
                    {
                        if (r !== 82) break;t.id = o.string();
                        continue
                    }
                case 1:
                    {
                        if (r !== 10) break;t.sheets.push(q.decode(o, o.uint32()));
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.styles = ri.decode(o, o.uint32());
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.theme = Gi.decode(o, o.uint32());
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;t.contentReferences.push(Xi.decode(o, o.uint32()));
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;t.images.push(Wi.decode(o, o.uint32()));
                        continue
                    }
                case 20:
                    {
                        if (r !== 162) break;t.people.push(di.decode(o, o.uint32()));
                        continue
                    }
                case 21:
                    {
                        if (r !== 170) break;t.threads.push(li.decode(o, o.uint32()));
                        continue
                    }
                case 22:
                    {
                        if (r !== 178) break;t.notes.push(ui.decode(o, o.uint32()));
                        continue
                    }
                case 23:
                    {
                        if (r !== 186) break;t.slicerCaches.push(xi.decode(o, o.uint32()));
                        continue
                    }
                case 24:
                    {
                        if (r !== 194) break;t.pivotCaches.push(Ji.decode(o, o.uint32()));
                        continue
                    }
                case 25:
                    {
                        if (r !== 202) break;t.timelineCaches.push(Ai.decode(o, o.uint32()));
                        continue
                    }
                case 26:
                    {
                        if (r !== 210) break;t.definedNames = z.decode(o, o.uint32());
                        continue
                    }
                case 27:
                    {
                        if (r !== 218) break;t.metadata = U.decode(o, o.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            id: e(i.id) ? a.String(i.id) : void 0,
            sheets: a.Array.isArray(i == null ? void 0 : i.sheets) ? i.sheets.map(n => q.fromJSON(n)) : [],
            styles: e(i.styles) ? ri.fromJSON(i.styles) : void 0,
            theme: e(i.theme) ? Gi.fromJSON(i.theme) : void 0,
            contentReferences: a.Array.isArray(i == null ? void 0 : i.contentReferences) ? i.contentReferences.map(n => Xi.fromJSON(n)) : [],
            images: a.Array.isArray(i == null ? void 0 : i.images) ? i.images.map(n => Wi.fromJSON(n)) : [],
            people: a.Array.isArray(i == null ? void 0 : i.people) ? i.people.map(n => di.fromJSON(n)) : [],
            threads: a.Array.isArray(i == null ? void 0 : i.threads) ? i.threads.map(n => li.fromJSON(n)) : [],
            notes: a.Array.isArray(i == null ? void 0 : i.notes) ? i.notes.map(n => ui.fromJSON(n)) : [],
            slicerCaches: a.Array.isArray(i == null ? void 0 : i.slicerCaches) ? i.slicerCaches.map(n => xi.fromJSON(n)) : [],
            pivotCaches: a.Array.isArray(i == null ? void 0 : i.pivotCaches) ? i.pivotCaches.map(n => Ji.fromJSON(n)) : [],
            timelineCaches: a.Array.isArray(i == null ? void 0 : i.timelineCaches) ? i.timelineCaches.map(n => Ai.fromJSON(n)) : [],
            definedNames: e(i.definedNames) ? z.fromJSON(i.definedNames) : void 0,
            metadata: e(i.metadata) ? U.fromJSON(i.metadata) : void 0
        }
    },
    toJSON(i) {
        var o, d, t, r, u, c, p, m, s;
        const n = {};
        return i.id !== void 0 && (n.id = i.id), (o = i.sheets) != null && o.length && (n.sheets = i.sheets.map(h => q.toJSON(h))), i.styles !== void 0 && (n.styles = ri.toJSON(i.styles)), i.theme !== void 0 && (n.theme = Gi.toJSON(i.theme)), (d = i.contentReferences) != null && d.length && (n.contentReferences = i.contentReferences.map(h => Xi.toJSON(h))), (t = i.images) != null && t.length && (n.images = i.images.map(h => Wi.toJSON(h))), (r = i.people) != null && r.length && (n.people = i.people.map(h => di.toJSON(h))), (u = i.threads) != null && u.length && (n.threads = i.threads.map(h => li.toJSON(h))), (c = i.notes) != null && c.length && (n.notes = i.notes.map(h => ui.toJSON(h))), (p = i.slicerCaches) != null && p.length && (n.slicerCaches = i.slicerCaches.map(h => xi.toJSON(h))), (m = i.pivotCaches) != null && m.length && (n.pivotCaches = i.pivotCaches.map(h => Ji.toJSON(h))), (s = i.timelineCaches) != null && s.length && (n.timelineCaches = i.timelineCaches.map(h => Ai.toJSON(h))), i.definedNames !== void 0 && (n.definedNames = z.toJSON(i.definedNames)), i.metadata !== void 0 && (n.metadata = U.toJSON(i.metadata)), n
    },
    create(i) {
        return Fo.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u, c, p, m, s, h;
        const n = qi();
        return n.id = (o = i.id) != null ? o : void 0, n.sheets = ((d = i.sheets) == null ? void 0 : d.map(f => q.fromPartial(f))) || [], n.styles = i.styles !== void 0 && i.styles !== null ? ri.fromPartial(i.styles) : void 0, n.theme = i.theme !== void 0 && i.theme !== null ? Gi.fromPartial(i.theme) : void 0, n.contentReferences = ((t = i.contentReferences) == null ? void 0 : t.map(f => Xi.fromPartial(f))) || [], n.images = ((r = i.images) == null ? void 0 : r.map(f => Wi.fromPartial(f))) || [], n.people = ((u = i.people) == null ? void 0 : u.map(f => di.fromPartial(f))) || [], n.threads = ((c = i.threads) == null ? void 0 : c.map(f => li.fromPartial(f))) || [], n.notes = ((p = i.notes) == null ? void 0 : p.map(f => ui.fromPartial(f))) || [], n.slicerCaches = ((m = i.slicerCaches) == null ? void 0 : m.map(f => xi.fromPartial(f))) || [], n.pivotCaches = ((s = i.pivotCaches) == null ? void 0 : s.map(f => Ji.fromPartial(f))) || [], n.timelineCaches = ((h = i.timelineCaches) == null ? void 0 : h.map(f => Ai.fromPartial(f))) || [], n.definedNames = i.definedNames !== void 0 && i.definedNames !== null ? z.fromPartial(i.definedNames) : void 0, n.metadata = i.metadata !== void 0 && i.metadata !== null ? U.fromPartial(i.metadata) : void 0, n
    }
};

function $i() {
    return {
        metadataTypes: [],
        futureMetadata: [],
        cellMetadata: []
    }
}
const U = {
    encode(i, n = new v) {
        for (const o of i.metadataTypes) V.encode(o, n.uint32(10).fork()).join();
        for (const o of i.futureMetadata) Y.encode(o, n.uint32(18).fork()).join();
        for (const o of i.cellMetadata) X.encode(o, n.uint32(26).fork()).join();
        return n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = $i();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.metadataTypes.push(V.decode(o, o.uint32()));
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.futureMetadata.push(Y.decode(o, o.uint32()));
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.cellMetadata.push(X.decode(o, o.uint32()));
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            metadataTypes: a.Array.isArray(i == null ? void 0 : i.metadataTypes) ? i.metadataTypes.map(n => V.fromJSON(n)) : [],
            futureMetadata: a.Array.isArray(i == null ? void 0 : i.futureMetadata) ? i.futureMetadata.map(n => Y.fromJSON(n)) : [],
            cellMetadata: a.Array.isArray(i == null ? void 0 : i.cellMetadata) ? i.cellMetadata.map(n => X.fromJSON(n)) : []
        }
    },
    toJSON(i) {
        var o, d, t;
        const n = {};
        return (o = i.metadataTypes) != null && o.length && (n.metadataTypes = i.metadataTypes.map(r => V.toJSON(r))), (d = i.futureMetadata) != null && d.length && (n.futureMetadata = i.futureMetadata.map(r => Y.toJSON(r))), (t = i.cellMetadata) != null && t.length && (n.cellMetadata = i.cellMetadata.map(r => X.toJSON(r))), n
    },
    create(i) {
        return U.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t;
        const n = $i();
        return n.metadataTypes = ((o = i.metadataTypes) == null ? void 0 : o.map(r => V.fromPartial(r))) || [], n.futureMetadata = ((d = i.futureMetadata) == null ? void 0 : d.map(r => Y.fromPartial(r))) || [], n.cellMetadata = ((t = i.cellMetadata) == null ? void 0 : t.map(r => X.fromPartial(r))) || [], n
    }
};

function gi() {
    return {
        name: "",
        minSupportedVersion: void 0,
        copy: void 0,
        pasteAll: void 0,
        pasteValues: void 0,
        merge: void 0,
        splitFirst: void 0,
        rowColShift: void 0,
        clearFormats: void 0,
        clearComments: void 0,
        assign: void 0,
        coerce: void 0,
        cellMeta: void 0
    }
}
const V = {
    encode(i, n = new v) {
        return i.name !== "" && n.uint32(10).string(i.name), i.minSupportedVersion !== void 0 && n.uint32(16).int32(i.minSupportedVersion), i.copy !== void 0 && n.uint32(24).bool(i.copy), i.pasteAll !== void 0 && n.uint32(32).bool(i.pasteAll), i.pasteValues !== void 0 && n.uint32(40).bool(i.pasteValues), i.merge !== void 0 && n.uint32(48).bool(i.merge), i.splitFirst !== void 0 && n.uint32(56).bool(i.splitFirst), i.rowColShift !== void 0 && n.uint32(64).bool(i.rowColShift), i.clearFormats !== void 0 && n.uint32(72).bool(i.clearFormats), i.clearComments !== void 0 && n.uint32(80).bool(i.clearComments), i.assign !== void 0 && n.uint32(88).bool(i.assign), i.coerce !== void 0 && n.uint32(96).bool(i.coerce), i.cellMeta !== void 0 && n.uint32(104).bool(i.cellMeta), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = gi();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.name = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;t.minSupportedVersion = o.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;t.copy = o.bool();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;t.pasteAll = o.bool();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;t.pasteValues = o.bool();
                        continue
                    }
                case 6:
                    {
                        if (r !== 48) break;t.merge = o.bool();
                        continue
                    }
                case 7:
                    {
                        if (r !== 56) break;t.splitFirst = o.bool();
                        continue
                    }
                case 8:
                    {
                        if (r !== 64) break;t.rowColShift = o.bool();
                        continue
                    }
                case 9:
                    {
                        if (r !== 72) break;t.clearFormats = o.bool();
                        continue
                    }
                case 10:
                    {
                        if (r !== 80) break;t.clearComments = o.bool();
                        continue
                    }
                case 11:
                    {
                        if (r !== 88) break;t.assign = o.bool();
                        continue
                    }
                case 12:
                    {
                        if (r !== 96) break;t.coerce = o.bool();
                        continue
                    }
                case 13:
                    {
                        if (r !== 104) break;t.cellMeta = o.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            name: e(i.name) ? a.String(i.name) : "",
            minSupportedVersion: e(i.minSupportedVersion) ? a.Number(i.minSupportedVersion) : void 0,
            copy: e(i.copy) ? a.Boolean(i.copy) : void 0,
            pasteAll: e(i.pasteAll) ? a.Boolean(i.pasteAll) : void 0,
            pasteValues: e(i.pasteValues) ? a.Boolean(i.pasteValues) : void 0,
            merge: e(i.merge) ? a.Boolean(i.merge) : void 0,
            splitFirst: e(i.splitFirst) ? a.Boolean(i.splitFirst) : void 0,
            rowColShift: e(i.rowColShift) ? a.Boolean(i.rowColShift) : void 0,
            clearFormats: e(i.clearFormats) ? a.Boolean(i.clearFormats) : void 0,
            clearComments: e(i.clearComments) ? a.Boolean(i.clearComments) : void 0,
            assign: e(i.assign) ? a.Boolean(i.assign) : void 0,
            coerce: e(i.coerce) ? a.Boolean(i.coerce) : void 0,
            cellMeta: e(i.cellMeta) ? a.Boolean(i.cellMeta) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.name !== "" && (n.name = i.name), i.minSupportedVersion !== void 0 && (n.minSupportedVersion = Math.round(i.minSupportedVersion)), i.copy !== void 0 && (n.copy = i.copy), i.pasteAll !== void 0 && (n.pasteAll = i.pasteAll), i.pasteValues !== void 0 && (n.pasteValues = i.pasteValues), i.merge !== void 0 && (n.merge = i.merge), i.splitFirst !== void 0 && (n.splitFirst = i.splitFirst), i.rowColShift !== void 0 && (n.rowColShift = i.rowColShift), i.clearFormats !== void 0 && (n.clearFormats = i.clearFormats), i.clearComments !== void 0 && (n.clearComments = i.clearComments), i.assign !== void 0 && (n.assign = i.assign), i.coerce !== void 0 && (n.coerce = i.coerce), i.cellMeta !== void 0 && (n.cellMeta = i.cellMeta), n
    },
    create(i) {
        return V.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u, c, p, m, s, h, f, S, T;
        const n = gi();
        return n.name = (o = i.name) != null ? o : "", n.minSupportedVersion = (d = i.minSupportedVersion) != null ? d : void 0, n.copy = (t = i.copy) != null ? t : void 0, n.pasteAll = (r = i.pasteAll) != null ? r : void 0, n.pasteValues = (u = i.pasteValues) != null ? u : void 0, n.merge = (c = i.merge) != null ? c : void 0, n.splitFirst = (p = i.splitFirst) != null ? p : void 0, n.rowColShift = (m = i.rowColShift) != null ? m : void 0, n.clearFormats = (s = i.clearFormats) != null ? s : void 0, n.clearComments = (h = i.clearComments) != null ? h : void 0, n.assign = (f = i.assign) != null ? f : void 0, n.coerce = (S = i.coerce) != null ? S : void 0, n.cellMeta = (T = i.cellMeta) != null ? T : void 0, n
    }
};

function bi() {
    return {
        name: "",
        count: void 0,
        blocks: []
    }
}
const Y = {
    encode(i, n = new v) {
        i.name !== "" && n.uint32(10).string(i.name), i.count !== void 0 && n.uint32(16).int32(i.count);
        for (const o of i.blocks) H.encode(o, n.uint32(26).fork()).join();
        return n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = bi();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.name = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;t.count = o.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.blocks.push(H.decode(o, o.uint32()));
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            name: e(i.name) ? a.String(i.name) : "",
            count: e(i.count) ? a.Number(i.count) : void 0,
            blocks: a.Array.isArray(i == null ? void 0 : i.blocks) ? i.blocks.map(n => H.fromJSON(n)) : []
        }
    },
    toJSON(i) {
        var o;
        const n = {};
        return i.name !== "" && (n.name = i.name), i.count !== void 0 && (n.count = Math.round(i.count)), (o = i.blocks) != null && o.length && (n.blocks = i.blocks.map(d => H.toJSON(d))), n
    },
    create(i) {
        return Y.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t;
        const n = bi();
        return n.name = (o = i.name) != null ? o : "", n.count = (d = i.count) != null ? d : void 0, n.blocks = ((t = i.blocks) == null ? void 0 : t.map(r => H.fromPartial(r))) || [], n
    }
};

function ji() {
    return {
        extensionUri: void 0,
        dynamicArrayProperties: void 0
    }
}
const H = {
    encode(i, n = new v) {
        return i.extensionUri !== void 0 && n.uint32(10).string(i.extensionUri), i.dynamicArrayProperties !== void 0 && G.encode(i.dynamicArrayProperties, n.uint32(18).fork()).join(), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = ji();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.extensionUri = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.dynamicArrayProperties = G.decode(o, o.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            extensionUri: e(i.extensionUri) ? a.String(i.extensionUri) : void 0,
            dynamicArrayProperties: e(i.dynamicArrayProperties) ? G.fromJSON(i.dynamicArrayProperties) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.extensionUri !== void 0 && (n.extensionUri = i.extensionUri), i.dynamicArrayProperties !== void 0 && (n.dynamicArrayProperties = G.toJSON(i.dynamicArrayProperties)), n
    },
    create(i) {
        return H.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o;
        const n = ji();
        return n.extensionUri = (o = i.extensionUri) != null ? o : void 0, n.dynamicArrayProperties = i.dynamicArrayProperties !== void 0 && i.dynamicArrayProperties !== null ? G.fromPartial(i.dynamicArrayProperties) : void 0, n
    }
};

function nn() {
    return {
        isDynamic: void 0,
        collapsed: void 0
    }
}
const G = {
    encode(i, n = new v) {
        return i.isDynamic !== void 0 && n.uint32(8).bool(i.isDynamic), i.collapsed !== void 0 && n.uint32(16).bool(i.collapsed), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = nn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;t.isDynamic = o.bool();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;t.collapsed = o.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            isDynamic: e(i.isDynamic) ? a.Boolean(i.isDynamic) : void 0,
            collapsed: e(i.collapsed) ? a.Boolean(i.collapsed) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.isDynamic !== void 0 && (n.isDynamic = i.isDynamic), i.collapsed !== void 0 && (n.collapsed = i.collapsed), n
    },
    create(i) {
        return G.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d;
        const n = nn();
        return n.isDynamic = (o = i.isDynamic) != null ? o : void 0, n.collapsed = (d = i.collapsed) != null ? d : void 0, n
    }
};

function on() {
    return {
        blocks: []
    }
}
const X = {
    encode(i, n = new v) {
        for (const o of i.blocks) W.encode(o, n.uint32(10).fork()).join();
        return n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = on();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.blocks.push(W.decode(o, o.uint32()));
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            blocks: a.Array.isArray(i == null ? void 0 : i.blocks) ? i.blocks.map(n => W.fromJSON(n)) : []
        }
    },
    toJSON(i) {
        var o;
        const n = {};
        return (o = i.blocks) != null && o.length && (n.blocks = i.blocks.map(d => W.toJSON(d))), n
    },
    create(i) {
        return X.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o;
        const n = on();
        return n.blocks = ((o = i.blocks) == null ? void 0 : o.map(d => W.fromPartial(d))) || [], n
    }
};

function rn() {
    return {
        entries: []
    }
}
const W = {
    encode(i, n = new v) {
        for (const o of i.entries) Z.encode(o, n.uint32(10).fork()).join();
        return n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = rn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.entries.push(Z.decode(o, o.uint32()));
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            entries: a.Array.isArray(i == null ? void 0 : i.entries) ? i.entries.map(n => Z.fromJSON(n)) : []
        }
    },
    toJSON(i) {
        var o;
        const n = {};
        return (o = i.entries) != null && o.length && (n.entries = i.entries.map(d => Z.toJSON(d))), n
    },
    create(i) {
        return W.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o;
        const n = rn();
        return n.entries = ((o = i.entries) == null ? void 0 : o.map(d => Z.fromPartial(d))) || [], n
    }
};

function tn() {
    return {
        type: void 0,
        value: void 0
    }
}
const Z = {
    encode(i, n = new v) {
        return i.type !== void 0 && n.uint32(8).int32(i.type), i.value !== void 0 && n.uint32(16).int32(i.value), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = tn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;t.type = o.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;t.value = o.int32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            type: e(i.type) ? a.Number(i.type) : void 0,
            value: e(i.value) ? a.Number(i.value) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.type !== void 0 && (n.type = Math.round(i.type)), i.value !== void 0 && (n.value = Math.round(i.value)), n
    },
    create(i) {
        return Z.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d;
        const n = tn();
        return n.type = (o = i.type) != null ? o : void 0, n.value = (d = i.value) != null ? d : void 0, n
    }
};

function dn() {
    return {
        name: "",
        text: "",
        localSheetId: void 0,
        hidden: void 0,
        comment: void 0,
        description: void 0,
        customMenu: void 0,
        help: void 0,
        statusBar: void 0,
        shortcutKey: void 0,
        function: void 0,
        vbProcedure: void 0,
        functionGroupId: void 0,
        publishToServer: void 0,
        workbookParameter: void 0,
        xlm: void 0
    }
}
const K = {
    encode(i, n = new v) {
        return i.name !== "" && n.uint32(10).string(i.name), i.text !== "" && n.uint32(18).string(i.text), i.localSheetId !== void 0 && n.uint32(24).int32(i.localSheetId), i.hidden !== void 0 && n.uint32(32).bool(i.hidden), i.comment !== void 0 && n.uint32(42).string(i.comment), i.description !== void 0 && n.uint32(50).string(i.description), i.customMenu !== void 0 && n.uint32(58).string(i.customMenu), i.help !== void 0 && n.uint32(66).string(i.help), i.statusBar !== void 0 && n.uint32(74).string(i.statusBar), i.shortcutKey !== void 0 && n.uint32(82).string(i.shortcutKey), i.function !== void 0 && n.uint32(88).bool(i.function), i.vbProcedure !== void 0 && n.uint32(96).bool(i.vbProcedure), i.functionGroupId !== void 0 && n.uint32(104).int32(i.functionGroupId), i.publishToServer !== void 0 && n.uint32(112).bool(i.publishToServer), i.workbookParameter !== void 0 && n.uint32(120).bool(i.workbookParameter), i.xlm !== void 0 && n.uint32(128).bool(i.xlm), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = dn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.name = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.text = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;t.localSheetId = o.int32();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;t.hidden = o.bool();
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;t.comment = o.string();
                        continue
                    }
                case 6:
                    {
                        if (r !== 50) break;t.description = o.string();
                        continue
                    }
                case 7:
                    {
                        if (r !== 58) break;t.customMenu = o.string();
                        continue
                    }
                case 8:
                    {
                        if (r !== 66) break;t.help = o.string();
                        continue
                    }
                case 9:
                    {
                        if (r !== 74) break;t.statusBar = o.string();
                        continue
                    }
                case 10:
                    {
                        if (r !== 82) break;t.shortcutKey = o.string();
                        continue
                    }
                case 11:
                    {
                        if (r !== 88) break;t.function = o.bool();
                        continue
                    }
                case 12:
                    {
                        if (r !== 96) break;t.vbProcedure = o.bool();
                        continue
                    }
                case 13:
                    {
                        if (r !== 104) break;t.functionGroupId = o.int32();
                        continue
                    }
                case 14:
                    {
                        if (r !== 112) break;t.publishToServer = o.bool();
                        continue
                    }
                case 15:
                    {
                        if (r !== 120) break;t.workbookParameter = o.bool();
                        continue
                    }
                case 16:
                    {
                        if (r !== 128) break;t.xlm = o.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            name: e(i.name) ? a.String(i.name) : "",
            text: e(i.text) ? a.String(i.text) : "",
            localSheetId: e(i.localSheetId) ? a.Number(i.localSheetId) : void 0,
            hidden: e(i.hidden) ? a.Boolean(i.hidden) : void 0,
            comment: e(i.comment) ? a.String(i.comment) : void 0,
            description: e(i.description) ? a.String(i.description) : void 0,
            customMenu: e(i.customMenu) ? a.String(i.customMenu) : void 0,
            help: e(i.help) ? a.String(i.help) : void 0,
            statusBar: e(i.statusBar) ? a.String(i.statusBar) : void 0,
            shortcutKey: e(i.shortcutKey) ? a.String(i.shortcutKey) : void 0,
            function: e(i.function) ? a.Boolean(i.function) : void 0,
            vbProcedure: e(i.vbProcedure) ? a.Boolean(i.vbProcedure) : void 0,
            functionGroupId: e(i.functionGroupId) ? a.Number(i.functionGroupId) : void 0,
            publishToServer: e(i.publishToServer) ? a.Boolean(i.publishToServer) : void 0,
            workbookParameter: e(i.workbookParameter) ? a.Boolean(i.workbookParameter) : void 0,
            xlm: e(i.xlm) ? a.Boolean(i.xlm) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.name !== "" && (n.name = i.name), i.text !== "" && (n.text = i.text), i.localSheetId !== void 0 && (n.localSheetId = Math.round(i.localSheetId)), i.hidden !== void 0 && (n.hidden = i.hidden), i.comment !== void 0 && (n.comment = i.comment), i.description !== void 0 && (n.description = i.description), i.customMenu !== void 0 && (n.customMenu = i.customMenu), i.help !== void 0 && (n.help = i.help), i.statusBar !== void 0 && (n.statusBar = i.statusBar), i.shortcutKey !== void 0 && (n.shortcutKey = i.shortcutKey), i.function !== void 0 && (n.function = i.function), i.vbProcedure !== void 0 && (n.vbProcedure = i.vbProcedure), i.functionGroupId !== void 0 && (n.functionGroupId = Math.round(i.functionGroupId)), i.publishToServer !== void 0 && (n.publishToServer = i.publishToServer), i.workbookParameter !== void 0 && (n.workbookParameter = i.workbookParameter), i.xlm !== void 0 && (n.xlm = i.xlm), n
    },
    create(i) {
        return K.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u, c, p, m, s, h, f, S, T, w, _, M;
        const n = dn();
        return n.name = (o = i.name) != null ? o : "", n.text = (d = i.text) != null ? d : "", n.localSheetId = (t = i.localSheetId) != null ? t : void 0, n.hidden = (r = i.hidden) != null ? r : void 0, n.comment = (u = i.comment) != null ? u : void 0, n.description = (c = i.description) != null ? c : void 0, n.customMenu = (p = i.customMenu) != null ? p : void 0, n.help = (m = i.help) != null ? m : void 0, n.statusBar = (s = i.statusBar) != null ? s : void 0, n.shortcutKey = (h = i.shortcutKey) != null ? h : void 0, n.function = (f = i.function) != null ? f : void 0, n.vbProcedure = (S = i.vbProcedure) != null ? S : void 0, n.functionGroupId = (T = i.functionGroupId) != null ? T : void 0, n.publishToServer = (w = i.publishToServer) != null ? w : void 0, n.workbookParameter = (_ = i.workbookParameter) != null ? _ : void 0, n.xlm = (M = i.xlm) != null ? M : void 0, n
    }
};

function an() {
    return {
        names: []
    }
}
const z = {
    encode(i, n = new v) {
        for (const o of i.names) K.encode(o, n.uint32(10).fork()).join();
        return n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = an();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.names.push(K.decode(o, o.uint32()));
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            names: a.Array.isArray(i == null ? void 0 : i.names) ? i.names.map(n => K.fromJSON(n)) : []
        }
    },
    toJSON(i) {
        var o;
        const n = {};
        return (o = i.names) != null && o.length && (n.names = i.names.map(d => K.toJSON(d))), n
    },
    create(i) {
        return z.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o;
        const n = an();
        return n.names = ((o = i.names) == null ? void 0 : o.map(d => K.fromPartial(d))) || [], n
    }
};

function en() {
    return {
        rowId: "",
        colId: "",
        colOffset: "",
        rowOffset: ""
    }
}
const I = {
    encode(i, n = new v) {
        return i.rowId !== "" && n.uint32(10).string(i.rowId), i.colId !== "" && n.uint32(18).string(i.colId), i.colOffset !== "" && n.uint32(26).string(i.colOffset), i.rowOffset !== "" && n.uint32(34).string(i.rowOffset), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = en();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.rowId = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.colId = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.colOffset = o.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;t.rowOffset = o.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            rowId: e(i.rowId) ? a.String(i.rowId) : "",
            colId: e(i.colId) ? a.String(i.colId) : "",
            colOffset: e(i.colOffset) ? a.String(i.colOffset) : "",
            rowOffset: e(i.rowOffset) ? a.String(i.rowOffset) : ""
        }
    },
    toJSON(i) {
        const n = {};
        return i.rowId !== "" && (n.rowId = i.rowId), i.colId !== "" && (n.colId = i.colId), i.colOffset !== "" && (n.colOffset = i.colOffset), i.rowOffset !== "" && (n.rowOffset = i.rowOffset), n
    },
    create(i) {
        return I.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r;
        const n = en();
        return n.rowId = (o = i.rowId) != null ? o : "", n.colId = (d = i.colId) != null ? d : "", n.colOffset = (t = i.colOffset) != null ? t : "", n.rowOffset = (r = i.rowOffset) != null ? r : "", n
    }
};

function ln() {
    return {
        fromAnchor: void 0,
        toAnchor: void 0,
        chart: void 0,
        imageReference: void 0,
        extentCx: void 0,
        extentCy: void 0
    }
}
const Q = {
    encode(i, n = new v) {
        return i.fromAnchor !== void 0 && I.encode(i.fromAnchor, n.uint32(10).fork()).join(), i.toAnchor !== void 0 && I.encode(i.toAnchor, n.uint32(18).fork()).join(), i.chart !== void 0 && Zi.encode(i.chart, n.uint32(26).fork()).join(), i.imageReference !== void 0 && Ki.encode(i.imageReference, n.uint32(34).fork()).join(), i.extentCx !== void 0 && n.uint32(42).string(i.extentCx), i.extentCy !== void 0 && n.uint32(50).string(i.extentCy), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = ln();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.fromAnchor = I.decode(o, o.uint32());
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.toAnchor = I.decode(o, o.uint32());
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.chart = Zi.decode(o, o.uint32());
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;t.imageReference = Ki.decode(o, o.uint32());
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;t.extentCx = o.string();
                        continue
                    }
                case 6:
                    {
                        if (r !== 50) break;t.extentCy = o.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            fromAnchor: e(i.fromAnchor) ? I.fromJSON(i.fromAnchor) : void 0,
            toAnchor: e(i.toAnchor) ? I.fromJSON(i.toAnchor) : void 0,
            chart: e(i.chart) ? Zi.fromJSON(i.chart) : void 0,
            imageReference: e(i.imageReference) ? Ki.fromJSON(i.imageReference) : void 0,
            extentCx: e(i.extentCx) ? a.String(i.extentCx) : void 0,
            extentCy: e(i.extentCy) ? a.String(i.extentCy) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.fromAnchor !== void 0 && (n.fromAnchor = I.toJSON(i.fromAnchor)), i.toAnchor !== void 0 && (n.toAnchor = I.toJSON(i.toAnchor)), i.chart !== void 0 && (n.chart = Zi.toJSON(i.chart)), i.imageReference !== void 0 && (n.imageReference = Ki.toJSON(i.imageReference)), i.extentCx !== void 0 && (n.extentCx = i.extentCx), i.extentCy !== void 0 && (n.extentCy = i.extentCy), n
    },
    create(i) {
        return Q.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d;
        const n = ln();
        return n.fromAnchor = i.fromAnchor !== void 0 && i.fromAnchor !== null ? I.fromPartial(i.fromAnchor) : void 0, n.toAnchor = i.toAnchor !== void 0 && i.toAnchor !== null ? I.fromPartial(i.toAnchor) : void 0, n.chart = i.chart !== void 0 && i.chart !== null ? Zi.fromPartial(i.chart) : void 0, n.imageReference = i.imageReference !== void 0 && i.imageReference !== null ? Ki.fromPartial(i.imageReference) : void 0, n.extentCx = (o = i.extentCx) != null ? o : void 0, n.extentCy = (d = i.extentCy) != null ? d : void 0, n
    }
};

function un() {
    return {
        id: void 0,
        sheetId: void 0,
        index: 0,
        name: "",
        rows: [],
        innerXml: "",
        outerXml: "",
        columns: [],
        defaultRowHeight: 0,
        drawings: [],
        defaultColWidth: 0,
        showGridLines: void 0,
        mergedCells: [],
        conditionalFormattings: [],
        sharedFormulas: [],
        tables: [],
        pivotTables: [],
        slicers: [],
        tabColor: void 0,
        timelines: [],
        dataTables: []
    }
}
const q = {
    encode(i, n = new v) {
        i.id !== void 0 && n.uint32(90).string(i.id), i.sheetId !== void 0 && n.uint32(162).string(i.sheetId), i.index !== 0 && n.uint32(8).int32(i.index), i.name !== "" && n.uint32(18).string(i.name);
        for (const o of i.rows) $.encode(o, n.uint32(26).fork()).join();
        i.innerXml !== "" && n.uint32(34).string(i.innerXml), i.outerXml !== "" && n.uint32(42).string(i.outerXml);
        for (const o of i.columns) ii.encode(o, n.uint32(50).fork()).join();
        i.defaultRowHeight !== 0 && n.uint32(61).float(i.defaultRowHeight);
        for (const o of i.drawings) Q.encode(o, n.uint32(66).fork()).join();
        i.defaultColWidth !== 0 && n.uint32(77).float(i.defaultColWidth), i.showGridLines !== void 0 && n.uint32(80).bool(i.showGridLines);
        for (const o of i.mergedCells) E.encode(o, n.uint32(98).fork()).join();
        for (const o of i.conditionalFormattings) hi.encode(o, n.uint32(106).fork()).join();
        for (const o of i.sharedFormulas) b.encode(o, n.uint32(114).fork()).join();
        for (const o of i.tables) yi.encode(o, n.uint32(122).fork()).join();
        for (const o of i.pivotTables) Fi.encode(o, n.uint32(130).fork()).join();
        for (const o of i.slicers) wi.encode(o, n.uint32(138).fork()).join();
        i.tabColor !== void 0 && N.encode(i.tabColor, n.uint32(146).fork()).join();
        for (const o of i.timelines) ki.encode(o, n.uint32(154).fork()).join();
        for (const o of i.dataTables) j.encode(o, n.uint32(170).fork()).join();
        return n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = un();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 11:
                    {
                        if (r !== 90) break;t.id = o.string();
                        continue
                    }
                case 20:
                    {
                        if (r !== 162) break;t.sheetId = o.string();
                        continue
                    }
                case 1:
                    {
                        if (r !== 8) break;t.index = o.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.name = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.rows.push($.decode(o, o.uint32()));
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;t.innerXml = o.string();
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;t.outerXml = o.string();
                        continue
                    }
                case 6:
                    {
                        if (r !== 50) break;t.columns.push(ii.decode(o, o.uint32()));
                        continue
                    }
                case 7:
                    {
                        if (r !== 61) break;t.defaultRowHeight = o.float();
                        continue
                    }
                case 8:
                    {
                        if (r !== 66) break;t.drawings.push(Q.decode(o, o.uint32()));
                        continue
                    }
                case 9:
                    {
                        if (r !== 77) break;t.defaultColWidth = o.float();
                        continue
                    }
                case 10:
                    {
                        if (r !== 80) break;t.showGridLines = o.bool();
                        continue
                    }
                case 12:
                    {
                        if (r !== 98) break;t.mergedCells.push(E.decode(o, o.uint32()));
                        continue
                    }
                case 13:
                    {
                        if (r !== 106) break;t.conditionalFormattings.push(hi.decode(o, o.uint32()));
                        continue
                    }
                case 14:
                    {
                        if (r !== 114) break;t.sharedFormulas.push(b.decode(o, o.uint32()));
                        continue
                    }
                case 15:
                    {
                        if (r !== 122) break;t.tables.push(yi.decode(o, o.uint32()));
                        continue
                    }
                case 16:
                    {
                        if (r !== 130) break;t.pivotTables.push(Fi.decode(o, o.uint32()));
                        continue
                    }
                case 17:
                    {
                        if (r !== 138) break;t.slicers.push(wi.decode(o, o.uint32()));
                        continue
                    }
                case 18:
                    {
                        if (r !== 146) break;t.tabColor = N.decode(o, o.uint32());
                        continue
                    }
                case 19:
                    {
                        if (r !== 154) break;t.timelines.push(ki.decode(o, o.uint32()));
                        continue
                    }
                case 21:
                    {
                        if (r !== 170) break;t.dataTables.push(j.decode(o, o.uint32()));
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            id: e(i.id) ? a.String(i.id) : void 0,
            sheetId: e(i.sheetId) ? a.String(i.sheetId) : void 0,
            index: e(i.index) ? a.Number(i.index) : 0,
            name: e(i.name) ? a.String(i.name) : "",
            rows: a.Array.isArray(i == null ? void 0 : i.rows) ? i.rows.map(n => $.fromJSON(n)) : [],
            innerXml: e(i.innerXml) ? a.String(i.innerXml) : "",
            outerXml: e(i.outerXml) ? a.String(i.outerXml) : "",
            columns: a.Array.isArray(i == null ? void 0 : i.columns) ? i.columns.map(n => ii.fromJSON(n)) : [],
            defaultRowHeight: e(i.defaultRowHeight) ? a.Number(i.defaultRowHeight) : 0,
            drawings: a.Array.isArray(i == null ? void 0 : i.drawings) ? i.drawings.map(n => Q.fromJSON(n)) : [],
            defaultColWidth: e(i.defaultColWidth) ? a.Number(i.defaultColWidth) : 0,
            showGridLines: e(i.showGridLines) ? a.Boolean(i.showGridLines) : void 0,
            mergedCells: a.Array.isArray(i == null ? void 0 : i.mergedCells) ? i.mergedCells.map(n => E.fromJSON(n)) : [],
            conditionalFormattings: a.Array.isArray(i == null ? void 0 : i.conditionalFormattings) ? i.conditionalFormattings.map(n => hi.fromJSON(n)) : [],
            sharedFormulas: a.Array.isArray(i == null ? void 0 : i.sharedFormulas) ? i.sharedFormulas.map(n => b.fromJSON(n)) : [],
            tables: a.Array.isArray(i == null ? void 0 : i.tables) ? i.tables.map(n => yi.fromJSON(n)) : [],
            pivotTables: a.Array.isArray(i == null ? void 0 : i.pivotTables) ? i.pivotTables.map(n => Fi.fromJSON(n)) : [],
            slicers: a.Array.isArray(i == null ? void 0 : i.slicers) ? i.slicers.map(n => wi.fromJSON(n)) : [],
            tabColor: e(i.tabColor) ? N.fromJSON(i.tabColor) : void 0,
            timelines: a.Array.isArray(i == null ? void 0 : i.timelines) ? i.timelines.map(n => ki.fromJSON(n)) : [],
            dataTables: a.Array.isArray(i == null ? void 0 : i.dataTables) ? i.dataTables.map(n => j.fromJSON(n)) : []
        }
    },
    toJSON(i) {
        var o, d, t, r, u, c, p, m, s, h, f;
        const n = {};
        return i.id !== void 0 && (n.id = i.id), i.sheetId !== void 0 && (n.sheetId = i.sheetId), i.index !== 0 && (n.index = Math.round(i.index)), i.name !== "" && (n.name = i.name), (o = i.rows) != null && o.length && (n.rows = i.rows.map(S => $.toJSON(S))), i.innerXml !== "" && (n.innerXml = i.innerXml), i.outerXml !== "" && (n.outerXml = i.outerXml), (d = i.columns) != null && d.length && (n.columns = i.columns.map(S => ii.toJSON(S))), i.defaultRowHeight !== 0 && (n.defaultRowHeight = i.defaultRowHeight), (t = i.drawings) != null && t.length && (n.drawings = i.drawings.map(S => Q.toJSON(S))), i.defaultColWidth !== 0 && (n.defaultColWidth = i.defaultColWidth), i.showGridLines !== void 0 && (n.showGridLines = i.showGridLines), (r = i.mergedCells) != null && r.length && (n.mergedCells = i.mergedCells.map(S => E.toJSON(S))), (u = i.conditionalFormattings) != null && u.length && (n.conditionalFormattings = i.conditionalFormattings.map(S => hi.toJSON(S))), (c = i.sharedFormulas) != null && c.length && (n.sharedFormulas = i.sharedFormulas.map(S => b.toJSON(S))), (p = i.tables) != null && p.length && (n.tables = i.tables.map(S => yi.toJSON(S))), (m = i.pivotTables) != null && m.length && (n.pivotTables = i.pivotTables.map(S => Fi.toJSON(S))), (s = i.slicers) != null && s.length && (n.slicers = i.slicers.map(S => wi.toJSON(S))), i.tabColor !== void 0 && (n.tabColor = N.toJSON(i.tabColor)), (h = i.timelines) != null && h.length && (n.timelines = i.timelines.map(S => ki.toJSON(S))), (f = i.dataTables) != null && f.length && (n.dataTables = i.dataTables.map(S => j.toJSON(S))), n
    },
    create(i) {
        return q.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u, c, p, m, s, h, f, S, T, w, _, M, Ui, Vi, Yi, Hi;
        const n = un();
        return n.id = (o = i.id) != null ? o : void 0, n.sheetId = (d = i.sheetId) != null ? d : void 0, n.index = (t = i.index) != null ? t : 0, n.name = (r = i.name) != null ? r : "", n.rows = ((u = i.rows) == null ? void 0 : u.map(k => $.fromPartial(k))) || [], n.innerXml = (c = i.innerXml) != null ? c : "", n.outerXml = (p = i.outerXml) != null ? p : "", n.columns = ((m = i.columns) == null ? void 0 : m.map(k => ii.fromPartial(k))) || [], n.defaultRowHeight = (s = i.defaultRowHeight) != null ? s : 0, n.drawings = ((h = i.drawings) == null ? void 0 : h.map(k => Q.fromPartial(k))) || [], n.defaultColWidth = (f = i.defaultColWidth) != null ? f : 0, n.showGridLines = (S = i.showGridLines) != null ? S : void 0, n.mergedCells = ((T = i.mergedCells) == null ? void 0 : T.map(k => E.fromPartial(k))) || [], n.conditionalFormattings = ((w = i.conditionalFormattings) == null ? void 0 : w.map(k => hi.fromPartial(k))) || [], n.sharedFormulas = ((_ = i.sharedFormulas) == null ? void 0 : _.map(k => b.fromPartial(k))) || [], n.tables = ((M = i.tables) == null ? void 0 : M.map(k => yi.fromPartial(k))) || [], n.pivotTables = ((Ui = i.pivotTables) == null ? void 0 : Ui.map(k => Fi.fromPartial(k))) || [], n.slicers = ((Vi = i.slicers) == null ? void 0 : Vi.map(k => wi.fromPartial(k))) || [], n.tabColor = i.tabColor !== void 0 && i.tabColor !== null ? N.fromPartial(i.tabColor) : void 0, n.timelines = ((Yi = i.timelines) == null ? void 0 : Yi.map(k => ki.fromPartial(k))) || [], n.dataTables = ((Hi = i.dataTables) == null ? void 0 : Hi.map(k => j.fromPartial(k))) || [], n
    }
};

function fn() {
    return {
        index: 0,
        cells: [],
        height: 0,
        customHeight: !1,
        styleIndex: void 0,
        hidden: void 0
    }
}
const $ = {
    encode(i, n = new v) {
        i.index !== 0 && n.uint32(8).int32(i.index);
        for (const o of i.cells) g.encode(o, n.uint32(18).fork()).join();
        return i.height !== 0 && n.uint32(29).float(i.height), i.customHeight !== !1 && n.uint32(32).bool(i.customHeight), i.styleIndex !== void 0 && n.uint32(40).int32(i.styleIndex), i.hidden !== void 0 && n.uint32(48).bool(i.hidden), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = fn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;t.index = o.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.cells.push(g.decode(o, o.uint32()));
                        continue
                    }
                case 3:
                    {
                        if (r !== 29) break;t.height = o.float();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;t.customHeight = o.bool();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;t.styleIndex = o.int32();
                        continue
                    }
                case 6:
                    {
                        if (r !== 48) break;t.hidden = o.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            index: e(i.index) ? a.Number(i.index) : 0,
            cells: a.Array.isArray(i == null ? void 0 : i.cells) ? i.cells.map(n => g.fromJSON(n)) : [],
            height: e(i.height) ? a.Number(i.height) : 0,
            customHeight: e(i.customHeight) ? a.Boolean(i.customHeight) : !1,
            styleIndex: e(i.styleIndex) ? a.Number(i.styleIndex) : void 0,
            hidden: e(i.hidden) ? a.Boolean(i.hidden) : void 0
        }
    },
    toJSON(i) {
        var o;
        const n = {};
        return i.index !== 0 && (n.index = Math.round(i.index)), (o = i.cells) != null && o.length && (n.cells = i.cells.map(d => g.toJSON(d))), i.height !== 0 && (n.height = i.height), i.customHeight !== !1 && (n.customHeight = i.customHeight), i.styleIndex !== void 0 && (n.styleIndex = Math.round(i.styleIndex)), i.hidden !== void 0 && (n.hidden = i.hidden), n
    },
    create(i) {
        return $.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u, c;
        const n = fn();
        return n.index = (o = i.index) != null ? o : 0, n.cells = ((d = i.cells) == null ? void 0 : d.map(p => g.fromPartial(p))) || [], n.height = (t = i.height) != null ? t : 0, n.customHeight = (r = i.customHeight) != null ? r : !1, n.styleIndex = (u = i.styleIndex) != null ? u : void 0, n.hidden = (c = i.hidden) != null ? c : void 0, n
    }
};

function cn() {
    return {
        address: "",
        value: void 0,
        formula: void 0,
        dataType: 0,
        styleIndex: void 0,
        paragraphs: [],
        textStyle: void 0,
        sharedFormulaSi: void 0,
        formulaType: void 0,
        formulaRef: void 0,
        formulaAlwaysCalculateArray: void 0,
        cellMetadataIndex: void 0
    }
}
const g = {
    encode(i, n = new v) {
        i.address !== "" && n.uint32(10).string(i.address), i.value !== void 0 && n.uint32(18).string(i.value), i.formula !== void 0 && n.uint32(26).string(i.formula), i.dataType !== 0 && n.uint32(32).int32(i.dataType), i.styleIndex !== void 0 && n.uint32(40).int32(i.styleIndex);
        for (const o of i.paragraphs) zi.encode(o, n.uint32(50).fork()).join();
        return i.textStyle !== void 0 && A.encode(i.textStyle, n.uint32(58).fork()).join(), i.sharedFormulaSi !== void 0 && n.uint32(64).int32(i.sharedFormulaSi), i.formulaType !== void 0 && n.uint32(72).int32(i.formulaType), i.formulaRef !== void 0 && n.uint32(82).string(i.formulaRef), i.formulaAlwaysCalculateArray !== void 0 && n.uint32(88).bool(i.formulaAlwaysCalculateArray), i.cellMetadataIndex !== void 0 && n.uint32(96).int32(i.cellMetadataIndex), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = cn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.address = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.value = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.formula = o.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;t.dataType = o.int32();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;t.styleIndex = o.int32();
                        continue
                    }
                case 6:
                    {
                        if (r !== 50) break;t.paragraphs.push(zi.decode(o, o.uint32()));
                        continue
                    }
                case 7:
                    {
                        if (r !== 58) break;t.textStyle = A.decode(o, o.uint32());
                        continue
                    }
                case 8:
                    {
                        if (r !== 64) break;t.sharedFormulaSi = o.int32();
                        continue
                    }
                case 9:
                    {
                        if (r !== 72) break;t.formulaType = o.int32();
                        continue
                    }
                case 10:
                    {
                        if (r !== 82) break;t.formulaRef = o.string();
                        continue
                    }
                case 11:
                    {
                        if (r !== 88) break;t.formulaAlwaysCalculateArray = o.bool();
                        continue
                    }
                case 12:
                    {
                        if (r !== 96) break;t.cellMetadataIndex = o.int32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            address: e(i.address) ? a.String(i.address) : "",
            value: e(i.value) ? a.String(i.value) : void 0,
            formula: e(i.formula) ? a.String(i.formula) : void 0,
            dataType: e(i.dataType) ? uo(i.dataType) : 0,
            styleIndex: e(i.styleIndex) ? a.Number(i.styleIndex) : void 0,
            paragraphs: a.Array.isArray(i == null ? void 0 : i.paragraphs) ? i.paragraphs.map(n => zi.fromJSON(n)) : [],
            textStyle: e(i.textStyle) ? A.fromJSON(i.textStyle) : void 0,
            sharedFormulaSi: e(i.sharedFormulaSi) ? a.Number(i.sharedFormulaSi) : void 0,
            formulaType: e(i.formulaType) ? co(i.formulaType) : void 0,
            formulaRef: e(i.formulaRef) ? a.String(i.formulaRef) : void 0,
            formulaAlwaysCalculateArray: e(i.formulaAlwaysCalculateArray) ? a.Boolean(i.formulaAlwaysCalculateArray) : void 0,
            cellMetadataIndex: e(i.cellMetadataIndex) ? a.Number(i.cellMetadataIndex) : void 0
        }
    },
    toJSON(i) {
        var o;
        const n = {};
        return i.address !== "" && (n.address = i.address), i.value !== void 0 && (n.value = i.value), i.formula !== void 0 && (n.formula = i.formula), i.dataType !== 0 && (n.dataType = fo(i.dataType)), i.styleIndex !== void 0 && (n.styleIndex = Math.round(i.styleIndex)), (o = i.paragraphs) != null && o.length && (n.paragraphs = i.paragraphs.map(d => zi.toJSON(d))), i.textStyle !== void 0 && (n.textStyle = A.toJSON(i.textStyle)), i.sharedFormulaSi !== void 0 && (n.sharedFormulaSi = Math.round(i.sharedFormulaSi)), i.formulaType !== void 0 && (n.formulaType = vo(i.formulaType)), i.formulaRef !== void 0 && (n.formulaRef = i.formulaRef), i.formulaAlwaysCalculateArray !== void 0 && (n.formulaAlwaysCalculateArray = i.formulaAlwaysCalculateArray), i.cellMetadataIndex !== void 0 && (n.cellMetadataIndex = Math.round(i.cellMetadataIndex)), n
    },
    create(i) {
        return g.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u, c, p, m, s, h, f;
        const n = cn();
        return n.address = (o = i.address) != null ? o : "", n.value = (d = i.value) != null ? d : void 0, n.formula = (t = i.formula) != null ? t : void 0, n.dataType = (r = i.dataType) != null ? r : 0, n.styleIndex = (u = i.styleIndex) != null ? u : void 0, n.paragraphs = ((c = i.paragraphs) == null ? void 0 : c.map(S => zi.fromPartial(S))) || [], n.textStyle = i.textStyle !== void 0 && i.textStyle !== null ? A.fromPartial(i.textStyle) : void 0, n.sharedFormulaSi = (p = i.sharedFormulaSi) != null ? p : void 0, n.formulaType = (m = i.formulaType) != null ? m : void 0, n.formulaRef = (s = i.formulaRef) != null ? s : void 0, n.formulaAlwaysCalculateArray = (h = i.formulaAlwaysCalculateArray) != null ? h : void 0, n.cellMetadataIndex = (f = i.cellMetadataIndex) != null ? f : void 0, n
    }
};

function vn() {
    return {
        si: 0,
        base: "",
        anchor: ""
    }
}
const b = {
    encode(i, n = new v) {
        return i.si !== 0 && n.uint32(8).int32(i.si), i.base !== "" && n.uint32(18).string(i.base), i.anchor !== "" && n.uint32(26).string(i.anchor), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = vn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;t.si = o.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.base = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.anchor = o.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            si: e(i.si) ? a.Number(i.si) : 0,
            base: e(i.base) ? a.String(i.base) : "",
            anchor: e(i.anchor) ? a.String(i.anchor) : ""
        }
    },
    toJSON(i) {
        const n = {};
        return i.si !== 0 && (n.si = Math.round(i.si)), i.base !== "" && (n.base = i.base), i.anchor !== "" && (n.anchor = i.anchor), n
    },
    create(i) {
        return b.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t;
        const n = vn();
        return n.si = (o = i.si) != null ? o : 0, n.base = (d = i.base) != null ? d : "", n.anchor = (t = i.anchor) != null ? t : "", n
    }
};

function sn() {
    return {
        anchor: "",
        ref: "",
        rowInput: void 0,
        columnInput: void 0,
        rowOriented: void 0,
        twoVariable: void 0
    }
}
const j = {
    encode(i, n = new v) {
        return i.anchor !== "" && n.uint32(10).string(i.anchor), i.ref !== "" && n.uint32(18).string(i.ref), i.rowInput !== void 0 && n.uint32(26).string(i.rowInput), i.columnInput !== void 0 && n.uint32(34).string(i.columnInput), i.rowOriented !== void 0 && n.uint32(40).bool(i.rowOriented), i.twoVariable !== void 0 && n.uint32(48).bool(i.twoVariable), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = sn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.anchor = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.ref = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.rowInput = o.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;t.columnInput = o.string();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;t.rowOriented = o.bool();
                        continue
                    }
                case 6:
                    {
                        if (r !== 48) break;t.twoVariable = o.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            anchor: e(i.anchor) ? a.String(i.anchor) : "",
            ref: e(i.ref) ? a.String(i.ref) : "",
            rowInput: e(i.rowInput) ? a.String(i.rowInput) : void 0,
            columnInput: e(i.columnInput) ? a.String(i.columnInput) : void 0,
            rowOriented: e(i.rowOriented) ? a.Boolean(i.rowOriented) : void 0,
            twoVariable: e(i.twoVariable) ? a.Boolean(i.twoVariable) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.anchor !== "" && (n.anchor = i.anchor), i.ref !== "" && (n.ref = i.ref), i.rowInput !== void 0 && (n.rowInput = i.rowInput), i.columnInput !== void 0 && (n.columnInput = i.columnInput), i.rowOriented !== void 0 && (n.rowOriented = i.rowOriented), i.twoVariable !== void 0 && (n.twoVariable = i.twoVariable), n
    },
    create(i) {
        return j.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u, c;
        const n = sn();
        return n.anchor = (o = i.anchor) != null ? o : "", n.ref = (d = i.ref) != null ? d : "", n.rowInput = (t = i.rowInput) != null ? t : void 0, n.columnInput = (r = i.columnInput) != null ? r : void 0, n.rowOriented = (u = i.rowOriented) != null ? u : void 0, n.twoVariable = (c = i.twoVariable) != null ? c : void 0, n
    }
};

function hn() {
    return {
        min: 0,
        max: 0,
        width: 0,
        customWidth: !1,
        styleIndex: void 0,
        hidden: void 0
    }
}
const ii = {
    encode(i, n = new v) {
        return i.min !== 0 && n.uint32(8).int32(i.min), i.max !== 0 && n.uint32(16).int32(i.max), i.width !== 0 && n.uint32(29).float(i.width), i.customWidth !== !1 && n.uint32(32).bool(i.customWidth), i.styleIndex !== void 0 && n.uint32(40).int32(i.styleIndex), i.hidden !== void 0 && n.uint32(48).bool(i.hidden), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = hn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;t.min = o.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;t.max = o.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 29) break;t.width = o.float();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;t.customWidth = o.bool();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;t.styleIndex = o.int32();
                        continue
                    }
                case 6:
                    {
                        if (r !== 48) break;t.hidden = o.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            min: e(i.min) ? a.Number(i.min) : 0,
            max: e(i.max) ? a.Number(i.max) : 0,
            width: e(i.width) ? a.Number(i.width) : 0,
            customWidth: e(i.customWidth) ? a.Boolean(i.customWidth) : !1,
            styleIndex: e(i.styleIndex) ? a.Number(i.styleIndex) : void 0,
            hidden: e(i.hidden) ? a.Boolean(i.hidden) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.min !== 0 && (n.min = Math.round(i.min)), i.max !== 0 && (n.max = Math.round(i.max)), i.width !== 0 && (n.width = i.width), i.customWidth !== !1 && (n.customWidth = i.customWidth), i.styleIndex !== void 0 && (n.styleIndex = Math.round(i.styleIndex)), i.hidden !== void 0 && (n.hidden = i.hidden), n
    },
    create(i) {
        return ii.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u, c;
        const n = hn();
        return n.min = (o = i.min) != null ? o : 0, n.max = (d = i.max) != null ? d : 0, n.width = (t = i.width) != null ? t : 0, n.customWidth = (r = i.customWidth) != null ? r : !1, n.styleIndex = (u = i.styleIndex) != null ? u : void 0, n.hidden = (c = i.hidden) != null ? c : void 0, n
    }
};

function pn() {
    return {
        style: "",
        color: void 0,
        indexedColorId: void 0
    }
}
const y = {
    encode(i, n = new v) {
        return i.style !== "" && n.uint32(10).string(i.style), i.color !== void 0 && N.encode(i.color, n.uint32(18).fork()).join(), i.indexedColorId !== void 0 && n.uint32(24).int32(i.indexedColorId), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = pn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.style = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.color = N.decode(o, o.uint32());
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;t.indexedColorId = o.int32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            style: e(i.style) ? a.String(i.style) : "",
            color: e(i.color) ? N.fromJSON(i.color) : void 0,
            indexedColorId: e(i.indexedColorId) ? a.Number(i.indexedColorId) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.style !== "" && (n.style = i.style), i.color !== void 0 && (n.color = N.toJSON(i.color)), i.indexedColorId !== void 0 && (n.indexedColorId = Math.round(i.indexedColorId)), n
    },
    create(i) {
        return y.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d;
        const n = pn();
        return n.style = (o = i.style) != null ? o : "", n.color = i.color !== void 0 && i.color !== null ? N.fromPartial(i.color) : void 0, n.indexedColorId = (d = i.indexedColorId) != null ? d : void 0, n
    }
};

function mn() {
    return {
        left: void 0,
        right: void 0,
        top: void 0,
        bottom: void 0,
        diagonal: void 0,
        diagonalUp: void 0,
        diagonalDown: void 0
    }
}
const R = {
    encode(i, n = new v) {
        return i.left !== void 0 && y.encode(i.left, n.uint32(10).fork()).join(), i.right !== void 0 && y.encode(i.right, n.uint32(18).fork()).join(), i.top !== void 0 && y.encode(i.top, n.uint32(26).fork()).join(), i.bottom !== void 0 && y.encode(i.bottom, n.uint32(34).fork()).join(), i.diagonal !== void 0 && y.encode(i.diagonal, n.uint32(42).fork()).join(), i.diagonalUp !== void 0 && n.uint32(48).bool(i.diagonalUp), i.diagonalDown !== void 0 && n.uint32(56).bool(i.diagonalDown), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = mn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.left = y.decode(o, o.uint32());
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.right = y.decode(o, o.uint32());
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.top = y.decode(o, o.uint32());
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;t.bottom = y.decode(o, o.uint32());
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;t.diagonal = y.decode(o, o.uint32());
                        continue
                    }
                case 6:
                    {
                        if (r !== 48) break;t.diagonalUp = o.bool();
                        continue
                    }
                case 7:
                    {
                        if (r !== 56) break;t.diagonalDown = o.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            left: e(i.left) ? y.fromJSON(i.left) : void 0,
            right: e(i.right) ? y.fromJSON(i.right) : void 0,
            top: e(i.top) ? y.fromJSON(i.top) : void 0,
            bottom: e(i.bottom) ? y.fromJSON(i.bottom) : void 0,
            diagonal: e(i.diagonal) ? y.fromJSON(i.diagonal) : void 0,
            diagonalUp: e(i.diagonalUp) ? a.Boolean(i.diagonalUp) : void 0,
            diagonalDown: e(i.diagonalDown) ? a.Boolean(i.diagonalDown) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.left !== void 0 && (n.left = y.toJSON(i.left)), i.right !== void 0 && (n.right = y.toJSON(i.right)), i.top !== void 0 && (n.top = y.toJSON(i.top)), i.bottom !== void 0 && (n.bottom = y.toJSON(i.bottom)), i.diagonal !== void 0 && (n.diagonal = y.toJSON(i.diagonal)), i.diagonalUp !== void 0 && (n.diagonalUp = i.diagonalUp), i.diagonalDown !== void 0 && (n.diagonalDown = i.diagonalDown), n
    },
    create(i) {
        return R.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d;
        const n = mn();
        return n.left = i.left !== void 0 && i.left !== null ? y.fromPartial(i.left) : void 0, n.right = i.right !== void 0 && i.right !== null ? y.fromPartial(i.right) : void 0, n.top = i.top !== void 0 && i.top !== null ? y.fromPartial(i.top) : void 0, n.bottom = i.bottom !== void 0 && i.bottom !== null ? y.fromPartial(i.bottom) : void 0, n.diagonal = i.diagonal !== void 0 && i.diagonal !== null ? y.fromPartial(i.diagonal) : void 0, n.diagonalUp = (o = i.diagonalUp) != null ? o : void 0, n.diagonalDown = (d = i.diagonalDown) != null ? d : void 0, n
    }
};

function Sn() {
    return {
        id: 0,
        formatCode: ""
    }
}
const x = {
    encode(i, n = new v) {
        return i.id !== 0 && n.uint32(8).int32(i.id), i.formatCode !== "" && n.uint32(18).string(i.formatCode), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = Sn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;t.id = o.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.formatCode = o.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            id: e(i.id) ? a.Number(i.id) : 0,
            formatCode: e(i.formatCode) ? a.String(i.formatCode) : ""
        }
    },
    toJSON(i) {
        const n = {};
        return i.id !== 0 && (n.id = Math.round(i.id)), i.formatCode !== "" && (n.formatCode = i.formatCode), n
    },
    create(i) {
        return x.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d;
        const n = Sn();
        return n.id = (o = i.id) != null ? o : 0, n.formatCode = (d = i.formatCode) != null ? d : "", n
    }
};

function In() {
    return {
        numFmtId: void 0,
        fontId: void 0,
        fillId: void 0,
        borderId: void 0,
        xfId: void 0,
        applyFill: void 0,
        applyFont: void 0,
        applyBorder: void 0,
        applyAlignment: void 0,
        horizontalAlignment: void 0,
        verticalAlignment: void 0,
        applyNumberFormat: void 0,
        applyProtection: void 0,
        wrapText: void 0,
        shrinkToFit: void 0
    }
}
const J = {
    encode(i, n = new v) {
        return i.numFmtId !== void 0 && n.uint32(8).int32(i.numFmtId), i.fontId !== void 0 && n.uint32(16).int32(i.fontId), i.fillId !== void 0 && n.uint32(24).int32(i.fillId), i.borderId !== void 0 && n.uint32(32).int32(i.borderId), i.xfId !== void 0 && n.uint32(40).int32(i.xfId), i.applyFill !== void 0 && n.uint32(48).bool(i.applyFill), i.applyFont !== void 0 && n.uint32(56).bool(i.applyFont), i.applyBorder !== void 0 && n.uint32(64).bool(i.applyBorder), i.applyAlignment !== void 0 && n.uint32(72).bool(i.applyAlignment), i.horizontalAlignment !== void 0 && n.uint32(82).string(i.horizontalAlignment), i.verticalAlignment !== void 0 && n.uint32(90).string(i.verticalAlignment), i.applyNumberFormat !== void 0 && n.uint32(96).bool(i.applyNumberFormat), i.applyProtection !== void 0 && n.uint32(104).bool(i.applyProtection), i.wrapText !== void 0 && n.uint32(112).bool(i.wrapText), i.shrinkToFit !== void 0 && n.uint32(120).bool(i.shrinkToFit), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = In();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;t.numFmtId = o.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;t.fontId = o.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;t.fillId = o.int32();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;t.borderId = o.int32();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;t.xfId = o.int32();
                        continue
                    }
                case 6:
                    {
                        if (r !== 48) break;t.applyFill = o.bool();
                        continue
                    }
                case 7:
                    {
                        if (r !== 56) break;t.applyFont = o.bool();
                        continue
                    }
                case 8:
                    {
                        if (r !== 64) break;t.applyBorder = o.bool();
                        continue
                    }
                case 9:
                    {
                        if (r !== 72) break;t.applyAlignment = o.bool();
                        continue
                    }
                case 10:
                    {
                        if (r !== 82) break;t.horizontalAlignment = o.string();
                        continue
                    }
                case 11:
                    {
                        if (r !== 90) break;t.verticalAlignment = o.string();
                        continue
                    }
                case 12:
                    {
                        if (r !== 96) break;t.applyNumberFormat = o.bool();
                        continue
                    }
                case 13:
                    {
                        if (r !== 104) break;t.applyProtection = o.bool();
                        continue
                    }
                case 14:
                    {
                        if (r !== 112) break;t.wrapText = o.bool();
                        continue
                    }
                case 15:
                    {
                        if (r !== 120) break;t.shrinkToFit = o.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            numFmtId: e(i.numFmtId) ? a.Number(i.numFmtId) : void 0,
            fontId: e(i.fontId) ? a.Number(i.fontId) : void 0,
            fillId: e(i.fillId) ? a.Number(i.fillId) : void 0,
            borderId: e(i.borderId) ? a.Number(i.borderId) : void 0,
            xfId: e(i.xfId) ? a.Number(i.xfId) : void 0,
            applyFill: e(i.applyFill) ? a.Boolean(i.applyFill) : void 0,
            applyFont: e(i.applyFont) ? a.Boolean(i.applyFont) : void 0,
            applyBorder: e(i.applyBorder) ? a.Boolean(i.applyBorder) : void 0,
            applyAlignment: e(i.applyAlignment) ? a.Boolean(i.applyAlignment) : void 0,
            horizontalAlignment: e(i.horizontalAlignment) ? a.String(i.horizontalAlignment) : void 0,
            verticalAlignment: e(i.verticalAlignment) ? a.String(i.verticalAlignment) : void 0,
            applyNumberFormat: e(i.applyNumberFormat) ? a.Boolean(i.applyNumberFormat) : void 0,
            applyProtection: e(i.applyProtection) ? a.Boolean(i.applyProtection) : void 0,
            wrapText: e(i.wrapText) ? a.Boolean(i.wrapText) : void 0,
            shrinkToFit: e(i.shrinkToFit) ? a.Boolean(i.shrinkToFit) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.numFmtId !== void 0 && (n.numFmtId = Math.round(i.numFmtId)), i.fontId !== void 0 && (n.fontId = Math.round(i.fontId)), i.fillId !== void 0 && (n.fillId = Math.round(i.fillId)), i.borderId !== void 0 && (n.borderId = Math.round(i.borderId)), i.xfId !== void 0 && (n.xfId = Math.round(i.xfId)), i.applyFill !== void 0 && (n.applyFill = i.applyFill), i.applyFont !== void 0 && (n.applyFont = i.applyFont), i.applyBorder !== void 0 && (n.applyBorder = i.applyBorder), i.applyAlignment !== void 0 && (n.applyAlignment = i.applyAlignment), i.horizontalAlignment !== void 0 && (n.horizontalAlignment = i.horizontalAlignment), i.verticalAlignment !== void 0 && (n.verticalAlignment = i.verticalAlignment), i.applyNumberFormat !== void 0 && (n.applyNumberFormat = i.applyNumberFormat), i.applyProtection !== void 0 && (n.applyProtection = i.applyProtection), i.wrapText !== void 0 && (n.wrapText = i.wrapText), i.shrinkToFit !== void 0 && (n.shrinkToFit = i.shrinkToFit), n
    },
    create(i) {
        return J.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u, c, p, m, s, h, f, S, T, w, _;
        const n = In();
        return n.numFmtId = (o = i.numFmtId) != null ? o : void 0, n.fontId = (d = i.fontId) != null ? d : void 0, n.fillId = (t = i.fillId) != null ? t : void 0, n.borderId = (r = i.borderId) != null ? r : void 0, n.xfId = (u = i.xfId) != null ? u : void 0, n.applyFill = (c = i.applyFill) != null ? c : void 0, n.applyFont = (p = i.applyFont) != null ? p : void 0, n.applyBorder = (m = i.applyBorder) != null ? m : void 0, n.applyAlignment = (s = i.applyAlignment) != null ? s : void 0, n.horizontalAlignment = (h = i.horizontalAlignment) != null ? h : void 0, n.verticalAlignment = (f = i.verticalAlignment) != null ? f : void 0, n.applyNumberFormat = (S = i.applyNumberFormat) != null ? S : void 0, n.applyProtection = (T = i.applyProtection) != null ? T : void 0, n.wrapText = (w = i.wrapText) != null ? w : void 0, n.shrinkToFit = (_ = i.shrinkToFit) != null ? _ : void 0, n
    }
};

function Nn() {
    return {
        index: 0,
        format: void 0
    }
}
const ni = {
    encode(i, n = new v) {
        return i.index !== 0 && n.uint32(8).int32(i.index), i.format !== void 0 && J.encode(i.format, n.uint32(18).fork()).join(), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = Nn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;t.index = o.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.format = J.decode(o, o.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            index: e(i.index) ? a.Number(i.index) : 0,
            format: e(i.format) ? J.fromJSON(i.format) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.index !== 0 && (n.index = Math.round(i.index)), i.format !== void 0 && (n.format = J.toJSON(i.format)), n
    },
    create(i) {
        return ni.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o;
        const n = Nn();
        return n.index = (o = i.index) != null ? o : 0, n.format = i.format !== void 0 && i.format !== null ? J.fromPartial(i.format) : void 0, n
    }
};

function yn() {
    return {
        index: 0,
        name: "",
        builtinId: "",
        xfId: void 0
    }
}
const oi = {
    encode(i, n = new v) {
        return i.index !== 0 && n.uint32(8).int32(i.index), i.name !== "" && n.uint32(18).string(i.name), i.builtinId !== "" && n.uint32(26).string(i.builtinId), i.xfId !== void 0 && n.uint32(32).int32(i.xfId), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = yn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;t.index = o.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.name = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.builtinId = o.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;t.xfId = o.int32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            index: e(i.index) ? a.Number(i.index) : 0,
            name: e(i.name) ? a.String(i.name) : "",
            builtinId: e(i.builtinId) ? a.String(i.builtinId) : "",
            xfId: e(i.xfId) ? a.Number(i.xfId) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.index !== 0 && (n.index = Math.round(i.index)), i.name !== "" && (n.name = i.name), i.builtinId !== "" && (n.builtinId = i.builtinId), i.xfId !== void 0 && (n.xfId = Math.round(i.xfId)), n
    },
    create(i) {
        return oi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r;
        const n = yn();
        return n.index = (o = i.index) != null ? o : 0, n.name = (d = i.name) != null ? d : "", n.builtinId = (t = i.builtinId) != null ? t : "", n.xfId = (r = i.xfId) != null ? r : void 0, n
    }
};

function kn() {
    return {
        fonts: [],
        fills: [],
        cellXfs: [],
        borders: [],
        cellStyles: [],
        cellStyleXfs: [],
        numberFormats: [],
        dxfs: [],
        indexedColors: [],
        mruColors: []
    }
}
const ri = {
    encode(i, n = new v) {
        for (const o of i.fonts) A.encode(o, n.uint32(10).fork()).join();
        for (const o of i.fills) O.encode(o, n.uint32(18).fork()).join();
        for (const o of i.cellXfs) J.encode(o, n.uint32(26).fork()).join();
        for (const o of i.borders) R.encode(o, n.uint32(34).fork()).join();
        for (const o of i.cellStyles) oi.encode(o, n.uint32(42).fork()).join();
        for (const o of i.cellStyleXfs) ni.encode(o, n.uint32(50).fork()).join();
        for (const o of i.numberFormats) x.encode(o, n.uint32(58).fork()).join();
        for (const o of i.dxfs) ti.encode(o, n.uint32(66).fork()).join();
        for (const o of i.indexedColors) N.encode(o, n.uint32(74).fork()).join();
        for (const o of i.mruColors) N.encode(o, n.uint32(82).fork()).join();
        return n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = kn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.fonts.push(A.decode(o, o.uint32()));
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.fills.push(O.decode(o, o.uint32()));
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.cellXfs.push(J.decode(o, o.uint32()));
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;t.borders.push(R.decode(o, o.uint32()));
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;t.cellStyles.push(oi.decode(o, o.uint32()));
                        continue
                    }
                case 6:
                    {
                        if (r !== 50) break;t.cellStyleXfs.push(ni.decode(o, o.uint32()));
                        continue
                    }
                case 7:
                    {
                        if (r !== 58) break;t.numberFormats.push(x.decode(o, o.uint32()));
                        continue
                    }
                case 8:
                    {
                        if (r !== 66) break;t.dxfs.push(ti.decode(o, o.uint32()));
                        continue
                    }
                case 9:
                    {
                        if (r !== 74) break;t.indexedColors.push(N.decode(o, o.uint32()));
                        continue
                    }
                case 10:
                    {
                        if (r !== 82) break;t.mruColors.push(N.decode(o, o.uint32()));
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            fonts: a.Array.isArray(i == null ? void 0 : i.fonts) ? i.fonts.map(n => A.fromJSON(n)) : [],
            fills: a.Array.isArray(i == null ? void 0 : i.fills) ? i.fills.map(n => O.fromJSON(n)) : [],
            cellXfs: a.Array.isArray(i == null ? void 0 : i.cellXfs) ? i.cellXfs.map(n => J.fromJSON(n)) : [],
            borders: a.Array.isArray(i == null ? void 0 : i.borders) ? i.borders.map(n => R.fromJSON(n)) : [],
            cellStyles: a.Array.isArray(i == null ? void 0 : i.cellStyles) ? i.cellStyles.map(n => oi.fromJSON(n)) : [],
            cellStyleXfs: a.Array.isArray(i == null ? void 0 : i.cellStyleXfs) ? i.cellStyleXfs.map(n => ni.fromJSON(n)) : [],
            numberFormats: a.Array.isArray(i == null ? void 0 : i.numberFormats) ? i.numberFormats.map(n => x.fromJSON(n)) : [],
            dxfs: a.Array.isArray(i == null ? void 0 : i.dxfs) ? i.dxfs.map(n => ti.fromJSON(n)) : [],
            indexedColors: a.Array.isArray(i == null ? void 0 : i.indexedColors) ? i.indexedColors.map(n => N.fromJSON(n)) : [],
            mruColors: a.Array.isArray(i == null ? void 0 : i.mruColors) ? i.mruColors.map(n => N.fromJSON(n)) : []
        }
    },
    toJSON(i) {
        var o, d, t, r, u, c, p, m, s, h;
        const n = {};
        return (o = i.fonts) != null && o.length && (n.fonts = i.fonts.map(f => A.toJSON(f))), (d = i.fills) != null && d.length && (n.fills = i.fills.map(f => O.toJSON(f))), (t = i.cellXfs) != null && t.length && (n.cellXfs = i.cellXfs.map(f => J.toJSON(f))), (r = i.borders) != null && r.length && (n.borders = i.borders.map(f => R.toJSON(f))), (u = i.cellStyles) != null && u.length && (n.cellStyles = i.cellStyles.map(f => oi.toJSON(f))), (c = i.cellStyleXfs) != null && c.length && (n.cellStyleXfs = i.cellStyleXfs.map(f => ni.toJSON(f))), (p = i.numberFormats) != null && p.length && (n.numberFormats = i.numberFormats.map(f => x.toJSON(f))), (m = i.dxfs) != null && m.length && (n.dxfs = i.dxfs.map(f => ti.toJSON(f))), (s = i.indexedColors) != null && s.length && (n.indexedColors = i.indexedColors.map(f => N.toJSON(f))), (h = i.mruColors) != null && h.length && (n.mruColors = i.mruColors.map(f => N.toJSON(f))), n
    },
    create(i) {
        return ri.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u, c, p, m, s, h;
        const n = kn();
        return n.fonts = ((o = i.fonts) == null ? void 0 : o.map(f => A.fromPartial(f))) || [], n.fills = ((d = i.fills) == null ? void 0 : d.map(f => O.fromPartial(f))) || [], n.cellXfs = ((t = i.cellXfs) == null ? void 0 : t.map(f => J.fromPartial(f))) || [], n.borders = ((r = i.borders) == null ? void 0 : r.map(f => R.fromPartial(f))) || [], n.cellStyles = ((u = i.cellStyles) == null ? void 0 : u.map(f => oi.fromPartial(f))) || [], n.cellStyleXfs = ((c = i.cellStyleXfs) == null ? void 0 : c.map(f => ni.fromPartial(f))) || [], n.numberFormats = ((p = i.numberFormats) == null ? void 0 : p.map(f => x.fromPartial(f))) || [], n.dxfs = ((m = i.dxfs) == null ? void 0 : m.map(f => ti.fromPartial(f))) || [], n.indexedColors = ((s = i.indexedColors) == null ? void 0 : s.map(f => N.fromPartial(f))) || [], n.mruColors = ((h = i.mruColors) == null ? void 0 : h.map(f => N.fromPartial(f))) || [], n
    }
};

function Tn() {
    return {
        font: void 0,
        fill: void 0,
        border: void 0,
        numberFormat: void 0
    }
}
const ti = {
    encode(i, n = new v) {
        return i.font !== void 0 && A.encode(i.font, n.uint32(10).fork()).join(), i.fill !== void 0 && O.encode(i.fill, n.uint32(18).fork()).join(), i.border !== void 0 && R.encode(i.border, n.uint32(26).fork()).join(), i.numberFormat !== void 0 && x.encode(i.numberFormat, n.uint32(34).fork()).join(), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = Tn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.font = A.decode(o, o.uint32());
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.fill = O.decode(o, o.uint32());
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.border = R.decode(o, o.uint32());
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;t.numberFormat = x.decode(o, o.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            font: e(i.font) ? A.fromJSON(i.font) : void 0,
            fill: e(i.fill) ? O.fromJSON(i.fill) : void 0,
            border: e(i.border) ? R.fromJSON(i.border) : void 0,
            numberFormat: e(i.numberFormat) ? x.fromJSON(i.numberFormat) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.font !== void 0 && (n.font = A.toJSON(i.font)), i.fill !== void 0 && (n.fill = O.toJSON(i.fill)), i.border !== void 0 && (n.border = R.toJSON(i.border)), i.numberFormat !== void 0 && (n.numberFormat = x.toJSON(i.numberFormat)), n
    },
    create(i) {
        return ti.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        const n = Tn();
        return n.font = i.font !== void 0 && i.font !== null ? A.fromPartial(i.font) : void 0, n.fill = i.fill !== void 0 && i.fill !== null ? O.fromPartial(i.fill) : void 0, n.border = i.border !== void 0 && i.border !== null ? R.fromPartial(i.border) : void 0, n.numberFormat = i.numberFormat !== void 0 && i.numberFormat !== null ? x.fromPartial(i.numberFormat) : void 0, n
    }
};

function An() {
    return {
        id: "",
        displayName: "",
        email: void 0,
        avatarUrl: void 0,
        type: void 0
    }
}
const di = {
    encode(i, n = new v) {
        return i.id !== "" && n.uint32(10).string(i.id), i.displayName !== "" && n.uint32(18).string(i.displayName), i.email !== void 0 && n.uint32(26).string(i.email), i.avatarUrl !== void 0 && n.uint32(34).string(i.avatarUrl), i.type !== void 0 && n.uint32(40).int32(i.type), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = An();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.id = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.displayName = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.email = o.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;t.avatarUrl = o.string();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;t.type = o.int32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            id: e(i.id) ? a.String(i.id) : "",
            displayName: e(i.displayName) ? a.String(i.displayName) : "",
            email: e(i.email) ? a.String(i.email) : void 0,
            avatarUrl: e(i.avatarUrl) ? a.String(i.avatarUrl) : void 0,
            type: e(i.type) ? Po(i.type) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.id !== "" && (n.id = i.id), i.displayName !== "" && (n.displayName = i.displayName), i.email !== void 0 && (n.email = i.email), i.avatarUrl !== void 0 && (n.avatarUrl = i.avatarUrl), i.type !== void 0 && (n.type = _o(i.type)), n
    },
    create(i) {
        return di.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u;
        const n = An();
        return n.id = (o = i.id) != null ? o : "", n.displayName = (d = i.displayName) != null ? d : "", n.email = (t = i.email) != null ? t : void 0, n.avatarUrl = (r = i.avatarUrl) != null ? r : void 0, n.type = (u = i.type) != null ? u : void 0, n
    }
};

function On() {
    return {
        plainText: ""
    }
}
const D = {
    encode(i, n = new v) {
        return i.plainText !== "" && n.uint32(10).string(i.plainText), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = On();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.plainText = o.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            plainText: e(i.plainText) ? a.String(i.plainText) : ""
        }
    },
    toJSON(i) {
        const n = {};
        return i.plainText !== "" && (n.plainText = i.plainText), n
    },
    create(i) {
        return D.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o;
        const n = On();
        return n.plainText = (o = i.plainText) != null ? o : "", n
    }
};

function Cn() {
    return {
        sheetName: "",
        sheetId: void 0,
        address: ""
    }
}
const ai = {
    encode(i, n = new v) {
        return i.sheetName !== "" && n.uint32(10).string(i.sheetName), i.sheetId !== void 0 && n.uint32(18).string(i.sheetId), i.address !== "" && n.uint32(26).string(i.address), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = Cn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.sheetName = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.sheetId = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.address = o.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            sheetName: e(i.sheetName) ? a.String(i.sheetName) : "",
            sheetId: e(i.sheetId) ? a.String(i.sheetId) : void 0,
            address: e(i.address) ? a.String(i.address) : ""
        }
    },
    toJSON(i) {
        const n = {};
        return i.sheetName !== "" && (n.sheetName = i.sheetName), i.sheetId !== void 0 && (n.sheetId = i.sheetId), i.address !== "" && (n.address = i.address), n
    },
    create(i) {
        return ai.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t;
        const n = Cn();
        return n.sheetName = (o = i.sheetName) != null ? o : "", n.sheetId = (d = i.sheetId) != null ? d : void 0, n.address = (t = i.address) != null ? t : "", n
    }
};

function En() {
    return {
        sheetName: "",
        sheetId: void 0,
        startAddress: "",
        endAddress: ""
    }
}
const E = {
    encode(i, n = new v) {
        return i.sheetName !== "" && n.uint32(10).string(i.sheetName), i.sheetId !== void 0 && n.uint32(18).string(i.sheetId), i.startAddress !== "" && n.uint32(26).string(i.startAddress), i.endAddress !== "" && n.uint32(34).string(i.endAddress), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = En();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.sheetName = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.sheetId = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.startAddress = o.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;t.endAddress = o.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            sheetName: e(i.sheetName) ? a.String(i.sheetName) : "",
            sheetId: e(i.sheetId) ? a.String(i.sheetId) : void 0,
            startAddress: e(i.startAddress) ? a.String(i.startAddress) : "",
            endAddress: e(i.endAddress) ? a.String(i.endAddress) : ""
        }
    },
    toJSON(i) {
        const n = {};
        return i.sheetName !== "" && (n.sheetName = i.sheetName), i.sheetId !== void 0 && (n.sheetId = i.sheetId), i.startAddress !== "" && (n.startAddress = i.startAddress), i.endAddress !== "" && (n.endAddress = i.endAddress), n
    },
    create(i) {
        return E.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r;
        const n = En();
        return n.sheetName = (o = i.sheetName) != null ? o : "", n.sheetId = (d = i.sheetId) != null ? d : void 0, n.startAddress = (t = i.startAddress) != null ? t : "", n.endAddress = (r = i.endAddress) != null ? r : "", n
    }
};

function Pn() {
    return {
        cell: void 0,
        range: void 0
    }
}
const L = {
    encode(i, n = new v) {
        return i.cell !== void 0 && ai.encode(i.cell, n.uint32(10).fork()).join(), i.range !== void 0 && E.encode(i.range, n.uint32(18).fork()).join(), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = Pn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.cell = ai.decode(o, o.uint32());
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.range = E.decode(o, o.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            cell: e(i.cell) ? ai.fromJSON(i.cell) : void 0,
            range: e(i.range) ? E.fromJSON(i.range) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.cell !== void 0 && (n.cell = ai.toJSON(i.cell)), i.range !== void 0 && (n.range = E.toJSON(i.range)), n
    },
    create(i) {
        return L.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        const n = Pn();
        return n.cell = i.cell !== void 0 && i.cell !== null ? ai.fromPartial(i.cell) : void 0, n.range = i.range !== void 0 && i.range !== null ? E.fromPartial(i.range) : void 0, n
    }
};

function _n() {
    return {
        id: "",
        parentId: void 0,
        authorId: "",
        createdAt: "",
        editedAt: void 0,
        body: void 0,
        isDeleted: !1
    }
}
const ei = {
    encode(i, n = new v) {
        return i.id !== "" && n.uint32(10).string(i.id), i.parentId !== void 0 && n.uint32(18).string(i.parentId), i.authorId !== "" && n.uint32(26).string(i.authorId), i.createdAt !== "" && n.uint32(34).string(i.createdAt), i.editedAt !== void 0 && n.uint32(42).string(i.editedAt), i.body !== void 0 && D.encode(i.body, n.uint32(50).fork()).join(), i.isDeleted !== !1 && n.uint32(56).bool(i.isDeleted), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = _n();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.id = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.parentId = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.authorId = o.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;t.createdAt = o.string();
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;t.editedAt = o.string();
                        continue
                    }
                case 6:
                    {
                        if (r !== 50) break;t.body = D.decode(o, o.uint32());
                        continue
                    }
                case 7:
                    {
                        if (r !== 56) break;t.isDeleted = o.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            id: e(i.id) ? a.String(i.id) : "",
            parentId: e(i.parentId) ? a.String(i.parentId) : void 0,
            authorId: e(i.authorId) ? a.String(i.authorId) : "",
            createdAt: e(i.createdAt) ? a.String(i.createdAt) : "",
            editedAt: e(i.editedAt) ? a.String(i.editedAt) : void 0,
            body: e(i.body) ? D.fromJSON(i.body) : void 0,
            isDeleted: e(i.isDeleted) ? a.Boolean(i.isDeleted) : !1
        }
    },
    toJSON(i) {
        const n = {};
        return i.id !== "" && (n.id = i.id), i.parentId !== void 0 && (n.parentId = i.parentId), i.authorId !== "" && (n.authorId = i.authorId), i.createdAt !== "" && (n.createdAt = i.createdAt), i.editedAt !== void 0 && (n.editedAt = i.editedAt), i.body !== void 0 && (n.body = D.toJSON(i.body)), i.isDeleted !== !1 && (n.isDeleted = i.isDeleted), n
    },
    create(i) {
        return ei.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u, c;
        const n = _n();
        return n.id = (o = i.id) != null ? o : "", n.parentId = (d = i.parentId) != null ? d : void 0, n.authorId = (t = i.authorId) != null ? t : "", n.createdAt = (r = i.createdAt) != null ? r : "", n.editedAt = (u = i.editedAt) != null ? u : void 0, n.body = i.body !== void 0 && i.body !== null ? D.fromPartial(i.body) : void 0, n.isDeleted = (c = i.isDeleted) != null ? c : !1, n
    }
};

function Fn() {
    return {
        id: "",
        target: void 0,
        comments: [],
        resolved: !1,
        resolvedBy: void 0,
        resolvedAt: void 0
    }
}
const li = {
    encode(i, n = new v) {
        i.id !== "" && n.uint32(10).string(i.id), i.target !== void 0 && L.encode(i.target, n.uint32(18).fork()).join();
        for (const o of i.comments) ei.encode(o, n.uint32(26).fork()).join();
        return i.resolved !== !1 && n.uint32(32).bool(i.resolved), i.resolvedBy !== void 0 && n.uint32(42).string(i.resolvedBy), i.resolvedAt !== void 0 && n.uint32(50).string(i.resolvedAt), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = Fn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.id = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.target = L.decode(o, o.uint32());
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.comments.push(ei.decode(o, o.uint32()));
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;t.resolved = o.bool();
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;t.resolvedBy = o.string();
                        continue
                    }
                case 6:
                    {
                        if (r !== 50) break;t.resolvedAt = o.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            id: e(i.id) ? a.String(i.id) : "",
            target: e(i.target) ? L.fromJSON(i.target) : void 0,
            comments: a.Array.isArray(i == null ? void 0 : i.comments) ? i.comments.map(n => ei.fromJSON(n)) : [],
            resolved: e(i.resolved) ? a.Boolean(i.resolved) : !1,
            resolvedBy: e(i.resolvedBy) ? a.String(i.resolvedBy) : void 0,
            resolvedAt: e(i.resolvedAt) ? a.String(i.resolvedAt) : void 0
        }
    },
    toJSON(i) {
        var o;
        const n = {};
        return i.id !== "" && (n.id = i.id), i.target !== void 0 && (n.target = L.toJSON(i.target)), (o = i.comments) != null && o.length && (n.comments = i.comments.map(d => ei.toJSON(d))), i.resolved !== !1 && (n.resolved = i.resolved), i.resolvedBy !== void 0 && (n.resolvedBy = i.resolvedBy), i.resolvedAt !== void 0 && (n.resolvedAt = i.resolvedAt), n
    },
    create(i) {
        return li.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u;
        const n = Fn();
        return n.id = (o = i.id) != null ? o : "", n.target = i.target !== void 0 && i.target !== null ? L.fromPartial(i.target) : void 0, n.comments = ((d = i.comments) == null ? void 0 : d.map(c => ei.fromPartial(c))) || [], n.resolved = (t = i.resolved) != null ? t : !1, n.resolvedBy = (r = i.resolvedBy) != null ? r : void 0, n.resolvedAt = (u = i.resolvedAt) != null ? u : void 0, n
    }
};

function wn() {
    return {
        id: "",
        target: void 0,
        authorId: "",
        createdAt: "",
        body: void 0
    }
}
const ui = {
    encode(i, n = new v) {
        return i.id !== "" && n.uint32(10).string(i.id), i.target !== void 0 && L.encode(i.target, n.uint32(18).fork()).join(), i.authorId !== "" && n.uint32(26).string(i.authorId), i.createdAt !== "" && n.uint32(34).string(i.createdAt), i.body !== void 0 && D.encode(i.body, n.uint32(42).fork()).join(), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = wn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.id = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.target = L.decode(o, o.uint32());
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.authorId = o.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;t.createdAt = o.string();
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;t.body = D.decode(o, o.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            id: e(i.id) ? a.String(i.id) : "",
            target: e(i.target) ? L.fromJSON(i.target) : void 0,
            authorId: e(i.authorId) ? a.String(i.authorId) : "",
            createdAt: e(i.createdAt) ? a.String(i.createdAt) : "",
            body: e(i.body) ? D.fromJSON(i.body) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.id !== "" && (n.id = i.id), i.target !== void 0 && (n.target = L.toJSON(i.target)), i.authorId !== "" && (n.authorId = i.authorId), i.createdAt !== "" && (n.createdAt = i.createdAt), i.body !== void 0 && (n.body = D.toJSON(i.body)), n
    },
    create(i) {
        return ui.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t;
        const n = wn();
        return n.id = (o = i.id) != null ? o : "", n.target = i.target !== void 0 && i.target !== null ? L.fromPartial(i.target) : void 0, n.authorId = (d = i.authorId) != null ? d : "", n.createdAt = (t = i.createdAt) != null ? t : "", n.body = i.body !== void 0 && i.body !== null ? D.fromPartial(i.body) : void 0, n
    }
};

function Rn() {
    return {
        type: "",
        val: void 0
    }
}
const P = {
    encode(i, n = new v) {
        return i.type !== "" && n.uint32(10).string(i.type), i.val !== void 0 && n.uint32(18).string(i.val), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = Rn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.type = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.val = o.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            type: e(i.type) ? a.String(i.type) : "",
            val: e(i.val) ? a.String(i.val) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.type !== "" && (n.type = i.type), i.val !== void 0 && (n.val = i.val), n
    },
    create(i) {
        return P.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d;
        const n = Rn();
        return n.type = (o = i.type) != null ? o : "", n.val = (d = i.val) != null ? d : void 0, n
    }
};

function xn() {
    return {
        cfvos: [],
        colors: []
    }
}
const fi = {
    encode(i, n = new v) {
        for (const o of i.cfvos) P.encode(o, n.uint32(10).fork()).join();
        for (const o of i.colors) N.encode(o, n.uint32(18).fork()).join();
        return n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = xn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.cfvos.push(P.decode(o, o.uint32()));
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.colors.push(N.decode(o, o.uint32()));
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            cfvos: a.Array.isArray(i == null ? void 0 : i.cfvos) ? i.cfvos.map(n => P.fromJSON(n)) : [],
            colors: a.Array.isArray(i == null ? void 0 : i.colors) ? i.colors.map(n => N.fromJSON(n)) : []
        }
    },
    toJSON(i) {
        var o, d;
        const n = {};
        return (o = i.cfvos) != null && o.length && (n.cfvos = i.cfvos.map(t => P.toJSON(t))), (d = i.colors) != null && d.length && (n.colors = i.colors.map(t => N.toJSON(t))), n
    },
    create(i) {
        return fi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d;
        const n = xn();
        return n.cfvos = ((o = i.cfvos) == null ? void 0 : o.map(t => P.fromPartial(t))) || [], n.colors = ((d = i.colors) == null ? void 0 : d.map(t => N.fromPartial(t))) || [], n
    }
};

function Jn() {
    return {
        cfvos: [],
        color: void 0,
        gradient: void 0
    }
}
const ci = {
    encode(i, n = new v) {
        for (const o of i.cfvos) P.encode(o, n.uint32(10).fork()).join();
        return i.color !== void 0 && N.encode(i.color, n.uint32(18).fork()).join(), i.gradient !== void 0 && n.uint32(24).bool(i.gradient), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = Jn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.cfvos.push(P.decode(o, o.uint32()));
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.color = N.decode(o, o.uint32());
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;t.gradient = o.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            cfvos: a.Array.isArray(i == null ? void 0 : i.cfvos) ? i.cfvos.map(n => P.fromJSON(n)) : [],
            color: e(i.color) ? N.fromJSON(i.color) : void 0,
            gradient: e(i.gradient) ? a.Boolean(i.gradient) : void 0
        }
    },
    toJSON(i) {
        var o;
        const n = {};
        return (o = i.cfvos) != null && o.length && (n.cfvos = i.cfvos.map(d => P.toJSON(d))), i.color !== void 0 && (n.color = N.toJSON(i.color)), i.gradient !== void 0 && (n.gradient = i.gradient), n
    },
    create(i) {
        return ci.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d;
        const n = Jn();
        return n.cfvos = ((o = i.cfvos) == null ? void 0 : o.map(t => P.fromPartial(t))) || [], n.color = i.color !== void 0 && i.color !== null ? N.fromPartial(i.color) : void 0, n.gradient = (d = i.gradient) != null ? d : void 0, n
    }
};

function Dn() {
    return {
        iconSet: "",
        showValue: void 0,
        reverse: void 0,
        custom: void 0,
        cfvos: []
    }
}
const vi = {
    encode(i, n = new v) {
        i.iconSet !== "" && n.uint32(10).string(i.iconSet), i.showValue !== void 0 && n.uint32(16).bool(i.showValue), i.reverse !== void 0 && n.uint32(24).bool(i.reverse), i.custom !== void 0 && n.uint32(32).bool(i.custom);
        for (const o of i.cfvos) P.encode(o, n.uint32(42).fork()).join();
        return n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = Dn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.iconSet = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;t.showValue = o.bool();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;t.reverse = o.bool();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;t.custom = o.bool();
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;t.cfvos.push(P.decode(o, o.uint32()));
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            iconSet: e(i.iconSet) ? a.String(i.iconSet) : "",
            showValue: e(i.showValue) ? a.Boolean(i.showValue) : void 0,
            reverse: e(i.reverse) ? a.Boolean(i.reverse) : void 0,
            custom: e(i.custom) ? a.Boolean(i.custom) : void 0,
            cfvos: a.Array.isArray(i == null ? void 0 : i.cfvos) ? i.cfvos.map(n => P.fromJSON(n)) : []
        }
    },
    toJSON(i) {
        var o;
        const n = {};
        return i.iconSet !== "" && (n.iconSet = i.iconSet), i.showValue !== void 0 && (n.showValue = i.showValue), i.reverse !== void 0 && (n.reverse = i.reverse), i.custom !== void 0 && (n.custom = i.custom), (o = i.cfvos) != null && o.length && (n.cfvos = i.cfvos.map(d => P.toJSON(d))), n
    },
    create(i) {
        return vi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u;
        const n = Dn();
        return n.iconSet = (o = i.iconSet) != null ? o : "", n.showValue = (d = i.showValue) != null ? d : void 0, n.reverse = (t = i.reverse) != null ? t : void 0, n.custom = (r = i.custom) != null ? r : void 0, n.cfvos = ((u = i.cfvos) == null ? void 0 : u.map(c => P.fromPartial(c))) || [], n
    }
};

function Ln() {
    return {
        type: "",
        priority: void 0,
        dxfId: void 0,
        operator: void 0,
        formula: [],
        colorScale: void 0,
        dataBar: void 0,
        iconSet: void 0
    }
}
const si = {
    encode(i, n = new v) {
        i.type !== "" && n.uint32(10).string(i.type), i.priority !== void 0 && n.uint32(16).int32(i.priority), i.dxfId !== void 0 && n.uint32(24).int32(i.dxfId), i.operator !== void 0 && n.uint32(34).string(i.operator);
        for (const o of i.formula) n.uint32(42).string(o);
        return i.colorScale !== void 0 && fi.encode(i.colorScale, n.uint32(82).fork()).join(), i.dataBar !== void 0 && ci.encode(i.dataBar, n.uint32(90).fork()).join(), i.iconSet !== void 0 && vi.encode(i.iconSet, n.uint32(98).fork()).join(), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = Ln();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.type = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;t.priority = o.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;t.dxfId = o.int32();
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;t.operator = o.string();
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;t.formula.push(o.string());
                        continue
                    }
                case 10:
                    {
                        if (r !== 82) break;t.colorScale = fi.decode(o, o.uint32());
                        continue
                    }
                case 11:
                    {
                        if (r !== 90) break;t.dataBar = ci.decode(o, o.uint32());
                        continue
                    }
                case 12:
                    {
                        if (r !== 98) break;t.iconSet = vi.decode(o, o.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            type: e(i.type) ? a.String(i.type) : "",
            priority: e(i.priority) ? a.Number(i.priority) : void 0,
            dxfId: e(i.dxfId) ? a.Number(i.dxfId) : void 0,
            operator: e(i.operator) ? a.String(i.operator) : void 0,
            formula: a.Array.isArray(i == null ? void 0 : i.formula) ? i.formula.map(n => a.String(n)) : [],
            colorScale: e(i.colorScale) ? fi.fromJSON(i.colorScale) : void 0,
            dataBar: e(i.dataBar) ? ci.fromJSON(i.dataBar) : void 0,
            iconSet: e(i.iconSet) ? vi.fromJSON(i.iconSet) : void 0
        }
    },
    toJSON(i) {
        var o;
        const n = {};
        return i.type !== "" && (n.type = i.type), i.priority !== void 0 && (n.priority = Math.round(i.priority)), i.dxfId !== void 0 && (n.dxfId = Math.round(i.dxfId)), i.operator !== void 0 && (n.operator = i.operator), (o = i.formula) != null && o.length && (n.formula = i.formula), i.colorScale !== void 0 && (n.colorScale = fi.toJSON(i.colorScale)), i.dataBar !== void 0 && (n.dataBar = ci.toJSON(i.dataBar)), i.iconSet !== void 0 && (n.iconSet = vi.toJSON(i.iconSet)), n
    },
    create(i) {
        return si.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u;
        const n = Ln();
        return n.type = (o = i.type) != null ? o : "", n.priority = (d = i.priority) != null ? d : void 0, n.dxfId = (t = i.dxfId) != null ? t : void 0, n.operator = (r = i.operator) != null ? r : void 0, n.formula = ((u = i.formula) == null ? void 0 : u.map(c => c)) || [], n.colorScale = i.colorScale !== void 0 && i.colorScale !== null ? fi.fromPartial(i.colorScale) : void 0, n.dataBar = i.dataBar !== void 0 && i.dataBar !== null ? ci.fromPartial(i.dataBar) : void 0, n.iconSet = i.iconSet !== void 0 && i.iconSet !== null ? vi.fromPartial(i.iconSet) : void 0, n
    }
};

function Bn() {
    return {
        ranges: [],
        rules: []
    }
}
const hi = {
    encode(i, n = new v) {
        for (const o of i.ranges) E.encode(o, n.uint32(10).fork()).join();
        for (const o of i.rules) si.encode(o, n.uint32(18).fork()).join();
        return n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = Bn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.ranges.push(E.decode(o, o.uint32()));
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.rules.push(si.decode(o, o.uint32()));
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            ranges: a.Array.isArray(i == null ? void 0 : i.ranges) ? i.ranges.map(n => E.fromJSON(n)) : [],
            rules: a.Array.isArray(i == null ? void 0 : i.rules) ? i.rules.map(n => si.fromJSON(n)) : []
        }
    },
    toJSON(i) {
        var o, d;
        const n = {};
        return (o = i.ranges) != null && o.length && (n.ranges = i.ranges.map(t => E.toJSON(t))), (d = i.rules) != null && d.length && (n.rules = i.rules.map(t => si.toJSON(t))), n
    },
    create(i) {
        return hi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d;
        const n = Bn();
        return n.ranges = ((o = i.ranges) == null ? void 0 : o.map(t => E.fromPartial(t))) || [], n.rules = ((d = i.rules) == null ? void 0 : d.map(t => si.fromPartial(t))) || [], n
    }
};

function Mn() {
    return {
        id: 0,
        name: "",
        totalsRowLabel: void 0,
        totalsRowFunction: void 0,
        dataDxfId: void 0
    }
}
const pi = {
    encode(i, n = new v) {
        return i.id !== 0 && n.uint32(8).int32(i.id), i.name !== "" && n.uint32(18).string(i.name), i.totalsRowLabel !== void 0 && n.uint32(26).string(i.totalsRowLabel), i.totalsRowFunction !== void 0 && n.uint32(34).string(i.totalsRowFunction), i.dataDxfId !== void 0 && n.uint32(40).int32(i.dataDxfId), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = Mn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;t.id = o.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.name = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.totalsRowLabel = o.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;t.totalsRowFunction = o.string();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;t.dataDxfId = o.int32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            id: e(i.id) ? a.Number(i.id) : 0,
            name: e(i.name) ? a.String(i.name) : "",
            totalsRowLabel: e(i.totalsRowLabel) ? a.String(i.totalsRowLabel) : void 0,
            totalsRowFunction: e(i.totalsRowFunction) ? a.String(i.totalsRowFunction) : void 0,
            dataDxfId: e(i.dataDxfId) ? a.Number(i.dataDxfId) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.id !== 0 && (n.id = Math.round(i.id)), i.name !== "" && (n.name = i.name), i.totalsRowLabel !== void 0 && (n.totalsRowLabel = i.totalsRowLabel), i.totalsRowFunction !== void 0 && (n.totalsRowFunction = i.totalsRowFunction), i.dataDxfId !== void 0 && (n.dataDxfId = Math.round(i.dataDxfId)), n
    },
    create(i) {
        return pi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u;
        const n = Mn();
        return n.id = (o = i.id) != null ? o : 0, n.name = (d = i.name) != null ? d : "", n.totalsRowLabel = (t = i.totalsRowLabel) != null ? t : void 0, n.totalsRowFunction = (r = i.totalsRowFunction) != null ? r : void 0, n.dataDxfId = (u = i.dataDxfId) != null ? u : void 0, n
    }
};

function Un() {
    return {
        name: "",
        showFirstColumn: void 0,
        showLastColumn: void 0,
        showRowStripes: void 0,
        showColumnStripes: void 0
    }
}
const mi = {
    encode(i, n = new v) {
        return i.name !== "" && n.uint32(10).string(i.name), i.showFirstColumn !== void 0 && n.uint32(16).bool(i.showFirstColumn), i.showLastColumn !== void 0 && n.uint32(24).bool(i.showLastColumn), i.showRowStripes !== void 0 && n.uint32(32).bool(i.showRowStripes), i.showColumnStripes !== void 0 && n.uint32(40).bool(i.showColumnStripes), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = Un();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.name = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;t.showFirstColumn = o.bool();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;t.showLastColumn = o.bool();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;t.showRowStripes = o.bool();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;t.showColumnStripes = o.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            name: e(i.name) ? a.String(i.name) : "",
            showFirstColumn: e(i.showFirstColumn) ? a.Boolean(i.showFirstColumn) : void 0,
            showLastColumn: e(i.showLastColumn) ? a.Boolean(i.showLastColumn) : void 0,
            showRowStripes: e(i.showRowStripes) ? a.Boolean(i.showRowStripes) : void 0,
            showColumnStripes: e(i.showColumnStripes) ? a.Boolean(i.showColumnStripes) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.name !== "" && (n.name = i.name), i.showFirstColumn !== void 0 && (n.showFirstColumn = i.showFirstColumn), i.showLastColumn !== void 0 && (n.showLastColumn = i.showLastColumn), i.showRowStripes !== void 0 && (n.showRowStripes = i.showRowStripes), i.showColumnStripes !== void 0 && (n.showColumnStripes = i.showColumnStripes), n
    },
    create(i) {
        return mi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u;
        const n = Un();
        return n.name = (o = i.name) != null ? o : "", n.showFirstColumn = (d = i.showFirstColumn) != null ? d : void 0, n.showLastColumn = (t = i.showLastColumn) != null ? t : void 0, n.showRowStripes = (r = i.showRowStripes) != null ? r : void 0, n.showColumnStripes = (u = i.showColumnStripes) != null ? u : void 0, n
    }
};

function Vn() {
    return {
        values: [],
        blank: void 0
    }
}
const Si = {
    encode(i, n = new v) {
        for (const o of i.values) n.uint32(10).string(o);
        return i.blank !== void 0 && n.uint32(16).bool(i.blank), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = Vn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.values.push(o.string());
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;t.blank = o.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            values: a.Array.isArray(i == null ? void 0 : i.values) ? i.values.map(n => a.String(n)) : [],
            blank: e(i.blank) ? a.Boolean(i.blank) : void 0
        }
    },
    toJSON(i) {
        var o;
        const n = {};
        return (o = i.values) != null && o.length && (n.values = i.values), i.blank !== void 0 && (n.blank = i.blank), n
    },
    create(i) {
        return Si.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d;
        const n = Vn();
        return n.values = ((o = i.values) == null ? void 0 : o.map(t => t)) || [], n.blank = (d = i.blank) != null ? d : void 0, n
    }
};

function Yn() {
    return {
        colId: 0,
        type: "",
        filters: void 0
    }
}
const Ii = {
    encode(i, n = new v) {
        return i.colId !== 0 && n.uint32(8).int32(i.colId), i.type !== "" && n.uint32(18).string(i.type), i.filters !== void 0 && Si.encode(i.filters, n.uint32(26).fork()).join(), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = Yn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;t.colId = o.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.type = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.filters = Si.decode(o, o.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            colId: e(i.colId) ? a.Number(i.colId) : 0,
            type: e(i.type) ? a.String(i.type) : "",
            filters: e(i.filters) ? Si.fromJSON(i.filters) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.colId !== 0 && (n.colId = Math.round(i.colId)), i.type !== "" && (n.type = i.type), i.filters !== void 0 && (n.filters = Si.toJSON(i.filters)), n
    },
    create(i) {
        return Ii.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d;
        const n = Yn();
        return n.colId = (o = i.colId) != null ? o : 0, n.type = (d = i.type) != null ? d : "", n.filters = i.filters !== void 0 && i.filters !== null ? Si.fromPartial(i.filters) : void 0, n
    }
};

function Hn() {
    return {
        ref: "",
        columns: []
    }
}
const Ni = {
    encode(i, n = new v) {
        i.ref !== "" && n.uint32(10).string(i.ref);
        for (const o of i.columns) Ii.encode(o, n.uint32(18).fork()).join();
        return n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = Hn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.ref = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.columns.push(Ii.decode(o, o.uint32()));
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            ref: e(i.ref) ? a.String(i.ref) : "",
            columns: a.Array.isArray(i == null ? void 0 : i.columns) ? i.columns.map(n => Ii.fromJSON(n)) : []
        }
    },
    toJSON(i) {
        var o;
        const n = {};
        return i.ref !== "" && (n.ref = i.ref), (o = i.columns) != null && o.length && (n.columns = i.columns.map(d => Ii.toJSON(d))), n
    },
    create(i) {
        return Ni.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d;
        const n = Hn();
        return n.ref = (o = i.ref) != null ? o : "", n.columns = ((d = i.columns) == null ? void 0 : d.map(t => Ii.fromPartial(t))) || [], n
    }
};

function Gn() {
    return {
        id: 0,
        name: "",
        displayName: "",
        ref: "",
        columns: [],
        style: void 0,
        totalsRowShown: void 0,
        headerRowCount: void 0,
        totalsRowCount: void 0,
        autoFilter: void 0,
        dataDxfId: void 0,
        headerRowCellStyle: void 0
    }
}
const yi = {
    encode(i, n = new v) {
        i.id !== 0 && n.uint32(8).int32(i.id), i.name !== "" && n.uint32(18).string(i.name), i.displayName !== "" && n.uint32(26).string(i.displayName), i.ref !== "" && n.uint32(34).string(i.ref);
        for (const o of i.columns) pi.encode(o, n.uint32(42).fork()).join();
        return i.style !== void 0 && mi.encode(i.style, n.uint32(50).fork()).join(), i.totalsRowShown !== void 0 && n.uint32(56).bool(i.totalsRowShown), i.headerRowCount !== void 0 && n.uint32(64).int32(i.headerRowCount), i.totalsRowCount !== void 0 && n.uint32(72).int32(i.totalsRowCount), i.autoFilter !== void 0 && Ni.encode(i.autoFilter, n.uint32(82).fork()).join(), i.dataDxfId !== void 0 && n.uint32(88).int32(i.dataDxfId), i.headerRowCellStyle !== void 0 && n.uint32(98).string(i.headerRowCellStyle), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = Gn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;t.id = o.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.name = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.displayName = o.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;t.ref = o.string();
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;t.columns.push(pi.decode(o, o.uint32()));
                        continue
                    }
                case 6:
                    {
                        if (r !== 50) break;t.style = mi.decode(o, o.uint32());
                        continue
                    }
                case 7:
                    {
                        if (r !== 56) break;t.totalsRowShown = o.bool();
                        continue
                    }
                case 8:
                    {
                        if (r !== 64) break;t.headerRowCount = o.int32();
                        continue
                    }
                case 9:
                    {
                        if (r !== 72) break;t.totalsRowCount = o.int32();
                        continue
                    }
                case 10:
                    {
                        if (r !== 82) break;t.autoFilter = Ni.decode(o, o.uint32());
                        continue
                    }
                case 11:
                    {
                        if (r !== 88) break;t.dataDxfId = o.int32();
                        continue
                    }
                case 12:
                    {
                        if (r !== 98) break;t.headerRowCellStyle = o.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            id: e(i.id) ? a.Number(i.id) : 0,
            name: e(i.name) ? a.String(i.name) : "",
            displayName: e(i.displayName) ? a.String(i.displayName) : "",
            ref: e(i.ref) ? a.String(i.ref) : "",
            columns: a.Array.isArray(i == null ? void 0 : i.columns) ? i.columns.map(n => pi.fromJSON(n)) : [],
            style: e(i.style) ? mi.fromJSON(i.style) : void 0,
            totalsRowShown: e(i.totalsRowShown) ? a.Boolean(i.totalsRowShown) : void 0,
            headerRowCount: e(i.headerRowCount) ? a.Number(i.headerRowCount) : void 0,
            totalsRowCount: e(i.totalsRowCount) ? a.Number(i.totalsRowCount) : void 0,
            autoFilter: e(i.autoFilter) ? Ni.fromJSON(i.autoFilter) : void 0,
            dataDxfId: e(i.dataDxfId) ? a.Number(i.dataDxfId) : void 0,
            headerRowCellStyle: e(i.headerRowCellStyle) ? a.String(i.headerRowCellStyle) : void 0
        }
    },
    toJSON(i) {
        var o;
        const n = {};
        return i.id !== 0 && (n.id = Math.round(i.id)), i.name !== "" && (n.name = i.name), i.displayName !== "" && (n.displayName = i.displayName), i.ref !== "" && (n.ref = i.ref), (o = i.columns) != null && o.length && (n.columns = i.columns.map(d => pi.toJSON(d))), i.style !== void 0 && (n.style = mi.toJSON(i.style)), i.totalsRowShown !== void 0 && (n.totalsRowShown = i.totalsRowShown), i.headerRowCount !== void 0 && (n.headerRowCount = Math.round(i.headerRowCount)), i.totalsRowCount !== void 0 && (n.totalsRowCount = Math.round(i.totalsRowCount)), i.autoFilter !== void 0 && (n.autoFilter = Ni.toJSON(i.autoFilter)), i.dataDxfId !== void 0 && (n.dataDxfId = Math.round(i.dataDxfId)), i.headerRowCellStyle !== void 0 && (n.headerRowCellStyle = i.headerRowCellStyle), n
    },
    create(i) {
        return yi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u, c, p, m, s, h;
        const n = Gn();
        return n.id = (o = i.id) != null ? o : 0, n.name = (d = i.name) != null ? d : "", n.displayName = (t = i.displayName) != null ? t : "", n.ref = (r = i.ref) != null ? r : "", n.columns = ((u = i.columns) == null ? void 0 : u.map(f => pi.fromPartial(f))) || [], n.style = i.style !== void 0 && i.style !== null ? mi.fromPartial(i.style) : void 0, n.totalsRowShown = (c = i.totalsRowShown) != null ? c : void 0, n.headerRowCount = (p = i.headerRowCount) != null ? p : void 0, n.totalsRowCount = (m = i.totalsRowCount) != null ? m : void 0, n.autoFilter = i.autoFilter !== void 0 && i.autoFilter !== null ? Ni.fromPartial(i.autoFilter) : void 0, n.dataDxfId = (s = i.dataDxfId) != null ? s : void 0, n.headerRowCellStyle = (h = i.headerRowCellStyle) != null ? h : void 0, n
    }
};

function Xn() {
    return {
        name: "",
        caption: "",
        cache: "",
        fromAnchor: void 0,
        toAnchor: void 0,
        cacheId: void 0,
        width: void 0,
        height: void 0,
        fill: void 0,
        line: void 0
    }
}
const ki = {
    encode(i, n = new v) {
        return i.name !== "" && n.uint32(10).string(i.name), i.caption !== "" && n.uint32(18).string(i.caption), i.cache !== "" && n.uint32(26).string(i.cache), i.fromAnchor !== void 0 && I.encode(i.fromAnchor, n.uint32(34).fork()).join(), i.toAnchor !== void 0 && I.encode(i.toAnchor, n.uint32(42).fork()).join(), i.cacheId !== void 0 && n.uint32(48).int32(i.cacheId), i.width !== void 0 && n.uint32(57).double(i.width), i.height !== void 0 && n.uint32(65).double(i.height), i.fill !== void 0 && O.encode(i.fill, n.uint32(74).fork()).join(), i.line !== void 0 && B.encode(i.line, n.uint32(82).fork()).join(), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = Xn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.name = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.caption = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.cache = o.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;t.fromAnchor = I.decode(o, o.uint32());
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;t.toAnchor = I.decode(o, o.uint32());
                        continue
                    }
                case 6:
                    {
                        if (r !== 48) break;t.cacheId = o.int32();
                        continue
                    }
                case 7:
                    {
                        if (r !== 57) break;t.width = o.double();
                        continue
                    }
                case 8:
                    {
                        if (r !== 65) break;t.height = o.double();
                        continue
                    }
                case 9:
                    {
                        if (r !== 74) break;t.fill = O.decode(o, o.uint32());
                        continue
                    }
                case 10:
                    {
                        if (r !== 82) break;t.line = B.decode(o, o.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            name: e(i.name) ? a.String(i.name) : "",
            caption: e(i.caption) ? a.String(i.caption) : "",
            cache: e(i.cache) ? a.String(i.cache) : "",
            fromAnchor: e(i.fromAnchor) ? I.fromJSON(i.fromAnchor) : void 0,
            toAnchor: e(i.toAnchor) ? I.fromJSON(i.toAnchor) : void 0,
            cacheId: e(i.cacheId) ? a.Number(i.cacheId) : void 0,
            width: e(i.width) ? a.Number(i.width) : void 0,
            height: e(i.height) ? a.Number(i.height) : void 0,
            fill: e(i.fill) ? O.fromJSON(i.fill) : void 0,
            line: e(i.line) ? B.fromJSON(i.line) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.name !== "" && (n.name = i.name), i.caption !== "" && (n.caption = i.caption), i.cache !== "" && (n.cache = i.cache), i.fromAnchor !== void 0 && (n.fromAnchor = I.toJSON(i.fromAnchor)), i.toAnchor !== void 0 && (n.toAnchor = I.toJSON(i.toAnchor)), i.cacheId !== void 0 && (n.cacheId = Math.round(i.cacheId)), i.width !== void 0 && (n.width = i.width), i.height !== void 0 && (n.height = i.height), i.fill !== void 0 && (n.fill = O.toJSON(i.fill)), i.line !== void 0 && (n.line = B.toJSON(i.line)), n
    },
    create(i) {
        return ki.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u, c;
        const n = Xn();
        return n.name = (o = i.name) != null ? o : "", n.caption = (d = i.caption) != null ? d : "", n.cache = (t = i.cache) != null ? t : "", n.fromAnchor = i.fromAnchor !== void 0 && i.fromAnchor !== null ? I.fromPartial(i.fromAnchor) : void 0, n.toAnchor = i.toAnchor !== void 0 && i.toAnchor !== null ? I.fromPartial(i.toAnchor) : void 0, n.cacheId = (r = i.cacheId) != null ? r : void 0, n.width = (u = i.width) != null ? u : void 0, n.height = (c = i.height) != null ? c : void 0, n.fill = i.fill !== void 0 && i.fill !== null ? O.fromPartial(i.fill) : void 0, n.line = i.line !== void 0 && i.line !== null ? B.fromPartial(i.line) : void 0, n
    }
};

function Wn() {
    return {
        index: void 0,
        value: "",
        selected: void 0
    }
}
const Ti = {
    encode(i, n = new v) {
        return i.index !== void 0 && n.uint32(8).int32(i.index), i.value !== "" && n.uint32(18).string(i.value), i.selected !== void 0 && n.uint32(24).bool(i.selected), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = Wn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;t.index = o.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.value = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;t.selected = o.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            index: e(i.index) ? a.Number(i.index) : void 0,
            value: e(i.value) ? a.String(i.value) : "",
            selected: e(i.selected) ? a.Boolean(i.selected) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.index !== void 0 && (n.index = Math.round(i.index)), i.value !== "" && (n.value = i.value), i.selected !== void 0 && (n.selected = i.selected), n
    },
    create(i) {
        return Ti.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t;
        const n = Wn();
        return n.index = (o = i.index) != null ? o : void 0, n.value = (d = i.value) != null ? d : "", n.selected = (t = i.selected) != null ? t : void 0, n
    }
};

function Zn() {
    return {
        name: "",
        caption: void 0,
        pivotCacheId: void 0,
        pivotTableIds: [],
        columnName: void 0,
        items: []
    }
}
const Ai = {
    encode(i, n = new v) {
        i.name !== "" && n.uint32(10).string(i.name), i.caption !== void 0 && n.uint32(18).string(i.caption), i.pivotCacheId !== void 0 && n.uint32(24).int32(i.pivotCacheId), n.uint32(34).fork();
        for (const o of i.pivotTableIds) n.int32(o);
        n.join(), i.columnName !== void 0 && n.uint32(42).string(i.columnName);
        for (const o of i.items) Ti.encode(o, n.uint32(50).fork()).join();
        return n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = Zn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.name = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.caption = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;t.pivotCacheId = o.int32();
                        continue
                    }
                case 4:
                    {
                        if (r === 32) {
                            t.pivotTableIds.push(o.int32());
                            continue
                        }
                        if (r === 34) {
                            const u = o.uint32() + o.pos;
                            for (; o.pos < u;) t.pivotTableIds.push(o.int32());
                            continue
                        }
                        break
                    }
                case 5:
                    {
                        if (r !== 42) break;t.columnName = o.string();
                        continue
                    }
                case 6:
                    {
                        if (r !== 50) break;t.items.push(Ti.decode(o, o.uint32()));
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            name: e(i.name) ? a.String(i.name) : "",
            caption: e(i.caption) ? a.String(i.caption) : void 0,
            pivotCacheId: e(i.pivotCacheId) ? a.Number(i.pivotCacheId) : void 0,
            pivotTableIds: a.Array.isArray(i == null ? void 0 : i.pivotTableIds) ? i.pivotTableIds.map(n => a.Number(n)) : [],
            columnName: e(i.columnName) ? a.String(i.columnName) : void 0,
            items: a.Array.isArray(i == null ? void 0 : i.items) ? i.items.map(n => Ti.fromJSON(n)) : []
        }
    },
    toJSON(i) {
        var o, d;
        const n = {};
        return i.name !== "" && (n.name = i.name), i.caption !== void 0 && (n.caption = i.caption), i.pivotCacheId !== void 0 && (n.pivotCacheId = Math.round(i.pivotCacheId)), (o = i.pivotTableIds) != null && o.length && (n.pivotTableIds = i.pivotTableIds.map(t => Math.round(t))), i.columnName !== void 0 && (n.columnName = i.columnName), (d = i.items) != null && d.length && (n.items = i.items.map(t => Ti.toJSON(t))), n
    },
    create(i) {
        return Ai.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u, c;
        const n = Zn();
        return n.name = (o = i.name) != null ? o : "", n.caption = (d = i.caption) != null ? d : void 0, n.pivotCacheId = (t = i.pivotCacheId) != null ? t : void 0, n.pivotTableIds = ((r = i.pivotTableIds) == null ? void 0 : r.map(p => p)) || [], n.columnName = (u = i.columnName) != null ? u : void 0, n.items = ((c = i.items) == null ? void 0 : c.map(p => Ti.fromPartial(p))) || [], n
    }
};

function Kn() {
    return {
        reference: "",
        firstHeaderRow: void 0,
        firstDataRow: void 0,
        firstHeaderColumn: void 0,
        firstDataColumn: void 0
    }
}
const Oi = {
    encode(i, n = new v) {
        return i.reference !== "" && n.uint32(10).string(i.reference), i.firstHeaderRow !== void 0 && n.uint32(16).int32(i.firstHeaderRow), i.firstDataRow !== void 0 && n.uint32(24).int32(i.firstDataRow), i.firstHeaderColumn !== void 0 && n.uint32(32).int32(i.firstHeaderColumn), i.firstDataColumn !== void 0 && n.uint32(40).int32(i.firstDataColumn), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = Kn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.reference = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;t.firstHeaderRow = o.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;t.firstDataRow = o.int32();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;t.firstHeaderColumn = o.int32();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;t.firstDataColumn = o.int32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            reference: e(i.reference) ? a.String(i.reference) : "",
            firstHeaderRow: e(i.firstHeaderRow) ? a.Number(i.firstHeaderRow) : void 0,
            firstDataRow: e(i.firstDataRow) ? a.Number(i.firstDataRow) : void 0,
            firstHeaderColumn: e(i.firstHeaderColumn) ? a.Number(i.firstHeaderColumn) : void 0,
            firstDataColumn: e(i.firstDataColumn) ? a.Number(i.firstDataColumn) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.reference !== "" && (n.reference = i.reference), i.firstHeaderRow !== void 0 && (n.firstHeaderRow = Math.round(i.firstHeaderRow)), i.firstDataRow !== void 0 && (n.firstDataRow = Math.round(i.firstDataRow)), i.firstHeaderColumn !== void 0 && (n.firstHeaderColumn = Math.round(i.firstHeaderColumn)), i.firstDataColumn !== void 0 && (n.firstDataColumn = Math.round(i.firstDataColumn)), n
    },
    create(i) {
        return Oi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u;
        const n = Kn();
        return n.reference = (o = i.reference) != null ? o : "", n.firstHeaderRow = (d = i.firstHeaderRow) != null ? d : void 0, n.firstDataRow = (t = i.firstDataRow) != null ? t : void 0, n.firstHeaderColumn = (r = i.firstHeaderColumn) != null ? r : void 0, n.firstDataColumn = (u = i.firstDataColumn) != null ? u : void 0, n
    }
};

function zn() {
    return {
        type: void 0,
        index: void 0,
        hidden: void 0,
        calculated: void 0,
        missing: void 0
    }
}
const C = {
    encode(i, n = new v) {
        return i.type !== void 0 && n.uint32(10).string(i.type), i.index !== void 0 && n.uint32(16).int32(i.index), i.hidden !== void 0 && n.uint32(24).bool(i.hidden), i.calculated !== void 0 && n.uint32(32).bool(i.calculated), i.missing !== void 0 && n.uint32(40).bool(i.missing), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = zn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.type = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;t.index = o.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;t.hidden = o.bool();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;t.calculated = o.bool();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;t.missing = o.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            type: e(i.type) ? a.String(i.type) : void 0,
            index: e(i.index) ? a.Number(i.index) : void 0,
            hidden: e(i.hidden) ? a.Boolean(i.hidden) : void 0,
            calculated: e(i.calculated) ? a.Boolean(i.calculated) : void 0,
            missing: e(i.missing) ? a.Boolean(i.missing) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.type !== void 0 && (n.type = i.type), i.index !== void 0 && (n.index = Math.round(i.index)), i.hidden !== void 0 && (n.hidden = i.hidden), i.calculated !== void 0 && (n.calculated = i.calculated), i.missing !== void 0 && (n.missing = i.missing), n
    },
    create(i) {
        return C.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u;
        const n = zn();
        return n.type = (o = i.type) != null ? o : void 0, n.index = (d = i.index) != null ? d : void 0, n.hidden = (t = i.hidden) != null ? t : void 0, n.calculated = (r = i.calculated) != null ? r : void 0, n.missing = (u = i.missing) != null ? u : void 0, n
    }
};

function Qn() {
    return {
        index: 0,
        name: "",
        axis: void 0,
        dataField: void 0,
        showAll: void 0,
        subtotalTop: void 0,
        items: [],
        numberFormatId: void 0,
        sortType: void 0,
        axisEnum: void 0,
        sortTypeEnum: void 0
    }
}
const Ci = {
    encode(i, n = new v) {
        i.index !== 0 && n.uint32(8).int32(i.index), i.name !== "" && n.uint32(18).string(i.name), i.axis !== void 0 && n.uint32(26).string(i.axis), i.dataField !== void 0 && n.uint32(32).bool(i.dataField), i.showAll !== void 0 && n.uint32(40).bool(i.showAll), i.subtotalTop !== void 0 && n.uint32(48).bool(i.subtotalTop);
        for (const o of i.items) C.encode(o, n.uint32(58).fork()).join();
        return i.numberFormatId !== void 0 && n.uint32(64).uint32(i.numberFormatId), i.sortType !== void 0 && n.uint32(74).string(i.sortType), i.axisEnum !== void 0 && n.uint32(240).int32(i.axisEnum), i.sortTypeEnum !== void 0 && n.uint32(248).int32(i.sortTypeEnum), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = Qn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;t.index = o.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.name = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.axis = o.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;t.dataField = o.bool();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;t.showAll = o.bool();
                        continue
                    }
                case 6:
                    {
                        if (r !== 48) break;t.subtotalTop = o.bool();
                        continue
                    }
                case 7:
                    {
                        if (r !== 58) break;t.items.push(C.decode(o, o.uint32()));
                        continue
                    }
                case 8:
                    {
                        if (r !== 64) break;t.numberFormatId = o.uint32();
                        continue
                    }
                case 9:
                    {
                        if (r !== 74) break;t.sortType = o.string();
                        continue
                    }
                case 30:
                    {
                        if (r !== 240) break;t.axisEnum = o.int32();
                        continue
                    }
                case 31:
                    {
                        if (r !== 248) break;t.sortTypeEnum = o.int32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            index: e(i.index) ? a.Number(i.index) : 0,
            name: e(i.name) ? a.String(i.name) : "",
            axis: e(i.axis) ? a.String(i.axis) : void 0,
            dataField: e(i.dataField) ? a.Boolean(i.dataField) : void 0,
            showAll: e(i.showAll) ? a.Boolean(i.showAll) : void 0,
            subtotalTop: e(i.subtotalTop) ? a.Boolean(i.subtotalTop) : void 0,
            items: a.Array.isArray(i == null ? void 0 : i.items) ? i.items.map(n => C.fromJSON(n)) : [],
            numberFormatId: e(i.numberFormatId) ? a.Number(i.numberFormatId) : void 0,
            sortType: e(i.sortType) ? a.String(i.sortType) : void 0,
            axisEnum: e(i.axisEnum) ? No(i.axisEnum) : void 0,
            sortTypeEnum: e(i.sortTypeEnum) ? ko(i.sortTypeEnum) : void 0
        }
    },
    toJSON(i) {
        var o;
        const n = {};
        return i.index !== 0 && (n.index = Math.round(i.index)), i.name !== "" && (n.name = i.name), i.axis !== void 0 && (n.axis = i.axis), i.dataField !== void 0 && (n.dataField = i.dataField), i.showAll !== void 0 && (n.showAll = i.showAll), i.subtotalTop !== void 0 && (n.subtotalTop = i.subtotalTop), (o = i.items) != null && o.length && (n.items = i.items.map(d => C.toJSON(d))), i.numberFormatId !== void 0 && (n.numberFormatId = Math.round(i.numberFormatId)), i.sortType !== void 0 && (n.sortType = i.sortType), i.axisEnum !== void 0 && (n.axisEnum = yo(i.axisEnum)), i.sortTypeEnum !== void 0 && (n.sortTypeEnum = To(i.sortTypeEnum)), n
    },
    create(i) {
        return Ci.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u, c, p, m, s, h, f;
        const n = Qn();
        return n.index = (o = i.index) != null ? o : 0, n.name = (d = i.name) != null ? d : "", n.axis = (t = i.axis) != null ? t : void 0, n.dataField = (r = i.dataField) != null ? r : void 0, n.showAll = (u = i.showAll) != null ? u : void 0, n.subtotalTop = (c = i.subtotalTop) != null ? c : void 0, n.items = ((p = i.items) == null ? void 0 : p.map(S => C.fromPartial(S))) || [], n.numberFormatId = (m = i.numberFormatId) != null ? m : void 0, n.sortType = (s = i.sortType) != null ? s : void 0, n.axisEnum = (h = i.axisEnum) != null ? h : void 0, n.sortTypeEnum = (f = i.sortTypeEnum) != null ? f : void 0, n
    }
};

function qn() {
    return {
        field: 0,
        item: void 0,
        name: void 0
    }
}
const Ei = {
    encode(i, n = new v) {
        return i.field !== 0 && n.uint32(8).int32(i.field), i.item !== void 0 && n.uint32(16).int32(i.item), i.name !== void 0 && n.uint32(26).string(i.name), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = qn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;t.field = o.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;t.item = o.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.name = o.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            field: e(i.field) ? a.Number(i.field) : 0,
            item: e(i.item) ? a.Number(i.item) : void 0,
            name: e(i.name) ? a.String(i.name) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.field !== 0 && (n.field = Math.round(i.field)), i.item !== void 0 && (n.item = Math.round(i.item)), i.name !== void 0 && (n.name = i.name), n
    },
    create(i) {
        return Ei.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t;
        const n = qn();
        return n.field = (o = i.field) != null ? o : 0, n.item = (d = i.item) != null ? d : void 0, n.name = (t = i.name) != null ? t : void 0, n
    }
};

function $n() {
    return {
        field: 0,
        name: void 0,
        subtotal: void 0,
        numberFormatId: void 0,
        showAs: void 0,
        baseField: void 0,
        baseItem: void 0,
        subtotalEnum: void 0
    }
}
const Pi = {
    encode(i, n = new v) {
        return i.field !== 0 && n.uint32(8).int32(i.field), i.name !== void 0 && n.uint32(18).string(i.name), i.subtotal !== void 0 && n.uint32(26).string(i.subtotal), i.numberFormatId !== void 0 && n.uint32(32).uint32(i.numberFormatId), i.showAs !== void 0 && n.uint32(42).string(i.showAs), i.baseField !== void 0 && n.uint32(48).int32(i.baseField), i.baseItem !== void 0 && n.uint32(56).int32(i.baseItem), i.subtotalEnum !== void 0 && n.uint32(240).int32(i.subtotalEnum), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = $n();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;t.field = o.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.name = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.subtotal = o.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;t.numberFormatId = o.uint32();
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;t.showAs = o.string();
                        continue
                    }
                case 6:
                    {
                        if (r !== 48) break;t.baseField = o.int32();
                        continue
                    }
                case 7:
                    {
                        if (r !== 56) break;t.baseItem = o.int32();
                        continue
                    }
                case 30:
                    {
                        if (r !== 240) break;t.subtotalEnum = o.int32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            field: e(i.field) ? a.Number(i.field) : 0,
            name: e(i.name) ? a.String(i.name) : void 0,
            subtotal: e(i.subtotal) ? a.String(i.subtotal) : void 0,
            numberFormatId: e(i.numberFormatId) ? a.Number(i.numberFormatId) : void 0,
            showAs: e(i.showAs) ? a.String(i.showAs) : void 0,
            baseField: e(i.baseField) ? a.Number(i.baseField) : void 0,
            baseItem: e(i.baseItem) ? a.Number(i.baseItem) : void 0,
            subtotalEnum: e(i.subtotalEnum) ? Ao(i.subtotalEnum) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.field !== 0 && (n.field = Math.round(i.field)), i.name !== void 0 && (n.name = i.name), i.subtotal !== void 0 && (n.subtotal = i.subtotal), i.numberFormatId !== void 0 && (n.numberFormatId = Math.round(i.numberFormatId)), i.showAs !== void 0 && (n.showAs = i.showAs), i.baseField !== void 0 && (n.baseField = Math.round(i.baseField)), i.baseItem !== void 0 && (n.baseItem = Math.round(i.baseItem)), i.subtotalEnum !== void 0 && (n.subtotalEnum = Oo(i.subtotalEnum)), n
    },
    create(i) {
        return Pi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u, c, p, m;
        const n = $n();
        return n.field = (o = i.field) != null ? o : 0, n.name = (d = i.name) != null ? d : void 0, n.subtotal = (t = i.subtotal) != null ? t : void 0, n.numberFormatId = (r = i.numberFormatId) != null ? r : void 0, n.showAs = (u = i.showAs) != null ? u : void 0, n.baseField = (c = i.baseField) != null ? c : void 0, n.baseItem = (p = i.baseItem) != null ? p : void 0, n.subtotalEnum = (m = i.subtotalEnum) != null ? m : void 0, n
    }
};

function gn() {
    return {
        field: 0,
        type: "",
        name: void 0,
        description: void 0,
        typeEnum: void 0
    }
}
const _i = {
    encode(i, n = new v) {
        return i.field !== 0 && n.uint32(8).int32(i.field), i.type !== "" && n.uint32(18).string(i.type), i.name !== void 0 && n.uint32(26).string(i.name), i.description !== void 0 && n.uint32(34).string(i.description), i.typeEnum !== void 0 && n.uint32(240).int32(i.typeEnum), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = gn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;t.field = o.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.type = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.name = o.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;t.description = o.string();
                        continue
                    }
                case 30:
                    {
                        if (r !== 240) break;t.typeEnum = o.int32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            field: e(i.field) ? a.Number(i.field) : 0,
            type: e(i.type) ? a.String(i.type) : "",
            name: e(i.name) ? a.String(i.name) : void 0,
            description: e(i.description) ? a.String(i.description) : void 0,
            typeEnum: e(i.typeEnum) ? Co(i.typeEnum) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.field !== 0 && (n.field = Math.round(i.field)), i.type !== "" && (n.type = i.type), i.name !== void 0 && (n.name = i.name), i.description !== void 0 && (n.description = i.description), i.typeEnum !== void 0 && (n.typeEnum = Eo(i.typeEnum)), n
    },
    create(i) {
        return _i.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u;
        const n = gn();
        return n.field = (o = i.field) != null ? o : 0, n.type = (d = i.type) != null ? d : "", n.name = (t = i.name) != null ? t : void 0, n.description = (r = i.description) != null ? r : void 0, n.typeEnum = (u = i.typeEnum) != null ? u : void 0, n
    }
};

function bn() {
    return {
        name: "",
        cacheId: 0,
        location: void 0,
        dataOnRows: void 0,
        rowGrandTotals: void 0,
        columnGrandTotals: void 0,
        pivotFields: [],
        rowFields: [],
        columnFields: [],
        pageFields: [],
        dataFields: [],
        filters: [],
        compact: void 0,
        outline: void 0,
        showDrill: void 0,
        styleName: void 0,
        rowItems: [],
        columnItems: [],
        showRowHeaders: void 0,
        showColHeaders: void 0,
        showRowStripes: void 0,
        showColStripes: void 0,
        showLastColumn: void 0
    }
}
const Fi = {
    encode(i, n = new v) {
        i.name !== "" && n.uint32(10).string(i.name), i.cacheId !== 0 && n.uint32(16).int32(i.cacheId), i.location !== void 0 && Oi.encode(i.location, n.uint32(26).fork()).join(), i.dataOnRows !== void 0 && n.uint32(32).bool(i.dataOnRows), i.rowGrandTotals !== void 0 && n.uint32(40).bool(i.rowGrandTotals), i.columnGrandTotals !== void 0 && n.uint32(48).bool(i.columnGrandTotals);
        for (const o of i.pivotFields) Ci.encode(o, n.uint32(58).fork()).join();
        n.uint32(66).fork();
        for (const o of i.rowFields) n.int32(o);
        n.join(), n.uint32(74).fork();
        for (const o of i.columnFields) n.int32(o);
        n.join();
        for (const o of i.pageFields) Ei.encode(o, n.uint32(82).fork()).join();
        for (const o of i.dataFields) Pi.encode(o, n.uint32(90).fork()).join();
        for (const o of i.filters) _i.encode(o, n.uint32(98).fork()).join();
        i.compact !== void 0 && n.uint32(104).bool(i.compact), i.outline !== void 0 && n.uint32(112).bool(i.outline), i.showDrill !== void 0 && n.uint32(120).bool(i.showDrill), i.styleName !== void 0 && n.uint32(130).string(i.styleName);
        for (const o of i.rowItems) C.encode(o, n.uint32(138).fork()).join();
        for (const o of i.columnItems) C.encode(o, n.uint32(146).fork()).join();
        return i.showRowHeaders !== void 0 && n.uint32(152).bool(i.showRowHeaders), i.showColHeaders !== void 0 && n.uint32(160).bool(i.showColHeaders), i.showRowStripes !== void 0 && n.uint32(168).bool(i.showRowStripes), i.showColStripes !== void 0 && n.uint32(176).bool(i.showColStripes), i.showLastColumn !== void 0 && n.uint32(184).bool(i.showLastColumn), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = bn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.name = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;t.cacheId = o.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.location = Oi.decode(o, o.uint32());
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;t.dataOnRows = o.bool();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;t.rowGrandTotals = o.bool();
                        continue
                    }
                case 6:
                    {
                        if (r !== 48) break;t.columnGrandTotals = o.bool();
                        continue
                    }
                case 7:
                    {
                        if (r !== 58) break;t.pivotFields.push(Ci.decode(o, o.uint32()));
                        continue
                    }
                case 8:
                    {
                        if (r === 64) {
                            t.rowFields.push(o.int32());
                            continue
                        }
                        if (r === 66) {
                            const u = o.uint32() + o.pos;
                            for (; o.pos < u;) t.rowFields.push(o.int32());
                            continue
                        }
                        break
                    }
                case 9:
                    {
                        if (r === 72) {
                            t.columnFields.push(o.int32());
                            continue
                        }
                        if (r === 74) {
                            const u = o.uint32() + o.pos;
                            for (; o.pos < u;) t.columnFields.push(o.int32());
                            continue
                        }
                        break
                    }
                case 10:
                    {
                        if (r !== 82) break;t.pageFields.push(Ei.decode(o, o.uint32()));
                        continue
                    }
                case 11:
                    {
                        if (r !== 90) break;t.dataFields.push(Pi.decode(o, o.uint32()));
                        continue
                    }
                case 12:
                    {
                        if (r !== 98) break;t.filters.push(_i.decode(o, o.uint32()));
                        continue
                    }
                case 13:
                    {
                        if (r !== 104) break;t.compact = o.bool();
                        continue
                    }
                case 14:
                    {
                        if (r !== 112) break;t.outline = o.bool();
                        continue
                    }
                case 15:
                    {
                        if (r !== 120) break;t.showDrill = o.bool();
                        continue
                    }
                case 16:
                    {
                        if (r !== 130) break;t.styleName = o.string();
                        continue
                    }
                case 17:
                    {
                        if (r !== 138) break;t.rowItems.push(C.decode(o, o.uint32()));
                        continue
                    }
                case 18:
                    {
                        if (r !== 146) break;t.columnItems.push(C.decode(o, o.uint32()));
                        continue
                    }
                case 19:
                    {
                        if (r !== 152) break;t.showRowHeaders = o.bool();
                        continue
                    }
                case 20:
                    {
                        if (r !== 160) break;t.showColHeaders = o.bool();
                        continue
                    }
                case 21:
                    {
                        if (r !== 168) break;t.showRowStripes = o.bool();
                        continue
                    }
                case 22:
                    {
                        if (r !== 176) break;t.showColStripes = o.bool();
                        continue
                    }
                case 23:
                    {
                        if (r !== 184) break;t.showLastColumn = o.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            name: e(i.name) ? a.String(i.name) : "",
            cacheId: e(i.cacheId) ? a.Number(i.cacheId) : 0,
            location: e(i.location) ? Oi.fromJSON(i.location) : void 0,
            dataOnRows: e(i.dataOnRows) ? a.Boolean(i.dataOnRows) : void 0,
            rowGrandTotals: e(i.rowGrandTotals) ? a.Boolean(i.rowGrandTotals) : void 0,
            columnGrandTotals: e(i.columnGrandTotals) ? a.Boolean(i.columnGrandTotals) : void 0,
            pivotFields: a.Array.isArray(i == null ? void 0 : i.pivotFields) ? i.pivotFields.map(n => Ci.fromJSON(n)) : [],
            rowFields: a.Array.isArray(i == null ? void 0 : i.rowFields) ? i.rowFields.map(n => a.Number(n)) : [],
            columnFields: a.Array.isArray(i == null ? void 0 : i.columnFields) ? i.columnFields.map(n => a.Number(n)) : [],
            pageFields: a.Array.isArray(i == null ? void 0 : i.pageFields) ? i.pageFields.map(n => Ei.fromJSON(n)) : [],
            dataFields: a.Array.isArray(i == null ? void 0 : i.dataFields) ? i.dataFields.map(n => Pi.fromJSON(n)) : [],
            filters: a.Array.isArray(i == null ? void 0 : i.filters) ? i.filters.map(n => _i.fromJSON(n)) : [],
            compact: e(i.compact) ? a.Boolean(i.compact) : void 0,
            outline: e(i.outline) ? a.Boolean(i.outline) : void 0,
            showDrill: e(i.showDrill) ? a.Boolean(i.showDrill) : void 0,
            styleName: e(i.styleName) ? a.String(i.styleName) : void 0,
            rowItems: a.Array.isArray(i == null ? void 0 : i.rowItems) ? i.rowItems.map(n => C.fromJSON(n)) : [],
            columnItems: a.Array.isArray(i == null ? void 0 : i.columnItems) ? i.columnItems.map(n => C.fromJSON(n)) : [],
            showRowHeaders: e(i.showRowHeaders) ? a.Boolean(i.showRowHeaders) : void 0,
            showColHeaders: e(i.showColHeaders) ? a.Boolean(i.showColHeaders) : void 0,
            showRowStripes: e(i.showRowStripes) ? a.Boolean(i.showRowStripes) : void 0,
            showColStripes: e(i.showColStripes) ? a.Boolean(i.showColStripes) : void 0,
            showLastColumn: e(i.showLastColumn) ? a.Boolean(i.showLastColumn) : void 0
        }
    },
    toJSON(i) {
        var o, d, t, r, u, c, p, m;
        const n = {};
        return i.name !== "" && (n.name = i.name), i.cacheId !== 0 && (n.cacheId = Math.round(i.cacheId)), i.location !== void 0 && (n.location = Oi.toJSON(i.location)), i.dataOnRows !== void 0 && (n.dataOnRows = i.dataOnRows), i.rowGrandTotals !== void 0 && (n.rowGrandTotals = i.rowGrandTotals), i.columnGrandTotals !== void 0 && (n.columnGrandTotals = i.columnGrandTotals), (o = i.pivotFields) != null && o.length && (n.pivotFields = i.pivotFields.map(s => Ci.toJSON(s))), (d = i.rowFields) != null && d.length && (n.rowFields = i.rowFields.map(s => Math.round(s))), (t = i.columnFields) != null && t.length && (n.columnFields = i.columnFields.map(s => Math.round(s))), (r = i.pageFields) != null && r.length && (n.pageFields = i.pageFields.map(s => Ei.toJSON(s))), (u = i.dataFields) != null && u.length && (n.dataFields = i.dataFields.map(s => Pi.toJSON(s))), (c = i.filters) != null && c.length && (n.filters = i.filters.map(s => _i.toJSON(s))), i.compact !== void 0 && (n.compact = i.compact), i.outline !== void 0 && (n.outline = i.outline), i.showDrill !== void 0 && (n.showDrill = i.showDrill), i.styleName !== void 0 && (n.styleName = i.styleName), (p = i.rowItems) != null && p.length && (n.rowItems = i.rowItems.map(s => C.toJSON(s))), (m = i.columnItems) != null && m.length && (n.columnItems = i.columnItems.map(s => C.toJSON(s))), i.showRowHeaders !== void 0 && (n.showRowHeaders = i.showRowHeaders), i.showColHeaders !== void 0 && (n.showColHeaders = i.showColHeaders), i.showRowStripes !== void 0 && (n.showRowStripes = i.showRowStripes), i.showColStripes !== void 0 && (n.showColStripes = i.showColStripes), i.showLastColumn !== void 0 && (n.showLastColumn = i.showLastColumn), n
    },
    create(i) {
        return Fi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u, c, p, m, s, h, f, S, T, w, _, M, Ui, Vi, Yi, Hi, k, Qi;
        const n = bn();
        return n.name = (o = i.name) != null ? o : "", n.cacheId = (d = i.cacheId) != null ? d : 0, n.location = i.location !== void 0 && i.location !== null ? Oi.fromPartial(i.location) : void 0, n.dataOnRows = (t = i.dataOnRows) != null ? t : void 0, n.rowGrandTotals = (r = i.rowGrandTotals) != null ? r : void 0, n.columnGrandTotals = (u = i.columnGrandTotals) != null ? u : void 0, n.pivotFields = ((c = i.pivotFields) == null ? void 0 : c.map(F => Ci.fromPartial(F))) || [], n.rowFields = ((p = i.rowFields) == null ? void 0 : p.map(F => F)) || [], n.columnFields = ((m = i.columnFields) == null ? void 0 : m.map(F => F)) || [], n.pageFields = ((s = i.pageFields) == null ? void 0 : s.map(F => Ei.fromPartial(F))) || [], n.dataFields = ((h = i.dataFields) == null ? void 0 : h.map(F => Pi.fromPartial(F))) || [], n.filters = ((f = i.filters) == null ? void 0 : f.map(F => _i.fromPartial(F))) || [], n.compact = (S = i.compact) != null ? S : void 0, n.outline = (T = i.outline) != null ? T : void 0, n.showDrill = (w = i.showDrill) != null ? w : void 0, n.styleName = (_ = i.styleName) != null ? _ : void 0, n.rowItems = ((M = i.rowItems) == null ? void 0 : M.map(F => C.fromPartial(F))) || [], n.columnItems = ((Ui = i.columnItems) == null ? void 0 : Ui.map(F => C.fromPartial(F))) || [], n.showRowHeaders = (Vi = i.showRowHeaders) != null ? Vi : void 0, n.showColHeaders = (Yi = i.showColHeaders) != null ? Yi : void 0, n.showRowStripes = (Hi = i.showRowStripes) != null ? Hi : void 0, n.showColStripes = (k = i.showColStripes) != null ? k : void 0, n.showLastColumn = (Qi = i.showLastColumn) != null ? Qi : void 0, n
    }
};

function jn() {
    return {
        name: "",
        caption: "",
        cache: "",
        lockedPosition: void 0,
        displayHeader: void 0,
        showNoDataItems: void 0,
        sortBy: void 0,
        style: void 0,
        fromAnchor: void 0,
        toAnchor: void 0,
        cacheId: void 0,
        width: void 0,
        height: void 0,
        isMultiSelect: void 0,
        fill: void 0,
        line: void 0,
        headerTextStyle: void 0,
        sortByEnum: void 0
    }
}
const wi = {
    encode(i, n = new v) {
        return i.name !== "" && n.uint32(10).string(i.name), i.caption !== "" && n.uint32(18).string(i.caption), i.cache !== "" && n.uint32(26).string(i.cache), i.lockedPosition !== void 0 && n.uint32(32).bool(i.lockedPosition), i.displayHeader !== void 0 && n.uint32(40).bool(i.displayHeader), i.showNoDataItems !== void 0 && n.uint32(48).bool(i.showNoDataItems), i.sortBy !== void 0 && n.uint32(58).string(i.sortBy), i.style !== void 0 && n.uint32(66).string(i.style), i.fromAnchor !== void 0 && I.encode(i.fromAnchor, n.uint32(74).fork()).join(), i.toAnchor !== void 0 && I.encode(i.toAnchor, n.uint32(82).fork()).join(), i.cacheId !== void 0 && n.uint32(88).int32(i.cacheId), i.width !== void 0 && n.uint32(97).double(i.width), i.height !== void 0 && n.uint32(105).double(i.height), i.isMultiSelect !== void 0 && n.uint32(112).bool(i.isMultiSelect), i.fill !== void 0 && O.encode(i.fill, n.uint32(122).fork()).join(), i.line !== void 0 && B.encode(i.line, n.uint32(130).fork()).join(), i.headerTextStyle !== void 0 && A.encode(i.headerTextStyle, n.uint32(138).fork()).join(), i.sortByEnum !== void 0 && n.uint32(144).int32(i.sortByEnum), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = jn();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.name = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.caption = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.cache = o.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;t.lockedPosition = o.bool();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;t.displayHeader = o.bool();
                        continue
                    }
                case 6:
                    {
                        if (r !== 48) break;t.showNoDataItems = o.bool();
                        continue
                    }
                case 7:
                    {
                        if (r !== 58) break;t.sortBy = o.string();
                        continue
                    }
                case 8:
                    {
                        if (r !== 66) break;t.style = o.string();
                        continue
                    }
                case 9:
                    {
                        if (r !== 74) break;t.fromAnchor = I.decode(o, o.uint32());
                        continue
                    }
                case 10:
                    {
                        if (r !== 82) break;t.toAnchor = I.decode(o, o.uint32());
                        continue
                    }
                case 11:
                    {
                        if (r !== 88) break;t.cacheId = o.int32();
                        continue
                    }
                case 12:
                    {
                        if (r !== 97) break;t.width = o.double();
                        continue
                    }
                case 13:
                    {
                        if (r !== 105) break;t.height = o.double();
                        continue
                    }
                case 14:
                    {
                        if (r !== 112) break;t.isMultiSelect = o.bool();
                        continue
                    }
                case 15:
                    {
                        if (r !== 122) break;t.fill = O.decode(o, o.uint32());
                        continue
                    }
                case 16:
                    {
                        if (r !== 130) break;t.line = B.decode(o, o.uint32());
                        continue
                    }
                case 17:
                    {
                        if (r !== 138) break;t.headerTextStyle = A.decode(o, o.uint32());
                        continue
                    }
                case 18:
                    {
                        if (r !== 144) break;t.sortByEnum = o.int32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            name: e(i.name) ? a.String(i.name) : "",
            caption: e(i.caption) ? a.String(i.caption) : "",
            cache: e(i.cache) ? a.String(i.cache) : "",
            lockedPosition: e(i.lockedPosition) ? a.Boolean(i.lockedPosition) : void 0,
            displayHeader: e(i.displayHeader) ? a.Boolean(i.displayHeader) : void 0,
            showNoDataItems: e(i.showNoDataItems) ? a.Boolean(i.showNoDataItems) : void 0,
            sortBy: e(i.sortBy) ? a.String(i.sortBy) : void 0,
            style: e(i.style) ? a.String(i.style) : void 0,
            fromAnchor: e(i.fromAnchor) ? I.fromJSON(i.fromAnchor) : void 0,
            toAnchor: e(i.toAnchor) ? I.fromJSON(i.toAnchor) : void 0,
            cacheId: e(i.cacheId) ? a.Number(i.cacheId) : void 0,
            width: e(i.width) ? a.Number(i.width) : void 0,
            height: e(i.height) ? a.Number(i.height) : void 0,
            isMultiSelect: e(i.isMultiSelect) ? a.Boolean(i.isMultiSelect) : void 0,
            fill: e(i.fill) ? O.fromJSON(i.fill) : void 0,
            line: e(i.line) ? B.fromJSON(i.line) : void 0,
            headerTextStyle: e(i.headerTextStyle) ? A.fromJSON(i.headerTextStyle) : void 0,
            sortByEnum: e(i.sortByEnum) ? so(i.sortByEnum) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.name !== "" && (n.name = i.name), i.caption !== "" && (n.caption = i.caption), i.cache !== "" && (n.cache = i.cache), i.lockedPosition !== void 0 && (n.lockedPosition = i.lockedPosition), i.displayHeader !== void 0 && (n.displayHeader = i.displayHeader), i.showNoDataItems !== void 0 && (n.showNoDataItems = i.showNoDataItems), i.sortBy !== void 0 && (n.sortBy = i.sortBy), i.style !== void 0 && (n.style = i.style), i.fromAnchor !== void 0 && (n.fromAnchor = I.toJSON(i.fromAnchor)), i.toAnchor !== void 0 && (n.toAnchor = I.toJSON(i.toAnchor)), i.cacheId !== void 0 && (n.cacheId = Math.round(i.cacheId)), i.width !== void 0 && (n.width = i.width), i.height !== void 0 && (n.height = i.height), i.isMultiSelect !== void 0 && (n.isMultiSelect = i.isMultiSelect), i.fill !== void 0 && (n.fill = O.toJSON(i.fill)), i.line !== void 0 && (n.line = B.toJSON(i.line)), i.headerTextStyle !== void 0 && (n.headerTextStyle = A.toJSON(i.headerTextStyle)), i.sortByEnum !== void 0 && (n.sortByEnum = ho(i.sortByEnum)), n
    },
    create(i) {
        return wi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u, c, p, m, s, h, f, S, T;
        const n = jn();
        return n.name = (o = i.name) != null ? o : "", n.caption = (d = i.caption) != null ? d : "", n.cache = (t = i.cache) != null ? t : "", n.lockedPosition = (r = i.lockedPosition) != null ? r : void 0, n.displayHeader = (u = i.displayHeader) != null ? u : void 0, n.showNoDataItems = (c = i.showNoDataItems) != null ? c : void 0, n.sortBy = (p = i.sortBy) != null ? p : void 0, n.style = (m = i.style) != null ? m : void 0, n.fromAnchor = i.fromAnchor !== void 0 && i.fromAnchor !== null ? I.fromPartial(i.fromAnchor) : void 0, n.toAnchor = i.toAnchor !== void 0 && i.toAnchor !== null ? I.fromPartial(i.toAnchor) : void 0, n.cacheId = (s = i.cacheId) != null ? s : void 0, n.width = (h = i.width) != null ? h : void 0, n.height = (f = i.height) != null ? f : void 0, n.isMultiSelect = (S = i.isMultiSelect) != null ? S : void 0, n.fill = i.fill !== void 0 && i.fill !== null ? O.fromPartial(i.fill) : void 0, n.line = i.line !== void 0 && i.line !== null ? B.fromPartial(i.line) : void 0, n.headerTextStyle = i.headerTextStyle !== void 0 && i.headerTextStyle !== null ? A.fromPartial(i.headerTextStyle) : void 0, n.sortByEnum = (T = i.sortByEnum) != null ? T : void 0, n
    }
};

function io() {
    return {
        index: void 0,
        value: "",
        selected: void 0,
        hasData: void 0,
        hidden: void 0
    }
}
const Ri = {
    encode(i, n = new v) {
        return i.index !== void 0 && n.uint32(8).int32(i.index), i.value !== "" && n.uint32(18).string(i.value), i.selected !== void 0 && n.uint32(24).bool(i.selected), i.hasData !== void 0 && n.uint32(32).bool(i.hasData), i.hidden !== void 0 && n.uint32(40).bool(i.hidden), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = io();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;t.index = o.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.value = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;t.selected = o.bool();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;t.hasData = o.bool();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;t.hidden = o.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            index: e(i.index) ? a.Number(i.index) : void 0,
            value: e(i.value) ? a.String(i.value) : "",
            selected: e(i.selected) ? a.Boolean(i.selected) : void 0,
            hasData: e(i.hasData) ? a.Boolean(i.hasData) : void 0,
            hidden: e(i.hidden) ? a.Boolean(i.hidden) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.index !== void 0 && (n.index = Math.round(i.index)), i.value !== "" && (n.value = i.value), i.selected !== void 0 && (n.selected = i.selected), i.hasData !== void 0 && (n.hasData = i.hasData), i.hidden !== void 0 && (n.hidden = i.hidden), n
    },
    create(i) {
        return Ri.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u;
        const n = io();
        return n.index = (o = i.index) != null ? o : void 0, n.value = (d = i.value) != null ? d : "", n.selected = (t = i.selected) != null ? t : void 0, n.hasData = (r = i.hasData) != null ? r : void 0, n.hidden = (u = i.hidden) != null ? u : void 0, n
    }
};

function no() {
    return {
        name: "",
        caption: void 0,
        sourceName: void 0,
        type: void 0,
        pivotCacheId: void 0,
        pivotTableIds: [],
        tableId: void 0,
        tableName: void 0,
        columnName: void 0,
        crossFilter: void 0,
        sortOrder: void 0,
        items: [],
        typeEnum: void 0,
        crossFilterEnum: void 0
    }
}
const xi = {
    encode(i, n = new v) {
        i.name !== "" && n.uint32(10).string(i.name), i.caption !== void 0 && n.uint32(18).string(i.caption), i.sourceName !== void 0 && n.uint32(26).string(i.sourceName), i.type !== void 0 && n.uint32(34).string(i.type), i.pivotCacheId !== void 0 && n.uint32(40).int32(i.pivotCacheId), n.uint32(50).fork();
        for (const o of i.pivotTableIds) n.int32(o);
        n.join(), i.tableId !== void 0 && n.uint32(56).int32(i.tableId), i.tableName !== void 0 && n.uint32(66).string(i.tableName), i.columnName !== void 0 && n.uint32(74).string(i.columnName), i.crossFilter !== void 0 && n.uint32(82).string(i.crossFilter), i.sortOrder !== void 0 && n.uint32(90).string(i.sortOrder);
        for (const o of i.items) Ri.encode(o, n.uint32(98).fork()).join();
        return i.typeEnum !== void 0 && n.uint32(104).int32(i.typeEnum), i.crossFilterEnum !== void 0 && n.uint32(112).int32(i.crossFilterEnum), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = no();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.name = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.caption = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.sourceName = o.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;t.type = o.string();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;t.pivotCacheId = o.int32();
                        continue
                    }
                case 6:
                    {
                        if (r === 48) {
                            t.pivotTableIds.push(o.int32());
                            continue
                        }
                        if (r === 50) {
                            const u = o.uint32() + o.pos;
                            for (; o.pos < u;) t.pivotTableIds.push(o.int32());
                            continue
                        }
                        break
                    }
                case 7:
                    {
                        if (r !== 56) break;t.tableId = o.int32();
                        continue
                    }
                case 8:
                    {
                        if (r !== 66) break;t.tableName = o.string();
                        continue
                    }
                case 9:
                    {
                        if (r !== 74) break;t.columnName = o.string();
                        continue
                    }
                case 10:
                    {
                        if (r !== 82) break;t.crossFilter = o.string();
                        continue
                    }
                case 11:
                    {
                        if (r !== 90) break;t.sortOrder = o.string();
                        continue
                    }
                case 12:
                    {
                        if (r !== 98) break;t.items.push(Ri.decode(o, o.uint32()));
                        continue
                    }
                case 13:
                    {
                        if (r !== 104) break;t.typeEnum = o.int32();
                        continue
                    }
                case 14:
                    {
                        if (r !== 112) break;t.crossFilterEnum = o.int32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            name: e(i.name) ? a.String(i.name) : "",
            caption: e(i.caption) ? a.String(i.caption) : void 0,
            sourceName: e(i.sourceName) ? a.String(i.sourceName) : void 0,
            type: e(i.type) ? a.String(i.type) : void 0,
            pivotCacheId: e(i.pivotCacheId) ? a.Number(i.pivotCacheId) : void 0,
            pivotTableIds: a.Array.isArray(i == null ? void 0 : i.pivotTableIds) ? i.pivotTableIds.map(n => a.Number(n)) : [],
            tableId: e(i.tableId) ? a.Number(i.tableId) : void 0,
            tableName: e(i.tableName) ? a.String(i.tableName) : void 0,
            columnName: e(i.columnName) ? a.String(i.columnName) : void 0,
            crossFilter: e(i.crossFilter) ? a.String(i.crossFilter) : void 0,
            sortOrder: e(i.sortOrder) ? a.String(i.sortOrder) : void 0,
            items: a.Array.isArray(i == null ? void 0 : i.items) ? i.items.map(n => Ri.fromJSON(n)) : [],
            typeEnum: e(i.typeEnum) ? po(i.typeEnum) : void 0,
            crossFilterEnum: e(i.crossFilterEnum) ? So(i.crossFilterEnum) : void 0
        }
    },
    toJSON(i) {
        var o, d;
        const n = {};
        return i.name !== "" && (n.name = i.name), i.caption !== void 0 && (n.caption = i.caption), i.sourceName !== void 0 && (n.sourceName = i.sourceName), i.type !== void 0 && (n.type = i.type), i.pivotCacheId !== void 0 && (n.pivotCacheId = Math.round(i.pivotCacheId)), (o = i.pivotTableIds) != null && o.length && (n.pivotTableIds = i.pivotTableIds.map(t => Math.round(t))), i.tableId !== void 0 && (n.tableId = Math.round(i.tableId)), i.tableName !== void 0 && (n.tableName = i.tableName), i.columnName !== void 0 && (n.columnName = i.columnName), i.crossFilter !== void 0 && (n.crossFilter = i.crossFilter), i.sortOrder !== void 0 && (n.sortOrder = i.sortOrder), (d = i.items) != null && d.length && (n.items = i.items.map(t => Ri.toJSON(t))), i.typeEnum !== void 0 && (n.typeEnum = mo(i.typeEnum)), i.crossFilterEnum !== void 0 && (n.crossFilterEnum = Io(i.crossFilterEnum)), n
    },
    create(i) {
        return xi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t, r, u, c, p, m, s, h, f, S, T, w;
        const n = no();
        return n.name = (o = i.name) != null ? o : "", n.caption = (d = i.caption) != null ? d : void 0, n.sourceName = (t = i.sourceName) != null ? t : void 0, n.type = (r = i.type) != null ? r : void 0, n.pivotCacheId = (u = i.pivotCacheId) != null ? u : void 0, n.pivotTableIds = ((c = i.pivotTableIds) == null ? void 0 : c.map(_ => _)) || [], n.tableId = (p = i.tableId) != null ? p : void 0, n.tableName = (m = i.tableName) != null ? m : void 0, n.columnName = (s = i.columnName) != null ? s : void 0, n.crossFilter = (h = i.crossFilter) != null ? h : void 0, n.sortOrder = (f = i.sortOrder) != null ? f : void 0, n.items = ((S = i.items) == null ? void 0 : S.map(_ => Ri.fromPartial(_))) || [], n.typeEnum = (T = i.typeEnum) != null ? T : void 0, n.crossFilterEnum = (w = i.crossFilterEnum) != null ? w : void 0, n
    }
};

function oo() {
    return {
        id: 0,
        name: void 0,
        fields: []
    }
}
const Ji = {
    encode(i, n = new v) {
        i.id !== 0 && n.uint32(8).int32(i.id), i.name !== void 0 && n.uint32(18).string(i.name);
        for (const o of i.fields) Bi.encode(o, n.uint32(26).fork()).join();
        return n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = oo();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;t.id = o.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.name = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.fields.push(Bi.decode(o, o.uint32()));
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            id: e(i.id) ? a.Number(i.id) : 0,
            name: e(i.name) ? a.String(i.name) : void 0,
            fields: a.Array.isArray(i == null ? void 0 : i.fields) ? i.fields.map(n => Bi.fromJSON(n)) : []
        }
    },
    toJSON(i) {
        var o;
        const n = {};
        return i.id !== 0 && (n.id = Math.round(i.id)), i.name !== void 0 && (n.name = i.name), (o = i.fields) != null && o.length && (n.fields = i.fields.map(d => Bi.toJSON(d))), n
    },
    create(i) {
        return Ji.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t;
        const n = oo();
        return n.id = (o = i.id) != null ? o : 0, n.name = (d = i.name) != null ? d : void 0, n.fields = ((t = i.fields) == null ? void 0 : t.map(r => Bi.fromPartial(r))) || [], n
    }
};

function ro() {
    return {
        parent: void 0,
        base: void 0,
        rangePr: void 0,
        groupItems: []
    }
}
const Di = {
    encode(i, n = new v) {
        i.parent !== void 0 && n.uint32(8).int32(i.parent), i.base !== void 0 && n.uint32(16).int32(i.base), i.rangePr !== void 0 && Li.encode(i.rangePr, n.uint32(26).fork()).join();
        for (const o of i.groupItems) n.uint32(34).string(o);
        return n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = ro();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;t.parent = o.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;t.base = o.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.rangePr = Li.decode(o, o.uint32());
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;t.groupItems.push(o.string());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            parent: e(i.parent) ? a.Number(i.parent) : void 0,
            base: e(i.base) ? a.Number(i.base) : void 0,
            rangePr: e(i.rangePr) ? Li.fromJSON(i.rangePr) : void 0,
            groupItems: a.Array.isArray(i == null ? void 0 : i.groupItems) ? i.groupItems.map(n => a.String(n)) : []
        }
    },
    toJSON(i) {
        var o;
        const n = {};
        return i.parent !== void 0 && (n.parent = Math.round(i.parent)), i.base !== void 0 && (n.base = Math.round(i.base)), i.rangePr !== void 0 && (n.rangePr = Li.toJSON(i.rangePr)), (o = i.groupItems) != null && o.length && (n.groupItems = i.groupItems), n
    },
    create(i) {
        return Di.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t;
        const n = ro();
        return n.parent = (o = i.parent) != null ? o : void 0, n.base = (d = i.base) != null ? d : void 0, n.rangePr = i.rangePr !== void 0 && i.rangePr !== null ? Li.fromPartial(i.rangePr) : void 0, n.groupItems = ((t = i.groupItems) == null ? void 0 : t.map(r => r)) || [], n
    }
};

function to() {
    return {
        groupBy: "",
        startDate: "",
        endDate: ""
    }
}
const Li = {
    encode(i, n = new v) {
        return i.groupBy !== "" && n.uint32(10).string(i.groupBy), i.startDate !== "" && n.uint32(18).string(i.startDate), i.endDate !== "" && n.uint32(26).string(i.endDate), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = to();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.groupBy = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;t.startDate = o.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.endDate = o.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            groupBy: e(i.groupBy) ? a.String(i.groupBy) : "",
            startDate: e(i.startDate) ? a.String(i.startDate) : "",
            endDate: e(i.endDate) ? a.String(i.endDate) : ""
        }
    },
    toJSON(i) {
        const n = {};
        return i.groupBy !== "" && (n.groupBy = i.groupBy), i.startDate !== "" && (n.startDate = i.startDate), i.endDate !== "" && (n.endDate = i.endDate), n
    },
    create(i) {
        return Li.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d, t;
        const n = to();
        return n.groupBy = (o = i.groupBy) != null ? o : "", n.startDate = (d = i.startDate) != null ? d : "", n.endDate = (t = i.endDate) != null ? t : "", n
    }
};

function ao() {
    return {
        name: "",
        numFmtId: void 0,
        sharedItems: void 0,
        fieldGroup: void 0
    }
}
const Bi = {
    encode(i, n = new v) {
        return i.name !== "" && n.uint32(10).string(i.name), i.numFmtId !== void 0 && n.uint32(16).uint32(i.numFmtId), i.sharedItems !== void 0 && Mi.encode(i.sharedItems, n.uint32(26).fork()).join(), i.fieldGroup !== void 0 && Di.encode(i.fieldGroup, n.uint32(34).fork()).join(), n
    },
    decode(i, n) {
        const o = i instanceof l ? i : new l(i);
        let d = n === void 0 ? o.len : o.pos + n;
        const t = ao();
        for (; o.pos < d;) {
            const r = o.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;t.name = o.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;t.numFmtId = o.uint32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;t.sharedItems = Mi.decode(o, o.uint32());
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;t.fieldGroup = Di.decode(o, o.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            o.skip(r & 7)
        }
        return t
    },
    fromJSON(i) {
        return {
            name: e(i.name) ? a.String(i.name) : "",
            numFmtId: e(i.numFmtId) ? a.Number(i.numFmtId) : void 0,
            sharedItems: e(i.sharedItems) ? Mi.fromJSON(i.sharedItems) : void 0,
            fieldGroup: e(i.fieldGroup) ? Di.fromJSON(i.fieldGroup) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.name !== "" && (n.name = i.name), i.numFmtId !== void 0 && (n.numFmtId = Math.round(i.numFmtId)), i.sharedItems !== void 0 && (n.sharedItems = Mi.toJSON(i.sharedItems)), i.fieldGroup !== void 0 && (n.fieldGroup = Di.toJSON(i.fieldGroup)), n
    },
    create(i) {
        return Bi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var o, d;
        const n = ao();
        return n.name = (o = i.name) != null ? o : "", n.numFmtId = (d = i.numFmtId) != null ? d : void 0, n.sharedItems = i.sharedItems !== void 0 && i.sharedItems !== null ? Mi.fromPartial(i.sharedItems) : void 0, n.fieldGroup = i.fieldGroup !== void 0 && i.fieldGroup !== null ? Di.fromPartial(i.fieldGroup) : void 0, n
    }
};

function eo() {
    return {
        values: [],
        containsBlank: void 0,
        containsDate: void 0,
        containsNumeric: void 0,
        containsString: void 0
    }
}
const Mi = {
        encode(i, n = new v) {
            for (const o of i.values) n.uint32(10).string(o);
            return i.containsBlank !== void 0 && n.uint32(16).bool(i.containsBlank), i.containsDate !== void 0 && n.uint32(24).bool(i.containsDate), i.containsNumeric !== void 0 && n.uint32(32).bool(i.containsNumeric), i.containsString !== void 0 && n.uint32(40).bool(i.containsString), n
        },
        decode(i, n) {
            const o = i instanceof l ? i : new l(i);
            let d = n === void 0 ? o.len : o.pos + n;
            const t = eo();
            for (; o.pos < d;) {
                const r = o.uint32();
                switch (r >>> 3) {
                    case 1:
                        {
                            if (r !== 10) break;t.values.push(o.string());
                            continue
                        }
                    case 2:
                        {
                            if (r !== 16) break;t.containsBlank = o.bool();
                            continue
                        }
                    case 3:
                        {
                            if (r !== 24) break;t.containsDate = o.bool();
                            continue
                        }
                    case 4:
                        {
                            if (r !== 32) break;t.containsNumeric = o.bool();
                            continue
                        }
                    case 5:
                        {
                            if (r !== 40) break;t.containsString = o.bool();
                            continue
                        }
                }
                if ((r & 7) === 4 || r === 0) break;
                o.skip(r & 7)
            }
            return t
        },
        fromJSON(i) {
            return {
                values: a.Array.isArray(i == null ? void 0 : i.values) ? i.values.map(n => a.String(n)) : [],
                containsBlank: e(i.containsBlank) ? a.Boolean(i.containsBlank) : void 0,
                containsDate: e(i.containsDate) ? a.Boolean(i.containsDate) : void 0,
                containsNumeric: e(i.containsNumeric) ? a.Boolean(i.containsNumeric) : void 0,
                containsString: e(i.containsString) ? a.Boolean(i.containsString) : void 0
            }
        },
        toJSON(i) {
            var o;
            const n = {};
            return (o = i.values) != null && o.length && (n.values = i.values), i.containsBlank !== void 0 && (n.containsBlank = i.containsBlank), i.containsDate !== void 0 && (n.containsDate = i.containsDate), i.containsNumeric !== void 0 && (n.containsNumeric = i.containsNumeric), i.containsString !== void 0 && (n.containsString = i.containsString), n
        },
        create(i) {
            return Mi.fromPartial(i != null ? i : {})
        },
        fromPartial(i) {
            var o, d, t, r, u;
            const n = eo();
            return n.values = ((o = i.values) == null ? void 0 : o.map(c => c)) || [], n.containsBlank = (d = i.containsBlank) != null ? d : void 0, n.containsDate = (t = i.containsDate) != null ? t : void 0, n.containsNumeric = (r = i.containsNumeric) != null ? r : void 0, n.containsString = (u = i.containsString) != null ? u : void 0, n
        }
    },
    a = (() => {
        if (typeof globalThis < "u") return globalThis;
        if (typeof self < "u") return self;
        if (typeof window < "u") return window;
        if (typeof global < "u") return global;
        throw "Unable to locate global object"
    })();

function e(i) {
    return i != null
}
export {
    lo as C, Fo as W
};
//# sourceMappingURL=nb22pb07i8ebbv0i.js.map