const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/jed1ux7qibe55pmj.js", "assets/fg33krlcm0qyi6yw.js", "assets/h1em0bjkpkjv8ykw.js", "assets/fgxxkkb4il90gii6.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/eafv7vq0yf9bv0fi.js", "assets/f76gy0b8ieo4s693.js", "assets/k15yxxoybkkir2ou.js", "assets/conversation-small-332fs9rk.css", "assets/jsd0vs4cv2vks3ah.js", "assets/dv2e3o9gddnli9b5.js", "assets/k57uzqpnr7k7r909.js", "assets/nfccle6oyncifphl.js", "assets/hu1bt0oauegdhua6.js", "assets/b5s349mvbdzayaxi.js", "assets/gy1lpvuoewmzh42c.js", "assets/dbshkzvpochy4889.js", "assets/loeoawlgsw5vcwar.js", "assets/17v8usp0o68l1lsz.js", "assets/e7ytp4eqtgc6bl6p.js"]))) => i.map(i => d[i]);
import {
    _ as i
} from "./fg33krlcm0qyi6yw.js";
import {
    h as E
} from "./jsd0vs4cv2vks3ah.js";
import {
    r4 as v
} from "./dykg4ktvbu3mhmdo.js";
async function A(r, n) {
    if (E.every(e => !r.includes(e))) return r;
    const {
        unified: _
    } = await i(async () => {
        const {
            unified: e
        } = await
        import ("./jed1ux7qibe55pmj.js").then(t => t.i);
        return {
            unified: e
        }
    }, __vite__mapDeps([0, 1, 2])), {
        CANVAS_REMARK_PLUGINS: a
    } = await i(async () => {
        const {
            CANVAS_REMARK_PLUGINS: e
        } = await
        import ("./fgxxkkb4il90gii6.js").then(t => t.p);
        return {
            CANVAS_REMARK_PLUGINS: e
        }
    }, __vite__mapDeps([3, 4, 1, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 2, 15, 16, 17, 18, 19])), {
        stripDirectivePlugin: o
    } = await i(async () => {
        const {
            stripDirectivePlugin: e
        } = await
        import ("./e7ytp4eqtgc6bl6p.js");
        return {
            stripDirectivePlugin: e
        }
    }, __vite__mapDeps([20, 10, 4, 1, 5, 8, 9])), {
        hiveLogDirectivePlugin: c
    } = await i(async () => {
        const {
            hiveLogDirectivePlugin: e
        } = await
        import ("./jsd0vs4cv2vks3ah.js").then(t => t.b);
        return {
            hiveLogDirectivePlugin: e
        }
    }, __vite__mapDeps([10, 4, 1, 5, 8, 9])), s = _();
    s.use(c).use(o, {
        preserve: n != null && n.preserveContentReferences ? [v] : void 0
    }).use(a);
    const u = await s.process(r);
    return String(u).trim()
}
export {
    A as s
};
//# sourceMappingURL=kwqlokvhsdnnmw9d.js.map