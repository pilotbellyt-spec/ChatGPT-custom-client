import {
    c as E
} from "./fg33krlcm0qyi6yw.js";
import {
    H as g,
    L as h,
    qI as x
} from "./dykg4ktvbu3mhmdo.js";
import {
    db as D,
    dc as F
} from "./k15yxxoybkkir2ou.js";

function w() {
    "use forget";
    var m, f, S, y, C;
    const s = E.c(15),
        t = g(),
        {
            country: n
        } = D();
    let a;
    s[0] !== n || s[1] !== t ? (a = {
        country: n,
        currentAccount: t,
        location: "useCheckoutDetails",
        shouldUsePaidSubscriptionBillingCurrency: !0
    }, s[0] = n, s[1] = t, s[2] = a) : a = s[2];
    const o = F(a),
        p = (m = t == null ? void 0 : t.data.subscriptionStatus.planType) != null ? m : h.FREE,
        u = t == null ? void 0 : t.data.subscriptionStatus.billingPeriod,
        r = (f = t == null ? void 0 : t.data.subscriptionStatus.hasPaidSubscription) != null ? f : !1,
        b = (S = t == null ? void 0 : t.data.subscriptionStatus.subscriptionPlan) != null ? S : x.FREE,
        d = (y = t == null ? void 0 : t.data.subscriptionStatus.subscriptionExpiresAt) != null ? y : void 0,
        P = (C = t == null ? void 0 : t.data.subscriptionStatus.wasPaidCustomer) != null ? C : !1;
    let i;
    s[3] !== u || s[4] !== r || s[5] !== b || s[6] !== d || s[7] !== P ? (i = {
        billingPeriod: u,
        hasPaidSubscription: r,
        subscriptionPlan: b,
        subscriptionExpiresAt: d,
        wasPaidCustomer: P
    }, s[3] = u, s[4] = r, s[5] = b, s[6] = d, s[7] = P, s[8] = i) : i = s[8];
    let l;
    s[9] !== p || s[10] !== i ? (l = {
        currentPlanType: p,
        subscriptionStatus: i
    }, s[9] = p, s[10] = i, s[11] = l) : l = s[11];
    const c = l;
    if (!o) return null;
    let e;
    return s[12] !== c || s[13] !== o ? (e = {
        billingDetails: o,
        plusAnalyticsParams: c
    }, s[12] = c, s[13] = o, s[14] = e) : e = s[14], e
}
export {
    w as u
};
//# sourceMappingURL=emixct2ecmtx0izd.js.map