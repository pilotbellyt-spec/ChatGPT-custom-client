const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/edyp3sdbe40d6h2d.js", "assets/fg33krlcm0qyi6yw.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/k15yxxoybkkir2ou.js", "assets/conversation-small-332fs9rk.css", "assets/lt0k52ryhjrp2fva.js", "assets/o92vxzxwc8gk40ts.js", "assets/3ype9xcsrgcixjgo.js", "assets/grh1jqxqycv190js.js"]))) => i.map(i => d[i]);
var Rt = Object.defineProperty,
    Ut = Object.defineProperties;
var Ft = Object.getOwnPropertyDescriptors;
var gt = Object.getOwnPropertySymbols;
var zt = Object.prototype.hasOwnProperty,
    Gt = Object.prototype.propertyIsEnumerable;
var ft = (t, e, s) => e in t ? Rt(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : t[e] = s,
    k = (t, e) => {
        for (var s in e || (e = {})) zt.call(e, s) && ft(t, s, e[s]);
        if (gt)
            for (var s of gt(e)) Gt.call(e, s) && ft(t, s, e[s]);
        return t
    },
    te = (t, e) => Ut(t, Ft(e));
import {
    c as Ee,
    j as o,
    e as se,
    r as h,
    M as W,
    f as _e,
    _ as Me,
    n as Vt,
    m as qt
} from "./fg33krlcm0qyi6yw.js";
import {
    dv as $t,
    dw as Ht,
    v as Yt,
    y as Qt,
    z as Jt,
    bp as Ae,
    bq as Pe,
    lk as je,
    ll as Kt,
    lm as Xt,
    ln as Zt,
    lo as eo,
    lp as yt,
    lq as St,
    lr as Le,
    ls as to,
    lt as oo,
    lu as so,
    o as ao,
    lv as no,
    eJ as ht,
    fi as io,
    lw as ro,
    lx as lo,
    cZ as co,
    ly as uo,
    lz as mo,
    m as po,
    jm as go,
    lA as fo,
    lB as ho,
    lC as bo,
    lD as _o,
    lE as Mo,
    lF as ko,
    iE as xo,
    lG as yo,
    lH as So,
    lI as wo,
    lJ as vo,
    lK as Co,
    lL as Oo,
    lM as No,
    lN as Do,
    lO as Ao,
    lP as Po,
    lQ as Lo,
    lR as Io,
    fg as Wo,
    lS as jo,
    lT as To,
    lU as Bo,
    lV as Eo,
    lW as Ro,
    lX as Uo,
    lY as Fo,
    lZ as zo,
    l_ as Go,
    l$ as Vo,
    m0 as qo,
    m1 as $o,
    m2 as Ho,
    m3 as Yo,
    m4 as Qo,
    m5 as Jo,
    m6 as Ko,
    gM as Xo,
    m7 as Zo,
    m8 as es,
    m9 as ts,
    ma as os,
    mb as ss,
    mc as as,
    md as ns,
    me as is,
    aB as rs,
    mf as ls,
    jL as cs,
    P as bt
} from "./k15yxxoybkkir2ou.js";
import {
    P as ds
} from "./hpmzcrnchtp2pgs4.js";
import {
    b as wt,
    d as us
} from "./k2oaaf8ac9lafsub.js";
import {
    H as ms,
    n as ue,
    Z as Te,
    S as Be,
    o as we,
    b as me,
    du as vt,
    bJ as ps,
    I as gs,
    l as fs,
    iw as hs,
    b4 as bs,
    es as be,
    a9 as ve,
    C as ae,
    W as Ce,
    ag as Ct,
    P as oe,
    be as Ot,
    bf as Nt,
    l5 as _s,
    $ as _t,
    R as Ms,
    x as J,
    Y as Oe,
    of as ks,
    z as xs,
    b$ as ys,
    bh as ke,
    V as Ss,
    rN as ws,
    rL as vs,
    fN as Cs,
    w as Os,
    p1 as Ns,
    af as Ds,
    tw as As,
    d as Ps,
    a_ as Ls,
    uB as Is,
    uC as Ws,
    uD as js,
    aL as Ie,
    aK as Mt,
    uE as We
} from "./dykg4ktvbu3mhmdo.js";
import {
    a as Ts
} from "./j63amn1eooyu8ua6.js";
import Dt from "./k7bax4ffse9ora8u.js";
const de = _e({
        title: {
            id: "workspaceDiscovery.renamePromptModal.title",
            defaultMessage: "Set a workspace display name"
        },
        laterCta: {
            id: "workspaceDiscovery.renamePromptModal.laterCta",
            defaultMessage: "Update later"
        },
        save: {
            id: "workspaceDiscovery.renamePromptModal.save",
            defaultMessage: "Update"
        },
        checkboxLabel: {
            id: "workspaceDiscovery.renamePromptModal.checkboxLabel",
            defaultMessage: "Use workspace name (recommended)"
        },
        body: {
            id: "workspaceDiscovery.renamePromptModal.body.1",
            defaultMessage: "This is what teammates on your domain will see when they request to join your workspace. <learnMoreLink>Open settings</learnMoreLink>.{br}{br}Current: <b>{currentName}</b>"
        },
        clearToWorkspaceNameAria: {
            id: "workspaceIdentity.clearToWorkspaceNameAria",
            defaultMessage: "Clear and use workspace name"
        }
    }),
    kt = {
        dismissedAt: 0,
        shownCount: 0
    },
    At = t => {
        if (!t) return kt;
        try {
            const e = JSON.parse(t);
            return {
                dismissedAt: Number(e.dismissedAt) || 0,
                shownCount: Number(e.shownCount) || 0
            }
        } catch (e) {
            return kt
        }
    },
    Bs = 5,
    Pt = () => {
        "use forget";
        var Y;
        const t = Ee.c(8),
            e = me(),
            s = ms();
        let a;
        t[0] !== s ? (a = s == null ? void 0 : s.getWorkspaceId(), t[0] = s, t[1] = a) : a = t[1];
        const r = a,
            c = ue(Us),
            i = c != null ? $t(c.role) || Ht(c.role) : void 0,
            u = At(Te.getItem(Be.WorkspaceDiscoveryRenamePromptInfo)),
            m = Date.now() > u.dismissedAt + 864e5,
            n = u.shownCount < Bs,
            _ = we(e, "1053331630"),
            p = we(e, "3592108663"),
            b = i && _ && p && m && n && !!r,
            {
                data: l,
                isLoading: M
            } = vt(b ? r : void 0),
            T = !!(l != null && l.support_workspace_discovery),
            x = !!(l != null && l.workspace_discoverable),
            g = (l == null ? void 0 : l.use_workspace_name_for_discovery) === !0,
            C = (g ? "" : (Y = l == null ? void 0 : l.public_display_name) != null ? Y : "").includes("Workspace #");
        if (!(T && b && !M && x && !g && C)) {
            let S;
            return t[2] !== M ? (S = {
                isOpen: !1,
                isLoading: M
            }, t[2] = M, t[3] = S) : S = t[3], S
        }
        let w;
        t[4] !== e ? (w = ps(e, "309365540").get("enable", !1), t[4] = e, t[5] = w) : w = t[5];
        const A = w;
        let v;
        return t[6] !== A ? (v = {
            isOpen: A,
            isLoading: !1
        }, t[6] = A, t[7] = v) : v = t[7], v
    },
    Es = t => {
        "use forget";
        const e = Ee.c(6),
            {
                onClose: s
            } = t,
            a = me();
        let r;
        if (e[0] !== a) {
            const n = gs(a);
            r = n == null ? void 0 : n.getWorkspaceId(), e[0] = a, e[1] = r
        } else r = e[1];
        const c = r,
            {
                data: i,
                isPending: u
            } = vt(c);
        if (!c || u || !i) return null;
        let m;
        return e[2] !== s || e[3] !== i || e[4] !== c ? (m = o.jsx(Rs, {
            onClose: s,
            workspaceId: c,
            settings: i
        }), e[2] = s, e[3] = i, e[4] = c, e[5] = m) : m = e[5], m
    },
    Rs = t => {
        "use forget";
        var fe;
        const e = Ee.c(68),
            {
                onClose: s,
                workspaceId: a,
                settings: r
            } = t,
            c = se(),
            i = me();
        let u;
        e[0] !== i || e[1] !== s ? (u = () => {
            be(i, "chatgpt_workspace_discovery_rename_prompt_modal_closed"), s()
        }, e[0] = i, e[1] = s, e[2] = u) : u = e[2];
        const m = u;
        let n;
        e[3] === Symbol.for("react.memo_cache_sentinel") ? (n = At(Te.getItem(Be.WorkspaceDiscoveryRenamePromptInfo)), e[3] = n) : n = e[3];
        const _ = n,
            {
                mutateAsync: p,
                isPending: b
            } = Yt(a),
            l = wt(),
            M = !!(r != null && r.workspace_discoverable),
            T = (r == null ? void 0 : r.use_workspace_name_for_discovery) === !0,
            x = T ? "" : (fe = r == null ? void 0 : r.public_display_name) != null ? fe : "",
            [g, xe] = h.useState(!0),
            [C, pe] = h.useState(""),
            [w, A] = h.useState(!1);
        let v;
        e[4] !== g || e[5] !== x || e[6] !== C || e[7] !== w || e[8] !== b || e[9] !== T ? (v = !g && !b && !T && (w ? C.trim() !== "" : x.trim() !== ""), e[4] = g, e[5] = x, e[6] = C, e[7] = w, e[8] = b, e[9] = T, e[10] = v) : v = e[10];
        const Y = v,
            S = g ? l : w ? C : x;
        let B;
        e[11] === Symbol.for("react.memo_cache_sentinel") ? (B = () => {
            Te.setItem(Be.WorkspaceDiscoveryRenamePromptInfo, JSON.stringify({
                dismissedAt: Date.now(),
                shownCount: _.shownCount + 1
            }))
        }, e[11] = B) : B = e[11];
        const f = B;
        let P;
        e[12] !== i ? (P = H => {
            xe(H), be(i, "chatgpt_workspace_discovery_rename_prompt_modal_checkbox_toggled", H ? 1 : 0)
        }, e[12] = i, e[13] = P) : P = e[13];
        const y = P;
        let O;
        e[14] !== i || e[15] !== m ? (O = () => {
            be(i, "chatgpt_workspace_discovery_rename_prompt_modal_dismiss_clicked"), f(), m()
        }, e[14] = i, e[15] = m, e[16] = O) : O = e[16];
        const E = O;
        let L;
        e[17] !== g || e[18] !== i || e[19] !== C || e[20] !== m || e[21] !== b || e[22] !== p || e[23] !== M ? (L = async () => {
            b || (be(i, "chatgpt_workspace_discovery_rename_prompt_modal_save_clicked"), await p({
                value: M,
                public_display_name: g ? null : C.trim(),
                use_workspace_name_for_discovery: g,
                action: "name"
            }), m())
        }, e[17] = g, e[18] = i, e[19] = C, e[20] = m, e[21] = b, e[22] = p, e[23] = M, e[24] = L) : L = e[24];
        const ge = L;
        let ne, ie;
        e[25] !== i ? (ne = () => {
            be(i, "chatgpt_workspace_discovery_rename_prompt_modal_shown")
        }, ie = [i], e[25] = i, e[26] = ne, e[27] = ie) : (ne = e[26], ie = e[27]), h.useEffect(ne, ie);
        let K;
        e[28] === Symbol.for("react.memo_cache_sentinel") ? (K = o.jsx(W, k({}, de.laterCta)), e[28] = K) : K = e[28];
        let R;
        e[29] !== E ? (R = o.jsx(ve, {
            color: "secondary",
            onClick: E,
            children: K
        }), e[29] = E, e[30] = R) : R = e[30];
        let X;
        e[31] === Symbol.for("react.memo_cache_sentinel") ? (X = o.jsx(W, k({}, de.save)), e[31] = X) : X = e[31];
        let I;
        e[32] !== ge || e[33] !== b ? (I = o.jsx(ve, {
            onClick: ge,
            loading: b,
            children: X
        }), e[32] = ge, e[33] = b, e[34] = I) : I = e[34];
        let U;
        e[35] !== R || e[36] !== I ? (U = o.jsxs("div", {
            className: "mt-8 flex w-full justify-end gap-3",
            children: [R, I]
        }), e[35] = R, e[36] = I, e[37] = U) : U = e[37];
        let re;
        e[38] === Symbol.for("react.memo_cache_sentinel") ? (re = o.jsx("div", {
            className: "mb-4 w-full text-xl",
            children: o.jsx(W, k({}, de.title))
        }), e[38] = re) : re = e[38];
        let F;
        e[39] === Symbol.for("react.memo_cache_sentinel") ? (F = o.jsx("br", {}), e[39] = F) : F = e[39];
        let Q;
        e[40] !== x ? (Q = o.jsx("div", {
            className: "text-token-text-secondary",
            children: o.jsx(W, te(k({}, de.body), {
                values: {
                    b: Fs,
                    br: F,
                    currentName: x,
                    learnMoreLink: zs
                }
            }))
        }), e[40] = x, e[41] = Q) : Q = e[41];
        let N;
        e[42] !== y ? (N = H => y(H.currentTarget.checked), e[42] = y, e[43] = N) : N = e[43];
        let z;
        e[44] !== l ? (z = o.jsx("span", {
            className: "text-sm",
            children: o.jsx(W, te(k({}, de.checkboxLabel), {
                values: {
                    workspaceName: l
                }
            }))
        }), e[44] = l, e[45] = z) : z = e[45];
        let G;
        e[46] !== g || e[47] !== N || e[48] !== z ? (G = o.jsx("div", {
            className: "mt-6 mb-3",
            children: o.jsx(Qt, {
                id: "use-workspace-name-for-discovery",
                checked: g,
                onChange: N,
                label: z
            })
        }), e[46] = g, e[47] = N, e[48] = z, e[49] = G) : G = e[49];
        const le = g && "text-token-text-tertiary";
        let V;
        e[50] !== le ? (V = fs(le), e[50] = le, e[51] = V) : V = e[51];
        let Z;
        e[52] === Symbol.for("react.memo_cache_sentinel") ? (Z = H => {
            pe(H.target.value), A(!0)
        }, e[52] = Z) : Z = e[52];
        let q;
        e[53] !== c || e[54] !== Y ? (q = Y ? o.jsx("button", {
            type: "button",
            className: "text-token-text-tertiary hover:text-token-text-secondary absolute end-0 top-1/2 -translate-y-1/2 pe-1",
            "aria-label": c.formatMessage(de.clearToWorkspaceNameAria),
            onClick: () => {
                pe("")
            },
            children: o.jsx(hs, {
                className: "icon-sm"
            })
        }) : null, e[53] = c, e[54] = Y, e[55] = q) : q = e[55];
        let $;
        e[56] !== g || e[57] !== x || e[58] !== S || e[59] !== V || e[60] !== q ? ($ = o.jsx(Jt, {
            name: "public_display_name",
            ariaLabel: !1,
            disabled: g,
            inputClassName: V,
            placeholder: x,
            maxLength: ds,
            value: S,
            onChange: Z,
            insideContainerChildren: q
        }), e[56] = g, e[57] = x, e[58] = S, e[59] = V, e[60] = q, e[61] = $) : $ = e[61];
        let ee;
        return e[62] !== E || e[63] !== U || e[64] !== Q || e[65] !== G || e[66] !== $ ? (ee = o.jsxs(ae, {
            isOpen: !0,
            onClose: E,
            contentClassName: "p-6",
            shouldIgnoreClickOutside: !0,
            size: "custom",
            className: "max-w-lg",
            testId: "modal-workspace-discovery-rename-prompt",
            footerContent: U,
            children: [re, Q, G, $]
        }), e[62] = E, e[63] = U, e[64] = Q, e[65] = G, e[66] = $, e[67] = ee) : ee = e[67], ee
    };

function Us(t) {
    return t.currentWorkspace
}

function Fs(t) {
    return o.jsx("b", {
        children: t
    })
}

function zs(t) {
    return o.jsx(bs, {
        href: "/admin/identity",
        children: t
    })
}
const Gs = Object.freeze(Object.defineProperty({
        __proto__: null,
        WorkspaceDiscoveryRenamePromptModal: Es,
        useWorkspaceDiscoveryRenamePromptModal: Pt
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Vs = "g-68c9a4676c8c81918d99178b55901b9a",
    qs = ({
        onContinue: t,
        scope: e
    }) => {
        const s = se(),
            a = wt();
        return o.jsx(ae, {
            testId: "modal-initial-workspace-onboarding",
            isOpen: !0,
            onClose: J,
            type: "success",
            title: o.jsxs("div", {
                className: "flex flex-col",
                children: [o.jsx("span", {
                    children: s.formatMessage(j.secureWorkspaceWelcomeTitle)
                }), o.jsx("span", {
                    className: "text-token-text-secondary text-sm",
                    children: a
                })]
            }),
            size: "custom",
            noPadding: !0,
            className: "max-w-2xl",
            children: o.jsx(yt, {
                onClose: () => {
                    t()
                },
                scope: e
            })
        })
    },
    $s = ({
        onContinue: t,
        onSkip: e,
        isEduPlan: s
    }) => {
        const a = se();
        return o.jsx(ae, {
            testId: "modal-role-survey",
            isOpen: !0,
            onClose: J,
            type: "success",
            title: a.formatMessage(j.primaryRoleTitle),
            size: "custom",
            className: "max-w-lg",
            children: o.jsx(Lt, {
                options: s ? Zt : eo,
                onSkip: e,
                onSubmit: t
            })
        })
    },
    Hs = ({
        onContinue: t,
        onSkip: e,
        isEduPlan: s
    }) => {
        const a = se();
        return o.jsx(ae, {
            testId: "modal-department-survey",
            isOpen: !0,
            onClose: J,
            type: "success",
            title: a.formatMessage(j.workTypeTitle),
            size: "custom",
            className: "max-w-lg",
            children: o.jsx(Lt, {
                options: s ? Kt : Xt,
                onSkip: e,
                onSubmit: t,
                multiSelect: !0
            })
        })
    };

function Lt({
    options: t,
    onSkip: e = J,
    onSubmit: s = J,
    multiSelect: a = !1
}) {
    const r = se(),
        [c, i] = h.useState([]);

    function u(n, _) {
        const p = n.indexOf(_);
        return p === -1 ? [...n, _] : [...n.slice(0, p), ...n.slice(p + 1)]
    }
    const m = h.useCallback(n => {
        var p;
        const _ = (p = n.currentTarget.dataset.value) != null ? p : "";
        a ? i(u(c, _)) : s(_)
    }, [s, c, i, a]);
    return o.jsxs("div", {
        children: [a && o.jsx("p", {
            className: "text-token-text-tertiary mx-2 text-sm",
            children: r.formatMessage(j.selectAll)
        }), o.jsx("div", {
            className: "flex flex-col items-center justify-center",
            children: o.jsx("div", {
                className: "flex-wrap space-y-4",
                children: t.map(n => o.jsx(ve, {
                    onClick: m,
                    color: c.includes(n.id) ? "primary" : "secondary",
                    size: "medium",
                    className: "mx-2",
                    "data-value": n.id,
                    children: o.jsx(W, k({}, n.displayValue))
                }, n.id))
            })
        }), o.jsxs("div", {
            className: "mt-4 flex flex-row justify-end",
            children: [o.jsx(Oe, {
                title: r.formatMessage(j.skipButton),
                onClick: e
            }), a && o.jsx(Oe, {
                title: r.formatMessage(j.continueButton),
                onClick: () => {
                    s(c)
                },
                disabled: c.length === 0,
                color: "primary",
                className: "ms-4"
            })]
        })]
    })
}
const Ys = ({
    onYes: t,
    onSkip: e
}) => {
    const s = se();
    return o.jsx(ae, {
        testId: "modal-chat-onboarding",
        isOpen: !0,
        onClose: J,
        type: "success",
        title: s.formatMessage(j.chatOnboardingTitle),
        size: "custom",
        className: "max-w-lg",
        children: o.jsxs("div", {
            className: "px-4 pb-2",
            children: [o.jsx("p", {
                className: "text-token-text-secondary mb-4 text-sm",
                children: s.formatMessage(j.chatOnboardingDescription)
            }), o.jsxs("div", {
                className: "mt-4 flex flex-row justify-end gap-3",
                children: [o.jsx(Oe, {
                    title: s.formatMessage(j.skipButton),
                    onClick: e
                }), o.jsx(Oe, {
                    title: s.formatMessage(j.yesButton),
                    onClick: t,
                    color: "primary"
                })]
            })]
        })
    })
};

function Qs({
    onClose: t
}) {
    var b;
    const e = me(),
        s = (b = we(e, "2839926172")) != null ? b : !1,
        [a, r] = h.useState(0),
        [c, i] = h.useState({
            role: "",
            departments: []
        }),
        u = ue(Ce.businessWorkspaceId),
        m = ue(Ce.isEduPlan),
        n = Ct(),
        _ = n == null ? void 0 : n.id,
        p = () => {
            _t.logEvent("chatgpt_biz_onboarding_skipped"), oe.logEvent("Business Onboarding Skipped"), t(), Ae(e, Pe.Onboarding)
        };
    switch (h.useEffect(() => {
        a === 0 && oe.logUpsellOrModalEvent(Ot, {
            eventId: "workspace_onboarding_modal_shown",
            type: Nt.UPSELL_OR_MODAL_TYPE_CUSTOM_NUX_MODAL
        })
    }, [a]), a) {
        case 0:
            return o.jsx(qs, {
                scope: je.Workspace,
                onContinue: () => {
                    r(1)
                }
            });
        case 1:
            return o.jsx($s, {
                onContinue: l => {
                    i(M => te(k({}, M), {
                        role: l
                    })), r(2)
                },
                onSkip: p,
                isEduPlan: m
            });
        case 2:
            return o.jsx(Hs, {
                onContinue: l => {
                    const M = te(k({}, c), {
                        departments: l
                    });
                    _t.logEvent("chatgpt_biz_onboarding_completed"), oe.logEvent("Business Onboarding Completed"), Ms.safePatch("/accounts/{account_id}/users/{user_id}", {
                        parameters: {
                            path: {
                                account_id: u,
                                user_id: _
                            }
                        },
                        requestBody: {
                            onboarding_information: M
                        }
                    }).finally(() => {
                        s ? r(3) : (t(), Ae(e, Pe.Onboarding))
                    })
                },
                onSkip: p,
                isEduPlan: m
            });
        case 3:
            return o.jsx(Ys, {
                onSkip: p,
                onYes: () => {
                    if (typeof window < "u") {
                        const l = _s(Vs);
                        window.location.assign(l)
                    }
                    t(), Ae(e, Pe.Onboarding)
                }
            });
        default:
            return o.jsx(o.Fragment, {})
    }
}
const j = _e({
        secureWorkspaceWelcomeTitle: {
            id: "onboarding.secureWorkspaceWelcomeTitle",
            defaultMessage: "Welcome to your secure workspace"
        },
        primaryRoleTitle: {
            id: "onboarding.primaryRoleTitle",
            defaultMessage: "What's your primary role?"
        },
        workTypeTitle: {
            id: "onboarding.workTypeTitle",
            defaultMessage: "What kind of work do you do?"
        },
        selectAll: {
            id: "onboarding.selectAll",
            defaultMessage: "Select all that apply"
        },
        skipButton: {
            id: "onboarding.skipButton",
            defaultMessage: "Skip"
        },
        continueButton: {
            id: "onboarding.continueButton",
            defaultMessage: "Continue"
        },
        yesButton: {
            id: "onboarding.yesButton",
            defaultMessage: "Yes"
        },
        chatOnboardingTitle: {
            id: "onboarding.chatOnboardingTitle",
            defaultMessage: "Meet Your Onboarding Buddy GPT?"
        },
        chatOnboardingDescription: {
            id: "onboarding.chatOnboardingDescription",
            defaultMessage: "Brainstorm ways to get the most out of ChatGPT with a personal onboarding buddy."
        }
    }),
    Js = () => {
        const t = me(),
            e = "center",
            {
                isOpen: s,
                modalType: a
            } = St(t),
            r = us(),
            c = ks();
        if (h.useEffect(() => {
                s && oe.logEvent("Sidetron: Blocking Modal Shown", {
                    modalType: a
                })
            }, [s, a]), !s) return null;

        function i() {
            switch (oe.logEvent("Sidetron: Modal Action Clicked", {
                modalType: a
            }), a) {
                case Le.unsupported_app_version:
                    window.open(c ? to : oo, "_blank");
                    return;
                case null:
                    ys.warn("No modal type provided for DesktopBlockingModal");
                    return
            }
        }

        function u() {
            switch (a) {
                case Le.unsupported_app_version:
                    return Xs;
                case null:
                    return Ks
            }
        }

        function m() {
            switch (a) {
                case Le.unsupported_app_version:
                    return !1;
                case null:
                    return !1
            }
        }
        return o.jsx(ae, {
            testId: "modal-desktop-blocking",
            isOpen: !0,
            onClose: J,
            shouldIgnoreClickOutside: !0,
            showCloseButton: !1,
            type: "success",
            noPadding: !0,
            position: e,
            children: o.jsxs("div", {
                className: "flex flex-col items-center justify-center px-6 py-8",
                children: [o.jsx("p", {
                    className: "mb-1 text-center text-2xl font-semibold",
                    children: o.jsx(W, k({}, u().title))
                }), o.jsx("p", {
                    className: "text-token-text-secondary mb-6 text-center text-lg",
                    children: o.jsx(W, k({}, u().subtitle))
                }), o.jsx(ve, {
                    as: "button",
                    size: "large",
                    color: "primary",
                    fullWidth: !0,
                    className: "mb-2 sm:mb-3",
                    "data-testid": "desktop-blocking-modal-action-button",
                    onClick: i,
                    children: o.jsx(W, k({}, u().cta))
                }), m() && o.jsxs("span", {
                    children: [r, " · ", o.jsx("a", {
                        href: "#",
                        className: "text-token-text-secondary cursor-pointer font-semibold underline sm:text-sm",
                        onClick: n => {
                            n.preventDefault(), oe.logEvent("Sidetron: Modal Logout Clicked", {
                                modalType: a
                            }), xs()
                        },
                        "data-testid": "desktop-blocking-modal-logout",
                        children: o.jsx(W, k({}, u().logout))
                    })]
                })]
            })
        })
    },
    Ks = _e({
        title: {
            id: "DesktopBlockingModal.paidTitle",
            defaultMessage: "Upgrade to use Windows app"
        },
        subtitle: {
            id: "DesktopBlockingModal.paidSubtitle",
            defaultMessage: "The Windows app is currently available for Plus, Business, Enterprise, and Edu plans."
        },
        cta: {
            id: "DesktopBlockingModal.paidUpgradeCta",
            defaultMessage: "See Plans"
        },
        logout: {
            id: "DesktopBlockingModal.paidLogout",
            defaultMessage: "Log out"
        }
    }),
    Xs = _e({
        title: {
            id: "DesktopBlockingModal.sunsettingTitle",
            defaultMessage: "Update required"
        },
        subtitle: {
            id: "DesktopBlockingModal.sunsettingSubtitle",
            defaultMessage: "A new version of ChatGPT Windows is available and must be installed to continue."
        },
        cta: {
            id: "DesktopBlockingModal.sunsettingCta",
            defaultMessage: "Get Download"
        },
        logout: {
            id: "DesktopBlockingModal.sunsettingLogout",
            defaultMessage: "Log out"
        }
    }),
    Zs = ke(() => Me(() => Promise.resolve().then(() => Gs), void 0).then(t => t.WorkspaceDiscoveryRenamePromptModal)),
    ea = ke(() => Me(() =>
        import ("./edyp3sdbe40d6h2d.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7]))),
    ta = ke(() => Me(() =>
        import ("./3ype9xcsrgcixjgo.js"), __vite__mapDeps([8, 1, 2, 3, 4, 5, 6, 7]))),
    oa = ke(() => Me(() =>
        import ("./grh1jqxqycv190js.js"), __vite__mapDeps([9, 1, 2, 3, 4, 5])).then(t => t.RequestWorkspaceAccessModal)),
    sa = ke(() => Me(() =>
        import ("./k15yxxoybkkir2ou.js").then(t => t.F7), __vite__mapDeps([4, 1, 2, 3, 5])).then(t => t.ConnectorsReconnectModal)),
    aa = ({
        onClose: t
    }) => {
        const e = se(),
            s = ue(Ce.isBusinessWorkspace),
            a = ue(c => c.currentWorkspace),
            r = s ? e.formatMessage(xt.workspaceWelcome, {
                workspaceName: a == null ? void 0 : a.name
            }) : "ChatGPT";
        return o.jsx(ae, {
            testId: "modal-onboarding",
            isOpen: !0,
            onClose: J,
            type: "success",
            title: r,
            size: "custom",
            noPadding: !0,
            className: "max-w-3xl",
            description: e.formatMessage(xt.personalOnboardingSubheading),
            children: o.jsx(yt, {
                onClose: t,
                scope: s ? je.Workspace : je.Personal
            })
        })
    };

function na(t) {
    return o.jsx(Dt, te(k({}, t), {
        mode: "blocking",
        section: "both",
        source: "first_login"
    }))
}

function ia(t) {
    return o.jsx(Dt, te(k({}, t), {
        mode: "blocking",
        section: "existing",
        source: "should_select_workspace"
    }))
}

function fa({
    clientThreadId: t,
    page: e,
    isIosDirectPurchaseFlow: s
}) {
    const a = me(),
        [r] = Vt(),
        c = s != null ? s : r.get("from_webview") === "ios",
        [i, u] = h.useState(0),
        m = Ss(a, "109457"),
        {
            hasSeenOnboardingDate: n
        } = so(),
        _ = n === !1 && m.get("is_new_user_banner_disclaimer_enabled", !1),
        {
            hasSeenWorkspaceDiscoveryFirstLoginDate: p
        } = ao(),
        {
            hasSeenTeamOwnerOnboardingDate: b
        } = no(),
        l = ue(Ce.isBusinessWorkspace),
        {
            isOpen: M,
            isLoading: T
        } = ht(),
        [x, g] = h.useState(!1),
        {
            data: xe,
            isPending: C,
            isEnabled: pe
        } = io(),
        w = ro(xe, C && pe),
        A = ws(),
        v = vs(),
        [Y, S] = Cs(t, d => [!d || d.isLoading, d == null ? void 0 : d.conversationOrigin]),
        B = Y && !!t,
        {
            data: f,
            isError: P
        } = Os(),
        y = Ns(f),
        O = f != null,
        E = lo(15),
        [L, ge] = h.useState(!1);
    h.useEffect(() => {
        E && !L && ge(!0)
    }, [E, L]);
    const {
        shouldShowModal: ne,
        isLoading: ie
    } = co(a), K = ie ? "loading" : ne ? "show" : "hide", R = uo(), X = mo(), I = Ct(), U = (I == null ? void 0 : I.email_domain_type) === "professional", re = !!(f != null && f.accountItems.some(d => d.isEnterprisey())), F = U && !re && Ds(a).getLayer("3217430380").get("enable_workspace_discovery", !1), Q = !!(U && p === !1 && F && L), {
        data: N,
        isLoading: z
    } = po(Q), G = !!(f && (f == null ? void 0 : f.accountItems.length) > 1 && f.currentAccountId == null), le = f == null ? void 0 : f.accountItems.some(d => d.isPersonalAccount()), V = !!(f != null && f.accountItems) && f.accountItems.length > 0 && f.accountItems.every(({
        canAccessWithCurrentSession: d
    }) => !d), {
        eligible: Z,
        isLoading: q
    } = go(), $ = we(a, "1542198993"), {
        punchOutRequireLoginInfo: ee
    } = fo(), {
        state: fe
    } = ho(), {
        isOpen: H
    } = bo(), {
        isOpen: Re,
        isLoading: Ue
    } = Pt(), {
        isOpen: Fe
    } = _o(), It = St(a), {
        isOpen: ze,
        isLoading: Ge
    } = It, {
        isOpen: Ve,
        isLoading: qe
    } = Mo(), {
        isOpen: $e,
        isLoading: He
    } = ko(), {
        isOpen: Ye
    } = xo(), {
        isOpen: Qe
    } = As(), {
        state: Je
    } = yo(), Ke = So(), Xe = wo(), Ze = vo(), et = Co(), tt = Oo(), ot = No(), st = Do(), at = Ao(), nt = Po(), {
        isOpen: it
    } = Lo(), {
        isOpen: Wt
    } = ht(), {
        isOpen: jt
    } = Io(), {
        isOpen: Tt
    } = Wo(), {
        isOpen: rt,
        open: lt
    } = jo(), [ct, dt] = Ps(() => [Ls(a), Is(a)]);
    h.useEffect(() => {
        _ && !l && !rt && lt()
    }, [_, l, rt, lt]);
    const Ne = h.useMemo(() => [{
            Component: To,
            visibility: ["chat", "codex"],
            getModalState: () => ee ? "show" : "hide",
            isDeferrable: !1,
            id: "punch_out_sign_in_as_modal"
        }, {
            Component: Bo,
            visibility: ["chat", "codex"],
            getModalState: () => fe,
            isDeferrable: !1,
            id: "punch_out_anon_to_authed_modal"
        }, {
            Component: Eo,
            visibility: ["chat"],
            getModalState: () => Je,
            isDeferrable: !1,
            id: "meet_chatgpt_modal"
        }, {
            Component: Ro,
            visibility: ["chat", "codex"],
            getModalState: () => nt,
            isDeferrable: !1,
            id: "subscription_failure_modal"
        }, {
            Component: Zs,
            visibility: ["chat", "codex"],
            getModalState: () => Ue ? "loading" : Re ? "show" : "hide",
            isDeferrable: !1,
            id: "workspace_discovery_rename_prompt_modal"
        }, {
            Component: na,
            visibility: ["chat", "codex"],
            getModalState: () => {
                var D, he;
                return !F || A != null || p || P ? "hide" : p == null || z ? "loading" : ((he = (D = N == null ? void 0 : N.workspaces) == null ? void 0 : D.length) != null ? he : 0) > 0 && L ? "show" : "hide"
            },
            isDeferrable: !1,
            id: "fullscreen_switcher_both"
        }, {
            Component: F ? ia : Ts,
            visibility: ["chat", "codex"],
            getModalState: () => A != null || P ? "hide" : O ? G ? "show" : "hide" : "loading",
            isDeferrable: !1,
            id: "workspace_switcher_modal"
        }, {
            Component: sa,
            visibility: ["chat"],
            getModalState: () => K,
            isDeferrable: !1,
            id: "connector_reconnect_modal"
        }, {
            Component: Uo,
            visibility: ["codex"],
            getModalState: () => R,
            isDeferrable: !1,
            id: "codex_onboarding_modal"
        }, {
            Component: Fo,
            visibility: ["codex"],
            getModalState: () => X,
            isDeferrable: !1,
            id: "codex_articFox_modal"
        }, {
            Component: zo,
            visibility: ["chat"],
            getModalState: () => it ? "show" : "hide",
            isDeferrable: !1,
            id: "noauth_promo_redemption_modal"
        }, {
            Component: Go,
            visibility: ["chat"],
            getModalState: () => H ? "show" : "hide",
            isDeferrable: !1,
            id: "noauth_plan_upsell_modal"
        }, {
            Component: Vo,
            visibility: ["chat"],
            getModalState: () => Xe,
            isDeferrable: !1,
            id: "noauth_free_trial_upsell_modal"
        }, {
            Component: qo,
            visibility: ["chat"],
            getModalState: () => Ke,
            isDeferrable: !0,
            id: "noauth_imagegen_nux_modal"
        }, {
            Component: $o,
            visibility: ["chat"],
            getModalState: () => B ? "loading" : S === We.APPLE ? "hide" : Fe ? "show" : "hide",
            isDeferrable: !0,
            id: "noauth_soft_rate_limit_modal"
        }, {
            Component: Ws,
            visibility: ["chat"],
            getModalState: () => B ? "loading" : S === We.APPLE ? "hide" : Qe ? "show" : "hide",
            isDeferrable: !0,
            id: "noauth_login_modal"
        }, {
            Component: Ho,
            visibility: ["chat"],
            getModalState: () => B ? "loading" : S === We.APPLE ? "hide" : Ye ? "show" : "hide",
            isDeferrable: !0,
            id: "noauth_welcome_back_modal"
        }, {
            Component: Yo,
            visibility: ["chat", "codex"],
            getModalState: () => dt ? "loading" : ct ? "show" : "hide",
            isDeferrable: !1,
            id: "cookie_consent_banner_tracker"
        }, {
            Component: aa,
            visibility: ["chat"],
            getModalState: () => l || _ ? "hide" : n === null ? "loading" : n === !1 ? "show" : "hide",
            isDeferrable: !0,
            id: "onboarding_modal"
        }, {
            Component: oa,
            visibility: ["chat", "codex"],
            getModalState: () => A !== null ? "show" : P || O ? "hide" : "loading",
            isDeferrable: !1,
            id: "request_workspace_access_modal"
        }, {
            Component: ea,
            visibility: ["chat", "codex"],
            getModalState: () => v != null ? "show" : P || O ? "hide" : "loading",
            isDeferrable: !1,
            id: "account_transfer_modal"
        }, {
            Component: Qo,
            visibility: ["chat", "codex"],
            getModalState: () => O ? V ? "show" : "hide" : "loading",
            isDeferrable: !1,
            id: "invalid_accounts_modal"
        }, {
            Component: Js,
            visibility: ["chat", "codex"],
            getModalState: () => Ge ? "loading" : ze ? "show" : "hide",
            isDeferrable: !1,
            id: "desktop_blocking_modal"
        }, {
            Component: Jo,
            visibility: ["chat", "codex"],
            getModalState: () => qe ? "loading" : Ve ? "show" : "hide",
            isDeferrable: !1,
            id: "desktop_onboarding_modal"
        }, {
            Component: Ko,
            visibility: ["chat", "codex"],
            getModalState: () => "hide",
            isDeferrable: !1,
            id: "authed_cookie_consent_banner"
        }, {
            Component: ta,
            visibility: ["chat", "codex"],
            getModalState: () => !(y != null && y.isSelfServeBusiness()) || !(y != null && y.isOwnerOfAccount()) || !le || y != null && y.startedAsFreeWorkspace ? "hide" : !O || b === null ? "loading" : b === !1 ? "show" : "hide",
            isDeferrable: !1,
            id: "team_account_transfer_modal"
        }, {
            Component: Xo,
            visibility: ["chat"],
            getModalState: () => l ? He ? "loading" : $e ? "show" : "hide" : "hide",
            isDeferrable: !1,
            id: "workspace_policy_modal"
        }, {
            Component: Qs,
            visibility: ["chat", "codex"],
            getModalState: () => !l || !T && M ? "hide" : n === null ? "loading" : n === !1 ? "show" : "hide",
            isDeferrable: !0,
            id: "workspace_onboarding_modal"
        }, {
            Component: Zo,
            visibility: ["chat"],
            getModalState: () => q ? "loading" : Z && $ ? "show" : "hide",
            isDeferrable: !1,
            id: "memory_onboarding_modal"
        }, {
            Component: es,
            visibility: ["chat", "codex"],
            getModalState: () => w,
            isDeferrable: !1,
            id: "age_verification_interstitial"
        }, {
            Component: ts,
            visibility: ["chat"],
            getModalState: () => l ? "hide" : Ze,
            isDeferrable: !1,
            id: "connectors_nux_modal"
        }, {
            Component: os,
            visibility: ["chat"],
            getModalState: () => st,
            isDeferrable: !1,
            id: "quiz_nux_modal"
        }, {
            Component: ss,
            visibility: ["chat"],
            getModalState: () => et,
            isDeferrable: !1,
            id: "google_connectors_nux_modal"
        }, {
            Component: as,
            visibility: ["chat"],
            getModalState: () => ot,
            isDeferrable: !0,
            id: "golden_hour_nux_modal"
        }, {
            Component: ns,
            visibility: ["chat"],
            getModalState: () => tt,
            isDeferrable: !0,
            id: "moonshine_nux_v2_modal"
        }, {
            Component: is,
            visibility: ["chat"],
            getModalState: () => at,
            isDeferrable: !0,
            id: "no_auth_modal"
        }].filter(D => D.visibility.includes(e)), [e, ee, fe, Je, it, Xe, Ke, Ue, Re, B, S, Fe, H, Ye, dt, ct, l, _, n, p, P, N, z, G, O, A, v, V, Ge, ze, qe, Ve, y, le, b, He, $e, q, Z, $, F, w, Ze, et, tt, st, R, X, L, Qe, ot, T, M, at, nt, K]),
        Bt = x;

    function ut(d) {
        if (d != null) return d.isDeferrable && Bt ? "hide" : d.Component ? d.getModalState() : "hide"
    }
    const ce = Ne[i],
        ye = ut(ce);
    ye === "hide" && u((() => {
        let D = i + 1;
        for (; D < Ne.length; D++)
            if (ut(Ne[D]) !== "hide") return D;
        return D
    })());
    const {
        pathname: Se
    } = qt(), mt = h.useRef(Se);
    h.useEffect(() => {
        mt.current !== Se && (mt.current = Se, u(0))
    }, [Se]), h.useEffect(() => {
        const d = ye === "show",
            he = js(a).getState().activeModals.has(Ie.BlockingInitialComponent);
        d !== he && (d ? Mt.openModal(Ie.BlockingInitialComponent) : Mt.closeModal(Ie.BlockingInitialComponent))
    }, [a, ye]);
    const De = ye !== "show" || Wt || jt || Tt || c,
        pt = rs(() => {
            oe.logUpsellOrModalEvent(Ot, {
                eventId: ce.id,
                type: Nt.UPSELL_OR_MODAL_TYPE_BLOCKING_INITIAL_MODAL
            })
        });
    if (h.useEffect(() => {
            if (ce == null) {
                ls.set(!0);
                return
            }
            De || (pt(), cs.dismiss())
        }, [ce, De, pt]), ce == null) return bt.trackNamespace(bt.NS_COMPOSER), o.jsx("span", {
        "data-testid": "blocking-initial-modals-done",
        className: "hidden"
    });
    if (De) return null;
    const Et = ce.Component;
    return o.jsx(Et, {
        onClose: () => {
            g(!0), u(d => d + 1)
        }
    })
}
const xt = _e({
    workspaceWelcome: {
        id: "BlockingInitialModals.workspaceWelcome",
        defaultMessage: "Welcome to the {workspaceName} workspace"
    },
    personalOnboardingSubheading: {
        id: "BlockingInitialModals.personalOnboardingSubheading",
        defaultMessage: "Tips for getting started"
    }
});
export {
    fa as B
};
//# sourceMappingURL=ii1vbrsyheft91cc.js.map