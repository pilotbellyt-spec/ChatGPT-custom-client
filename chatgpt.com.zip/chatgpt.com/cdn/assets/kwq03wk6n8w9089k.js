import {
    c as e,
    s as r
} from "./dykg4ktvbu3mhmdo.js";
const a = e(r, "2120a0", 24, 24),
    o = e(r, "172f95", 20, 20);
export {
    a as C, o as S
};
//# sourceMappingURL=kwq03wk6n8w9089k.js.map