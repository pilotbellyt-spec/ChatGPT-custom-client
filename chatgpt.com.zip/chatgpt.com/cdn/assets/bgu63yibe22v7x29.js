import {
    c as e,
    s as t
} from "./dykg4ktvbu3mhmdo.js";
const o = e(t, "7eff44", 12, 12, !0);
export {
    o as C
};
//# sourceMappingURL=bgu63yibe22v7x29.js.map