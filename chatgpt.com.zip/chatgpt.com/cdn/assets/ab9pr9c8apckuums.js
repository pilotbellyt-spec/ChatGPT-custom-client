import {
    s as o
} from "./cmaobpdpreyiep8p.js";
import {
    c as r
} from "./dykg4ktvbu3mhmdo.js";
const s = r(o, "265471", 24, 24);
export {
    s as M
};
//# sourceMappingURL=ab9pr9c8apckuums.js.map