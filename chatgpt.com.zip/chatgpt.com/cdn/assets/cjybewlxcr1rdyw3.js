import {
    c as t,
    s as e
} from "./dykg4ktvbu3mhmdo.js";
const r = t(e, "917f75", 20, 20);
export {
    r as A
};
//# sourceMappingURL=cjybewlxcr1rdyw3.js.map