import {
    S as t
} from "./iwhq2rihp0137gzf.js";
import {
    ap as a,
    aq as o,
    ar as i
} from "./k15yxxoybkkir2ou.js";
import {
    M as s
} from "./nf79rzyd6jobmpxe.js";
import {
    S as d
} from "./kyjerv6rln8oin0o.js";
import {
    d as e
} from "./fg33krlcm0qyi6yw.js";
const p = [{
    id: "review",
    title: e({
        id: "upv1Y0",
        defaultMessage: "Code review"
    }),
    icon: s,
    prompt: e({
        id: "t/Ghj2",
        defaultMessage: "Search for bugs and opportunities to improve the code—for example, ways that performance or code structure could be improved. Leave as few comments as possible, but add more comments if the text is long. DO NOT leave more than 5 comments. You may reply that you reviewed the code and left suggestions to improve the coding quality, but do not mention the prompt."
    }),
    action: t.COMMENT
}, {
    id: "comments",
    title: e({
        id: "sTWMBR",
        defaultMessage: "Add comments"
    }),
    icon: a,
    prompt: e({
        id: "yE/5uO",
        defaultMessage: "Add inline code comments to explain the code, especially parts that are more complex. Make sure to rewrite all the code. You may reply that you added inline comments, but do not mention the prompt."
    }),
    action: t.EDIT
}, {
    id: "logs",
    title: e({
        id: "+00vDz",
        defaultMessage: "Add logs"
    }),
    icon: d,
    prompt: e({
        id: "rrAJ7R",
        defaultMessage: "Insert logs/print statements in the code that will help debug its behavior. Do not make any other changes to the code."
    }),
    action: t.EDIT
}, {
    id: "bugs",
    title: e({
        id: "Uw2B/L",
        defaultMessage: "Fix bugs"
    }),
    icon: o,
    prompt: e({
        id: "8JI5Am",
        defaultMessage: "Find any bugs and rewrite all the code to fix the bugs. Do not add any new comments. If there are no bugs, reply that you reviewed the code and found no bugs."
    }),
    action: t.EDIT
}, {
    id: "port",
    title: e({
        id: "BotcNe",
        defaultMessage: "Port to a language"
    }),
    icon: i,
    action: t.CREATE_TEXTDOC,
    menu: [{
        prompt: e({
            id: "LGUTjb",
            defaultMessage: "Create a new document that rewrites the code in PHP"
        }),
        title: e({
            id: "oR7PqF",
            defaultMessage: "PHP"
        })
    }, {
        prompt: e({
            id: "t6K8xn",
            defaultMessage: "Create a new document that rewrites the code in C++"
        }),
        title: e({
            id: "QbnHp2",
            defaultMessage: "C++"
        })
    }, {
        prompt: e({
            id: "hmI7x6",
            defaultMessage: "Create a new document that rewrites the code in Python"
        }),
        title: e({
            id: "viPy6U",
            defaultMessage: "Python"
        })
    }, {
        prompt: e({
            id: "oY48Xk",
            defaultMessage: "Create a new document that rewrites the code in JavaScript"
        }),
        title: e({
            id: "Mnbu7B",
            defaultMessage: "JavaScript"
        })
    }, {
        prompt: e({
            id: "7H04sz",
            defaultMessage: "Create a new document that rewrites the code in TypeScript"
        }),
        title: e({
            id: "pot/GV",
            defaultMessage: "TypeScript"
        })
    }, {
        prompt: e({
            id: "IFRMM/",
            defaultMessage: "Create a new document that rewrites the code in Java"
        }),
        title: e({
            id: "78tNyh",
            defaultMessage: "Java"
        })
    }]
}];
export {
    p as C
};
//# sourceMappingURL=nh559o9htk2jfyt0.js.map