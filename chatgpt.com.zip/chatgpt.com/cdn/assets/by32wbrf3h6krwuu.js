var ie = Object.defineProperty,
    ne = Object.defineProperties;
var re = Object.getOwnPropertyDescriptors;
var _ = Object.getOwnPropertySymbols;
var oe = Object.prototype.hasOwnProperty,
    de = Object.prototype.propertyIsEnumerable;
var I = (o, a, i) => a in o ? ie(o, a, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: i
    }) : o[a] = i,
    c = (o, a) => {
        for (var i in a || (a = {})) oe.call(a, i) && I(o, i, a[i]);
        if (_)
            for (var i of _(a)) de.call(a, i) && I(o, i, a[i]);
        return o
    },
    g = (o, a) => ne(o, re(a));
import {
    ad as G,
    rd as U
} from "./dykg4ktvbu3mhmdo.js";
import {
    A as F
} from "./lfdsdf4it937c4a2.js";
import {
    S as E,
    M as y,
    T as S,
    A as T,
    a as O,
    L as w,
    P as V,
    I as L,
    R as D,
    b as B,
    c as le,
    d as j,
    C as N,
    e as k,
    B as W,
    f as q,
    g as Y,
    h as z,
    i as H,
    F as Q,
    j as K,
    k as ue,
    l as ce,
    m as ge,
    n as me,
    o as pe,
    p as fe
} from "./mvl4u7g4pep6uysr.js";
import {
    c6 as m,
    c7 as C,
    c8 as h,
    c9 as $,
    ca as J,
    cb as X,
    cc as Me,
    cd as Pe,
    ce as R,
    cf as Z,
    az as ee,
    cg as Ce,
    ch as he,
    ci as ae,
    cj as te
} from "./k15yxxoybkkir2ou.js";
import {
    f as e
} from "./fg33krlcm0qyi6yw.js";
const x = e({
        cancelAnytime: {
            id: "pricingPlanConstants.freeTrial.cancelAnytime",
            defaultMessage: "Cancel anytime"
        },
        remindYouBeforeTrialEnds: {
            id: "pricingPlanConstants.freeTrial.remindYouBeforeTrialEnds",
            defaultMessage: "We'll remind you before your trial ends"
        }
    }),
    Ae = e({
        goCTA: {
            id: "pricingPlanConstants.go.callToAction",
            defaultMessage: "Upgrade to Go"
        },
        goCTAActive: {
            id: "pricingPlanConstants.go.callToActionActive",
            defaultMessage: "Your current plan"
        },
        goSummary: {
            id: "pricingPlanConstants.go.summary",
            defaultMessage: "Get more access to our most popular features"
        },
        goCTAPromo: {
            id: "pricingPlanConstants.go.callToActionPromo",
            defaultMessage: "Apply to my subscription"
        }
    }),
    se = e({
        freeCTA_UnifiedAccountCreation_Experiment: {
            id: "pricingPlanConstants.free.freeCTA_UnifiedAccountCreation_Experiment",
            defaultMessage: "Continue with free plan"
        },
        freeCTA: {
            id: "pricingPlanConstants.free.callToAction",
            defaultMessage: "Your current plan"
        },
        freeSummary: {
            id: "pricingPlanConstants.free.freeSummary",
            defaultMessage: "Explore how AI can help you with everyday tasks"
        },
        freeCost: {
            id: "pricingPlanConstants.free.cost",
            defaultMessage: "0"
        },
        freeBasicModelAccess: {
            id: "pricingPlanConstants.free.freeAdvertisedFeaturesProduce0_1",
            defaultMessage: "Access to GPT-5"
        },
        costRetrievalError: {
            id: "pricingPlanConstants.costRetrievalError",
            defaultMessage: "Unable to load plan cost, please refresh the page"
        }
    }),
    be = e({
        plusSummary: {
            id: "pricingPlanConstants.plus.plusSummary",
            defaultMessage: "Level up productivity and creativity with expanded access"
        },
        plusSummaryWithDiscount: {
            id: "pricingPlanConstants.plus.plusSummaryWithDiscount",
            defaultMessage: "More access to advanced intelligence"
        },
        plusActive: {
            id: "pricingPlanConstants.plus.callToAction.active",
            defaultMessage: "Your current plan"
        },
        plusInactive: {
            id: "pricingPlanConstants.plus.callToAction.inactivePayment",
            defaultMessage: "Get Plus"
        },
        plusInactiveUnauthenticated: {
            id: "pricingPlanConstants.plus.callToAction.inactiveUnauthenticated",
            defaultMessage: "Sign up to get free Plus"
        },
        memoryUpsell: {
            id: "pricingPlanConstants.plus.memoryUpsell",
            defaultMessage: "More space for memories"
        },
        studentAdvertisedFeatures1: {
            id: "pricingPlanConstants.student.studentAdvertisedFeatures1",
            defaultMessage: "Generate quick summaries of documents with more file uploads"
        },
        studentAdvertisedFeatures2: {
            id: "pricingPlanConstants.student.studentAdvertisedFeatures2",
            defaultMessage: "Practice speaking foreign languages with advanced voice"
        },
        studentAdvertisedFeatures3: {
            id: "pricingPlanConstants.student.studentAdvertisedFeatures3",
            defaultMessage: "Test new features like Projects, which lets you organize chats by topic"
        },
        studentAdvertisedFeatures4: {
            id: "pricingPlanConstants.student.studentAdvertisedFeatures4",
            defaultMessage: "Get better answers to your biggest questions with our most advanced AI models"
        },
        plusRedesignFeatures: {
            id: "pricingPlanConstants.plus.plusRedesignFeatures",
            defaultMessage: "Everything in Free"
        }
    }),
    A = e({
        featureEverythingInFree: {
            id: "pricingPlanConstants.go.checkout.featureEverythingInFree",
            defaultMessage: "Smarter, faster responses with GPT-5"
        },
        featureGPT5Extended: {
            id: "pricingPlanConstants.go.checkout.featureGPT5Extended",
            defaultMessage: "More messages & uploads"
        },
        featureImgGenExtended: {
            id: "pricingPlanConstants.go.checkout.featureImgGenExtended",
            defaultMessage: "Faster, higher-quality image creation"
        },
        featureFileUploadsExtended: {
            id: "pricingPlanConstants.go.checkout.featureFileUploadsExtended",
            defaultMessage: "Extra memory & context"
        }
    }),
    b = e({
        featureSmarterFasterResponses: {
            id: "pricingPlanConstants.plus.checkout.featureSmarterFasterResponses",
            defaultMessage: "Smarter, faster responses with GPT-5"
        },
        featureMoreMessagesUploads: {
            id: "pricingPlanConstants.plus.checkout.featureMoreMessagesUploads",
            defaultMessage: "More messages & uploads"
        },
        featureFasterImages: {
            id: "pricingPlanConstants.plus.checkout.featureFasterImages",
            defaultMessage: "Faster, higher-quality image creation"
        },
        featureExpandedMemory: {
            id: "pricingPlanConstants.plus.checkout.featureExpandedMemory",
            defaultMessage: "Extra memory & context"
        }
    }),
    ve = e({
        teamPlanSummary: {
            id: "pricingPlanConstants.team.teamPlanSummary",
            defaultMessage: "Supercharge your business with a secure, collaborative workspace"
        },
        teamPlanSummary_V2: {
            id: "pricingPlanConstants.team.teamPlanSummary_V2",
            defaultMessage: "Secure, collaborative workspace for teams"
        },
        teamPlanActive: {
            id: "pricingPlanConstants.teams.teamPlanActive",
            defaultMessage: "Your current plan"
        },
        teamPlanCreate: {
            id: "pricingPlanConstants.teams.teamPlanCreate",
            defaultMessage: "Add Business workspace"
        },
        teamPlanCost: {
            id: "pricingPlanConstants.teams.teamPlanSubTitle",
            defaultMessage: "25"
        },
        teamAdvertisedFeatures0: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures0_1",
            defaultMessage: "Everything in Plus and more: unlimited GPT-5 messages, with generous access to GPT-5 thinking, access to GPT-5 pro, and optional credits that scale with your team."
        },
        teamAdvertisedFeatures1: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures1",
            defaultMessage: "Connect your company knowledge: Google Drive, SharePoint, Dropbox, GitHub, Outlook, and custom integrations"
        },
        teamAdvertisedFeatures2: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures2",
            defaultMessage: "Business-essential security: SAML SSO, MFA, SOC 2 Type 2, encryption in transit & at rest, data excluded from training"
        },
        teamAdvertisedFeatures3: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures3",
            defaultMessage: "Record mode: capture meetings and voice notes on macOS desktop, then search and reference transcripts in any chat"
        },
        teamAdvertisedFeatures4: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures4",
            defaultMessage: "Business features like shared projects, tasks, file uploads, and custom workspace GPTs"
        },
        teamAdvertisedFeatures5: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures5",
            defaultMessage: "Built-in agents – deep research, ChatGPT agent, and Codex can reason across your documents, tools, and codebases to save you hours"
        },
        teamAdvertisedFeatures6: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures6",
            defaultMessage: "Multimodal creation – create videos with Sora, generate images, build canvases, run advanced data analysis, and execute code inline"
        },
        teamAdvertisedFeatures0_ComparisonV2_Experiment: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures0_ComparisonV2_Experiment",
            defaultMessage: "Everything in Plus, with even higher limits"
        },
        teamAdvertisedFeatures1_ComparisonV2_Experiment: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures1_ComparisonV2_Experiment",
            defaultMessage: "Unlimited access to our best model for work"
        },
        teamAdvertisedFeatures2_ComparisonV2_Experiment: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures2_ComparisonV2_Experiment",
            defaultMessage: "Advanced security with SSO, MFA & more"
        },
        teamAdvertisedFeatures3_ComparisonV2_Experiment: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures3_ComparisonV2_Experiment",
            defaultMessage: "Privacy built in; data never used for training"
        },
        teamAdvertisedFeatures4_ComparisonV2_Experiment: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures4_ComparisonV2_Experiment",
            defaultMessage: "Integration with Sharepoint & other tools"
        },
        teamAdvertisedFeatures5_ComparisonV2_Experiment: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures5_ComparisonV2_Experiment",
            defaultMessage: "Tools for teams like shared projects & custom GPTs"
        },
        teamAdvertisedFeatures6_ComparisonV2_Experiment: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures6_ComparisonV2_Experiment",
            defaultMessage: "Simplified billing and user management"
        },
        teamAdvertisedFeatures7_ComparisonV2_Experiment: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures7_ComparisonV2_Experiment",
            defaultMessage: "Meeting and voice transcription"
        },
        teamAdvertisedFeatures8_ComparisonV2_Experiment: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures8_ComparisonV2_Experiment",
            defaultMessage: "Coding and deep research agents"
        },
        teamAdvertisedFeatures9_ComparisonV2_Experiment: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures9_ComparisonV2_Experiment",
            defaultMessage: "Videos, image gen, data, & code all in chat"
        },
        teamPlanSummary_UnifiedAccountCreation_Experiment: {
            id: "pricingPlanConstants.team.teamPlanSummary_UnifiedAccountCreation_Experiment",
            defaultMessage: "Secure, collaborative workspace for teams"
        },
        teamAdvertisedFeatures_EverythingInFreePlus_UnifiedAccountCreation_Experiment: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures_EverythingInFreePlus_UnifiedAccountCreation_Experiment",
            defaultMessage: "Everything in free, plus"
        },
        teamAdvertisedFeatures0_UnifiedAccountCreation_Experiment: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures0_UnifiedAccountCreation_Experiment",
            defaultMessage: "Unlimited access to our best model for work"
        },
        teamAdvertisedFeatures1_UnifiedAccountCreation_Experiment: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures1_UnifiedAccountCreation_Experiment",
            defaultMessage: "Privacy built in; data never used for training"
        },
        teamAdvertisedFeatures2_UnifiedAccountCreation_Experiment: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures2_UnifiedAccountCreation_Experiment",
            defaultMessage: "Tools for teams like shared projects & custom GPTs"
        },
        teamAdvertisedFeatures3_UnifiedAccountCreation_Experiment: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures3_UnifiedAccountCreation_Experiment",
            defaultMessage: "Integration with Sharepoint & other tools"
        },
        teamAdvertisedFeatures4_UnifiedAccountCreation_Experiment: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures4_UnifiedAccountCreation_Experiment",
            defaultMessage: "Coding and deep research agents"
        },
        teamAdvertisedFeatures5_UnifiedAccountCreation_Experiment: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures5_UnifiedAccountCreation_Experiment",
            defaultMessage: "Simplified billing and user management"
        },
        teamAdvertisedFeatures6_UnifiedAccountCreation_Experiment: {
            id: "pricingPlanConstants.team.teamAdvertisedFeatures6_UnifiedAccountCreation_Experiment",
            defaultMessage: "Advanced security with SSO, MFA & more"
        },
        teamPlanInactive_UnifiedAccountCreation_Experiment: {
            id: "pricingPlanConstants.team.teamPlanInactive_UnifiedAccountCreation_Experiment",
            defaultMessage: "Start Business trial"
        },
        teamPricingDisclaimer: {
            id: "pricingPlanConstants.teams.teamPricingDisclaimer",
            defaultMessage: "For {minSeats}+ users, billed annually"
        },
        teamPricingDisclaimer2: {
            id: "pricingPlanConstants.team.teamPricingDisclaimer2",
            defaultMessage: "Unlimited subject to abuse guardrails. <link>Learn more</link>",
            link: "https://help.openai.com/en/articles/8792828-what-is-chatgpt-team"
        },
        teamPricingDisclaimerRedesign: {
            id: "pricingPlanConstants.teams.teamPricingDisclaimerRedesign",
            defaultMessage: "*Billed as $1/seat for 30 days up to 5 seats and $30 seat/mo thereafter"
        },
        teamPlanInactive: {
            id: "pricingPlanConstants.teams.callToAction.inactivePayment",
            defaultMessage: "Get Business"
        }
    }),
    u = e({
        featureUnlimitedBestModel: {
            id: "pricingPlanConstants.business.checkout.featureUnlimitedBestModel",
            defaultMessage: "Advanced access to our best model for work"
        },
        featureAdvancedSecurity: {
            id: "pricingPlanConstants.business.checkout.featureAdvancedSecurity",
            defaultMessage: "Advanced security with SSO, MFA, and more"
        },
        featureUnifiedBilling: {
            id: "pricingPlanConstants.business.checkout.featureUnifiedBilling",
            defaultMessage: "Unified billing and org management"
        },
        featureConnectExternalSources: {
            id: "pricingPlanConstants.business.checkout.featureConnectExternalSources",
            defaultMessage: "Connect external apps securely"
        },
        featureTeamTools: {
            id: "pricingPlanConstants.business.checkout.featureTeamTools",
            defaultMessage: "Team tools like projects and custom GPTs"
        },
        featureIntegrations: {
            id: "pricingPlanConstants.business.checkout.featureIntegrations",
            defaultMessage: "Integration with SharePoint and more"
        },
        featureAdminControls: {
            id: "pricingPlanConstants.business.checkout.featureAdminControls",
            defaultMessage: "Easy member, role, and billing management"
        }
    }),
    xe = e({
        proActive: {
            id: "pricingPlanConstants.pro.callToAction.active",
            defaultMessage: "Your current plan"
        },
        proInactive: {
            id: "pricingPlanConstants.pro.callToAction.inactive",
            defaultMessage: "Get Pro"
        },
        proSummary: {
            id: "pricingPlanConstants.pro.proPlanSummary",
            defaultMessage: "Get the best of OpenAI with the highest level of access"
        },
        proPricingDisclaimer: {
            id: "pricingPlanConstants.pro.proPricingDisclaimer",
            defaultMessage: "Unlimited subject to abuse guardrails. <link>Learn more</link>",
            link: "https://help.openai.com/en/articles/9793128-what-is-chatgpt-pro"
        }
    }),
    v = e({
        featureUnlimitedBestModels: {
            id: "pricingPlanConstants.pro.checkout.featureUnlimitedBestModels",
            defaultMessage: "Unlimited access to our best models"
        },
        featureUnlimitedAdvancedVoice: {
            id: "pricingPlanConstants.pro.checkout.featureUnlimitedAdvancedVoice",
            defaultMessage: "Unlimited use of advanced voice features"
        },
        featureExpandedAgent: {
            id: "pricingPlanConstants.pro.checkout.featureExpandedAgent",
            defaultMessage: "Expanded, priority-speed Codex agent"
        },
        featureMostImageVideo: {
            id: "pricingPlanConstants.pro.checkout.featureMostImageVideo",
            defaultMessage: "The most image and video generation"
        },
        featureLatestFeaturesFirst: {
            id: "pricingPlanConstants.pro.checkout.featureLatestFeaturesFirst",
            defaultMessage: "Access the latest new features first"
        }
    }),
    p = e({
        manageSubscriptionWeb: {
            id: "pricingPlanConstants.manageSubscriptionWeb.callToAction",
            defaultMessage: "Manage my subscription"
        },
        manageSubscriptionIos: {
            id: "pricingPlanConstants.manageSubscriptionIos.callToAction",
            defaultMessage: "Manage my subscription in the ChatGPT iOS app"
        },
        manageSubscriptionAndroid: {
            id: "pricingPlanConstants.manageSubscriptionAndroid.callToAction",
            defaultMessage: "Manage my subscription in the ChatGPT Android app"
        },
        cancelSubscriptionWeb: {
            id: "pricingPlanConstants.cancelSubscriptionWeb.callToAction",
            defaultMessage: "Cancel my subscription"
        },
        cancelSubscriptionIos: {
            id: "pricingPlanConstants.cancelSubscriptionIos.callToAction",
            defaultMessage: "Cancel my subscription in the ChatGPT iOS app"
        },
        cancelSubscriptionAndroid: {
            id: "pricingPlanConstants.cancelSubscriptionAndroid.callToAction",
            defaultMessage: "Cancel my subscription in the ChatGPT Android app"
        }
    }),
    _e = {
        manageSubscriptionIos: {
            callToAction: p.manageSubscriptionIos
        },
        manageSubscriptionAndroid: {
            callToAction: p.manageSubscriptionAndroid
        },
        cancelSubscriptionWeb: {
            callToAction: p.cancelSubscriptionWeb
        },
        cancelSubscriptionIos: {
            callToAction: p.cancelSubscriptionIos
        },
        cancelSubscriptionAndroid: {
            callToAction: p.cancelSubscriptionAndroid
        }
    },
    f = e({
        planName: {
            id: "pricing.freeRedesign.planName",
            defaultMessage: "Free"
        },
        headline: {
            id: "pricing.freeRedesign.headline_08012025",
            defaultMessage: "Intelligence for everyday tasks"
        },
        cta: {
            id: "pricing.freeRedesign.cta",
            defaultMessage: "Start for free"
        },
        featureBasicModels: {
            id: "pricing.freeRedesign.feature.basicModels",
            defaultMessage: "Basic models"
        },
        featureLimitedMessagesUploads: {
            id: "pricingPlanConstants.free.freeAdvertisedFeaturesProduce0_2_restricted",
            defaultMessage: "Limited file uploads"
        },
        featureLimitedImageGen: {
            id: "pricing.freeRedesign.feature.limitedImageGen",
            defaultMessage: "Limited and slower image generation"
        },
        featureLimitedDeepResearch: {
            id: "pricing.freeRedesign.feature.limitedDeepResearch",
            defaultMessage: "Limited deep research"
        },
        featureLimitedMemoryContext: {
            id: "pricing.freeRedesign.feature.limitedMemoryContext",
            defaultMessage: "Limited memory and context"
        }
    }),
    t = e({
        planName: {
            id: "pricing.plusRedesign.planName",
            defaultMessage: "Plus"
        },
        headline: {
            id: "pricing.plusRedesign.headline",
            defaultMessage: "More access to advanced intelligence"
        },
        cta: {
            id: "pricing.plusRedesign.cta",
            defaultMessage: "Get Plus"
        },
        featureAdvancedReasoning: {
            id: "pricingPlanConstants.plus.plusAdvertisedFeatures0_redesign_restricted",
            defaultMessage: "GPT-5 with advanced reasoning"
        },
        featureExpandedMessagesUploads: {
            id: "pricing.plusRedesign.feature.expandedMessagesUploads",
            defaultMessage: "Expanded messaging and uploads"
        },
        featureMoreImageCreation: {
            id: "pricing.plusRedesign.feature.moreImageCreation",
            defaultMessage: "More image creation, faster loading"
        },
        featureExpandedFasterImageCreation: {
            id: "pricing.plusRedesign.feature.expandedFasterImageCreation",
            defaultMessage: "Expanded and faster image creation"
        },
        featureExpandedDeepResearchAgentMode: {
            id: "pricing.plusRedesign.feature.expandedDeepResearchAgentMode",
            defaultMessage: "Expanded deep research and agent mode"
        },
        featureExpandedMemoryContext: {
            id: "pricing.plusRedesign.feature.expandedMemoryContext",
            defaultMessage: "Expanded memory and context"
        },
        featureSoraVideoGeneration: {
            id: "pricing.plusRedesign.feature.soraVideoGeneration",
            defaultMessage: "Sora video generation"
        },
        featureCodexAgent: {
            id: "pricing.plusRedesign.feature.codexAgent",
            defaultMessage: "Codex agent"
        },
        footnoteLimitsApply: {
            id: "pricing.plusRedesign.footnote.limitsApply",
            defaultMessage: "Limits apply"
        }
    }),
    n = e({
        planName: {
            id: "pricing.proRedesign.planName",
            defaultMessage: "Pro"
        },
        headline: {
            id: "pricing.proRedesign.headline_08012025",
            defaultMessage: "Full access to the best of ChatGPT"
        },
        cta: {
            id: "pricing.proRedesign.cta",
            defaultMessage: "Get Pro"
        },
        featureMostPowerfulModels: {
            id: "pricingPlanConstants.pro.proAdvertisedFeatures0_redesign_restricted",
            defaultMessage: "GPT-5 with pro reasoning"
        },
        featureUnlimitedMessagesUploads: {
            id: "pricing.proRedesign.feature.unlimitedMessagesUploads",
            defaultMessage: "Unlimited messages and uploads"
        },
        featureUnlimitedFasterImageCreation: {
            id: "pricing.proRedesign.feature.unlimitedFasterImageCreation",
            defaultMessage: "Unlimited and faster image creation"
        },
        featureMaximumDeepResearchAgentMode: {
            id: "pricing.proRedesign.feature.maximumDeepResearchAgentMode",
            defaultMessage: "Maximum deep research and agent mode"
        },
        featureMaximumMemoryContext: {
            id: "pricing.proRedesign.feature.maximumMemoryContext",
            defaultMessage: "Maximum memory and context"
        },
        featureExpandedProjectsTasksCustomGPTs: {
            id: "pricing.proRedesign.feature.expandedProjectsTasksCustomGPTs",
            defaultMessage: "Expanded projects, tasks, and custom GPTs"
        },
        featureExpandedSoraVideoGeneration: {
            id: "pricing.proRedesign.feature.expandedSoraVideoGeneration",
            defaultMessage: "Expanded Sora video generation"
        },
        featureExpandedCodexAgent: {
            id: "pricing.proRedesign.feature.expandedCodexAgent",
            defaultMessage: "Expanded, priority-speed Codex agent"
        },
        featureResearchPreview: {
            id: "pricing.proRedesign.feature.researchPreview",
            defaultMessage: "Research preview of new features"
        },
        footnoteAbuseGuardrails: {
            id: "pricing.proRedesign.footnote.abuseGuardrails",
            defaultMessage: "Unlimited subject to abuse guardrails"
        }
    }),
    ye = e({
        planName: {
            id: "pricing.teamRedesign.planName",
            defaultMessage: "Business"
        },
        headline: {
            id: "pricing.teamRedesign.headline",
            defaultMessage: "Supercharge your business with a secure, collaborative workspace"
        },
        cta: {
            id: "pricing.teamRedesign.cta",
            defaultMessage: "Get Business"
        },
        featureEverythingInPlus: {
            id: "pricing.teamRedesign.feature.everythingInPlus",
            defaultMessage: "Everything in Plus"
        },
        featureUnlimitedGpt4oAnd41Mini: {
            id: "pricing.teamRedesign.feature.unlimitedGpt4oAnd41Mini",
            defaultMessage: "Unlimited access to GPT-4o and 4.1‑mini"
        },
        featureConnectorsInternalKnowledge: {
            id: "pricing.teamRedesign.feature.connectorsInternalKnowledge",
            defaultMessage: "Connectors to internal knowledge"
        },
        featureSecuredWorkspaceAdminBilling: {
            id: "pricing.teamRedesign.feature.securedWorkspaceAdminBilling",
            defaultMessage: "Secured workspace with admin tools and billing"
        },
        featurePrivacyLawCompliant: {
            id: "pricing.teamRedesign.feature.privacyLawCompliant",
            defaultMessage: "Privacy law compliant"
        },
        featureBusinessFeaturesDataAnalysisRecordModeCustomGPTs: {
            id: "pricing.teamRedesign.feature.businessFeaturesDataAnalysisRecordModeCustomGPTs",
            defaultMessage: "Business features like data analysis, record mode, and custom GPTs"
        }
    }),
    M = e({
        headline: {
            id: "pricing.freeOutcome.headline",
            defaultMessage: "See what AI can do"
        },
        featureSimpleExplanations: {
            id: "pricing.freeOutcome.feature.simpleExplanations",
            defaultMessage: "Get simple explanations"
        },
        featureShortChats: {
            id: "pricing.freeOutcome.feature.shortChats",
            defaultMessage: "Have short chats for common questions"
        },
        featureTryImageGeneration: {
            id: "pricing.freeOutcome.feature.tryImageGeneration",
            defaultMessage: "Try out image generation"
        },
        featureLimitedMemory: {
            id: "pricing.freeOutcome.feature.limitedMemory",
            defaultMessage: "Save limited memory and context"
        }
    }),
    l = e({
        headline: {
            id: "pricing.goOutcome.headline",
            defaultMessage: "Do more with smarter AI"
        },
        featureDeepQuestions: {
            id: "pricing.goOutcome.feature.deepQuestions",
            defaultMessage: "Go deep on harder questions"
        },
        featureLongerChatsUploads: {
            id: "pricing.goOutcome.feature.longerChatsUploads",
            defaultMessage: "Chat longer and upload more content"
        },
        featureRealisticImages: {
            id: "pricing.goOutcome.feature.realisticImages",
            defaultMessage: "Make realistic images for your projects"
        },
        featureSmarterReplies: {
            id: "pricing.goOutcome.feature.smarterReplies",
            defaultMessage: "Store more context for smarter replies"
        },
        featurePlanningTasks: {
            id: "pricing.goOutcome.feature.planningTasks",
            defaultMessage: "Get help with planning and tasks"
        },
        featureProjectsTasksGPTs: {
            id: "pricing.goOutcome.feature.projectsTasksGpts",
            defaultMessage: "Explore projects, tasks, and custom GPTs"
        }
    }),
    d = e({
        headline: {
            id: "pricing.plusOutcome.headline",
            defaultMessage: "Unlock the full experience"
        },
        featureSolveComplexProblems: {
            id: "pricing.plusOutcome.feature.solveComplexProblems",
            defaultMessage: "Solve complex problems"
        },
        featureLongChats: {
            id: "pricing.plusOutcome.feature.longChats",
            defaultMessage: "Have long chats over multiple sessions"
        },
        featureFasterImages: {
            id: "pricing.plusOutcome.feature.fasterImages",
            defaultMessage: "Create more images, faster"
        },
        featureRememberGoals: {
            id: "pricing.plusOutcome.feature.rememberGoals",
            defaultMessage: "Remember goals and past conversations"
        },
        featureAgentModePlanning: {
            id: "pricing.plusOutcome.feature.agentModePlanning",
            defaultMessage: "Plan travel and tasks with agent mode"
        },
        featureOrganizeProjects: {
            id: "pricing.plusOutcome.feature.organizeProjects",
            defaultMessage: "Organize projects and customize GPTs"
        },
        featureSoraVideos: {
            id: "pricing.plusOutcome.feature.soraVideos",
            defaultMessage: "Produce and share videos on Sora"
        },
        featureCodexApps: {
            id: "pricing.plusOutcome.feature.codexApps",
            defaultMessage: "Write code and build apps with Codex"
        }
    }),
    r = e({
        headline: {
            id: "pricing.proOutcome.headline",
            defaultMessage: "Maximize your productivity"
        },
        featureMasterAdvancedTasks: {
            id: "pricing.proOutcome.feature.masterAdvancedTasks",
            defaultMessage: "Master advanced tasks and topics"
        },
        featureUnlimitedMessages: {
            id: "pricing.proOutcome.feature.unlimitedMessages",
            defaultMessage: "Tackle big projects with unlimited messages"
        },
        featureHighQualityImages: {
            id: "pricing.proOutcome.feature.highQualityImages",
            defaultMessage: "Create high-quality images at any scale"
        },
        featureMaximumMemory: {
            id: "pricing.proOutcome.feature.maximumMemory",
            defaultMessage: "Keep full context with maximum memory"
        },
        featureResearchAgents: {
            id: "pricing.proOutcome.feature.researchAgents",
            defaultMessage: "Run research and plan tasks with agents"
        },
        featureScaleProjects: {
            id: "pricing.proOutcome.feature.scaleProjects",
            defaultMessage: "Scale your projects and automate workflows"
        },
        featureSoraVideoCreation: {
            id: "pricing.proOutcome.feature.soraVideoCreation",
            defaultMessage: "Expand your limits with Sora video creation"
        },
        featureCodexDeploy: {
            id: "pricing.proOutcome.feature.codexDeploy",
            defaultMessage: "Deploy code faster with Codex"
        },
        featureEarlyAccess: {
            id: "pricing.proOutcome.feature.earlyAccess",
            defaultMessage: "Get early access to experimental features"
        }
    }),
    s = e({
        headline: {
            id: "pricing.teamOutcome.headline",
            defaultMessage: "Get more work done with AI for teams"
        },
        featureProfessionalAnalysis: {
            id: "pricing.teamOutcome.feature.professionalAnalysis",
            defaultMessage: "Conduct professional analysis"
        },
        featureUnlimitedMessages: {
            id: "pricing.teamOutcome.feature.unlimitedMessages",
            defaultMessage: "Get unlimited messages with GPT-5"
        },
        featureProduceMedia: {
            id: "pricing.teamOutcome.feature.produceMedia",
            defaultMessage: "Produce images, videos, slides, & more"
        },
        featureSecureWorkspace: {
            id: "pricing.teamOutcome.feature.secureWorkspace",
            defaultMessage: "Secure your space with SSO, MFA, & more"
        },
        featureProtectPrivacy: {
            id: "pricing.teamOutcome.feature.protectPrivacy",
            defaultMessage: "Protect privacy; data never used for training"
        },
        featureShareProjects: {
            id: "pricing.teamOutcome.feature.shareProjects",
            defaultMessage: "Share projects & custom GPTs"
        },
        featureIntegrations: {
            id: "pricing.teamOutcome.feature.integrations",
            defaultMessage: "Integrate with SharePoint & other tools"
        },
        featureBillingManagement: {
            id: "pricing.teamOutcome.feature.billingManagement",
            defaultMessage: "Simplify billing and user management"
        },
        featureMeetingTranscription: {
            id: "pricing.teamOutcome.feature.meetingTranscription",
            defaultMessage: "Capture meeting notes with transcription"
        },
        featureDeployAgents: {
            id: "pricing.teamOutcome.feature.deployAgents",
            defaultMessage: "Deploy agents to code and research"
        }
    }),
    P = e({
        planName: {
            id: "pricing.goRedesign.planName",
            defaultMessage: "Go"
        },
        headline: {
            id: "pricing.goRedesign.headline",
            defaultMessage: "More access to popular features"
        },
        cta: {
            id: "pricing.goRedesign.cta",
            defaultMessage: "Try Go"
        },
        featureAccessToGPT5: {
            id: "pricing.goRedesign.feature.accessToGpt5",
            defaultMessage: "Expanded access to GPT-5"
        },
        featureExpandedMessagesUploads: {
            id: "pricing.goRedesign.feature.expandedMessagesUploads",
            defaultMessage: "Expanded messaging and uploads"
        },
        featureExpandedImageCreation: {
            id: "pricing.goRedesign.feature.expandedImageCreation",
            defaultMessage: "Expanded image creation"
        },
        featureLimitedDeepResearch: {
            id: "pricing.goRedesign.feature.limitedDeepResearch",
            defaultMessage: "Limited deep research"
        },
        featureLongerMemoryContext: {
            id: "pricing.goRedesign.feature.longerMemoryContext",
            defaultMessage: "Longer memory and context"
        },
        featureExtendedADA: {
            id: "pricing.goRedesign.feature.extendedADA",
            defaultMessage: "Extended advanced data analysis"
        }
    }),
    Ie = () => [{
        label: se.freeBasicModelAccess,
        icon: R
    }, {
        label: f.featureLimitedMessagesUploads,
        icon: ae
    }, {
        label: f.featureLimitedImageGen,
        icon: te
    }, {
        label: f.featureLimitedMemoryContext,
        icon: U
    }, {
        label: f.featureLimitedDeepResearch,
        icon: Z
    }],
    Ge = () => [{
        label: P.featureAccessToGPT5,
        icon: R
    }, {
        label: P.featureExpandedMessagesUploads,
        icon: C
    }, {
        label: t.featureExpandedFasterImageCreation,
        icon: h
    }, {
        label: P.featureLongerMemoryContext,
        icon: y
    }, {
        label: P.featureLimitedDeepResearch,
        icon: Z
    }, {
        label: G.featureProjectsTasksCustomGPTs,
        icon: T
    }],
    Ue = () => [{
        label: x.cancelAnytime,
        icon: J
    }, {
        label: x.remindYouBeforeTrialEnds,
        icon: X
    }, {
        label: t.featureExpandedMessagesUploads,
        icon: C
    }, {
        label: t.featureMoreImageCreation,
        icon: h
    }, {
        label: t.featureExpandedDeepResearchAgentMode,
        icon: S
    }],
    Oe = () => [{
        label: t.featureAdvancedReasoning,
        icon: E
    }, {
        label: t.featureExpandedMessagesUploads,
        icon: C
    }, {
        label: t.featureExpandedFasterImageCreation,
        icon: h
    }, {
        label: t.featureExpandedMemoryContext,
        icon: y
    }, {
        label: t.featureExpandedDeepResearchAgentMode,
        icon: S
    }, {
        label: G.featureProjectsTasksCustomGPTs,
        icon: T
    }, {
        label: t.featureSoraVideoGeneration,
        icon: O
    }, {
        label: t.featureCodexAgent,
        icon: $
    }],
    we = () => [{
        label: n.featureMostPowerfulModels,
        icon: j
    }, {
        label: n.featureUnlimitedMessagesUploads,
        icon: N
    }, {
        label: n.featureUnlimitedFasterImageCreation,
        icon: k
    }, {
        label: n.featureMaximumMemoryContext,
        icon: W
    }, {
        label: n.featureMaximumDeepResearchAgentMode,
        icon: q
    }, {
        label: n.featureExpandedProjectsTasksCustomGPTs,
        icon: Y
    }, {
        label: n.featureExpandedSoraVideoGeneration,
        icon: z
    }, {
        label: n.featureExpandedCodexAgent,
        icon: H
    }, {
        label: n.featureResearchPreview,
        icon: Q
    }],
    Ve = () => [{
        label: M.featureSimpleExplanations,
        icon: R
    }, {
        label: M.featureShortChats,
        icon: ae
    }, {
        label: M.featureTryImageGeneration,
        icon: te
    }, {
        label: M.featureLimitedMemory,
        icon: U
    }],
    Le = () => [{
        label: l.featureDeepQuestions,
        icon: E
    }, {
        label: l.featureLongerChatsUploads,
        icon: C
    }, {
        label: l.featureRealisticImages,
        icon: h
    }, {
        label: l.featureSmarterReplies,
        icon: y
    }, {
        label: l.featurePlanningTasks,
        icon: S
    }, {
        label: l.featureProjectsTasksGPTs,
        icon: T
    }],
    De = () => [{
        label: d.featureSolveComplexProblems,
        icon: E
    }, {
        label: d.featureLongChats,
        icon: C
    }, {
        label: d.featureFasterImages,
        icon: h
    }, {
        label: d.featureRememberGoals,
        icon: y
    }, {
        label: d.featureAgentModePlanning,
        icon: S
    }, {
        label: d.featureOrganizeProjects,
        icon: T
    }, {
        label: d.featureSoraVideos,
        icon: O
    }, {
        label: d.featureCodexApps,
        icon: $
    }],
    Be = () => [{
        label: r.featureMasterAdvancedTasks,
        icon: j
    }, {
        label: r.featureUnlimitedMessages,
        icon: N
    }, {
        label: r.featureHighQualityImages,
        icon: k
    }, {
        label: r.featureMaximumMemory,
        icon: W
    }, {
        label: r.featureResearchAgents,
        icon: q
    }, {
        label: r.featureScaleProjects,
        icon: Y
    }, {
        label: r.featureSoraVideoCreation,
        icon: z
    }, {
        label: r.featureCodexDeploy,
        icon: H
    }, {
        label: r.featureEarlyAccess,
        icon: Q
    }],
    je = () => [{
        label: s.featureProfessionalAnalysis,
        icon: Ce
    }, {
        label: s.featureUnlimitedMessages,
        icon: ge
    }, {
        label: s.featureProduceMedia,
        icon: k
    }, {
        label: s.featureSecureWorkspace,
        icon: ee
    }, {
        label: s.featureProtectPrivacy,
        icon: he
    }, {
        label: s.featureShareProjects,
        icon: me
    }, {
        label: s.featureIntegrations,
        icon: F
    }, {
        label: s.featureBillingManagement,
        icon: K
    }, {
        label: s.featureMeetingTranscription,
        icon: pe
    }, {
        label: s.featureDeployAgents,
        icon: fe
    }],
    Ne = () => [{
        label: A.featureEverythingInFree,
        icon: w
    }, {
        label: A.featureGPT5Extended,
        icon: V
    }, {
        label: A.featureImgGenExtended,
        icon: L
    }, {
        label: A.featureFileUploadsExtended,
        icon: D
    }],
    We = () => [{
        label: b.featureSmarterFasterResponses,
        icon: w
    }, {
        label: b.featureMoreMessagesUploads,
        icon: V
    }, {
        label: b.featureFasterImages,
        icon: L
    }, {
        label: b.featureExpandedMemory,
        icon: D
    }],
    qe = () => [{
        label: v.featureUnlimitedBestModels,
        icon: B
    }, {
        label: v.featureUnlimitedAdvancedVoice,
        icon: Me
    }, {
        label: v.featureExpandedAgent,
        icon: le
    }, {
        label: v.featureMostImageVideo,
        icon: Pe
    }],
    Ye = () => [{
        label: x.cancelAnytime,
        icon: J
    }, {
        label: x.remindYouBeforeTrialEnds,
        icon: X
    }, {
        label: u.featureAdvancedSecurity,
        icon: ee
    }, {
        label: u.featureUnifiedBilling,
        icon: K
    }, {
        label: u.featureConnectExternalSources,
        icon: F
    }],
    ze = () => [{
        label: u.featureUnlimitedBestModel,
        icon: B
    }, {
        label: u.featureAdvancedSecurity,
        icon: ue
    }, {
        label: u.featureTeamTools,
        icon: ce
    }, {
        label: u.featureIntegrations,
        icon: F
    }],
    He = {
        go: g(c({}, Ae), {
            goName: m.go
        }),
        free: g(c({}, se), {
            freeName: m.free
        }),
        plus: g(c({}, be), {
            plusName: m.plus
        }),
        team: g(c({}, ve), {
            teamPlanName: m.team
        }),
        pro: g(c({}, xe), {
            proName: m.pro
        }),
        freeOutcome: M,
        goOutcome: l,
        plusOutcome: d,
        proOutcome: r,
        teamOutcome: s,
        goRedesign: P,
        freeRedesign: f,
        plusRedesign: t,
        proRedesign: n,
        teamRedesign: ye
    };
export {
    We as a, De as b, Ue as c, qe as d, Be as e, we as f, Oe as g, Ne as h, Le as i, Ge as j, Ye as k, ze as l, je as m, Ve as n, Ie as o, He as p, n as q, t as r, _e as s, be as t
};
//# sourceMappingURL=by32wbrf3h6krwuu.js.map