var F = Object.defineProperty,
    K = Object.defineProperties;
var J = Object.getOwnPropertyDescriptors;
var b = Object.getOwnPropertySymbols;
var W = Object.prototype.hasOwnProperty,
    _ = Object.prototype.propertyIsEnumerable;
var A = (l, t, e) => t in l ? F(l, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : l[t] = e,
    k = (l, t) => {
        for (var e in t || (t = {})) W.call(t, e) && A(l, e, t[e]);
        if (b)
            for (var e of b(t)) _.call(t, e) && A(l, e, t[e]);
        return l
    },
    L = (l, t) => K(l, J(t));
import {
    wI as G,
    wJ as Q,
    wK as R,
    wL as P,
    iZ as X,
    rT as p,
    rS as w,
    wM as v,
    wN as Z,
    wO as B,
    wP as $,
    wQ as j,
    wR as T
} from "./dykg4ktvbu3mhmdo.js";
import {
    N as x
} from "./f76gy0b8ieo4s693.js";
class q extends x {
    unistNodeName() {
        return "text"
    }
    static proseMirrorNodeName() {
        return "text"
    }
    proseMirrorNodeSpec() {
        return {
            group: "inline"
        }
    }
    unistNodeToProseMirrorNodes({
        node: t,
        schema: e,
        attrs: n
    }) {
        return G(t, e, n)
    }
    proseMirrorNodeToUnistNodes(t) {
        var e;
        return [{
            type: this.unistNodeName(),
            value: (e = t.text) != null ? e : ""
        }]
    }
}
class m {
    constructor(t, e, n = {}) {
        this.match = t, this.match = t, this.handler = typeof e == "string" ? E(e) : e, this.undoable = n.undoable !== !1, this.inCode = n.inCode || !1
    }
}

function E(l) {
    return function(t, e, n, r) {
        let o = l;
        if (e[1]) {
            let s = e[0].lastIndexOf(e[1]);
            o += e[0].slice(s + e[1].length), n += s;
            let i = n - r;
            i > 0 && (o = e[0].slice(s - i, s) + o, n = r)
        }
        return t.tr.insertText(o, n, r)
    }
}
const Y = 500;

function ce({
    rules: l
}) {
    let t = new Q({
        state: {
            init() {
                return null
            },
            apply(e, n) {
                let r = e.getMeta(this);
                return r || (e.selectionSet || e.docChanged ? null : n)
            }
        },
        props: {
            handleTextInput(e, n, r, o) {
                return O(e, n, r, o, l, t)
            },
            handleDOMEvents: {
                compositionend: e => {
                    setTimeout(() => {
                        let {
                            $cursor: n
                        } = e.state.selection;
                        n && O(e, n.pos, n.pos, "", l, t)
                    })
                }
            }
        },
        isInputRules: !0
    });
    return t
}

function O(l, t, e, n, r, o) {
    if (l.composing) return !1;
    let s = l.state,
        i = s.doc.resolve(t),
        a = i.parent.textBetween(Math.max(0, i.parentOffset - Y), i.parentOffset, null, "￼") + n;
    for (let u = 0; u < r.length; u++) {
        let d = r[u];
        if (i.parent.type.spec.code) {
            if (!d.inCode) continue
        } else if (d.inCode === "only") continue;
        let f = d.match.exec(a),
            c = f && d.handler(s, f, t - (f[0].length - n.length), e);
        if (c) return d.undoable && c.setMeta(o, {
            transform: c,
            from: t,
            to: e,
            text: n
        }), l.dispatch(c), !0
    }
    return !1
}
new m(/--$/, "—");
new m(/\.\.\.$/, "…");
new m(/(?:^|[\s\{\[\(\<'"\u2018\u201C])(")$/, "“");
new m(/"$/, "”");
new m(/(?:^|[\s\{\[\(\<'"\u2018\u201C])(')$/, "‘");
new m(/'$/, "’");

function pe(l, t, e = null, n) {
    return new m(l, (r, o, s, i) => {
        let a = e instanceof Function ? e(o) : e,
            u = r.tr.delete(s, i),
            d = u.doc.resolve(s),
            f = d.blockRange(),
            c = f && R(f, t, a);
        if (!c) return null;
        u.wrap(f, c);
        let h = u.doc.resolve(s - 1).nodeBefore;
        return h && h.type == t && P(u.doc, s - 1) && (!n || n(o, h)) && u.join(s - 1), u
    })
}

function H(l, t, e = null) {
    return new m(l, (n, r, o, s) => {
        let i = n.doc.resolve(o),
            a = e instanceof Function ? e(r) : e;
        return i.node(-1).canReplaceWith(i.index(-1), i.indexAfter(-1), t) ? n.tr.delete(o, s).setBlockType(o, o, t, a) : null
    })
}

function S(l, t, e, n = {}) {
    if (l == null) return null;
    const r = (Array.isArray(e) ? e : [e]).filter(X),
        o = t.nodes[l].createAndFill(n, r);
    return o == null ? null : o
}

function he(l, t = null) {
    return function(e, n) {
        let {
            $from: r,
            $to: o
        } = e.selection, s = r.blockRange(o), i = !1, a = s;
        if (!s) return !1;
        if (s.depth >= 2 && r.node(s.depth - 1).type.compatibleContent(l) && s.startIndex == 0) {
            if (r.index(s.depth - 1) == 0) return !1;
            let d = e.doc.resolve(s.start - 2);
            a = new $(d, d, s.depth), s.endIndex < s.parent.childCount && (s = new $(r, e.doc.resolve(o.end(s.depth)), s.depth)), i = !0
        }
        let u = R(a, l, t, s);
        return u ? (n && n(ee(e.tr, s, u, i, l).scrollIntoView()), !0) : !1
    }
}

function ee(l, t, e, n, r) {
    let o = p.empty;
    for (let d = e.length - 1; d >= 0; d--) o = p.from(e[d].type.create(e[d].attrs, o));
    l.step(new v(t.start - (n ? 2 : 0), t.end, t.start, t.end, new w(o, 0, 0), e.length, !0));
    let s = 0;
    for (let d = 0; d < e.length; d++) e[d].type == r && (s = d + 1);
    let i = e.length - s,
        a = t.start + e.length - (n ? 2 : 0),
        u = t.parent;
    for (let d = t.startIndex, f = t.endIndex, c = !0; d < f; d++, c = !1) !c && B(l.doc, a, i) && (l.split(a, i), a += 2 * i), a += u.child(d).nodeSize;
    return l
}

function te(l, t) {
    return function(e, n) {
        let {
            $from: r,
            $to: o,
            node: s
        } = e.selection;
        if (s && s.isBlock || r.depth < 2 || !r.sameParent(o)) return !1;
        let i = r.node(-1);
        if (i.type != l) return !1;
        if (r.parent.content.size == 0 && r.node(-1).childCount == r.indexAfter(-1)) {
            if (r.depth == 3 || r.node(-3).type != l || r.index(-2) != r.node(-2).childCount - 1) return !1;
            if (n) {
                let f = p.empty,
                    c = r.index(-1) ? 1 : r.index(-2) ? 2 : 3;
                for (let g = r.depth - c; g >= r.depth - 3; g--) f = p.from(r.node(g).copy(f));
                let h = r.indexAfter(-1) < r.node(-2).childCount ? 1 : r.indexAfter(-2) < r.node(-3).childCount ? 2 : 3;
                f = f.append(p.from(l.createAndFill()));
                let M = r.before(r.depth - (c - 1)),
                    y = e.tr.replace(M, r.after(-h), new w(f, 4 - c, 0)),
                    C = -1;
                y.doc.nodesBetween(M, y.doc.content.size, (g, V) => {
                    if (C > -1) return !1;
                    g.isTextblock && g.content.size == 0 && (C = V + 1)
                }), C > -1 && y.setSelection(Z.near(y.doc.resolve(C))), n(y.scrollIntoView())
            }
            return !0
        }
        let a = o.pos == r.end() ? i.contentMatchAt(0).defaultType : null,
            u = e.tr.delete(r.pos, o.pos),
            d = a ? [null, {
                type: a
            }] : void 0;
        return B(u.doc, r.pos, 2, d) ? (n && n(u.split(r.pos, 2, d).scrollIntoView()), !0) : !1
    }
}

function D(l) {
    return function(t, e) {
        let {
            $from: n,
            $to: r
        } = t.selection, o = n.blockRange(r, s => s.childCount > 0 && s.firstChild.type == l);
        return o ? e ? n.node(o.depth - 1).type == l ? re(t, e, l, o) : ne(t, e, o) : !0 : !1
    }
}

function re(l, t, e, n) {
    let r = l.tr,
        o = n.end,
        s = n.$to.end(n.depth);
    o < s && (r.step(new v(o - 1, s, o, s, new w(p.from(e.create(null, n.parent.copy())), 1, 0), 1, !0)), n = new $(r.doc.resolve(n.$from.pos), r.doc.resolve(s), n.depth));
    const i = j(n);
    if (i == null) return !1;
    r.lift(n, i);
    let a = r.mapping.map(o, -1) - 1;
    return P(r.doc, a) && r.join(a), t(r.scrollIntoView()), !0
}

function ne(l, t, e) {
    let n = l.tr,
        r = e.parent;
    for (let h = e.end, M = e.endIndex - 1, y = e.startIndex; M > y; M--) h -= r.child(M).nodeSize, n.delete(h - 1, h + 1);
    let o = n.doc.resolve(e.start),
        s = o.nodeAfter;
    if (n.mapping.map(e.end) != e.start + o.nodeAfter.nodeSize) return !1;
    let i = e.startIndex == 0,
        a = e.endIndex == r.childCount,
        u = o.node(-1),
        d = o.index(-1);
    if (!u.canReplace(d + (i ? 0 : 1), d + 1, s.content.append(a ? p.empty : p.from(r)))) return !1;
    let f = o.pos,
        c = f + s.nodeSize;
    return n.step(new v(f - (i ? 1 : 0), c + (a ? 1 : 0), f + 1, c - 1, new w((i ? p.empty : p.from(r.copy(p.empty))).append(a ? p.empty : p.from(r.copy(p.empty))), i ? 0 : 1, a ? 0 : 1), i ? 0 : 1)), t(n.scrollIntoView()), !0
}

function oe(l) {
    return function(t, e) {
        let {
            $from: n,
            $to: r
        } = t.selection, o = n.blockRange(r, u => u.childCount > 0 && u.firstChild.type == l);
        if (!o) return !1;
        let s = o.startIndex;
        if (s == 0) return !1;
        let i = o.parent,
            a = i.child(s - 1);
        if (a.type != l) return !1;
        if (e) {
            let u = a.lastChild && a.lastChild.type == i.type,
                d = p.from(u ? l.create() : null),
                f = new w(p.from(l.create(null, p.from(i.type.create(null, d)))), u ? 3 : 1, 0),
                c = o.start,
                h = o.end;
            e(t.tr.step(new v(c - (u ? 3 : 1), h, c, h, f, 1, !0)).scrollIntoView())
        }
        return !0
    }
}
class le extends x {
    unistNodeName() {
        return "listItem"
    }
    static proseMirrorNodeName() {
        return "regular_list_item"
    }
    proseMirrorNodeSpec() {
        return {
            content: "paragraph block*",
            defining: !0,
            group: "list_item",
            parseDOM: [{
                tag: "li"
            }],
            toDOM() {
                return ["li", 0]
            }
        }
    }
    unistToProseMirrorTest(t) {
        return t.type === this.unistNodeName() && (!("checked" in t) || typeof t.checked != "boolean")
    }
    proseMirrorKeymap(t) {
        const e = t.nodes[this.proseMirrorNodeName()];
        return {
            Enter: te(e),
            "Shift-Tab": D(e),
            Tab: oe(e)
        }
    }
    unistNodeToProseMirrorNodes({
        schema: t,
        convertedChildren: e,
        attrs: n
    }) {
        return S(this.proseMirrorNodeName(), t, e, n)
    }
    proseMirrorNodeToUnistNodes(t, e) {
        return [{
            type: this.unistNodeName(),
            children: e
        }]
    }
}
const z = (l, t) => {
        const e = t.filter(Boolean);
        if (e.length === 0) return !1;
        const {
            $from: n
        } = l.selection, r = new Set(e);
        for (let o = n.depth; o >= 0; o--)
            if (r.has(n.node(o).type)) return !0;
        return !1
    },
    U = (l, t, e, n = []) => {
        if (!e) return !0;
        const r = se(n);
        if (r.length === 0) return !0;
        for (; z(l(), r);)
            if (!D(e)(l(), t)) return !1;
        return !0
    },
    Ne = (l, t, e) => !e || z(l(), [e]) ? !0 : T(e)(l(), t),
    se = l => l.filter(Boolean),
    ie = {
        content: "inline*",
        group: "block",
        parseDOM: [{
            tag: "p"
        }],
        toDOM() {
            return ["p", 0]
        }
    },
    de = "paragraph";
class I extends x {
    static paragraphStyleCommand(t) {
        return (e, n) => {
            const r = t.nodes[I.proseMirrorNodeName()],
                o = t.nodes.ordered_list,
                s = t.nodes.list,
                i = t.nodes[le.proseMirrorNodeName()];
            if (!r) return !1;
            let a = e;
            const u = () => a,
                d = f => {
                    a = a.apply(f), n && n(f)
                };
            return U(u, d, i, [o, s]) ? T(r)(u(), d) : !1
        }
    }
    unistNodeName() {
        return de
    }
    static proseMirrorNodeName() {
        return "paragraph"
    }
    proseMirrorNodeSpec() {
        return ie
    }
    proseMirrorKeymap(t) {
        return {
            "Alt-Mod-0": I.paragraphStyleCommand(t)
        }
    }
    unistNodeToProseMirrorNodes({
        schema: t,
        convertedChildren: e,
        attrs: n
    }) {
        return S(this.proseMirrorNodeName(), t, e, n)
    }
    proseMirrorNodeToUnistNodes(t, e) {
        return [{
            type: this.unistNodeName(),
            children: e
        }]
    }
}
class N extends x {
    static isAtStart(t, e) {
        return t.selection.empty ? e !== void 0 ? e.endOfTextblock("backward", t) : t.selection.$anchor.parentOffset > 0 : !1
    }
    static headingLevelCommandBuilder(t, e, n) {
        return (r, o, s) => {
            if (n && !N.isAtStart(r, s)) return !1;
            const {
                $anchor: i
            } = r.selection, a = i.parent;
            if (a.type.name !== "heading") return !1;
            const u = a.attrs.level + e;
            if (u < 0 || u > 6) return !1;
            if (o === void 0) return !0;
            const d = i.before(i.depth);
            return u > 0 ? o(r.tr.setNodeMarkup(d, void 0, {
                level: u
            })) : o(r.tr.setNodeMarkup(d, t.nodes.paragraph)), !0
        }
    }
    static headingStyleCommand(t, e) {
        return (n, r) => {
            const o = t.nodes[this.proseMirrorNodeName()];
            if (!o) return !1;
            const s = t.nodes.ordered_list,
                i = t.nodes.list,
                a = t.nodes.regular_list_item;
            let u = n;
            const d = () => u,
                f = c => {
                    u = u.apply(c), r && r(c)
                };
            return U(d, f, a, [s, i]) ? T(o, {
                level: e
            })(d(), f) : !1
        }
    }
    dependencies() {
        return [new I, new q]
    }
    unistNodeName() {
        return "heading"
    }
    static proseMirrorNodeName() {
        return "heading"
    }
    proseMirrorNodeSpec() {
        return {
            attrs: {
                level: {
                    default: 1
                }
            },
            content: "text*",
            group: "block",
            defining: !0,
            parseDOM: [{
                tag: "h1",
                attrs: {
                    level: 1
                }
            }, {
                tag: "h2",
                attrs: {
                    level: 2
                }
            }, {
                tag: "h3",
                attrs: {
                    level: 3
                }
            }, {
                tag: "h4",
                attrs: {
                    level: 4
                }
            }, {
                tag: "h5",
                attrs: {
                    level: 5
                }
            }, {
                tag: "h6",
                attrs: {
                    level: 6
                }
            }],
            toDOM(t) {
                return ["h" + t.attrs.level.toString(), 0]
            }
        }
    }
    proseMirrorInputRules(t) {
        return [H(/^\s{0,3}(#{1,6})\s$/, t.nodes[this.proseMirrorNodeName()], e => ({
            level: e[1].length
        }))]
    }
    proseMirrorKeymap(t) {
        const e = t.nodes[this.proseMirrorNodeName()],
            n = {
                Tab: N.headingLevelCommandBuilder(t, 1, !1),
                "#": N.headingLevelCommandBuilder(t, 1, !0),
                "Shift-Tab": N.headingLevelCommandBuilder(t, -1, !1),
                "Shift-Mod-1": N.headingStyleCommand(t, 1),
                "Shift-Mod-2": N.headingStyleCommand(t, 2),
                "Shift-Mod-3": N.headingStyleCommand(t, 3),
                "Alt-Mod-1": N.headingStyleCommand(t, 1),
                "Alt-Mod-2": N.headingStyleCommand(t, 2),
                "Alt-Mod-3": N.headingStyleCommand(t, 3)
            };
        for (let r = 1; r <= 6; r++) n["Shift-Mod-".concat(r.toString())] = T(e, {
            level: r
        });
        return n
    }
    unistNodeToProseMirrorNodes({
        node: t,
        schema: e,
        convertedChildren: n,
        attrs: r
    }) {
        const {
            depth: o
        } = t;
        return S(this.proseMirrorNodeName(), e, n, L(k({}, r), {
            level: o
        }))
    }
    proseMirrorNodeToUnistNodes(t, e) {
        return [{
            type: this.unistNodeName(),
            depth: t.attrs.level,
            children: e
        }]
    }
}
class me extends x {
    unistNodeName() {
        return "root"
    }
    static proseMirrorNodeName() {
        return "doc"
    }
    proseMirrorNodeSpec() {
        return {
            content: "block+"
        }
    }
    unistNodeToProseMirrorNodes({
        schema: t,
        convertedChildren: e,
        attrs: n
    }) {
        return S(this.proseMirrorNodeName(), t, e, n)
    }
    proseMirrorNodeToUnistNodes(t, e) {
        return [{
            type: this.unistNodeName(),
            children: e
        }]
    }
}
export {
    N as H, m as I, le as L, I as P, me as R, q as T, ie as a, de as b, S as c, he as d, Ne as e, D as f, ce as i, U as l, z as s, H as t, pe as w
};
//# sourceMappingURL=eafv7vq0yf9bv0fi.js.map