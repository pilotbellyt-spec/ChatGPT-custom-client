import {
    eC as o
} from "./k15yxxoybkkir2ou.js";
import {
    C as t
} from "./ftef8970ba1zoykr.js";
var n = (e => (e.IgnoredMicrophonePrompt = "userIgnoredMicrophonePrompt", e.DeniedMicrophonePrompt = "userDeniedMicrophonePrompt", e.LimitReached = "limitReached", e.UserAbort = "userAbort", e.UserRequest = "userRequest", e.NetworkDisconnected = "networkDisconnected", e.UserNavigatedAway = "userNavigatedAway", e.UserSwitchedToStandard = "userSwitchedToStandard", e.Failed = "failed", e.ElectronAppMinimized = "electron-app-minimized", e))(n || {});

function p({
    voiceStore: e,
    reason: r
}) {
    const {
        voiceMode: i
    } = e.getState();
    return i || (r === "userIgnoredMicrophonePrompt" || r === "userDeniedMicrophonePrompt" ? "no-microphone" : "unknown")
}
async function s({
    isLimitExceeded: e,
    connectionState: r
}) {
    const i = await o();
    return i === "prompt" ? "userIgnoredMicrophonePrompt" : i === "denied" ? "userDeniedMicrophonePrompt" : e ? "limitReached" : r == null || r === t.Connecting || r === t.Reconnecting || r === t.SignalReconnecting ? "userAbort" : r === t.Connected ? "userRequest" : "networkDisconnected"
}
export {
    n as D, s as a, p as g
};
//# sourceMappingURL=cu0e6szsqsyduwov.js.map