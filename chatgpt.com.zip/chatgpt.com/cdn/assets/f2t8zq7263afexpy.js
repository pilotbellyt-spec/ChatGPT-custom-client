const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/n9j7fjwo21ago9aa.js", "assets/fg33krlcm0qyi6yw.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/jzcvgi3ud281qm7h.js", "assets/ef7gr7kimbtxrws9.js", "assets/ktlrbeajo849nxci.js", "assets/k15yxxoybkkir2ou.js", "assets/conversation-small-332fs9rk.css", "assets/kl7c6054usfnqmd4.js", "assets/ns51nblw8ziscsgd.js", "assets/hy7ook5wufdcl2wy.js", "assets/bx8o5u3qhj3ykfih.js", "assets/gry8j32h87k624fm.js", "assets/jo3nkzo78m31wkxo.js", "assets/bxjmpsz2dryfouus.js", "assets/o589vqy9dgmjuag5.js", "assets/ce3hgmw4iyyhicud.js", "assets/mstl8wgfzorpgdoe.js", "assets/f2sn8zvpzei2915e.js", "assets/kfdkis1zwf4ccfgg.js", "assets/ol9d5wxhynx9q2is.js", "assets/mbmcx8v24u1ao1ke.js", "assets/ieglwgr2zyuektzv.js", "assets/coi95al0vrqe13ds.js", "assets/l09h2qppleubii6l.js", "assets/deakbbf27g8e7ba0.js", "assets/kwqlokvhsdnnmw9d.js", "assets/jsd0vs4cv2vks3ah.js", "assets/k97n0y6ba9c9h39c.js", "assets/kz8g43osloy7fyhi.js", "assets/jjqluv6nhf16nnr9.js", "assets/iwhq2rihp0137gzf.js", "assets/h1j5sazq8s0md41z.js", "assets/f76gy0b8ieo4s693.js", "assets/ovpdmx71kjznjdh8.js", "assets/nh559o9htk2jfyt0.js", "assets/nf79rzyd6jobmpxe.js", "assets/kyjerv6rln8oin0o.js", "assets/iv26jzbt1vvl49kt.js", "assets/eo73z75xc7fd61fn.js", "assets/b2l059fz4znz94nm.js", "assets/hzx735z33xljaym3.js", "assets/loeoawlgsw5vcwar.js", "assets/m77bejnre58pj934.js", "assets/jc2eye6u0uwos0uk.js", "assets/aozfqr1i52mjkof3.js", "assets/eaak105t3h6pgvs1.js", "assets/i5kvudettvxsr7pw.js", "assets/hz9475nc5ndyfqsu.js", "assets/ou2xm3xmri21t4zm.js", "assets/irqko7c1s7qpl41n.js", "assets/e1qtg70ehhxpvvw9.js", "assets/l13qvsuc1mktoblg.js", "assets/jlu292yvnhcpthaw.js", "assets/k2oaaf8ac9lafsub.js", "assets/lans8a2ikbh9ax9r.js", "assets/f78b2oufkmgyeo1t.js", "assets/ew68kf01y1h7e4uk.js", "assets/ib78f9d5brp6znzf.js", "assets/njpaiih217owxm7n.js", "assets/bj1ejin6tzi0v3v8.js", "assets/oped93nrvnxd635x.js", "assets/gb3g89r4fqk97sov.js", "assets/mzj1f1z14g1kybwx.js", "assets/nzjsohh941f1fuvy.js", "assets/fyk9tph6baj60t7u.js", "assets/jzwivbl10of3y0cy.js", "assets/gnem48tlfbbnt1lb.js", "assets/h3mm4dcmy7evm6n4.js", "assets/brbv8u56dvmb3wbc.js", "assets/u9jpwxvw30u3h6nc.js", "assets/kx34yg3blv92o8xp.js", "assets/map-with-entities-ejapwmw2.css"]))) => i.map(i => d[i]);
import {
    _ as D,
    c as ie,
    n as re,
    l as oe,
    j as s,
    i as le,
    m as ne
} from "./fg33krlcm0qyi6yw.js";
import {
    N as ce,
    C as de,
    S as me
} from "./cw1lyo20zi7916n8.js";
import {
    bu as he,
    bv as fe,
    bw as ue,
    bx as be,
    by as G,
    bz as _e,
    bA as ge,
    bB as ve,
    bC as xe,
    bD as Se,
    bE as pe,
    bF as Ce,
    bG as je,
    bH as ye,
    bI as Te,
    bJ as Ae,
    bK as Ie,
    bL as Pe,
    a9 as Ee,
    bM as Me
} from "./k15yxxoybkkir2ou.js";
import {
    bh as L,
    d as J,
    dz as Fe,
    c_ as Ne,
    o as Ve,
    e as we,
    r9 as Oe,
    mv as Re,
    j as De,
    hg as ae,
    qx as Le,
    b as He,
    hh as We
} from "./dykg4ktvbu3mhmdo.js";
import {
    a as $e
} from "./f78b2oufkmgyeo1t.js";
import {
    C as Be
} from "./pau1yzg54moerxhg.js";
import {
    T as ke
} from "./iw47v9tf328v3kli.js";
import {
    T as ze
} from "./mstnrsa4h2hq1kxz.js";
import {
    ThreadModal as Ke
} from "./b6zf7y7f0igpluq0.js";
const Ue = L(() => D(() =>
        import ("./n9j7fjwo21ago9aa.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10])).then(a => a.EcosystemAppSidebar)),
    qe = L(() => D(() =>
        import ("./hy7ook5wufdcl2wy.js"), __vite__mapDeps([11, 1, 2, 3, 12, 7, 8, 13])).then(a => a.DevModeSidebar)),
    Ge = L(() => D(() =>
        import ("./jo3nkzo78m31wkxo.js"), __vite__mapDeps([14, 1, 2, 3, 7, 8, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 9, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 10, 41, 42, 12, 6, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61])).then(a => a.CanvasFocusedViewManager)),
    Je = L(() => D(() =>
        import ("./oped93nrvnxd635x.js"), __vite__mapDeps([62, 1, 7, 2, 3, 8, 63])).then(a => a.VNCFocusedViewManager)),
    Qe = L(() => D(() =>
        import ("./mzj1f1z14g1kybwx.js"), __vite__mapDeps([64, 1, 2, 3, 65, 7, 8, 66, 9, 67])).then(a => a.WalnutFocusedViewManager));
L(() => D(() =>
    import ("./gnem48tlfbbnt1lb.js"), __vite__mapDeps([68, 1, 2, 3, 69, 70, 7, 8, 71, 72, 73])).then(a => a.PlacesOverlay));

function lt(a) {
    "use forget";
    const e = ie.c(81),
        {
            conversation: t,
            urlThreadId: i,
            threadHeader: o,
            forceHideNavigation: H,
            children: l
        } = a;
    let n;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (n = we(), e[0] = n) : n = e[0];
    const h = n,
        [u] = re();
    let c;
    e[1] !== t ? (c = () => !!ge(t).currentMessageId$(), e[1] = t, e[2] = c) : c = e[2];
    const r = J(c);
    let d;
    e[3] === Symbol.for("react.memo_cache_sentinel") ? (d = () => Oe(h), e[3] = d) : d = e[3];
    const Q = J(d);
    let f;
    e[4] === Symbol.for("react.memo_cache_sentinel") ? (f = Fe(), e[4] = f) : f = e[4];
    const b = f;
    let m;
    e[5] !== t ? (m = () => Re() && ve(t).hasPinnedWidget$(), e[5] = t, e[6] = m) : m = e[6];
    const W = J(m),
        X = he(),
        _ = !!H || Q || W;
    let $;
    e[7] !== _ ? ($ = Ne() && !_, e[7] = _, e[8] = $) : $ = e[8];
    const Y = $,
        Z = oe();
    let B;
    e[9] !== Z ? (B = fe(Z, "library"), e[9] = Z, e[10] = B) : B = e[10];
    const ee = B;
    let te;
    e[11] === Symbol.for("react.memo_cache_sentinel") ? (te = Ve(h, "3127600850"), e[11] = te) : te = e[11];
    let k;
    e[12] === Symbol.for("react.memo_cache_sentinel") ? (k = () => De(h), e[12] = k) : k = e[12];
    const se = J(k);
    let g;
    e[13] !== t.id ? (g = b && s.jsx(ue, {
        clientThreadId: t.id
    }), e[13] = t.id, e[14] = g) : g = e[14];
    let v;
    e[15] !== t.id || e[16] !== u ? (v = s.jsx(Xe, {
        clientThreadId: t.id,
        searchParams: u
    }), e[15] = t.id, e[16] = u, e[17] = v) : v = e[17];
    let x;
    e[18] !== t.id || e[19] !== i ? (x = s.jsx(be, {
        clientThreadId: t.id,
        urlThreadId: i
    }), e[18] = t.id, e[19] = i, e[20] = x) : x = e[20];
    let S;
    e[21] !== t.id || e[22] !== Y ? (S = Y && s.jsx(G.Navbar, {
        children: s.jsx($e, {
            children: s.jsx(ce, {
                navHeader: s.jsx(me, {}),
                children: s.jsx(de, {
                    clientThreadId: t.id
                })
            })
        })
    }), e[21] = t.id, e[22] = Y, e[23] = S) : S = e[23];
    let p;
    e[24] !== _ ? (p = !_ && s.jsx(ae, {
        children: s.jsx(xe, {})
    }), e[24] = _, e[25] = p) : p = e[25];
    let C;
    e[26] !== t || e[27] !== X || e[28] !== se || e[29] !== ee || e[30] !== o ? (C = o != null ? o : ee || X || se ? s.jsx(s.Fragment, {}) : s.jsx(ze, {
        conversation: t
    }, t.id), e[26] = t, e[27] = X, e[28] = se, e[29] = ee, e[30] = o, e[31] = C) : C = e[31];
    let j;
    e[32] !== p || e[33] !== C ? (j = s.jsxs(G.Header, {
        children: [p, C]
    }), e[32] = p, e[33] = C, e[34] = j) : j = e[34];
    let z;
    e[35] === Symbol.for("react.memo_cache_sentinel") ? (z = s.jsx(Se, {}), e[35] = z) : z = e[35];
    let y;
    e[36] !== l || e[37] !== t ? (y = l != null ? l : s.jsx(ke, {
        conversation: t
    }, t.id), e[36] = l, e[37] = t, e[38] = y) : y = e[38];
    let T;
    e[39] !== t || e[40] !== r ? (T = r && !1, e[39] = t, e[40] = r, e[41] = T) : T = e[41];
    let A;
    e[42] !== t ? (A = s.jsx(Ue, {
        conversation: t
    }), e[42] = t, e[43] = A) : A = e[43];
    let I;
    e[44] !== t ? (I = s.jsx(ae, {
        children: s.jsx(Be, {
            conversation: t
        })
    }), e[44] = t, e[45] = I) : I = e[45];
    let P, E;
    e[46] !== t.id ? (P = s.jsx(Ge, {
        clientThreadId: t.id
    }), E = s.jsx(qe, {
        clientThreadId: t.id
    }), e[46] = t.id, e[47] = P, e[48] = E) : (P = e[47], E = e[48]);
    let K;
    e[49] === Symbol.for("react.memo_cache_sentinel") ? (K = !1, e[49] = K) : K = e[49];
    let M, F;
    e[50] !== t.id ? (M = s.jsx(Je, {
        clientThreadId: t.id
    }), F = s.jsx(Qe, {
        clientThreadId: t.id
    }), e[50] = t.id, e[51] = M, e[52] = F) : (M = e[51], F = e[52]);
    let N;
    e[53] !== A || e[54] !== I || e[55] !== P || e[56] !== E || e[57] !== M || e[58] !== F ? (N = s.jsxs(G.ContentSidebar, {
        children: [A, I, P, E, K, M, F]
    }), e[53] = A, e[54] = I, e[55] = P, e[56] = E, e[57] = M, e[58] = F, e[59] = N) : N = e[59];
    let V;
    e[60] !== S || e[61] !== j || e[62] !== y || e[63] !== T || e[64] !== N ? (V = s.jsxs(G, {
        children: [S, j, z, y, T, N]
    }), e[60] = S, e[61] = j, e[62] = y, e[63] = T, e[64] = N, e[65] = V) : V = e[65];
    let w;
    e[66] !== t || e[67] !== V ? (w = s.jsx(Le, {
        conversation: t,
        children: V
    }), e[66] = t, e[67] = V, e[68] = w) : w = e[68];
    let O;
    e[69] !== t ? (O = s.jsx(Ke, {
        conversation: t
    }), e[69] = t, e[70] = O) : O = e[70];
    let R;
    e[71] !== t.id ? (R = s.jsx(_e, {
        conversationId: t.id
    }), e[71] = t.id, e[72] = R) : R = e[72];
    let U;
    e[73] === Symbol.for("react.memo_cache_sentinel") ? (U = !1, e[73] = U) : U = e[73];
    let q;
    return e[74] !== g || e[75] !== v || e[76] !== x || e[77] !== w || e[78] !== O || e[79] !== R ? (q = s.jsxs(s.Fragment, {
        children: [g, v, x, w, O, R, U]
    }), e[74] = g, e[75] = v, e[76] = x, e[77] = w, e[78] = O, e[79] = R, e[80] = q) : q = e[80], q
}

function Xe(a) {
    "use forget";
    const e = ie.c(18),
        {
            clientThreadId: t,
            searchParams: i
        } = a,
        o = He(),
        H = le(),
        l = ne();
    let n;
    e[0] !== i ? (n = i.has("messageId"), e[0] = i, e[1] = n) : n = e[1], pe(t, !n);
    let h;
    e[2] !== i ? (h = i.get("messageId"), e[2] = i, e[3] = h) : h = e[3];
    const u = h;
    let c;
    e[4] !== t || e[5] !== u ? (c = {
        clientThreadId: t,
        messageId: u
    }, e[4] = t, e[5] = u, e[6] = c) : c = e[6], Ce(c);
    let r;
    e[7] !== o || e[8] !== l || e[9] !== H ? (r = W => {
        Ee(o, W, {
            location: "Keyboard command"
        }), W.defaultPrevented || Me(H, {
            replace: l.pathname === "/"
        })
    }, e[7] = o, e[8] = l, e[9] = H, e[10] = r) : r = e[10];
    let d;
    e[11] !== t || e[12] !== r ? (d = {
        newChatAction: r,
        clientThreadId: t
    }, e[11] = t, e[12] = r, e[13] = d) : d = e[13], je(d);
    const Q = We(t),
        f = ye(Q);
    Te(), Ae(t), Ie();
    let b;
    e[14] !== t ? (b = {
        clientThreadId: t
    }, e[14] = t, e[15] = b) : b = e[15], Pe(b);
    let m;
    return e[16] !== f ? (m = s.jsx(s.Fragment, {
        children: f
    }), e[16] = f, e[17] = m) : m = e[17], m
}
export {
    lt as C, Xe as a
};
//# sourceMappingURL=f2t8zq7263afexpy.js.map