const s = "/cdn/assets/team-upsell-mjqpjoww.webp",
    e = {
        src: s
    };
export {
    e as T
};
//# sourceMappingURL=h370k1wse4qy92bx.js.map