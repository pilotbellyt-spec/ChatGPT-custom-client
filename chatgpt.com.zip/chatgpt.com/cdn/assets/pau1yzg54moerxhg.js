const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/cbu1fjafb968gwfi.js", "assets/fg33krlcm0qyi6yw.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/k15yxxoybkkir2ou.js", "assets/conversation-small-332fs9rk.css", "assets/oxzaatrh4u5nlvw7.js", "assets/bz18jski55ynqbl1.js", "assets/bcsv6m4oh341rml5.js", "assets/lqog7ixiwnif6sbp.js", "assets/nzl91iujqafxz8y1.js", "assets/ebc4iyfg14nu1gw4.js", "assets/gy1lpvuoewmzh42c.js", "assets/jed1ux7qibe55pmj.js", "assets/h1em0bjkpkjv8ykw.js", "assets/nfccle6oyncifphl.js", "assets/hu1bt0oauegdhua6.js", "assets/b5s349mvbdzayaxi.js", "assets/dbshkzvpochy4889.js", "assets/zdzro29lk5w2w085.js", "assets/gjyisy9q1t8rz8p4.js", "assets/djfxxaryk37v3pj1.js", "assets/dcboyjh87ll7k264.js", "assets/l09h2qppleubii6l.js", "assets/c1lw0j14sexsyj33.js", "assets/jbh6ambg0gcrgcqd.js", "assets/b31u62knn5mcc1vg.js", "assets/product-variants-pcfu1bfm.css", "assets/i7egh70diihkdvnr.js", "assets/h3mm4dcmy7evm6n4.js", "assets/ou2xm3xmri21t4zm.js", "assets/omy347b79inqzbaj.js", "assets/o67bv4dtwt5l98l7.js", "assets/fj4bpqcms0mhjoda.js", "assets/eejiqzdptzp07q5y.js", "assets/ew68kf01y1h7e4uk.js", "assets/k2oaaf8ac9lafsub.js", "assets/lans8a2ikbh9ax9r.js", "assets/jttqqjx6qab96ezg.js", "assets/e3ddui4ro6nb7fig.js", "assets/i5kvudettvxsr7pw.js", "assets/hz9475nc5ndyfqsu.js", "assets/jlu292yvnhcpthaw.js", "assets/f78b2oufkmgyeo1t.js", "assets/ib78f9d5brp6znzf.js", "assets/gb3g89r4fqk97sov.js", "assets/h21g9slzr4ujv9kj.js", "assets/u9jpwxvw30u3h6nc.js", "assets/cgzifg3i9o9z2mll.js", "assets/kwnt5gec5u9yguq4.js", "assets/huyvl5jhsuxofll4.js", "assets/kuvu1ok8vnzveb23.js", "assets/ondm185xc1426dha.js", "assets/f8zwc22xu46enu24.js", "assets/obmzp3ebe8x6w67a.js", "assets/cmznq0xmstwpnnee.js", "assets/bnzpk5jkohz236gc.js", "assets/d500l0l73692yic4.js", "assets/gd2ozzf4upgi0amm.js", "assets/tjmll0bdtco26rsw.js", "assets/nr0ly5umft9hqfl0.js", "assets/jnh7gh80gtj0452q.js", "assets/msn8hpk3ivp7ibnw.js", "assets/l9twb3s7m6ux25j8.js", "assets/nf79rzyd6jobmpxe.js", "assets/o10zzeqfs0jt3ob2.js", "assets/j7da7d2tjwptnbm7.js", "assets/kebbqamw9fhr6qgk.js"]))) => i.map(i => d[i]);
import {
    _ as l,
    c as S,
    j as n,
    r as E,
    E as p
} from "./fg33krlcm0qyi6yw.js";
import {
    bh as c,
    d as f,
    gt as x,
    p7 as v,
    bg as y,
    bv as C
} from "./dykg4ktvbu3mhmdo.js";
import {
    P as j
} from "./omxv5qehu9kgsx7t.js";
import {
    bN as g,
    bO as T,
    bP as A
} from "./k15yxxoybkkir2ou.js";
const P = c(() => l(() =>
        import ("./cbu1fjafb968gwfi.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27])).then(s => s.ChatScreenProductFlyout), {
        loading: d
    }),
    F = c(() => l(() =>
        import ("./cbu1fjafb968gwfi.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27])).then(s => s.ChatScreenAgentProductFlyout), {
        loading: d
    }),
    R = c(() => l(() =>
        import ("./i7egh70diihkdvnr.js"), __vite__mapDeps([28, 1, 2, 3, 4, 5, 29, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47])).then(s => s.ChatScreenEntityFlyout), {
        loading: d
    }),
    L = c(() => l(() =>
        import ("./cgzifg3i9o9z2mll.js"), __vite__mapDeps([48, 1, 4, 2, 3, 5, 49, 50, 51])).then(s => s.ChatScreenSearchSourcesFlyout), {
        loading: d
    }),
    I = c(() => l(() =>
        import ("./ondm185xc1426dha.js"), __vite__mapDeps([52, 1, 53, 2, 3, 4, 5, 24, 54, 49, 50, 51])).then(s => s.ChatScreenRetrievalResultsFlyout), {
        loading: d
    }),
    O = c(() => l(() =>
        import ("./cmznq0xmstwpnnee.js"), __vite__mapDeps([55, 1, 2, 3, 4, 5])).then(s => s.ChatScreenSummarizerFlyout), {
        loading: d
    }),
    V = c(() => l(() =>
        import ("./bnzpk5jkohz236gc.js").then(s => s.c), __vite__mapDeps([56, 1, 2, 3, 4, 5, 57, 54, 58, 59, 60, 61, 25, 62, 49, 50, 51])).then(s => s.ChatScreenCoTFlyout), {
        loading: d
    }),
    D = c(() => l(() =>
        import ("./l9twb3s7m6ux25j8.js"), __vite__mapDeps([63, 1, 4, 2, 3, 5, 56, 57, 54, 58, 59, 60, 61, 25, 62, 49, 50, 51, 64])).then(s => s.CaterpillarSidebar), {
        loading: d
    }),
    w = c(() => l(() =>
        import ("./o10zzeqfs0jt3ob2.js"), __vite__mapDeps([65, 1, 4, 2, 3, 5, 49, 50, 51])).then(s => s.AgentSourcesSidebar), {
        loading: d
    }),
    $ = c(() => l(() =>
        import ("./j7da7d2tjwptnbm7.js"), __vite__mapDeps([66, 1, 4, 2, 3, 5])).then(s => s.AgentTabsSidebar), {
        loading: d
    });
c(() => l(() =>
    import ("./kebbqamw9fhr6qgk.js"), __vite__mapDeps([67, 1, 2, 3, 4, 5, 58])).then(s => s.CodingCitationsSidebar), {
    loading: d
});

function d() {
    "use forget";
    const s = S.c(5),
        e = x();
    let r;
    s[0] !== e ? (r = () => e && T(e), s[0] = e, s[1] = r) : r = s[1];
    let a;
    s[2] === Symbol.for("react.memo_cache_sentinel") ? (a = n.jsx(n.Fragment, {}), s[2] = a) : a = s[2];
    let o;
    return s[3] !== r ? (o = n.jsx(A, {
        ariaLabel: "",
        handleClose: r,
        children: a
    }), s[3] = r, s[4] = o) : o = s[4], o
}

function z(s) {
    "use forget";
    const e = S.c(11),
        {
            isExpanded: r,
            children: a
        } = s,
        [o, u] = E.useState("400px");
    let i;
    e[0] !== a ? (i = p.isValidElement(a) ? p.cloneElement(a, {
        setWidth: u
    }) : a, e[0] = a, e[1] = i) : i = e[1];
    const t = i;
    let h;
    e[2] !== t ? (h = p.Children.toArray(t).some(Boolean), e[2] = t, e[3] = h) : h = e[3];
    const m = h;
    let _;
    e[4] !== t || e[5] !== m || e[6] !== r || e[7] !== o ? (_ = r && m ? n.jsx(y.div, {
        className: "bg-token-sidebar-surface-primary relative z-1 shrink-0 overflow-x-hidden max-lg:w-0!",
        initial: {
            width: 0
        },
        animate: {
            width: o,
            transition: {
                type: "spring",
                bounce: .12
            }
        },
        exit: {
            width: 0
        },
        children: n.jsx("div", {
            className: "absolute h-full",
            style: {
                width: o
            },
            children: n.jsx("div", {
                className: "flex h-full flex-col",
                children: t
            })
        })
    }) : null, e[4] = t, e[5] = m, e[6] = r, e[7] = o, e[8] = _) : _ = e[8];
    let b;
    return e[9] !== _ ? (b = n.jsx(C, {
        children: _
    }), e[9] = _, e[10] = b) : b = e[10], b
}

function G(s) {
    "use forget";
    const e = S.c(7),
        {
            conversation: r
        } = s;
    let a;
    e[0] !== r ? (a = () => g(r), e[0] = r, e[1] = a) : a = e[1];
    const u = f(a) != null;
    let i;
    e[2] !== r ? (i = n.jsx(N, {
        conversation: r
    }), e[2] = r, e[3] = i) : i = e[3];
    let t;
    return e[4] !== u || e[5] !== i ? (t = n.jsx(z, {
        isExpanded: u,
        children: i
    }), e[4] = u, e[5] = i, e[6] = t) : t = e[6], t
}
const N = s => {
    "use forget";
    const e = S.c(41),
        {
            conversation: r,
            setWidth: a
        } = s,
        o = f(v);
    let u;
    e[0] !== r ? (u = () => g(r), e[0] = r, e[1] = u) : u = e[1];
    const i = f(u);
    if (!i) return null;
    if (o) switch (i.type) {
        case "searchSources":
            {
                let t;
                return e[2] !== i || e[3] !== r ? (t = n.jsx(L, {
                    conversation: r,
                    sidebar: i
                }), e[2] = i, e[3] = r, e[4] = t) : t = e[4],
                t
            }
        case "product":
            {
                let t;
                return e[5] !== i || e[6] !== r ? (t = n.jsx(P, {
                    conversation: r,
                    sidebar: i
                }), e[5] = i, e[6] = r, e[7] = t) : t = e[7],
                t
            }
        case "product_agent":
            {
                let t;
                return e[8] !== i || e[9] !== r ? (t = n.jsx(F, {
                    conversation: r,
                    sidebar: i
                }), e[8] = i, e[9] = r, e[10] = t) : t = e[10],
                t
            }
        case "entity":
            {
                let t;
                return e[11] !== i || e[12] !== r || e[13] !== a ? (t = n.jsx(R, {
                    conversation: r,
                    sidebar: i,
                    setWidth: a
                }), e[11] = i, e[12] = r, e[13] = a, e[14] = t) : t = e[14],
                t
            }
        case "pulse":
            {
                let t;
                return e[15] !== a ? (t = n.jsx(j, {
                    type: "sidebar",
                    setWidth: a
                }), e[15] = a, e[16] = t) : t = e[16],
                t
            }
    }
    switch (i.type) {
        case "retrievalResults":
            {
                let t;
                return e[17] !== i || e[18] !== r ? (t = n.jsx(I, {
                    conversation: r,
                    sidebar: i
                }), e[17] = i, e[18] = r, e[19] = t) : t = e[19],
                t
            }
        case "summarizer":
            {
                let t;
                return e[20] !== i || e[21] !== r ? (t = n.jsx(O, {
                    conversation: r,
                    sidebar: i
                }), e[20] = i, e[21] = r, e[22] = t) : t = e[22],
                t
            }
        case "cot":
            {
                let t;
                return e[23] !== i || e[24] !== r ? (t = n.jsx(V, {
                    conversation: r,
                    sidebar: i
                }), e[23] = i, e[24] = r, e[25] = t) : t = e[25],
                t
            }
        case "caterpillar":
            {
                let t;
                return e[26] !== i.caterpillarId || e[27] !== i.initialTab ? (t = n.jsx(D, {
                    taskId: i.caterpillarId,
                    initialTab: i.initialTab
                }), e[26] = i.caterpillarId, e[27] = i.initialTab, e[28] = t) : t = e[28],
                t
            }
        case "n7jupdSources":
            {
                let t;
                return e[29] !== i || e[30] !== r ? (t = n.jsx(w, {
                    conversation: r,
                    sidebar: i
                }), e[29] = i, e[30] = r, e[31] = t) : t = e[31],
                t
            }
        case "n7jupdTabs":
            {
                let t;
                return e[32] !== i.tabs || e[33] !== r ? (t = n.jsx($, {
                    conversation: r,
                    tabs: i.tabs
                }), e[32] = i.tabs, e[33] = r, e[34] = t) : t = e[34],
                t
            }
    }
    return null
};
export {
    G as C, z as S
};
//# sourceMappingURL=pau1yzg54moerxhg.js.map