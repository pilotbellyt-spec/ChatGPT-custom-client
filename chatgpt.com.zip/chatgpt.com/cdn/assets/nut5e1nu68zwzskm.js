var ne = Object.defineProperty;
var H = Object.getOwnPropertySymbols;
var ae = Object.prototype.hasOwnProperty,
    oe = Object.prototype.propertyIsEnumerable;
var U = (t, e, s) => e in t ? ne(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : t[e] = s,
    L = (t, e) => {
        for (var s in e || (e = {})) ae.call(e, s) && U(t, s, e[s]);
        if (H)
            for (var s of H(e)) oe.call(e, s) && U(t, s, e[s]);
        return t
    };
import {
    j as a,
    e as T,
    r as d,
    M as _,
    i as W,
    c as F,
    f as re,
    w as ce,
    v as le,
    E as ie
} from "./fg33krlcm0qyi6yw.js";
import {
    M as B,
    l as C,
    aY as ue,
    ao as de,
    to as S,
    tp as N,
    P as fe,
    qq as me,
    c2 as X,
    b as Q,
    e1 as z,
    gI as he,
    zB as ye,
    v6 as V,
    v5 as xe,
    R as ge,
    fe as pe,
    o as K,
    zC as ke,
    hA as ve,
    aW as be,
    C as we,
    I as je,
    i9 as Ne
} from "./dykg4ktvbu3mhmdo.js";
import {
    u as Ce,
    F as G
} from "./o4n6pqcoqgw7owdr.js";
import {
    ci as Z,
    aa as Me,
    vd as Se,
    yN as Pe,
    bM as _e
} from "./k15yxxoybkkir2ou.js";
import {
    F as M
} from "./bo2v113kbgrh2zlp.js";

function Fe({
    children: t,
    rootClassName: e,
    className: s,
    description: n,
    icon: c,
    isOpen: o = !1,
    onClose: r,
    primaryButton: u,
    secondaryButton: f,
    size: l = "normal",
    title: i,
    type: m,
    noPadding: k = !1,
    hideSeparator: y = !1,
    showCloseButton: g = !1,
    shouldIgnoreClickOutside: h = !1,
    closeButton: x,
    isScrollable: v = !0,
    position: j = "center",
    removePopoverStyling: w = !1,
    showOverlayBackground: A = !0,
    shadow: R = "normal"
}) {
    const E = !!i,
        P = !!t,
        D = E && P && !y;
    return a.jsx(B.Root, {
        testId: "modal-fanny-pack",
        isOpen: o,
        onClose: r,
        shouldIgnoreClickOutside: h,
        className: e,
        children: a.jsx(B.Overlay, {
            showBackground: A,
            children: a.jsxs(Re, {
                size: l,
                position: j,
                className: C("flex flex-col focus:outline-hidden", {
                    "max-w-md": l === "normal"
                }, s),
                removePopoverStyling: w,
                shadow: R,
                children: [a.jsx(B.Header, {
                    icon: c,
                    title: i,
                    type: m,
                    closeButton: g && (x != null ? x : a.jsx(ue, {
                        onClick: () => r(!0)
                    })),
                    description: n,
                    hasSeparator: D
                }), a.jsxs("div", {
                    className: C("grow", v ? "overflow-y-auto" : "overflow-y-hidden", {
                        "p-4 sm:p-6": l !== "fullscreen" && !k,
                        "md:pt-0!": !P
                    }),
                    children: [t, u != null || f != null ? a.jsx(B.Actions, {
                        primaryButton: u,
                        secondaryButton: f,
                        modalHasContent: P
                    }) : null]
                })]
            })
        })
    })
}

function Re({
    className: t,
    children: e,
    position: s = "center",
    size: n,
    removePopoverStyling: c = !1,
    shadow: o = "normal"
}) {
    return a.jsx("div", {
        className: C("z-50 h-full w-full overflow-y-auto", n !== "fullscreen" && "grid grid-cols-[10px_1fr_10px]", n !== "fullscreen" && s === "center" && "grid-rows-[minmax(10px,1fr)_auto_minmax(10px,1fr)] md:grid-rows-[minmax(20px,1fr)_auto_minmax(20px,1fr)]", n !== "fullscreen" && s === "bottom" && "grid-rows-[minmax(10px,1fr)_auto_10px] md:grid-rows-[minmax(20px,1fr)_auto_20px]"),
        children: a.jsx(de, {
            className: C(!c && "popover", "bg-token-main-surface-primary relative start-1/2 col-auto col-start-2 row-auto row-start-2 h-full w-full text-start ltr:-translate-x-1/2 rtl:translate-x-1/2", n !== "fullscreen" && "rounded-2xl", o === "normal" && "shadow-xl", t),
            onEscapeKeyDown: r => {
                r.stopPropagation()
            },
            children: e
        })
    })
}

function Ee() {
    const t = T(),
        e = S(n => n.query),
        s = d.useRef(null);
    return a.jsx("input", {
        className: "placeholder:text-token-text-tertiary w-full border-none bg-transparent focus:border-transparent focus:ring-0 focus:outline-hidden",
        placeholder: t.formatMessage({
            id: "FannyPack.SearchPlaceholder",
            defaultMessage: "Search chats..."
        }),
        onChange: n => N.setQuery(n.target.value),
        onKeyDown: n => {
            !n.shiftKey && (n.key === "ArrowUp" || n.key === "ArrowDown") && n.preventDefault()
        },
        value: e,
        ref: s
    })
}

function q({
    className: t,
    isActive: e = !1,
    icon: s,
    children: n,
    onClick: c,
    onMouseEnter: o,
    onMouseLeave: r
}) {
    const u = S(f => f.mouseInteractionsDisabled);
    return a.jsx("div", {
        className: C("cursor-pointer", t),
        onMouseEnter: u ? void 0 : o,
        onMouseLeave: u ? void 0 : r,
        onClick: c,
        children: a.jsxs("div", {
            className: C("group relative flex items-center rounded-xl px-4 py-3", e && "dark:bg-token-main-surface-secondary bg-[#f4f4f4]"),
            children: [s, a.jsx("div", {
                className: C("relative grow overflow-hidden whitespace-nowrap", s ? "ps-2" : ""),
                children: n
            })]
        })
    })
}

function ee(t) {
    return t.formatMessage({
        id: "fannyPack.DefaultChatTitle",
        defaultMessage: "New chat"
    })
}

function De({
    historyResult: t,
    index: e
}) {
    var r;
    const s = T(),
        {
            item: n,
            onSelect: c
        } = t,
        o = S(u => u.activeIndex);
    return a.jsx(q, {
        isActive: o === e,
        icon: a.jsx(Z, {
            className: "icon"
        }),
        onClick: () => {
            M.logClick(n.id, e, "history"), c && c()
        },
        onMouseEnter: () => N.setActiveIndex(e),
        onMouseLeave: () => N.setActiveIndex(void 0),
        children: a.jsx("div", {
            className: "text-sm",
            children: (r = n.title) != null ? r : ee(s)
        })
    })
}

function Ie({
    labelResult: t
}) {
    return a.jsx("div", {
        className: "group text-token-text-tertiary relative my-2 px-4 pt-2 text-xs leading-4",
        children: t.text
    })
}

function Ae({
    newChatResult: t,
    query: e = void 0,
    index: s
}) {
    const {
        onSelect: n
    } = t, c = S(o => o.activeIndex);
    return a.jsx(q, {
        isActive: c === s,
        onClick: () => {
            fe.logNewChatButtonClicked({
                location: "Fanny Pack"
            }), n && n()
        },
        onMouseEnter: () => N.setActiveIndex(s),
        onMouseLeave: () => N.setActiveIndex(void 0),
        icon: a.jsx(Me, {
            className: "icon"
        }),
        children: a.jsx("div", {
            className: "text-sm",
            children: e ? a.jsx(_, {
                id: "iQsutJ",
                defaultMessage: 'New chat "{query}"',
                values: {
                    query: e
                }
            }) : a.jsx(_, {
                id: "FannyPack.NewChat",
                defaultMessage: "New chat"
            })
        })
    })
}

function Le(t) {
    return d.useMemo(() => {
        if (!t) return null;
        const e = new Date(t * 1e3),
            s = new Date;
        return e.toDateString() === s.toDateString() ? "Today" : new Date(new Date().setDate(s.getDate() - 1)).toDateString() === e.toDateString() ? "Yesterday" : e.getFullYear() === s.getFullYear() ? e.toLocaleDateString(void 0, {
            month: "short",
            day: "numeric"
        }) : e.toLocaleDateString(void 0, {
            year: "2-digit",
            month: "numeric",
            day: "numeric"
        })
    }, [t])
}
const Te = 8;

function qe(t) {
    return t.isArchived ? {
        titleClassName: "text-sm text-token-text-tertiary",
        titleHighlightedClassName: "text-token-text-secondary font-semibold",
        messageClassName: "text-xs text-token-text-tertiary",
        messageHighlightedClassName: "text-token-text-secondary font-medium"
    } : {
        titleClassName: "text-sm text-token-text-primary",
        titleHighlightedClassName: "text-token-text-primary font-semibold",
        messageClassName: "text-xs text-token-text-secondary",
        messageHighlightedClassName: "text-token-text-primary font-medium"
    }
}

function J({
    text: t,
    textToHighlight: e,
    shouldAdjustStart: s = !1,
    highlightClassName: n
}) {
    const c = d.useMemo(() => {
            if (!s || !e) return t;
            const r = t.toLowerCase().indexOf(e == null ? void 0 : e.toLowerCase());
            if (r === -1) return t;
            const u = Math.max(r - Te, 0),
                f = t.substring(u);
            return u === 0 ? f : "…" + f
        }, [t, e, s]),
        o = d.useMemo(() => {
            const r = new RegExp("(".concat(Pe(e), ")"), "gi");
            return c.split(r)
        }, [c, e]);
    return !e || e.length === 0 ? a.jsx("span", {
        children: t
    }) : a.jsx("div", {
        className: "truncate",
        children: o.map((r, u) => r.toLowerCase() === e.toLowerCase() ? a.jsx("span", {
            className: n,
            children: r
        }, u) : r)
    })
}

function Ye({
    searchResult: t,
    index: e,
    elementRef: s
}) {
    var k;
    const {
        item: n,
        onSelect: c,
        query: o
    } = t, r = T(), u = Le(n.updateTime), f = qe(n), i = S(y => y.activeIndex) === e, m = d.useRef(null);
    return d.useEffect(() => {
        let y;
        const g = setTimeout(() => {
            y = new IntersectionObserver(h => {
                h.forEach(x => {
                    x.isIntersecting && (M.logImpression(n.source, e, n.conversationId), y && y.disconnect())
                })
            }, {
                threshold: .5
            }), m.current && y.observe(m.current)
        }, 250);
        return () => {
            y && y.disconnect(), clearTimeout(g)
        }
    }, [m, n, o, e]), a.jsx("div", {
        ref: m,
        children: a.jsx(q, {
            isActive: i,
            icon: n.isArchived ? a.jsx(Se, {
                className: "icon text-token-text-tertiary"
            }) : a.jsx(Z, {
                className: "icon"
            }),
            onClick: () => {
                M.logClick(n.conversationId, e, n.source, n.updateTime), c && c()
            },
            onMouseEnter: () => N.setActiveIndex(e),
            onMouseLeave: () => N.setActiveIndex(void 0),
            children: a.jsxs("div", {
                className: "flex items-center",
                ref: s,
                children: [a.jsxs("div", {
                    className: "relative grow overflow-hidden whitespace-nowrap",
                    children: [a.jsx("div", {
                        className: f.titleClassName,
                        children: a.jsx(J, {
                            text: n.title && n.title.length > 0 ? n.title : ee(r),
                            textToHighlight: o.length >= 3 ? o : void 0,
                            highlightClassName: f.titleHighlightedClassName
                        })
                    }), a.jsx("div", {
                        className: C("pt-1", f.messageClassName),
                        children: a.jsx(J, {
                            text: (k = n.snippet) != null ? k : "",
                            textToHighlight: o.length >= 3 ? o : void 0,
                            shouldAdjustStart: !0,
                            highlightClassName: f.messageHighlightedClassName
                        })
                    })]
                }), i && a.jsx("div", {
                    className: "text-token-text-secondary ps-6 text-xs",
                    children: u
                })]
            })
        })
    })
}

function Y() {
    return d.useMemo(() => ({
        closeFannyPackModal: t => {
            M.logClose(t), N.setIsActive(!1)
        }
    }), [])
}

function O() {
    const t = W(),
        {
            closeFannyPackModal: e
        } = Y();
    return d.useCallback(s => {
        t(s), e("click")
    }, [t, e])
}

function Be() {
    "use forget";
    var x;
    const t = F.c(21),
        {
            conversations: e
        } = me(),
        s = Q(),
        {
            closeFannyPackModal: n
        } = Y();
    let c;
    t[0] !== s ? (c = X(s, "550560761"), t[0] = s, t[1] = c) : c = t[1];
    const o = c.value,
        r = Number((x = o == null ? void 0 : o.history_results_limit) != null ? x : 6);
    let u;
    t[2] !== e || t[3] !== r ? (u = e.slice(0, Math.min(e.length, r)), t[2] = e, t[3] = r, t[4] = u) : u = t[4];
    const l = $e(u),
        i = O(),
        m = W();
    let k;
    t[5] !== n || t[6] !== m ? (k = {
        kind: "newChat",
        onSelect: () => {
            _e(m), n("button")
        }
    }, t[5] = n, t[6] = m, t[7] = k) : k = t[7];
    const y = k;
    let g;
    if (t[8] !== l.dynamicMonths || t[9] !== l.dynamicYears || t[10] !== l.recent || t[11] !== i || t[12] !== y) {
        g = [y];
        let v;
        if (t[14] !== l.dynamicMonths || t[15] !== l.dynamicYears || t[16] !== l.recent || t[17] !== i) {
            let j;
            t[19] !== i ? (j = (w, A) => (Object.entries(A).forEach(R => {
                const [, E] = R, {
                    items: P,
                    label: D
                } = E;
                P.length > 0 && (w.push({
                    kind: "label",
                    text: D
                }), P.forEach(p => {
                    w.push({
                        kind: "history",
                        onSelect: () => {
                            i(z(p.id))
                        },
                        item: p
                    })
                }))
            }), w), t[19] = i, t[20] = j) : j = t[20], v = [l.recent, l.dynamicMonths, l.dynamicYears].reduce(j, []), t[14] = l.dynamicMonths, t[15] = l.dynamicYears, t[16] = l.recent, t[17] = i, t[18] = v
        } else v = t[18];
        g.push(...v), t[8] = l.dynamicMonths, t[9] = l.dynamicYears, t[10] = l.recent, t[11] = i, t[12] = y, t[13] = g
    } else g = t[13];
    return g
}
const $ = re({
    historyBucketToday: {
        id: "history.bucket.today",
        defaultMessage: "Today"
    },
    historyBucketYesterday: {
        id: "history.bucket.yesterday",
        defaultMessage: "Yesterday"
    },
    historyBucketLastSeven: {
        id: "history.bucket.lastSeven",
        defaultMessage: "Previous 7 Days"
    },
    historyBucketLastThirty: {
        id: "history.bucket.lastThirty",
        defaultMessage: "Previous 30 Days"
    }
});

function $e(t) {
    "use forget";
    const e = F.c(9),
        s = T();
    let n;
    if (e[0] !== s || e[1] !== t) {
        let c;
        e[3] !== s ? (c = (l, i) => {
            var y, g;
            const m = new Date((g = (y = i.update_time) != null ? y : i.create_time) != null ? g : 0),
                k = he(new Date, m);
            if (k === 0) l.recent.today.items.push(i);
            else if (k <= 1) l.recent.yesterday.items.push(i);
            else if (k <= 7) l.recent.lastSeven.items.push(i);
            else if (k <= 30) l.recent.lastThirty.items.push(i);
            else if (ye(m)) {
                const h = V(m),
                    x = xe(m),
                    v = "".concat(h, "-").concat(x);
                l.dynamicMonths[v] ? l.dynamicMonths[v].items.push(i) : l.dynamicMonths[v] = {
                    label: s.formatDate(m, {
                        month: "long"
                    }),
                    items: [i]
                }
            } else {
                const h = V(m),
                    x = "".concat(h, "-");
                l.dynamicYears[x] ? l.dynamicYears[x].items.push(i) : l.dynamicYears[x] = {
                    label: s.formatDate(m, {
                        year: "numeric"
                    }),
                    items: [i]
                }
            }
            return l
        }, e[3] = s, e[4] = c) : c = e[4];
        let o;
        e[5] === Symbol.for("react.memo_cache_sentinel") ? (o = a.jsx(_, L({}, $.historyBucketToday)), e[5] = o) : o = e[5];
        let r;
        e[6] === Symbol.for("react.memo_cache_sentinel") ? (r = a.jsx(_, L({}, $.historyBucketYesterday)), e[6] = r) : r = e[6];
        let u;
        e[7] === Symbol.for("react.memo_cache_sentinel") ? (u = a.jsx(_, L({}, $.historyBucketLastSeven)), e[7] = u) : u = e[7];
        let f;
        e[8] === Symbol.for("react.memo_cache_sentinel") ? (f = a.jsx(_, L({}, $.historyBucketLastThirty)), e[8] = f) : f = e[8], n = t.reduce(c, {
            recent: {
                today: {
                    label: o,
                    items: []
                },
                yesterday: {
                    label: r,
                    items: []
                },
                lastSeven: {
                    label: u,
                    items: []
                },
                lastThirty: {
                    label: f,
                    items: []
                }
            },
            dynamicMonths: {},
            dynamicYears: {}
        }), e[0] = s, e[1] = t, e[2] = n
    } else n = e[2];
    return n
}
async function Qe({
    query: t,
    cursor: e
}) {
    return ge.safeGet("/conversations/search", {
        parameters: {
            query: {
                query: t,
                cursor: e
            }
        }
    })
}

function Ke() {
    var D;
    const t = S(p => p.query),
        e = O(),
        [s, n] = d.useState(""),
        [c, o] = d.useState(!1),
        r = d.useRef(pe(p => {
            o(!1), n(p)
        }, 250)).current,
        u = d.useCallback(p => {
            p !== s && (o(!0), r(p))
        }, [s, r]);
    d.useEffect(() => {
        u(t)
    }, [t, u]);
    const {
        data: f,
        isError: l,
        isLoading: i,
        isFetchingNextPage: m,
        hasNextPage: k,
        fetchNextPage: y
    } = ce({
        queryKey: ["conversationSearch", {
            query: s
        }],
        queryFn: ({
            pageParam: p
        }) => Qe({
            query: s,
            cursor: p
        }),
        initialPageParam: "",
        getNextPageParam: p => {
            var b;
            return (b = p.cursor) != null ? b : void 0
        },
        enabled: !!s
    });
    d.useEffect(() => {
        i && M.logQuery()
    }, [i]), d.useEffect(() => {
        l && M.logQueryError()
    }, [l]), d.useEffect(() => {
        m && M.logQueryMore()
    }, [m]);
    const g = d.useMemo(() => {
            var p;
            return (p = f == null ? void 0 : f.pages.flatMap(b => b.items)) != null ? p : []
        }, [f]),
        h = d.useCallback(p => {
            if (i || p == null) return;
            const b = new IntersectionObserver(se => {
                se[0].isIntersecting && !m && k && y()
            });
            return b.observe(p), () => {
                b.disconnect()
            }
        }, [i, m, k, y]),
        x = g && s === t,
        v = t.length > 0 && (c || i || m),
        j = Q(),
        w = X(j, "550560761").value,
        A = Number((D = w == null ? void 0 : w.local_results_limit) != null ? D : 0),
        R = Ce(t, A),
        E = d.useMemo(() => {
            const p = R;
            return x && g.forEach(b => {
                p.has(b.conversation_id) || p.set(b.conversation_id, {
                    conversationId: b.conversation_id,
                    nodeId: b.current_node_id,
                    title: b.title,
                    isArchived: b.is_archived,
                    updateTime: b.update_time,
                    snippet: b.payload.snippet,
                    source: "remote"
                })
            }), Array.from(p.values())
        }, [R, g, x]);
    return {
        searchResults: d.useMemo(() => E.map(p => ({
            kind: "search",
            onSelect: () => {
                e("".concat(z(p.conversationId), "?src=history_search"))
            },
            item: p,
            query: t
        })), [E, e, t]),
        shouldShowLoading: v,
        infiniteScrollTriggerElementRef: h
    }
}

function Oe(t, e, s) {
    switch (t.kind) {
        case "history":
            return a.jsx(De, {
                historyResult: t,
                index: e
            });
        case "label":
            return a.jsx(Ie, {
                labelResult: t
            });
        case "loading":
            return a.jsx(Ge, {
                loadingResults: t
            });
        case "newChat":
            return a.jsx(Ae, {
                newChatResult: t,
                query: t.query,
                index: e
            });
        case "noResults":
            return a.jsx(Ve, {});
        case "search":
            return a.jsx(Ye, {
                searchResult: t,
                index: e,
                elementRef: s
            })
    }
}

function He(t, e) {
    const s = d.useCallback(() => {
            for (let o = (t != null ? t : -1) + 1; o < e.length; o++)
                if (e[o].onSelect) return o;
            return t
        }, [t, e]),
        n = d.useCallback(() => {
            for (let o = (t != null ? t : e.length) - 1; o >= 0; o--)
                if (e[o].onSelect) return o;
            return t
        }, [t, e]),
        c = d.useCallback(() => {
            t !== void 0 && e[t] && e[t].onSelect && e[t].onSelect()
        }, [t, e]);
    d.useEffect(() => {
        const o = r => {
            r.isComposing || (r.key === "ArrowUp" && !r.shiftKey ? N.setActiveIndex(n()) : r.key === "ArrowDown" && !r.shiftKey ? N.setActiveIndex(s()) : (r.key === "Enter" || r.key === "Return") && (r.preventDefault(), c()))
        };
        return window.addEventListener("keydown", o), () => {
            window.removeEventListener("keydown", o)
        }
    }, [n, s, c]), d.useEffect(() => {
        const o = () => {
            ke.getMouseInteractionsDisabled() && N.setMouseInteractionsDisabled(!1)
        };
        return window.addEventListener("mousemove", o), () => {
            window.removeEventListener("mousemove", o)
        }
    }, [])
}

function Ue(t, e) {
    const s = d.useRef([]);
    return d.useEffect(() => {
        s.current = e.map(() => ie.createRef())
    }, [e]), d.useEffect(() => {
        s.current.forEach((n, c) => {
            t === c && (n != null && n.current) && n.current.scrollIntoView({
                behavior: "instant",
                block: "nearest"
            })
        })
    }, [t, s]), s
}

function Ve() {
    return a.jsx(q, {
        className: "text-token-text-tertiary text-sm",
        icon: a.jsx(ve, {
            className: "icon"
        }),
        children: a.jsx(_, {
            id: "FannyPack.Noresults",
            defaultMessage: "No results"
        })
    })
}

function I() {
    return a.jsx(q, {
        icon: a.jsx("div", {
            className: "loading-results-shimmer bg-token-main-surface-secondary h-[14px] w-[14px] rounded-full"
        }),
        children: a.jsxs("div", {
            className: "flex min-h-[40px] flex-col justify-center",
            children: [a.jsx("div", {
                className: "loading-results-shimmer bg-token-main-surface-secondary h-2 w-1/4 rounded-full"
            }), a.jsx("div", {
                className: "loading-results-shimmer bg-token-main-surface-secondary mt-3 h-2 w-1/2 rounded-full"
            })]
        })
    })
}

function Ge({
    loadingResults: t
}) {
    return t.shouldShowMultiple ? a.jsxs(a.Fragment, {
        children: [a.jsx(I, {}), a.jsx(I, {}), a.jsx(I, {}), a.jsx(I, {}), a.jsx(I, {})]
    }) : a.jsx(I, {})
}

function Je() {
    const t = O(),
        {
            searchResults: e,
            shouldShowLoading: s,
            infiniteScrollTriggerElementRef: n
        } = Ke(),
        c = Be(),
        o = S(h => h.query),
        r = o.length > 0,
        u = Q(),
        f = K(u, "1741586789");
    d.useEffect(() => {
        M.setQuerySessionId(le())
    }, [o]);
    const l = d.useMemo(() => ({
            kind: "newChat",
            query: o,
            onSelect: () => {
                t("/?q=".concat(o))
            }
        }), [o, t]),
        i = d.useMemo(() => {
            const h = [];
            return o && f && h.push(l), r ? h.push(...e) : h.push(...c), s ? h.push({
                kind: "loading",
                shouldShowMultiple: h.length === 0
            }) : h.length === 0 && h.push({
                kind: "noResults"
            }), h
        }, [o, f, l, r, s, e, c]),
        m = S(h => h.activeIndex);
    He(m, i);
    const k = Ue(m, i),
        y = d.useRef(null);
    d.useEffect(() => {
        N.setActiveIndex(0), y.current && (y.current.scrollTop = 0)
    }, [o]);
    const g = d.useRef(!0);
    return d.useEffect(() => {
        g.current && !s && i.length === 1 && i[0].kind === "noResults" && M.logNoResults(), g.current = s
    }, [s, i]), a.jsx("div", {
        ref: y,
        children: a.jsx("ol", {
            className: "mx-2",
            children: i.map((h, x) => a.jsx("li", {
                ref: k.current[x],
                children: Oe(h, x, x === i.length - 1 ? n : void 0)
            }, x))
        })
    })
}

function rt() {
    "use forget";
    const t = F.c(3),
        e = S(We),
        s = be();
    let n;
    return t[0] !== e || t[1] !== s ? (n = s ? a.jsx(ze, {
        isOpen: e
    }) : a.jsx(Ze, {
        isOpen: e
    }), t[0] = e, t[1] = s, t[2] = n) : n = t[2], n
}

function We(t) {
    return t.isActive
}

function Xe(t) {
    "use forget";
    const e = F.c(9),
        {
            onClick: s,
            className: n
        } = t,
        c = T();
    let o;
    e[0] !== n ? (o = C("hover:bg-token-main-surface-secondary focus-visible:ring-token-text-quaternary dark:hover:bg-token-main-surface-tertiary flex items-center justify-center rounded-full bg-transparent p-1 focus-visible:ring-2 focus-visible:ring-offset-1 focus-visible:ring-offset-transparent focus-visible:outline-hidden", n), e[0] = n, e[1] = o) : o = e[1];
    let r;
    e[2] !== c ? (r = c.formatMessage({
        id: "Px7S/2",
        defaultMessage: "Close"
    }), e[2] = c, e[3] = r) : r = e[3];
    let u;
    e[4] === Symbol.for("react.memo_cache_sentinel") ? (u = a.jsx(Ne, {
        className: "icon text-token-text-tertiary hover:text-token-text-primary"
    }), e[4] = u) : u = e[4];
    let f;
    return e[5] !== s || e[6] !== o || e[7] !== r ? (f = a.jsx("button", {
        className: o,
        "aria-label": r,
        onClick: s,
        children: u
    }), e[5] = s, e[6] = o, e[7] = r, e[8] = f) : f = e[8], f
}

function te(t) {
    "use forget";
    const e = F.c(21),
        {
            className: s
        } = t,
        {
            closeFannyPackModal: n
        } = Y(),
        c = Q();
    let o;
    e[0] !== c ? (o = je(c), e[0] = c, e[1] = o) : o = e[1];
    const r = o,
        u = d.useRef(!1);
    let f;
    e[2] !== c ? (f = K(c, "3678527908"), e[2] = c, e[3] = f) : f = e[3];
    const l = f;
    let i;
    e[4] !== c ? (i = K(c, "1422501431"), e[4] = c, e[5] = i) : i = e[5];
    const m = i;
    let k, y;
    e[6] !== r || e[7] !== l || e[8] !== m ? (k = () => {
        !u.current && l && r && (m ? G.setCurrentAccountV2(r) : G.setCurrentAccount(r), u.current = !0)
    }, y = [l, r, m], e[6] = r, e[7] = l, e[8] = m, e[9] = k, e[10] = y) : (k = e[9], y = e[10]), d.useEffect(k, y);
    let g;
    e[11] !== s ? (g = C("flex flex-col", s), e[11] = s, e[12] = g) : g = e[12];
    let h;
    e[13] === Symbol.for("react.memo_cache_sentinel") ? (h = a.jsx(Ee, {}), e[13] = h) : h = e[13];
    let x;
    e[14] !== n ? (x = a.jsxs("div", {
        className: "ms-3 me-4 flex max-h-[64px] min-h-[64px] items-center justify-between",
        children: [h, a.jsx(Xe, {
            className: "ms-4",
            onClick: () => {
                n("button")
            }
        })]
    }), e[14] = n, e[15] = x) : x = e[15];
    let v;
    e[16] === Symbol.for("react.memo_cache_sentinel") ? (v = a.jsx("hr", {
        className: "border-token-border-default"
    }), e[16] = v) : v = e[16];
    let j;
    e[17] === Symbol.for("react.memo_cache_sentinel") ? (j = a.jsx("div", {
        className: "my-2 grow overflow-y-auto",
        children: a.jsx(Je, {})
    }), e[17] = j) : j = e[17];
    let w;
    return e[18] !== g || e[19] !== x ? (w = a.jsxs("div", {
        className: g,
        children: [x, v, j]
    }), e[18] = g, e[19] = x, e[20] = w) : w = e[20], w
}

function ze(t) {
    "use forget";
    const e = F.c(6),
        {
            isOpen: s
        } = t,
        {
            closeFannyPackModal: n
        } = Y();
    let c;
    e[0] !== n ? (c = () => {
        n("modal")
    }, e[0] = n, e[1] = c) : c = e[1];
    let o;
    e[2] === Symbol.for("react.memo_cache_sentinel") ? (o = a.jsx(te, {}), e[2] = o) : o = e[2];
    let r;
    return e[3] !== s || e[4] !== c ? (r = a.jsx(we, {
        testId: "modal-fanny-pack-mobile",
        isOpen: s,
        onClose: c,
        size: "fullscreen",
        showCloseButton: !0,
        type: "success",
        noPadding: !0,
        children: o
    }), e[3] = s, e[4] = c, e[5] = r) : r = e[5], r
}

function Ze(t) {
    "use forget";
    const e = F.c(6),
        {
            isOpen: s
        } = t,
        {
            closeFannyPackModal: n
        } = Y();
    let c;
    e[0] !== n ? (c = () => {
        n("modal")
    }, e[0] = n, e[1] = c) : c = e[1];
    let o;
    e[2] === Symbol.for("react.memo_cache_sentinel") ? (o = a.jsx(te, {
        className: "max-h-[440px] min-h-[440px]"
    }), e[2] = o) : o = e[2];
    let r;
    return e[3] !== s || e[4] !== c ? (r = a.jsx(Fe, {
        className: "border-token-border-default border bg-clip-padding shadow-[0_14px_62px_0_rgba(0,0,0,0.25)] md:max-w-[680px] md:min-w-[680px]",
        isOpen: s,
        onClose: c,
        showCloseButton: !0,
        type: "success",
        noPadding: !0,
        showOverlayBackground: !1,
        shadow: "custom",
        children: o
    }), e[3] = s, e[4] = c, e[5] = r) : r = e[5], r
}
export {
    rt as FannyPackModalContainer
};
//# sourceMappingURL=nut5e1nu68zwzskm.js.map