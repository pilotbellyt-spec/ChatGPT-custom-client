const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/e6bg0tkkqv946sj3.js", "assets/fg33krlcm0qyi6yw.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/nru7ghjfumsslhdj.js", "assets/jwm2780gzkkhdmn4.js", "assets/k15yxxoybkkir2ou.js", "assets/conversation-small-332fs9rk.css", "assets/ia54sddtrl9qa2wj.js", "assets/eiz8m6b2n93cr92l.js", "assets/lcm07h4hrgbddd47.js", "assets/pavmkm4i771s3in0.js", "assets/jgvzsx6f79dwdz3i.js", "assets/kc6yq367wl0uhtra.js", "assets/jdg49hmintmo4ij6.js", "assets/gzhsdx8lam3386fv.js", "assets/uwm5r01je8eaqgfc.js", "assets/newet32g44ysnvsb.js", "assets/djur71wanhd4j63t.js", "assets/ogty5pbz2ckq625a.js", "assets/e3ddui4ro6nb7fig.js", "assets/jdzosouyvpzu0tpb.js", "assets/22dgvhxdlo5c1yiw.js", "assets/cehclh0a60ppuuvu.js", "assets/cjybewlxcr1rdyw3.js", "assets/lqog7ixiwnif6sbp.js", "assets/nzl91iujqafxz8y1.js", "assets/ebc4iyfg14nu1gw4.js", "assets/gy1lpvuoewmzh42c.js", "assets/jed1ux7qibe55pmj.js", "assets/h1em0bjkpkjv8ykw.js", "assets/nfccle6oyncifphl.js", "assets/hu1bt0oauegdhua6.js", "assets/b5s349mvbdzayaxi.js", "assets/dbshkzvpochy4889.js", "assets/k78yzov06lrhyte9.js", "assets/jhvz2qkf3st8xisu.js", "assets/cfxpg7jffbmx1lzc.js", "assets/kk75394dp7aj1ofk.js", "assets/gf03dbmrlccb2uqq.js", "assets/jd9zt1u141h04j00.js", "assets/n7nqkdn53j3o5j6k.js", "assets/mtdf3zn500avq96a.js", "assets/hfibvokhkz8skuqw.js", "assets/lfdsdf4it937c4a2.js", "assets/mvl4u7g4pep6uysr.js", "assets/ma6fexe1cysk08ib.js", "assets/mh2edg92ng3qntdf.js", "assets/by32wbrf3h6krwuu.js", "assets/emixct2ecmtx0izd.js", "assets/ml3sfbo53uz391cc.js", "assets/elwpnpvd3n8263yf.js", "assets/jjruw0pg8h58hov8.js", "assets/ni16khhtjgvldr4m.js", "assets/hn5e71c3hkpkv00z.js", "assets/cgt1h5qo3k52ojx3.js", "assets/bmupik4h4l2k89rq.js", "assets/flbjosd8n90k89o3.js", "assets/jnh7gh80gtj0452q.js", "assets/j8307ki0hiq07pvv.js", "assets/blqq7ow0e0qiilq1.js", "assets/dukay9hyrtkqj0qi.js", "assets/nqsndip1gtokbr16.js", "assets/l2auawa985ju84xg.js", "assets/hf084iz91dvtpxr2.js", "assets/bmtdvqxk4wi5vo9c.js", "assets/3ype9xcsrgcixjgo.js", "assets/lt0k52ryhjrp2fva.js", "assets/o92vxzxwc8gk40ts.js", "assets/oi0jufgbruu7yg53.js", "assets/gogo7bs85ip5x228.js", "assets/3jqmuecsvur0aphg.js", "assets/k2oaaf8ac9lafsub.js", "assets/lans8a2ikbh9ax9r.js", "assets/iej0cupg2dqkmejt.js", "assets/h8afdg57t22ai4ff.js", "assets/dn6cv9mouo82roaf.js", "assets/d2k0z35o3p2yn5tf.js", "assets/jey1kqkf4thir7xd.js", "assets/g4v4kimchdgh1fre.js", "assets/mh5ruqlo4xwv83so.js", "assets/mqaxq6uz189xwrrs.js", "assets/nm2809n8a8o53c7h.js", "assets/irqko7c1s7qpl41n.js", "assets/ceksygc7o6kb5ygo.js", "assets/fknpszl3y0505y7v.js", "assets/ltr8f2om043h2xo1.js", "assets/nvxvk0t5hsctb5xf.js", "assets/kbmrqr6usrjd7suv.js"]))) => i.map(i => d[i]);
var co = Object.freeze,
    go = Object.defineProperty,
    _r = Object.defineProperties;
var wr = Object.getOwnPropertyDescriptors;
var Hn = Object.getOwnPropertySymbols;
var fo = Object.prototype.hasOwnProperty,
    mo = Object.prototype.propertyIsEnumerable;
var uo = (s, e, a) => e in s ? go(s, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: a
    }) : s[e] = a,
    b = (s, e) => {
        for (var a in e || (e = {})) fo.call(e, a) && uo(s, a, e[a]);
        if (Hn)
            for (var a of Hn(e)) mo.call(e, a) && uo(s, a, e[a]);
        return s
    },
    Ee = (s, e) => _r(s, wr(e));
var Wn = (s, e) => {
    var a = {};
    for (var n in s) fo.call(s, n) && e.indexOf(n) < 0 && (a[n] = s[n]);
    if (s != null && Hn)
        for (var n of Hn(s)) e.indexOf(n) < 0 && mo.call(s, n) && (a[n] = s[n]);
    return a
};
var po = (s, e) => co(go(s, "raw", {
    value: co(e || s.slice())
}));
import {
    c as Se,
    j as t,
    M as m,
    e as K,
    a as _t,
    r as w,
    u as pt,
    f as Ke,
    b as Fs,
    E as Is,
    _ as gt,
    m as Sn,
    am as li,
    i as bs,
    L as Rn,
    n as ci,
    a9 as kr,
    d as Er
} from "./fg33krlcm0qyi6yw.js";
import {
    m as Ct,
    AV as ca,
    R as tt,
    tb as Ne,
    oD as di,
    a9 as ne,
    iK as Ln,
    C as Js,
    ih as ui,
    ag as Us,
    a as Nr,
    AW as gi,
    aT as ct,
    i7 as Tr,
    aX as en,
    aR as Q,
    l as Ht,
    aS as ka,
    bh as ft,
    AX as Ar,
    b3 as Ae,
    b as ve,
    AY as Lt,
    AZ as ho,
    cU as $e,
    T as Wt,
    A_ as xo,
    P as Ue,
    A$ as Bs,
    m3 as St,
    jQ as Pr,
    p0 as na,
    jL as Dr,
    mc as Lr,
    br as fi,
    md as Ir,
    B0 as mi,
    ma as La,
    b_ as pi,
    B1 as Rr,
    p as Br,
    B2 as Or,
    B3 as Gs,
    cP as _n,
    yv as Fr,
    e as Ur,
    B4 as Gr,
    B5 as zr,
    f as Hr,
    b7 as Wr,
    cy as hi,
    xS as Vr,
    g$ as xi,
    bp as Ot,
    bT as Ia,
    cz as da,
    H as zs,
    L as vt,
    d as Qe,
    zT as $r,
    bw as bo,
    bU as xs,
    cE as Kr,
    cF as qr,
    cG as nt,
    n_ as ha,
    bQ as ua,
    B6 as bi,
    cx as ea,
    Z as yi,
    S as Mi,
    cI as Yr,
    bR as Ra,
    bW as Ba,
    cR as Bn,
    bE as Oa,
    bZ as bn,
    b4 as Rs,
    n$ as Qr,
    bY as Zr,
    gU as vi,
    o as je,
    gz as Os,
    cu as Xr,
    cw as Jr,
    cv as el,
    bq as rt,
    bt as lt,
    ct as tl,
    cs as sl,
    cr as nl,
    cq as al,
    cp as ol,
    B7 as il,
    c0 as ys,
    wk as rl,
    B8 as ll,
    vN as cl,
    sC as dl,
    hs as Ci,
    i6 as ji,
    d3 as kt,
    ht as ul,
    py as Fa,
    b6 as ie,
    cS as gl,
    nW as Ea,
    cH as Si,
    tN as fl,
    gO as _i,
    gL as aa,
    hA as ml,
    zq as pl,
    ad as Ua,
    u_ as wi,
    rq as Ga,
    B9 as In,
    tO as hl,
    ck as es,
    en as xl,
    g2 as De,
    gJ as ki,
    aY as Ei,
    xt as za,
    nX as Ni,
    lL as bl,
    lM as yl,
    Ba as Ml,
    Bb as vl,
    rr as Cl,
    bX as Ha,
    w4 as Ti,
    Bc as jl,
    Bd as Sl,
    Be as _l,
    Bf as wl,
    Bg as kl,
    bo as Na,
    Bh as Ai,
    Bi as El,
    zU as Nl,
    v0 as Tl,
    Bj as Al,
    Bk as yo,
    eu as Mo,
    Bl as Pl,
    Bm as Dl,
    cA as Ll,
    Bn as vo,
    Bo as Il,
    bm as Rl,
    bn as Ta,
    Bp as Bl,
    so as Wa,
    I as ga,
    Bq as Ol,
    bO as Fl,
    mu as yn,
    F as Ul,
    Br as hs,
    sA as xa,
    bJ as Gl,
    N as zl,
    ga as Hl,
    V as Pi,
    i9 as Wl,
    hv as Vl,
    kS as $l,
    Bs as Kl,
    _ as Zs,
    ly as pn,
    rF as Co,
    hx as ql,
    hw as Yl,
    hy as Ql,
    rY as Zl,
    aD as Xl,
    b1 as Va,
    Bt as Mn,
    b5 as Et,
    gH as Jl,
    fN as ec,
    dB as tc,
    $ as $a,
    aF as sc,
    aG as nc,
    xu as ac,
    fP as oc,
    bv as ic,
    bg as rc,
    n as Xs,
    W as on,
    du as lc,
    Bu as cc,
    M as jo,
    Bv as So,
    y4 as dc,
    mE as uc,
    A as gc,
    Bw as fc,
    dF as mc,
    Bx as pc,
    r5 as hc,
    sy as xc,
    qG as _o,
    c_ as bc,
    By as yc,
    B as Mc,
    aP as vc,
    Bz as Cc,
    BA as jc,
    BB as Sc,
    BC as _c,
    mN as wc,
    BD as kc,
    oJ as Ec,
    aL as Nc,
    BE as Di,
    pt as Tc,
    pu as Ac,
    BF as gs,
    ko as wo,
    kp as ko,
    K as Pc,
    BG as Dc,
    dz as Li,
    fa as Lc,
    b9 as Ic,
    w as fa,
    p1 as ma,
    dg as Rc,
    b2 as Bc,
    mv as Oc,
    bi as Fc,
    z as Eo,
    y as Uc,
    et as Gc,
    my as zc,
    BH as Hc,
    yg as Wc,
    BI as Vc,
    e_ as No,
    ac as $c,
    ke as To,
    BJ as Kc,
    oX as qc,
    oW as Yc,
    oY as Ao,
    BK as Po,
    hd as Do
} from "./dykg4ktvbu3mhmdo.js";
import {
    z as Ka,
    jR as On,
    d4 as Ii,
    cy as Qc,
    dG as Fn,
    ao as Ri,
    CL as qa,
    c9 as Zc,
    CM as Xc,
    p$ as Bi,
    kA as Jc,
    nn as oa,
    wZ as wn,
    fn as Un,
    qs as Oi,
    rc as kn,
    fx as vn,
    b0 as hn,
    sT as ed,
    Ab as td,
    Aa as sd,
    w_ as Fi,
    de as Dn,
    jC as nd,
    CN as ad,
    jB as Pn,
    CO as od,
    CP as id,
    dP as rd,
    y as Ui,
    d0 as ld,
    d1 as cd,
    d2 as dd,
    CQ as Gi,
    da as ud,
    ie as gd,
    cx as Ya,
    iH as fd,
    CR as md,
    CS as Lo,
    CT as pd,
    CU as hd,
    CV as ta,
    j9 as xd,
    ex as bd,
    cr as yd,
    fB as Md,
    e7 as vd,
    dg as Aa,
    ir as Cd,
    is as Io,
    m_ as Ro,
    iw as jd,
    zQ as zi,
    A3 as Sd,
    A4 as _d,
    zx as wd,
    cV as Qa,
    fU as ba,
    cw as Hi,
    zU as kd,
    zT as Ed,
    cg as Nd,
    gQ as Td,
    u_ as Ad,
    BN as Pd,
    BM as Dd,
    c$ as Ld,
    CW as Id,
    BI as Wi,
    d9 as Rd,
    cD as Y,
    CX as Bd,
    cP as Od,
    fX as Fd,
    dX as Ud,
    CY as Gd,
    d5 as zd,
    fT as Hd,
    CZ as Za,
    d6 as Wd,
    C_ as Vi,
    C$ as $i,
    q0 as Vd,
    jo as $d,
    D0 as Kd,
    D1 as Ki,
    D2 as qi,
    jl as qd,
    q4 as Yd,
    D3 as Yi,
    D4 as Bo,
    D5 as Qi,
    D6 as Qd,
    D7 as Re,
    D8 as Zd,
    D9 as Xd,
    Da as fn,
    Db as Jd,
    Dc as eu,
    Dd as Pa,
    De as tu,
    nJ as su,
    Df as nu,
    Dg as au,
    Dh as ou,
    dM as Vn,
    Di as $n,
    Dj as iu,
    qg as Zi,
    gH as ru,
    gI as lu,
    Dk as cu,
    Dl as du,
    kn as uu,
    cX as gu,
    cb as Xi,
    Dm as fu,
    CB as mu,
    gA as pu,
    ic as hu,
    qu as xu,
    Dn as bu,
    an as fs
} from "./k15yxxoybkkir2ou.js";
import {
    E as yu
} from "./jdg49hmintmo4ij6.js";
import {
    E as Mu,
    A as vu
} from "./gzhsdx8lam3386fv.js";
import {
    l as Cu
} from "./uwm5r01je8eaqgfc.js";
import {
    m as Pe,
    a as Ji,
    u as er,
    M as ju,
    C as Su
} from "./newet32g44ysnvsb.js";
import {
    a as _u
} from "./jdzosouyvpzu0tpb.js";
import {
    G as wu
} from "./lcm07h4hrgbddd47.js";
import {
    C as ku
} from "./22dgvhxdlo5c1yiw.js";
import {
    O as Eu
} from "./lqog7ixiwnif6sbp.js";
import {
    S as Nu
} from "./nzl91iujqafxz8y1.js";
import {
    U as Tu
} from "./k78yzov06lrhyte9.js";
import {
    E as Au
} from "./jhvz2qkf3st8xisu.js";
import {
    C as Pu
} from "./cfxpg7jffbmx1lzc.js";
import {
    g as Du
} from "./kk75394dp7aj1ofk.js";
import {
    g as Lu,
    h as tr
} from "./jd9zt1u141h04j00.js";
import {
    c as sr,
    a as nr,
    b as Iu
} from "./hfibvokhkz8skuqw.js";
import {
    P as Ru
} from "./mtdf3zn500avq96a.js";
import {
    u as Bu
} from "./emixct2ecmtx0izd.js";
import {
    a as Ou
} from "./ml3sfbo53uz391cc.js";
import {
    u as ar,
    M as Oo,
    a as ya,
    b as Fu
} from "./elwpnpvd3n8263yf.js";
import {
    G as Uu,
    E as Gu,
    M as zu
} from "./jjruw0pg8h58hov8.js";
import {
    b as Hu
} from "./cgt1h5qo3k52ojx3.js";
import Wu from "./bmupik4h4l2k89rq.js";
import {
    s as Vu
} from "./flbjosd8n90k89o3.js";
import {
    L as $u
} from "./jnh7gh80gtj0452q.js";

function ia() {
    "use forget";
    const s = Se.c(1);
    let e;
    return s[0] === Symbol.for("react.memo_cache_sentinel") ? (e = t.jsx("span", {
        className: "bg-token-interactive-bg-accent-default flex items-center gap-1 rounded-full px-2.5 py-1.5 text-xs text-blue-400",
        children: t.jsx(m, {
            id: "GRxNeD",
            defaultMessage: "Parent"
        })
    }), s[0] = e) : e = s[0], e
}

function Ku({
    amphoraId: s,
    invite: e,
    onBack: a
}) {
    var h, y;
    const n = K(),
        o = Ct(),
        i = _t(),
        [c, l] = w.useState(!1),
        [d, r] = w.useState(!1),
        u = pt({
            mutationFn: async () => {
                const x = e.account_identifier,
                    j = e.email ? {
                        email: e.email
                    } : x ? {
                        account_identifier: x
                    } : null;
                if (!j) throw new Error("Missing invite identifier");
                await tt.safePost("/amphora/{amphora_id}/remove", {
                    parameters: {
                        path: {
                            amphora_id: s
                        }
                    },
                    requestBody: j
                })
            },
            onSuccess: async () => {
                await ca(i), a()
            },
            onError: x => {
                const j = x instanceof Error ? x.message : String(x);
                o.danger(n.formatMessage(jt.cancelInviteError, {
                    error: j
                }), {
                    toastId: "amphora_invite_cancel"
                })
            }
        }),
        f = pt({
            mutationFn: async () => {
                var j;
                const x = (j = e.email) != null ? j : e.account_identifier;
                if (!x) throw new Error("Missing invite identifier");
                await tt.safePost("/amphora/{amphora_id}/members/resend", {
                    parameters: {
                        path: {
                            amphora_id: s
                        }
                    },
                    requestBody: {
                        account_identifier: x
                    }
                })
            },
            onSuccess: async () => {
                l(!1), r(!0), o.success(n.formatMessage(jt.resendInviteSuccess)), await i.invalidateQueries({
                    queryKey: ["amphora", s]
                })
            },
            onError: x => {
                const j = x instanceof Error ? x.message : String(x);
                o.danger(n.formatMessage(jt.resendInviteError, {
                    error: j
                }), {
                    toastId: "amphora_invite_resend"
                })
            }
        }),
        p = (y = (h = e.email) != null ? h : e.account_identifier) != null ? y : "",
        g = p || n.formatMessage(jt.missingIdentifier);
    return t.jsxs(Ne, {
        title: t.jsxs("button", {
            "aria-label": n.formatMessage(jt.back),
            onClick: a,
            className: "hover:bg-token-bg-tertiary -ms-3 flex items-center gap-2 rounded-full px-3 py-1",
            children: [t.jsx(On, {
                className: "icon-sm"
            }), t.jsx("span", {
                children: t.jsx(m, b({}, jt.back))
            })]
        }),
        noBorder: !0,
        headerInteractable: !0,
        children: [t.jsx("div", {
            className: "border-token-border-light my-3 rounded-xl border p-4",
            children: t.jsxs("div", {
                className: "flex w-full items-center justify-between",
                children: [t.jsxs("div", {
                    className: "flex items-center gap-3",
                    children: [t.jsx("div", {
                        className: "bg-token-bg-tertiary text-token-text-tertiary flex h-12 w-12 shrink-0 items-center justify-center rounded-full",
                        children: t.jsx(di, {
                            className: "icon-lg"
                        })
                    }), t.jsxs("div", {
                        className: "flex flex-col",
                        children: [t.jsx("div", {
                            className: "text-sm",
                            children: g
                        }), t.jsx("div", {
                            className: "text-token-text-secondary mt-0.5 flex items-center gap-1 text-sm",
                            children: t.jsx("span", {
                                children: t.jsx(m, b({}, jt.invitationSent))
                            })
                        })]
                    })]
                }), e.role === "owner" && t.jsx(ia, {})]
            })
        }), t.jsxs("div", {
            className: "flex flex-col items-start py-6",
            children: [t.jsxs("div", {
                className: "flex gap-3",
                children: [t.jsx(ne, {
                    color: "secondary",
                    onClick: () => l(!0),
                    disabled: f.isPending || u.isPending,
                    children: t.jsx(m, b({}, jt.resendInvite))
                }), t.jsx(ne, {
                    color: "danger-outline",
                    onClick: () => u.mutate(),
                    disabled: u.isPending,
                    children: t.jsx(m, b({}, jt.cancelInvite))
                })]
            }), t.jsx("p", {
                className: "text-token-text-tertiary mt-6 text-sm",
                children: e.role === "owner" ? t.jsx(m, b({}, jt.childLinkParentInviteDescription)) : t.jsx(m, Ee(b({}, jt.learnMoreVesselControls), {
                    values: {
                        LearnMoreLink: t.jsx(Ln, {
                            href: "https://help.openai.com/en/articles/12315553-parental-controls-faq",
                            className: "underline",
                            children: t.jsx(m, {
                                id: "LGjcbz",
                                defaultMessage: "Learn more"
                            })
                        })
                    }
                }))
            })]
        }), t.jsx(Js, {
            testId: "modal-amphora-resend-invite",
            isOpen: c,
            onClose: () => l(!1),
            size: "custom",
            showCloseButton: !0,
            className: "max-w-md text-sm",
            title: n.formatMessage(jt.resendConfirmTitle),
            description: t.jsx("p", {
                children: n.formatMessage(jt.resendConfirmDesc)
            }),
            primaryButton: t.jsx(ne, {
                onClick: () => f.mutate(),
                disabled: f.isPending,
                children: n.formatMessage(jt.resendSendButton)
            }),
            secondaryButton: t.jsx(ne, {
                color: "secondary",
                onClick: () => l(!1),
                children: n.formatMessage(jt.resendCancelButton)
            }),
            children: t.jsx("div", {
                className: "mt-4",
                children: t.jsx(Ka, {
                    name: "identifier",
                    ariaLabel: !1,
                    className: "",
                    type: "text",
                    value: p,
                    disabled: !0,
                    placeholder: ""
                })
            })
        }), t.jsx(Js, {
            testId: "modal-amphora-resend-invite-success",
            isOpen: d,
            onClose: () => r(!1),
            size: "custom",
            showCloseButton: !0,
            className: "max-w-md text-sm",
            title: n.formatMessage(jt.resendSentTitle),
            description: t.jsx("p", {
                children: n.formatMessage(jt.resendSentDesc, {
                    identifier: p
                })
            }),
            primaryButton: t.jsx(ne, {
                onClick: () => r(!1),
                children: n.formatMessage(jt.doneButton)
            })
        })]
    })
}
const jt = Ke({
    back: {
        id: "amphora.invited.back",
        defaultMessage: "Back"
    },
    invitationSent: {
        id: "amphora.invited.status.sent",
        defaultMessage: "Invitation sent"
    },
    cancelInvite: {
        id: "amphora.invited.cancel",
        defaultMessage: "Cancel invitation"
    },
    cancelInviteError: {
        id: "amphora.invited.cancel.error",
        defaultMessage: "Unable to cancel invite: {error}"
    },
    resendInvite: {
        id: "amphora.invited.resend",
        defaultMessage: "Resend invitation"
    },
    resendInviteError: {
        id: "amphora.invited.resend.error",
        defaultMessage: "Unable to resend invite: {error}"
    },
    resendInviteSuccess: {
        id: "amphora.invited.resend.success",
        defaultMessage: "Invitation sent"
    },
    resendConfirmTitle: {
        id: "amphora.invited.resend.confirmTitle",
        defaultMessage: "Resend invitation"
    },
    resendConfirmDesc: {
        id: "amphora.invited.resend.confirmDesc",
        defaultMessage: "We’ll send another invite to your family member. If they’re new to ChatGPT, they’ll be asked to create an account."
    },
    resendCancelButton: {
        id: "amphora.invited.resend.cancel",
        defaultMessage: "Cancel"
    },
    resendSendButton: {
        id: "amphora.invited.resend.send",
        defaultMessage: "Send"
    },
    resendSentTitle: {
        id: "amphora.invited.resend.sentTitle",
        defaultMessage: "Sent!"
    },
    resendSentDesc: {
        id: "amphora.invited.resend.sentDesc",
        defaultMessage: "We sent {identifier} a new invite. If they’re new to ChatGPT, they’ll be asked to create a new account."
    },
    doneButton: {
        id: "amphora.invited.done",
        defaultMessage: "Done"
    },
    missingIdentifier: {
        id: "amphora.invited.missingIdentifier",
        defaultMessage: "[missing]"
    },
    learnMoreVesselControls: {
        id: "amphora.invited.learnMoreVesselControls2",
        defaultMessage: "{LearnMoreLink} about parental controls"
    },
    childLinkParentInviteDescription: {
        id: "amphora.invited.childLinkParentInviteDescription",
        defaultMessage: "You can link to one parent at a time."
    }
});

function Xa(s) {
    "use forget";
    var h;
    const e = Se.c(22),
        {
            user: a
        } = s,
        n = K();
    let o;
    e[0] !== n || e[1] !== a.email || e[2] !== a.name ? (o = a.name || a.email || n.formatMessage({
        id: "VB4+Q+",
        defaultMessage: "Member"
    }), e[0] = n, e[1] = a.email, e[2] = a.name, e[3] = o) : o = e[3];
    const i = o,
        c = (h = a.profile_picture_url) != null ? h : void 0;
    let l;
    e[4] !== i || e[5] !== c ? (l = t.jsx(ui, {
        user: {
            picture: c,
            name: i
        },
        size: "large"
    }), e[4] = i, e[5] = c, e[6] = l) : l = e[6];
    let d;
    e[7] !== i ? (d = t.jsx("div", {
        className: "text-token-text-primary",
        children: i
    }), e[7] = i, e[8] = d) : d = e[8];
    let r;
    e[9] !== a.email ? (r = a.email ? t.jsx("div", {
        className: "text-token-text-secondary",
        children: a.email
    }) : null, e[9] = a.email, e[10] = r) : r = e[10];
    let u;
    e[11] !== d || e[12] !== r ? (u = t.jsxs("div", {
        className: "flex flex-col truncate text-sm",
        children: [d, r]
    }), e[11] = d, e[12] = r, e[13] = u) : u = e[13];
    let f;
    e[14] !== l || e[15] !== u ? (f = t.jsxs("div", {
        className: "flex items-center gap-3",
        children: [l, u]
    }), e[14] = l, e[15] = u, e[16] = f) : f = e[16];
    let p;
    e[17] !== a.role ? (p = a.role === "owner" && t.jsx(ia, {}), e[17] = a.role, e[18] = p) : p = e[18];
    let g;
    return e[19] !== f || e[20] !== p ? (g = t.jsx("div", {
        className: "border-token-border-light my-3 rounded-xl border p-4",
        children: t.jsxs("div", {
            className: "flex items-center justify-between gap-3",
            children: [f, p]
        })
    }), e[19] = f, e[20] = p, e[21] = g) : g = e[21], g
}

function qu(s, e = void 0, a = void 0) {
    return Fs({
        queryKey: ["amphora", s, a ? a.join(",") : void 0],
        queryFn: async () => await tt.safeGet("/amphora/{amphora_id}/members", {
            parameters: {
                path: {
                    amphora_id: s
                }
            }
        }),
        placeholderData: e,
        enabled: !!s
    })
}
const Ma = {
        U18_MODEL_INSTRUCTIONS_ENABLED: ["3VyEPC5dTP_model_instructions_enabled"],
        TRAINING_ALLOWED: ["training_allowed"],
        MEMORY: ["sunshine", "moonshine"]
    },
    Ja = s => Array.isArray(s);

function Yu(s, e, a) {
    var n;
    if (Ja(e)) {
        for (const o of e)
            if ((a == null ? void 0 : a[o]) === !0) return !0;
        return !1
    }
    return (n = s == null ? void 0 : s.includes(e)) != null ? n : !1
}

function Qu(s, e) {
    var n;
    const a = (n = s == null ? void 0 : s.amphora_locks) != null ? n : void 0;
    if (!a) return !1;
    if (Ja(e)) {
        for (const o of e)
            if (a[o] === !0) return !0;
        return !1
    }
    return a[e] === !0
}
var or = (s => (s.Toggle = "toggle", s.Blackout = "blackout", s))(or || {});

function Zu(s) {
    if (typeof s != "object" || s === null) return !1;
    const e = s,
        {
            pages: a,
            root_page_id: n
        } = e;
    return !(!Array.isArray(a) || typeof n != "string")
}

function Xu(s) {
    if (!Zu(s)) throw new Error("Invalid amphora settings layout response");
    return s
}
const Ju = tt.safeGet.bind(tt),
    Jt = Ke({
        modelPolicyLabel: {
            id: "amphora.permissions.modelPolicyLabel",
            defaultMessage: "Model policy"
        },
        personalizationLabel: {
            id: "amphora.permissions.personalizationLabel",
            defaultMessage: "Memory"
        },
        dataControlsLabel: {
            id: "amphora.permissions.dataControlsLabel",
            defaultMessage: "Training"
        },
        VyEPC5dTPModelPolicyLabel: {
            id: "amphora.permissions.VyEPC5dTPModelPolicyLabel3",
            defaultMessage: "Reduce sensitive content"
        },
        u18Explainer: {
            id: "amphora.permissions.u18Explainer3",
            defaultMessage: "Add extra safeguards to help protect teens. {LearnMoreLink}"
        },
        VyEPC5dTPModelPolicyAria: {
            id: "amphora.permissions.VyEPC5dTPModelPolicyAria2",
            defaultMessage: "Enable teen-safe model policy for {email}"
        },
        referenceMemoriesLabel: {
            id: "amphora.permissions.referenceMemoriesLabel",
            defaultMessage: "Reference saved memories"
        },
        referenceMemoriesAria: {
            id: "amphora.permissions.referenceMemoriesAria",
            defaultMessage: "Allow referencing saved memories for {email}"
        },
        improveModelLabel: {
            id: "amphora.permissions.improveModelLabel",
            defaultMessage: "Improve the model for everyone"
        },
        improveModelAria: {
            id: "amphora.permissions.improveModelAria",
            defaultMessage: "Allow improving the model for everyone for {email}"
        },
        parentalControlsTab: {
            id: "settingsModal.parentalControlsTab",
            defaultMessage: "Parental controls"
        },
        removeMemberError: {
            id: "amphora.members.removeMemberError",
            defaultMessage: "Unable to remove member: {error}"
        }
    });
Jt.modelPolicyLabel, Ma.U18_MODEL_INSTRUCTIONS_ENABLED, Jt.VyEPC5dTPModelPolicyLabel, Jt.VyEPC5dTPModelPolicyAria, Jt.u18Explainer, Jt.personalizationLabel, Ma.MEMORY, Jt.referenceMemoriesLabel, Jt.referenceMemoriesAria, Jt.dataControlsLabel, Ma.TRAINING_ALLOWED, Jt.improveModelLabel, Jt.improveModelAria;

function eg(s) {
    const e = K(),
        a = Ct(),
        n = _t();
    return pt({
        mutationFn: ({
            userId: o,
            permissions: i
        }) => tt.safePost("/amphora/{amphora_id}/members/{user_id}/permissions", {
            parameters: {
                path: {
                    amphora_id: s,
                    user_id: o
                }
            },
            requestBody: {
                permissions: i
            }
        }),
        onMutate: async ({
            userId: o,
            permissions: i
        }) => {
            const c = ["amphora", s, o, "permissions"];
            await n.cancelQueries({
                queryKey: c
            });
            const l = n.getQueryData(c);
            return n.setQueryData(c, d => Ee(b({}, d), {
                permissions: i
            })), {
                queryKey: c,
                previous: l
            }
        },
        onError: o => {
            a.danger(e.formatMessage({
                id: "amphora.permissions.updatePermissionError",
                defaultMessage: "Unable to update permissions: {error}"
            }, {
                error: o.message
            }))
        },
        onSettled: (o, i, c, l) => {
            const d = c == null ? void 0 : c.userId,
                r = l == null ? void 0 : l.queryKey,
                u = Array.isArray(r) ? r : d ? ["amphora", s, d, "permissions"] : void 0;
            i && l && l.previous && Array.isArray(u) && n.setQueryData(u, l.previous), d && n.invalidateQueries({
                queryKey: ["amphora", s, d, "permissions"]
            })
        }
    })
}

function ir(s) {
    const e = K(),
        a = Ct(),
        n = _t(),
        o = Us();
    return pt({
        mutationFn: ({
            userId: i,
            feature: c,
            value: l
        }) => tt.safePatch("/amphora/{amphora_id}/members/{user_id}/settings", {
            parameters: {
                path: {
                    amphora_id: s,
                    user_id: i
                }
            },
            requestBody: {
                feature: c,
                value: l
            }
        }),
        onMutate: async ({
            userId: i,
            feature: c,
            value: l
        }) => {
            const d = ["amphora", s, i, "permissions"];
            await n.cancelQueries({
                queryKey: d
            });
            const r = n.getQueryData(d);
            return n.setQueryData(d, u => {
                var p;
                const f = (p = u == null ? void 0 : u.settings) != null ? p : {};
                return Ee(b({}, u), {
                    settings: Ee(b({}, f), {
                        [c]: l
                    })
                })
            }), {
                queryKey: d,
                previous: r
            }
        },
        onError: i => {
            a.danger(e.formatMessage({
                id: "amphora.permissions.updatePermissionError",
                defaultMessage: "Unable to update permissions: {error}"
            }, {
                error: i.message
            }))
        },
        onSettled: (i, c, l) => {
            const d = l == null ? void 0 : l.userId;
            d && n.invalidateQueries({
                queryKey: ["amphora", s, d, "permissions"]
            }), d && (o != null && o.id) && d === o.id && n.invalidateQueries(Nr())
        }
    })
}

function tg(s, e, a) {
    const n = Array.isArray(s) ? s : [];
    return a ? Array.from(new Set([...n, e])) : n.filter(o => o !== e)
}

function sg(s, e, a) {
    const n = [];
    for (const o of e)(s == null ? void 0 : s[o]) === !0 !== a && n.push({
        feature: o,
        value: a
    });
    return n
}

function ng(s) {
    const {
        memberId: e,
        currentPerms: a,
        currentSettings: n,
        toggleKey: o,
        enabled: i,
        updatePermission: c,
        patchSetting: l
    } = s;
    if (Ja(o)) {
        const r = sg(n, o, i);
        for (const u of r) l({
            userId: e,
            feature: u.feature,
            value: u.value
        });
        return
    }
    const d = tg(a, o, i);
    c({
        userId: e,
        permissions: d
    })
}

function ag(s) {
    const e = eg(s),
        a = ir(s);
    return {
        triggerToggle: n => ng(Ee(b({}, n), {
            updatePermission: e.mutate,
            patchSetting: a.mutate
        }))
    }
}

function eo(s) {
    const e = K(),
        a = Ct(),
        n = _t();
    return pt({
        mutationFn: ({
            userId: o
        }) => tt.safePost("/amphora/{amphora_id}/remove", {
            parameters: {
                path: {
                    amphora_id: s
                }
            },
            requestBody: {
                user_id: o
            }
        }).catch(i => {
            a.danger(e.formatMessage(Jt.removeMemberError, {
                error: i.message
            }), {
                toastId: "amphora_member_remove"
            })
        }),
        onSuccess: (o, {
            userId: i
        }) => {
            n.removeQueries({
                predicate: ({
                    queryKey: c
                }) => !Array.isArray(c) || c[0] !== "amphora" || c[1] !== s || c.length !== 4 || c[3] !== "permissions" ? !1 : c[2] === i
            })
        }
    })
}

function og(s) {
    const {
        data: e,
        isLoading: a,
        error: n
    } = qu(s);
    return {
        members: w.useMemo(() => {
            var c;
            const i = (c = e == null ? void 0 : e.items) != null ? c : [];
            return Array.isArray(i) ? i.filter(l => typeof l == "object" && l != null && "status" in l).filter(l => l.status === "accepted").filter(l => typeof l.user_id == "string") : []
        }, [e]),
        isLoading: a,
        error: n,
        raw: e
    }
}

function ig(s, e) {
    return Fs({
        queryKey: ["amphora", s, e, "permissions"],
        queryFn: () => tt.safeGet("/amphora/{amphora_id}/members/{user_id}/settings", {
            parameters: {
                path: {
                    amphora_id: s,
                    user_id: e
                }
            }
        }),
        enabled: !!(s && e)
    })
}

function rg() {
    return Fs({
        queryKey: ["amphora", "settings_layout"],
        queryFn: async () => {
            const s = await Ju("/amphora/settings_layout");
            return Xu(s)
        }
    })
}

function lg({
    amphoraId: s,
    member: e,
    onBack: a
}) {
    const n = K(),
        o = Us(),
        i = gi(),
        c = eo(s),
        l = _t(),
        d = (i == null ? void 0 : i.role) === "member_role",
        r = e.role === "member_role",
        u = !(d && r),
        f = u ? "text-token-text-secondary pt-6 text-sm" : "text-token-text-secondary text-sm",
        p = async () => {
            if (!(!(o != null && o.id) || !window.confirm(n.formatMessage(An.unlinkConfirm)))) try {
                await c.mutateAsync({
                    userId: o.id
                }), await ca(l), a()
            } catch (h) {}
        };
    return t.jsxs(Ne, {
        title: t.jsxs("button", {
            "aria-label": n.formatMessage(An.back),
            onClick: a,
            className: "hover:bg-token-bg-tertiary -ms-3 flex items-center gap-2 rounded-full px-3 py-1",
            children: [t.jsx(On, {
                className: "icon-sm"
            }), t.jsx("span", {
                children: t.jsx(m, b({}, An.back))
            })]
        }),
        noBorder: !0,
        headerInteractable: !0,
        children: [t.jsx(Xa, {
            user: e
        }), t.jsxs("div", {
            className: "flex flex-col items-start py-3",
            children: [u ? t.jsx(ne, {
                color: "danger-outline",
                disabled: c.isPending || !(o != null && o.id),
                onClick: p,
                children: t.jsx(m, b({}, An.unlinkButton))
            }) : null, t.jsx("p", {
                className: f,
                children: n.formatMessage(An.helpCenterParagraph)
            })]
        })]
    })
}
const An = Ke({
    back: {
        id: "amphora.relationship.back",
        defaultMessage: "Back"
    },
    relationshipDescription: {
        id: "amphora.relationship.description",
        defaultMessage: "When your account is linked to a guardian, they can manage certain privacy and content settings for you. They won't have access to your chats, but they'll be notified if we detect conversations with ChatGPT that may put your safety at risk."
    },
    unlinkButton: {
        id: "amphora.relationship.unlinkButton",
        defaultMessage: "Unlink accounts"
    },
    unlinkConfirm: {
        id: "amphora.relationship.unlinkConfirm",
        defaultMessage: "Are you sure you want to unlink your accounts?"
    },
    unknownMember: {
        id: "amphora.relationship.unknownMember",
        defaultMessage: "Member"
    },
    helpCenterParagraph: {
        id: "amphora.relationship.helpCenterParagraph2",
        defaultMessage: "You can link one parent at a time."
    }
});

function Fo(s) {
    "use forget";
    const e = Se.c(12),
        {
            valueMinutes: a,
            disabled: n,
            onChange: o
        } = s,
        i = K();
    let c;
    e[0] !== i ? (c = h => {
        const y = Math.max(0, Math.min(1439, h | 0)),
            x = new Date;
        return x.setHours(Math.floor(y / 60), y % 60, 0, 0), i.formatDate(x, {
            hour: "numeric",
            minute: "2-digit"
        })
    }, e[0] = i, e[1] = c) : c = e[1];
    const l = c;
    let d;
    e[2] === Symbol.for("react.memo_cache_sentinel") ? (d = Array.from({
        length: 48
    }), e[2] = d) : d = e[2];
    let r;
    e[3] !== l ? (r = d.map((h, y) => {
        const x = y * 30;
        return {
            label: l(x),
            value: String(x)
        }
    }), e[3] = l, e[4] = r) : r = e[4];
    const u = r,
        f = String(Math.max(0, Math.min(1439, a | 0)));
    let p;
    e[5] !== o ? (p = h => o(Number(h)), e[5] = o, e[6] = p) : p = e[6];
    let g;
    return e[7] !== n || e[8] !== u || e[9] !== f || e[10] !== p ? (g = t.jsx(Ii, {
        options: u,
        value: f,
        disabled: n,
        onValueChange: p,
        triggerClassName: "text-token-text-primary",
        contentClassName: "min-w-[var(--radix-select-trigger-width)]!",
        triggerId: "time-picker"
    }), e[7] = n, e[8] = u, e[9] = f, e[10] = p, e[11] = g) : g = e[11], g
}

function cg({
    enabled: s,
    disabled: e,
    startMinutes: a,
    endMinutes: n,
    onToggle: o,
    onStartChange: i,
    onEndChange: c
}) {
    const l = K();
    return t.jsxs(t.Fragment, {
        children: [t.jsx(ct, {
            label: l.formatMessage(sn.blackoutHoursLabel),
            description: l.formatMessage(sn.blackoutHoursDescription),
            enabled: s,
            disabled: e,
            onChange: o,
            ariaLabel: l.formatMessage(sn.blackoutHoursLabelAria)
        }), s ? t.jsxs("div", {
            className: "flex flex-col gap-1",
            children: [t.jsxs("div", {
                className: "flex w-full items-center justify-between",
                children: [t.jsxs("span", {
                    className: "text-token-text-primary inline-flex items-center gap-1.5 text-sm",
                    children: [t.jsx(Qc, {
                        className: "icon-sm"
                    }), l.formatMessage(sn.startLabel)]
                }), t.jsx(Fo, {
                    label: t.jsx("span", {
                        className: "sr-only",
                        children: l.formatMessage(sn.startLabel)
                    }),
                    valueMinutes: a,
                    disabled: e,
                    onChange: i
                })]
            }), t.jsxs("div", {
                className: "flex w-full items-center justify-between",
                children: [t.jsxs("span", {
                    className: "text-token-text-primary inline-flex items-center gap-1.5 text-sm",
                    children: [t.jsx(Tr, {
                        className: "icon-sm"
                    }), l.formatMessage(sn.endLabel)]
                }), t.jsx(Fo, {
                    label: t.jsx("span", {
                        className: "sr-only",
                        children: l.formatMessage(sn.endLabel)
                    }),
                    valueMinutes: n,
                    disabled: e,
                    onChange: c
                })]
            })]
        }) : null]
    })
}
const sn = Ke({
        blackoutHoursLabel: {
            id: "amphora.permissions.blackoutHoursLabel",
            defaultMessage: "Quiet hours"
        },
        blackoutHoursDescription: {
            id: "amphora.permissions.blackoutHoursDescription",
            defaultMessage: "Schedule hours when ChatGPT can't be used."
        },
        blackoutHoursLabelAria: {
            id: "amphora.permissions.blackoutHoursLabelAria",
            defaultMessage: "Quiet hours"
        },
        startLabel: {
            id: "amphora.permissions.blackout.start",
            defaultMessage: "Start time"
        },
        endLabel: {
            id: "amphora.permissions.blackout.end",
            defaultMessage: "End time"
        }
    }),
    Uo = 1320,
    Go = 360,
    ra = (s, e, a) => Math.min(a, Math.max(e, s | 0)),
    Kn = (s, e = 0) => {
        if (!s) return e;
        const [a, n] = s.split(":").map(o => parseInt(o, 10) || 0);
        return ra(a, 0, 23) * 60 + ra(n, 0, 59)
    },
    zo = s => {
        const e = ra(Math.floor(s / 60), 0, 23),
            a = ra(s % 60, 0, 59);
        return "".concat(String(e).padStart(2, "0"), ":").concat(String(a).padStart(2, "0"))
    };

function dg(s) {
    "use forget";
    var _, D;
    const e = Se.c(28),
        {
            disabled: a,
            userId: n,
            currentBlackout: o,
            featureKey: i,
            onPatch: c
        } = s,
        [l, d] = Is.useState(typeof(o == null ? void 0 : o.enabled) == "boolean" ? o.enabled : !1),
        r = o == null ? void 0 : o.start_time;
    let u;
    e[0] !== r ? (u = Kn(r, Uo), e[0] = r, e[1] = u) : u = e[1];
    const [f, p] = Is.useState(u), g = o == null ? void 0 : o.end_time;
    let h;
    e[2] !== g ? (h = Kn(g, Go), e[2] = g, e[3] = h) : h = e[3];
    const [y, x] = Is.useState(h), j = o == null ? void 0 : o.enabled, v = (_ = o == null ? void 0 : o.start_time) != null ? _ : null, S = (D = o == null ? void 0 : o.end_time) != null ? D : null;
    let C, M;
    e[4] !== j || e[5] !== S || e[6] !== v ? (C = () => {
        d(!!j), p(Kn(v, Uo)), x(Kn(S, Go))
    }, M = [j, v, S], e[4] = j, e[5] = S, e[6] = v, e[7] = C, e[8] = M) : (C = e[7], M = e[8]), Is.useEffect(C, M);
    let E;
    e[9] !== y || e[10] !== i || e[11] !== c || e[12] !== f || e[13] !== n ? (E = T => {
        const {
            nextEnabled: F,
            nextStartMinutes: O,
            nextEndMinutes: I
        } = T, U = O === void 0 ? f : O, R = I === void 0 ? y : I, B = zo(U), z = zo(R);
        c({
            userId: n,
            feature: i,
            value: {
                enabled: F,
                start_time: F ? B : null,
                end_time: F ? z : null
            }
        })
    }, e[9] = y, e[10] = i, e[11] = c, e[12] = f, e[13] = n, e[14] = E) : E = e[14];
    const N = en(E);
    let k, P, L;
    e[15] !== a || e[16] !== N ? (P = T => {
        d(T), a || N({
            nextEnabled: T
        })
    }, L = T => {
        p(T), a || N({
            nextEnabled: !0,
            nextStartMinutes: T
        })
    }, k = T => {
        x(T), a || N({
            nextEnabled: !0,
            nextEndMinutes: T
        })
    }, e[15] = a, e[16] = N, e[17] = k, e[18] = P, e[19] = L) : (k = e[17], P = e[18], L = e[19]);
    let A;
    return e[20] !== a || e[21] !== l || e[22] !== y || e[23] !== f || e[24] !== k || e[25] !== P || e[26] !== L ? (A = t.jsx(cg, {
        enabled: l,
        disabled: a,
        startMinutes: f,
        endMinutes: y,
        onToggle: P,
        onStartChange: L,
        onEndChange: k
    }), e[20] = a, e[21] = l, e[22] = y, e[23] = f, e[24] = k, e[25] = P, e[26] = L, e[27] = A) : A = e[27], A
}

function rr(s, e) {
    const a = typeof s == "string" ? s.trim() : "";
    if (a) return e ? t.jsxs(t.Fragment, {
        children: [a, " ", t.jsx(Ln, {
            href: e.href,
            className: "underline",
            children: e.label
        })]
    }) : a
}

function ug(s) {
    return s.kind === "setting" ? s.settings : s.permission
}

function gg(s) {
    return s.toggle_type === or.Blackout && s.kind === "setting"
}

function fg({
    pages: s,
    rootPageId: e,
    onBack: a
}) {
    const n = w.useMemo(() => {
            const p = new Map;
            for (const g of s) p.set(g.id, g);
            return p
        }, [s]),
        o = w.useMemo(() => {
            var p;
            if (s.length) return e && n.has(e) ? e : (p = s[0]) == null ? void 0 : p.id
        }, [n, s, e]),
        [i, c] = w.useState(() => o ? [o] : []);
    w.useEffect(() => {
        if (!o) {
            c([]);
            return
        }
        c(p => {
            if (!p.length) return [o];
            const g = new Set(s.map(x => x.id));
            if (g.size === 0) return [];
            const h = [o];
            for (const x of p.slice(1)) g.has(x) && h.push(x);
            return h.length === p.length && h.every((x, j) => x === p[j]) ? p : h
        })
    }, [o, s]);
    const l = i.length > 0 ? i[i.length - 1] : o,
        d = l ? n.get(l) : void 0,
        r = i.length > 1,
        u = w.useCallback(() => {
            c(p => p.length > 1 ? p.slice(0, -1) : (a(), p))
        }, [a]),
        f = w.useCallback(p => {
            !p || !n.has(p) || c(g => g[g.length - 1] === p ? g : [...g, p])
        }, [n]);
    return {
        activePageId: l,
        activePage: d,
        isSubPageActive: r,
        goBack: u,
        goToPage: f
    }
}

function mg(s, e) {
    return s.type === "toggle" ? "".concat(e != null ? e : "member", "-").concat(s.id) : "nav-item-".concat(s.id)
}

function pg(s, e, a) {
    var r, u;
    if (s.kind === "setting" && s.settings.length === 0) return null;
    const {
        memberId: n,
        isPermissionsLoading: o
    } = e, i = ug(s), c = Qu(e.currentSettings, i), l = e.isSelf && c, d = o || !n || l;
    if (gg(s)) {
        const f = s.settings[0];
        if (!f || !n) return null;
        const p = (u = (r = e.currentSettings) == null ? void 0 : r[f]) != null ? u : {};
        return t.jsx(Q, {
            children: t.jsx(dg, {
                disabled: d,
                userId: n,
                currentBlackout: p,
                featureKey: f,
                onPatch: e.onPatchSetting
            })
        }, a)
    }
    return t.jsx(Q, {
        children: t.jsx(ct, {
            label: s.label,
            description: rr(s.description, s.learn_more),
            enabled: Yu(e.currentPerms, i, e.currentSettings),
            disabled: d,
            onChange: f => {
                !n || l || e.onToggle({
                    memberId: n,
                    currentPerms: e.currentPerms,
                    currentSettings: e.currentSettings,
                    toggleKey: i,
                    enabled: f
                })
            }
        })
    }, a)
}

function hg(s, e, a) {
    return t.jsx(Q, {
        children: t.jsxs("button", {
            type: "button",
            onClick: () => e(s.target_page_id),
            className: "hover:bg-token-bg-tertiary flex w-full items-center justify-between rounded-lg py-2 ps-0 pe-0 text-start transition",
            children: [t.jsxs("span", {
                children: [t.jsx("div", {
                    className: "text-base font-medium",
                    children: s.label
                }), s.description && t.jsx("div", {
                    className: "text-token-text-tertiary text-xs",
                    children: s.description
                })]
            }), t.jsx(ka, {
                className: "icon-sm shrink-0"
            })]
        })
    }, a)
}

function xg({
    amphoraId: s,
    member: e,
    onBack: a
}) {
    var L, A;
    const n = K(),
        o = e.name || e.email || "",
        i = (L = e.user_id) != null ? L : void 0,
        c = Us(),
        {
            data: l,
            isLoading: d
        } = ig(s, i),
        r = l == null ? void 0 : l.permissions,
        u = l == null ? void 0 : l.settings,
        {
            data: f
        } = rg(),
        p = (A = f == null ? void 0 : f.pages) != null ? A : [],
        {
            activePageId: g,
            activePage: h,
            isSubPageActive: y,
            goBack: x,
            goToPage: j
        } = fg({
            pages: p,
            rootPageId: f == null ? void 0 : f.root_page_id,
            onBack: a
        }),
        {
            triggerToggle: v
        } = ag(s),
        {
            mutate: S
        } = ir(s),
        C = eo(s),
        M = _t(),
        E = !!(i && (c != null && c.id) && i === c.id),
        N = w.useMemo(() => ({
            memberId: i,
            isSelf: E,
            isPermissionsLoading: d,
            currentPerms: r,
            currentSettings: u,
            onToggle: v,
            onPatchSetting: S,
            onNavigate: j
        }), [r, u, j, d, E, i, S, v]),
        k = C.isPending,
        P = w.useCallback(async () => {
            if (!i) return;
            const _ = o || n.formatMessage(xn.unlinkFallbackName);
            if (window.confirm(n.formatMessage(xn.unlinkConfirm, {
                    name: _
                }))) try {
                await C.mutateAsync({
                    userId: i
                }), a(), await ca(M)
            } catch (T) {}
        }, [o, n, i, a, M, C]);
    return {
        backLabel: n.formatMessage(xn.back),
        onBackClick: x,
        activePage: h,
        activePageId: g,
        sectionItemContext: N,
        isSubPageActive: y,
        isViewingSelf: E,
        isRemoving: k,
        handleUnlink: P
    }
}

function bg({
    page: s,
    isSubPageActive: e
}) {
    const a = typeof(s == null ? void 0 : s.heading) == "string" ? s.heading.trim() : "",
        n = rr(s == null ? void 0 : s.description, s == null ? void 0 : s.description_learn_more),
        o = a.length > 0,
        i = !!n;
    return !o && !i ? null : t.jsxs(t.Fragment, {
        children: [t.jsx("div", {
            className: "pt-3",
            children: t.jsx(Q, {
                children: t.jsxs("div", {
                    className: "py-2",
                    children: [o && t.jsx("div", {
                        className: "text-base font-medium",
                        children: a
                    }), i && t.jsx("div", {
                        className: "text-token-text-tertiary text-xs",
                        children: n
                    })]
                })
            })
        }), e && t.jsx("hr", {
            className: "border-token-border-light"
        })]
    })
}

function yg({
    page: s,
    context: e,
    fallbackPageId: a
}) {
    var i, c, l;
    const n = (i = s == null ? void 0 : s.sections) != null ? i : [],
        o = (l = (c = s == null ? void 0 : s.id) != null ? c : a) != null ? l : "page";
    return t.jsx(t.Fragment, {
        children: n.map((d, r) => {
            var u;
            return t.jsxs("div", {
                className: Ht({
                    "pt-6": d.extra_top_padding,
                    "pt-3": !d.extra_top_padding && r === 0
                }),
                children: [d.label && t.jsx(Q, {
                    children: t.jsx("div", {
                        className: "mb-1 text-base",
                        children: d.label
                    })
                }), d.items.map(f => {
                    const p = mg(f, e.memberId);
                    return f.type === "toggle" ? pg(f, e, p) : f.type === "navigation" ? hg(f, e.onNavigate, p) : null
                }), t.jsx("hr", {
                    className: "border-token-border-light"
                })]
            }, "".concat(o, "-").concat((u = d.id) != null ? u : r))
        })
    })
}

function Mg({
    amphoraId: s,
    member: e,
    onBack: a
}) {
    const {
        backLabel: n,
        onBackClick: o,
        activePage: i,
        activePageId: c,
        sectionItemContext: l,
        isSubPageActive: d,
        isViewingSelf: r,
        isRemoving: u,
        handleUnlink: f
    } = xg({
        amphoraId: s,
        member: e,
        onBack: a
    }), p = !d, g = p && r && e.role === "member_role";
    return t.jsxs(Ne, {
        title: t.jsxs("button", {
            "aria-label": n,
            onClick: o,
            className: "hover:bg-token-bg-tertiary -ms-3 flex items-center gap-2 rounded-full px-3 py-1",
            children: [t.jsx(On, {
                className: "icon-sm"
            }), t.jsx("span", {
                children: t.jsx(m, b({}, xn.back))
            })]
        }),
        noBorder: !0,
        headerInteractable: !0,
        children: [p && t.jsxs(t.Fragment, {
            children: [t.jsx(Xa, {
                user: e
            }), g && t.jsx(vg, {})]
        }), t.jsx(bg, {
            page: i,
            isSubPageActive: d
        }), t.jsx(yg, {
            page: i,
            context: l,
            fallbackPageId: c
        }), p && t.jsx(ne, {
            color: "danger-outline",
            disabled: u,
            onClick: () => {
                f()
            },
            className: "mt-6",
            children: t.jsx(m, b({}, xn.unlinkButton))
        })]
    })
}

function vg() {
    "use forget";
    const s = Se.c(1);
    let e;
    return s[0] === Symbol.for("react.memo_cache_sentinel") ? (e = t.jsx("div", {
        className: "bg-token-bg-tertiary text-token-text-secondary mt-6 mb-3 flex items-center rounded-xl border-none p-3 text-xs",
        children: t.jsx(m, b({}, xn.childInformationalBanner))
    }), s[0] = e) : e = s[0], e
}
const xn = Ke({
    back: {
        id: "settingsModal.back",
        defaultMessage: "Back"
    },
    unlinkButton: {
        id: "amphora.memberSettings.unlinkButton",
        defaultMessage: "Unlink accounts"
    },
    unlinkConfirm: {
        id: "amphora.memberSettings.unlinkConfirm",
        defaultMessage: "Remove {name} from this family group?"
    },
    unlinkFallbackName: {
        id: "amphora.memberSettings.unlinkFallbackName",
        defaultMessage: "this member"
    },
    childInformationalBanner: {
        id: "amphora.memberSettings.childInformationalBanner",
        defaultMessage: "Your parent or guardian can adjust these settings to help guide how you use ChatGPT and Sora."
    }
});

function Cg({
    amphoraId: s,
    selectedParent: e,
    onBack: a
}) {
    const n = K(),
        o = Us(),
        i = eo(s),
        c = _t(),
        l = i.isPending,
        d = async () => {
            const r = o == null ? void 0 : o.id;
            if (!(!r || !window.confirm(n.formatMessage(qn.leaveConfirm)))) try {
                await i.mutateAsync({
                    userId: r
                }), await ca(c), a()
            } catch (f) {}
        };
    return t.jsxs(Ne, {
        title: t.jsxs("button", {
            "aria-label": n.formatMessage(qn.back),
            onClick: a,
            className: "hover:bg-token-bg-tertiary -ms-3 flex items-center gap-2 rounded-full px-3 py-1",
            children: [t.jsx(On, {
                className: "icon-sm"
            }), t.jsx("span", {
                children: t.jsx(m, b({}, qn.back))
            })]
        }),
        noBorder: !0,
        headerInteractable: !0,
        children: [t.jsx(Xa, {
            user: e
        }), t.jsxs("div", {
            className: "flex w-full flex-col items-start gap-3 py-3",
            children: [t.jsx(ne, {
                color: "danger-outline",
                disabled: l,
                onClick: d,
                children: t.jsx(m, b({}, qn.removeFromFamilyButton))
            }), t.jsx("p", {
                className: "text-token-text-secondary py-3 text-xs",
                children: t.jsx(m, {
                    id: "jNO9yz",
                    defaultMessage: "{LearnMoreLink} about parental controls",
                    values: {
                        LearnMoreLink: t.jsx(Ln, {
                            href: "https://help.openai.com/en/articles/12315553-parental-controls-faq",
                            className: "underline",
                            children: t.jsx(m, {
                                id: "0M5wS5",
                                defaultMessage: "Learn more"
                            })
                        })
                    }
                })
            })]
        })]
    })
}
const qn = Ke({
        back: {
            id: "amphora.parent.back",
            defaultMessage: "Back"
        },
        parentBadge: {
            id: "amphora.parent.badge",
            defaultMessage: "Parent"
        },
        removeFromFamilyButton: {
            id: "amphora.parent.removeFromFamily",
            defaultMessage: "Remove from family"
        },
        leaveConfirm: {
            id: "amphora.parent.leaveConfirm",
            defaultMessage: "Are you sure you want to leave this family group?"
        },
        unknownMember: {
            id: "amphora.parent.unknownMember",
            defaultMessage: "Member"
        }
    }),
    jg = ft(() => gt(() =>
        import ("./e6bg0tkkqv946sj3.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8])).then(s => s.AmphoraInviteModal));

function Sg() {
    "use forget";
    var He, Be;
    const s = Se.c(81),
        e = K(),
        a = ve(),
        n = gi(),
        o = Ar(),
        {
            openSettings: i
        } = Fn(),
        c = Sn(),
        l = n == null ? void 0 : n.id;
    let d;
    e: {
        let G;
        if (s[0] !== c.hash) {
            const [be] = c.hash.split("?");
            G = be.split("/"), s[0] = c.hash, s[1] = G
        } else G = s[1];
        const [, se, pe, fe] = G;
        if (se === Ae.ParentalControls && pe === "member" && typeof fe == "string" && fe.length > 0) try {
            d = decodeURIComponent(fe);
            break e
        } catch (be) {
            d = fe;
            break e
        }
        d = null
    }
    const r = d;
    let u;
    s[2] !== o ? (u = o.find(wg), s[2] = o, s[3] = u) : u = s[3];
    const f = u;
    let p;
    e: {
        const G = f == null ? void 0 : f.payload;
        if (!(G != null && G.family_group_id)) {
            p = null;
            break e
        }
        p = G
    }
    const g = p,
        h = (He = f == null ? void 0 : f.id) != null ? He : null,
        [y, x] = w.useState(!1),
        j = Us(),
        [v, S] = w.useState(null);
    let C;
    s[4] !== i || s[5] !== r ? (C = () => {
        r && i(Ae.ParentalControls)
    }, s[4] = i, s[5] = r, s[6] = C) : C = s[6];
    const M = C;
    let E;
    s[7] !== M ? (E = () => {
        S(null), M()
    }, s[7] = M, s[8] = E) : E = s[8];
    const N = E;
    let k, P;
    s[9] !== n || s[10] !== a || s[11] !== y || s[12] !== h || s[13] !== g ? (k = () => {
        n !== void 0 && !(n != null && n.id) && g && !y && (x(!0), ho(a, g, h != null ? h : void 0))
    }, P = [a, n, g, h, y], s[9] = n, s[10] = a, s[11] = y, s[12] = h, s[13] = g, s[14] = k, s[15] = P) : (k = s[14], P = s[15]), w.useEffect(k, P);
    const {
        members: L,
        raw: A,
        isLoading: _
    } = og(l);
    let D;
    s[16] !== L ? (D = L != null ? L : [], s[16] = L, s[17] = D) : D = s[17];
    const T = D,
        O = ((Be = A == null ? void 0 : A.items) != null ? Be : []).filter(_g),
        I = (n == null ? void 0 : n.role) === "owner",
        U = (n == null ? void 0 : n.role) === "member_role";
    let R;
    e: {
        if (I) {
            let se;
            s[18] !== e ? (se = e.formatMessage(zt.addChildCTA), s[18] = e, s[19] = se) : se = s[19], R = se;
            break e
        }
        let G;s[20] !== e ? (G = e.formatMessage(zt.addFamilyMemberCTA), s[20] = e, s[21] = G) : G = s[21],
        R = G
    }
    const B = R,
        z = I && (n != null && n.id) ? "member_role" : void 0;
    let W;
    s[22] !== (n == null ? void 0 : n.id) || s[23] !== a || s[24] !== z ? (W = () => {
        var G;
        $e(a, jg, {
            amphora_id: (G = n == null ? void 0 : n.id) != null ? G : null,
            forceInviteeRole: z
        })
    }, s[22] = n == null ? void 0 : n.id, s[23] = a, s[24] = z, s[25] = W) : W = s[25], n == null || n.id;
    const V = W;
    let J, ce;
    s[26] !== l || s[27] !== T || s[28] !== r ? (J = () => {
        if (!r || !l) return;
        const G = T.find(se => se.user_id === r);
        G && S(se => (se == null ? void 0 : se.type) === "member" && se.member.user_id === G.user_id ? se : {
            type: "member",
            member: G
        })
    }, ce = [l, T, r], s[26] = l, s[27] = T, s[28] = r, s[29] = J, s[30] = ce) : (J = s[29], ce = s[30]), w.useEffect(J, ce);
    let ae, Z;
    if (s[31] !== l || s[32] !== M || s[33] !== _ || s[34] !== T || s[35] !== r ? (ae = () => {
            if (!r || _ || !l) return;
            T.some(se => se.user_id === r) || M()
        }, Z = [M, _, T, r, l], s[31] = l, s[32] = M, s[33] = _, s[34] = T, s[35] = r, s[36] = ae, s[37] = Z) : (ae = s[36], Z = s[37]), w.useEffect(ae, Z), n != null && n.id && v) {
        if (v.type === "parent") {
            let G;
            return s[38] !== n.id || s[39] !== N || s[40] !== v.member ? (G = t.jsx(Cg, {
                amphoraId: n.id,
                selectedParent: v.member,
                onBack: N
            }), s[38] = n.id, s[39] = N, s[40] = v.member, s[41] = G) : G = s[41], G
        }
        if (v.type === "member") {
            let G;
            return s[42] !== n.id || s[43] !== N || s[44] !== v.member ? (G = t.jsx(Mg, {
                amphoraId: n.id,
                member: v.member,
                onBack: N
            }), s[42] = n.id, s[43] = N, s[44] = v.member, s[45] = G) : G = s[45], G
        }
        if (v.type === "relationship") {
            let G;
            return s[46] !== n.id || s[47] !== N || s[48] !== v.member ? (G = t.jsx(lg, {
                amphoraId: n.id,
                member: v.member,
                onBack: N
            }), s[46] = n.id, s[47] = N, s[48] = v.member, s[49] = G) : G = s[49], G
        }
        if (v.type === "invite") {
            let G;
            return s[50] !== n.id || s[51] !== N || s[52] !== v.invite ? (G = t.jsx(Ku, {
                amphoraId: n.id,
                invite: v.invite,
                onBack: N
            }), s[50] = n.id, s[51] = N, s[52] = v.invite, s[53] = G) : G = s[53], G
        }
    }
    const $ = Ne;
    let ee;
    s[54] !== e ? (ee = e.formatMessage(zt.amphoraControlsTab), s[54] = e, s[55] = ee) : ee = s[55];
    const de = "https://help.openai.com/en/articles/12315553-parental-controls-faq";
    let ye;
    s[56] !== n || s[57] !== a || s[58] !== e || s[59] !== h || s[60] !== g ? (ye = n !== void 0 && !(n != null && n.id) && g && t.jsx(Q, {
        children: t.jsx(Lt, {
            label: e.formatMessage(zt.pendingAmphoraInvite),
            buttonLabel: e.formatMessage(zt.inviteButton),
            onClick: () => ho(a, g, h != null ? h : void 0)
        })
    }), s[56] = n, s[57] = a, s[58] = e, s[59] = h, s[60] = g, s[61] = ye) : ye = s[61];
    let ze;
    s[62] === Symbol.for("react.memo_cache_sentinel") ? (ze = t.jsx("div", {
        className: "flex min-h-15 items-center pt-4",
        children: t.jsx("div", {
            className: "w-full",
            children: t.jsx("div", {
                className: "flex flex-col items-start gap-8 pt-1 pb-3",
                children: t.jsx("p", {
                    className: "text-sm",
                    children: t.jsx(m, b({}, zt.inviteAmphoraMembersParagraph))
                })
            })
        })
    }), s[62] = ze) : ze = s[62];
    const Le = (n == null ? void 0 : n.id) && (T.length > 0 || O.length > 0) && t.jsxs("div", {
        className: "mt-4",
        children: [t.jsx("h4", {
            className: "mb-2 text-base font-medium",
            children: t.jsx(m, b({}, zt.amphoraMembersTitle))
        }), t.jsxs("div", {
            children: [T.map(G => {
                var be, Te, Oe, We, Ve;
                const se = G.user_id,
                    pe = G.user_id === (j == null ? void 0 : j.id),
                    fe = G.role === "owner";
                return t.jsx("div", {
                    className: "border-token-border-default hover:bg-token-interactive-bg-secondary-hover active:bg-token-interactive-bg-secondary-press border-t last:border-b",
                    children: t.jsxs("button", {
                        className: "flex w-full items-center justify-between py-4 pe-4",
                        onClick: () => {
                            if (se) {
                                if (fe) {
                                    M(), S(I ? {
                                        type: "parent",
                                        member: G
                                    } : {
                                        type: "relationship",
                                        member: G
                                    });
                                    return
                                }(n == null ? void 0 : n.role) === "member_role" && !pe ? (M(), S({
                                    type: "relationship",
                                    member: G
                                })) : (i(Ae.ParentalControls, {
                                    parentalControlsMemberId: se
                                }), S({
                                    type: "member",
                                    member: G
                                }))
                            }
                        },
                        children: [t.jsxs("div", {
                            className: "flex items-center gap-3 text-start",
                            children: [t.jsx(ui, {
                                user: {
                                    picture: (be = G.profile_picture_url) != null ? be : void 0,
                                    name: (Oe = (Te = G.name) != null ? Te : G.email) != null ? Oe : ""
                                },
                                size: "large"
                            }), t.jsx("div", {
                                className: "flex items-center gap-2",
                                children: t.jsx("div", {
                                    className: "text-[15px] leading-5",
                                    children: (Ve = (We = G.name) != null ? We : G.email) != null ? Ve : t.jsx(m, b({}, zt.amphoraMemberFallback))
                                })
                            })]
                        }), t.jsxs("div", {
                            className: "flex items-center gap-4",
                            children: [fe && t.jsx(ia, {}), t.jsx(ka, {
                                className: "icon-sm opacity-60"
                            })]
                        })]
                    })
                }, se)
            }), O.map(G => {
                var pe, fe;
                const se = (pe = G.user_id) != null ? pe : G.email;
                return t.jsx("div", {
                    className: "border-token-border-default hover:bg-token-interactive-bg-secondary-hover active:bg-token-interactive-bg-secondary-press border-t last:border-b",
                    children: t.jsxs("button", {
                        className: "flex w-full items-center justify-between py-4 pe-4",
                        onClick: () => {
                            M(), S({
                                type: "invite",
                                invite: G
                            })
                        },
                        children: [t.jsxs("div", {
                            className: "flex items-center gap-3 text-start",
                            children: [t.jsx("div", {
                                className: "bg-token-bg-tertiary text-token-text-tertiary flex h-12 w-12 shrink-0 items-center justify-center rounded-full",
                                children: t.jsx(di, {
                                    className: "icon-lg"
                                })
                            }), t.jsxs("div", {
                                children: [t.jsx("div", {
                                    className: "text-sm",
                                    children: (fe = G.email) != null ? fe : t.jsx(m, b({}, zt.missingMember))
                                }), t.jsx("div", {
                                    className: "text-token-text-secondary mt-0.5 text-sm",
                                    children: t.jsx("span", {
                                        children: e.formatMessage(zt.invitationSent)
                                    })
                                })]
                            })]
                        }), t.jsxs("div", {
                            className: "flex items-center gap-4",
                            children: [G.role === "owner" && t.jsx(ia, {}), t.jsx(ka, {
                                className: "icon-sm opacity-60"
                            })]
                        })]
                    })
                }, "pending-".concat(se))
            })]
        })]
    });
    let Me;
    s[63] !== V || s[64] !== B || s[65] !== U ? (Me = !U && t.jsx(Q, {
        children: t.jsx("div", {
            className: "flex flex-col items-start gap-8 py-1",
            children: t.jsx(ne, {
                color: "secondary",
                icon: Ri,
                onClick: V,
                children: B
            })
        })
    }), s[63] = V, s[64] = B, s[65] = U, s[66] = Me) : Me = s[66];
    let me;
    s[67] !== $ || s[68] !== ee || s[69] !== ye || s[70] !== ze || s[71] !== Le || s[72] !== Me ? (me = t.jsxs($, {
        title: ee,
        learnMoreHref: de,
        children: [ye, ze, Le, Me]
    }), s[67] = $, s[68] = ee, s[69] = ye, s[70] = ze, s[71] = Le, s[72] = Me, s[73] = me) : me = s[73];
    let xe;
    s[74] !== e || s[75] !== I || s[76] !== i ? (xe = I && t.jsx(Ne, {
        title: e.formatMessage(zt.safetyNotifications),
        noBorder: !0,
        learnMoreHref: "https://help.openai.com/en/articles/12315553-parental-controls-faq",
        children: t.jsxs("div", {
            className: "flex flex-col items-start gap-3",
            children: [t.jsx("p", {
                className: "text-sm",
                children: t.jsx(m, b({}, zt.safetyNotificationsDescription))
            }), t.jsx(ne, {
                color: "secondary",
                onClick: () => i(Ae.Notifications),
                children: t.jsx(m, b({}, zt.safetyNotificationsButton))
            })]
        })
    }), s[74] = e, s[75] = I, s[76] = i, s[77] = xe) : xe = s[77];
    let Ce;
    return s[78] !== me || s[79] !== xe ? (Ce = t.jsxs(t.Fragment, {
        children: [me, xe]
    }), s[78] = me, s[79] = xe, s[80] = Ce) : Ce = s[80], Ce
}

function _g(s) {
    return s.status === "invited"
}

function wg(s) {
    return s.notification_type === "family-invite" && !s.reacted_to_at
}
const zt = Ke({
    amphoraControlsTab: {
        id: "settingsModal.amphoraControlsTab",
        defaultMessage: "Parental controls"
    },
    pendingAmphoraInvite: {
        id: "settingsModal.pendingAmphoraInvite",
        defaultMessage: "You have a pending family invite"
    },
    inviteAmphoraMembers: {
        id: "settingsModal.inviteAmphoraMembers",
        defaultMessage: "Invite family members"
    },
    inviteButton: {
        id: "settingsModal.inviteButton",
        defaultMessage: "Invite"
    },
    inviteAmphoraMembersParagraph: {
        id: "settingsModal.inviteAmphoraMembersParagraph3",
        defaultMessage: "Parents and teens can link accounts, giving parents tools to adjust certain features, set limits, and add safeguards that work for their family."
    },
    addFamilyMemberCTA: {
        id: "settingsModal.addFamilyMemberCTA",
        defaultMessage: "Add family member"
    },
    addChildCTA: {
        id: "settingsModal.addChildCTA",
        defaultMessage: "Add child"
    },
    amphoraMembersTitle: {
        id: "settingsModal.amphoraMembersTitle",
        defaultMessage: "Family members"
    },
    amphoraMembersRoleLabel: {
        id: "settingsModal.amphoraMembersRoleLabel",
        defaultMessage: "Role"
    },
    amphoraMembersStatusLabel: {
        id: "settingsModal.amphoraMembersStatusLabel",
        defaultMessage: "Status"
    },
    amphoraMemberFallback: {
        id: "settingsModal.amphoraMemberFallback",
        defaultMessage: "Family member"
    },
    removeMember: {
        id: "amphora.members.removeMember",
        defaultMessage: "Remove"
    },
    leaveAmphora: {
        id: "amphora.members.leaveAmphora",
        defaultMessage: "Leave family group"
    },
    invitedStatus: {
        id: "amphora.members.status.invited",
        defaultMessage: "Invited"
    },
    invitationSent: {
        id: "amphora.members.status.invitationSent",
        defaultMessage: "Invitation sent"
    },
    cancelInvite: {
        id: "amphora.invites.cancelInvite",
        defaultMessage: "Cancel"
    },
    cancelInviteError: {
        id: "amphora.invites.cancelInviteError",
        defaultMessage: "Unable to cancel invite: {error}"
    },
    missingMember: {
        id: "amphora.members.missingMember",
        defaultMessage: "[missing]"
    },
    selfLabel: {
        id: "amphora.members.self",
        defaultMessage: "You"
    },
    safetyNotifications: {
        id: "amphora.settings.safetyNotifications",
        defaultMessage: "Safety notifications"
    },
    safetyNotificationsDescription: {
        id: "amphora.settings.safetyNotificationsDescription",
        defaultMessage: "We care about your teen's safety. If we detect certain serious safety concerns, we will notify you—though no system is perfect. You can choose how you'd like to be contacted."
    },
    safetyNotificationsButton: {
        id: "amphora.settings.safetyNotificationsButton",
        defaultMessage: "Manage notifications"
    }
});

function kg(s) {
    return s.type === xo.GDRIVE_SYNC_CONNECTOR || s.type === xo.SLACK_SYNC_CONNECTOR ? "".concat(window.location.origin, "/ca/").concat(s.id, "/oauth/callback") : "".concat(window.location.origin, "/ccc/").concat(s.id, "/oauth/callback")
}
const Eg = ({
        entry: s,
        isConnected: e,
        onDisconnect: a,
        onConnect: n,
        redirectUri: o
    }) => t.jsx(Ng, {
        isConnected: e,
        onConnect: () => n({
            id: s.id
        }, "settings_connected_apps", kg(s), o),
        onDisconnect: () => a(s == null ? void 0 : s.type)
    }),
    Ng = ({
        isConnected: s,
        isDisabledByAdmin: e,
        onDisconnect: a,
        onConnect: n
    }) => {
        const o = K();
        return e ? t.jsx(Wt, {
            label: o.formatMessage(Yn.disabledByAdmin),
            children: t.jsx(ne, {
                onClick: a,
                color: "secondary",
                size: "small",
                disabled: e,
                children: t.jsx(m, b({}, Yn.connect))
            })
        }) : s ? t.jsx(ne, {
            onClick: a,
            color: "danger-outline",
            size: "small",
            children: t.jsx(m, b({}, Yn.disconnect))
        }) : t.jsx(ne, {
            onClick: n,
            color: "secondary",
            size: "small",
            children: t.jsx(m, b({}, Yn.connect))
        })
    },
    Yn = Ke({
        connect: {
            id: "connectorSettings.connect",
            defaultMessage: "Connect"
        },
        disconnect: {
            id: "connectorSettings.disconnect",
            defaultMessage: "Disconnect"
        },
        disabledByAdmin: {
            id: "connectorSettings.disabledByAdmin",
            defaultMessage: "Disabled by workspace admin"
        }
    });

function Tg(s) {
    switch (s) {
        case St.CONFLUENCE:
            return Ir;
        case St.GDRIVE:
            return fi;
        case St.JIRA:
            return Lr;
        case St.NOTION_OPEN_CONNECTOR:
            return Dr;
        case St.O365:
        case St.O365_PERSONAL:
        case St.O365_BUSINESS:
            return na;
        case St.SLACK_OPEN_CONNECTOR:
            return Pr
    }
}

function Ag({
    clientApplications: s
}) {
    const {
        mutate: e,
        isPending: a
    } = qa();
    return t.jsx(t.Fragment, {
        children: s.map(n => t.jsx(Pg, {
            clientApplication: n,
            disabled: a,
            onDisconnect: () => {
                Ue.logEventWithStatsig("Connector Settings: Client Application Disconnect Button Clicked", "chatgpt_connector_settings_client_application_disconnect_button_clicked", {
                    id: n.id,
                    name: n.name,
                    type: n.type
                }), e(n.id)
            }
        }, n.id))
    })
}

function Pg({
    clientApplication: s,
    disabled: e,
    onDisconnect: a
}) {
    return t.jsx(Q, {
        children: t.jsx(Bs, {
            icon: t.jsx(yu, {
                className: "icon-lg"
            }),
            title: s.name,
            description: t.jsx(m, b({}, Cn.appleDesc)),
            statusIndicator: t.jsx(ne, {
                onClick: a,
                color: "danger-outline",
                size: "small",
                disabled: e,
                children: t.jsx(m, b({}, Cn.disconnect))
            })
        })
    })
}

function Dg({
    clientApplications: s
}) {
    const {
        mutate: e,
        isPending: a
    } = qa();
    return t.jsx(t.Fragment, {
        children: s.map(n => t.jsx(Lg, {
            clientApplication: n,
            disabled: a,
            onDisconnect: () => {
                Ue.logEventWithStatsig("Connector Settings: Kakao Client Application Disconnect Button Clicked", "chatgpt_connector_settings_client_application_disconnect_button_clicked", {
                    id: n.id,
                    name: n.name,
                    type: n.type
                }), e(n.id)
            }
        }, n.id))
    })
}

function Lg({
    clientApplication: s,
    disabled: e,
    onDisconnect: a
}) {
    return t.jsx(Q, {
        children: t.jsx(Bs, {
            icon: t.jsx(Mu, {
                className: "icon-lg"
            }),
            title: s.name,
            description: t.jsx(m, b({}, Cn.kakaoDesc)),
            statusIndicator: t.jsx(ne, {
                onClick: a,
                color: "danger-outline",
                size: "small",
                disabled: e,
                children: t.jsx(m, b({}, Cn.disconnect))
            })
        })
    })
}

function Ig({
    clientApplications: s
}) {
    const {
        mutate: e,
        isPending: a
    } = qa();
    return t.jsx(t.Fragment, {
        children: s.map(n => t.jsx(Rg, {
            clientApplication: n,
            disabled: a,
            onDisconnect: () => {
                Ue.logEventWithStatsig("Connector Settings: Codex CLI Client Application Disconnect Button Clicked", "chatgpt_connector_settings_client_application_disconnect_button_clicked", {
                    id: n.id,
                    name: n.name,
                    type: n.type
                }), e(n.id)
            }
        }, n.id))
    })
}

function Rg({
    clientApplication: s,
    disabled: e,
    onDisconnect: a
}) {
    return t.jsx(Q, {
        children: t.jsx(Bs, {
            icon: t.jsx(Zc, {
                className: "icon-lg"
            }),
            title: s.name,
            description: t.jsx(m, b({}, Cn.codexCLIDesc)),
            statusIndicator: t.jsx(ne, {
                onClick: a,
                color: "danger-outline",
                size: "small",
                disabled: e,
                children: t.jsx(m, b({}, Cn.disconnect))
            })
        })
    })
}
const Cn = Ke({
    appleDesc: {
        id: "P5OVxG",
        defaultMessage: "Get personalized ChatGPT responses and Plus benefits when using Siri and Writing Tools."
    },
    kakaoDesc: {
        id: "IKXNCX",
        defaultMessage: "ChatGPT in KakaoTalk."
    },
    disconnect: {
        id: "connectorSettings.disconnectButton",
        defaultMessage: "Disconnect"
    },
    codexCLIDesc: {
        id: "DWVivD",
        defaultMessage: "Allow Codex CLI to use models from the API."
    }
});

function Bg({
    renderAsSheet: s
}) {
    const {
        data: e
    } = Fs(Xc), a = e == null ? void 0 : e.items, n = a == null ? void 0 : a.filter(({
        type: r
    }) => r === "apple"), o = !!(n != null && n.length), i = a == null ? void 0 : a.filter(({
        type: r
    }) => r === "kakao_talk"), c = !!(i != null && i.length), l = a == null ? void 0 : a.filter(({
        type: r
    }) => r === "codex_cli"), d = !!(l != null && l.length);
    return t.jsxs(Ne, {
        title: t.jsx(m, b({}, Ho.secureSigninTitle)),
        description: t.jsx(m, Ee(b({}, Ho.secureSigninDescription), {
            values: {
                learn_more_link: s ? null : t.jsx("a", {
                    href: "https://help.openai.com/en/collections/13193904-secure-sign-in",
                    className: "underline",
                    target: "_blank",
                    rel: "noopener noreferrer",
                    children: t.jsx(m, {
                        id: "G/jd2T",
                        defaultMessage: "Learn more"
                    })
                })
            }
        })),
        children: [!o && !c && !d && t.jsx("div", {
            className: "text-token-text-secondary bg-token-bg-tertiary my-4 rounded-xl p-4",
            children: t.jsx(m, {
                id: "5VTvRh",
                defaultMessage: "You haven’t used ChatGPT to sign into any websites or apps yet. Once you do, they’ll show up here."
            })
        }), o && t.jsx(Ag, {
            clientApplications: n
        }), c && t.jsx(Dg, {
            clientApplications: i
        }), d && t.jsx(Ig, {
            clientApplications: l
        })]
    })
}
const Ho = Ke({
        secureSigninTitle: {
            id: "wGZ2DC",
            defaultMessage: "Secure sign in with ChatGPT"
        },
        secureSigninDescription: {
            id: "mq87/x",
            defaultMessage: "Sign in to websites and apps across the internet with the trusted security of ChatGPT. {learn_more_link}"
        }
    }),
    Og = () => {
        "use forget";
        const s = Se.c(20),
            {
                connectorConfig: e,
                isLoading: a
            } = mi();
        let n;
        s[0] !== e ? (n = e.get(St.GDRIVE), s[0] = e, s[1] = n) : n = s[1];
        const o = n;
        let i;
        s[2] !== e ? (i = e.get(St.O365_PERSONAL), s[2] = e, s[3] = i) : i = s[3];
        const c = i;
        let l;
        s[4] !== e ? (l = e.get(St.O365_BUSINESS), s[4] = e, s[5] = l) : l = s[5];
        const d = l,
            r = !!(o != null && o.access_token),
            u = !!(c != null && c.access_token),
            f = !!(d != null && d.access_token);
        if (a || !(r || u || f)) return null;
        let g;
        s[6] === Symbol.for("react.memo_cache_sentinel") ? (g = t.jsx(m, b({}, Qn.fileUploadsTitle)), s[6] = g) : g = s[6];
        let h;
        s[7] !== o || s[8] !== r ? (h = o && r && t.jsx(va, {
            entry: o,
            description: Qn.googleDriveDesc
        }), s[7] = o, s[8] = r, s[9] = h) : h = s[9];
        let y;
        s[10] !== u || s[11] !== c ? (y = c && u && t.jsx(va, {
            entry: c,
            description: Qn.o365Desc
        }), s[10] = u, s[11] = c, s[12] = y) : y = s[12];
        let x;
        s[13] !== f || s[14] !== d ? (x = d && f && t.jsx(va, {
            entry: d,
            description: Qn.o365BusinessDesc
        }), s[13] = f, s[14] = d, s[15] = x) : x = s[15];
        let j;
        return s[16] !== h || s[17] !== y || s[18] !== x ? (j = t.jsx(Ne, {
            title: g,
            children: t.jsxs(t.Fragment, {
                children: [h, y, x]
            })
        }), s[16] = h, s[17] = y, s[18] = x, s[19] = j) : j = s[19], j
    };

function va(s) {
    "use forget";
    const e = Se.c(18),
        {
            entry: a,
            description: n
        } = s,
        o = a.type;
    let i;
    e[0] !== o ? (i = Tg(o), e[0] = o, e[1] = i) : i = e[1];
    const c = i,
        l = K();
    let d;
    e[2] === Symbol.for("react.memo_cache_sentinel") ? (d = Ht("border-token-border-default bg-token-bg-primary shadow-xxs h-fit rounded-[10px] border-[0.5px] p-2"), e[2] = d) : d = e[2];
    let r;
    e[3] !== c ? (r = t.jsx("div", {
        className: d,
        children: t.jsx(c, {
            className: "icon-lg"
        })
    }), e[3] = c, e[4] = r) : r = e[4];
    const u = a.type;
    let f;
    e[5] !== l || e[6] !== u ? (f = La(u, l), e[5] = l, e[6] = u, e[7] = f) : f = e[7];
    let p;
    e[8] !== n ? (p = t.jsx(m, b({}, n)), e[8] = n, e[9] = p) : p = e[9];
    const g = !!a.access_token;
    let h;
    e[10] !== a || e[11] !== g ? (h = t.jsx(Eg, {
        entry: a,
        isConnected: g,
        onDisconnect: Rr,
        onConnect: Fg,
        redirectUri: pi
    }), e[10] = a, e[11] = g, e[12] = h) : h = e[12];
    let y;
    return e[13] !== r || e[14] !== f || e[15] !== p || e[16] !== h ? (y = t.jsx("div", {
        className: "border-token-border-light items-center border-b px-0.5 py-3 last-of-type:border-none",
        children: t.jsx(Bs, {
            icon: r,
            title: f,
            description: p,
            statusIndicator: h
        })
    }), e[13] = r, e[14] = f, e[15] = p, e[16] = h, e[17] = y) : y = e[17], y
}

function Fg() {}
const Qn = Ke({
        fileUploadsTitle: {
            id: "connectorSettings.fileUploadsTitle",
            defaultMessage: "File uploads"
        },
        googleDriveDesc: {
            id: "connectorSettings.googleDriveDesc.1",
            defaultMessage: "Upload Google Docs, Sheets, Slides and other files."
        },
        o365Desc: {
            id: "connectorSettings.o365Desc.1",
            defaultMessage: "Upload Microsoft Word, Excel, PowerPoint and other files."
        },
        o365BusinessDesc: {
            id: "connectorSettings.o365BusinessDesc.1",
            defaultMessage: "Upload Microsoft Word, Excel, PowerPoint, and other files, including those from SharePoint sites."
        }
    }),
    Mt = Ke({
        title: {
            id: "AiqVkG",
            defaultMessage: "MCP OAuth Validator"
        },
        description: {
            id: "sR7eMV",
            defaultMessage: "Fetch OAuth metadata exposed by MCP server."
        },
        urlPlaceholder: {
            id: "hkjy2v",
            defaultMessage: "https://example.com/mcp"
        },
        validateButton: {
            id: "rrkmei",
            defaultMessage: "Fetch"
        },
        statusOk: {
            id: "3p6lU0",
            defaultMessage: "Status: OK"
        },
        statusError: {
            id: "uujZdN",
            defaultMessage: "Status: Error"
        },
        authorizationEndpoint: {
            id: "3JTp9o",
            defaultMessage: "Authorization endpoint"
        },
        tokenEndpoint: {
            id: "zNlEqZ",
            defaultMessage: "Token endpoint"
        },
        revocationEndpoint: {
            id: "O/fClz",
            defaultMessage: "Revocation endpoint (optional)"
        },
        registrationEndpoint: {
            id: "JONdFm",
            defaultMessage: "Registration endpoint (required for DCR)"
        },
        scopes: {
            id: "souwx1",
            defaultMessage: "Base scopes"
        },
        tokenEndpointAuthMethods: {
            id: "ZE/WI4",
            defaultMessage: "Token endpoint auth methods supported"
        },
        pkceMethods: {
            id: "ySHZI+",
            defaultMessage: "Code challenge methods supported"
        },
        scopesSupported: {
            id: "+uWpOP",
            defaultMessage: "Scopes"
        },
        missingUrl: {
            id: "LRu6bd",
            defaultMessage: "Enter an MCP server URL to validate."
        },
        unknownError: {
            id: "Ju3Bv+",
            defaultMessage: "Unable to validate the URL right now."
        },
        noScopes: {
            id: "zCLL1q",
            defaultMessage: "None"
        },
        notSet: {
            id: "Ohpadu",
            defaultMessage: "Not set"
        },
        clearResult: {
            id: "fKcvJp",
            defaultMessage: "Clear result"
        }
    });

function nn({
    label: s,
    value: e,
    className: a
}) {
    if (!e) return null;
    const n = typeof e == "string" && e.trim().toLowerCase() === "(not set)";
    return t.jsxs("div", {
        className: "flex flex-col gap-1 ".concat(a != null ? a : ""),
        children: [t.jsx("span", {
            className: "text-token-text-secondary text-xs",
            children: s
        }), t.jsx("span", {
            className: "text-token-text-primary text-sm break-words",
            children: n ? t.jsx("span", {
                className: "text-token-text-secondary italic",
                children: e
            }) : e
        })]
    })
}

function Ug() {
    var r, u, f, p;
    const [s, e] = w.useState(""), [a, n] = w.useState(null), o = K(), i = pt({
        mutationFn: async () => {
            const g = s.trim();
            if (!g) throw new Error(o.formatMessage(Mt.missingUrl));
            return Or(g)
        },
        onSuccess: g => {
            n({
                status: g.status,
                oauth_config: g.oauth_config,
                error: g.error
            })
        },
        onError: g => {
            var y;
            const h = g instanceof Br ? typeof((y = g == null ? void 0 : g.body) == null ? void 0 : y.detail) == "string" ? g.body.detail : g.message : g instanceof Error ? g.message : o.formatMessage(Mt.unknownError);
            n({
                status: "error",
                error: h
            })
        }
    }), c = a == null ? void 0 : a.oauth_config, l = "(".concat(o.formatMessage(Mt.notSet).toLowerCase(), ")"), d = c;
    return t.jsxs("div", {
        className: "flex flex-col gap-3 rounded-md p-4",
        children: [t.jsxs("div", {
            className: "flex flex-col gap-1",
            children: [t.jsxs("div", {
                className: "flex items-center gap-2 text-sm font-medium",
                children: [t.jsx("p", {
                    children: t.jsx(m, b({}, Mt.title))
                }), t.jsx(Bi, {})]
            }), t.jsx("p", {
                className: "text-token-text-secondary text-xs",
                children: t.jsx(m, b({}, Mt.description))
            })]
        }), t.jsxs("div", {
            className: "flex flex-col gap-2 sm:flex-row sm:items-center sm:gap-3",
            children: [t.jsx(Ka, {
                name: "mcpUrl",
                ariaLabel: o.formatMessage(Mt.urlPlaceholder),
                className: "w-full",
                placeholder: o.formatMessage(Mt.urlPlaceholder),
                value: s,
                onChange: g => e(g.target.value),
                onKeyDown: g => {
                    g.key === "Enter" && (g.preventDefault(), i.mutate())
                }
            }), t.jsx(ne, {
                color: "secondary",
                className: "shrink-0",
                loading: i.isPending,
                disabled: !s.trim(),
                onClick: () => i.mutate(),
                children: t.jsx(m, b({}, Mt.validateButton))
            })]
        }), a && t.jsxs("div", {
            className: "border-token-border-subtle bg-token-main-surface-secondary rounded-md border p-3",
            children: [t.jsxs("div", {
                className: "flex items-center justify-between gap-2",
                children: [t.jsxs("div", {
                    className: "flex items-center gap-2",
                    children: [t.jsx("span", {
                        "aria-hidden": !0,
                        className: "h-2.5 w-2.5 rounded-full ".concat(a.status === "ok" ? "bg-green-500" : "bg-red-500")
                    }), t.jsx("span", {
                        className: "text-sm font-medium",
                        children: a.status === "ok" ? t.jsx(m, b({}, Mt.statusOk)) : t.jsx(m, b({}, Mt.statusError))
                    })]
                }), t.jsx("button", {
                    type: "button",
                    "aria-label": o.formatMessage(Mt.clearResult),
                    className: "text-token-text-secondary hover:text-token-text-primary flex h-8 w-8 items-center justify-center rounded",
                    onClick: () => n(null),
                    children: t.jsx(Jc, {
                        className: "icon-sm"
                    })
                })]
            }), a.status === "error" ? t.jsx("p", {
                className: "text-token-text-secondary mt-2 text-sm",
                children: (r = a.error) != null ? r : o.formatMessage(Mt.unknownError)
            }) : c ? t.jsxs("div", {
                className: "mt-3 grid gap-3",
                children: [t.jsx(nn, {
                    label: t.jsx(m, b({}, Mt.authorizationEndpoint)),
                    value: c.authorization_url || l
                }), t.jsx(nn, {
                    label: t.jsx(m, b({}, Mt.registrationEndpoint)),
                    value: (d == null ? void 0 : d.registration_endpoint) || l
                }), t.jsx(nn, {
                    label: t.jsx(m, b({}, Mt.tokenEndpoint)),
                    value: c.token_url || l
                }), t.jsx(nn, {
                    label: t.jsx(m, b({}, Mt.revocationEndpoint)),
                    value: (d == null ? void 0 : d.revocation_url) || l
                }), t.jsx(nn, {
                    label: t.jsx(m, b({}, Mt.pkceMethods)),
                    value: (u = d == null ? void 0 : d.pkce_methods) != null && u.length ? d.pkce_methods.join(", ") : void 0
                }), t.jsx(nn, {
                    label: t.jsx(m, b({}, Mt.tokenEndpointAuthMethods)),
                    value: (f = d == null ? void 0 : d.token_endpoint_auth_methods_supported) != null && f.length ? d.token_endpoint_auth_methods_supported.join(", ") : void 0
                }), t.jsx(nn, {
                    label: t.jsx(m, b({}, Mt.scopesSupported)),
                    value: (p = d == null ? void 0 : d.scopes_supported) != null && p.length ? d.scopes_supported.join(", ") : void 0
                })]
            }) : null]
        })]
    })
}
const Gg = ({
        connector: s
    }) => {
        const e = K(),
            a = Gs(),
            n = s.status === "DISABLED_BY_ADMIN";
        return t.jsx(Wt, {
            label: n ? e.formatMessage(Fr.disabledByAdmin) : void 0,
            triggerAs: "div",
            children: t.jsxs(ne, {
                color: "secondary",
                className: "disabled:hover:bg-token-bg-primary border-token-border-default hover:bg-token-interactive-bg-secondary-hover w-full rounded-[10px] border p-3 pb-[10px] disabled:opacity-25",
                contentWrapperClassName: "flex-col gap-2 truncate items-start flex-1",
                onClick: () => a(s.id),
                disabled: n,
                children: [t.jsxs("div", {
                    className: "flex w-full items-center justify-between",
                    children: [t.jsx(oa, {
                        connector: s
                    }), t.jsx(wn, {
                        connector: s
                    })]
                }), t.jsx("span", {
                    className: "max-w-full truncate text-sm font-normal",
                    children: _n(s.name, e)
                })]
            })
        })
    },
    Wo = ({
        connectors: s
    }) => {
        const e = w.useMemo(() => [...s].sort((a, n) => {
            const o = (n.status !== "DISABLED_BY_ADMIN" ? 1 : 0) - (a.status !== "DISABLED_BY_ADMIN" ? 1 : 0),
                i = n.owners.length - a.owners.length,
                c = a.name.localeCompare(n.name);
            return 100 * o + 10 * i + c
        }), [s]);
        return t.jsx("div", {
            className: "my-2 grid grid-cols-2 gap-2 sm:grid-cols-3",
            children: e.map(a => t.jsx(Gg, {
                connector: a
            }, a.id))
        })
    },
    zg = ({
        apps: s
    }) => t.jsxs("div", {
        className: "flex flex-1 flex-col items-center justify-center p-4 text-center",
        children: [s.length > 0 && t.jsx("div", {
            className: "my-1 flex items-center justify-center",
            children: s.map((e, a) => t.jsxs("div", {
                style: {
                    zIndex: s.length - a
                },
                className: Ht("relative", "my-1", a !== 0 && "-ms-2"),
                children: [t.jsx(Un, {
                    connector: e,
                    size: "large",
                    className: Ht("shadow-xxs h-fit", "bg-token-bg-primary overflow-hidden rounded-full")
                }), t.jsx("div", {
                    className: Ht("absolute inset-0 rounded-full ring ring-black/[0.08] ring-inset dark:ring-white/[0.06]")
                })]
            }, e.id))
        }), t.jsx("p", {
            className: "text-token-text-secondary font-regular my-3",
            children: t.jsx(m, b({}, Vo.appsBrowseNux))
        }), t.jsx(ne, {
            as: "link",
            to: "/apps",
            state: Oi("settings-browse-apps"),
            color: "primary",
            size: "medium",
            className: "my-3 rounded-full px-6",
            children: t.jsx(m, b({}, Vo.browseAppsButton))
        })]
    }),
    Vo = Ke({
        appsBrowseNux: {
            id: "VxJQp6",
            defaultMessage: "Add and manage apps ChatGPT can use in your chats."
        },
        browseAppsButton: {
            id: "69/HZw",
            defaultMessage: "Explore apps"
        }
    }),
    lr = ({
        onClick: s,
        children: e,
        disabled: a
    }) => t.jsx("button", {
        className: "border-token-border-light items-center border-b px-0.5 py-3 last-of-type:border-none",
        onClick: s,
        disabled: a,
        children: e
    }),
    Gn = ({
        connector: s,
        trailingButton: e,
        description: a,
        disabled: n
    }) => {
        const o = Ur(),
            i = K(),
            c = Gs(),
            l = kn(o);
        return t.jsx(lr, {
            onClick: () => c(s.id),
            disabled: n,
            children: t.jsx(Bs, {
                icon: t.jsxs("div", {
                    className: Ht("relative", l && "my-1"),
                    children: [t.jsx(Un, {
                        connector: s,
                        size: l ? "medium" : "small",
                        className: Ht("shadow-xxs h-fit", l ? "overflow-hidden rounded-full" : "border-token-border-default bg-token-bg-primary rounded-[10px] border-[0.5px] p-2")
                    }), l && t.jsx("div", {
                        className: "absolute inset-0 rounded-full ring ring-black/[0.08] ring-inset dark:ring-white/[0.06]"
                    })]
                }),
                title: _n(s.name, i),
                badge: t.jsx(wn, {
                    connector: s
                }),
                description: a,
                statusIndicator: t.jsxs("div", {
                    className: "flex flex-shrink-0 items-center gap-4",
                    children: [e, t.jsx(vn, {
                        className: "icon"
                    })]
                })
            })
        })
    },
    Hg = ({
        connectorLinks: s,
        platformConnectors: e,
        gdriveRow: a,
        onedrivePersonalRow: n,
        onedriveBusinessRow: o,
        githubRow: i,
        genericSyncableRows: c
    }) => {
        const l = K(),
            d = w.useMemo(() => [...Array.from(s.keys()).map(f => e.find(p => p.id === f)).filter(f => !!f).map(f => ({
                type: "platform_connector",
                name: f.name,
                connector: f
            })), ...n ? [{
                type: "onedrive_personal",
                name: l.formatMessage(Gr)
            }] : [], ...o ? [{
                type: "onedrive_business",
                name: l.formatMessage(zr)
            }] : [], ...a ? [{
                type: "gdrive",
                name: "Google Drive"
            }] : [], ...i ? [{
                type: "github",
                name: "GitHub"
            }] : [], ...(c != null ? c : []).map(f => b({
                type: "syncable_platform_connector",
                name: f.connector.name
            }, f))].sort((f, p) => f.name.localeCompare(p.name)), [s, n, l, o, a, i, c, e]);
        return t.jsx("div", {
            className: "flex flex-col",
            children: d.map(r => r.type === "platform_connector" ? t.jsx(Gn, {
                connector: r.connector
            }, r.connector.id) : r.type === "onedrive_personal" ? t.jsx(Is.Fragment, {
                children: n
            }, r.type) : r.type === "onedrive_business" ? t.jsx(Is.Fragment, {
                children: o
            }, r.type) : r.type === "gdrive" ? t.jsx(Is.Fragment, {
                children: a
            }, r.type) : r.type === "github" ? t.jsx(Is.Fragment, {
                children: i
            }, r.type) : r.type === "syncable_platform_connector" ? t.jsx(Is.Fragment, {
                children: r.row
            }, r.connector.id) : void 0)
        })
    };

function $o(s) {
    return rl(s) ? ll(s, dl.CreateMcpConnector, cl(s)) : !0
}
const cr = Hr(s => Wr(() => {
        const e = vi(s);
        if (!e) return {
            shouldRenderButton: !1,
            isDisabledByAdmin: !1
        };
        if (e.isSelfServeBusiness() && e.isStandardUserOfAccount()) return {
            shouldRenderButton: !1,
            isDisabledByAdmin: !1
        };
        if (je(s, "3927245414")) return Os(s) ? {
            shouldRenderButton: !0,
            isDisabledByAdmin: e.isWorkspaceAccount() ? !$o(s) : !1
        } : {
            shouldRenderButton: !1,
            isDisabledByAdmin: !1
        };
        if (!je(s, "3828441000") && !Os(s)) return {
            shouldRenderButton: !1,
            isDisabledByAdmin: !1
        };
        if (!e.isWorkspaceAccount()) return {
            shouldRenderButton: !0,
            isDisabledByAdmin: !1
        };
        const o = $o(s);
        return o === void 0 ? {
            shouldRenderButton: !1,
            isDisabledByAdmin: !1
        } : {
            shouldRenderButton: !0,
            isDisabledByAdmin: !o
        }
    })),
    Da = ({
        disabled: s,
        message: e,
        onAddClick: a,
        tooltip: n,
        side: o = "right"
    }) => {
        const i = t.jsx(ne, {
            color: "secondary",
            disabled: s,
            onClick: c => {
                c.preventDefault(), a()
            },
            size: "small",
            children: t.jsx(m, b({}, e))
        });
        return n ? t.jsx(Wt, {
            label: t.jsx("div", {
                className: "max-w-50",
                children: n
            }),
            side: o,
            children: i
        }) : i
    },
    mn = ({
        disabled: s,
        loading: e,
        onClick: a,
        tooltip: n
    }) => {
        if (e) return t.jsx(Qr, {
            sizeOverride: 18,
            percentage: 0
        });
        const o = t.jsx(ne, {
            color: "secondary",
            disabled: s,
            onClick: i => {
                i.preventDefault(), i.stopPropagation(), a == null || a(i)
            },
            size: "small",
            children: t.jsxs("div", {
                className: "flex items-center gap-1 text-xs",
                children: [t.jsx(td, {
                    className: "icon-xs text-[#007AFF]"
                }), t.jsx(m, b({}, ke.syncForBetterAnswers))]
            })
        });
        return n ? t.jsx(Wt, {
            label: t.jsx("div", {
                className: "max-w-50",
                children: n
            }),
            side: "right",
            children: o
        }) : o
    },
    Wg = ({
        gdrivePlatformConnector: s,
        isFileUploadsEnabled: e,
        numPlatformLinks: a,
        platformLinks: n,
        numInternalKnowledgeLinks: o,
        numInternalKnowledgeConfigs: i,
        onAddClick: c
    }) => {
        var A;
        const l = ve(),
            d = K(),
            r = zs(),
            u = r == null ? void 0 : r.isPersonalAccount(),
            f = r == null ? void 0 : r.isWorkspaceAccount(),
            p = Oa(),
            g = !!f || p && !!u,
            h = (A = Ba()) != null ? A : "unknown_referrer",
            y = li({
                filters: {
                    mutationKey: ["upgradeConnectorToSync"]
                },
                select: _ => _.state
            }),
            {
                mutateAsync: x
            } = Ra(),
            {
                internalKnowledgeEnabled: j,
                internalKnowledgeConfigs: v,
                isLoading: S
            } = ua(),
            C = i - o,
            M = w.useMemo(() => {
                var _;
                return g ? (_ = n.get(xs)) == null ? void 0 : _.find(D => D.connector_id === s.id) : null
            }, [n, s.id, g]),
            E = w.useMemo(() => !(v != null && v.length) || !(M != null && M.id) || !g ? null : v.find(_ => (M == null ? void 0 : M.id) === _.user_connection_details.backing_link_id), [v, M == null ? void 0 : M.id, g]),
            N = y.some(_ => {
                var D, T;
                return _.status === "success" && ((T = (D = _.variables) == null ? void 0 : D.link) == null ? void 0 : T.id) === (M == null ? void 0 : M.id) && !E
            }),
            k = y.some(_ => {
                var D, T;
                return _.status === "pending" && ((T = (D = _.variables) == null ? void 0 : D.link) == null ? void 0 : T.id) === (M == null ? void 0 : M.id)
            });
        w.useEffect(() => {
            N && setTimeout(() => {
                bn(l)
            }, 1e3)
        }, [l, N]);
        const P = w.useMemo(() => {
                const _ = s.status !== "DISABLED_BY_ADMIN",
                    D = a > 0;
                if (r != null && r.isPersonalAccount()) {
                    if (M && !E && g) {
                        const T = () => {
                            Ue.logEventWithStatsig("Connectors - Upgrade Personal Google Drive", "chatgpt_connectors_upgrade_personal_google_drive_clicked"), x({
                                link: M,
                                referrer: h
                            })
                        };
                        return t.jsx(mn, {
                            onClick: T,
                            loading: k || S || N,
                            tooltip: d.formatMessage(ke.syncForBetterAnswersTooltip)
                        })
                    }
                    return M && E ? t.jsx(Bn, {
                        connection: E,
                        location: "user_settings"
                    }) : e && !M ? t.jsx(ne, {
                        size: "small",
                        color: "secondary",
                        onClick: c,
                        children: t.jsx(m, b({}, ke.addChatAndOrDeepResearch))
                    }) : null
                }
                if (D) {
                    if (C > 0 && o === 0) {
                        if (M && g) {
                            const T = () => {
                                Ue.logEventWithStatsig("Connectors - Upgrade Workspace Google Drive", "chatgpt_contextual_answers_user_upgrade_to_sync_initiated"), x({
                                    link: M,
                                    referrer: h
                                })
                            };
                            return t.jsx(mn, {
                                onClick: T,
                                loading: k || S || N,
                                tooltip: d.formatMessage(ke.syncForBetterAnswersTooltip)
                            })
                        }
                        return t.jsx(mn, {
                            onClick: c,
                            tooltip: d.formatMessage(ke.syncForBetterAnswersTooltip)
                        })
                    }
                    if (j && i === 0) return t.jsx(mn, {
                        disabled: !0,
                        onClick: c,
                        tooltip: d.formatMessage(ke.contactAdminTooltip)
                    })
                } else {
                    if (e && (o > 0 || C === 0)) return t.jsx(Da, {
                        disabled: !_,
                        message: ke.addDeepResearch,
                        onAddClick: c,
                        tooltip: _ ? void 0 : d.formatMessage(ke.deepResearchDisabledByAdmin)
                    });
                    if (_ && e && o === 0) return t.jsx(Da, {
                        message: ke.addChatAndOrDeepResearch,
                        onAddClick: c
                    });
                    if (e && !_ && o === 0 && C > 0) return t.jsx(mn, {
                        onClick: c,
                        tooltip: d.formatMessage(ke.syncForBetterAnswersTooltip)
                    })
                }
                return null
            }, [s.status, a, g, M, E, c, k, S, N, d, x, C, o, j, i, r, e, h]),
            L = w.useMemo(() => {
                const _ = [];
                return e && _.push("fileUploads"), Cu(_, d)
            }, [e, d]);
        return t.jsx(Gn, {
            connector: s,
            description: L,
            trailingButton: P
        })
    },
    Ko = ({
        config: s,
        onClick: e
    }) => {
        const a = K();
        return t.jsx(lr, {
            onClick: e,
            children: t.jsx(Bs, {
                icon: t.jsx("span", {
                    className: "border-token-border-default bg-token-bg-primary shadow-xxs h-fit rounded-[10px] border-[0.5px] p-2",
                    children: t.jsx(na, {
                        className: "icon-lg"
                    })
                }),
                title: La(s.type, a),
                statusIndicator: t.jsx(vn, {
                    className: "icon"
                })
            })
        })
    },
    Vg = ({
        githubLink: s,
        githubPlatformConnector: e
    }) => {
        var c;
        const a = K(),
            {
                data: n,
                isLoading: o
            } = Fi({
                linkId: (c = s == null ? void 0 : s.id) != null ? c : ""
            }),
            i = !n;
        return t.jsx(Gn, {
            connector: e,
            disabled: o,
            description: i ? a.formatMessage(ke.setupIncompleteGithub) : void 0
        })
    },
    $g = ({
        link: s,
        connector: e,
        syncConnectorId: a,
        refetchLinks: n
    }) => {
        var M, E, N;
        const o = ve(),
            i = K(),
            c = Ct(),
            l = Yr(),
            d = hi(),
            {
                data: r,
                refetch: u
            } = da(),
            f = d ? r == null ? void 0 : r.connection_statuses.find(k => k.user_connection_details.backing_link_id === (s == null ? void 0 : s.id) || e.id === ea && k.user_connection_details.connection_type === "sharepoint_admin_sync_connector" && k.user_connection_details.auth_status === "admin_connected") : void 0,
            p = li({
                filters: {
                    mutationKey: ["upgradeConnectorToSync"]
                },
                select: k => k.state
            });
        let g = "no-sync";
        if (f) g = "upgraded-to-sync";
        else
            for (const k of p)
                if (((E = (M = k.variables) == null ? void 0 : M.link) == null ? void 0 : E.id) === (s == null ? void 0 : s.id))
                    if (k.status === "success" && !f) {
                        g = "upgrade-succeeded-updating-status";
                        break
                    } else k.status === "pending" && (g = "upgrade-pending");
        w.useEffect(() => {
            g === "upgrade-succeeded-updating-status" && setTimeout(() => {
                u()
            }, 1e3)
        }, [g, u]);
        const {
            mutateAsync: h
        } = Ra(), [y, x] = w.useState(!1), j = !!a, v = (N = Ba()) != null ? N : "unknown_referrer", S = async () => {
            var k;
            if (a) try {
                x(!0), sd("popup");
                const P = await Zr({
                        connector: e,
                        redirectAfter: pi,
                        openPopup: l,
                        intl: i,
                        toaster: c,
                        productSku: Ot.CONNECTOR_SETTING,
                        connectorIdOverride: a
                    }),
                    L = a != null ? a : e.id,
                    {
                        data: A
                    } = await n(),
                    _ = P && typeof P == "object" ? P.linkId : void 0,
                    D = (k = A == null ? void 0 : A.get(L)) == null ? void 0 : k[0];
                let T = null;
                typeof _ == "string" ? T = {
                    id: _,
                    name: e.name,
                    connector_id: L
                } : D && typeof D.id == "string" && (T = {
                    id: D.id,
                    name: e.name,
                    connector_id: L
                }), T && (await h({
                    link: T,
                    isConnectingAndUpgrading: !0,
                    referrer: v
                }), await bn(o)), c.success(i.formatMessage(ke.syncConnectorSuccess, {
                    connector: e.name
                }))
            } catch (P) {
                const L = P instanceof Error ? P.message : void 0;
                c.danger(L != null ? L : i.formatMessage(ke.syncConnectorError, {
                    connector: e.name
                }), {
                    toastId: "connector_oauth_connect"
                })
            } finally {
                x(!1)
            }
        }, C = f ? t.jsx(Bn, {
            connection: f,
            location: "user_settings"
        }) : s && t.jsx(mn, {
            onClick: () => {
                if (j) {
                    S();
                    return
                }
                h({
                    link: s,
                    referrer: v
                })
            },
            loading: y || g === "upgrade-succeeded-updating-status" || g === "upgrade-pending",
            tooltip: i.formatMessage(ke.syncFilesForBetterAnswersTooltip, {
                connector: e.name
            })
        });
        return t.jsx(Gn, {
            connector: e,
            trailingButton: C
        })
    },
    Kg = s => {
        "use forget";
        var Tn, to, so, no, ao, oo, io, ro, lo;
        const e = Se.c(231),
            {
                onCreateCustomConnectorClick: a,
                onAddClick: n
            } = s,
            o = ve(),
            i = K(),
            c = hi(),
            l = Vr(),
            d = xi(!0, Ot.CONNECTOR_SETTING);
        let r;
        e[0] === Symbol.for("react.memo_cache_sentinel") ? (r = {
            fetchValidLinksOnly: !0,
            productSku: Ot.CONNECTOR_SETTING
        }, e[0] = r) : r = e[0];
        const u = Ia(r),
            {
                data: f
            } = da(),
            p = Gs(),
            g = zs(),
            h = !(g != null && g.isPersonalAccount()) && (g == null ? void 0 : g.planType) !== vt.SELF_SERVE_BUSINESS;
        let y;
        e[1] !== o ? (y = () => cr(o), e[1] = o, e[2] = y) : y = e[2];
        const {
            shouldRenderButton: x,
            isDisabledByAdmin: j
        } = Qe(y);
        let v;
        e[3] !== l.availableConnectors ? (v = new Set(l.availableConnectors.map(qg)), e[3] = l.availableConnectors, e[4] = v) : v = e[4];
        const S = v;
        let C;
        e[5] !== S || e[6] !== d.platformConnectors || e[7] !== c ? (C = Array.from(d.platformConnectors.values()).filter(ge => {
            var ut;
            if ($r.has(ge.id) || ge.connector_type === "FIRST_PARTY_ECOSYSTEM" && !((ut = ge.app_metadata) != null && ut.first_party_requires_install)) return !1;
            const Ie = S.has(ge.id),
                qe = Object.values(bo).some(bt => {
                    const {
                        access: Xt,
                        sync: Gt
                    } = bt;
                    return Xt === ge.id && S.has(Gt)
                });
            return ge.connector_type === "MCP" || ge.connector_type === "FIRST_PARTY_ECOSYSTEM" || Ie || qe || ge.id === xs && c
        }), e[5] = S, e[6] = d.platformConnectors, e[7] = c, e[8] = C) : C = e[8];
        const M = C,
            E = Kr(),
            {
                isLoading: N,
                isEnabled: k
            } = qr(),
            P = h ? k && !N : !0,
            L = nt("linear"),
            A = nt("dropbox"),
            _ = nt("box"),
            D = nt("notion"),
            T = nt("hubspot"),
            F = nt("confluence"),
            O = nt("jira"),
            I = nt("jira_servicemanagement"),
            U = nt("intercom"),
            R = nt("aha"),
            B = nt("asana"),
            z = nt("azure_devops"),
            W = nt("basecamp"),
            V = nt("clickup"),
            J = nt("front"),
            ce = nt("gitlab"),
            ae = nt("gorgias"),
            Z = nt("help_scout"),
            $ = nt("ironclad"),
            ee = nt("pipedrive"),
            de = nt("shortcut"),
            ye = nt("teamwork"),
            ze = nt("zendesk"),
            Le = nt("zoho"),
            Me = nt("zoho_desk");
        let me;
        e[9] !== (f == null ? void 0 : f.connection_statuses) ? (me = f == null ? void 0 : f.connection_statuses.some(Yg), e[9] = f == null ? void 0 : f.connection_statuses, e[10] = me) : me = e[10];
        const xe = !!me,
            Ce = E && P || xe;
        let He;
        e[11] !== Ce ? (He = {
            connectorId: ea,
            shouldRenderRow: Ce
        }, e[11] = Ce, e[12] = He) : He = e[12];
        let Be;
        e[13] !== L ? (Be = {
            connectorId: Xr,
            shouldRenderRow: L
        }, e[13] = L, e[14] = Be) : Be = e[14];
        let G;
        e[15] !== A ? (G = {
            connectorId: Jr,
            shouldRenderRow: A
        }, e[15] = A, e[16] = G) : G = e[16];
        let se;
        e[17] !== _ ? (se = {
            connectorId: el,
            shouldRenderRow: _
        }, e[17] = _, e[18] = se) : se = e[18];
        let pe;
        e[19] !== F ? (pe = {
            connectorId: rt[lt.CONFLUENCE_CONNECTOR],
            shouldRenderRow: F
        }, e[19] = F, e[20] = pe) : pe = e[20];
        let fe;
        e[21] !== O ? (fe = {
            connectorId: rt[lt.JIRA_CONNECTOR],
            shouldRenderRow: O
        }, e[21] = O, e[22] = fe) : fe = e[22];
        let be;
        e[23] !== I ? (be = {
            connectorId: rt[lt.JIRA_SERVICEMANAGEMENT_CONNECTOR],
            shouldRenderRow: I
        }, e[23] = I, e[24] = be) : be = e[24];
        let Te;
        e[25] !== D ? (Te = {
            connectorId: sl,
            shouldRenderRow: D,
            syncConnectorId: tl
        }, e[25] = D, e[26] = Te) : Te = e[26];
        let Oe;
        e[27] !== T ? (Oe = {
            connectorId: al,
            shouldRenderRow: T,
            syncConnectorId: nl
        }, e[27] = T, e[28] = Oe) : Oe = e[28];
        let We;
        e[29] !== U ? (We = {
            connectorId: il,
            shouldRenderRow: U,
            syncConnectorId: ol
        }, e[29] = U, e[30] = We) : We = e[30];
        let Ve;
        e[31] !== R ? (Ve = {
            connectorId: rt[lt.AHA_CONNECTOR],
            shouldRenderRow: R
        }, e[31] = R, e[32] = Ve) : Ve = e[32];
        let ot;
        e[33] !== B ? (ot = {
            connectorId: rt[lt.ASANA_CONNECTOR],
            shouldRenderRow: B
        }, e[33] = B, e[34] = ot) : ot = e[34];
        let Ze;
        e[35] !== z ? (Ze = {
            connectorId: rt[lt.AZURE_DEVOPS_CONNECTOR],
            shouldRenderRow: z
        }, e[35] = z, e[36] = Ze) : Ze = e[36];
        let Fe;
        e[37] !== W ? (Fe = {
            connectorId: rt[lt.BASECAMP_CONNECTOR],
            shouldRenderRow: W
        }, e[37] = W, e[38] = Fe) : Fe = e[38];
        let Ge;
        e[39] !== V ? (Ge = {
            connectorId: rt[lt.CLICKUP_CONNECTOR],
            shouldRenderRow: V
        }, e[39] = V, e[40] = Ge) : Ge = e[40];
        let Xe;
        e[41] !== J ? (Xe = {
            connectorId: rt[lt.FRONT_CONNECTOR],
            shouldRenderRow: J
        }, e[41] = J, e[42] = Xe) : Xe = e[42];
        let X;
        e[43] !== ce ? (X = {
            connectorId: rt[lt.GITLAB_CONNECTOR],
            shouldRenderRow: ce
        }, e[43] = ce, e[44] = X) : X = e[44];
        let re;
        e[45] !== ae ? (re = {
            connectorId: rt[lt.GORGIAS_CONNECTOR],
            shouldRenderRow: ae
        }, e[45] = ae, e[46] = re) : re = e[46];
        let we;
        e[47] !== Z ? (we = {
            connectorId: rt[lt.HELP_SCOUT_CONNECTOR],
            shouldRenderRow: Z
        }, e[47] = Z, e[48] = we) : we = e[48];
        let te;
        e[49] !== $ ? (te = {
            connectorId: rt[lt.IRONCLAD_CONNECTOR],
            shouldRenderRow: $
        }, e[49] = $, e[50] = te) : te = e[50];
        let oe;
        e[51] !== ee ? (oe = {
            connectorId: rt[lt.PIPEDRIVE_CONNECTOR],
            shouldRenderRow: ee
        }, e[51] = ee, e[52] = oe) : oe = e[52];
        let le;
        e[53] !== de ? (le = {
            connectorId: rt[lt.SHORTCUT_CONNECTOR],
            shouldRenderRow: de
        }, e[53] = de, e[54] = le) : le = e[54];
        let he;
        e[55] !== ye ? (he = {
            connectorId: rt[lt.TEAMWORK_CONNECTOR],
            shouldRenderRow: ye
        }, e[55] = ye, e[56] = he) : he = e[56];
        let H;
        e[57] !== ze ? (H = {
            connectorId: rt[lt.ZENDESK_CONNECTOR],
            shouldRenderRow: ze
        }, e[57] = ze, e[58] = H) : H = e[58];
        let ue;
        e[59] !== Le ? (ue = {
            connectorId: rt[lt.ZOHO_CONNECTOR],
            shouldRenderRow: Le
        }, e[59] = Le, e[60] = ue) : ue = e[60];
        let _e;
        e[61] !== Me ? (_e = {
            connectorId: rt[lt.ZOHO_DESK_CONNECTOR],
            shouldRenderRow: Me
        }, e[61] = Me, e[62] = _e) : _e = e[62];
        let st;
        e[63] !== se || e[64] !== pe || e[65] !== fe || e[66] !== be || e[67] !== Te || e[68] !== Oe || e[69] !== We || e[70] !== Ve || e[71] !== ot || e[72] !== Ze || e[73] !== Fe || e[74] !== Ge || e[75] !== Xe || e[76] !== X || e[77] !== re || e[78] !== we || e[79] !== te || e[80] !== oe || e[81] !== le || e[82] !== he || e[83] !== H || e[84] !== ue || e[85] !== _e || e[86] !== He || e[87] !== Be || e[88] !== G ? (st = [He, Be, G, se, pe, fe, be, Te, Oe, We, Ve, ot, Ze, Fe, Ge, Xe, X, re, we, te, oe, le, he, H, ue, _e], e[63] = se, e[64] = pe, e[65] = fe, e[66] = be, e[67] = Te, e[68] = Oe, e[69] = We, e[70] = Ve, e[71] = ot, e[72] = Ze, e[73] = Fe, e[74] = Ge, e[75] = Xe, e[76] = X, e[77] = re, e[78] = we, e[79] = te, e[80] = oe, e[81] = le, e[82] = he, e[83] = H, e[84] = ue, e[85] = _e, e[86] = He, e[87] = Be, e[88] = G, e[89] = st) : st = e[89];
        const ht = st;
        let Nt;
        if (e[90] !== d.platformConnectors || e[91] !== xe || e[92] !== u.connectorLinks || e[93] !== u.refetch || e[94] !== ht) {
            Nt = [];
            for (const {
                    connectorId: ge,
                    shouldRenderRow: Ie,
                    syncConnectorId: qe
                } of ht) {
                if (!Ie) continue;
                const ut = d.platformConnectors.has(ge),
                    bt = ut ? ge : qe,
                    Xt = bt ? d.platformConnectors.get(bt) : void 0,
                    Gt = (Tn = u.connectorLinks.get(ge)) == null ? void 0 : Tn[0],
                    Ds = qe ? (to = u.connectorLinks.get(qe)) == null ? void 0 : to[0] : void 0,
                    rn = Gt != null ? Gt : Ds;
                if (!Xt) continue;
                const Ls = ge === ea && xe;
                (Ls || rn) && (Ds && ut && Gt || Nt.push({
                    connector: Xt,
                    row: t.jsx($g, {
                        link: rn,
                        isAdminSyncConnected: Ls,
                        connector: Xt,
                        syncConnectorId: qe,
                        refetchLinks: u.refetch
                    })
                }))
            }
            e[90] = d.platformConnectors, e[91] = xe, e[92] = u.connectorLinks, e[93] = u.refetch, e[94] = ht, e[95] = Nt
        } else Nt = e[95];
        const Tt = Nt;
        let Vt;
        e[96] !== Tt ? (Vt = Tt.map(Qg), e[96] = Tt, e[97] = Vt) : Vt = e[97];
        const Ms = Vt;
        let $t;
        e[98] !== Ms || e[99] !== u.connectorLinks ? ($t = new Map(u.connectorLinks), $t.delete(xs), $t.delete(ha), Ms.forEach(ge => {
            $t.delete(ge)
        }), e[98] = Ms, e[99] = u.connectorLinks, e[100] = $t) : $t = e[100];
        const Je = $t,
            {
                fileUploadConfig: it,
                internalKnowledgeConfigs: et
            } = ua(),
            Ft = bi();
        let vs;
        e[101] !== et ? (vs = (so = et == null ? void 0 : et.filter(Zg).length) != null ? so : 0, e[101] = et, e[102] = vs) : vs = e[102];
        const Cs = vs;
        let En;
        e[103] !== u.connectorLinks ? (En = (ao = (no = u.connectorLinks.get(xs)) == null ? void 0 : no.length) != null ? ao : 0, e[103] = u.connectorLinks, e[104] = En) : En = e[104];
        const Hs = En,
            Ut = !!(it != null && it.access_token) || Hs > 0 || Cs > 0,
            Ws = !!((oo = Ft.personalConfig) != null && oo.access_token),
            ss = !!((io = Ft.businessConfig) != null && io.access_token);
        let Kt;
        e[105] !== d.platformConnectors ? (Kt = d.platformConnectors.get(xs), e[105] = d.platformConnectors, e[106] = Kt) : Kt = e[106];
        const js = Kt;
        let Ss;
        e[107] !== u.connectorLinks ? (Ss = (ro = u.connectorLinks.get(ha)) == null ? void 0 : ro[0], e[107] = u.connectorLinks, e[108] = Ss) : Ss = e[108];
        const Rt = Ss;
        let Vs;
        e[109] !== d.platformConnectors ? (Vs = d.platformConnectors.get(ha), e[109] = d.platformConnectors, e[110] = Vs) : Vs = e[110];
        const ns = Vs;
        let as;
        e[111] !== M || e[112] !== S || e[113] !== Ut || e[114] !== xe || e[115] !== u.connectorLinks ? (as = M.filter(ge => {
            const Ie = Object.values(bo).find(qe => qe.access === ge.id || qe.sync === ge.id);
            if (ge.id === xs) return !Ut;
            if (u.connectorLinks.has(ge.id)) return !1;
            if (ge.id === ea) return !xe;
            if (Ie) {
                const qe = u.connectorLinks.has(Ie.access),
                    ut = u.connectorLinks.has(Ie.sync);
                if (Ie.access === ge.id) return !qe && !ut;
                if (Ie.sync === ge.id) return S.has(Ie.access) ? !1 : !ut
            }
            return !0
        }), e[111] = M, e[112] = S, e[113] = Ut, e[114] = xe, e[115] = u.connectorLinks, e[116] = as) : as = e[116];
        const ds = as;
        let os;
        if (e[117] !== ds) {
            const ge = [],
                Ie = [];
            ds.forEach(qe => {
                var ut, bt, Xt;
                (ut = qe.branding) != null && ut.is_discoverable_app || ((bt = qe.app_metadata) == null ? void 0 : bt.first_party_type) === "hermes" || (Xt = qe.app_metadata) != null && Xt.version ? ge.push(qe) : Ie.push(qe)
            }), os = [ge, Ie], e[117] = ds, e[118] = os
        } else os = e[118];
        const [At, qt] = os;
        let $s;
        e[119] !== At ? ($s = At.slice(0, 4), e[119] = At, e[120] = $s) : $s = e[120];
        const us = $s;
        let is;
        e[121] !== M ? (is = M.filter(Xg), e[121] = M, e[122] = is) : is = e[122];
        const Yt = is;
        let rs;
        e[123] !== o ? (rs = kn(o), e[123] = o, e[124] = rs) : rs = e[124];
        const Qt = rs;
        if (d.isLoading || l.isLoading || u.isLoading) {
            let ge;
            e[125] === Symbol.for("react.memo_cache_sentinel") ? (ge = t.jsx(m, b({}, ke.connectorsTitle)), e[125] = ge) : ge = e[125];
            let Ie;
            return e[126] === Symbol.for("react.memo_cache_sentinel") ? (Ie = t.jsx(Ne, {
                title: ge,
                children: t.jsx("div", {
                    className: "flex justify-center p-6",
                    children: t.jsx(ys, {})
                })
            }), e[126] = Ie) : Ie = e[126], Ie
        }
        const _s = l.enabled,
            ls = _s && x,
            Ks = !_s || !M.length;
        let qs;
        e[127] !== i || e[128] !== j || e[129] !== a || e[130] !== ls ? (qs = ls ? t.jsx(Da, {
            disabled: j,
            message: ke.createCustomConnectorButton,
            onAddClick: a,
            tooltip: j ? i.formatMessage(ke.createCustomConnectorDisabledByAdmin) : void 0,
            side: "bottom"
        }) : null, e[127] = i, e[128] = j, e[129] = a, e[130] = ls, e[131] = qs) : qs = e[131];
        const dt = qs;
        if (Ks && !Qt) {
            let ge;
            e[132] === Symbol.for("react.memo_cache_sentinel") ? (ge = t.jsx(m, b({}, ke.connectorsTitle)), e[132] = ge) : ge = e[132];
            let Ie;
            e[133] !== dt ? (Ie = dt && t.jsx(t.Fragment, {
                children: dt
            }), e[133] = dt, e[134] = Ie) : Ie = e[134];
            let qe;
            e[135] !== Ie ? (qe = t.jsxs("div", {
                className: "flex items-center justify-between gap-2",
                children: [ge, Ie]
            }), e[135] = Ie, e[136] = qe) : qe = e[136];
            let ut;
            e[137] === Symbol.for("react.memo_cache_sentinel") ? (ut = t.jsx(hn, {
                type: "info",
                className: "mt-4",
                children: t.jsx(m, b({}, ke.noConnectorsAvailable))
            }), e[137] = ut) : ut = e[137];
            let bt;
            return e[138] !== qe ? (bt = t.jsx(Ne, {
                title: qe,
                children: ut
            }), e[138] = qe, e[139] = bt) : bt = e[139], bt
        }
        if (d.error || u.error) {
            let ge;
            e[140] === Symbol.for("react.memo_cache_sentinel") ? (ge = t.jsx(m, b({}, ke.connectorsTitle)), e[140] = ge) : ge = e[140];
            let Ie;
            return e[141] === Symbol.for("react.memo_cache_sentinel") ? (Ie = t.jsx(Ne, {
                title: ge,
                children: t.jsx(hn, {
                    type: "danger",
                    children: t.jsx(m, b({}, ke.error))
                })
            }), e[141] = Ie) : Ie = e[141], Ie
        }
        let cs;
        e[142] !== Je || e[143] !== Tt.length || e[144] !== Rt || e[145] !== Ut || e[146] !== ss || e[147] !== Ws ? (cs = [...Je.values()].some(ef) || Ut || Ws || ss || !!Rt || Tt.length > 0, e[142] = Je, e[143] = Tt.length, e[144] = Rt, e[145] = Ut, e[146] = ss, e[147] = Ws, e[148] = cs) : cs = e[148];
        const xt = cs;
        let Nn;
        (ge => {
            ge.INSTALLED = "INSTALLED", ge.UNLINKED_APPS = "UNLINKED_APPS", ge.UNLINKED_NON_APP_CONNECTORS = "UNLINKED_NON_APP_CONNECTORS"
        })(Nn || (Nn = {}));
        let Zt = null;
        ls && (xt ? Zt = "INSTALLED" : At.length > 0 ? Zt = "UNLINKED_APPS" : qt.length > 0 && (Zt = "UNLINKED_NON_APP_CONNECTORS"));
        let ws;
        e[149] !== (it == null ? void 0 : it.access_token) || e[150] !== js || e[151] !== (et == null ? void 0 : et.length) || e[152] !== Ut || e[153] !== u.connectorLinks || e[154] !== Hs || e[155] !== Cs || e[156] !== n || e[157] !== p ? (ws = Ut && js ? t.jsx(Wg, {
            gdrivePlatformConnector: js,
            isFileUploadsEnabled: !!(it != null && it.access_token),
            numPlatformLinks: Hs,
            platformLinks: u.connectorLinks,
            numInternalKnowledgeLinks: Cs,
            numInternalKnowledgeConfigs: (lo = et == null ? void 0 : et.length) != null ? lo : 0,
            onAddClick: () => {
                p(xs), n()
            }
        }) : null, e[149] = it == null ? void 0 : it.access_token, e[150] = js, e[151] = et == null ? void 0 : et.length, e[152] = Ut, e[153] = u.connectorLinks, e[154] = Hs, e[155] = Cs, e[156] = n, e[157] = p, e[158] = ws) : ws = e[158];
        let ks;
        e[159] !== Ws || e[160] !== Ft.personalConfig || e[161] !== p ? (ks = Ws && Ft.personalConfig ? t.jsx(Ko, {
            config: Ft.personalConfig,
            onClick: () => p("onedrive-personal")
        }) : null, e[159] = Ws, e[160] = Ft.personalConfig, e[161] = p, e[162] = ks) : ks = e[162];
        let Es;
        e[163] !== ss || e[164] !== Ft.businessConfig || e[165] !== p ? (Es = ss && Ft.businessConfig ? t.jsx(Ko, {
            config: Ft.businessConfig,
            onClick: () => p("onedrive-business")
        }) : null, e[163] = ss, e[164] = Ft.businessConfig, e[165] = p, e[166] = Es) : Es = e[166];
        let Ns;
        e[167] !== Rt || e[168] !== ns ? (Ns = Rt && ns ? t.jsx(Vg, {
            githubLink: Rt,
            githubPlatformConnector: ns
        }) : null, e[167] = Rt, e[168] = ns, e[169] = Ns) : Ns = e[169];
        let tn;
        e[170] !== M || e[171] !== Je || e[172] !== Tt || e[173] !== ws || e[174] !== ks || e[175] !== Es || e[176] !== Ns ? (tn = t.jsx(Hg, {
            connectorLinks: Je,
            platformConnectors: M,
            gdriveRow: ws,
            onedrivePersonalRow: ks,
            onedriveBusinessRow: Es,
            githubRow: Ns,
            genericSyncableRows: Tt
        }), e[170] = M, e[171] = Je, e[172] = Tt, e[173] = ws, e[174] = ks, e[175] = Es, e[176] = Ns, e[177] = tn) : tn = e[177];
        const Ts = tn;
        if (Qt) {
            let ge;
            e[178] !== xt ? (ge = xt && !yi.getItem(Mi.HomeDiscoveryDismissed), e[178] = xt, e[179] = ge) : ge = e[179];
            const Ie = ge,
                qe = Yt.length > 0;
            let ut;
            e[180] !== Ts || e[181] !== xt ? (ut = xt && t.jsx(Ne, {
                headerInteractable: !0,
                title: t.jsxs("div", {
                    className: "flex items-center justify-between gap-2",
                    children: [t.jsx("span", {
                        className: "select-none",
                        children: t.jsx(m, b({}, ke.enabledAppsTitle))
                    }), t.jsxs(ne, {
                        as: "link",
                        to: "/apps",
                        state: Oi("settings-apps"),
                        color: "secondary",
                        size: "medium",
                        contentWrapperClassName: "gap-1.5",
                        children: [t.jsx(ed, {
                            className: "icon-sm text-token-text-primary"
                        }), t.jsx(m, b({}, ke.addAppsButton))]
                    })]
                }),
                description: t.jsx(m, b({}, ke.enabledAppsDescription)),
                children: Ts
            }), e[180] = Ts, e[181] = xt, e[182] = ut) : ut = e[182];
            let bt;
            e[183] !== us || e[184] !== qe || e[185] !== xt ? (bt = !xt && t.jsx(Ne, {
                className: Ht("flex flex-1 flex-col", !qe && "mb-0"),
                headerInteractable: !0,
                title: t.jsx("div", {
                    className: "flex items-center justify-between gap-2",
                    children: t.jsx("span", {
                        className: "select-none",
                        children: t.jsx(m, b({}, ke.appsTitle))
                    })
                }),
                children: t.jsx(zg, {
                    apps: us
                })
            }), e[183] = us, e[184] = qe, e[185] = xt, e[186] = bt) : bt = e[186];
            const Xt = xt && "-mt-4";
            let Gt;
            e[187] !== Xt ? (Gt = Ht(Xt), e[187] = Xt, e[188] = Gt) : Gt = e[188];
            let Ds;
            e[189] !== Gt ? (Ds = t.jsx("span", {
                id: "developer-mode-settings",
                className: Gt
            }), e[189] = Gt, e[190] = Ds) : Ds = e[190];
            const rn = !xt && !qe && "mt-auto";
            let Ls;
            e[191] !== rn ? (Ls = Ht(rn), e[191] = rn, e[192] = Ls) : Ls = e[192];
            let ln;
            e[193] !== dt ? (ln = t.jsx(qo, {
                createButton: dt
            }), e[193] = dt, e[194] = ln) : ln = e[194];
            let cn;
            e[195] !== Ls || e[196] !== ln ? (cn = t.jsx("div", {
                className: Ls,
                children: ln
            }), e[195] = Ls, e[196] = ln, e[197] = cn) : cn = e[197];
            let dn;
            e[198] !== Ie ? (dn = Ie && t.jsx(hn, {
                isDismissible: !0,
                className: "bg-token-bg-tertiary mt-4",
                onDismiss: tf,
                children: t.jsxs("div", {
                    className: "flex flex-col select-none",
                    children: [t.jsx("span", {
                        className: "mb-1 font-medium",
                        children: t.jsx(m, b({}, ke.connectorsMovedNoticeTitle))
                    }), t.jsx("span", {
                        children: t.jsx(m, Ee(b({}, ke.connectorsMovedNoticeDescription), {
                            values: {
                                link: sf
                            }
                        }))
                    })]
                })
            }), e[198] = Ie, e[199] = dn) : dn = e[199];
            let un;
            e[200] !== Yt ? (un = Yt.length > 0 && t.jsx(Ne, {
                title: t.jsx(m, b({}, ke.devAppsTitle)),
                description: t.jsx(m, b({}, ke.devAppsDescription)),
                children: t.jsx("div", {
                    className: "flex flex-col gap-2",
                    children: Yt.map(nf)
                })
            }), e[200] = Yt, e[201] = un) : un = e[201];
            let zn;
            return e[202] !== ut || e[203] !== bt || e[204] !== Ds || e[205] !== cn || e[206] !== dn || e[207] !== un ? (zn = t.jsxs("div", {
                className: "flex flex-col",
                children: [ut, bt, Ds, cn, dn, un]
            }), e[202] = ut, e[203] = bt, e[204] = Ds, e[205] = cn, e[206] = dn, e[207] = un, e[208] = zn) : zn = e[208], zn
        }
        let As;
        e[209] !== dt || e[210] !== Ts || e[211] !== xt || e[212] !== Qt ? (As = xt && t.jsx(Ne, {
            headerInteractable: !0,
            title: t.jsxs("div", {
                className: "flex items-center justify-between gap-2",
                children: [t.jsx("span", {
                    className: "select-none",
                    children: t.jsx(m, b({}, ke.enabledAppsConnectorsTitle))
                }), dt]
            }),
            description: t.jsx("div", {
                className: Qt ? "mt-2" : "",
                children: t.jsx(m, b({}, ke.enabledAppsConnectorsDescription))
            }),
            children: Ts
        }), e[209] = dt, e[210] = Ts, e[211] = xt, e[212] = Qt, e[213] = As) : As = e[213];
        let Ps;
        e[214] !== dt || e[215] !== Zt || e[216] !== At ? (Ps = At.length > 0 && t.jsx(Ne, {
            noBorder: !0,
            headerInteractable: !0,
            title: t.jsxs("div", {
                className: "flex items-center justify-between gap-2",
                children: [t.jsx("span", {
                    className: "select-none",
                    children: t.jsx(m, b({}, ke.allAppsTitle))
                }), Zt === "UNLINKED_APPS" && dt]
            }),
            description: t.jsx(m, Ee(b({}, ke.appsDescription), {
                values: {
                    link: af
                }
            })),
            children: t.jsx(Wo, {
                connectors: At
            })
        }), e[214] = dt, e[215] = Zt, e[216] = At, e[217] = Ps) : Ps = e[217];
        let mt;
        e[218] !== dt || e[219] !== Zt || e[220] !== qt ? (mt = qt.length > 0 && t.jsx(Ne, {
            noBorder: !0,
            headerInteractable: !0,
            title: t.jsxs("div", {
                className: "flex items-center justify-between gap-2",
                children: [t.jsx("span", {
                    className: "select-none",
                    children: t.jsx(m, b({}, ke.allConnectorsTitle))
                }), Zt === "UNLINKED_NON_APP_CONNECTORS" && dt]
            }),
            description: t.jsx(m, Ee(b({}, ke.connectorsDescription), {
                values: {
                    link: of
                }
            })),
            children: t.jsx(Wo, {
                connectors: qt
            })
        }), e[218] = dt, e[219] = Zt, e[220] = qt, e[221] = mt) : mt = e[221];
        let Pt, yt;
        e[222] === Symbol.for("react.memo_cache_sentinel") ? (Pt = t.jsx("div", {
            className: "flex-auto"
        }), yt = t.jsx("span", {
            id: "developer-mode-settings"
        }), e[222] = Pt, e[223] = yt) : (Pt = e[222], yt = e[223]);
        let Dt;
        e[224] !== dt ? (Dt = t.jsxs(Ne, {
            children: [Pt, yt, t.jsx(qo, {
                createButton: dt
            })]
        }), e[224] = dt, e[225] = Dt) : Dt = e[225];
        let Ys;
        return e[226] !== As || e[227] !== Ps || e[228] !== mt || e[229] !== Dt ? (Ys = t.jsxs(t.Fragment, {
            children: [As, Ps, mt, Dt]
        }), e[226] = As, e[227] = Ps, e[228] = mt, e[229] = Dt, e[230] = Ys) : Ys = e[230], Ys
    };

function qo(s) {
    "use forget";
    const e = Se.c(27),
        {
            createButton: a
        } = s,
        n = ve(),
        o = K(),
        i = bs();
    let c;
    e[0] !== n ? (c = () => Os(n), e[0] = n, e[1] = c) : c = e[1];
    const l = Qe(c);
    let d;
    if (e[2] !== n ? (d = () => Ci(n), e[2] = n, e[3] = d) : d = e[3], !Qe(d) && !l) return null;
    let u;
    e[4] === Symbol.for("react.memo_cache_sentinel") ? (u = t.jsx("hr", {
        className: "border-token-border-light"
    }), e[4] = u) : u = e[4];
    let f;
    e[5] !== i ? (f = () => i("#settings/Connectors/Advanced"), e[5] = i, e[6] = f) : f = e[6];
    let p, g;
    e[7] === Symbol.for("react.memo_cache_sentinel") ? (p = t.jsx("div", {
        className: "border-token-border-heavy bg-token-bg-primary shadow-xxs flex h-8 w-8 items-center justify-center rounded-full border-[0.5px]",
        children: t.jsx(ji, {
            "aria-hidden": !0,
            className: "icon"
        })
    }), g = t.jsx(m, b({}, ke.advancedSettings)), e[7] = p, e[8] = g) : (p = e[7], g = e[8]);
    let h;
    e[9] !== f ? (h = t.jsxs("button", {
        className: "flex min-w-0 flex-1 flex-row items-center gap-3 py-4 text-start",
        type: "button",
        onClick: f,
        children: [p, g]
    }), e[9] = f, e[10] = h) : h = e[10];
    let y;
    e[11] !== a ? (y = a ? t.jsx("div", {
        className: "shrink-0",
        children: a
    }) : null, e[11] = a, e[12] = y) : y = e[12];
    let x;
    e[13] !== o ? (x = o.formatMessage(ke.advancedSettings), e[13] = o, e[14] = x) : x = e[14];
    let j;
    e[15] !== i ? (j = () => i("#settings/Connectors/Advanced"), e[15] = i, e[16] = j) : j = e[16];
    let v;
    e[17] === Symbol.for("react.memo_cache_sentinel") ? (v = t.jsx(vn, {
        className: "icon"
    }), e[17] = v) : v = e[17];
    let S;
    e[18] !== j || e[19] !== x ? (S = t.jsx("button", {
        type: "button",
        "aria-label": x,
        className: "text-token-text-primary me-0.5 flex min-h-[38px] items-center",
        onClick: j,
        children: v
    }), e[18] = j, e[19] = x, e[20] = S) : S = e[20];
    let C;
    e[21] !== S || e[22] !== y ? (C = t.jsxs("div", {
        className: "flex items-center gap-2",
        children: [y, S]
    }), e[21] = S, e[22] = y, e[23] = C) : C = e[23];
    let M;
    return e[24] !== C || e[25] !== h ? (M = t.jsxs(t.Fragment, {
        children: [u, t.jsxs("div", {
            className: "flex cursor-pointer items-center justify-between gap-3 ps-0.5",
            children: [h, C]
        })]
    }), e[24] = C, e[25] = h, e[26] = M) : M = e[26], M
}
const ke = Ke({
    contactAdminTooltip: {
        id: "q5N+up",
        defaultMessage: "Contact your admin to enable Google Drive for chat."
    },
    addChatAndOrDeepResearch: {
        id: "4/yhnQ",
        defaultMessage: "Add chat, deep research"
    },
    addDeepResearch: {
        id: "PT3yzw",
        defaultMessage: "Add deep research"
    },
    deepResearchDisabledByAdmin: {
        id: "uYQCnH",
        defaultMessage: "Your admin has not enabled deep research for Google Drive."
    },
    setupIncompleteGithub: {
        id: "WPhFYm",
        defaultMessage: "Setup incomplete"
    },
    syncForBetterAnswers: {
        id: "6wQ3rX",
        defaultMessage: "Enable sync"
    },
    syncForBetterAnswersTooltip: {
        id: "zhVkue",
        defaultMessage: "Sync Google Drive files to ChatGPT for faster, more relevant answers."
    },
    syncConnectorSuccess: {
        id: "oyKGlh",
        defaultMessage: "{connector} is now connected and syncing."
    },
    syncConnectorError: {
        id: "P7CgsH",
        defaultMessage: "Failed to connect and start syncing {connector}."
    },
    syncFilesForBetterAnswersTooltip: {
        id: "+u4cD2",
        defaultMessage: "Sync {connector} files to ChatGPT for faster, more relevant answers."
    },
    addAppsButton: {
        id: "9nddI+",
        defaultMessage: "Add more"
    },
    appsTitle: {
        id: "Y+czYr",
        defaultMessage: "Apps"
    },
    allAppsTitle: {
        id: "vSrYkz",
        defaultMessage: "Browse Apps"
    },
    appsDescription: {
        id: "cg5JvO",
        defaultMessage: "Connect apps so you can talk to them with visual and interactive experiences in ChatGPT. <link>Learn more</link>."
    },
    connectorsTitle: {
        id: "CRwNSN",
        defaultMessage: "Connectors"
    },
    allConnectorsTitle: {
        id: "cL3AUC",
        defaultMessage: "Browse connectors"
    },
    connectorsDescription: {
        id: "qKGquG",
        defaultMessage: "ChatGPT can access information from your connected tools to give you more useful answers. Your permissions are always respected. <link>Learn more</link>."
    },
    createCustomConnectorButton: {
        id: "DFa4mD",
        defaultMessage: "Create app"
    },
    createCustomConnectorDisabledByAdmin: {
        id: "createCustomConnectorDisabledByAdmin",
        defaultMessage: "Your admin has not enabled access to Developer Mode."
    },
    noConnectorsAvailable: {
        id: "rOddez",
        defaultMessage: "No connectors available"
    },
    connectorsMovedNoticeTitle: {
        id: "jjbcfp",
        defaultMessage: "Looking for Connectors?"
    },
    connectorsMovedNoticeDescription: {
        id: "wdeHr4",
        defaultMessage: "Connectors are now called Apps. You can still manage enabled ones here. <link>Explore all apps</link>"
    },
    enabledAppsTitle: {
        id: "AuVGPH",
        defaultMessage: "Enabled apps"
    },
    enabledAppsDescription: {
        id: "o8qCrp",
        defaultMessage: "Manage enabled apps ChatGPT can use in your chats."
    },
    enabledAppsConnectorsTitle: {
        id: "7EXTHH",
        defaultMessage: "Enabled apps and connectors"
    },
    enabledAppsConnectorsDescription: {
        id: "OEoK2K",
        defaultMessage: "The apps and connectors you’ve enabled appear here. ChatGPT can use them in your conversations, based on the permissions you’ve granted."
    },
    error: {
        id: "F+mY2E",
        defaultMessage: "Error fetching connectors"
    },
    advancedSettings: {
        id: "6qpafZ",
        defaultMessage: "Advanced settings"
    },
    devAppsTitle: {
        id: "JBDbar",
        defaultMessage: "Drafts"
    },
    devAppsDescription: {
        id: "jIjpz+",
        defaultMessage: "Private apps you've created in developer mode."
    }
});

function qg(s) {
    return s.id
}

function Yg(s) {
    return s.user_connection_details.connection_type === "sharepoint_admin_sync_connector" && s.user_connection_details.auth_status === "admin_connected"
}

function Qg(s) {
    return s.connector.id
}

function Zg(s) {
    return s.user_connection_details.auth_status !== "not_connected"
}

function Xg(s) {
    return s.status === "ONLY_ME"
}

function Jg(s) {
    return s.visibility !== "HIDDEN"
}

function ef(s) {
    return s.some(Jg)
}

function tf() {
    return yi.setItem(Mi.HomeDiscoveryDismissed, !0)
}

function sf(s) {
    return t.jsx(Rs, {
        href: "/apps",
        openNewTab: !0,
        children: s
    })
}

function nf(s) {
    return t.jsx(Gn, {
        connector: s
    }, s.id)
}

function af(s) {
    return t.jsx(Rs, {
        href: "https://help.openai.com/en/articles/12503483-apps-in-chatgpt-and-the-apps-sdk",
        openNewTab: !0,
        children: s
    })
}

function of (s) {
    return t.jsx(Rs, {
        href: "https://help.openai.com/en/collections/12923329-connected-apps",
        openNewTab: !0,
        children: s
    })
}
const rf = "https://platform.openai.com/docs/mcp#risks-and-safety",
    an = Ke({
        title: {
            id: "QvgpB4",
            defaultMessage: "Advanced settings"
        },
        developerModeTitle: {
            id: "4DDtEK",
            defaultMessage: "Developer mode"
        },
        developerModeDescription: {
            id: "Uo45Zz",
            defaultMessage: "Allows you to add unverified connectors that could modify or erase data permanently. Memory is disabled. Use at your own risk. <link>Learn more</link>"
        },
        developerModeDisabledByAdmin: {
            id: "1dOaHH",
            defaultMessage: "Your admin has not enabled developer mode."
        },
        backButton: {
            id: "2XH9oW",
            defaultMessage: "Back"
        },
        createCustomConnectorButton: {
            id: "lPzbCm",
            defaultMessage: "Create app"
        },
        createCustomConnectorDisabledByAdmin: {
            id: "kQKvCS",
            defaultMessage: "Your admin has not enabled access to Developer Mode."
        }
    }),
    lf = s => {
        "use forget";
        const e = Se.c(14),
            {
                disabled: a,
                message: n,
                onAddClick: o,
                tooltip: i,
                side: c
            } = s,
            l = c === void 0 ? "right" : c;
        let d;
        e[0] !== o ? (d = p => {
            p.preventDefault(), o()
        }, e[0] = o, e[1] = d) : d = e[1];
        let r;
        e[2] !== n ? (r = t.jsx(m, b({}, n)), e[2] = n, e[3] = r) : r = e[3];
        let u;
        e[4] !== a || e[5] !== d || e[6] !== r ? (u = t.jsx(ne, {
            color: "secondary",
            disabled: a,
            onClick: d,
            size: "small",
            children: r
        }), e[4] = a, e[5] = d, e[6] = r, e[7] = u) : u = e[7];
        const f = u;
        if (i) {
            let p;
            e[8] !== i ? (p = t.jsx("div", {
                className: "max-w-50",
                children: i
            }), e[8] = i, e[9] = p) : p = e[9];
            let g;
            return e[10] !== f || e[11] !== l || e[12] !== p ? (g = t.jsx(Wt, {
                label: p,
                side: l,
                children: f
            }), e[10] = f, e[11] = l, e[12] = p, e[13] = g) : g = e[13], g
        }
        return f
    };

function cf(s) {
    "use forget";
    const e = Se.c(47),
        {
            onBack: a,
            onCreateCustomConnectorClick: n
        } = s,
        o = ve(),
        i = K();
    let c;
    e[0] !== o ? (c = () => Os(o), e[0] = o, e[1] = c) : c = e[1];
    const l = Qe(c),
        d = kt(!0);
    let r;
    e[2] !== o ? (r = () => Ci(o), e[2] = o, e[3] = r) : r = e[3];
    const u = Qe(r);
    let f;
    e[4] !== o ? (f = () => ul(o), e[4] = o, e[5] = f) : f = e[5];
    const p = Qe(f);
    let g;
    e[6] !== o ? (g = je(o, "3582352215"), e[6] = o, e[7] = g) : g = e[7];
    const y = l && g;
    let x;
    e[8] !== o ? (x = kn(o), e[8] = o, e[9] = x) : x = e[9];
    const j = x;
    let v;
    e[10] !== o ? (v = () => cr(o), e[10] = o, e[11] = v) : v = e[11];
    const {
        shouldRenderButton: S,
        isDisabledByAdmin: C
    } = Qe(v);
    let M;
    e[12] !== j || e[13] !== i || e[14] !== C || e[15] !== l || e[16] !== n || e[17] !== S ? (M = l && S && j ? t.jsx(lf, {
        disabled: C,
        message: an.createCustomConnectorButton,
        onAddClick: n,
        tooltip: C ? i.formatMessage(an.createCustomConnectorDisabledByAdmin) : void 0,
        side: "bottom"
    }) : null, e[12] = j, e[13] = i, e[14] = C, e[15] = l, e[16] = n, e[17] = S, e[18] = M) : M = e[18];
    const E = M;
    if (!u && !l) return null;
    let N, k;
    e[19] === Symbol.for("react.memo_cache_sentinel") ? (N = t.jsx(Fa, {
        className: "icon icon-md"
    }), k = t.jsx(m, b({}, an.backButton)), e[19] = N, e[20] = k) : (N = e[19], k = e[20]);
    let P;
    e[21] !== a ? (P = t.jsxs(ne, {
        color: "ghost",
        size: "medium",
        onClick: a,
        contentWrapperClassName: "gap-[6px]",
        className: "rounded-lg ps-0.5 pe-1.5",
        children: [N, k]
    }), e[21] = a, e[22] = P) : P = e[22];
    let L;
    e[23] !== E || e[24] !== P ? (L = t.jsxs("div", {
        className: "flex items-center justify-between gap-2",
        children: [P, E]
    }), e[23] = E, e[24] = P, e[25] = L) : L = e[25];
    let A;
    e[26] === Symbol.for("react.memo_cache_sentinel") ? (A = t.jsxs("div", {
        className: "flex items-center gap-2",
        children: [t.jsx(m, b({}, an.developerModeTitle)), t.jsx(Bi, {})]
    }), e[26] = A) : A = e[26];
    let _;
    e[27] !== i ? (_ = i.formatMessage(an.developerModeTitle), e[27] = i, e[28] = _) : _ = e[28];
    const D = !p || d.isPending;
    let T;
    e[29] !== p || e[30] !== i ? (T = p ? void 0 : i.formatMessage(an.developerModeDisabledByAdmin), e[29] = p, e[30] = i, e[31] = T) : T = e[31];
    let F;
    e[32] !== d ? (F = B => {
        d.mutate({
            setting: ie.DeveloperMode,
            value: B
        })
    }, e[32] = d, e[33] = F) : F = e[33];
    let O;
    e[34] === Symbol.for("react.memo_cache_sentinel") ? (O = t.jsx(m, Ee(b({}, an.developerModeDescription), {
        values: {
            link: df
        }
    })), e[34] = O) : O = e[34];
    let I;
    e[35] !== l || e[36] !== _ || e[37] !== D || e[38] !== T || e[39] !== F ? (I = t.jsx(Q, {
        children: t.jsx("div", {
            className: "rounded-md py-4",
            children: t.jsx(ct, {
                label: A,
                ariaLabel: _,
                disabled: D,
                toggleTooltip: T,
                enabled: l,
                onChange: F,
                description: O
            })
        })
    }), e[35] = l, e[36] = _, e[37] = D, e[38] = T, e[39] = F, e[40] = I) : I = e[40];
    let U;
    e[41] !== y ? (U = y && t.jsx(Q, {
        children: t.jsx(Ug, {})
    }), e[41] = y, e[42] = U) : U = e[42];
    let R;
    return e[43] !== L || e[44] !== I || e[45] !== U ? (R = t.jsxs(Ne, {
        title: L,
        children: [I, U]
    }), e[43] = L, e[44] = I, e[45] = U, e[46] = R) : R = e[46], R
}

function df(s) {
    return t.jsx(Rs, {
        href: rf,
        openNewTab: !0,
        children: s
    })
}
const Ye = Ke({
        appVersion: {
            id: "v1ZDFs",
            defaultMessage: "Version name"
        },
        appVersionId: {
            id: "O1JjS2",
            defaultMessage: "Version Id"
        },
        appVersionNotes: {
            id: "oseCth",
            defaultMessage: "Version notes"
        },
        appReviewStatus: {
            id: "xE4C7M",
            defaultMessage: "Review status"
        },
        category: {
            id: "XG1+sz",
            defaultMessage: "Category"
        },
        subcategory: {
            id: "NiXO1S",
            defaultMessage: "Subcategory"
        },
        createdAtLabel: {
            id: "a7VJd0",
            defaultMessage: "Created at"
        },
        connectedOnLabel: {
            id: "YQAQMf",
            defaultMessage: "Connected on"
        },
        developer: {
            id: "6JoJBm",
            defaultMessage: "Developer"
        },
        website: {
            id: "8Qxsof",
            defaultMessage: "Website"
        },
        privacyPolicy: {
            id: "diKoqe",
            defaultMessage: "Privacy Policy"
        },
        landingPageTitle: {
            id: "eYNUhF",
            defaultMessage: "Landing Page"
        },
        termsOfService: {
            id: "NfU0SI",
            defaultMessage: "Terms of Service"
        },
        categoryBusinessAndAnalytics: {
            id: "QhPypU",
            defaultMessage: "Business and Analytics"
        },
        categoryCreativityAndDesign: {
            id: "/bcuXB",
            defaultMessage: "Creativity and Design"
        },
        categoryDeveloperTools: {
            id: "15wsiU",
            defaultMessage: "Developer Tools"
        },
        categoryMessagingAndSocial: {
            id: "rBRiVM",
            defaultMessage: "Messaging and Social"
        },
        categoryProductivity: {
            id: "UH2JU4",
            defaultMessage: "Productivity"
        },
        categoryResearchAndKnowledge: {
            id: "WKfdK1",
            defaultMessage: "Research and Knowledge"
        },
        baseUrl: {
            id: "XOcfO/",
            defaultMessage: "URL"
        },
        safetyScanTitle: {
            id: "1IzOM7",
            defaultMessage: "Safety Scan"
        },
        safetyScanScanningStatus: {
            id: "YfgX5F",
            defaultMessage: "Scanning"
        },
        safetyScanPassed: {
            id: "UrwyRa",
            defaultMessage: "Passed"
        },
        safetyScanSoftBlocked: {
            id: "bQN4n9",
            defaultMessage: "Warning"
        },
        safetyScanFailed: {
            id: "FeaZe+",
            defaultMessage: "Failed"
        },
        authorizationSupported: {
            id: "oA2ynd",
            defaultMessage: "Authorization supported"
        },
        linkAuthorizationType: {
            id: "39RCjo",
            defaultMessage: "Authorization used"
        },
        authorizationTypeOAuth: {
            id: "VsekFo",
            defaultMessage: "OAuth"
        },
        authorizationTypeApiKey: {
            id: "1WrvLC",
            defaultMessage: "API key"
        },
        authorizationTypeNone: {
            id: "ETv4pb",
            defaultMessage: "None"
        }
    }),
    uf = (s, e) => {
        switch (s) {
            case "BUSINESS_AND_ANALYTICS":
                return e.formatMessage(Ye.categoryBusinessAndAnalytics);
            case "CREATIVITY_AND_DESIGN":
                return e.formatMessage(Ye.categoryCreativityAndDesign);
            case "DEVELOPER_TOOLS":
                return e.formatMessage(Ye.categoryDeveloperTools);
            case "MESSAGING_AND_SOCIAL":
                return e.formatMessage(Ye.categoryMessagingAndSocial);
            case "PRODUCTIVITY":
                return e.formatMessage(Ye.categoryProductivity);
            case "RESEARCH_AND_KNOWLEDGE":
                return e.formatMessage(Ye.categoryResearchAndKnowledge);
            default:
                return null
        }
    },
    gf = s => !s || typeof s != "object" ? null : "type" in s && s.type ? s.type : "header_scheme" in s ? "API_KEY" : "authorization_url" in s ? "OAUTH" : "NONE",
    Yo = (s, e) => {
        switch (s) {
            case "OAUTH":
                return e.formatMessage(Ye.authorizationTypeOAuth);
            case "API_KEY":
                return e.formatMessage(Ye.authorizationTypeApiKey);
            case "NONE":
                return e.formatMessage(Ye.authorizationTypeNone)
        }
        return s
    },
    jn = (s, e, a) => {
        var f, p, g, h, y, x, j;
        const n = a == null ? void 0 : a.linkAuthType,
            o = [],
            i = uf((f = s.branding) == null ? void 0 : f.category, e);
        if (i && o.push({
                title: e.formatMessage(Ye.category),
                value: i
            }), (p = s.branding) != null && p.developer && o.push({
                title: e.formatMessage(Ye.developer),
                value: s.branding.developer
            }), (g = s.branding) != null && g.website && o.push({
                title: e.formatMessage(Ye.website),
                value: t.jsx(Rs, {
                    href: s.branding.website,
                    openNewTab: !0,
                    underline: !1,
                    "aria-label": e.formatMessage(Ye.website),
                    className: "text-blue-400",
                    children: t.jsx(Dn, {
                        className: "icon"
                    })
                })
            }), (h = s.branding) != null && h.privacy_policy && o.push({
                title: e.formatMessage(Ye.privacyPolicy),
                value: t.jsx(Rs, {
                    href: s.branding.privacy_policy,
                    openNewTab: !0,
                    underline: !1,
                    "aria-label": e.formatMessage(Ye.privacyPolicy),
                    className: "text-blue-400",
                    children: t.jsx(Dn, {
                        className: "icon"
                    })
                })
            }), (y = s.branding) != null && y.terms_of_service && o.push({
                title: e.formatMessage(Ye.termsOfService),
                value: t.jsx(Rs, {
                    href: s.branding.terms_of_service,
                    openNewTab: !0,
                    underline: !1,
                    "aria-label": e.formatMessage(Ye.termsOfService),
                    className: "text-blue-400",
                    children: t.jsx(Dn, {
                        className: "icon"
                    })
                })
            }), ["MCP", "OPEN_API"].includes(s.connector_type) && s.base_url && (!((x = s.branding) != null && x.is_discoverable_app) || a != null && a.ecosystemDebugShowAppUrlsInSettings) && o.push({
                title: e.formatMessage(Ye.baseUrl),
                value: s.base_url
            }), s.policy_info) {
            const v = s.policy_info.safety_status === "SCANNED_OK" ? t.jsx(gl, {
                    className: "icon-sm text-token-text-primary"
                }) : s.policy_info.safety_status === "SCANNED_BLOCKED" ? t.jsx(Ea, {
                    className: "icon-sm interactive-label-warning-secondary"
                }) : s.policy_info.safety_status === "SCANNED_SOFT_BLOCKED" ? t.jsx(Ea, {
                    className: "icon-sm interactive-label-warning-secondary"
                }) : t.jsx(ys, {
                    className: "icon-sm"
                }),
                S = s.policy_info.safety_status === "SCANNED_OK" ? t.jsx(m, b({}, Ye.safetyScanPassed)) : s.policy_info.safety_status === "SCANNED_BLOCKED" ? t.jsx(m, b({}, Ye.safetyScanFailed)) : s.policy_info.safety_status === "SCANNED_SOFT_BLOCKED" ? t.jsx(m, b({}, Ye.safetyScanSoftBlocked)) : t.jsx(m, b({}, Ye.safetyScanScanningStatus));
            s.policy_info.safety_status !== "SCANNED_OK" && o.push({
                title: e.formatMessage(Ye.safetyScanTitle),
                value: t.jsxs("span", {
                    className: "flex items-center gap-1",
                    children: [v, S]
                })
            })
        }
        if (!(a != null && a.isDeveloperMode)) return o;
        const c = ((j = s.supported_auth) != null ? j : []).map(v => gf(v)).filter(v => !!v),
            l = Array.from(new Set(c)),
            r = (l.length > 0 ? l : ["NONE"]).map(v => Yo(v, e)),
            u = r.length > 1 ? e.formatList(r) : r[0];
        return o.push({
            title: e.formatMessage(Ye.authorizationSupported),
            value: u
        }), n && o.push({
            title: e.formatMessage(Ye.linkAuthorizationType),
            value: Yo(n, e)
        }), s.app_metadata && (s.app_metadata.version && o.push({
            title: e.formatMessage(Ye.appVersion),
            value: s.app_metadata.version
        }), s.app_metadata.version_notes && o.push({
            title: e.formatMessage(Ye.appVersionNotes),
            value: s.app_metadata.version_notes
        }), s.app_metadata.version_id && o.push({
            title: e.formatMessage(Ye.appVersionId),
            value: s.app_metadata.version_id
        }), s.app_metadata.review && s.app_metadata.version_id && o.push({
            title: e.formatMessage(Ye.appReviewStatus),
            value: s.app_metadata.review.status.toLowerCase()
        })), o
    },
    ff = ft(() => gt(() =>
        import ("./eiz8m6b2n93cr92l.js"), __vite__mapDeps([9, 1, 2, 3, 6, 7, 10])).then(s => s.GithubOnboardingModal)),
    mf = ({
        link: s,
        onDisableSync: e
    }) => {
        var F, O, I;
        const a = ve(),
            n = K(),
            o = Si(),
            i = fl(a),
            [c, l] = w.useState(""),
            [d, r] = w.useState(new Map),
            [u] = _u(c, 500),
            {
                data: f,
                isLoading: p
            } = Qe(() => _i.if$(a, o)),
            g = w.useMemo(() => f == null ? void 0 : f.connection_statuses.find(U => {
                var R, B;
                return ((R = U == null ? void 0 : U.user_connection_details) == null ? void 0 : R.knowledge_connector_type) === "github" && ((B = U == null ? void 0 : U.user_connection_details) == null ? void 0 : B.backing_link_id) === s.id
            }), [f, s.id]),
            {
                data: h,
                isLoading: y,
                isFetchingNextPage: x,
                hasNextPage: j,
                fetchNextPage: v
            } = nd({
                enabled: !!(s && g),
                debouncedSearchTerm: u,
                linkId: s.id
            }),
            {
                data: S,
                isLoading: C,
                refetch: M
            } = ad({
                enabled: !!((F = g == null ? void 0 : g.user_connection_details) != null && F.connection_instance_id),
                connectionInstanceId: (I = (O = g == null ? void 0 : g.user_connection_details) == null ? void 0 : O.connection_instance_id) != null ? I : ""
            });
        w.useEffect(() => {
            var U, R, B;
            if ((U = S == null ? void 0 : S.sync_enabled_objects) != null && U.length) {
                const z = (R = S == null ? void 0 : S.sync_enabled_objects) == null ? void 0 : R.filter(W => W.object_type === "repository");
                z != null && z.length && r(new Map((B = z == null ? void 0 : z.map(W => {
                    var V, J;
                    return [Number(W.object_id), {
                        id: Number(W.object_id),
                        repository_full_name: (V = W.object_name) != null ? V : "",
                        description: (J = W.object_description) != null ? J : "",
                        is_code_search_indexed: !0
                    }]
                })) != null ? B : []))
            }
        }, [S]);
        const {
            mutate: E,
            isPending: N
        } = pt({
            mutationFn: async () => {
                var R;
                const U = (R = g == null ? void 0 : g.user_connection_details) == null ? void 0 : R.connection_instance_id;
                U && await aa.user_connection_update_sync_configuration(U, {
                    type: "GithubUserApiExtension",
                    opted_in_repository_ids: Array.from(d.keys())
                })
            },
            onSuccess: () => {
                M(), bn(a)
            }
        }), k = w.useCallback(() => {
            var U;
            r(new Map(((U = S == null ? void 0 : S.sync_enabled_objects) != null ? U : []).filter(R => R.object_type === "repository").map(R => {
                var B, z;
                return [Number(R.object_id), {
                    id: Number(R.object_id),
                    repository_full_name: (B = R.object_name) != null ? B : "",
                    description: (z = R.object_description) != null ? z : "",
                    is_code_search_indexed: !0
                }]
            })))
        }, [S]), P = w.useMemo(() => {
            var B, z;
            const U = (B = h == null ? void 0 : h.pages.flatMap(W => W.repos)) != null ? B : [],
                R = (z = S == null ? void 0 : S.sync_enabled_objects) == null ? void 0 : z.filter(W => W.object_type === "repository");
            if (!u && (R != null && R.length)) {
                const W = new Map(U.map(Z => [Number(Z.id), Z])),
                    V = new Set(U.map(Z => Number(Z.id))),
                    J = R.filter(Z => V.has(Number(Z.object_id))).map(Z => W.get(Number(Z.object_id))),
                    ce = R.filter(Z => !V.has(Number(Z.object_id))).map(Z => {
                        var $;
                        return {
                            id: Number(Z.object_id),
                            repository_full_name: ($ = Z.object_name) != null ? $ : "",
                            description: "",
                            is_code_search_indexed: !0
                        }
                    }),
                    ae = U.filter(Z => !R.some($ => Number($.object_id) === Number(Z.id)));
                return [...J, ...ce, ...ae]
            }
            return U
        }, [h, u, S]), L = !!g && (P.length > 5 || !!u), A = w.useCallback(U => {
            r(U)
        }, []), _ = w.useMemo(() => {
            if (!g) return !1;
            if (!(S != null && S.sync_enabled_objects)) return d.size > 0;
            const U = new Set(S.sync_enabled_objects.filter(R => R.object_type === "repository").map(R => Number(R.object_id)));
            if (U.size !== d.size) return !0;
            for (const R of d.keys())
                if (!U.has(R)) return !0;
            for (const R of U)
                if (!d.has(R)) return !0;
            return !1
        }, [d, S, g]), D = p || y || C;
        if (!o) return null;
        const T = t.jsx(ne, {
            color: "secondary",
            disabled: i,
            onClick: () => {
                $e(a, ff, {
                    initialState: Pn.SyncRepos,
                    onClose: () => {
                        bn(a)
                    }
                })
            },
            children: t.jsx(m, {
                id: "Dnyhgs",
                defaultMessage: "Choose repositories"
            })
        });
        return t.jsxs(t.Fragment, {
            children: [t.jsx("div", {
                className: "px-2 pt-5",
                children: t.jsx(Ne, {
                    description: t.jsx(m, {
                        id: "+8dStU",
                        defaultMessage: "Syncing improves speed and quality, so select the repositories you use most. ChatGPT can still access repositories that aren’t synced."
                    }),
                    noBorder: !0,
                    title: t.jsxs("div", {
                        className: "flex items-center gap-2",
                        children: [t.jsx(m, {
                            id: "JQCZHf",
                            defaultMessage: "Synced repositories"
                        }), g && t.jsx(Bn, {
                            connection: g,
                            location: "user_settings"
                        })]
                    }),
                    children: t.jsxs("div", {
                        className: "mt-2 flex flex-col",
                        children: [L && t.jsx(Ka, {
                            ariaLabel: n.formatMessage({
                                id: "D2Xhv1",
                                defaultMessage: "Search repositories"
                            }),
                            autoComplete: "off",
                            className: "mb-2",
                            icon: ml,
                            iconPosition: "left",
                            name: "search-repos",
                            onChange: U => {
                                l(U.target.value)
                            },
                            placeholder: n.formatMessage({
                                id: "jYgjAb",
                                defaultMessage: "Search repositories"
                            })
                        }), D || g ? t.jsx(wu, {
                            allRepos: P,
                            enableScroll: !1,
                            fetchNextPage: v,
                            hasNextPage: j,
                            isFetchingNextPage: x,
                            isLoading: D,
                            searchTerm: c,
                            onChange: A,
                            selectedRepos: d
                        }) : t.jsxs("div", {
                            className: "border-token-border-default flex items-center justify-between rounded-xl border-1 p-4",
                            children: [t.jsx("div", {
                                className: "text-token-text-tertiary text-xs",
                                children: t.jsx(m, {
                                    id: "fwutvn",
                                    defaultMessage: "No repositories synced"
                                })
                            }), i ? t.jsx(pl, {
                                children: T
                            }) : T]
                        })]
                    })
                })
            }), _ && t.jsx("div", {
                className: "bg-token-bg-primary border-token-border-default sticky end-0 bottom-0 z-10 -mx-4 border-t-1 px-4 py-6",
                children: t.jsxs("div", {
                    className: "flex justify-end gap-2",
                    children: [t.jsx(ne, {
                        color: "secondary",
                        onClick: k,
                        children: t.jsx(m, b({}, Ua.cancelButtonText))
                    }), t.jsx(ne, {
                        color: "primary",
                        loading: N,
                        onClick: () => {
                            d.size === 0 ? e() : E()
                        },
                        children: t.jsx(m, {
                            id: "4e7T8Q",
                            defaultMessage: "Save"
                        })
                    })]
                })
            })]
        })
    },
    sa = rt[lt.GITHUB_CONNECTOR],
    dr = s => {
        "use forget";
        var Nn, Zt, ws, Es, Ns, tn, Ts, As, Ps;
        const e = Se.c(141),
            {
                badge: a,
                connector: n,
                connectorId: o,
                connectorDisabled: i,
                connectorDisabledTooltip: c,
                link: l,
                icon: d,
                name: r,
                description: u,
                onBackClick: f,
                details: p,
                detailsHeaderTrailingContent: g,
                onConnectClick: h,
                onDisconnectClick: y,
                isConnecting: x,
                isDisconnecting: j,
                isDeleting: v,
                onBlockItems: S,
                onDelete: C,
                onDeleteSyncClick: M,
                onEnableSyncClick: E,
                reportEntity: N,
                onEditName: k,
                onEditDescription: P,
                onEditPrivacyPolicy: L,
                onEditLogo: A
            } = s,
            _ = i === void 0 ? !1 : i,
            D = p === void 0 ? [] : p,
            T = j === void 0 ? !1 : j,
            F = v === void 0 ? !1 : v,
            O = K(),
            I = ve();
        let U;
        e[0] !== I ? (U = es(I), e[0] = I, e[1] = U) : U = e[1];
        const R = U,
            B = ve(),
            [z, W] = w.useState(!1);
        let V;
        e[2] !== B ? (V = je(B, "4202324921"), e[2] = B, e[3] = V) : V = e[3];
        const J = V;
        let ce;
        e[4] !== B ? (ce = je(B, "1628108066"), e[4] = B, e[5] = ce) : ce = e[5];
        const ae = o === rt[lt.SHAREPOINT_CONNECTOR];
        let Z;
        e[6] !== ae ? (Z = {
            enabled: ae
        }, e[6] = ae, e[7] = Z) : Z = e[7];
        const {
            data: $
        } = da(Z);
        let ee;
        e[8] !== ae || e[9] !== ($ == null ? void 0 : $.connection_statuses) ? (ee = ae && !!($ != null && $.connection_statuses.some(vf)), e[8] = ae, e[9] = $ == null ? void 0 : $.connection_statuses, e[10] = ee) : ee = e[10];
        const de = ee;
        let ye;
        e[11] !== B ? (ye = () => vi(B), e[11] = B, e[12] = ye) : ye = e[12];
        const ze = xl(ye),
            Le = !!(l != null ? l : y),
            Me = !!(h && !Le),
            me = !!(y && Le);
        (Nn = n == null ? void 0 : n.id) != null;
        const xe = !1;
        let Ce;
        e[13] !== I || e[14] !== xe ? (Ce = () => ({
            data: void 0,
            isLoading: !1,
            isSuccess: !1,
            error: void 0
        }), e[13] = I, e[14] = xe, e[15] = Ce) : Ce = e[15];
        const Be = (Zt = Qe(Ce).data) == null ? void 0 : Zt.message,
            G = hf({
                connector: n,
                account: ze
            });
        n == null || n.id;
        let se;
        e: {
            const mt = (ws = n == null ? void 0 : n.id) != null ? ws : o;
            if (!mt) {
                se = null;
                break e
            }
            se = "/admin/ca#drafts?publish=".concat(encodeURIComponent(mt))
        }
        const pe = se,
            fe = o === sa || G && !!pe || !!y && !me || !!h && !Me || !!E || !!S || !!M || !!C || !1;
        let be;
        e[16] !== B ? (be = je(B, "2571214709"), e[16] = B, e[17] = be) : be = e[17];
        const Te = be;
        let Oe;
        e[18] !== B ? (Oe = je(B, "521401680"), e[18] = B, e[19] = Oe) : Oe = e[19];
        const We = Oe;
        let Ve;
        e[20] !== I ? (Ve = () => za(I), e[20] = I, e[21] = Ve) : Ve = e[21];
        const {
            isLoading: ot,
            data: Ze
        } = Qe(Ve), ks = Ze != null ? Ze : {}, {
            disabledTools: Fe
        } = ks, Ge = Wn(ks, ["disabledTools"]), Xe = Fe === void 0 ? [] : Fe, X = _t();
        let re;
        e[22] !== X ? (re = async mt => {
            const {
                data: Pt
            } = mt;
            await X.cancelQueries({
                queryKey: ["userContext"]
            });
            const yt = X.getQueryData(["userContext"]);
            return X.setQueryData(["userContext"], Dt => b(b({}, Dt != null ? Dt : {}), Pt)), {
                prevData: yt
            }
        }, e[22] = X, e[23] = re) : re = e[23];
        let we;
        e[24] !== O || e[25] !== X || e[26] !== R ? (we = (mt, Pt, yt) => {
            yt != null && yt.prevData && X.setQueryData(["userContext"], yt.prevData), R.danger(O.formatMessage(Pe.settingError), {
                toastId: "connector_details_listing_setting_error"
            })
        }, e[24] = O, e[25] = X, e[26] = R, e[27] = we) : we = e[27];
        let te;
        e[28] !== X ? (te = () => {
            X.invalidateQueries({
                queryKey: ["userContext"]
            })
        }, e[28] = X, e[29] = te) : te = e[29];
        let oe;
        e[30] !== re || e[31] !== we || e[32] !== te ? (oe = {
            mutationFn: Cf,
            onMutate: re,
            onError: we,
            onSettled: te
        }, e[30] = re, e[31] = we, e[32] = te, e[33] = oe) : oe = e[33];
        const {
            isPending: le,
            mutate: he
        } = pt(oe), H = xf(o);
        let ue;
        e[34] === Symbol.for("react.memo_cache_sentinel") ? (ue = Ni("installations/select_target"), e[34] = ue) : ue = e[34];
        const _e = ue,
            st = () => {
                if (!H) return;
                const mt = Xe.includes(H) ? Xe.filter(Pt => Pt !== H) : Array.from(new Set([...Xe, H]));
                he({
                    data: b({
                        disabledTools: mt
                    }, Ge)
                })
            };
        let ht;
        e[35] !== ((Es = n == null ? void 0 : n.supported_auth) == null ? void 0 : Es.length) || e[36] !== o || e[37] !== h ? (ht = mt => {
            var Pt, yt;
            if (o) {
                const Dt = {};
                (Pt = n == null ? void 0 : n.supported_auth) != null && Pt.length && (Dt.supports_mixed_auth = ((yt = n == null ? void 0 : n.supported_auth) == null ? void 0 : yt.length) > 1 ? "true" : "false"), bl(o, yl.ConnectorSettingsConnectClick, Dt)
            }
            return h == null ? void 0 : h(mt)
        }, e[35] = (Ns = n == null ? void 0 : n.supported_auth) == null ? void 0 : Ns.length, e[36] = o, e[37] = h, e[38] = ht) : ht = e[38];
        const Nt = ht,
            Tt = !!(Te && H);
        let Vt;
        e[39] !== o || e[40] !== I ? (Vt = od(I, o), e[39] = o, e[40] = I, e[41] = Vt) : Vt = e[41];
        const Ms = Vt,
            $t = (Ts = (tn = n == null ? void 0 : n.allowed_with_approval_context_scopes) == null ? void 0 : tn.filter(jf)) != null ? Ts : [];
        l == null || l.approved_context_scopes;
        let Je;
        e[42] !== (l == null ? void 0 : l.approved_context_scopes) ? (Je = (Ps = (As = l == null ? void 0 : l.approved_context_scopes) == null ? void 0 : As.filter(Sf)) != null ? Ps : [], e[42] = l == null ? void 0 : l.approved_context_scopes, e[43] = Je) : Je = e[43];
        const it = Je,
            [et, Ft] = w.useState(it);
        let vs, Cs;
        e[44] !== it ? (vs = () => {
            Ft(it)
        }, Cs = [it], e[44] = it, e[45] = vs, e[46] = Cs) : (vs = e[45], Cs = e[46]), w.useEffect(vs, Cs);
        const [En, Hs] = w.useState(null);
        l != null && l.id;
        let Ut;
        e[47] !== et || e[48] !== O || e[49] !== (l == null ? void 0 : l.id) || e[50] !== X || e[51] !== R ? (Ut = async (mt, Pt) => {
            const yt = l == null ? void 0 : l.id;
            if (!yt) return;
            const Dt = et.includes(mt);
            if (Pt === Dt) return;
            Hs(mt);
            const Ys = Pt ? [...et, mt].sort(_f) : et.filter(Tn => Tn !== mt);
            try {
                await Ml(yt, Ys), vl(X, yt, Ys), Ft(Ys), Hs(null)
            } catch (Tn) {
                Hs(null), R.danger(O.formatMessage(Pe.settingError), {
                    toastId: "connector_context_scope_toggle_error_".concat(yt, "_").concat(mt)
                })
            }
        }, e[47] = et, e[48] = O, e[49] = l == null ? void 0 : l.id, e[50] = X, e[51] = R, e[52] = Ut) : Ut = e[52], l == null || l.id, We && $t.length > 0, l && n && l.connector_type;
        const Ws = Tt || Ms || !1;
        let ss;
        e[53] !== I ? (ss = kn(I), e[53] = I, e[54] = ss) : ss = e[54];
        const Kt = ss;
        let js, Ss;
        e[55] === Symbol.for("react.memo_cache_sentinel") ? (js = t.jsx(Fa, {
            className: "icon icon-md"
        }), Ss = t.jsx(m, b({}, Pe.backButton)), e[55] = js, e[56] = Ss) : (js = e[55], Ss = e[56]);
        let Rt;
        e[57] !== f ? (Rt = t.jsx("div", {
            className: "h-header-height flex flex-shrink-0 items-center",
            children: t.jsxs(ne, {
                color: "ghost",
                size: "medium",
                onClick: f,
                contentWrapperClassName: "gap-[6px]",
                className: "rounded-lg ps-0.5 pe-1.5",
                children: [js, Ss]
            })
        }), e[57] = f, e[58] = Rt) : Rt = e[58];
        const Vs = Kt ? "text-lg font-medium" : "text-lg font-semibold";
        let ns;
        e[59] !== r || e[60] !== Vs ? (ns = t.jsx("div", {
            className: Vs,
            children: r
        }), e[59] = r, e[60] = Vs, e[61] = ns) : ns = e[61];
        let as;
        e[62] !== a || e[63] !== ns ? (as = t.jsxs("div", {
            className: "flex items-center gap-2",
            children: [ns, a]
        }), e[62] = a, e[63] = ns, e[64] = as) : as = e[64];
        let ds;
        e[65] !== xe || e[66] !== Be ? (ds = !1, e[65] = xe, e[66] = Be, e[67] = ds) : ds = e[67];
        let os;
        e[68] !== u || e[69] !== Kt ? (os = Kt ? null : t.jsx("span", {
            className: "text-token-text-tertiary",
            children: u
        }), e[68] = u, e[69] = Kt, e[70] = os) : os = e[70];
        let At;
        e[71] !== as || e[72] !== ds || e[73] !== os ? (At = t.jsxs("div", {
            className: "flex-1",
            children: [as, ds, os]
        }), e[71] = as, e[72] = ds, e[73] = os, e[74] = At) : At = e[74];
        let qt;
        e[75] !== c || e[76] !== O ? (qt = c != null ? c : O.formatMessage(Pe.connectorDisabled), e[75] = c, e[76] = O, e[77] = qt) : qt = e[77];
        const $s = !_ || me;
        let us;
        e[78] !== _ || e[79] !== O || e[80] !== de || e[81] !== x || e[82] !== Nt || e[83] !== Me ? (us = Me && (de ? t.jsx(Wt, {
            label: O.formatMessage(Pe.adminConnectedDescription),
            triggerAs: "div",
            children: t.jsx("div", {
                className: "text-token-text-secondary font-medium",
                children: t.jsx(m, b({}, Pe.connected))
            })
        }) : t.jsx("div", {
            children: t.jsx(ne, {
                onClick: Nt,
                loading: x,
                disabled: _,
                children: t.jsx(m, b({}, Pe.connectButton))
            })
        })), e[78] = _, e[79] = O, e[80] = de, e[81] = x, e[82] = Nt, e[83] = Me, e[84] = us) : us = e[84];
        let is;
        e[85] !== Kt || e[86] !== F || e[87] !== T || e[88] !== y || e[89] !== me ? (is = me && t.jsx("div", {
            children: t.jsx(ne, {
                onClick: y,
                loading: T,
                color: Kt ? "secondary" : "danger",
                disabled: F || T,
                children: t.jsx(m, b({}, Pe.disconnectButton))
            })
        }), e[85] = Kt, e[86] = F, e[87] = T, e[88] = y, e[89] = me, e[90] = is) : is = e[90];
        let Yt;
        e[91] !== _ || e[92] !== o || e[93] !== F || e[94] !== S || e[95] !== h || e[96] !== Nt || e[97] !== C || e[98] !== M || e[99] !== y || e[100] !== P || e[101] !== A || e[102] !== k || e[103] !== L || e[104] !== E || e[105] !== pe || e[106] !== Me || e[107] !== me || e[108] !== fe || e[109] !== G ? (Yt = fe && t.jsx("div", {
            children: t.jsxs(De.Root, {
                children: [t.jsx(De.BasicTrigger, {
                    disabled: _,
                    asChild: !0,
                    children: t.jsxs(ne, {
                        color: "secondary",
                        className: "px-2.25",
                        disabled: _,
                        children: [t.jsx(ki, {
                            className: "icon icon-sm"
                        }), t.jsx("span", {
                            className: "sr-only",
                            children: t.jsx(m, b({}, Pe.manageDropdown))
                        })]
                    })
                }), t.jsx(De.Portal, {
                    children: t.jsxs(De.Content, {
                        size: "small",
                        align: "end",
                        children: [o === sa && t.jsx(Rs, {
                            href: _e,
                            openNewTab: !0,
                            underline: !1,
                            children: t.jsx(De.Item, {
                                children: t.jsx(m, b({}, Pe.settingsButton))
                            })
                        }), G && pe && t.jsx(Rs, {
                            href: pe,
                            openNewTab: !0,
                            underline: !1,
                            children: t.jsx(De.Item, {
                                children: t.jsx(m, b({}, Pe.publishButton))
                            })
                        }), !1, !1, !1, !1, !Me && h && t.jsx(De.Item, {
                            onClick: Nt,
                            children: t.jsx(m, b({}, Pe.connectButton))
                        }), E && t.jsx(De.Item, {
                            onClick: E,
                            children: t.jsx(m, b({}, Pe.enableSync))
                        }), S && t.jsx(De.Item, {
                            onClick: S,
                            children: t.jsx(m, b({}, Pe.blockItems))
                        }), M && t.jsx(De.Item, {
                            onClick: M,
                            children: t.jsx(m, b({}, Pe.disableSync))
                        }), !me && y && t.jsx(De.Item, {
                            onClick: y,
                            color: "danger",
                            children: t.jsx(m, b({}, Pe.disconnectButton))
                        }), C && t.jsx(De.Item, {
                            onClick: C,
                            color: "danger",
                            disabled: F,
                            children: t.jsx(m, b({}, Pe.deleteButton))
                        })]
                    })
                })]
            })
        }), e[91] = _, e[92] = o, e[93] = F, e[94] = S, e[95] = h, e[96] = Nt, e[97] = C, e[98] = M, e[99] = y, e[100] = P, e[101] = A, e[102] = k, e[103] = L, e[104] = E, e[105] = pe, e[106] = Me, e[107] = me, e[108] = fe, e[109] = G, e[110] = Yt) : Yt = e[110];
        let rs;
        e[111] !== us || e[112] !== is || e[113] !== Yt ? (rs = t.jsxs("div", {
            className: "flex items-center gap-2 py-1",
            children: [us, is, Yt]
        }), e[111] = us, e[112] = is, e[113] = Yt, e[114] = rs) : rs = e[114];
        let Qt;
        e[115] !== qt || e[116] !== $s || e[117] !== rs ? (Qt = t.jsx(Wt, {
            label: qt,
            disabled: $s,
            children: rs
        }), e[115] = qt, e[116] = $s, e[117] = rs, e[118] = Qt) : Qt = e[118];
        let _s;
        e[119] !== d || e[120] !== At || e[121] !== Qt ? (_s = t.jsxs("div", {
            className: "flex items-center gap-4 px-2 pt-2",
            children: [d, At, Qt]
        }), e[119] = d, e[120] = At, e[121] = Qt, e[122] = _s) : _s = e[122];
        let ls;
        e[123] !== o || e[124] !== l ? (ls = o === sa && l && t.jsx(yf, {
            link: l
        }), e[123] = o, e[124] = l, e[125] = ls) : ls = e[125];
        let Ks;
        e[126] !== de ? (Ks = de && t.jsx(bf, {}), e[126] = de, e[127] = Ks) : Ks = e[127];
        const qs = Ws && t.jsx("div", {
                className: "px-2 pt-6",
                children: t.jsxs(Ne, {
                    title: t.jsx(m, b({}, Pe.preferences)),
                    children: [!1, !1, Tt && H && t.jsx(Q, {
                        children: t.jsx(ct, {
                            label: l != null ? O.formatMessage(Pe.allowUsingAutomatically) : O.formatMessage(Pe.recommendConnection),
                            description: l != null ? O.formatMessage(Pe.allowUsingAutomaticallyDescription, {
                                connectorName: r
                            }) : O.formatMessage(Pe.recommendConnectionDescription, {
                                connectorName: r
                            }),
                            enabled: !Xe.includes(H),
                            isLoading: ot || le,
                            onChange: st
                        })
                    }), Ms && t.jsx(id, {
                        connectorId: o,
                        connectorName: r
                    })]
                })
            }),
            dt = D.length > 0 && t.jsx("div", {
                className: "px-2 pt-6",
                children: t.jsx(Ne, {
                    title: t.jsx(m, b({}, Pe.information)),
                    noBorder: !0,
                    headerTrailingContent: g,
                    children: t.jsxs("div", {
                        className: "border-token-border-default flex flex-col gap-3 border-t pt-4",
                        children: [D.filter(wf).map(kf), N && J && t.jsxs("button", {
                            type: "button",
                            onClick: () => W(!0),
                            className: "text-token-text-tertiary flex w-full items-center justify-between gap-3 text-start",
                            children: [t.jsx("span", {
                                children: t.jsx(m, b({}, Pe.reportButton))
                            }), t.jsx(rd, {
                                className: "icon icon-md text-token-text-primary"
                            })]
                        })]
                    })
                })
            });
        let cs;
        e[128] !== N || e[129] !== W || e[130] !== J || e[131] !== z ? (cs = z && N && J && t.jsx(pf, {
            reportEntity: N,
            onClose: () => W(!1)
        }), e[128] = N, e[129] = W, e[130] = J, e[131] = z, e[132] = cs) : cs = e[132];
        let xt;
        return e[133] !== Rt || e[134] !== _s || e[135] !== ls || e[136] !== Ks || e[137] !== qs || e[138] !== dt || e[139] !== cs ? (xt = t.jsxs(t.Fragment, {
            children: [Rt, _s, ls, Ks, qs, dt, cs]
        }), e[133] = Rt, e[134] = _s, e[135] = ls, e[136] = Ks, e[137] = qs, e[138] = dt, e[139] = cs, e[140] = xt) : xt = e[140], xt
    };

function pf({
    reportEntity: s,
    onClose: e
}) {
    var l;
    const a = ve(),
        n = K(),
        {
            data: o
        } = ld(a, s.entityType),
        i = cd(a, n, s.id, s.entityType, Cl.FirstParty);
    if (o == null) return null;
    const c = (l = s.title) != null ? l : n.formatMessage(Pe.reportModalTitle);
    return t.jsx(dd, {
        reasons: o.reasons,
        submitReport: i,
        title: c,
        onClose: e,
        header: o.header,
        subHeader: o.header_explanation
    })
}

function hf({
    connector: s,
    account: e
}) {
    const a = (e == null ? void 0 : e.isAdminOfAccount()) || (e == null ? void 0 : e.isOwnerOfAccount());
    return !!(s && s.connector_type !== "SERVICE" && s.status === "ONLY_ME" && a && !(e != null && e.isPersonalAccount()))
}

function xf(s) {
    switch (s) {
        case rt[lt.GMAIL_CONNECTOR]:
            return "gmail";
        case rt[lt.GCAL_CONNECTOR]:
            return "gcal";
        case rt[lt.GOOGLE_CONTACTS_CONNECTOR]:
            return "gcontacts";
        default:
            return null
    }
}
const bf = () => {
        "use forget";
        const s = Se.c(1);
        let e;
        return s[0] === Symbol.for("react.memo_cache_sentinel") ? (e = t.jsx("div", {
            className: "px-2 pt-6",
            children: t.jsxs("div", {
                className: "border-token-border-default flex flex-row gap-2 rounded-2xl border p-3",
                children: [t.jsx(Ha, {
                    className: "icon-md"
                }), t.jsx(m, b({}, Pe.adminConnectedDescription))]
            })
        }), s[0] = e) : e = s[0], e
    },
    yf = ({
        link: s
    }) => {
        var i;
        const e = Ni("installations/select_target"),
            {
                data: a,
                isLoading: n
            } = Fi({
                linkId: (i = s == null ? void 0 : s.id) != null ? i : ""
            }),
            o = !a;
        return n || !o ? null : t.jsx("div", {
            className: "px-2 pt-6",
            children: t.jsx("div", {
                className: "border-token-border-default flex flex-col gap-2 rounded-2xl border p-3",
                children: t.jsxs("div", {
                    className: "flex justify-between gap-3",
                    children: [t.jsx(m, b({}, Pe.githubInstallationAlert)), t.jsxs(ne, {
                        color: "primary",
                        contentWrapperClassName: "gap-1.5",
                        onClick: () => {
                            window.open(e, "_blank")
                        },
                        children: [t.jsx(m, b({}, Pe.chooseRepos)), t.jsx(Dn, {
                            className: "icon"
                        })]
                    })]
                })
            })
        })
    },
    pa = d => {
        var r = d,
            {
                connector: s,
                connectorDisabled: e,
                connectorDisabledTooltip: a,
                onEditName: n,
                onEditDescription: o,
                onEditPrivacyPolicy: i,
                onEditLogo: c
            } = r,
            l = Wn(r, ["connector", "connectorDisabled", "connectorDisabledTooltip", "onEditName", "onEditDescription", "onEditPrivacyPolicy", "onEditLogo"]);
        const u = ve(),
            f = K(),
            p = kn(u),
            g = a != null ? a : void 0,
            h = s.status === "DISABLED_BY_ADMIN" || !!e || !!g;
        return w.useEffect(() => {
            Ue.logEventWithStatsig("Ecosystem app: Connector settings opened", "chatgpt_web_ecosystem_connector_settings_opened", {
                connector_id: s.id
            })
        }, [s.id]), t.jsx(dr, b({
            connectorId: s.id,
            connector: s,
            icon: t.jsxs("div", {
                className: "relative",
                children: [t.jsx(Un, {
                    connector: s,
                    size: "large",
                    className: "shadow-xxs max-h-fit bg-clip-padding ".concat(p ? "overflow-hidden rounded-full" : "border-token-border-default bg-token-bg-primary rounded-2xl border-[.5px] p-2")
                }), p && t.jsx("div", {
                    className: "absolute inset-0 rounded-full ring ring-black/[0.08] ring-inset dark:ring-white/[0.06]"
                })]
            }),
            name: _n(s.name, f),
            badge: t.jsx(wn, {
                connector: s
            }),
            description: s.description,
            connectorDisabled: h,
            connectorDisabledTooltip: g,
            onEditName: n,
            onEditDescription: o,
            onEditPrivacyPolicy: i,
            onEditLogo: c
        }, l))
    },
    ur = ({
        connector: s,
        link: e,
        onBackClick: a,
        onDisconnectClick: n,
        onConnectClick: o,
        isConnecting: i,
        isDisconnecting: c,
        isDeleting: l,
        isRefreshingActions: d,
        isTogglingAction: r,
        onDelete: u,
        onRefreshActions: f,
        onToggleAction: p,
        onEditName: g,
        onEditDescription: h,
        onEditPrivacyPolicy: y,
        onEditLogo: x
    }) => {
        const j = ve(),
            v = j && je(j, "4026425501"),
            S = zs(),
            C = K(),
            M = Si(),
            E = Qe(() => Os(j)),
            N = In(e),
            k = w.useMemo(() => N ? [...jn(s, C, {
                isDeveloperMode: E,
                linkAuthType: e.auth_type,
                ecosystemDebugShowAppUrlsInSettings: v
            })] : [{
                title: C.formatMessage(Pe.connectedOn),
                value: new Date(e.created_at).toLocaleString([], {
                    year: "numeric",
                    month: "short",
                    day: "numeric"
                })
            }, ...jn(s, C, {
                isDeveloperMode: E,
                linkAuthType: e.auth_type,
                ecosystemDebugShowAppUrlsInSettings: v
            })], [s, e.created_at, e.auth_type, C, E, v, N]),
            [P, L] = w.useState(!1),
            {
                isLoading: A,
                isEnabled: _
            } = hl(),
            T = !(S != null && S.isPersonalAccount()) && (S == null ? void 0 : S.planType) !== vt.SELF_SERVE_BUSINESS && (!_ || A),
            F = s.id === sa && M,
            O = Qe(() => _i(j).data),
            I = w.useMemo(() => {
                var V;
                return !((V = O == null ? void 0 : O.connection_statuses) != null && V.length) || !(e != null && e.id) ? null : O.connection_statuses.find(J => (e == null ? void 0 : e.id) === J.user_connection_details.backing_link_id)
            }, [O, e == null ? void 0 : e.id]),
            U = w.useCallback(async () => {
                var V;
                (V = I == null ? void 0 : I.user_connection_details) != null && V.connection_instance_id && (S != null && S.isPersonalAccount() ? await aa.user_delete_sync(e.id) : await aa.user_disconnect(I.user_connection_details.connection_instance_id), globalThis.setTimeout(() => {
                    bn(j)
                }, 500))
            }, [j, S, I == null ? void 0 : I.user_connection_details.connection_instance_id, e.id]),
            R = je(j, "350291705"),
            B = er(s) && (s.status === "ONLY_ME" || R) && !!e,
            {
                actions: z,
                isLoading: W
            } = wi(s, Ot.CONNECTOR_SETTING);
        return t.jsxs(t.Fragment, {
            children: [t.jsx(pa, {
                connector: s,
                badge: t.jsx(wn, {
                    connector: s
                }),
                link: e,
                onBackClick: a,
                details: k,
                detailsHeaderTrailingContent: B && f && t.jsx(ne, {
                    onClick: f,
                    size: "small",
                    color: "secondary",
                    loading: !!d || W,
                    children: t.jsx(m, b({}, Pe.refreshActionsButton))
                }),
                onEditDescription: h,
                reportEntity: {
                    id: s.id,
                    entityType: Ga.Connector
                },
                onDeleteSyncClick: I ? () => L(!0) : void 0,
                onDisconnectClick: In(e) ? void 0 : n,
                onConnectClick: o,
                isConnecting: i,
                isDisconnecting: c,
                isDeleting: l,
                onDelete: u,
                onEditName: g,
                onEditPrivacyPolicy: y,
                onEditLogo: x
            }), F && !T && t.jsx(mf, {
                link: e,
                onDisableSync: () => L(!0)
            }), t.jsx(Ji, {
                connector: s,
                link: e,
                actions: z,
                onToggleAction: p,
                isTogglingAction: r
            }), t.jsx(gr, {
                connector: s,
                onDisableSync: U,
                isOpen: P,
                onClose: () => L(!1)
            })]
        })
    },
    gr = ({
        connector: s,
        onDisableSync: e,
        isOpen: a,
        onClose: n
    }) => {
        const o = K(),
            i = Ct(),
            [c, l] = w.useState(!1),
            [d, r] = w.useState(!1),
            u = w.useCallback(async () => {
                try {
                    l(!0), await e(), n(), l(!1), i.success(o.formatMessage({
                        id: "OgQmj5",
                        defaultMessage: "Sync disabled"
                    }))
                } catch (f) {
                    i.danger(o.formatMessage({
                        id: "pg29j7",
                        defaultMessage: "Failed to disable sync"
                    }))
                } finally {
                    l(!1)
                }
            }, [e, n, o, i]);
        return t.jsxs(Js, {
            className: "w-[400px] p-2",
            isOpen: a,
            onClose: n,
            testId: "modal-disable-sync",
            children: [t.jsx("div", {
                className: "flex justify-end pb-6",
                children: t.jsx(Ei, {
                    onClick: n
                })
            }), t.jsxs("div", {
                className: "flex flex-col items-center",
                children: [t.jsx("div", {
                    className: "flex items-center gap-2.5",
                    children: t.jsx(Un, {
                        connector: s,
                        className: "rounded-xl border-[0.5px] p-2 shadow-sm",
                        size: "medium"
                    })
                }), t.jsx("div", {
                    className: "pt-4 text-center text-2xl font-semibold",
                    children: t.jsx(m, Ee(b({}, Pe.disableSyncModalTitle), {
                        values: {
                            connector: s.name
                        }
                    }))
                }), t.jsx("div", {
                    className: "text-md text-token-text-secondary pt-2 text-center text-sm",
                    children: t.jsx(m, b({}, Pe.disableSyncModalDescription))
                }), t.jsx(Ui, {
                    id: "disable-segment-replacement",
                    className: "rounded-xl",
                    label: o.formatMessage(Pe.disableSyncModalCheckboxLabel),
                    labelClassName: "font-medium",
                    checked: d,
                    onChange: () => r(!d),
                    containerClassName: "col-span-3 w-full p-4 border border-gray-300 rounded-xl mt-5 gap-4 text-sm"
                }), t.jsxs("div", {
                    className: "flex w-full flex-row justify-evenly gap-2 pt-6",
                    children: [t.jsx(ne, {
                        onClick: n,
                        color: "secondary",
                        size: "large",
                        className: "flex-1",
                        children: t.jsx(m, b({}, Ua.cancelButtonText))
                    }), t.jsx(ne, {
                        disabled: !d || c,
                        loading: c,
                        onClick: u,
                        color: "danger",
                        size: "large",
                        className: "flex-1",
                        children: t.jsx(m, b({}, Pe.disableSync))
                    })]
                })]
            })]
        })
    },
    Mf = ({
        connector: s,
        onBackClick: e,
        onDisconnectClick: a,
        internalKnowledgeConfig: n,
        onConnectClick: o
    }) => {
        const i = ve(),
            c = i && je(i, "4026425501"),
            l = K(),
            d = Qe(() => Os(i)),
            r = w.useMemo(() => jn(s, l, {
                isDeveloperMode: d,
                ecosystemDebugShowAppUrlsInSettings: c
            }), [s, l, d, c]),
            u = n.user_connection_details.knowledge_connector_type !== "google_drive_dwd";
        return t.jsx(pa, {
            connector: s,
            badge: t.jsx(wn, {
                connector: s
            }),
            onBackClick: e,
            details: r,
            onDisconnectClick: u ? a : void 0,
            onConnectClick: o
        })
    },
    fr = ({
        connector: s,
        onBackClick: e,
        onConnectClick: a,
        connectorDisabled: n,
        connectorDisabledTooltip: o,
        isConnecting: i,
        isDisconnecting: c,
        isDeleting: l,
        onDelete: d,
        onEditName: r,
        onEditDescription: u,
        onEditPrivacyPolicy: f,
        onEditLogo: p
    }) => {
        const g = K(),
            h = ve(),
            y = Qe(() => Os(h)),
            x = h && je(h, "4026425501"),
            j = w.useMemo(() => [...s.created_at ? [{
                title: g.formatMessage(Pe.createdAt),
                value: new Date(s.created_at).toLocaleString([], {
                    year: "numeric",
                    month: "short",
                    day: "numeric",
                    hour: "numeric",
                    minute: "2-digit"
                })
            }] : [], ...jn(s, g, {
                isDeveloperMode: y,
                ecosystemDebugShowAppUrlsInSettings: x
            })], [s, g, y, x]),
            {
                actions: v
            } = wi(s, Ot.CONNECTOR_SETTING);
        return t.jsxs(t.Fragment, {
            children: [t.jsx(pa, {
                connector: s,
                badge: t.jsx(wn, {
                    connector: s
                }),
                onBackClick: e,
                details: j,
                onConnectClick: a,
                connectorDisabled: n,
                connectorDisabledTooltip: o,
                isConnecting: i,
                isDisconnecting: c,
                isDeleting: l,
                onDelete: d,
                reportEntity: {
                    id: s.id,
                    entityType: Ga.Connector
                },
                onEditName: r,
                onEditDescription: u,
                onEditPrivacyPolicy: f,
                onEditLogo: p
            }), t.jsx(Ji, {
                connector: s,
                actions: v
            })]
        })
    };

function vf(s) {
    return s.user_connection_details.connection_type === "sharepoint_admin_sync_connector" && s.user_connection_details.auth_status === "admin_connected"
}
async function Cf(s) {
    const {
        data: e
    } = s;
    return await Ti(e)
}

function jf(s) {
    return typeof s == "string"
}

function Sf(s) {
    return typeof s == "string"
}

function _f(s, e) {
    return s.localeCompare(e)
}

function wf(s) {
    return s.value != null
}

function kf(s) {
    return t.jsxs("div", {
        className: "flex justify-between gap-3",
        children: [t.jsx("span", {
            className: "text-token-text-tertiary text-nowrap",
            children: s.title
        }), typeof s.value == "string" ? t.jsx("span", {
            className: "no-scrollbar overflow-x-scroll whitespace-nowrap",
            children: s.value
        }) : t.jsx("span", {
            className: "truncate",
            children: s.value
        })]
    }, s.title)
}
const Ef = s => {
        "use forget";
        var ae, Z;
        const e = Se.c(49),
            {
                canEditDescription: a,
                connector: n,
                refetchConnectors: o
            } = s,
            i = K(),
            c = Ct(),
            [l, d] = w.useState(!1),
            [r, u] = w.useState(""),
            [f, p] = w.useState("");
        let g, h;
        e[0] !== n || e[1] !== l ? (g = () => {
            var $, ee;
            if (!n) {
                u(""), p("");
                return
            }
            if (!l) {
                const de = n;
                u(($ = n.description) != null ? $ : ""), p((ee = de.model_description) != null ? ee : "")
            }
        }, h = [n, l], e[0] = n, e[1] = l, e[2] = g, e[3] = h) : (g = e[2], h = e[3]), w.useEffect(g, h);
        let y;
        e[4] !== r ? (y = r.trim(), e[4] = r, e[5] = y) : y = e[5];
        const x = y;
        let j;
        e[6] !== f ? (j = f.trim(), e[6] = f, e[7] = j) : j = e[7];
        const v = j,
            S = (ae = n == null ? void 0 : n.description) != null ? ae : "";
        let C;
        e[8] !== S ? (C = S.trim(), e[8] = S, e[9] = C) : C = e[9];
        const M = C,
            E = (Z = n == null ? void 0 : n.model_description) != null ? Z : "";
        let N;
        e[10] !== E ? (N = E.trim(), e[10] = E, e[11] = N) : N = e[11];
        const k = N,
            P = x !== M,
            L = v !== k,
            A = P || L;
        let _;
        e[12] !== i || e[13] !== o || e[14] !== c ? (_ = async () => {
            await o(), c.success(i.formatMessage(Qo.updateDescriptionSuccess)), d(!1)
        }, e[12] = i, e[13] = o, e[14] = c, e[15] = _) : _ = e[15];
        let D;
        e[16] !== c ? (D = $ => {
            c.danger(Qo.updateDescriptionError, {
                error: $
            })
        }, e[16] = c, e[17] = D) : D = e[17];
        let T;
        e[18] !== D || e[19] !== _ ? (T = {
            mutationFn: Nf,
            onSuccess: _,
            onError: D
        }, e[18] = D, e[19] = _, e[20] = T) : T = e[20];
        const F = pt(T),
            O = F.isPending;
        let I;
        e[21] !== a || e[22] !== n ? (I = () => {
            var ee, de;
            if (!a || !n) return;
            const $ = n;
            u((ee = n.description) != null ? ee : ""), p((de = $.model_description) != null ? de : ""), d(!0)
        }, e[21] = a, e[22] = n, e[23] = I) : I = e[23];
        const U = I;
        let R;
        e[24] !== n ? (R = () => {
            var $, ee;
            if (d(!1), n) {
                const de = n;
                u(($ = n.description) != null ? $ : ""), p((ee = de.model_description) != null ? ee : "")
            } else u(""), p("")
        }, e[24] = n, e[25] = R) : R = e[25];
        const B = R;
        let z;
        e[26] !== n || e[27] !== A || e[28] !== P || e[29] !== L || e[30] !== O || e[31] !== x || e[32] !== v || e[33] !== F ? (z = () => {
            !n || !A || O || F.mutate({
                connectorId: n.id,
                description: x,
                modelDescription: v,
                updateDescription: P,
                updateModelDescription: L
            })
        }, e[26] = n, e[27] = A, e[28] = P, e[29] = L, e[30] = O, e[31] = x, e[32] = v, e[33] = F, e[34] = z) : z = e[34];
        const W = z;
        let V;
        e[35] !== a || e[36] !== n || e[37] !== r || e[38] !== B || e[39] !== W || e[40] !== A || e[41] !== i || e[42] !== l || e[43] !== O || e[44] !== f ? (V = null, e[35] = a, e[36] = n, e[37] = r, e[38] = B, e[39] = W, e[40] = A, e[41] = i, e[42] = l, e[43] = O, e[44] = f, e[45] = V) : V = e[45];
        const J = V;
        let ce;
        return e[46] !== J || e[47] !== U ? (ce = {
            descriptionModal: J,
            openDescriptionModal: U
        }, e[46] = J, e[47] = U, e[48] = ce) : ce = e[48], ce
    },
    Qo = Ke({
        editDescription: {
            id: "8KkNYS",
            defaultMessage: "Edit connector descriptions"
        },
        saveDescription: {
            id: "b728ms",
            defaultMessage: "Save"
        },
        descriptionFieldLabel: {
            id: "G4TQb4",
            defaultMessage: "Connector description"
        },
        descriptionPlaceholder: {
            id: "ju5+Yf",
            defaultMessage: "Describe what this connector does"
        },
        modelDescriptionFieldLabel: {
            id: "5YP4M7",
            defaultMessage: "Model description"
        },
        updateDescriptionSuccess: {
            id: "4TAQ6T",
            defaultMessage: "Descriptions saved"
        },
        updateDescriptionError: {
            id: "AUTu7I",
            defaultMessage: "Error saving descriptions"
        }
    });
async function Nf(s) {
    const {
        connectorId: e,
        description: a,
        modelDescription: n,
        updateDescription: o,
        updateModelDescription: i
    } = s, c = [];
    o && c.push(jl(e, a)), i && c.push(Sl(e, n)), c.length !== 0 && await Promise.all(c)
}
const Tf = s => new Promise((e, a) => {
        const n = new FileReader;
        n.onloadend = () => {
            const o = n.result;
            if (typeof o != "string") {
                a(new Error("Failed to read file as data URL"));
                return
            }
            e(o)
        }, n.onerror = a, n.readAsDataURL(s)
    }),
    Af = s => {
        "use forget";
        var z;
        const e = Se.c(46),
            {
                canEditLogo: a,
                connector: n,
                refetchConnectors: o,
                refetchLinks: i
            } = s,
            c = K(),
            l = Ct(),
            [d, r] = w.useState(!1),
            [u, f] = w.useState(null),
            [p, g] = w.useState(null),
            h = w.useRef(null);
        let y, x;
        e[0] !== p ? (y = () => () => {
            p && URL.revokeObjectURL(p)
        }, x = [p], e[0] = p, e[1] = y, e[2] = x) : (y = e[1], x = e[2]), w.useEffect(y, x);
        let j;
        e[3] !== p ? (j = () => {
            p && URL.revokeObjectURL(p), g(null), f(null)
        }, e[3] = p, e[4] = j) : j = e[4];
        const v = j;
        let S;
        e[5] !== a || e[6] !== v || e[7] !== n ? (S = () => {
            !a || !n || (v(), r(!0))
        }, e[5] = a, e[6] = v, e[7] = n, e[8] = S) : S = e[8];
        const C = S;
        let M;
        e[9] !== v ? (M = () => {
            v(), r(!1)
        }, e[9] = v, e[10] = M) : M = e[10];
        const E = M,
            N = Pf;
        let k;
        if (e[11] !== p || e[12] !== l) {
            const W = V => {
                if (V.size > ju) {
                    l.danger(ms.logoTooLarge);
                    return
                }
                if (!N(V)) {
                    l.danger(ms.logoInvalidType);
                    return
                }
                p && URL.revokeObjectURL(p), f(V), g(URL.createObjectURL(V))
            };
            k = V => {
                var ce;
                const J = (ce = V.target.files) == null ? void 0 : ce[0];
                J && W(J), h.current && (h.current.value = "")
            }, e[11] = p, e[12] = l, e[13] = k
        } else k = e[13];
        const P = k;
        let L;
        e[14] !== n || e[15] !== o || e[16] !== i ? (L = async W => {
            const {
                logoData: V
            } = W;
            if (!n) throw new Error("Connector not found");
            await _l(n.id, V), await Promise.all([o(), i()])
        }, e[14] = n, e[15] = o, e[16] = i, e[17] = L) : L = e[17];
        let A;
        e[18] !== E || e[19] !== c || e[20] !== l ? (A = () => {
            l.success(c.formatMessage(ms.updateLogoSuccess)), E()
        }, e[18] = E, e[19] = c, e[20] = l, e[21] = A) : A = e[21];
        let _;
        e[22] !== l ? (_ = W => {
            l.danger(ms.updateLogoError, {
                error: W
            })
        }, e[22] = l, e[23] = _) : _ = e[23];
        let D;
        e[24] !== L || e[25] !== A || e[26] !== _ ? (D = {
            mutationFn: L,
            onSuccess: A,
            onError: _
        }, e[24] = L, e[25] = A, e[26] = _, e[27] = D) : D = e[27];
        const T = pt(D);
        let F;
        e[28] !== u || e[29] !== l || e[30] !== T ? (F = async () => {
            if (!(!u || T.isPending)) try {
                const W = await Tf(u);
                await T.mutateAsync({
                    logoData: W
                })
            } catch (W) {
                const V = W;
                l.danger(ms.updateLogoError, {
                    error: V
                })
            }
        }, e[28] = u, e[29] = l, e[30] = T, e[31] = F) : F = e[31];
        const O = F,
            I = (z = p != null ? p : n == null ? void 0 : n.logo_url) != null ? z : void 0;
        let U;
        e[32] !== a || e[33] !== n || e[34] !== E || e[35] !== P || e[36] !== O || e[37] !== c || e[38] !== d || e[39] !== u || e[40] !== I || e[41] !== T ? (U = a && n ? t.jsx(Js, {
            isOpen: d,
            onClose: E,
            showCloseButton: !0,
            type: "success",
            className: "max-w-[360px]",
            testId: "modal-update-connector-logo",
            title: t.jsx(m, b({}, ms.editLogoModalTitle)),
            children: t.jsxs("div", {
                className: "flex flex-col gap-4",
                children: [t.jsxs("div", {
                    className: "flex items-center gap-4",
                    children: [t.jsx("div", {
                        className: "border-token-border-default bg-token-bg-primary flex h-20 w-20 items-center justify-center overflow-hidden rounded-2xl border p-2",
                        children: I ? t.jsx("img", {
                            src: I,
                            alt: c.formatMessage(ms.logoPreviewAlt),
                            className: "h-full w-full object-cover"
                        }) : t.jsx(Un, {
                            connector: n,
                            size: "large",
                            className: "h-full w-full"
                        })
                    }), t.jsxs("div", {
                        className: "flex flex-col gap-2 text-sm",
                        children: [t.jsx(m, b({}, ms.editLogoModalDescription)), t.jsxs("div", {
                            children: [t.jsx("input", {
                                ref: h,
                                type: "file",
                                accept: ".svg,image/svg+xml",
                                className: "hidden",
                                onChange: P,
                                disabled: T.isPending
                            }), t.jsx(ne, {
                                color: "secondary",
                                size: "small",
                                onClick: () => {
                                    var W;
                                    return (W = h.current) == null ? void 0 : W.click()
                                },
                                disabled: T.isPending,
                                children: t.jsx(m, b({}, ms.logoUploadCta))
                            })]
                        }), u && t.jsx("span", {
                            className: "text-token-text-secondary text-xs",
                            children: u.name
                        })]
                    })]
                }), t.jsxs("div", {
                    className: "flex justify-end gap-2",
                    children: [t.jsx(ne, {
                        color: "ghost",
                        onClick: E,
                        disabled: T.isPending,
                        children: t.jsx(m, b({}, Ua.cancelButtonText))
                    }), t.jsx(ne, {
                        onClick: O,
                        loading: T.isPending,
                        disabled: !u || T.isPending,
                        children: t.jsx(m, b({}, ms.saveLogo))
                    })]
                })]
            })
        }) : null, e[32] = a, e[33] = n, e[34] = E, e[35] = P, e[36] = O, e[37] = c, e[38] = d, e[39] = u, e[40] = I, e[41] = T, e[42] = U) : U = e[42];
        const R = U;
        let B;
        return e[43] !== C || e[44] !== R ? (B = {
            logoModal: R,
            openLogoModal: C
        }, e[43] = C, e[44] = R, e[45] = B) : B = e[45], B
    },
    ms = Ke({
        logoTooLarge: {
            id: "32+ZLw",
            defaultMessage: "Logo is too large"
        },
        editLogoModalTitle: {
            id: "6wYY0P",
            defaultMessage: "Update connector logo"
        },
        editLogoModalDescription: {
            id: "YrJSJz",
            defaultMessage: "Upload an SVG under 5MB."
        },
        logoUploadCta: {
            id: "msWUua",
            defaultMessage: "Choose image"
        },
        logoPreviewAlt: {
            id: "w8X79n",
            defaultMessage: "Selected connector logo preview"
        },
        saveLogo: {
            id: "RQ6oQW",
            defaultMessage: "Save"
        },
        updateLogoSuccess: {
            id: "tkukWJ",
            defaultMessage: "Connector logo updated"
        },
        updateLogoError: {
            id: "ywBEC5",
            defaultMessage: "Couldn't update connector logo"
        },
        logoInvalidType: {
            id: "pSNZvD",
            defaultMessage: "Only SVG files are supported"
        }
    });

function Pf(s) {
    const e = s.type.toLowerCase(),
        a = s.name.toLowerCase();
    return e === "image/svg+xml" || a.endsWith(".svg")
}
const Df = s => {
        "use forget";
        var B;
        const e = Se.c(46),
            {
                canEditName: a,
                connector: n,
                refetchConnectors: o
            } = s,
            i = K(),
            c = Ct(),
            [l, d] = w.useState(!1),
            [r, u] = w.useState(""),
            [f, p] = w.useState(null);
        let g, h;
        e[0] !== n || e[1] !== l ? (g = () => {
            var z;
            if (!n) {
                u("");
                return
            }
            l || (u((z = n.name) != null ? z : ""), p(null))
        }, h = [n, l], e[0] = n, e[1] = l, e[2] = g, e[3] = h) : (g = e[2], h = e[3]), w.useEffect(g, h);
        let y;
        e[4] !== r ? (y = r.trim(), e[4] = r, e[5] = y) : y = e[5];
        const x = y,
            j = (B = n == null ? void 0 : n.name) != null ? B : "";
        let v;
        e[6] !== j ? (v = j.trim(), e[6] = j, e[7] = v) : v = e[7];
        const C = x !== v;
        let M;
        e[8] !== i ? (M = async z => {
            const {
                connectorId: W,
                name: V
            } = z;
            if (!V) throw new Error(i.formatMessage(Zn.nameRequiredError));
            await wl(W, V)
        }, e[8] = i, e[9] = M) : M = e[9];
        let E;
        e[10] !== i || e[11] !== o || e[12] !== c ? (E = async () => {
            await o(), c.success(i.formatMessage(Zn.updateNameSuccess)), d(!1)
        }, e[10] = i, e[11] = o, e[12] = c, e[13] = E) : E = e[13];
        let N;
        e[14] !== c ? (N = z => {
            c.danger(Zn.updateNameError, {
                error: z
            })
        }, e[14] = c, e[15] = N) : N = e[15];
        let k;
        e[16] !== M || e[17] !== E || e[18] !== N ? (k = {
            mutationFn: M,
            onSuccess: E,
            onError: N
        }, e[16] = M, e[17] = E, e[18] = N, e[19] = k) : k = e[19];
        const P = pt(k),
            L = P.isPending;
        let A;
        e[20] !== a || e[21] !== n ? (A = () => {
            var z;
            !a || !n || n.connector_type !== "MCP" || (u((z = n.name) != null ? z : ""), p(null), d(!0))
        }, e[20] = a, e[21] = n, e[22] = A) : A = e[22];
        const _ = A;
        let D;
        e[23] !== n ? (D = () => {
            var z;
            d(!1), u(n && (z = n.name) != null ? z : ""), p(null)
        }, e[23] = n, e[24] = D) : D = e[24];
        const T = D;
        let F;
        e[25] !== n || e[26] !== C || e[27] !== i || e[28] !== L || e[29] !== x || e[30] !== P ? (F = () => {
            if (!(!n || n.connector_type !== "MCP" || !C || L)) {
                if (!x) {
                    p(i.formatMessage(Zn.nameRequiredError));
                    return
                }
                p(null), P.mutate({
                    connectorId: n.id,
                    name: x
                })
            }
        }, e[25] = n, e[26] = C, e[27] = i, e[28] = L, e[29] = x, e[30] = P, e[31] = F) : F = e[31];
        const O = F;
        let I;
        e[32] !== a || e[33] !== (n == null ? void 0 : n.connector_type) || e[34] !== f || e[35] !== T || e[36] !== O || e[37] !== C || e[38] !== i || e[39] !== l || e[40] !== L || e[41] !== r ? (I = (a && (n == null || n.connector_type), null), e[32] = a, e[33] = n == null ? void 0 : n.connector_type, e[34] = f, e[35] = T, e[36] = O, e[37] = C, e[38] = i, e[39] = l, e[40] = L, e[41] = r, e[42] = I) : I = e[42];
        const U = I;
        let R;
        return e[43] !== _ || e[44] !== U ? (R = {
            nameModal: U,
            openNameModal: _
        }, e[43] = _, e[44] = U, e[45] = R) : R = e[45], R
    },
    Zn = Ke({
        editNameTitle: {
            id: "DOLSQI",
            defaultMessage: "Edit connector name"
        },
        saveName: {
            id: "anaUOZ",
            defaultMessage: "Save"
        },
        nameFieldLabel: {
            id: "ucgD0L",
            defaultMessage: "Connector name"
        },
        namePlaceholder: {
            id: "fhKXMM",
            defaultMessage: "Enter connector name"
        },
        nameRequiredError: {
            id: "Jr2vnL",
            defaultMessage: "Connector name is required"
        },
        updateNameSuccess: {
            id: "BjLQFv",
            defaultMessage: "Connector name updated"
        },
        updateNameError: {
            id: "PCgsha",
            defaultMessage: "Failed to update connector name"
        }
    }),
    Lf = s => {
        "use forget";
        var B, z;
        const e = Se.c(46),
            {
                canEditPrivacyPolicy: a,
                connector: n,
                refetchConnectors: o
            } = s,
            i = K(),
            c = Ct(),
            [l, d] = w.useState(!1),
            [r, u] = w.useState(""),
            [f, p] = w.useState(null);
        let g, h;
        e[0] !== n || e[1] !== l ? (g = () => {
            var W, V;
            if (!n) {
                u("");
                return
            }
            l || (u((V = (W = n.branding) == null ? void 0 : W.privacy_policy) != null ? V : ""), p(null))
        }, h = [n, l], e[0] = n, e[1] = l, e[2] = g, e[3] = h) : (g = e[2], h = e[3]), w.useEffect(g, h);
        let y;
        e[4] !== r ? (y = r.trim(), e[4] = r, e[5] = y) : y = e[5];
        const x = y,
            j = (z = (B = n == null ? void 0 : n.branding) == null ? void 0 : B.privacy_policy) != null ? z : "";
        let v;
        e[6] !== j ? (v = j.trim(), e[6] = j, e[7] = v) : v = e[7];
        const C = x !== v;
        let M;
        e[8] !== i ? (M = async W => {
            const {
                connectorId: V,
                privacyPolicyUrl: J
            } = W;
            if (J && !J.match(/^https?:\/\//)) throw new Error(i.formatMessage(Xn.privacyPolicyInvalidUrlError));
            await kl(V, {
                privacy_policy: J || null
            })
        }, e[8] = i, e[9] = M) : M = e[9];
        let E;
        e[10] !== i || e[11] !== o || e[12] !== c ? (E = async () => {
            await o(), c.success(i.formatMessage(Xn.updatePrivacyPolicySuccess)), d(!1)
        }, e[10] = i, e[11] = o, e[12] = c, e[13] = E) : E = e[13];
        let N;
        e[14] !== c ? (N = W => {
            c.danger(Xn.updatePrivacyPolicyError, {
                error: W
            })
        }, e[14] = c, e[15] = N) : N = e[15];
        let k;
        e[16] !== M || e[17] !== E || e[18] !== N ? (k = {
            mutationFn: M,
            onSuccess: E,
            onError: N
        }, e[16] = M, e[17] = E, e[18] = N, e[19] = k) : k = e[19];
        const P = pt(k),
            L = P.isPending;
        let A;
        e[20] !== a || e[21] !== n ? (A = () => {
            var W, V;
            !a || !n || (u((V = (W = n.branding) == null ? void 0 : W.privacy_policy) != null ? V : ""), p(null), d(!0))
        }, e[20] = a, e[21] = n, e[22] = A) : A = e[22];
        const _ = A;
        let D;
        e[23] !== n ? (D = () => {
            var W, V;
            d(!1), u(n && (V = (W = n.branding) == null ? void 0 : W.privacy_policy) != null ? V : ""), p(null)
        }, e[23] = n, e[24] = D) : D = e[24];
        const T = D;
        let F;
        e[25] !== n || e[26] !== C || e[27] !== i || e[28] !== L || e[29] !== x || e[30] !== P ? (F = () => {
            if (!(!n || !C || L)) {
                if (x && !x.match(/^https?:\/\//)) {
                    p(i.formatMessage(Xn.privacyPolicyInvalidUrlError));
                    return
                }
                p(null), P.mutate({
                    connectorId: n.id,
                    privacyPolicyUrl: x
                })
            }
        }, e[25] = n, e[26] = C, e[27] = i, e[28] = L, e[29] = x, e[30] = P, e[31] = F) : F = e[31];
        const O = F;
        let I;
        e[32] !== a || e[33] !== n || e[34] !== f || e[35] !== T || e[36] !== O || e[37] !== C || e[38] !== i || e[39] !== l || e[40] !== L || e[41] !== r ? (I = null, e[32] = a, e[33] = n, e[34] = f, e[35] = T, e[36] = O, e[37] = C, e[38] = i, e[39] = l, e[40] = L, e[41] = r, e[42] = I) : I = e[42];
        const U = I;
        let R;
        return e[43] !== _ || e[44] !== U ? (R = {
            privacyPolicyModal: U,
            openPrivacyPolicyModal: _
        }, e[43] = _, e[44] = U, e[45] = R) : R = e[45], R
    },
    Xn = Ke({
        editPrivacyPolicyTitle: {
            id: "K1Teho",
            defaultMessage: "Update privacy policy URL"
        },
        savePrivacyPolicy: {
            id: "9ZkqeU",
            defaultMessage: "Save"
        },
        privacyPolicyFieldLabel: {
            id: "P2lucE",
            defaultMessage: "Privacy policy URL"
        },
        privacyPolicyPlaceholder: {
            id: "Unv37k",
            defaultMessage: "https://example.com/privacy"
        },
        privacyPolicyHelper: {
            id: "5IWBi3",
            defaultMessage: "Use an https:// URL. Leave blank to clear the value."
        },
        privacyPolicyInvalidUrlError: {
            id: "xAdurX",
            defaultMessage: "Privacy policy URL must start with http:// or https://"
        },
        updatePrivacyPolicySuccess: {
            id: "GvaMBG",
            defaultMessage: "Privacy policy updated"
        },
        updatePrivacyPolicyError: {
            id: "9ktIkp",
            defaultMessage: "Failed to update privacy policy"
        }
    }),
    mr = ({
        onBackClick: s,
        onDisconnectClick: e,
        fileUploadConfig: a,
        onConnectClick: n,
        connector: o
    }) => {
        const i = K(),
            c = La(a.type, i),
            {
                description: l,
                Icon: d
            } = If[a.type],
            r = ve(),
            u = Qe(() => Os(r)),
            f = r && je(r, "4026425501"),
            p = o ? jn(o, i, {
                isDeveloperMode: u,
                ecosystemDebugShowAppUrlsInSettings: f
            }) : void 0;
        return t.jsx(dr, {
            icon: t.jsx("span", {
                className: "border-token-border-default bg-token-bg-primary shadow-xxs max-h-fit rounded-2xl border-[0.5px] bg-clip-padding p-2",
                children: t.jsx(d, {
                    className: "h-10 w-10"
                })
            }),
            name: c,
            description: i.formatMessage(l),
            onBackClick: s,
            details: p,
            onDisconnectClick: e,
            onConnectClick: n
        })
    },
    Ca = Ke({
        o365Desc: {
            id: "connectorSettings.o365Desc.1",
            defaultMessage: "Upload Microsoft Word, Excel, PowerPoint and other files."
        },
        o365BusinessDesc: {
            id: "connectorSettings.o365BusinessDesc.1",
            defaultMessage: "Upload Microsoft Word, Excel, PowerPoint, and other files, including those from SharePoint sites."
        },
        gdriveDesc: {
            id: "HIdrop",
            defaultMessage: "Search and reference files from your Drive."
        }
    }),
    If = {
        [St.O365_PERSONAL]: {
            description: Ca.o365Desc,
            Icon: na
        },
        [St.O365_BUSINESS]: {
            description: Ca.o365BusinessDesc,
            Icon: na
        },
        [St.GDRIVE]: {
            description: Ca.gdriveDesc,
            Icon: fi
        }
    },
    pr = s => {
        "use forget";
        const e = Se.c(2),
            {
                children: a
            } = s;
        let n;
        return e[0] !== a ? (n = t.jsx("span", {
            className: "bg-token-bg-tertiary text-token-text-secondary my-0.5 inline-block rounded-md px-1.5 py-0.5 text-xs",
            children: a
        }), e[0] = a, e[1] = n) : n = e[1], n
    },
    Rf = s => {
        "use forget";
        const e = Se.c(9),
            {
                internalKnowledgeConfig: a
            } = s,
            n = K();
        let o;
        e[0] !== n ? (o = n.formatMessage(It.sync), e[0] = n, e[1] = o) : o = e[1];
        let i;
        e[2] !== o ? (i = t.jsx(pr, {
            children: o
        }), e[2] = o, e[3] = i) : i = e[3];
        let c;
        e[4] !== a ? (c = t.jsx(Bn, {
            connection: a,
            location: "user_settings"
        }), e[4] = a, e[5] = c) : c = e[5];
        let l;
        return e[6] !== i || e[7] !== c ? (l = t.jsxs("div", {
            className: "flex items-center gap-1",
            children: [i, c]
        }), e[6] = i, e[7] = c, e[8] = l) : l = e[8], l
    },
    hr = (s, e) => {
        const a = ve(),
            {
                refetch: n
            } = mi();
        return async () => {
            try {
                await tt.safeDelete("/connectors/user_setting/{connector_name}", {
                    parameters: {
                        path: {
                            connector_name: s
                        }
                    }
                }), e == null || e()
            } catch (o) {
                es(a).danger(It.disconnectError, {
                    error: o
                })
            } finally {
                n()
            }
        }
    },
    Bf = () => {
        const s = ve(),
            {
                refetch: e
            } = da();
        return async a => {
            try {
                await aa.user_disconnect(a)
            } catch (n) {
                es(s).danger(It.disconnectError, {
                    error: n
                })
            } finally {
                e()
            }
        }
    },
    Of = ({
        connector: s,
        links: e,
        removeConnectorId: a,
        onLinkClick: n,
        onAddClick: o,
        additionalLinks: i
    }) => t.jsxs(t.Fragment, {
        children: [t.jsxs("div", {
            className: "min-h-header-height flex items-center justify-between",
            children: [t.jsx(ne, {
                color: "ghost",
                onClick: a,
                icon: Fa,
                children: t.jsx(m, b({}, It.backButton))
            }), o && t.jsx(ne, {
                color: "secondary",
                onClick: o,
                children: t.jsx(m, b({}, It.addButton))
            })]
        }), t.jsxs("div", {
            className: "pt-2",
            children: [e.map(c => t.jsx(Ff, {
                link: c,
                onLinkClick: n,
                connector: s
            }, c.id)), i]
        })]
    }),
    Ff = ({
        link: s,
        onLinkClick: e,
        connector: a
    }) => {
        var n, o, i, c;
        return t.jsx(Q, {
            children: t.jsx("button", {
                className: "w-full",
                onClick: () => e(s.id),
                children: t.jsx("div", {
                    className: "px-3 pt-3 pb-1",
                    children: t.jsx(Bs, {
                        icon: t.jsx(oa, {
                            connector: a
                        }),
                        title: (c = (i = (n = s.owner_profile) == null ? void 0 : n.email) != null ? i : (o = s.owner_profile) == null ? void 0 : o.name) != null ? c : s.name,
                        statusIndicator: t.jsx(vn, {
                            className: "icon"
                        })
                    })
                })
            })
        }, s.id)
    },
    Uf = ({
        connector: s,
        platformLink: e
    }) => {
        var P, L, A, _;
        const a = ve(),
            n = K(),
            o = zs(),
            i = Oa(),
            c = Gs(),
            l = Ai(),
            d = Qe(() => Os(a)),
            r = Dl(),
            {
                mutateAsync: u
            } = Ra(),
            f = Ct(),
            [p, g] = w.useState(!1),
            [h, y] = w.useState(!1),
            {
                internalKnowledgeConfigs: x
            } = ua(),
            j = In(e),
            v = (P = Ba()) != null ? P : "unknown_referrer",
            S = j ? void 0 : () => {
                l(e.id, () => {
                    f.success(n.formatMessage(It.disconnectSuccess, {
                        connector: _n(s.name, n)
                    })), c(), bn(a)
                }, Ot.CONNECTOR_SETTING)
            },
            C = w.useMemo(() => !(x != null && x.length) || !(e != null && e.id) ? null : x.find(D => (e == null ? void 0 : e.id) === D.user_connection_details.backing_link_id), [x, e == null ? void 0 : e.id]),
            M = async () => {
                await r(e.id)
            },
            E = a && je(a, "4026425501"),
            N = w.useMemo(() => e ? [{
                title: n.formatMessage(It.connectedOn),
                value: new Date(e.created_at).toLocaleString([], {
                    year: "numeric",
                    month: "short",
                    day: "numeric"
                })
            }, ...jn(s, n, {
                isDeveloperMode: d,
                linkAuthType: e.auth_type,
                ecosystemDebugShowAppUrlsInSettings: E
            })] : [], [e, n, s, d, E]),
            k = w.useMemo(() => {
                if (!C) return;
                const D = C.user_connection_details.knowledge_connector_type;
                if (D) return D === "slack" ? "synced_channel" : "synced_object"
            }, [C]);
        return t.jsxs(t.Fragment, {
            children: [t.jsx(pa, {
                badge: C ? t.jsx(Bn, {
                    connection: C,
                    location: "user_settings"
                }) : void 0,
                connector: s,
                onBackClick: () => c(),
                details: N,
                reportEntity: {
                    id: s.id,
                    entityType: Ga.Connector
                },
                onBlockItems: C && i ? () => g(!0) : void 0,
                onDisconnectClick: S,
                onDeleteSyncClick: C ? () => y(!0) : void 0,
                onEnableSyncClick: C || !i ? void 0 : () => {
                    Ue.logEventWithStatsig("Connectors - Upgrade Personal Google Drive", "chatgpt_connectors_upgrade_personal_google_drive_clicked"), u({
                        link: e,
                        referrer: v
                    })
                }
            }), t.jsx(gr, {
                connector: s,
                onDisableSync: M,
                isOpen: h,
                onClose: () => y(!1)
            }), k && t.jsx(ku, {
                accountId: (L = o == null ? void 0 : o.id) != null ? L : "",
                connectionId: (_ = (A = C == null ? void 0 : C.user_connection_details) == null ? void 0 : A.connection_instance_id) != null ? _ : "",
                isOpen: p,
                objectType: k,
                onClose: () => g(!1)
            })]
        })
    },
    Gf = ({
        onAddClick: s
    }) => {
        var L;
        const e = ve(),
            a = K(),
            n = zs(),
            o = Oa(),
            i = !!(n != null && n.isPersonalAccount() && o),
            c = Qe(() => Na(e, {
                productSku: Ot.CONNECTOR_SETTING
            })),
            l = Ia({
                fetchValidLinksOnly: !0,
                productSku: Ot.CONNECTOR_SETTING
            }),
            d = (L = c.data) == null ? void 0 : L.connectors.find(A => A.id === xs),
            r = w.useMemo(() => Gi(d), [d]),
            u = w.useMemo(() => {
                var A;
                return (A = l.connectorLinks.get(xs)) != null ? A : []
            }, [l.connectorLinks]),
            f = Gs(),
            p = Ai(),
            g = Bf(),
            h = hr(St.GDRIVE),
            {
                internalKnowledgeConfigs: y,
                fileUploadConfig: x,
                isLoading: j
            } = ua(),
            v = w.useMemo(() => {
                var A;
                return (A = y == null ? void 0 : y.filter(_ => _.user_connection_details.auth_status !== "not_connected")) != null ? A : []
            }, [y]),
            [S, C] = w.useState(null),
            M = (x != null && x.access_token ? 1 : 0) + (n != null && n.isPersonalAccount() ? 0 : v.length) + u.length,
            [E] = w.useState(M),
            N = w.useMemo(() => !!y && !i && y.length - v.length > 0 || u.length === 0, [y, i, v.length, u.length]),
            k = w.useMemo(() => E > 1 ? S : x != null && x.access_token ? {
                type: "file_uploads"
            } : n != null && n.isPersonalAccount() && u.length > 0 ? {
                type: "upgradable_platform_connector",
                link: u[0]
            } : v.length > 0 ? {
                type: "internal_knowledge",
                config: v[0]
            } : u.length > 0 ? {
                type: "platform_connector",
                link: u[0]
            } : null, [E, x == null ? void 0 : x.access_token, n, u, v, S]);
        if (c.isFetching || l.isLoading || j) return t.jsx("div", {
            className: "flex justify-center p-10",
            children: t.jsx(ys, {})
        });
        if (c.error || l.error || !r) return f(), null;
        if (M === 0) return t.jsx(fr, {
            connector: r,
            onBackClick: () => f(),
            onConnectClick: s
        });
        if (!k) {
            const A = _ => {
                const D = u.find(T => T.id === _);
                D && (n != null && n.isPersonalAccount() ? C({
                    type: "upgradable_platform_connector",
                    link: D
                }) : C({
                    type: "platform_connector",
                    link: D
                }))
            };
            return t.jsx(Of, {
                connector: r,
                links: u,
                removeConnectorId: () => f(),
                onLinkClick: A,
                onAddClick: N ? s : void 0,
                additionalLinks: t.jsxs(t.Fragment, {
                    children: [!(n != null && n.isPersonalAccount()) && v.map(_ => t.jsx(Q, {
                        children: t.jsx("button", {
                            className: "w-full",
                            onClick: () => C({
                                type: "internal_knowledge",
                                config: _
                            }),
                            children: t.jsx("div", {
                                className: "px-3 pt-3 pb-1",
                                children: t.jsx(Bs, {
                                    icon: t.jsx(oa, {
                                        connector: r
                                    }),
                                    title: _.connection_display_info.display_name,
                                    description: t.jsx(Rf, {
                                        internalKnowledgeConfig: _
                                    }),
                                    statusIndicator: t.jsx(vn, {
                                        className: "icon"
                                    })
                                })
                            })
                        })
                    }, _.user_connection_details.connection_instance_id)), !!(x != null && x.access_token) && t.jsx(Q, {
                        children: t.jsx("button", {
                            className: "w-full",
                            onClick: () => C({
                                type: "file_uploads"
                            }),
                            children: t.jsx("div", {
                                className: "px-3 pt-3 pb-1",
                                children: t.jsx(Bs, {
                                    icon: t.jsx(oa, {
                                        connector: r
                                    }),
                                    title: x.name,
                                    description: t.jsx(pr, {
                                        children: a.formatMessage(It.fileUploads)
                                    }),
                                    statusIndicator: t.jsx(vn, {
                                        className: "icon"
                                    })
                                })
                            })
                        })
                    })]
                })
            })
        }
        const P = () => {
            S ? C(null) : f()
        };
        switch (k.type) {
            case "platform_connector":
                {
                    const _ = In(k.link) ? void 0 : () => {
                        p(k.link.id, () => {
                            es(e).success(a.formatMessage(It.disconnectSuccess, {
                                connector: _n(r.name, a)
                            })), C(null)
                        }, Ot.CONNECTOR_SETTING)
                    };
                    return t.jsx(ur, {
                        connector: r,
                        onBackClick: P,
                        link: k.link,
                        onDisconnectClick: _,
                        onConnectClick: N ? s : void 0
                    })
                }
            case "upgradable_platform_connector":
                return t.jsx(Uf, {
                    connector: r,
                    platformLink: k.link
                });
            case "internal_knowledge":
                {
                    const A = async () => {
                        await g(k.config.user_connection_details.connection_instance_id), C(null)
                    };
                    return t.jsx(Mf, {
                        connector: r,
                        onBackClick: P,
                        onDisconnectClick: A,
                        internalKnowledgeConfig: k.config,
                        onConnectClick: N ? s : void 0
                    })
                }
            case "file_uploads":
                {
                    if (!x) return null;
                    const A = async () => {
                        await h(), C(null)
                    };
                    return t.jsx(mr, {
                        onBackClick: P,
                        onDisconnectClick: A,
                        fileUploadConfig: x,
                        connector: r,
                        onConnectClick: N ? s : void 0
                    })
                }
        }
    },
    Zo = ({
        type: s
    }) => {
        const {
            personalConfig: e,
            businessConfig: a,
            isLoading: n
        } = bi(), o = s === St.O365_PERSONAL ? e : a, i = Gs(), c = hr(s, () => {
            i()
        });
        return n ? t.jsx("div", {
            className: "flex justify-center p-10",
            children: t.jsx(ys, {})
        }) : o ? t.jsx(mr, {
            onBackClick: () => i(),
            onDisconnectClick: c,
            fileUploadConfig: o
        }) : (i(), null)
    },
    zf = ({
        connectorId: s,
        onAddLinkClick: e
    }) => {
        var R;
        const a = ve(),
            n = K(),
            o = Qe(() => Na(a, {
                productSku: Ot.CONNECTOR_SETTING
            })),
            i = () => Na.refetch(a, {
                productSku: Ot.CONNECTOR_SETTING
            }),
            c = Ia({
                fetchValidLinksOnly: !0,
                productSku: Ot.CONNECTOR_SETTING
            }),
            l = (R = o.data) == null ? void 0 : R.connectors.find(B => B.id === s),
            d = w.useMemo(() => Gi(l), [l]),
            r = c.connectorLinks.get(s),
            u = r && r.length > 0,
            f = !!d && d.connector_type === "MCP",
            p = Gs(),
            g = El(),
            h = er(d),
            y = f && h,
            j = !!(je(a, "3870713715") && f && h),
            {
                logoModal: v,
                openLogoModal: S
            } = Af({
                canEditLogo: j,
                connector: d,
                refetchConnectors: i,
                refetchLinks: () => c.refetch()
            }),
            {
                nameModal: C,
                openNameModal: M
            } = Df({
                canEditName: !!(h && f),
                connector: d,
                refetchConnectors: i
            }),
            {
                descriptionModal: E,
                openDescriptionModal: N
            } = Ef({
                canEditDescription: h,
                connector: d,
                refetchConnectors: i
            }),
            {
                privacyPolicyModal: k,
                openPrivacyPolicyModal: P
            } = Lf({
                canEditPrivacyPolicy: h,
                connector: d,
                refetchConnectors: i
            }),
            L = o.isLoading || c.isLoading,
            A = pt({
                mutationFn: async () => {
                    if (!d) throw new Error("Connector not found");
                    e()
                },
                onError: B => {
                    es(a).danger(It.connectError, {
                        error: B
                    })
                }
            }),
            _ = pt({
                mutationFn: async () => {
                    await g(s, () => {
                        es(a).success(d ? n.formatMessage(It.disconnectSuccess, {
                            connector: _n(d.name, n)
                        }) : n.formatMessage(It.disconnectGenericSuccess))
                    }, Ot.CONNECTOR_SETTING)
                }
            }),
            D = pt({
                mutationFn: async B => {
                    await Tl(B)
                },
                onSuccess: () => {
                    F.refetchQueries({
                        queryKey: ["connector-actions", s]
                    }), F.refetchQueries({
                        queryKey: Nl()
                    })
                },
                onError: B => {
                    es(a).danger(It.refreshActionsError, {
                        error: B
                    })
                }
            }),
            T = pt({
                mutationFn: async () => {
                    await Al(s), await Promise.all([i(), c.refetch()])
                },
                onError: B => {
                    es(a).danger(It.deleteError, {
                        error: B
                    })
                },
                onSuccess: () => {
                    p()
                }
            }),
            F = _t(),
            O = pt({
                mutationFn: async ({
                    linkId: B,
                    action: z,
                    enabled: W
                }) => {
                    F.setQueryData(yo(!0), ae => Mo(ae, Z => {
                        var ee;
                        const $ = (ee = Z[s]) == null ? void 0 : ee.find(de => de.id === B);
                        if (W) $ != null && $.actions.includes(z) || $ == null || $.actions.push(z);
                        else {
                            const de = $ == null ? void 0 : $.actions.indexOf(z);
                            de !== void 0 && de !== -1 && ($ == null || $.actions.splice(de, 1))
                        }
                    }));
                    const V = r == null ? void 0 : r.find(ae => ae.id === B);
                    if (!V) return;
                    const J = W ? [...V.actions, z] : V.actions.filter(ae => ae !== z),
                        ce = await Pl(B, J);
                    F.setQueryData(yo(!0), ae => Mo(ae, Z => {
                        const $ = Z[s],
                            ee = $ == null ? void 0 : $.findIndex(de => de.id === B);
                        ee !== void 0 && ee !== -1 && ($[ee] = ce.link)
                    }))
                },
                onError: B => {
                    es(a).danger(It.toggleActionError, {
                        error: B
                    })
                }
            });
        if (L) return t.jsx("div", {
            className: "flex justify-center p-10",
            children: t.jsx(ys, {})
        });
        if (o.error || c.error || !d) return p(), null;
        if (!u) return t.jsxs(t.Fragment, {
            children: [t.jsx(fr, {
                connector: d,
                onBackClick: () => p(),
                onConnectClick: () => A.mutate(),
                isConnecting: A.isPending,
                isDisconnecting: _.isPending,
                isDeleting: T.isPending,
                onDelete: y ? () => T.mutate() : void 0,
                onEditName: h && f ? M : void 0,
                onEditDescription: h ? N : void 0,
                onEditPrivacyPolicy: h ? P : void 0,
                onEditLogo: j ? S : void 0
            }), C, E, k, v]
        });
        const U = (r != null && r[0] ? In(r[0]) : !1) ? void 0 : () => _.mutate();
        return t.jsxs(t.Fragment, {
            children: [t.jsx(ur, {
                connector: d,
                onBackClick: () => p(),
                link: r[0],
                onDisconnectClick: U,
                isDisconnecting: _.isPending,
                isDeleting: T.isPending,
                onDelete: y ? () => T.mutate() : void 0,
                onRefreshActions: () => D.mutate(r[0].id),
                isRefreshingActions: D.isPending,
                onToggleAction: (B, z) => O.mutate({
                    linkId: r[0].id,
                    action: B,
                    enabled: z
                }),
                isTogglingAction: O.isPending,
                onEditName: h && f ? M : void 0,
                onEditDescription: h ? N : void 0,
                onEditPrivacyPolicy: h ? P : void 0,
                onEditLogo: j ? S : void 0
            }), C, E, k, v]
        })
    },
    Hf = ({
        connectorId: s,
        onAddClick: e
    }) => s === xs ? t.jsx(Gf, {
        onAddClick: e
    }) : s === "onedrive-personal" ? t.jsx(Zo, {
        type: St.O365_PERSONAL
    }) : s === "onedrive-business" ? t.jsx(Zo, {
        type: St.O365_BUSINESS
    }) : t.jsx(zf, {
        connectorId: s,
        onAddLinkClick: e
    }),
    It = Ke({
        backButton: {
            id: "2XH9oW",
            defaultMessage: "Back"
        },
        addButton: {
            id: "lkrz+6",
            defaultMessage: "Add"
        },
        connectedOn: {
            id: "b1ykGv",
            defaultMessage: "Connected on"
        },
        sync: {
            id: "W4yI4C",
            defaultMessage: "Chat"
        },
        disableSync: {
            id: "LM6oW1",
            defaultMessage: "Disable sync"
        },
        fileUploads: {
            id: "gFheug",
            defaultMessage: "File uploads"
        },
        deepResearch: {
            id: "EnDZig",
            defaultMessage: "Deep Research"
        },
        connectError: {
            id: "9/ATb1",
            defaultMessage: "Error connecting your account."
        },
        refreshActionsError: {
            id: "j+WGY0",
            defaultMessage: "Error refreshing actions."
        },
        disconnectError: {
            id: "DqZbNO",
            defaultMessage: "Error disconnecting your account."
        },
        disconnectSuccess: {
            id: "CoyFU4",
            defaultMessage: "{connector} disconnected"
        },
        disconnectGenericSuccess: {
            id: "Yh+piF",
            defaultMessage: "Connector disconnected"
        },
        deleteError: {
            id: "ZeAn4n",
            defaultMessage: "Error deleting your connector."
        },
        toggleActionError: {
            id: "DofG17",
            defaultMessage: "Error toggling action."
        },
        mcpServerConformError: {
            id: "igeVCu",
            defaultMessage: "This MCP server can't be used by ChatGPT to search information because it doesn't implement <link>our specification</link>."
        },
        mcpServerConformErrorWithReason: {
            id: "g1U6+s",
            defaultMessage: "This MCP server can't be used by ChatGPT to search information because it doesn't implement <link>our specification</link>: {reason}"
        }
    }),
    Wf = ft(() => gt(() =>
        import ("./eiz8m6b2n93cr92l.js"), __vite__mapDeps([9, 1, 2, 3, 6, 7, 10])).then(s => s.GithubOnboardingModal)),
    Vf = ft(() => gt(() =>
        import ("./pavmkm4i771s3in0.js"), __vite__mapDeps([11, 1, 2, 3])).then(s => s.ConnectorsUpgradeModal)),
    $f = s => {
        "use forget";
        const e = Se.c(37),
            {
                onAddLinkClick: a,
                onCreateCustomConnectorClick: n
            } = s,
            o = ve(),
            i = bs(),
            c = Sn(),
            l = Ll(),
            d = Gs(),
            r = zs(),
            u = xi(!0, Ot.CONNECTOR_SETTING);
        let f;
        e[0] !== u.platformConnectors ? (f = u.platformConnectors.has(vo), e[0] = u.platformConnectors, e[1] = f) : f = e[1];
        const p = f,
            g = w.useRef(!1),
            h = Il(),
            y = c.hash.startsWith("#settings/Connectors/Advanced");
        let x;
        e[2] !== o ? (x = je(o, "2050949565"), e[2] = o, e[3] = x) : x = e[3];
        const j = x;
        let v, S;
        e[4] !== r || e[5] !== l || e[6] !== u.isLoading || e[7] !== o || e[8] !== p || e[9] !== j || e[10] !== d ? (v = () => {
            !l || l !== vo || !j || !r || !r.isFree() || u.isLoading || p || g.current || (g.current = !0, d(), $e(o, Vf))
        }, S = [r, l, u.isLoading, o, p, j, d], e[4] = r, e[5] = l, e[6] = u.isLoading, e[7] = o, e[8] = p, e[9] = j, e[10] = d, e[11] = v, e[12] = S) : (v = e[11], S = e[12]), w.useEffect(v, S);
        let C, M;
        e[13] !== o || e[14] !== i ? (C = () => {
            const _ = window.location.hash,
                D = _.indexOf("?");
            if (D === -1) return;
            const T = new URLSearchParams(_.substring(D + 1));
            if (T.has("github_onboarding")) {
                const F = T.get("github_onboarding");
                let O = Pn.ConfigureRepos;
                F && [Pn.ConfigureRepos, Pn.SyncRepos, Pn.IndexRepos].includes(F) && (O = F), $e(o, Wf, {
                    initialState: O
                }), T.delete("github_onboarding");
                const I = _.substring(0, D),
                    U = T.toString() ? "".concat(I, "?").concat(T.toString()) : I;
                i({
                    hash: U
                }, {
                    replace: !0
                })
            }
        }, M = [o, i], e[13] = o, e[14] = i, e[15] = C, e[16] = M) : (C = e[15], M = e[16]), w.useEffect(C, M);
        let E, N;
        if (e[17] !== l ? (E = () => {
                Rl.logEntryPointShown({
                    referrer: Ta.SettingsConnectorsTab
                }), l ? Ue.logEventWithStatsig("Connectors Details Settings Modal Shown", "chatgpt_connectors_details_settings_modal_shown", {
                    type: l
                }) : Ue.logEventWithStatsig("Connectors Settings Modal Shown", "chatgpt_connectors_settings_modal_shown")
            }, N = [l], e[17] = l, e[18] = E, e[19] = N) : (E = e[18], N = e[19]), w.useEffect(E, N), l) {
            let _;
            return e[20] !== l || e[21] !== a ? (_ = t.jsx(Hf, {
                connectorId: l,
                onAddClick: a
            }), e[20] = l, e[21] = a, e[22] = _) : _ = e[22], _
        }
        if (y) {
            let _;
            e[23] !== i ? (_ = () => i("#settings/Connectors", {
                replace: !0
            }), e[23] = i, e[24] = _) : _ = e[24];
            let D;
            return e[25] !== n || e[26] !== _ ? (D = t.jsx(cf, {
                onBack: _,
                onCreateCustomConnectorClick: n
            }), e[25] = n, e[26] = _, e[27] = D) : D = e[27], D
        }
        let k;
        e[28] !== a || e[29] !== n ? (k = t.jsx(Kg, {
            onCreateCustomConnectorClick: n,
            onAddClick: a
        }), e[28] = a, e[29] = n, e[30] = k) : k = e[30];
        let P;
        e[31] === Symbol.for("react.memo_cache_sentinel") ? (P = t.jsx(Og, {}), e[31] = P) : P = e[31];
        let L;
        e[32] !== h ? (L = h && t.jsx(Bl, {}), e[32] = h, e[33] = L) : L = e[33];
        let A;
        return e[34] !== L || e[35] !== k ? (A = t.jsxs(t.Fragment, {
            children: [k, P, L]
        }), e[34] = L, e[35] = k, e[36] = A) : A = e[36], A
    },
    Kf = () => {
        const {
            openSettings: s
        } = Fn();
        return t.jsx("button", {
            onClick: () => s(Ae.Account),
            children: t.jsx(Ya, {
                className: "icon-sm"
            })
        })
    };

function qf({
    gizmoId: s,
    gizmoName: e,
    gizmoAvatar: a,
    canEdit: n,
    socials: o
}) {
    const {
        data: i,
        isLoading: c
    } = Wa();
    return c ? null : i ? t.jsxs(t.Fragment, {
        children: [n && s && t.jsx("span", {
            className: "absolute end-2 top-2",
            children: t.jsx(Kf, {})
        }), t.jsx(ud, {
            src: a,
            isFirstParty: !1,
            className: "h-8 w-8"
        }), t.jsx("div", {
            className: "text-token-text-primary mt-1 text-center text-sm font-semibold",
            children: e
        }), t.jsx(gd, {
            builderName: i.display_name,
            builderUrl: i.website_url,
            socials: o,
            className: "text-xs"
        })]
    }) : t.jsx(hn, {
        type: "info",
        children: t.jsx(m, {
            id: "gizmo.builderProfile.unableToLoadProfile",
            defaultMessage: "Unable to load your builder profile"
        })
    })
}

function Yf() {
    const s = K(),
        {
            data: e,
            isLoading: a
        } = Wa(),
        n = ve(),
        o = ga(n);
    return t.jsx(Ne, {
        title: s.formatMessage(wt.gizmoTab),
        children: a ? t.jsx("div", {
            className: "flex justify-center p-6",
            children: t.jsx(ys, {})
        }) : e === void 0 || o == null ? t.jsx(hn, {
            type: "info",
            children: t.jsx(m, b({}, wt.noCreatorProfile))
        }) : t.jsx(Xf, {
            data: e
        })
    })
}

function Qf({
    gizmoName: s,
    canEdit: e,
    gizmoAvatar: a
}) {
    const n = K(),
        {
            openSettings: o
        } = Fn(),
        {
            data: i
        } = Wa();
    return i ? t.jsxs("div", {
        className: "bg-token-main-surface-primary relative flex w-full flex-col items-center justify-stretch rounded-lg p-4",
        children: [t.jsx(qf, {
            gizmoAvatar: a,
            gizmoName: s != null ? s : n.formatMessage(wt.placeholderGPT),
            canEdit: e,
            socials: [i.socials.linkedin, i.socials.github]
        }), t.jsx("div", {
            className: "text-token-text-tertiary absolute end-4 top-3 text-xs",
            children: e ? t.jsx("button", {
                onClick: () => {
                    o(Ae.Account)
                },
                children: t.jsx(Ya, {
                    className: "icon-sm"
                })
            }) : t.jsx(m, b({}, wt.preview))
        })]
    }) : null
}

function Zf(s, e) {
    if (s.website_url && e.length > 0) {
        const a = e.find(n => n.url === s.website_url);
        return a ? a.hostname : e[0].hostname
    } else {
        if (e.length > 0) return e[0].hostname;
        if (s.website_url) return
    }
}

function Xf({
    data: s
}) {
    const e = K(),
        a = Ol(),
        n = ve(),
        o = ga(n),
        i = o == null ? void 0 : o.isEnterprisey(),
        c = o == null ? void 0 : o.isWorkspaceAccount(),
        l = Us(),
        d = s.domains.reduce((g, h) => h.status === "verified" ? [...g, {
            id: h.id,
            hostname: h.hostname,
            url: h.hostname
        }] : g, []),
        r = Zf(s, d),
        u = je(n, "2256850471"),
        f = s.name == null || a.isPending,
        p = t.jsx(Fl, {
            size: "small",
            onCheckedChange: g => {
                a.mutateAsync({
                    hideName: !g
                })
            },
            disabled: f,
            checked: !s.hide_name,
            "aria-label": s.hide_name ? e.formatMessage(wt.showNameToggle) : e.formatMessage(wt.hideNameToggle)
        });
    return t.jsxs("div", {
        className: "flex flex-col items-stretch pt-3",
        children: [t.jsx("div", {
            className: "mb-2",
            children: t.jsx(m, b({}, wt.creatorProfileDescription))
        }), t.jsx(Qf, {
            canEdit: !1
        }), t.jsx(Q, {
            children: t.jsxs("div", {
                className: "flex flex-col",
                children: [!s.is_verified && t.jsxs(hn, {
                    type: "info",
                    children: [t.jsx("div", {
                        children: t.jsx(m, b({}, wt.creatorProfileUnverifiedDisclaimer))
                    }), t.jsx("div", {
                        children: c ? t.jsx(m, b({}, wt.creatorProfileBusinessUnverifiedDisclaimer)) : t.jsx(m, b({}, wt.creatorProfilePersonalUnverifiedDisclaimer))
                    })]
                }), s.name && t.jsxs("div", {
                    className: "mt-4 flex flex-col gap-2",
                    children: [t.jsxs("div", {
                        className: "flex flex-row justify-between",
                        children: [t.jsx("b", {
                            children: t.jsx(m, b({}, wt.creatorProfileNameLabel))
                        }), f ? t.jsx(Wt, {
                            side: "left",
                            label: e.formatMessage(wt.linkDisabledTooltip),
                            children: p
                        }) : p]
                    }), t.jsxs("div", {
                        className: "flex flex-row items-center space-x-2",
                        children: [t.jsx("span", {
                            children: s.name
                        }), t.jsx(Wt, {
                            side: "top",
                            className: "ms-auto",
                            label: e.formatMessage(wt.nameSourceReason),
                            children: t.jsx(Ha, {
                                className: "icon-sm text-token-text-tertiary"
                            })
                        })]
                    })]
                }), !i && t.jsxs("div", {
                    className: "flex flex-col justify-center gap-2",
                    children: [t.jsx("hr", {
                        className: "border-token-border-default my-3"
                    }), t.jsx("div", {
                        className: "flex flex-row justify-between",
                        children: t.jsx("b", {
                            children: t.jsx(m, b({}, wt.creatorProfileLinkHeader))
                        })
                    }), t.jsxs("div", {
                        className: "flex flex-row items-center justify-between space-x-2",
                        children: [t.jsx(fd, {
                            className: "icon-sm"
                        }), t.jsx("div", {
                            children: t.jsx(md, {
                                selectedDomain: r,
                                domains: s.domains,
                                verifiedDomains: d,
                                onChangeDomain: g => {
                                    a.mutateAsync({
                                        websiteUrl: g
                                    })
                                }
                            })
                        })]
                    }), u && t.jsxs(t.Fragment, {
                        children: [t.jsx(Lo, {
                            socialData: s.socials.linkedin,
                            icon: pd
                        }), t.jsx(Lo, {
                            socialData: s.socials.github,
                            icon: hd
                        })]
                    })]
                }), !i && l && l.email && t.jsxs("div", {
                    className: "flex flex-col justify-center gap-2",
                    children: [t.jsx("hr", {
                        className: "border-token-border-default my-3"
                    }), t.jsx("div", {
                        className: "flex flex-row justify-between",
                        children: t.jsx("b", {
                            children: t.jsx(m, b({}, wt.creatorProfileEmailHeader))
                        })
                    }), t.jsxs("div", {
                        className: "my-1 flex flex-row items-center space-x-2",
                        children: [t.jsx(Au, {
                            className: "icon-sm"
                        }), t.jsx("span", {
                            children: l.email
                        })]
                    }), t.jsx(Wt, {
                        label: e.formatMessage(wt.feedbackEmailTooltip),
                        children: t.jsx(Ui, {
                            className: "rounded-xl",
                            id: "receive-support-emails",
                            onChange: g => {
                                a.mutateAsync({
                                    willReceiveSupportEmails: g.currentTarget.checked
                                })
                            },
                            checked: s.will_receive_support_emails,
                            label: e.formatMessage(wt.receiveFeedbackEmails)
                        })
                    })]
                })]
            })
        })]
    })
}
const wt = Ke({
    gizmoTab: {
        id: "settingsModal.gizmoTab",
        defaultMessage: "GPT builder profile"
    },
    creatorProfileDescription: {
        id: "settingsModal.creatorProfileDescription",
        defaultMessage: "Personalize your builder profile to connect with users of your GPTs. These settings apply to publicly shared GPTs."
    },
    creatorProfileUnverifiedDisclaimer: {
        id: "settingsModal.createrProfileUnverifiedDisclaimer",
        defaultMessage: "Complete verification to publish GPTs to everyone."
    },
    creatorProfilePersonalUnverifiedDisclaimer: {
        id: "settingsModal.creatorProfilePersonalUnverifiedDisclaimer",
        defaultMessage: "Verify your identity by adding billing details or verifying ownership of a public domain name."
    },
    creatorProfileBusinessUnverifiedDisclaimer: {
        id: "settingsModal.creatorProfileBusinessUnverifiedDisclaimer",
        defaultMessage: "Contact your workspace administrator to set up a builder profile"
    },
    creatorProfileNameLabel: {
        id: "settingsModal.creatorProfileNameLabel",
        defaultMessage: "Name"
    },
    placeholderGPT: {
        id: "settingsModal.placeholderGPT",
        defaultMessage: "PlaceholderGPT"
    },
    byName: {
        id: "settingsModal.byName",
        defaultMessage: "by {name}"
    },
    preview: {
        id: "settingsModal.preview",
        defaultMessage: "Preview"
    },
    noCreatorProfile: {
        id: "settingsModal.noCreatorProfile",
        defaultMessage: "Unable to retrieve builder profile"
    },
    creatorProfileLinkHeader: {
        id: "settingsModal.creatorProfileLinkHeader.1",
        defaultMessage: "Links"
    },
    creatorProfileEmailHeader: {
        id: "settingsModal.creatorProfileEmailHeader.0",
        defaultMessage: "Email"
    },
    nameDisabledTooltip: {
        id: "settingsModal.nameDisabledTooltip",
        defaultMessage: "You must have a verified name to enable displaying a name"
    },
    linkDisabledTooltip: {
        id: "settingsModal.linkDisabledTooltip",
        defaultMessage: "You must have a verified domain to enable displaying a link"
    },
    addDomain: {
        id: "settingsModal.addDomain",
        defaultMessage: "Verify new domain"
    },
    nameSourceReason: {
        id: "settingsModal.nameSourceReason",
        defaultMessage: "Name is populated from your billing details"
    },
    hideNameToggle: {
        id: "settingsModal.hideNameToggle",
        defaultMessage: "Hide your name in your builder profile"
    },
    showNameToggle: {
        id: "settingsModal.showNameToggle",
        defaultMessage: "Show your name in your builder profile"
    },
    hideWebsiteToggle: {
        id: "settingsModal.hideWebsiteToggle",
        defaultMessage: "Hide your website in your builder profile"
    },
    showWebsiteToggle: {
        id: "settingsModal.showWebsiteToggle",
        defaultMessage: "Show your website in your builder profile"
    },
    feedbackEmailTooltip: {
        id: "settingsModal.feedbackEmailTooltip",
        defaultMessage: "Allow users of your GPTs to send feedback to your ChatGPT login email. Your email will never be shared publicly."
    },
    receiveFeedbackEmails: {
        id: "settingsModal.receiveFeedbackEmails.1",
        defaultMessage: "Receive feedback emails"
    }
});
let ja = 0;
var ri;
const Jf = Ul(De.CheckboxItem)(ri || (ri = po(["flex flex-row justify-between h-10 mx-2 items-center"])));

function em(s, e, a, n) {
    const o = {
        category: s.category,
        [a]: e
    };
    n(o)
}

function tm() {
    const s = K(),
        a = _t().getQueryData([ta]),
        [n, o] = w.useState(a),
        i = om(o);
    return xd({
        onSuccess: c => {
            o(c)
        },
        alwaysRefetchOnMount: !0
    }), t.jsx(Ne, {
        title: s.formatMessage({
            id: "settingsModal.notifications",
            defaultMessage: "Notifications"
        }),
        children: n ? n.map(c => t.jsx(Q, {
            children: t.jsx(sm, {
                settings: c,
                updateSettings: i.mutate
            })
        }, c.category)) : t.jsx("div", {
            className: "flex justify-center p-6",
            children: t.jsx(ys, {})
        })
    })
}

function sm({
    settings: s,
    updateSettings: e
}) {
    const a = K(),
        n = Us(),
        i = s.category === "teen_safety" ? am(s.options, !!(n != null && n.email), !!(n != null && n.phone_number)) : s.options;
    return t.jsxs(t.Fragment, {
        children: [t.jsxs("div", {
            className: "flex items-center justify-between",
            children: [t.jsx("span", {
                children: s.name
            }), t.jsxs(De.Root, {
                children: [t.jsxs(De.Trigger, {
                    children: [t.jsx("div", {
                        children: nm(i, a)
                    }), t.jsx(yd, {
                        className: "icon-sm"
                    })]
                }), t.jsx(De.Portal, {
                    children: t.jsx(De.Content, {
                        size: "small",
                        align: "end",
                        children: i.map((c, l) => t.jsx(Jf, {
                            checked: c.enabled,
                            onCheckedChange: d => em(s, d, c.channel, e),
                            children: c.name
                        }, l))
                    })
                })]
            })]
        }), t.jsxs(yn, {
            children: [s.description, s.category === "tasks" && t.jsxs(t.Fragment, {
                children: [t.jsx("br", {}), t.jsx(Rn, {
                    className: "underline",
                    to: "/tasks",
                    children: t.jsx(m, {
                        id: "notificationSettings.manageTasks",
                        defaultMessage: "Manage tasks"
                    })
                })]
            })]
        })]
    })
}

function nm(s, e) {
    const a = s.some(i => i.channel === "email" && i.enabled),
        n = s.some(i => i.channel === "sms" && i.enabled),
        o = s.some(i => i.channel === "push" && i.enabled);
    return o && a && n || o && a ? e.formatMessage(Qs.pushAndEmailEnabled) : o && n ? e.formatMessage(Qs.pushAndSmsEnabled) : a && n ? e.formatMessage(Qs.emailAndSmsEnabled) : n ? e.formatMessage(Qs.smsEnabled) : o ? e.formatMessage(Qs.pushEnabled) : a ? e.formatMessage(Qs.emailEnabled) : e.formatMessage(Qs.notificationsOff)
}

function am(s, e, a) {
    return s.filter(n => n.channel === "email" ? e : n.channel === "sms" ? a : !0)
}

function om(s) {
    const e = _t();
    return pt({
        mutationFn: async a => (await bd.updateSettings(a)).settings,
        onMutate: async a => {
            ja += 1;
            const n = ja;
            await e.cancelQueries({
                queryKey: ta
            });
            const o = e.getQueryData(ta);
            return s(i => {
                if (!i) return i;
                const d = a,
                    {
                        category: c
                    } = d,
                    l = Wn(d, ["category"]);
                return i.map(r => {
                    if (r.category !== c) return r;
                    const u = r.options.map(f => {
                        const p = l[f.channel];
                        return typeof p == "boolean" ? Ee(b({}, f), {
                            enabled: p
                        }) : f
                    });
                    return Ee(b({}, r), {
                        options: u
                    })
                })
            }), {
                previousSettingsList: o,
                mutationId: n
            }
        },
        onError: (a, n, o) => {
            o != null && o.previousSettingsList && s(o.previousSettingsList)
        },
        onSuccess: (a, n, o) => {
            (o == null ? void 0 : o.mutationId) === ja && (e.setQueryData(ta, a), s(a))
        }
    })
}
const Qs = Ke({
    pushEnabled: {
        id: "notificationSettings.pushEnabled",
        defaultMessage: "Push"
    },
    emailEnabled: {
        id: "notificationSettings.emailEnabled",
        defaultMessage: "Email"
    },
    smsEnabled: {
        id: "notificationSettings.smsEnabled",
        defaultMessage: "SMS"
    },
    pushAndEmailEnabled: {
        id: "notificationSettings.pushAndEmailEnabled",
        defaultMessage: "Push, Email"
    },
    pushAndSmsEnabled: {
        id: "notificationSettings.pushAndSmsEnabled",
        defaultMessage: "Push, SMS"
    },
    emailAndSmsEnabled: {
        id: "notificationSettings.emailAndSmsEnabled",
        defaultMessage: "Email, SMS"
    },
    pushAndEmailAndSmsEnabled: {
        id: "notificationSettings.pushAndEmailAndSmsEnabled",
        defaultMessage: "Push, Email, SMS"
    },
    notificationsOff: {
        id: "notificationSettings.notificationsOff",
        defaultMessage: "Off"
    }
});

function im() {
    const s = K();
    return t.jsx(hs, {
        value: Ae.Notifications,
        icon: Md,
        label: s.formatMessage({
            id: "settingsModal.notifications",
            defaultMessage: "Notifications"
        })
    })
}

function rm(s) {
    "use forget";
    const e = Se.c(10),
        {
            currentAccount: a
        } = s,
        n = bs(),
        o = a.data.subscriptionStatus.planType;
    let i;
    e[0] !== a ? (i = a.willRenewSubscription(), e[0] = a, e[1] = i) : i = e[1];
    const c = i;
    let l;
    e[2] !== o || e[3] !== c ? (l = o === vt.PLUS ? t.jsx(m, {
        id: "hLd2Ar",
        defaultMessage: "Upgrade plan"
    }) : o === vt.PRO && c ? t.jsx(m, {
        id: "/4GuNx",
        defaultMessage: "Change plan"
    }) : t.jsx(m, {
        id: "4Bc5M+",
        defaultMessage: "View plans"
    }), e[2] = o, e[3] = c, e[4] = l) : l = e[4];
    const d = l;
    let r;
    e[5] !== n ? (r = () => {
        Ue.logEventWithStatsig("Subscription Settings Change Plan Button Clicked", "chatgpt_subscription_settings_change_plan_button_clicked"), Qa(n, "Subscription settings manage button")
    }, e[5] = n, e[6] = r) : r = e[6];
    const u = r;
    let f;
    return e[7] !== u || e[8] !== d ? (f = t.jsx(De.Item, {
        icon: Nd,
        onClick: u,
        children: d
    }), e[7] = u, e[8] = d, e[9] = f) : f = e[9], f
}

function lm(s) {
    "use forget";
    const e = Se.c(9),
        {
            currentAccount: a,
            onCancelSubscriptionClick: n
        } = s,
        o = ve(),
        i = a.willRenewSubscription(),
        c = a.getDaysUntilSubscriptionCancelAt(),
        l = a.willPlanChange(),
        d = Pi(o, "468168202"),
        r = K(),
        u = Ct();
    if (!i || c != null || l) return null;
    const f = d.get("should_cancel_button_take_user_to_stripe", !1);
    let p;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (p = t.jsx(De.Separator, {}), e[0] = p) : p = e[0];
    let g;
    e[1] !== r || e[2] !== n || e[3] !== f || e[4] !== u ? (g = async () => {
        if (Ue.logEventWithStatsig("Subscription Settings Cancel Subscription Button Clicked", "chatgpt_subscription_settings_cancel_subscription_button_clicked"), f) try {
            const x = await tt.safeGet("/payments/customer_portal");
            location.href = x.url
        } catch (x) {
            u.warning(r.formatMessage(at.accountErrorWarning), {
                hasCloseButton: !0
            })
        } else n()
    }, e[1] = r, e[2] = n, e[3] = f, e[4] = u, e[5] = g) : g = e[5];
    let h;
    e[6] === Symbol.for("react.memo_cache_sentinel") ? (h = t.jsx(m, {
        id: "icBiUI",
        defaultMessage: "Cancel Subscription"
    }), e[6] = h) : h = e[6];
    let y;
    return e[7] !== g ? (y = t.jsxs(t.Fragment, {
        children: [p, t.jsx(De.Item, {
            color: "danger",
            icon: Wl,
            onClick: g,
            children: h
        })]
    }), e[7] = g, e[8] = y) : y = e[8], y
}

function cm(s, e) {
    return s === vt.FREE || s === vt.PLUS && e === vt.PRO || s === vt.GO && [vt.PRO, vt.PLUS].includes(e)
}

function dm(s) {
    "use forget";
    const e = Se.c(9),
        {
            currentAccount: a,
            onRenewSubscriptionClick: n
        } = s,
        o = a.data.subscriptionStatus.planType;
    let i;
    e[0] !== o ? (i = Aa(o.toLowerCase()), e[0] = o, e[1] = i) : i = e[1];
    const c = i,
        l = a.willRenewSubscription(),
        d = a.getDaysUntilSubscriptionCancelAt(),
        r = a.getNextPlanType();
    if (!(!l || d != null || r && cm(r, o))) return null;
    let f;
    e[2] !== n ? (f = () => {
        Ue.logEventWithStatsig("Subscription Settings Renew Plan Button Clicked", "chatgpt_subscription_settings_renew_plan_button_clicked"), n()
    }, e[2] = n, e[3] = f) : f = e[3];
    const p = f;
    let g;
    e[4] !== c ? (g = t.jsx(m, {
        id: "L6UCRY",
        defaultMessage: "Renew {planName} Plan",
        values: {
            planName: c
        }
    }), e[4] = c, e[5] = g) : g = e[5];
    let h;
    return e[6] !== p || e[7] !== g ? (h = t.jsx(De.Item, {
        icon: Td,
        onClick: p,
        children: g
    }), e[6] = p, e[7] = g, e[8] = h) : h = e[8], h
}

function um(s) {
    "use forget";
    const e = Se.c(13),
        {
            currentAccount: a,
            onCancelSubscriptionClick: n,
            onRenewSubscriptionClick: o
        } = s;
    let i;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (i = t.jsx(De.BasicTrigger, {
        asChild: !0,
        children: t.jsxs(ne, {
            color: "secondary",
            children: [t.jsx(m, {
                id: "g3k4Zt",
                defaultMessage: "Manage"
            }), t.jsx(Hi, {
                className: "ms-1 -me-1 h-4 w-4"
            })]
        })
    }), e[0] = i) : i = e[0];
    let c;
    e[1] !== a ? (c = t.jsx(rm, {
        currentAccount: a
    }), e[1] = a, e[2] = c) : c = e[2];
    let l;
    e[3] !== a || e[4] !== o ? (l = t.jsx(dm, {
        currentAccount: a,
        onRenewSubscriptionClick: o
    }), e[3] = a, e[4] = o, e[5] = l) : l = e[5];
    let d;
    e[6] !== a || e[7] !== n ? (d = t.jsx(lm, {
        currentAccount: a,
        onCancelSubscriptionClick: n
    }), e[6] = a, e[7] = n, e[8] = d) : d = e[8];
    let r;
    return e[9] !== c || e[10] !== l || e[11] !== d ? (r = t.jsxs(De.Root, {
        children: [i, t.jsx(De.Portal, {
            children: t.jsxs(De.Content, {
                align: "end",
                size: "auto",
                sideOffset: 2,
                children: [c, l, d]
            })
        })]
    }), e[9] = c, e[10] = l, e[11] = d, e[12] = r) : r = e[12], r
}

function xr({
    currentAccount: s
}) {
    const e = s.subscriptionAnalyticsParams,
        a = s.getLastActiveSubscription(),
        n = a == null ? void 0 : a.purchase_origin_platform,
        o = Ct(),
        i = K(),
        c = async () => {
            var d;
            Ue.logEvent("Account Portal: Click Manage My Subscription", e);
            try {
                const r = await tt.safeGet("/payments/customer_portal");
                Ue.logEvent("Account Portal: Navigating to Account Portal", e), location.href = r.url
            } catch (r) {
                const u = (d = Hl(r)) != null ? d : i.formatMessage(at.accountErrorWarning);
                o.warning(u, {
                    hasCloseButton: !0
                })
            }
        },
        l = (d, r) => t.jsx(Rn, {
            to: d,
            target: "_blank",
            className: "inline-block",
            children: t.jsx(ne, {
                onClick: () => Ue.logEvent(r, e),
                color: "secondary",
                children: t.jsx(m, {
                    id: "eQL80k",
                    defaultMessage: "Manage"
                })
            })
        });
    switch (n) {
        case ba.CHATGPT_IOS:
        case ba.SORA_IOS:
            return l(Ed, "Account Portal: Click iOS Manage Subscription");
        case ba.MOBILE_ANDROID:
            return l(kd, "Account Portal: Click Android Manage Subscription");
        default:
            return t.jsx(ne, {
                onClick: c,
                color: "secondary",
                children: t.jsx(m, {
                    id: "eQL80k",
                    defaultMessage: "Manage"
                })
            })
    }
}

function Xo(s, e) {
    return s == null || e == null ? !1 : Math.abs(s - e) <= 1
}

function br(s) {
    "use forget";
    const e = Se.c(29),
        {
            title: a,
            subtitle: n,
            features: o,
            ctaButton: i,
            planChangeMessage: c,
            planCanceledMessage: l,
            scheduledCancelMessage: d,
            discountMessage: r,
            renewMessage: u,
            manageButton: f,
            paymentSection: p
        } = s;
    let g;
    e[0] !== a ? (g = t.jsx("div", {
        className: "",
        children: a
    }), e[0] = a, e[1] = g) : g = e[1];
    let h;
    e[2] !== r || e[3] !== l || e[4] !== c || e[5] !== u ? (h = t.jsxs("div", {
        className: "text-token-text-secondary",
        children: [c, r, u, l]
    }), e[2] = r, e[3] = l, e[4] = c, e[5] = u, e[6] = h) : h = e[6];
    let y;
    e[7] !== g || e[8] !== h ? (y = t.jsxs("div", {
        children: [g, h]
    }), e[7] = g, e[8] = h, e[9] = y) : y = e[9];
    const x = i || f;
    let j;
    e[10] !== y || e[11] !== x ? (j = t.jsxs("div", {
        className: "flex items-center justify-between",
        children: [y, x]
    }), e[10] = y, e[11] = x, e[12] = j) : j = e[12];
    let v;
    e[13] !== d ? (v = d && t.jsx("div", {
        className: "mt-3 rounded-md border border-yellow-200 bg-yellow-50 px-3 py-2 text-sm text-yellow-800 dark:border-yellow-800 dark:bg-yellow-950 dark:text-yellow-200",
        children: d
    }), e[13] = d, e[14] = v) : v = e[14];
    let S;
    e[15] !== n ? (S = t.jsx("span", {
        className: "inline-block pb-4 text-sm font-semibold",
        children: n
    }), e[15] = n, e[16] = S) : S = e[16];
    let C;
    e[17] !== o ? (C = t.jsx(Ru, {
        advertisedFeatures: o
    }), e[17] = o, e[18] = C) : C = e[18];
    let M;
    e[19] !== S || e[20] !== C ? (M = t.jsxs("div", {
        className: "mt-2 rounded-lg bg-transparent p-4 px-0 dark:bg-transparent",
        children: [S, C]
    }), e[19] = S, e[20] = C, e[21] = M) : M = e[21];
    let E;
    e[22] !== j || e[23] !== v || e[24] !== M ? (E = t.jsxs(Q, {
        children: [j, v, M]
    }), e[22] = j, e[23] = v, e[24] = M, e[25] = E) : E = e[25];
    let N;
    return e[26] !== p || e[27] !== E ? (N = t.jsxs(t.Fragment, {
        children: [E, p]
    }), e[26] = p, e[27] = E, e[28] = N) : N = e[28], N
}

function gm(s) {
    "use forget";
    const e = Se.c(42),
        {
            currentAccount: a
        } = s;
    let n;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (n = [], e[0] = n) : n = e[0], w.useEffect(fm, n);
    const o = ve();
    let i;
    e[1] !== o ? (i = sr({
        ctx: o
    }), e[1] = o, e[2] = i) : i = e[2];
    const c = i;
    let l;
    e[3] !== o ? (l = nr({
        ctx: o
    }), e[3] = o, e[4] = l) : l = e[4];
    const d = l,
        r = Sd(),
        u = _d(),
        f = bs();
    let p;
    e[5] !== o ? (p = wd(o), e[5] = o, e[6] = p) : p = e[6];
    const g = p;
    let h;
    e[7] !== c || e[8] !== g || e[9] !== r || e[10] !== u || e[11] !== d ? (h = g ? {
        planName: "Go",
        advertisedFeatures: c.advertisedFeatures,
        isTrialEligible: r
    } : {
        planName: "Plus",
        advertisedFeatures: d.advertisedFeatures,
        isTrialEligible: u
    }, e[7] = c, e[8] = g, e[9] = r, e[10] = u, e[11] = d, e[12] = h) : h = e[12];
    const y = h,
        {
            planName: x,
            advertisedFeatures: j,
            isTrialEligible: v
        } = y,
        S = v ? at.upgradeFromFreeTrialTitle : at.upgradeFromFreeTitle,
        C = v ? at.upgradeTrialButton : at.upgradeButton;
    let M;
    e[13] !== x ? (M = t.jsx(m, Ee(b({}, at.managePaymentTitle), {
        values: {
            planName: x
        }
    })), e[13] = x, e[14] = M) : M = e[14];
    let E;
    e[15] === Symbol.for("react.memo_cache_sentinel") ? (E = t.jsx(Rn, {
        target: "_blank",
        to: zi,
        onClick: tr,
        className: "text-token-link text-xs",
        children: t.jsx(m, b({}, at.billingHelp))
    }, "row-plus-plan-help-link"), e[15] = E) : E = e[15];
    let N;
    e[16] !== M ? (N = t.jsxs("div", {
        className: "flex flex-col gap-1",
        children: [M, E]
    }), e[16] = M, e[17] = N) : N = e[17];
    let k;
    e[18] !== a ? (k = t.jsx(xr, {
        currentAccount: a
    }), e[18] = a, e[19] = k) : k = e[19];
    let P;
    e[20] !== N || e[21] !== k ? (P = t.jsx(Q, {
        children: t.jsxs("div", {
            className: "flex items-center justify-between gap-2",
            children: [N, k]
        })
    }), e[20] = N, e[21] = k, e[22] = P) : P = e[22];
    const L = P;
    let A;
    e[23] !== x ? (A = {
        planName: x
    }, e[23] = x, e[24] = A) : A = e[24];
    let _;
    e[25] !== A || e[26] !== S ? (_ = t.jsx(m, Ee(b({}, S), {
        values: A
    })), e[25] = A, e[26] = S, e[27] = _) : _ = e[27];
    let D;
    e[28] === Symbol.for("react.memo_cache_sentinel") ? (D = t.jsx(m, b({}, at.upgradeFromFreeDescription)), e[28] = D) : D = e[28];
    let T;
    e[29] !== f || e[30] !== x ? (T = () => {
        Ue.logEventWithStatsig("Subscription Settings Free to Paid Upgrade Button Clicked", "chatgpt_subscription_settings_free_to_paid_upgrade_button_clicked"), Qa(f, "Subscription settings manage button Free to ".concat(x))
    }, e[29] = f, e[30] = x, e[31] = T) : T = e[31];
    let F;
    e[32] !== C ? (F = t.jsx(m, b({}, C)), e[32] = C, e[33] = F) : F = e[33];
    let O;
    e[34] !== T || e[35] !== F ? (O = t.jsx(ne, {
        onClick: T,
        color: "primary",
        children: F
    }), e[34] = T, e[35] = F, e[36] = O) : O = e[36];
    let I;
    return e[37] !== j || e[38] !== L || e[39] !== _ || e[40] !== O ? (I = t.jsx(br, {
        title: _,
        subtitle: D,
        features: j,
        ctaButton: O,
        paymentSection: L
    }), e[37] = j, e[38] = L, e[39] = _, e[40] = O, e[41] = I) : I = e[41], I
}

function fm() {
    Ue.logEventWithStatsig("Subscription Settings Shown: Free", "chatgpt_subscription_settings_shown_free")
}

function Sa(s) {
    "use forget";
    var ze, Le, Me, me, xe, Ce, He, Be, G, se, pe;
    const e = Se.c(39);
    let {
        currentAccount: a,
        onCancelSubscriptionClick: n,
        onRenewSubscriptionClick: o,
        pricingPlan: i
    } = s, c;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (c = [], e[0] = c) : c = e[0], w.useEffect(mm, c);
    const l = (ze = a.data.subscriptionStatus.billingCurrency) != null ? ze : "USD",
        d = K(),
        r = ve();
    let u;
    e[1] !== r || e[2] !== l ? (u = {
        currency: l,
        ctx: r
    }, e[1] = r, e[2] = l, e[3] = u) : u = e[3];
    const {
        data: f,
        isLoading: p
    } = vd(u), g = a.planType;
    let h;
    e[4] !== a ? (h = a.willRenewSubscription(), e[4] = a, e[5] = h) : h = e[5];
    const y = h;
    let x;
    e[6] !== a ? (x = a.willPlanChange(), e[6] = a, e[7] = x) : x = e[7];
    const j = x,
        v = a.getDaysUntilSubscriptionCancelAt(),
        S = a.getDaysUntilPlanChanges(),
        C = a.getDaysUntilPlanRenews(),
        M = a.getDaysUntilPlanDiscountExpires(),
        E = a.getNextPlanType(),
        N = a.data.subscriptionStatus.discount,
        k = (Me = (Le = a.data.subscriptionStatus.discount) == null ? void 0 : Le.discount_start_in_num_periods) != null ? Me : 0,
        P = Aa(g.toLowerCase()),
        L = E ? Aa(E.toLowerCase()) : null;
    if (!p && f) {
        const fe = Cd(f, Ro(g), g === vt.SELF_SERVE_BUSINESS ? Io.Year : Io.Month);
        i = Ee(b({}, i), {
            cost: {
                costValue: fe.amount,
                costTitle: jd(fe.amount, Ro(g), l)
            }
        })
    }
    const {
        advertisedFeatures: A
    } = i, {
        costTitle: _,
        currencySymbol: D
    } = Du(i, l), T = f && N ? Lu(d, 1, N.discount_type === xa.PERCENTAGE ? {
        percentage: N.amount
    } : {
        value: N.amount,
        currency_code: l
    }, l, f, g).formattedDiscountedCost : null, F = j && S && L ? t.jsx("span", {
        children: t.jsx(m, Ee(b({}, at.planChangeMessage), {
            values: {
                planName: L,
                date: ps(S, d)
            }
        }))
    }) : null, O = () => Gl(r, "4136204731").get("show_richer_discount_message", !1), I = y && !j && N && k > 0 ? ((me = a.data.subscriptionStatus.discount) == null ? void 0 : me.discount_type) === xa.PERCENTAGE ? t.jsx("span", {
        children: t.jsx(m, Ee(b({}, at.discountPercentFutureMessage), {
            values: {
                discountPercent: a.data.subscriptionStatus.discount.amount,
                planName: P,
                numPeriods: k
            }
        }))
    }) : D.sign.defaultMessage && t.jsx("span", {
        children: t.jsx(m, Ee(b({}, at.discountFixedFutureMessage), {
            values: {
                discountFixed: (xe = a.data.subscriptionStatus.discount) == null ? void 0 : xe.amount,
                planName: P,
                numPeriods: k,
                currencySymbol: D.sign.defaultMessage.toString()
            }
        }))
    }) : y && !j && C && N && (((Ce = a.data.subscriptionStatus.discount) == null ? void 0 : Ce.discount_type) === xa.PERCENTAGE ? Xo(M, C) && (_ != null && _.defaultMessage) && ((He = D == null ? void 0 : D.sign) != null && He.defaultMessage) ? t.jsx("span", {
        children: t.jsx(m, Ee(b({}, at.discountPercentMessageWithNewPrice), {
            values: {
                discountPercent: a.data.subscriptionStatus.discount.amount,
                planName: P,
                date: ps(C, d),
                newPrice: _.defaultMessage.toString(),
                currencySymbol: D.sign.defaultMessage.toString()
            }
        }))
    }) : t.jsx("span", {
        children: t.jsx(m, Ee(b({}, M != null && T && O() ? at.discountPercentMessageWithDiscountEndDateAndPrice : at.discountPercentMessage), {
            values: {
                discountPercent: a.data.subscriptionStatus.discount.amount,
                planName: P,
                date: ps(C, d),
                discountEndDate: M != null ? ps(M, d) : void 0,
                nextBillingCycleDiscountedFormattedCost: T
            }
        }))
    }) : Xo(M, C) && (_ != null && _.defaultMessage) && ((Be = D == null ? void 0 : D.sign) != null && Be.defaultMessage) ? t.jsx("span", {
        children: t.jsx(m, Ee(b({}, at.discountFixedMessageWithNewPrice), {
            values: {
                discountFixed: (G = a.data.subscriptionStatus.discount) == null ? void 0 : G.amount,
                planName: P,
                date: ps(C, d),
                newPrice: _.defaultMessage.toString(),
                currencySymbol: D.sign.defaultMessage.toString()
            }
        }))
    }) : ((se = D == null ? void 0 : D.sign) == null ? void 0 : se.defaultMessage) && t.jsx("span", {
        children: t.jsx(m, Ee(b({}, M != null && T && O() ? at.discountFixedMessageWithDiscountEndDateAndPrice : at.discountFixedMessage), {
            values: {
                discountFixed: (pe = a.data.subscriptionStatus.discount) == null ? void 0 : pe.amount,
                planName: P,
                date: ps(C, d),
                currencySymbol: D.sign.defaultMessage.toString(),
                discountEndDate: M != null ? ps(M, d) : void 0,
                nextBillingCycleDiscountedFormattedCost: T
            }
        }))
    })), U = y && !j && C && !N ? t.jsx("span", {
        children: t.jsx(m, Ee(b({}, at.renewMessage), {
            values: {
                date: ps(C, d)
            }
        }))
    }) : null, R = !y && !j && C ? t.jsx("span", {
        children: t.jsx(m, Ee(b({}, at.planCanceledMessage), {
            values: {
                date: ps(C, d)
            }
        }))
    }) : null, B = v && v !== C ? t.jsx("span", {
        children: t.jsx(m, Ee(b({}, at.scheduledCancelMessage), {
            values: {
                date: ps(v, d)
            }
        }))
    }) : null;
    let z;
    e[8] !== P ? (z = t.jsx(m, Ee(b({}, at.managePaymentTitle), {
        values: {
            planName: P
        }
    })), e[8] = P, e[9] = z) : z = e[9];
    let W;
    e[10] === Symbol.for("react.memo_cache_sentinel") ? (W = t.jsx(Rn, {
        target: "_blank",
        to: zi,
        onClick: tr,
        className: "text-token-link text-xs",
        children: t.jsx(m, b({}, at.billingHelp))
    }, "row-plus-plan-help-link"), e[10] = W) : W = e[10];
    let V;
    e[11] !== z ? (V = t.jsxs("div", {
        className: "flex flex-col gap-1",
        children: [z, W]
    }), e[11] = z, e[12] = V) : V = e[12];
    let J;
    e[13] !== a ? (J = t.jsx(xr, {
        currentAccount: a
    }), e[13] = a, e[14] = J) : J = e[14];
    let ce;
    e[15] !== V || e[16] !== J ? (ce = t.jsx(Q, {
        children: t.jsxs("div", {
            className: "flex items-center justify-between gap-2",
            children: [V, J]
        })
    }), e[15] = V, e[16] = J, e[17] = ce) : ce = e[17];
    const ae = ce;
    let Z;
    e[18] !== P ? (Z = t.jsx(m, Ee(b({}, at.subscriptionTitle), {
        values: {
            planName: P
        }
    })), e[18] = P, e[19] = Z) : Z = e[19];
    let $;
    e[20] !== P ? ($ = t.jsx(m, Ee(b({}, at.thanksMessage), {
        values: {
            planName: P
        }
    })), e[20] = P, e[21] = $) : $ = e[21];
    let ee;
    e[22] !== A ? (ee = A != null ? A : [], e[22] = A, e[23] = ee) : ee = e[23];
    let de;
    e[24] !== a || e[25] !== n || e[26] !== o ? (de = t.jsx(um, {
        currentAccount: a,
        onCancelSubscriptionClick: n,
        onRenewSubscriptionClick: o
    }), e[24] = a, e[25] = n, e[26] = o, e[27] = de) : de = e[27];
    let ye;
    return e[28] !== I || e[29] !== ae || e[30] !== R || e[31] !== F || e[32] !== U || e[33] !== B || e[34] !== Z || e[35] !== $ || e[36] !== ee || e[37] !== de ? (ye = t.jsx(br, {
        title: Z,
        subtitle: $,
        features: ee,
        manageButton: de,
        planChangeMessage: F,
        discountMessage: I,
        renewMessage: U,
        planCanceledMessage: R,
        scheduledCancelMessage: B,
        paymentSection: ae
    }), e[28] = I, e[29] = ae, e[30] = R, e[31] = F, e[32] = U, e[33] = B, e[34] = Z, e[35] = $, e[36] = ee, e[37] = de, e[38] = ye) : ye = e[38], ye
}

function mm() {
    Ue.logEventWithStatsig("Subscription Settings Shown", "chatgpt_subscription_settings_shown")
}

function ps(s, e) {
    const a = zl(new Date, s);
    return new Intl.DateTimeFormat(e.locale, {
        year: "numeric",
        month: "short",
        day: "numeric"
    }).format(a)
}
const at = Ke({
    subscriptionTitle: {
        id: "settingsModal.subscriptionTitle",
        defaultMessage: "ChatGPT {planName}"
    },
    managePaymentTitle: {
        id: "settingsModal.managePaymentTitle",
        defaultMessage: "Payment"
    },
    billingHelp: {
        id: "settingsModal.billingHelp",
        defaultMessage: "Need help with billing?"
    },
    accountErrorWarning: {
        id: "settingsModal.accountErrorWarning",
        defaultMessage: "The account management page encountered an error. Please try again. If the problem continues, please visit help.openai.com."
    },
    planChangeMessage: {
        id: "settingsModal.planChangeMessage",
        defaultMessage: "Your plan changes to {planName} on {date}"
    },
    planCanceledMessage: {
        id: "settingsModal.planCanceledMessage",
        defaultMessage: "Your plan will be canceled on {date}"
    },
    scheduledCancelMessage: {
        id: "settingsModal.scheduledCancelMessage",
        defaultMessage: "Your paid plan will downgrade to ChatGPT free on {date}"
    },
    renewMessage: {
        id: "settingsModal.renewMessage",
        defaultMessage: "Your plan auto-renews on {date}"
    },
    discountPercentMessage: {
        id: "settingsModal.discountPercentMessage",
        defaultMessage: "You've got {discountPercent}% off {planName}. Your discounted plan renews on {date}."
    },
    discountPercentMessageWithDiscountEndDateAndPrice: {
        id: "settingsModal.discountPercentMessageWithDiscountEndDateAndPrice",
        defaultMessage: "You've got {discountPercent}% off {planName} until {discountEndDate}. Your discounted plan renews (at {nextBillingCycleDiscountedFormattedCost}/month) on {date}."
    },
    discountPercentMessageWithNewPrice: {
        id: "settingsModal.discountPercentMessageWithNewPrice",
        defaultMessage: "You've got {discountPercent}% off {planName}. Your plan renews (at {currencySymbol}{newPrice}/month) on {date}."
    },
    discountFixedMessage: {
        id: "settingsModal.discountFixedMessage",
        defaultMessage: "You've got {currencySymbol}{discountFixed} off {planName}. Your discounted plan renews on {date}."
    },
    discountFixedMessageWithNewPrice: {
        id: "settingsModal.discountFixedMessageWithNewPrice",
        defaultMessage: "You've got {currencySymbol}{discountFixed} off {planName}. Your plan renews (at {currencySymbol}{newPrice}/month) on {date}."
    },
    discountPercentFutureMessage: {
        id: "settingsModal.discountPercentFutureMessage",
        defaultMessage: "Your {discountPercent}% off {planName} discount will apply in {numPeriods, plural, one {the next billing period} other {# billing periods}}."
    },
    discountFixedMessageWithDiscountEndDateAndPrice: {
        id: "settingsModal.discountFixedMessageWithDiscountEndDateAndPrice",
        defaultMessage: "You've got {currencySymbol}{discountFixed} off {planName} until {discountEndDate}. Your discounted plan renews (at {nextBillingCycleDiscountedFormattedCost}/month) on {date}."
    },
    discountFixedFutureMessage: {
        id: "settingsModal.discountFixedFutureMessage",
        defaultMessage: "Your {currencySymbol}{discountFixed} off {planName} discount will apply in {numPeriods, plural, one {the next billing period} other {# billing periods}}."
    },
    thanksMessage: {
        id: "settingsModal.thanksMessage",
        defaultMessage: "Thanks for subscribing to ChatGPT {planName}! Your {planName} plan includes:"
    },
    paymentMethodMessage: {
        id: "settingsModal.paymentMethodMessage",
        defaultMessage: "Payment method"
    },
    upgradeFromFreeTitle: {
        id: "settingsModal.upgradeFromFreeTitle",
        defaultMessage: "Get ChatGPT {planName}"
    },
    upgradeFromFreeTrialTitle: {
        id: "settingsModal.upgradeFromFreeTrialTitle",
        defaultMessage: "Try ChatGPT {planName} for free"
    },
    upgradeFromFreeDescription: {
        id: "settingsModal.upgradeFromFreeDescription",
        defaultMessage: "Get everything in Free, and more."
    },
    upgradeButton: {
        id: "settingsModal.upgradeButton",
        defaultMessage: "Upgrade"
    },
    upgradeTrialButton: {
        id: "settingsModal.upgradeTrialButton",
        defaultMessage: "Start trial"
    }
});

function pm({
    enabled: s = !1
} = {}) {
    return Fs({
        queryKey: ["mfaPushAuthDevices"],
        queryFn: () => tt.safeGet("/accounts/mfa_push_auth_devices"),
        enabled: s
    })
}
const hm = Ke({
    referralLinkModalTitle: {
        id: "referralLinkModal.title",
        defaultMessage: "Refer classmates, earn rewards"
    },
    referralLinkModalMessage: {
        id: "referralLinkModal.message",
        defaultMessage: "Get a friend to sign up for ChatGPT, and you’ll both get a free month of Plus."
    },
    referralLinkModalDisclaimer: {
        id: "referralLinkModal.disclaimer",
        defaultMessage: "For every ChatGPT user with a valid university email address you refer, you get {discount} your next billing cycle. You can refer up to 12 people, and discounts are automatically applied."
    }
});

function xm(s) {
    return w.useCallback(async () => {
        try {
            if (!s) return;
            await Ad(s.billingDetails, s.plusAnalyticsParams)
        } catch (e) {}
    }, [s])
}

function bm({
    eligibleProgramName: s
}) {
    const {
        data: e
    } = Fs({
        queryKey: ["referrals-enrollment-details"],
        queryFn: () => Wi.getEnrollmentDetails()
    }), a = e == null ? void 0 : e.enrollment_details;
    return a ? t.jsx(ym, {
        enrollmentDetails: a
    }) : t.jsx(Mm, {
        eligibleProgramName: s
    })
}

function ym({
    enrollmentDetails: s
}) {
    const e = ve(),
        a = ga(e),
        n = K(),
        o = Ct(),
        i = Bu(),
        c = xm(i),
        l = a == null ? void 0 : a.hasPaidSubscription(),
        d = Pd(s.referral_code),
        {
            discount: r
        } = s.referral_metadata,
        u = Dd(n, r.value || 0, r.currency_code),
        f = s.earned_amount.split(".")[0],
        p = s.remaining_amount.split(".")[0];
    return t.jsxs(Q, {
        children: [t.jsxs("div", {
            className: "flex items-center justify-between gap-2",
            children: [t.jsx(m, {
                id: "OR4iav",
                defaultMessage: "Referrals"
            }), t.jsxs("div", {
                className: "flex h-8 items-center gap-2",
                children: [t.jsx("button", {
                    onClick: () => {
                        Vl(d, o).then(() => {
                            o.success(n.formatMessage({
                                id: "1TiBkD",
                                defaultMessage: "Copied referral link to clipboard"
                            }))
                        })
                    },
                    children: t.jsxs("div", {
                        className: "flex items-center gap-1",
                        children: [t.jsx("div", {
                            className: "text-sm",
                            children: d
                        }), t.jsx(Ld, {
                            className: "icon-sm"
                        })]
                    })
                }), !l && s.is_eligible_to_redeem && i && c ? t.jsx("div", {
                    className: "ms-1 flex flex-1 justify-end",
                    children: t.jsx(ne, {
                        color: "secondary",
                        onClick: c,
                        children: t.jsx(m, {
                            id: "u1eO00",
                            defaultMessage: "Get free Plus"
                        })
                    })
                }) : null]
            })]
        }), t.jsxs("div", {
            className: "border-token-border-default my-4 flex rounded-md border bg-gray-50 px-3 py-4 dark:bg-gray-900",
            children: [t.jsx(_a, {
                className: "border-token-border-default flex-1 border-e",
                info: s.num_referred,
                label: t.jsx(m, {
                    id: "i/bF9u",
                    defaultMessage: "Friends referred"
                })
            }), t.jsx(_a, {
                className: "flex-1",
                info: f,
                label: t.jsx(m, {
                    id: "iA319g",
                    defaultMessage: "Earned"
                })
            }), t.jsx(_a, {
                className: "border-token-border-default flex-1 border-s",
                info: p,
                label: t.jsx(m, {
                    id: "wY0EA3",
                    defaultMessage: "Remaining"
                })
            })]
        }), t.jsx("div", {
            className: "text-token-text-tertiary text-xs",
            children: t.jsx(m, Ee(b({}, hm.referralLinkModalDisclaimer), {
                values: {
                    discount: u
                }
            }))
        })]
    })
}

function _a({
    className: s,
    info: e,
    label: a
}) {
    return t.jsxs("div", {
        className: Ht("flex flex-col items-center gap-0.5", s),
        children: [t.jsx("div", {
            className: "text-base font-normal",
            children: e
        }), t.jsx("div", {
            className: "text-token-text-secondary text-xs",
            children: a
        })]
    })
}

function Mm({
    eligibleProgramName: s
}) {
    const e = K(),
        a = bs();
    return s ? t.jsx(Q, {
        children: t.jsx(Lt, {
            label: e.formatMessage({
                id: "OR4iav",
                defaultMessage: "Referrals"
            }),
            buttonLabel: e.formatMessage({
                id: "LZKJO9",
                defaultMessage: "Get my referral link"
            }),
            onClick: () => {
                a(Id(s))
            }
        })
    }) : null
}

function vm() {
    const s = ve(),
        e = je(s, "550432558"),
        {
            data: a
        } = Fs({
            queryKey: ["is-eligible-for-referrals"],
            queryFn: () => Wi.getIsEligibleForReferrals(),
            enabled: e
        }),
        n = e ? a == null ? void 0 : a.eligible_program_name : null;
    return n ? t.jsx(bm, {
        eligibleProgramName: n
    }) : null
}

function Cm() {
    return new URL(window.location.href).searchParams.get("disable_mfa") != null
}

function jm({
    onClose: s,
    onConfirm: e
}) {
    const a = K();
    return t.jsx(Rd, {
        isOpen: !0,
        title: a.formatMessage(Jo.disableConfimationTitle),
        confirmText: a.formatMessage(Jo.disable),
        onConfirm: e,
        onClose: s,
        primaryButtonColor: "danger",
        children: t.jsx("div", {
            children: t.jsx(m, {
                id: "postSigninDisableConfimationModal.description.1",
                defaultMessage: "Are you sure you want to disable multi-factor authentication? You will no longer need to provide a verification code when you log into your account."
            })
        })
    })
}
const Jo = Ke({
    disableConfimationTitle: {
        id: "mfaDisableConfirmationModal.title.0",
        defaultMessage: "Disable multi-factor authentication (MFA)"
    },
    disable: {
        id: "mfaDisableConfirmationModal.button",
        defaultMessage: "Disable MFA"
    }
});

function Sm() {
    const [s, e] = $l(), a = K();
    return t.jsxs("div", {
        className: "flex items-center justify-between",
        children: [t.jsx("div", {
            children: t.jsx(m, {
                id: "settingsModal.theme",
                defaultMessage: "Appearance"
            })
        }), t.jsx(Ii, {
            value: s,
            onValueChange: e,
            options: [{
                label: a.formatMessage({
                    id: "settingsModal.system",
                    defaultMessage: "System"
                }),
                value: "system"
            }, {
                label: a.formatMessage({
                    id: "settingsModal.dark",
                    defaultMessage: "Dark"
                }),
                value: "dark"
            }, {
                label: a.formatMessage({
                    id: "settingsModal.light",
                    defaultMessage: "Light"
                }),
                value: "light"
            }]
        })]
    })
}
async function _m() {
    var a;
    let s;
    "keyboard" in navigator && (s = navigator.keyboard);
    const e = (a = await (s == null ? void 0 : s.getLayoutMap())) != null ? a : new Map;
    return s != null && s.lock && await (s == null ? void 0 : s.lock()), new Promise(n => {
        const o = new Set,
            i = new Set;
        let c = !0;
        const l = g => {
                const h = ei(g, e);
                h && !o.has(h) && (o.add(h), i.add(h))
            },
            d = g => {
                const h = ei(g, e);
                h && o.delete(h), o.size === 0 && c && f()
            },
            r = g => {
                c && (u(), n(void 0))
            },
            u = () => {
                window.removeEventListener("keydown", l), window.removeEventListener("keyup", d), window.removeEventListener("mousedown", r), window.removeEventListener("click", r), window.removeEventListener("blur", r), clearTimeout(p), s != null && s.unlock && (s == null || s.unlock()), c = !1
            },
            f = () => {
                u();
                const g = wm(Array.from(i));
                n(yr({
                    webKeys: g
                }))
            };
        window.addEventListener("keydown", l), window.addEventListener("keyup", d), window.addEventListener("mousedown", r), window.addEventListener("click", r), window.addEventListener("blur", r);
        const p = setTimeout(() => {
            c && (u(), n(void 0))
        }, 1e4)
    })
}

function wm(s) {
    return s.toSorted((e, a) => {
        const n = Object.values(la).indexOf(e),
            o = n === -1 ? Number.MAX_SAFE_INTEGER : n,
            i = Object.values(la).indexOf(a),
            c = i === -1 ? Number.MAX_SAFE_INTEGER : i;
        return o === c ? e.charCodeAt(0) - a.charCodeAt(0) : o - c
    })
}
const km = s => /^[a-zA-Z]$/.test(s);

function ei(s, e) {
    var o;
    const a = (o = e.get(s.code)) != null ? o : s.key;
    let n;
    return Y[s.key] ? n = Y[s.key] : km(a) ? n = a.toUpperCase() : n = a, n
}

function yr(s) {
    return s.webKeys ? (s.electronAcceleratorKeys = s.webKeys.map(Nm), s.electronAcceleratorString = ti(s.electronAcceleratorKeys)) : s.electronAcceleratorKeys ? (s.webKeys = s.electronAcceleratorKeys.map(Em), s.electronAcceleratorString = ti(s.electronAcceleratorKeys)) : s = {
        webKeys: [],
        electronAcceleratorKeys: [],
        electronAcceleratorString: void 0
    }, s
}

function Em(s) {
    var e;
    return (e = la[s]) != null ? e : s
}

function Nm(s) {
    var e;
    return (e = Am[s]) != null ? e : s
}

function Mr(s) {
    const e = new Set(Object.keys(vr)),
        a = s.filter(o => !e.has(o)).length,
        n = s.length - a;
    return a === 1 && n > 0
}
const Tm = s => {
        const e = s.split("+");
        return Mr(e) ? e : void 0
    },
    ti = s => Mr(s) ? s.join("+") : void 0,
    vr = {
        Meta: Y.Meta,
        CmdOrCtrl: Y.Mod,
        CommandOrControl: Y.Mod,
        Ctrl: Y.Control,
        Control: Y.Control,
        Cmd: Y.Mod,
        Command: Y.Mod,
        Alt: Y.Alt,
        Option: Y.Alt,
        AltGr: Y.AltGraph,
        Shift: Y.Shift,
        Super: Y.Super
    },
    la = Ee(b({}, vr), {
        Capslock: Y.CapsLock,
        Space: Y.Space,
        Tab: Y.Tab,
        Numlock: Y.NumLock,
        Scrolllock: Y.ScrollLock,
        Backspace: Y.Backspace,
        Delete: Y.Delete,
        Insert: Y.Insert,
        Return: Y.Enter,
        Enter: Y.Enter,
        Home: Y.Home,
        End: Y.End,
        PageUp: Y.PageUp,
        PageDown: Y.PageDown,
        Up: Y.ArrowUp,
        Down: Y.ArrowDown,
        Left: Y.ArrowLeft,
        Right: Y.ArrowRight,
        Esc: Y.Escape,
        Escape: Y.Escape,
        VolumeUp: Y.AudioVolumeUp,
        VolumeDown: Y.AudioVolumeDown,
        VolumeMute: Y.AudioVolumeMute,
        MediaNextTrack: Y.MediaTrackNext,
        MediaPreviousTrack: Y.MediaTrackPrevious,
        MediaStop: Y.MediaStop,
        MediaPlayPause: Y.MediaPlayPause,
        PrintScreen: Y.PrintScreen,
        numadd: Y.Add,
        numsub: Y.Subtract,
        nummult: Y.Multiply,
        numdiv: Y.Divide,
        numdec: Y.Decimal,
        F1: Y.F1,
        F2: Y.F2,
        F3: Y.F3,
        F4: Y.F4,
        F5: Y.F5,
        F6: Y.F6,
        F7: Y.F7,
        F8: Y.F8,
        F9: Y.F9,
        F10: Y.F10,
        F11: Y.F11,
        F12: Y.F12,
        F13: Y.F13,
        F14: Y.F14,
        F15: Y.F15,
        F16: Y.F16,
        F17: Y.F17,
        F18: Y.F18,
        F19: Y.F19,
        F20: Y.F20
    }),
    Am = Object.fromEntries(Object.entries(la).map(([s, e]) => [e, s]));
async function Pm() {
    var s;
    await ((s = pn) == null ? void 0 : s.checkForUpdates())
}

function Dm() {
    var a;
    const [s, e] = w.useState(!1);
    return t.jsx(t.Fragment, {
        children: t.jsx(Q, {
            children: t.jsx(Lt, {
                label: t.jsx(m, b({}, ts.updatesSettingLabel)),
                disabled: s,
                buttonLabel: s ? t.jsx(m, b({}, ts.updateInProgressButtonLabel)) : t.jsx(m, b({}, ts.updateButtonLabel)),
                onClick: async () => {
                    try {
                        e(!0), await Pm()
                    } catch (n) {
                        Zs.addError(new Error("Sidetron Settings: Error checking for updates"), {
                            cause: n
                        })
                    } finally {
                        e(!1)
                    }
                },
                description: t.jsx(m, Ee(b({}, ts.updateSettingDescription), {
                    values: {
                        version: (a = Kl(Zl())) != null ? a : "Unknown"
                    }
                }))
            })
        })
    })
}
const Lm = async () => {
    var n;
    let s = "";
    const e = await ((n = pn) == null ? void 0 : n.getSettingValue("companionWindowShortcut"));
    typeof e == "string" ? s = e : Zs.addError(new Error("Sidetron Settings: No companion chat hotkey found over IPC"));
    const a = Tm(s);
    return Promise.resolve(yr({
        electronAcceleratorKeys: a
    }))
};

function Im() {
    const [s, e] = w.useState(!1), [a, n] = w.useState(void 0);
    return w.useEffect(() => {
        (async () => {
            const i = await Lm();
            n(i)
        })()
    }, []), w.useEffect(() => {
        var o;
        (o = pn) == null || o.publish(Co.HOTKEY_RECORDING_STATE, {
            inProgress: s
        })
    }, [s]), t.jsx(t.Fragment, {
        children: t.jsx(Q, {
            children: t.jsx(Lt, {
                label: t.jsx(m, b({}, ts.companionChatHotkeyLabel)),
                disabled: a === void 0 || s,
                buttonLabel: s ? t.jsx(m, b({}, ts.companionChatHotkeyRecordingLabel)) : a ? t.jsx(Bd, {
                    binding: a.webKeys,
                    className: "text-xs"
                }) : t.jsx(m, b({}, ts.companionChatHotkeyLoadingLabel)),
                onClick: async () => {
                    e(!0);
                    const o = await _m();
                    o ? o.electronAcceleratorString ? (n(o), pn && (pn.publish(Co.DESKTOP_SETTING_CHANGED, {
                        setting: "companionWindowShortcut",
                        value: o.electronAcceleratorString
                    }), Zs.addAction("Sidetron Settings: User recorded a new hotkey: ".concat(o.electronAcceleratorString)))) : Zs.addError(new Error("Sidetron Settings: Invalid companion chat hotkey registered: ".concat(o))) : Zs.addAction("Sidetron Settings: User did not record a hotkey"), e(!1)
                }
            })
        })
    })
}

function Rm() {
    return t.jsx(t.Fragment, {
        children: t.jsx(Q, {
            children: t.jsxs("div", {
                className: "flex items-center justify-between",
                children: [t.jsx("div", {
                    children: t.jsx(m, b({}, ts.textSizeLabel))
                }), t.jsxs("div", {
                    className: "flex shrink-0 gap-2",
                    children: [t.jsx(ne, {
                        color: "secondary",
                        onClick: ql,
                        "data-testid": "text-size-decrease",
                        icon: Od,
                        className: "aspect-square p-0"
                    }), t.jsx(ne, {
                        color: "secondary",
                        onClick: Yl,
                        "data-testid": "text-size-increase",
                        icon: Ri,
                        className: "aspect-square p-0"
                    }), t.jsx(ne, {
                        color: "secondary",
                        onClick: Ql,
                        "data-testid": "text-size-reset",
                        children: t.jsx(m, b({}, ts.textSizeResetButtonLabel))
                    })]
                })]
            })
        })
    })
}

function Bm({
    href: s,
    label: e,
    stateLabel: a,
    testId: n
}) {
    return t.jsx("a", {
        className: "w-full",
        "data-testid": n,
        href: s,
        target: "_blank",
        rel: "noreferrer",
        children: t.jsxs("div", {
            className: "flex items-center justify-between",
            children: [t.jsx("div", {
                children: e
            }), t.jsxs("div", {
                className: "me-3 -mb-1 flex items-center",
                children: [a && t.jsx("div", {
                    className: "me-2 -mt-0.5",
                    children: a
                }), t.jsx(Dn, {
                    className: "icon-sm"
                })]
            })]
        })
    })
}

function Om() {
    const [s, e] = w.useState(!1), a = K(), n = async () => {
        var i;
        const o = await ((i = pn) == null ? void 0 : i.getSettingValue("autoLaunch"));
        e(!!o)
    };
    return w.useEffect(() => {
        n();
        const o = () => {
            n()
        };
        return window.addEventListener("focus", o), () => {
            window.removeEventListener("focus", o)
        }
    }, []), t.jsx(t.Fragment, {
        children: t.jsx(Q, {
            children: t.jsx(Bm, {
                href: "ms-settings:startupapps",
                label: t.jsx(m, b({}, ts.autoLaunchLabel)),
                stateLabel: s ? a.formatMessage(ts.autoLaunchOnLabel) : a.formatMessage(ts.autoLaunchOffLabel)
            })
        })
    })
}
const ts = Ke({
    autoLaunchLabel: {
        id: "desktopAppSettingsModal.autoLaunchLabel",
        defaultMessage: "Launch at Login"
    },
    autoLaunchOnLabel: {
        id: "desktopAppSettingsModal.autoLaunchOnLabel",
        defaultMessage: "On"
    },
    autoLaunchOffLabel: {
        id: "desktopAppSettingsModal.autoLaunchOffLabel",
        defaultMessage: "Off"
    },
    updatesSettingLabel: {
        id: "desktopAppSettingsModal.updatesSettingLabel",
        defaultMessage: "App updates"
    },
    updateButtonLabel: {
        id: "desktopAppSettingsModal.updateButtonLabel",
        defaultMessage: "Check for updates"
    },
    updateInProgressButtonLabel: {
        id: "desktopAppSettingsModal.updateInProgressButtonLabel",
        defaultMessage: "Checking for updates..."
    },
    updateSettingDescription: {
        id: "desktopAppSettingsModal.updateSettingDescription",
        defaultMessage: "Current version: {version}"
    },
    companionChatHotkeyLabel: {
        id: "desktopAppSettingsModal.companionChatHotkeyLabel",
        defaultMessage: "Companion window hotkey"
    },
    companionChatHotkeyLoadingLabel: {
        id: "desktopAppSettingsModal.companionChatHotkeyLoadingLabel",
        defaultMessage: "Loading..."
    },
    companionChatHotkeyRecordingLabel: {
        id: "desktopAppSettingsModal.companionChatHotkeyRecordingLabel",
        defaultMessage: "Recording..."
    },
    textSizeLabel: {
        id: "desktopAppSettingsModal.textSizeLabel",
        defaultMessage: "Text size"
    },
    textSizeResetButtonLabel: {
        id: "desktopAppSettingsModal.textSizeResetButtonLabel",
        defaultMessage: "Reset"
    }
});
var Fm = (s => (s.SMS = "sms", s.WHATSAPP = "whatsapp", s))(Fm || {});

function Um() {
    const s = _t();
    return pt({
        mutationFn: ({
            factor: e,
            phoneNumber: a = void 0,
            channel: n
        }) => tt.safePost("/accounts/mfa/enroll", {
            requestBody: {
                factor_type: e,
                phone_number: a,
                phone_verification_channel: n
            }
        }),
        onSuccess: () => {
            s.invalidateQueries({
                queryKey: ["mfaInfo"]
            })
        }
    })
}

function xh() {
    const s = _t();
    return pt({
        mutationFn: ({
            factor: e,
            sessionId: a,
            code: n
        }) => tt.safePost("/accounts/mfa/user/activate_enrollment", {
            requestBody: {
                code: n,
                factor_type: e,
                session_id: a
            }
        }),
        onSuccess: () => {
            s.invalidateQueries({
                queryKey: ["mfaInfo"]
            })
        }
    })
}

function bh() {
    const s = _t();
    return pt({
        mutationFn: ({
            factorId: e
        }) => tt.safePost("/accounts/mfa/user/disable_in_house", {
            requestBody: {
                factor_id: e
            }
        }),
        onSuccess: () => {
            s.invalidateQueries({
                queryKey: ["mfaInfo"]
            })
        }
    })
}
const Gm = ft(() => gt(() =>
        import ("./jgvzsx6f79dwdz3i.js"), __vite__mapDeps([12, 1, 4, 5, 6, 2, 3, 7, 8, 13, 14, 15, 16, 17, 18, 19, 20, 21, 10, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58])).then(s => s.EnterPhoneNumberModal)),
    zm = ft(() => gt(() =>
        import ("./j8307ki0hiq07pvv.js"), __vite__mapDeps([59, 1, 6, 2, 3, 7, 13, 14, 15, 16, 17, 18, 19, 20, 21, 10, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58])).then(s => s.EnterOtpCodeModal)),
    gn = ft(() => gt(() =>
        import ("./blqq7ow0e0qiilq1.js"), __vite__mapDeps([60, 1, 2, 3, 6, 7, 14, 15, 16, 17, 18, 19, 20, 21, 10, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58])).then(s => s.DisableMfaFactorModal)),
    Hm = ft(() => gt(() =>
        import ("./dukay9hyrtkqj0qi.js"), __vite__mapDeps([61, 1, 6, 2, 3, 7, 13, 14, 15, 16, 17, 18, 19, 20, 21, 10, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58])).then(s => s.EnrollTotpModal)),
    Cr = (s, e) => {
        $e(s, Gm, {
            renderAsSheet: e,
            onOtpRequested: ({
                phoneNumber: a,
                enrollmentSessionId: n,
                factorId: o
            }) => {
                $e(s, zm, {
                    phoneNumber: a,
                    enrollmentSessionId: n,
                    factorId: o,
                    renderAsSheet: e,
                    onBack: () => {
                        Cr(s, e)
                    }
                })
            }
        })
    };

function Wm(s) {
    "use forget";
    var pe, fe, be, Te, Oe, We, Ve, ot, Ze, Fe, Ge, Xe, X, re, we;
    const e = Se.c(71),
        {
            factors: a,
            isDisabled: n,
            isLoading: o,
            showPushAuth: i,
            showSms: c,
            email: l,
            numTrustedDevices: d,
            renderAsSheet: r
        } = s;
    let u;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (u = {}, e[0] = u) : u = e[0];
    const {
        setupMfa: f,
        removeMfa: p
    } = ar(u), g = ve(), h = K(), y = Ct(), x = zs(), [j] = ci(), {
        pathname: v
    } = Sn(), S = bs(), C = Um(), M = w.useRef(!1), E = w.useRef(!1), N = w.useRef(!1), k = w.useRef(!1), P = w.useRef(!1);
    let L;
    e[1] !== g ? (L = je(g, "959646612"), e[1] = g, e[2] = L) : L = e[2];
    const A = L,
        _ = ((fe = (pe = a == null ? void 0 : a.totp) == null ? void 0 : pe.length) != null ? fe : 0) > 0,
        D = (Oe = (Te = (be = a == null ? void 0 : a.totp) == null ? void 0 : be[0]) == null ? void 0 : Te.id) != null ? Oe : "",
        [T, F] = w.useState(null),
        O = (a == null ? void 0 : a.push_auth) != null,
        I = (Ve = (We = a == null ? void 0 : a.push_auth) == null ? void 0 : We.id) != null ? Ve : "",
        [U, R] = w.useState(!1),
        [B, z] = w.useState(null);
    let W, V;
    e[3] !== _ || e[4] !== T ? (W = () => {
        T !== null && T === _ && F(null)
    }, V = [_, T], e[3] = _, e[4] = T, e[5] = W, e[6] = V) : (W = e[5], V = e[6]), w.useEffect(W, V);
    let J, ce;
    e[7] !== O || e[8] !== B ? (J = () => {
        B !== null && B === O && z(null)
    }, ce = [O, B], e[7] = O, e[8] = B, e[9] = J, e[10] = ce) : (J = e[9], ce = e[10]), w.useEffect(J, ce), x == null || x.planType;
    let ae;
    e: {
        if (!(x != null && x.planType)) {
            ae = !1;
            break e
        }
        const {
            country: te
        } = Xl();
        if (!te) {
            ae = !1;
            break e
        }
        const oe = Fd[te];
        if (!oe) {
            ae = !1;
            break e
        }
        let le;e[11] !== (x == null ? void 0 : x.planType) || e[12] !== oe.plans ? (le = oe.plans.has(x == null ? void 0 : x.planType), e[11] = x == null ? void 0 : x.planType, e[12] = oe.plans, e[13] = le) : le = e[13],
        ae = le
    }
    const Z = ae,
        $ = ((ot = a == null ? void 0 : a.sms.length) != null ? ot : 0) > 0,
        ee = (Fe = (Ze = a == null ? void 0 : a.sms[0]) == null ? void 0 : Ze.metadata) == null ? void 0 : Fe.phone_number,
        de = (X = (Xe = (Ge = a == null ? void 0 : a.sms[0]) == null ? void 0 : Ge.metadata) == null ? void 0 : Xe.verified_channels) == null ? void 0 : X[0],
        ye = (we = (re = a == null ? void 0 : a.sms[0]) == null ? void 0 : re.id) != null ? we : "",
        [ze, Le] = w.useState(!1);
    let Me;
    e[14] !== g || e[15] !== r ? (Me = () => {
        Cr(g, r)
    }, e[14] = g, e[15] = r, e[16] = Me) : Me = e[16];
    const me = Me;
    let xe;
    e[17] !== g || e[18] !== l || e[19] !== C || e[20] !== h || e[21] !== r || e[22] !== y ? (xe = () => {
        C.mutateAsync({
            factor: "totp"
        }).then(te => {
            N.current = !1, $e(g, Hm, {
                sessionId: te.session_id,
                secret: te.secret,
                email: l,
                renderAsSheet: r,
                onActivated: () => {
                    N.current = !0
                },
                onCancelled: () => {
                    N.current || F(!1), N.current = !1
                }
            })
        }).catch(() => {
            y.danger(h.formatMessage({
                id: "PK1QdN",
                defaultMessage: "We couldn't start setup. Please try again."
            }))
        })
    }, e[17] = g, e[18] = l, e[19] = C, e[20] = h, e[21] = r, e[22] = y, e[23] = xe) : xe = e[23];
    const Ce = xe;
    let He, Be;
    e[24] !== g || e[25] !== C || e[26] !== h || e[27] !== o || e[28] !== S || e[29] !== me || e[30] !== Ce || e[31] !== v || e[32] !== I || e[33] !== r || e[34] !== j || e[35] !== ye || e[36] !== y || e[37] !== D ? (He = () => {
        if (o || P.current) return;
        const te = j.get("action"),
            oe = j.get("factor"),
            le = j.get("factor_id");
        if (!te) return;
        let he = !1;
        const H = () => {
                var ht;
                if (k.current) return;
                if (v === "/security-settings") {
                    S({
                        pathname: "/security-settings",
                        search: ""
                    }, {
                        replace: !0
                    }), k.current = !0;
                    return
                }
                const st = Va(Ae.Security);
                S({
                    pathname: "/",
                    hash: (ht = st.hash) != null ? ht : "settings",
                    search: ""
                }, {
                    replace: !0
                }), k.current = !0
            },
            ue = () => {
                if (le) {
                    if (le === ye) {
                        $e(g, gn, {
                            factorId: le,
                            factor: "sms",
                            renderAsSheet: r
                        }), he = !0;
                        return
                    }
                    if (le === I) {
                        $e(g, gn, {
                            factorId: le,
                            factor: "push_auth",
                            onDisabled: () => z(!1),
                            renderAsSheet: r
                        }), he = !0;
                        return
                    }
                    if (le === D) {
                        $e(g, gn, {
                            factorId: le,
                            factor: "totp",
                            onDisabled: () => F(!1),
                            renderAsSheet: r
                        }), he = !0;
                        return
                    }
                }
            },
            _e = () => {
                if (oe === ya.PushAuth) {
                    if (M.current) {
                        he = !0;
                        return
                    }
                    M.current = !0, R(!0), C.mutateAsync({
                        factor: "push_auth"
                    }).then(() => {
                        R(!1), z(!0), y.success(h.formatMessage({
                            id: "ybOc16",
                            defaultMessage: "Push notifications enabled"
                        }), {
                            testId: "push-mfa-activation-success"
                        })
                    }).catch(() => {
                        R(!1), y.danger(h.formatMessage({
                            id: "h0SqYQ",
                            defaultMessage: "We couldn't enroll you in push notifications. Please try again."
                        }), {
                            testId: "push-mfa-enrollment-failed"
                        })
                    }), he = !0;
                    return
                }
                if (oe === ya.Totp) {
                    if (E.current) {
                        he = !0;
                        return
                    }
                    E.current = !0, Ce(), he = !0;
                    return
                }
                if (oe === ya.Sms) {
                    me(), he = !0;
                    return
                }
            };
        te === Oo.Disable ? ue() : te === Oo.Enable && _e(), he && (P.current = !0, H())
    }, Be = [j, g, S, v, ye, I, D, o, C, h, y, me, Ce, r], e[24] = g, e[25] = C, e[26] = h, e[27] = o, e[28] = S, e[29] = me, e[30] = Ce, e[31] = v, e[32] = I, e[33] = r, e[34] = j, e[35] = ye, e[36] = y, e[37] = D, e[38] = He, e[39] = Be) : (He = e[38], Be = e[39]), w.useEffect(He, Be);
    let G;
    e[40] !== g || e[41] !== C || e[42] !== h || e[43] !== n || e[44] !== o || e[45] !== Z || e[46] !== O || e[47] !== $ || e[48] !== _ || e[49] !== B || e[50] !== d || e[51] !== me || e[52] !== Ce || e[53] !== U || e[54] !== I || e[55] !== p || e[56] !== r || e[57] !== f || e[58] !== i || e[59] !== c || e[60] !== A || e[61] !== ye || e[62] !== ee || e[63] !== ze || e[64] !== de || e[65] !== y || e[66] !== D || e[67] !== T ? (G = !o && t.jsxs(t.Fragment, {
        children: [t.jsx("div", {
            className: "text-token-text-primary mt-2.5 mb-1.5 flex items-center gap-2 text-lg font-normal",
            children: t.jsx(m, {
                id: "settingsModal.mfaSectionTitle",
                defaultMessage: "Multi-factor authentication (MFA)"
            })
        }), t.jsx(Q, {
            children: t.jsx(ct, {
                disabled: n,
                enabled: T != null ? T : _,
                label: t.jsx(m, {
                    id: "settingsModal.mfaAuthenticatorLabel",
                    defaultMessage: "Authenticator app"
                }),
                description: t.jsx(m, {
                    id: "settingsModal.mfaAuthenticatorDescription",
                    defaultMessage: "Use one-time codes from an authenticator app."
                }),
                onChange: async te => {
                    if (te) {
                        if (F(!0), await f("totp", {
                                native_modal: !0,
                                mobile_webview: r
                            })) {
                            F(!1);
                            return
                        }
                        Ce()
                    } else {
                        const oe = D;
                        if (!oe || await p("totp", oe, {
                                mobile_webview: r
                            })) return;
                        $e(g, gn, {
                            factorId: oe,
                            factor: "totp",
                            renderAsSheet: r,
                            onDisabled: () => F(!1)
                        })
                    }
                }
            })
        }), i && t.jsx(Q, {
            children: t.jsx(ct, {
                disabled: n,
                enabled: B != null ? B : O,
                isLoading: U,
                toggleLeftAdornment: (B != null ? B : O) === !0 && typeof d == "number" && d === 0 ? t.jsx(Wt, {
                    label: t.jsx(m, {
                        id: "settingsModal.pushMfaNoTrustedDevicesTooltip",
                        defaultMessage: "No active trusted devices — we’ll email you a code instead"
                    }),
                    side: "top",
                    contentClassName: "!max-w-[180px]",
                    labelTextAlign: "left",
                    children: t.jsx(Ea, {
                        className: "icon-sm text-token-interactive-label-danger-secondary-default"
                    })
                }) : void 0,
                label: t.jsx(m, {
                    id: "settingsModal.pushMfaLabel",
                    defaultMessage: "Push notifications"
                }),
                description: t.jsx(m, {
                    id: "settingsModal.pushMfaDescription",
                    defaultMessage: "Approve log-ins with a push sent to your trusted device"
                }),
                onChange: async te => {
                    if (te) {
                        if (R(!0), await f("push_auth", {
                                mobile_webview: r
                            })) {
                            R(!1);
                            return
                        }
                        try {
                            await C.mutateAsync({
                                factor: "push_auth"
                            }).then(() => {
                                R(!1), z(!0), y.success(h.formatMessage({
                                    id: "ybOc16",
                                    defaultMessage: "Push notifications enabled"
                                }), {
                                    testId: "push-mfa-activation-success"
                                })
                            })
                        } catch (le) {
                            y.danger(h.formatMessage({
                                id: "1n5hT/",
                                defaultMessage: "We couldn't enroll you in push notifications. Please try again."
                            }), {
                                testId: "push-mfa-enrollment-failed"
                            }), R(!1)
                        }
                    } else {
                        const oe = I;
                        if (await p("push_auth", oe, {
                                mobile_webview: r
                            })) return;
                        $e(g, gn, {
                            factorId: oe,
                            factor: "push_auth",
                            renderAsSheet: r,
                            onDisabled: () => z(!1)
                        })
                    }
                }
            })
        }), ($ || c && (Z || A)) && t.jsx(Q, {
            children: t.jsx(ct, {
                label: t.jsx(m, {
                    id: "settingsModal.smsMfaLabel",
                    defaultMessage: "Text message"
                }),
                enabled: $,
                disabled: n,
                isLoading: o || ze,
                onChange: async te => {
                    if (te && !$) {
                        Le(!0);
                        const oe = await f("sms", {
                            mobile_webview: r
                        });
                        if (Le(!1), oe) return;
                        me()
                    } else if (!te && $) {
                        if (Le(!0), await p("sms", ye, {
                                mobile_webview: r
                            })) return;
                        Le(!1), $e(g, gn, {
                            factorId: ye,
                            factor: "sms",
                            renderAsSheet: r
                        })
                    }
                },
                description: t.jsxs(t.Fragment, {
                    children: [t.jsx("div", {
                        className: "text-token-text-tertiary mt-1 pe-[40px] text-start text-xs",
                        children: $ ? t.jsx(m, {
                            id: "settingsModal.smsMfaDescription.smsEnabled",
                            defaultMessage: "Get 6-digit verification codes by {channel}",
                            values: {
                                channel: de === "whatsapp" ? "WhatsApp" : "text"
                            }
                        }) : t.jsx(m, {
                            id: "settingsModal.smsMfaDescription.smsNotEnabled",
                            defaultMessage: "Get 6-digit verification codes by SMS or WhatsApp based on your country code"
                        })
                    }), ee && t.jsx("div", {
                        className: "mt-1",
                        children: t.jsx("p", {
                            className: "text-blue-400",
                            "data-testid": ee ? "sms-phone-number-row" : "sms-phone-number-row-add",
                            children: ee
                        })
                    })]
                })
            })
        }), t.jsx("div", {
            className: "hidden",
            "aria-hidden": !0
        })]
    }), e[40] = g, e[41] = C, e[42] = h, e[43] = n, e[44] = o, e[45] = Z, e[46] = O, e[47] = $, e[48] = _, e[49] = B, e[50] = d, e[51] = me, e[52] = Ce, e[53] = U, e[54] = I, e[55] = p, e[56] = r, e[57] = f, e[58] = i, e[59] = c, e[60] = A, e[61] = ye, e[62] = ee, e[63] = ze, e[64] = de, e[65] = y, e[66] = D, e[67] = T, e[68] = G) : G = e[68];
    let se;
    return e[69] !== G ? (se = t.jsx("div", {
        className: "flex flex-col",
        children: G
    }), e[69] = G, e[70] = se) : se = e[70], se
}
const wa = ft(() => gt(() =>
        import ("./nqsndip1gtokbr16.js"), __vite__mapDeps([62, 1, 6, 2, 3, 7, 51])).then(s => s.PasskeysModal)),
    Vm = ft(() => gt(() =>
        import ("./l2auawa985ju84xg.js"), __vite__mapDeps([63, 1, 2, 3, 6, 7, 14, 15, 16, 17, 18, 19, 20, 21, 10, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58])).then(s => s.DeletePasskeyModal));

function $m({
    factors: s,
    renderAsSheet: e
}) {
    const a = ve(),
        {
            setupMfa: n
        } = ar({}),
        o = K(),
        [i] = ci(),
        c = bs(),
        l = w.useRef(!1),
        d = w.useRef(new Set),
        r = w.useMemo(() => {
            var v;
            return (v = s == null ? void 0 : s.passkeys) != null ? v : []
        }, [s == null ? void 0 : s.passkeys]);
    if (w.useEffect(() => {
            var N, k, P;
            if (l.current) return;
            const v = i.get("action"),
                S = i.get("factor"),
                C = i.get("factor_id");
            if (v !== "disable" || S !== "passkey" || !C) return;
            const M = r.find(L => L.id === C);
            if (!M || (l.current = !0, d.current.has(M.id))) return;
            d.current.add(M.id), $e(a, wa, {
                passkeys: r,
                onCreatePasskey: () => {
                    n("passkey")
                },
                renderAsSheet: e
            }), $e(a, Vm, {
                factorId: M.id,
                passkeyName: (k = (N = M.metadata) == null ? void 0 : N.authenticator_name) != null ? k : null,
                onDeleted: L => {
                    const A = r.filter(_ => _.id !== L);
                    $e(a, wa, {
                        passkeys: A,
                        onCreatePasskey: () => {
                            n("passkey")
                        },
                        renderAsSheet: e
                    }), d.current.delete(L)
                },
                onClose: () => {
                    d.current.delete(M.id)
                },
                renderAsSheet: e
            });
            const E = Va(Ae.Security);
            c({
                pathname: "/",
                hash: (P = E.hash) != null ? P : "settings",
                search: ""
            }, {
                replace: !0
            })
        }, [a, r, i, n, c, e]), !je(a, "1216135095")) return null;
    const f = r.length,
        p = r.reduce((v, S) => {
            var M, E;
            const C = (E = (M = S.metadata) == null ? void 0 : M.create_time_seconds) != null ? E : 0;
            return C > v ? C : v
        }, 0),
        g = p > 0 ? new Date(p * 1e3) : null,
        h = () => {
            n("passkey")
        },
        y = t.jsxs("div", {
            className: "text-start font-normal",
            children: [t.jsx(m, {
                id: "settingsModal.passkeysRowTitle",
                defaultMessage: "Passkeys"
            }), f === 0 && t.jsx("p", {
                className: "text-token-text-tertiary mt-1 text-xs",
                children: t.jsx(m, {
                    id: "settingsModal.passkeysRowDescription",
                    defaultMessage: "Passkeys are secure and protect your account with multi-factor authentication. They don't require any extra steps."
                })
            }), f > 0 && g && t.jsx("p", {
                className: "text-token-text-tertiary mt-1 text-xs",
                children: t.jsx(m, {
                    id: "settingsModal.passkeysRowLastAdded",
                    defaultMessage: "Last added on {date}",
                    values: {
                        date: o.formatDate(g, {
                            month: "long",
                            day: "numeric",
                            year: "numeric"
                        })
                    }
                })
            })]
        }),
        x = f === 0 ? o.formatMessage({
            id: "settingsModal.passkeysRowAdd",
            defaultMessage: "Add"
        }) : o.formatMessage({
            id: "settingsModal.passkeysRowCountLabel",
            defaultMessage: "{count, plural, one {# passkey} other {# passkeys}}"
        }, {
            count: f
        }),
        j = () => {
            if (f === 0) {
                h();
                return
            }
            $e(a, wa, {
                passkeys: r,
                onCreatePasskey: h,
                renderAsSheet: e
            })
        };
    return t.jsx(Q, {
        children: t.jsx(Mn, {
            onClick: j,
            label: y,
            stateLabel: x
        })
    })
}

function Km(s) {
    "use forget";
    const e = Se.c(25),
        {
            personalitiesList: a,
            selectedPersonality: n,
            traitsList: o,
            currentTraits: i,
            onSelectPersonality: c,
            onSelectTrait: l
        } = s,
        d = Ud(null),
        [r, u] = w.useState(null),
        f = en(c),
        p = en(l);
    let g, h;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (g = t.jsx(m, {
        defaultMessage: "Base style and tone",
        id: "settings.personality.baseStyleAndTone"
    }), h = t.jsx(m, {
        defaultMessage: "Set the style and tone of how ChatGPT responds to you. This doesn't impact ChatGPT's capabilities.",
        id: "settings.personality.baseStyleAndToneDescription"
    }), e[0] = g, e[1] = h) : (g = e[0], h = e[1]);
    let y;
    e[2] !== f ? (y = M => {
        w.startTransition(() => {
            f(M)
        })
    }, e[2] = f, e[3] = y) : y = e[3];
    const x = n == null ? void 0 : n.key;
    let j;
    e[4] !== a || e[5] !== y || e[6] !== x ? (j = t.jsx(si, {
        label: g,
        subtitle: h,
        dropdown: t.jsx(Gd, {
            personalitiesList: a,
            enabled: !0,
            onSelect: y,
            selectedPersonality: x
        })
    }), e[4] = a, e[5] = y, e[6] = x, e[7] = j) : j = e[7];
    let v;
    e[8] !== o.length ? (v = o.length > 0 && t.jsxs(t.Fragment, {
        children: [t.jsx(Qm, {}), t.jsxs("div", {
            className: "col-span-full mb-2 w-full",
            children: [t.jsx("div", {
                className: "w-full truncate select-none",
                children: t.jsx(m, {
                    defaultMessage: "Characteristics",
                    id: "settings.personality.characteristics"
                })
            }), t.jsx("div", {
                className: "text-token-text-tertiary text-xs text-pretty",
                children: t.jsx(m, {
                    defaultMessage: "Choose additional customizations on top of your base style and tone.",
                    id: "settings.personality.characteristicsDescription"
                })
            })]
        })]
    }), e[8] = o.length, e[9] = v) : v = e[9];
    let S;
    if (e[10] !== i || e[11] !== d || e[12] !== r || e[13] !== p || e[14] !== o) {
        let M;
        e[16] !== i || e[17] !== d || e[18] !== r || e[19] !== p ? (M = E => {
            var N;
            return t.jsx(si, {
                label: E.label,
                dropdown: t.jsx(qm, {
                    trait: E,
                    level: (N = i.get(E.key)) != null ? N : null,
                    parent: r,
                    openDropdownType: d,
                    onLevelChange: k => {
                        w.startTransition(() => {
                            p(E.key, k)
                        })
                    }
                })
            }, E.key)
        }, e[16] = i, e[17] = d, e[18] = r, e[19] = p, e[20] = M) : M = e[20], S = o.map(M), e[10] = i, e[11] = d, e[12] = r, e[13] = p, e[14] = o, e[15] = S
    } else S = e[15];
    let C;
    return e[21] !== j || e[22] !== v || e[23] !== S ? (C = t.jsxs(Zm, {
        ref: u,
        children: [j, v, S]
    }), e[21] = j, e[22] = v, e[23] = S, e[24] = C) : C = e[24], C
}

function qm(s) {
    "use forget";
    const e = Se.c(34),
        {
            trait: a,
            level: n,
            onLevelChange: o,
            parent: i,
            openDropdownType: c
        } = s;
    let l;
    e[0] !== c || e[1] !== a.key ? (l = () => c() === a.key, e[0] = c, e[1] = a.key, e[2] = l) : l = e[2];
    const d = Qe(l),
        r = a.key;
    let u;
    e[3] !== c || e[4] !== a.key ? (u = E => {
        w.startTransition(() => {
            E ? c.set(a.key) : requestAnimationFrame(() => {
                c() === a.key && c.set(null)
            })
        })
    }, e[3] = c, e[4] = a.key, e[5] = u) : u = e[5];
    let f;
    e[6] !== n ? (f = n === "less" && t.jsx(m, {
        defaultMessage: "Less",
        id: "settings.personality.trait.less"
    }), e[6] = n, e[7] = f) : f = e[7];
    let p;
    e[8] !== n ? (p = n === "more" && t.jsx(m, {
        defaultMessage: "More",
        id: "settings.personality.trait.more"
    }), e[8] = n, e[9] = p) : p = e[9];
    let g;
    e[10] !== n ? (g = (!n || n === "default") && t.jsx(m, {
        defaultMessage: "Default",
        id: "settings.personality.trait.default"
    }), e[10] = n, e[11] = g) : g = e[11];
    let h;
    e[12] === Symbol.for("react.memo_cache_sentinel") ? (h = t.jsx("svg", {
        className: "text-muted ms-2 h-4 w-4",
        fill: "none",
        stroke: "currentColor",
        viewBox: "0 0 24 24",
        children: t.jsx("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: 2,
            d: "M19 9l-7 7-7-7"
        })
    }), e[12] = h) : h = e[12];
    let y;
    e[13] !== f || e[14] !== p || e[15] !== g ? (y = t.jsx(De.Trigger, {
        asChild: !0,
        children: t.jsxs(ne, {
            color: "ghost",
            className: "font-normal",
            children: [f, p, g, h]
        })
    }), e[13] = f, e[14] = p, e[15] = g, e[16] = y) : y = e[16];
    const x = n != null ? n : "default";
    let j;
    e[17] !== o ? (j = E => {
        o(E)
    }, e[17] = o, e[18] = j) : j = e[18];
    let v;
    e[19] !== a.levels ? (v = a.levels.map(Ym), e[19] = a.levels, e[20] = v) : v = e[20];
    let S;
    e[21] !== j || e[22] !== v || e[23] !== x ? (S = t.jsx(De.Content, {
        align: "end",
        children: t.jsx(De.RadioGroup, {
            value: x,
            onValueChange: j,
            children: v
        })
    }), e[21] = j, e[22] = v, e[23] = x, e[24] = S) : S = e[24];
    let C;
    e[25] !== i || e[26] !== S ? (C = t.jsx(De.Portal, {
        container: i,
        children: S
    }), e[25] = i, e[26] = S, e[27] = C) : C = e[27];
    let M;
    return e[28] !== d || e[29] !== C || e[30] !== u || e[31] !== y || e[32] !== a.key ? (M = t.jsxs(De.Root, {
        modal: !0,
        open: d,
        onOpenChange: u,
        children: [y, C]
    }, r), e[28] = d, e[29] = C, e[30] = u, e[31] = y, e[32] = a.key, e[33] = M) : M = e[33], M
}

function Ym(s) {
    return t.jsx(De.RadioItem, {
        label: t.jsxs("div", {
            className: "flex flex-col",
            children: [t.jsx("span", {
                children: s.option_label
            }), t.jsx("span", {
                className: "text-token-text-tertiary truncate text-xs text-balance wrap-break-word",
                children: s.description
            })]
        }),
        value: s.key
    }, s.key)
}

function Qm() {
    "use forget";
    const s = Se.c(1);
    let e;
    return s[0] === Symbol.for("react.memo_cache_sentinel") ? (e = t.jsx("div", {
        className: "col-span-full h-1.5 w-full"
    }), s[0] = e) : e = s[0], e
}

function si(s) {
    "use forget";
    const e = Se.c(10),
        {
            label: a,
            dropdown: n,
            subtitle: o
        } = s;
    let i;
    e[0] !== a ? (i = t.jsx("div", {
        className: "truncate select-none",
        children: a
    }), e[0] = a, e[1] = i) : i = e[1];
    let c;
    e[2] !== n ? (c = n && t.jsx("div", {
        className: "w-fit justify-self-end",
        children: n
    }), e[2] = n, e[3] = c) : c = e[3];
    let l;
    e[4] !== o ? (l = o && t.jsxs(t.Fragment, {
        children: [t.jsx("div", {
            className: "text-token-text-tertiary -mt-3 text-xs text-pretty",
            children: o
        }), t.jsx("div", {
            "data-empty": !0
        })]
    }), e[4] = o, e[5] = l) : l = e[5];
    let d;
    return e[6] !== i || e[7] !== c || e[8] !== l ? (d = t.jsxs(t.Fragment, {
        children: [i, c, l]
    }), e[6] = i, e[7] = c, e[8] = l, e[9] = d) : d = e[9], d
}

function Zm(s) {
    "use forget";
    const e = Se.c(8),
        {
            children: a,
            title: n,
            ref: o
        } = s;
    let i;
    e[0] !== n ? (i = n && t.jsx("h2", {
        className: "text-heading-3 font-normal",
        children: n
    }), e[0] = n, e[1] = i) : i = e[1];
    let c;
    e[2] !== a ? (c = t.jsx("div", {
        className: "grid [grid-auto-rows:minmax(min-content,auto)] grid-cols-[minmax(0,1fr)_max-content] items-center gap-2",
        children: a
    }), e[2] = a, e[3] = c) : c = e[3];
    let l;
    return e[4] !== o || e[5] !== i || e[6] !== c ? (l = t.jsxs("section", {
        className: "flex flex-col gap-2 pt-4",
        ref: o,
        children: [i, c]
    }), e[4] = o, e[5] = i, e[6] = c, e[7] = l) : l = e[7], l
}

function Xm({
    onSuccess: s,
    onError: e
}) {
    const a = _t();
    return pt({
        mutationFn: ({
            userContext: n,
            conversationId: o,
            messageId: i
        }) => Ti(Ee(b({}, n), {
            conversationId: o,
            messageId: i
        })),
        onSettled: (n, o) => {
            const i = ["userContext"];
            n !== null && !o ? a.setQueryData(i, n) : a.invalidateQueries({
                queryKey: i
            })
        },
        onSuccess: s,
        onError: e
    })
}
const ni = 100,
    Jm = 80;

function ep() {
    "use forget";
    const s = Se.c(31),
        {
            data: e,
            isLoading: a
        } = Et(ie.Sunshine),
        {
            data: n,
            isLoading: o
        } = Et(ie.Moonshine),
        {
            data: i,
            isLoading: c
        } = Et(ie.UkdvthMemoryEnabled),
        {
            data: l,
            isLoading: d
        } = Et(ie.UkdvthEntrypointVisible),
        {
            mutate: r,
            isPending: u
        } = kt(!0),
        {
            mutate: f,
            isPending: p
        } = kt(!0),
        g = Za(),
        h = K(),
        y = (g == null ? void 0 : g[ie.UkdvthMemoryEnabled]) === !0 || !e || !n,
        x = (g == null ? void 0 : g[ie.UkdvthEntrypointVisible]) === !0 || !e || !n || !i,
        j = y ? !1 : i,
        v = x ? !1 : l,
        S = c || a || o || u,
        C = d || c || a || o || p;
    let M;
    s[0] !== h ? (M = h.formatMessage(Re.pulseSettingTitle), s[0] = h, s[1] = M) : M = s[1];
    let E;
    s[2] !== h ? (E = h.formatMessage(Re.pulseReferenceMemoriesToggleLabel), s[2] = h, s[3] = E) : E = s[3];
    const N = j != null ? j : !1;
    let k;
    s[4] !== y || s[5] !== r ? (k = I => {
        y || (Ue.logEventWithStatsig(I ? "ChatGPT Personalization Settings Pulse Enabled" : "ChatGPT Personalization Settings Pulse Disabled", I ? "chatgpt_personalization_settings_pulse_enabled" : "chatgpt_personalization_settings_pulse_disabled"), r({
            setting: ie.UkdvthMemoryEnabled,
            value: I
        }))
    }, s[4] = y, s[5] = r, s[6] = k) : k = s[6];
    let P;
    s[7] !== y || s[8] !== S || s[9] !== E || s[10] !== N || s[11] !== k ? (P = t.jsx(ct, {
        label: E,
        enabled: N,
        disabled: y,
        isLoading: S,
        onChange: k
    }), s[7] = y, s[8] = S, s[9] = E, s[10] = N, s[11] = k, s[12] = P) : P = s[12];
    let L;
    s[13] === Symbol.for("react.memo_cache_sentinel") ? (L = t.jsx(yn, {
        children: t.jsx(m, b({}, Re.pulseReferenceMemoriesDescription))
    }), s[13] = L) : L = s[13];
    let A;
    s[14] !== P ? (A = t.jsxs(Q, {
        children: [P, L]
    }), s[14] = P, s[15] = A) : A = s[15];
    let _;
    s[16] !== h ? (_ = h.formatMessage(Re.pulseEntrypointToggleLabel), s[16] = h, s[17] = _) : _ = s[17];
    const D = v != null ? v : !1;
    let T;
    s[18] !== x || s[19] !== f ? (T = I => {
        x || (Ue.logEventWithStatsig(I ? "ChatGPT Personalization Settings Pulse Entrypoint Enabled" : "ChatGPT Personalization Settings Pulse Entrypoint Disabled", I ? "chatgpt_personalization_settings_pulse_entrypoint_enabled" : "chatgpt_personalization_settings_pulse_entrypoint_disabled"), f({
            setting: ie.UkdvthEntrypointVisible,
            value: I
        }))
    }, s[18] = x, s[19] = f, s[20] = T) : T = s[20];
    let F;
    s[21] !== x || s[22] !== C || s[23] !== _ || s[24] !== D || s[25] !== T ? (F = t.jsx(Q, {
        children: t.jsx(ct, {
            label: _,
            enabled: D,
            disabled: x,
            isLoading: C,
            onChange: T
        })
    }), s[21] = x, s[22] = C, s[23] = _, s[24] = D, s[25] = T, s[26] = F) : F = s[26];
    let O;
    return s[27] !== M || s[28] !== F || s[29] !== A ? (O = t.jsxs(Ne, {
        title: M,
        children: [A, F]
    }), s[27] = M, s[28] = F, s[29] = A, s[30] = O) : O = s[30], O
}

function tp() {
    var d, r, u;
    const s = K(),
        e = Xs(on.isBusinessWorkspace),
        a = (d = Xs(on.businessWorkspaceId)) != null ? d : void 0,
        {
            data: n,
            isLoading: o
        } = lc(a),
        {
            data: i
        } = Et(ie.HiveReferencedInInternalKnowledge),
        c = kt();
    return o ? t.jsx("div", {
        className: "flex justify-center",
        children: t.jsx(ys, {})
    }) : (e ? ((r = n == null ? void 0 : n.beta_settings.hive) != null ? r : !1) && ((u = n == null ? void 0 : n.beta_settings.hive_knowledge_retrieval) != null ? u : !1) : !0) ? t.jsx(Ne, {
        title: s.formatMessage(Re.RecordModeTitle),
        learnMoreHref: "https://help.openai.com/en/articles/11487532-chatgpt-record",
        children: t.jsx(Q, {
            children: t.jsx(ct, {
                label: s.formatMessage(Re.recordModeToggleLabel),
                enabled: !!i,
                onChange: f => c.mutate({
                    setting: ie.HiveReferencedInInternalKnowledge,
                    value: f
                }),
                description: t.jsx(m, b({}, Re.recordModeDescription))
            })
        })
    }) : null
}

function sp({
    disabledTools: s,
    localUserContext: e,
    setLocalUserContext: a,
    userContextData: n
}) {
    var y, x;
    const o = K(),
        i = ve(),
        [c, l] = w.useState(!1),
        d = w.useRef(null),
        u = cc(i) && je(i, "798638120"),
        {
            data: f,
            isLoading: p
        } = Et(ie.ConnectorSearchEnabled),
        {
            mutate: g,
            isPending: h
        } = kt();
    return t.jsx(Ne, {
        title: t.jsxs("button", {
            onClick: () => {
                l(j => !j), c || requestAnimationFrame(() => {
                    d.current && d.current.scrollIntoView({
                        behavior: "smooth",
                        block: "end"
                    })
                })
            },
            "aria-label": o.formatMessage(c ? Re.advancedClose : Re.advancedOpen),
            "data-testid": "advanced-toggle",
            "aria-expanded": c,
            className: "flex items-center justify-between gap-1",
            children: [t.jsx(m, b({}, Re.advanced)), c ? t.jsx(su, {
                className: "icon-sm"
            }) : t.jsx(Hi, {
                className: "icon-sm"
            })]
        }),
        noBorder: !c,
        children: c && t.jsxs("div", {
            className: "mt-2",
            children: [t.jsx(tu, {
                disabledTools: (x = (y = e.disabledTools) != null ? y : s) != null ? x : [],
                onDisabledToolsChanged: j => fn({
                    userContextData: n,
                    updates: {
                        disabledTools: j
                    },
                    localUserContext: e,
                    setLocalUserContext: a
                })
            }), u && t.jsx("div", {
                children: t.jsx(Q, {
                    children: t.jsx(ct, {
                        label: o.formatMessage(Re.connectorSearchToggleLabel),
                        description: t.jsx(m, b({}, Re.connectorSearchDescription)),
                        enabled: f != null ? f : !0,
                        isLoading: p || h,
                        onChange: j => g({
                            setting: ie.ConnectorSearchEnabled,
                            value: j
                        })
                    })
                })
            }), t.jsx("span", {
                ref: d
            })]
        })
    })
}
const np = Er({
    id: "+CiZn7",
    defaultMessage: "Base style and tone updated"
});

function ap(s) {
    "use forget";
    var ht, Nt, Tt, Vt, Ms, $t;
    const e = Se.c(136),
        {
            userContextData: a,
            conversationId: n,
            messageId: o,
            localUserContext: i,
            setLocalUserContext: c,
            onSubmit: l,
            hasModError: d
        } = s,
        r = ve(),
        u = K();
    let f;
    e[0] !== r ? (f = () => nu(r)(), e[0] = r, e[1] = f) : f = e[1];
    const p = Qe(f);
    let g;
    e[2] !== r ? (g = () => au(r), e[2] = r, e[3] = g) : g = e[3];
    const h = Qe(g);
    let y;
    e[4] !== r ? (y = () => ou(r)(), e[4] = r, e[5] = y) : y = e[5];
    const x = Qe(y);
    let j;
    e[6] !== r ? (j = () => So(r), e[6] = r, e[7] = j) : j = e[7];
    const v = Qe(j),
        S = w.useRef(null);
    let C;
    e[8] !== n || e[9] !== r || e[10] !== u || e[11] !== o ? (C = Je => {
        dc({
            ctx: r,
            personalityType: Je,
            conversationId: n,
            messageId: o,
            opts: {
                optimistic: !0
            }
        }), w.startTransition(() => {
            var et;
            const it = es(r);
            (et = S.current) == null || et.close(), S.current = it.success(u.formatMessage(np), {
                duration: 4,
                hasCloseButton: !0
            })
        })
    }, e[8] = n, e[9] = r, e[10] = u, e[11] = o, e[12] = C) : C = e[12];
    const M = en(C);
    let E;
    e[13] !== n || e[14] !== r || e[15] !== o ? (E = (Je, it) => {
        const et = new Map(So(r));
        et.set(Je, it), uc(r, et, n, o, {
            optimistic: !0
        })
    }, e[13] = n, e[14] = r, e[15] = o, e[16] = E) : E = e[16];
    const N = en(E),
        k = oc(ip),
        P = (ht = i.enabled) != null ? ht : !!(a != null && a.enabled);
    let L;
    e[17] !== a ? (L = Qi(a), e[17] = a, e[18] = L) : L = e[18];
    const {
        nameUserMessage: A,
        roleUserMessage: _,
        traitsModelMessage: D,
        otherUserMessage: T
    } = L, [F, O] = w.useState(0), [I, U] = w.useState(!0);
    let R, B;
    e[19] === Symbol.for("react.memo_cache_sentinel") ? (R = () => {
        const Je = setTimeout(() => {
                U(!1)
            }, 1e3),
            it = setInterval(() => {
                O(op)
            }, 5500);
        return () => {
            clearInterval(it), clearTimeout(Je)
        }
    }, B = [], e[19] = R, e[20] = B) : (R = e[19], B = e[20]), w.useEffect(R, B);
    let z, W;
    e[21] === Symbol.for("react.memo_cache_sentinel") ? (z = () => (tt.safePost("/personality_settings_impression", {
        authOption: gc.SendIfAvailable
    }), () => {
        S.current = null
    }), W = [], e[21] = z, e[22] = W) : (z = e[21], W = e[22]), w.useEffect(z, W);
    let V;
    e[23] !== r ? (V = () => fc(r), e[23] = r, e[24] = V) : V = e[24];
    const J = Qe(V);
    let ce;
    e[25] !== u ? (ce = u.formatMessage(Re.customizeTitle), e[25] = u, e[26] = ce) : ce = e[26];
    let ae;
    e[27] !== u || e[28] !== i || e[29] !== J || e[30] !== c || e[31] !== a || e[32] !== P ? (ae = !J && t.jsx(Q, {
        children: t.jsx(ct, {
            label: t.jsx(m, b({}, Re.enablePersonalizationRowLabel)),
            description: t.jsx(m, b({}, Re.enablePersonalizationRowDescription)),
            enabled: P,
            onChange: Je => {
                fn({
                    userContextData: a,
                    updates: {
                        enabled: Je
                    },
                    localUserContext: i,
                    setLocalUserContext: c
                }), Ue.logEventWithStatsig("Enable Customization Toggled", "chatgpt_enable_customization_toggled", {
                    enabled: Je
                })
            },
            "aria-label": P ? u.formatMessage(Re.disableToggleLabel) : u.formatMessage(Re.enableToggleLabel)
        })
    }), e[27] = u, e[28] = i, e[29] = J, e[30] = c, e[31] = a, e[32] = P, e[33] = ae) : ae = e[33];
    let Z;
    e[34] !== v || e[35] !== M || e[36] !== N || e[37] !== p || e[38] !== J || e[39] !== h || e[40] !== x ? (Z = J && t.jsx(Km, {
        personalitiesList: p,
        selectedPersonality: h,
        traitsList: x,
        currentTraits: v,
        onSelectPersonality: M,
        onSelectTrait: N
    }), e[34] = v, e[35] = M, e[36] = N, e[37] = p, e[38] = J, e[39] = h, e[40] = x, e[41] = Z) : Z = e[41];
    let $;
    e[42] !== u ? ($ = u.formatMessage(Re.customInstructions), e[42] = u, e[43] = $) : $ = e[43];
    const ee = !P,
        de = d === "traits_model_message",
        ye = (Nt = i.traitsModelMessage) != null ? Nt : D;
    let ze;
    e[44] !== u ? (ze = u.formatMessage(Re.customInstructionsPlaceholder), e[44] = u, e[45] = ze) : ze = e[45];
    let Le;
    e[46] !== i || e[47] !== c || e[48] !== a ? (Le = Je => fn({
        userContextData: a,
        updates: {
            traitsModelMessage: Je.target.value
        },
        localUserContext: i,
        setLocalUserContext: c
    }), e[46] = i, e[47] = c, e[48] = a, e[49] = Le) : Le = e[49];
    let Me;
    e[50] !== l || e[51] !== ee || e[52] !== de || e[53] !== ye || e[54] !== ze || e[55] !== Le ? (Me = t.jsx(Vn, {
        onSubmit: l,
        name: "traits_model_message",
        disabled: ee,
        hasModError: de,
        value: ye,
        placeholder: ze,
        onChange: Le,
        scrollObscuringHeight: 84,
        scrollOnFocus: !0,
        scrollOnChange: !0,
        size: "sm",
        showCharacterCount: !1,
        textareaClassName: "scroll-mb-25",
        isNewCustomInstructionsUIEnabled: !0,
        dynamicHeight: !0
    }), e[50] = l, e[51] = ee, e[52] = de, e[53] = ye, e[54] = ze, e[55] = Le, e[56] = Me) : Me = e[56];
    let me;
    e[57] !== $ || e[58] !== Me ? (me = t.jsx($n, {
        title: $,
        className: "pt-7",
        children: Me
    }), e[57] = $, e[58] = Me, e[59] = me) : me = e[59];
    let xe;
    e[60] !== ce || e[61] !== ae || e[62] !== Z || e[63] !== me ? (xe = t.jsxs(Ne, {
        title: ce,
        children: [ae, Z, me]
    }), e[60] = ce, e[61] = ae, e[62] = Z, e[63] = me, e[64] = xe) : xe = e[64];
    let Ce;
    e[65] !== u ? (Ce = u.formatMessage(Re.aboutYouSectionTitle), e[65] = u, e[66] = Ce) : Ce = e[66];
    let He;
    e[67] !== u ? (He = u.formatMessage(Re.customizeNamePlaceholder), e[67] = u, e[68] = He) : He = e[68];
    const Be = !P,
        G = d === "name_user_message",
        se = (Tt = i.nameUserMessage) != null ? Tt : A;
    let pe;
    e[69] !== u ? (pe = u.formatMessage(Re.customizeName), e[69] = u, e[70] = pe) : pe = e[70];
    let fe;
    e[71] !== i || e[72] !== c || e[73] !== a ? (fe = Je => fn({
        userContextData: a,
        updates: {
            nameUserMessage: Je.target.value
        },
        localUserContext: i,
        setLocalUserContext: c
    }), e[71] = i, e[72] = c, e[73] = a, e[74] = fe) : fe = e[74];
    let be;
    e[75] !== k || e[76] !== l || e[77] !== Be || e[78] !== G || e[79] !== se || e[80] !== pe || e[81] !== fe ? (be = t.jsx(Vn, {
        onSubmit: l,
        disabled: Be,
        name: "name_user_message",
        hasModError: G,
        value: se,
        placeholder: pe,
        onChange: fe,
        size: "sm",
        showCharacterCount: !1,
        autoHighlight: k
    }), e[75] = k, e[76] = l, e[77] = Be, e[78] = G, e[79] = se, e[80] = pe, e[81] = fe, e[82] = be) : be = e[82];
    let Te;
    e[83] !== He || e[84] !== be ? (Te = t.jsx($n, {
        title: He,
        className: "pt-5",
        children: be
    }), e[83] = He, e[84] = be, e[85] = Te) : Te = e[85];
    let Oe;
    e[86] !== u ? (Oe = u.formatMessage(Re.occupationInputTitle), e[86] = u, e[87] = Oe) : Oe = e[87];
    let We;
    e[88] !== I || e[89] !== u || e[90] !== i.roleUserMessage || e[91] !== F || e[92] !== _ ? (We = !((Vt = i.roleUserMessage) != null ? Vt : _) && t.jsx(ic, {
        mode: "wait",
        children: t.jsx(rc.span, {
            variants: Jd,
            initial: I ? !1 : "initial",
            animate: "animate",
            exit: "exit",
            className: "pointer-events-none absolute start-[0.81rem] top-[0.55rem] text-sm text-gray-400",
            children: u.formatMessage(eu[Pa[F]])
        }, Pa[F])
    }), e[88] = I, e[89] = u, e[90] = i.roleUserMessage, e[91] = F, e[92] = _, e[93] = We) : We = e[93];
    const Ve = !P,
        ot = d === "role_user_message",
        Ze = (Ms = i.roleUserMessage) != null ? Ms : _;
    let Fe;
    e[94] !== i || e[95] !== c || e[96] !== a ? (Fe = Je => fn({
        userContextData: a,
        updates: {
            roleUserMessage: Je.target.value
        },
        localUserContext: i,
        setLocalUserContext: c
    }), e[94] = i, e[95] = c, e[96] = a, e[97] = Fe) : Fe = e[97];
    let Ge;
    e[98] !== l || e[99] !== Ve || e[100] !== ot || e[101] !== Ze || e[102] !== Fe ? (Ge = t.jsx(Vn, {
        onSubmit: l,
        name: "role_user_message",
        disabled: Ve,
        hasModError: ot,
        value: Ze,
        placeholder: "",
        onChange: Fe,
        size: "sm",
        showCharacterCount: !1
    }), e[98] = l, e[99] = Ve, e[100] = ot, e[101] = Ze, e[102] = Fe, e[103] = Ge) : Ge = e[103];
    let Xe;
    e[104] !== We || e[105] !== Ge ? (Xe = t.jsxs("div", {
        className: "relative overflow-clip",
        children: [We, Ge]
    }), e[104] = We, e[105] = Ge, e[106] = Xe) : Xe = e[106];
    let X;
    e[107] !== Oe || e[108] !== Xe ? (X = t.jsx($n, {
        title: Oe,
        className: "pt-7",
        children: Xe
    }), e[107] = Oe, e[108] = Xe, e[109] = X) : X = e[109];
    let re;
    e[110] !== u ? (re = u.formatMessage(Re.moreDetailsInputTitle), e[110] = u, e[111] = re) : re = e[111];
    const we = !P,
        te = d === "other_user_message",
        oe = ($t = i.otherUserMessage) != null ? $t : T;
    let le;
    e[112] !== u ? (le = u.formatMessage(Re.customizeOtherPlaceholder), e[112] = u, e[113] = le) : le = e[113];
    let he;
    e[114] !== i || e[115] !== c || e[116] !== a ? (he = Je => fn({
        userContextData: a,
        updates: {
            otherUserMessage: Je.target.value
        },
        localUserContext: i,
        setLocalUserContext: c
    }), e[114] = i, e[115] = c, e[116] = a, e[117] = he) : he = e[117];
    let H;
    e[118] !== l || e[119] !== we || e[120] !== te || e[121] !== oe || e[122] !== le || e[123] !== he ? (H = t.jsx(Vn, {
        onSubmit: l,
        disabled: we,
        name: "other_user_message",
        hasModError: te,
        value: oe,
        placeholder: le,
        onChange: he,
        size: "sm",
        showCharacterCount: !1,
        isNewCustomInstructionsUIEnabled: !0,
        dynamicHeight: !0
    }), e[118] = l, e[119] = we, e[120] = te, e[121] = oe, e[122] = le, e[123] = he, e[124] = H) : H = e[124];
    let ue;
    e[125] !== re || e[126] !== H ? (ue = t.jsx($n, {
        title: re,
        className: "pt-7",
        children: H
    }), e[125] = re, e[126] = H, e[127] = ue) : ue = e[127];
    let _e;
    e[128] !== Ce || e[129] !== Te || e[130] !== X || e[131] !== ue ? (_e = t.jsxs(Ne, {
        title: Ce,
        children: [Te, X, ue]
    }), e[128] = Ce, e[129] = Te, e[130] = X, e[131] = ue, e[132] = _e) : _e = e[132];
    let st;
    return e[133] !== xe || e[134] !== _e ? (st = t.jsxs(t.Fragment, {
        children: [xe, _e]
    }), e[133] = xe, e[134] = _e, e[135] = st) : st = e[135], st
}

function op(s) {
    return (s + 1) % Pa.length
}

function ip(s) {
    return s.autoHighlightNicknameInput
}

function rp() {
    "use no forget";
    var re, we, te, oe, le, he;
    const s = ve(),
        [e, a] = w.useState(!1),
        n = w.useCallback(() => {
            if (typeof window < "u") {
                const H = document.getElementById("memory-modal");
                H && H.scrollIntoView({
                    block: "start"
                })
            }
            a(!0)
        }, []),
        o = K(),
        i = bs(),
        c = zd(),
        l = Hd(),
        {
            isLoading: d,
            data: r
        } = Qe(() => za(s)),
        u = kt(),
        f = kt(!0),
        p = Za(),
        {
            data: g
        } = Wd({
            includeMemoryEntries: !1,
            enabled: c
        }),
        h = Vi(),
        y = $i(),
        x = Vd(s),
        j = $d(),
        v = Kd(),
        S = Ki(),
        C = qi(s),
        {
            data: M,
            isLoading: E
        } = Et(ie.BrowserReferenceWebHistoryInChat),
        N = M !== void 0,
        k = f.isPending && ((re = f.variables) == null ? void 0 : re.setting) === ie.BrowserReferenceWebHistoryInChat,
        {
            isLoading: P
        } = Et(ie.Sunshine),
        {
            isLoading: L
        } = Et(ie.Moonshine),
        {
            mutate: A,
            isPending: _
        } = kt(!0),
        {
            mutate: D,
            isPending: T
        } = kt(!0),
        F = kt(!0),
        O = ga(s),
        I = O == null ? void 0 : O.hasPlusFeatures(),
        U = je(s, "1900515849"),
        R = qd(s),
        B = Yd(s, (we = g == null ? void 0 : g.memoryFullPct) != null ? we : 0) !== "control",
        z = w.useCallback(() => {
            var H;
            Ue.logEventWithStatsig("Memories Upgrade Link Clicked", "chatgpt_memories_upgrade_link_clicked_settings", {
                memory_full_pct: (H = g == null ? void 0 : g.memoryFullPct) != null ? H : 0
            }), Qa(i, "memory_settings_upgrade_link")
        }, [g == null ? void 0 : g.memoryFullPct, i]),
        V = Pi(s, "1704793646").get("full_name_llm", !1),
        J = Us(),
        ce = Ct(),
        ae = je(s, "1804926979") && je(s, "3365913332"),
        [Z, $] = w.useState(null),
        [ee, de] = w.useState(b({}, Yi));
    w.useEffect(() => {
        var H, ue;
        if (!(typeof window > "u")) try {
            ((H = window.sessionStorage) == null ? void 0 : H.getItem(Bo)) === "true" && ((ue = window.sessionStorage) == null || ue.removeItem(Bo), n())
        } catch (_e) {}
    }, [n]), w.useEffect(() => {
        const H = () => {
            n()
        };
        return window.addEventListener("personalization:show-memories-modal", H), () => window.removeEventListener("personalization:show-memories-modal", H)
    }, [n]);
    const {
        isPending: ye,
        mutate: ze
    } = Xm({
        onSuccess: H => {
            sc.setCookie(nc.GreetingName, ac(H, J, V)), window.dispatchEvent(new Event("refreshGreeting"))
        },
        onError: H => {
            var ue, _e, st;
            return ((ue = H.response) == null ? void 0 : ue.reason) === "content_policy" && ((_e = H.response) != null && _e.field) ? $((st = H.response) == null ? void 0 : st.field) : ce.danger(o.formatMessage({
                id: "userContextModal.saveError",
                defaultMessage: "Failed to update settings"
            }), {
                loggingTitle: "Failed to update settings",
                toastId: "user_context_modal"
            }), H
        }
    }), {
        nameUserMessage: Le,
        roleUserMessage: Me,
        traitsModelMessage: me,
        otherUserMessage: xe,
        disabledTools: Ce,
        enabled: He
    } = Qi(r), {
        aboutUserMessage: Be,
        aboutModelMessage: G,
        nameUserMessage: se,
        roleUserMessage: pe,
        traitsModelMessage: fe,
        otherUserMessage: be,
        disabledTools: Te,
        enabled: Oe
    } = ee, We = w.useMemo(() => [se, pe, fe, be].some(H => Qd(H != null ? H : "")), [se, pe, fe, be]), Ve = w.useMemo(() => [{
        local: se,
        server: Le
    }, {
        local: pe,
        server: Me
    }, {
        local: fe,
        server: me
    }, {
        local: be,
        server: xe
    }].some(({
        local: ue,
        server: _e
    }) => ue !== void 0 && ue !== _e) || Te !== void 0 && !Jl(Te, Ce) || Oe !== void 0 && Oe !== He, [Le, Me, me, xe, se, pe, fe, be, Te, Ce, Oe, He]), {
        conversationId: ot = null
    } = kr(), Ze = ot, Fe = ec(Ze, H => mc.getLastAssistantMessage(H)), Ge = Qe(() => Ze ? tc(s, Ze).serverId$() : void 0), Xe = en(() => {
        if (!ye) {
            $(null);
            const H = {
                    aboutUserMessage: Be != null ? Be : "",
                    aboutModelMessage: G != null ? G : "",
                    nameUserMessage: se != null ? se : "",
                    roleUserMessage: pe != null ? pe : "",
                    traitsModelMessage: fe != null ? fe : "",
                    otherUserMessage: be != null ? be : "",
                    disabledTools: Te != null ? Te : [],
                    enabled: !!Oe
                },
                ue = {
                    name: Le,
                    role: Me,
                    traits: me,
                    other: xe
                },
                _e = {
                    name: H.nameUserMessage,
                    role: H.roleUserMessage,
                    traits: H.traitsModelMessage,
                    other: H.otherUserMessage
                },
                st = es(s);
            fe !== ue.traits && st.success(o.formatMessage({
                id: "KVhWun",
                defaultMessage: "Custom instructions updated"
            }), {
                duration: 4,
                hasCloseButton: !0
            }), Ue.logEvent("User Context Save Customize ChatGPT", {
                previousState: ue,
                newState: _e
            }), $a.logEvent("chatgpt_user_context_save_custom_instructions", void 0, {
                previousState: JSON.stringify(ue),
                newState: JSON.stringify(_e)
            }), ze({
                userContext: H,
                conversationId: Ge != null ? Ge : null,
                messageId: Fe == null ? void 0 : Fe.id
            })
        }
    }), X = en(() => {
        if (We) {
            ce.danger(o.formatMessage(Re.messageLimitError, {
                limit: Zd
            }), {
                duration: 4,
                hasCloseButton: !0,
                loggingTitle: "Message limit error",
                toastId: "user_context_modal",
                loggingDescription: Re.messageLimitError.defaultMessage
            });
            return
        }
        Xe()
    });
    return w.useEffect(() => {
        Ue.logEventWithStatsig("User Context Custom Instructions Modal Opened", "chatgpt_user_context_custom_instructions_modal_opened", {
            location: "personalization_settings"
        })
    }, []), d ? t.jsx("div", {
        className: "flex justify-center p-6",
        children: t.jsx(ys, {})
    }) : t.jsxs(t.Fragment, {
        children: [t.jsx(ap, {
            conversationId: Ge != null ? Ge : null,
            messageId: (te = Fe == null ? void 0 : Fe.id) != null ? te : null,
            userContextData: r,
            localUserContext: ee,
            setLocalUserContext: de,
            onSubmit: X,
            hasModError: Z
        }), l && t.jsxs(t.Fragment, {
            children: [t.jsx("div", {
                id: "memory-modal"
            }), t.jsxs(Ne, {
                noBorder: !0,
                title: R ? t.jsxs("div", {
                    className: "flex items-center gap-1",
                    children: [t.jsx("span", {
                        children: o.formatMessage(Re.memoryTitle)
                    }), t.jsx(zu, {
                        memoryFullPct: g == null ? void 0 : g.memoryFullPct
                    })]
                }) : o.formatMessage(Re.memoryTitle),
                description: B && (((oe = g == null ? void 0 : g.memoryFullPct) != null ? oe : 0) < ni ? t.jsx(m, {
                    id: "GiIDzv",
                    defaultMessage: "Responses may feel less personalized soon. For more memory, <upgradeLink>upgrade to Plus.</upgradeLink>",
                    values: {
                        upgradeLink: H => t.jsx("button", {
                            type: "button",
                            className: "text-token-interactive-label-accent-default hover:text-token-interactive-label-accent-hover hover:underline",
                            onClick: ue => {
                                ue.preventDefault(), z()
                            },
                            children: H
                        })
                    }
                }) : t.jsx(m, {
                    id: "Z4GyWA",
                    defaultMessage: "New memories can’t be saved, so responses may feel less personalized. For more memory, <upgradeLink>upgrade to Plus.</upgradeLink>",
                    values: {
                        upgradeLink: H => t.jsx("button", {
                            type: "button",
                            className: "text-token-interactive-label-accent-default hover:text-token-interactive-label-accent-hover hover:underline",
                            onClick: ue => {
                                ue.preventDefault(), z()
                            },
                            children: H
                        })
                    }
                })),
                learnMoreHref: "https://help.openai.com/en/articles/8590148-memory-faq",
                headerTrailingContent: t.jsx("div", {
                    className: "flex flex-row gap-2",
                    children: t.jsx(ne, {
                        color: "secondary",
                        onClick: () => {
                            Ue.logEventWithStatsig("Manage Memories Button Clicked", "chatgpt_manage_memories_button_clicked_settings"), a(!0)
                        },
                        size: "small",
                        children: t.jsx(m, b({}, Re.manageButton))
                    })
                }),
                children: [R && t.jsx("div", {
                    className: "border-token-border-light flex border-b"
                }), !R && ((le = g == null ? void 0 : g.memoryFullPct) != null ? le : 0) >= Jm && t.jsxs("div", {
                    className: "border-token-border-light flex flex-col gap-[2px] border-b pb-2",
                    children: [t.jsx(Hu, {
                        memoryFullPct: g == null ? void 0 : g.memoryFullPct,
                        showInfoLabel: !1,
                        onManageMemories: () => {
                            a(!0)
                        }
                    }), t.jsx("div", {
                        className: "text-token-text-tertiary my-1.5 text-xs",
                        children: ((he = g == null ? void 0 : g.memoryFullPct) != null ? he : 0) < ni ? I ? t.jsx(m, {
                            id: "SrHwDd",
                            defaultMessage: "Once memory is full, responses may feel less personalized. Manage existing memories to free up space."
                        }) : t.jsx(m, {
                            id: "eczLio",
                            defaultMessage: "Once memory is full, responses may feel less personalized. Upgrade to expand memory, or manage existing memories."
                        }) : I ? t.jsx(m, {
                            id: "ho9xyz",
                            defaultMessage: "New memories can't be saved, so responses may feel less personalized. Manage existing memories to free up space."
                        }) : t.jsx(m, {
                            id: "s+OVoX",
                            defaultMessage: "New memories can't be saved, so responses may feel less personalized. Upgrade to expand memory, or manage existing memories."
                        })
                    })]
                }), t.jsxs(Q, {
                    children: [t.jsx(ct, {
                        label: o.formatMessage(Re.toggleLabel),
                        enabled: c,
                        disabled: (p == null ? void 0 : p[ie.Sunshine]) === !0,
                        isLoading: P || _,
                        onChange: H => {
                            A({
                                setting: ie.Sunshine,
                                value: H
                            }, {
                                onSuccess: () => {
                                    Ue.logEventWithStatsig("Personalization Settings Saved Memories ".concat(H ? "Enabled" : "Disabled"), "chatgpt_personalization_settings_saved_memories_".concat(H ? "enabled" : "disabled")), !H && c ? (x && I && F.mutate({
                                        setting: ie.GoldenHour,
                                        value: !1
                                    }), j && v && D({
                                        setting: ie.Moonshine,
                                        value: !1
                                    }), y && h && u.mutate({
                                        setting: ie.MemoryInSearch,
                                        value: !1
                                    }), N && M && f.mutate({
                                        setting: ie.BrowserReferenceWebHistoryInChat,
                                        value: !1
                                    })) : H && (j && D({
                                        setting: ie.Moonshine,
                                        value: !0
                                    }), x && I && F.mutate({
                                        setting: ie.GoldenHour,
                                        value: !0
                                    }), N && f.mutate({
                                        setting: ie.BrowserReferenceWebHistoryInChat,
                                        value: !0
                                    }))
                                }
                            })
                        }
                    }), t.jsx(yn, {
                        children: t.jsx(m, b({}, Re.exampleDescription))
                    })]
                }), c && N && t.jsx(Q, {
                    children: t.jsx(ct, {
                        label: o.formatMessage({
                            id: "1Ma0kL",
                            defaultMessage: "Reference browser memories"
                        }),
                        enabled: !!M,
                        isLoading: E || k,
                        onChange: H => {
                            f.mutate({
                                setting: ie.BrowserReferenceWebHistoryInChat,
                                value: H
                            })
                        },
                        disabled: (p == null ? void 0 : p[ie.BrowserReferenceWebHistoryInChat]) === !0,
                        description: t.jsx(m, {
                            id: "C4+9kG",
                            defaultMessage: "Let ChatGPT reference key details from your ChatGPT Atlas web browsing. You can manage your browser memories in Atlas. {learnMoreLink}",
                            values: {
                                learnMoreLink: t.jsx(Ln, {
                                    href: "https://help.openai.com/en/articles/12574142-chatgpt-atlas-data-controls-and-privacy",
                                    className: "underline",
                                    children: t.jsx(m, {
                                        id: "kgGuAd",
                                        defaultMessage: "Learn more"
                                    })
                                })
                            }
                        })
                    })
                }), c && j && t.jsx(Q, {
                    children: t.jsx(ct, {
                        label: o.formatMessage({
                            id: "2qTSAN",
                            defaultMessage: "Reference chat history"
                        }),
                        enabled: v,
                        isLoading: L || T,
                        onChange: H => {
                            Ue.logEventWithStatsig("Personalization Settings Reference Recent Conversations ".concat(H ? "Enabled" : "Disabled"), "chatgpt_personalization_settings_reference_recent_conversations_".concat(H ? "enabled" : "disabled")), D({
                                setting: ie.Moonshine,
                                value: H
                            })
                        },
                        disabled: !j || (p == null ? void 0 : p[ie.Moonshine]) === !0,
                        description: I ? t.jsx(m, {
                            id: "poYymi",
                            defaultMessage: "Let ChatGPT reference all previous conversations when responding."
                        }) : t.jsx(m, {
                            id: "kZ8Ljp",
                            defaultMessage: "Let ChatGPT reference recent conversations when responding."
                        })
                    })
                }), S && !C && t.jsx(Q, {
                    children: t.jsx("div", {
                        className: "text-token-text-tertiary pe-12 text-xs",
                        children: t.jsx(m, {
                            id: "iCZODP",
                            defaultMessage: "ChatGPT may use Memory to personalize queries to search providers, such as Bing. {learnMoreLink}",
                            values: {
                                learnMoreLink: t.jsx(Ln, {
                                    href: "https://help.openai.com/en/articles/9237897-chatgpt-search",
                                    className: "underline",
                                    children: t.jsx(m, {
                                        id: "0M5wS5",
                                        defaultMessage: "Learn more"
                                    })
                                })
                            }
                        })
                    })
                }), e && (R ? t.jsx(Uu, {
                    isOpen: e,
                    onClose: () => a(!1)
                }) : U ? t.jsx(Gu, {
                    onClose: () => a(!1)
                }) : t.jsx(Wu, {
                    onClose: () => a(!1)
                }))]
            })]
        }), Xd(s) && t.jsx(ep, {}), ae && t.jsx(tp, {}), t.jsx(sp, {
            disabledTools: Ce,
            userContextData: r,
            localUserContext: ee,
            setLocalUserContext: de
        }), Ve && t.jsx(lp, {
            setLocalUserContext: de,
            isMutationLoading: ye,
            onSubmit: X,
            isAnyMessagePastLimit: We,
            hasUnsavedChanges: Ve
        })]
    })
}

function lp({
    setLocalUserContext: s,
    isMutationLoading: e,
    onSubmit: a,
    isAnyMessagePastLimit: n,
    hasUnsavedChanges: o
}) {
    return t.jsx("div", {
        className: "bg-token-main-surface-primary sticky bottom-0 flex min-h-21 items-center justify-end border-t px-4",
        children: t.jsxs("footer", {
            className: "flex gap-2",
            children: [t.jsx(jo.Button, {
                onClick: () => s(Yi),
                children: t.jsx(m, b({}, Re.cancel))
            }), t.jsx(jo.Button, {
                loading: e,
                onClick: a,
                color: "primary",
                visuallyDisabled: n,
                disabled: !o,
                children: t.jsx(m, b({}, Re.save))
            })]
        })
    })
}

function cp() {
    "use forget";
    const s = Se.c(8),
        {
            signInForReauth: e
        } = Fu(),
        [a, n] = w.useState(!1),
        o = dp;
    let i;
    s[0] !== e ? (i = async u => (await e({
        callbackUrl: u,
        authorizationParams: {
            post_login_password_reset: "true"
        }
    }), !0), s[0] = e, s[1] = i) : i = s[1];
    const c = i;
    let l;
    s[2] !== c || s[3] !== a ? (l = async () => {
        if (a) return !1;
        n(!0);
        const f = new URL("/", o()).toString();
        return await c(f) ? !0 : (n(!1), !1)
    }, s[2] = c, s[3] = a, s[4] = l) : l = s[4];
    const d = l;
    let r;
    return s[5] !== a || s[6] !== d ? (r = {
        startChangePasswordFlow: d,
        isChangePasswordLoading: a
    }, s[5] = a, s[6] = d, s[7] = r) : r = s[7], r
}

function dp() {
    var e;
    return typeof window < "u" && !!((e = window.location) != null && e.origin) ? window.location.origin : "https://chatgpt.com"
}
const up = 0,
    gp = 150,
    Bt = Ke({
        placeholder: {
            id: "settingsModal.birthdayPlaceholder",
            defaultMessage: "MM / DD / YYYY"
        },
        add: {
            id: "settingsModal.birthday.add",
            defaultMessage: "Add"
        },
        edit: {
            id: "settingsModal.birthday.edit",
            defaultMessage: "Edit"
        },
        addAria: {
            id: "settingsModal.birthday.addAria",
            defaultMessage: "Add your date of birth"
        },
        editAria: {
            id: "settingsModal.birthday.editAria",
            defaultMessage: "Edit your date of birth"
        },
        cancel: {
            id: "settingsModal.birthday.cancel",
            defaultMessage: "Cancel"
        },
        confirm: {
            id: "settingsModal.birthday.confirm",
            defaultMessage: "Confirm"
        },
        verifyAgeTitle: {
            id: "settingsModal.birthday.verifyAgeTitle",
            defaultMessage: "Verify your age"
        },
        verifyAgeDescription: {
            id: "settingsModal.birthday.verifyAgeDescription",
            defaultMessage: "To make changes, we need to verify your age."
        },
        verifyAgeButton: {
            id: "settingsModal.birthday.verifyAgeButton",
            defaultMessage: "Verify age"
        },
        ageVerifiedTooltip: {
            id: "settingsModal.birthday.ageVerifiedTooltip",
            defaultMessage: "Age verified"
        },
        errorInvalid: {
            id: "settingsModal.birthday.error.invalid",
            defaultMessage: "Invalid birthdate"
        },
        birthdayUpdated: {
            id: "settingsModal.birthday.updated",
            defaultMessage: "You updated your date of birth"
        },
        ageVerificationPendingTooltip: {
            id: "settingsModal.birthday.ageVerificationPendingTooltip",
            defaultMessage: "Your age is verified and will update soon."
        },
        provideRightSettingsText: {
            id: "settingsModal.birthday.provideRightSettingsText",
            defaultMessage: "provide the right settings"
        },
        provideRightSettingsTextUnder18: {
            id: "settingsModal.birthday.provideRightSettingsTextUnder18",
            defaultMessage: "provide age-appropriate settings"
        }
    });

function ai(s) {
    "use forget";
    const e = Se.c(126),
        {
            birthday: a,
            onSave: n,
            userIsAdultData: o
        } = s,
        i = K(),
        c = ve();
    let l;
    e[0] !== c ? (l = es(c), e[0] = c, e[1] = l) : l = e[1];
    const d = l,
        r = w.useRef(null),
        [u, f] = w.useState(!1);
    let p;
    e[2] !== a ? (p = () => Jn(a), e[2] = a, e[3] = p) : p = e[3];
    const [g, h] = w.useState(p), [y, x] = w.useState(!1), [j, v] = w.useState(!1), [S, C] = w.useState(!1), [M, E] = w.useState(a), [N, k] = w.useState(!1), [P, L] = w.useState(!1), A = w.useId(), _ = w.useId(), D = w.useId(), T = en(n);
    let F;
    e[4] !== g ? (F = mp(g), e[4] = g, e[5] = F) : F = e[5];
    const O = F,
        {
            mutate: I
        } = pc(),
        U = O.type === "valid",
        R = y && O.type === "error" ? O.error : null;
    let B;
    e[6] !== a || e[7] !== i ? (B = a ? Jn(a) : i.formatMessage(Bt.add), e[6] = a, e[7] = i, e[8] = B) : B = e[8];
    const z = B;
    let W;
    e[9] !== i ? (W = i.formatMessage(Bt.placeholder), e[9] = i, e[10] = W) : W = e[10];
    const V = W,
        J = !!(o != null && o.has_verified_age_or_dob),
        ce = (o == null ? void 0 : o.is_adult) === !1,
        ae = !J && (o == null ? void 0 : o.is_adult) === !1;
    let Z, $;
    e[11] !== I || e[12] !== c || e[13] !== j ? (Z = () => {
        if (!j) return;
        const X = re => {
            v(!1), k(!1), re === "completed" && (I(), L(!0))
        };
        return Vu(c, {
            onCancel: () => {
                X("canceled")
            },
            onComplete: () => {
                X("completed")
            },
            onLoad: () => {
                k(!0)
            }
        })
    }, $ = [j, c, I], e[11] = I, e[12] = c, e[13] = j, e[14] = Z, e[15] = $) : (Z = e[14], $ = e[15]), w.useEffect(Z, $);
    let ee, de;
    e[16] !== u ? (ee = () => {
        if (!u) return;
        const X = requestAnimationFrame(() => {
            var re;
            (re = r.current) == null || re.focus()
        });
        return () => cancelAnimationFrame(X)
    }, de = [u], e[16] = u, e[17] = ee, e[18] = de) : (ee = e[17], de = e[18]), w.useEffect(ee, de), M !== a && a && S && (E(a), C(!1));
    let ye;
    e[19] === Symbol.for("react.memo_cache_sentinel") ? (ye = function() {
        f(!1)
    }, e[19] = ye) : ye = e[19];
    const ze = ye;
    let Le;
    e[20] !== a ? (Le = function() {
        ze(), h(Jn(a)), x(!1)
    }, e[20] = a, e[21] = Le) : Le = e[21];
    const Me = Le;
    let me;
    e[22] !== i || e[23] !== T || e[24] !== d || e[25] !== O.isoValue || e[26] !== O.type ? (me = function(re) {
        re.preventDefault(), C(!0), x(!0), O.type === "valid" && (ze(), T(O.isoValue).then(() => {
            d.success(i.formatMessage(Bt.birthdayUpdated))
        }))
    }, e[22] = i, e[23] = T, e[24] = d, e[25] = O.isoValue, e[26] = O.type, e[27] = me) : me = e[27];
    const xe = me;
    let Ce;
    e[28] === Symbol.for("react.memo_cache_sentinel") ? (Ce = function() {
        v(!0)
    }, e[28] = Ce) : Ce = e[28];
    const He = Ce;
    let Be;
    e[29] === Symbol.for("react.memo_cache_sentinel") ? (Be = t.jsx("a", {
        href: "https://openai.com/policies/privacy-policy/",
        className: "underline",
        target: "_blank",
        rel: "noopener noreferrer",
        children: t.jsx(m, {
            id: "settingsModal.verify-age.privacy-policy-link",
            defaultMessage: "Privacy Policy"
        })
    }), e[29] = Be) : Be = e[29];
    let G;
    e[30] !== i || e[31] !== ce ? (G = ce ? i.formatMessage(Bt.provideRightSettingsTextUnder18) : i.formatMessage(Bt.provideRightSettingsText), e[30] = i, e[31] = ce, e[32] = G) : G = e[32];
    let se;
    e[33] !== G ? (se = t.jsx(yn, {
        children: t.jsx(m, {
            id: "settingsModal.verify-age.description",
            defaultMessage: "This helps us personalize your experience and {provide_right_settings_text}, in line with our {privacy_policy_link}.",
            values: {
                privacy_policy_link: Be,
                provide_right_settings_text: G
            }
        })
    }), e[33] = G, e[34] = se) : se = e[34];
    const pe = se;
    if (P) {
        let X;
        e[35] !== i ? (X = i.formatMessage(Bt.ageVerificationPendingTooltip), e[35] = i, e[36] = X) : X = e[36];
        const re = X;
        let we;
        e[37] === Symbol.for("react.memo_cache_sentinel") ? (we = t.jsx(m, {
            id: "settingsModal.birthday",
            defaultMessage: "Date of birth"
        }), e[37] = we) : we = e[37];
        let te;
        e[38] !== A ? (te = t.jsx("div", {
            id: A,
            className: "text-sm font-medium",
            children: we
        }), e[38] = A, e[39] = te) : te = e[39];
        let oe;
        e[40] === Symbol.for("react.memo_cache_sentinel") ? (oe = t.jsx("span", {
            children: t.jsx(m, {
                id: "settingsModal.birthday.ageVerificationPendingLabel",
                defaultMessage: "Pending"
            })
        }), e[40] = oe) : oe = e[40];
        let le;
        e[41] !== re ? (le = t.jsx("span", {
            className: "sr-only",
            children: re
        }), e[41] = re, e[42] = le) : le = e[42];
        let he;
        e[43] === Symbol.for("react.memo_cache_sentinel") ? (he = t.jsx(Ha, {
            "aria-hidden": !0,
            className: "icon-md text-token-text-tertiary"
        }), e[43] = he) : he = e[43];
        let H;
        e[44] !== re ? (H = t.jsx(Wt, {
            label: re,
            children: he
        }), e[44] = re, e[45] = H) : H = e[45];
        let ue;
        e[46] !== le || e[47] !== H ? (ue = t.jsxs("div", {
            className: "text-token-text-primary flex items-center gap-2 text-sm font-medium",
            children: [oe, t.jsxs("div", {
                className: "flex items-center gap-1",
                children: [le, H]
            })]
        }), e[46] = le, e[47] = H, e[48] = ue) : ue = e[48];
        let _e;
        return e[49] !== te || e[50] !== ue ? (_e = t.jsx("div", {
            className: "flex flex-col gap-1",
            children: t.jsxs("div", {
                className: "flex items-center justify-between gap-4",
                children: [te, ue]
            })
        }), e[49] = te, e[50] = ue, e[51] = _e) : _e = e[51], _e
    }
    if (ae) {
        let X;
        e[52] === Symbol.for("react.memo_cache_sentinel") ? (X = t.jsx(m, {
            id: "settingsModal.ageVerification",
            defaultMessage: "Age verification"
        }), e[52] = X) : X = e[52];
        let re;
        e[53] !== A ? (re = t.jsx("div", {
            id: A,
            className: "text-sm font-medium",
            children: X
        }), e[53] = A, e[54] = re) : re = e[54];
        let we;
        e[55] === Symbol.for("react.memo_cache_sentinel") ? (we = t.jsx(yn, {
            children: t.jsx(m, {
                id: "settingsModal.verify-age.description2",
                defaultMessage: "Your ChatGPT experience includes safeguards for teens. If you’re 18 or older, you can verify your age. {learn_more_link}.",
                values: {
                    learn_more_link: t.jsx("a", {
                        href: "https://help.openai.com/en/articles/12652064-age-verification",
                        className: "underline",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        children: t.jsx(m, {
                            id: "settingsModal.verify-age.learn-more-link",
                            defaultMessage: "Learn more"
                        })
                    })
                }
            })
        }), e[55] = we) : we = e[55];
        let te;
        e[56] !== re ? (te = t.jsxs("div", {
            className: "flex flex-1 flex-col gap-2",
            children: [re, we]
        }), e[56] = re, e[57] = te) : te = e[57];
        const oe = j && !N;
        let le;
        e[58] === Symbol.for("react.memo_cache_sentinel") ? (le = t.jsx(m, b({}, Bt.verifyAgeButton)), e[58] = le) : le = e[58];
        let he;
        e[59] !== oe ? (he = t.jsx(ne, {
            type: "button",
            size: "medium",
            color: "primary",
            onClick: He,
            loading: oe,
            children: le
        }), e[59] = oe, e[60] = he) : he = e[60];
        let H;
        return e[61] !== te || e[62] !== he ? (H = t.jsx("div", {
            className: "flex flex-col gap-1",
            children: t.jsxs("div", {
                className: "flex items-start justify-between gap-4",
                children: [te, he]
            })
        }), e[61] = te, e[62] = he, e[63] = H) : H = e[63], H
    }
    if (J) {
        let X;
        e[64] !== i ? (X = i.formatMessage(Bt.ageVerifiedTooltip), e[64] = i, e[65] = X) : X = e[65];
        const re = X;
        let we;
        e[66] === Symbol.for("react.memo_cache_sentinel") ? (we = t.jsx(m, {
            id: "settingsModal.birthday",
            defaultMessage: "Date of birth"
        }), e[66] = we) : we = e[66];
        let te;
        e[67] !== A ? (te = t.jsx("div", {
            id: A,
            className: "text-sm font-medium",
            children: we
        }), e[67] = A, e[68] = te) : te = e[68];
        let oe;
        e[69] !== z ? (oe = t.jsx("span", {
            children: z
        }), e[69] = z, e[70] = oe) : oe = e[70];
        let le;
        e[71] !== re ? (le = t.jsx("span", {
            className: "sr-only",
            children: re
        }), e[71] = re, e[72] = le) : le = e[72];
        let he;
        e[73] === Symbol.for("react.memo_cache_sentinel") ? (he = t.jsx(hc, {
            "aria-hidden": !0,
            className: "icon-md text-token-text-tertiary"
        }), e[73] = he) : he = e[73];
        let H;
        e[74] !== re ? (H = t.jsx(Wt, {
            label: re,
            children: he
        }), e[74] = re, e[75] = H) : H = e[75];
        let ue;
        e[76] !== le || e[77] !== H ? (ue = t.jsxs("div", {
            className: "flex items-center gap-1",
            children: [le, H]
        }), e[76] = le, e[77] = H, e[78] = ue) : ue = e[78];
        let _e;
        e[79] !== oe || e[80] !== ue ? (_e = t.jsxs("div", {
            className: "text-token-text-tertiary flex items-center gap-2 text-sm font-medium",
            children: [oe, ue]
        }), e[79] = oe, e[80] = ue, e[81] = _e) : _e = e[81];
        let st;
        e[82] !== te || e[83] !== _e ? (st = t.jsxs("div", {
            className: "flex items-center justify-between gap-4",
            children: [te, _e]
        }), e[82] = te, e[83] = _e, e[84] = st) : st = e[84];
        let ht;
        return e[85] !== st || e[86] !== pe ? (ht = t.jsxs("div", {
            className: "flex flex-col gap-1",
            children: [st, pe]
        }), e[85] = st, e[86] = pe, e[87] = ht) : ht = e[87], ht
    }
    let fe;
    e[88] === Symbol.for("react.memo_cache_sentinel") ? (fe = t.jsx(m, {
        id: "settingsModal.birthday",
        defaultMessage: "Date of birth"
    }), e[88] = fe) : fe = e[88];
    let be;
    e[89] !== A ? (be = t.jsx("div", {
        id: A,
        className: "text-sm font-medium",
        children: fe
    }), e[89] = A, e[90] = be) : be = e[90];
    let Te;
    e[91] !== a ? (Te = X => {
        f(X), x(!1), h(Jn(a))
    }, e[91] = a, e[92] = Te) : Te = e[92];
    const Oe = a && "gap-1.5 text-token-text-tertiary";
    let We;
    e[93] !== Oe ? (We = Ht(Oe), e[93] = Oe, e[94] = We) : We = e[94];
    let Ve;
    e[95] !== a ? (Ve = a && t.jsx(Ya, {
        "aria-hidden": !0,
        className: "icon-sm text-token-text-secondary"
    }), e[95] = a, e[96] = Ve) : Ve = e[96];
    let ot;
    e[97] !== S || e[98] !== We || e[99] !== Ve || e[100] !== z ? (ot = t.jsx(De.BasicTrigger, {
        children: t.jsxs(ne, {
            color: "ghost",
            size: "medium",
            loading: S,
            contentWrapperClassName: We,
            children: [z, Ve]
        })
    }), e[97] = S, e[98] = We, e[99] = Ve, e[100] = z, e[101] = ot) : ot = e[101];
    let Ze;
    e[102] !== R || e[103] !== a || e[104] !== U || e[105] !== D || e[106] !== A || e[107] !== Me || e[108] !== xe || e[109] !== N || e[110] !== _ || e[111] !== g || e[112] !== j || e[113] !== V ? (Ze = t.jsx(De.Portal, {
        children: t.jsx(De.Content, {
            align: "end",
            size: "small",
            className: "border-token-border bg-token-bg-primary w-[min(360px,calc(100vw-2rem))] rounded-3xl border p-4 shadow-xl",
            children: a ? t.jsxs("div", {
                className: "flex flex-col gap-4",
                children: [t.jsxs("div", {
                    className: "flex flex-col gap-1",
                    children: [t.jsx("p", {
                        className: "text-base font-medium",
                        children: t.jsx(m, b({}, Bt.verifyAgeTitle))
                    }), t.jsx("p", {
                        className: "text-token-text-secondary text-sm",
                        children: t.jsx(m, b({}, Bt.verifyAgeDescription))
                    })]
                }), t.jsx("div", {
                    className: "flex justify-end",
                    children: t.jsx(ne, {
                        type: "button",
                        size: "large",
                        color: "primary",
                        onClick: () => He(),
                        loading: j && !N,
                        children: t.jsx(m, b({}, Bt.verifyAgeButton))
                    })
                })]
            }) : t.jsxs("form", {
                className: "flex flex-col gap-4",
                onSubmit: xe,
                children: [t.jsxs("div", {
                    className: "flex flex-col gap-2",
                    children: [t.jsx("label", {
                        htmlFor: _,
                        className: "text-token-text-primary text-sm font-medium",
                        children: t.jsx(m, {
                            id: "settingsModal.birthday",
                            defaultMessage: "Date of birth"
                        })
                    }), t.jsx("input", {
                        id: _,
                        ref: r,
                        type: "text",
                        inputMode: "numeric",
                        pattern: "[0-9/ ]*",
                        maxLength: 14,
                        name: "birthday",
                        autoComplete: "bday",
                        "aria-labelledby": A,
                        "aria-describedby": R ? D : void 0,
                        "aria-invalid": !!R,
                        className: Ht("bg-token-bg-tertiary/20 text-token-text-primary h-12 rounded-2xl border px-4 text-base outline-none focus:ring-2", R ? "border-token-border-error focus:ring-token-border-error" : "border-token-border hover:border-token-border-strong focus:ring-token-border-strong"),
                        placeholder: V,
                        value: g,
                        onChange: X => {
                            x(!0), h(fp(X.target.value))
                        }
                    }), R && t.jsx("p", {
                        id: D,
                        role: "alert",
                        className: "text-interactive-label-warning-secondary text-token-text-status-error text-xs",
                        children: t.jsx(m, b({}, Bt.errorInvalid))
                    })]
                }), t.jsxs("div", {
                    className: "flex justify-end gap-2",
                    children: [t.jsx(ne, {
                        type: "button",
                        color: "ghost",
                        size: "small",
                        onClick: Me,
                        children: t.jsx(m, b({}, Bt.cancel))
                    }), t.jsx(ne, {
                        type: "submit",
                        size: "small",
                        color: "primary",
                        disabled: !U,
                        children: t.jsx(m, b({}, Bt.confirm))
                    })]
                })]
            })
        })
    }), e[102] = R, e[103] = a, e[104] = U, e[105] = D, e[106] = A, e[107] = Me, e[108] = xe, e[109] = N, e[110] = _, e[111] = g, e[112] = j, e[113] = V, e[114] = Ze) : Ze = e[114];
    let Fe;
    e[115] !== u || e[116] !== Te || e[117] !== ot || e[118] !== Ze ? (Fe = t.jsxs(De.Root, {
        open: u,
        onOpenChange: Te,
        children: [ot, Ze]
    }), e[115] = u, e[116] = Te, e[117] = ot, e[118] = Ze, e[119] = Fe) : Fe = e[119];
    let Ge;
    e[120] !== be || e[121] !== Fe ? (Ge = t.jsxs("div", {
        className: "flex items-center justify-between gap-4",
        children: [be, Fe]
    }), e[120] = be, e[121] = Fe, e[122] = Ge) : Ge = e[122];
    let Xe;
    return e[123] !== Ge || e[124] !== pe ? (Xe = t.jsxs("div", {
        className: "flex flex-col gap-1",
        children: [Ge, pe]
    }), e[123] = Ge, e[124] = pe, e[125] = Xe) : Xe = e[125], Xe
}

function Jn(s) {
    if (!s) return "";
    const [e, a, n] = s.split("-");
    return !e || !a || !n ? "" : [a.padStart(2, "0"), n.padStart(2, "0"), e].join("/")
}

function fp(s) {
    const e = s.replace(/\D/g, "").slice(0, 8);
    if (e.length === 0) return "";
    let a = e.slice(0, 2),
        n = e.slice(2, 4),
        o = e.slice(4, 8);
    return (/^\s*\d{4}[^\d]?/.test(s) || e.length === 8 && Number.parseInt(e.slice(0, 4), 10) > 1900 && Number.parseInt(e.slice(4, 6), 10) <= 12 && Number.parseInt(e.slice(6, 8), 10) <= 31) && e.length === 8 && (o = e.slice(0, 4), a = e.slice(4, 6), n = e.slice(6, 8)), [a, n, o].filter(Boolean).join(" / ")
}

function mp(s) {
    const e = s.replace(/\D/g, "");
    if (e.length === 0) return {
        type: "empty"
    };
    if (e.length < 8) return {
        type: "incomplete"
    };
    const a = e.slice(0, 2),
        n = e.slice(2, 4),
        o = e.slice(4, 8);
    if (n.length !== 2 || a.length !== 2 || o.length !== 4) return {
        type: "error",
        error: "invalid"
    };
    const i = "".concat(o, "-").concat(a, "-").concat(n),
        c = new Date("".concat(i, "T00:00:00.000Z"));
    if (Number.isNaN(c.getTime()) || c.getUTCDate() !== Number.parseInt(n, 10) || c.getUTCMonth() + 1 !== Number.parseInt(a, 10) || c.getUTCFullYear() !== Number.parseInt(o, 10)) return {
        type: "error",
        error: "invalid"
    };
    const l = new Date;
    if (c > l) return {
        type: "error",
        error: "future"
    };
    const d = pp(c, l);
    return d < up ? {
        type: "error",
        error: "tooYoung"
    } : d >= gp ? {
        type: "error",
        error: "tooOld"
    } : {
        type: "valid",
        isoValue: i,
        age: d
    }
}

function pp(s, e) {
    let a = e.getUTCFullYear() - s.getUTCFullYear();
    const n = e.getUTCMonth() - s.getUTCMonth();
    return (n < 0 || n === 0 && e.getUTCDate() < s.getUTCDate()) && (a -= 1), a
}
const q = Ke({
    showLegacyModels: {
        id: "settingsModal.showLegacyModels",
        defaultMessage: "Show legacy models"
    },
    showAdditionalModels: {
        id: "settingsModal.showAdditionalModels",
        defaultMessage: "Show additional models"
    },
    settings: {
        id: "settingsModal.settings",
        defaultMessage: "General"
    },
    locale: {
        id: "settingsModal.locale_alpha",
        defaultMessage: "Language"
    },
    localeAuto: {
        id: "settingsModal.localeAuto",
        defaultMessage: "Auto-detect"
    },
    archivedConversations: {
        id: "settingsModal.archivedConversations",
        defaultMessage: "Archived chats"
    },
    sharedConversations: {
        id: "settingsModal.sharedConversations",
        defaultMessage: "Shared links"
    },
    manageButton: {
        id: "settingsModal.manageButton",
        defaultMessage: "Manage"
    },
    mergePersonalData: {
        id: "settingsModal.mergePersonalData",
        defaultMessage: "Merge data from your personal workspace"
    },
    mergeButton: {
        id: "settingsModal.mergeButton",
        defaultMessage: "Merge"
    },
    cookieManagement: {
        id: "settingsModal.cookieManagement",
        defaultMessage: "Cookie preferences"
    },
    cookieManagementButton: {
        id: "settingsModal.cookieManagementButton",
        defaultMessage: "Manage"
    },
    exportData: {
        id: "settingsModal.exportData",
        defaultMessage: "Export data"
    },
    exportButton: {
        id: "settingsModal.exportButton",
        defaultMessage: "Export"
    },
    deleteAccount: {
        id: "settingsModal.deleteAccount",
        defaultMessage: "Delete account"
    },
    deleteAccountButton: {
        id: "settingsModal.deleteButton",
        defaultMessage: "Delete"
    },
    modelStickyForNewChats: {
        id: "settingsModal.modelStickyForNewChats",
        defaultMessage: "Start new chats with most recently used model"
    },
    trainingAllowedDescription: {
        id: "Qalmv5",
        defaultMessage: "Allow your content to be used to train our models, which makes ChatGPT better for you and everyone who uses it. We take steps to protect your privacy. <link>Learn more</link>"
    },
    deleteHistoryModalTitle: {
        id: "settingsModal.deleteHistoryModalTitle",
        defaultMessage: "Clear your chat history - are you sure?"
    },
    deleteHistoryModalConfirm: {
        id: "settingsModal.deleteHistoryModalConfirm",
        defaultMessage: "Confirm deletion"
    },
    deleteHistoryModalCancel: {
        id: "settingsModal.deleteHistoryModalCancel",
        defaultMessage: "Cancel"
    },
    archiveHistoryModalTitle: {
        id: "settingsModal.archiveHistoryModalTitle",
        defaultMessage: "Archive your chat history - are you sure?"
    },
    archiveHistoryModalConfirm: {
        id: "settingsModal.archiveHistoryModalConfirm",
        defaultMessage: "Confirm archive"
    },
    archiveHistoryModalCancel: {
        id: "settingsModal.archiveHistoryModalCancel",
        defaultMessage: "Cancel"
    },
    archiveHistorySuccess: {
        id: "settingsModal.archiveHistorySuccess",
        defaultMessage: "Successfully archived chats. You can view your archived chats in Settings."
    },
    dataExportRequested: {
        id: "settingsModal.dataExportRequested",
        defaultMessage: "Successfully exported data. You should receive an email shortly with your data."
    },
    dataExportFailed: {
        id: "settingsModal.dataExportFailed",
        defaultMessage: "We were unable to process your export at this time. Please try again later."
    },
    dataExportModalTitle: {
        id: "settingsModal.dataExportModalTitle",
        defaultMessage: "Request data export - are you sure?"
    },
    dataExportModalConfirm: {
        id: "settingsModal.dataExportModalConfirm",
        defaultMessage: "Confirm export"
    },
    dataExportModalCancel: {
        id: "settingsModal.dataExportModalCancel",
        defaultMessage: "Cancel"
    },
    dataExportModalDescription1: {
        id: "settingsModal.dataExportModalDescription1",
        defaultMessage: "Your account details and chats will be included in the export."
    },
    dataExportModalDescription2: {
        id: "settingsModal.dataExportModalDescription2",
        defaultMessage: "The data will be sent to your registered email in a downloadable file."
    },
    dataExportModalDescription3: {
        id: "settingsModal.dataExportModalDescription3",
        defaultMessage: "The download link will expire 24 hours after you receive it."
    },
    dataExportModalDescription4: {
        id: "settingsModal.dataExportModalDescription4",
        defaultMessage: "Processing may take some time. You'll be notified when it's ready."
    },
    dataExportModalDescription5: {
        id: "settingsModal.dataExportModalDescription5",
        defaultMessage: 'To proceed, click "Confirm export" below.'
    },
    deleteAccountSessionTooOld: {
        id: "settingsModal.deleteAccountSessionTooOld",
        defaultMessage: "Your login session is too old. Please log in again before deleting your account."
    },
    deleteAccountFailed: {
        id: "settingsModal.deleteAccountFailed",
        defaultMessage: "Failed to delete account. Please try again later."
    },
    deleteAccountTitle: {
        id: "settingsModal.deleteAccountTitle",
        defaultMessage: "Delete account - are you sure?"
    },
    deleteAccountWarning: {
        id: "settingsModal.deleteAccountWarning",
        defaultMessage: "Deleting your account is permanent and cannot be undone."
    },
    reuseEmailPhoneWarning: {
        id: "settingsModal.reuseEmailPhoneWarning-2",
        defaultMessage: "You cannot create a new account using the same email address."
    },
    dataRemovalWarning: {
        id: "settingsModal.dataRemovalWarning-2",
        defaultMessage: "Your data will be deleted within 30 days, except we may retain a limited set of data for longer where required or permitted by law."
    },
    apiAccessDeletionWarning: {
        id: "settingsModal.apiAccessDeletionWarning-2",
        defaultMessage: "Deletion will prevent you from accessing OpenAI services, including ChatGPT, API, and DALL·E."
    },
    deleteHelpCenter: {
        id: "settingsModal.deleteHelpCenter",
        defaultMessage: "Read our <article>help center article</article> for more information."
    },
    iapSubscriptionWarning: {
        id: "settingsModal.iapSubscriptionWarning",
        defaultMessage: "You will need to cancel your in-app purchase subscription in the Apple App Store. We cannot cancel your subscription for you."
    },
    playStoreSubscriptionWarning: {
        id: "settingsModal.playStoreSubscriptionWarning",
        defaultMessage: "You will need to cancel your in-app purchase subscription in the Google Play Store. We cannot cancel your subscription for you."
    },
    typeEmailLabel: {
        id: "settingsModal.typeEmailLabel",
        defaultMessage: "Please type your account email."
    },
    typePhoneNumberLabel: {
        id: "settingsModal.typePhoneNumberLabel",
        defaultMessage: "Please type your account phone number."
    },
    typeDeleteInputLabel: {
        id: "settingsModal.typeDeleteInputLabel",
        defaultMessage: 'To proceed, type "{keyword}" in the input field below.'
    },
    deleteAccountKeyword: {
        id: "settingsModal.deleteAccountKeyword",
        defaultMessage: "DELETE"
    },
    lockedButtonLabel: {
        id: "settingsModal.lockedButtonLabel",
        defaultMessage: "Locked"
    },
    deleteAccountButtonLabel: {
        id: "settingsModal.deleteAccountButtonLabel",
        defaultMessage: "Permanently delete my account"
    },
    recentLoginMessage: {
        id: "settingsModal.recentLoginMessage",
        defaultMessage: "You may only delete your account if you have logged in within the last 10 minutes. Please log in again, then return here to continue."
    },
    refreshLoginButtonLabel: {
        id: "settingsModal.refreshLoginButtonLabel",
        defaultMessage: "Refresh login"
    },
    chatTrainingAllowedToggleLabel: {
        id: "settingsModal.trainingAllowedToggleLabel",
        defaultMessage: "Improve the model for everyone"
    },
    chatTrainingEnterpriseTooltip: {
        id: "settingsModal.chatTrainingEnterpriseTooltip",
        defaultMessage: "ChatGPT Enterprise automatically disables training."
    },
    chatTrainingEduTooltip: {
        id: "settingsModal.chatTrainingEduTooltip",
        defaultMessage: "ChatGPT Edu automatically disables training."
    },
    chatTrainingTeamsTooltip: {
        id: "settingsModal.chatTrainingTeamsTooltip",
        defaultMessage: "ChatGPT Business automatically disables training."
    },
    preciseLocationToggleLabel: {
        id: "dataControlsSettings.preciseLocationToggleLabel",
        defaultMessage: "Share precise location"
    },
    preciseLocationToggleDescription: {
        id: "dataControlsSettings.preciseLocationToggleDescriptionV2",
        defaultMessage: "Allow ChatGPT to use your device's precise location when providing information."
    },
    dataControlsTab: {
        id: "settingsModal.dataControls",
        defaultMessage: "Data controls"
    },
    schedulesTab: {
        id: "settingsModal.schedulesTab",
        defaultMessage: "Schedules"
    },
    cookiesTab: {
        id: "settingsModal.cookies",
        defaultMessage: "Cookie Preferences"
    },
    personalizationTab: {
        id: "settingsModal.personalization",
        defaultMessage: "Personalization"
    },
    personalityTab: {
        id: "settingsModal.personalityTab",
        defaultMessage: "Personality"
    },
    generalTab: {
        id: "settingsModal.generalTab",
        defaultMessage: "General"
    },
    desktopAppTab: {
        id: "settingsModal.desktopAppTab",
        defaultMessage: "App"
    },
    connectorsTabRevamp: {
        id: "settingsModal.connectorsTabRevamp",
        defaultMessage: "Connectors"
    },
    connectorsTabModelToolDiscovery: {
        id: "settingsModal.connectorsModelToolDiscovery",
        defaultMessage: "Apps & Connectors"
    },
    appsTab: {
        id: "settingsModal.appsTab",
        defaultMessage: "Apps"
    },
    securityTab: {
        id: "settingsModal.securityTab",
        defaultMessage: "Security"
    },
    loginMethodsSectionTitle: {
        id: "settingsModal.loginMethodsSectionTitle",
        defaultMessage: "Login methods"
    },
    passwordSettingLabel: {
        id: "settingsModal.passwordSettingLabel",
        defaultMessage: "Password"
    },
    passwordSettingMaskedValue: {
        id: "settingsModal.passwordSettingMaskedValue",
        defaultMessage: "******"
    },
    accountTab: {
        id: "settingsModal.accountTab",
        defaultMessage: "Account"
    },
    internalTab: {
        id: "settingsModal.internalTab",
        defaultMessage: "Employee Only"
    },
    subscriptionTab: {
        id: "settingsModal.subscriptionTab",
        defaultMessage: "Subscription"
    },
    logoutAllSuccess: {
        id: "settingsModal.logoutAllSuccess",
        defaultMessage: "Successfully logged out of all devices."
    },
    logoutAllFailed: {
        id: "settingsModal.logoutAllFailed",
        defaultMessage: "We were unable to process your request at this time. Please try again later."
    },
    accountInfoNameLabel: {
        id: "settingsModal.accountInfoNameLabel",
        defaultMessage: "Name"
    },
    accountInfoEmailAddAction: {
        id: "settingsModal.accountInfoEmailAddAction",
        defaultMessage: "Add"
    },
    accountInfoEmailLabel: {
        id: "settingsModal.accountInfoEmailLabel",
        defaultMessage: "Email"
    },
    deleteChatLabel: {
        id: "settingsModal.deleteChatLabel",
        defaultMessage: "Delete all chats"
    },
    deleteChatButton: {
        id: "settingsModal.deleteChatButton",
        defaultMessage: "Delete all"
    },
    logOutLabel: {
        id: "settingsModal.logOutLabel",
        defaultMessage: "Log out of this device"
    },
    logOutButton: {
        id: "settingsModal.logoutButton",
        defaultMessage: "Log out"
    },
    trustedDevices: {
        id: "settingsModal.trustedDevices",
        defaultMessage: "Trusted Devices"
    },
    deviceCodeAuthToggleLabel: {
        id: "settingsModal.deviceCodeAuthToggleLabel",
        defaultMessage: "Enable device code authorization for Codex"
    },
    deviceCodeAuthToggleDescription: {
        id: "settingsModal.deviceCodeAuthToggleDescription",
        defaultMessage: "Use device code sign-in for headless or remote environments where the normal browser flow isn’t available. Exercise caution in enabling, as device codes can be phished. Never share a device code."
    },
    archiveChatsLabel: {
        id: "settingsModal.archiveChatsLabel",
        defaultMessage: "Archive all chats"
    },
    archiveChatsButton: {
        id: "settingsModal.archiveChatsButton",
        defaultMessage: "Archive all"
    },
    remoteBrowserData: {
        id: "settingsModal.remoteBrowserData",
        defaultMessage: "Remote browser data"
    },
    remoteBrowserDataKeepLabel: {
        id: "settingsModal.remoteBrowserDataKeepLabel",
        defaultMessage: "Remember site data between sessions"
    },
    remoteBrowserDataKeepDescription: {
        id: "settingsModal.remoteBrowserDataKeepDescription",
        defaultMessage: "Let agent mode's remote browser reuse cookies between sessions."
    },
    remoteBrowserDataSitesLabel: {
        id: "settingsModal.remoteBrowserDataSitesLabel",
        defaultMessage: "{count} {count, plural, one {site} other {sites}}"
    },
    chatHistoryDescription: {
        id: "settingsModal.chatHistoryDescription",
        defaultMessage: "Save new chats on this browser to your history and allow them to be used to improve our models. Unsaved chats will be deleted from our systems within 30 days. This setting does not sync across browsers or devices. <link>Learn more</link>"
    },
    voiceTrainingAllowedLabel: {
        id: "settingsModal.voiceTrainingAllowedLabel",
        defaultMessage: "Include your audio recordings"
    },
    videoTrainingAllowedLabel: {
        id: "settingsModal.videoTrainingAllowedLabel",
        defaultMessage: "Include your video recordings"
    },
    voiceAndVideoTrainingDescription: {
        id: "settingsModal.voiceAndVideoTrainingDescription",
        defaultMessage: 'Include your audio and video recordings from Voice Mode to train our models. Transcripts and other files are covered by "Improve the model for everyone." <link>Learn more</link>'
    },
    accountErrorWarning: {
        id: "SettingsModalImpl.accountErrorWarning",
        defaultMessage: "The account management page encountered an error. Please try again. If the problem continues, please visit help.openai.com."
    },
    deleteBrowserContext: {
        id: "settingsModal.deleteBrowserContext",
        defaultMessage: "Remote browser data"
    },
    deleteBrowserContextButton: {
        id: "settingsModal.deleteBrowserContextButton",
        defaultMessage: "Delete all"
    },
    deleteBrowserContextSuccess: {
        id: "settingsModal.deleteBrowserContextSuccess",
        defaultMessage: "Remote browser data deleted successfully."
    },
    deleteBrowserContextError: {
        id: "settingsModal.deleteBrowserContextError",
        defaultMessage: "Error deleting browser context!"
    },
    deleteBrowserContextModalTitle: {
        id: "settingsModal.deleteBrowserContextModalTitle",
        defaultMessage: "Delete all browser data?"
    },
    deleteBrowserContextModalConfirm: {
        id: "settingsModal.deleteBrowserContextModalConfirm",
        defaultMessage: "Delete"
    },
    deleteBrowserContextModalCancel: {
        id: "settingsModal.deleteBrowserContextModalCancel",
        defaultMessage: "Cancel"
    },
    disableRemoteBrowserDataTitle: {
        id: "settingsModal.disableRemoteBrowserDataTitle",
        defaultMessage: "Turning off remote browser data?"
    },
    disableRemoteBrowserDataDescription: {
        id: "settingsModal.disableRemoteBrowserDataDescription",
        defaultMessage: "This will disable cookies and connectors for any active and scheduled tasks."
    },
    disableRemoteBrowserDataConfirm: {
        id: "settingsModal.disableRemoteBrowserDataConfirm",
        defaultMessage: "OK"
    },
    disableRemoteBrowserDataCancel: {
        id: "settingsModal.disableRemoteBrowserDataCancel",
        defaultMessage: "Keep on"
    }
});

function hp({
    type: s,
    className: e
}) {
    return s === "computer" ? t.jsx($u, {
        className: e
    }) : s === "phone" ? t.jsx(vu, {
        className: e
    }) : t.jsx(iu, {
        className: e
    })
}

function xp({
    onClose: s,
    devices: e,
    renderAsSheet: a
}) {
    const n = K(),
        o = !!a,
        i = xc(),
        c = o && !i,
        l = o && i;
    return t.jsxs(Js, {
        isOpen: !0,
        onClose: s,
        showOverlayBackground: !l,
        overlayClassName: l ? "bg-token-bg-primary" : void 0,
        position: l ? "top" : void 0,
        isBottomSheet: c,
        contentSize: c ? "fill" : void 0,
        contentSheetViewClassName: c ? "w-screen h-[max(100svh,100dvh,100%)]" : void 0,
        className: c ? "sm:border-token-border-light! max-sm:h-full max-sm:w-screen max-sm:max-w-none max-sm:rounded-none sm:w-[calc(100vw-2rem)] sm:max-w-[900px] sm:border" : "max-w-[524px]!",
        title: t.jsx("span", {
            className: "heading-sm [font-weight:500]",
            children: n.formatMessage({
                id: "trustedDevicesModal.title",
                defaultMessage: "Trusted devices"
            })
        }),
        testId: "modal-trusted-devices",
        headerClassName: "!px-6 !py-0 !h-[76px] !items-center",
        contentClassName: "!px-6 !pt-6 !pb-0",
        showCloseButton: !0,
        hasSeparator: !0,
        modalActionsClassName: "!mt-0",
        children: [t.jsx("p", {
            className: "text-sm",
            children: t.jsx(m, {
                id: "trustedDevicesModal.description",
                defaultMessage: "After you sign in, a device becomes trusted. When you log in somewhere new, we'll send a prompt to your trusted devices for approval. To remove a trusted device from this list, just log out."
            })
        }), t.jsx("div", {
            className: "border-token-border mt-6 border-t"
        }), t.jsx("ul", {
            className: "divide-token-border border-token-border divide-y border-b",
            children: e.map(d => {
                var r;
                return t.jsxs("li", {
                    className: "flex items-center gap-3 py-2",
                    children: [t.jsx("div", {
                        className: "text-token-icon-primary",
                        children: t.jsx(hp, {
                            type: d.device_type
                        })
                    }), t.jsxs("div", {
                        children: [t.jsx("p", {
                            className: "py-0.5 text-sm",
                            children: (r = d.device_name) != null ? r : n.formatMessage({
                                id: "trustedDevicesModal.unknownDeviceName",
                                defaultMessage: "Unknown"
                            })
                        }), (d.last_seen_time != null || d.device_location) && t.jsx("p", {
                            className: "text-token-text-secondary py-0.5 text-sm",
                            children: d.device_location ? t.jsx(m, {
                                id: "trustedDevicesModal.lastSeen.withLocation",
                                defaultMessage: "Last logged in on {ts, date, short} at {ts, time, short} from {location}",
                                values: {
                                    ts: d.last_seen_time ? d.last_seen_time * 1e3 : Date.now(),
                                    location: d.device_location
                                }
                            }) : t.jsx(m, {
                                id: "trustedDevicesModal.lastSeen.noLocation",
                                defaultMessage: "Last logged in on {ts, date, short} at {ts, time, short}",
                                values: {
                                    ts: d.last_seen_time ? d.last_seen_time * 1e3 : Date.now()
                                }
                            })
                        })]
                    })]
                }, d.device_id)
            })
        }), t.jsx("div", {
            className: "mt-6"
        })]
    })
}
const bp = ft(() => gt(() =>
        import ("./hf084iz91dvtpxr2.js"), __vite__mapDeps([64, 1, 2, 3, 6, 7, 54, 65])).then(s => s.default)),
    yp = ft(() => gt(() =>
        import ("./3ype9xcsrgcixjgo.js"), __vite__mapDeps([66, 1, 2, 3, 6, 7, 67, 68]))),
    Mp = ft(() => gt(() =>
        import ("./oi0jufgbruu7yg53.js").then(s => s.b), __vite__mapDeps([69, 1, 2, 3, 6, 7, 70, 71, 72, 73, 74, 41, 75, 40, 48, 44, 45])).then(s => s.default)),
    oi = ft(() => gt(() =>
        import ("./dn6cv9mouo82roaf.js"), __vite__mapDeps([76, 1, 2, 3, 6, 7, 77, 40])).then(s => s.CancelSubscriptionModal)),
    ii = ft(() => gt(() =>
        import ("./jey1kqkf4thir7xd.js"), __vite__mapDeps([78, 1, 2, 3, 6, 7, 69, 70, 71, 72, 73, 74, 41, 75, 40, 48, 44, 45, 77])).then(s => s.SubscriptionClaimCancelPromoModal)),
    vp = ft(() => gt(() =>
        import ("./g4v4kimchdgh1fre.js"), __vite__mapDeps([79, 1, 2, 3, 6, 7])).then(s => s.EditEmailModal)),
    Cp = ft(() => gt(() =>
        import ("./mh5ruqlo4xwv83so.js"), __vite__mapDeps([80, 1, 2, 3, 6, 7, 81])).then(s => s.AddEmailModal)),
    jp = ft(() => gt(() =>
        import ("./nm2809n8a8o53c7h.js"), __vite__mapDeps([82, 1, 2, 3, 83, 6, 7, 54])).then(s => s.default)),
    Sp = ft(() => gt(() =>
        import ("./ceksygc7o6kb5ygo.js"), __vite__mapDeps([84, 1, 2, 3, 6, 7, 14, 15, 16, 17, 18, 19, 20, 21, 10, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58])).then(s => s.ConfirmDeleteHistoryModal)),
    jr = ft(() => gt(() =>
        import ("./fknpszl3y0505y7v.js"), __vite__mapDeps([85, 1, 2, 3, 6, 7, 14, 15, 16, 17, 18, 19, 20, 21, 10, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58])).then(s => s.ConfirmDeleteBrowserContextModal)),
    _p = ft(() => gt(() =>
        import ("./ltr8f2om043h2xo1.js"), __vite__mapDeps([86, 1, 2, 3, 6, 7, 14, 15, 16, 17, 18, 19, 20, 21, 10, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58])).then(s => s.ConfirmArchiveHistoryModal)),
    wp = ft(() => gt(() =>
        import ("./nvxvk0t5hsctb5xf.js"), __vite__mapDeps([87, 1, 2, 3, 6, 7, 14, 15, 16, 17, 18, 19, 20, 21, 10, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58])).then(s => s.ConfirmExportDataModal)),
    kp = ft(() => gt(() =>
        import ("./kbmrqr6usrjd7suv.js"), __vite__mapDeps([88, 1, 2, 3, 6, 7])).then(s => s.ConfirmDeleteAccountModal)),
    Ep = () => !1,
    Sr = "https://help.openai.com/en/articles/5722486",
    Np = "https://help.openai.com/en/articles/8400625-voice-mode-faq#h_3839e62d6a";
async function Tp() {
    return {
        eligible: (await tt.safeGet("/accounts/change_email/eligibility")).eligible
    }
}

function Ap(s) {
    const e = ma(s),
        {
            data: a
        } = Fs({
            queryKey: ["data-usage-for-training", e == null ? void 0 : e.accountUserId],
            queryFn: () => tt.safeGet("/accounts/data_usage_for_training"),
            enabled: e != null
        });
    return a == null ? void 0 : a.data_usage_for_training
}

function Pp({
    account: s
}) {
    return s ? s.isFree() ? vt.FREE : s.isGo() ? vt.GO : s.isPlus() ? vt.PLUS : s.isPro() ? vt.PRO : null : null
}

function Dp() {
    const {
        data: s
    } = fa(), e = K(), a = Xs(on.isBusinessWorkspace), [n, o] = w.useState(!1), i = Xs(on.isTeamPlan), c = Xs(on.isEduPlan), {
        data: l
    } = Et(ie.TrainingAllowed), {
        data: d
    } = Et(ie.VoiceTrainingAllowed), {
        data: r
    } = Et(ie.VideoTrainingAllowed), u = kt(), f = Za(), p = Ap(s), g = p === "disallowed" ? !1 : !!l;
    return t.jsxs(Q, {
        children: [t.jsx(Mn, {
            onClick: () => o(!0),
            label: e.formatMessage(q.chatTrainingAllowedToggleLabel),
            stateLabel: g ? e.formatMessage({
                id: "settingsModal.trainingEnabled",
                defaultMessage: "On"
            }) : e.formatMessage({
                id: "settingsModal.trainingDisabled",
                defaultMessage: "Off"
            }),
            testId: "improve-model-open-modal-button"
        }), n && t.jsxs(Js, {
            testId: "modal-training-toggle",
            isOpen: !0,
            onClose: () => o(!1),
            title: e.formatMessage({
                id: "settingsModal.trainingToggleModalTitle",
                defaultMessage: "Model improvement"
            }),
            type: "success",
            secondaryButton: t.jsx(ne, {
                color: "secondary",
                onClick: () => o(!1),
                "data-testid": "improve-model-done-button",
                children: t.jsx(m, {
                    id: "settingsModal.trainingToggleModalDoneButton",
                    defaultMessage: "Done"
                })
            }),
            children: [t.jsx("div", {
                className: "pb-8",
                children: t.jsx(ct, {
                    label: e.formatMessage(q.chatTrainingAllowedToggleLabel),
                    disabled: p === "disallowed" || (f == null ? void 0 : f[ie.TrainingAllowed]) === !0,
                    enabled: g,
                    onChange: async h => {
                        await u.mutateAsync({
                            setting: ie.TrainingAllowed,
                            value: h
                        }), h || (await u.mutateAsync({
                            setting: ie.VoiceTrainingAllowed,
                            value: !1
                        }), await u.mutateAsync({
                            setting: ie.VideoTrainingAllowed,
                            value: !1
                        }))
                    },
                    toggleTooltip: a ? t.jsx(m, b({}, i ? q.chatTrainingTeamsTooltip : c ? q.chatTrainingEduTooltip : q.chatTrainingEnterpriseTooltip)) : null,
                    description: t.jsx(m, Ee(b({}, q.trainingAllowedDescription), {
                        values: {
                            link: h => t.jsx("a", {
                                href: Sr,
                                target: "_blank",
                                className: "underline",
                                rel: "noreferrer",
                                children: h
                            })
                        }
                    })),
                    testId: "improve-model-toggle"
                })
            }), !a && t.jsxs("div", {
                className: "flex flex-col",
                children: [t.jsx("p", {
                    className: "text-token-text-secondary mb-2 text-lg leading-7 font-semibold",
                    children: t.jsx(m, {
                        id: "settingsModal.trainingToggleModalVoiceAndVideoTitle",
                        defaultMessage: "Voice mode"
                    })
                }), t.jsx("div", {
                    className: "pb-2",
                    children: t.jsx(ct, {
                        label: e.formatMessage(q.voiceTrainingAllowedLabel),
                        enabled: g ? !!d : !1,
                        disabled: !g || (f == null ? void 0 : f[ie.VoiceTrainingAllowed]) === !0,
                        onChange: h => {
                            g && u.mutate({
                                setting: ie.VoiceTrainingAllowed,
                                value: h
                            })
                        }
                    })
                }), t.jsx(ct, {
                    label: e.formatMessage(q.videoTrainingAllowedLabel),
                    enabled: g ? !!r : !1,
                    disabled: !g || (f == null ? void 0 : f[ie.VideoTrainingAllowed]) === !0,
                    onChange: h => {
                        g && u.mutate({
                            setting: ie.VideoTrainingAllowed,
                            value: h
                        })
                    },
                    description: t.jsx(m, Ee(b({}, q.voiceAndVideoTrainingDescription), {
                        values: {
                            link: h => t.jsx("a", {
                                href: Np,
                                target: "_blank",
                                className: "underline",
                                rel: "noreferrer",
                                children: h
                            })
                        }
                    }))
                })]
            })]
        })]
    })
}
const yh = () => {
    const s = ve(),
        e = K(),
        a = vc(),
        n = Sn(),
        {
            pathname: o
        } = n,
        i = bs(),
        {
            closeSettings: c,
            currentTab: l,
            openSettings: d
        } = Fn(),
        r = Cc(),
        u = jc(),
        f = Sc(),
        p = _c(),
        g = Ep(),
        h = Gs(),
        y = wc(),
        x = kc(),
        [j, v] = w.useState(r);
    w.useEffect(() => {
        v(r)
    }, [r]);
    const [S, C] = w.useState(p), [M, E] = w.useState(g), N = Cm(), k = Zi(), P = je(s, "733205176"), L = je(s, "3375735072"), A = je(s, "490346566"), _ = kn(s), D = Ec(Nc.CookieManagement), T = _t(), [F, O] = w.useState(null);
    w.useEffect(() => {
        const [ae] = n.hash.split("?"), [Z, $, ee] = ae.split("/");
        Z === "#settings" && $ === Ae.DataControls && ee === Di.ArchivedChats && $e(s, bp, {})
    }, [s, n.hash, i]);
    const I = k.status !== "loading",
        {
            native_default_factor_id: U
        } = k,
        R = () => {
            if (k.status !== "enabled") throw new Error("MFA is not enabled");
            if (!U) throw new Error("No factor ID found");
            return tt.safePost("/accounts/mfa/user/disable_in_house", {
                requestBody: {
                    factor_id: U
                }
            })
        },
        B = () => {
            R().then(() => {
                T.invalidateQueries({
                    queryKey: ["mfaInfo"]
                }), i(wo(ko.DISABLE_MFA_SUCCESS, "/#settings/".concat(Ae.Security)))
            }).catch(() => {
                i(wo(ko.DISABLE_MFA_TIMEOUT, "/#settings/".concat(Ae.Security)))
            })
        },
        z = je(s, "3325813340");
    je(s, "3384364566");
    const W = zs(),
        V = W == null ? void 0 : W.isPersonalAccount(),
        J = V !== !1;
    w.useEffect(() => {
        V === !1 && l === Ae.ParentalControls && d(Ae.General)
    }, [l, V, d]);
    let ce = null;
    if (N) return I ? t.jsx(jm, {
        onClose: () => i("/", {
            replace: !0
        }),
        onConfirm: B
    }) : null;
    if (D) return null;
    if (j) {
        if (ce = t.jsx(xu, {
                onClose: () => {
                    u ? (v(!1), x()) : i(o, {
                        replace: !0
                    })
                }
            }), !u) return ce
    } else {
        if (f) return t.jsx(Pu, {
            onClose: () => i("/", {
                replace: !0
            }),
            referrer: Ta.ConnectorToggle,
            toggleAllAfterRedirect: !0
        });
        if (S) return t.jsx(Su, {
            onClose: ae => {
                ae ? (h(ae), C(!1)) : p ? i(o, {
                    replace: !0
                }) : C(!1)
            }
        })
    }
    return t.jsxs(t.Fragment, {
        children: [t.jsx(Js, {
            testId: "modal-settings",
            isOpen: !0,
            onClose: c,
            size: "custom",
            className: "max-h-[85vh] max-md:min-h-[60vh] md:h-[600px] md:max-w-[680px]",
            type: "success",
            title: e.formatMessage(q.settings),
            showCloseButton: !0,
            visuallyHiddenHeader: a,
            hasSeparator: !0,
            noPadding: !0,
            children: t.jsxs(Tc, {
                className: "flex h-[100%] flex-col md:flex-row",
                value: l != null ? l : Ae.General,
                orientation: a ? "vertical" : void 0,
                onValueChange: ae => {
                    d(ae)
                },
                children: [t.jsxs(Ac, {
                    className: "bg-token-bg-elevated-secondary flex shrink-0 flex-row flex-wrap select-none max-md:overflow-x-auto max-md:border-b max-md:p-1.5 md:max-w-[210px] md:min-w-[180px] md:flex-col dark:bg-black/10",
                    children: [t.jsx("div", {
                        className: "py-3 ps-2.5 max-md:hidden",
                        children: t.jsx(Ei, {
                            onClick: c
                        })
                    }), t.jsx(hs, {
                        value: Ae.General,
                        icon: ji,
                        label: t.jsx(m, b({}, q.generalTab))
                    }), z && t.jsx(im, {}), t.jsx(hs, {
                        value: Ae.Personalization,
                        icon: ru,
                        label: t.jsx(m, b({}, q.personalizationTab)),
                        "data-testid": "personalization-tab",
                        onMouseOver: () => {
                            T.prefetchQuery(lu()), za(s), cu(s), du(s)
                        }
                    }), t.jsx(hs, {
                        value: Ae.Connectors,
                        icon: _ ? uu : gu,
                        label: _ ? t.jsx(m, b({}, q.appsTab)) : A ? t.jsx(m, b({}, q.connectorsTabModelToolDiscovery)) : t.jsx(m, b({}, q.connectorsTabRevamp))
                    }), P && t.jsx(hs, {
                        value: Ae.Schedules,
                        icon: Xi,
                        label: t.jsx(m, b({}, q.schedulesTab)),
                        "data-testid": "schedules-tab"
                    }), L && t.jsx(hs, {
                        value: Ae.Orders,
                        icon: Nu,
                        label: t.jsx(m, {
                            id: "xdSD9Q",
                            defaultMessage: "Orders"
                        }),
                        "data-testid": "orders-tab"
                    }), t.jsx(hs, {
                        value: Ae.DataControls,
                        icon: fu,
                        label: t.jsx(m, b({}, q.dataControlsTab)),
                        "data-testid": "data-controls-tab"
                    }), t.jsx(hs, {
                        value: Ae.Security,
                        icon: mu,
                        label: t.jsx(m, b({}, q.securityTab)),
                        "data-testid": "security-tab"
                    }), J && t.jsx(hs, {
                        value: Ae.ParentalControls,
                        icon: Tu,
                        label: e.formatMessage(Jt.parentalControlsTab),
                        "data-testid": "amphora-controls-tab"
                    }), !1, t.jsx(hs, {
                        value: Ae.Account,
                        icon: pu,
                        label: t.jsx(m, b({}, q.accountTab)),
                        "data-testid": "account-tab"
                    }), !1]
                }), t.jsx(gs, {
                    value: Ae.General,
                    children: t.jsx(Lp, {})
                }), z && t.jsx(gs, {
                    value: Ae.Notifications,
                    children: t.jsx(tm, {})
                }), t.jsx(gs, {
                    value: Ae.Personalization,
                    children: t.jsx(rp, {})
                }), t.jsx(gs, {
                    value: Ae.Connectors,
                    children: t.jsx($f, {
                        onAddLinkClick: () => {
                            y({
                                referrer: Ta.SettingsConnectorsTab,
                                showSettingsBehindConnectorLink: !0
                            }), v(!0)
                        },
                        onCreateCustomConnectorClick: () => C(!0)
                    })
                }), t.jsx(gs, {
                    value: Ae.DataControls,
                    children: F === "remoteBrowserData" ? t.jsx(Gp, {
                        onBack: () => O(null)
                    }) : t.jsx(Rp, {
                        onOpenRemoteBrowserDataPage: () => O("remoteBrowserData")
                    })
                }), P && t.jsx(gs, {
                    value: Ae.Schedules,
                    children: t.jsx(Bp, {})
                }), L && t.jsx(gs, {
                    value: Ae.Orders,
                    children: t.jsx(Eu, {})
                }), t.jsx(gs, {
                    value: Ae.Security,
                    children: t.jsx(Op, {})
                }), J && t.jsx(gs, {
                    value: Ae.ParentalControls,
                    children: t.jsx(Sg, {})
                }), !1, t.jsx(gs, {
                    value: Ae.Account,
                    children: t.jsx(Fp, {})
                }), !1]
            })
        }), ce]
    })
};

function Lp() {
    "use forget";
    const s = Se.c(51),
        e = K(),
        a = kt(),
        n = _t(),
        o = Pc(),
        i = ve();
    let c;
    s[0] !== i ? (c = Dc(i) && !Li(), s[0] = i, s[1] = c) : c = s[1];
    const l = c,
        {
            data: d
        } = Et(ie.ShowLegacyModels),
        r = zs();
    let u;
    s[2] !== i ? (u = je(i, "2991909965"), s[2] = i, s[3] = u) : u = s[3];
    const f = u;
    let p;
    s[4] !== i ? (p = je(i, "2036808540"), s[4] = i, s[5] = p) : p = s[5];
    const g = p;
    let h;
    s[6] !== i ? (h = je(i, "4230914712"), s[6] = i, s[7] = h) : h = s[7];
    const y = h,
        x = je(i, "3315017149");
    let j;
    s[8] !== r || s[9] !== g || s[10] !== y ? (j = (r == null ? void 0 : r.isEnterprisey()) && g || (r == null ? void 0 : r.isSelfServeBusiness()) && y, s[8] = r, s[9] = g, s[10] = y, s[11] = j) : j = s[11];
    const v = j;
    let S;
    s[12] !== e ? (S = e.formatMessage(q.showLegacyModels), s[12] = e, s[13] = S) : S = s[13];
    let C = S,
        M;
    s[14] === Symbol.for("react.memo_cache_sentinel") ? (M = t.jsx(m, {
        id: "dw9iMe",
        defaultMessage: "Please contact your administrator to enable or disable legacy models."
    }), s[14] = M) : M = s[14];
    let E = M;
    if (x) {
        let R;
        s[15] !== e ? (R = e.formatMessage(q.showAdditionalModels), s[15] = e, s[16] = R) : R = s[16], C = R;
        let B;
        s[17] === Symbol.for("react.memo_cache_sentinel") ? (B = t.jsx(m, {
            id: "TJwldi",
            defaultMessage: "Please contact your administrator to enable or disable additional models."
        }), s[17] = B) : B = s[17], E = B
    }
    let N;
    s[18] !== e ? (N = e.formatMessage(q.settings), s[18] = e, s[19] = N) : N = s[19];
    let k;
    s[20] !== o ? (k = o && t.jsx(Dm, {}), s[20] = o, s[21] = k) : k = s[21];
    let P;
    s[22] !== o ? (P = o && t.jsx(Om, {}), s[22] = o, s[23] = P) : P = s[23];
    let L;
    s[24] !== o ? (L = o && t.jsx(Im, {}), s[24] = o, s[25] = L) : L = s[25];
    let A;
    s[26] === Symbol.for("react.memo_cache_sentinel") ? (A = t.jsx(Q, {
        children: t.jsx(Sm, {})
    }), s[26] = A) : A = s[26];
    let _;
    s[27] !== r || s[28] !== l ? (_ = l && r && t.jsx(Q, {
        children: t.jsx(Ou, {
            account: r
        })
    }), s[27] = r, s[28] = l, s[29] = _) : _ = s[29];
    let D;
    s[30] !== o ? (D = o && t.jsx(Rm, {}), s[30] = o, s[31] = D) : D = s[31];
    let T, F, O;
    s[32] === Symbol.for("react.memo_cache_sentinel") ? (T = t.jsx(Q, {
        children: t.jsx(Up, {})
    }), F = !1, O = t.jsx(bu, {}), s[32] = T, s[33] = F, s[34] = O) : (T = s[32], F = s[33], O = s[34]);
    let I;
    s[35] !== f || s[36] !== E || s[37] !== C || s[38] !== n || s[39] !== v || s[40] !== d || s[41] !== a ? (I = f && t.jsx(Q, {
        children: t.jsx(ct, {
            label: C,
            enabled: v ? !1 : !!d,
            disabled: v,
            description: v ? E : void 0,
            isLoading: a.isPending,
            onChange: async R => {
                await a.mutateAsync({
                    setting: ie.ShowLegacyModels,
                    value: R
                }), n.invalidateQueries({
                    queryKey: Lc()
                })
            }
        })
    }), s[35] = f, s[36] = E, s[37] = C, s[38] = n, s[39] = v, s[40] = d, s[41] = a, s[42] = I) : I = s[42];
    let U;
    return s[43] !== L || s[44] !== _ || s[45] !== D || s[46] !== I || s[47] !== N || s[48] !== k || s[49] !== P ? (U = t.jsxs(Ne, {
        title: N,
        children: [k, P, L, A, _, D, T, F, O, I]
    }), s[43] = L, s[44] = _, s[45] = D, s[46] = I, s[47] = N, s[48] = k, s[49] = P, s[50] = U) : U = s[50], U
}

function Ip() {
    const s = K(),
        e = kt(),
        a = Ct(),
        {
            data: n
        } = Et(ie.PreciseLocationEnabledForDevice);
    return t.jsx(Q, {
        children: t.jsx(ct, {
            label: s.formatMessage(q.preciseLocationToggleLabel),
            description: t.jsx(m, b({}, q.preciseLocationToggleDescription)),
            enabled: !!n,
            isLoading: n == null,
            onChange: o => {
                o ? Wc(i => {
                    e.mutate({
                        setting: ie.PreciseLocationEnabledForDevice,
                        value: i
                    }), o && !i && a.danger(s.formatMessage({
                        id: "+qUF+G",
                        defaultMessage: "Browser denied location sharing. Location sharing not enabled."
                    }))
                }) : (e.mutate({
                    setting: ie.PreciseLocationEnabledForDevice,
                    value: !1
                }), Vc())
            }
        })
    })
}

function Rp({
    onOpenRemoteBrowserDataPage: s
}) {
    const e = ve(),
        a = K(),
        n = Ct(),
        {
            pathname: o
        } = Sn(),
        i = bs(),
        c = je(e, "733205176"),
        l = je(e, "1030527215"),
        d = je(e, "1957563541"),
        r = hu(Ic.WorkspaceShareLinks),
        u = kt(),
        {
            data: f
        } = fa(),
        p = ma(f),
        g = Xs(on.isBusinessWorkspace),
        h = p == null ? void 0 : p.isSelfServeBusiness(),
        y = f == null ? void 0 : f.accountItems.some(P => P.isPersonalAccount()),
        x = Vi(),
        j = $i(),
        v = Ki(),
        S = qi(e),
        C = _t(),
        {
            data: M
        } = Et(ie.EnableRemoteBrowserData),
        E = () => {
            tt.safePatch("/conversations", {
                requestBody: {
                    is_archived: !0
                }
            }).then(() => {
                n.info(a.formatMessage(q.archiveHistorySuccess)), No(C)
            }), o !== "/" && i("/", {
                replace: !0
            })
        },
        N = () => {
            tt.safePatch("/conversations", {
                requestBody: {
                    is_visible: !1
                }
            }).then(() => {
                No(C)
            }), o !== "/" && i("/", {
                replace: !0
            })
        },
        k = () => {
            tt.safeDelete("/agent/browser_context", {}).then(P => {
                P.success ? n.success(a.formatMessage(q.deleteBrowserContextSuccess)) : n.danger(q.deleteBrowserContextError, {
                    toastId: "delete-browser-context-failed"
                })
            }).catch(() => {
                n.danger(q.deleteBrowserContextError, {
                    toastId: "delete-browser-context-error"
                })
            })
        };
    return t.jsxs(Ne, {
        title: a.formatMessage(q.dataControlsTab),
        children: [t.jsx(Dp, {}), c && t.jsx(Q, {
            children: l ? t.jsx(Mn, {
                label: a.formatMessage(q.remoteBrowserData),
                stateLabel: M ? a.formatMessage({
                    id: "personalizationSettings.on",
                    defaultMessage: "On"
                }) : a.formatMessage({
                    id: "personalizationSettings.off",
                    defaultMessage: "Off"
                }),
                onClick: s
            }) : t.jsx(Lt, {
                color: "danger-outline",
                label: a.formatMessage(q.deleteBrowserContext),
                buttonLabel: a.formatMessage(q.deleteBrowserContextButton),
                onClick: () => {
                    $e(e, jr, {
                        onDeleteBrowserContext: k
                    })
                },
                "data-testid": "delete-browser-context-button"
            })
        }), d && t.jsx(Ip, {}), v && S && t.jsx(Q, {
            children: t.jsx(ct, {
                label: a.formatMessage({
                    id: "APWP2z",
                    defaultMessage: "Enable memory in search"
                }),
                enabled: x,
                onChange: P => {
                    u.mutate({
                        setting: ie.MemoryInSearch,
                        value: P
                    })
                },
                disabled: !j,
                description: t.jsx(m, {
                    id: "nQ+QoN",
                    defaultMessage: "To be more helpful in getting you more relevant responses, ChatGPT may share disassociated search queries based on past memories with third-party search providers. <link>Learn more</link>",
                    values: {
                        link: P => t.jsx("a", {
                            href: "https://help.openai.com/en/articles/9237897-chatgpt-search",
                            target: "_blank",
                            className: "underline",
                            rel: "noreferrer",
                            children: P
                        })
                    }
                })
            })
        }), r && t.jsx(Q, {
            children: t.jsx(Lt, {
                label: a.formatMessage(q.sharedConversations),
                buttonLabel: a.formatMessage(q.manageButton),
                onClick: () => {
                    $e(e, jp)
                },
                "data-testid": "manage-shared-conversations-button"
            })
        }), t.jsx(Q, {
            children: t.jsx(Lt, {
                label: a.formatMessage(q.archivedConversations),
                buttonLabel: a.formatMessage(q.manageButton),
                onClick: () => {
                    i(Va(Ae.DataControls, {
                        dataControlsRoute: Di.ArchivedChats
                    }))
                },
                "data-testid": "manage-archived-conversations-button"
            })
        }), t.jsx(Q, {
            children: t.jsx(Lt, {
                label: a.formatMessage(q.archiveChatsLabel),
                buttonLabel: a.formatMessage(q.archiveChatsButton),
                onClick: () => {
                    $e(e, _p, {
                        onArchiveHistory: E
                    })
                },
                "data-testid": "archive-all-chats-button"
            })
        }), t.jsx(Q, {
            children: t.jsx(Lt, {
                color: "danger-outline",
                label: a.formatMessage(q.deleteChatLabel),
                buttonLabel: a.formatMessage(q.deleteChatButton),
                onClick: () => {
                    $e(e, Sp, {
                        onDeleteHistory: N
                    })
                },
                "data-testid": "delete-all-chats-button"
            })
        }), h && y && t.jsx(Q, {
            children: t.jsx(Lt, {
                label: a.formatMessage(q.mergePersonalData),
                buttonLabel: a.formatMessage(q.mergeButton),
                onClick: () => {
                    $e(e, yp, {
                        fromSettings: !0
                    })
                }
            })
        }), !g && t.jsx(Q, {
            children: t.jsx(Lt, {
                label: a.formatMessage(q.exportData),
                buttonLabel: a.formatMessage(q.exportButton),
                onClick: () => {
                    $e(e, wp)
                },
                "data-testid": "export-data-button"
            })
        })]
    })
}

function Bp() {
    "use forget";
    const s = Se.c(6),
        e = K();
    let a;
    s[0] !== e ? (a = e.formatMessage(q.schedulesTab), s[0] = e, s[1] = a) : a = s[1];
    let n;
    s[2] === Symbol.for("react.memo_cache_sentinel") ? (n = t.jsx("div", {
        children: t.jsx(m, {
            id: "eTC7El",
            defaultMessage: "ChatGPT can be scheduled to run again after it completes a task. Choose {scheduleIcon} Schedule from the {menuIcon} menu in a conversation to set up future runs.",
            values: {
                scheduleIcon: t.jsx(Xi, {
                    className: "-mt-1 inline-block size-4"
                }),
                menuIcon: t.jsx(ki, {
                    className: "-mt-1 inline-block size-4"
                })
            }
        })
    }), s[2] = n) : n = s[2];
    let o;
    s[3] === Symbol.for("react.memo_cache_sentinel") ? (o = t.jsxs("div", {
        className: "flex flex-col gap-5 py-4",
        children: [n, t.jsx("div", {
            children: t.jsx(Rn, {
                to: "/schedules",
                className: "hover:bg-token-bg-tertiary rounded-full border px-4 py-2",
                children: t.jsx(m, {
                    id: "+0oCTk",
                    defaultMessage: "Manage"
                })
            })
        })]
    }), s[3] = o) : o = s[3];
    let i;
    return s[4] !== a ? (i = t.jsx(Ne, {
        title: a,
        children: o
    }), s[4] = a, s[5] = i) : i = s[5], i
}

function Op({
    isFullPage: s
}) {
    var T, F, O, I, U, R;
    const e = ve(),
        a = K(),
        n = Ct(),
        o = kt(),
        [i, c] = w.useState(!1),
        [l, d] = w.useState(!1),
        r = Zi(),
        u = r.status,
        f = Rc(),
        p = Li() && !f,
        {
            session: g
        } = Bc(e),
        h = g == null ? void 0 : g.user,
        {
            data: y
        } = Et(ie.EnableDeviceCodeAuth),
        {
            data: x
        } = fa(),
        j = ma(x),
        v = j == null ? void 0 : j.features,
        S = Xs(B => {
            var z;
            return ((z = B.currentWorkspace) == null ? void 0 : z.structure) === "workspace"
        });
    Zs.addAction("security_settings_has_workspace", {
        hasWorkspace: S
    });
    const C = Oc(),
        M = !!(s && C),
        {
            startChangePasswordFlow: E
        } = cp(),
        N = !S && je(e, "2508433885"),
        k = pm({
            enabled: !0
        }),
        P = je(e, "511709950"),
        L = u === "enabled" || (h == null ? void 0 : h.email) != null && (v == null ? void 0 : v.includes(Fc)) === !0 && (u === "loading" || u === "disabled"),
        A = L && r.status === "loading",
        _ = w.useCallback(() => {
            c(!0), tt.safePost("/accounts/logout_all").then(() => {
                n.success(a.formatMessage(q.logoutAllSuccess), {
                    testId: "logout-all-success-toaster"
                }), Eo()
            }).catch(B => {
                Zs.addError(new Error("Failed logging out all accounts: ", {
                    cause: B
                })), n.danger(q.logoutAllFailed, {
                    hasCloseButton: !0,
                    toastId: "settings_modal_failed_to_log_out_all"
                }), c(!1)
            })
        }, [a, n]),
        D = t.jsx(m, b({}, q.passwordSettingLabel));
    return t.jsxs(t.Fragment, {
        children: [t.jsxs(Ne, {
            title: t.jsxs("div", {
                className: "flex items-center gap-2",
                children: [a.formatMessage(q.securityTab), A ? t.jsx(ys, {
                    className: "h-4 w-4"
                }) : null]
            }),
            headerInteractable: !0,
            children: [P && t.jsx(Q, {
                children: t.jsx(Mn, {
                    onClick: () => {
                        E()
                    },
                    label: D,
                    stateLabel: a.formatMessage(q.passwordSettingMaskedValue),
                    testId: "password-setting"
                })
            }), L && !A && t.jsx($m, {
                factors: r.factors,
                renderAsSheet: M
            }), L && t.jsx(Wm, {
                factors: r.factors,
                isDisabled: A,
                isLoading: A,
                showPushAuth: r.show_push_auth,
                showSms: r.show_sms,
                email: (T = h == null ? void 0 : h.email) != null ? T : void 0,
                numTrustedDevices: k.isError || (F = k.data) == null ? void 0 : F.devices.length,
                renderAsSheet: M
            }), !k.isError && k.data && t.jsx(Q, {
                children: k.data && k.data.devices.length > 0 ? t.jsx(Mn, {
                    onClick: () => d(!0),
                    label: t.jsx(m, b({}, q.trustedDevices)),
                    stateLabel: k.data ? String(k.data.devices.length) : "0"
                }) : t.jsxs("div", {
                    children: [t.jsx("div", {
                        children: t.jsx(m, b({}, q.trustedDevices))
                    }), t.jsx(yn, {
                        children: t.jsx(m, {
                            id: "settingsModal.trustedDevicesEmptyDescription",
                            defaultMessage: "When you sign in on another device, it will be added here and can automatically receive device prompts for signing in."
                        })
                    })]
                })
            }), !p && !M && t.jsx(Q, {
                children: t.jsx(Lt, {
                    label: a.formatMessage(q.logOutLabel),
                    buttonLabel: a.formatMessage(q.logOutButton),
                    onClick: () => Eo(),
                    "data-testid": "logout-button"
                })
            }), !M && t.jsx(Q, {
                children: t.jsx(Lt, {
                    label: t.jsx(m, {
                        id: "settingsModal.logoutAllLabel",
                        defaultMessage: "Log out of all devices"
                    }),
                    color: "danger-outline",
                    buttonLabel: t.jsx("div", {
                        style: {
                            whiteSpace: "nowrap"
                        },
                        children: t.jsx(m, {
                            id: "settingsModal.logoutAllButton",
                            defaultMessage: "Log out all"
                        })
                    }),
                    description: t.jsx(m, {
                        id: "settingsModal.logoutAllDescription",
                        defaultMessage: "Log out of all active sessions across all devices, including your current session. It may take up to 30 minutes for other devices to be logged out."
                    }),
                    onClick: () => {
                        Ue.logLogOutButtonClicked({
                            location: "settings_modal_log_out_all"
                        }, Uc.ACCESS_LOGOUT_ACTION_LOCATION_SETTINGS_MODAL_LOG_OUT_ALL), _()
                    },
                    disabled: i,
                    testId: "logout-all-button"
                })
            })]
        }), l && !k.isError && ((O = k == null ? void 0 : k.data) == null ? void 0 : O.devices) && ((I = k == null ? void 0 : k.data) == null ? void 0 : I.devices.length) > 0 && t.jsx(xp, {
            devices: (R = (U = k == null ? void 0 : k.data) == null ? void 0 : U.devices) != null ? R : [],
            onClose: () => d(!1),
            renderAsSheet: M
        }), t.jsx(Bg, {
            renderAsSheet: M
        }), t.jsx("div", {
            className: "pb-2",
            children: N && t.jsx(Q, {
                children: t.jsx(ct, {
                    label: a.formatMessage(q.deviceCodeAuthToggleLabel),
                    description: t.jsx(m, b({}, q.deviceCodeAuthToggleDescription)),
                    enabled: !!y,
                    disabled: o.isPending,
                    isLoading: o.isPending,
                    onChange: B => {
                        o.mutate({
                            setting: ie.EnableDeviceCodeAuth,
                            value: B
                        })
                    }
                })
            })
        })]
    })
}

function Fp() {
    var S, C;
    const s = ve(),
        e = K(),
        {
            data: a
        } = fa(),
        n = ma(a),
        o = Us(),
        i = Xs(on.isBusinessWorkspace),
        c = je(s, "107120153"),
        d = ((S = Fs({
            queryKey: ["change-email-eligibility", o == null ? void 0 : o.id],
            queryFn: Tp,
            enabled: c,
            staleTime: 300 * 1e3
        }).data) == null ? void 0 : S.eligible) === !0,
        r = Qe(() => Gc(s, ie.Birthday)),
        u = Qe(() => zc(s)),
        p = !!!(u != null && u.has_verified_age_or_dob) && (u == null ? void 0 : u.is_adult) === !1 && (u == null ? void 0 : u.is_u18_model_policy_enabled),
        g = kt(),
        h = () => {
            if (!n) return;
            const M = n.mustGetSubscriptionBillingCurrency("GlobalSettingsModal");
            $e(s, Mp, {
                isOpen: !0,
                accountId: n.id,
                initialPlanType: n.data.subscriptionStatus.planType,
                updatedPlanType: n.data.subscriptionStatus.planType,
                billingDetails: {
                    currency: M
                }
            })
        },
        y = () => {
            n && $e(s, oi, {
                isOpen: !0,
                currentAccount: n,
                onClose: () => {
                    Ue.logEventWithStatsig("Cancel Subscription Modal Dismissed", "chatgpt_cancel_subscription_modal_dismissed")
                },
                onClaimOfferButtonClicked: () => {
                    Ue.logEventWithStatsig("Cancel Subscription Modal Claim Offer Button Clicked", "chatgpt_cancel_subscription_modal_claim_offer_offer_button_clicked"), Do(s, oi), x()
                }
            })
        },
        x = () => {
            n && $e(s, ii, {
                account: n,
                onBackButtonClicked: () => {
                    Do(s, ii), y()
                }
            })
        },
        j = Pp({
            account: n
        });
    let v = null;
    if (n && j) {
        const M = Iu({
                ctx: s
            }),
            E = nr({
                ctx: s
            }),
            N = sr({
                ctx: s
            });
        switch (j) {
            case vt.FREE:
                v = t.jsx(gm, {
                    currentAccount: n
                });
                break;
            case vt.GO:
                v = t.jsx(Sa, {
                    currentAccount: n,
                    onCancelSubscriptionClick: y,
                    onRenewSubscriptionClick: h,
                    pricingPlan: N
                });
                break;
            case vt.PLUS:
                v = t.jsx(Sa, {
                    currentAccount: n,
                    onCancelSubscriptionClick: y,
                    onRenewSubscriptionClick: h,
                    pricingPlan: E
                });
                break;
            case vt.PRO:
                v = t.jsx(Sa, {
                    currentAccount: n,
                    onCancelSubscriptionClick: y,
                    onRenewSubscriptionClick: h,
                    pricingPlan: M
                });
                break
        }
    }
    return t.jsxs(t.Fragment, {
        children: [t.jsxs(Ne, {
            title: e.formatMessage(q.accountTab),
            children: [c && t.jsxs(t.Fragment, {
                children: [t.jsx(Q, {
                    children: t.jsx(Hc, {
                        labelMessage: q.accountInfoNameLabel,
                        value: (C = o == null ? void 0 : o.name) != null ? C : "",
                        testId: "account-info-name"
                    })
                }), d && t.jsx(Q, {
                    children: t.jsx(Mn, {
                        onClick: () => {
                            if (!(o != null && o.email)) {
                                $e(s, Cp);
                                return
                            }
                            $e(s, vp, {
                                email: o.email
                            })
                        },
                        label: t.jsx(m, b({}, q.accountInfoEmailLabel)),
                        stateLabel: o != null && o.email ? o.email : e.formatMessage(q.accountInfoEmailAddAction),
                        testId: "account-info-email"
                    })
                })]
            }), v, je(s, "408981619") && p && t.jsx(Q, {
                children: t.jsx(ai, {
                    birthday: r != null ? r : null,
                    userIsAdultData: u,
                    onSave: M => {
                        var E;
                        return g.mutateAsync({
                            setting: ie.Birthday,
                            value: M,
                            account_id: (E = n == null ? void 0 : n.id) != null ? E : ""
                        })
                    }
                })
            }), je(s, "2444205802") && t.jsx(Q, {
                children: t.jsx(ai, {
                    birthday: r != null ? r : null,
                    userIsAdultData: u,
                    onSave: M => {
                        var E;
                        return g.mutateAsync({
                            setting: ie.Birthday,
                            value: M,
                            account_id: (E = n == null ? void 0 : n.id) != null ? E : ""
                        })
                    }
                })
            }), t.jsx(vm, {}), !i && t.jsx(Q, {
                children: t.jsx(Lt, {
                    label: e.formatMessage(q.deleteAccount),
                    buttonLabel: e.formatMessage(q.deleteAccountButton),
                    color: "danger-outline",
                    onClick: () => {
                        $e(s, kp)
                    },
                    "data-testid": "delete-account-button"
                })
            })]
        }), n && t.jsx(Yf, {})]
    })
}

function Up() {
    var d;
    const s = $c().locale,
        e = Yc,
        a = (d = To(() => Kc())) != null ? d : null,
        n = To(() => navigator.language),
        o = n == null ? null : qc(n),
        i = w.useCallback(async r => {
            try {
                await tt.safePatch("/accounts/users/locale", {
                    requestBody: {
                        locale: r
                    }
                })
            } catch (u) {
                Zs.addError(new Error("Failed to persist locale preference", {
                    cause: u instanceof Error ? u : void 0
                }))
            }
        }, []),
        c = [...new Set([a, o])].filter(r => r != null),
        l = e.filter(r => !c.includes(r));
    return t.jsxs("div", {
        className: "flex items-center justify-between",
        children: [t.jsx("div", {
            children: t.jsx(m, b({}, q.locale))
        }), t.jsxs(fs.Root, {
            value: a != null ? a : "auto",
            onValueChange: r => {
                Ue.logEvent("Locale Updated by User", {
                    from_locale: s,
                    to_locale: r,
                    raw_browser_locale: n != null ? n : "",
                    suggested_locale: o != null ? o : ""
                }), $a.logEvent("chatgpt_locale_updated_by_user", r, {
                    from_locale: s,
                    to_locale: r,
                    raw_browser_locale: n != null ? n : "",
                    suggested_locale: o != null ? o : ""
                }), (async () => {
                    const u = r === "auto" ? null : r;
                    await i(u), u === null ? Po(null) : Po(u)
                })()
            },
            children: [t.jsxs(fs.Trigger, {
                children: [t.jsx(fs.Value, {}), t.jsx(fs.Icon, {})]
            }), t.jsx(fs.Portal, {
                children: t.jsxs(fs.Content, {
                    side: void 0,
                    sideOffset: void 0,
                    position: "item-aligned",
                    children: [t.jsx(fs.Item, {
                        value: "auto",
                        children: t.jsx(m, b({}, q.localeAuto))
                    }), c.map(r => {
                        var u;
                        return t.jsx(fs.Item, {
                            value: r,
                            children: (u = Ao[r]) != null ? u : r
                        }, r)
                    }), t.jsx(fs.Separator, {}), l.map(r => {
                        var u;
                        return t.jsx(fs.Item, {
                            value: r,
                            children: (u = Ao[r]) != null ? u : r
                        }, r)
                    })]
                })
            })]
        })]
    })
}

function Mh() {
    const s = K(),
        e = ve(),
        a = Sn(),
        {
            pathname: n,
            hash: o,
            search: i
        } = a,
        c = Qe(() => _o(e)),
        {
            closeSettings: l
        } = Fn(),
        d = w.useRef(!1);
    return w.useEffect(() => {
        bc() || !yc(o) || d.current || (d.current = !0, Mc(e, {
            callbackUrl: "".concat(n).concat(i).concat(o),
            fallbackScreenHint: "login",
            useFallbackScreenHint: !0
        }))
    }, [e, o, n, i]), w.useEffect(() => {
        $a.logEvent("chatgpt_unauthenticated_settings_modal_shown"), Ue.logEvent("Unauthenticated Settings Modal Shown")
    }, []), t.jsx(Js, {
        testId: "modal-settings-unauth",
        isOpen: !0,
        onClose: l,
        type: "success",
        showCloseButton: !0,
        title: s.formatMessage(q.settings),
        children: t.jsx(Q, {
            children: t.jsx(ct, {
                label: s.formatMessage({
                    id: "settingsModal.unauthChatTrainingToggleLabel",
                    defaultMessage: "Improve the model for everyone"
                }),
                enabled: c,
                onChange: r => {
                    _o.set(e, r), Ue.logEvent("No Auth Chat Training Toggled", {
                        isEnabled: r
                    })
                },
                description: t.jsx(m, {
                    id: "rtxsI1",
                    defaultMessage: "Allow your content to be used to train our models, which makes ChatGPT better for you and everyone who uses it. We take steps to protect your privacy. <link>Learn more</link>.",
                    values: {
                        link: r => t.jsx("a", {
                            href: Sr,
                            target: "_blank",
                            className: "underline",
                            rel: "noreferrer",
                            children: r
                        })
                    }
                })
            })
        })
    })
}

function Gp({
    onBack: s
}) {
    const e = K(),
        a = ve(),
        n = kt(!0),
        {
            data: o
        } = Et(ie.EnableRemoteBrowserData),
        i = () => {
            $e(a, jr, {
                onDeleteBrowserContext: () => tt.safeDelete("/agent/browser_context", {})
            })
        };
    return t.jsxs(Ne, {
        title: t.jsxs("div", {
            className: "flex items-center gap-2",
            children: [t.jsx("button", {
                "aria-label": e.formatMessage({
                    id: "settingsModal.back",
                    defaultMessage: "Back"
                }),
                onClick: s,
                className: "hover:bg-token-bg-tertiary -ms-1 rounded p-1",
                children: t.jsx(On, {
                    className: "icon-sm"
                })
            }), t.jsx("span", {
                children: e.formatMessage(q.remoteBrowserData)
            })]
        }),
        children: [t.jsx(Q, {
            children: t.jsx(ct, {
                label: e.formatMessage(q.remoteBrowserDataKeepLabel),
                enabled: !!o,
                onChange: c => {
                    n.mutate({
                        setting: ie.EnableRemoteBrowserData,
                        value: c
                    })
                },
                description: t.jsx(m, b({}, q.remoteBrowserDataKeepDescription)),
                "data-testid": "remote-browser-data-toggle"
            })
        }), t.jsx(Q, {
            children: t.jsx(Lt, {
                color: "danger-outline",
                label: e.formatMessage(q.deleteBrowserContext),
                buttonLabel: e.formatMessage(q.deleteBrowserContextButton),
                onClick: i,
                "data-testid": "delete-browser-context-button"
            })
        })]
    })
}
export {
    yh as G, Fm as P, hm as R, Op as S, Mh as U, bh as a, Um as b, q as m, xh as u
};
//# sourceMappingURL=h1fcjd3llzasn5hk.js.map