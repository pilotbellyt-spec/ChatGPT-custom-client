var f = Object.defineProperty,
    h = Object.defineProperties;
var y = Object.getOwnPropertyDescriptors;
var x = Object.getOwnPropertySymbols;
var b = Object.prototype.hasOwnProperty,
    j = Object.prototype.propertyIsEnumerable;
var m = (l, e, t) => e in l ? f(l, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : l[e] = t,
    u = (l, e) => {
        for (var t in e || (e = {})) b.call(e, t) && m(l, t, e[t]);
        if (x)
            for (var t of x(e)) j.call(e, t) && m(l, t, e[t]);
        return l
    },
    d = (l, e) => h(l, y(e));
import {
    r as v,
    j as s
} from "./fg33krlcm0qyi6yw.js";
import {
    R as k,
    I as N
} from "./k15yxxoybkkir2ou.js";
import {
    l as n,
    bg as S
} from "./dykg4ktvbu3mhmdo.js";

function C({
    ariaLabel: l,
    isCompact: e = !1,
    className: t,
    leftItem: o,
    onChange: i,
    rightItem: r,
    value: a
}) {
    const p = a === o.value,
        c = v.useId();
    return s.jsx(k, {
        type: "single",
        "aria-label": l,
        onClick: () => {
            i(p ? r.value : o.value)
        },
        value: a,
        className: n("bg-token-main-surface-tertiary cursor-pointer rounded-full p-1 select-none", t),
        children: s.jsxs("div", {
            className: "relative grid h-full grid-cols-2 gap-1",
            children: [s.jsx(g, d(u({}, o), {
                isCompact: e,
                isSelected: a === o.value,
                highlightLayoutId: c
            })), s.jsx(g, d(u({}, r), {
                isCompact: e,
                isSelected: a === r.value,
                highlightLayoutId: c
            }))]
        })
    })
}

function g({
    ariaLabel: l,
    isSelected: e,
    label: t,
    value: o,
    isCompact: i = !1,
    className: r,
    highlightLayoutId: a
}) {
    return s.jsxs("div", {
        className: n("relative z-10 h-full px-3 text-center font-medium", i ? "py-1 text-xs" : "py-1.5 text-sm"),
        children: [s.jsx(N, {
            "aria-label": l,
            className: n({
                "box-content h-full": !0,
                "text-token-text-primary": e,
                "text-token-text-tertiary": !e
            }),
            value: o,
            children: t
        }), e ? s.jsx(S.div, {
            transition: {
                duration: .05
            },
            layoutId: a,
            className: n("bg-token-bg-primary absolute inset-0 -z-10 box-content h-full rounded-full shadow-sm", r)
        }) : null]
    })
}
export {
    C as S
};
//# sourceMappingURL=mcy89srphizz0hls.js.map