import {
    dw as m,
    s_ as A,
    da as l,
    de as b,
    ik as k,
    _ as f
} from "./dykg4ktvbu3mhmdo.js";
import {
    r as K
} from "./fg33krlcm0qyi6yw.js";

function h(e, r, n) {
    const t = m(),
        c = e.map(d => {
            const {
                keyboardBinding: i
            } = d;
            let s = i.join("+");
            if (d.altKeyboardBindings) {
                s = [s];
                const u = d.altKeyboardBindings.map(o => o.join("+"));
                s = s.concat(u)
            }
            return A(s, {
                byKey: !0
            })
        });
    l(() => {
        var u;
        if ((n == null ? void 0 : n.enabled) === !1) return;
        const d = o => {
                if (!o.repeat)
                    for (let a = 0; a < c.length; a++) c[a](o) && (e[a].enabled === void 0 || e[a].enabled) && (o.preventDefault(), r(e[a]), e[a].action(o))
            },
            i = o => {
                o.key !== void 0 && d(o)
            },
            s = (u = t == null ? void 0 : t.document) != null ? u : document;
        return s.addEventListener("keydown", i), () => {
            s.removeEventListener("keydown", i)
        }
    }, [e, n])
}
const y = b(e => ({
        actions: [],
        addActionsActions: r => e(n => ({
            actions: k([...n.actions, ...r], t => t.key)
        })),
        removeActionsActions: r => {
            const n = r.map(t => t.key);
            return e(t => ({
                actions: t.actions.filter(c => !n.includes(c.key))
            }))
        }
    })),
    v = e => h(e, r => {
        f.addAction("wham_keyboard_shortcut", {
            keyboardActionKey: r.key
        })
    }, {
        enabled: !0
    });

function E() {
    return y(e => e.actions)
}

function S(e = []) {
    const r = y(t => t.addActionsActions),
        n = y(t => t.removeActionsActions);
    K.useEffect(() => (r(e), () => n(e)), [e, r, n]), v(e)
}
export {
    E as a, S as u
};
//# sourceMappingURL=jdbfnvyv9bb4osfa.js.map