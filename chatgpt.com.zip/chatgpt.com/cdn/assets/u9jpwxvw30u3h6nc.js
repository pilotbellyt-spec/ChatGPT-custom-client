import {
    r as e,
    j as r
} from "./fg33krlcm0qyi6yw.js";
const n = e.createContext(void 0);

function s({
    value: t,
    children: o
}) {
    return r.jsx(n.Provider, {
        value: t,
        children: o
    })
}

function x() {
    return e.useContext(n)
}
export {
    s as E, x as u
};
//# sourceMappingURL=u9jpwxvw30u3h6nc.js.map