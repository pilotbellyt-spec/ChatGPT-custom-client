import {
    j as s
} from "./fg33krlcm0qyi6yw.js";
import {
    B as e
} from "./k15yxxoybkkir2ou.js";
import {
    l as a
} from "./dykg4ktvbu3mhmdo.js";
const n = ({
    className: r
}) => {
    const m = "relative flex flex-1 flex-col justify-center gap-3 rounded-2xl px-6 pt-6 pb-8 text-sm",
        c = a("border border-token-border-default", "md:min-h-[30rem] md:max-w-96 md:pb-6");
    return s.jsxs("div", {
        className: a(m, c, "bg-token-main-surface-primary", "w-full", r),
        role: "status",
        "aria-busy": "true",
        children: [s.jsxs("div", {
            className: "mt-2 mb-5 flex items-center justify-between gap-4",
            children: [s.jsx(e, {
                className: "h-8 w-15"
            }), s.jsx(e, {
                className: "h-5 w-20 rounded-full"
            })]
        }), s.jsxs("div", {
            className: "mb-2 flex items-end gap-4",
            children: [s.jsx(e, {
                className: "h-15 w-20"
            }), s.jsxs("div", {
                className: "flex w-44 flex-col gap-2",
                children: [s.jsx(e, {
                    className: "h-5 w-10"
                }), s.jsx(e, {
                    className: "h-5 w-20"
                })]
            })]
        }), s.jsx(e, {
            className: "mb-3 h-5 w-2/3"
        }), s.jsx(e, {
            className: "mb-5 h-10 w-full rounded-full"
        }), s.jsx("div", {
            className: "flex flex-col gap-5",
            children: Array.from({
                length: 7
            }).map((t, l) => s.jsxs("div", {
                className: "grid grid-cols-[20px_1fr] items-center gap-3",
                children: [s.jsx(e, {
                    className: "h-5 w-5 rounded"
                }), s.jsx(e, {
                    className: a("h-5", ["w-[88%]", "w-[92%]", "w-[86%]", "w-[90%]", "w-[84%]", "w-[96%]", "w-[85%]"][l])
                })]
            }, l))
        }), s.jsx("div", {
            className: "mt-8 flex flex-col gap-1",
            children: s.jsx(e, {
                className: "h-3 w-5/6"
            })
        })]
    })
};
export {
    n as P
};
//# sourceMappingURL=ky2byeos1ob0g323.js.map