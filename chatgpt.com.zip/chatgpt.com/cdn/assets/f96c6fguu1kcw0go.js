function lr() {
    let i = 0,
        n = 0;
    for (let e = 0; e < 28; e += 7) {
        let o = this.buf[this.pos++];
        if (i |= (o & 127) << e, (o & 128) == 0) return this.assertBounds(), [i, n]
    }
    let t = this.buf[this.pos++];
    if (i |= (t & 15) << 28, n = (t & 112) >> 4, (t & 128) == 0) return this.assertBounds(), [i, n];
    for (let e = 3; e <= 31; e += 7) {
        let o = this.buf[this.pos++];
        if (n |= (o & 127) << e, (o & 128) == 0) return this.assertBounds(), [i, n]
    }
    throw new Error("invalid varint")
}

function dn(i, n, t) {
    for (let r = 0; r < 28; r = r + 7) {
        const u = i >>> r,
            c = !(!(u >>> 7) && n == 0),
            s = (c ? u | 128 : u) & 255;
        if (t.push(s), !c) return
    }
    const e = i >>> 28 & 15 | (n & 7) << 4,
        o = n >> 3 != 0;
    if (t.push((o ? e | 128 : e) & 255), !!o) {
        for (let r = 3; r < 31; r = r + 7) {
            const u = n >>> r,
                c = !!(u >>> 7),
                s = (c ? u | 128 : u) & 255;
            if (t.push(s), !c) return
        }
        t.push(n >>> 31 & 1)
    }
}
const un = 4294967296;

function Rn(i) {
    const n = i[0] === "-";
    n && (i = i.slice(1));
    const t = 1e6;
    let e = 0,
        o = 0;

    function r(u, c) {
        const s = Number(i.slice(u, c));
        o *= t, e = e * t + s, e >= un && (o = o + (e / un | 0), e = e % un)
    }
    return r(-24, -18), r(-18, -12), r(-12, -6), r(-6), n ? tr(e, o) : cn(e, o)
}

function _r(i, n) {
    let t = cn(i, n);
    const e = t.hi & 2147483648;
    e && (t = tr(t.lo, t.hi));
    const o = nr(t.lo, t.hi);
    return e ? "-" + o : o
}

function nr(i, n) {
    if ({
            lo: i,
            hi: n
        } = cr(i, n), n <= 2097151) return String(un * n + i);
    const t = i & 16777215,
        e = (i >>> 24 | n << 8) & 16777215,
        o = n >> 16 & 65535;
    let r = t + e * 6777216 + o * 6710656,
        u = e + o * 8147497,
        c = o * 2;
    const s = 1e7;
    return r >= s && (u += Math.floor(r / s), r %= s), u >= s && (c += Math.floor(u / s), u %= s), c.toString() + sn(u) + sn(r)
}

function cr(i, n) {
    return {
        lo: i >>> 0,
        hi: n >>> 0
    }
}

function cn(i, n) {
    return {
        lo: i | 0,
        hi: n | 0
    }
}

function tr(i, n) {
    return n = ~n, i ? i = ~i + 1 : n += 1, cn(i, n)
}
const sn = i => {
    const n = String(i);
    return "0000000".slice(n.length) + n
};

function An(i, n) {
    if (i >= 0) {
        for (; i > 127;) n.push(i & 127 | 128), i = i >>> 7;
        n.push(i)
    } else {
        for (let t = 0; t < 9; t++) n.push(i & 127 | 128), i = i >> 7;
        n.push(1)
    }
}

function fr() {
    let i = this.buf[this.pos++],
        n = i & 127;
    if ((i & 128) == 0) return this.assertBounds(), n;
    if (i = this.buf[this.pos++], n |= (i & 127) << 7, (i & 128) == 0) return this.assertBounds(), n;
    if (i = this.buf[this.pos++], n |= (i & 127) << 14, (i & 128) == 0) return this.assertBounds(), n;
    if (i = this.buf[this.pos++], n |= (i & 127) << 21, (i & 128) == 0) return this.assertBounds(), n;
    i = this.buf[this.pos++], n |= (i & 15) << 28;
    for (let t = 5;
        (i & 128) !== 0 && t < 10; t++) i = this.buf[this.pos++];
    if ((i & 128) != 0) throw new Error("invalid varint");
    return this.assertBounds(), n >>> 0
}
var Nn = {};
const K = Tr();

function Tr() {
    const i = new DataView(new ArrayBuffer(8));
    if (typeof BigInt == "function" && typeof i.getBigInt64 == "function" && typeof i.getBigUint64 == "function" && typeof i.setBigInt64 == "function" && typeof i.setBigUint64 == "function" && (typeof process != "object" || typeof Nn != "object" || Nn.BUF_BIGINT_DISABLE !== "1")) {
        const t = BigInt("-9223372036854775808"),
            e = BigInt("9223372036854775807"),
            o = BigInt("0"),
            r = BigInt("18446744073709551615");
        return {
            zero: BigInt(0),
            supported: !0,
            parse(u) {
                const c = typeof u == "bigint" ? u : BigInt(u);
                if (c > e || c < t) throw new Error("invalid int64: ".concat(u));
                return c
            },
            uParse(u) {
                const c = typeof u == "bigint" ? u : BigInt(u);
                if (c > r || c < o) throw new Error("invalid uint64: ".concat(u));
                return c
            },
            enc(u) {
                return i.setBigInt64(0, this.parse(u), !0), {
                    lo: i.getInt32(0, !0),
                    hi: i.getInt32(4, !0)
                }
            },
            uEnc(u) {
                return i.setBigInt64(0, this.uParse(u), !0), {
                    lo: i.getInt32(0, !0),
                    hi: i.getInt32(4, !0)
                }
            },
            dec(u, c) {
                return i.setInt32(0, u, !0), i.setInt32(4, c, !0), i.getBigInt64(0, !0)
            },
            uDec(u, c) {
                return i.setInt32(0, u, !0), i.setInt32(4, c, !0), i.getBigUint64(0, !0)
            }
        }
    }
    return {
        zero: "0",
        supported: !1,
        parse(t) {
            return typeof t != "string" && (t = t.toString()), Sn(t), t
        },
        uParse(t) {
            return typeof t != "string" && (t = t.toString()), vn(t), t
        },
        enc(t) {
            return typeof t != "string" && (t = t.toString()), Sn(t), Rn(t)
        },
        uEnc(t) {
            return typeof t != "string" && (t = t.toString()), vn(t), Rn(t)
        },
        dec(t, e) {
            return _r(t, e)
        },
        uDec(t, e) {
            return nr(t, e)
        }
    }
}

function Sn(i) {
    if (!/^-?[0-9]+$/.test(i)) throw new Error("invalid int64: " + i)
}

function vn(i) {
    if (!/^[0-9]+$/.test(i)) throw new Error("invalid uint64: " + i)
}
const ln = Symbol.for("@bufbuild/protobuf/text-encoding");

function rr() {
    if (globalThis[ln] == null) {
        const i = new globalThis.TextEncoder,
            n = new globalThis.TextDecoder;
        globalThis[ln] = {
            encodeUtf8(t) {
                return i.encode(t)
            },
            decodeUtf8(t) {
                return n.decode(t)
            },
            checkUtf8(t) {
                try {
                    return encodeURIComponent(t), !0
                } catch (e) {
                    return !1
                }
            }
        }
    }
    return globalThis[ln]
}
var z;
(function(i) {
    i[i.Varint = 0] = "Varint", i[i.Bit64 = 1] = "Bit64", i[i.LengthDelimited = 2] = "LengthDelimited", i[i.StartGroup = 3] = "StartGroup", i[i.EndGroup = 4] = "EndGroup", i[i.Bit32 = 5] = "Bit32"
})(z || (z = {}));
const Or = 34028234663852886e22,
    Rr = -34028234663852886e22,
    sr = 4294967295,
    Ar = 2147483647,
    Nr = -2147483648;
class O {
    constructor(n = rr().encodeUtf8) {
        this.encodeUtf8 = n, this.stack = [], this.chunks = [], this.buf = []
    }
    finish() {
        this.buf.length && (this.chunks.push(new Uint8Array(this.buf)), this.buf = []);
        let n = 0;
        for (let o = 0; o < this.chunks.length; o++) n += this.chunks[o].length;
        let t = new Uint8Array(n),
            e = 0;
        for (let o = 0; o < this.chunks.length; o++) t.set(this.chunks[o], e), e += this.chunks[o].length;
        return this.chunks = [], t
    }
    fork() {
        return this.stack.push({
            chunks: this.chunks,
            buf: this.buf
        }), this.chunks = [], this.buf = [], this
    }
    join() {
        let n = this.finish(),
            t = this.stack.pop();
        if (!t) throw new Error("invalid state, fork stack empty");
        return this.chunks = t.chunks, this.buf = t.buf, this.uint32(n.byteLength), this.raw(n)
    }
    tag(n, t) {
        return this.uint32((n << 3 | t) >>> 0)
    }
    raw(n) {
        return this.buf.length && (this.chunks.push(new Uint8Array(this.buf)), this.buf = []), this.chunks.push(n), this
    }
    uint32(n) {
        for (Pn(n); n > 127;) this.buf.push(n & 127 | 128), n = n >>> 7;
        return this.buf.push(n), this
    }
    int32(n) {
        return _n(n), An(n, this.buf), this
    }
    bool(n) {
        return this.buf.push(n ? 1 : 0), this
    }
    bytes(n) {
        return this.uint32(n.byteLength), this.raw(n)
    }
    string(n) {
        let t = this.encodeUtf8(n);
        return this.uint32(t.byteLength), this.raw(t)
    }
    float(n) {
        Sr(n);
        let t = new Uint8Array(4);
        return new DataView(t.buffer).setFloat32(0, n, !0), this.raw(t)
    }
    double(n) {
        let t = new Uint8Array(8);
        return new DataView(t.buffer).setFloat64(0, n, !0), this.raw(t)
    }
    fixed32(n) {
        Pn(n);
        let t = new Uint8Array(4);
        return new DataView(t.buffer).setUint32(0, n, !0), this.raw(t)
    }
    sfixed32(n) {
        _n(n);
        let t = new Uint8Array(4);
        return new DataView(t.buffer).setInt32(0, n, !0), this.raw(t)
    }
    sint32(n) {
        return _n(n), n = (n << 1 ^ n >> 31) >>> 0, An(n, this.buf), this
    }
    sfixed64(n) {
        let t = new Uint8Array(8),
            e = new DataView(t.buffer),
            o = K.enc(n);
        return e.setInt32(0, o.lo, !0), e.setInt32(4, o.hi, !0), this.raw(t)
    }
    fixed64(n) {
        let t = new Uint8Array(8),
            e = new DataView(t.buffer),
            o = K.uEnc(n);
        return e.setInt32(0, o.lo, !0), e.setInt32(4, o.hi, !0), this.raw(t)
    }
    int64(n) {
        let t = K.enc(n);
        return dn(t.lo, t.hi, this.buf), this
    }
    sint64(n) {
        const t = K.enc(n),
            e = t.hi >> 31,
            o = t.lo << 1 ^ e,
            r = (t.hi << 1 | t.lo >>> 31) ^ e;
        return dn(o, r, this.buf), this
    }
    uint64(n) {
        const t = K.uEnc(n);
        return dn(t.lo, t.hi, this.buf), this
    }
}
class a {
    constructor(n, t = rr().decodeUtf8) {
        this.decodeUtf8 = t, this.varint64 = lr, this.uint32 = fr, this.buf = n, this.len = n.length, this.pos = 0, this.view = new DataView(n.buffer, n.byteOffset, n.byteLength)
    }
    tag() {
        let n = this.uint32(),
            t = n >>> 3,
            e = n & 7;
        if (t <= 0 || e < 0 || e > 5) throw new Error("illegal tag: field no " + t + " wire type " + e);
        return [t, e]
    }
    skip(n, t) {
        let e = this.pos;
        switch (n) {
            case z.Varint:
                for (; this.buf[this.pos++] & 128;);
                break;
            case z.Bit64:
                this.pos += 4;
            case z.Bit32:
                this.pos += 4;
                break;
            case z.LengthDelimited:
                let o = this.uint32();
                this.pos += o;
                break;
            case z.StartGroup:
                for (;;) {
                    const [r, u] = this.tag();
                    if (u === z.EndGroup) {
                        if (t !== void 0 && r !== t) throw new Error("invalid end group tag");
                        break
                    }
                    this.skip(u, r)
                }
                break;
            default:
                throw new Error("cant skip wire type " + n)
        }
        return this.assertBounds(), this.buf.subarray(e, this.pos)
    }
    assertBounds() {
        if (this.pos > this.len) throw new RangeError("premature EOF")
    }
    int32() {
        return this.uint32() | 0
    }
    sint32() {
        let n = this.uint32();
        return n >>> 1 ^ -(n & 1)
    }
    int64() {
        return K.dec(...this.varint64())
    }
    uint64() {
        return K.uDec(...this.varint64())
    }
    sint64() {
        let [n, t] = this.varint64(), e = -(n & 1);
        return n = (n >>> 1 | (t & 1) << 31) ^ e, t = t >>> 1 ^ e, K.dec(n, t)
    }
    bool() {
        let [n, t] = this.varint64();
        return n !== 0 || t !== 0
    }
    fixed32() {
        return this.view.getUint32((this.pos += 4) - 4, !0)
    }
    sfixed32() {
        return this.view.getInt32((this.pos += 4) - 4, !0)
    }
    fixed64() {
        return K.uDec(this.sfixed32(), this.sfixed32())
    }
    sfixed64() {
        return K.dec(this.sfixed32(), this.sfixed32())
    }
    float() {
        return this.view.getFloat32((this.pos += 4) - 4, !0)
    }
    double() {
        return this.view.getFloat64((this.pos += 8) - 8, !0)
    }
    bytes() {
        let n = this.uint32(),
            t = this.pos;
        return this.pos += n, this.assertBounds(), this.buf.subarray(t, t + n)
    }
    string() {
        return this.decodeUtf8(this.bytes())
    }
}

function _n(i) {
    if (typeof i == "string") i = Number(i);
    else if (typeof i != "number") throw new Error("invalid int32: " + typeof i);
    if (!Number.isInteger(i) || i > Ar || i < Nr) throw new Error("invalid int32: " + i)
}

function Pn(i) {
    if (typeof i == "string") i = Number(i);
    else if (typeof i != "number") throw new Error("invalid uint32: " + typeof i);
    if (!Number.isInteger(i) || i > sr || i < 0) throw new Error("invalid uint32: " + i)
}

function Sr(i) {
    if (typeof i == "string") {
        const n = i;
        if (i = Number(i), Number.isNaN(i) && n !== "NaN") throw new Error("invalid float32: " + n)
    } else if (typeof i != "number") throw new Error("invalid float32: " + typeof i);
    if (Number.isFinite(i) && (i > Or || i < Rr)) throw new Error("invalid float32: " + i)
}
var vr = (i => (i[i.COLOR_TYPE_UNSPECIFIED = 0] = "COLOR_TYPE_UNSPECIFIED", i[i.COLOR_TYPE_RGB = 1] = "COLOR_TYPE_RGB", i[i.COLOR_TYPE_SCHEME = 2] = "COLOR_TYPE_SCHEME", i[i.COLOR_TYPE_SYSTEM = 3] = "COLOR_TYPE_SYSTEM", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(vr || {});

function Pr(i) {
    switch (i) {
        case 0:
        case "COLOR_TYPE_UNSPECIFIED":
            return 0;
        case 1:
        case "COLOR_TYPE_RGB":
            return 1;
        case 2:
        case "COLOR_TYPE_SCHEME":
            return 2;
        case 3:
        case "COLOR_TYPE_SYSTEM":
            return 3;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Ir(i) {
    switch (i) {
        case 0:
            return "COLOR_TYPE_UNSPECIFIED";
        case 1:
            return "COLOR_TYPE_RGB";
        case 2:
            return "COLOR_TYPE_SCHEME";
        case 3:
            return "COLOR_TYPE_SYSTEM";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var Lr = (i => (i[i.FILL_TYPE_UNSPECIFIED = 0] = "FILL_TYPE_UNSPECIFIED", i[i.FILL_TYPE_SOLID = 1] = "FILL_TYPE_SOLID", i[i.FILL_TYPE_GRADIENT = 2] = "FILL_TYPE_GRADIENT", i[i.FILL_TYPE_PATTERN = 3] = "FILL_TYPE_PATTERN", i[i.FILL_TYPE_PICTURE = 4] = "FILL_TYPE_PICTURE", i[i.FILL_TYPE_VIDEO = 5] = "FILL_TYPE_VIDEO", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(Lr || {});

function Cr(i) {
    switch (i) {
        case 0:
        case "FILL_TYPE_UNSPECIFIED":
            return 0;
        case 1:
        case "FILL_TYPE_SOLID":
            return 1;
        case 2:
        case "FILL_TYPE_GRADIENT":
            return 2;
        case 3:
        case "FILL_TYPE_PATTERN":
            return 3;
        case 4:
        case "FILL_TYPE_PICTURE":
            return 4;
        case 5:
        case "FILL_TYPE_VIDEO":
            return 5;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Mr(i) {
    switch (i) {
        case 0:
            return "FILL_TYPE_UNSPECIFIED";
        case 1:
            return "FILL_TYPE_SOLID";
        case 2:
            return "FILL_TYPE_GRADIENT";
        case 3:
            return "FILL_TYPE_PATTERN";
        case 4:
            return "FILL_TYPE_PICTURE";
        case 5:
            return "FILL_TYPE_VIDEO";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var hr = (i => (i[i.ALIGNMENT_TYPE_UNSPECIFIED = 0] = "ALIGNMENT_TYPE_UNSPECIFIED", i[i.ALIGNMENT_TYPE_LEFT = 1] = "ALIGNMENT_TYPE_LEFT", i[i.ALIGNMENT_TYPE_CENTER = 2] = "ALIGNMENT_TYPE_CENTER", i[i.ALIGNMENT_TYPE_RIGHT = 3] = "ALIGNMENT_TYPE_RIGHT", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(hr || {});

function Yr(i) {
    switch (i) {
        case 0:
        case "ALIGNMENT_TYPE_UNSPECIFIED":
            return 0;
        case 1:
        case "ALIGNMENT_TYPE_LEFT":
            return 1;
        case 2:
        case "ALIGNMENT_TYPE_CENTER":
            return 2;
        case 3:
        case "ALIGNMENT_TYPE_RIGHT":
            return 3;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Hr(i) {
    switch (i) {
        case 0:
            return "ALIGNMENT_TYPE_UNSPECIFIED";
        case 1:
            return "ALIGNMENT_TYPE_LEFT";
        case 2:
            return "ALIGNMENT_TYPE_CENTER";
        case 3:
            return "ALIGNMENT_TYPE_RIGHT";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var pr = (i => (i[i.ANCHOR_TYPE_UNSPECIFIED = 0] = "ANCHOR_TYPE_UNSPECIFIED", i[i.ANCHOR_TYPE_TOP = 1] = "ANCHOR_TYPE_TOP", i[i.ANCHOR_TYPE_MIDDLE = 2] = "ANCHOR_TYPE_MIDDLE", i[i.ANCHOR_TYPE_BOTTOM = 3] = "ANCHOR_TYPE_BOTTOM", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(pr || {});

function kr(i) {
    switch (i) {
        case 0:
        case "ANCHOR_TYPE_UNSPECIFIED":
            return 0;
        case 1:
        case "ANCHOR_TYPE_TOP":
            return 1;
        case 2:
        case "ANCHOR_TYPE_MIDDLE":
            return 2;
        case 3:
        case "ANCHOR_TYPE_BOTTOM":
            return 3;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Dr(i) {
    switch (i) {
        case 0:
            return "ANCHOR_TYPE_UNSPECIFIED";
        case 1:
            return "ANCHOR_TYPE_TOP";
        case 2:
            return "ANCHOR_TYPE_MIDDLE";
        case 3:
            return "ANCHOR_TYPE_BOTTOM";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var Gr = (i => (i[i.VERTICAL_TYPE_UNSPECIFIED = 0] = "VERTICAL_TYPE_UNSPECIFIED", i[i.VERTICAL_TYPE_HORIZONTAL = 1] = "VERTICAL_TYPE_HORIZONTAL", i[i.VERTICAL_TYPE_VERTICAL = 2] = "VERTICAL_TYPE_VERTICAL", i[i.VERTICAL_TYPE_VERTICAL_270 = 3] = "VERTICAL_TYPE_VERTICAL_270", i[i.VERTICAL_TYPE_WORD_ART_VERTICAL = 4] = "VERTICAL_TYPE_WORD_ART_VERTICAL", i[i.VERTICAL_TYPE_EA_VERTICAL = 5] = "VERTICAL_TYPE_EA_VERTICAL", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(Gr || {});

function Ur(i) {
    switch (i) {
        case 0:
        case "VERTICAL_TYPE_UNSPECIFIED":
            return 0;
        case 1:
        case "VERTICAL_TYPE_HORIZONTAL":
            return 1;
        case 2:
        case "VERTICAL_TYPE_VERTICAL":
            return 2;
        case 3:
        case "VERTICAL_TYPE_VERTICAL_270":
            return 3;
        case 4:
        case "VERTICAL_TYPE_WORD_ART_VERTICAL":
            return 4;
        case 5:
        case "VERTICAL_TYPE_EA_VERTICAL":
            return 5;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Br(i) {
    switch (i) {
        case 0:
            return "VERTICAL_TYPE_UNSPECIFIED";
        case 1:
            return "VERTICAL_TYPE_HORIZONTAL";
        case 2:
            return "VERTICAL_TYPE_VERTICAL";
        case 3:
            return "VERTICAL_TYPE_VERTICAL_270";
        case 4:
            return "VERTICAL_TYPE_WORD_ART_VERTICAL";
        case 5:
            return "VERTICAL_TYPE_EA_VERTICAL";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var Fr = (i => (i[i.GRADIENT_KIND_UNSPECIFIED = 0] = "GRADIENT_KIND_UNSPECIFIED", i[i.GRADIENT_KIND_LINEAR = 1] = "GRADIENT_KIND_LINEAR", i[i.GRADIENT_KIND_PATH = 2] = "GRADIENT_KIND_PATH", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(Fr || {});

function xr(i) {
    switch (i) {
        case 0:
        case "GRADIENT_KIND_UNSPECIFIED":
            return 0;
        case 1:
        case "GRADIENT_KIND_LINEAR":
            return 1;
        case 2:
        case "GRADIENT_KIND_PATH":
            return 2;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function yr(i) {
    switch (i) {
        case 0:
            return "GRADIENT_KIND_UNSPECIFIED";
        case 1:
            return "GRADIENT_KIND_LINEAR";
        case 2:
            return "GRADIENT_KIND_PATH";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var Jr = (i => (i[i.GRADIENT_PATH_TYPE_UNSPECIFIED = 0] = "GRADIENT_PATH_TYPE_UNSPECIFIED", i[i.GRADIENT_PATH_TYPE_SHAPE = 1] = "GRADIENT_PATH_TYPE_SHAPE", i[i.GRADIENT_PATH_TYPE_RECT = 2] = "GRADIENT_PATH_TYPE_RECT", i[i.GRADIENT_PATH_TYPE_CIRCLE = 3] = "GRADIENT_PATH_TYPE_CIRCLE", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(Jr || {});

function wr(i) {
    switch (i) {
        case 0:
        case "GRADIENT_PATH_TYPE_UNSPECIFIED":
            return 0;
        case 1:
        case "GRADIENT_PATH_TYPE_SHAPE":
            return 1;
        case 2:
        case "GRADIENT_PATH_TYPE_RECT":
            return 2;
        case 3:
        case "GRADIENT_PATH_TYPE_CIRCLE":
            return 3;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Wr(i) {
    switch (i) {
        case 0:
            return "GRADIENT_PATH_TYPE_UNSPECIFIED";
        case 1:
            return "GRADIENT_PATH_TYPE_SHAPE";
        case 2:
            return "GRADIENT_PATH_TYPE_RECT";
        case 3:
            return "GRADIENT_PATH_TYPE_CIRCLE";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function mr(i) {
    switch (i) {
        case 0:
        case "CONTENT_REFERENCE_TYPE_UNSPECIFIED":
            return 0;
        case 1:
        case "CONTENT_REFERENCE_TYPE_INTERNAL":
            return 1;
        case 2:
        case "CONTENT_REFERENCE_TYPE_EXTERNAL":
            return 2;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Vr(i) {
    switch (i) {
        case 0:
            return "CONTENT_REFERENCE_TYPE_UNSPECIFIED";
        case 1:
            return "CONTENT_REFERENCE_TYPE_INTERNAL";
        case 2:
            return "CONTENT_REFERENCE_TYPE_EXTERNAL";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function Kr(i) {
    switch (i) {
        case 0:
        case "SOURCE_TYPE_UNSPECIFIED":
            return 0;
        case 1:
        case "SOURCE_TYPE_WEBPAGE":
            return 1;
        case 2:
        case "SOURCE_TYPE_IMAGE":
            return 2;
        case 3:
        case "SOURCE_TYPE_FILE":
            return 3;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Zr(i) {
    switch (i) {
        case 0:
            return "SOURCE_TYPE_UNSPECIFIED";
        case 1:
            return "SOURCE_TYPE_WEBPAGE";
        case 2:
            return "SOURCE_TYPE_IMAGE";
        case 3:
            return "SOURCE_TYPE_FILE";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var Xr = (i => (i[i.PATTERN_TYPE_UNSPECIFIED = 0] = "PATTERN_TYPE_UNSPECIFIED", i[i.PATTERN_TYPE_NONE = 1] = "PATTERN_TYPE_NONE", i[i.PATTERN_TYPE_SOLID = 2] = "PATTERN_TYPE_SOLID", i[i.PATTERN_TYPE_MEDIUM_GRAY = 3] = "PATTERN_TYPE_MEDIUM_GRAY", i[i.PATTERN_TYPE_DARK_GRAY = 4] = "PATTERN_TYPE_DARK_GRAY", i[i.PATTERN_TYPE_LIGHT_GRAY = 5] = "PATTERN_TYPE_LIGHT_GRAY", i[i.PATTERN_TYPE_DARK_HORIZONTAL = 6] = "PATTERN_TYPE_DARK_HORIZONTAL", i[i.PATTERN_TYPE_DARK_VERTICAL = 7] = "PATTERN_TYPE_DARK_VERTICAL", i[i.PATTERN_TYPE_DARK_DOWN = 8] = "PATTERN_TYPE_DARK_DOWN", i[i.PATTERN_TYPE_DARK_UP = 9] = "PATTERN_TYPE_DARK_UP", i[i.PATTERN_TYPE_DARK_GRID = 10] = "PATTERN_TYPE_DARK_GRID", i[i.PATTERN_TYPE_DARK_TRELLIS = 11] = "PATTERN_TYPE_DARK_TRELLIS", i[i.PATTERN_TYPE_LIGHT_HORIZONTAL = 12] = "PATTERN_TYPE_LIGHT_HORIZONTAL", i[i.PATTERN_TYPE_LIGHT_VERTICAL = 13] = "PATTERN_TYPE_LIGHT_VERTICAL", i[i.PATTERN_TYPE_LIGHT_DOWN = 14] = "PATTERN_TYPE_LIGHT_DOWN", i[i.PATTERN_TYPE_LIGHT_UP = 15] = "PATTERN_TYPE_LIGHT_UP", i[i.PATTERN_TYPE_LIGHT_GRID = 16] = "PATTERN_TYPE_LIGHT_GRID", i[i.PATTERN_TYPE_LIGHT_TRELLIS = 17] = "PATTERN_TYPE_LIGHT_TRELLIS", i[i.PATTERN_TYPE_GRAY125 = 18] = "PATTERN_TYPE_GRAY125", i[i.PATTERN_TYPE_GRAY0625 = 19] = "PATTERN_TYPE_GRAY0625", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(Xr || {});

function zr(i) {
    switch (i) {
        case 0:
        case "PATTERN_TYPE_UNSPECIFIED":
            return 0;
        case 1:
        case "PATTERN_TYPE_NONE":
            return 1;
        case 2:
        case "PATTERN_TYPE_SOLID":
            return 2;
        case 3:
        case "PATTERN_TYPE_MEDIUM_GRAY":
            return 3;
        case 4:
        case "PATTERN_TYPE_DARK_GRAY":
            return 4;
        case 5:
        case "PATTERN_TYPE_LIGHT_GRAY":
            return 5;
        case 6:
        case "PATTERN_TYPE_DARK_HORIZONTAL":
            return 6;
        case 7:
        case "PATTERN_TYPE_DARK_VERTICAL":
            return 7;
        case 8:
        case "PATTERN_TYPE_DARK_DOWN":
            return 8;
        case 9:
        case "PATTERN_TYPE_DARK_UP":
            return 9;
        case 10:
        case "PATTERN_TYPE_DARK_GRID":
            return 10;
        case 11:
        case "PATTERN_TYPE_DARK_TRELLIS":
            return 11;
        case 12:
        case "PATTERN_TYPE_LIGHT_HORIZONTAL":
            return 12;
        case 13:
        case "PATTERN_TYPE_LIGHT_VERTICAL":
            return 13;
        case 14:
        case "PATTERN_TYPE_LIGHT_DOWN":
            return 14;
        case 15:
        case "PATTERN_TYPE_LIGHT_UP":
            return 15;
        case 16:
        case "PATTERN_TYPE_LIGHT_GRID":
            return 16;
        case 17:
        case "PATTERN_TYPE_LIGHT_TRELLIS":
            return 17;
        case 18:
        case "PATTERN_TYPE_GRAY125":
            return 18;
        case 19:
        case "PATTERN_TYPE_GRAY0625":
            return 19;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Qr(i) {
    switch (i) {
        case 0:
            return "PATTERN_TYPE_UNSPECIFIED";
        case 1:
            return "PATTERN_TYPE_NONE";
        case 2:
            return "PATTERN_TYPE_SOLID";
        case 3:
            return "PATTERN_TYPE_MEDIUM_GRAY";
        case 4:
            return "PATTERN_TYPE_DARK_GRAY";
        case 5:
            return "PATTERN_TYPE_LIGHT_GRAY";
        case 6:
            return "PATTERN_TYPE_DARK_HORIZONTAL";
        case 7:
            return "PATTERN_TYPE_DARK_VERTICAL";
        case 8:
            return "PATTERN_TYPE_DARK_DOWN";
        case 9:
            return "PATTERN_TYPE_DARK_UP";
        case 10:
            return "PATTERN_TYPE_DARK_GRID";
        case 11:
            return "PATTERN_TYPE_DARK_TRELLIS";
        case 12:
            return "PATTERN_TYPE_LIGHT_HORIZONTAL";
        case 13:
            return "PATTERN_TYPE_LIGHT_VERTICAL";
        case 14:
            return "PATTERN_TYPE_LIGHT_DOWN";
        case 15:
            return "PATTERN_TYPE_LIGHT_UP";
        case 16:
            return "PATTERN_TYPE_LIGHT_GRID";
        case 17:
            return "PATTERN_TYPE_LIGHT_TRELLIS";
        case 18:
            return "PATTERN_TYPE_GRAY125";
        case 19:
            return "PATTERN_TYPE_GRAY0625";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var qr = (i => (i[i.LINE_STYLE_UNSPECIFIED = 0] = "LINE_STYLE_UNSPECIFIED", i[i.LINE_STYLE_SOLID = 1] = "LINE_STYLE_SOLID", i[i.LINE_STYLE_DASHED = 2] = "LINE_STYLE_DASHED", i[i.LINE_STYLE_DOTTED = 3] = "LINE_STYLE_DOTTED", i[i.LINE_STYLE_DASH_DOT = 4] = "LINE_STYLE_DASH_DOT", i[i.LINE_STYLE_DASH_DOT_DOT = 5] = "LINE_STYLE_DASH_DOT_DOT", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(qr || {});

function $r(i) {
    switch (i) {
        case 0:
        case "LINE_STYLE_UNSPECIFIED":
            return 0;
        case 1:
        case "LINE_STYLE_SOLID":
            return 1;
        case 2:
        case "LINE_STYLE_DASHED":
            return 2;
        case 3:
        case "LINE_STYLE_DOTTED":
            return 3;
        case 4:
        case "LINE_STYLE_DASH_DOT":
            return 4;
        case 5:
        case "LINE_STYLE_DASH_DOT_DOT":
            return 5;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function gr(i) {
    switch (i) {
        case 0:
            return "LINE_STYLE_UNSPECIFIED";
        case 1:
            return "LINE_STYLE_SOLID";
        case 2:
            return "LINE_STYLE_DASHED";
        case 3:
            return "LINE_STYLE_DOTTED";
        case 4:
            return "LINE_STYLE_DASH_DOT";
        case 5:
            return "LINE_STYLE_DASH_DOT_DOT";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function In() {
    return {
        xEmu: void 0,
        yEmu: void 0,
        widthEmu: void 0,
        heightEmu: void 0,
        rotation: void 0,
        horizontalFlip: void 0,
        verticalFlip: void 0
    }
}
const F = {
    encode(i, n = new O) {
        return i.xEmu !== void 0 && n.uint32(8).int64(i.xEmu), i.yEmu !== void 0 && n.uint32(16).int64(i.yEmu), i.widthEmu !== void 0 && n.uint32(24).int64(i.widthEmu), i.heightEmu !== void 0 && n.uint32(32).int64(i.heightEmu), i.rotation !== void 0 && n.uint32(40).int32(i.rotation), i.horizontalFlip !== void 0 && n.uint32(48).bool(i.horizontalFlip), i.verticalFlip !== void 0 && n.uint32(56).bool(i.verticalFlip), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = In();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.xEmu = En(t.int64());
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.yEmu = En(t.int64());
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;o.widthEmu = En(t.int64());
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;o.heightEmu = En(t.int64());
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;o.rotation = t.int32();
                        continue
                    }
                case 6:
                    {
                        if (r !== 48) break;o.horizontalFlip = t.bool();
                        continue
                    }
                case 7:
                    {
                        if (r !== 56) break;o.verticalFlip = t.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            xEmu: f(i.xEmu) ? R.Number(i.xEmu) : void 0,
            yEmu: f(i.yEmu) ? R.Number(i.yEmu) : void 0,
            widthEmu: f(i.widthEmu) ? R.Number(i.widthEmu) : void 0,
            heightEmu: f(i.heightEmu) ? R.Number(i.heightEmu) : void 0,
            rotation: f(i.rotation) ? R.Number(i.rotation) : void 0,
            horizontalFlip: f(i.horizontalFlip) ? R.Boolean(i.horizontalFlip) : void 0,
            verticalFlip: f(i.verticalFlip) ? R.Boolean(i.verticalFlip) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.xEmu !== void 0 && (n.xEmu = Math.round(i.xEmu)), i.yEmu !== void 0 && (n.yEmu = Math.round(i.yEmu)), i.widthEmu !== void 0 && (n.widthEmu = Math.round(i.widthEmu)), i.heightEmu !== void 0 && (n.heightEmu = Math.round(i.heightEmu)), i.rotation !== void 0 && (n.rotation = Math.round(i.rotation)), i.horizontalFlip !== void 0 && (n.horizontalFlip = i.horizontalFlip), i.verticalFlip !== void 0 && (n.verticalFlip = i.verticalFlip), n
    },
    create(i) {
        return F.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u, c, s;
        const n = In();
        return n.xEmu = (t = i.xEmu) != null ? t : void 0, n.yEmu = (e = i.yEmu) != null ? e : void 0, n.widthEmu = (o = i.widthEmu) != null ? o : void 0, n.heightEmu = (r = i.heightEmu) != null ? r : void 0, n.rotation = (u = i.rotation) != null ? u : void 0, n.horizontalFlip = (c = i.horizontalFlip) != null ? c : void 0, n.verticalFlip = (s = i.verticalFlip) != null ? s : void 0, n
    }
};

function Ln() {
    return {
        tint: void 0,
        shade: void 0,
        lumMod: void 0,
        lumOff: void 0,
        satMod: void 0,
        alpha: void 0
    }
}
const q = {
    encode(i, n = new O) {
        return i.tint !== void 0 && n.uint32(8).int32(i.tint), i.shade !== void 0 && n.uint32(16).int32(i.shade), i.lumMod !== void 0 && n.uint32(24).int32(i.lumMod), i.lumOff !== void 0 && n.uint32(32).int32(i.lumOff), i.satMod !== void 0 && n.uint32(40).int32(i.satMod), i.alpha !== void 0 && n.uint32(48).int32(i.alpha), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Ln();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.tint = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.shade = t.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;o.lumMod = t.int32();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;o.lumOff = t.int32();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;o.satMod = t.int32();
                        continue
                    }
                case 6:
                    {
                        if (r !== 48) break;o.alpha = t.int32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            tint: f(i.tint) ? R.Number(i.tint) : void 0,
            shade: f(i.shade) ? R.Number(i.shade) : void 0,
            lumMod: f(i.lumMod) ? R.Number(i.lumMod) : void 0,
            lumOff: f(i.lumOff) ? R.Number(i.lumOff) : void 0,
            satMod: f(i.satMod) ? R.Number(i.satMod) : void 0,
            alpha: f(i.alpha) ? R.Number(i.alpha) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.tint !== void 0 && (n.tint = Math.round(i.tint)), i.shade !== void 0 && (n.shade = Math.round(i.shade)), i.lumMod !== void 0 && (n.lumMod = Math.round(i.lumMod)), i.lumOff !== void 0 && (n.lumOff = Math.round(i.lumOff)), i.satMod !== void 0 && (n.satMod = Math.round(i.satMod)), i.alpha !== void 0 && (n.alpha = Math.round(i.alpha)), n
    },
    create(i) {
        return q.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u, c;
        const n = Ln();
        return n.tint = (t = i.tint) != null ? t : void 0, n.shade = (e = i.shade) != null ? e : void 0, n.lumMod = (o = i.lumMod) != null ? o : void 0, n.lumOff = (r = i.lumOff) != null ? r : void 0, n.satMod = (u = i.satMod) != null ? u : void 0, n.alpha = (c = i.alpha) != null ? c : void 0, n
    }
};

function Cn() {
    return {
        type: 0,
        value: "",
        transform: void 0,
        lastColor: void 0
    }
}
const S = {
    encode(i, n = new O) {
        return i.type !== 0 && n.uint32(8).int32(i.type), i.value !== "" && n.uint32(18).string(i.value), i.transform !== void 0 && q.encode(i.transform, n.uint32(26).fork()).join(), i.lastColor !== void 0 && n.uint32(34).string(i.lastColor), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Cn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.type = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.value = t.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.transform = q.decode(t, t.uint32());
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;o.lastColor = t.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            type: f(i.type) ? Pr(i.type) : 0,
            value: f(i.value) ? R.String(i.value) : "",
            transform: f(i.transform) ? q.fromJSON(i.transform) : void 0,
            lastColor: f(i.lastColor) ? R.String(i.lastColor) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.type !== 0 && (n.type = Ir(i.type)), i.value !== "" && (n.value = i.value), i.transform !== void 0 && (n.transform = q.toJSON(i.transform)), i.lastColor !== void 0 && (n.lastColor = i.lastColor), n
    },
    create(i) {
        return S.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o;
        const n = Cn();
        return n.type = (t = i.type) != null ? t : 0, n.value = (e = i.value) != null ? e : "", n.transform = i.transform !== void 0 && i.transform !== null ? q.fromPartial(i.transform) : void 0, n.lastColor = (o = i.lastColor) != null ? o : void 0, n
    }
};

function Mn() {
    return {
        ref: void 0,
        fill: void 0
    }
}
const x = {
    encode(i, n = new O) {
        return i.ref !== void 0 && $.encode(i.ref, n.uint32(18).fork()).join(), i.fill !== void 0 && A.encode(i.fill, n.uint32(26).fork()).join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Mn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 2:
                    {
                        if (r !== 18) break;o.ref = $.decode(t, t.uint32());
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.fill = A.decode(t, t.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            ref: f(i.ref) ? $.fromJSON(i.ref) : void 0,
            fill: f(i.fill) ? A.fromJSON(i.fill) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.ref !== void 0 && (n.ref = $.toJSON(i.ref)), i.fill !== void 0 && (n.fill = A.toJSON(i.fill)), n
    },
    create(i) {
        return x.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        const n = Mn();
        return n.ref = i.ref !== void 0 && i.ref !== null ? $.fromPartial(i.ref) : void 0, n.fill = i.fill !== void 0 && i.fill !== null ? A.fromPartial(i.fill) : void 0, n
    }
};

function hn() {
    return {
        index: 0,
        schemeColor: ""
    }
}
const $ = {
    encode(i, n = new O) {
        return i.index !== 0 && n.uint32(8).int32(i.index), i.schemeColor !== "" && n.uint32(18).string(i.schemeColor), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = hn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.index = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.schemeColor = t.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            index: f(i.index) ? R.Number(i.index) : 0,
            schemeColor: f(i.schemeColor) ? R.String(i.schemeColor) : ""
        }
    },
    toJSON(i) {
        const n = {};
        return i.index !== 0 && (n.index = Math.round(i.index)), i.schemeColor !== "" && (n.schemeColor = i.schemeColor), n
    },
    create(i) {
        return $.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e;
        const n = hn();
        return n.index = (t = i.index) != null ? t : 0, n.schemeColor = (e = i.schemeColor) != null ? e : "", n
    }
};

function Yn() {
    return {
        id: void 0,
        type: 0,
        color: void 0,
        gradientStops: [],
        relId: void 0,
        gradientKind: void 0,
        angleDeg: void 0,
        isScaled: void 0,
        pathType: void 0,
        fillRect: void 0,
        imageReference: void 0,
        alphaModFix: void 0,
        lum: void 0,
        srcRect: void 0,
        stretchFillRect: void 0,
        duotone: void 0,
        pattern: void 0
    }
}
const A = {
    encode(i, n = new O) {
        i.id !== void 0 && n.uint32(82).string(i.id), i.type !== 0 && n.uint32(8).int32(i.type), i.color !== void 0 && S.encode(i.color, n.uint32(18).fork()).join();
        for (const t of i.gradientStops) j.encode(t, n.uint32(26).fork()).join();
        return i.relId !== void 0 && n.uint32(34).string(i.relId), i.gradientKind !== void 0 && n.uint32(40).int32(i.gradientKind), i.angleDeg !== void 0 && n.uint32(49).double(i.angleDeg), i.isScaled !== void 0 && n.uint32(56).bool(i.isScaled), i.pathType !== void 0 && n.uint32(64).int32(i.pathType), i.fillRect !== void 0 && p.encode(i.fillRect, n.uint32(74).fork()).join(), i.imageReference !== void 0 && y.encode(i.imageReference, n.uint32(90).fork()).join(), i.alphaModFix !== void 0 && n.uint32(96).int32(i.alphaModFix), i.lum !== void 0 && n.uint32(104).bool(i.lum), i.srcRect !== void 0 && p.encode(i.srcRect, n.uint32(114).fork()).join(), i.stretchFillRect !== void 0 && p.encode(i.stretchFillRect, n.uint32(122).fork()).join(), i.duotone !== void 0 && b.encode(i.duotone, n.uint32(130).fork()).join(), i.pattern !== void 0 && g.encode(i.pattern, n.uint32(138).fork()).join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Yn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 10:
                    {
                        if (r !== 82) break;o.id = t.string();
                        continue
                    }
                case 1:
                    {
                        if (r !== 8) break;o.type = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.color = S.decode(t, t.uint32());
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.gradientStops.push(j.decode(t, t.uint32()));
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;o.relId = t.string();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;o.gradientKind = t.int32();
                        continue
                    }
                case 6:
                    {
                        if (r !== 49) break;o.angleDeg = t.double();
                        continue
                    }
                case 7:
                    {
                        if (r !== 56) break;o.isScaled = t.bool();
                        continue
                    }
                case 8:
                    {
                        if (r !== 64) break;o.pathType = t.int32();
                        continue
                    }
                case 9:
                    {
                        if (r !== 74) break;o.fillRect = p.decode(t, t.uint32());
                        continue
                    }
                case 11:
                    {
                        if (r !== 90) break;o.imageReference = y.decode(t, t.uint32());
                        continue
                    }
                case 12:
                    {
                        if (r !== 96) break;o.alphaModFix = t.int32();
                        continue
                    }
                case 13:
                    {
                        if (r !== 104) break;o.lum = t.bool();
                        continue
                    }
                case 14:
                    {
                        if (r !== 114) break;o.srcRect = p.decode(t, t.uint32());
                        continue
                    }
                case 15:
                    {
                        if (r !== 122) break;o.stretchFillRect = p.decode(t, t.uint32());
                        continue
                    }
                case 16:
                    {
                        if (r !== 130) break;o.duotone = b.decode(t, t.uint32());
                        continue
                    }
                case 17:
                    {
                        if (r !== 138) break;o.pattern = g.decode(t, t.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            id: f(i.id) ? R.String(i.id) : void 0,
            type: f(i.type) ? Cr(i.type) : 0,
            color: f(i.color) ? S.fromJSON(i.color) : void 0,
            gradientStops: R.Array.isArray(i == null ? void 0 : i.gradientStops) ? i.gradientStops.map(n => j.fromJSON(n)) : [],
            relId: f(i.relId) ? R.String(i.relId) : void 0,
            gradientKind: f(i.gradientKind) ? xr(i.gradientKind) : void 0,
            angleDeg: f(i.angleDeg) ? R.Number(i.angleDeg) : void 0,
            isScaled: f(i.isScaled) ? R.Boolean(i.isScaled) : void 0,
            pathType: f(i.pathType) ? wr(i.pathType) : void 0,
            fillRect: f(i.fillRect) ? p.fromJSON(i.fillRect) : void 0,
            imageReference: f(i.imageReference) ? y.fromJSON(i.imageReference) : void 0,
            alphaModFix: f(i.alphaModFix) ? R.Number(i.alphaModFix) : void 0,
            lum: f(i.lum) ? R.Boolean(i.lum) : void 0,
            srcRect: f(i.srcRect) ? p.fromJSON(i.srcRect) : void 0,
            stretchFillRect: f(i.stretchFillRect) ? p.fromJSON(i.stretchFillRect) : void 0,
            duotone: f(i.duotone) ? b.fromJSON(i.duotone) : void 0,
            pattern: f(i.pattern) ? g.fromJSON(i.pattern) : void 0
        }
    },
    toJSON(i) {
        var t;
        const n = {};
        return i.id !== void 0 && (n.id = i.id), i.type !== 0 && (n.type = Mr(i.type)), i.color !== void 0 && (n.color = S.toJSON(i.color)), (t = i.gradientStops) != null && t.length && (n.gradientStops = i.gradientStops.map(e => j.toJSON(e))), i.relId !== void 0 && (n.relId = i.relId), i.gradientKind !== void 0 && (n.gradientKind = yr(i.gradientKind)), i.angleDeg !== void 0 && (n.angleDeg = i.angleDeg), i.isScaled !== void 0 && (n.isScaled = i.isScaled), i.pathType !== void 0 && (n.pathType = Wr(i.pathType)), i.fillRect !== void 0 && (n.fillRect = p.toJSON(i.fillRect)), i.imageReference !== void 0 && (n.imageReference = y.toJSON(i.imageReference)), i.alphaModFix !== void 0 && (n.alphaModFix = Math.round(i.alphaModFix)), i.lum !== void 0 && (n.lum = i.lum), i.srcRect !== void 0 && (n.srcRect = p.toJSON(i.srcRect)), i.stretchFillRect !== void 0 && (n.stretchFillRect = p.toJSON(i.stretchFillRect)), i.duotone !== void 0 && (n.duotone = b.toJSON(i.duotone)), i.pattern !== void 0 && (n.pattern = g.toJSON(i.pattern)), n
    },
    create(i) {
        return A.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u, c, s, v, P, L;
        const n = Yn();
        return n.id = (t = i.id) != null ? t : void 0, n.type = (e = i.type) != null ? e : 0, n.color = i.color !== void 0 && i.color !== null ? S.fromPartial(i.color) : void 0, n.gradientStops = ((o = i.gradientStops) == null ? void 0 : o.map(I => j.fromPartial(I))) || [], n.relId = (r = i.relId) != null ? r : void 0, n.gradientKind = (u = i.gradientKind) != null ? u : void 0, n.angleDeg = (c = i.angleDeg) != null ? c : void 0, n.isScaled = (s = i.isScaled) != null ? s : void 0, n.pathType = (v = i.pathType) != null ? v : void 0, n.fillRect = i.fillRect !== void 0 && i.fillRect !== null ? p.fromPartial(i.fillRect) : void 0, n.imageReference = i.imageReference !== void 0 && i.imageReference !== null ? y.fromPartial(i.imageReference) : void 0, n.alphaModFix = (P = i.alphaModFix) != null ? P : void 0, n.lum = (L = i.lum) != null ? L : void 0, n.srcRect = i.srcRect !== void 0 && i.srcRect !== null ? p.fromPartial(i.srcRect) : void 0, n.stretchFillRect = i.stretchFillRect !== void 0 && i.stretchFillRect !== null ? p.fromPartial(i.stretchFillRect) : void 0, n.duotone = i.duotone !== void 0 && i.duotone !== null ? b.fromPartial(i.duotone) : void 0, n.pattern = i.pattern !== void 0 && i.pattern !== null ? g.fromPartial(i.pattern) : void 0, n
    }
};

function Hn() {
    return {
        patternType: 0,
        color: void 0
    }
}
const g = {
    encode(i, n = new O) {
        return i.patternType !== 0 && n.uint32(8).int32(i.patternType), i.color !== void 0 && S.encode(i.color, n.uint32(26).fork()).join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Hn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.patternType = t.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.color = S.decode(t, t.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            patternType: f(i.patternType) ? zr(i.patternType) : 0,
            color: f(i.color) ? S.fromJSON(i.color) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.patternType !== 0 && (n.patternType = Qr(i.patternType)), i.color !== void 0 && (n.color = S.toJSON(i.color)), n
    },
    create(i) {
        return g.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t;
        const n = Hn();
        return n.patternType = (t = i.patternType) != null ? t : 0, n.color = i.color !== void 0 && i.color !== null ? S.fromPartial(i.color) : void 0, n
    }
};

function pn() {
    return {
        id: ""
    }
}
const y = {
    encode(i, n = new O) {
        return i.id !== "" && n.uint32(10).string(i.id), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = pn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.id = t.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            id: f(i.id) ? R.String(i.id) : ""
        }
    },
    toJSON(i) {
        const n = {};
        return i.id !== "" && (n.id = i.id), n
    },
    create(i) {
        return y.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t;
        const n = pn();
        return n.id = (t = i.id) != null ? t : "", n
    }
};

function kn() {
    return {
        darkColor: void 0,
        lightColor: void 0
    }
}
const b = {
    encode(i, n = new O) {
        return i.darkColor !== void 0 && S.encode(i.darkColor, n.uint32(10).fork()).join(), i.lightColor !== void 0 && S.encode(i.lightColor, n.uint32(18).fork()).join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = kn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.darkColor = S.decode(t, t.uint32());
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.lightColor = S.decode(t, t.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            darkColor: f(i.darkColor) ? S.fromJSON(i.darkColor) : void 0,
            lightColor: f(i.lightColor) ? S.fromJSON(i.lightColor) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.darkColor !== void 0 && (n.darkColor = S.toJSON(i.darkColor)), i.lightColor !== void 0 && (n.lightColor = S.toJSON(i.lightColor)), n
    },
    create(i) {
        return b.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        const n = kn();
        return n.darkColor = i.darkColor !== void 0 && i.darkColor !== null ? S.fromPartial(i.darkColor) : void 0, n.lightColor = i.lightColor !== void 0 && i.lightColor !== null ? S.fromPartial(i.lightColor) : void 0, n
    }
};

function Dn() {
    return {
        position: void 0,
        color: void 0
    }
}
const j = {
    encode(i, n = new O) {
        return i.position !== void 0 && n.uint32(8).int32(i.position), i.color !== void 0 && S.encode(i.color, n.uint32(18).fork()).join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Dn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.position = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.color = S.decode(t, t.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            position: f(i.position) ? R.Number(i.position) : void 0,
            color: f(i.color) ? S.fromJSON(i.color) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.position !== void 0 && (n.position = Math.round(i.position)), i.color !== void 0 && (n.color = S.toJSON(i.color)), n
    },
    create(i) {
        return j.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t;
        const n = Dn();
        return n.position = (t = i.position) != null ? t : void 0, n.color = i.color !== void 0 && i.color !== null ? S.fromPartial(i.color) : void 0, n
    }
};

function Gn() {
    return {
        anchor: void 0,
        vertical: void 0,
        rotation: void 0,
        bold: void 0,
        italic: void 0,
        fontSize: void 0,
        fill: void 0,
        alignment: void 0,
        underline: void 0,
        bottomInset: void 0,
        leftInset: void 0,
        rightInset: void 0,
        topInset: void 0,
        useParagraphSpacing: void 0,
        name: void 0,
        family: void 0,
        scheme: void 0,
        typeface: void 0
    }
}
const N = {
    encode(i, n = new O) {
        return i.anchor !== void 0 && n.uint32(8).int32(i.anchor), i.vertical !== void 0 && n.uint32(16).int32(i.vertical), i.rotation !== void 0 && n.uint32(24).int32(i.rotation), i.bold !== void 0 && n.uint32(32).bool(i.bold), i.italic !== void 0 && n.uint32(40).bool(i.italic), i.fontSize !== void 0 && n.uint32(48).int32(i.fontSize), i.fill !== void 0 && A.encode(i.fill, n.uint32(58).fork()).join(), i.alignment !== void 0 && n.uint32(64).int32(i.alignment), i.underline !== void 0 && n.uint32(74).string(i.underline), i.bottomInset !== void 0 && n.uint32(80).int32(i.bottomInset), i.leftInset !== void 0 && n.uint32(88).int32(i.leftInset), i.rightInset !== void 0 && n.uint32(96).int32(i.rightInset), i.topInset !== void 0 && n.uint32(104).int32(i.topInset), i.useParagraphSpacing !== void 0 && n.uint32(112).bool(i.useParagraphSpacing), i.name !== void 0 && n.uint32(122).string(i.name), i.family !== void 0 && n.uint32(128).int32(i.family), i.scheme !== void 0 && n.uint32(138).string(i.scheme), i.typeface !== void 0 && n.uint32(146).string(i.typeface), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Gn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.anchor = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.vertical = t.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;o.rotation = t.int32();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;o.bold = t.bool();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;o.italic = t.bool();
                        continue
                    }
                case 6:
                    {
                        if (r !== 48) break;o.fontSize = t.int32();
                        continue
                    }
                case 7:
                    {
                        if (r !== 58) break;o.fill = A.decode(t, t.uint32());
                        continue
                    }
                case 8:
                    {
                        if (r !== 64) break;o.alignment = t.int32();
                        continue
                    }
                case 9:
                    {
                        if (r !== 74) break;o.underline = t.string();
                        continue
                    }
                case 10:
                    {
                        if (r !== 80) break;o.bottomInset = t.int32();
                        continue
                    }
                case 11:
                    {
                        if (r !== 88) break;o.leftInset = t.int32();
                        continue
                    }
                case 12:
                    {
                        if (r !== 96) break;o.rightInset = t.int32();
                        continue
                    }
                case 13:
                    {
                        if (r !== 104) break;o.topInset = t.int32();
                        continue
                    }
                case 14:
                    {
                        if (r !== 112) break;o.useParagraphSpacing = t.bool();
                        continue
                    }
                case 15:
                    {
                        if (r !== 122) break;o.name = t.string();
                        continue
                    }
                case 16:
                    {
                        if (r !== 128) break;o.family = t.int32();
                        continue
                    }
                case 17:
                    {
                        if (r !== 138) break;o.scheme = t.string();
                        continue
                    }
                case 18:
                    {
                        if (r !== 146) break;o.typeface = t.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            anchor: f(i.anchor) ? kr(i.anchor) : void 0,
            vertical: f(i.vertical) ? Ur(i.vertical) : void 0,
            rotation: f(i.rotation) ? R.Number(i.rotation) : void 0,
            bold: f(i.bold) ? R.Boolean(i.bold) : void 0,
            italic: f(i.italic) ? R.Boolean(i.italic) : void 0,
            fontSize: f(i.fontSize) ? R.Number(i.fontSize) : void 0,
            fill: f(i.fill) ? A.fromJSON(i.fill) : void 0,
            alignment: f(i.alignment) ? Yr(i.alignment) : void 0,
            underline: f(i.underline) ? R.String(i.underline) : void 0,
            bottomInset: f(i.bottomInset) ? R.Number(i.bottomInset) : void 0,
            leftInset: f(i.leftInset) ? R.Number(i.leftInset) : void 0,
            rightInset: f(i.rightInset) ? R.Number(i.rightInset) : void 0,
            topInset: f(i.topInset) ? R.Number(i.topInset) : void 0,
            useParagraphSpacing: f(i.useParagraphSpacing) ? R.Boolean(i.useParagraphSpacing) : void 0,
            name: f(i.name) ? R.String(i.name) : void 0,
            family: f(i.family) ? R.Number(i.family) : void 0,
            scheme: f(i.scheme) ? R.String(i.scheme) : void 0,
            typeface: f(i.typeface) ? R.String(i.typeface) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.anchor !== void 0 && (n.anchor = Dr(i.anchor)), i.vertical !== void 0 && (n.vertical = Br(i.vertical)), i.rotation !== void 0 && (n.rotation = Math.round(i.rotation)), i.bold !== void 0 && (n.bold = i.bold), i.italic !== void 0 && (n.italic = i.italic), i.fontSize !== void 0 && (n.fontSize = Math.round(i.fontSize)), i.fill !== void 0 && (n.fill = A.toJSON(i.fill)), i.alignment !== void 0 && (n.alignment = Hr(i.alignment)), i.underline !== void 0 && (n.underline = i.underline), i.bottomInset !== void 0 && (n.bottomInset = Math.round(i.bottomInset)), i.leftInset !== void 0 && (n.leftInset = Math.round(i.leftInset)), i.rightInset !== void 0 && (n.rightInset = Math.round(i.rightInset)), i.topInset !== void 0 && (n.topInset = Math.round(i.topInset)), i.useParagraphSpacing !== void 0 && (n.useParagraphSpacing = i.useParagraphSpacing), i.name !== void 0 && (n.name = i.name), i.family !== void 0 && (n.family = Math.round(i.family)), i.scheme !== void 0 && (n.scheme = i.scheme), i.typeface !== void 0 && (n.typeface = i.typeface), n
    },
    create(i) {
        return N.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u, c, s, v, P, L, I, Y, G, H, Z, X, an;
        const n = Gn();
        return n.anchor = (t = i.anchor) != null ? t : void 0, n.vertical = (e = i.vertical) != null ? e : void 0, n.rotation = (o = i.rotation) != null ? o : void 0, n.bold = (r = i.bold) != null ? r : void 0, n.italic = (u = i.italic) != null ? u : void 0, n.fontSize = (c = i.fontSize) != null ? c : void 0, n.fill = i.fill !== void 0 && i.fill !== null ? A.fromPartial(i.fill) : void 0, n.alignment = (s = i.alignment) != null ? s : void 0, n.underline = (v = i.underline) != null ? v : void 0, n.bottomInset = (P = i.bottomInset) != null ? P : void 0, n.leftInset = (L = i.leftInset) != null ? L : void 0, n.rightInset = (I = i.rightInset) != null ? I : void 0, n.topInset = (Y = i.topInset) != null ? Y : void 0, n.useParagraphSpacing = (G = i.useParagraphSpacing) != null ? G : void 0, n.name = (H = i.name) != null ? H : void 0, n.family = (Z = i.family) != null ? Z : void 0, n.scheme = (X = i.scheme) != null ? X : void 0, n.typeface = (an = i.typeface) != null ? an : void 0, n
    }
};

function Un() {
    return {
        bulletCharacter: void 0,
        marginLeft: void 0,
        indent: void 0,
        lineSpacingPercent: void 0,
        lineSpacingPoints: void 0,
        autoNumberType: void 0,
        autoNumberStartAt: void 0
    }
}
const J = {
    encode(i, n = new O) {
        return i.bulletCharacter !== void 0 && n.uint32(10).string(i.bulletCharacter), i.marginLeft !== void 0 && n.uint32(16).int32(i.marginLeft), i.indent !== void 0 && n.uint32(24).int32(i.indent), i.lineSpacingPercent !== void 0 && n.uint32(32).int32(i.lineSpacingPercent), i.lineSpacingPoints !== void 0 && n.uint32(40).int32(i.lineSpacingPoints), i.autoNumberType !== void 0 && n.uint32(50).string(i.autoNumberType), i.autoNumberStartAt !== void 0 && n.uint32(56).int32(i.autoNumberStartAt), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Un();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.bulletCharacter = t.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.marginLeft = t.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;o.indent = t.int32();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;o.lineSpacingPercent = t.int32();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;o.lineSpacingPoints = t.int32();
                        continue
                    }
                case 6:
                    {
                        if (r !== 50) break;o.autoNumberType = t.string();
                        continue
                    }
                case 7:
                    {
                        if (r !== 56) break;o.autoNumberStartAt = t.int32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            bulletCharacter: f(i.bulletCharacter) ? R.String(i.bulletCharacter) : void 0,
            marginLeft: f(i.marginLeft) ? R.Number(i.marginLeft) : void 0,
            indent: f(i.indent) ? R.Number(i.indent) : void 0,
            lineSpacingPercent: f(i.lineSpacingPercent) ? R.Number(i.lineSpacingPercent) : void 0,
            lineSpacingPoints: f(i.lineSpacingPoints) ? R.Number(i.lineSpacingPoints) : void 0,
            autoNumberType: f(i.autoNumberType) ? R.String(i.autoNumberType) : void 0,
            autoNumberStartAt: f(i.autoNumberStartAt) ? R.Number(i.autoNumberStartAt) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.bulletCharacter !== void 0 && (n.bulletCharacter = i.bulletCharacter), i.marginLeft !== void 0 && (n.marginLeft = Math.round(i.marginLeft)), i.indent !== void 0 && (n.indent = Math.round(i.indent)), i.lineSpacingPercent !== void 0 && (n.lineSpacingPercent = Math.round(i.lineSpacingPercent)), i.lineSpacingPoints !== void 0 && (n.lineSpacingPoints = Math.round(i.lineSpacingPoints)), i.autoNumberType !== void 0 && (n.autoNumberType = i.autoNumberType), i.autoNumberStartAt !== void 0 && (n.autoNumberStartAt = Math.round(i.autoNumberStartAt)), n
    },
    create(i) {
        return J.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u, c, s;
        const n = Un();
        return n.bulletCharacter = (t = i.bulletCharacter) != null ? t : void 0, n.marginLeft = (e = i.marginLeft) != null ? e : void 0, n.indent = (o = i.indent) != null ? o : void 0, n.lineSpacingPercent = (r = i.lineSpacingPercent) != null ? r : void 0, n.lineSpacingPoints = (u = i.lineSpacingPoints) != null ? u : void 0, n.autoNumberType = (c = i.autoNumberType) != null ? c : void 0, n.autoNumberStartAt = (s = i.autoNumberStartAt) != null ? s : void 0, n
    }
};

function Bn() {
    return {
        id: void 0,
        level: 0,
        textStyle: void 0,
        paragraphStyle: void 0,
        spaceBefore: void 0,
        spaceAfter: void 0
    }
}
const C = {
    encode(i, n = new O) {
        return i.id !== void 0 && n.uint32(10).string(i.id), i.level !== 0 && n.uint32(16).int32(i.level), i.textStyle !== void 0 && N.encode(i.textStyle, n.uint32(26).fork()).join(), i.paragraphStyle !== void 0 && J.encode(i.paragraphStyle, n.uint32(34).fork()).join(), i.spaceBefore !== void 0 && n.uint32(40).int32(i.spaceBefore), i.spaceAfter !== void 0 && n.uint32(48).int32(i.spaceAfter), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Bn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.id = t.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.level = t.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.textStyle = N.decode(t, t.uint32());
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;o.paragraphStyle = J.decode(t, t.uint32());
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;o.spaceBefore = t.int32();
                        continue
                    }
                case 6:
                    {
                        if (r !== 48) break;o.spaceAfter = t.int32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            id: f(i.id) ? R.String(i.id) : void 0,
            level: f(i.level) ? R.Number(i.level) : 0,
            textStyle: f(i.textStyle) ? N.fromJSON(i.textStyle) : void 0,
            paragraphStyle: f(i.paragraphStyle) ? J.fromJSON(i.paragraphStyle) : void 0,
            spaceBefore: f(i.spaceBefore) ? R.Number(i.spaceBefore) : void 0,
            spaceAfter: f(i.spaceAfter) ? R.Number(i.spaceAfter) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.id !== void 0 && (n.id = i.id), i.level !== 0 && (n.level = Math.round(i.level)), i.textStyle !== void 0 && (n.textStyle = N.toJSON(i.textStyle)), i.paragraphStyle !== void 0 && (n.paragraphStyle = J.toJSON(i.paragraphStyle)), i.spaceBefore !== void 0 && (n.spaceBefore = Math.round(i.spaceBefore)), i.spaceAfter !== void 0 && (n.spaceAfter = Math.round(i.spaceAfter)), n
    },
    create(i) {
        return C.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r;
        const n = Bn();
        return n.id = (t = i.id) != null ? t : void 0, n.level = (e = i.level) != null ? e : 0, n.textStyle = i.textStyle !== void 0 && i.textStyle !== null ? N.fromPartial(i.textStyle) : void 0, n.paragraphStyle = i.paragraphStyle !== void 0 && i.paragraphStyle !== null ? J.fromPartial(i.paragraphStyle) : void 0, n.spaceBefore = (o = i.spaceBefore) != null ? o : void 0, n.spaceAfter = (r = i.spaceAfter) != null ? r : void 0, n
    }
};

function Fn() {
    return {
        style: 0,
        widthEmu: 0,
        fill: void 0
    }
}
const T = {
    encode(i, n = new O) {
        return i.style !== 0 && n.uint32(8).int32(i.style), i.widthEmu !== 0 && n.uint32(16).int32(i.widthEmu), i.fill !== void 0 && A.encode(i.fill, n.uint32(26).fork()).join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Fn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.style = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.widthEmu = t.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.fill = A.decode(t, t.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            style: f(i.style) ? $r(i.style) : 0,
            widthEmu: f(i.widthEmu) ? R.Number(i.widthEmu) : 0,
            fill: f(i.fill) ? A.fromJSON(i.fill) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.style !== 0 && (n.style = gr(i.style)), i.widthEmu !== 0 && (n.widthEmu = Math.round(i.widthEmu)), i.fill !== void 0 && (n.fill = A.toJSON(i.fill)), n
    },
    create(i) {
        return T.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e;
        const n = Fn();
        return n.style = (t = i.style) != null ? t : 0, n.widthEmu = (e = i.widthEmu) != null ? e : 0, n.fill = i.fill !== void 0 && i.fill !== null ? A.fromPartial(i.fill) : void 0, n
    }
};

function xn() {
    return {
        l: void 0,
        t: void 0,
        r: void 0,
        b: void 0
    }
}
const p = {
    encode(i, n = new O) {
        return i.l !== void 0 && n.uint32(8).int32(i.l), i.t !== void 0 && n.uint32(16).int32(i.t), i.r !== void 0 && n.uint32(24).int32(i.r), i.b !== void 0 && n.uint32(32).int32(i.b), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = xn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.l = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.t = t.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;o.r = t.int32();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;o.b = t.int32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            l: f(i.l) ? R.Number(i.l) : void 0,
            t: f(i.t) ? R.Number(i.t) : void 0,
            r: f(i.r) ? R.Number(i.r) : void 0,
            b: f(i.b) ? R.Number(i.b) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.l !== void 0 && (n.l = Math.round(i.l)), i.t !== void 0 && (n.t = Math.round(i.t)), i.r !== void 0 && (n.r = Math.round(i.r)), i.b !== void 0 && (n.b = Math.round(i.b)), n
    },
    create(i) {
        return p.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r;
        const n = xn();
        return n.l = (t = i.l) != null ? t : void 0, n.t = (e = i.t) != null ? e : void 0, n.r = (o = i.r) != null ? o : void 0, n.b = (r = i.b) != null ? r : void 0, n
    }
};

function yn() {
    return {
        contentType: "",
        data: new Uint8Array(0),
        id: "",
        prompt: void 0,
        uri: void 0
    }
}
const ii = {
    encode(i, n = new O) {
        return i.contentType !== "" && n.uint32(10).string(i.contentType), i.data.length !== 0 && n.uint32(18).bytes(i.data), i.id !== "" && n.uint32(26).string(i.id), i.prompt !== void 0 && n.uint32(34).string(i.prompt), i.uri !== void 0 && n.uint32(42).string(i.uri), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = yn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.contentType = t.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.data = t.bytes();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.id = t.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;o.prompt = t.string();
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;o.uri = t.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            contentType: f(i.contentType) ? R.String(i.contentType) : "",
            data: f(i.data) ? br(i.data) : new Uint8Array(0),
            id: f(i.id) ? R.String(i.id) : "",
            prompt: f(i.prompt) ? R.String(i.prompt) : void 0,
            uri: f(i.uri) ? R.String(i.uri) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.contentType !== "" && (n.contentType = i.contentType), i.data.length !== 0 && (n.data = jr(i.data)), i.id !== "" && (n.id = i.id), i.prompt !== void 0 && (n.prompt = i.prompt), i.uri !== void 0 && (n.uri = i.uri), n
    },
    create(i) {
        return ii.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u;
        const n = yn();
        return n.contentType = (t = i.contentType) != null ? t : "", n.data = (e = i.data) != null ? e : new Uint8Array(0), n.id = (o = i.id) != null ? o : "", n.prompt = (r = i.prompt) != null ? r : void 0, n.uri = (u = i.uri) != null ? u : void 0, n
    }
};

function Jn() {
    return {
        id: "",
        tetherId: "",
        uri: void 0,
        title: void 0,
        type: 0,
        sourceType: void 0,
        targetId: "",
        contentLineRange: void 0,
        contentId: void 0
    }
}
const ni = {
    encode(i, n = new O) {
        return i.id !== "" && n.uint32(10).string(i.id), i.tetherId !== "" && n.uint32(18).string(i.tetherId), i.uri !== void 0 && n.uint32(26).string(i.uri), i.title !== void 0 && n.uint32(34).string(i.title), i.type !== 0 && n.uint32(40).int32(i.type), i.sourceType !== void 0 && n.uint32(48).int32(i.sourceType), i.targetId !== "" && n.uint32(58).string(i.targetId), i.contentLineRange !== void 0 && ti.encode(i.contentLineRange, n.uint32(66).fork()).join(), i.contentId !== void 0 && n.uint32(74).string(i.contentId), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Jn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.id = t.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.tetherId = t.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.uri = t.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;o.title = t.string();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;o.type = t.int32();
                        continue
                    }
                case 6:
                    {
                        if (r !== 48) break;o.sourceType = t.int32();
                        continue
                    }
                case 7:
                    {
                        if (r !== 58) break;o.targetId = t.string();
                        continue
                    }
                case 8:
                    {
                        if (r !== 66) break;o.contentLineRange = ti.decode(t, t.uint32());
                        continue
                    }
                case 9:
                    {
                        if (r !== 74) break;o.contentId = t.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            id: f(i.id) ? R.String(i.id) : "",
            tetherId: f(i.tetherId) ? R.String(i.tetherId) : "",
            uri: f(i.uri) ? R.String(i.uri) : void 0,
            title: f(i.title) ? R.String(i.title) : void 0,
            type: f(i.type) ? mr(i.type) : 0,
            sourceType: f(i.sourceType) ? Kr(i.sourceType) : void 0,
            targetId: f(i.targetId) ? R.String(i.targetId) : "",
            contentLineRange: f(i.contentLineRange) ? ti.fromJSON(i.contentLineRange) : void 0,
            contentId: f(i.contentId) ? R.String(i.contentId) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.id !== "" && (n.id = i.id), i.tetherId !== "" && (n.tetherId = i.tetherId), i.uri !== void 0 && (n.uri = i.uri), i.title !== void 0 && (n.title = i.title), i.type !== 0 && (n.type = Vr(i.type)), i.sourceType !== void 0 && (n.sourceType = Zr(i.sourceType)), i.targetId !== "" && (n.targetId = i.targetId), i.contentLineRange !== void 0 && (n.contentLineRange = ti.toJSON(i.contentLineRange)), i.contentId !== void 0 && (n.contentId = i.contentId), n
    },
    create(i) {
        return ni.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u, c, s, v;
        const n = Jn();
        return n.id = (t = i.id) != null ? t : "", n.tetherId = (e = i.tetherId) != null ? e : "", n.uri = (o = i.uri) != null ? o : void 0, n.title = (r = i.title) != null ? r : void 0, n.type = (u = i.type) != null ? u : 0, n.sourceType = (c = i.sourceType) != null ? c : void 0, n.targetId = (s = i.targetId) != null ? s : "", n.contentLineRange = i.contentLineRange !== void 0 && i.contentLineRange !== null ? ti.fromPartial(i.contentLineRange) : void 0, n.contentId = (v = i.contentId) != null ? v : void 0, n
    }
};

function wn() {
    return {
        startLineNum: 0,
        endLineNum: void 0
    }
}
const ti = {
        encode(i, n = new O) {
            return i.startLineNum !== 0 && n.uint32(8).uint64(i.startLineNum), i.endLineNum !== void 0 && n.uint32(16).uint64(i.endLineNum), n
        },
        decode(i, n) {
            const t = i instanceof a ? i : new a(i);
            let e = n === void 0 ? t.len : t.pos + n;
            const o = wn();
            for (; t.pos < e;) {
                const r = t.uint32();
                switch (r >>> 3) {
                    case 1:
                        {
                            if (r !== 8) break;o.startLineNum = En(t.uint64());
                            continue
                        }
                    case 2:
                        {
                            if (r !== 16) break;o.endLineNum = En(t.uint64());
                            continue
                        }
                }
                if ((r & 7) === 4 || r === 0) break;
                t.skip(r & 7)
            }
            return o
        },
        fromJSON(i) {
            return {
                startLineNum: f(i.startLineNum) ? R.Number(i.startLineNum) : 0,
                endLineNum: f(i.endLineNum) ? R.Number(i.endLineNum) : void 0
            }
        },
        toJSON(i) {
            const n = {};
            return i.startLineNum !== 0 && (n.startLineNum = Math.round(i.startLineNum)), i.endLineNum !== void 0 && (n.endLineNum = Math.round(i.endLineNum)), n
        },
        create(i) {
            return ti.fromPartial(i != null ? i : {})
        },
        fromPartial(i) {
            var t, e;
            const n = wn();
            return n.startLineNum = (t = i.startLineNum) != null ? t : 0, n.endLineNum = (e = i.endLineNum) != null ? e : void 0, n
        }
    },
    R = (() => {
        if (typeof globalThis < "u") return globalThis;
        if (typeof self < "u") return self;
        if (typeof window < "u") return window;
        if (typeof global < "u") return global;
        throw "Unable to locate global object"
    })();

function br(i) {
    if (R.Buffer) return Uint8Array.from(R.Buffer.from(i, "base64")); {
        const n = R.atob(i),
            t = new Uint8Array(n.length);
        for (let e = 0; e < n.length; ++e) t[e] = n.charCodeAt(e);
        return t
    }
}

function jr(i) {
    if (R.Buffer) return R.Buffer.from(i).toString("base64"); {
        const n = [];
        return i.forEach(t => {
            n.push(R.String.fromCharCode(t))
        }), R.btoa(n.join(""))
    }
}

function En(i) {
    const n = R.Number(i.toString());
    if (n > R.Number.MAX_SAFE_INTEGER) throw new R.Error("Value is larger than Number.MAX_SAFE_INTEGER");
    if (n < R.Number.MIN_SAFE_INTEGER) throw new R.Error("Value is smaller than Number.MIN_SAFE_INTEGER");
    return n
}

function f(i) {
    return i != null
}
var io = (i => (i[i.LEGEND_POSITION_UNSPECIFIED = 0] = "LEGEND_POSITION_UNSPECIFIED", i[i.LEGEND_POSITION_RIGHT = 1] = "LEGEND_POSITION_RIGHT", i[i.LEGEND_POSITION_LEFT = 2] = "LEGEND_POSITION_LEFT", i[i.LEGEND_POSITION_TOP = 3] = "LEGEND_POSITION_TOP", i[i.LEGEND_POSITION_BOTTOM = 4] = "LEGEND_POSITION_BOTTOM", i[i.LEGEND_POSITION_TOP_RIGHT = 5] = "LEGEND_POSITION_TOP_RIGHT", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(io || {});

function no(i) {
    switch (i) {
        case 0:
        case "LEGEND_POSITION_UNSPECIFIED":
            return 0;
        case 1:
        case "LEGEND_POSITION_RIGHT":
            return 1;
        case 2:
        case "LEGEND_POSITION_LEFT":
            return 2;
        case 3:
        case "LEGEND_POSITION_TOP":
            return 3;
        case 4:
        case "LEGEND_POSITION_BOTTOM":
            return 4;
        case 5:
        case "LEGEND_POSITION_TOP_RIGHT":
            return 5;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function to(i) {
    switch (i) {
        case 0:
            return "LEGEND_POSITION_UNSPECIFIED";
        case 1:
            return "LEGEND_POSITION_RIGHT";
        case 2:
            return "LEGEND_POSITION_LEFT";
        case 3:
            return "LEGEND_POSITION_TOP";
        case 4:
            return "LEGEND_POSITION_BOTTOM";
        case 5:
            return "LEGEND_POSITION_TOP_RIGHT";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var ro = (i => (i[i.BAR_DIRECTION_UNSPECIFIED = 0] = "BAR_DIRECTION_UNSPECIFIED", i[i.BAR_DIRECTION_COLUMN = 1] = "BAR_DIRECTION_COLUMN", i[i.BAR_DIRECTION_BAR = 2] = "BAR_DIRECTION_BAR", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(ro || {});

function or(i) {
    switch (i) {
        case 0:
        case "BAR_DIRECTION_UNSPECIFIED":
            return 0;
        case 1:
        case "BAR_DIRECTION_COLUMN":
            return 1;
        case 2:
        case "BAR_DIRECTION_BAR":
            return 2;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function er(i) {
    switch (i) {
        case 0:
            return "BAR_DIRECTION_UNSPECIFIED";
        case 1:
            return "BAR_DIRECTION_COLUMN";
        case 2:
            return "BAR_DIRECTION_BAR";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var oo = (i => (i[i.BAR_GROUPING_UNSPECIFIED = 0] = "BAR_GROUPING_UNSPECIFIED", i[i.BAR_GROUPING_CLUSTERED = 1] = "BAR_GROUPING_CLUSTERED", i[i.BAR_GROUPING_STACKED = 2] = "BAR_GROUPING_STACKED", i[i.BAR_GROUPING_PERCENT_STACKED = 3] = "BAR_GROUPING_PERCENT_STACKED", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(oo || {});

function eo(i) {
    switch (i) {
        case 0:
        case "BAR_GROUPING_UNSPECIFIED":
            return 0;
        case 1:
        case "BAR_GROUPING_CLUSTERED":
            return 1;
        case 2:
        case "BAR_GROUPING_STACKED":
            return 2;
        case 3:
        case "BAR_GROUPING_PERCENT_STACKED":
            return 3;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Eo(i) {
    switch (i) {
        case 0:
            return "BAR_GROUPING_UNSPECIFIED";
        case 1:
            return "BAR_GROUPING_CLUSTERED";
        case 2:
            return "BAR_GROUPING_STACKED";
        case 3:
            return "BAR_GROUPING_PERCENT_STACKED";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var ao = (i => (i[i.DATA_LABEL_POSITION_UNSPECIFIED = 0] = "DATA_LABEL_POSITION_UNSPECIFIED", i[i.DATA_LABEL_POSITION_OUT_END = 1] = "DATA_LABEL_POSITION_OUT_END", i[i.DATA_LABEL_POSITION_IN_END = 2] = "DATA_LABEL_POSITION_IN_END", i[i.DATA_LABEL_POSITION_CENTER = 3] = "DATA_LABEL_POSITION_CENTER", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(ao || {});

function Er(i) {
    switch (i) {
        case 0:
        case "DATA_LABEL_POSITION_UNSPECIFIED":
            return 0;
        case 1:
        case "DATA_LABEL_POSITION_OUT_END":
            return 1;
        case 2:
        case "DATA_LABEL_POSITION_IN_END":
            return 2;
        case 3:
        case "DATA_LABEL_POSITION_CENTER":
            return 3;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function ar(i) {
    switch (i) {
        case 0:
            return "DATA_LABEL_POSITION_UNSPECIFIED";
        case 1:
            return "DATA_LABEL_POSITION_OUT_END";
        case 2:
            return "DATA_LABEL_POSITION_IN_END";
        case 3:
            return "DATA_LABEL_POSITION_CENTER";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function uo(i) {
    switch (i) {
        case 0:
        case "DISPLAY_BLANKS_AS_UNSPECIFIED":
            return 0;
        case 1:
        case "DISPLAY_BLANKS_AS_GAP":
            return 1;
        case 2:
        case "DISPLAY_BLANKS_AS_ZERO":
            return 2;
        case 3:
        case "DISPLAY_BLANKS_AS_SPAN":
            return 3;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function lo(i) {
    switch (i) {
        case 0:
            return "DISPLAY_BLANKS_AS_UNSPECIFIED";
        case 1:
            return "DISPLAY_BLANKS_AS_GAP";
        case 2:
            return "DISPLAY_BLANKS_AS_ZERO";
        case 3:
            return "DISPLAY_BLANKS_AS_SPAN";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var _o = (i => (i[i.SCATTER_STYLE_UNSPECIFIED = 0] = "SCATTER_STYLE_UNSPECIFIED", i[i.SCATTER_STYLE_LINE_MARKER = 1] = "SCATTER_STYLE_LINE_MARKER", i[i.SCATTER_STYLE_LINE = 2] = "SCATTER_STYLE_LINE", i[i.SCATTER_STYLE_MARKER = 3] = "SCATTER_STYLE_MARKER", i[i.SCATTER_STYLE_SMOOTH = 4] = "SCATTER_STYLE_SMOOTH", i[i.SCATTER_STYLE_SMOOTH_MARKER = 5] = "SCATTER_STYLE_SMOOTH_MARKER", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(_o || {});

function co(i) {
    switch (i) {
        case 0:
        case "SCATTER_STYLE_UNSPECIFIED":
            return 0;
        case 1:
        case "SCATTER_STYLE_LINE_MARKER":
            return 1;
        case 2:
        case "SCATTER_STYLE_LINE":
            return 2;
        case 3:
        case "SCATTER_STYLE_MARKER":
            return 3;
        case 4:
        case "SCATTER_STYLE_SMOOTH":
            return 4;
        case 5:
        case "SCATTER_STYLE_SMOOTH_MARKER":
            return 5;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function fo(i) {
    switch (i) {
        case 0:
            return "SCATTER_STYLE_UNSPECIFIED";
        case 1:
            return "SCATTER_STYLE_LINE_MARKER";
        case 2:
            return "SCATTER_STYLE_LINE";
        case 3:
            return "SCATTER_STYLE_MARKER";
        case 4:
            return "SCATTER_STYLE_SMOOTH";
        case 5:
            return "SCATTER_STYLE_SMOOTH_MARKER";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var To = (i => (i[i.RADAR_STYLE_UNSPECIFIED = 0] = "RADAR_STYLE_UNSPECIFIED", i[i.RADAR_STYLE_STANDARD = 1] = "RADAR_STYLE_STANDARD", i[i.RADAR_STYLE_MARKER = 2] = "RADAR_STYLE_MARKER", i[i.RADAR_STYLE_FILLED = 3] = "RADAR_STYLE_FILLED", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(To || {});

function Oo(i) {
    switch (i) {
        case 0:
        case "RADAR_STYLE_UNSPECIFIED":
            return 0;
        case 1:
        case "RADAR_STYLE_STANDARD":
            return 1;
        case 2:
        case "RADAR_STYLE_MARKER":
            return 2;
        case 3:
        case "RADAR_STYLE_FILLED":
            return 3;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Ro(i) {
    switch (i) {
        case 0:
            return "RADAR_STYLE_UNSPECIFIED";
        case 1:
            return "RADAR_STYLE_STANDARD";
        case 2:
            return "RADAR_STYLE_MARKER";
        case 3:
            return "RADAR_STYLE_FILLED";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var so = (i => (i[i.LINE_GROUPING_UNSPECIFIED = 0] = "LINE_GROUPING_UNSPECIFIED", i[i.LINE_GROUPING_STANDARD = 1] = "LINE_GROUPING_STANDARD", i[i.LINE_GROUPING_STACKED = 2] = "LINE_GROUPING_STACKED", i[i.LINE_GROUPING_PERCENT_STACKED = 3] = "LINE_GROUPING_PERCENT_STACKED", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(so || {});

function Ao(i) {
    switch (i) {
        case 0:
        case "LINE_GROUPING_UNSPECIFIED":
            return 0;
        case 1:
        case "LINE_GROUPING_STANDARD":
            return 1;
        case 2:
        case "LINE_GROUPING_STACKED":
            return 2;
        case 3:
        case "LINE_GROUPING_PERCENT_STACKED":
            return 3;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function No(i) {
    switch (i) {
        case 0:
            return "LINE_GROUPING_UNSPECIFIED";
        case 1:
            return "LINE_GROUPING_STANDARD";
        case 2:
            return "LINE_GROUPING_STACKED";
        case 3:
            return "LINE_GROUPING_PERCENT_STACKED";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var So = (i => (i[i.AREA_GROUPING_UNSPECIFIED = 0] = "AREA_GROUPING_UNSPECIFIED", i[i.AREA_GROUPING_STANDARD = 1] = "AREA_GROUPING_STANDARD", i[i.AREA_GROUPING_STACKED = 2] = "AREA_GROUPING_STACKED", i[i.AREA_GROUPING_PERCENT_STACKED = 3] = "AREA_GROUPING_PERCENT_STACKED", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(So || {});

function vo(i) {
    switch (i) {
        case 0:
        case "AREA_GROUPING_UNSPECIFIED":
            return 0;
        case 1:
        case "AREA_GROUPING_STANDARD":
            return 1;
        case 2:
        case "AREA_GROUPING_STACKED":
            return 2;
        case 3:
        case "AREA_GROUPING_PERCENT_STACKED":
            return 3;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Po(i) {
    switch (i) {
        case 0:
            return "AREA_GROUPING_UNSPECIFIED";
        case 1:
            return "AREA_GROUPING_STANDARD";
        case 2:
            return "AREA_GROUPING_STACKED";
        case 3:
            return "AREA_GROUPING_PERCENT_STACKED";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function Io(i) {
    switch (i) {
        case 0:
        case "MAP_AREA_UNSPECIFIED":
            return 0;
        case 1:
        case "MAP_AREA_AUTO":
            return 1;
        case 2:
        case "MAP_AREA_WORLD":
            return 2;
        case 3:
        case "MAP_AREA_DATA_ONLY":
            return 3;
        case 4:
        case "MAP_AREA_REGION":
            return 4;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Lo(i) {
    switch (i) {
        case 0:
            return "MAP_AREA_UNSPECIFIED";
        case 1:
            return "MAP_AREA_AUTO";
        case 2:
            return "MAP_AREA_WORLD";
        case 3:
            return "MAP_AREA_DATA_ONLY";
        case 4:
            return "MAP_AREA_REGION";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function Co(i) {
    switch (i) {
        case 0:
        case "MAP_PROJECTION_UNSPECIFIED":
            return 0;
        case 1:
        case "MAP_PROJECTION_AUTO":
            return 1;
        case 2:
        case "MAP_PROJECTION_MERCATOR":
            return 2;
        case 3:
        case "MAP_PROJECTION_MILLER":
            return 3;
        case 4:
        case "MAP_PROJECTION_ALBERS":
            return 4;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Mo(i) {
    switch (i) {
        case 0:
            return "MAP_PROJECTION_UNSPECIFIED";
        case 1:
            return "MAP_PROJECTION_AUTO";
        case 2:
            return "MAP_PROJECTION_MERCATOR";
        case 3:
            return "MAP_PROJECTION_MILLER";
        case 4:
            return "MAP_PROJECTION_ALBERS";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function ho(i) {
    switch (i) {
        case 0:
        case "MAP_LABEL_LAYOUT_UNSPECIFIED":
            return 0;
        case 1:
        case "MAP_LABEL_LAYOUT_NONE":
            return 1;
        case 2:
        case "MAP_LABEL_LAYOUT_BEST_FIT":
            return 2;
        case 3:
        case "MAP_LABEL_LAYOUT_SHOW_ALL":
            return 3;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Yo(i) {
    switch (i) {
        case 0:
            return "MAP_LABEL_LAYOUT_UNSPECIFIED";
        case 1:
            return "MAP_LABEL_LAYOUT_NONE";
        case 2:
            return "MAP_LABEL_LAYOUT_BEST_FIT";
        case 3:
            return "MAP_LABEL_LAYOUT_SHOW_ALL";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function Ho(i) {
    switch (i) {
        case 0:
        case "MAP_DATA_LEVEL_UNSPECIFIED":
            return 0;
        case 1:
        case "MAP_DATA_LEVEL_AUTO":
            return 1;
        case 2:
        case "MAP_DATA_LEVEL_COUNTRY_OR_REGION":
            return 2;
        case 3:
        case "MAP_DATA_LEVEL_STATE_OR_PROVINCE":
            return 3;
        case 4:
        case "MAP_DATA_LEVEL_COUNTY":
            return 4;
        case 5:
        case "MAP_DATA_LEVEL_POSTAL_CODE":
            return 5;
        case 6:
        case "MAP_DATA_LEVEL_COUNTRY_OR_REGION_CODE":
            return 6;
        case 7:
        case "MAP_DATA_LEVEL_STATE_CODE":
            return 7;
        case 8:
        case "MAP_DATA_LEVEL_COUNTY_CODE":
            return 8;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function po(i) {
    switch (i) {
        case 0:
            return "MAP_DATA_LEVEL_UNSPECIFIED";
        case 1:
            return "MAP_DATA_LEVEL_AUTO";
        case 2:
            return "MAP_DATA_LEVEL_COUNTRY_OR_REGION";
        case 3:
            return "MAP_DATA_LEVEL_STATE_OR_PROVINCE";
        case 4:
            return "MAP_DATA_LEVEL_COUNTY";
        case 5:
            return "MAP_DATA_LEVEL_POSTAL_CODE";
        case 6:
            return "MAP_DATA_LEVEL_COUNTRY_OR_REGION_CODE";
        case 7:
            return "MAP_DATA_LEVEL_STATE_CODE";
        case 8:
            return "MAP_DATA_LEVEL_COUNTY_CODE";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var ko = (i => (i[i.MARKER_SYMBOL_UNSPECIFIED = 0] = "MARKER_SYMBOL_UNSPECIFIED", i[i.MARKER_SYMBOL_NONE = 1] = "MARKER_SYMBOL_NONE", i[i.MARKER_SYMBOL_DOT = 2] = "MARKER_SYMBOL_DOT", i[i.MARKER_SYMBOL_CIRCLE = 3] = "MARKER_SYMBOL_CIRCLE", i[i.MARKER_SYMBOL_SQUARE = 4] = "MARKER_SYMBOL_SQUARE", i[i.MARKER_SYMBOL_DIAMOND = 5] = "MARKER_SYMBOL_DIAMOND", i[i.MARKER_SYMBOL_TRIANGLE = 6] = "MARKER_SYMBOL_TRIANGLE", i[i.MARKER_SYMBOL_X = 7] = "MARKER_SYMBOL_X", i[i.MARKER_SYMBOL_STAR = 8] = "MARKER_SYMBOL_STAR", i[i.MARKER_SYMBOL_PLUS = 9] = "MARKER_SYMBOL_PLUS", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(ko || {});

function Do(i) {
    switch (i) {
        case 0:
        case "MARKER_SYMBOL_UNSPECIFIED":
            return 0;
        case 1:
        case "MARKER_SYMBOL_NONE":
            return 1;
        case 2:
        case "MARKER_SYMBOL_DOT":
            return 2;
        case 3:
        case "MARKER_SYMBOL_CIRCLE":
            return 3;
        case 4:
        case "MARKER_SYMBOL_SQUARE":
            return 4;
        case 5:
        case "MARKER_SYMBOL_DIAMOND":
            return 5;
        case 6:
        case "MARKER_SYMBOL_TRIANGLE":
            return 6;
        case 7:
        case "MARKER_SYMBOL_X":
            return 7;
        case 8:
        case "MARKER_SYMBOL_STAR":
            return 8;
        case 9:
        case "MARKER_SYMBOL_PLUS":
            return 9;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Go(i) {
    switch (i) {
        case 0:
            return "MARKER_SYMBOL_UNSPECIFIED";
        case 1:
            return "MARKER_SYMBOL_NONE";
        case 2:
            return "MARKER_SYMBOL_DOT";
        case 3:
            return "MARKER_SYMBOL_CIRCLE";
        case 4:
            return "MARKER_SYMBOL_SQUARE";
        case 5:
            return "MARKER_SYMBOL_DIAMOND";
        case 6:
            return "MARKER_SYMBOL_TRIANGLE";
        case 7:
            return "MARKER_SYMBOL_X";
        case 8:
            return "MARKER_SYMBOL_STAR";
        case 9:
            return "MARKER_SYMBOL_PLUS";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function Uo(i) {
    switch (i) {
        case 0:
        case "AXIS_POSITION_UNSPECIFIED":
            return 0;
        case 1:
        case "AXIS_POSITION_LEFT":
            return 1;
        case 2:
        case "AXIS_POSITION_RIGHT":
            return 2;
        case 3:
        case "AXIS_POSITION_TOP":
            return 3;
        case 4:
        case "AXIS_POSITION_BOTTOM":
            return 4;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Bo(i) {
    switch (i) {
        case 0:
            return "AXIS_POSITION_UNSPECIFIED";
        case 1:
            return "AXIS_POSITION_LEFT";
        case 2:
            return "AXIS_POSITION_RIGHT";
        case 3:
            return "AXIS_POSITION_TOP";
        case 4:
            return "AXIS_POSITION_BOTTOM";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var Fo = (i => (i[i.AXIS_ORIENTATION_UNSPECIFIED = 0] = "AXIS_ORIENTATION_UNSPECIFIED", i[i.AXIS_ORIENTATION_MIN_MAX = 1] = "AXIS_ORIENTATION_MIN_MAX", i[i.AXIS_ORIENTATION_MAX_MIN = 2] = "AXIS_ORIENTATION_MAX_MIN", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(Fo || {});

function xo(i) {
    switch (i) {
        case 0:
        case "AXIS_ORIENTATION_UNSPECIFIED":
            return 0;
        case 1:
        case "AXIS_ORIENTATION_MIN_MAX":
            return 1;
        case 2:
        case "AXIS_ORIENTATION_MAX_MIN":
            return 2;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function yo(i) {
    switch (i) {
        case 0:
            return "AXIS_ORIENTATION_UNSPECIFIED";
        case 1:
            return "AXIS_ORIENTATION_MIN_MAX";
        case 2:
            return "AXIS_ORIENTATION_MAX_MIN";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function Wn(i) {
    switch (i) {
        case 0:
        case "TICK_MARK_UNSPECIFIED":
            return 0;
        case 1:
        case "TICK_MARK_NONE":
            return 1;
        case 2:
        case "TICK_MARK_INSIDE":
            return 2;
        case 3:
        case "TICK_MARK_OUTSIDE":
            return 3;
        case 4:
        case "TICK_MARK_CROSS":
            return 4;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function mn(i) {
    switch (i) {
        case 0:
            return "TICK_MARK_UNSPECIFIED";
        case 1:
            return "TICK_MARK_NONE";
        case 2:
            return "TICK_MARK_INSIDE";
        case 3:
            return "TICK_MARK_OUTSIDE";
        case 4:
            return "TICK_MARK_CROSS";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function Jo(i) {
    switch (i) {
        case 0:
        case "TICK_LABEL_POSITION_UNSPECIFIED":
            return 0;
        case 1:
        case "TICK_LABEL_POSITION_HIGH":
            return 1;
        case 2:
        case "TICK_LABEL_POSITION_LOW":
            return 2;
        case 3:
        case "TICK_LABEL_POSITION_NEXT_TO":
            return 3;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function wo(i) {
    switch (i) {
        case 0:
            return "TICK_LABEL_POSITION_UNSPECIFIED";
        case 1:
            return "TICK_LABEL_POSITION_HIGH";
        case 2:
            return "TICK_LABEL_POSITION_LOW";
        case 3:
            return "TICK_LABEL_POSITION_NEXT_TO";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function Wo(i) {
    switch (i) {
        case 0:
        case "CROSS_BETWEEN_UNSPECIFIED":
            return 0;
        case 1:
        case "CROSS_BETWEEN_BETWEEN":
            return 1;
        case 2:
        case "CROSS_BETWEEN_MIDPOINT_CATEGORY":
            return 2;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function mo(i) {
    switch (i) {
        case 0:
            return "CROSS_BETWEEN_UNSPECIFIED";
        case 1:
            return "CROSS_BETWEEN_BETWEEN";
        case 2:
            return "CROSS_BETWEEN_MIDPOINT_CATEGORY";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function Vo(i) {
    switch (i) {
        case 0:
        case "CROSSES_UNSPECIFIED":
            return 0;
        case 1:
        case "CROSSES_AUTO_ZERO":
            return 1;
        case 2:
        case "CROSSES_MIN":
            return 2;
        case 3:
        case "CROSSES_MAX":
            return 3;
        case 4:
        case "CROSSES_AT":
            return 4;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Ko(i) {
    switch (i) {
        case 0:
            return "CROSSES_UNSPECIFIED";
        case 1:
            return "CROSSES_AUTO_ZERO";
        case 2:
            return "CROSSES_MIN";
        case 3:
            return "CROSSES_MAX";
        case 4:
            return "CROSSES_AT";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function Zo(i) {
    switch (i) {
        case 0:
        case "BAR3D_SHAPE_UNSPECIFIED":
            return 0;
        case 1:
        case "BAR3D_SHAPE_BOX":
            return 1;
        case 2:
        case "BAR3D_SHAPE_CONE_TO_POINT":
            return 2;
        case 3:
        case "BAR3D_SHAPE_CONE_TO_MAX":
            return 3;
        case 4:
        case "BAR3D_SHAPE_CYLINDER":
            return 4;
        case 5:
        case "BAR3D_SHAPE_PYRAMID_TO_POINT":
            return 5;
        case 6:
        case "BAR3D_SHAPE_PYRAMID_TO_MAX":
            return 6;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Xo(i) {
    switch (i) {
        case 0:
            return "BAR3D_SHAPE_UNSPECIFIED";
        case 1:
            return "BAR3D_SHAPE_BOX";
        case 2:
            return "BAR3D_SHAPE_CONE_TO_POINT";
        case 3:
            return "BAR3D_SHAPE_CONE_TO_MAX";
        case 4:
            return "BAR3D_SHAPE_CYLINDER";
        case 5:
            return "BAR3D_SHAPE_PYRAMID_TO_POINT";
        case 6:
            return "BAR3D_SHAPE_PYRAMID_TO_MAX";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var zo = (i => (i[i.CHART_TYPE_UNSPECIFIED = 0] = "CHART_TYPE_UNSPECIFIED", i[i.CHART_TYPE_AREA_3D = 1] = "CHART_TYPE_AREA_3D", i[i.CHART_TYPE_AREA = 2] = "CHART_TYPE_AREA", i[i.CHART_TYPE_BAR_3D = 3] = "CHART_TYPE_BAR_3D", i[i.CHART_TYPE_BAR = 4] = "CHART_TYPE_BAR", i[i.CHART_TYPE_BUBBLE = 5] = "CHART_TYPE_BUBBLE", i[i.CHART_TYPE_DOUGHNUT = 8] = "CHART_TYPE_DOUGHNUT", i[i.CHART_TYPE_LINE_3D = 12] = "CHART_TYPE_LINE_3D", i[i.CHART_TYPE_LINE = 13] = "CHART_TYPE_LINE", i[i.CHART_TYPE_OF_PIE = 14] = "CHART_TYPE_OF_PIE", i[i.CHART_TYPE_PIE_3D = 15] = "CHART_TYPE_PIE_3D", i[i.CHART_TYPE_PIE = 16] = "CHART_TYPE_PIE", i[i.CHART_TYPE_RADAR = 17] = "CHART_TYPE_RADAR", i[i.CHART_TYPE_SCATTER = 18] = "CHART_TYPE_SCATTER", i[i.CHART_TYPE_STOCK = 20] = "CHART_TYPE_STOCK", i[i.CHART_TYPE_SURFACE_3D = 21] = "CHART_TYPE_SURFACE_3D", i[i.CHART_TYPE_SURFACE = 22] = "CHART_TYPE_SURFACE", i[i.CHART_TYPE_MAP = 23] = "CHART_TYPE_MAP", i[i.CHART_TYPE_HISTOGRAM = 24] = "CHART_TYPE_HISTOGRAM", i[i.CHART_TYPE_PARETO = 25] = "CHART_TYPE_PARETO", i[i.CHART_TYPE_BOX_WHISKER = 26] = "CHART_TYPE_BOX_WHISKER", i[i.CHART_TYPE_WATERFALL = 27] = "CHART_TYPE_WATERFALL", i[i.CHART_TYPE_FUNNEL = 28] = "CHART_TYPE_FUNNEL", i[i.CHART_TYPE_TREEMAP = 29] = "CHART_TYPE_TREEMAP", i[i.CHART_TYPE_SUNBURST = 30] = "CHART_TYPE_SUNBURST", i[i.CHART_TYPE_COMBO = 31] = "CHART_TYPE_COMBO", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(zo || {});

function Qo(i) {
    switch (i) {
        case 0:
        case "CHART_TYPE_UNSPECIFIED":
            return 0;
        case 1:
        case "CHART_TYPE_AREA_3D":
            return 1;
        case 2:
        case "CHART_TYPE_AREA":
            return 2;
        case 3:
        case "CHART_TYPE_BAR_3D":
            return 3;
        case 4:
        case "CHART_TYPE_BAR":
            return 4;
        case 5:
        case "CHART_TYPE_BUBBLE":
            return 5;
        case 8:
        case "CHART_TYPE_DOUGHNUT":
            return 8;
        case 12:
        case "CHART_TYPE_LINE_3D":
            return 12;
        case 13:
        case "CHART_TYPE_LINE":
            return 13;
        case 14:
        case "CHART_TYPE_OF_PIE":
            return 14;
        case 15:
        case "CHART_TYPE_PIE_3D":
            return 15;
        case 16:
        case "CHART_TYPE_PIE":
            return 16;
        case 17:
        case "CHART_TYPE_RADAR":
            return 17;
        case 18:
        case "CHART_TYPE_SCATTER":
            return 18;
        case 20:
        case "CHART_TYPE_STOCK":
            return 20;
        case 21:
        case "CHART_TYPE_SURFACE_3D":
            return 21;
        case 22:
        case "CHART_TYPE_SURFACE":
            return 22;
        case 23:
        case "CHART_TYPE_MAP":
            return 23;
        case 24:
        case "CHART_TYPE_HISTOGRAM":
            return 24;
        case 25:
        case "CHART_TYPE_PARETO":
            return 25;
        case 26:
        case "CHART_TYPE_BOX_WHISKER":
            return 26;
        case 27:
        case "CHART_TYPE_WATERFALL":
            return 27;
        case 28:
        case "CHART_TYPE_FUNNEL":
            return 28;
        case 29:
        case "CHART_TYPE_TREEMAP":
            return 29;
        case 30:
        case "CHART_TYPE_SUNBURST":
            return 30;
        case 31:
        case "CHART_TYPE_COMBO":
            return 31;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function qo(i) {
    switch (i) {
        case 0:
            return "CHART_TYPE_UNSPECIFIED";
        case 1:
            return "CHART_TYPE_AREA_3D";
        case 2:
            return "CHART_TYPE_AREA";
        case 3:
            return "CHART_TYPE_BAR_3D";
        case 4:
            return "CHART_TYPE_BAR";
        case 5:
            return "CHART_TYPE_BUBBLE";
        case 8:
            return "CHART_TYPE_DOUGHNUT";
        case 12:
            return "CHART_TYPE_LINE_3D";
        case 13:
            return "CHART_TYPE_LINE";
        case 14:
            return "CHART_TYPE_OF_PIE";
        case 15:
            return "CHART_TYPE_PIE_3D";
        case 16:
            return "CHART_TYPE_PIE";
        case 17:
            return "CHART_TYPE_RADAR";
        case 18:
            return "CHART_TYPE_SCATTER";
        case 20:
            return "CHART_TYPE_STOCK";
        case 21:
            return "CHART_TYPE_SURFACE_3D";
        case 22:
            return "CHART_TYPE_SURFACE";
        case 23:
            return "CHART_TYPE_MAP";
        case 24:
            return "CHART_TYPE_HISTOGRAM";
        case 25:
            return "CHART_TYPE_PARETO";
        case 26:
            return "CHART_TYPE_BOX_WHISKER";
        case 27:
            return "CHART_TYPE_WATERFALL";
        case 28:
            return "CHART_TYPE_FUNNEL";
        case 29:
            return "CHART_TYPE_TREEMAP";
        case 30:
            return "CHART_TYPE_SUNBURST";
        case 31:
            return "CHART_TYPE_COMBO";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function $o(i) {
    switch (i) {
        case 0:
        case "CLASSIFICATION_UNSPECIFIED":
            return 0;
        case 1:
        case "CLASSIFICATION_EQUAL_INTERVAL":
            return 1;
        case 2:
        case "CLASSIFICATION_QUANTILE":
            return 2;
        case 3:
        case "CLASSIFICATION_CUSTOM":
            return 3;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function go(i) {
    switch (i) {
        case 0:
            return "CLASSIFICATION_UNSPECIFIED";
        case 1:
            return "CLASSIFICATION_EQUAL_INTERVAL";
        case 2:
            return "CLASSIFICATION_QUANTILE";
        case 3:
            return "CLASSIFICATION_CUSTOM";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var bo = (i => (i[i.PARENT_LABEL_LAYOUT_UNSPECIFIED = 0] = "PARENT_LABEL_LAYOUT_UNSPECIFIED", i[i.PARENT_LABEL_LAYOUT_NONE = 1] = "PARENT_LABEL_LAYOUT_NONE", i[i.PARENT_LABEL_LAYOUT_BANNER = 2] = "PARENT_LABEL_LAYOUT_BANNER", i[i.PARENT_LABEL_LAYOUT_OVERLAPPING = 3] = "PARENT_LABEL_LAYOUT_OVERLAPPING", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(bo || {});

function jo(i) {
    switch (i) {
        case 0:
        case "PARENT_LABEL_LAYOUT_UNSPECIFIED":
            return 0;
        case 1:
        case "PARENT_LABEL_LAYOUT_NONE":
            return 1;
        case 2:
        case "PARENT_LABEL_LAYOUT_BANNER":
            return 2;
        case 3:
        case "PARENT_LABEL_LAYOUT_OVERLAPPING":
            return 3;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function ie(i) {
    switch (i) {
        case 0:
            return "PARENT_LABEL_LAYOUT_UNSPECIFIED";
        case 1:
            return "PARENT_LABEL_LAYOUT_NONE";
        case 2:
            return "PARENT_LABEL_LAYOUT_BANNER";
        case 3:
            return "PARENT_LABEL_LAYOUT_OVERLAPPING";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var ne = (i => (i[i.QUARTILE_METHOD_UNSPECIFIED = 0] = "QUARTILE_METHOD_UNSPECIFIED", i[i.QUARTILE_METHOD_INCLUSIVE = 1] = "QUARTILE_METHOD_INCLUSIVE", i[i.QUARTILE_METHOD_EXCLUSIVE = 2] = "QUARTILE_METHOD_EXCLUSIVE", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(ne || {});

function te(i) {
    switch (i) {
        case 0:
        case "QUARTILE_METHOD_UNSPECIFIED":
            return 0;
        case 1:
        case "QUARTILE_METHOD_INCLUSIVE":
            return 1;
        case 2:
        case "QUARTILE_METHOD_EXCLUSIVE":
            return 2;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function re(i) {
    switch (i) {
        case 0:
            return "QUARTILE_METHOD_UNSPECIFIED";
        case 1:
            return "QUARTILE_METHOD_INCLUSIVE";
        case 2:
            return "QUARTILE_METHOD_EXCLUSIVE";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var oe = (i => (i[i.INTERVAL_CLOSED_UNSPECIFIED = 0] = "INTERVAL_CLOSED_UNSPECIFIED", i[i.INTERVAL_CLOSED_LEFT = 1] = "INTERVAL_CLOSED_LEFT", i[i.INTERVAL_CLOSED_RIGHT = 2] = "INTERVAL_CLOSED_RIGHT", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(oe || {});

function ee(i) {
    switch (i) {
        case 0:
        case "INTERVAL_CLOSED_UNSPECIFIED":
            return 0;
        case 1:
        case "INTERVAL_CLOSED_LEFT":
            return 1;
        case 2:
        case "INTERVAL_CLOSED_RIGHT":
            return 2;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Ee(i) {
    switch (i) {
        case 0:
            return "INTERVAL_CLOSED_UNSPECIFIED";
        case 1:
            return "INTERVAL_CLOSED_LEFT";
        case 2:
            return "INTERVAL_CLOSED_RIGHT";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function ae(i) {
    switch (i) {
        case 0:
        case "TYPE_UNSPECIFIED":
            return 0;
        case 1:
        case "TYPE_SEQUENTIAL":
            return 1;
        case 2:
        case "TYPE_DIVERGING":
            return 2;
        case 3:
        case "TYPE_QUALITATIVE":
            return 3;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function ue(i) {
    switch (i) {
        case 0:
            return "TYPE_UNSPECIFIED";
        case 1:
            return "TYPE_SEQUENTIAL";
        case 2:
            return "TYPE_DIVERGING";
        case 3:
            return "TYPE_QUALITATIVE";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function Vn() {
    return {
        title: "",
        categories: [],
        series: [],
        bbox: void 0,
        type: 0,
        styleIndex: 0,
        id: "",
        xAxis: void 0,
        yAxis: void 0,
        barDirection: 0,
        hasLegend: !1,
        legend: void 0,
        titleTextStyle: void 0,
        dataLabels: void 0,
        chartFill: void 0,
        chartLine: void 0,
        plotAreaFill: void 0,
        plotAreaLine: void 0,
        pivot: void 0,
        pivotOptions: void 0,
        pivotFormats: [],
        mapOptions: void 0,
        style: void 0,
        displayBlanksAs: void 0,
        showDlblsOverMax: void 0,
        view3d: void 0,
        barOptions: void 0,
        lineOptions: void 0,
        areaOptions: void 0,
        pieOptions: void 0,
        doughnutOptions: void 0,
        scatterOptions: void 0,
        bubbleOptions: void 0,
        radarOptions: void 0,
        surfaceOptions: void 0,
        treemapOptions: void 0,
        boxWhiskerOptions: void 0,
        histogramOptions: void 0,
        waterfallOptions: void 0,
        funnelOptions: void 0
    }
}
const ri = {
    encode(i, n = new O) {
        i.title !== "" && n.uint32(10).string(i.title);
        for (const t of i.categories) n.uint32(18).string(t);
        for (const t of i.series) Ei.encode(t, n.uint32(26).fork()).join();
        i.bbox !== void 0 && F.encode(i.bbox, n.uint32(34).fork()).join(), i.type !== 0 && n.uint32(40).int32(i.type), i.styleIndex !== 0 && n.uint32(48).int32(i.styleIndex), i.id !== "" && n.uint32(58).string(i.id), i.xAxis !== void 0 && U.encode(i.xAxis, n.uint32(66).fork()).join(), i.yAxis !== void 0 && U.encode(i.yAxis, n.uint32(74).fork()).join(), i.barDirection !== 0 && n.uint32(80).int32(i.barDirection), i.hasLegend !== !1 && n.uint32(88).bool(i.hasLegend), i.legend !== void 0 && oi.encode(i.legend, n.uint32(98).fork()).join(), i.titleTextStyle !== void 0 && N.encode(i.titleTextStyle, n.uint32(106).fork()).join(), i.dataLabels !== void 0 && w.encode(i.dataLabels, n.uint32(114).fork()).join(), i.chartFill !== void 0 && A.encode(i.chartFill, n.uint32(122).fork()).join(), i.chartLine !== void 0 && T.encode(i.chartLine, n.uint32(130).fork()).join(), i.plotAreaFill !== void 0 && A.encode(i.plotAreaFill, n.uint32(138).fork()).join(), i.plotAreaLine !== void 0 && T.encode(i.plotAreaLine, n.uint32(146).fork()).join(), i.pivot !== void 0 && Mi.encode(i.pivot, n.uint32(154).fork()).join(), i.pivotOptions !== void 0 && hi.encode(i.pivotOptions, n.uint32(162).fork()).join();
        for (const t of i.pivotFormats) Yi.encode(t, n.uint32(170).fork()).join();
        return i.mapOptions !== void 0 && si.encode(i.mapOptions, n.uint32(178).fork()).join(), i.style !== void 0 && Li.encode(i.style, n.uint32(186).fork()).join(), i.displayBlanksAs !== void 0 && n.uint32(224).int32(i.displayBlanksAs), i.showDlblsOverMax !== void 0 && n.uint32(232).bool(i.showDlblsOverMax), i.view3d !== void 0 && pi.encode(i.view3d, n.uint32(330).fork()).join(), i.barOptions !== void 0 && ei.encode(i.barOptions, n.uint32(402).fork()).join(), i.lineOptions !== void 0 && ai.encode(i.lineOptions, n.uint32(410).fork()).join(), i.areaOptions !== void 0 && ui.encode(i.areaOptions, n.uint32(418).fork()).join(), i.pieOptions !== void 0 && di.encode(i.pieOptions, n.uint32(426).fork()).join(), i.doughnutOptions !== void 0 && li.encode(i.doughnutOptions, n.uint32(434).fork()).join(), i.scatterOptions !== void 0 && _i.encode(i.scatterOptions, n.uint32(442).fork()).join(), i.bubbleOptions !== void 0 && ci.encode(i.bubbleOptions, n.uint32(450).fork()).join(), i.radarOptions !== void 0 && fi.encode(i.radarOptions, n.uint32(458).fork()).join(), i.surfaceOptions !== void 0 && Ti.encode(i.surfaceOptions, n.uint32(466).fork()).join(), i.treemapOptions !== void 0 && Ni.encode(i.treemapOptions, n.uint32(354).fork()).join(), i.boxWhiskerOptions !== void 0 && Si.encode(i.boxWhiskerOptions, n.uint32(362).fork()).join(), i.histogramOptions !== void 0 && vi.encode(i.histogramOptions, n.uint32(370).fork()).join(), i.waterfallOptions !== void 0 && Pi.encode(i.waterfallOptions, n.uint32(378).fork()).join(), i.funnelOptions !== void 0 && Ii.encode(i.funnelOptions, n.uint32(386).fork()).join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Vn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.title = t.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.categories.push(t.string());
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.series.push(Ei.decode(t, t.uint32()));
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;o.bbox = F.decode(t, t.uint32());
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;o.type = t.int32();
                        continue
                    }
                case 6:
                    {
                        if (r !== 48) break;o.styleIndex = t.int32();
                        continue
                    }
                case 7:
                    {
                        if (r !== 58) break;o.id = t.string();
                        continue
                    }
                case 8:
                    {
                        if (r !== 66) break;o.xAxis = U.decode(t, t.uint32());
                        continue
                    }
                case 9:
                    {
                        if (r !== 74) break;o.yAxis = U.decode(t, t.uint32());
                        continue
                    }
                case 10:
                    {
                        if (r !== 80) break;o.barDirection = t.int32();
                        continue
                    }
                case 11:
                    {
                        if (r !== 88) break;o.hasLegend = t.bool();
                        continue
                    }
                case 12:
                    {
                        if (r !== 98) break;o.legend = oi.decode(t, t.uint32());
                        continue
                    }
                case 13:
                    {
                        if (r !== 106) break;o.titleTextStyle = N.decode(t, t.uint32());
                        continue
                    }
                case 14:
                    {
                        if (r !== 114) break;o.dataLabels = w.decode(t, t.uint32());
                        continue
                    }
                case 15:
                    {
                        if (r !== 122) break;o.chartFill = A.decode(t, t.uint32());
                        continue
                    }
                case 16:
                    {
                        if (r !== 130) break;o.chartLine = T.decode(t, t.uint32());
                        continue
                    }
                case 17:
                    {
                        if (r !== 138) break;o.plotAreaFill = A.decode(t, t.uint32());
                        continue
                    }
                case 18:
                    {
                        if (r !== 146) break;o.plotAreaLine = T.decode(t, t.uint32());
                        continue
                    }
                case 19:
                    {
                        if (r !== 154) break;o.pivot = Mi.decode(t, t.uint32());
                        continue
                    }
                case 20:
                    {
                        if (r !== 162) break;o.pivotOptions = hi.decode(t, t.uint32());
                        continue
                    }
                case 21:
                    {
                        if (r !== 170) break;o.pivotFormats.push(Yi.decode(t, t.uint32()));
                        continue
                    }
                case 22:
                    {
                        if (r !== 178) break;o.mapOptions = si.decode(t, t.uint32());
                        continue
                    }
                case 23:
                    {
                        if (r !== 186) break;o.style = Li.decode(t, t.uint32());
                        continue
                    }
                case 28:
                    {
                        if (r !== 224) break;o.displayBlanksAs = t.int32();
                        continue
                    }
                case 29:
                    {
                        if (r !== 232) break;o.showDlblsOverMax = t.bool();
                        continue
                    }
                case 41:
                    {
                        if (r !== 330) break;o.view3d = pi.decode(t, t.uint32());
                        continue
                    }
                case 50:
                    {
                        if (r !== 402) break;o.barOptions = ei.decode(t, t.uint32());
                        continue
                    }
                case 51:
                    {
                        if (r !== 410) break;o.lineOptions = ai.decode(t, t.uint32());
                        continue
                    }
                case 52:
                    {
                        if (r !== 418) break;o.areaOptions = ui.decode(t, t.uint32());
                        continue
                    }
                case 53:
                    {
                        if (r !== 426) break;o.pieOptions = di.decode(t, t.uint32());
                        continue
                    }
                case 54:
                    {
                        if (r !== 434) break;o.doughnutOptions = li.decode(t, t.uint32());
                        continue
                    }
                case 55:
                    {
                        if (r !== 442) break;o.scatterOptions = _i.decode(t, t.uint32());
                        continue
                    }
                case 56:
                    {
                        if (r !== 450) break;o.bubbleOptions = ci.decode(t, t.uint32());
                        continue
                    }
                case 57:
                    {
                        if (r !== 458) break;o.radarOptions = fi.decode(t, t.uint32());
                        continue
                    }
                case 58:
                    {
                        if (r !== 466) break;o.surfaceOptions = Ti.decode(t, t.uint32());
                        continue
                    }
                case 44:
                    {
                        if (r !== 354) break;o.treemapOptions = Ni.decode(t, t.uint32());
                        continue
                    }
                case 45:
                    {
                        if (r !== 362) break;o.boxWhiskerOptions = Si.decode(t, t.uint32());
                        continue
                    }
                case 46:
                    {
                        if (r !== 370) break;o.histogramOptions = vi.decode(t, t.uint32());
                        continue
                    }
                case 47:
                    {
                        if (r !== 378) break;o.waterfallOptions = Pi.decode(t, t.uint32());
                        continue
                    }
                case 48:
                    {
                        if (r !== 386) break;o.funnelOptions = Ii.decode(t, t.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            title: E(i.title) ? _.String(i.title) : "",
            categories: _.Array.isArray(i == null ? void 0 : i.categories) ? i.categories.map(n => _.String(n)) : [],
            series: _.Array.isArray(i == null ? void 0 : i.series) ? i.series.map(n => Ei.fromJSON(n)) : [],
            bbox: E(i.bbox) ? F.fromJSON(i.bbox) : void 0,
            type: E(i.type) ? Qo(i.type) : 0,
            styleIndex: E(i.styleIndex) ? _.Number(i.styleIndex) : 0,
            id: E(i.id) ? _.String(i.id) : "",
            xAxis: E(i.xAxis) ? U.fromJSON(i.xAxis) : void 0,
            yAxis: E(i.yAxis) ? U.fromJSON(i.yAxis) : void 0,
            barDirection: E(i.barDirection) ? or(i.barDirection) : 0,
            hasLegend: E(i.hasLegend) ? _.Boolean(i.hasLegend) : !1,
            legend: E(i.legend) ? oi.fromJSON(i.legend) : void 0,
            titleTextStyle: E(i.titleTextStyle) ? N.fromJSON(i.titleTextStyle) : void 0,
            dataLabels: E(i.dataLabels) ? w.fromJSON(i.dataLabels) : void 0,
            chartFill: E(i.chartFill) ? A.fromJSON(i.chartFill) : void 0,
            chartLine: E(i.chartLine) ? T.fromJSON(i.chartLine) : void 0,
            plotAreaFill: E(i.plotAreaFill) ? A.fromJSON(i.plotAreaFill) : void 0,
            plotAreaLine: E(i.plotAreaLine) ? T.fromJSON(i.plotAreaLine) : void 0,
            pivot: E(i.pivot) ? Mi.fromJSON(i.pivot) : void 0,
            pivotOptions: E(i.pivotOptions) ? hi.fromJSON(i.pivotOptions) : void 0,
            pivotFormats: _.Array.isArray(i == null ? void 0 : i.pivotFormats) ? i.pivotFormats.map(n => Yi.fromJSON(n)) : [],
            mapOptions: E(i.mapOptions) ? si.fromJSON(i.mapOptions) : void 0,
            style: E(i.style) ? Li.fromJSON(i.style) : void 0,
            displayBlanksAs: E(i.displayBlanksAs) ? uo(i.displayBlanksAs) : void 0,
            showDlblsOverMax: E(i.showDlblsOverMax) ? _.Boolean(i.showDlblsOverMax) : void 0,
            view3d: E(i.view3d) ? pi.fromJSON(i.view3d) : void 0,
            barOptions: E(i.barOptions) ? ei.fromJSON(i.barOptions) : void 0,
            lineOptions: E(i.lineOptions) ? ai.fromJSON(i.lineOptions) : void 0,
            areaOptions: E(i.areaOptions) ? ui.fromJSON(i.areaOptions) : void 0,
            pieOptions: E(i.pieOptions) ? di.fromJSON(i.pieOptions) : void 0,
            doughnutOptions: E(i.doughnutOptions) ? li.fromJSON(i.doughnutOptions) : void 0,
            scatterOptions: E(i.scatterOptions) ? _i.fromJSON(i.scatterOptions) : void 0,
            bubbleOptions: E(i.bubbleOptions) ? ci.fromJSON(i.bubbleOptions) : void 0,
            radarOptions: E(i.radarOptions) ? fi.fromJSON(i.radarOptions) : void 0,
            surfaceOptions: E(i.surfaceOptions) ? Ti.fromJSON(i.surfaceOptions) : void 0,
            treemapOptions: E(i.treemapOptions) ? Ni.fromJSON(i.treemapOptions) : void 0,
            boxWhiskerOptions: E(i.boxWhiskerOptions) ? Si.fromJSON(i.boxWhiskerOptions) : void 0,
            histogramOptions: E(i.histogramOptions) ? vi.fromJSON(i.histogramOptions) : void 0,
            waterfallOptions: E(i.waterfallOptions) ? Pi.fromJSON(i.waterfallOptions) : void 0,
            funnelOptions: E(i.funnelOptions) ? Ii.fromJSON(i.funnelOptions) : void 0
        }
    },
    toJSON(i) {
        var t, e, o;
        const n = {};
        return i.title !== "" && (n.title = i.title), (t = i.categories) != null && t.length && (n.categories = i.categories), (e = i.series) != null && e.length && (n.series = i.series.map(r => Ei.toJSON(r))), i.bbox !== void 0 && (n.bbox = F.toJSON(i.bbox)), i.type !== 0 && (n.type = qo(i.type)), i.styleIndex !== 0 && (n.styleIndex = Math.round(i.styleIndex)), i.id !== "" && (n.id = i.id), i.xAxis !== void 0 && (n.xAxis = U.toJSON(i.xAxis)), i.yAxis !== void 0 && (n.yAxis = U.toJSON(i.yAxis)), i.barDirection !== 0 && (n.barDirection = er(i.barDirection)), i.hasLegend !== !1 && (n.hasLegend = i.hasLegend), i.legend !== void 0 && (n.legend = oi.toJSON(i.legend)), i.titleTextStyle !== void 0 && (n.titleTextStyle = N.toJSON(i.titleTextStyle)), i.dataLabels !== void 0 && (n.dataLabels = w.toJSON(i.dataLabels)), i.chartFill !== void 0 && (n.chartFill = A.toJSON(i.chartFill)), i.chartLine !== void 0 && (n.chartLine = T.toJSON(i.chartLine)), i.plotAreaFill !== void 0 && (n.plotAreaFill = A.toJSON(i.plotAreaFill)), i.plotAreaLine !== void 0 && (n.plotAreaLine = T.toJSON(i.plotAreaLine)), i.pivot !== void 0 && (n.pivot = Mi.toJSON(i.pivot)), i.pivotOptions !== void 0 && (n.pivotOptions = hi.toJSON(i.pivotOptions)), (o = i.pivotFormats) != null && o.length && (n.pivotFormats = i.pivotFormats.map(r => Yi.toJSON(r))), i.mapOptions !== void 0 && (n.mapOptions = si.toJSON(i.mapOptions)), i.style !== void 0 && (n.style = Li.toJSON(i.style)), i.displayBlanksAs !== void 0 && (n.displayBlanksAs = lo(i.displayBlanksAs)), i.showDlblsOverMax !== void 0 && (n.showDlblsOverMax = i.showDlblsOverMax), i.view3d !== void 0 && (n.view3d = pi.toJSON(i.view3d)), i.barOptions !== void 0 && (n.barOptions = ei.toJSON(i.barOptions)), i.lineOptions !== void 0 && (n.lineOptions = ai.toJSON(i.lineOptions)), i.areaOptions !== void 0 && (n.areaOptions = ui.toJSON(i.areaOptions)), i.pieOptions !== void 0 && (n.pieOptions = di.toJSON(i.pieOptions)), i.doughnutOptions !== void 0 && (n.doughnutOptions = li.toJSON(i.doughnutOptions)), i.scatterOptions !== void 0 && (n.scatterOptions = _i.toJSON(i.scatterOptions)), i.bubbleOptions !== void 0 && (n.bubbleOptions = ci.toJSON(i.bubbleOptions)), i.radarOptions !== void 0 && (n.radarOptions = fi.toJSON(i.radarOptions)), i.surfaceOptions !== void 0 && (n.surfaceOptions = Ti.toJSON(i.surfaceOptions)), i.treemapOptions !== void 0 && (n.treemapOptions = Ni.toJSON(i.treemapOptions)), i.boxWhiskerOptions !== void 0 && (n.boxWhiskerOptions = Si.toJSON(i.boxWhiskerOptions)), i.histogramOptions !== void 0 && (n.histogramOptions = vi.toJSON(i.histogramOptions)), i.waterfallOptions !== void 0 && (n.waterfallOptions = Pi.toJSON(i.waterfallOptions)), i.funnelOptions !== void 0 && (n.funnelOptions = Ii.toJSON(i.funnelOptions)), n
    },
    create(i) {
        return ri.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u, c, s, v, P, L, I;
        const n = Vn();
        return n.title = (t = i.title) != null ? t : "", n.categories = ((e = i.categories) == null ? void 0 : e.map(Y => Y)) || [], n.series = ((o = i.series) == null ? void 0 : o.map(Y => Ei.fromPartial(Y))) || [], n.bbox = i.bbox !== void 0 && i.bbox !== null ? F.fromPartial(i.bbox) : void 0, n.type = (r = i.type) != null ? r : 0, n.styleIndex = (u = i.styleIndex) != null ? u : 0, n.id = (c = i.id) != null ? c : "", n.xAxis = i.xAxis !== void 0 && i.xAxis !== null ? U.fromPartial(i.xAxis) : void 0, n.yAxis = i.yAxis !== void 0 && i.yAxis !== null ? U.fromPartial(i.yAxis) : void 0, n.barDirection = (s = i.barDirection) != null ? s : 0, n.hasLegend = (v = i.hasLegend) != null ? v : !1, n.legend = i.legend !== void 0 && i.legend !== null ? oi.fromPartial(i.legend) : void 0, n.titleTextStyle = i.titleTextStyle !== void 0 && i.titleTextStyle !== null ? N.fromPartial(i.titleTextStyle) : void 0, n.dataLabels = i.dataLabels !== void 0 && i.dataLabels !== null ? w.fromPartial(i.dataLabels) : void 0, n.chartFill = i.chartFill !== void 0 && i.chartFill !== null ? A.fromPartial(i.chartFill) : void 0, n.chartLine = i.chartLine !== void 0 && i.chartLine !== null ? T.fromPartial(i.chartLine) : void 0, n.plotAreaFill = i.plotAreaFill !== void 0 && i.plotAreaFill !== null ? A.fromPartial(i.plotAreaFill) : void 0, n.plotAreaLine = i.plotAreaLine !== void 0 && i.plotAreaLine !== null ? T.fromPartial(i.plotAreaLine) : void 0, n.pivot = i.pivot !== void 0 && i.pivot !== null ? Mi.fromPartial(i.pivot) : void 0, n.pivotOptions = i.pivotOptions !== void 0 && i.pivotOptions !== null ? hi.fromPartial(i.pivotOptions) : void 0, n.pivotFormats = ((P = i.pivotFormats) == null ? void 0 : P.map(Y => Yi.fromPartial(Y))) || [], n.mapOptions = i.mapOptions !== void 0 && i.mapOptions !== null ? si.fromPartial(i.mapOptions) : void 0, n.style = i.style !== void 0 && i.style !== null ? Li.fromPartial(i.style) : void 0, n.displayBlanksAs = (L = i.displayBlanksAs) != null ? L : void 0, n.showDlblsOverMax = (I = i.showDlblsOverMax) != null ? I : void 0, n.view3d = i.view3d !== void 0 && i.view3d !== null ? pi.fromPartial(i.view3d) : void 0, n.barOptions = i.barOptions !== void 0 && i.barOptions !== null ? ei.fromPartial(i.barOptions) : void 0, n.lineOptions = i.lineOptions !== void 0 && i.lineOptions !== null ? ai.fromPartial(i.lineOptions) : void 0, n.areaOptions = i.areaOptions !== void 0 && i.areaOptions !== null ? ui.fromPartial(i.areaOptions) : void 0, n.pieOptions = i.pieOptions !== void 0 && i.pieOptions !== null ? di.fromPartial(i.pieOptions) : void 0, n.doughnutOptions = i.doughnutOptions !== void 0 && i.doughnutOptions !== null ? li.fromPartial(i.doughnutOptions) : void 0, n.scatterOptions = i.scatterOptions !== void 0 && i.scatterOptions !== null ? _i.fromPartial(i.scatterOptions) : void 0, n.bubbleOptions = i.bubbleOptions !== void 0 && i.bubbleOptions !== null ? ci.fromPartial(i.bubbleOptions) : void 0, n.radarOptions = i.radarOptions !== void 0 && i.radarOptions !== null ? fi.fromPartial(i.radarOptions) : void 0, n.surfaceOptions = i.surfaceOptions !== void 0 && i.surfaceOptions !== null ? Ti.fromPartial(i.surfaceOptions) : void 0, n.treemapOptions = i.treemapOptions !== void 0 && i.treemapOptions !== null ? Ni.fromPartial(i.treemapOptions) : void 0, n.boxWhiskerOptions = i.boxWhiskerOptions !== void 0 && i.boxWhiskerOptions !== null ? Si.fromPartial(i.boxWhiskerOptions) : void 0, n.histogramOptions = i.histogramOptions !== void 0 && i.histogramOptions !== null ? vi.fromPartial(i.histogramOptions) : void 0, n.waterfallOptions = i.waterfallOptions !== void 0 && i.waterfallOptions !== null ? Pi.fromPartial(i.waterfallOptions) : void 0, n.funnelOptions = i.funnelOptions !== void 0 && i.funnelOptions !== null ? Ii.fromPartial(i.funnelOptions) : void 0, n
    }
};

function Kn() {
    return {
        position: 0,
        overlay: void 0,
        textStyle: void 0,
        fill: void 0,
        stroke: void 0
    }
}
const oi = {
    encode(i, n = new O) {
        return i.position !== 0 && n.uint32(8).int32(i.position), i.overlay !== void 0 && n.uint32(16).bool(i.overlay), i.textStyle !== void 0 && N.encode(i.textStyle, n.uint32(26).fork()).join(), i.fill !== void 0 && A.encode(i.fill, n.uint32(34).fork()).join(), i.stroke !== void 0 && T.encode(i.stroke, n.uint32(42).fork()).join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Kn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.position = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.overlay = t.bool();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.textStyle = N.decode(t, t.uint32());
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;o.fill = A.decode(t, t.uint32());
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;o.stroke = T.decode(t, t.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            position: E(i.position) ? no(i.position) : 0,
            overlay: E(i.overlay) ? _.Boolean(i.overlay) : void 0,
            textStyle: E(i.textStyle) ? N.fromJSON(i.textStyle) : void 0,
            fill: E(i.fill) ? A.fromJSON(i.fill) : void 0,
            stroke: E(i.stroke) ? T.fromJSON(i.stroke) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.position !== 0 && (n.position = to(i.position)), i.overlay !== void 0 && (n.overlay = i.overlay), i.textStyle !== void 0 && (n.textStyle = N.toJSON(i.textStyle)), i.fill !== void 0 && (n.fill = A.toJSON(i.fill)), i.stroke !== void 0 && (n.stroke = T.toJSON(i.stroke)), n
    },
    create(i) {
        return oi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e;
        const n = Kn();
        return n.position = (t = i.position) != null ? t : 0, n.overlay = (e = i.overlay) != null ? e : void 0, n.textStyle = i.textStyle !== void 0 && i.textStyle !== null ? N.fromPartial(i.textStyle) : void 0, n.fill = i.fill !== void 0 && i.fill !== null ? A.fromPartial(i.fill) : void 0, n.stroke = i.stroke !== void 0 && i.stroke !== null ? T.fromPartial(i.stroke) : void 0, n
    }
};

function Zn() {
    return {
        direction: void 0,
        grouping: void 0,
        varyColors: void 0,
        gapWidth: void 0,
        overlap: void 0,
        gapDepth: void 0,
        bar3dShape: void 0
    }
}
const ei = {
    encode(i, n = new O) {
        return i.direction !== void 0 && n.uint32(8).int32(i.direction), i.grouping !== void 0 && n.uint32(16).int32(i.grouping), i.varyColors !== void 0 && n.uint32(24).bool(i.varyColors), i.gapWidth !== void 0 && n.uint32(32).uint32(i.gapWidth), i.overlap !== void 0 && n.uint32(40).sint32(i.overlap), i.gapDepth !== void 0 && n.uint32(48).uint32(i.gapDepth), i.bar3dShape !== void 0 && n.uint32(56).int32(i.bar3dShape), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Zn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.direction = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.grouping = t.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;o.varyColors = t.bool();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;o.gapWidth = t.uint32();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;o.overlap = t.sint32();
                        continue
                    }
                case 6:
                    {
                        if (r !== 48) break;o.gapDepth = t.uint32();
                        continue
                    }
                case 7:
                    {
                        if (r !== 56) break;o.bar3dShape = t.int32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            direction: E(i.direction) ? or(i.direction) : void 0,
            grouping: E(i.grouping) ? eo(i.grouping) : void 0,
            varyColors: E(i.varyColors) ? _.Boolean(i.varyColors) : void 0,
            gapWidth: E(i.gapWidth) ? _.Number(i.gapWidth) : void 0,
            overlap: E(i.overlap) ? _.Number(i.overlap) : void 0,
            gapDepth: E(i.gapDepth) ? _.Number(i.gapDepth) : void 0,
            bar3dShape: E(i.bar3dShape) ? Zo(i.bar3dShape) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.direction !== void 0 && (n.direction = er(i.direction)), i.grouping !== void 0 && (n.grouping = Eo(i.grouping)), i.varyColors !== void 0 && (n.varyColors = i.varyColors), i.gapWidth !== void 0 && (n.gapWidth = Math.round(i.gapWidth)), i.overlap !== void 0 && (n.overlap = Math.round(i.overlap)), i.gapDepth !== void 0 && (n.gapDepth = Math.round(i.gapDepth)), i.bar3dShape !== void 0 && (n.bar3dShape = Xo(i.bar3dShape)), n
    },
    create(i) {
        return ei.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u, c, s;
        const n = Zn();
        return n.direction = (t = i.direction) != null ? t : void 0, n.grouping = (e = i.grouping) != null ? e : void 0, n.varyColors = (o = i.varyColors) != null ? o : void 0, n.gapWidth = (r = i.gapWidth) != null ? r : void 0, n.overlap = (u = i.overlap) != null ? u : void 0, n.gapDepth = (c = i.gapDepth) != null ? c : void 0, n.bar3dShape = (s = i.bar3dShape) != null ? s : void 0, n
    }
};

function Xn() {
    return {
        id: void 0,
        name: "",
        values: [],
        formula: "",
        stringCache: "",
        categories: [],
        categoryFormula: "",
        fill: void 0,
        stroke: void 0,
        points: [],
        valuesFormatCode: void 0,
        categoryFormatCode: void 0,
        invertIfNegative: void 0,
        uniqueId: void 0,
        explosion: void 0,
        marker: void 0,
        xValues: [],
        xFormula: "",
        xValuesFormatCode: void 0,
        bubbleSizes: [],
        bubbleSizeFormula: "",
        categoryPaths: [],
        dataLabels: void 0,
        dataLabelOverrides: []
    }
}
const Ei = {
    encode(i, n = new O) {
        i.id !== void 0 && n.uint32(66).string(i.id), i.name !== "" && n.uint32(10).string(i.name), n.uint32(18).fork();
        for (const t of i.values) n.double(t);
        n.join(), i.formula !== "" && n.uint32(26).string(i.formula), i.stringCache !== "" && n.uint32(34).string(i.stringCache);
        for (const t of i.categories) n.uint32(42).string(t);
        i.categoryFormula !== "" && n.uint32(50).string(i.categoryFormula), i.fill !== void 0 && A.encode(i.fill, n.uint32(58).fork()).join(), i.stroke !== void 0 && T.encode(i.stroke, n.uint32(74).fork()).join();
        for (const t of i.points) Oi.encode(t, n.uint32(82).fork()).join();
        i.valuesFormatCode !== void 0 && n.uint32(90).string(i.valuesFormatCode), i.categoryFormatCode !== void 0 && n.uint32(98).string(i.categoryFormatCode), i.invertIfNegative !== void 0 && n.uint32(104).bool(i.invertIfNegative), i.uniqueId !== void 0 && n.uint32(114).string(i.uniqueId), i.explosion !== void 0 && n.uint32(120).uint32(i.explosion), i.marker !== void 0 && Hi.encode(i.marker, n.uint32(130).fork()).join(), n.uint32(138).fork();
        for (const t of i.xValues) n.double(t);
        n.join(), i.xFormula !== "" && n.uint32(146).string(i.xFormula), i.xValuesFormatCode !== void 0 && n.uint32(154).string(i.xValuesFormatCode), n.uint32(162).fork();
        for (const t of i.bubbleSizes) n.double(t);
        n.join(), i.bubbleSizeFormula !== "" && n.uint32(170).string(i.bubbleSizeFormula);
        for (const t of i.categoryPaths) Ai.encode(t, n.uint32(178).fork()).join();
        i.dataLabels !== void 0 && w.encode(i.dataLabels, n.uint32(186).fork()).join();
        for (const t of i.dataLabelOverrides) Ri.encode(t, n.uint32(194).fork()).join();
        return n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Xn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 8:
                    {
                        if (r !== 66) break;o.id = t.string();
                        continue
                    }
                case 1:
                    {
                        if (r !== 10) break;o.name = t.string();
                        continue
                    }
                case 2:
                    {
                        if (r === 17) {
                            o.values.push(t.double());
                            continue
                        }
                        if (r === 18) {
                            const u = t.uint32() + t.pos;
                            for (; t.pos < u;) o.values.push(t.double());
                            continue
                        }
                        break
                    }
                case 3:
                    {
                        if (r !== 26) break;o.formula = t.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;o.stringCache = t.string();
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;o.categories.push(t.string());
                        continue
                    }
                case 6:
                    {
                        if (r !== 50) break;o.categoryFormula = t.string();
                        continue
                    }
                case 7:
                    {
                        if (r !== 58) break;o.fill = A.decode(t, t.uint32());
                        continue
                    }
                case 9:
                    {
                        if (r !== 74) break;o.stroke = T.decode(t, t.uint32());
                        continue
                    }
                case 10:
                    {
                        if (r !== 82) break;o.points.push(Oi.decode(t, t.uint32()));
                        continue
                    }
                case 11:
                    {
                        if (r !== 90) break;o.valuesFormatCode = t.string();
                        continue
                    }
                case 12:
                    {
                        if (r !== 98) break;o.categoryFormatCode = t.string();
                        continue
                    }
                case 13:
                    {
                        if (r !== 104) break;o.invertIfNegative = t.bool();
                        continue
                    }
                case 14:
                    {
                        if (r !== 114) break;o.uniqueId = t.string();
                        continue
                    }
                case 15:
                    {
                        if (r !== 120) break;o.explosion = t.uint32();
                        continue
                    }
                case 16:
                    {
                        if (r !== 130) break;o.marker = Hi.decode(t, t.uint32());
                        continue
                    }
                case 17:
                    {
                        if (r === 137) {
                            o.xValues.push(t.double());
                            continue
                        }
                        if (r === 138) {
                            const u = t.uint32() + t.pos;
                            for (; t.pos < u;) o.xValues.push(t.double());
                            continue
                        }
                        break
                    }
                case 18:
                    {
                        if (r !== 146) break;o.xFormula = t.string();
                        continue
                    }
                case 19:
                    {
                        if (r !== 154) break;o.xValuesFormatCode = t.string();
                        continue
                    }
                case 20:
                    {
                        if (r === 161) {
                            o.bubbleSizes.push(t.double());
                            continue
                        }
                        if (r === 162) {
                            const u = t.uint32() + t.pos;
                            for (; t.pos < u;) o.bubbleSizes.push(t.double());
                            continue
                        }
                        break
                    }
                case 21:
                    {
                        if (r !== 170) break;o.bubbleSizeFormula = t.string();
                        continue
                    }
                case 22:
                    {
                        if (r !== 178) break;o.categoryPaths.push(Ai.decode(t, t.uint32()));
                        continue
                    }
                case 23:
                    {
                        if (r !== 186) break;o.dataLabels = w.decode(t, t.uint32());
                        continue
                    }
                case 24:
                    {
                        if (r !== 194) break;o.dataLabelOverrides.push(Ri.decode(t, t.uint32()));
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            id: E(i.id) ? _.String(i.id) : void 0,
            name: E(i.name) ? _.String(i.name) : "",
            values: _.Array.isArray(i == null ? void 0 : i.values) ? i.values.map(n => _.Number(n)) : [],
            formula: E(i.formula) ? _.String(i.formula) : "",
            stringCache: E(i.stringCache) ? _.String(i.stringCache) : "",
            categories: _.Array.isArray(i == null ? void 0 : i.categories) ? i.categories.map(n => _.String(n)) : [],
            categoryFormula: E(i.categoryFormula) ? _.String(i.categoryFormula) : "",
            fill: E(i.fill) ? A.fromJSON(i.fill) : void 0,
            stroke: E(i.stroke) ? T.fromJSON(i.stroke) : void 0,
            points: _.Array.isArray(i == null ? void 0 : i.points) ? i.points.map(n => Oi.fromJSON(n)) : [],
            valuesFormatCode: E(i.valuesFormatCode) ? _.String(i.valuesFormatCode) : void 0,
            categoryFormatCode: E(i.categoryFormatCode) ? _.String(i.categoryFormatCode) : void 0,
            invertIfNegative: E(i.invertIfNegative) ? _.Boolean(i.invertIfNegative) : void 0,
            uniqueId: E(i.uniqueId) ? _.String(i.uniqueId) : void 0,
            explosion: E(i.explosion) ? _.Number(i.explosion) : void 0,
            marker: E(i.marker) ? Hi.fromJSON(i.marker) : void 0,
            xValues: _.Array.isArray(i == null ? void 0 : i.xValues) ? i.xValues.map(n => _.Number(n)) : [],
            xFormula: E(i.xFormula) ? _.String(i.xFormula) : "",
            xValuesFormatCode: E(i.xValuesFormatCode) ? _.String(i.xValuesFormatCode) : void 0,
            bubbleSizes: _.Array.isArray(i == null ? void 0 : i.bubbleSizes) ? i.bubbleSizes.map(n => _.Number(n)) : [],
            bubbleSizeFormula: E(i.bubbleSizeFormula) ? _.String(i.bubbleSizeFormula) : "",
            categoryPaths: _.Array.isArray(i == null ? void 0 : i.categoryPaths) ? i.categoryPaths.map(n => Ai.fromJSON(n)) : [],
            dataLabels: E(i.dataLabels) ? w.fromJSON(i.dataLabels) : void 0,
            dataLabelOverrides: _.Array.isArray(i == null ? void 0 : i.dataLabelOverrides) ? i.dataLabelOverrides.map(n => Ri.fromJSON(n)) : []
        }
    },
    toJSON(i) {
        var t, e, o, r, u, c, s;
        const n = {};
        return i.id !== void 0 && (n.id = i.id), i.name !== "" && (n.name = i.name), (t = i.values) != null && t.length && (n.values = i.values), i.formula !== "" && (n.formula = i.formula), i.stringCache !== "" && (n.stringCache = i.stringCache), (e = i.categories) != null && e.length && (n.categories = i.categories), i.categoryFormula !== "" && (n.categoryFormula = i.categoryFormula), i.fill !== void 0 && (n.fill = A.toJSON(i.fill)), i.stroke !== void 0 && (n.stroke = T.toJSON(i.stroke)), (o = i.points) != null && o.length && (n.points = i.points.map(v => Oi.toJSON(v))), i.valuesFormatCode !== void 0 && (n.valuesFormatCode = i.valuesFormatCode), i.categoryFormatCode !== void 0 && (n.categoryFormatCode = i.categoryFormatCode), i.invertIfNegative !== void 0 && (n.invertIfNegative = i.invertIfNegative), i.uniqueId !== void 0 && (n.uniqueId = i.uniqueId), i.explosion !== void 0 && (n.explosion = Math.round(i.explosion)), i.marker !== void 0 && (n.marker = Hi.toJSON(i.marker)), (r = i.xValues) != null && r.length && (n.xValues = i.xValues), i.xFormula !== "" && (n.xFormula = i.xFormula), i.xValuesFormatCode !== void 0 && (n.xValuesFormatCode = i.xValuesFormatCode), (u = i.bubbleSizes) != null && u.length && (n.bubbleSizes = i.bubbleSizes), i.bubbleSizeFormula !== "" && (n.bubbleSizeFormula = i.bubbleSizeFormula), (c = i.categoryPaths) != null && c.length && (n.categoryPaths = i.categoryPaths.map(v => Ai.toJSON(v))), i.dataLabels !== void 0 && (n.dataLabels = w.toJSON(i.dataLabels)), (s = i.dataLabelOverrides) != null && s.length && (n.dataLabelOverrides = i.dataLabelOverrides.map(v => Ri.toJSON(v))), n
    },
    create(i) {
        return Ei.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u, c, s, v, P, L, I, Y, G, H, Z, X, an, fn, Tn, On;
        const n = Xn();
        return n.id = (t = i.id) != null ? t : void 0, n.name = (e = i.name) != null ? e : "", n.values = ((o = i.values) == null ? void 0 : o.map(D => D)) || [], n.formula = (r = i.formula) != null ? r : "", n.stringCache = (u = i.stringCache) != null ? u : "", n.categories = ((c = i.categories) == null ? void 0 : c.map(D => D)) || [], n.categoryFormula = (s = i.categoryFormula) != null ? s : "", n.fill = i.fill !== void 0 && i.fill !== null ? A.fromPartial(i.fill) : void 0, n.stroke = i.stroke !== void 0 && i.stroke !== null ? T.fromPartial(i.stroke) : void 0, n.points = ((v = i.points) == null ? void 0 : v.map(D => Oi.fromPartial(D))) || [], n.valuesFormatCode = (P = i.valuesFormatCode) != null ? P : void 0, n.categoryFormatCode = (L = i.categoryFormatCode) != null ? L : void 0, n.invertIfNegative = (I = i.invertIfNegative) != null ? I : void 0, n.uniqueId = (Y = i.uniqueId) != null ? Y : void 0, n.explosion = (G = i.explosion) != null ? G : void 0, n.marker = i.marker !== void 0 && i.marker !== null ? Hi.fromPartial(i.marker) : void 0, n.xValues = ((H = i.xValues) == null ? void 0 : H.map(D => D)) || [], n.xFormula = (Z = i.xFormula) != null ? Z : "", n.xValuesFormatCode = (X = i.xValuesFormatCode) != null ? X : void 0, n.bubbleSizes = ((an = i.bubbleSizes) == null ? void 0 : an.map(D => D)) || [], n.bubbleSizeFormula = (fn = i.bubbleSizeFormula) != null ? fn : "", n.categoryPaths = ((Tn = i.categoryPaths) == null ? void 0 : Tn.map(D => Ai.fromPartial(D))) || [], n.dataLabels = i.dataLabels !== void 0 && i.dataLabels !== null ? w.fromPartial(i.dataLabels) : void 0, n.dataLabelOverrides = ((On = i.dataLabelOverrides) == null ? void 0 : On.map(D => Ri.fromPartial(D))) || [], n
    }
};

function zn() {
    return {
        grouping: void 0,
        smooth: void 0,
        varyColors: void 0
    }
}
const ai = {
    encode(i, n = new O) {
        return i.grouping !== void 0 && n.uint32(8).int32(i.grouping), i.smooth !== void 0 && n.uint32(16).bool(i.smooth), i.varyColors !== void 0 && n.uint32(24).bool(i.varyColors), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = zn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.grouping = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.smooth = t.bool();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;o.varyColors = t.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            grouping: E(i.grouping) ? Ao(i.grouping) : void 0,
            smooth: E(i.smooth) ? _.Boolean(i.smooth) : void 0,
            varyColors: E(i.varyColors) ? _.Boolean(i.varyColors) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.grouping !== void 0 && (n.grouping = No(i.grouping)), i.smooth !== void 0 && (n.smooth = i.smooth), i.varyColors !== void 0 && (n.varyColors = i.varyColors), n
    },
    create(i) {
        return ai.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o;
        const n = zn();
        return n.grouping = (t = i.grouping) != null ? t : void 0, n.smooth = (e = i.smooth) != null ? e : void 0, n.varyColors = (o = i.varyColors) != null ? o : void 0, n
    }
};

function Qn() {
    return {
        grouping: void 0,
        varyColors: void 0
    }
}
const ui = {
    encode(i, n = new O) {
        return i.grouping !== void 0 && n.uint32(8).int32(i.grouping), i.varyColors !== void 0 && n.uint32(16).bool(i.varyColors), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Qn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.grouping = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.varyColors = t.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            grouping: E(i.grouping) ? vo(i.grouping) : void 0,
            varyColors: E(i.varyColors) ? _.Boolean(i.varyColors) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.grouping !== void 0 && (n.grouping = Po(i.grouping)), i.varyColors !== void 0 && (n.varyColors = i.varyColors), n
    },
    create(i) {
        return ui.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e;
        const n = Qn();
        return n.grouping = (t = i.grouping) != null ? t : void 0, n.varyColors = (e = i.varyColors) != null ? e : void 0, n
    }
};

function qn() {
    return {
        firstSliceAngle: void 0
    }
}
const di = {
    encode(i, n = new O) {
        return i.firstSliceAngle !== void 0 && n.uint32(8).uint32(i.firstSliceAngle), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = qn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.firstSliceAngle = t.uint32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            firstSliceAngle: E(i.firstSliceAngle) ? _.Number(i.firstSliceAngle) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.firstSliceAngle !== void 0 && (n.firstSliceAngle = Math.round(i.firstSliceAngle)), n
    },
    create(i) {
        return di.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t;
        const n = qn();
        return n.firstSliceAngle = (t = i.firstSliceAngle) != null ? t : void 0, n
    }
};

function $n() {
    return {
        holeSize: void 0,
        firstSliceAngle: void 0
    }
}
const li = {
    encode(i, n = new O) {
        return i.holeSize !== void 0 && n.uint32(8).uint32(i.holeSize), i.firstSliceAngle !== void 0 && n.uint32(16).uint32(i.firstSliceAngle), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = $n();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.holeSize = t.uint32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.firstSliceAngle = t.uint32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            holeSize: E(i.holeSize) ? _.Number(i.holeSize) : void 0,
            firstSliceAngle: E(i.firstSliceAngle) ? _.Number(i.firstSliceAngle) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.holeSize !== void 0 && (n.holeSize = Math.round(i.holeSize)), i.firstSliceAngle !== void 0 && (n.firstSliceAngle = Math.round(i.firstSliceAngle)), n
    },
    create(i) {
        return li.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e;
        const n = $n();
        return n.holeSize = (t = i.holeSize) != null ? t : void 0, n.firstSliceAngle = (e = i.firstSliceAngle) != null ? e : void 0, n
    }
};

function gn() {
    return {
        style: void 0,
        varyColors: void 0
    }
}
const _i = {
    encode(i, n = new O) {
        return i.style !== void 0 && n.uint32(8).int32(i.style), i.varyColors !== void 0 && n.uint32(16).bool(i.varyColors), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = gn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.style = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.varyColors = t.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            style: E(i.style) ? co(i.style) : void 0,
            varyColors: E(i.varyColors) ? _.Boolean(i.varyColors) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.style !== void 0 && (n.style = fo(i.style)), i.varyColors !== void 0 && (n.varyColors = i.varyColors), n
    },
    create(i) {
        return _i.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e;
        const n = gn();
        return n.style = (t = i.style) != null ? t : void 0, n.varyColors = (e = i.varyColors) != null ? e : void 0, n
    }
};

function bn() {
    return {
        is3d: void 0,
        scale: void 0,
        showNegative: void 0,
        varyColors: void 0
    }
}
const ci = {
    encode(i, n = new O) {
        return i.is3d !== void 0 && n.uint32(8).bool(i.is3d), i.scale !== void 0 && n.uint32(16).uint32(i.scale), i.showNegative !== void 0 && n.uint32(24).bool(i.showNegative), i.varyColors !== void 0 && n.uint32(32).bool(i.varyColors), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = bn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.is3d = t.bool();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.scale = t.uint32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;o.showNegative = t.bool();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;o.varyColors = t.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            is3d: E(i.is3d) ? _.Boolean(i.is3d) : void 0,
            scale: E(i.scale) ? _.Number(i.scale) : void 0,
            showNegative: E(i.showNegative) ? _.Boolean(i.showNegative) : void 0,
            varyColors: E(i.varyColors) ? _.Boolean(i.varyColors) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.is3d !== void 0 && (n.is3d = i.is3d), i.scale !== void 0 && (n.scale = Math.round(i.scale)), i.showNegative !== void 0 && (n.showNegative = i.showNegative), i.varyColors !== void 0 && (n.varyColors = i.varyColors), n
    },
    create(i) {
        return ci.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r;
        const n = bn();
        return n.is3d = (t = i.is3d) != null ? t : void 0, n.scale = (e = i.scale) != null ? e : void 0, n.showNegative = (o = i.showNegative) != null ? o : void 0, n.varyColors = (r = i.varyColors) != null ? r : void 0, n
    }
};

function jn() {
    return {
        style: void 0,
        varyColors: void 0
    }
}
const fi = {
    encode(i, n = new O) {
        return i.style !== void 0 && n.uint32(8).int32(i.style), i.varyColors !== void 0 && n.uint32(16).bool(i.varyColors), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = jn();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.style = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.varyColors = t.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            style: E(i.style) ? Oo(i.style) : void 0,
            varyColors: E(i.varyColors) ? _.Boolean(i.varyColors) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.style !== void 0 && (n.style = Ro(i.style)), i.varyColors !== void 0 && (n.varyColors = i.varyColors), n
    },
    create(i) {
        return fi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e;
        const n = jn();
        return n.style = (t = i.style) != null ? t : void 0, n.varyColors = (e = i.varyColors) != null ? e : void 0, n
    }
};

function it() {
    return {
        wireframe: void 0
    }
}
const Ti = {
    encode(i, n = new O) {
        return i.wireframe !== void 0 && n.uint32(8).bool(i.wireframe), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = it();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.wireframe = t.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            wireframe: E(i.wireframe) ? _.Boolean(i.wireframe) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.wireframe !== void 0 && (n.wireframe = i.wireframe), n
    },
    create(i) {
        return Ti.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t;
        const n = it();
        return n.wireframe = (t = i.wireframe) != null ? t : void 0, n
    }
};

function nt() {
    return {
        idx: 0,
        fill: void 0,
        stroke: void 0
    }
}
const Oi = {
    encode(i, n = new O) {
        return i.idx !== 0 && n.uint32(8).int32(i.idx), i.fill !== void 0 && A.encode(i.fill, n.uint32(18).fork()).join(), i.stroke !== void 0 && T.encode(i.stroke, n.uint32(26).fork()).join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = nt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.idx = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.fill = A.decode(t, t.uint32());
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.stroke = T.decode(t, t.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            idx: E(i.idx) ? _.Number(i.idx) : 0,
            fill: E(i.fill) ? A.fromJSON(i.fill) : void 0,
            stroke: E(i.stroke) ? T.fromJSON(i.stroke) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.idx !== 0 && (n.idx = Math.round(i.idx)), i.fill !== void 0 && (n.fill = A.toJSON(i.fill)), i.stroke !== void 0 && (n.stroke = T.toJSON(i.stroke)), n
    },
    create(i) {
        return Oi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t;
        const n = nt();
        return n.idx = (t = i.idx) != null ? t : 0, n.fill = i.fill !== void 0 && i.fill !== null ? A.fromPartial(i.fill) : void 0, n.stroke = i.stroke !== void 0 && i.stroke !== null ? T.fromPartial(i.stroke) : void 0, n
    }
};

function tt() {
    return {
        textStyle: void 0,
        line: void 0,
        min: void 0,
        max: void 0,
        majorGridlines: void 0,
        minorGridlines: void 0,
        numberFormatCode: void 0,
        numberFormatSourceLinked: void 0,
        majorUnit: void 0,
        minorUnit: void 0,
        position: void 0,
        orientation: void 0,
        majorTickMark: void 0,
        minorTickMark: void 0,
        tickLabelPosition: void 0,
        crossBetween: void 0,
        crosses: void 0,
        crossValue: void 0,
        deleted: void 0,
        title: void 0,
        titleTextStyle: void 0
    }
}
const U = {
    encode(i, n = new O) {
        return i.textStyle !== void 0 && N.encode(i.textStyle, n.uint32(10).fork()).join(), i.line !== void 0 && T.encode(i.line, n.uint32(18).fork()).join(), i.min !== void 0 && n.uint32(25).double(i.min), i.max !== void 0 && n.uint32(33).double(i.max), i.majorGridlines !== void 0 && T.encode(i.majorGridlines, n.uint32(42).fork()).join(), i.minorGridlines !== void 0 && T.encode(i.minorGridlines, n.uint32(50).fork()).join(), i.numberFormatCode !== void 0 && n.uint32(58).string(i.numberFormatCode), i.numberFormatSourceLinked !== void 0 && n.uint32(168).bool(i.numberFormatSourceLinked), i.majorUnit !== void 0 && n.uint32(65).double(i.majorUnit), i.minorUnit !== void 0 && n.uint32(73).double(i.minorUnit), i.position !== void 0 && n.uint32(80).int32(i.position), i.orientation !== void 0 && n.uint32(88).int32(i.orientation), i.majorTickMark !== void 0 && n.uint32(96).int32(i.majorTickMark), i.minorTickMark !== void 0 && n.uint32(104).int32(i.minorTickMark), i.tickLabelPosition !== void 0 && n.uint32(112).int32(i.tickLabelPosition), i.crossBetween !== void 0 && n.uint32(120).int32(i.crossBetween), i.crosses !== void 0 && n.uint32(128).int32(i.crosses), i.crossValue !== void 0 && n.uint32(137).double(i.crossValue), i.deleted !== void 0 && n.uint32(144).bool(i.deleted), i.title !== void 0 && n.uint32(154).string(i.title), i.titleTextStyle !== void 0 && N.encode(i.titleTextStyle, n.uint32(162).fork()).join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = tt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.textStyle = N.decode(t, t.uint32());
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.line = T.decode(t, t.uint32());
                        continue
                    }
                case 3:
                    {
                        if (r !== 25) break;o.min = t.double();
                        continue
                    }
                case 4:
                    {
                        if (r !== 33) break;o.max = t.double();
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;o.majorGridlines = T.decode(t, t.uint32());
                        continue
                    }
                case 6:
                    {
                        if (r !== 50) break;o.minorGridlines = T.decode(t, t.uint32());
                        continue
                    }
                case 7:
                    {
                        if (r !== 58) break;o.numberFormatCode = t.string();
                        continue
                    }
                case 21:
                    {
                        if (r !== 168) break;o.numberFormatSourceLinked = t.bool();
                        continue
                    }
                case 8:
                    {
                        if (r !== 65) break;o.majorUnit = t.double();
                        continue
                    }
                case 9:
                    {
                        if (r !== 73) break;o.minorUnit = t.double();
                        continue
                    }
                case 10:
                    {
                        if (r !== 80) break;o.position = t.int32();
                        continue
                    }
                case 11:
                    {
                        if (r !== 88) break;o.orientation = t.int32();
                        continue
                    }
                case 12:
                    {
                        if (r !== 96) break;o.majorTickMark = t.int32();
                        continue
                    }
                case 13:
                    {
                        if (r !== 104) break;o.minorTickMark = t.int32();
                        continue
                    }
                case 14:
                    {
                        if (r !== 112) break;o.tickLabelPosition = t.int32();
                        continue
                    }
                case 15:
                    {
                        if (r !== 120) break;o.crossBetween = t.int32();
                        continue
                    }
                case 16:
                    {
                        if (r !== 128) break;o.crosses = t.int32();
                        continue
                    }
                case 17:
                    {
                        if (r !== 137) break;o.crossValue = t.double();
                        continue
                    }
                case 18:
                    {
                        if (r !== 144) break;o.deleted = t.bool();
                        continue
                    }
                case 19:
                    {
                        if (r !== 154) break;o.title = t.string();
                        continue
                    }
                case 20:
                    {
                        if (r !== 162) break;o.titleTextStyle = N.decode(t, t.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            textStyle: E(i.textStyle) ? N.fromJSON(i.textStyle) : void 0,
            line: E(i.line) ? T.fromJSON(i.line) : void 0,
            min: E(i.min) ? _.Number(i.min) : void 0,
            max: E(i.max) ? _.Number(i.max) : void 0,
            majorGridlines: E(i.majorGridlines) ? T.fromJSON(i.majorGridlines) : void 0,
            minorGridlines: E(i.minorGridlines) ? T.fromJSON(i.minorGridlines) : void 0,
            numberFormatCode: E(i.numberFormatCode) ? _.String(i.numberFormatCode) : void 0,
            numberFormatSourceLinked: E(i.numberFormatSourceLinked) ? _.Boolean(i.numberFormatSourceLinked) : void 0,
            majorUnit: E(i.majorUnit) ? _.Number(i.majorUnit) : void 0,
            minorUnit: E(i.minorUnit) ? _.Number(i.minorUnit) : void 0,
            position: E(i.position) ? Uo(i.position) : void 0,
            orientation: E(i.orientation) ? xo(i.orientation) : void 0,
            majorTickMark: E(i.majorTickMark) ? Wn(i.majorTickMark) : void 0,
            minorTickMark: E(i.minorTickMark) ? Wn(i.minorTickMark) : void 0,
            tickLabelPosition: E(i.tickLabelPosition) ? Jo(i.tickLabelPosition) : void 0,
            crossBetween: E(i.crossBetween) ? Wo(i.crossBetween) : void 0,
            crosses: E(i.crosses) ? Vo(i.crosses) : void 0,
            crossValue: E(i.crossValue) ? _.Number(i.crossValue) : void 0,
            deleted: E(i.deleted) ? _.Boolean(i.deleted) : void 0,
            title: E(i.title) ? _.String(i.title) : void 0,
            titleTextStyle: E(i.titleTextStyle) ? N.fromJSON(i.titleTextStyle) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.textStyle !== void 0 && (n.textStyle = N.toJSON(i.textStyle)), i.line !== void 0 && (n.line = T.toJSON(i.line)), i.min !== void 0 && (n.min = i.min), i.max !== void 0 && (n.max = i.max), i.majorGridlines !== void 0 && (n.majorGridlines = T.toJSON(i.majorGridlines)), i.minorGridlines !== void 0 && (n.minorGridlines = T.toJSON(i.minorGridlines)), i.numberFormatCode !== void 0 && (n.numberFormatCode = i.numberFormatCode), i.numberFormatSourceLinked !== void 0 && (n.numberFormatSourceLinked = i.numberFormatSourceLinked), i.majorUnit !== void 0 && (n.majorUnit = i.majorUnit), i.minorUnit !== void 0 && (n.minorUnit = i.minorUnit), i.position !== void 0 && (n.position = Bo(i.position)), i.orientation !== void 0 && (n.orientation = yo(i.orientation)), i.majorTickMark !== void 0 && (n.majorTickMark = mn(i.majorTickMark)), i.minorTickMark !== void 0 && (n.minorTickMark = mn(i.minorTickMark)), i.tickLabelPosition !== void 0 && (n.tickLabelPosition = wo(i.tickLabelPosition)), i.crossBetween !== void 0 && (n.crossBetween = mo(i.crossBetween)), i.crosses !== void 0 && (n.crosses = Ko(i.crosses)), i.crossValue !== void 0 && (n.crossValue = i.crossValue), i.deleted !== void 0 && (n.deleted = i.deleted), i.title !== void 0 && (n.title = i.title), i.titleTextStyle !== void 0 && (n.titleTextStyle = N.toJSON(i.titleTextStyle)), n
    },
    create(i) {
        return U.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u, c, s, v, P, L, I, Y, G, H, Z, X;
        const n = tt();
        return n.textStyle = i.textStyle !== void 0 && i.textStyle !== null ? N.fromPartial(i.textStyle) : void 0, n.line = i.line !== void 0 && i.line !== null ? T.fromPartial(i.line) : void 0, n.min = (t = i.min) != null ? t : void 0, n.max = (e = i.max) != null ? e : void 0, n.majorGridlines = i.majorGridlines !== void 0 && i.majorGridlines !== null ? T.fromPartial(i.majorGridlines) : void 0, n.minorGridlines = i.minorGridlines !== void 0 && i.minorGridlines !== null ? T.fromPartial(i.minorGridlines) : void 0, n.numberFormatCode = (o = i.numberFormatCode) != null ? o : void 0, n.numberFormatSourceLinked = (r = i.numberFormatSourceLinked) != null ? r : void 0, n.majorUnit = (u = i.majorUnit) != null ? u : void 0, n.minorUnit = (c = i.minorUnit) != null ? c : void 0, n.position = (s = i.position) != null ? s : void 0, n.orientation = (v = i.orientation) != null ? v : void 0, n.majorTickMark = (P = i.majorTickMark) != null ? P : void 0, n.minorTickMark = (L = i.minorTickMark) != null ? L : void 0, n.tickLabelPosition = (I = i.tickLabelPosition) != null ? I : void 0, n.crossBetween = (Y = i.crossBetween) != null ? Y : void 0, n.crosses = (G = i.crosses) != null ? G : void 0, n.crossValue = (H = i.crossValue) != null ? H : void 0, n.deleted = (Z = i.deleted) != null ? Z : void 0, n.title = (X = i.title) != null ? X : void 0, n.titleTextStyle = i.titleTextStyle !== void 0 && i.titleTextStyle !== null ? N.fromPartial(i.titleTextStyle) : void 0, n
    }
};

function rt() {
    return {
        showValue: !1,
        position: 0,
        textStyle: void 0,
        leaderLine: void 0,
        fill: void 0,
        stroke: void 0,
        showCategoryName: !1,
        showSeriesName: !1,
        showLegendKey: !1,
        showPercent: !1,
        showBubbleSize: !1,
        showLeaderLines: !1
    }
}
const w = {
    encode(i, n = new O) {
        return i.showValue !== !1 && n.uint32(8).bool(i.showValue), i.position !== 0 && n.uint32(16).int32(i.position), i.textStyle !== void 0 && N.encode(i.textStyle, n.uint32(26).fork()).join(), i.leaderLine !== void 0 && T.encode(i.leaderLine, n.uint32(34).fork()).join(), i.fill !== void 0 && A.encode(i.fill, n.uint32(42).fork()).join(), i.stroke !== void 0 && T.encode(i.stroke, n.uint32(50).fork()).join(), i.showCategoryName !== !1 && n.uint32(56).bool(i.showCategoryName), i.showSeriesName !== !1 && n.uint32(64).bool(i.showSeriesName), i.showLegendKey !== !1 && n.uint32(72).bool(i.showLegendKey), i.showPercent !== !1 && n.uint32(80).bool(i.showPercent), i.showBubbleSize !== !1 && n.uint32(88).bool(i.showBubbleSize), i.showLeaderLines !== !1 && n.uint32(96).bool(i.showLeaderLines), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = rt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.showValue = t.bool();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.position = t.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.textStyle = N.decode(t, t.uint32());
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;o.leaderLine = T.decode(t, t.uint32());
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;o.fill = A.decode(t, t.uint32());
                        continue
                    }
                case 6:
                    {
                        if (r !== 50) break;o.stroke = T.decode(t, t.uint32());
                        continue
                    }
                case 7:
                    {
                        if (r !== 56) break;o.showCategoryName = t.bool();
                        continue
                    }
                case 8:
                    {
                        if (r !== 64) break;o.showSeriesName = t.bool();
                        continue
                    }
                case 9:
                    {
                        if (r !== 72) break;o.showLegendKey = t.bool();
                        continue
                    }
                case 10:
                    {
                        if (r !== 80) break;o.showPercent = t.bool();
                        continue
                    }
                case 11:
                    {
                        if (r !== 88) break;o.showBubbleSize = t.bool();
                        continue
                    }
                case 12:
                    {
                        if (r !== 96) break;o.showLeaderLines = t.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            showValue: E(i.showValue) ? _.Boolean(i.showValue) : !1,
            position: E(i.position) ? Er(i.position) : 0,
            textStyle: E(i.textStyle) ? N.fromJSON(i.textStyle) : void 0,
            leaderLine: E(i.leaderLine) ? T.fromJSON(i.leaderLine) : void 0,
            fill: E(i.fill) ? A.fromJSON(i.fill) : void 0,
            stroke: E(i.stroke) ? T.fromJSON(i.stroke) : void 0,
            showCategoryName: E(i.showCategoryName) ? _.Boolean(i.showCategoryName) : !1,
            showSeriesName: E(i.showSeriesName) ? _.Boolean(i.showSeriesName) : !1,
            showLegendKey: E(i.showLegendKey) ? _.Boolean(i.showLegendKey) : !1,
            showPercent: E(i.showPercent) ? _.Boolean(i.showPercent) : !1,
            showBubbleSize: E(i.showBubbleSize) ? _.Boolean(i.showBubbleSize) : !1,
            showLeaderLines: E(i.showLeaderLines) ? _.Boolean(i.showLeaderLines) : !1
        }
    },
    toJSON(i) {
        const n = {};
        return i.showValue !== !1 && (n.showValue = i.showValue), i.position !== 0 && (n.position = ar(i.position)), i.textStyle !== void 0 && (n.textStyle = N.toJSON(i.textStyle)), i.leaderLine !== void 0 && (n.leaderLine = T.toJSON(i.leaderLine)), i.fill !== void 0 && (n.fill = A.toJSON(i.fill)), i.stroke !== void 0 && (n.stroke = T.toJSON(i.stroke)), i.showCategoryName !== !1 && (n.showCategoryName = i.showCategoryName), i.showSeriesName !== !1 && (n.showSeriesName = i.showSeriesName), i.showLegendKey !== !1 && (n.showLegendKey = i.showLegendKey), i.showPercent !== !1 && (n.showPercent = i.showPercent), i.showBubbleSize !== !1 && (n.showBubbleSize = i.showBubbleSize), i.showLeaderLines !== !1 && (n.showLeaderLines = i.showLeaderLines), n
    },
    create(i) {
        return w.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u, c, s, v;
        const n = rt();
        return n.showValue = (t = i.showValue) != null ? t : !1, n.position = (e = i.position) != null ? e : 0, n.textStyle = i.textStyle !== void 0 && i.textStyle !== null ? N.fromPartial(i.textStyle) : void 0, n.leaderLine = i.leaderLine !== void 0 && i.leaderLine !== null ? T.fromPartial(i.leaderLine) : void 0, n.fill = i.fill !== void 0 && i.fill !== null ? A.fromPartial(i.fill) : void 0, n.stroke = i.stroke !== void 0 && i.stroke !== null ? T.fromPartial(i.stroke) : void 0, n.showCategoryName = (o = i.showCategoryName) != null ? o : !1, n.showSeriesName = (r = i.showSeriesName) != null ? r : !1, n.showLegendKey = (u = i.showLegendKey) != null ? u : !1, n.showPercent = (c = i.showPercent) != null ? c : !1, n.showBubbleSize = (s = i.showBubbleSize) != null ? s : !1, n.showLeaderLines = (v = i.showLeaderLines) != null ? v : !1, n
    }
};

function ot() {
    return {
        idx: 0,
        text: void 0,
        position: void 0,
        textStyle: void 0,
        fill: void 0,
        stroke: void 0,
        showValue: void 0,
        showCategoryName: void 0,
        showSeriesName: void 0,
        showLegendKey: void 0,
        showPercent: void 0,
        showBubbleSize: void 0
    }
}
const Ri = {
    encode(i, n = new O) {
        return i.idx !== 0 && n.uint32(8).int32(i.idx), i.text !== void 0 && n.uint32(18).string(i.text), i.position !== void 0 && n.uint32(24).int32(i.position), i.textStyle !== void 0 && N.encode(i.textStyle, n.uint32(34).fork()).join(), i.fill !== void 0 && A.encode(i.fill, n.uint32(42).fork()).join(), i.stroke !== void 0 && T.encode(i.stroke, n.uint32(50).fork()).join(), i.showValue !== void 0 && n.uint32(56).bool(i.showValue), i.showCategoryName !== void 0 && n.uint32(64).bool(i.showCategoryName), i.showSeriesName !== void 0 && n.uint32(72).bool(i.showSeriesName), i.showLegendKey !== void 0 && n.uint32(80).bool(i.showLegendKey), i.showPercent !== void 0 && n.uint32(88).bool(i.showPercent), i.showBubbleSize !== void 0 && n.uint32(96).bool(i.showBubbleSize), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = ot();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.idx = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.text = t.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;o.position = t.int32();
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;o.textStyle = N.decode(t, t.uint32());
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;o.fill = A.decode(t, t.uint32());
                        continue
                    }
                case 6:
                    {
                        if (r !== 50) break;o.stroke = T.decode(t, t.uint32());
                        continue
                    }
                case 7:
                    {
                        if (r !== 56) break;o.showValue = t.bool();
                        continue
                    }
                case 8:
                    {
                        if (r !== 64) break;o.showCategoryName = t.bool();
                        continue
                    }
                case 9:
                    {
                        if (r !== 72) break;o.showSeriesName = t.bool();
                        continue
                    }
                case 10:
                    {
                        if (r !== 80) break;o.showLegendKey = t.bool();
                        continue
                    }
                case 11:
                    {
                        if (r !== 88) break;o.showPercent = t.bool();
                        continue
                    }
                case 12:
                    {
                        if (r !== 96) break;o.showBubbleSize = t.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            idx: E(i.idx) ? _.Number(i.idx) : 0,
            text: E(i.text) ? _.String(i.text) : void 0,
            position: E(i.position) ? Er(i.position) : void 0,
            textStyle: E(i.textStyle) ? N.fromJSON(i.textStyle) : void 0,
            fill: E(i.fill) ? A.fromJSON(i.fill) : void 0,
            stroke: E(i.stroke) ? T.fromJSON(i.stroke) : void 0,
            showValue: E(i.showValue) ? _.Boolean(i.showValue) : void 0,
            showCategoryName: E(i.showCategoryName) ? _.Boolean(i.showCategoryName) : void 0,
            showSeriesName: E(i.showSeriesName) ? _.Boolean(i.showSeriesName) : void 0,
            showLegendKey: E(i.showLegendKey) ? _.Boolean(i.showLegendKey) : void 0,
            showPercent: E(i.showPercent) ? _.Boolean(i.showPercent) : void 0,
            showBubbleSize: E(i.showBubbleSize) ? _.Boolean(i.showBubbleSize) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.idx !== 0 && (n.idx = Math.round(i.idx)), i.text !== void 0 && (n.text = i.text), i.position !== void 0 && (n.position = ar(i.position)), i.textStyle !== void 0 && (n.textStyle = N.toJSON(i.textStyle)), i.fill !== void 0 && (n.fill = A.toJSON(i.fill)), i.stroke !== void 0 && (n.stroke = T.toJSON(i.stroke)), i.showValue !== void 0 && (n.showValue = i.showValue), i.showCategoryName !== void 0 && (n.showCategoryName = i.showCategoryName), i.showSeriesName !== void 0 && (n.showSeriesName = i.showSeriesName), i.showLegendKey !== void 0 && (n.showLegendKey = i.showLegendKey), i.showPercent !== void 0 && (n.showPercent = i.showPercent), i.showBubbleSize !== void 0 && (n.showBubbleSize = i.showBubbleSize), n
    },
    create(i) {
        return Ri.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u, c, s, v, P;
        const n = ot();
        return n.idx = (t = i.idx) != null ? t : 0, n.text = (e = i.text) != null ? e : void 0, n.position = (o = i.position) != null ? o : void 0, n.textStyle = i.textStyle !== void 0 && i.textStyle !== null ? N.fromPartial(i.textStyle) : void 0, n.fill = i.fill !== void 0 && i.fill !== null ? A.fromPartial(i.fill) : void 0, n.stroke = i.stroke !== void 0 && i.stroke !== null ? T.fromPartial(i.stroke) : void 0, n.showValue = (r = i.showValue) != null ? r : void 0, n.showCategoryName = (u = i.showCategoryName) != null ? u : void 0, n.showSeriesName = (c = i.showSeriesName) != null ? c : void 0, n.showLegendKey = (s = i.showLegendKey) != null ? s : void 0, n.showPercent = (v = i.showPercent) != null ? v : void 0, n.showBubbleSize = (P = i.showBubbleSize) != null ? P : void 0, n
    }
};

function et() {
    return {
        mapArea: void 0,
        projection: void 0,
        labelLayout: void 0,
        dataLevel: void 0,
        showUnknown: void 0,
        onlyRegionsWithData: void 0,
        regionFilter: void 0,
        colorScale: [],
        buckets: void 0,
        classification: void 0,
        colorScaleEx: void 0
    }
}
const si = {
    encode(i, n = new O) {
        i.mapArea !== void 0 && n.uint32(8).int32(i.mapArea), i.projection !== void 0 && n.uint32(16).int32(i.projection), i.labelLayout !== void 0 && n.uint32(24).int32(i.labelLayout), i.dataLevel !== void 0 && n.uint32(32).int32(i.dataLevel), i.showUnknown !== void 0 && n.uint32(40).bool(i.showUnknown), i.onlyRegionsWithData !== void 0 && n.uint32(48).bool(i.onlyRegionsWithData), i.regionFilter !== void 0 && n.uint32(58).string(i.regionFilter);
        for (const t of i.colorScale) S.encode(t, n.uint32(66).fork()).join();
        return i.buckets !== void 0 && n.uint32(72).int32(i.buckets), i.classification !== void 0 && n.uint32(80).int32(i.classification), i.colorScaleEx !== void 0 && Ci.encode(i.colorScaleEx, n.uint32(90).fork()).join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = et();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.mapArea = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.projection = t.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;o.labelLayout = t.int32();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;o.dataLevel = t.int32();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;o.showUnknown = t.bool();
                        continue
                    }
                case 6:
                    {
                        if (r !== 48) break;o.onlyRegionsWithData = t.bool();
                        continue
                    }
                case 7:
                    {
                        if (r !== 58) break;o.regionFilter = t.string();
                        continue
                    }
                case 8:
                    {
                        if (r !== 66) break;o.colorScale.push(S.decode(t, t.uint32()));
                        continue
                    }
                case 9:
                    {
                        if (r !== 72) break;o.buckets = t.int32();
                        continue
                    }
                case 10:
                    {
                        if (r !== 80) break;o.classification = t.int32();
                        continue
                    }
                case 11:
                    {
                        if (r !== 90) break;o.colorScaleEx = Ci.decode(t, t.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            mapArea: E(i.mapArea) ? Io(i.mapArea) : void 0,
            projection: E(i.projection) ? Co(i.projection) : void 0,
            labelLayout: E(i.labelLayout) ? ho(i.labelLayout) : void 0,
            dataLevel: E(i.dataLevel) ? Ho(i.dataLevel) : void 0,
            showUnknown: E(i.showUnknown) ? _.Boolean(i.showUnknown) : void 0,
            onlyRegionsWithData: E(i.onlyRegionsWithData) ? _.Boolean(i.onlyRegionsWithData) : void 0,
            regionFilter: E(i.regionFilter) ? _.String(i.regionFilter) : void 0,
            colorScale: _.Array.isArray(i == null ? void 0 : i.colorScale) ? i.colorScale.map(n => S.fromJSON(n)) : [],
            buckets: E(i.buckets) ? _.Number(i.buckets) : void 0,
            classification: E(i.classification) ? $o(i.classification) : void 0,
            colorScaleEx: E(i.colorScaleEx) ? Ci.fromJSON(i.colorScaleEx) : void 0
        }
    },
    toJSON(i) {
        var t;
        const n = {};
        return i.mapArea !== void 0 && (n.mapArea = Lo(i.mapArea)), i.projection !== void 0 && (n.projection = Mo(i.projection)), i.labelLayout !== void 0 && (n.labelLayout = Yo(i.labelLayout)), i.dataLevel !== void 0 && (n.dataLevel = po(i.dataLevel)), i.showUnknown !== void 0 && (n.showUnknown = i.showUnknown), i.onlyRegionsWithData !== void 0 && (n.onlyRegionsWithData = i.onlyRegionsWithData), i.regionFilter !== void 0 && (n.regionFilter = i.regionFilter), (t = i.colorScale) != null && t.length && (n.colorScale = i.colorScale.map(e => S.toJSON(e))), i.buckets !== void 0 && (n.buckets = Math.round(i.buckets)), i.classification !== void 0 && (n.classification = go(i.classification)), i.colorScaleEx !== void 0 && (n.colorScaleEx = Ci.toJSON(i.colorScaleEx)), n
    },
    create(i) {
        return si.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u, c, s, v, P, L;
        const n = et();
        return n.mapArea = (t = i.mapArea) != null ? t : void 0, n.projection = (e = i.projection) != null ? e : void 0, n.labelLayout = (o = i.labelLayout) != null ? o : void 0, n.dataLevel = (r = i.dataLevel) != null ? r : void 0, n.showUnknown = (u = i.showUnknown) != null ? u : void 0, n.onlyRegionsWithData = (c = i.onlyRegionsWithData) != null ? c : void 0, n.regionFilter = (s = i.regionFilter) != null ? s : void 0, n.colorScale = ((v = i.colorScale) == null ? void 0 : v.map(I => S.fromPartial(I))) || [], n.buckets = (P = i.buckets) != null ? P : void 0, n.classification = (L = i.classification) != null ? L : void 0, n.colorScaleEx = i.colorScaleEx !== void 0 && i.colorScaleEx !== null ? Ci.fromPartial(i.colorScaleEx) : void 0, n
    }
};

function Et() {
    return {
        levels: []
    }
}
const Ai = {
    encode(i, n = new O) {
        for (const t of i.levels) n.uint32(10).string(t);
        return n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Et();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.levels.push(t.string());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            levels: _.Array.isArray(i == null ? void 0 : i.levels) ? i.levels.map(n => _.String(n)) : []
        }
    },
    toJSON(i) {
        var t;
        const n = {};
        return (t = i.levels) != null && t.length && (n.levels = i.levels), n
    },
    create(i) {
        return Ai.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t;
        const n = Et();
        return n.levels = ((t = i.levels) == null ? void 0 : t.map(e => e)) || [], n
    }
};

function at() {
    return {
        parentLabelLayout: void 0
    }
}
const Ni = {
    encode(i, n = new O) {
        return i.parentLabelLayout !== void 0 && n.uint32(8).int32(i.parentLabelLayout), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = at();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.parentLabelLayout = t.int32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            parentLabelLayout: E(i.parentLabelLayout) ? jo(i.parentLabelLayout) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.parentLabelLayout !== void 0 && (n.parentLabelLayout = ie(i.parentLabelLayout)), n
    },
    create(i) {
        return Ni.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t;
        const n = at();
        return n.parentLabelLayout = (t = i.parentLabelLayout) != null ? t : void 0, n
    }
};

function ut() {
    return {
        showMeanLine: void 0,
        showMeanMarker: void 0,
        showNonOutliers: void 0,
        showOutliers: void 0,
        quartileMethod: void 0
    }
}
const Si = {
    encode(i, n = new O) {
        return i.showMeanLine !== void 0 && n.uint32(8).bool(i.showMeanLine), i.showMeanMarker !== void 0 && n.uint32(16).bool(i.showMeanMarker), i.showNonOutliers !== void 0 && n.uint32(24).bool(i.showNonOutliers), i.showOutliers !== void 0 && n.uint32(32).bool(i.showOutliers), i.quartileMethod !== void 0 && n.uint32(40).int32(i.quartileMethod), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = ut();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.showMeanLine = t.bool();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.showMeanMarker = t.bool();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;o.showNonOutliers = t.bool();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;o.showOutliers = t.bool();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;o.quartileMethod = t.int32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            showMeanLine: E(i.showMeanLine) ? _.Boolean(i.showMeanLine) : void 0,
            showMeanMarker: E(i.showMeanMarker) ? _.Boolean(i.showMeanMarker) : void 0,
            showNonOutliers: E(i.showNonOutliers) ? _.Boolean(i.showNonOutliers) : void 0,
            showOutliers: E(i.showOutliers) ? _.Boolean(i.showOutliers) : void 0,
            quartileMethod: E(i.quartileMethod) ? te(i.quartileMethod) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.showMeanLine !== void 0 && (n.showMeanLine = i.showMeanLine), i.showMeanMarker !== void 0 && (n.showMeanMarker = i.showMeanMarker), i.showNonOutliers !== void 0 && (n.showNonOutliers = i.showNonOutliers), i.showOutliers !== void 0 && (n.showOutliers = i.showOutliers), i.quartileMethod !== void 0 && (n.quartileMethod = re(i.quartileMethod)), n
    },
    create(i) {
        return Si.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u;
        const n = ut();
        return n.showMeanLine = (t = i.showMeanLine) != null ? t : void 0, n.showMeanMarker = (e = i.showMeanMarker) != null ? e : void 0, n.showNonOutliers = (o = i.showNonOutliers) != null ? o : void 0, n.showOutliers = (r = i.showOutliers) != null ? r : void 0, n.quartileMethod = (u = i.quartileMethod) != null ? u : void 0, n
    }
};

function dt() {
    return {
        intervalClosed: void 0,
        binWidth: void 0,
        binCount: void 0,
        underflow: void 0,
        overflow: void 0,
        aggregated: void 0
    }
}
const vi = {
    encode(i, n = new O) {
        return i.intervalClosed !== void 0 && n.uint32(8).int32(i.intervalClosed), i.binWidth !== void 0 && n.uint32(17).double(i.binWidth), i.binCount !== void 0 && n.uint32(24).uint32(i.binCount), i.underflow !== void 0 && n.uint32(33).double(i.underflow), i.overflow !== void 0 && n.uint32(41).double(i.overflow), i.aggregated !== void 0 && n.uint32(48).bool(i.aggregated), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = dt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.intervalClosed = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 17) break;o.binWidth = t.double();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;o.binCount = t.uint32();
                        continue
                    }
                case 4:
                    {
                        if (r !== 33) break;o.underflow = t.double();
                        continue
                    }
                case 5:
                    {
                        if (r !== 41) break;o.overflow = t.double();
                        continue
                    }
                case 6:
                    {
                        if (r !== 48) break;o.aggregated = t.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            intervalClosed: E(i.intervalClosed) ? ee(i.intervalClosed) : void 0,
            binWidth: E(i.binWidth) ? _.Number(i.binWidth) : void 0,
            binCount: E(i.binCount) ? _.Number(i.binCount) : void 0,
            underflow: E(i.underflow) ? _.Number(i.underflow) : void 0,
            overflow: E(i.overflow) ? _.Number(i.overflow) : void 0,
            aggregated: E(i.aggregated) ? _.Boolean(i.aggregated) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.intervalClosed !== void 0 && (n.intervalClosed = Ee(i.intervalClosed)), i.binWidth !== void 0 && (n.binWidth = i.binWidth), i.binCount !== void 0 && (n.binCount = Math.round(i.binCount)), i.underflow !== void 0 && (n.underflow = i.underflow), i.overflow !== void 0 && (n.overflow = i.overflow), i.aggregated !== void 0 && (n.aggregated = i.aggregated), n
    },
    create(i) {
        return vi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u, c;
        const n = dt();
        return n.intervalClosed = (t = i.intervalClosed) != null ? t : void 0, n.binWidth = (e = i.binWidth) != null ? e : void 0, n.binCount = (o = i.binCount) != null ? o : void 0, n.underflow = (r = i.underflow) != null ? r : void 0, n.overflow = (u = i.overflow) != null ? u : void 0, n.aggregated = (c = i.aggregated) != null ? c : void 0, n
    }
};

function lt() {
    return {
        subtotalIndices: []
    }
}
const Pi = {
    encode(i, n = new O) {
        n.uint32(10).fork();
        for (const t of i.subtotalIndices) n.uint32(t);
        return n.join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = lt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r === 8) {
                            o.subtotalIndices.push(t.uint32());
                            continue
                        }
                        if (r === 10) {
                            const u = t.uint32() + t.pos;
                            for (; t.pos < u;) o.subtotalIndices.push(t.uint32());
                            continue
                        }
                        break
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            subtotalIndices: _.Array.isArray(i == null ? void 0 : i.subtotalIndices) ? i.subtotalIndices.map(n => _.Number(n)) : []
        }
    },
    toJSON(i) {
        var t;
        const n = {};
        return (t = i.subtotalIndices) != null && t.length && (n.subtotalIndices = i.subtotalIndices.map(e => Math.round(e))), n
    },
    create(i) {
        return Pi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t;
        const n = lt();
        return n.subtotalIndices = ((t = i.subtotalIndices) == null ? void 0 : t.map(e => e)) || [], n
    }
};

function _t() {
    return {
        gapWidth: void 0
    }
}
const Ii = {
    encode(i, n = new O) {
        return i.gapWidth !== void 0 && n.uint32(9).double(i.gapWidth), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = _t();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 9) break;o.gapWidth = t.double();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            gapWidth: E(i.gapWidth) ? _.Number(i.gapWidth) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.gapWidth !== void 0 && (n.gapWidth = i.gapWidth), n
    },
    create(i) {
        return Ii.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t;
        const n = _t();
        return n.gapWidth = (t = i.gapWidth) != null ? t : void 0, n
    }
};

function ct() {
    return {
        styleId: void 0,
        colorStyleId: void 0,
        palette: [],
        themeName: void 0
    }
}
const Li = {
    encode(i, n = new O) {
        i.styleId !== void 0 && n.uint32(8).int32(i.styleId), i.colorStyleId !== void 0 && n.uint32(16).int32(i.colorStyleId);
        for (const t of i.palette) S.encode(t, n.uint32(26).fork()).join();
        return i.themeName !== void 0 && n.uint32(34).string(i.themeName), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = ct();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.styleId = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.colorStyleId = t.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.palette.push(S.decode(t, t.uint32()));
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;o.themeName = t.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            styleId: E(i.styleId) ? _.Number(i.styleId) : void 0,
            colorStyleId: E(i.colorStyleId) ? _.Number(i.colorStyleId) : void 0,
            palette: _.Array.isArray(i == null ? void 0 : i.palette) ? i.palette.map(n => S.fromJSON(n)) : [],
            themeName: E(i.themeName) ? _.String(i.themeName) : void 0
        }
    },
    toJSON(i) {
        var t;
        const n = {};
        return i.styleId !== void 0 && (n.styleId = Math.round(i.styleId)), i.colorStyleId !== void 0 && (n.colorStyleId = Math.round(i.colorStyleId)), (t = i.palette) != null && t.length && (n.palette = i.palette.map(e => S.toJSON(e))), i.themeName !== void 0 && (n.themeName = i.themeName), n
    },
    create(i) {
        return Li.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r;
        const n = ct();
        return n.styleId = (t = i.styleId) != null ? t : void 0, n.colorStyleId = (e = i.colorStyleId) != null ? e : void 0, n.palette = ((o = i.palette) == null ? void 0 : o.map(u => S.fromPartial(u))) || [], n.themeName = (r = i.themeName) != null ? r : void 0, n
    }
};

function ft() {
    return {
        type: void 0,
        colors: []
    }
}
const Ci = {
    encode(i, n = new O) {
        i.type !== void 0 && n.uint32(8).int32(i.type);
        for (const t of i.colors) S.encode(t, n.uint32(18).fork()).join();
        return n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = ft();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.type = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.colors.push(S.decode(t, t.uint32()));
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            type: E(i.type) ? ae(i.type) : void 0,
            colors: _.Array.isArray(i == null ? void 0 : i.colors) ? i.colors.map(n => S.fromJSON(n)) : []
        }
    },
    toJSON(i) {
        var t;
        const n = {};
        return i.type !== void 0 && (n.type = ue(i.type)), (t = i.colors) != null && t.length && (n.colors = i.colors.map(e => S.toJSON(e))), n
    },
    create(i) {
        return Ci.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e;
        const n = ft();
        return n.type = (t = i.type) != null ? t : void 0, n.colors = ((e = i.colors) == null ? void 0 : e.map(o => S.fromPartial(o))) || [], n
    }
};

function Tt() {
    return {
        pivotTableQualifiedName: "",
        pivotTableName: void 0,
        pivotCacheId: void 0,
        fmtId: void 0,
        pivotTableId: void 0
    }
}
const Mi = {
    encode(i, n = new O) {
        return i.pivotTableQualifiedName !== "" && n.uint32(10).string(i.pivotTableQualifiedName), i.pivotTableName !== void 0 && n.uint32(18).string(i.pivotTableName), i.pivotCacheId !== void 0 && n.uint32(24).uint32(i.pivotCacheId), i.fmtId !== void 0 && n.uint32(32).uint32(i.fmtId), i.pivotTableId !== void 0 && n.uint32(42).string(i.pivotTableId), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Tt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.pivotTableQualifiedName = t.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.pivotTableName = t.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;o.pivotCacheId = t.uint32();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;o.fmtId = t.uint32();
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;o.pivotTableId = t.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            pivotTableQualifiedName: E(i.pivotTableQualifiedName) ? _.String(i.pivotTableQualifiedName) : "",
            pivotTableName: E(i.pivotTableName) ? _.String(i.pivotTableName) : void 0,
            pivotCacheId: E(i.pivotCacheId) ? _.Number(i.pivotCacheId) : void 0,
            fmtId: E(i.fmtId) ? _.Number(i.fmtId) : void 0,
            pivotTableId: E(i.pivotTableId) ? _.String(i.pivotTableId) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.pivotTableQualifiedName !== "" && (n.pivotTableQualifiedName = i.pivotTableQualifiedName), i.pivotTableName !== void 0 && (n.pivotTableName = i.pivotTableName), i.pivotCacheId !== void 0 && (n.pivotCacheId = Math.round(i.pivotCacheId)), i.fmtId !== void 0 && (n.fmtId = Math.round(i.fmtId)), i.pivotTableId !== void 0 && (n.pivotTableId = i.pivotTableId), n
    },
    create(i) {
        return Mi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u;
        const n = Tt();
        return n.pivotTableQualifiedName = (t = i.pivotTableQualifiedName) != null ? t : "", n.pivotTableName = (e = i.pivotTableName) != null ? e : void 0, n.pivotCacheId = (o = i.pivotCacheId) != null ? o : void 0, n.fmtId = (r = i.fmtId) != null ? r : void 0, n.pivotTableId = (u = i.pivotTableId) != null ? u : void 0, n
    }
};

function Ot() {
    return {
        dropZonesVisible: void 0,
        showFilterButtons: void 0,
        showCategoryButtons: void 0,
        showDataButtons: void 0,
        showSeriesButtons: void 0
    }
}
const hi = {
    encode(i, n = new O) {
        return i.dropZonesVisible !== void 0 && n.uint32(8).bool(i.dropZonesVisible), i.showFilterButtons !== void 0 && n.uint32(16).bool(i.showFilterButtons), i.showCategoryButtons !== void 0 && n.uint32(24).bool(i.showCategoryButtons), i.showDataButtons !== void 0 && n.uint32(32).bool(i.showDataButtons), i.showSeriesButtons !== void 0 && n.uint32(40).bool(i.showSeriesButtons), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Ot();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.dropZonesVisible = t.bool();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.showFilterButtons = t.bool();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;o.showCategoryButtons = t.bool();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;o.showDataButtons = t.bool();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;o.showSeriesButtons = t.bool();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            dropZonesVisible: E(i.dropZonesVisible) ? _.Boolean(i.dropZonesVisible) : void 0,
            showFilterButtons: E(i.showFilterButtons) ? _.Boolean(i.showFilterButtons) : void 0,
            showCategoryButtons: E(i.showCategoryButtons) ? _.Boolean(i.showCategoryButtons) : void 0,
            showDataButtons: E(i.showDataButtons) ? _.Boolean(i.showDataButtons) : void 0,
            showSeriesButtons: E(i.showSeriesButtons) ? _.Boolean(i.showSeriesButtons) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.dropZonesVisible !== void 0 && (n.dropZonesVisible = i.dropZonesVisible), i.showFilterButtons !== void 0 && (n.showFilterButtons = i.showFilterButtons), i.showCategoryButtons !== void 0 && (n.showCategoryButtons = i.showCategoryButtons), i.showDataButtons !== void 0 && (n.showDataButtons = i.showDataButtons), i.showSeriesButtons !== void 0 && (n.showSeriesButtons = i.showSeriesButtons), n
    },
    create(i) {
        return hi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u;
        const n = Ot();
        return n.dropZonesVisible = (t = i.dropZonesVisible) != null ? t : void 0, n.showFilterButtons = (e = i.showFilterButtons) != null ? e : void 0, n.showCategoryButtons = (o = i.showCategoryButtons) != null ? o : void 0, n.showDataButtons = (r = i.showDataButtons) != null ? r : void 0, n.showSeriesButtons = (u = i.showSeriesButtons) != null ? u : void 0, n
    }
};

function Rt() {
    return {
        idx: 0,
        fill: void 0,
        stroke: void 0,
        text: void 0
    }
}
const Yi = {
    encode(i, n = new O) {
        return i.idx !== 0 && n.uint32(8).uint32(i.idx), i.fill !== void 0 && A.encode(i.fill, n.uint32(18).fork()).join(), i.stroke !== void 0 && T.encode(i.stroke, n.uint32(26).fork()).join(), i.text !== void 0 && N.encode(i.text, n.uint32(34).fork()).join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Rt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.idx = t.uint32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.fill = A.decode(t, t.uint32());
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.stroke = T.decode(t, t.uint32());
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;o.text = N.decode(t, t.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            idx: E(i.idx) ? _.Number(i.idx) : 0,
            fill: E(i.fill) ? A.fromJSON(i.fill) : void 0,
            stroke: E(i.stroke) ? T.fromJSON(i.stroke) : void 0,
            text: E(i.text) ? N.fromJSON(i.text) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.idx !== 0 && (n.idx = Math.round(i.idx)), i.fill !== void 0 && (n.fill = A.toJSON(i.fill)), i.stroke !== void 0 && (n.stroke = T.toJSON(i.stroke)), i.text !== void 0 && (n.text = N.toJSON(i.text)), n
    },
    create(i) {
        return Yi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t;
        const n = Rt();
        return n.idx = (t = i.idx) != null ? t : 0, n.fill = i.fill !== void 0 && i.fill !== null ? A.fromPartial(i.fill) : void 0, n.stroke = i.stroke !== void 0 && i.stroke !== null ? T.fromPartial(i.stroke) : void 0, n.text = i.text !== void 0 && i.text !== null ? N.fromPartial(i.text) : void 0, n
    }
};

function st() {
    return {
        symbol: void 0,
        size: void 0
    }
}
const Hi = {
    encode(i, n = new O) {
        return i.symbol !== void 0 && n.uint32(8).int32(i.symbol), i.size !== void 0 && n.uint32(16).uint32(i.size), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = st();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.symbol = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.size = t.uint32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            symbol: E(i.symbol) ? Do(i.symbol) : void 0,
            size: E(i.size) ? _.Number(i.size) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.symbol !== void 0 && (n.symbol = Go(i.symbol)), i.size !== void 0 && (n.size = Math.round(i.size)), n
    },
    create(i) {
        return Hi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e;
        const n = st();
        return n.symbol = (t = i.symbol) != null ? t : void 0, n.size = (e = i.size) != null ? e : void 0, n
    }
};

function At() {
    return {
        rotX: void 0,
        rotY: void 0,
        rightAngleAxes: void 0,
        perspective: void 0
    }
}
const pi = {
        encode(i, n = new O) {
            return i.rotX !== void 0 && n.uint32(8).int32(i.rotX), i.rotY !== void 0 && n.uint32(16).int32(i.rotY), i.rightAngleAxes !== void 0 && n.uint32(24).bool(i.rightAngleAxes), i.perspective !== void 0 && n.uint32(32).uint32(i.perspective), n
        },
        decode(i, n) {
            const t = i instanceof a ? i : new a(i);
            let e = n === void 0 ? t.len : t.pos + n;
            const o = At();
            for (; t.pos < e;) {
                const r = t.uint32();
                switch (r >>> 3) {
                    case 1:
                        {
                            if (r !== 8) break;o.rotX = t.int32();
                            continue
                        }
                    case 2:
                        {
                            if (r !== 16) break;o.rotY = t.int32();
                            continue
                        }
                    case 3:
                        {
                            if (r !== 24) break;o.rightAngleAxes = t.bool();
                            continue
                        }
                    case 4:
                        {
                            if (r !== 32) break;o.perspective = t.uint32();
                            continue
                        }
                }
                if ((r & 7) === 4 || r === 0) break;
                t.skip(r & 7)
            }
            return o
        },
        fromJSON(i) {
            return {
                rotX: E(i.rotX) ? _.Number(i.rotX) : void 0,
                rotY: E(i.rotY) ? _.Number(i.rotY) : void 0,
                rightAngleAxes: E(i.rightAngleAxes) ? _.Boolean(i.rightAngleAxes) : void 0,
                perspective: E(i.perspective) ? _.Number(i.perspective) : void 0
            }
        },
        toJSON(i) {
            const n = {};
            return i.rotX !== void 0 && (n.rotX = Math.round(i.rotX)), i.rotY !== void 0 && (n.rotY = Math.round(i.rotY)), i.rightAngleAxes !== void 0 && (n.rightAngleAxes = i.rightAngleAxes), i.perspective !== void 0 && (n.perspective = Math.round(i.perspective)), n
        },
        create(i) {
            return pi.fromPartial(i != null ? i : {})
        },
        fromPartial(i) {
            var t, e, o, r;
            const n = At();
            return n.rotX = (t = i.rotX) != null ? t : void 0, n.rotY = (e = i.rotY) != null ? e : void 0, n.rightAngleAxes = (o = i.rightAngleAxes) != null ? o : void 0, n.perspective = (r = i.perspective) != null ? r : void 0, n
        }
    },
    _ = (() => {
        if (typeof globalThis < "u") return globalThis;
        if (typeof self < "u") return self;
        if (typeof window < "u") return window;
        if (typeof global < "u") return global;
        throw "Unable to locate global object"
    })();

function E(i) {
    return i != null
}
var de = (i => (i[i.SHAPE_GEOMETRY_UNSPECIFIED = 0] = "SHAPE_GEOMETRY_UNSPECIFIED", i[i.SHAPE_GEOMETRY_LINE = 1] = "SHAPE_GEOMETRY_LINE", i[i.SHAPE_GEOMETRY_LINE_INV = 2] = "SHAPE_GEOMETRY_LINE_INV", i[i.SHAPE_GEOMETRY_TRIANGLE = 3] = "SHAPE_GEOMETRY_TRIANGLE", i[i.SHAPE_GEOMETRY_RT_TRIANGLE = 4] = "SHAPE_GEOMETRY_RT_TRIANGLE", i[i.SHAPE_GEOMETRY_RECT = 5] = "SHAPE_GEOMETRY_RECT", i[i.SHAPE_GEOMETRY_DIAMOND = 6] = "SHAPE_GEOMETRY_DIAMOND", i[i.SHAPE_GEOMETRY_PARALLELOGRAM = 7] = "SHAPE_GEOMETRY_PARALLELOGRAM", i[i.SHAPE_GEOMETRY_TRAPEZOID = 8] = "SHAPE_GEOMETRY_TRAPEZOID", i[i.SHAPE_GEOMETRY_NON_ISOSCELES_TRAPEZOID = 9] = "SHAPE_GEOMETRY_NON_ISOSCELES_TRAPEZOID", i[i.SHAPE_GEOMETRY_PENTAGON = 10] = "SHAPE_GEOMETRY_PENTAGON", i[i.SHAPE_GEOMETRY_HEXAGON = 11] = "SHAPE_GEOMETRY_HEXAGON", i[i.SHAPE_GEOMETRY_HEPTAGON = 12] = "SHAPE_GEOMETRY_HEPTAGON", i[i.SHAPE_GEOMETRY_OCTAGON = 13] = "SHAPE_GEOMETRY_OCTAGON", i[i.SHAPE_GEOMETRY_DECAGON = 14] = "SHAPE_GEOMETRY_DECAGON", i[i.SHAPE_GEOMETRY_DODECAGON = 15] = "SHAPE_GEOMETRY_DODECAGON", i[i.SHAPE_GEOMETRY_STAR4 = 16] = "SHAPE_GEOMETRY_STAR4", i[i.SHAPE_GEOMETRY_STAR5 = 17] = "SHAPE_GEOMETRY_STAR5", i[i.SHAPE_GEOMETRY_STAR6 = 18] = "SHAPE_GEOMETRY_STAR6", i[i.SHAPE_GEOMETRY_STAR7 = 19] = "SHAPE_GEOMETRY_STAR7", i[i.SHAPE_GEOMETRY_STAR8 = 20] = "SHAPE_GEOMETRY_STAR8", i[i.SHAPE_GEOMETRY_STAR10 = 21] = "SHAPE_GEOMETRY_STAR10", i[i.SHAPE_GEOMETRY_STAR12 = 22] = "SHAPE_GEOMETRY_STAR12", i[i.SHAPE_GEOMETRY_STAR16 = 23] = "SHAPE_GEOMETRY_STAR16", i[i.SHAPE_GEOMETRY_STAR24 = 24] = "SHAPE_GEOMETRY_STAR24", i[i.SHAPE_GEOMETRY_STAR32 = 25] = "SHAPE_GEOMETRY_STAR32", i[i.SHAPE_GEOMETRY_ROUND_RECT = 26] = "SHAPE_GEOMETRY_ROUND_RECT", i[i.SHAPE_GEOMETRY_ROUND1_RECT = 27] = "SHAPE_GEOMETRY_ROUND1_RECT", i[i.SHAPE_GEOMETRY_ROUND2_SAME_RECT = 28] = "SHAPE_GEOMETRY_ROUND2_SAME_RECT", i[i.SHAPE_GEOMETRY_ROUND2_DIAG_RECT = 29] = "SHAPE_GEOMETRY_ROUND2_DIAG_RECT", i[i.SHAPE_GEOMETRY_SNIP_ROUND_RECT = 30] = "SHAPE_GEOMETRY_SNIP_ROUND_RECT", i[i.SHAPE_GEOMETRY_SNIP1_RECT = 31] = "SHAPE_GEOMETRY_SNIP1_RECT", i[i.SHAPE_GEOMETRY_SNIP2_SAME_RECT = 32] = "SHAPE_GEOMETRY_SNIP2_SAME_RECT", i[i.SHAPE_GEOMETRY_SNIP2_DIAG_RECT = 33] = "SHAPE_GEOMETRY_SNIP2_DIAG_RECT", i[i.SHAPE_GEOMETRY_PLAQUE = 34] = "SHAPE_GEOMETRY_PLAQUE", i[i.SHAPE_GEOMETRY_ELLIPSE = 35] = "SHAPE_GEOMETRY_ELLIPSE", i[i.SHAPE_GEOMETRY_TEARDROP = 36] = "SHAPE_GEOMETRY_TEARDROP", i[i.SHAPE_GEOMETRY_HOME_PLATE = 37] = "SHAPE_GEOMETRY_HOME_PLATE", i[i.SHAPE_GEOMETRY_CHEVRON = 38] = "SHAPE_GEOMETRY_CHEVRON", i[i.SHAPE_GEOMETRY_PIE_WEDGE = 39] = "SHAPE_GEOMETRY_PIE_WEDGE", i[i.SHAPE_GEOMETRY_PIE = 40] = "SHAPE_GEOMETRY_PIE", i[i.SHAPE_GEOMETRY_BLOCK_ARC = 41] = "SHAPE_GEOMETRY_BLOCK_ARC", i[i.SHAPE_GEOMETRY_DONUT = 42] = "SHAPE_GEOMETRY_DONUT", i[i.SHAPE_GEOMETRY_NO_SMOKING = 43] = "SHAPE_GEOMETRY_NO_SMOKING", i[i.SHAPE_GEOMETRY_RIGHT_ARROW = 44] = "SHAPE_GEOMETRY_RIGHT_ARROW", i[i.SHAPE_GEOMETRY_LEFT_ARROW = 45] = "SHAPE_GEOMETRY_LEFT_ARROW", i[i.SHAPE_GEOMETRY_UP_ARROW = 46] = "SHAPE_GEOMETRY_UP_ARROW", i[i.SHAPE_GEOMETRY_DOWN_ARROW = 47] = "SHAPE_GEOMETRY_DOWN_ARROW", i[i.SHAPE_GEOMETRY_STRIPED_RIGHT_ARROW = 48] = "SHAPE_GEOMETRY_STRIPED_RIGHT_ARROW", i[i.SHAPE_GEOMETRY_NOTCHED_RIGHT_ARROW = 49] = "SHAPE_GEOMETRY_NOTCHED_RIGHT_ARROW", i[i.SHAPE_GEOMETRY_BENT_UP_ARROW = 50] = "SHAPE_GEOMETRY_BENT_UP_ARROW", i[i.SHAPE_GEOMETRY_LEFT_RIGHT_ARROW = 51] = "SHAPE_GEOMETRY_LEFT_RIGHT_ARROW", i[i.SHAPE_GEOMETRY_UP_DOWN_ARROW = 52] = "SHAPE_GEOMETRY_UP_DOWN_ARROW", i[i.SHAPE_GEOMETRY_LEFT_UP_ARROW = 53] = "SHAPE_GEOMETRY_LEFT_UP_ARROW", i[i.SHAPE_GEOMETRY_LEFT_RIGHT_UP_ARROW = 54] = "SHAPE_GEOMETRY_LEFT_RIGHT_UP_ARROW", i[i.SHAPE_GEOMETRY_QUAD_ARROW = 55] = "SHAPE_GEOMETRY_QUAD_ARROW", i[i.SHAPE_GEOMETRY_LEFT_ARROW_CALLOUT = 56] = "SHAPE_GEOMETRY_LEFT_ARROW_CALLOUT", i[i.SHAPE_GEOMETRY_RIGHT_ARROW_CALLOUT = 57] = "SHAPE_GEOMETRY_RIGHT_ARROW_CALLOUT", i[i.SHAPE_GEOMETRY_UP_ARROW_CALLOUT = 58] = "SHAPE_GEOMETRY_UP_ARROW_CALLOUT", i[i.SHAPE_GEOMETRY_DOWN_ARROW_CALLOUT = 59] = "SHAPE_GEOMETRY_DOWN_ARROW_CALLOUT", i[i.SHAPE_GEOMETRY_LEFT_RIGHT_ARROW_CALLOUT = 60] = "SHAPE_GEOMETRY_LEFT_RIGHT_ARROW_CALLOUT", i[i.SHAPE_GEOMETRY_UP_DOWN_ARROW_CALLOUT = 61] = "SHAPE_GEOMETRY_UP_DOWN_ARROW_CALLOUT", i[i.SHAPE_GEOMETRY_QUAD_ARROW_CALLOUT = 62] = "SHAPE_GEOMETRY_QUAD_ARROW_CALLOUT", i[i.SHAPE_GEOMETRY_BENT_ARROW = 63] = "SHAPE_GEOMETRY_BENT_ARROW", i[i.SHAPE_GEOMETRY_UTURN_ARROW = 64] = "SHAPE_GEOMETRY_UTURN_ARROW", i[i.SHAPE_GEOMETRY_CIRCULAR_ARROW = 65] = "SHAPE_GEOMETRY_CIRCULAR_ARROW", i[i.SHAPE_GEOMETRY_LEFT_CIRCULAR_ARROW = 66] = "SHAPE_GEOMETRY_LEFT_CIRCULAR_ARROW", i[i.SHAPE_GEOMETRY_LEFT_RIGHT_CIRCULAR_ARROW = 67] = "SHAPE_GEOMETRY_LEFT_RIGHT_CIRCULAR_ARROW", i[i.SHAPE_GEOMETRY_CURVED_RIGHT_ARROW = 68] = "SHAPE_GEOMETRY_CURVED_RIGHT_ARROW", i[i.SHAPE_GEOMETRY_CURVED_LEFT_ARROW = 69] = "SHAPE_GEOMETRY_CURVED_LEFT_ARROW", i[i.SHAPE_GEOMETRY_CURVED_UP_ARROW = 70] = "SHAPE_GEOMETRY_CURVED_UP_ARROW", i[i.SHAPE_GEOMETRY_CURVED_DOWN_ARROW = 71] = "SHAPE_GEOMETRY_CURVED_DOWN_ARROW", i[i.SHAPE_GEOMETRY_SWOOSH_ARROW = 72] = "SHAPE_GEOMETRY_SWOOSH_ARROW", i[i.SHAPE_GEOMETRY_CUBE = 73] = "SHAPE_GEOMETRY_CUBE", i[i.SHAPE_GEOMETRY_CAN = 74] = "SHAPE_GEOMETRY_CAN", i[i.SHAPE_GEOMETRY_LIGHTNING_BOLT = 75] = "SHAPE_GEOMETRY_LIGHTNING_BOLT", i[i.SHAPE_GEOMETRY_HEART = 76] = "SHAPE_GEOMETRY_HEART", i[i.SHAPE_GEOMETRY_SUN = 77] = "SHAPE_GEOMETRY_SUN", i[i.SHAPE_GEOMETRY_MOON = 78] = "SHAPE_GEOMETRY_MOON", i[i.SHAPE_GEOMETRY_SMILEY_FACE = 79] = "SHAPE_GEOMETRY_SMILEY_FACE", i[i.SHAPE_GEOMETRY_IRREGULAR_SEAL1 = 80] = "SHAPE_GEOMETRY_IRREGULAR_SEAL1", i[i.SHAPE_GEOMETRY_IRREGULAR_SEAL2 = 81] = "SHAPE_GEOMETRY_IRREGULAR_SEAL2", i[i.SHAPE_GEOMETRY_FOLDED_CORNER = 82] = "SHAPE_GEOMETRY_FOLDED_CORNER", i[i.SHAPE_GEOMETRY_BEVEL = 83] = "SHAPE_GEOMETRY_BEVEL", i[i.SHAPE_GEOMETRY_FRAME = 84] = "SHAPE_GEOMETRY_FRAME", i[i.SHAPE_GEOMETRY_HALF_FRAME = 85] = "SHAPE_GEOMETRY_HALF_FRAME", i[i.SHAPE_GEOMETRY_CORNER = 86] = "SHAPE_GEOMETRY_CORNER", i[i.SHAPE_GEOMETRY_DIAG_STRIPE = 87] = "SHAPE_GEOMETRY_DIAG_STRIPE", i[i.SHAPE_GEOMETRY_CHORD = 88] = "SHAPE_GEOMETRY_CHORD", i[i.SHAPE_GEOMETRY_ARC = 89] = "SHAPE_GEOMETRY_ARC", i[i.SHAPE_GEOMETRY_LEFT_BRACKET = 90] = "SHAPE_GEOMETRY_LEFT_BRACKET", i[i.SHAPE_GEOMETRY_RIGHT_BRACKET = 91] = "SHAPE_GEOMETRY_RIGHT_BRACKET", i[i.SHAPE_GEOMETRY_LEFT_BRACE = 92] = "SHAPE_GEOMETRY_LEFT_BRACE", i[i.SHAPE_GEOMETRY_RIGHT_BRACE = 93] = "SHAPE_GEOMETRY_RIGHT_BRACE", i[i.SHAPE_GEOMETRY_BRACKET_PAIR = 94] = "SHAPE_GEOMETRY_BRACKET_PAIR", i[i.SHAPE_GEOMETRY_BRACE_PAIR = 95] = "SHAPE_GEOMETRY_BRACE_PAIR", i[i.SHAPE_GEOMETRY_STRAIGHT_CONNECTOR1 = 96] = "SHAPE_GEOMETRY_STRAIGHT_CONNECTOR1", i[i.SHAPE_GEOMETRY_BENT_CONNECTOR2 = 97] = "SHAPE_GEOMETRY_BENT_CONNECTOR2", i[i.SHAPE_GEOMETRY_BENT_CONNECTOR3 = 98] = "SHAPE_GEOMETRY_BENT_CONNECTOR3", i[i.SHAPE_GEOMETRY_BENT_CONNECTOR4 = 99] = "SHAPE_GEOMETRY_BENT_CONNECTOR4", i[i.SHAPE_GEOMETRY_BENT_CONNECTOR5 = 100] = "SHAPE_GEOMETRY_BENT_CONNECTOR5", i[i.SHAPE_GEOMETRY_CURVED_CONNECTOR2 = 101] = "SHAPE_GEOMETRY_CURVED_CONNECTOR2", i[i.SHAPE_GEOMETRY_CURVED_CONNECTOR3 = 102] = "SHAPE_GEOMETRY_CURVED_CONNECTOR3", i[i.SHAPE_GEOMETRY_CURVED_CONNECTOR4 = 103] = "SHAPE_GEOMETRY_CURVED_CONNECTOR4", i[i.SHAPE_GEOMETRY_CURVED_CONNECTOR5 = 104] = "SHAPE_GEOMETRY_CURVED_CONNECTOR5", i[i.SHAPE_GEOMETRY_CALLOUT1 = 105] = "SHAPE_GEOMETRY_CALLOUT1", i[i.SHAPE_GEOMETRY_CALLOUT2 = 106] = "SHAPE_GEOMETRY_CALLOUT2", i[i.SHAPE_GEOMETRY_CALLOUT3 = 107] = "SHAPE_GEOMETRY_CALLOUT3", i[i.SHAPE_GEOMETRY_ACCENT_CALLOUT1 = 108] = "SHAPE_GEOMETRY_ACCENT_CALLOUT1", i[i.SHAPE_GEOMETRY_ACCENT_CALLOUT2 = 109] = "SHAPE_GEOMETRY_ACCENT_CALLOUT2", i[i.SHAPE_GEOMETRY_ACCENT_CALLOUT3 = 110] = "SHAPE_GEOMETRY_ACCENT_CALLOUT3", i[i.SHAPE_GEOMETRY_BORDER_CALLOUT1 = 111] = "SHAPE_GEOMETRY_BORDER_CALLOUT1", i[i.SHAPE_GEOMETRY_BORDER_CALLOUT2 = 112] = "SHAPE_GEOMETRY_BORDER_CALLOUT2", i[i.SHAPE_GEOMETRY_BORDER_CALLOUT3 = 113] = "SHAPE_GEOMETRY_BORDER_CALLOUT3", i[i.SHAPE_GEOMETRY_ACCENT_BORDER_CALLOUT1 = 114] = "SHAPE_GEOMETRY_ACCENT_BORDER_CALLOUT1", i[i.SHAPE_GEOMETRY_ACCENT_BORDER_CALLOUT2 = 115] = "SHAPE_GEOMETRY_ACCENT_BORDER_CALLOUT2", i[i.SHAPE_GEOMETRY_ACCENT_BORDER_CALLOUT3 = 116] = "SHAPE_GEOMETRY_ACCENT_BORDER_CALLOUT3", i[i.SHAPE_GEOMETRY_WEDGE_RECT_CALLOUT = 117] = "SHAPE_GEOMETRY_WEDGE_RECT_CALLOUT", i[i.SHAPE_GEOMETRY_WEDGE_ROUND_RECT_CALLOUT = 118] = "SHAPE_GEOMETRY_WEDGE_ROUND_RECT_CALLOUT", i[i.SHAPE_GEOMETRY_WEDGE_ELLIPSE_CALLOUT = 119] = "SHAPE_GEOMETRY_WEDGE_ELLIPSE_CALLOUT", i[i.SHAPE_GEOMETRY_CLOUD_CALLOUT = 120] = "SHAPE_GEOMETRY_CLOUD_CALLOUT", i[i.SHAPE_GEOMETRY_CLOUD = 121] = "SHAPE_GEOMETRY_CLOUD", i[i.SHAPE_GEOMETRY_RIBBON = 122] = "SHAPE_GEOMETRY_RIBBON", i[i.SHAPE_GEOMETRY_RIBBON2 = 123] = "SHAPE_GEOMETRY_RIBBON2", i[i.SHAPE_GEOMETRY_ELLIPSE_RIBBON = 124] = "SHAPE_GEOMETRY_ELLIPSE_RIBBON", i[i.SHAPE_GEOMETRY_ELLIPSE_RIBBON2 = 125] = "SHAPE_GEOMETRY_ELLIPSE_RIBBON2", i[i.SHAPE_GEOMETRY_LEFT_RIGHT_RIBBON = 126] = "SHAPE_GEOMETRY_LEFT_RIGHT_RIBBON", i[i.SHAPE_GEOMETRY_VERTICAL_SCROLL = 127] = "SHAPE_GEOMETRY_VERTICAL_SCROLL", i[i.SHAPE_GEOMETRY_HORIZONTAL_SCROLL = 128] = "SHAPE_GEOMETRY_HORIZONTAL_SCROLL", i[i.SHAPE_GEOMETRY_WAVE = 129] = "SHAPE_GEOMETRY_WAVE", i[i.SHAPE_GEOMETRY_DOUBLE_WAVE = 130] = "SHAPE_GEOMETRY_DOUBLE_WAVE", i[i.SHAPE_GEOMETRY_PLUS = 131] = "SHAPE_GEOMETRY_PLUS", i[i.SHAPE_GEOMETRY_FLOW_CHART_PROCESS = 132] = "SHAPE_GEOMETRY_FLOW_CHART_PROCESS", i[i.SHAPE_GEOMETRY_FLOW_CHART_DECISION = 133] = "SHAPE_GEOMETRY_FLOW_CHART_DECISION", i[i.SHAPE_GEOMETRY_FLOW_CHART_INPUT_OUTPUT = 134] = "SHAPE_GEOMETRY_FLOW_CHART_INPUT_OUTPUT", i[i.SHAPE_GEOMETRY_FLOW_CHART_PREDEFINED_PROCESS = 135] = "SHAPE_GEOMETRY_FLOW_CHART_PREDEFINED_PROCESS", i[i.SHAPE_GEOMETRY_FLOW_CHART_INTERNAL_STORAGE = 136] = "SHAPE_GEOMETRY_FLOW_CHART_INTERNAL_STORAGE", i[i.SHAPE_GEOMETRY_FLOW_CHART_DOCUMENT = 137] = "SHAPE_GEOMETRY_FLOW_CHART_DOCUMENT", i[i.SHAPE_GEOMETRY_FLOW_CHART_MULTIDOCUMENT = 138] = "SHAPE_GEOMETRY_FLOW_CHART_MULTIDOCUMENT", i[i.SHAPE_GEOMETRY_FLOW_CHART_TERMINATOR = 139] = "SHAPE_GEOMETRY_FLOW_CHART_TERMINATOR", i[i.SHAPE_GEOMETRY_FLOW_CHART_PREPARATION = 140] = "SHAPE_GEOMETRY_FLOW_CHART_PREPARATION", i[i.SHAPE_GEOMETRY_FLOW_CHART_MANUAL_INPUT = 141] = "SHAPE_GEOMETRY_FLOW_CHART_MANUAL_INPUT", i[i.SHAPE_GEOMETRY_FLOW_CHART_MANUAL_OPERATION = 142] = "SHAPE_GEOMETRY_FLOW_CHART_MANUAL_OPERATION", i[i.SHAPE_GEOMETRY_FLOW_CHART_CONNECTOR = 143] = "SHAPE_GEOMETRY_FLOW_CHART_CONNECTOR", i[i.SHAPE_GEOMETRY_FLOW_CHART_PUNCHED_CARD = 144] = "SHAPE_GEOMETRY_FLOW_CHART_PUNCHED_CARD", i[i.SHAPE_GEOMETRY_FLOW_CHART_PUNCHED_TAPE = 145] = "SHAPE_GEOMETRY_FLOW_CHART_PUNCHED_TAPE", i[i.SHAPE_GEOMETRY_FLOW_CHART_SUMMING_JUNCTION = 146] = "SHAPE_GEOMETRY_FLOW_CHART_SUMMING_JUNCTION", i[i.SHAPE_GEOMETRY_FLOW_CHART_OR = 147] = "SHAPE_GEOMETRY_FLOW_CHART_OR", i[i.SHAPE_GEOMETRY_FLOW_CHART_COLLATE = 148] = "SHAPE_GEOMETRY_FLOW_CHART_COLLATE", i[i.SHAPE_GEOMETRY_FLOW_CHART_SORT = 149] = "SHAPE_GEOMETRY_FLOW_CHART_SORT", i[i.SHAPE_GEOMETRY_FLOW_CHART_EXTRACT = 150] = "SHAPE_GEOMETRY_FLOW_CHART_EXTRACT", i[i.SHAPE_GEOMETRY_FLOW_CHART_MERGE = 151] = "SHAPE_GEOMETRY_FLOW_CHART_MERGE", i[i.SHAPE_GEOMETRY_FLOW_CHART_OFFLINE_STORAGE = 152] = "SHAPE_GEOMETRY_FLOW_CHART_OFFLINE_STORAGE", i[i.SHAPE_GEOMETRY_FLOW_CHART_ONLINE_STORAGE = 153] = "SHAPE_GEOMETRY_FLOW_CHART_ONLINE_STORAGE", i[i.SHAPE_GEOMETRY_FLOW_CHART_MAGNETIC_TAPE = 154] = "SHAPE_GEOMETRY_FLOW_CHART_MAGNETIC_TAPE", i[i.SHAPE_GEOMETRY_FLOW_CHART_MAGNETIC_DISK = 155] = "SHAPE_GEOMETRY_FLOW_CHART_MAGNETIC_DISK", i[i.SHAPE_GEOMETRY_FLOW_CHART_MAGNETIC_DRUM = 156] = "SHAPE_GEOMETRY_FLOW_CHART_MAGNETIC_DRUM", i[i.SHAPE_GEOMETRY_FLOW_CHART_DISPLAY = 157] = "SHAPE_GEOMETRY_FLOW_CHART_DISPLAY", i[i.SHAPE_GEOMETRY_FLOW_CHART_DELAY = 158] = "SHAPE_GEOMETRY_FLOW_CHART_DELAY", i[i.SHAPE_GEOMETRY_FLOW_CHART_ALTERNATE_PROCESS = 159] = "SHAPE_GEOMETRY_FLOW_CHART_ALTERNATE_PROCESS", i[i.SHAPE_GEOMETRY_FLOW_CHART_OFFPAGE_CONNECTOR = 160] = "SHAPE_GEOMETRY_FLOW_CHART_OFFPAGE_CONNECTOR", i[i.SHAPE_GEOMETRY_ACTION_BUTTON_BLANK = 161] = "SHAPE_GEOMETRY_ACTION_BUTTON_BLANK", i[i.SHAPE_GEOMETRY_ACTION_BUTTON_HOME = 162] = "SHAPE_GEOMETRY_ACTION_BUTTON_HOME", i[i.SHAPE_GEOMETRY_ACTION_BUTTON_HELP = 163] = "SHAPE_GEOMETRY_ACTION_BUTTON_HELP", i[i.SHAPE_GEOMETRY_ACTION_BUTTON_INFORMATION = 164] = "SHAPE_GEOMETRY_ACTION_BUTTON_INFORMATION", i[i.SHAPE_GEOMETRY_ACTION_BUTTON_FORWARD_NEXT = 165] = "SHAPE_GEOMETRY_ACTION_BUTTON_FORWARD_NEXT", i[i.SHAPE_GEOMETRY_ACTION_BUTTON_BACK_PREVIOUS = 166] = "SHAPE_GEOMETRY_ACTION_BUTTON_BACK_PREVIOUS", i[i.SHAPE_GEOMETRY_ACTION_BUTTON_END = 167] = "SHAPE_GEOMETRY_ACTION_BUTTON_END", i[i.SHAPE_GEOMETRY_ACTION_BUTTON_BEGINNING = 168] = "SHAPE_GEOMETRY_ACTION_BUTTON_BEGINNING", i[i.SHAPE_GEOMETRY_ACTION_BUTTON_RETURN = 169] = "SHAPE_GEOMETRY_ACTION_BUTTON_RETURN", i[i.SHAPE_GEOMETRY_ACTION_BUTTON_DOCUMENT = 170] = "SHAPE_GEOMETRY_ACTION_BUTTON_DOCUMENT", i[i.SHAPE_GEOMETRY_ACTION_BUTTON_SOUND = 171] = "SHAPE_GEOMETRY_ACTION_BUTTON_SOUND", i[i.SHAPE_GEOMETRY_ACTION_BUTTON_MOVIE = 172] = "SHAPE_GEOMETRY_ACTION_BUTTON_MOVIE", i[i.SHAPE_GEOMETRY_GEAR6 = 173] = "SHAPE_GEOMETRY_GEAR6", i[i.SHAPE_GEOMETRY_GEAR9 = 174] = "SHAPE_GEOMETRY_GEAR9", i[i.SHAPE_GEOMETRY_FUNNEL = 175] = "SHAPE_GEOMETRY_FUNNEL", i[i.SHAPE_GEOMETRY_MATH_PLUS = 176] = "SHAPE_GEOMETRY_MATH_PLUS", i[i.SHAPE_GEOMETRY_MATH_MINUS = 177] = "SHAPE_GEOMETRY_MATH_MINUS", i[i.SHAPE_GEOMETRY_MATH_MULTIPLY = 178] = "SHAPE_GEOMETRY_MATH_MULTIPLY", i[i.SHAPE_GEOMETRY_MATH_DIVIDE = 179] = "SHAPE_GEOMETRY_MATH_DIVIDE", i[i.SHAPE_GEOMETRY_MATH_EQUAL = 180] = "SHAPE_GEOMETRY_MATH_EQUAL", i[i.SHAPE_GEOMETRY_MATH_NOT_EQUAL = 181] = "SHAPE_GEOMETRY_MATH_NOT_EQUAL", i[i.SHAPE_GEOMETRY_CORNER_TABS = 182] = "SHAPE_GEOMETRY_CORNER_TABS", i[i.SHAPE_GEOMETRY_SQUARE_TABS = 183] = "SHAPE_GEOMETRY_SQUARE_TABS", i[i.SHAPE_GEOMETRY_PLAQUE_TABS = 184] = "SHAPE_GEOMETRY_PLAQUE_TABS", i[i.SHAPE_GEOMETRY_CHART_X = 185] = "SHAPE_GEOMETRY_CHART_X", i[i.SHAPE_GEOMETRY_CHART_STAR = 186] = "SHAPE_GEOMETRY_CHART_STAR", i[i.SHAPE_GEOMETRY_CHART_PLUS = 187] = "SHAPE_GEOMETRY_CHART_PLUS", i[i.SHAPE_GEOMETRY_CUSTOM = 188] = "SHAPE_GEOMETRY_CUSTOM", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(de || {});

function le(i) {
    switch (i) {
        case 0:
        case "SHAPE_GEOMETRY_UNSPECIFIED":
            return 0;
        case 1:
        case "SHAPE_GEOMETRY_LINE":
            return 1;
        case 2:
        case "SHAPE_GEOMETRY_LINE_INV":
            return 2;
        case 3:
        case "SHAPE_GEOMETRY_TRIANGLE":
            return 3;
        case 4:
        case "SHAPE_GEOMETRY_RT_TRIANGLE":
            return 4;
        case 5:
        case "SHAPE_GEOMETRY_RECT":
            return 5;
        case 6:
        case "SHAPE_GEOMETRY_DIAMOND":
            return 6;
        case 7:
        case "SHAPE_GEOMETRY_PARALLELOGRAM":
            return 7;
        case 8:
        case "SHAPE_GEOMETRY_TRAPEZOID":
            return 8;
        case 9:
        case "SHAPE_GEOMETRY_NON_ISOSCELES_TRAPEZOID":
            return 9;
        case 10:
        case "SHAPE_GEOMETRY_PENTAGON":
            return 10;
        case 11:
        case "SHAPE_GEOMETRY_HEXAGON":
            return 11;
        case 12:
        case "SHAPE_GEOMETRY_HEPTAGON":
            return 12;
        case 13:
        case "SHAPE_GEOMETRY_OCTAGON":
            return 13;
        case 14:
        case "SHAPE_GEOMETRY_DECAGON":
            return 14;
        case 15:
        case "SHAPE_GEOMETRY_DODECAGON":
            return 15;
        case 16:
        case "SHAPE_GEOMETRY_STAR4":
            return 16;
        case 17:
        case "SHAPE_GEOMETRY_STAR5":
            return 17;
        case 18:
        case "SHAPE_GEOMETRY_STAR6":
            return 18;
        case 19:
        case "SHAPE_GEOMETRY_STAR7":
            return 19;
        case 20:
        case "SHAPE_GEOMETRY_STAR8":
            return 20;
        case 21:
        case "SHAPE_GEOMETRY_STAR10":
            return 21;
        case 22:
        case "SHAPE_GEOMETRY_STAR12":
            return 22;
        case 23:
        case "SHAPE_GEOMETRY_STAR16":
            return 23;
        case 24:
        case "SHAPE_GEOMETRY_STAR24":
            return 24;
        case 25:
        case "SHAPE_GEOMETRY_STAR32":
            return 25;
        case 26:
        case "SHAPE_GEOMETRY_ROUND_RECT":
            return 26;
        case 27:
        case "SHAPE_GEOMETRY_ROUND1_RECT":
            return 27;
        case 28:
        case "SHAPE_GEOMETRY_ROUND2_SAME_RECT":
            return 28;
        case 29:
        case "SHAPE_GEOMETRY_ROUND2_DIAG_RECT":
            return 29;
        case 30:
        case "SHAPE_GEOMETRY_SNIP_ROUND_RECT":
            return 30;
        case 31:
        case "SHAPE_GEOMETRY_SNIP1_RECT":
            return 31;
        case 32:
        case "SHAPE_GEOMETRY_SNIP2_SAME_RECT":
            return 32;
        case 33:
        case "SHAPE_GEOMETRY_SNIP2_DIAG_RECT":
            return 33;
        case 34:
        case "SHAPE_GEOMETRY_PLAQUE":
            return 34;
        case 35:
        case "SHAPE_GEOMETRY_ELLIPSE":
            return 35;
        case 36:
        case "SHAPE_GEOMETRY_TEARDROP":
            return 36;
        case 37:
        case "SHAPE_GEOMETRY_HOME_PLATE":
            return 37;
        case 38:
        case "SHAPE_GEOMETRY_CHEVRON":
            return 38;
        case 39:
        case "SHAPE_GEOMETRY_PIE_WEDGE":
            return 39;
        case 40:
        case "SHAPE_GEOMETRY_PIE":
            return 40;
        case 41:
        case "SHAPE_GEOMETRY_BLOCK_ARC":
            return 41;
        case 42:
        case "SHAPE_GEOMETRY_DONUT":
            return 42;
        case 43:
        case "SHAPE_GEOMETRY_NO_SMOKING":
            return 43;
        case 44:
        case "SHAPE_GEOMETRY_RIGHT_ARROW":
            return 44;
        case 45:
        case "SHAPE_GEOMETRY_LEFT_ARROW":
            return 45;
        case 46:
        case "SHAPE_GEOMETRY_UP_ARROW":
            return 46;
        case 47:
        case "SHAPE_GEOMETRY_DOWN_ARROW":
            return 47;
        case 48:
        case "SHAPE_GEOMETRY_STRIPED_RIGHT_ARROW":
            return 48;
        case 49:
        case "SHAPE_GEOMETRY_NOTCHED_RIGHT_ARROW":
            return 49;
        case 50:
        case "SHAPE_GEOMETRY_BENT_UP_ARROW":
            return 50;
        case 51:
        case "SHAPE_GEOMETRY_LEFT_RIGHT_ARROW":
            return 51;
        case 52:
        case "SHAPE_GEOMETRY_UP_DOWN_ARROW":
            return 52;
        case 53:
        case "SHAPE_GEOMETRY_LEFT_UP_ARROW":
            return 53;
        case 54:
        case "SHAPE_GEOMETRY_LEFT_RIGHT_UP_ARROW":
            return 54;
        case 55:
        case "SHAPE_GEOMETRY_QUAD_ARROW":
            return 55;
        case 56:
        case "SHAPE_GEOMETRY_LEFT_ARROW_CALLOUT":
            return 56;
        case 57:
        case "SHAPE_GEOMETRY_RIGHT_ARROW_CALLOUT":
            return 57;
        case 58:
        case "SHAPE_GEOMETRY_UP_ARROW_CALLOUT":
            return 58;
        case 59:
        case "SHAPE_GEOMETRY_DOWN_ARROW_CALLOUT":
            return 59;
        case 60:
        case "SHAPE_GEOMETRY_LEFT_RIGHT_ARROW_CALLOUT":
            return 60;
        case 61:
        case "SHAPE_GEOMETRY_UP_DOWN_ARROW_CALLOUT":
            return 61;
        case 62:
        case "SHAPE_GEOMETRY_QUAD_ARROW_CALLOUT":
            return 62;
        case 63:
        case "SHAPE_GEOMETRY_BENT_ARROW":
            return 63;
        case 64:
        case "SHAPE_GEOMETRY_UTURN_ARROW":
            return 64;
        case 65:
        case "SHAPE_GEOMETRY_CIRCULAR_ARROW":
            return 65;
        case 66:
        case "SHAPE_GEOMETRY_LEFT_CIRCULAR_ARROW":
            return 66;
        case 67:
        case "SHAPE_GEOMETRY_LEFT_RIGHT_CIRCULAR_ARROW":
            return 67;
        case 68:
        case "SHAPE_GEOMETRY_CURVED_RIGHT_ARROW":
            return 68;
        case 69:
        case "SHAPE_GEOMETRY_CURVED_LEFT_ARROW":
            return 69;
        case 70:
        case "SHAPE_GEOMETRY_CURVED_UP_ARROW":
            return 70;
        case 71:
        case "SHAPE_GEOMETRY_CURVED_DOWN_ARROW":
            return 71;
        case 72:
        case "SHAPE_GEOMETRY_SWOOSH_ARROW":
            return 72;
        case 73:
        case "SHAPE_GEOMETRY_CUBE":
            return 73;
        case 74:
        case "SHAPE_GEOMETRY_CAN":
            return 74;
        case 75:
        case "SHAPE_GEOMETRY_LIGHTNING_BOLT":
            return 75;
        case 76:
        case "SHAPE_GEOMETRY_HEART":
            return 76;
        case 77:
        case "SHAPE_GEOMETRY_SUN":
            return 77;
        case 78:
        case "SHAPE_GEOMETRY_MOON":
            return 78;
        case 79:
        case "SHAPE_GEOMETRY_SMILEY_FACE":
            return 79;
        case 80:
        case "SHAPE_GEOMETRY_IRREGULAR_SEAL1":
            return 80;
        case 81:
        case "SHAPE_GEOMETRY_IRREGULAR_SEAL2":
            return 81;
        case 82:
        case "SHAPE_GEOMETRY_FOLDED_CORNER":
            return 82;
        case 83:
        case "SHAPE_GEOMETRY_BEVEL":
            return 83;
        case 84:
        case "SHAPE_GEOMETRY_FRAME":
            return 84;
        case 85:
        case "SHAPE_GEOMETRY_HALF_FRAME":
            return 85;
        case 86:
        case "SHAPE_GEOMETRY_CORNER":
            return 86;
        case 87:
        case "SHAPE_GEOMETRY_DIAG_STRIPE":
            return 87;
        case 88:
        case "SHAPE_GEOMETRY_CHORD":
            return 88;
        case 89:
        case "SHAPE_GEOMETRY_ARC":
            return 89;
        case 90:
        case "SHAPE_GEOMETRY_LEFT_BRACKET":
            return 90;
        case 91:
        case "SHAPE_GEOMETRY_RIGHT_BRACKET":
            return 91;
        case 92:
        case "SHAPE_GEOMETRY_LEFT_BRACE":
            return 92;
        case 93:
        case "SHAPE_GEOMETRY_RIGHT_BRACE":
            return 93;
        case 94:
        case "SHAPE_GEOMETRY_BRACKET_PAIR":
            return 94;
        case 95:
        case "SHAPE_GEOMETRY_BRACE_PAIR":
            return 95;
        case 96:
        case "SHAPE_GEOMETRY_STRAIGHT_CONNECTOR1":
            return 96;
        case 97:
        case "SHAPE_GEOMETRY_BENT_CONNECTOR2":
            return 97;
        case 98:
        case "SHAPE_GEOMETRY_BENT_CONNECTOR3":
            return 98;
        case 99:
        case "SHAPE_GEOMETRY_BENT_CONNECTOR4":
            return 99;
        case 100:
        case "SHAPE_GEOMETRY_BENT_CONNECTOR5":
            return 100;
        case 101:
        case "SHAPE_GEOMETRY_CURVED_CONNECTOR2":
            return 101;
        case 102:
        case "SHAPE_GEOMETRY_CURVED_CONNECTOR3":
            return 102;
        case 103:
        case "SHAPE_GEOMETRY_CURVED_CONNECTOR4":
            return 103;
        case 104:
        case "SHAPE_GEOMETRY_CURVED_CONNECTOR5":
            return 104;
        case 105:
        case "SHAPE_GEOMETRY_CALLOUT1":
            return 105;
        case 106:
        case "SHAPE_GEOMETRY_CALLOUT2":
            return 106;
        case 107:
        case "SHAPE_GEOMETRY_CALLOUT3":
            return 107;
        case 108:
        case "SHAPE_GEOMETRY_ACCENT_CALLOUT1":
            return 108;
        case 109:
        case "SHAPE_GEOMETRY_ACCENT_CALLOUT2":
            return 109;
        case 110:
        case "SHAPE_GEOMETRY_ACCENT_CALLOUT3":
            return 110;
        case 111:
        case "SHAPE_GEOMETRY_BORDER_CALLOUT1":
            return 111;
        case 112:
        case "SHAPE_GEOMETRY_BORDER_CALLOUT2":
            return 112;
        case 113:
        case "SHAPE_GEOMETRY_BORDER_CALLOUT3":
            return 113;
        case 114:
        case "SHAPE_GEOMETRY_ACCENT_BORDER_CALLOUT1":
            return 114;
        case 115:
        case "SHAPE_GEOMETRY_ACCENT_BORDER_CALLOUT2":
            return 115;
        case 116:
        case "SHAPE_GEOMETRY_ACCENT_BORDER_CALLOUT3":
            return 116;
        case 117:
        case "SHAPE_GEOMETRY_WEDGE_RECT_CALLOUT":
            return 117;
        case 118:
        case "SHAPE_GEOMETRY_WEDGE_ROUND_RECT_CALLOUT":
            return 118;
        case 119:
        case "SHAPE_GEOMETRY_WEDGE_ELLIPSE_CALLOUT":
            return 119;
        case 120:
        case "SHAPE_GEOMETRY_CLOUD_CALLOUT":
            return 120;
        case 121:
        case "SHAPE_GEOMETRY_CLOUD":
            return 121;
        case 122:
        case "SHAPE_GEOMETRY_RIBBON":
            return 122;
        case 123:
        case "SHAPE_GEOMETRY_RIBBON2":
            return 123;
        case 124:
        case "SHAPE_GEOMETRY_ELLIPSE_RIBBON":
            return 124;
        case 125:
        case "SHAPE_GEOMETRY_ELLIPSE_RIBBON2":
            return 125;
        case 126:
        case "SHAPE_GEOMETRY_LEFT_RIGHT_RIBBON":
            return 126;
        case 127:
        case "SHAPE_GEOMETRY_VERTICAL_SCROLL":
            return 127;
        case 128:
        case "SHAPE_GEOMETRY_HORIZONTAL_SCROLL":
            return 128;
        case 129:
        case "SHAPE_GEOMETRY_WAVE":
            return 129;
        case 130:
        case "SHAPE_GEOMETRY_DOUBLE_WAVE":
            return 130;
        case 131:
        case "SHAPE_GEOMETRY_PLUS":
            return 131;
        case 132:
        case "SHAPE_GEOMETRY_FLOW_CHART_PROCESS":
            return 132;
        case 133:
        case "SHAPE_GEOMETRY_FLOW_CHART_DECISION":
            return 133;
        case 134:
        case "SHAPE_GEOMETRY_FLOW_CHART_INPUT_OUTPUT":
            return 134;
        case 135:
        case "SHAPE_GEOMETRY_FLOW_CHART_PREDEFINED_PROCESS":
            return 135;
        case 136:
        case "SHAPE_GEOMETRY_FLOW_CHART_INTERNAL_STORAGE":
            return 136;
        case 137:
        case "SHAPE_GEOMETRY_FLOW_CHART_DOCUMENT":
            return 137;
        case 138:
        case "SHAPE_GEOMETRY_FLOW_CHART_MULTIDOCUMENT":
            return 138;
        case 139:
        case "SHAPE_GEOMETRY_FLOW_CHART_TERMINATOR":
            return 139;
        case 140:
        case "SHAPE_GEOMETRY_FLOW_CHART_PREPARATION":
            return 140;
        case 141:
        case "SHAPE_GEOMETRY_FLOW_CHART_MANUAL_INPUT":
            return 141;
        case 142:
        case "SHAPE_GEOMETRY_FLOW_CHART_MANUAL_OPERATION":
            return 142;
        case 143:
        case "SHAPE_GEOMETRY_FLOW_CHART_CONNECTOR":
            return 143;
        case 144:
        case "SHAPE_GEOMETRY_FLOW_CHART_PUNCHED_CARD":
            return 144;
        case 145:
        case "SHAPE_GEOMETRY_FLOW_CHART_PUNCHED_TAPE":
            return 145;
        case 146:
        case "SHAPE_GEOMETRY_FLOW_CHART_SUMMING_JUNCTION":
            return 146;
        case 147:
        case "SHAPE_GEOMETRY_FLOW_CHART_OR":
            return 147;
        case 148:
        case "SHAPE_GEOMETRY_FLOW_CHART_COLLATE":
            return 148;
        case 149:
        case "SHAPE_GEOMETRY_FLOW_CHART_SORT":
            return 149;
        case 150:
        case "SHAPE_GEOMETRY_FLOW_CHART_EXTRACT":
            return 150;
        case 151:
        case "SHAPE_GEOMETRY_FLOW_CHART_MERGE":
            return 151;
        case 152:
        case "SHAPE_GEOMETRY_FLOW_CHART_OFFLINE_STORAGE":
            return 152;
        case 153:
        case "SHAPE_GEOMETRY_FLOW_CHART_ONLINE_STORAGE":
            return 153;
        case 154:
        case "SHAPE_GEOMETRY_FLOW_CHART_MAGNETIC_TAPE":
            return 154;
        case 155:
        case "SHAPE_GEOMETRY_FLOW_CHART_MAGNETIC_DISK":
            return 155;
        case 156:
        case "SHAPE_GEOMETRY_FLOW_CHART_MAGNETIC_DRUM":
            return 156;
        case 157:
        case "SHAPE_GEOMETRY_FLOW_CHART_DISPLAY":
            return 157;
        case 158:
        case "SHAPE_GEOMETRY_FLOW_CHART_DELAY":
            return 158;
        case 159:
        case "SHAPE_GEOMETRY_FLOW_CHART_ALTERNATE_PROCESS":
            return 159;
        case 160:
        case "SHAPE_GEOMETRY_FLOW_CHART_OFFPAGE_CONNECTOR":
            return 160;
        case 161:
        case "SHAPE_GEOMETRY_ACTION_BUTTON_BLANK":
            return 161;
        case 162:
        case "SHAPE_GEOMETRY_ACTION_BUTTON_HOME":
            return 162;
        case 163:
        case "SHAPE_GEOMETRY_ACTION_BUTTON_HELP":
            return 163;
        case 164:
        case "SHAPE_GEOMETRY_ACTION_BUTTON_INFORMATION":
            return 164;
        case 165:
        case "SHAPE_GEOMETRY_ACTION_BUTTON_FORWARD_NEXT":
            return 165;
        case 166:
        case "SHAPE_GEOMETRY_ACTION_BUTTON_BACK_PREVIOUS":
            return 166;
        case 167:
        case "SHAPE_GEOMETRY_ACTION_BUTTON_END":
            return 167;
        case 168:
        case "SHAPE_GEOMETRY_ACTION_BUTTON_BEGINNING":
            return 168;
        case 169:
        case "SHAPE_GEOMETRY_ACTION_BUTTON_RETURN":
            return 169;
        case 170:
        case "SHAPE_GEOMETRY_ACTION_BUTTON_DOCUMENT":
            return 170;
        case 171:
        case "SHAPE_GEOMETRY_ACTION_BUTTON_SOUND":
            return 171;
        case 172:
        case "SHAPE_GEOMETRY_ACTION_BUTTON_MOVIE":
            return 172;
        case 173:
        case "SHAPE_GEOMETRY_GEAR6":
            return 173;
        case 174:
        case "SHAPE_GEOMETRY_GEAR9":
            return 174;
        case 175:
        case "SHAPE_GEOMETRY_FUNNEL":
            return 175;
        case 176:
        case "SHAPE_GEOMETRY_MATH_PLUS":
            return 176;
        case 177:
        case "SHAPE_GEOMETRY_MATH_MINUS":
            return 177;
        case 178:
        case "SHAPE_GEOMETRY_MATH_MULTIPLY":
            return 178;
        case 179:
        case "SHAPE_GEOMETRY_MATH_DIVIDE":
            return 179;
        case 180:
        case "SHAPE_GEOMETRY_MATH_EQUAL":
            return 180;
        case 181:
        case "SHAPE_GEOMETRY_MATH_NOT_EQUAL":
            return 181;
        case 182:
        case "SHAPE_GEOMETRY_CORNER_TABS":
            return 182;
        case 183:
        case "SHAPE_GEOMETRY_SQUARE_TABS":
            return 183;
        case 184:
        case "SHAPE_GEOMETRY_PLAQUE_TABS":
            return 184;
        case 185:
        case "SHAPE_GEOMETRY_CHART_X":
            return 185;
        case 186:
        case "SHAPE_GEOMETRY_CHART_STAR":
            return 186;
        case 187:
        case "SHAPE_GEOMETRY_CHART_PLUS":
            return 187;
        case 188:
        case "SHAPE_GEOMETRY_CUSTOM":
            return 188;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function _e(i) {
    switch (i) {
        case 0:
            return "SHAPE_GEOMETRY_UNSPECIFIED";
        case 1:
            return "SHAPE_GEOMETRY_LINE";
        case 2:
            return "SHAPE_GEOMETRY_LINE_INV";
        case 3:
            return "SHAPE_GEOMETRY_TRIANGLE";
        case 4:
            return "SHAPE_GEOMETRY_RT_TRIANGLE";
        case 5:
            return "SHAPE_GEOMETRY_RECT";
        case 6:
            return "SHAPE_GEOMETRY_DIAMOND";
        case 7:
            return "SHAPE_GEOMETRY_PARALLELOGRAM";
        case 8:
            return "SHAPE_GEOMETRY_TRAPEZOID";
        case 9:
            return "SHAPE_GEOMETRY_NON_ISOSCELES_TRAPEZOID";
        case 10:
            return "SHAPE_GEOMETRY_PENTAGON";
        case 11:
            return "SHAPE_GEOMETRY_HEXAGON";
        case 12:
            return "SHAPE_GEOMETRY_HEPTAGON";
        case 13:
            return "SHAPE_GEOMETRY_OCTAGON";
        case 14:
            return "SHAPE_GEOMETRY_DECAGON";
        case 15:
            return "SHAPE_GEOMETRY_DODECAGON";
        case 16:
            return "SHAPE_GEOMETRY_STAR4";
        case 17:
            return "SHAPE_GEOMETRY_STAR5";
        case 18:
            return "SHAPE_GEOMETRY_STAR6";
        case 19:
            return "SHAPE_GEOMETRY_STAR7";
        case 20:
            return "SHAPE_GEOMETRY_STAR8";
        case 21:
            return "SHAPE_GEOMETRY_STAR10";
        case 22:
            return "SHAPE_GEOMETRY_STAR12";
        case 23:
            return "SHAPE_GEOMETRY_STAR16";
        case 24:
            return "SHAPE_GEOMETRY_STAR24";
        case 25:
            return "SHAPE_GEOMETRY_STAR32";
        case 26:
            return "SHAPE_GEOMETRY_ROUND_RECT";
        case 27:
            return "SHAPE_GEOMETRY_ROUND1_RECT";
        case 28:
            return "SHAPE_GEOMETRY_ROUND2_SAME_RECT";
        case 29:
            return "SHAPE_GEOMETRY_ROUND2_DIAG_RECT";
        case 30:
            return "SHAPE_GEOMETRY_SNIP_ROUND_RECT";
        case 31:
            return "SHAPE_GEOMETRY_SNIP1_RECT";
        case 32:
            return "SHAPE_GEOMETRY_SNIP2_SAME_RECT";
        case 33:
            return "SHAPE_GEOMETRY_SNIP2_DIAG_RECT";
        case 34:
            return "SHAPE_GEOMETRY_PLAQUE";
        case 35:
            return "SHAPE_GEOMETRY_ELLIPSE";
        case 36:
            return "SHAPE_GEOMETRY_TEARDROP";
        case 37:
            return "SHAPE_GEOMETRY_HOME_PLATE";
        case 38:
            return "SHAPE_GEOMETRY_CHEVRON";
        case 39:
            return "SHAPE_GEOMETRY_PIE_WEDGE";
        case 40:
            return "SHAPE_GEOMETRY_PIE";
        case 41:
            return "SHAPE_GEOMETRY_BLOCK_ARC";
        case 42:
            return "SHAPE_GEOMETRY_DONUT";
        case 43:
            return "SHAPE_GEOMETRY_NO_SMOKING";
        case 44:
            return "SHAPE_GEOMETRY_RIGHT_ARROW";
        case 45:
            return "SHAPE_GEOMETRY_LEFT_ARROW";
        case 46:
            return "SHAPE_GEOMETRY_UP_ARROW";
        case 47:
            return "SHAPE_GEOMETRY_DOWN_ARROW";
        case 48:
            return "SHAPE_GEOMETRY_STRIPED_RIGHT_ARROW";
        case 49:
            return "SHAPE_GEOMETRY_NOTCHED_RIGHT_ARROW";
        case 50:
            return "SHAPE_GEOMETRY_BENT_UP_ARROW";
        case 51:
            return "SHAPE_GEOMETRY_LEFT_RIGHT_ARROW";
        case 52:
            return "SHAPE_GEOMETRY_UP_DOWN_ARROW";
        case 53:
            return "SHAPE_GEOMETRY_LEFT_UP_ARROW";
        case 54:
            return "SHAPE_GEOMETRY_LEFT_RIGHT_UP_ARROW";
        case 55:
            return "SHAPE_GEOMETRY_QUAD_ARROW";
        case 56:
            return "SHAPE_GEOMETRY_LEFT_ARROW_CALLOUT";
        case 57:
            return "SHAPE_GEOMETRY_RIGHT_ARROW_CALLOUT";
        case 58:
            return "SHAPE_GEOMETRY_UP_ARROW_CALLOUT";
        case 59:
            return "SHAPE_GEOMETRY_DOWN_ARROW_CALLOUT";
        case 60:
            return "SHAPE_GEOMETRY_LEFT_RIGHT_ARROW_CALLOUT";
        case 61:
            return "SHAPE_GEOMETRY_UP_DOWN_ARROW_CALLOUT";
        case 62:
            return "SHAPE_GEOMETRY_QUAD_ARROW_CALLOUT";
        case 63:
            return "SHAPE_GEOMETRY_BENT_ARROW";
        case 64:
            return "SHAPE_GEOMETRY_UTURN_ARROW";
        case 65:
            return "SHAPE_GEOMETRY_CIRCULAR_ARROW";
        case 66:
            return "SHAPE_GEOMETRY_LEFT_CIRCULAR_ARROW";
        case 67:
            return "SHAPE_GEOMETRY_LEFT_RIGHT_CIRCULAR_ARROW";
        case 68:
            return "SHAPE_GEOMETRY_CURVED_RIGHT_ARROW";
        case 69:
            return "SHAPE_GEOMETRY_CURVED_LEFT_ARROW";
        case 70:
            return "SHAPE_GEOMETRY_CURVED_UP_ARROW";
        case 71:
            return "SHAPE_GEOMETRY_CURVED_DOWN_ARROW";
        case 72:
            return "SHAPE_GEOMETRY_SWOOSH_ARROW";
        case 73:
            return "SHAPE_GEOMETRY_CUBE";
        case 74:
            return "SHAPE_GEOMETRY_CAN";
        case 75:
            return "SHAPE_GEOMETRY_LIGHTNING_BOLT";
        case 76:
            return "SHAPE_GEOMETRY_HEART";
        case 77:
            return "SHAPE_GEOMETRY_SUN";
        case 78:
            return "SHAPE_GEOMETRY_MOON";
        case 79:
            return "SHAPE_GEOMETRY_SMILEY_FACE";
        case 80:
            return "SHAPE_GEOMETRY_IRREGULAR_SEAL1";
        case 81:
            return "SHAPE_GEOMETRY_IRREGULAR_SEAL2";
        case 82:
            return "SHAPE_GEOMETRY_FOLDED_CORNER";
        case 83:
            return "SHAPE_GEOMETRY_BEVEL";
        case 84:
            return "SHAPE_GEOMETRY_FRAME";
        case 85:
            return "SHAPE_GEOMETRY_HALF_FRAME";
        case 86:
            return "SHAPE_GEOMETRY_CORNER";
        case 87:
            return "SHAPE_GEOMETRY_DIAG_STRIPE";
        case 88:
            return "SHAPE_GEOMETRY_CHORD";
        case 89:
            return "SHAPE_GEOMETRY_ARC";
        case 90:
            return "SHAPE_GEOMETRY_LEFT_BRACKET";
        case 91:
            return "SHAPE_GEOMETRY_RIGHT_BRACKET";
        case 92:
            return "SHAPE_GEOMETRY_LEFT_BRACE";
        case 93:
            return "SHAPE_GEOMETRY_RIGHT_BRACE";
        case 94:
            return "SHAPE_GEOMETRY_BRACKET_PAIR";
        case 95:
            return "SHAPE_GEOMETRY_BRACE_PAIR";
        case 96:
            return "SHAPE_GEOMETRY_STRAIGHT_CONNECTOR1";
        case 97:
            return "SHAPE_GEOMETRY_BENT_CONNECTOR2";
        case 98:
            return "SHAPE_GEOMETRY_BENT_CONNECTOR3";
        case 99:
            return "SHAPE_GEOMETRY_BENT_CONNECTOR4";
        case 100:
            return "SHAPE_GEOMETRY_BENT_CONNECTOR5";
        case 101:
            return "SHAPE_GEOMETRY_CURVED_CONNECTOR2";
        case 102:
            return "SHAPE_GEOMETRY_CURVED_CONNECTOR3";
        case 103:
            return "SHAPE_GEOMETRY_CURVED_CONNECTOR4";
        case 104:
            return "SHAPE_GEOMETRY_CURVED_CONNECTOR5";
        case 105:
            return "SHAPE_GEOMETRY_CALLOUT1";
        case 106:
            return "SHAPE_GEOMETRY_CALLOUT2";
        case 107:
            return "SHAPE_GEOMETRY_CALLOUT3";
        case 108:
            return "SHAPE_GEOMETRY_ACCENT_CALLOUT1";
        case 109:
            return "SHAPE_GEOMETRY_ACCENT_CALLOUT2";
        case 110:
            return "SHAPE_GEOMETRY_ACCENT_CALLOUT3";
        case 111:
            return "SHAPE_GEOMETRY_BORDER_CALLOUT1";
        case 112:
            return "SHAPE_GEOMETRY_BORDER_CALLOUT2";
        case 113:
            return "SHAPE_GEOMETRY_BORDER_CALLOUT3";
        case 114:
            return "SHAPE_GEOMETRY_ACCENT_BORDER_CALLOUT1";
        case 115:
            return "SHAPE_GEOMETRY_ACCENT_BORDER_CALLOUT2";
        case 116:
            return "SHAPE_GEOMETRY_ACCENT_BORDER_CALLOUT3";
        case 117:
            return "SHAPE_GEOMETRY_WEDGE_RECT_CALLOUT";
        case 118:
            return "SHAPE_GEOMETRY_WEDGE_ROUND_RECT_CALLOUT";
        case 119:
            return "SHAPE_GEOMETRY_WEDGE_ELLIPSE_CALLOUT";
        case 120:
            return "SHAPE_GEOMETRY_CLOUD_CALLOUT";
        case 121:
            return "SHAPE_GEOMETRY_CLOUD";
        case 122:
            return "SHAPE_GEOMETRY_RIBBON";
        case 123:
            return "SHAPE_GEOMETRY_RIBBON2";
        case 124:
            return "SHAPE_GEOMETRY_ELLIPSE_RIBBON";
        case 125:
            return "SHAPE_GEOMETRY_ELLIPSE_RIBBON2";
        case 126:
            return "SHAPE_GEOMETRY_LEFT_RIGHT_RIBBON";
        case 127:
            return "SHAPE_GEOMETRY_VERTICAL_SCROLL";
        case 128:
            return "SHAPE_GEOMETRY_HORIZONTAL_SCROLL";
        case 129:
            return "SHAPE_GEOMETRY_WAVE";
        case 130:
            return "SHAPE_GEOMETRY_DOUBLE_WAVE";
        case 131:
            return "SHAPE_GEOMETRY_PLUS";
        case 132:
            return "SHAPE_GEOMETRY_FLOW_CHART_PROCESS";
        case 133:
            return "SHAPE_GEOMETRY_FLOW_CHART_DECISION";
        case 134:
            return "SHAPE_GEOMETRY_FLOW_CHART_INPUT_OUTPUT";
        case 135:
            return "SHAPE_GEOMETRY_FLOW_CHART_PREDEFINED_PROCESS";
        case 136:
            return "SHAPE_GEOMETRY_FLOW_CHART_INTERNAL_STORAGE";
        case 137:
            return "SHAPE_GEOMETRY_FLOW_CHART_DOCUMENT";
        case 138:
            return "SHAPE_GEOMETRY_FLOW_CHART_MULTIDOCUMENT";
        case 139:
            return "SHAPE_GEOMETRY_FLOW_CHART_TERMINATOR";
        case 140:
            return "SHAPE_GEOMETRY_FLOW_CHART_PREPARATION";
        case 141:
            return "SHAPE_GEOMETRY_FLOW_CHART_MANUAL_INPUT";
        case 142:
            return "SHAPE_GEOMETRY_FLOW_CHART_MANUAL_OPERATION";
        case 143:
            return "SHAPE_GEOMETRY_FLOW_CHART_CONNECTOR";
        case 144:
            return "SHAPE_GEOMETRY_FLOW_CHART_PUNCHED_CARD";
        case 145:
            return "SHAPE_GEOMETRY_FLOW_CHART_PUNCHED_TAPE";
        case 146:
            return "SHAPE_GEOMETRY_FLOW_CHART_SUMMING_JUNCTION";
        case 147:
            return "SHAPE_GEOMETRY_FLOW_CHART_OR";
        case 148:
            return "SHAPE_GEOMETRY_FLOW_CHART_COLLATE";
        case 149:
            return "SHAPE_GEOMETRY_FLOW_CHART_SORT";
        case 150:
            return "SHAPE_GEOMETRY_FLOW_CHART_EXTRACT";
        case 151:
            return "SHAPE_GEOMETRY_FLOW_CHART_MERGE";
        case 152:
            return "SHAPE_GEOMETRY_FLOW_CHART_OFFLINE_STORAGE";
        case 153:
            return "SHAPE_GEOMETRY_FLOW_CHART_ONLINE_STORAGE";
        case 154:
            return "SHAPE_GEOMETRY_FLOW_CHART_MAGNETIC_TAPE";
        case 155:
            return "SHAPE_GEOMETRY_FLOW_CHART_MAGNETIC_DISK";
        case 156:
            return "SHAPE_GEOMETRY_FLOW_CHART_MAGNETIC_DRUM";
        case 157:
            return "SHAPE_GEOMETRY_FLOW_CHART_DISPLAY";
        case 158:
            return "SHAPE_GEOMETRY_FLOW_CHART_DELAY";
        case 159:
            return "SHAPE_GEOMETRY_FLOW_CHART_ALTERNATE_PROCESS";
        case 160:
            return "SHAPE_GEOMETRY_FLOW_CHART_OFFPAGE_CONNECTOR";
        case 161:
            return "SHAPE_GEOMETRY_ACTION_BUTTON_BLANK";
        case 162:
            return "SHAPE_GEOMETRY_ACTION_BUTTON_HOME";
        case 163:
            return "SHAPE_GEOMETRY_ACTION_BUTTON_HELP";
        case 164:
            return "SHAPE_GEOMETRY_ACTION_BUTTON_INFORMATION";
        case 165:
            return "SHAPE_GEOMETRY_ACTION_BUTTON_FORWARD_NEXT";
        case 166:
            return "SHAPE_GEOMETRY_ACTION_BUTTON_BACK_PREVIOUS";
        case 167:
            return "SHAPE_GEOMETRY_ACTION_BUTTON_END";
        case 168:
            return "SHAPE_GEOMETRY_ACTION_BUTTON_BEGINNING";
        case 169:
            return "SHAPE_GEOMETRY_ACTION_BUTTON_RETURN";
        case 170:
            return "SHAPE_GEOMETRY_ACTION_BUTTON_DOCUMENT";
        case 171:
            return "SHAPE_GEOMETRY_ACTION_BUTTON_SOUND";
        case 172:
            return "SHAPE_GEOMETRY_ACTION_BUTTON_MOVIE";
        case 173:
            return "SHAPE_GEOMETRY_GEAR6";
        case 174:
            return "SHAPE_GEOMETRY_GEAR9";
        case 175:
            return "SHAPE_GEOMETRY_FUNNEL";
        case 176:
            return "SHAPE_GEOMETRY_MATH_PLUS";
        case 177:
            return "SHAPE_GEOMETRY_MATH_MINUS";
        case 178:
            return "SHAPE_GEOMETRY_MATH_MULTIPLY";
        case 179:
            return "SHAPE_GEOMETRY_MATH_DIVIDE";
        case 180:
            return "SHAPE_GEOMETRY_MATH_EQUAL";
        case 181:
            return "SHAPE_GEOMETRY_MATH_NOT_EQUAL";
        case 182:
            return "SHAPE_GEOMETRY_CORNER_TABS";
        case 183:
            return "SHAPE_GEOMETRY_SQUARE_TABS";
        case 184:
            return "SHAPE_GEOMETRY_PLAQUE_TABS";
        case 185:
            return "SHAPE_GEOMETRY_CHART_X";
        case 186:
            return "SHAPE_GEOMETRY_CHART_STAR";
        case 187:
            return "SHAPE_GEOMETRY_CHART_PLUS";
        case 188:
            return "SHAPE_GEOMETRY_CUSTOM";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var ce = (i => (i[i.ELEMENT_TYPE_UNSPECIFIED = 0] = "ELEMENT_TYPE_UNSPECIFIED", i[i.ELEMENT_TYPE_TEXT = 1] = "ELEMENT_TYPE_TEXT", i[i.ELEMENT_TYPE_TEXT_GROUP = 2] = "ELEMENT_TYPE_TEXT_GROUP", i[i.ELEMENT_TYPE_IMAGE = 3] = "ELEMENT_TYPE_IMAGE", i[i.ELEMENT_TYPE_CHART = 4] = "ELEMENT_TYPE_CHART", i[i.ELEMENT_TYPE_SHAPE = 5] = "ELEMENT_TYPE_SHAPE", i[i.ELEMENT_TYPE_CHART_REFERENCE = 6] = "ELEMENT_TYPE_CHART_REFERENCE", i[i.ELEMENT_TYPE_IMAGE_REFERENCE = 7] = "ELEMENT_TYPE_IMAGE_REFERENCE", i[i.ELEMENT_TYPE_VIDEO_REFERENCE = 8] = "ELEMENT_TYPE_VIDEO_REFERENCE", i[i.ELEMENT_TYPE_TABLE = 9] = "ELEMENT_TYPE_TABLE", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(ce || {});

function fe(i) {
    switch (i) {
        case 0:
        case "ELEMENT_TYPE_UNSPECIFIED":
            return 0;
        case 1:
        case "ELEMENT_TYPE_TEXT":
            return 1;
        case 2:
        case "ELEMENT_TYPE_TEXT_GROUP":
            return 2;
        case 3:
        case "ELEMENT_TYPE_IMAGE":
            return 3;
        case 4:
        case "ELEMENT_TYPE_CHART":
            return 4;
        case 5:
        case "ELEMENT_TYPE_SHAPE":
            return 5;
        case 6:
        case "ELEMENT_TYPE_CHART_REFERENCE":
            return 6;
        case 7:
        case "ELEMENT_TYPE_IMAGE_REFERENCE":
            return 7;
        case 8:
        case "ELEMENT_TYPE_VIDEO_REFERENCE":
            return 8;
        case 9:
        case "ELEMENT_TYPE_TABLE":
            return 9;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Te(i) {
    switch (i) {
        case 0:
            return "ELEMENT_TYPE_UNSPECIFIED";
        case 1:
            return "ELEMENT_TYPE_TEXT";
        case 2:
            return "ELEMENT_TYPE_TEXT_GROUP";
        case 3:
            return "ELEMENT_TYPE_IMAGE";
        case 4:
            return "ELEMENT_TYPE_CHART";
        case 5:
            return "ELEMENT_TYPE_SHAPE";
        case 6:
            return "ELEMENT_TYPE_CHART_REFERENCE";
        case 7:
            return "ELEMENT_TYPE_IMAGE_REFERENCE";
        case 8:
            return "ELEMENT_TYPE_VIDEO_REFERENCE";
        case 9:
            return "ELEMENT_TYPE_TABLE";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}
var Oe = (i => (i[i.EFFECT_TYPE_UNSPECIFIED = 0] = "EFFECT_TYPE_UNSPECIFIED", i[i.EFFECT_TYPE_OUTER_SHADOW = 1] = "EFFECT_TYPE_OUTER_SHADOW", i[i.UNRECOGNIZED = -1] = "UNRECOGNIZED", i))(Oe || {});

function Re(i) {
    switch (i) {
        case 0:
        case "EFFECT_TYPE_UNSPECIFIED":
            return 0;
        case 1:
        case "EFFECT_TYPE_OUTER_SHADOW":
            return 1;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function se(i) {
    switch (i) {
        case 0:
            return "EFFECT_TYPE_UNSPECIFIED";
        case 1:
            return "EFFECT_TYPE_OUTER_SHADOW";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function Ae(i) {
    switch (i) {
        case 0:
        case "CODE_BLOCK_KIND_UNSPECIFIED":
            return 0;
        case 1:
        case "CODE_BLOCK_KIND_SOURCE_ONLY":
            return 1;
        case 2:
        case "CODE_BLOCK_KIND_OUTPUT_ONLY":
            return 2;
        case 3:
        case "CODE_BLOCK_KIND_SOURCE_THEN_OUTPUT":
            return 3;
        case 4:
        case "CODE_BLOCK_KIND_SOURCE_OUTPUT_SPLIT":
            return 4;
        case 5:
        case "CODE_BLOCK_KIND_PREVIEW_ONLY":
            return 5;
        case -1:
        case "UNRECOGNIZED":
        default:
            return -1
    }
}

function Ne(i) {
    switch (i) {
        case 0:
            return "CODE_BLOCK_KIND_UNSPECIFIED";
        case 1:
            return "CODE_BLOCK_KIND_SOURCE_ONLY";
        case 2:
            return "CODE_BLOCK_KIND_OUTPUT_ONLY";
        case 3:
            return "CODE_BLOCK_KIND_SOURCE_THEN_OUTPUT";
        case 4:
            return "CODE_BLOCK_KIND_SOURCE_OUTPUT_SPLIT";
        case 5:
            return "CODE_BLOCK_KIND_PREVIEW_ONLY";
        case -1:
        default:
            return "UNRECOGNIZED"
    }
}

function Nt() {
    return {
        id: void 0,
        slides: [],
        theme: void 0,
        layouts: [],
        charts: [],
        images: [],
        contentReferences: []
    }
}
const Se = {
    encode(i, n = new O) {
        i.id !== void 0 && n.uint32(82).string(i.id);
        for (const t of i.slides) B.encode(t, n.uint32(10).fork()).join();
        i.theme !== void 0 && ki.encode(i.theme, n.uint32(18).fork()).join();
        for (const t of i.layouts) Ui.encode(t, n.uint32(26).fork()).join();
        for (const t of i.charts) ri.encode(t, n.uint32(74).fork()).join();
        for (const t of i.images) ii.encode(t, n.uint32(34).fork()).join();
        for (const t of i.contentReferences) ni.encode(t, n.uint32(42).fork()).join();
        return n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Nt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 10:
                    {
                        if (r !== 82) break;o.id = t.string();
                        continue
                    }
                case 1:
                    {
                        if (r !== 10) break;o.slides.push(B.decode(t, t.uint32()));
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.theme = ki.decode(t, t.uint32());
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.layouts.push(Ui.decode(t, t.uint32()));
                        continue
                    }
                case 9:
                    {
                        if (r !== 74) break;o.charts.push(ri.decode(t, t.uint32()));
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;o.images.push(ii.decode(t, t.uint32()));
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;o.contentReferences.push(ni.decode(t, t.uint32()));
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            id: d(i.id) ? l.String(i.id) : void 0,
            slides: l.Array.isArray(i == null ? void 0 : i.slides) ? i.slides.map(n => B.fromJSON(n)) : [],
            theme: d(i.theme) ? ki.fromJSON(i.theme) : void 0,
            layouts: l.Array.isArray(i == null ? void 0 : i.layouts) ? i.layouts.map(n => Ui.fromJSON(n)) : [],
            charts: l.Array.isArray(i == null ? void 0 : i.charts) ? i.charts.map(n => ri.fromJSON(n)) : [],
            images: l.Array.isArray(i == null ? void 0 : i.images) ? i.images.map(n => ii.fromJSON(n)) : [],
            contentReferences: l.Array.isArray(i == null ? void 0 : i.contentReferences) ? i.contentReferences.map(n => ni.fromJSON(n)) : []
        }
    },
    toJSON(i) {
        var t, e, o, r, u;
        const n = {};
        return i.id !== void 0 && (n.id = i.id), (t = i.slides) != null && t.length && (n.slides = i.slides.map(c => B.toJSON(c))), i.theme !== void 0 && (n.theme = ki.toJSON(i.theme)), (e = i.layouts) != null && e.length && (n.layouts = i.layouts.map(c => Ui.toJSON(c))), (o = i.charts) != null && o.length && (n.charts = i.charts.map(c => ri.toJSON(c))), (r = i.images) != null && r.length && (n.images = i.images.map(c => ii.toJSON(c))), (u = i.contentReferences) != null && u.length && (n.contentReferences = i.contentReferences.map(c => ni.toJSON(c))), n
    },
    create(i) {
        return Se.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u, c;
        const n = Nt();
        return n.id = (t = i.id) != null ? t : void 0, n.slides = ((e = i.slides) == null ? void 0 : e.map(s => B.fromPartial(s))) || [], n.theme = i.theme !== void 0 && i.theme !== null ? ki.fromPartial(i.theme) : void 0, n.layouts = ((o = i.layouts) == null ? void 0 : o.map(s => Ui.fromPartial(s))) || [], n.charts = ((r = i.charts) == null ? void 0 : r.map(s => ri.fromPartial(s))) || [], n.images = ((u = i.images) == null ? void 0 : u.map(s => ii.fromPartial(s))) || [], n.contentReferences = ((c = i.contentReferences) == null ? void 0 : c.map(s => ni.fromPartial(s))) || [], n
    }
};

function St() {
    return {
        colorScheme: void 0,
        backgroundFillStyleList: [],
        lineStyleList: [],
        effectStyleList: []
    }
}
const ki = {
    encode(i, n = new O) {
        i.colorScheme !== void 0 && Di.encode(i.colorScheme, n.uint32(10).fork()).join();
        for (const t of i.backgroundFillStyleList) A.encode(t, n.uint32(18).fork()).join();
        for (const t of i.lineStyleList) T.encode(t, n.uint32(26).fork()).join();
        for (const t of i.effectStyleList) mi.encode(t, n.uint32(34).fork()).join();
        return n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = St();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.colorScheme = Di.decode(t, t.uint32());
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.backgroundFillStyleList.push(A.decode(t, t.uint32()));
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.lineStyleList.push(T.decode(t, t.uint32()));
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;o.effectStyleList.push(mi.decode(t, t.uint32()));
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            colorScheme: d(i.colorScheme) ? Di.fromJSON(i.colorScheme) : void 0,
            backgroundFillStyleList: l.Array.isArray(i == null ? void 0 : i.backgroundFillStyleList) ? i.backgroundFillStyleList.map(n => A.fromJSON(n)) : [],
            lineStyleList: l.Array.isArray(i == null ? void 0 : i.lineStyleList) ? i.lineStyleList.map(n => T.fromJSON(n)) : [],
            effectStyleList: l.Array.isArray(i == null ? void 0 : i.effectStyleList) ? i.effectStyleList.map(n => mi.fromJSON(n)) : []
        }
    },
    toJSON(i) {
        var t, e, o;
        const n = {};
        return i.colorScheme !== void 0 && (n.colorScheme = Di.toJSON(i.colorScheme)), (t = i.backgroundFillStyleList) != null && t.length && (n.backgroundFillStyleList = i.backgroundFillStyleList.map(r => A.toJSON(r))), (e = i.lineStyleList) != null && e.length && (n.lineStyleList = i.lineStyleList.map(r => T.toJSON(r))), (o = i.effectStyleList) != null && o.length && (n.effectStyleList = i.effectStyleList.map(r => mi.toJSON(r))), n
    },
    create(i) {
        return ki.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o;
        const n = St();
        return n.colorScheme = i.colorScheme !== void 0 && i.colorScheme !== null ? Di.fromPartial(i.colorScheme) : void 0, n.backgroundFillStyleList = ((t = i.backgroundFillStyleList) == null ? void 0 : t.map(r => A.fromPartial(r))) || [], n.lineStyleList = ((e = i.lineStyleList) == null ? void 0 : e.map(r => T.fromPartial(r))) || [], n.effectStyleList = ((o = i.effectStyleList) == null ? void 0 : o.map(r => mi.fromPartial(r))) || [], n
    }
};

function vt() {
    return {
        name: "",
        colors: []
    }
}
const Di = {
    encode(i, n = new O) {
        i.name !== "" && n.uint32(10).string(i.name);
        for (const t of i.colors) Gi.encode(t, n.uint32(18).fork()).join();
        return n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = vt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.name = t.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.colors.push(Gi.decode(t, t.uint32()));
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            name: d(i.name) ? l.String(i.name) : "",
            colors: l.Array.isArray(i == null ? void 0 : i.colors) ? i.colors.map(n => Gi.fromJSON(n)) : []
        }
    },
    toJSON(i) {
        var t;
        const n = {};
        return i.name !== "" && (n.name = i.name), (t = i.colors) != null && t.length && (n.colors = i.colors.map(e => Gi.toJSON(e))), n
    },
    create(i) {
        return Di.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e;
        const n = vt();
        return n.name = (t = i.name) != null ? t : "", n.colors = ((e = i.colors) == null ? void 0 : e.map(o => Gi.fromPartial(o))) || [], n
    }
};

function Pt() {
    return {
        name: "",
        color: void 0
    }
}
const Gi = {
    encode(i, n = new O) {
        return i.name !== "" && n.uint32(10).string(i.name), i.color !== void 0 && S.encode(i.color, n.uint32(18).fork()).join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Pt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.name = t.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.color = S.decode(t, t.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            name: d(i.name) ? l.String(i.name) : "",
            color: d(i.color) ? S.fromJSON(i.color) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.name !== "" && (n.name = i.name), i.color !== void 0 && (n.color = S.toJSON(i.color)), n
    },
    create(i) {
        return Gi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t;
        const n = Pt();
        return n.name = (t = i.name) != null ? t : "", n.color = i.color !== void 0 && i.color !== null ? S.fromPartial(i.color) : void 0, n
    }
};

function It() {
    return {
        id: "",
        innerXml: void 0,
        outerXml: void 0,
        name: "",
        type: "",
        background: void 0,
        elements: [],
        bodyLevelStyles: [],
        titleLevelStyles: [],
        otherLevelStyles: [],
        parentLayoutId: "",
        colorMap: void 0
    }
}
const Ui = {
    encode(i, n = new O) {
        i.id !== "" && n.uint32(10).string(i.id), i.innerXml !== void 0 && n.uint32(50).string(i.innerXml), i.outerXml !== void 0 && n.uint32(58).string(i.outerXml), i.name !== "" && n.uint32(66).string(i.name), i.type !== "" && n.uint32(74).string(i.type), i.background !== void 0 && x.encode(i.background, n.uint32(82).fork()).join();
        for (const t of i.elements) k.encode(t, n.uint32(90).fork()).join();
        for (const t of i.bodyLevelStyles) C.encode(t, n.uint32(98).fork()).join();
        for (const t of i.titleLevelStyles) C.encode(t, n.uint32(106).fork()).join();
        for (const t of i.otherLevelStyles) C.encode(t, n.uint32(114).fork()).join();
        return i.parentLayoutId !== "" && n.uint32(122).string(i.parentLayoutId), i.colorMap !== void 0 && Qi.encode(i.colorMap, n.uint32(130).fork()).join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = It();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.id = t.string();
                        continue
                    }
                case 6:
                    {
                        if (r !== 50) break;o.innerXml = t.string();
                        continue
                    }
                case 7:
                    {
                        if (r !== 58) break;o.outerXml = t.string();
                        continue
                    }
                case 8:
                    {
                        if (r !== 66) break;o.name = t.string();
                        continue
                    }
                case 9:
                    {
                        if (r !== 74) break;o.type = t.string();
                        continue
                    }
                case 10:
                    {
                        if (r !== 82) break;o.background = x.decode(t, t.uint32());
                        continue
                    }
                case 11:
                    {
                        if (r !== 90) break;o.elements.push(k.decode(t, t.uint32()));
                        continue
                    }
                case 12:
                    {
                        if (r !== 98) break;o.bodyLevelStyles.push(C.decode(t, t.uint32()));
                        continue
                    }
                case 13:
                    {
                        if (r !== 106) break;o.titleLevelStyles.push(C.decode(t, t.uint32()));
                        continue
                    }
                case 14:
                    {
                        if (r !== 114) break;o.otherLevelStyles.push(C.decode(t, t.uint32()));
                        continue
                    }
                case 15:
                    {
                        if (r !== 122) break;o.parentLayoutId = t.string();
                        continue
                    }
                case 16:
                    {
                        if (r !== 130) break;o.colorMap = Qi.decode(t, t.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            id: d(i.id) ? l.String(i.id) : "",
            innerXml: d(i.innerXml) ? l.String(i.innerXml) : void 0,
            outerXml: d(i.outerXml) ? l.String(i.outerXml) : void 0,
            name: d(i.name) ? l.String(i.name) : "",
            type: d(i.type) ? l.String(i.type) : "",
            background: d(i.background) ? x.fromJSON(i.background) : void 0,
            elements: l.Array.isArray(i == null ? void 0 : i.elements) ? i.elements.map(n => k.fromJSON(n)) : [],
            bodyLevelStyles: l.Array.isArray(i == null ? void 0 : i.bodyLevelStyles) ? i.bodyLevelStyles.map(n => C.fromJSON(n)) : [],
            titleLevelStyles: l.Array.isArray(i == null ? void 0 : i.titleLevelStyles) ? i.titleLevelStyles.map(n => C.fromJSON(n)) : [],
            otherLevelStyles: l.Array.isArray(i == null ? void 0 : i.otherLevelStyles) ? i.otherLevelStyles.map(n => C.fromJSON(n)) : [],
            parentLayoutId: d(i.parentLayoutId) ? l.String(i.parentLayoutId) : "",
            colorMap: d(i.colorMap) ? Qi.fromJSON(i.colorMap) : void 0
        }
    },
    toJSON(i) {
        var t, e, o, r;
        const n = {};
        return i.id !== "" && (n.id = i.id), i.innerXml !== void 0 && (n.innerXml = i.innerXml), i.outerXml !== void 0 && (n.outerXml = i.outerXml), i.name !== "" && (n.name = i.name), i.type !== "" && (n.type = i.type), i.background !== void 0 && (n.background = x.toJSON(i.background)), (t = i.elements) != null && t.length && (n.elements = i.elements.map(u => k.toJSON(u))), (e = i.bodyLevelStyles) != null && e.length && (n.bodyLevelStyles = i.bodyLevelStyles.map(u => C.toJSON(u))), (o = i.titleLevelStyles) != null && o.length && (n.titleLevelStyles = i.titleLevelStyles.map(u => C.toJSON(u))), (r = i.otherLevelStyles) != null && r.length && (n.otherLevelStyles = i.otherLevelStyles.map(u => C.toJSON(u))), i.parentLayoutId !== "" && (n.parentLayoutId = i.parentLayoutId), i.colorMap !== void 0 && (n.colorMap = Qi.toJSON(i.colorMap)), n
    },
    create(i) {
        return Ui.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u, c, s, v, P, L;
        const n = It();
        return n.id = (t = i.id) != null ? t : "", n.innerXml = (e = i.innerXml) != null ? e : void 0, n.outerXml = (o = i.outerXml) != null ? o : void 0, n.name = (r = i.name) != null ? r : "", n.type = (u = i.type) != null ? u : "", n.background = i.background !== void 0 && i.background !== null ? x.fromPartial(i.background) : void 0, n.elements = ((c = i.elements) == null ? void 0 : c.map(I => k.fromPartial(I))) || [], n.bodyLevelStyles = ((s = i.bodyLevelStyles) == null ? void 0 : s.map(I => C.fromPartial(I))) || [], n.titleLevelStyles = ((v = i.titleLevelStyles) == null ? void 0 : v.map(I => C.fromPartial(I))) || [], n.otherLevelStyles = ((P = i.otherLevelStyles) == null ? void 0 : P.map(I => C.fromPartial(I))) || [], n.parentLayoutId = (L = i.parentLayoutId) != null ? L : "", n.colorMap = i.colorMap !== void 0 && i.colorMap !== null ? Qi.fromPartial(i.colorMap) : void 0, n
    }
};

function Lt() {
    return {
        index: 0,
        useLayoutId: "",
        elements: [],
        widthEmu: 0,
        heightEmu: 0,
        innerXml: void 0,
        outerXml: void 0,
        background: void 0,
        id: "",
        notesSlide: void 0
    }
}
const B = {
    encode(i, n = new O) {
        i.index !== 0 && n.uint32(8).int32(i.index), i.useLayoutId !== "" && n.uint32(18).string(i.useLayoutId);
        for (const t of i.elements) k.encode(t, n.uint32(26).fork()).join();
        return i.widthEmu !== 0 && n.uint32(40).int64(i.widthEmu), i.heightEmu !== 0 && n.uint32(48).int64(i.heightEmu), i.innerXml !== void 0 && n.uint32(58).string(i.innerXml), i.outerXml !== void 0 && n.uint32(66).string(i.outerXml), i.background !== void 0 && x.encode(i.background, n.uint32(82).fork()).join(), i.id !== "" && n.uint32(90).string(i.id), i.notesSlide !== void 0 && B.encode(i.notesSlide, n.uint32(98).fork()).join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Lt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.index = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.useLayoutId = t.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.elements.push(k.decode(t, t.uint32()));
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;o.widthEmu = Q(t.int64());
                        continue
                    }
                case 6:
                    {
                        if (r !== 48) break;o.heightEmu = Q(t.int64());
                        continue
                    }
                case 7:
                    {
                        if (r !== 58) break;o.innerXml = t.string();
                        continue
                    }
                case 8:
                    {
                        if (r !== 66) break;o.outerXml = t.string();
                        continue
                    }
                case 10:
                    {
                        if (r !== 82) break;o.background = x.decode(t, t.uint32());
                        continue
                    }
                case 11:
                    {
                        if (r !== 90) break;o.id = t.string();
                        continue
                    }
                case 12:
                    {
                        if (r !== 98) break;o.notesSlide = B.decode(t, t.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            index: d(i.index) ? l.Number(i.index) : 0,
            useLayoutId: d(i.useLayoutId) ? l.String(i.useLayoutId) : "",
            elements: l.Array.isArray(i == null ? void 0 : i.elements) ? i.elements.map(n => k.fromJSON(n)) : [],
            widthEmu: d(i.widthEmu) ? l.Number(i.widthEmu) : 0,
            heightEmu: d(i.heightEmu) ? l.Number(i.heightEmu) : 0,
            innerXml: d(i.innerXml) ? l.String(i.innerXml) : void 0,
            outerXml: d(i.outerXml) ? l.String(i.outerXml) : void 0,
            background: d(i.background) ? x.fromJSON(i.background) : void 0,
            id: d(i.id) ? l.String(i.id) : "",
            notesSlide: d(i.notesSlide) ? B.fromJSON(i.notesSlide) : void 0
        }
    },
    toJSON(i) {
        var t;
        const n = {};
        return i.index !== 0 && (n.index = Math.round(i.index)), i.useLayoutId !== "" && (n.useLayoutId = i.useLayoutId), (t = i.elements) != null && t.length && (n.elements = i.elements.map(e => k.toJSON(e))), i.widthEmu !== 0 && (n.widthEmu = Math.round(i.widthEmu)), i.heightEmu !== 0 && (n.heightEmu = Math.round(i.heightEmu)), i.innerXml !== void 0 && (n.innerXml = i.innerXml), i.outerXml !== void 0 && (n.outerXml = i.outerXml), i.background !== void 0 && (n.background = x.toJSON(i.background)), i.id !== "" && (n.id = i.id), i.notesSlide !== void 0 && (n.notesSlide = B.toJSON(i.notesSlide)), n
    },
    create(i) {
        return B.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u, c, s, v;
        const n = Lt();
        return n.index = (t = i.index) != null ? t : 0, n.useLayoutId = (e = i.useLayoutId) != null ? e : "", n.elements = ((o = i.elements) == null ? void 0 : o.map(P => k.fromPartial(P))) || [], n.widthEmu = (r = i.widthEmu) != null ? r : 0, n.heightEmu = (u = i.heightEmu) != null ? u : 0, n.innerXml = (c = i.innerXml) != null ? c : void 0, n.outerXml = (s = i.outerXml) != null ? s : void 0, n.background = i.background !== void 0 && i.background !== null ? x.fromPartial(i.background) : void 0, n.id = (v = i.id) != null ? v : "", n.notesSlide = i.notesSlide !== void 0 && i.notesSlide !== null ? B.fromPartial(i.notesSlide) : void 0, n
    }
};

function Ct() {
    return {
        bbox: void 0,
        zIndex: void 0,
        innerXml: void 0,
        outerXml: void 0,
        shape: void 0,
        image: void 0,
        chartReference: void 0,
        video: void 0,
        table: void 0,
        imageReference: void 0,
        codeBlock: void 0,
        paragraphs: [],
        name: void 0,
        type: 0,
        placeholderIndex: void 0,
        placeholderType: void 0,
        textStyle: void 0,
        effects: [],
        children: [],
        levelsStyles: [],
        fill: void 0,
        lineReference: void 0,
        fillReference: void 0,
        effectReference: void 0,
        fontReference: void 0,
        hyperlink: void 0,
        id: "",
        connector: void 0,
        citations: []
    }
}
const k = {
    encode(i, n = new O) {
        i.bbox !== void 0 && F.encode(i.bbox, n.uint32(10).fork()).join(), i.zIndex !== void 0 && n.uint32(16).int32(i.zIndex), i.innerXml !== void 0 && n.uint32(58).string(i.innerXml), i.outerXml !== void 0 && n.uint32(66).string(i.outerXml), i.shape !== void 0 && Ki.encode(i.shape, n.uint32(34).fork()).join(), i.image !== void 0 && Xi.encode(i.image, n.uint32(42).fork()).join(), i.chartReference !== void 0 && Bi.encode(i.chartReference, n.uint32(146).fork()).join(), i.video !== void 0 && zi.encode(i.video, n.uint32(162).fork()).join(), i.table !== void 0 && xi.encode(i.table, n.uint32(170).fork()).join(), i.imageReference !== void 0 && y.encode(i.imageReference, n.uint32(26).fork()).join(), i.codeBlock !== void 0 && en.encode(i.codeBlock, n.uint32(74).fork()).join();
        for (const t of i.paragraphs) h.encode(t, n.uint32(50).fork()).join();
        i.name !== void 0 && n.uint32(82).string(i.name), i.type !== 0 && n.uint32(88).int32(i.type), i.placeholderIndex !== void 0 && n.uint32(96).int32(i.placeholderIndex), i.placeholderType !== void 0 && n.uint32(106).string(i.placeholderType), i.textStyle !== void 0 && N.encode(i.textStyle, n.uint32(114).fork()).join();
        for (const t of i.effects) m.encode(t, n.uint32(122).fork()).join();
        for (const t of i.children) k.encode(t, n.uint32(138).fork()).join();
        for (const t of i.levelsStyles) C.encode(t, n.uint32(130).fork()).join();
        i.fill !== void 0 && A.encode(i.fill, n.uint32(154).fork()).join(), i.lineReference !== void 0 && M.encode(i.lineReference, n.uint32(178).fork()).join(), i.fillReference !== void 0 && M.encode(i.fillReference, n.uint32(186).fork()).join(), i.effectReference !== void 0 && M.encode(i.effectReference, n.uint32(194).fork()).join(), i.fontReference !== void 0 && M.encode(i.fontReference, n.uint32(202).fork()).join(), i.hyperlink !== void 0 && W.encode(i.hyperlink, n.uint32(210).fork()).join(), i.id !== "" && n.uint32(218).string(i.id), i.connector !== void 0 && Fi.encode(i.connector, n.uint32(226).fork()).join();
        for (const t of i.citations) n.uint32(234).string(t);
        return n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Ct();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.bbox = F.decode(t, t.uint32());
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.zIndex = t.int32();
                        continue
                    }
                case 7:
                    {
                        if (r !== 58) break;o.innerXml = t.string();
                        continue
                    }
                case 8:
                    {
                        if (r !== 66) break;o.outerXml = t.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;o.shape = Ki.decode(t, t.uint32());
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;o.image = Xi.decode(t, t.uint32());
                        continue
                    }
                case 18:
                    {
                        if (r !== 146) break;o.chartReference = Bi.decode(t, t.uint32());
                        continue
                    }
                case 20:
                    {
                        if (r !== 162) break;o.video = zi.decode(t, t.uint32());
                        continue
                    }
                case 21:
                    {
                        if (r !== 170) break;o.table = xi.decode(t, t.uint32());
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.imageReference = y.decode(t, t.uint32());
                        continue
                    }
                case 9:
                    {
                        if (r !== 74) break;o.codeBlock = en.decode(t, t.uint32());
                        continue
                    }
                case 6:
                    {
                        if (r !== 50) break;o.paragraphs.push(h.decode(t, t.uint32()));
                        continue
                    }
                case 10:
                    {
                        if (r !== 82) break;o.name = t.string();
                        continue
                    }
                case 11:
                    {
                        if (r !== 88) break;o.type = t.int32();
                        continue
                    }
                case 12:
                    {
                        if (r !== 96) break;o.placeholderIndex = t.int32();
                        continue
                    }
                case 13:
                    {
                        if (r !== 106) break;o.placeholderType = t.string();
                        continue
                    }
                case 14:
                    {
                        if (r !== 114) break;o.textStyle = N.decode(t, t.uint32());
                        continue
                    }
                case 15:
                    {
                        if (r !== 122) break;o.effects.push(m.decode(t, t.uint32()));
                        continue
                    }
                case 17:
                    {
                        if (r !== 138) break;o.children.push(k.decode(t, t.uint32()));
                        continue
                    }
                case 16:
                    {
                        if (r !== 130) break;o.levelsStyles.push(C.decode(t, t.uint32()));
                        continue
                    }
                case 19:
                    {
                        if (r !== 154) break;o.fill = A.decode(t, t.uint32());
                        continue
                    }
                case 22:
                    {
                        if (r !== 178) break;o.lineReference = M.decode(t, t.uint32());
                        continue
                    }
                case 23:
                    {
                        if (r !== 186) break;o.fillReference = M.decode(t, t.uint32());
                        continue
                    }
                case 24:
                    {
                        if (r !== 194) break;o.effectReference = M.decode(t, t.uint32());
                        continue
                    }
                case 25:
                    {
                        if (r !== 202) break;o.fontReference = M.decode(t, t.uint32());
                        continue
                    }
                case 26:
                    {
                        if (r !== 210) break;o.hyperlink = W.decode(t, t.uint32());
                        continue
                    }
                case 27:
                    {
                        if (r !== 218) break;o.id = t.string();
                        continue
                    }
                case 28:
                    {
                        if (r !== 226) break;o.connector = Fi.decode(t, t.uint32());
                        continue
                    }
                case 29:
                    {
                        if (r !== 234) break;o.citations.push(t.string());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            bbox: d(i.bbox) ? F.fromJSON(i.bbox) : void 0,
            zIndex: d(i.zIndex) ? l.Number(i.zIndex) : void 0,
            innerXml: d(i.innerXml) ? l.String(i.innerXml) : void 0,
            outerXml: d(i.outerXml) ? l.String(i.outerXml) : void 0,
            shape: d(i.shape) ? Ki.fromJSON(i.shape) : void 0,
            image: d(i.image) ? Xi.fromJSON(i.image) : void 0,
            chartReference: d(i.chartReference) ? Bi.fromJSON(i.chartReference) : void 0,
            video: d(i.video) ? zi.fromJSON(i.video) : void 0,
            table: d(i.table) ? xi.fromJSON(i.table) : void 0,
            imageReference: d(i.imageReference) ? y.fromJSON(i.imageReference) : void 0,
            codeBlock: d(i.codeBlock) ? en.fromJSON(i.codeBlock) : void 0,
            paragraphs: l.Array.isArray(i == null ? void 0 : i.paragraphs) ? i.paragraphs.map(n => h.fromJSON(n)) : [],
            name: d(i.name) ? l.String(i.name) : void 0,
            type: d(i.type) ? fe(i.type) : 0,
            placeholderIndex: d(i.placeholderIndex) ? l.Number(i.placeholderIndex) : void 0,
            placeholderType: d(i.placeholderType) ? l.String(i.placeholderType) : void 0,
            textStyle: d(i.textStyle) ? N.fromJSON(i.textStyle) : void 0,
            effects: l.Array.isArray(i == null ? void 0 : i.effects) ? i.effects.map(n => m.fromJSON(n)) : [],
            children: l.Array.isArray(i == null ? void 0 : i.children) ? i.children.map(n => k.fromJSON(n)) : [],
            levelsStyles: l.Array.isArray(i == null ? void 0 : i.levelsStyles) ? i.levelsStyles.map(n => C.fromJSON(n)) : [],
            fill: d(i.fill) ? A.fromJSON(i.fill) : void 0,
            lineReference: d(i.lineReference) ? M.fromJSON(i.lineReference) : void 0,
            fillReference: d(i.fillReference) ? M.fromJSON(i.fillReference) : void 0,
            effectReference: d(i.effectReference) ? M.fromJSON(i.effectReference) : void 0,
            fontReference: d(i.fontReference) ? M.fromJSON(i.fontReference) : void 0,
            hyperlink: d(i.hyperlink) ? W.fromJSON(i.hyperlink) : void 0,
            id: d(i.id) ? l.String(i.id) : "",
            connector: d(i.connector) ? Fi.fromJSON(i.connector) : void 0,
            citations: l.Array.isArray(i == null ? void 0 : i.citations) ? i.citations.map(n => l.String(n)) : []
        }
    },
    toJSON(i) {
        var t, e, o, r, u;
        const n = {};
        return i.bbox !== void 0 && (n.bbox = F.toJSON(i.bbox)), i.zIndex !== void 0 && (n.zIndex = Math.round(i.zIndex)), i.innerXml !== void 0 && (n.innerXml = i.innerXml), i.outerXml !== void 0 && (n.outerXml = i.outerXml), i.shape !== void 0 && (n.shape = Ki.toJSON(i.shape)), i.image !== void 0 && (n.image = Xi.toJSON(i.image)), i.chartReference !== void 0 && (n.chartReference = Bi.toJSON(i.chartReference)), i.video !== void 0 && (n.video = zi.toJSON(i.video)), i.table !== void 0 && (n.table = xi.toJSON(i.table)), i.imageReference !== void 0 && (n.imageReference = y.toJSON(i.imageReference)), i.codeBlock !== void 0 && (n.codeBlock = en.toJSON(i.codeBlock)), (t = i.paragraphs) != null && t.length && (n.paragraphs = i.paragraphs.map(c => h.toJSON(c))), i.name !== void 0 && (n.name = i.name), i.type !== 0 && (n.type = Te(i.type)), i.placeholderIndex !== void 0 && (n.placeholderIndex = Math.round(i.placeholderIndex)), i.placeholderType !== void 0 && (n.placeholderType = i.placeholderType), i.textStyle !== void 0 && (n.textStyle = N.toJSON(i.textStyle)), (e = i.effects) != null && e.length && (n.effects = i.effects.map(c => m.toJSON(c))), (o = i.children) != null && o.length && (n.children = i.children.map(c => k.toJSON(c))), (r = i.levelsStyles) != null && r.length && (n.levelsStyles = i.levelsStyles.map(c => C.toJSON(c))), i.fill !== void 0 && (n.fill = A.toJSON(i.fill)), i.lineReference !== void 0 && (n.lineReference = M.toJSON(i.lineReference)), i.fillReference !== void 0 && (n.fillReference = M.toJSON(i.fillReference)), i.effectReference !== void 0 && (n.effectReference = M.toJSON(i.effectReference)), i.fontReference !== void 0 && (n.fontReference = M.toJSON(i.fontReference)), i.hyperlink !== void 0 && (n.hyperlink = W.toJSON(i.hyperlink)), i.id !== "" && (n.id = i.id), i.connector !== void 0 && (n.connector = Fi.toJSON(i.connector)), (u = i.citations) != null && u.length && (n.citations = i.citations), n
    },
    create(i) {
        return k.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u, c, s, v, P, L, I, Y, G;
        const n = Ct();
        return n.bbox = i.bbox !== void 0 && i.bbox !== null ? F.fromPartial(i.bbox) : void 0, n.zIndex = (t = i.zIndex) != null ? t : void 0, n.innerXml = (e = i.innerXml) != null ? e : void 0, n.outerXml = (o = i.outerXml) != null ? o : void 0, n.shape = i.shape !== void 0 && i.shape !== null ? Ki.fromPartial(i.shape) : void 0, n.image = i.image !== void 0 && i.image !== null ? Xi.fromPartial(i.image) : void 0, n.chartReference = i.chartReference !== void 0 && i.chartReference !== null ? Bi.fromPartial(i.chartReference) : void 0, n.video = i.video !== void 0 && i.video !== null ? zi.fromPartial(i.video) : void 0, n.table = i.table !== void 0 && i.table !== null ? xi.fromPartial(i.table) : void 0, n.imageReference = i.imageReference !== void 0 && i.imageReference !== null ? y.fromPartial(i.imageReference) : void 0, n.codeBlock = i.codeBlock !== void 0 && i.codeBlock !== null ? en.fromPartial(i.codeBlock) : void 0, n.paragraphs = ((r = i.paragraphs) == null ? void 0 : r.map(H => h.fromPartial(H))) || [], n.name = (u = i.name) != null ? u : void 0, n.type = (c = i.type) != null ? c : 0, n.placeholderIndex = (s = i.placeholderIndex) != null ? s : void 0, n.placeholderType = (v = i.placeholderType) != null ? v : void 0, n.textStyle = i.textStyle !== void 0 && i.textStyle !== null ? N.fromPartial(i.textStyle) : void 0, n.effects = ((P = i.effects) == null ? void 0 : P.map(H => m.fromPartial(H))) || [], n.children = ((L = i.children) == null ? void 0 : L.map(H => k.fromPartial(H))) || [], n.levelsStyles = ((I = i.levelsStyles) == null ? void 0 : I.map(H => C.fromPartial(H))) || [], n.fill = i.fill !== void 0 && i.fill !== null ? A.fromPartial(i.fill) : void 0, n.lineReference = i.lineReference !== void 0 && i.lineReference !== null ? M.fromPartial(i.lineReference) : void 0, n.fillReference = i.fillReference !== void 0 && i.fillReference !== null ? M.fromPartial(i.fillReference) : void 0, n.effectReference = i.effectReference !== void 0 && i.effectReference !== null ? M.fromPartial(i.effectReference) : void 0, n.fontReference = i.fontReference !== void 0 && i.fontReference !== null ? M.fromPartial(i.fontReference) : void 0, n.hyperlink = i.hyperlink !== void 0 && i.hyperlink !== null ? W.fromPartial(i.hyperlink) : void 0, n.id = (Y = i.id) != null ? Y : "", n.connector = i.connector !== void 0 && i.connector !== null ? Fi.fromPartial(i.connector) : void 0, n.citations = ((G = i.citations) == null ? void 0 : G.map(H => H)) || [], n
    }
};

function Mt() {
    return {
        index: "",
        color: void 0
    }
}
const M = {
    encode(i, n = new O) {
        return i.index !== "" && n.uint32(10).string(i.index), i.color !== void 0 && S.encode(i.color, n.uint32(18).fork()).join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Mt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.index = t.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.color = S.decode(t, t.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            index: d(i.index) ? l.String(i.index) : "",
            color: d(i.color) ? S.fromJSON(i.color) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.index !== "" && (n.index = i.index), i.color !== void 0 && (n.color = S.toJSON(i.color)), n
    },
    create(i) {
        return M.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t;
        const n = Mt();
        return n.index = (t = i.index) != null ? t : "", n.color = i.color !== void 0 && i.color !== null ? S.fromPartial(i.color) : void 0, n
    }
};

function ht() {
    return {
        id: ""
    }
}
const Bi = {
    encode(i, n = new O) {
        return i.id !== "" && n.uint32(10).string(i.id), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = ht();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.id = t.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            id: d(i.id) ? l.String(i.id) : ""
        }
    },
    toJSON(i) {
        const n = {};
        return i.id !== "" && (n.id = i.id), n
    },
    create(i) {
        return Bi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t;
        const n = ht();
        return n.id = (t = i.id) != null ? t : "", n
    }
};

function Yt() {
    return {
        fromElementId: "",
        fromIdx: 0,
        toElementId: "",
        toIdx: 0
    }
}
const Fi = {
    encode(i, n = new O) {
        return i.fromElementId !== "" && n.uint32(10).string(i.fromElementId), i.fromIdx !== 0 && n.uint32(16).int32(i.fromIdx), i.toElementId !== "" && n.uint32(26).string(i.toElementId), i.toIdx !== 0 && n.uint32(32).int32(i.toIdx), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Yt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.fromElementId = t.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.fromIdx = t.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.toElementId = t.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;o.toIdx = t.int32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            fromElementId: d(i.fromElementId) ? l.String(i.fromElementId) : "",
            fromIdx: d(i.fromIdx) ? l.Number(i.fromIdx) : 0,
            toElementId: d(i.toElementId) ? l.String(i.toElementId) : "",
            toIdx: d(i.toIdx) ? l.Number(i.toIdx) : 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.fromElementId !== "" && (n.fromElementId = i.fromElementId), i.fromIdx !== 0 && (n.fromIdx = Math.round(i.fromIdx)), i.toElementId !== "" && (n.toElementId = i.toElementId), i.toIdx !== 0 && (n.toIdx = Math.round(i.toIdx)), n
    },
    create(i) {
        return Fi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r;
        const n = Yt();
        return n.fromElementId = (t = i.fromElementId) != null ? t : "", n.fromIdx = (e = i.fromIdx) != null ? e : 0, n.toElementId = (o = i.toElementId) != null ? o : "", n.toIdx = (r = i.toIdx) != null ? r : 0, n
    }
};

function Ht() {
    return {
        rows: [],
        columnWidths: []
    }
}
const xi = {
    encode(i, n = new O) {
        for (const t of i.rows) wi.encode(t, n.uint32(10).fork()).join();
        n.uint32(18).fork();
        for (const t of i.columnWidths) n.int32(t);
        return n.join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Ht();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.rows.push(wi.decode(t, t.uint32()));
                        continue
                    }
                case 2:
                    {
                        if (r === 16) {
                            o.columnWidths.push(t.int32());
                            continue
                        }
                        if (r === 18) {
                            const u = t.uint32() + t.pos;
                            for (; t.pos < u;) o.columnWidths.push(t.int32());
                            continue
                        }
                        break
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            rows: l.Array.isArray(i == null ? void 0 : i.rows) ? i.rows.map(n => wi.fromJSON(n)) : [],
            columnWidths: l.Array.isArray(i == null ? void 0 : i.columnWidths) ? i.columnWidths.map(n => l.Number(n)) : []
        }
    },
    toJSON(i) {
        var t, e;
        const n = {};
        return (t = i.rows) != null && t.length && (n.rows = i.rows.map(o => wi.toJSON(o))), (e = i.columnWidths) != null && e.length && (n.columnWidths = i.columnWidths.map(o => Math.round(o))), n
    },
    create(i) {
        return xi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e;
        const n = Ht();
        return n.rows = ((t = i.rows) == null ? void 0 : t.map(o => wi.fromPartial(o))) || [], n.columnWidths = ((e = i.columnWidths) == null ? void 0 : e.map(o => o)) || [], n
    }
};

function pt() {
    return {
        id: void 0,
        text: "",
        textStyle: void 0,
        paragraphs: [],
        levelsStyles: [],
        fill: void 0,
        lines: void 0
    }
}
const yi = {
    encode(i, n = new O) {
        i.id !== void 0 && n.uint32(58).string(i.id), i.text !== "" && n.uint32(10).string(i.text), i.textStyle !== void 0 && N.encode(i.textStyle, n.uint32(18).fork()).join();
        for (const t of i.paragraphs) h.encode(t, n.uint32(26).fork()).join();
        for (const t of i.levelsStyles) C.encode(t, n.uint32(34).fork()).join();
        return i.fill !== void 0 && A.encode(i.fill, n.uint32(42).fork()).join(), i.lines !== void 0 && Ji.encode(i.lines, n.uint32(50).fork()).join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = pt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 7:
                    {
                        if (r !== 58) break;o.id = t.string();
                        continue
                    }
                case 1:
                    {
                        if (r !== 10) break;o.text = t.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.textStyle = N.decode(t, t.uint32());
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.paragraphs.push(h.decode(t, t.uint32()));
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;o.levelsStyles.push(C.decode(t, t.uint32()));
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;o.fill = A.decode(t, t.uint32());
                        continue
                    }
                case 6:
                    {
                        if (r !== 50) break;o.lines = Ji.decode(t, t.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            id: d(i.id) ? l.String(i.id) : void 0,
            text: d(i.text) ? l.String(i.text) : "",
            textStyle: d(i.textStyle) ? N.fromJSON(i.textStyle) : void 0,
            paragraphs: l.Array.isArray(i == null ? void 0 : i.paragraphs) ? i.paragraphs.map(n => h.fromJSON(n)) : [],
            levelsStyles: l.Array.isArray(i == null ? void 0 : i.levelsStyles) ? i.levelsStyles.map(n => C.fromJSON(n)) : [],
            fill: d(i.fill) ? A.fromJSON(i.fill) : void 0,
            lines: d(i.lines) ? Ji.fromJSON(i.lines) : void 0
        }
    },
    toJSON(i) {
        var t, e;
        const n = {};
        return i.id !== void 0 && (n.id = i.id), i.text !== "" && (n.text = i.text), i.textStyle !== void 0 && (n.textStyle = N.toJSON(i.textStyle)), (t = i.paragraphs) != null && t.length && (n.paragraphs = i.paragraphs.map(o => h.toJSON(o))), (e = i.levelsStyles) != null && e.length && (n.levelsStyles = i.levelsStyles.map(o => C.toJSON(o))), i.fill !== void 0 && (n.fill = A.toJSON(i.fill)), i.lines !== void 0 && (n.lines = Ji.toJSON(i.lines)), n
    },
    create(i) {
        return yi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r;
        const n = pt();
        return n.id = (t = i.id) != null ? t : void 0, n.text = (e = i.text) != null ? e : "", n.textStyle = i.textStyle !== void 0 && i.textStyle !== null ? N.fromPartial(i.textStyle) : void 0, n.paragraphs = ((o = i.paragraphs) == null ? void 0 : o.map(u => h.fromPartial(u))) || [], n.levelsStyles = ((r = i.levelsStyles) == null ? void 0 : r.map(u => C.fromPartial(u))) || [], n.fill = i.fill !== void 0 && i.fill !== null ? A.fromPartial(i.fill) : void 0, n.lines = i.lines !== void 0 && i.lines !== null ? Ji.fromPartial(i.lines) : void 0, n
    }
};

function kt() {
    return {
        top: void 0,
        right: void 0,
        bottom: void 0,
        left: void 0
    }
}
const Ji = {
    encode(i, n = new O) {
        return i.top !== void 0 && T.encode(i.top, n.uint32(10).fork()).join(), i.right !== void 0 && T.encode(i.right, n.uint32(18).fork()).join(), i.bottom !== void 0 && T.encode(i.bottom, n.uint32(26).fork()).join(), i.left !== void 0 && T.encode(i.left, n.uint32(34).fork()).join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = kt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.top = T.decode(t, t.uint32());
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.right = T.decode(t, t.uint32());
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.bottom = T.decode(t, t.uint32());
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;o.left = T.decode(t, t.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            top: d(i.top) ? T.fromJSON(i.top) : void 0,
            right: d(i.right) ? T.fromJSON(i.right) : void 0,
            bottom: d(i.bottom) ? T.fromJSON(i.bottom) : void 0,
            left: d(i.left) ? T.fromJSON(i.left) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.top !== void 0 && (n.top = T.toJSON(i.top)), i.right !== void 0 && (n.right = T.toJSON(i.right)), i.bottom !== void 0 && (n.bottom = T.toJSON(i.bottom)), i.left !== void 0 && (n.left = T.toJSON(i.left)), n
    },
    create(i) {
        return Ji.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        const n = kt();
        return n.top = i.top !== void 0 && i.top !== null ? T.fromPartial(i.top) : void 0, n.right = i.right !== void 0 && i.right !== null ? T.fromPartial(i.right) : void 0, n.bottom = i.bottom !== void 0 && i.bottom !== null ? T.fromPartial(i.bottom) : void 0, n.left = i.left !== void 0 && i.left !== null ? T.fromPartial(i.left) : void 0, n
    }
};

function Dt() {
    return {
        id: void 0,
        cells: [],
        heightEmu: void 0
    }
}
const wi = {
    encode(i, n = new O) {
        i.id !== void 0 && n.uint32(26).string(i.id);
        for (const t of i.cells) yi.encode(t, n.uint32(10).fork()).join();
        return i.heightEmu !== void 0 && n.uint32(16).int32(i.heightEmu), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Dt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 3:
                    {
                        if (r !== 26) break;o.id = t.string();
                        continue
                    }
                case 1:
                    {
                        if (r !== 10) break;o.cells.push(yi.decode(t, t.uint32()));
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.heightEmu = t.int32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            id: d(i.id) ? l.String(i.id) : void 0,
            cells: l.Array.isArray(i == null ? void 0 : i.cells) ? i.cells.map(n => yi.fromJSON(n)) : [],
            heightEmu: d(i.heightEmu) ? l.Number(i.heightEmu) : void 0
        }
    },
    toJSON(i) {
        var t;
        const n = {};
        return i.id !== void 0 && (n.id = i.id), (t = i.cells) != null && t.length && (n.cells = i.cells.map(e => yi.toJSON(e))), i.heightEmu !== void 0 && (n.heightEmu = Math.round(i.heightEmu)), n
    },
    create(i) {
        return wi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o;
        const n = Dt();
        return n.id = (t = i.id) != null ? t : void 0, n.cells = ((e = i.cells) == null ? void 0 : e.map(r => yi.fromPartial(r))) || [], n.heightEmu = (o = i.heightEmu) != null ? o : void 0, n
    }
};

function Gt() {
    return {
        id: void 0,
        runs: [],
        textStyle: void 0,
        bulletCharacter: void 0,
        marginLeft: void 0,
        indent: void 0,
        spaceAfter: void 0,
        spaceBefore: void 0,
        styleId: void 0,
        paragraphStyle: void 0
    }
}
const h = {
    encode(i, n = new O) {
        i.id !== void 0 && n.uint32(74).string(i.id);
        for (const t of i.runs) Wi.encode(t, n.uint32(10).fork()).join();
        return i.textStyle !== void 0 && N.encode(i.textStyle, n.uint32(18).fork()).join(), i.bulletCharacter !== void 0 && n.uint32(26).string(i.bulletCharacter), i.marginLeft !== void 0 && n.uint32(32).int32(i.marginLeft), i.indent !== void 0 && n.uint32(40).int32(i.indent), i.spaceAfter !== void 0 && n.uint32(48).int32(i.spaceAfter), i.spaceBefore !== void 0 && n.uint32(56).int32(i.spaceBefore), i.styleId !== void 0 && n.uint32(66).string(i.styleId), i.paragraphStyle !== void 0 && J.encode(i.paragraphStyle, n.uint32(82).fork()).join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Gt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 9:
                    {
                        if (r !== 74) break;o.id = t.string();
                        continue
                    }
                case 1:
                    {
                        if (r !== 10) break;o.runs.push(Wi.decode(t, t.uint32()));
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.textStyle = N.decode(t, t.uint32());
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.bulletCharacter = t.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;o.marginLeft = t.int32();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;o.indent = t.int32();
                        continue
                    }
                case 6:
                    {
                        if (r !== 48) break;o.spaceAfter = t.int32();
                        continue
                    }
                case 7:
                    {
                        if (r !== 56) break;o.spaceBefore = t.int32();
                        continue
                    }
                case 8:
                    {
                        if (r !== 66) break;o.styleId = t.string();
                        continue
                    }
                case 10:
                    {
                        if (r !== 82) break;o.paragraphStyle = J.decode(t, t.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            id: d(i.id) ? l.String(i.id) : void 0,
            runs: l.Array.isArray(i == null ? void 0 : i.runs) ? i.runs.map(n => Wi.fromJSON(n)) : [],
            textStyle: d(i.textStyle) ? N.fromJSON(i.textStyle) : void 0,
            bulletCharacter: d(i.bulletCharacter) ? l.String(i.bulletCharacter) : void 0,
            marginLeft: d(i.marginLeft) ? l.Number(i.marginLeft) : void 0,
            indent: d(i.indent) ? l.Number(i.indent) : void 0,
            spaceAfter: d(i.spaceAfter) ? l.Number(i.spaceAfter) : void 0,
            spaceBefore: d(i.spaceBefore) ? l.Number(i.spaceBefore) : void 0,
            styleId: d(i.styleId) ? l.String(i.styleId) : void 0,
            paragraphStyle: d(i.paragraphStyle) ? J.fromJSON(i.paragraphStyle) : void 0
        }
    },
    toJSON(i) {
        var t;
        const n = {};
        return i.id !== void 0 && (n.id = i.id), (t = i.runs) != null && t.length && (n.runs = i.runs.map(e => Wi.toJSON(e))), i.textStyle !== void 0 && (n.textStyle = N.toJSON(i.textStyle)), i.bulletCharacter !== void 0 && (n.bulletCharacter = i.bulletCharacter), i.marginLeft !== void 0 && (n.marginLeft = Math.round(i.marginLeft)), i.indent !== void 0 && (n.indent = Math.round(i.indent)), i.spaceAfter !== void 0 && (n.spaceAfter = Math.round(i.spaceAfter)), i.spaceBefore !== void 0 && (n.spaceBefore = Math.round(i.spaceBefore)), i.styleId !== void 0 && (n.styleId = i.styleId), i.paragraphStyle !== void 0 && (n.paragraphStyle = J.toJSON(i.paragraphStyle)), n
    },
    create(i) {
        return h.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u, c, s, v;
        const n = Gt();
        return n.id = (t = i.id) != null ? t : void 0, n.runs = ((e = i.runs) == null ? void 0 : e.map(P => Wi.fromPartial(P))) || [], n.textStyle = i.textStyle !== void 0 && i.textStyle !== null ? N.fromPartial(i.textStyle) : void 0, n.bulletCharacter = (o = i.bulletCharacter) != null ? o : void 0, n.marginLeft = (r = i.marginLeft) != null ? r : void 0, n.indent = (u = i.indent) != null ? u : void 0, n.spaceAfter = (c = i.spaceAfter) != null ? c : void 0, n.spaceBefore = (s = i.spaceBefore) != null ? s : void 0, n.styleId = (v = i.styleId) != null ? v : void 0, n.paragraphStyle = i.paragraphStyle !== void 0 && i.paragraphStyle !== null ? J.fromPartial(i.paragraphStyle) : void 0, n
    }
};

function Ut() {
    return {
        id: void 0,
        text: "",
        textStyle: void 0,
        hyperlink: void 0,
        citations: []
    }
}
const Wi = {
    encode(i, n = new O) {
        i.id !== void 0 && n.uint32(34).string(i.id), i.text !== "" && n.uint32(10).string(i.text), i.textStyle !== void 0 && N.encode(i.textStyle, n.uint32(18).fork()).join(), i.hyperlink !== void 0 && W.encode(i.hyperlink, n.uint32(26).fork()).join();
        for (const t of i.citations) n.uint32(42).string(t);
        return n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Ut();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 4:
                    {
                        if (r !== 34) break;o.id = t.string();
                        continue
                    }
                case 1:
                    {
                        if (r !== 10) break;o.text = t.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.textStyle = N.decode(t, t.uint32());
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.hyperlink = W.decode(t, t.uint32());
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;o.citations.push(t.string());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            id: d(i.id) ? l.String(i.id) : void 0,
            text: d(i.text) ? l.String(i.text) : "",
            textStyle: d(i.textStyle) ? N.fromJSON(i.textStyle) : void 0,
            hyperlink: d(i.hyperlink) ? W.fromJSON(i.hyperlink) : void 0,
            citations: l.Array.isArray(i == null ? void 0 : i.citations) ? i.citations.map(n => l.String(n)) : []
        }
    },
    toJSON(i) {
        var t;
        const n = {};
        return i.id !== void 0 && (n.id = i.id), i.text !== "" && (n.text = i.text), i.textStyle !== void 0 && (n.textStyle = N.toJSON(i.textStyle)), i.hyperlink !== void 0 && (n.hyperlink = W.toJSON(i.hyperlink)), (t = i.citations) != null && t.length && (n.citations = i.citations), n
    },
    create(i) {
        return Wi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o;
        const n = Ut();
        return n.id = (t = i.id) != null ? t : void 0, n.text = (e = i.text) != null ? e : "", n.textStyle = i.textStyle !== void 0 && i.textStyle !== null ? N.fromPartial(i.textStyle) : void 0, n.hyperlink = i.hyperlink !== void 0 && i.hyperlink !== null ? W.fromPartial(i.hyperlink) : void 0, n.citations = ((o = i.citations) == null ? void 0 : o.map(r => r)) || [], n
    }
};

function Bt() {
    return {
        uri: "",
        isExternal: !1,
        action: ""
    }
}
const W = {
    encode(i, n = new O) {
        return i.uri !== "" && n.uint32(10).string(i.uri), i.isExternal !== !1 && n.uint32(16).bool(i.isExternal), i.action !== "" && n.uint32(26).string(i.action), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Bt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.uri = t.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.isExternal = t.bool();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.action = t.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            uri: d(i.uri) ? l.String(i.uri) : "",
            isExternal: d(i.isExternal) ? l.Boolean(i.isExternal) : !1,
            action: d(i.action) ? l.String(i.action) : ""
        }
    },
    toJSON(i) {
        const n = {};
        return i.uri !== "" && (n.uri = i.uri), i.isExternal !== !1 && (n.isExternal = i.isExternal), i.action !== "" && (n.action = i.action), n
    },
    create(i) {
        return W.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o;
        const n = Bt();
        return n.uri = (t = i.uri) != null ? t : "", n.isExternal = (e = i.isExternal) != null ? e : !1, n.action = (o = i.action) != null ? o : "", n
    }
};

function Ft() {
    return {
        effects: []
    }
}
const mi = {
    encode(i, n = new O) {
        for (const t of i.effects) m.encode(t, n.uint32(10).fork()).join();
        return n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Ft();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.effects.push(m.decode(t, t.uint32()));
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            effects: l.Array.isArray(i == null ? void 0 : i.effects) ? i.effects.map(n => m.fromJSON(n)) : []
        }
    },
    toJSON(i) {
        var t;
        const n = {};
        return (t = i.effects) != null && t.length && (n.effects = i.effects.map(e => m.toJSON(e))), n
    },
    create(i) {
        return mi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t;
        const n = Ft();
        return n.effects = ((t = i.effects) == null ? void 0 : t.map(e => m.fromPartial(e))) || [], n
    }
};

function xt() {
    return {
        type: 0,
        shadow: void 0
    }
}
const m = {
    encode(i, n = new O) {
        return i.type !== 0 && n.uint32(8).int32(i.type), i.shadow !== void 0 && Vi.encode(i.shadow, n.uint32(18).fork()).join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = xt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.type = t.int32();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.shadow = Vi.decode(t, t.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            type: d(i.type) ? Re(i.type) : 0,
            shadow: d(i.shadow) ? Vi.fromJSON(i.shadow) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.type !== 0 && (n.type = se(i.type)), i.shadow !== void 0 && (n.shadow = Vi.toJSON(i.shadow)), n
    },
    create(i) {
        return m.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t;
        const n = xt();
        return n.type = (t = i.type) != null ? t : 0, n.shadow = i.shadow !== void 0 && i.shadow !== null ? Vi.fromPartial(i.shadow) : void 0, n
    }
};

function yt() {
    return {
        color: void 0,
        blurRadius: 0,
        distance: 0,
        direction: 0
    }
}
const Vi = {
    encode(i, n = new O) {
        return i.color !== void 0 && S.encode(i.color, n.uint32(18).fork()).join(), i.blurRadius !== 0 && n.uint32(24).int32(i.blurRadius), i.distance !== 0 && n.uint32(32).int32(i.distance), i.direction !== 0 && n.uint32(40).int32(i.direction), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = yt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 2:
                    {
                        if (r !== 18) break;o.color = S.decode(t, t.uint32());
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;o.blurRadius = t.int32();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;o.distance = t.int32();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;o.direction = t.int32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            color: d(i.color) ? S.fromJSON(i.color) : void 0,
            blurRadius: d(i.blurRadius) ? l.Number(i.blurRadius) : 0,
            distance: d(i.distance) ? l.Number(i.distance) : 0,
            direction: d(i.direction) ? l.Number(i.direction) : 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.color !== void 0 && (n.color = S.toJSON(i.color)), i.blurRadius !== 0 && (n.blurRadius = Math.round(i.blurRadius)), i.distance !== 0 && (n.distance = Math.round(i.distance)), i.direction !== 0 && (n.direction = Math.round(i.direction)), n
    },
    create(i) {
        return Vi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o;
        const n = yt();
        return n.color = i.color !== void 0 && i.color !== null ? S.fromPartial(i.color) : void 0, n.blurRadius = (t = i.blurRadius) != null ? t : 0, n.distance = (e = i.distance) != null ? e : 0, n.direction = (o = i.direction) != null ? o : 0, n
    }
};

function Jt() {
    return {
        geometry: 0,
        fill: void 0,
        line: void 0,
        adjustmentList: [],
        rectFormula: void 0,
        customPaths: []
    }
}
const Ki = {
    encode(i, n = new O) {
        i.geometry !== 0 && n.uint32(8).int32(i.geometry), i.fill !== void 0 && A.encode(i.fill, n.uint32(42).fork()).join(), i.line !== void 0 && T.encode(i.line, n.uint32(50).fork()).join();
        for (const t of i.adjustmentList) Zi.encode(t, n.uint32(58).fork()).join();
        i.rectFormula !== void 0 && qi.encode(i.rectFormula, n.uint32(66).fork()).join();
        for (const t of i.customPaths) nn.encode(t, n.uint32(74).fork()).join();
        return n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Jt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.geometry = t.int32();
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;o.fill = A.decode(t, t.uint32());
                        continue
                    }
                case 6:
                    {
                        if (r !== 50) break;o.line = T.decode(t, t.uint32());
                        continue
                    }
                case 7:
                    {
                        if (r !== 58) break;o.adjustmentList.push(Zi.decode(t, t.uint32()));
                        continue
                    }
                case 8:
                    {
                        if (r !== 66) break;o.rectFormula = qi.decode(t, t.uint32());
                        continue
                    }
                case 9:
                    {
                        if (r !== 74) break;o.customPaths.push(nn.decode(t, t.uint32()));
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            geometry: d(i.geometry) ? le(i.geometry) : 0,
            fill: d(i.fill) ? A.fromJSON(i.fill) : void 0,
            line: d(i.line) ? T.fromJSON(i.line) : void 0,
            adjustmentList: l.Array.isArray(i == null ? void 0 : i.adjustmentList) ? i.adjustmentList.map(n => Zi.fromJSON(n)) : [],
            rectFormula: d(i.rectFormula) ? qi.fromJSON(i.rectFormula) : void 0,
            customPaths: l.Array.isArray(i == null ? void 0 : i.customPaths) ? i.customPaths.map(n => nn.fromJSON(n)) : []
        }
    },
    toJSON(i) {
        var t, e;
        const n = {};
        return i.geometry !== 0 && (n.geometry = _e(i.geometry)), i.fill !== void 0 && (n.fill = A.toJSON(i.fill)), i.line !== void 0 && (n.line = T.toJSON(i.line)), (t = i.adjustmentList) != null && t.length && (n.adjustmentList = i.adjustmentList.map(o => Zi.toJSON(o))), i.rectFormula !== void 0 && (n.rectFormula = qi.toJSON(i.rectFormula)), (e = i.customPaths) != null && e.length && (n.customPaths = i.customPaths.map(o => nn.toJSON(o))), n
    },
    create(i) {
        return Ki.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o;
        const n = Jt();
        return n.geometry = (t = i.geometry) != null ? t : 0, n.fill = i.fill !== void 0 && i.fill !== null ? A.fromPartial(i.fill) : void 0, n.line = i.line !== void 0 && i.line !== null ? T.fromPartial(i.line) : void 0, n.adjustmentList = ((e = i.adjustmentList) == null ? void 0 : e.map(r => Zi.fromPartial(r))) || [], n.rectFormula = i.rectFormula !== void 0 && i.rectFormula !== null ? qi.fromPartial(i.rectFormula) : void 0, n.customPaths = ((o = i.customPaths) == null ? void 0 : o.map(r => nn.fromPartial(r))) || [], n
    }
};

function wt() {
    return {
        name: "",
        formula: ""
    }
}
const Zi = {
    encode(i, n = new O) {
        return i.name !== "" && n.uint32(10).string(i.name), i.formula !== "" && n.uint32(18).string(i.formula), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = wt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.name = t.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.formula = t.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            name: d(i.name) ? l.String(i.name) : "",
            formula: d(i.formula) ? l.String(i.formula) : ""
        }
    },
    toJSON(i) {
        const n = {};
        return i.name !== "" && (n.name = i.name), i.formula !== "" && (n.formula = i.formula), n
    },
    create(i) {
        return Zi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e;
        const n = wt();
        return n.name = (t = i.name) != null ? t : "", n.formula = (e = i.formula) != null ? e : "", n
    }
};

function Wt() {
    return {
        geometry: "",
        cropLeft: 0,
        cropTop: 0,
        cropRight: 0,
        cropBottom: 0
    }
}
const V = {
    encode(i, n = new O) {
        return i.geometry !== "" && n.uint32(10).string(i.geometry), i.cropLeft !== 0 && n.uint32(16).uint32(i.cropLeft), i.cropTop !== 0 && n.uint32(24).uint32(i.cropTop), i.cropRight !== 0 && n.uint32(32).uint32(i.cropRight), i.cropBottom !== 0 && n.uint32(40).uint32(i.cropBottom), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Wt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.geometry = t.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.cropLeft = t.uint32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 24) break;o.cropTop = t.uint32();
                        continue
                    }
                case 4:
                    {
                        if (r !== 32) break;o.cropRight = t.uint32();
                        continue
                    }
                case 5:
                    {
                        if (r !== 40) break;o.cropBottom = t.uint32();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            geometry: d(i.geometry) ? l.String(i.geometry) : "",
            cropLeft: d(i.cropLeft) ? l.Number(i.cropLeft) : 0,
            cropTop: d(i.cropTop) ? l.Number(i.cropTop) : 0,
            cropRight: d(i.cropRight) ? l.Number(i.cropRight) : 0,
            cropBottom: d(i.cropBottom) ? l.Number(i.cropBottom) : 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.geometry !== "" && (n.geometry = i.geometry), i.cropLeft !== 0 && (n.cropLeft = Math.round(i.cropLeft)), i.cropTop !== 0 && (n.cropTop = Math.round(i.cropTop)), i.cropRight !== 0 && (n.cropRight = Math.round(i.cropRight)), i.cropBottom !== 0 && (n.cropBottom = Math.round(i.cropBottom)), n
    },
    create(i) {
        return V.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u;
        const n = Wt();
        return n.geometry = (t = i.geometry) != null ? t : "", n.cropLeft = (e = i.cropLeft) != null ? e : 0, n.cropTop = (o = i.cropTop) != null ? o : 0, n.cropRight = (r = i.cropRight) != null ? r : 0, n.cropBottom = (u = i.cropBottom) != null ? u : 0, n
    }
};

function mt() {
    return {
        contentType: "",
        data: new Uint8Array(0),
        mask: void 0,
        alt: ""
    }
}
const Xi = {
    encode(i, n = new O) {
        return i.contentType !== "" && n.uint32(10).string(i.contentType), i.data.length !== 0 && n.uint32(18).bytes(i.data), i.mask !== void 0 && V.encode(i.mask, n.uint32(26).fork()).join(), i.alt !== "" && n.uint32(34).string(i.alt), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = mt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.contentType = t.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.data = t.bytes();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.mask = V.decode(t, t.uint32());
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;o.alt = t.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            contentType: d(i.contentType) ? l.String(i.contentType) : "",
            data: d(i.data) ? ur(i.data) : new Uint8Array(0),
            mask: d(i.mask) ? V.fromJSON(i.mask) : void 0,
            alt: d(i.alt) ? l.String(i.alt) : ""
        }
    },
    toJSON(i) {
        const n = {};
        return i.contentType !== "" && (n.contentType = i.contentType), i.data.length !== 0 && (n.data = dr(i.data)), i.mask !== void 0 && (n.mask = V.toJSON(i.mask)), i.alt !== "" && (n.alt = i.alt), n
    },
    create(i) {
        return Xi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o;
        const n = mt();
        return n.contentType = (t = i.contentType) != null ? t : "", n.data = (e = i.data) != null ? e : new Uint8Array(0), n.mask = i.mask !== void 0 && i.mask !== null ? V.fromPartial(i.mask) : void 0, n.alt = (o = i.alt) != null ? o : "", n
    }
};

function Vt() {
    return {
        contentType: "",
        data: new Uint8Array(0),
        mask: void 0,
        alt: ""
    }
}
const zi = {
    encode(i, n = new O) {
        return i.contentType !== "" && n.uint32(10).string(i.contentType), i.data.length !== 0 && n.uint32(18).bytes(i.data), i.mask !== void 0 && V.encode(i.mask, n.uint32(26).fork()).join(), i.alt !== "" && n.uint32(34).string(i.alt), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Vt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.contentType = t.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.data = t.bytes();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.mask = V.decode(t, t.uint32());
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;o.alt = t.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            contentType: d(i.contentType) ? l.String(i.contentType) : "",
            data: d(i.data) ? ur(i.data) : new Uint8Array(0),
            mask: d(i.mask) ? V.fromJSON(i.mask) : void 0,
            alt: d(i.alt) ? l.String(i.alt) : ""
        }
    },
    toJSON(i) {
        const n = {};
        return i.contentType !== "" && (n.contentType = i.contentType), i.data.length !== 0 && (n.data = dr(i.data)), i.mask !== void 0 && (n.mask = V.toJSON(i.mask)), i.alt !== "" && (n.alt = i.alt), n
    },
    create(i) {
        return zi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o;
        const n = Vt();
        return n.contentType = (t = i.contentType) != null ? t : "", n.data = (e = i.data) != null ? e : new Uint8Array(0), n.mask = i.mask !== void 0 && i.mask !== null ? V.fromPartial(i.mask) : void 0, n.alt = (o = i.alt) != null ? o : "", n
    }
};

function Kt() {
    return {
        accent1: "",
        accent2: "",
        accent3: "",
        accent4: "",
        accent5: "",
        accent6: "",
        bg1: "",
        bg2: "",
        tx1: "",
        tx2: "",
        hlink: "",
        folHlink: ""
    }
}
const Qi = {
    encode(i, n = new O) {
        return i.accent1 !== "" && n.uint32(10).string(i.accent1), i.accent2 !== "" && n.uint32(18).string(i.accent2), i.accent3 !== "" && n.uint32(26).string(i.accent3), i.accent4 !== "" && n.uint32(34).string(i.accent4), i.accent5 !== "" && n.uint32(42).string(i.accent5), i.accent6 !== "" && n.uint32(50).string(i.accent6), i.bg1 !== "" && n.uint32(58).string(i.bg1), i.bg2 !== "" && n.uint32(66).string(i.bg2), i.tx1 !== "" && n.uint32(74).string(i.tx1), i.tx2 !== "" && n.uint32(82).string(i.tx2), i.hlink !== "" && n.uint32(90).string(i.hlink), i.folHlink !== "" && n.uint32(98).string(i.folHlink), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Kt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.accent1 = t.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.accent2 = t.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.accent3 = t.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;o.accent4 = t.string();
                        continue
                    }
                case 5:
                    {
                        if (r !== 42) break;o.accent5 = t.string();
                        continue
                    }
                case 6:
                    {
                        if (r !== 50) break;o.accent6 = t.string();
                        continue
                    }
                case 7:
                    {
                        if (r !== 58) break;o.bg1 = t.string();
                        continue
                    }
                case 8:
                    {
                        if (r !== 66) break;o.bg2 = t.string();
                        continue
                    }
                case 9:
                    {
                        if (r !== 74) break;o.tx1 = t.string();
                        continue
                    }
                case 10:
                    {
                        if (r !== 82) break;o.tx2 = t.string();
                        continue
                    }
                case 11:
                    {
                        if (r !== 90) break;o.hlink = t.string();
                        continue
                    }
                case 12:
                    {
                        if (r !== 98) break;o.folHlink = t.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            accent1: d(i.accent1) ? l.String(i.accent1) : "",
            accent2: d(i.accent2) ? l.String(i.accent2) : "",
            accent3: d(i.accent3) ? l.String(i.accent3) : "",
            accent4: d(i.accent4) ? l.String(i.accent4) : "",
            accent5: d(i.accent5) ? l.String(i.accent5) : "",
            accent6: d(i.accent6) ? l.String(i.accent6) : "",
            bg1: d(i.bg1) ? l.String(i.bg1) : "",
            bg2: d(i.bg2) ? l.String(i.bg2) : "",
            tx1: d(i.tx1) ? l.String(i.tx1) : "",
            tx2: d(i.tx2) ? l.String(i.tx2) : "",
            hlink: d(i.hlink) ? l.String(i.hlink) : "",
            folHlink: d(i.folHlink) ? l.String(i.folHlink) : ""
        }
    },
    toJSON(i) {
        const n = {};
        return i.accent1 !== "" && (n.accent1 = i.accent1), i.accent2 !== "" && (n.accent2 = i.accent2), i.accent3 !== "" && (n.accent3 = i.accent3), i.accent4 !== "" && (n.accent4 = i.accent4), i.accent5 !== "" && (n.accent5 = i.accent5), i.accent6 !== "" && (n.accent6 = i.accent6), i.bg1 !== "" && (n.bg1 = i.bg1), i.bg2 !== "" && (n.bg2 = i.bg2), i.tx1 !== "" && (n.tx1 = i.tx1), i.tx2 !== "" && (n.tx2 = i.tx2), i.hlink !== "" && (n.hlink = i.hlink), i.folHlink !== "" && (n.folHlink = i.folHlink), n
    },
    create(i) {
        return Qi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r, u, c, s, v, P, L, I, Y;
        const n = Kt();
        return n.accent1 = (t = i.accent1) != null ? t : "", n.accent2 = (e = i.accent2) != null ? e : "", n.accent3 = (o = i.accent3) != null ? o : "", n.accent4 = (r = i.accent4) != null ? r : "", n.accent5 = (u = i.accent5) != null ? u : "", n.accent6 = (c = i.accent6) != null ? c : "", n.bg1 = (s = i.bg1) != null ? s : "", n.bg2 = (v = i.bg2) != null ? v : "", n.tx1 = (P = i.tx1) != null ? P : "", n.tx2 = (L = i.tx2) != null ? L : "", n.hlink = (I = i.hlink) != null ? I : "", n.folHlink = (Y = i.folHlink) != null ? Y : "", n
    }
};

function Zt() {
    return {
        t: "",
        l: "",
        r: "",
        b: ""
    }
}
const qi = {
    encode(i, n = new O) {
        return i.t !== "" && n.uint32(10).string(i.t), i.l !== "" && n.uint32(18).string(i.l), i.r !== "" && n.uint32(26).string(i.r), i.b !== "" && n.uint32(34).string(i.b), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Zt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.t = t.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.l = t.string();
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.r = t.string();
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;o.b = t.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            t: d(i.t) ? l.String(i.t) : "",
            l: d(i.l) ? l.String(i.l) : "",
            r: d(i.r) ? l.String(i.r) : "",
            b: d(i.b) ? l.String(i.b) : ""
        }
    },
    toJSON(i) {
        const n = {};
        return i.t !== "" && (n.t = i.t), i.l !== "" && (n.l = i.l), i.r !== "" && (n.r = i.r), i.b !== "" && (n.b = i.b), n
    },
    create(i) {
        return qi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r;
        const n = Zt();
        return n.t = (t = i.t) != null ? t : "", n.l = (e = i.l) != null ? e : "", n.r = (o = i.r) != null ? o : "", n.b = (r = i.b) != null ? r : "", n
    }
};

function Xt() {
    return {
        x: 0,
        y: 0
    }
}
const $i = {
    encode(i, n = new O) {
        return i.x !== 0 && n.uint32(8).int64(i.x), i.y !== 0 && n.uint32(16).int64(i.y), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Xt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.x = Q(t.int64());
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.y = Q(t.int64());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            x: d(i.x) ? l.Number(i.x) : 0,
            y: d(i.y) ? l.Number(i.y) : 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.x !== 0 && (n.x = Math.round(i.x)), i.y !== 0 && (n.y = Math.round(i.y)), n
    },
    create(i) {
        return $i.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e;
        const n = Xt();
        return n.x = (t = i.x) != null ? t : 0, n.y = (e = i.y) != null ? e : 0, n
    }
};

function zt() {
    return {
        x: 0,
        y: 0
    }
}
const gi = {
    encode(i, n = new O) {
        return i.x !== 0 && n.uint32(8).int64(i.x), i.y !== 0 && n.uint32(16).int64(i.y), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = zt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 8) break;o.x = Q(t.int64());
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.y = Q(t.int64());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            x: d(i.x) ? l.Number(i.x) : 0,
            y: d(i.y) ? l.Number(i.y) : 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.x !== 0 && (n.x = Math.round(i.x)), i.y !== 0 && (n.y = Math.round(i.y)), n
    },
    create(i) {
        return gi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e;
        const n = zt();
        return n.x = (t = i.x) != null ? t : 0, n.y = (e = i.y) != null ? e : 0, n
    }
};

function Qt() {
    return {}
}
const bi = {
    encode(i, n = new O) {
        return n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = Qt();
        for (; t.pos < e;) {
            const r = t.uint32();
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {}
    },
    toJSON(i) {
        return {}
    },
    create(i) {
        return bi.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        return Qt()
    }
};

function qt() {
    return {
        moveTo: void 0,
        lineTo: void 0,
        close: void 0
    }
}
const ji = {
    encode(i, n = new O) {
        return i.moveTo !== void 0 && $i.encode(i.moveTo, n.uint32(10).fork()).join(), i.lineTo !== void 0 && gi.encode(i.lineTo, n.uint32(18).fork()).join(), i.close !== void 0 && bi.encode(i.close, n.uint32(26).fork()).join(), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = qt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.moveTo = $i.decode(t, t.uint32());
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.lineTo = gi.decode(t, t.uint32());
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.close = bi.decode(t, t.uint32());
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            moveTo: d(i.moveTo) ? $i.fromJSON(i.moveTo) : void 0,
            lineTo: d(i.lineTo) ? gi.fromJSON(i.lineTo) : void 0,
            close: d(i.close) ? bi.fromJSON(i.close) : void 0
        }
    },
    toJSON(i) {
        const n = {};
        return i.moveTo !== void 0 && (n.moveTo = $i.toJSON(i.moveTo)), i.lineTo !== void 0 && (n.lineTo = gi.toJSON(i.lineTo)), i.close !== void 0 && (n.close = bi.toJSON(i.close)), n
    },
    create(i) {
        return ji.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        const n = qt();
        return n.moveTo = i.moveTo !== void 0 && i.moveTo !== null ? $i.fromPartial(i.moveTo) : void 0, n.lineTo = i.lineTo !== void 0 && i.lineTo !== null ? gi.fromPartial(i.lineTo) : void 0, n.close = i.close !== void 0 && i.close !== null ? bi.fromPartial(i.close) : void 0, n
    }
};

function $t() {
    return {
        id: void 0,
        widthEmu: 0,
        heightEmu: 0,
        commands: []
    }
}
const nn = {
    encode(i, n = new O) {
        i.id !== void 0 && n.uint32(34).string(i.id), i.widthEmu !== 0 && n.uint32(8).int64(i.widthEmu), i.heightEmu !== 0 && n.uint32(16).int64(i.heightEmu);
        for (const t of i.commands) ji.encode(t, n.uint32(26).fork()).join();
        return n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = $t();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 4:
                    {
                        if (r !== 34) break;o.id = t.string();
                        continue
                    }
                case 1:
                    {
                        if (r !== 8) break;o.widthEmu = Q(t.int64());
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.heightEmu = Q(t.int64());
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.commands.push(ji.decode(t, t.uint32()));
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            id: d(i.id) ? l.String(i.id) : void 0,
            widthEmu: d(i.widthEmu) ? l.Number(i.widthEmu) : 0,
            heightEmu: d(i.heightEmu) ? l.Number(i.heightEmu) : 0,
            commands: l.Array.isArray(i == null ? void 0 : i.commands) ? i.commands.map(n => ji.fromJSON(n)) : []
        }
    },
    toJSON(i) {
        var t;
        const n = {};
        return i.id !== void 0 && (n.id = i.id), i.widthEmu !== 0 && (n.widthEmu = Math.round(i.widthEmu)), i.heightEmu !== 0 && (n.heightEmu = Math.round(i.heightEmu)), (t = i.commands) != null && t.length && (n.commands = i.commands.map(e => ji.toJSON(e))), n
    },
    create(i) {
        return nn.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r;
        const n = $t();
        return n.id = (t = i.id) != null ? t : void 0, n.widthEmu = (e = i.widthEmu) != null ? e : 0, n.heightEmu = (o = i.heightEmu) != null ? o : 0, n.commands = ((r = i.commands) == null ? void 0 : r.map(u => ji.fromPartial(u))) || [], n
    }
};

function gt() {
    return {
        themeId: ""
    }
}
const tn = {
    encode(i, n = new O) {
        return i.themeId !== "" && n.uint32(10).string(i.themeId), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = gt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.themeId = t.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            themeId: d(i.themeId) ? l.String(i.themeId) : ""
        }
    },
    toJSON(i) {
        const n = {};
        return i.themeId !== "" && (n.themeId = i.themeId), n
    },
    create(i) {
        return tn.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t;
        const n = gt();
        return n.themeId = (t = i.themeId) != null ? t : "", n
    }
};

function bt() {
    return {
        key: "",
        sourceRuns: [],
        outputRuns: []
    }
}
const rn = {
    encode(i, n = new O) {
        i.key !== "" && n.uint32(10).string(i.key);
        for (const t of i.sourceRuns) h.encode(t, n.uint32(18).fork()).join();
        for (const t of i.outputRuns) h.encode(t, n.uint32(26).fork()).join();
        return n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = bt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.key = t.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 18) break;o.sourceRuns.push(h.decode(t, t.uint32()));
                        continue
                    }
                case 3:
                    {
                        if (r !== 26) break;o.outputRuns.push(h.decode(t, t.uint32()));
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            key: d(i.key) ? l.String(i.key) : "",
            sourceRuns: l.Array.isArray(i == null ? void 0 : i.sourceRuns) ? i.sourceRuns.map(n => h.fromJSON(n)) : [],
            outputRuns: l.Array.isArray(i == null ? void 0 : i.outputRuns) ? i.outputRuns.map(n => h.fromJSON(n)) : []
        }
    },
    toJSON(i) {
        var t, e;
        const n = {};
        return i.key !== "" && (n.key = i.key), (t = i.sourceRuns) != null && t.length && (n.sourceRuns = i.sourceRuns.map(o => h.toJSON(o))), (e = i.outputRuns) != null && e.length && (n.outputRuns = i.outputRuns.map(o => h.toJSON(o))), n
    },
    create(i) {
        return rn.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o;
        const n = bt();
        return n.key = (t = i.key) != null ? t : "", n.sourceRuns = ((e = i.sourceRuns) == null ? void 0 : e.map(r => h.fromPartial(r))) || [], n.outputRuns = ((o = i.outputRuns) == null ? void 0 : o.map(r => h.fromPartial(r))) || [], n
    }
};

function jt() {
    return {
        runtime: "",
        exitCode: 0,
        durationMs: 0,
        timestampIso8601: ""
    }
}
const on = {
    encode(i, n = new O) {
        return i.runtime !== "" && n.uint32(10).string(i.runtime), i.exitCode !== 0 && n.uint32(16).int32(i.exitCode), i.durationMs !== 0 && n.uint32(25).double(i.durationMs), i.timestampIso8601 !== "" && n.uint32(34).string(i.timestampIso8601), n
    },
    decode(i, n) {
        const t = i instanceof a ? i : new a(i);
        let e = n === void 0 ? t.len : t.pos + n;
        const o = jt();
        for (; t.pos < e;) {
            const r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    {
                        if (r !== 10) break;o.runtime = t.string();
                        continue
                    }
                case 2:
                    {
                        if (r !== 16) break;o.exitCode = t.int32();
                        continue
                    }
                case 3:
                    {
                        if (r !== 25) break;o.durationMs = t.double();
                        continue
                    }
                case 4:
                    {
                        if (r !== 34) break;o.timestampIso8601 = t.string();
                        continue
                    }
            }
            if ((r & 7) === 4 || r === 0) break;
            t.skip(r & 7)
        }
        return o
    },
    fromJSON(i) {
        return {
            runtime: d(i.runtime) ? l.String(i.runtime) : "",
            exitCode: d(i.exitCode) ? l.Number(i.exitCode) : 0,
            durationMs: d(i.durationMs) ? l.Number(i.durationMs) : 0,
            timestampIso8601: d(i.timestampIso8601) ? l.String(i.timestampIso8601) : ""
        }
    },
    toJSON(i) {
        const n = {};
        return i.runtime !== "" && (n.runtime = i.runtime), i.exitCode !== 0 && (n.exitCode = Math.round(i.exitCode)), i.durationMs !== 0 && (n.durationMs = i.durationMs), i.timestampIso8601 !== "" && (n.timestampIso8601 = i.timestampIso8601), n
    },
    create(i) {
        return on.fromPartial(i != null ? i : {})
    },
    fromPartial(i) {
        var t, e, o, r;
        const n = jt();
        return n.runtime = (t = i.runtime) != null ? t : "", n.exitCode = (e = i.exitCode) != null ? e : 0, n.durationMs = (o = i.durationMs) != null ? o : 0, n.timestampIso8601 = (r = i.timestampIso8601) != null ? r : "", n
    }
};

function ir() {
    return {
        id: "",
        language: "",
        source: void 0,
        output: void 0,
        kind: 0,
        theme: void 0,
        sourceMime: "",
        outputMime: "",
        exec: void 0,
        cache: void 0
    }
}
const en = {
        encode(i, n = new O) {
            return i.id !== "" && n.uint32(10).string(i.id), i.language !== "" && n.uint32(18).string(i.language), i.source !== void 0 && n.uint32(26).string(i.source), i.output !== void 0 && n.uint32(34).string(i.output), i.kind !== 0 && n.uint32(40).int32(i.kind), i.theme !== void 0 && tn.encode(i.theme, n.uint32(50).fork()).join(), i.sourceMime !== "" && n.uint32(114).string(i.sourceMime), i.outputMime !== "" && n.uint32(122).string(i.outputMime), i.exec !== void 0 && on.encode(i.exec, n.uint32(130).fork()).join(), i.cache !== void 0 && rn.encode(i.cache, n.uint32(138).fork()).join(), n
        },
        decode(i, n) {
            const t = i instanceof a ? i : new a(i);
            let e = n === void 0 ? t.len : t.pos + n;
            const o = ir();
            for (; t.pos < e;) {
                const r = t.uint32();
                switch (r >>> 3) {
                    case 1:
                        {
                            if (r !== 10) break;o.id = t.string();
                            continue
                        }
                    case 2:
                        {
                            if (r !== 18) break;o.language = t.string();
                            continue
                        }
                    case 3:
                        {
                            if (r !== 26) break;o.source = t.string();
                            continue
                        }
                    case 4:
                        {
                            if (r !== 34) break;o.output = t.string();
                            continue
                        }
                    case 5:
                        {
                            if (r !== 40) break;o.kind = t.int32();
                            continue
                        }
                    case 6:
                        {
                            if (r !== 50) break;o.theme = tn.decode(t, t.uint32());
                            continue
                        }
                    case 14:
                        {
                            if (r !== 114) break;o.sourceMime = t.string();
                            continue
                        }
                    case 15:
                        {
                            if (r !== 122) break;o.outputMime = t.string();
                            continue
                        }
                    case 16:
                        {
                            if (r !== 130) break;o.exec = on.decode(t, t.uint32());
                            continue
                        }
                    case 17:
                        {
                            if (r !== 138) break;o.cache = rn.decode(t, t.uint32());
                            continue
                        }
                }
                if ((r & 7) === 4 || r === 0) break;
                t.skip(r & 7)
            }
            return o
        },
        fromJSON(i) {
            return {
                id: d(i.id) ? l.String(i.id) : "",
                language: d(i.language) ? l.String(i.language) : "",
                source: d(i.source) ? l.String(i.source) : void 0,
                output: d(i.output) ? l.String(i.output) : void 0,
                kind: d(i.kind) ? Ae(i.kind) : 0,
                theme: d(i.theme) ? tn.fromJSON(i.theme) : void 0,
                sourceMime: d(i.sourceMime) ? l.String(i.sourceMime) : "",
                outputMime: d(i.outputMime) ? l.String(i.outputMime) : "",
                exec: d(i.exec) ? on.fromJSON(i.exec) : void 0,
                cache: d(i.cache) ? rn.fromJSON(i.cache) : void 0
            }
        },
        toJSON(i) {
            const n = {};
            return i.id !== "" && (n.id = i.id), i.language !== "" && (n.language = i.language), i.source !== void 0 && (n.source = i.source), i.output !== void 0 && (n.output = i.output), i.kind !== 0 && (n.kind = Ne(i.kind)), i.theme !== void 0 && (n.theme = tn.toJSON(i.theme)), i.sourceMime !== "" && (n.sourceMime = i.sourceMime), i.outputMime !== "" && (n.outputMime = i.outputMime), i.exec !== void 0 && (n.exec = on.toJSON(i.exec)), i.cache !== void 0 && (n.cache = rn.toJSON(i.cache)), n
        },
        create(i) {
            return en.fromPartial(i != null ? i : {})
        },
        fromPartial(i) {
            var t, e, o, r, u, c, s;
            const n = ir();
            return n.id = (t = i.id) != null ? t : "", n.language = (e = i.language) != null ? e : "", n.source = (o = i.source) != null ? o : void 0, n.output = (r = i.output) != null ? r : void 0, n.kind = (u = i.kind) != null ? u : 0, n.theme = i.theme !== void 0 && i.theme !== null ? tn.fromPartial(i.theme) : void 0, n.sourceMime = (c = i.sourceMime) != null ? c : "", n.outputMime = (s = i.outputMime) != null ? s : "", n.exec = i.exec !== void 0 && i.exec !== null ? on.fromPartial(i.exec) : void 0, n.cache = i.cache !== void 0 && i.cache !== null ? rn.fromPartial(i.cache) : void 0, n
        }
    },
    l = (() => {
        if (typeof globalThis < "u") return globalThis;
        if (typeof self < "u") return self;
        if (typeof window < "u") return window;
        if (typeof global < "u") return global;
        throw "Unable to locate global object"
    })();

function ur(i) {
    if (l.Buffer) return Uint8Array.from(l.Buffer.from(i, "base64")); {
        const n = l.atob(i),
            t = new Uint8Array(n.length);
        for (let e = 0; e < n.length; ++e) t[e] = n.charCodeAt(e);
        return t
    }
}

function dr(i) {
    if (l.Buffer) return l.Buffer.from(i).toString("base64"); {
        const n = [];
        return i.forEach(t => {
            n.push(l.String.fromCharCode(t))
        }), l.btoa(n.join(""))
    }
}

function Q(i) {
    const n = l.Number(i.toString());
    if (n > l.Number.MAX_SAFE_INTEGER) throw new l.Error("Value is larger than Number.MAX_SAFE_INTEGER");
    if (n < l.Number.MIN_SAFE_INTEGER) throw new l.Error("Value is smaller than Number.MIN_SAFE_INTEGER");
    return n
}

function d(i) {
    return i != null
}
export {
    pr as A, O as B, ni as C, ao as D, ce as E, A as F, Jr as G, oe as H, ii as I, T as L, ko as M, h as P, To as R, de as S, ki as T, Gr as V, a, S as b, N as c, ri as d, y as e, Se as f, Xr as g, vr as h, hr as i, Lr as j, qr as k, Fr as l, Oe as m, zo as n, So as o, so as p, oo as q, io as r, bo as s, Fo as t, _o as u, ne as v, ro as w
};
//# sourceMappingURL=f96c6fguu1kcw0go.js.map