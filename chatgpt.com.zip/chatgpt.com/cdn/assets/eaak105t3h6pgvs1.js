import {
    r as u,
    e as T,
    j as e,
    f as Se
} from "./fg33krlcm0qyi6yw.js";
import {
    qC as ve,
    rE as ne,
    cM as Te,
    j1 as Ce,
    a5 as Ae,
    qD as De
} from "./k15yxxoybkkir2ou.js";
import {
    O as He
} from "./o589vqy9dgmjuag5.js";
import {
    p as Re,
    g as Le,
    h as Ge,
    b as Ve
} from "./iwhq2rihp0137gzf.js";
import {
    Z as Be
} from "./ce3hgmw4iyyhicud.js";
import {
    E as Oe
} from "./ovpdmx71kjznjdh8.js";
import {
    wZ as _e,
    d as se,
    k5 as re,
    bg as g,
    l as G,
    xl as Pe,
    T as je,
    uZ as Ue,
    tf as Ze,
    bb as $e,
    fZ as Fe,
    bv as ge,
    oa as ze
} from "./dykg4ktvbu3mhmdo.js";

function Ke(r) {
    const {
        doc: i,
        selection: t
    } = r, {
        $from: c,
        $to: d
    } = t, {
        pos: h
    } = c, {
        pos: f
    } = d, a = i.textBetween(h, f);
    try {
        const s = Re(i, c),
            x = Le(i, d);
        return {
            sourceFrom: s,
            sourceTo: x,
            from: h,
            to: f,
            selectedText: a
        }
    } catch (s) {
        ve.logError("Getting source selection", s)
    }
    return {
        selectedText: a,
        from: h,
        to: f
    }
}
const L = {
    type: "spring",
    bounce: .2,
    duration: .5
};

function Xe(r) {
    return r instanceof _e
}

function pt(r) {
    return r instanceof Oe
}

function Je() {
    const r = Ge(),
        i = Ve();
    return u.useMemo(() => () => {
        var t;
        return (t = r()) != null ? t : i()
    }, [r, i])
}
const ke = ({
    title: r,
    icon: i,
    size: t,
    opacity: c,
    initialHeight: d = t,
    initialScale: h = 1,
    onClick: f,
    isConfirming: a,
    isSmall: s,
    onSubmit: x
}) => {
    const p = T(),
        E = Pe(),
        [N, m] = u.useState(!1),
        y = se(re),
        V = () => {
            m(!0)
        },
        M = () => {
            m(!1)
        },
        I = e.jsx(g.div, {
            initial: {
                scale: h,
                opacity: 0
            },
            animate: {
                scale: 1,
                opacity: 1,
                transition: {
                    type: "spring",
                    bounce: .24,
                    duration: .52
                }
            },
            exit: {
                scale: .5,
                opacity: 0,
                transition: {
                    type: "spring",
                    bounce: .24,
                    duration: .52,
                    opacity: {
                        duration: .1
                    }
                }
            },
            whileHover: {
                scale: 1.15
            },
            transition: L,
            children: e.jsx(g.div, {
                className: "flex cursor-pointer items-start overflow-hidden",
                initial: {
                    width: t,
                    height: t
                },
                animate: {
                    width: t,
                    height: t
                },
                transition: L,
                onMouseEnter: V,
                onMouseLeave: M,
                children: a ? e.jsx(g.button, {
                    className: "m-auto flex h-8 w-8 items-center justify-center rounded-full bg-black text-center dark:bg-white",
                    initial: {
                        opacity: 0,
                        scale: .64
                    },
                    animate: {
                        opacity: 1,
                        scale: 1
                    },
                    exit: {
                        opacity: 0,
                        scale: .64
                    },
                    transition: {
                        type: "spring",
                        duration: .32,
                        bounce: .14
                    },
                    onClick: x,
                    children: e.jsx(ne, {
                        className: G("animate-pulsing text-white dark:text-black", s ? "icon" : "icon-lg")
                    })
                }) : i
            })
        });
    return e.jsx(g.div, {
        role: "button",
        onClick: f,
        initial: {
            height: d
        },
        animate: {
            height: t,
            opacity: a ? 1 : c != null ? c : .52
        },
        exit: {
            height: 0
        },
        whileHover: {
            opacity: 1
        },
        transition: L,
        children: y ? e.jsx(je, {
            open: E ? !!(a || N) : !1,
            label: p.formatMessage(r),
            side: "left",
            contentClassName: "pointer-events-none",
            children: I
        }) : I
    })
};

function be({
    accelerator: r,
    size: i,
    opacity: t,
    onClick: c,
    onSubmit: d,
    disableHeightAnimation: h = !1,
    disableLabel: f = !1,
    isCancelledScrubber: a = !1,
    isSmall: s = !1,
    isConfirming: x
}) {
    const {
        title: p,
        icon: E
    } = r, N = se(re), m = T();
    return e.jsxs("div", {
        className: "relative",
        children: [!N && !f && e.jsx(g.div, {
            className: "text-token-text-secondary absolute end-full top-1/2 w-[160px] -translate-y-1/2 transform pe-4 text-end text-sm",
            initial: {
                opacity: 0
            },
            animate: {
                opacity: 1
            },
            exit: {
                opacity: 0
            },
            transition: {
                duration: .2
            },
            children: m.formatMessage(p)
        }), e.jsx(ke, {
            size: i,
            onClick: c,
            opacity: t,
            initialHeight: a || h ? "auto" : 0,
            initialScale: a ? .88 : .5,
            title: p,
            isSmall: s,
            isConfirming: x,
            onSubmit: d,
            icon: e.jsx(E, {
                className: G("text-token-primary m-auto", s ? "icon" : "icon-lg")
            })
        })]
    })
}

function Qe({
    title: r,
    onSubmit: i,
    icon: t
}) {
    const c = T(),
        d = t;
    return e.jsxs(g.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        onClick: i,
        className: "text-token-text-secondary hover:text-token-text-primary flex aspect-square w-20 max-w-20 min-w-20 cursor-pointer flex-col items-center rounded-2xl p-3 transition-colors hover:bg-gray-100/75 dark:hover:bg-gray-700",
        children: [e.jsx(d, {
            className: "icon-2xl m-auto"
        }), e.jsx("div", {
            className: "line-clamp-1 w-16 max-w-16 overflow-hidden text-center text-xs",
            children: c.formatMessage(r)
        })]
    })
}

function We({
    grid: r,
    onSubmit: i,
    title: t
}) {
    const c = T();
    return e.jsxs("div", {
        className: "flex h-full flex-col content-center gap-y-4 overflow-x-hidden px-3 py-4",
        children: [e.jsx("div", {
            className: "text-token-primary mt-1 text-center font-medium",
            children: t
        }), e.jsx("div", {
            className: "flex-auto",
            children: e.jsx("div", {
                className: "grid grid-cols-2 gap-1",
                children: r.map((d, h) => e.jsx(Qe, {
                    title: d.title,
                    icon: d.icon,
                    onSubmit: f => {
                        const a = r[h];
                        "prompt" in a && (i == null || i(f, c.formatMessage(a.prompt)))
                    }
                }, h))
            })
        })]
    })
}

function Ye({
    title: r,
    onClick: i,
    isConfirming: t,
    onSubmit: c,
    isAnyItemConfirmed: d
}) {
    const h = T();
    return e.jsxs(g.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        onClick: i,
        className: G("flex-item my-1 flex min-w-40 cursor-pointer items-center overflow-hidden rounded-2xl py-2 ps-4 pe-2 font-medium text-clip whitespace-nowrap transition-colors hover:bg-gray-100/75 dark:hover:bg-gray-700", {
            "bg-gray-100/50 dark:bg-gray-700/50": t,
            "text-token-text-secondary hover:text-token-text-primary": !t && d
        }),
        children: [e.jsx("div", {
            className: "flex-auto",
            children: h.formatMessage(r)
        }), e.jsx(g.button, {
            className: G("ms-3 h-6 w-6 rounded-full bg-black text-center dark:bg-white", {
                "pointer-events-none invisible": !t
            }),
            initial: {
                opacity: 0,
                scale: .64
            },
            animate: {
                opacity: t ? 1 : 0,
                scale: t ? 1 : .64
            },
            transition: {
                type: "spring",
                duration: .32,
                bounce: .14
            },
            onClick: c,
            children: e.jsx(ne, {
                className: "icon-lg text-white dark:text-black"
            })
        })]
    })
}

function qe({
    menu: r,
    onConfirm: i,
    onSubmit: t
}) {
    const [c, d] = u.useState(!1), h = T();
    return e.jsx("div", {
        className: "h-full flex-col content-center overflow-x-hidden px-3",
        children: r.map((f, a) => e.jsx(Ye, {
            title: f.title,
            isConfirming: c === a,
            isAnyItemConfirmed: c !== !1,
            onClick: () => {
                d(a), i == null || i()
            },
            onSubmit: s => {
                const x = r[a];
                "prompt" in x && (t == null || t(s, h.formatMessage(x.prompt)))
            }
        }, "menu-item-".concat(f.title)))
    })
}
const et = r => "isCancel" in r && r.isCancel,
    we = 280;

function tt(r, i, t) {
    if (t === i) return 1;
    const c = (r - i) / (t - i);
    return Te(c, 0, 1)
}

function nt({
    size: r,
    acceleratorScrubber: i,
    onConfirm: t,
    onCancel: c,
    onSubmit: d,
    onDragStart: h,
    isConfirming: f
}) {
    const {
        icon: a
    } = i, s = "scrub" in i ? i.scrub : [], x = 6, p = r - x * 2, E = T(), N = u.useRef(null), m = u.useRef(null), [y, V] = u.useState(s ? Math.floor(s.length / 2) : 0), M = Math.round(y), I = u.useRef(y), v = s ? E.formatMessage(s[M].title) : null, C = Ue(0);
    Ze(C, "change", S => {
        const z = -137 + p / 2,
            D = (we - x) / 2 - p / 2,
            H = tt(S, z, D) * (s ? s.length - 1 : 0);
        I.current = H, V(H)
    });
    const A = () => {
            if (!s || et(s[M]) || f) return c == null ? void 0 : c();
            s && (t == null || t())
        },
        B = S => {
            S.preventDefault(), !(!s || !f || !("prompt" in s[M])) && (d == null || d(S, E.formatMessage(s[M].prompt)))
        };
    return e.jsx(g.div, {
        ref: N,
        className: "start-items relative z-20 flex w-full",
        style: {
            top: x,
            height: we - x * 2
        },
        children: e.jsx(g.div, {
            drag: "y",
            ref: m,
            dragConstraints: N,
            dragMomentum: !1,
            dragElastic: 0,
            className: G("border-token-border-default m-auto rounded-full border shadow-md transition-colors", f ? "cursor-pointer bg-black dark:bg-white" : "bg-token-main-surface-primary cursor-grab"),
            style: {
                y: C,
                width: p,
                height: p
            },
            onDragStart: h,
            onDragEnd: A,
            children: e.jsx(je, {
                open: !0,
                label: v,
                side: "right",
                children: e.jsx("div", {
                    className: "flex h-full w-full items-center justify-center overflow-hidden",
                    children: f ? e.jsx(ne, {
                        onClick: B,
                        className: "icon-xl animate-pulsing text-white dark:text-black"
                    }) : e.jsx(a, {
                        className: "text-token-primary icon-lg m-auto"
                    })
                })
            })
        })
    })
}
const W = 280,
    st = 235,
    ye = 1250,
    rt = 56,
    it = 32,
    ot = 28;

function at({
    top: r
}) {
    return e.jsx(g.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        className: "absolute start-1/2 m-auto h-1 w-1 -translate-x-1/2 rounded-full bg-gray-300",
        style: {
            top: r
        }
    })
}

function gt({
    bottom: r = 20,
    right: i = 20,
    isEmbeddedInPromptArea: t = !1,
    disableHint: c = !1,
    disableOverlay: d = !1,
    onCancel: h,
    onExpandedChange: f,
    onSubmit: a,
    isRequestActive: s = !1,
    isVisuallyHidden: x = !1,
    actions: p
}) {
    const [E, N] = u.useState(!1), [m, y] = u.useState(!c && !s), [V, M] = u.useState(!0), [I, v] = u.useState(null), [C, A] = u.useState(!1), [B, S] = u.useState(!1), [z, D] = u.useState(!1), [w, H] = u.useState(null), [P, Y] = u.useState(null), [U, q] = u.useState(null), ie = !V, oe = $e(), K = t && !m, o = K ? it : rt, ae = T(), ce = se(re), Ee = Je(), j = u.useRef(null), k = s || E, Z = s && !m && V;
    u.useEffect(() => {
        m && !B && S(!0), f == null || f(m)
    }, [m, B]), u.useEffect(() => {
        C && !k && !w && (j.current != null && clearTimeout(j.current), y(!0)), !C && !k && !w && (j.current != null && clearTimeout(j.current), j.current = window.setTimeout(() => {
            y(!1), v(null), D(!1)
        }, ye))
    }, [C, k, w, m]), u.useEffect(() => {
        if (s) {
            v(null);
            return
        }
        N(!1), !B && !c && (S(!0), y(!0), j.current != null && clearTimeout(j.current), j.current = window.setTimeout(() => {
            y(!1), v(null), D(!1), S(!0)
        }, ye))
    }, [s, c, B]);
    const ee = n => {
            v(n)
        },
        X = (n, l, b) => {
            A(!1), N(!0), y(!1), v(null), D(!1), H(null), Y(null), q(null);
            const Q = Ee(),
                pe = (_, F) => {
                    ve.logButtonClick(De.ACCELERATOR, {
                        action: {
                            action: b.action,
                            id: b.id,
                            title: b.title
                        },
                        prompt: l,
                        sourceFrom: _,
                        sourceTo: F
                    })
                };
            if (Q && Xe(Q)) {
                const {
                    state: _
                } = Q, {
                    sourceFrom: F,
                    sourceTo: te
                } = Ke(_);
                if (pe(F, te), F == null || te == null) {
                    a == null || a(n, null, l, b);
                    return
                }
                a == null || a(n, {
                    start: F,
                    end: te
                }, l, b);
                const Ie = _.tr.setSelection(ze.create(_.doc, _.selection.anchor));
                Q.dispatch(Ie);
                return
            }
            pe(), a == null || a(n, null, l, b)
        },
        J = p[0],
        Ne = p.slice(1),
        $ = !!w && p.find(({
            id: n
        }) => n === w),
        R = !!P && p.find(({
            id: n
        }) => n === P),
        O = !!U && p.find(({
            id: n
        }) => n === U),
        le = (n, l) => {
            if (ie) return;
            if (!C) {
                A(!0);
                return
            }
            const {
                id: b
            } = l;
            if ("scrub" in l) return H(b);
            if ("menu" in l) return Y(b);
            if ("grid" in l) return q(b);
            ee(b)
        },
        ue = (n, l) => {
            ie || "prompt" in l && X(n, ae.formatMessage(l.prompt), l)
        },
        Me = Ne.map(n => {
            if (!m) return null;
            const {
                id: l
            } = n;
            return e.jsx(be, {
                accelerator: n,
                isConfirming: l === I,
                isCancelledScrubber: z,
                size: o,
                onClick: b => le(b, n),
                onSubmit: b => ue(b, n)
            }, l)
        }),
        de = u.useRef(null);
    u.useEffect(() => {
        const {
            current: n
        } = de;
        if (n) return Fe(document, {
            mousedown: ({
                target: l
            }) => {
                l instanceof HTMLElement && !n.contains(l) && (y(!1), v(null), D(!1), A(!1), H(null), Y(null), q(null))
            }
        })
    }, [w, P, U]);
    const fe = Math.round(W / o) * 2,
        me = [];
    let he = 0;
    for (let n = 0; n < fe - 1; n++) he += W / fe, me.push(e.jsx(at, {
        top: he
    }));
    const xe = e.jsx(g.div, {
        ref: de,
        initial: {
            opacity: 0,
            scale: .85,
            borderRadius: o / 2
        },
        exit: {
            opacity: 0,
            borderRadius: o / 2
        },
        className: G("border-token-border-default absolute overflow-visible border transition-colors select-none", Be.accelerators, {
            "pointer-events-none": x,
            "bg-token-main-surface-primary shadow-xl": m && !w && !s,
            "bg-token-main-surface-primary shadow-lg": !m && !w && !s && !t,
            "bg-token-main-surface-primary border-transparent shadow-sm": !m && !w && !s && t,
            "bg-token-main-surface-secondary border-transparent": w && !s,
            "bg-token-main-surface-primary": s && !Z,
            "bg-black! text-white!": !oe && Z,
            "bg-white! text-black!": oe && Z
        }),
        style: {
            right: i,
            bottom: r
        },
        animate: {
            scale: k || Z || E ? .85 : 1,
            opacity: x ? 0 : 1,
            borderRadius: P && R && !k || U && O && !k ? ot : o / 2
        },
        onHoverStart: () => {
            j.current != null && clearTimeout(j.current), A(!0)
        },
        onHoverEnd: () => A(!1),
        children: e.jsx(ge, {
            children: P && R && "menu" in R && !k ? e.jsx(g.div, {
                initial: {
                    height: o,
                    width: o
                },
                transition: L,
                animate: {
                    height: W,
                    width: "auto"
                },
                exit: {
                    height: o,
                    width: o
                },
                children: e.jsx(qe, {
                    isConfirming: I === R.id,
                    onConfirm: () => ee(R.id),
                    onSubmit: (n, l) => X(n, l, R),
                    menu: R.menu
                })
            }) : U && O && "grid" in O && !k ? e.jsx(g.div, {
                initial: {
                    height: o,
                    width: o
                },
                transition: L,
                animate: {
                    height: st,
                    width: "auto"
                },
                exit: {
                    height: o,
                    width: o
                },
                children: e.jsx(We, {
                    title: ae.formatMessage(O.title),
                    onSubmit: (n, l) => X(n, l, O),
                    grid: O.grid
                })
            }) : w && $ && !k ? e.jsxs(g.div, {
                initial: {
                    height: o,
                    width: o
                },
                transition: L,
                animate: {
                    height: W,
                    width: o
                },
                exit: {
                    height: o,
                    width: o
                },
                onClick: () => {
                    v(null)
                },
                children: [e.jsx(nt, {
                    onDragStart: () => v(null),
                    isConfirming: I === $.id,
                    onConfirm: () => ee($.id),
                    onSubmit: (n, l) => X(n, l, $),
                    onCancel: () => {
                        H(null), D(!0)
                    },
                    size: o,
                    acceleratorScrubber: $
                }), me]
            }) : e.jsxs(g.div, {
                className: "flex flex-col",
                initial: t ? !1 : {
                    height: o,
                    width: o
                },
                transition: L,
                animate: {
                    height: m ? o * p.length : o,
                    width: o
                },
                exit: {
                    height: o,
                    width: o
                },
                onAnimationComplete: () => M(!0),
                onAnimationStart: () => M(!1),
                children: [e.jsx(ge, {
                    children: Me
                }), e.jsx("div", {
                    className: "flex items-center",
                    style: {
                        width: o,
                        height: o
                    },
                    children: k ? Z ? e.jsx(ke, {
                        title: ct.cancel,
                        icon: e.jsx(Ce, {
                            className: G("animate-pulsing m-auto shrink-0", K ? "h-6 w-6" : "h-10 w-10")
                        }),
                        isSmall: K,
                        opacity: 1,
                        size: o,
                        onClick: () => {
                            v(null), h == null || h()
                        }
                    }) : e.jsx(Ae, {
                        size: 20,
                        className: "text-token-text-secondary m-auto"
                    }) : e.jsx(be, {
                        disableHeightAnimation: t,
                        disableLabel: ce || !m,
                        isCancelledScrubber: z,
                        accelerator: J,
                        isConfirming: I === J.id,
                        opacity: m ? void 0 : 1,
                        isSmall: K,
                        size: o,
                        onSubmit: n => ue(n, J),
                        onClick: n => le(n, J)
                    })
                })]
            })
        })
    });
    return d || ce ? xe : e.jsxs(e.Fragment, {
        children: [m && e.jsx(He, {
            zIndexKey: "acceleratorsOverlay",
            className: "bg-white/95 dark:bg-black/85"
        }), xe]
    })
}
const ct = Se({
    cancel: {
        id: "Hov840",
        defaultMessage: "Cancel"
    }
});
export {
    gt as D, pt as a, Ke as g, Xe as i, Je as u
};
//# sourceMappingURL=eaak105t3h6pgvs1.js.map