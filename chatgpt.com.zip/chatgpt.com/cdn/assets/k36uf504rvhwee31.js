import {
    H as t,
    p as i,
    n as p,
    m as r,
    a as n,
    l as h,
    y as g,
    x as o,
    w as m,
    v as c,
    t as u,
    s as f,
    b,
    c as v,
    d as y,
    r as j,
    e as w,
    f as x,
    g as d,
    h as k,
    i as q,
    j as A,
    k as C,
    o as H,
    q as J,
    u as L,
    z as N,
    A as O,
    B as R,
    C as z,
    D as B,
    E as D,
    F as E,
    G as F,
    I as G,
    J as I,
    K,
    L as M,
    M as P,
    N as Q,
    O as S,
    P as T,
    Q as U,
    R as V
} from "./j37p94g6trtb4j3z.js";
import "./fg33krlcm0qyi6yw.js";
import "./lad8yx56mqsdspc9.js";
const W = {
    arduino: V,
    bash: U,
    c: T,
    cpp: S,
    csharp: Q,
    css: P,
    diff: M,
    go: K,
    graphql: I,
    ini: G,
    java: F,
    javascript: E,
    json: D,
    kotlin: B,
    less: z,
    lua: R,
    makefile: O,
    markdown: N,
    objectivec: L,
    perl: J,
    php: H,
    "php-template": C,
    plaintext: A,
    powershell: q,
    python: k,
    "python-repl": d,
    r: x,
    ruby: w,
    rust: j,
    scss: y,
    shell: v,
    sql: b,
    swift: f,
    typescript: u,
    vbnet: c,
    wasm: m,
    xml: o,
    yaml: g,
    latex: h,
    mathematica: n,
    matlab: r,
    nginx: p,
    pgsql: i
};
for (const [s, a] of Object.entries(W)) t.registerLanguage(s, a);
t.registerAliases(["wolfram"], {
    languageName: "mathematica"
});

function _(s, a) {
    if (a) {
        const {
            value: e
        } = t.highlight(s, {
            language: a
        });
        return {
            html: e,
            language: a
        }
    } else {
        const {
            value: e,
            language: l
        } = t.highlightAuto(s);
        return {
            html: e,
            language: l
        }
    }
}
export {
    _ as highlightCode
};
//# sourceMappingURL=k36uf504rvhwee31.js.map