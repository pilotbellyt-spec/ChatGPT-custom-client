var q = Object.defineProperty,
    v = Object.defineProperties;
var J = Object.getOwnPropertyDescriptors;
var Y = Object.getOwnPropertySymbols;
var K = Object.prototype.hasOwnProperty,
    Q = Object.prototype.propertyIsEnumerable;
var z = (t, e, a) => e in t ? q(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: a
    }) : t[e] = a,
    $ = (t, e) => {
        for (var a in e || (e = {})) K.call(e, a) && z(t, a, e[a]);
        if (Y)
            for (var a of Y(e)) Q.call(e, a) && z(t, a, e[a]);
        return t
    },
    I = (t, e) => v(t, J(e));
import {
    c as M,
    j as c,
    r as R,
    e as U
} from "./fg33krlcm0qyi6yw.js";
import {
    b as W,
    d as X,
    dB as D,
    iW as w,
    tY as S,
    aY as ee,
    C as se,
    tZ as te,
    p8 as le,
    p7 as ae
} from "./dykg4ktvbu3mhmdo.js";
import {
    iS as re,
    j$ as G,
    e1 as oe,
    e2 as ne,
    iR as ce,
    jc as ie,
    k0 as k,
    k1 as de,
    k2 as ue,
    e0 as H,
    e3 as fe,
    bP as pe
} from "./k15yxxoybkkir2ou.js";
import {
    T as O
} from "./iw47v9tf328v3kli.js";
const me = t => {
        "use forget";
        const e = M.c(11),
            {
                cardId: a
            } = t,
            l = W();
        let d;
        e[0] !== a || e[1] !== l ? (d = () => re(l).find(N => N.id === a), e[0] = a, e[1] = l, e[2] = d) : d = e[2];
        const o = X(d);
        if (!o) return null;
        const r = o.conversation_id ? o.conversation_id : void 0;
        if (!r) return null;
        let s;
        e[3] !== r || e[4] !== l ? (s = D(l, r), e[3] = r, e[4] = l, e[5] = s) : s = e[5];
        let n;
        e[6] !== s ? (n = c.jsx(O, {
            conversation: s,
            className: "min-h-0! flex-1",
            hideDisclaimer: !0
        }), e[6] = s, e[7] = n) : n = e[7];
        let f;
        return e[8] !== r || e[9] !== n ? (f = c.jsx(G, {
            clientThreadId: r,
            threadContent: n
        }), e[8] = r, e[9] = n, e[10] = f) : f = e[10], f
    },
    xe = () => {
        "use forget";
        const t = M.c(14),
            e = W();
        let a;
        t[0] !== e ? (a = () => oe(e), t[0] = e, t[1] = a) : a = t[1];
        const l = X(a);
        let d, o;
        if (t[2] !== l || t[3] !== e ? (d = () => {
                ne(e).logEventWithStatsig("(Web) FYP Feedback Conversation Shown", "chatgpt_web_fyp_feedback_conversation_shown", {
                    feedback_conversation_id: l
                })
            }, o = [e, l], t[2] = l, t[3] = e, t[4] = d, t[5] = o) : (d = t[4], o = t[5]), R.useEffect(d, o), !l) return null;
        let r;
        t[6] !== l || t[7] !== e ? (r = D(e, l), t[6] = l, t[7] = e, t[8] = r) : r = t[8];
        let s;
        t[9] !== r ? (s = c.jsx(O, {
            conversation: r,
            className: "min-h-0! flex-1",
            hideDisclaimer: !0,
            withCustomCompletionParams: be
        }), t[9] = r, t[10] = s) : s = t[10];
        let n;
        return t[11] !== l || t[12] !== s ? (n = c.jsx(G, {
            clientThreadId: l,
            shouldScrollToBottom: !0,
            threadContent: s
        }), t[11] = l, t[12] = s, t[13] = n) : n = t[13], n
    };

function be(t) {
    var e;
    return I($({}, t), {
        extraStreamParams: I($({}, t.extraStreamParams), {
            pulseCompletionParams: I($({}, (e = t.extraStreamParams) == null ? void 0 : e.pulseCompletionParams), {
                type: "feedback-conversation"
            })
        })
    })
}

function Fe(t) {
    "use forget";
    const e = M.c(40),
        {
            type: a,
            setWidth: l
        } = t,
        d = a === void 0 ? "sidebar" : a,
        o = W();
    let r;
    e[0] !== o ? (r = () => H(o).viewState$(), e[0] = o, e[1] = r) : r = e[1];
    const s = X(r),
        {
            closeView: n
        } = ce(),
        f = U(),
        N = R.useRef(null),
        {
            goBack: T,
            canGoBack: B
        } = ie();
    let h;
    e[2] !== o || e[3] !== T ? (h = () => {
        H(o).openFeedbackView({
            type: fe.Preview
        }), T()
    }, e[2] = o, e[3] = T, e[4] = h) : h = e[4];
    const L = h,
        Z = ke;
    let y;
    e[5] !== n || e[6] !== o || e[7] !== (s == null ? void 0 : s.type) ? (y = () => {
        (s == null ? void 0 : s.type) === k.Card ? n() : (s == null ? void 0 : s.type) === k.Feedback && H(o).closeFeedbackView()
    }, e[5] = n, e[6] = o, e[7] = s == null ? void 0 : s.type, e[8] = y) : y = e[8];
    const u = y;
    let P, g;
    e[9] !== l ? (P = () => w(() => Z(), i => l == null ? void 0 : l(i), {
        fireImmediately: !0
    }), g = [l], e[9] = l, e[10] = P, e[11] = g) : (P = e[10], g = e[11]), R.useEffect(P, g);
    let j;
    e[12] !== (s == null ? void 0 : s.cardId) || e[13] !== (s == null ? void 0 : s.type) ? (j = (s == null ? void 0 : s.type) === k.Card ? c.jsx(me, {
        cardId: s == null ? void 0 : s.cardId
    }) : (s == null ? void 0 : s.type) === k.Feedback ? c.jsx(xe, {}) : null, e[12] = s == null ? void 0 : s.cardId, e[13] = s == null ? void 0 : s.type, e[14] = j) : j = e[14];
    const A = j;
    let F;
    e[15] !== s ? (F = (s == null ? void 0 : s.type) === k.Feedback ? c.jsx(de, {
        feedbackState: s.feedbackState,
        className: "backdrop-blur-xl backdrop-filter"
    }) : (s == null ? void 0 : s.type) === k.Card ? c.jsx(ue, {
        className: "backdrop-blur-xl backdrop-filter"
    }) : null, e[15] = s, e[16] = F) : F = e[16];
    const E = F;
    let p;
    e[17] !== B || e[18] !== L ? (p = B && c.jsx(S, {
        onClick: L,
        className: ""
    }), e[17] = B, e[18] = L, e[19] = p) : p = e[19];
    let m;
    e[20] !== u ? (m = c.jsx(ee, {
        className: "backdrop-blur-xl backdrop-filter",
        onClick: u
    }), e[20] = u, e[21] = m) : m = e[21];
    let x;
    e[22] !== E || e[23] !== m ? (x = c.jsxs("div", {
        className: "ms-auto flex items-center gap-1",
        children: [E, m]
    }), e[22] = E, e[23] = m, e[24] = x) : x = e[24];
    let b;
    e[25] !== x || e[26] !== p ? (b = c.jsxs("div", {
        className: "fixed inset-x-0 top-0 z-50 flex items-center p-2",
        children: [p, x]
    }), e[25] = x, e[26] = p, e[27] = b) : b = e[27];
    let V;
    e[28] !== A || e[29] !== b ? (V = c.jsxs("div", {
        className: "relative flex h-full flex-col overflow-auto",
        children: [b, A]
    }), e[28] = A, e[29] = b, e[30] = V) : V = e[30];
    const C = V;
    switch (d) {
        case "sidebar":
            {
                let i;e[31] !== f ? (i = f.formatMessage({
                    id: "pulse.sidebar.title",
                    defaultMessage: "Pulse"
                }), e[31] = f, e[32] = i) : i = e[32];
                let _;
                return e[33] !== C || e[34] !== u || e[35] !== i ? (_ = c.jsx(pe, {
                    handleClose: u,
                    renderLeading: Ce,
                    ariaLabel: i,
                    scrollMode: "content-only",
                    children: C
                }, "pulse-sidebar"), e[33] = C, e[34] = u, e[35] = i, e[36] = _) : _ = e[36],
                _
            }
        case "modal":
            {
                let i;
                return e[37] !== C || e[38] !== u ? (i = c.jsx(se, {
                    testId: "modal-chat-screen-pulse-flyout",
                    className: "relative max-w-[500px]",
                    size: "custom",
                    type: "success",
                    position: "end",
                    noPadding: !0,
                    contentRef: N,
                    visuallyHiddenHeader: !0,
                    showCloseButton: !0,
                    isOpen: !0,
                    onClose: u,
                    children: C
                }, "pulse-modal"), e[37] = C, e[38] = u, e[39] = i) : i = e[39],
                i
            }
    }
}

function Ce() {
    return null
}

function ke() {
    return te() ? "700px" : le() ? "500px" : (ae(), "400px")
}
export {
    Fe as P
};
//# sourceMappingURL=omxv5qehu9kgsx7t.js.map