import {
    c as e,
    jx as a,
    s
} from "./dykg4ktvbu3mhmdo.js";
const r = e(a, "9e013b", 24, 24),
    n = e(s, "0aed53", 20, 20);
export {
    r as E, n as S
};
//# sourceMappingURL=g63j6um9azgogw0s.js.map