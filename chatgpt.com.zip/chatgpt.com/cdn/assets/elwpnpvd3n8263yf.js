var z = Object.defineProperty;
var O = Object.getOwnPropertySymbols;
var B = Object.prototype.hasOwnProperty,
    K = Object.prototype.propertyIsEnumerable;
var H = (t, e, r) => e in t ? z(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : t[e] = r,
    C = (t, e) => {
        for (var r in e || (e = {})) B.call(e, r) && H(t, r, e[r]);
        if (O)
            for (var r of O(e)) K.call(e, r) && H(t, r, e[r]);
        return t
    };
import {
    c as q,
    A as v,
    r as G
} from "./fg33krlcm0qyi6yw.js";
import {
    b2 as $,
    e as Q,
    ro as V,
    t0 as X,
    nk as Y,
    b as Z,
    r as ee,
    t1 as te,
    b1 as re,
    b3 as ne
} from "./dykg4ktvbu3mhmdo.js";

function se() {
    "use forget";
    const t = q.c(5);
    let e, r;
    t[0] === Symbol.for("react.memo_cache_sentinel") ? (e = Q(), r = $(e), t[0] = e, t[1] = r) : (e = t[0], r = t[1]);
    const {
        session: a
    } = r;
    let n;
    t[2] === Symbol.for("react.memo_cache_sentinel") ? (n = () => {
        var d;
        return (d = a == null ? void 0 : a.authProvider) != null ? d : V(e, typeof window < "u" ? new URLSearchParams(window.location.search) : new URLSearchParams)
    }, t[2] = n) : n = t[2], a == null || a.authProvider;
    const k = n;
    let g;
    t[3] === Symbol.for("react.memo_cache_sentinel") ? (g = d => {
        var h;
        const m = d === void 0 ? {} : d,
            i = (h = m.authProvider) != null ? h : k();
        return v.signIn(i, {
            callbackUrl: m.callbackUrl
        }, X({
            deviceID: Y(),
            user: a == null ? void 0 : a.user,
            params: m.authorizationParams
        }))
    }, t[3] = g) : g = t[3], a == null || a.user;
    const c = g;
    let w;
    return t[4] === Symbol.for("react.memo_cache_sentinel") ? (w = {
        signInForReauth: c
    }, t[4] = w) : w = t[4], w
}

function J() {
    var e;
    return typeof window < "u" && !!((e = window.location) != null && e.origin) ? window.location.origin : "https://chatgpt.com"
}
const ae = 240;

function I(t) {
    if (!t) throw new Error("No session found, cannot enable MFA");
    if (t.authProvider === "mocked") throw new Error("Mock users can't enable MFA! Please setup Auth0 following the instructions in the README")
}

function oe(t) {
    try {
        return ee(t)
    } catch (e) {
        throw new Error("Unable to decode access token")
    }
}

function ie(t) {
    return t.pwd_auth_time
}

function ce(t) {
    const e = ie(t);
    if (!e) return !0;
    const r = e / 1e3;
    return Date.now() / 1e3 - r > ae
}

function le(t) {
    var e;
    return ((e = t[te]) == null ? void 0 : e.required) === "yes"
}
var ue = (t => (t.PushAuth = "push_auth", t.Totp = "totp", t.Sms = "sms", t))(ue || {}),
    fe = (t => (t.Enable = "enable", t.Disable = "disable", t))(fe || {});

function j() {
    var a;
    const t = J(),
        e = new URL("/", t);
    if (typeof window < "u" && ((a = window.location) == null ? void 0 : a.pathname) === "/security-settings") e.pathname = "/security-settings", e.hash = "";
    else {
        const n = re(ne.Security).hash;
        e.hash = n || "settings"
    }
    return e
}

function D(t) {
    const e = j(),
        r = new URLSearchParams;
    return r.set("action", "enable"), r.set("factor", t), e.search = r.toString(), e.toString()
}

function W(t) {
    const e = j(),
        r = new URLSearchParams;
    return r.set("action", "disable"), r.set("factor_id", t), e.search = r.toString(), e.toString()
}

function _e(t) {
    "use forget";
    var x, F;
    const e = q.c(18),
        r = Z();
    let a;
    e[0] !== r ? (a = $(r), e[0] = r, e[1] = a) : a = e[1];
    const {
        session: n
    } = a, {
        signInForReauth: k
    } = se(), [g, c] = G.useState(!1), w = ((x = n == null ? void 0 : n.user) == null ? void 0 : x.idp) === "auth0", d = !!((F = n == null ? void 0 : n.user) != null && F.mfa);
    let m;
    e[2] !== n || e[3] !== k ? (m = async (p, s, o, l, u, T) => {
        var y, P;
        const S = s === void 0 ? !1 : s;
        I(n);
        let f = !0;
        if (n != null && n.accessToken) {
            const _ = oe(n.accessToken);
            f = ce(_) || S && !le(_)
        }
        if (f) {
            c(!0);
            const _ = C({
                type: "refresh",
                action: o,
                factor: l
            }, u != null ? {
                factorId: u
            } : {});
            return T && typeof window < "u" && window.SecurityNative ? window.SecurityNative.postMessage(btoa(JSON.stringify(_))) : T && ((P = (y = window.webkit) == null ? void 0 : y.messageHandlers) != null && P.securityNative) ? window.webkit.messageHandlers.securityNative.postMessage(btoa(JSON.stringify(_))) : k({
                callbackUrl: p
            }), !0
        }
        return !1
    }, e[2] = n, e[3] = k, e[4] = m) : m = e[4];
    const i = m;
    let h;
    e[5] !== i || e[6] !== t.redirectUrl || e[7] !== n ? (h = async (p, s) => {
        var S, f, y, P, _;
        const o = p === void 0 ? "totp" : p;
        I(n), c(!0);
        const l = J();
        if (o === "totp") {
            if (!(s != null && s.native_modal)) {
                const M = new URL("/auth/enroll_mfa", l);
                M.searchParams.set("factor", o), t.redirectUrl && M.searchParams.set("redirect_path", t.redirectUrl);
                const N = M.toString();
                return await i(N, !1, "enable", "totp", null, (S = s == null ? void 0 : s.mobile_webview) != null ? S : !1) ? !0 : (window.location.href = N, c(!1), !1)
            }
            const U = D("totp");
            return await i(U, !1, "enable", "totp", null, (f = s == null ? void 0 : s.mobile_webview) != null ? f : !1) ? !0 : (c(!1), !1)
        }
        if (o === "passkey") {
            const U = new URL("/auth/enroll_mfa", l);
            U.searchParams.set("factor", o), t.redirectUrl && U.searchParams.set("redirect_path", t.redirectUrl);
            const L = U.toString();
            return await i(L, !1, "enable", "passkey", null, (y = s == null ? void 0 : s.mobile_webview) != null ? y : !1) ? !0 : (window.location.href = L, c(!1), !1)
        }
        if (o === "push_auth") {
            const U = D("push_auth");
            return await i(U, !1, "enable", "push_auth", null, (P = s == null ? void 0 : s.mobile_webview) != null ? P : !1) ? !0 : (c(!1), !1)
        }
        const u = D("sms");
        return await i(u, !1, "enable", "sms", null, (_ = s == null ? void 0 : s.mobile_webview) != null ? _ : !1) ? !0 : (c(!1), !1)
    }, e[5] = i, e[6] = t.redirectUrl, e[7] = n, e[8] = h) : h = e[8];
    const A = h;
    let E;
    e[9] !== i || e[10] !== n ? (E = async (p, s, o) => {
        var T, S;
        const l = p === void 0 ? "totp" : p,
            u = s === void 0 ? "" : s;
        if (I(n), l === "push_auth" || l === "sms" || l === "totp") {
            if (!u) throw new Error("Factor ID is required for MFA factor removal");
            const f = W(u);
            return await i(f, !0, "disable", l, u, (T = o == null ? void 0 : o.mobile_webview) != null ? T : !1) ? !0 : (c(!1), !1)
        }
        if (l === "passkey") {
            if (!u) throw new Error("Factor ID is required for MFA factor removal");
            const f = new URL(W(u));
            return f.searchParams.set("factor", "passkey"), await i(f.toString(), !0, "disable", "passkey", u, (S = o == null ? void 0 : o.mobile_webview) != null ? S : !1) ? !0 : (c(!1), !1)
        }
        throw new Error("Failed to remove invalid factor type:" + l)
    }, e[9] = i, e[10] = n, e[11] = E) : E = e[11];
    const b = E;
    let R;
    return e[12] !== g || e[13] !== d || e[14] !== w || e[15] !== b || e[16] !== A ? (R = {
        setupMfa: A,
        isUsernamePassword: w,
        isLoggedInWithMfa: d,
        removeMfa: b,
        isLoadingRedirect: g
    }, e[12] = g, e[13] = d, e[14] = w, e[15] = b, e[16] = A, e[17] = R) : R = e[17], R
}
export {
    fe as M, ue as a, se as b, _e as u
};
//# sourceMappingURL=elwpnpvd3n8263yf.js.map