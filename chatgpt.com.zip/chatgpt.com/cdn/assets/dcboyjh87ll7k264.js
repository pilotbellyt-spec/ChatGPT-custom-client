const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/bi8yc1kfvs31a44q.js", "assets/fg33krlcm0qyi6yw.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css"]))) => i.map(i => d[i]);
var oe = Object.freeze,
    ce = Object.defineProperty,
    We = Object.defineProperties;
var Ae = Object.getOwnPropertyDescriptors;
var E = Object.getOwnPropertySymbols;
var de = Object.prototype.hasOwnProperty,
    ue = Object.prototype.propertyIsEnumerable;
var re = (e, t, a) => t in e ? ce(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: a
    }) : e[t] = a,
    A = (e, t) => {
        for (var a in t || (t = {})) de.call(t, a) && re(e, a, t[a]);
        if (E)
            for (var a of E(t)) ue.call(t, a) && re(e, a, t[a]);
        return e
    },
    P = (e, t) => We(e, Ae(t));
var me = (e, t) => {
    var a = {};
    for (var l in e) de.call(e, l) && t.indexOf(l) < 0 && (a[l] = e[l]);
    if (e != null && E)
        for (var l of E(e)) t.indexOf(l) < 0 && ue.call(e, l) && (a[l] = e[l]);
    return a
};
var pe = (e, t) => oe(ce(e, "raw", {
    value: oe(t || e.slice())
}));
import {
    j as s,
    _ as De,
    r as x,
    e as $e
} from "./fg33krlcm0qyi6yw.js";
import {
    f0 as Pe,
    f9 as Oe,
    f4 as ze,
    cX as Y,
    ef as Be,
    ej as ee,
    hd as ye,
    kh as Ge,
    f5 as Q,
    ki as Re,
    e$ as Ue,
    kj as ve,
    kk as Ee,
    eW as fe,
    kl as Ie,
    aw as He,
    eT as je,
    km as ke
} from "./k15yxxoybkkir2ou.js";
import {
    l as C,
    F as Ve,
    bh as qe,
    ba as Je,
    k as Ke,
    t_ as Xe,
    hh as Ye,
    o as U,
    b as V,
    fN as Qe,
    ny as Ne,
    cU as Ze,
    hd as et,
    nw as tt,
    d as te,
    bL as st,
    iK as G,
    bb as we,
    id as at,
    f8 as lt,
    T as Te,
    eo as nt,
    da as it,
    de as ot,
    bg as H,
    oO as rt,
    fZ as ct,
    t$ as dt,
    oF as ut
} from "./dykg4ktvbu3mhmdo.js";
import {
    u as mt
} from "./l09h2qppleubii6l.js";
import {
    u as pt,
    a as ft
} from "./c1lw0j14sexsyj33.js";
import {
    s as xt
} from "./jbh6ambg0gcrgcqd.js";

function xe(e, t, a, l, n = !1, p = void 0) {
    var F, y, b, j;
    const i = n != null ? n : !1,
        c = Pe(a) || i,
        f = Oe(a),
        {
            Icon: r,
            appName: o
        } = ze({
            cloud_doc_url: e.cloud_doc_url,
            connectorId: e.connector_id,
            availableConnectors: p,
            iconClassName: t
        }),
        u = e.name,
        m = o != null ? o : l.formatMessage({
            id: "bqY3sN",
            defaultMessage: "File"
        });
    let h = e.cloud_doc_url ? e.cloud_doc_url : "";
    f && ((F = e.medical_file_reference) != null && F.journal_homepage_url) && (h = (y = e.medical_file_reference) == null ? void 0 : y.journal_homepage_url);
    let _ = (b = r || (e.cloud_doc_url ? s.jsx(Y, {
        alt: m,
        className: t
    }) : void 0)) != null ? b : s.jsx(Be, {
        alt: m,
        className: t
    });
    return c && h.length > 0 && (_ = s.jsx(ee, {
        url: h,
        className: t,
        fallback: s.jsx(Y, {
            alt: m,
            className: t
        })
    })), {
        fileName: u,
        fileTypeDisplayName: m,
        fileTypeIcon: _,
        url: e.cloud_doc_url,
        snippet: (j = e.description) != null ? j : e.snippet,
        fileLastModifiedTime: e.last_modified_time
    }
}
const he = qe(() => De(() =>
        import ("./bi8yc1kfvs31a44q.js"), __vite__mapDeps([0, 1, 2, 3])).then(e => e.FilePreviewModal)),
    be = 32;

function Fe(e) {
    const t = e.split(".");
    let a = e;
    return t.length > 1 && t.slice(0, -1).some(l => l.length > 0) && (a = t.slice(0, -1).join(".")), a.length > be && (a = a.slice(0, be - 1) + "…"), a
}

function ht({
    additionalFileRefs: e,
    fileRef: t,
    index: a,
    trackContentReferenceEvent: l
}) {
    var k, w, N, W, S, D, v;
    const n = Je(Ke),
        p = Xe(),
        i = x.useContext(ye),
        c = (k = i == null ? void 0 : i.clientThreadId) != null ? k : i == null ? void 0 : i.analyticsMetadata.clientThreadId,
        f = Ye(c),
        r = (N = (w = i == null ? void 0 : i.analyticsMetadata.threadId) != null ? w : f) != null ? N : c,
        o = V(),
        u = (W = U(o, "1878635359")) != null ? W : !1,
        m = x.useMemo(() => ({
            source: t.source,
            index: a
        }), [t.source, a]);
    x.useEffect(() => {
        l("File Citation Shown", "file_citation_shown", "file", m)
    }, []);
    const h = x.useCallback(g => {
            g ? l("File Citation Hovered", "file_citation_hovered", "file", m) : l("File Citation Unhovered", "file_citation_unhovered", "file", m)
        }, [m, l]),
        _ = x.useCallback(() => {
            l("File Citation Clicked", "file_citation_clicked", "file", m)
        }, [m, l]),
        F = x.useCallback(() => {
            l("File Citation Followup Clicked", "file_citation_followup_clicked", "file", m)
        }, [m, l]),
        y = Qe((S = i == null ? void 0 : i.analyticsMetadata.clientThreadId) != null ? S : Ne, g => g == null ? void 0 : g.mode),
        b = Ge(y) ? y.gizmo_id : void 0,
        j = typeof((v = (D = i == null ? void 0 : i.message) == null ? void 0 : D.metadata) == null ? void 0 : v.gizmo_id) == "string" ? i.message.metadata.gizmo_id : void 0,
        d = x.useCallback(() => {
            u ? Ze(o, he, {
                gizmoId: b,
                fileId: t.id,
                fileName: t.name,
                clientThreadId: r,
                onClose: () => et(o, he)
            }) : p(t.id, t.name, {
                conversationId: r,
                gizmoId: b
            })
        }, [b, r, o, p, u, t.id, t.name]);
    return n && Q(t.id) || b && tt(b) ? null : j && b !== j && !t.cloud_doc_url ? s.jsx("span", {
        className: C(xt, "ms-1"),
        title: t.name,
        children: Fe(t.name)
    }) : s.jsx(bt, {
        additionalFileRefs: e,
        fileItem: t,
        onClickFileReference: d,
        trackCloudLinkClick: _,
        trackFileCitationFollowup: F,
        trackTooltipOpenChange: h
    })
}
var _e;
const Z = Ve.p(_e || (_e = pe(["not-prose mt-0! mb-0! flex-auto truncate"])));

function Se({
    className: e,
    isBetaMedicalRetrieval: t,
    disableMarginStart: a
} = {}) {
    let l = C(a ? null : "ms-1", "flex h-[25px] text-[10px] leading-[13px] rounded-xl corner-superellipse/1.1 items-center justify-center gap-1 px-2 relative", "text-token-text-secondary! hover:text-token-text-primary! hover:bg-token-bg-secondary dark:bg-token-main-surface-secondary dark:hover:bg-token-bg-secondary", e);
    return t || (l += " bg-[#f4f4f4] "), l
}

function bt({
    additionalFileRefs: e,
    className: t,
    fileItem: a,
    onClickFileReference: l,
    trackCloudLinkClick: n,
    trackFileCitationFollowup: p,
    trackTooltipOpenChange: i
}) {
    var g, z;
    const c = $e(),
        f = V(),
        r = Ue(),
        o = !!(U(f, "1424158285") || r),
        u = te(() => st(f, {
            skipLogos: !1
        })),
        {
            fileName: m,
            fileTypeDisplayName: h,
            fileTypeIcon: _,
            url: F,
            snippet: y
        } = xe(a, "h-[16px] w-[16px] object-contain text-token-text-primary! flex-none", f, c, r, u),
        b = x.useMemo(() => {
            var B;
            const M = {
                    fileItem: a,
                    fileName: m,
                    fileTypeDisplayName: h,
                    fileTypeIcon: _,
                    url: F,
                    snippet: y
                },
                T = (B = e == null ? void 0 : e.map(R => {
                    const $ = xe(R, "h-[16px] w-[16px] object-contain", f, c, r, u);
                    return {
                        fileItem: R,
                        fileName: $.fileName,
                        fileTypeDisplayName: $.fileTypeDisplayName,
                        fileTypeIcon: $.fileTypeIcon,
                        url: $.url,
                        snippet: $.snippet
                    }
                })) != null ? B : [];
            return [M, ...T]
        }, [a, m, h, _, F, y, e, f, c, r, u]),
        j = x.useMemo(() => {
            const M = new Map;
            for (const T of b) {
                const B = "".concat(T.fileName, "-").concat(T.url, "-").concat(T.snippet);
                M.set(B, T)
            }
            return Array.from(M.values())
        }, [b]),
        d = x.useMemo(() => j.filter(M => !!M.url || Q(M.fileItem.id)), [j]);
    if (d.length === 0) return null;
    const k = d[0],
        w = Se({
            className: t,
            isBetaMedicalRetrieval: o
        }),
        N = k.fileItem,
        W = o && N.medical_file_reference !== null && ((g = N.medical_file_reference) == null ? void 0 : g.journal_name) !== null ? (z = N.medical_file_reference) == null ? void 0 : z.journal_name : k.fileName,
        S = Math.max(d.length - 1, 0),
        D = "".concat(Fe(W)).concat(S > 0 ? " +".concat(S) : ""),
        v = s.jsx("span", {
            className: "relative inline-flex items-center",
            children: k.url ? s.jsxs(G, {
                href: k.url,
                className: w,
                onClick: n,
                children: [k.fileTypeIcon, s.jsx(Z, {
                    children: D
                })]
            }) : Q(k.fileItem.id) ? s.jsxs("button", {
                onClick: l,
                className: w,
                children: [k.fileTypeIcon, s.jsx(Z, {
                    children: D
                })]
            }) : s.jsx("span", {
                className: w,
                children: s.jsx(Y, {})
            })
        });
    return s.jsx(gt, {
        items: d,
        contentType: k.fileTypeDisplayName,
        trackFileCitationFollowup: p,
        trackTooltipOpenChange: i,
        children: v
    })
}

function gt({
    items: e,
    children: t,
    contentType: a,
    trackFileCitationFollowup: l,
    trackTooltipOpenChange: n
}) {
    var b, j, d, k;
    const p = we(),
        i = x.useContext(ye),
        c = (b = i == null ? void 0 : i.clientThreadId) != null ? b : Ne,
        f = at(),
        r = V(),
        o = U(r, "1424158285"),
        u = U(r, "733205176"),
        h = lt({
            id: (k = (d = (j = i == null ? void 0 : i.message) == null ? void 0 : j.metadata) == null ? void 0 : d.model_slug) != null ? k : ""
        }, r) || U(r, "2137702454"),
        _ = pt(c, e[0].fileItem.id, e[0].fileName, e[0].url),
        F = x.useCallback((w, N) => {
            N.length && (_(w, N), l == null || l())
        }, [_, l]),
        y = () => {
            var w, N, W;
            return h ? s.jsx("div", {
                className: "max-h-[420px] max-w-sm min-w-xs overflow-y-auto p-2",
                children: e.map(({
                    fileItem: S,
                    fileName: D,
                    snippet: v,
                    url: g
                }) => {
                    var z, M, T;
                    return s.jsxs(G, {
                        href: g,
                        className: C("text-token-text-primary flex flex-col gap-1 rounded-md p-2 text-start text-xs font-normal no-underline!"),
                        children: [s.jsxs("div", {
                            className: "flex items-center gap-1.5",
                            children: [s.jsx("div", {
                                className: "icon-sm h-4 w-4 shrink-0 items-center overflow-hidden rounded-full",
                                children: e[0].fileTypeIcon
                            }), s.jsx("div", {
                                className: "text-token-text-secondary line-clamp-1 text-sm",
                                children: o ? (z = e[0].fileItem.medical_file_reference) == null ? void 0 : z.journal_name : a
                            })]
                        }), s.jsx("div", {
                            className: C("text-sm font-medium break-all", v ? "line-clamp-1" : "line-clamp-2"),
                            children: D
                        }), o && s.jsxs("div", {
                            className: "line-clamp-2 text-sm break-words",
                            children: [s.jsx("span", {
                                className: "italic",
                                children: (M = S.medical_file_reference) == null ? void 0 : M.authors_display
                            }), s.jsx("span", {
                                className: "ms-1 not-italic",
                                children: (T = S.medical_file_reference) == null ? void 0 : T.publication_year
                            })]
                        }), v && s.jsx("div", {
                            className: "text-token-text-secondary line-clamp-3 text-sm break-words",
                            children: v
                        })]
                    }, S.id)
                })
            }) : s.jsxs(s.Fragment, {
                children: [s.jsxs(G, {
                    href: e[0].url,
                    className: C("text-token-text-primary flex max-w-80 flex-col gap-1 text-start text-xs font-normal no-underline!"),
                    children: [s.jsxs("div", {
                        className: "flex items-center justify-center gap-1.5",
                        children: [e[0].fileTypeIcon, s.jsx("div", {
                            className: "text-token-text-primary flex-auto truncate",
                            children: o ? (w = e[0].fileItem.medical_file_reference) == null ? void 0 : w.journal_name : a
                        })]
                    }), s.jsx("div", {
                        className: "line-clamp-2 text-sm font-medium break-all",
                        children: e[0].fileName
                    }), o && s.jsxs("div", {
                        className: "line-clamp-2 text-sm break-words",
                        children: [s.jsx("span", {
                            className: "italic",
                            children: (N = e[0].fileItem.medical_file_reference) == null ? void 0 : N.authors_display
                        }), s.jsx("span", {
                            className: "ms-1 not-italic",
                            children: (W = e[0].fileItem.medical_file_reference) == null ? void 0 : W.publication_year
                        })]
                    })]
                }), f || u ? null : s.jsx("div", {
                    className: "flex w-full cursor-pointer flex-row items-center gap-2 pt-3 text-sm",
                    children: s.jsx(ft, {
                        sendReply: F
                    })
                })]
            })
        };
    return s.jsx(Te, {
        label: s.jsx(y, {}),
        align: "start",
        cornerRadius: "xl",
        customBorderClassName: "border-token-border-default border",
        customPaddingClassName: h ? "p-0" : "p-3",
        delayDuration: 150,
        interactive: !0,
        onOpenChange: n,
        side: "bottom",
        theme: p ? "default" : "white",
        wide: !0,
        children: t
    })
}

function Dt({
    contentReferences: e,
    fileRef: t,
    index: a,
    trackContentReferenceEvent: l
}) {
    const n = e[a - 1];
    if ((n == null ? void 0 : n.type) === "file" && (n.end_idx === t.start_idx - 1 || n.end_idx === t.start_idx)) return;
    const p = _t({
        contentReferences: e,
        fileRef: t,
        index: a
    });
    return Object.entries(p).map(([i, c]) => s.jsx(ht, {
        additionalFileRefs: c.slice(1),
        fileRef: c[0],
        index: a,
        trackContentReferenceEvent: l
    }, i))
}
const _t = ({
    contentReferences: e,
    fileRef: t,
    index: a
}) => {
    var f, r;
    const l = [];
    let n = a,
        p = t;
    for (let o = n + 1; o < e.length; o++) {
        const u = e[o];
        if ((u == null ? void 0 : u.type) === "file" && (p.end_idx === u.start_idx - 1 || p.end_idx === u.start_idx)) l.push(u), p = u, n = o;
        else break
    }
    const i = [t, ...l],
        c = {};
    for (const o of i) {
        const u = (r = Re((f = o.cloud_doc_url) != null ? f : "")) != null ? r : "unknown";
        c[u] || (c[u] = []), c[u].push(o)
    }
    return c
};

function $t(e) {
    return ve(), null
}

function yt(e) {
    if (e.startsWith("file://")) return !1;
    try {
        return new URL(e).hostname !== "localhost"
    } catch (t) {
        return !0
    }
}

function Pt(e) {
    if (ve()) {
        if (e.webpageRef.fallback_items) {
            const a = P(A({}, e), {
                webpageRef: P(A({}, e.webpageRef), {
                    items: e.webpageRef.fallback_items,
                    fallback_items: void 0
                })
            });
            return s.jsx(ge, A({}, a))
        }
        return null
    }
    return s.jsx(ge, A({}, e))
}

function ge({
    webpageRef: e,
    trackContentReferenceEvent: t,
    message: a,
    index: l
}) {
    var f;
    const [n, p] = x.useState(null), i = a.status, c = a.id;
    if (e.style === "hidden" || i === "in_progress" && ((f = a.metadata) == null ? void 0 : f.mercury_message) === !0) return null;
    switch (e.status) {
        case "loading":
        case "error":
            return null;
        default:
            return s.jsx(s.Fragment, {
                children: e.items.map((r, o) => {
                    if (!yt(r.url)) return null;
                    const m = n === o;
                    return s.jsx(vt, {
                        webpageItem: r,
                        trackContentReferenceEvent: t,
                        onMouseEnter: () => {
                            p(o)
                        },
                        isLastHovered: m,
                        messageId: c,
                        analyticsMetadata: {
                            section: "inline",
                            section_location: "response",
                            section_index: r.section_index
                        },
                        index: l,
                        style: e.style
                    }, "".concat(o, "-").concat(r.url))
                })
            })
    }
}
const K = {
    prev: {
        x: "0%",
        opacity: 0,
        pointerEvents: "none",
        transition: {
            duration: .1,
            ease: "easeOut"
        }
    },
    cur: {
        x: "0",
        opacity: 1,
        pointerEvents: "auto",
        transition: {
            duration: .15,
            ease: "easeOut"
        }
    },
    next: {
        x: "5%",
        opacity: 0,
        pointerEvents: "none",
        transition: {
            duration: .1,
            ease: "easeOut"
        }
    }
};

function vt({
    webpageItem: e,
    className: t,
    trackContentReferenceEvent: a,
    onMouseEnter: l,
    isLastHovered: n,
    messageId: p,
    analyticsMetadata: i,
    index: c,
    noMarginStart: f,
    style: r
}) {
    var ae, le, ne, ie;
    const o = V(),
        u = te(() => nt(o)),
        m = Ee(o),
        h = L => A({
            url: L.url,
            title: L.title,
            pub_date: Ie(L.pub_date),
            sub_pill_index: L.sub_pill_index,
            link_type: "pill"
        }, i),
        _ = (le = (ae = e.supporting_websites) == null ? void 0 : ae.length) != null ? le : 0,
        [F, y] = x.useState(!1),
        [b, j] = x.useState(!1),
        d = (F || b) && n,
        k = m ? Se({
            className: t,
            isBetaMedicalRetrieval: m,
            disableMarginStart: f
        }) : C("flex h-4.5 overflow-hidden rounded-xl px-2 text-[9px] font-medium", "transition-colors duration-150 ease-in-out", d ? "bg-token-text-primary! text-token-main-surface-primary!" : "text-token-text-secondary!", !d && !u && "bg-[#F4F4F4]! dark:bg-[#303030]!", u && "hover:bg-token-bg-tertiary bg-(--bg-quaternary)", t),
        w = x.useRef(d);
    d || (w.current = !1);
    const N = !d || !w.current,
        W = x.useRef(null),
        [S, D] = x.useState(null);
    it(() => {
        if (W.current) {
            const {
                offsetWidth: L
            } = W.current;
            D(L + 1)
        }
    }, []), x.useEffect(() => {
        n && (d ? fe.setHighlightBySource(p, e) : fe.clearHighlights())
    }, [d, n, p, e]);
    const v = [e, ...(ne = e.supporting_websites) != null ? ne : []],
        [g, z] = x.useState(0),
        M = L => {
            L !== g && d && (w.current = d), z(L)
        },
        T = (ie = v[g]) != null ? ie : e,
        B = O(g - 1, v.length),
        R = O(g + 1, v.length),
        $ = {
            url: T.url,
            title: T.title,
            pub_date: T.pub_date,
            sub_pill_index: g
        };
    x.useEffect(() => {
        d || M(0)
    }, [d]);
    const se = wt(p, c != null ? c : 0, g);
    x.useEffect(() => {
        se || (a("link_action", null, "webpage", P(A({}, h($)), {
            action: "show"
        })), Tt(p, c != null ? c : 0, g))
    }, [se]);
    const q = () => {
            a("link_action", null, "webpage", P(A({}, h($)), {
                action: "click"
            }))
        },
        Le = L => {
            L && a("link_action", null, "webpage", P(A({}, h($)), {
                action: "hover"
            })), j(L)
        };
    let J = null;
    return r === "reduced" ? J = s.jsx("span", {
        className: C(!f && "ms-1", "inline-flex items-center", "relative top-1"),
        onMouseEnter: () => {
            l == null || l(), y(!0)
        },
        onMouseLeave: () => {
            y(!1)
        },
        onClick: q,
        children: s.jsx(G, {
            href: T.url,
            className: C("rounded-full px-1.5 py-0.5", "bg-token-border-xlight text-token-text-secondary!", "hover:bg-token-border-default hover:text-token-text-primary"),
            children: s.jsx(He, {
                className: "icon-sm"
            })
        })
    }) : J = s.jsx("span", {
        ref: W,
        className: C(!m && !f && "ms-1", "inline-flex max-w-full items-center", m ? "relative" : "relative top-[-0.094rem]", !m && "animate-[show_150ms_ease-in]"),
        style: S ? {
            width: S
        } : void 0,
        "data-testid": "webpage-citation-pill",
        children: s.jsx(G, {
            href: T.url,
            className: k,
            style: S ? {
                maxWidth: S
            } : void 0,
            onClick: q,
            onMouseEnter: () => {
                l == null || l(), y(!0)
            },
            onMouseLeave: () => {
                y(!1)
            },
            children: s.jsxs("span", {
                className: "relative start-0 bottom-0 flex h-full w-full items-center",
                children: [v.length > 3 && s.jsx(X, {
                    variant: "prev",
                    item: v[B],
                    numAdditionalSupportingWebsites: _,
                    isActive: d != null ? d : !1,
                    shouldShowSupportingCount: N,
                    renderLikeFile: m,
                    className: "absolute"
                }, B), s.jsx(X, {
                    variant: "cur",
                    item: v[g],
                    numAdditionalSupportingWebsites: _,
                    isActive: d != null ? d : !1,
                    shouldShowSupportingCount: N,
                    renderLikeFile: m
                }, g), v.length > 2 && s.jsx(X, {
                    variant: "next",
                    item: v[R],
                    numAdditionalSupportingWebsites: _,
                    isActive: d != null ? d : !1,
                    shouldShowSupportingCount: N,
                    renderLikeFile: m,
                    className: "absolute"
                }, R)]
            })
        })
    }), s.jsx(jt, {
        webpageItem: e,
        open: b && n,
        onOpenChange: Le,
        onClick: q,
        currentItemIndex: g,
        setCurrentItemIndex: M,
        children: J
    })
}

function X(f) {
    var r = f,
        {
            className: e,
            variant: t,
            item: a,
            numAdditionalSupportingWebsites: l,
            isActive: n,
            shouldShowSupportingCount: p,
            renderLikeFile: i
        } = r,
        c = me(r, ["className", "variant", "item", "numAdditionalSupportingWebsites", "isActive", "shouldShowSupportingCount", "renderLikeFile"]);
    var h, _;
    const o = p && l > 0,
        u = (h = a.attribution) != null ? h : je(a.url),
        m = i ? s.jsxs("span", {
            className: "flex min-w-0 flex-1 items-center gap-1.5",
            children: [s.jsx("span", {
                className: "inline-flex h-4 w-4 flex-none items-center justify-center overflow-hidden rounded-full",
                children: s.jsx(ke, {
                    url: a.url,
                    size: "xsmall",
                    className: "h-4 w-4",
                    connectorSource: (_ = a.attribution) == null ? void 0 : _.toLowerCase(),
                    fallback: s.jsx(ee, {
                        url: a.url,
                        size: 32,
                        minSize: 16,
                        className: "h-4 w-4"
                    })
                })
            }), s.jsx(Z, {
                className: "max-w-[15ch] text-center",
                children: u
            })]
        }) : s.jsx("span", {
            className: "max-w-[15ch] grow truncate overflow-hidden text-center",
            children: u
        });
    return s.jsxs(H.span, P(A({
        variants: {
            prev: {
                x: "0%",
                opacity: 0,
                transition: {
                    duration: .1,
                    ease: "easeOut"
                }
            },
            cur: {
                x: "0",
                opacity: 1,
                transition: {
                    duration: .1,
                    ease: "easeOut"
                }
            },
            next: {
                x: "10%",
                opacity: 0
            }
        },
        animate: t,
        initial: t,
        className: C("flex h-4 w-full items-center justify-between", !o && "overflow-hidden", e)
    }, c), {
        children: [m, o && s.jsxs("span", {
            className: C("-me-1 flex h-full items-center rounded-full px-1 text-[#8F8F8F]", n && "text-token-main-surface-tertiary"),
            children: ["+", l]
        })]
    }))
}

function jt({
    webpageItem: e,
    onClick: t,
    open: a,
    onOpenChange: l,
    children: n,
    currentItemIndex: p,
    setCurrentItemIndex: i,
    className: c
}) {
    const f = we(),
        r = s.jsx(kt, {
            webpageItem: e,
            onClick: t,
            currentItemIndex: p,
            setCurrentItemIndex: i
        });
    return s.jsx(Te, {
        label: r,
        onOpenChange: l,
        open: a,
        side: "bottom",
        delayDuration: 150,
        theme: f ? "default" : "white",
        align: "start",
        customPaddingClassName: "p-0",
        cornerRadius: "xl",
        customBorderClassName: "border-token-border-default border",
        contentClassName: "animate-show",
        className: c,
        wide: !0,
        interactive: !0,
        children: n
    })
}
const I = x.forwardRef(function({
    item: t,
    onClick: a
}, l) {
    var p, i;
    if (!t) return null;
    const n = t.pub_date != null ? new Date(t.pub_date * 1e3) : null;
    return s.jsxs(G, {
        ref: l,
        className: "flex flex-col gap-2 p-3",
        href: t.url,
        onClick: a,
        children: [s.jsxs("div", {
            className: "flex gap-1.5",
            children: [s.jsx("div", {
                className: "h-4 w-4 shrink-0 overflow-hidden rounded-full",
                children: s.jsx(ke, {
                    url: t.url,
                    size: "xsmall",
                    className: "icon-sm",
                    connectorSource: (p = t.attribution) == null ? void 0 : p.toLowerCase(),
                    fallback: s.jsx(ee, {
                        url: t.url,
                        size: 32,
                        minSize: 16,
                        className: "icon-sm"
                    })
                })
            }), s.jsx("div", {
                className: "text-token-text-primary truncate",
                children: (i = t.attribution) != null ? i : je(t.url)
            })]
        }), s.jsx("div", {
            className: "line-clamp-2 text-sm font-medium",
            children: t.title
        }), s.jsxs("div", {
            className: "text-token-text-secondary line-clamp-2 text-sm",
            children: [Nt(n), n && t.snippet && " — ", t.snippet]
        })]
    })
});

function kt({
    webpageItem: e,
    onClick: t,
    currentItemIndex: a,
    setCurrentItemIndex: l
}) {
    var j;
    const n = [e, ...(j = e.supporting_websites) != null ? j : []],
        p = n[a != null ? a : 0],
        i = a != null && "".concat(a + 1, "/").concat(n.length),
        c = a ? n[O(a + 1, n.length)] : void 0,
        f = a ? n[O(a - 1, n.length)] : void 0,
        r = () => {
            a != null && (l == null || l(O(a + 1, n.length)))
        },
        o = () => {
            a != null && (l == null || l(O(a - 1, n.length)))
        },
        u = te(rt),
        m = !u,
        [{
            width: h
        }, _] = mt(),
        [F, y] = x.useState(h != null ? h : 0);
    F < h && y(h), x.useEffect(() => ct(document, {
        keydown: d => {
            d.key === "ArrowRight" ? r() : d.key === "ArrowLeft" && o()
        }
    }));
    const b = C("flex flex-col dark:bg-token-main-surface-secondary");
    return s.jsxs("span", {
        className: "text-token-text-primary flex flex-col text-start text-xs font-normal no-underline!",
        children: [a != null && n.length > 1 && s.jsxs("div", {
            className: "bg-token-main-surface-secondary dark:bg-token-main-surface-tertiary flex h-9 items-center justify-between gap-1.5",
            children: [s.jsxs("div", {
                className: "text-token-text-secondary mx-1.5 flex gap-1",
                children: [s.jsx("button", {
                    onClick: o,
                    className: "hover:bg-token-border-xlight disabled:text-token-text-quaternary h-6 w-6 rounded-md disabled:hover:bg-transparent",
                    children: s.jsx(dt, {
                        className: "icon-sm m-auto"
                    })
                }), s.jsx("button", {
                    onClick: r,
                    className: "hover:bg-token-border-xlight disabled:text-token-text-quaternary h-6 w-6 rounded-md disabled:hover:bg-transparent",
                    children: s.jsx(ut, {
                        className: "icon-sm m-auto"
                    })
                })]
            }), s.jsx("span", {
                className: "text-token-text-tertiary mx-3.5",
                children: i
            })]
        }), a != null && n.length > 1 ? s.jsxs("div", {
            className: "flex overflow-hidden",
            children: [n.length > 3 && s.jsx(H.span, {
                className: C(b, "absolute"),
                variants: K,
                animate: "prev",
                initial: "prev",
                children: s.jsx(I, {
                    item: f,
                    onClick: t
                })
            }, O(a - 1, n.length)), s.jsx(H.span, {
                className: b,
                variants: K,
                animate: "cur",
                initial: "cur",
                style: u ? void 0 : {
                    minWidth: F
                },
                children: s.jsx(I, {
                    ref: m ? _ : void 0,
                    item: p,
                    onClick: t
                })
            }, a), n.length > 2 && s.jsx(H.span, {
                className: C(b, "absolute"),
                variants: K,
                animate: "next",
                initial: "next",
                children: s.jsx(I, {
                    item: c,
                    onClick: t
                })
            }, O(a + 1, n.length))]
        }) : s.jsx("div", {
            className: b,
            children: s.jsx(I, {
                item: p,
                onClick: t
            })
        })]
    })
}

function Nt(e) {
    return e && e.toLocaleDateString(void 0, {
        year: "numeric",
        month: "long",
        day: "numeric"
    })
}

function O(e, t) {
    return (e % t + t) % t
}
const Ce = ot(() => ({}));

function Me(e, t, a) {
    return "".concat(e, "-").concat(t, "-").concat(a)
}

function wt(e, t, a) {
    return Ce(l => l[Me(e, t, a)])
}

function Tt(e, t, a) {
    Ce.setState(l => P(A({}, l), {
        [Me(e, t, a)]: 1
    }))
}
export {
    Dt as F, vt as W, Pt as a, jt as b, $t as c, ht as d, xe as g
};
//# sourceMappingURL=dcboyjh87ll7k264.js.map