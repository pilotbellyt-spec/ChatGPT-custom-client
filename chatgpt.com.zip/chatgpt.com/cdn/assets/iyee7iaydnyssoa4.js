import {
    c as t,
    jx as e
} from "./dykg4ktvbu3mhmdo.js";
const r = t(e, "08f77b", 24, 24);
export {
    r as E
};
//# sourceMappingURL=iyee7iaydnyssoa4.js.map