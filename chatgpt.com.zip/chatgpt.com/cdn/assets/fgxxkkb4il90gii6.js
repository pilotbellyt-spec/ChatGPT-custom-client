var xe = Object.defineProperty,
    ye = Object.defineProperties;
var we = Object.getOwnPropertyDescriptors;
var J = Object.getOwnPropertySymbols;
var be = Object.prototype.hasOwnProperty,
    Te = Object.prototype.propertyIsEnumerable;
var V = (n, e, r) => e in n ? xe(n, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : n[e] = r,
    c = (n, e) => {
        for (var r in e || (e = {})) be.call(e, r) && V(n, r, e[r]);
        if (J)
            for (var r of J(e)) Te.call(e, r) && V(n, r, e[r]);
        return n
    },
    x = (n, e) => ye(n, we(e));
var Q = (n, e, r) => V(n, typeof e != "symbol" ? e + "" : e, r);
import {
    Ad as Ee,
    oa as oe,
    Ae as Ie,
    xI as Ae,
    Af as _e,
    hq as De,
    hr as Ce,
    wI as ie,
    r4 as D,
    _ as W,
    Ag as q,
    c3 as X,
    kq as Y,
    aU as ve,
    gd as Se,
    Ah as Pe,
    dD as Le
} from "./dykg4ktvbu3mhmdo.js";
import {
    w as j,
    c as h,
    I as ae,
    T as ue,
    t as Oe,
    a as Re,
    b as Be,
    L as C,
    P as G,
    s as le,
    l as O,
    e as de,
    d as pe,
    H as $e,
    R as Ue
} from "./eafv7vq0yf9bv0fi.js";
import {
    S as v,
    M as S,
    N,
    E as He
} from "./f76gy0b8ieo4s693.js";
import {
    gn as ce,
    c5 as Ke
} from "./k15yxxoybkkir2ou.js";
import {
    i as Ne,
    H as A,
    f as ze,
    a as Ve
} from "./jsd0vs4cv2vks3ah.js";
import {
    r as qe,
    a as We,
    b as je,
    c as Ge
} from "./dv2e3o9gddnli9b5.js";
import {
    c as Fe
} from "./loeoawlgsw5vcwar.js";
import {
    t as Je
} from "./17v8usp0o68l1lsz.js";
import {
    r as Qe
} from "./nfccle6oyncifphl.js";
import {
    r as Xe
} from "./b5s349mvbdzayaxi.js";
const Ye = v.proseMirrorMarkName();

function B(n, e) {
    const r = [],
        t = [];
    for (const s of n.marks) {
        if (s.type.name === Ye) {
            r.push(s);
            continue
        }
        t.push(s)
    }
    return n.mark([...t, e, ...r])
}
class Ze extends S {
    unistNodeName() {
        return "link"
    }
    static proseMirrorMarkName() {
        return "link"
    }
    proseMirrorMarkSpec() {
        return {
            attrs: {
                href: {},
                title: {
                    default: null
                },
                disabled: {
                    default: !0
                }
            },
            inclusive: !1,
            parseDOM: [{
                tag: "a[href]",
                getAttrs(e) {
                    return {
                        href: e.getAttribute("href"),
                        title: e.getAttribute("title")
                    }
                }
            }],
            toDOM(e) {
                return ["a", c(c({}, e.attrs), e.attrs.disabled ? {
                    href: void 0
                } : {})]
            }
        }
    }
    unistNodeToProseMirrorNodes({
        node: e,
        convertedChildren: r,
        schema: t
    }) {
        const {
            url: s,
            title: o
        } = e;
        return r.map(i => B(i, t.marks[this.proseMirrorMarkName()].create({
            href: s,
            title: o
        })))
    }
    processConvertedUnistNode(e, r) {
        return x(c({
            type: this.unistNodeName(),
            url: r.attrs.href
        }, r.attrs.title != null && {
            title: r.attrs.title
        }), {
            children: [e]
        })
    }
}
class er extends N {
    unistNodeName() {
        return "blockquote"
    }
    static proseMirrorNodeName() {
        return "blockquote"
    }
    proseMirrorNodeSpec() {
        return {
            content: "block+",
            group: "block",
            parseDOM: [{
                tag: "blockquote"
            }],
            toDOM() {
                return ["blockquote", 0]
            }
        }
    }
    proseMirrorInputRules(e) {
        return [j(/^\s{0,3}>\s$/, e.nodes[this.proseMirrorNodeName()])]
    }
    proseMirrorKeymap(e) {
        return {
            "Mod->": Ee(e.nodes[this.proseMirrorNodeName()])
        }
    }
    unistNodeToProseMirrorNodes({
        schema: e,
        convertedChildren: r,
        attrs: t
    }) {
        return h(this.proseMirrorNodeName(), e, r, t)
    }
    proseMirrorNodeToUnistNodes(e, r) {
        return [{
            type: this.unistNodeName(),
            children: r
        }]
    }
}

function rr(n, e, r, t) {
    for (let s = 0; s < e.length; s++) {
        const {
            $from: o,
            $to: i
        } = e[s];
        let a = o.depth === 0 ? n.inlineContent && n.type.allowsMarkType(r) : !1;
        if (n.nodesBetween(o.pos, i.pos, (l, d) => {
                if (a) return !1;
                a = l.inlineContent && l.type.allowsMarkType(r)
            }), a) return !0
    }
    return !1
}

function Z(n) {
    var r, t;
    const e = /^\s*/.exec(n);
    return (t = (r = e == null ? void 0 : e[0]) == null ? void 0 : r.length) != null ? t : 0
}

function ee(n) {
    var r, t;
    const e = /\s*$/.exec(n);
    return (t = (r = e == null ? void 0 : e[0]) == null ? void 0 : r.length) != null ? t : 0
}

function tr(n, e, r) {
    for (; e > 0;) {
        const t = e - 1;
        if (!n.rangeHasMark(t, e, r)) break;
        e = t
    }
    return e
}

function sr(n, e, r) {
    for (; e < n.content.size && n.rangeHasMark(e, e + 1, r);) e += 1;
    return e
}

function nr(n, e, r, t = null) {
    var l, d, u, p, f, g, w, b;
    const {
        selection: s
    } = n;
    if (!(s instanceof oe)) return !1;
    const {
        empty: o,
        $cursor: i,
        ranges: a
    } = s;
    if (o && !i || !rr(n.doc, a, r)) return !1;
    if (i) r.isInSet(n.storedMarks || i.marks()) ? e(n.tr.removeStoredMark(r)) : e(n.tr.addStoredMark(r.create(t)));
    else {
        const I = n.tr,
            P = !a.some(k => n.doc.rangeHasMark(k.$from.pos, k.$to.pos, r));
        for (let k = 0; k < a.length; k++) {
            const {
                $from: T,
                $to: E
            } = a[k];
            let m = T.pos,
                M = E.pos;
            const U = n.doc.textBetween(m, M, "\n");
            if (/^\s*$/.test(U)) continue;
            const H = (d = (l = T.nodeBefore) == null ? void 0 : l.text) != null ? d : "",
                K = (p = (u = T.nodeAfter) == null ? void 0 : u.text) != null ? p : "",
                ge = (g = (f = E.nodeBefore) == null ? void 0 : f.text) != null ? g : "",
                ke = (b = (w = E.nodeAfter) == null ? void 0 : w.text) != null ? b : "";
            if (P) {
                const L = Z(K),
                    z = ee(ge);
                m + L < M && (m += L, M -= z), m = tr(n.doc, m, r), M = sr(n.doc, M, r), I.removeMark(m, M, n.schema.marks[v.proseMirrorMarkName()]), I.addMark(m, M, r.create(t))
            } else {
                const L = ee(H),
                    z = Z(ke);
                m -= L, M += z, I.removeMark(m, M, r)
            }
        }
        e(I.scrollIntoView())
    }
    return !0
}

function re(n, e = null) {
    return (r, t) => t ? nr(r, t, n, e) : !0
}
class y extends ae {
    constructor(r, t) {
        super(r, (s, o, i, a) => this.markHandler(s, o, i, a));
        Q(this, "markType");
        this.markType = t
    }
    static markApplies(r, t, s) {
        for (const o of t) {
            const {
                $from: i,
                $to: a
            } = o;
            let l = i.depth === 0 ? r.type.allowsMarkType(s) : !1;
            if (r.nodesBetween(i.pos, a.pos, d => l ? !1 : (l = d.inlineContent && d.type.allowsMarkType(s), !0)), l) return !0
        }
        return !1
    }
    markHandler(r, t, s, o) {
        var p, f;
        if (!(r.selection instanceof oe)) return null;
        const i = r.doc.resolve(s),
            a = r.doc.resolve(o),
            l = [new Ie(i, a)];
        if (!y.markApplies(r.doc, l, this.markType)) return null;
        const d = (f = (p = r.doc.nodeAt(s)) == null ? void 0 : p.marks.map(g => g.type)) != null ? f : [];
        d.push(this.markType);
        const u = r.tr.replaceWith(s, o, this.markType.schema.text(t[1]));
        for (const g of d) u.addMark(u.mapping.map(s), u.mapping.map(o), g.create(null));
        for (const g of d) u.removeStoredMark(g);
        return u.insertText(t[2])
    }
}
class or extends S {
    unistNodeName() {
        return "strong"
    }
    static proseMirrorMarkName() {
        return "strong"
    }
    proseMirrorMarkSpec() {
        return {
            parseDOM: [{
                tag: "b"
            }, {
                tag: "strong"
            }, {
                style: "font-weight",
                getAttrs: e => /^(bold(er)?|[5-9]\d{2,})$/.test(e) && null
            }],
            toDOM() {
                return ["strong"]
            }
        }
    }
    proseMirrorInputRules(e) {
        return [new y(/\*\*([^\s](?:.*[^\s])?)\*\*([\s\S])$/, e.marks[this.proseMirrorMarkName()]), new y(/__([^\s](?:.*[^\s])?)__([\s\S])$/, e.marks[this.proseMirrorMarkName()])]
    }
    proseMirrorKeymap(e) {
        const r = e.marks[this.proseMirrorMarkName()];
        return {
            "Mod-b": re(r),
            "Mod-B": re(r)
        }
    }
    unistNodeToProseMirrorNodes({
        schema: e,
        convertedChildren: r,
        attrs: t
    }) {
        return r.map(s => B(s, e.marks[this.proseMirrorMarkName()].create(t)))
    }
    processConvertedUnistNode(e) {
        return {
            type: this.unistNodeName(),
            children: [e]
        }
    }
}
const me = 92,
    ir = 10,
    R = "backslashEscape";

function ar(n, e, r) {
    function t(s) {
        return s == null || s === ir ? (n.exit(R), e(s)) : r(s)
    }
    return s => s !== me ? r(s) : (n.enter(R), n.consume(s), t)
}

function ur() {
    return {
        text: {
            [me]: {
                name: R,
                tokenize: ar
            }
        }
    }
}

function lr() {
    var e, r;
    const n = this.data();
    (e = n.micromarkExtensions) != null || (n.micromarkExtensions = []), n.micromarkExtensions.push(ur()), (r = n.fromMarkdownExtensions) != null || (n.fromMarkdownExtensions = []), n.fromMarkdownExtensions.push({
        enter: {
            [R](t) {
                this.enter({
                    type: "break"
                }, t), this.exit(t)
            }
        }
    })
}
class dr extends N {
    unistNodeName() {
        return "break"
    }
    static proseMirrorNodeName() {
        return "hard_break"
    }
    proseMirrorNodeSpec() {
        return {
            inline: !0,
            group: "inline",
            selectable: !1,
            parseDOM: [{
                tag: "br"
            }],
            marks: v.proseMirrorMarkName(),
            toDOM() {
                return ["br"]
            }
        }
    }
    proseMirrorKeymap(e) {
        const r = Ae(_e, (s, o) => (o && o(s.tr.replaceSelectionWith(e.nodes[this.proseMirrorNodeName()].create()).scrollIntoView()), !0)),
            t = De() || Ce();
        return c({
            "Mod-Enter": r,
            "Shift-Enter": r
        }, t && {
            "Ctrl-Enter": r
        })
    }
    unistNodeToProseMirrorNodes({
        schema: e,
        convertedChildren: r,
        attrs: t
    }) {
        return h(this.proseMirrorNodeName(), e, r, t)
    }
    proseMirrorNodeToUnistNodes() {
        return [{
            type: this.unistNodeName()
        }]
    }
    unifiedInitializationHook(e) {
        return e.use(lr)
    }
}
const pr = "code_block",
    te = "```\n";

function cr(n, e) {
    var s;
    const {
        start: r,
        end: t
    } = n;
    return r == null || t == null ? null : {
        start: r + te.length + ((s = e.lang) != null ? s : "").length,
        end: t - te.length
    }
}
class Nr extends N {
    dependencies() {
        return [new ue]
    }
    unistNodeName() {
        return "code"
    }
    static proseMirrorNodeName() {
        return pr
    }
    proseMirrorNodeSpec() {
        return {
            content: "text*",
            group: "block",
            code: !0,
            defining: !0,
            marks: [v.proseMirrorMarkName()].join(" "),
            attrs: {
                lang: {
                    default: null
                },
                isDarkMode: {
                    default: null
                }
            },
            parseDOM: [{
                tag: "pre",
                preserveWhitespace: "full"
            }],
            toDOM() {
                return ["pre", ["code", 0]]
            }
        }
    }
    proseMirrorInputRules(e) {
        return [Oe(/^\s{0,3}```$/, e.nodes[this.proseMirrorNodeName()])]
    }
    unistNodeToProseMirrorNodes({
        node: e,
        attrs: r,
        schema: t
    }) {
        var o;
        const {
            lang: s
        } = e;
        return h(this.proseMirrorNodeName(), t, ie(e, t, c(c({}, r), (o = cr(r, e)) != null ? o : {})), c({
            lang: s
        }, r))
    }
    proseMirrorNodeToUnistNodes(e, r) {
        return [{
            type: this.unistNodeName(),
            value: r.map(t => t.type === "startend" ? t.children.map(s => s.value).join("") : t.value).join(""),
            lang: e.attrs.lang
        }]
    }
}
class mr extends N {
    unistNodeName() {
        return "textDirective"
    }
    customDirectiveName() {
        return D
    }
    static proseMirrorNodeName() {
        return D
    }
    proseMirrorNodeSpec() {
        return {
            group: "inline",
            inline: !0,
            content: "inline*",
            atom: !0,
            attrs: {
                index: {
                    default: null
                },
                displayLayout: {
                    default: "inline"
                }
            },
            toDOM: e => ["span", {
                "data-type": "content-reference",
                "data-content-reference-index": e.attrs.index,
                "data-display-layout": e.attrs.displayLayout
            }, ":contentReference[oaicite:".concat(e.attrs.index, ']{index="').concat(e.attrs.index, '" displayLayout="').concat(e.attrs.displayLayout, '"}')],
            parseDOM: [{
                tag: 'span[data-type="content-reference"]',
                getAttrs(e) {
                    return {
                        index: e.getAttribute("data-index"),
                        displayLayout: e.getAttribute("data-display-layout") || "inline"
                    }
                }
            }]
        }
    }
    unistNodeToProseMirrorNodes({
        node: e,
        schema: r,
        convertedChildren: t
    }) {
        var o, i, a;
        if (!ce(e) || e.name !== D || e.type !== this.unistNodeName()) return W.addError("ContentReferenceExtension: unistNodeToProseMirrorNodes: node is not a directive node or name is not contentReference", e), null;
        const s = {
            index: (o = e.attributes) == null ? void 0 : o.index,
            displayLayout: (a = (i = e.attributes) == null ? void 0 : i.displayLayout) != null ? a : "inline"
        };
        return r.nodes.contentReference.create(s, t)
    }
    proseMirrorNodeToUnistNodes(e, r) {
        if (r.length !== 1) return console.warn("ContentReferenceExtension: proseMirrorNodeToUnistNodes: convertedChildren.length != 1", r), [];
        const o = [{
            type: "text",
            value: r[0].children[0].value
        }];
        return [{
            type: "textDirective",
            name: D,
            attributes: {
                index: e.attrs.index,
                displayLayout: e.attrs.displayLayout
            },
            children: o,
            data: {
                hName: D,
                hProperties: {
                    displayLayout: e.attrs.displayLayout,
                    index: e.attrs.index
                }
            }
        }]
    }
}
class Mr extends N {
    unistNodeName() {
        return "thematicBreak"
    }
    static proseMirrorNodeName() {
        return "horizontal_rule"
    }
    proseMirrorNodeSpec() {
        return {
            group: "block",
            selectable: !1,
            parseDOM: [{
                tag: "hr"
            }],
            toDOM() {
                return ["div", ["hr"]]
            }
        }
    }
    proseMirrorInputRules(e) {
        return [new ae(/^\s{0,3}(?:\*\*\*|---|___)\n$/, (r, t, s, o) => {
            var i;
            return r.tr.replaceWith(s, o, (i = h(this.proseMirrorNodeName(), e, [])) != null ? i : [])
        })]
    }
    proseMirrorKeymap(e) {
        return {
            "Mod-_": (r, t) => (t && t(r.tr.replaceSelectionWith(e.nodes[this.proseMirrorNodeName()].create()).scrollIntoView()), !0)
        }
    }
    unistNodeToProseMirrorNodes({
        schema: e,
        convertedChildren: r,
        attrs: t
    }) {
        return h(this.proseMirrorNodeName(), e, r, t)
    }
    proseMirrorNodeToUnistNodes() {
        return [{
            type: this.unistNodeName()
        }]
    }
}
class hr extends S {
    unistNodeName() {
        return "inlineCode"
    }
    static proseMirrorMarkName() {
        return "code"
    }
    proseMirrorMarkSpec() {
        return {
            inclusive: !1,
            parseDOM: [{
                tag: "code"
            }],
            toDOM() {
                return ["code"]
            }
        }
    }
    proseMirrorInputRules(e) {
        return [new y(/`([^\s](?:.*[^\s])?)`([\s\S])$/, e.marks[this.proseMirrorMarkName()])]
    }
    proseMirrorKeymap(e) {
        const r = e.marks[this.proseMirrorMarkName()];
        return {
            "Ctrl-`": q(r)
        }
    }
    unistNodeToProseMirrorNodes({
        node: e,
        schema: r,
        attrs: t
    }) {
        const s = ie(e, r, t, [r.marks[this.proseMirrorMarkName()].create(t)]);
        return s ? [s] : []
    }
    processConvertedUnistNode(e) {
        return {
            type: this.unistNodeName(),
            value: e.value
        }
    }
}
class fr extends N {
    unistNodeName() {
        return "inlineMath"
    }
    static proseMirrorNodeName() {
        return "inline_math"
    }
    proseMirrorNodeSpec() {
        return {
            group: "inline",
            inline: !0,
            content: "text*",
            atom: !0,
            attrs: {
                latex: {
                    default: null
                }
            },
            parseDOM: [{
                tag: "span.inline-math",
                getAttrs(e) {
                    return {
                        latex: e.getAttribute("latex")
                    }
                }
            }],
            toDOM() {
                return ["span", {
                    class: "inline-math"
                }, 0]
            }
        }
    }
    unistNodeToProseMirrorNodes({
        node: e,
        schema: r,
        convertedChildren: t,
        attrs: s
    }) {
        const {
            value: o
        } = e;
        return h(this.proseMirrorNodeName(), r, t, x(c({}, s), {
            latex: o
        }))
    }
    proseMirrorNodeToUnistNodes(e) {
        return [{
            type: this.unistNodeName(),
            value: e.attrs.latex
        }]
    }
}
class gr extends S {
    unistNodeName() {
        return "emphasis"
    }
    static proseMirrorMarkName() {
        return "em"
    }
    proseMirrorMarkSpec() {
        return {
            parseDOM: [{
                tag: "i"
            }, {
                tag: "em"
            }, {
                style: "font-style",
                getAttrs: e => e === "italic" && null
            }],
            toDOM() {
                return ["em"]
            }
        }
    }
    proseMirrorInputRules(e) {
        try {
            return [new y(new RegExp("(?<!\\*)\\*([^\\s*](?:.*[^\\s])?)\\*([^*])$"), e.marks[this.proseMirrorMarkName()]), new y(new RegExp("(?<!_)_([^\\s_](?:.*[^\\s])?)_([^_])$"), e.marks[this.proseMirrorMarkName()])]
        } catch (r) {
            return W.addError(r), []
        }
    }
    proseMirrorKeymap(e) {
        const r = e.marks[this.proseMirrorMarkName()];
        return {
            "Mod-i": q(r),
            "Mod-I": q(r)
        }
    }
    unistNodeToProseMirrorNodes({
        schema: e,
        convertedChildren: r,
        attrs: t
    }) {
        return r.map(s => B(s, e.marks[this.proseMirrorMarkName()].create(t)))
    }
    processConvertedUnistNode(e) {
        return {
            type: this.unistNodeName(),
            children: [e]
        }
    }
}
const _ = "lineEndingBlank";

function se(n) {
    return n.type === _
}
const kr = ({
    startIndex: n,
    endIndex: e,
    depth: r,
    isLastChild: t,
    parent: s = null
}) => {
    const o = e - n;
    return r > 0 && (s == null ? void 0 : s.type) !== "list" ? o : t || n === 0 ? o - Math.floor((o + 1) / 2) : o - Math.floor((o - 1) / 2)
};

function xr() {
    var r;
    const n = this.data();
    (r = n.fromMarkdownExtensions) != null || (n.fromMarkdownExtensions = []), n.fromMarkdownExtensions.push({
        enter: {
            lineEndingBlank(t) {
                this.enter({
                    type: _
                }, t)
            }
        },
        exit: {
            lineEndingBlank(t) {
                this.exit(t)
            }
        }
    });
    const e = (t, s = 0) => {
        if (!Ne(t)) return;
        const {
            children: o
        } = t;
        let i = 0,
            a = null,
            l = null;
        const d = o.length;
        for (let u = 0; u < d; u++) {
            const p = o[u - i];
            e(p, s + 1);
            const {
                type: f
            } = p, w = u === d - 1 && f === _;
            if (f === _ && a == null ? a = u : f !== _ && a != null ? l = u : w && a != null && (l = u + 1), a != null && l != null) {
                const b = kr({
                    startIndex: a,
                    endIndex: l,
                    depth: s,
                    isLastChild: w,
                    parent: t
                });
                o.splice(a - i, b), a = null, l = null, i += b
            }
        }
    };
    return t => {
        e(t)
    }
}
class yr extends N {
    unistNodeName() {
        return _
    }
    static proseMirrorNodeName() {
        return "paragraph"
    }
    proseMirrorNodeSpec() {
        return Re
    }
    unistNodeToProseMirrorNodes({
        schema: e,
        convertedChildren: r,
        attrs: t
    }) {
        return h(this.proseMirrorNodeName(), e, r, t)
    }
    proseMirrorNodeToUnistNodes(e, r) {
        return [{
            type: Be,
            children: r
        }]
    }
    unifiedInitializationHook(e) {
        return e.use(xr)
    }
}
class wr extends N {
    unistNodeName() {
        return "math"
    }
    static proseMirrorNodeName() {
        return "math_block"
    }
    proseMirrorNodeSpec() {
        return {
            group: "block",
            content: "text*",
            atom: !0,
            code: !0,
            attrs: {
                latex: {
                    default: null
                }
            },
            parseDOM: [{
                tag: "div.math-block",
                getAttrs(e) {
                    return {
                        latex: e.getAttribute("latex")
                    }
                }
            }],
            toDOM() {
                return ["div", {
                    class: "math-block"
                }, 0]
            }
        }
    }
    unistNodeToProseMirrorNodes({
        node: e,
        schema: r,
        convertedChildren: t,
        attrs: s
    }) {
        const {
            value: o
        } = e;
        return h(this.proseMirrorNodeName(), r, t, x(c({}, s), {
            latex: o
        }))
    }
    proseMirrorNodeToUnistNodes(e) {
        return [{
            type: this.unistNodeName(),
            value: e.attrs.latex
        }]
    }
}
class $ extends N {
    static unorderedListCommand(e) {
        return (r, t) => {
            const s = e.nodes[this.proseMirrorNodeName()],
                o = e.nodes.ordered_list,
                i = e.nodes[C.proseMirrorNodeName()],
                a = e.nodes[G.proseMirrorNodeName()];
            if (!s) return !1;
            let l = r;
            const d = () => l,
                u = p => {
                    l = l.apply(p), t && t(p)
                };
            return le(d(), [s]) ? O(d, u, i, [o, s]) : !O(d, u, i, [o]) || !de(d, u, a) ? !1 : pe(s)(d(), u)
        }
    }
    dependencies() {
        return [new C]
    }
    unistNodeName() {
        return "list"
    }
    unistToProseMirrorTest(e) {
        return e.type === this.unistNodeName() && e.ordered !== !0
    }
    static proseMirrorNodeName() {
        return "list"
    }
    proseMirrorNodeSpec() {
        return {
            content: "list_item+",
            group: "block",
            attrs: {
                spread: {
                    default: !1
                }
            },
            parseDOM: [{
                getAttrs(e) {
                    return {
                        spread: e.getAttribute("data-spread") === "true"
                    }
                },
                tag: "ul"
            }],
            toDOM(e) {
                return ["ul", {
                    "data-spread": e.attrs.spread
                }, 0]
            }
        }
    }
    proseMirrorInputRules(e) {
        return [j(/^\s{0,3}([-+*])\s$/, e.nodes[this.proseMirrorNodeName()])]
    }
    proseMirrorKeymap(e) {
        const r = $.unorderedListCommand(e);
        return {
            "Shift-Mod-8": r,
            "Alt-Mod-5": r
        }
    }
    unistNodeToProseMirrorNodes({
        node: e,
        schema: r,
        convertedChildren: t,
        attrs: s
    }) {
        const {
            spread: o
        } = e;
        return h(this.proseMirrorNodeName(), r, t, x(c({}, s), {
            spread: o
        }))
    }
    proseMirrorNodeToUnistNodes(e, r) {
        const t = e.attrs.spread;
        return [{
            type: this.unistNodeName(),
            ordered: !1,
            spread: t,
            children: r.map(s => (s.spread = t, s))
        }]
    }
}
class F extends N {
    static orderedListCommand(e) {
        return (r, t) => {
            const s = e.nodes[this.proseMirrorNodeName()],
                o = e.nodes[$.proseMirrorNodeName()],
                i = e.nodes[C.proseMirrorNodeName()],
                a = e.nodes[G.proseMirrorNodeName()];
            if (!s) return !1;
            let l = r;
            const d = () => l,
                u = p => {
                    l = l.apply(p), t && t(p)
                };
            return le(d(), [s]) ? O(d, u, i, [s, o]) : !O(d, u, i, [o]) || !de(d, u, a) ? !1 : pe(s)(d(), u)
        }
    }
    dependencies() {
        return [new C]
    }
    unistNodeName() {
        return "list"
    }
    unistToProseMirrorTest(e) {
        return e.type === this.unistNodeName() && e.ordered === !0
    }
    static proseMirrorNodeName() {
        return "ordered_list"
    }
    proseMirrorNodeSpec() {
        return {
            content: "list_item+",
            group: "block",
            attrs: {
                spread: {
                    default: !1
                },
                startingNumber: {
                    default: 1
                }
            },
            parseDOM: [{
                getAttrs(e) {
                    const r = e.getAttribute("start");
                    return {
                        spread: e.getAttribute("data-spread") === "true",
                        startingNumber: r != null ? parseInt(r) : 1
                    }
                },
                tag: "ol"
            }],
            toDOM(e) {
                return ["ol", {
                    "data-spread": e.attrs.spread,
                    start: e.attrs.startingNumber
                }, 0]
            }
        }
    }
    proseMirrorInputRules(e) {
        return [j(/^\s{0,3}(\d+)\.\s$/, e.nodes[this.proseMirrorNodeName()], r => ({
            startingNumber: +r[1]
        }), (r, t) => t.childCount + t.attrs.startingNumber === +r[1])]
    }
    proseMirrorKeymap(e) {
        const r = F.orderedListCommand(e);
        return {
            "Shift-Mod-9": r,
            "Alt-Mod-4": r
        }
    }
    unistNodeToProseMirrorNodes({
        node: e,
        schema: r,
        convertedChildren: t,
        attrs: s
    }) {
        const {
            spread: o,
            start: i
        } = e;
        return h(this.proseMirrorNodeName(), r, t, x(c({}, s), {
            spread: o,
            startingNumber: i != null ? i : 1
        }))
    }
    proseMirrorNodeToUnistNodes(e, r) {
        const t = e.attrs.spread;
        return [{
            type: this.unistNodeName(),
            ordered: !0,
            spread: t,
            start: e.attrs.startingNumber,
            children: r.map(s => (s.spread = t, s))
        }]
    }
}
class br extends S {
    unistNodeName() {
        return "delete"
    }
    static proseMirrorMarkName() {
        return "strikethrough"
    }
    proseMirrorMarkSpec() {
        return {
            parseDOM: [{
                tag: "s"
            }, {
                tag: "del"
            }, {
                style: "text-decoration",
                getAttrs: e => /(^|[\s])line-through([\s]|$)/.test(e) && null
            }],
            toDOM() {
                return ["s"]
            }
        }
    }
    proseMirrorInputRules(e) {
        return [new y(/~([^\s](?:.*[^\s~])?)~([^~])$/, e.marks[this.proseMirrorMarkName()]), new y(/~~([^\s](?:.*[^\s])?)~~([\s\S])$/, e.marks[this.proseMirrorMarkName()])]
    }
    unistNodeToProseMirrorNodes({
        schema: e,
        convertedChildren: r
    }) {
        return r.map(t => B(t, e.marks[this.proseMirrorMarkName()].create()))
    }
    processConvertedUnistNode(e) {
        return {
            type: this.unistNodeName(),
            children: [e]
        }
    }
}

function Tr() {
    return n => {
        let e = -1;

        function r(s, o) {
            var i;
            if (s.type === "tableRow" && e++, s.type === "tableCell") {
                const a = s;
                a.data = x(c({}, (i = a.data) != null ? i : {}), {
                    rowIndex: e,
                    columnIndex: o
                })
            }
        }

        function t(s) {
            if (Ne(s))
                for (let o = 0; o < s.children.length; o++) {
                    const i = s.children[o];
                    r(i, o), t(i)
                }
        }
        t(n)
    }
}
class Me extends N {
    unistNodeName() {
        return "tableCell"
    }
    unistToProseMirrorTest(e) {
        return e.type === this.unistNodeName()
    }
    static proseMirrorNodeName() {
        return "table_cell"
    }
    proseMirrorNodeSpec() {
        return {
            content: "inline*",
            attrs: {
                rowIndex: {
                    default: null
                },
                columnIndex: {
                    default: null
                },
                colspan: {
                    default: 1
                },
                rowspan: {
                    default: 1
                }
            },
            tableRole: "cell",
            isolating: !0,
            parseDOM: [{
                tag: "td",
                getAttrs(e) {
                    const r = e;
                    return {
                        colspan: Y(r.getAttribute("colspan"), 1),
                        rowspan: Y(r.getAttribute("rowspan"), 1)
                    }
                }
            }],
            toDOM(e) {
                const {
                    colspan: r,
                    rowspan: t
                } = e.attrs, s = {
                    colspan: r !== 1 ? X(r, void 0) : void 0,
                    rowspan: t !== 1 ? X(t, void 0) : void 0
                };
                return [e.attrs.rowIndex == null || e.attrs.rowIndex > 0 ? "td" : "th", s, 0]
            }
        }
    }
    proseMirrorInputRules(e) {
        return []
    }
    proseMirrorKeymap(e) {
        return {}
    }
    unistNodeToProseMirrorNodes({
        node: e,
        schema: r,
        convertedChildren: t,
        attrs: s
    }) {
        var o, i;
        return h(this.proseMirrorNodeName(), r, t, x(c({}, s), {
            colspan: 1,
            rowspan: 1,
            rowIndex: (o = e.data) == null ? void 0 : o.rowIndex,
            columnIndex: (i = e.data) == null ? void 0 : i.columnIndex
        }))
    }
    proseMirrorNodeToUnistNodes(e, r) {
        return [{
            type: this.unistNodeName(),
            children: r,
            data: {
                rowIndex: e.attrs.rowIndex,
                columnIndex: e.attrs.columnIndex
            }
        }]
    }
}
class he extends N {
    dependencies() {
        return [new Me]
    }
    unistNodeName() {
        return "tableRow"
    }
    static proseMirrorNodeName() {
        return "table_row"
    }
    proseMirrorNodeSpec() {
        return {
            content: "(table_cell+)",
            tableRole: "row",
            parseDOM: [{
                tag: "tr"
            }],
            toDOM() {
                return ["tr", 0]
            }
        }
    }
    proseMirrorInputRules(e) {
        return []
    }
    proseMirrorKeymap(e) {
        return {}
    }
    unistNodeToProseMirrorNodes({
        schema: e,
        convertedChildren: r,
        attrs: t
    }) {
        return h(this.proseMirrorNodeName(), e, r, t)
    }
    proseMirrorNodeToUnistNodes(e, r) {
        return [{
            type: this.unistNodeName(),
            children: r
        }]
    }
}
class Er extends N {
    dependencies() {
        return [new he]
    }
    unistNodeName() {
        return "table"
    }
    static proseMirrorNodeName() {
        return "table"
    }
    proseMirrorNodeSpec() {
        return {
            content: "(table_row+)",
            tableRole: "table",
            isolating: !0,
            group: "block",
            parseDOM: [{
                tag: "table"
            }],
            toDOM() {
                return ["table", ["tbody", 0]]
            }
        }
    }
    proseMirrorInputRules(e) {
        return []
    }
    proseMirrorKeymap(e) {
        return {}
    }
    unistNodeToProseMirrorNodes({
        schema: e,
        convertedChildren: r,
        attrs: t
    }) {
        return h(this.proseMirrorNodeName(), e, r, t)
    }
    proseMirrorNodeToUnistNodes(e, r) {
        return [{
            type: this.unistNodeName(),
            align: [],
            children: r
        }]
    }
    unifiedInitializationHook(e) {
        return e.use(Tr)
    }
}

function ne(n, e) {
    if (!(n == null || e == null)) return {
        start: c({}, n),
        end: c({}, e)
    }
}
const Ir = () => n => {
    Ke(n, "list", (e, r, t) => {
        var a, l, d, u, p, f, g, w, b, I, P, k;
        if (t == null || r == null) return;
        const s = [];
        let o = [],
            i = 0;
        for (; i < e.children.length;) {
            const T = e.children[i];
            if (se(T)) {
                const E = [];
                for (; i < e.children.length && se(e.children[i]);) E.push(e.children[i]), i++;
                if (o.length === 0) throw new Error("Unexpected state: currentListItems is empty after encountering blank lines.");
                const m = o[0],
                    M = ve(Se(o)),
                    U = ne((d = (a = m.position) == null ? void 0 : a.start) != null ? d : (l = e.position) == null ? void 0 : l.start, (f = (u = M.position) == null ? void 0 : u.end) != null ? f : (p = e.position) == null ? void 0 : p.end),
                    H = {
                        type: "list",
                        ordered: e.ordered,
                        start: e.start,
                        spread: e.spread,
                        children: o,
                        position: U
                    };
                s.push(H), o = [], s.push(...E.map(K => ({
                    type: "lineEndingBlank",
                    position: K.position
                })))
            } else o.push(T), i++
        }
        if (o.length > 0) {
            const T = o[0],
                E = o[o.length - 1],
                m = ne((b = (g = T.position) == null ? void 0 : g.start) != null ? b : (w = e.position) == null ? void 0 : w.start, (k = (I = E.position) == null ? void 0 : I.end) != null ? k : (P = e.position) == null ? void 0 : P.end),
                M = {
                    type: "list",
                    ordered: e.ordered,
                    start: e.start,
                    spread: e.spread,
                    children: o,
                    position: m
                };
            s.push(M)
        }
        t.children.splice(r, 1, ...s)
    })
};
class Ar extends N {
    unistNodeName() {
        return "textDirective"
    }
    customDirectiveName() {
        return A
    }
    static proseMirrorNodeName() {
        return A
    }
    proseMirrorNodeSpec() {
        return {
            group: "inline",
            inline: !0,
            atom: !0,
            selectable: !1,
            attrs: {
                timestamp: {
                    default: null
                }
            },
            toDOM: e => ["span", {
                "data-type": "hive-log",
                "data-timestamp": e.attrs.timestamp
            }],
            parseDOM: [{
                tag: 'span[data-type="hive-log"]',
                getAttrs(e) {
                    return {
                        timestamp: e.getAttribute("data-timestamp")
                    }
                }
            }]
        }
    }
    unistNodeToProseMirrorNodes({
        node: e,
        schema: r,
        convertedChildren: t
    }) {
        var o, i;
        if (!ce(e) || e.name !== A || e.type !== this.unistNodeName()) return W.addError("HiveLogExtension: unistNodeToProseMirrorNodes: node is not a directive node or name is not HIVE_LOG_DIRECTIVE_NAME", e), null;
        const s = {
            timestamp: (i = (o = e.attributes) == null ? void 0 : o.timestamp) != null ? i : null
        };
        return r.nodes[A].create(s, t)
    }
    proseMirrorNodeToUnistNodes(e) {
        return [{
            type: "textDirective",
            name: A,
            attributes: {
                timestamp: e.attrs.timestamp
            },
            children: [],
            data: {
                hName: A,
                hProperties: {
                    timestamp: e.attrs.timestamp
                }
            }
        }]
    }
}
const _r = (n, e, r, t) => n.children.map(s => r.handle(s, void 0, r, t)).join(""),
    Dr = (n, e, r, t) => r.safe(n.value, t).replaceAll("\\[", "[").replaceAll("\\&", "&"),
    Cr = n => "\\(".concat(n.value, "\\)");

function vr() {
    const n = this;
    n.compiler = e;

    function e(r) {
        return Je(r, x(c({}, n.data("settings")), {
            fences: !0,
            bullet: "-",
            bulletOther: "*",
            listItemIndent: "one",
            resourceLink: !0,
            tightDefinitions: !0,
            rule: "-",
            handlers: {
                text: Dr,
                startend: _r,
                inlineMath: Cr
            },
            extensions: n.data("toMarkdownExtensions") || []
        }))
    }
}
const fe = [Qe, [Xe, {
        singleTilde: !1
    }],
    [qe, {
        singleDollarTextMath: !1
    }], We, je, Ge, ze, Ir, vr, Ve
];
class Sr extends He {
    dependencies() {
        const e = Pe(Le());
        return [new yr, new G, new er, new or, new dr, new Nr, new $e, new Mr, new hr, new fr, new wr, new gr, new Ze, new C, new F, new Ue, new ue, new $, new br, new v, new Er, new he, new Me, ...e ? [new mr] : [], ...Fe() ? [new Ar] : []]
    }
    unifiedInitializationHook(e) {
        return e.use(fe)
    }
}
const qr = Object.freeze(Object.defineProperty({
    __proto__: null,
    CANVAS_REMARK_PLUGINS: fe,
    MarkdownExtension: Sr
}, Symbol.toStringTag, {
    value: "Module"
}));
export {
    or as B, mr as C, Mr as H, gr as I, Ze as L, Sr as M, F as O, br as S, Er as T, $ as U, pr as a, Nr as b, yr as c, er as d, dr as e, hr as f, he as g, Me as h, vr as i, qr as p, Ir as s, nr as t
};
//# sourceMappingURL=fgxxkkb4il90gii6.js.map