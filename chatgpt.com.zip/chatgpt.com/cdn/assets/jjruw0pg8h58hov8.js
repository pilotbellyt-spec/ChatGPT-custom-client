var Qe = Object.freeze,
    $e = Object.defineProperty,
    Mt = Object.defineProperties;
var yt = Object.getOwnPropertyDescriptors;
var Ke = Object.getOwnPropertySymbols;
var pt = Object.prototype.hasOwnProperty,
    vt = Object.prototype.propertyIsEnumerable;
var Ye = (t, s, o) => s in t ? $e(t, s, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: o
    }) : t[s] = o,
    M = (t, s) => {
        for (var o in s || (s = {})) pt.call(s, o) && Ye(t, o, s[o]);
        if (Ke)
            for (var o of Ke(s)) vt.call(s, o) && Ye(t, o, s[o]);
        return t
    },
    te = (t, s) => Mt(t, yt(s));
var Ne = (t, s) => Qe($e(t, "raw", {
    value: Qe(s || t.slice())
}));
import {
    e as ce,
    a as pe,
    u as ge,
    f as ve,
    r as a,
    j as e,
    M as d,
    i as ot,
    b as rt
} from "./fg33krlcm0qyi6yw.js";
import {
    m as De,
    R as se,
    vE as Me,
    U as jt,
    vF as bt,
    l as ye,
    g2 as l,
    gJ as Ge,
    P as Y,
    b as je,
    iK as xe,
    b6 as Te,
    I as at,
    a9 as le,
    C as Re,
    bb as wt,
    o as Xe,
    b5 as kt,
    d3 as Ct,
    hv as Nt,
    hA as Je,
    F as nt,
    T as Ze
} from "./dykg4ktvbu3mhmdo.js";
import {
    q0 as it,
    d7 as ie,
    d8 as me,
    fy as _t,
    cL as Ae,
    d9 as de,
    o2 as St,
    q1 as lt,
    q2 as Ht,
    d5 as dt,
    jo as Tt,
    d6 as ct,
    q3 as Dt,
    q4 as Gt,
    q5 as Rt,
    cV as mt,
    ca as At,
    c$ as Ft,
    y as Pt,
    cx as Ot,
    cw as Et,
    da as Lt
} from "./k15yxxoybkkir2ou.js";
import {
    S as It
} from "./ni16khhtjgvldr4m.js";
import {
    T as Z
} from "./hn5e71c3hkpkv00z.js";
import {
    t as ut,
    a as Ut,
    M as qt,
    R as Bt
} from "./cgt1h5qo3k52ojx3.js";
const zt = "https://help.openai.com/en/articles/8590148-memory-faq";

function ft({
    memory: t,
    gizmo: s,
    className: o,
    readOnly: y,
    showDivider: b,
    inlineComponent: c
}) {
    var X, oe;
    const x = ce(),
        u = De(),
        G = pe(),
        w = je(),
        U = it(w),
        {
            mutate: v,
            isPending: O
        } = ge({
            mutationFn: async ({
                memoryId: k,
                status: J
            }) => {
                const {
                    success: Q
                } = await se.safePatch("/memories/{memory_id}/status", {
                    parameters: {
                        path: {
                            memory_id: k
                        }
                    },
                    requestBody: {
                        status: J
                    }
                });
                if (!Q) throw new Error("An error occurred while updating the memory status")
            },
            onSettled: () => {
                G.invalidateQueries({
                    queryKey: ie(s == null ? void 0 : s.id)
                }), G.invalidateQueries({
                    queryKey: me()
                })
            },
            onError: () => {
                u.danger(P.somethingWentWrong, {
                    id: "memoryUpdateStatusFailed",
                    toastId: "memory_update_status_failed"
                })
            }
        }),
        {
            mutate: R,
            isPending: q
        } = ge({
            mutationFn: async k => {
                const {
                    success: J
                } = await se.safeDelete("/memories/{memory_id}", {
                    parameters: {
                        path: {
                            memory_id: k
                        }
                    },
                    requestBody: {
                        gizmo_id: s == null ? void 0 : s.id
                    }
                });
                if (!J) throw new Error("An error occurred while deleting the memory")
            },
            onSettled: () => {
                G.invalidateQueries({
                    queryKey: ie(s == null ? void 0 : s.id)
                }), G.invalidateQueries({
                    queryKey: me()
                })
            },
            onError: () => {
                u.danger(P.deleteFailed, {
                    id: "memoryDeleteFailed",
                    toastId: "memory_delete_failed"
                })
            }
        }),
        [S, E] = a.useState(!1);

    function A(k) {
        const J = new Date,
            Q = k.getFullYear() === J.getFullYear();
        try {
            return x.formatDate(k, M({
                month: "long",
                day: "numeric"
            }, Q ? {} : {
                year: "numeric"
            }))
        } catch (n) {
            const i = {
                month: "long",
                day: "numeric"
            };
            return Q || (i.year = "numeric"), k.toLocaleDateString(void 0, i)
        }
    }
    const f = x.formatMessage(P.moreOptions),
        N = ((X = t.status) != null ? X : Me) === "cold",
        j = N ? () => {
            Y.logEvent("Memory Manage Modal Memory Unarchive Clicked"), v({
                memoryId: t.id,
                status: "warm"
            }, {
                onSuccess: () => {
                    u.successNeutral(x.formatMessage(P.memoryPrioritized), {
                        duration: 4,
                        hasCloseButton: !1
                    })
                }
            })
        } : void 0,
        T = () => {
            Y.logEvent("Memory Manage Modal Memory Delete Clicked"), E(!0)
        },
        z = N && t.last_updated ? P.deprioritizedOnNoReason : null,
        m = N && t.last_updated ? {
            actor: t.last_updated.actor === "user" ? x.formatMessage(P.you) : "ChatGPT",
            date: t.last_updated.timestamp != null ? (() => {
                const k = jt(t.last_updated.timestamp);
                return A(k)
            })() : x.formatMessage(P.unknownDate)
        } : void 0,
        $ = t.conversation_id,
        C = $ ? "/c/".concat($) : void 0,
        B = t.updated_at ? (() => {
            const k = bt(t.updated_at);
            return A(k)
        })() : void 0,
        ee = N ? null : C ? B ? P.savedOnFromChat : P.savedFromChat : B ? P.savedOnNoChat : null,
        W = N ? void 0 : C ? {
            date: B,
            link: k => e.jsx("a", {
                href: C,
                className: "underline",
                target: "_blank",
                rel: "noreferrer",
                children: k
            })
        } : B ? {
            date: B
        } : void 0;
    return e.jsxs(e.Fragment, {
        children: [e.jsxs("div", {
            className: ye("group border-token-border-default flex w-full flex-row items-center justify-between gap-3 border-b px-3", b === !1 && "border-b-0", (q || O) && "pointer-events-none opacity-50", o),
            children: [e.jsxs("div", {
                className: "flex min-w-0 flex-1 flex-row items-center gap-2",
                children: [e.jsx("div", {
                    className: ye("min-w-0 flex-initial py-3 [overflow-wrap:anywhere] whitespace-pre-wrap", N && "text-token-text-tertiary"),
                    children: t.content
                }), c || null]
            }), e.jsx("div", {
                className: "flex shrink-0 justify-end",
                children: e.jsx(Z.Actions, {
                    children: !y && e.jsxs(l.Root, {
                        children: [e.jsx(l.Trigger, {
                            asChild: !0,
                            children: e.jsx("button", {
                                "aria-label": f,
                                className: "text-token-text-tertiary hover:text-token-text-secondary pointer-events-none size-8! opacity-0 group-hover:pointer-events-auto group-hover:opacity-100",
                                children: e.jsx(Ge, {
                                    className: "icon"
                                })
                            })
                        }), e.jsx(l.Portal, {
                            children: e.jsxs(l.Content, {
                                align: "start",
                                size: "small",
                                className: "max-w-[280px] min-w-0",
                                children: [j && U && e.jsx(l.Item, {
                                    icon: _t,
                                    onClick: j,
                                    children: x.formatMessage(P.prioritizeThisMemory)
                                }), e.jsx(l.Item, {
                                    icon: Ae,
                                    color: "danger",
                                    onClick: T,
                                    children: x.formatMessage(P.delete)
                                }), z && m && e.jsx(l.Group, {
                                    children: e.jsx("div", {
                                        className: "text-token-text-tertiary px-4 py-2 text-[13px] leading-4",
                                        children: e.jsx(d, te(M({}, z), {
                                            values: m
                                        }))
                                    })
                                }), ee && W && e.jsx(l.Group, {
                                    children: e.jsx("div", {
                                        className: "text-token-text-tertiary px-4 py-2 text-[13px] leading-4",
                                        children: e.jsx(d, te(M({}, ee), {
                                            values: W
                                        }))
                                    })
                                })]
                            })
                        })]
                    })
                })
            })]
        }), !y && S && e.jsx(de, {
            isOpen: !0,
            primaryButtonColor: "danger",
            title: x.formatMessage(P.deleteConfirmTitle),
            confirmText: x.formatMessage(P.delete),
            onConfirm: () => {
                Y.logEvent("Memory Manage Modal Memory Delete Confirmed"), R(t.id, {
                    onSuccess: () => {
                        u.successNeutral(x.formatMessage(P.memoryDeleted), {
                            duration: 4,
                            hasCloseButton: !1
                        })
                    }
                }), E(!1)
            },
            onClose: () => {
                E(!1)
            },
            children: e.jsx("div", {
                className: "mb-2 text-sm",
                children: x.formatMessage(P.deleteConfirmDescription, {
                    name: (oe = s == null ? void 0 : s.name) != null ? oe : "ChatGPT",
                    title: e.jsx("strong", {
                        children: ut(t.content, {
                            length: 130,
                            omission: "..."
                        })
                    }),
                    link: k => e.jsx("a", {
                        href: zt,
                        target: "_blank",
                        rel: "noreferrer",
                        className: "underline",
                        children: k
                    })
                })
            })
        })]
    })
}
const P = ve({
        deprioritizedOnNoReason: {
            id: "MemoryRow.deprioritizedOnNoReason",
            defaultMessage: "Deprioritized by {actor} on {date}."
        },
        deprioritizedOnWithReason: {
            id: "MemoryRow.deprioritizedOnWithReason",
            defaultMessage: "Deprioritized by {actor} on {date} because {reason}."
        },
        delete: {
            id: "MemoryRow.delete",
            defaultMessage: "Delete"
        },
        deleteConfirmTitle: {
            id: "MemoryRow.deleteConfirmTitle",
            defaultMessage: "Delete this memory?"
        },
        deleteConfirmDescription: {
            id: "MemoryRow.deleteConfirmDescription",
            defaultMessage: '"{title}" will be deleted. {name} may not remember this information going forward. <link>Learn more</link>'
        },
        deleteFailed: {
            id: "MemoryRow.deleteFailed",
            defaultMessage: "Failed to forget memory"
        },
        moreOptions: {
            id: "MemoryRow.moreOptions",
            defaultMessage: "More options"
        },
        savedFromChat: {
            id: "MemoryRow.savedFromChat",
            defaultMessage: "Saved from a <link>chat</link>."
        },
        savedOnFromChat: {
            id: "MemoryRow.savedOnFromChat",
            defaultMessage: "Saved on {date} from a <link>chat</link>."
        },
        savedOnNoChat: {
            id: "MemoryRow.savedOnNoChat",
            defaultMessage: "Saved on {date}."
        },
        somethingWentWrong: {
            id: "MemoryRow.somethingWentWrong",
            defaultMessage: "Something went wrong..."
        },
        memoryPrioritized: {
            id: "MemoryRow.memoryPrioritized",
            defaultMessage: "Memory prioritized"
        },
        memoryDeleted: {
            id: "MemoryRow.memoryDeleted",
            defaultMessage: "Memory deleted"
        },
        prioritizeThisMemory: {
            id: "MemoryRow.prioritizeThisMemory",
            defaultMessage: "Prioritize this memory"
        },
        unknownDate: {
            id: "MemoryRow.unknownDate",
            defaultMessage: "Unknown date"
        },
        you: {
            id: "MemoryRow.you",
            defaultMessage: "You"
        }
    }),
    Wt = 80,
    Vt = 100;

function Qt(t) {
    const s = St(),
        o = lt();
    return s && !o && t != null && t > Wt
}

function Kt({
    memoryFullPct: t,
    className: s
}) {
    if (!Qt(t)) return null;
    const y = t;
    return e.jsx("div", {
        className: ye("flex items-center justify-center", s),
        children: e.jsx("div", {
            className: ye("flex items-center justify-center gap-0.5 rounded-[8px] p-1 text-sm leading-4 font-semibold whitespace-nowrap", y >= Vt ? "bg-token-bg-status-error text-token-interactive-label-danger-secondary-default" : "bg-token-bg-status-warning text-token-text-status-warning"),
            children: e.jsx(d, {
                id: "R17Ykc",
                defaultMessage: "{memoryFullPct}% full",
                values: {
                    memoryFullPct: y
                }
            })
        })
    })
}
const _e = ve({
        disableOptimizeTitle: {
            id: "personalizationSettings.disableOptimizeTitle",
            defaultMessage: "Turn off automatic memory management?"
        },
        turnOff: {
            id: "common.turnOff",
            defaultMessage: "Turn off"
        },
        disableOptimizeDescription: {
            id: "personalizationSettings.disableOptimizeDescription",
            defaultMessage: "Once memory is full, ChatGPT won't save new memories, and responses may feel less personal. {link}"
        }
    }),
    Yt = ({
        isOpen: t = !1,
        setShowDisableOMConfirm: s,
        goldenHourMutation: o
    }) => {
        const y = ce();
        return e.jsx(de, {
            isOpen: t,
            title: y.formatMessage(_e.disableOptimizeTitle),
            confirmText: y.formatMessage(_e.turnOff),
            primaryButtonColor: "danger",
            onConfirm: () => {
                o.mutate({
                    setting: Te.GoldenHour,
                    value: !1
                }), s(!1)
            },
            onClose: () => {
                s(!1)
            },
            children: e.jsx("div", {
                className: "mb-2 text-sm",
                children: e.jsx(d, te(M({}, _e.disableOptimizeDescription), {
                    values: {
                        link: b => e.jsx(xe, {
                            href: "https://help.openai.com/en/articles/8590148-memory-faq",
                            className: "underline",
                            children: b
                        })
                    }
                }))
            })
        })
    };

function $t({
    label: t,
    active: s,
    onClick: o
}) {
    return e.jsx("button", {
        onClick: o,
        className: "rounded-lg px-3 py-2.5 text-start text-sm " + (s ? "dark:bg-token-interactive-bg-secondary-press dark:hover:bg-token-interactive-bg-secondary-hover bg-[#0000000f] hover:bg-[#0000000a]" : "dark:hover:bg-token-interactive-bg-secondary-hover hover:bg-[#0000000a]"),
        children: e.jsx("div", {
            className: "font-semibold text-wrap",
            children: t
        })
    })
}

function Xt({
    isOpen: t,
    onClose: s
}) {
    const o = ce(),
        y = je();
    at(y);
    const b = pe(),
        {
            data: c,
            isLoading: x,
            isFetching: u,
            refetch: G
        } = Ht(50, t),
        w = a.useMemo(() => Array.isArray(c == null ? void 0 : c.history) ? c.history : [], [c]),
        U = x || u && !c,
        [v, O] = a.useState(null),
        [R, q] = a.useState(!1),
        [S, E] = a.useState(!1),
        [A, f] = a.useState(!1),
        [H, N] = a.useState(!1),
        j = a.useCallback(async () => {
            await G()
        }, [G]),
        T = a.useCallback(n => {
            const i = new Date((n || 0) * 1e3),
                h = i.getFullYear() === new Date().getFullYear();
            try {
                const D = o.formatDate(i, M({
                        month: "long",
                        day: "numeric"
                    }, h ? {} : {
                        year: "numeric"
                    })),
                    _ = o.formatTime(i, {
                        hour: "numeric",
                        minute: "2-digit"
                    });
                return "".concat(D, ", ").concat(_)
            } catch (D) {
                const _ = {
                    month: "long",
                    day: "numeric"
                };
                h || (_.year = "numeric");
                const g = i.toLocaleDateString(void 0, _),
                    L = i.toLocaleTimeString(void 0, {
                        hour: "numeric",
                        minute: "2-digit"
                    });
                return "".concat(g, ", ").concat(L)
            }
        }, [o]),
        z = a.useMemo(() => w.map(n => {
            var i;
            return {
                id: (i = n.id) != null ? i : "__current__",
                label: T(n.snapshot_time)
            }
        }), [w, T]),
        m = a.useMemo(() => {
            var i, h, D;
            if (w.length === 0) return null;
            if (v == null) return (h = (i = w.find(_ => _.id == null)) != null ? i : w[0]) != null ? h : null;
            const n = v === "__current__" ? null : v;
            return (D = w.find(_ => {
                var g;
                return ((g = _.id) != null ? g : "__current__") === (n != null ? n : "__current__")
            })) != null ? D : null
        }, [w, v]),
        $ = a.useMemo(() => m ? T(m.snapshot_time) : "", [m, T]),
        C = a.useCallback(() => {
            !m || m.id == null || f(!0)
        }, [m]),
        B = a.useCallback(async () => {
            if (!(!m || m.id == null)) {
                N(!0);
                try {
                    const {
                        success: n
                    } = await se.safeDelete("/memories/history/{memory_history_id}", {
                        parameters: {
                            path: {
                                memory_history_id: m.id
                            }
                        }
                    });
                    if (!n) throw new Error("failed");
                    await j(), O(null)
                } catch (n) {} finally {
                    N(!1), f(!1)
                }
            }
        }, [m, j]),
        ee = (v != null ? v : "__current__") === "__current__",
        W = (m == null ? void 0 : m.id) != null && !ee;
    a.useEffect(() => {
        if (!t || U) return;
        if (w.length === 0) {
            O(h => h === null ? h : null);
            return
        }
        const n = new Set(w.map(h => {
                var D;
                return (D = h.id) != null ? D : "__current__"
            })),
            i = n.has("__current__");
        O(h => {
            var _, g;
            const D = h != null ? h : "__current__";
            return n.has(D) ? h : i ? null : (g = (_ = w[0]) == null ? void 0 : _.id) != null ? g : null
        })
    }, [t, U, w]);

    function X(n) {
        var g, L;
        const i = n.updated_at != null ? Date.parse(n.updated_at) : NaN;
        let h = (g = n.last_updated) == null ? void 0 : g.timestamp;
        h = h != null ? h : (L = n.created_timestamp) != null ? L : void 0;
        const D = h != null ? h * 1e3 : NaN,
            _ = Math.max(Number.isFinite(i) ? i : -1 / 0, Number.isFinite(D) ? D : -1 / 0);
        return Number.isFinite(_) ? _ : 0
    }
    const {
        currentMemories: oe,
        deprioritizedMemories: k
    } = a.useMemo(() => {
        var _, g;
        const n = (_ = m == null ? void 0 : m.memories) != null ? _ : [],
            i = [],
            h = [];
        for (const L of n)((g = L.status) != null ? g : Me) === "cold" ? h.push(L) : i.push(L);
        const D = (L, re) => X(re) - X(L);
        return {
            currentMemories: i.sort(D),
            deprioritizedMemories: h.sort(D)
        }
    }, [m]), J = a.useMemo(() => [...oe, ...k], [oe, k]);
    let Q = null;
    return U ? Q = e.jsxs("div", {
        className: "border-token-border-default flex w-full flex-col rounded-lg border",
        children: [e.jsxs("div", {
            className: "border-token-border-default relative flex flex-row items-center justify-between gap-3 px-4 py-5",
            children: [e.jsxs("div", {
                className: "flex w-48 flex-col gap-2 px-3",
                children: [e.jsx("div", {
                    className: "bg-token-bg-tertiary h-5 w-48 animate-pulse rounded"
                }), e.jsx("div", {
                    className: "bg-token-bg-tertiary h-3 w-28 animate-pulse rounded"
                })]
            }), e.jsx("div", {
                className: "bg-token-bg-tertiary h-8 w-36 animate-pulse rounded-full"
            }), e.jsx("span", {
                className: "sr-only",
                children: e.jsx(d, M({}, I.loading))
            })]
        }), e.jsx("div", {
            className: "flex flex-1 overflow-y-auto px-4",
            children: e.jsx("div", {
                className: "w-full",
                children: Array.from({
                    length: 6
                }).map((n, i) => {
                    const h = Math.floor(Math.random() * 193) + 128;
                    return e.jsx("div", {
                        className: "border-token-border-default flex items-start gap-3 border-b py-4",
                        children: e.jsx("div", {
                            className: "bg-token-bg-tertiary h-6 animate-pulse rounded",
                            style: {
                                width: "".concat(h, "px")
                            }
                        })
                    }, i)
                })
            })
        })]
    }) : m ? Q = e.jsxs("div", {
        className: "border-token-border-default flex w-full flex-col rounded-lg border",
        children: [e.jsxs("div", {
            className: "border-token-border-default group relative flex flex-row items-center justify-between gap-2 px-4 py-5",
            children: [e.jsx("div", {
                className: "min-w-0 flex-1 px-3",
                children: e.jsx("div", {
                    className: "text-lg font-semibold",
                    children: $
                })
            }), e.jsxs("div", {
                className: "flex h-full shrink-0 items-start gap-2 pe-1",
                children: [W ? e.jsxs(l.Root, {
                    children: [e.jsx(l.Trigger, {
                        asChild: !0,
                        children: e.jsx("button", {
                            "aria-label": o.formatMessage(I.moreOptions),
                            className: "text-token-text-tertiary hover:text-token-text-secondary size-8!",
                            children: e.jsx(Ge, {
                                className: "icon"
                            })
                        })
                    }), e.jsx(l.Portal, {
                        children: e.jsx(l.Content, {
                            align: "start",
                            size: "small",
                            className: "max-w-[200px] min-w-0",
                            children: e.jsx(l.Item, {
                                icon: Ae,
                                color: "danger",
                                onClick: C,
                                className: "gap-2.5! pe-3!",
                                children: o.formatMessage(I.deleteSnapshot)
                            })
                        })
                    })]
                }) : null, e.jsx(le, {
                    color: "secondary",
                    onClick: () => q(!0),
                    disabled: ee,
                    style: {
                        pointerEvents: ee ? "none" : void 0
                    },
                    children: m.id == null ? e.jsx(d, M({}, I.currentVersion)) : e.jsx(d, M({}, I.restoreThisVersion))
                })]
            })]
        }), oe.length + k.length === 0 ? e.jsx("div", {
            className: "text-token-text-tertiary flex flex-1 items-center justify-center p-4 text-sm",
            children: e.jsx(d, M({}, I.noMemories))
        }) : e.jsx("div", {
            className: "flex flex-1 overflow-y-auto px-4",
            children: e.jsx("div", {
                className: "w-full text-sm",
                children: J.map((n, i) => e.jsx(ft, {
                    memory: n,
                    gizmo: void 0,
                    readOnly: !0,
                    showDivider: i !== J.length - 1
                }, n.id))
            })
        })]
    }) : Q = e.jsx("div", {
        className: "border-token-border-default text-token-text-tertiary flex h-full w-full items-center justify-center rounded-lg border p-4 text-sm",
        children: e.jsx(d, M({}, I.noMemories))
    }), e.jsxs(e.Fragment, {
        children: [e.jsx(Re, {
            testId: "modal-saved-memories-history",
            isOpen: t,
            onClose: s,
            size: "custom",
            className: "max-h-[85vh] max-md:min-h-[60vh] md:h-[740px] md:max-w-[960px]",
            type: "success",
            title: o.formatMessage(I.title),
            showCloseButton: !0,
            children: e.jsxs("div", {
                className: "flex h-full min-h-0 gap-4",
                children: [e.jsx("div", {
                    className: "w-60 shrink-0 overflow-y-auto",
                    children: e.jsx("div", {
                        className: "flex flex-col pb-2",
                        children: U ? Array.from({
                            length: 6
                        }).map((n, i) => e.jsx("div", {
                            className: "rounded px-3 py-2.5",
                            children: e.jsx("div", {
                                className: "bg-token-bg-tertiary h-4 w-40 animate-pulse rounded"
                            })
                        }, i)) : e.jsxs(e.Fragment, {
                            children: [z.map(n => {
                                const i = (v != null ? v : "__current__") === n.id;
                                return e.jsx($t, {
                                    label: n.label,
                                    active: i,
                                    onClick: () => O(n.id)
                                }, n.id)
                            }), z.length === 0 ? e.jsx("div", {
                                className: "text-sm",
                                children: e.jsx(d, M({}, I.noHistory))
                            }) : null]
                        })
                    })
                }), e.jsx("div", {
                    className: "flex min-w-0 flex-1 overflow-hidden",
                    children: Q
                })]
            })
        }), A && (m == null ? void 0 : m.id) != null && e.jsx(de, {
            isOpen: !0,
            title: o.formatMessage(I.confirmDeleteTitle),
            confirmText: o.formatMessage(I.confirmDeleteCta),
            primaryButtonColor: "danger",
            loading: H,
            onConfirm: B,
            onClose: () => {
                H || f(!1)
            },
            children: e.jsx("div", {
                className: "text-token-text-secondary mb-2 text-sm",
                children: e.jsx(d, M({}, I.confirmDeleteBody))
            })
        }), R && e.jsx(de, {
            isOpen: !0,
            title: o.formatMessage(I.confirmRestoreTitle),
            confirmText: o.formatMessage(I.confirmRestoreCta),
            primaryButtonColor: "danger",
            loading: S,
            onConfirm: async () => {
                if (!(!m || m.id == null)) {
                    E(!0);
                    try {
                        const {
                            success: n
                        } = await se.safePost("/memories/history/{memory_history_id}/revert", {
                            parameters: {
                                path: {
                                    memory_history_id: m.id
                                }
                            }
                        });
                        if (!n) throw new Error("failed");
                        await j(), O(null), b.invalidateQueries({
                            queryKey: ["memories"]
                        })
                    } catch (n) {} finally {
                        q(!1), E(!1)
                    }
                }
            },
            onClose: () => q(!1),
            children: e.jsx("div", {
                className: "mb-2 text-sm",
                children: e.jsx(d, M({}, I.confirmRestoreBody))
            })
        })]
    })
}
const I = ve({
    title: {
        id: "SavedMemoriesHistoryModal.title",
        defaultMessage: "Saved memories history"
    },
    loading: {
        id: "SavedMemoriesHistoryModal.loading",
        defaultMessage: "Loading..."
    },
    noHistory: {
        id: "SavedMemoriesHistoryModal.noHistory",
        defaultMessage: "No checkpoints"
    },
    noMemories: {
        id: "SavedMemoriesHistoryModal.noMemories",
        defaultMessage: "No memories"
    },
    currentVersion: {
        id: "SavedMemoriesHistoryModal.currentVersion",
        defaultMessage: "Current version"
    },
    restoreThisVersion: {
        id: "SavedMemoriesHistoryModal.restoreThisVersion",
        defaultMessage: "Restore this version"
    },
    confirmRestoreTitle: {
        id: "SavedMemoriesHistoryModal.confirmRestoreTitle",
        defaultMessage: "Restore this version?"
    },
    confirmRestoreBody: {
        id: "SavedMemoriesHistoryModal.confirmRestoreBody",
        defaultMessage: "This will replace your current saved memories."
    },
    confirmRestoreCta: {
        id: "SavedMemoriesHistoryModal.confirmRestoreCta",
        defaultMessage: "Restore"
    },
    cancel: {
        id: "common.cancel",
        defaultMessage: "Cancel"
    },
    moreOptions: {
        id: "SavedMemoriesHistoryModal.moreOptions",
        defaultMessage: "More options"
    },
    deleteSnapshot: {
        id: "SavedMemoriesHistoryModal.deleteSnapshot",
        defaultMessage: "Delete this version"
    },
    confirmDeleteTitle: {
        id: "SavedMemoriesHistoryModal.confirmDeleteTitle",
        defaultMessage: "Delete this version?"
    },
    confirmDeleteBody: {
        id: "SavedMemoriesHistoryModal.confirmDeleteBody",
        defaultMessage: "This cannot be undone."
    },
    confirmDeleteCta: {
        id: "SavedMemoriesHistoryModal.confirmDeleteCta",
        defaultMessage: "Delete"
    }
});
var tt;
const he = nt.div(tt || (tt = Ne(["flex h-full items-center justify-center pb-8 text-sm text-token-text-tertiary rounded-lg border border-token-border-default"])));

function et(t) {
    var c, x;
    const s = t.updated_at != null ? Date.parse(t.updated_at) : NaN;
    let o = (c = t.last_updated) == null ? void 0 : c.timestamp;
    o = o != null ? o : (x = t.created_timestamp) != null ? x : void 0;
    const y = o != null ? o * 1e3 : NaN,
        b = Math.max(Number.isFinite(s) ? s : -1 / 0, Number.isFinite(y) ? y : -1 / 0);
    return Number.isFinite(b) ? b : 0
}

function ds({
    isOpen: t,
    onClose: s,
    initialGizmoId: o,
    contextScopes: y,
    requiredContextScopes: b
}) {
    var Ie, Ue, qe, Be, ze, We, Ve;
    const c = je(),
        x = ot(),
        u = ce(),
        G = wt(),
        w = De(),
        U = dt(),
        [v, O] = a.useState(o),
        [R, q] = a.useState(!1),
        [S, E] = a.useState(""),
        [A, f] = a.useState(!1),
        [H, N] = a.useState(!1),
        [j, T] = a.useState(!1),
        [z, m] = a.useState(!1),
        [$, C] = a.useState(!1),
        [B, ee] = a.useState(!1),
        W = a.useRef(null),
        X = Tt(),
        oe = (Ie = Xe(c, "3453210147")) != null ? Ie : !1;
    Xe(c, "1900515849");
    const k = it(c),
        {
            data: J,
            isLoading: Q
        } = kt(Te.GoldenHour),
        n = J !== void 0 && k,
        i = lt(),
        h = Ct(!0),
        D = a.useCallback(r => {
            if (!r && i) {
                C(!0);
                return
            }
            h.mutate({
                setting: Te.GoldenHour,
                value: r
            }), Y.logEventWithStatsig("Personalization Settings Automatic Memory Management ".concat(r ? "Enabled" : "Disabled"), "chatgpt_personalization_settings_automatic_memory_management_".concat(r ? "enabled" : "disabled"))
        }, [h, i]),
        _ = Q || h.isPending,
        {
            data: g,
            isLoading: L,
            isError: re,
            refetch: Fe
        } = ct({
            gizmoId: v,
            enabled: U,
            contextScopes: y,
            requiredContextScopes: b
        }),
        Pe = (Ue = g == null ? void 0 : g.memories) != null ? Ue : [],
        be = Pe.length,
        ue = [...Pe].sort((r, F) => (R ? 1 : -1) * (et(r) - et(F))),
        we = (() => {
            const r = S.trim();
            if (r === "") return ue;
            const F = new Set(Dt(ue, r, K => ({
                targets: [K.content]
            }), {
                locale: u.locale,
                maxResults: ue.length
            }).map(K => K.id));
            return ue.filter(K => F.has(K.id))
        })(),
        Oe = we.filter(r => {
            var F;
            return ((F = r.status) != null ? F : Me) !== "cold"
        }),
        Ee = we.filter(r => {
            var F;
            return ((F = r.status) != null ? F : Me) === "cold"
        }),
        ae = a.useMemo(() => [...Oe, ...Ee], [Oe, Ee]);
    a.useEffect(() => () => {
        W.current && (clearTimeout(W.current), W.current = null)
    }, []);
    const ht = a.useCallback(async r => {
            if (ae.length === 0) return;
            const F = ae.map(K => {
                var fe;
                return (fe = K.content) != null ? fe : ""
            }).join("\n");
            try {
                await Nt(F, w, r), ee(!0), W.current && clearTimeout(W.current), W.current = setTimeout(() => {
                    ee(!1), W.current = null
                }, 2e3)
            } catch (K) {}
        }, [ae, w]),
        {
            data: ke,
            refetch: es
        } = rt({
            queryKey: ["memory_gizmos"],
            queryFn: () => se.safeGet("/memories/gizmos"),
            refetchOnMount: "always"
        }),
        Ce = Gt(c, (qe = g == null ? void 0 : g.memoryFullPct) != null ? qe : 0) !== "control",
        V = [{
            id: void 0,
            name: "ChatGPT",
            iconUrl: null
        }, ...(Be = ke == null ? void 0 : ke.items.map(({
            gizmo: r
        }) => {
            var F;
            return {
                id: r.id,
                name: r.display.name,
                iconUrl: (F = r.display.profile_picture_url) != null ? F : null
            }
        })) != null ? Be : []].find(r => r.id === v);
    a.useEffect(() => {
        !L && !re && v !== void 0 && be === 0 && O(void 0)
    }, [L, re, v, be]);
    const xt = X && i ? p.descriptionOptimizeOn : X && n ? p.descriptionPaid : X ? p.descriptionFreeMoonshine : p.descriptionFree,
        Le = u.formatMessage(B ? p.copiedAll : p.copyAll),
        gt = r => e.jsx(xe, {
            href: Se,
            className: "underline",
            children: r
        });
    let ne;
    return L ? ne = e.jsx(he, {
        className: "border-none",
        children: e.jsx(d, M({}, p.loading))
    }) : re ? ne = e.jsx(he, {
        className: "border-none",
        children: e.jsxs("div", {
            className: "max-w-sm text-center",
            children: [e.jsx("div", {
                className: "mb-4 text-red-500",
                children: e.jsx(d, {
                    id: "MemoriesModal.somethingWentWrong",
                    defaultMessage: "Something went wrong..."
                })
            }), e.jsx("div", {
                children: e.jsx(le, {
                    color: "secondary",
                    size: "small",
                    onClick: () => {
                        Fe()
                    },
                    children: e.jsx(d, {
                        id: "MemoriesModal.retry",
                        defaultMessage: "Retry"
                    })
                })
            })]
        })
    }) : be === 0 ? ne = e.jsx(he, {
        className: "text-token-text-primary border-none",
        children: U ? e.jsxs("div", {
            className: "flex h-full max-w-sm flex-col items-center justify-center gap-0.5 text-center text-base",
            children: [e.jsx(Rt, {
                className: "icon-xl"
            }), e.jsx(d, te(M({}, p.noMemories), {
                values: {
                    name: (ze = V == null ? void 0 : V.name) != null ? ze : "ChatGPT"
                }
            }))]
        }) : e.jsx("div", {
            className: "flex h-full max-w-sm items-center justify-center text-center",
            children: e.jsx(d, M({}, p.noMemoriesAndDisabled))
        })
    }) : S.trim() !== "" && we.length === 0 ? ne = e.jsx(he, {
        className: "text-token-text-tertiary border-none",
        children: e.jsxs("div", {
            className: "flex h-full max-w-sm flex-col items-center justify-center gap-2 text-center text-base",
            children: [e.jsx(Je, {
                className: "icon-lg"
            }), e.jsx("div", {
                children: e.jsx(d, te(M({}, p.searchNoResults), {
                    values: {
                        query: S.trim()
                    }
                }))
            }), e.jsx("div", {
                children: e.jsx(le, {
                    color: "secondary",
                    size: "small",
                    onClick: () => {
                        T(!0)
                    },
                    children: e.jsx(d, M({}, p.viewHistory))
                })
            })]
        })
    }) : ne = e.jsx(Z.Root, {
        size: "compact",
        children: e.jsx(Z.Body, {
            children: ae.map((r, F) => {
                const K = V ? {
                        id: V.id,
                        name: V.name
                    } : void 0,
                    fe = {
                        memory: r,
                        gizmo: K,
                        showDivider: F !== ae.length - 1
                    };
                return e.jsx(ft, M({}, fe), r.id)
            })
        })
    }), e.jsxs(e.Fragment, {
        children: [e.jsxs(Re, {
            testId: "modal-golden-hour-memories",
            isOpen: t,
            size: "custom",
            className: "max-h-[85vh] px-2 py-2 max-md:min-h-[60vh] md:h-[740px] md:max-w-[680px]",
            headerClassName: "shrink-0",
            contentClassName: "h-full flex flex-col",
            type: "success",
            onClose: s,
            title: e.jsxs("div", {
                className: "flex items-center gap-1.5",
                children: [e.jsx("span", {
                    children: u.formatMessage(p.title)
                }), !Ce && e.jsx(Kt, {
                    memoryFullPct: g == null ? void 0 : g.memoryFullPct
                })]
            }),
            description: !Ce && e.jsx("div", {
                className: "text-token-text-secondary",
                children: u.formatMessage(xt, {
                    link: gt
                })
            }),
            showCloseButton: !0,
            isScrollable: !1,
            children: [e.jsxs("div", {
                className: "border-token-border-default w-full border-b pb-4",
                children: [Ce && e.jsx(Ut, {
                    memoryFullPct: g == null ? void 0 : g.memoryFullPct,
                    onUpgrade: () => {
                        var r;
                        Y.logEventWithStatsig("Memories Upgrade Button Clicked", "chatgpt_memories_upgrade_button_clicked_settings", {
                            memory_full_pct: (r = g == null ? void 0 : g.memoryFullPct) != null ? r : 0
                        }), mt(x, "chatgpt_memories_upgrade_button")
                    },
                    className: "mb-6"
                }), e.jsxs("div", {
                    className: "flex items-center justify-between gap-2",
                    children: [e.jsxs("div", {
                        className: "relative min-w-0 flex-1",
                        children: [e.jsx("div", {
                            className: "pointer-events-none absolute start-3 top-1/2 flex h-5 w-5 -translate-y-1/2 items-center justify-center",
                            children: e.jsx(Je, {
                                className: "icon text-token-text-tertiary"
                            })
                        }), e.jsx("input", {
                            type: "text",
                            id: "memories-search",
                            name: "memories-search",
                            placeholder: u.formatMessage(p.searchPlaceholder),
                            className: "border-token-border-default placeholder:text-token-text-tertiary/70 h-9.5 w-full max-w-[320px] rounded-full border bg-transparent ps-10 pe-3 text-sm outline-none focus:shadow-none focus:ring-0 focus:outline-none",
                            value: S,
                            onChange: r => E(r.target.value)
                        })]
                    }), e.jsxs("div", {
                        className: "flex items-center gap-0.5",
                        children: [oe && e.jsx("button", {
                            type: "button",
                            "aria-label": Le,
                            title: Le,
                            disabled: ae.length === 0,
                            onClick: ht,
                            className: "text-token-text-tertiary hover:text-token-text-secondary hover:bg-token-interactive-bg-tertiary-hover inline-flex size-8! items-center justify-center rounded-md disabled:cursor-not-allowed disabled:opacity-40",
                            children: B ? e.jsx(At, {
                                className: "icon"
                            }) : e.jsx(Ft, {
                                className: "icon"
                            })
                        }), e.jsxs(l.Root, {
                            children: [e.jsx(l.Trigger, {
                                asChild: !0,
                                children: e.jsx("button", {
                                    "aria-label": u.formatMessage(p.sortAria),
                                    className: "text-token-text-tertiary hover:text-token-text-secondary hover:bg-token-interactive-bg-tertiary-hover inline-flex size-8! items-center justify-center rounded-md",
                                    children: e.jsx(It, {
                                        className: "icon"
                                    })
                                })
                            }), e.jsx(l.Portal, {
                                children: e.jsxs(l.Content, {
                                    align: "start",
                                    size: "auto",
                                    className: "max-w-[280px] min-w-[165px]",
                                    children: [e.jsx(l.Group, {
                                        children: e.jsx("div", {
                                            className: "text-token-text-tertiary px-4 pt-2.5 pb-2 text-[13px] leading-4",
                                            children: e.jsx(d, M({}, p.sortHeader))
                                        })
                                    }), e.jsxs(l.RadioGroup, {
                                        value: R ? "oldest" : "newest",
                                        onValueChange: r => q(r === "oldest"),
                                        children: [e.jsx(l.RadioItem, {
                                            value: "newest",
                                            children: e.jsx(d, M({}, p.newestFirst))
                                        }), e.jsx(l.RadioItem, {
                                            value: "oldest",
                                            children: e.jsx(d, M({}, p.oldestFirst))
                                        })]
                                    })]
                                })
                            })]
                        }), e.jsxs(l.Root, {
                            children: [e.jsx(l.Trigger, {
                                asChild: !0,
                                children: e.jsx("button", {
                                    "aria-label": u.formatMessage(p.moreOptionsAria),
                                    className: "text-token-text-tertiary hover:text-token-text-secondary hover:bg-token-interactive-bg-tertiary-hover inline-flex size-8! items-center justify-center rounded-md",
                                    children: e.jsx(Ge, {
                                        className: "icon"
                                    })
                                })
                            }), e.jsx(l.Portal, {
                                children: e.jsxs(l.Content, {
                                    align: "start",
                                    size: "small",
                                    className: "max-w-[280px] min-w-0",
                                    children: [n && e.jsx(l.Group, {
                                        children: e.jsx(l.CheckboxItem, {
                                            label: u.formatMessage(p.autoManageTitle),
                                            checked: i,
                                            disabled: _,
                                            onCheckedChange: r => {
                                                D(r === !0)
                                            }
                                        })
                                    }), e.jsxs(l.Group, {
                                        children: [e.jsx(l.Item, {
                                            onClick: () => {
                                                T(!0)
                                            },
                                            children: e.jsx(d, M({}, p.viewHistory))
                                        }), e.jsx(l.Item, {
                                            color: "danger",
                                            onClick: () => {
                                                N(!1), f(!0)
                                            },
                                            children: e.jsx(d, M({}, p.deleteAllMemories))
                                        })]
                                    })]
                                })
                            })]
                        })]
                    })]
                })]
            }), e.jsx("div", {
                className: "h-full min-w-sm overflow-y-auto",
                children: ne
            }), A && e.jsx(de, {
                isOpen: !0,
                primaryButtonColor: "danger",
                title: u.formatMessage(p.deleteAllConfirmTitle),
                confirmText: u.formatMessage(p.deleteAllConfirmCta),
                loading: z,
                onConfirm: async () => {
                    m(!0);
                    try {
                        const r = {
                            gizmo_id: v,
                            context_scopes: y,
                            required_context_scopes: b,
                            delete_history: H
                        };
                        v === void 0 && (r.delete_history = H), await se.safeDelete("/settings/clear_account_user_memory", {
                            requestBody: r
                        }), await Fe()
                    } catch (r) {} finally {
                        m(!1), f(!1)
                    }
                },
                onClose: () => f(!1),
                children: e.jsxs("div", {
                    className: "mb-2 flex flex-col gap-5 text-sm",
                    children: [e.jsx("div", {
                        className: "text-sm",
                        children: X ? e.jsx(d, te(M({}, p.deleteAllConfirmDescriptionUpdated), {
                            values: {
                                name: (We = V == null ? void 0 : V.name) != null ? We : "ChatGPT",
                                link: r => e.jsx(xe, {
                                    href: Se,
                                    className: "underline",
                                    children: r
                                })
                            }
                        })) : e.jsx(d, te(M({}, p.deleteAllConfirmDescription), {
                            values: {
                                name: (Ve = V == null ? void 0 : V.name) != null ? Ve : "ChatGPT",
                                link: r => e.jsx(xe, {
                                    href: Se,
                                    className: "underline",
                                    children: r
                                })
                            }
                        }))
                    }), e.jsxs("div", {
                        className: "border-token-border-default flex flex-row gap-3 rounded-2xl border px-4 py-4 text-sm",
                        children: [e.jsx(Pt, {
                            id: "delete-past-versions",
                            checked: H,
                            onChange: r => N(r.target.checked),
                            className: "border-token-border-default! h-5 w-5 shrink-0 rounded-full! border ring-0 ring-offset-0 focus:ring-0 focus:ring-offset-0 focus:outline-none",
                            style: {
                                backgroundColor: H ? G ? "transparent" : "black" : "transparent"
                            }
                        }), e.jsx("span", {
                            children: u.formatMessage(p.alsoDeletePastVersions)
                        })]
                    })]
                })
            })]
        }), e.jsx(Xt, {
            isOpen: j,
            onClose: () => T(!1)
        }), n && $ && e.jsx(Yt, {
            isOpen: $,
            setShowDisableOMConfirm: C,
            goldenHourMutation: h
        })]
    })
}
const Se = "https://help.openai.com/en/articles/8983136-what-is-memory",
    p = ve({
        descriptionFree: {
            id: "GoldenHourMemoriesModalFree.description",
            defaultMessage: "ChatGPT remembers useful details about you and your preferences so it can be more helpful. <link>Learn more</link>"
        },
        descriptionFreeMoonshine: {
            id: "GoldenHourMemoriesModal.description.freeMoonshine",
            defaultMessage: "ChatGPT tries to remember your recent chats, but it may forget things over time. Saved memories are never forgotten. <link>Learn more</link>"
        },
        descriptionPaid: {
            id: "GoldenHourMemoriesModal.description",
            defaultMessage: "ChatGPT automatically remembers useful information from chats, making responses more relevant and personal. <link>Learn more</link>"
        },
        descriptionOptimizeOn: {
            id: "GoldenHourMemoriesModal.description.optimizeOn",
            defaultMessage: "ChatGPT remembers and automatically manages useful information from chats, making responses more relevant and personal. <link>Learn more</link>"
        },
        copyAll: {
            id: "GoldenHourMemoriesModal.copyAll",
            defaultMessage: "Copy all"
        },
        copiedAll: {
            id: "GoldenHourMemoriesModal.copiedAll",
            defaultMessage: "Copied"
        },
        delete: {
            id: "GoldenHourMemoriesModal.delete",
            defaultMessage: "Delete"
        },
        deleteDescription: {
            id: "GoldenHourMemoriesModal.deleteDescription",
            defaultMessage: '"{title}" will be deleted. {name} may not remember this information going forward. <link>Learn more</link>'
        },
        history: {
            id: "GoldenHourMemoriesModal.history",
            defaultMessage: "History"
        },
        historyIntro: {
            id: "GoldenHourMemoriesModal.historyIntro",
            defaultMessage: "Revert to a previous version of your saved memories."
        },
        historyModalTitle: {
            id: "GoldenHourMemoriesModal.historyModalTitle",
            defaultMessage: "Saved memories history"
        },
        loading: {
            id: "GoldenHourMemoriesModal.loading",
            defaultMessage: "Loading..."
        },
        noHistory: {
            id: "GoldenHourMemoriesModal.noHistory",
            defaultMessage: "No checkpoints"
        },
        noMemories: {
            id: "GoldenHourMemoriesModal.noMemories",
            defaultMessage: "No saved memories"
        },
        noMemoriesAndDisabled: {
            id: "GoldenHourMemoriesModal.noMemoriesAndDisabled",
            defaultMessage: "Memory is disabled. ChatGPT won't use or save memories."
        },
        autoManageTitle: {
            id: "GoldenHourMemoriesModal.autoManageTitle",
            defaultMessage: "Automatically manage"
        },
        remove: {
            id: "GoldenHourMemoriesModal.remove",
            defaultMessage: "Remove"
        },
        retry: {
            id: "GoldenHourMemoriesModal.retry",
            defaultMessage: "Retry"
        },
        somethingWentWrong: {
            id: "GoldenHourMemoriesModal.somethingWentWrong",
            defaultMessage: "Something went wrong..."
        },
        title: {
            id: "GoldenHourMemoriesModal.title",
            defaultMessage: "Saved memories"
        },
        unknownGizmo: {
            id: "GoldenHourMemoriesModal.unknownGizmo",
            defaultMessage: "Unknown GPT"
        },
        viewHistoryTooltip: {
            id: "GoldenHourMemoriesModal.viewHistoryTooltip",
            defaultMessage: "View saved memories history"
        },
        viewingSnapshot: {
            id: "GoldenHourMemoriesModal.viewingSnapshot",
            defaultMessage: "Viewing snapshot from {date}"
        },
        searchPlaceholder: {
            id: "GoldenHourMemoriesModal.searchPlaceholder",
            defaultMessage: "Search memories"
        },
        searchNoResults: {
            id: "GoldenHourMemoriesModal.searchNoResults",
            defaultMessage: 'No results found for "{query}"'
        },
        sortAria: {
            id: "GoldenHourMemoriesModal.sortAria",
            defaultMessage: "Sort"
        },
        sortHeader: {
            id: "GoldenHourMemoriesModal.sortHeader",
            defaultMessage: "Sort"
        },
        newestFirst: {
            id: "GoldenHourMemoriesModal.newestFirst",
            defaultMessage: "Newest first"
        },
        oldestFirst: {
            id: "GoldenHourMemoriesModal.oldestFirst",
            defaultMessage: "Oldest first"
        },
        moreOptionsAria: {
            id: "GoldenHourMemoriesModal.moreOptionsAria",
            defaultMessage: "More options"
        },
        viewHistory: {
            id: "GoldenHourMemoriesModal.viewHistory",
            defaultMessage: "View history"
        },
        deleteAllMemories: {
            id: "GoldenHourMemoriesModal.deleteAllMemories",
            defaultMessage: "Delete all memories"
        },
        deleteAllConfirmTitle: {
            id: "GoldenHourMemoriesModal.deleteAllConfirmTitle",
            defaultMessage: "Delete all memories?"
        },
        deleteAllConfirmCta: {
            id: "GoldenHourMemoriesModal.deleteAllConfirmCta",
            defaultMessage: "Delete all"
        },
        deleteAllConfirmDescription: {
            id: "GoldenHourMemoriesModal.deleteAllConfirmDescription",
            defaultMessage: "{name} may not remember this information going forward. To fully remove this information from memory, also delete any related chats. <link>Learn more</link>"
        },
        deleteAllConfirmDescriptionUpdated: {
            id: "GoldenHourMemoriesModal.deleteAllConfirmDescriptionUpdated",
            defaultMessage: "{name} may not remember this information going forward. To fully remove this information from memory, also delete any related chats. <link>Learn more</link>"
        },
        alsoDeletePastVersions: {
            id: "GoldenHourMemoriesModal.alsoDeletePastVersions",
            defaultMessage: "Also delete all past versions of saved memories. This cannot be undone."
        }
    });

function Jt({
    gizmo: t,
    memory: s
}) {
    var A;
    const o = ce(),
        y = De(),
        b = pe(),
        [c, x] = a.useState(!1),
        [u, G] = a.useState(s.content),
        w = a.useRef(null);
    a.useEffect(() => {
        if (c && w.current) {
            const f = w.current,
                H = f.value.length;
            f.focus(), f.setSelectionRange(H, H)
        }
    }, [c]);
    const {
        mutate: U,
        isPending: v
    } = ge({
        mutationFn: async f => {
            const {
                success: H
            } = await se.safeDelete("/memories/{memory_id}", {
                parameters: {
                    path: {
                        memory_id: f
                    }
                },
                requestBody: {
                    gizmo_id: t == null ? void 0 : t.id
                }
            });
            if (!H) throw new Error("An error occurred while deleting the memory")
        },
        onSettled: () => {
            b.invalidateQueries({
                queryKey: ie(t == null ? void 0 : t.id)
            }), b.invalidateQueries({
                queryKey: me()
            })
        },
        onError: () => {
            y.danger({
                id: "MemoriesModal.deleteFailed",
                defaultMessage: "Failed to forget memory",
                description: "Toast message when deleting memory fails"
            }, {
                id: "memoryDeleteFailed",
                toastId: "memory_delete_failed"
            })
        }
    }), {
        mutate: O,
        isPending: R
    } = ge({
        mutationFn: async () => await se.safePatch("/memories/{memory_id}", {
            parameters: {
                path: {
                    memory_id: s.id
                }
            },
            requestBody: {
                gizmo_id: t == null ? void 0 : t.id,
                content: u
            }
        }),
        onSuccess: f => {
            const {
                memory_max_tokens: H,
                memory_num_tokens: N
            } = f;
            b.setQueryData(ie(t == null ? void 0 : t.id), j => {
                if (!j || typeof j != "object") return j;
                const T = j,
                    z = Math.min(Math.floor(100 * N / H), 100);
                return te(M({}, T), {
                    memory_max_tokens: H,
                    memory_num_tokens: N,
                    memoryFullPct: z
                })
            }), b.invalidateQueries({
                queryKey: ie(t == null ? void 0 : t.id)
            }), b.invalidateQueries({
                queryKey: me()
            }), x(!1)
        },
        onError: () => {
            y.danger({
                id: "MemoriesModal.editFailed",
                defaultMessage: "Failed to update memory",
                description: "Toast message when editing memory fails"
            }, {
                id: "memoryEditFailed",
                toastId: "memory_edit_failed"
            })
        }
    }), [q, S] = a.useState(!1), E = o.formatMessage({
        id: "N0czuB",
        defaultMessage: "Remove"
    });
    return e.jsxs(e.Fragment, {
        children: [e.jsx(Z.Row, {
            disabled: v || R,
            children: c ? e.jsxs(Z.Cell, {
                colSpan: 2,
                className: "relative pe-0",
                children: [e.jsx("input", {
                    ref: w,
                    autoFocus: !0,
                    value: u,
                    onChange: f => G(f.target.value),
                    className: "w-full rounded border-2 border-transparent py-2 pe-36 focus:outline-none",
                    maxLength: 500,
                    onKeyDown: f => {
                        if (!f.nativeEvent.isComposing && f.key === "Enter") {
                            if (u.trim() === "") {
                                Y.logEvent("Memory Manage Modal Memory Delete Clicked"), S(!0);
                                return
                            }
                            O()
                        }
                    }
                }), e.jsxs("div", {
                    className: "absolute end-1 top-1/2 flex -translate-y-1/2 gap-1",
                    children: [e.jsx(le, {
                        color: "secondary",
                        size: "small",
                        onClick: () => {
                            G(s.content), x(!1)
                        },
                        children: e.jsx(d, {
                            id: "TTo8Tw",
                            defaultMessage: "Cancel"
                        })
                    }), e.jsx(le, {
                        size: "small",
                        onClick: () => {
                            if (u.trim() === "") {
                                Y.logEvent("Memory Manage Modal Memory Delete Clicked"), S(!0);
                                return
                            }
                            O()
                        },
                        disabled: R,
                        children: e.jsx(d, {
                            id: "mDcKbU",
                            defaultMessage: "Save"
                        })
                    })]
                })]
            }) : e.jsxs(e.Fragment, {
                children: [e.jsx(Z.Cell, {
                    className: "pe-0",
                    divClassName: "min-h-[40px] items-center w-full",
                    children: e.jsx("div", {
                        className: "border-2 border-transparent py-2 whitespace-pre-wrap",
                        children: s.content
                    })
                }), e.jsx(Z.Cell, {
                    textAlign: "right",
                    children: e.jsxs(Z.Actions, {
                        children: [(() => {
                            const f = o.formatMessage({
                                id: "EditableMemoriesModal.edit",
                                defaultMessage: "Edit"
                            });
                            return e.jsx("button", {
                                onClick: () => x(!0),
                                "aria-label": f,
                                className: "text-token-text-tertiary hover:text-token-text-secondary",
                                children: e.jsx(Ze, {
                                    label: f,
                                    side: "top",
                                    className: "leading-none",
                                    children: e.jsx(Ot, {
                                        className: "icon-sm"
                                    })
                                })
                            })
                        })(), e.jsx("button", {
                            onClick: () => {
                                Y.logEvent("Memory Manage Modal Memory Delete Clicked"), S(!0)
                            },
                            "aria-label": E,
                            className: "text-token-text-tertiary hover:text-token-text-secondary",
                            children: e.jsx(Ze, {
                                className: "leading-none",
                                label: E,
                                side: "top",
                                children: e.jsx(Ae, {
                                    className: "icon-sm"
                                })
                            })
                        })]
                    })
                })]
            })
        }), q && e.jsx(de, {
            isOpen: !0,
            primaryButtonColor: "danger",
            title: E,
            confirmText: o.formatMessage({
                id: "fCn0ar",
                defaultMessage: "Forget"
            }),
            onConfirm: () => {
                Y.logEvent("Memory Manage Modal Memory Delete Confirmed"), U(s.id), S(!1)
            },
            onClose: () => {
                S(!1), G(s.content), x(!1)
            },
            children: e.jsx(d, {
                id: "j2cZHW",
                defaultMessage: 'Remove "{title}" from {name}’s saved memories. This can’t be undone. <link>Learn more</link>',
                values: {
                    name: (A = t == null ? void 0 : t.name) != null ? A : "ChatGPT",
                    title: e.jsx("strong", {
                        children: ut(s.content, {
                            length: 130,
                            omission: "..."
                        })
                    }),
                    link: f => e.jsx("a", {
                        href: "https://help.openai.com/en/articles/8590148-memory-faq",
                        target: "_blank",
                        className: "underline",
                        rel: "noreferrer",
                        children: f
                    })
                }
            })
        })]
    })
}

function Zt({
    selectedGizmoId: t,
    onSelect: s,
    items: o
}) {
    const y = o.find(c => c.id === t);

    function b(c) {
        var x;
        return e.jsx(Lt, {
            isFirstParty: c.id === void 0,
            src: (x = c.iconUrl) != null ? x : null,
            className: "icon"
        })
    }
    return e.jsx("div", {
        className: "border-token-border-medium mb-2 inline-flex rounded-md border",
        children: e.jsxs(l.Root, {
            children: [e.jsx(l.Trigger, {
                children: e.jsxs("div", {
                    className: "flex items-center gap-2",
                    children: [y ? e.jsxs(e.Fragment, {
                        children: [b(y), e.jsx("span", {
                            className: "text-token-text-primary",
                            children: y.name
                        })]
                    }) : e.jsx(d, {
                        id: "MemoriesModal.unknownGizmo",
                        defaultMessage: "Unknown GPT"
                    }), e.jsx(Et, {
                        className: "icon-sm text-token-text-tertiary"
                    })]
                })
            }), e.jsx(l.Portal, {
                children: e.jsx(l.Content, {
                    children: o.map(c => e.jsxs(l.Item, {
                        className: "flex items-center gap-3",
                        onClick: () => {
                            s(c.id)
                        },
                        children: [b(c), c.name]
                    }, c.id))
                })
            })]
        })
    })
}
var st;
const He = nt.div(st || (st = Ne(["flex h-full items-center justify-center pb-8 text-sm text-token-text-tertiary rounded-lg border border-token-border-default"])));

function cs({
    onClose: t,
    initialGizmoId: s,
    contextScopes: o,
    requiredContextScopes: y
}) {
    var z, m, $;
    const b = ce(),
        c = pe(),
        x = dt(),
        [u, G] = a.useState(s),
        w = je(),
        U = ot(),
        v = at(w),
        O = v == null ? void 0 : v.hasPlusFeatures();
    a.useEffect(() => {
        Y.logEvent("Memory Modal Shown")
    }, []);
    const {
        data: R,
        isLoading: q,
        isError: S,
        refetch: E
    } = ct({
        gizmoId: u,
        enabled: x,
        contextScopes: o,
        requiredContextScopes: y
    }), A = R == null ? void 0 : R.memories, {
        data: f,
        refetch: H
    } = rt({
        queryKey: ["memory_gizmos"],
        queryFn: () => se.safeGet("/memories/gizmos"),
        refetchOnMount: "always"
    }), N = [{
        id: void 0,
        name: "ChatGPT",
        iconUrl: null
    }, ...(z = f == null ? void 0 : f.items.map(({
        gizmo: C
    }) => {
        var B;
        return {
            id: C.id,
            name: C.display.name,
            iconUrl: (B = C.display.profile_picture_url) != null ? B : null
        }
    })) != null ? z : []], j = N.find(C => C.id === u);
    a.useEffect(() => {
        !q && !S && u !== void 0 && (!A || A.length === 0) && G(void 0)
    }, [q, S, A, u]);
    let T;
    return q ? T = e.jsx(He, {
        children: e.jsx(d, {
            id: "MemoriesModal.loading",
            defaultMessage: "Loading..."
        })
    }) : S ? T = e.jsx(He, {
        children: e.jsxs("div", {
            className: "max-w-sm text-center",
            children: [e.jsx("div", {
                className: "mb-4 text-red-500",
                children: e.jsx(d, {
                    id: "MemoriesModal.somethingWentWrong",
                    defaultMessage: "Something went wrong..."
                })
            }), e.jsx("div", {
                children: e.jsx(le, {
                    color: "secondary",
                    onClick: () => {
                        E()
                    },
                    children: e.jsx(d, {
                        id: "MemoriesModal.retry",
                        defaultMessage: "Retry"
                    })
                })
            })]
        })
    }) : !A || A.length === 0 ? T = e.jsx(He, {
        children: e.jsx("div", {
            className: "max-w-sm text-center",
            children: x ? e.jsx(d, {
                id: "MemoriesModal.noMemories.1",
                defaultMessage: "As you chat with {name}, the details and preferences it saves will be shown here.",
                values: {
                    name: (m = j == null ? void 0 : j.name) != null ? m : "ChatGPT"
                }
            }) : e.jsx(d, {
                id: "MemoriesModal.noMemoriesAndDisabled",
                defaultMessage: "Memory is disabled. ChatGPT won't use or save memories."
            })
        })
    }) : T = e.jsx(Z.Root, {
        className: "border-token-border-default h-full",
        size: "compact",
        bordered: !0,
        children: e.jsx(Z.Body, {
            children: A.map(C => e.jsx(Jt, {
                gizmo: j ? {
                    id: j.id,
                    name: j.name
                } : void 0,
                memory: C
            }, C.id))
        })
    }), e.jsxs(Re, {
        testId: "modal-memories",
        isOpen: !0,
        onClose: t,
        size: "custom",
        className: "max-w-5xl",
        type: "success",
        title: b.formatMessage({
            id: "MemoriesModal.title",
            defaultMessage: "Saved memories"
        }),
        showCloseButton: !0,
        children: [O && N.length > 1 && e.jsx("div", {
            className: "mb-4",
            children: e.jsx(Zt, {
                selectedGizmoId: u,
                items: N,
                onSelect: C => {
                    c.invalidateQueries({
                        queryKey: ie(C)
                    }), c.invalidateQueries({
                        queryKey: me()
                    }), G(C)
                }
            })
        }), e.jsx(qt, {
            memoryFullPct: R == null ? void 0 : R.memoryFullPct,
            className: "mb-5",
            showUpgradeCTA: !1,
            isPaid: O,
            onUpgrade: () => {
                Y.logEventWithStatsig("Memories Upgrade Button Clicked", "chatgpt_memories_upgrade_button_clicked_settings"), mt(U, "chatgpt_memories_upgrade_button")
            }
        }), e.jsx("div", {
            className: "h-[24rem]",
            children: T
        }), e.jsx("div", {
            className: "mt-5 flex justify-end",
            children: e.jsx(Bt, {
                onReset: () => {
                    E(), H(), u && G(void 0)
                },
                gizmoId: u,
                memoryName: ($ = j == null ? void 0 : j.name) != null ? $ : "ChatGPT",
                contextScopes: o,
                requiredContextScopes: y
            })
        })]
    })
}
export {
    cs as E, ds as G, Kt as M
};
//# sourceMappingURL=jjruw0pg8h58hov8.js.map