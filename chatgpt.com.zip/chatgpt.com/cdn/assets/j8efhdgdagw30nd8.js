import {
    r as m,
    j as r
} from "./fg33krlcm0qyi6yw.js";
import {
    l as f,
    c0 as a
} from "./dykg4ktvbu3mhmdo.js";

function d({
    isFetchingNextPage: n,
    hasNextPage: s,
    fetchNextPage: e,
    bgColor: l = "bg-token-bg-primary"
}) {
    const o = m.useCallback(i => {
        if (n || i == null) return;
        const t = new IntersectionObserver(c => {
            c[0].isIntersecting && s && e()
        });
        return t.observe(i), () => {
            t.disconnect()
        }
    }, [n, s, e]);
    return r.jsxs(r.Fragment, {
        children: [s && !n && r.jsx("div", {
            className: "h-1",
            "data-testid": "infinite-scroll-trigger",
            ref: o
        }), r.jsx("div", {
            className: f("flex w-full items-center justify-center", l),
            children: n && r.jsx(a, {
                className: "min-h-[50px]"
            })
        })]
    })
}
export {
    d as I
};
//# sourceMappingURL=j8efhdgdagw30nd8.js.map