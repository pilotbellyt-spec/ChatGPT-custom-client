var We = Object.defineProperty,
    Xe = Object.defineProperties;
var Je = Object.getOwnPropertyDescriptors;
var ue = Object.getOwnPropertySymbols;
var Se = Object.prototype.hasOwnProperty,
    Ne = Object.prototype.propertyIsEnumerable;
var Ce = (t, e, s) => e in t ? We(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : t[e] = s,
    H = (t, e) => {
        for (var s in e || (e = {})) Se.call(e, s) && Ce(t, s, e[s]);
        if (ue)
            for (var s of ue(e)) Ne.call(e, s) && Ce(t, s, e[s]);
        return t
    },
    W = (t, e) => Xe(t, Je(e));
var be = (t, e) => {
    var s = {};
    for (var r in t) Se.call(t, r) && e.indexOf(r) < 0 && (s[r] = t[r]);
    if (t != null && ue)
        for (var r of ue(t)) e.indexOf(r) < 0 && Ne.call(t, r) && (s[r] = t[r]);
    return s
};
import {
    c as V,
    e as O,
    j as a,
    M as Y,
    b as Ke,
    r as y,
    _ as Ye
} from "./fg33krlcm0qyi6yw.js";
import {
    er as f,
    rM as Ve,
    rN as qe,
    iG as Ze,
    eq as De,
    iF as et,
    kY as tt,
    kZ as st,
    rO as ze,
    rP as X,
    eT as at,
    rQ as rt,
    ee as nt,
    ej as ot,
    j2 as it,
    rR as lt,
    ij as ct,
    aX as ut,
    rS as _e,
    hp as Re
} from "./k15yxxoybkkir2ou.js";
import {
    xj as K,
    l as b,
    e4 as Te,
    bb as dt,
    cS as ft,
    mi as gt,
    c_ as mt,
    go as xt,
    gq as ht,
    bg as _,
    hA as pt,
    P as Ae,
    iK as Mt,
    aX as vt,
    da as wt,
    b as yt,
    bh as jt,
    bc as Ct,
    bd as St
} from "./dykg4ktvbu3mhmdo.js";
import {
    cleanQuery as we,
    GlauxSearchQueryOverflow as Nt,
    GlauxSearchResultOverflow as bt,
    GlauxSearchQueryWithIcon as Be,
    GlauxSearchResultItem as Fe
} from "./obmzp3ebe8x6w67a.js";
import {
    c as _t,
    g as Rt,
    a as Tt,
    b as At,
    i as It,
    d as Et,
    C as Ot,
    e as kt
} from "./gd2ozzf4upgi0amm.js";
import {
    C as Pt
} from "./tjmll0bdtco26rsw.js";
import {
    s as qt,
    l as Dt
} from "./jbh6ambg0gcrgcqd.js";

function P(t, e, s, r, o, n, i = !0) {
    var l, c, u;
    if (r && o && !s) return t.formatMessage({
        id: "xvTcn5",
        defaultMessage: "Stopping"
    });
    if ("title" in e && e.title && i) return e.title;
    switch (e.type) {
        case f.Thought:
            return e.thought.summary;
        case f.Recap:
            return e.content;
        case f.N7jupdAPI:
            return de({
                action: e.action,
                source: e.source,
                intl: t
            });
        case f.Browsing:
            return Ge({
                contextualAnswerSources: e.sources,
                intl: t
            });
        case f.Search:
            return s ? t.formatMessage({
                id: "+a5J9x",
                defaultMessage: "Searched the web"
            }) : t.formatMessage({
                id: "GamH3R",
                defaultMessage: "Searching the web"
            });
        case f.CodeAnalysis:
            return s ? t.formatMessage({
                id: "SGdXPO",
                defaultMessage: "Analyzed"
            }) : t.formatMessage({
                id: "+JAejT",
                defaultMessage: "Writing code"
            });
        case f.ImageAnalysis:
            return s ? t.formatMessage({
                id: "fjqIXj",
                defaultMessage: "Analyzed image"
            }) : t.formatMessage({
                id: "D//PTx",
                defaultMessage: "Analyzing image"
            });
        case f.ComputerOutput:
            return s ? t.formatMessage({
                id: "PlB7p/",
                defaultMessage: "Browsed the web"
            }) : (c = (l = e.thoughts) == null ? void 0 : l.at(-1)) != null ? c : t.formatMessage({
                id: "HFx/8x",
                defaultMessage: "Browsing the web"
            });
        case f.e1ld0dvz:
            return e.tasks.every(d => d.status === "completed") ? t.formatMessage({
                id: "WUrSuY",
                defaultMessage: "Completed tasks"
            }) : t.formatMessage({
                id: "tH3LAN",
                defaultMessage: "Running tasks"
            });
        case f.N7jupdLoading:
            {
                const d = (u = e.custom_headline) == null ? void 0 : u.trim();
                return d || (n ? Bt(t, n) : t.formatMessage({
                    id: "hgnsat",
                    defaultMessage: "Thinking"
                }))
            }
        case f.Glaux:
            return zt(t, e, s);
        case f.Strix:
            return
    }
}
const zt = (t, e, s) => {
        const r = e.isEducationPlan;
        if (e.queries.length > 1) {
            const i = new Map;
            if (e.queries.forEach(({
                    connectorName: u
                }) => {
                    var d;
                    i.set(u, ((d = i.get(u)) != null ? d : 0) + 1)
                }), i.has("*")) return s ? r ? t.formatMessage({
                id: "NQ1WJC",
                defaultMessage: "Searched organization knowledge"
            }) : t.formatMessage({
                id: "APiAqk",
                defaultMessage: "Searched company knowledge"
            }) : r ? t.formatMessage({
                id: "5syqRS",
                defaultMessage: "Searching organization knowledge"
            }) : t.formatMessage({
                id: "kcBn4V",
                defaultMessage: "Searching company knowledge"
            });
            let l = Array.from(i.entries()).toSorted(([u, d], [w, g]) => g - d).map(([u]) => u);
            if (l.length > 3) {
                const u = l.length - 2;
                l = [...l.slice(0, 2), t.formatMessage({
                    id: "45+rh1",
                    defaultMessage: "{number} others"
                }, {
                    number: u
                })]
            }
            const c = t.formatList(l);
            return s ? t.formatMessage({
                id: "OvXUzx",
                defaultMessage: "Searched {connectorNames}"
            }, {
                connectorNames: c
            }) : t.formatMessage({
                id: "r44Nbg",
                defaultMessage: "Searching {connectorNames}"
            }, {
                connectorNames: c
            })
        } else return s ? r ? t.formatMessage({
            id: "NQ1WJC",
            defaultMessage: "Searched organization knowledge"
        }) : t.formatMessage({
            id: "APiAqk",
            defaultMessage: "Searched company knowledge"
        }) : r ? t.formatMessage({
            id: "5syqRS",
            defaultMessage: "Searching organization knowledge"
        }) : t.formatMessage({
            id: "kcBn4V",
            defaultMessage: "Searching company knowledge"
        })
    },
    Bt = (t, e) => e === K.Research ? t.formatMessage({
        id: "CsSGJm",
        defaultMessage: "Starting research"
    }) : e === K.Autoswitch ? t.formatMessage({
        id: "9CDId8",
        defaultMessage: "Thinking longer with agent mode"
    }) : e === K.KAUR1BR5 ? t.formatMessage({
        id: "QqaVzm",
        defaultMessage: "Getting started..."
    }) : t.locale.startsWith("en") && e === K.Random ? Ft(t) : t.formatMessage({
        id: "gw6x6T",
        defaultMessage: "Setting up my desktop"
    }),
    Ie = [{
        text: "Pouring a cup of coffee",
        weight: 1
    }, {
        text: "Sharpening pencils",
        weight: 1
    }, {
        text: "Consulting the rubber duck",
        weight: 1
    }, {
        text: "Negotiating with servers",
        weight: 1
    }, {
        text: "Tuning caffeine levels",
        weight: 1
    }, {
        text: "Untangling the wires",
        weight: 1
    }, {
        text: "Refilling the printer paper",
        weight: 1
    }, {
        text: "Baking cookies — HTTP only, of course",
        weight: 1
    }, {
        text: "Looking for snacks",
        weight: 1
    }, {
        text: "Warming up the neurons",
        weight: 1
    }, {
        text: "Folding the transformer layers neatly",
        weight: 1
    }, {
        text: "Plugging into the matrix",
        weight: 1
    }, {
        text: "Downloading the extended trilogy",
        weight: 1
    }, {
        text: "Putting on my super suit",
        weight: 1
    }, {
        text: "Building additional pylons",
        weight: 1
    }, {
        text: "Reticulating splines",
        weight: 1
    }, {
        text: "Blowing dust out of the cartridge",
        weight: 1
    }, {
        text: "Installing the flux capacitor",
        weight: 1
    }, {
        text: "Ordering extra pizza for the Turtles",
        weight: 1
    }, {
        text: "Refining the data",
        weight: 1
    }];

function Ft(t) {
    const e = Ie.reduce((r, o) => r + o.weight, 2e3);
    let s = Math.random() * e;
    for (const {
            text: r,
            weight: o
        } of Ie) {
        if (s < o) return r;
        s -= o
    }
    return t.formatMessage({
        id: "gw6x6T",
        defaultMessage: "Setting up my desktop"
    })
}
const de = ({
        action: t,
        source: e,
        intl: s
    }) => t === "n7jupd_as" ? s.formatMessage({
        id: "np3RkB",
        defaultMessage: "Checking available APIs"
    }) : t === "n7jupd_ag" ? s.formatMessage({
        id: "Q0QNzM",
        defaultMessage: "Reading API documentation"
    }) : t === "n7jupd_cf" && !e ? s.formatMessage({
        id: "soOFxK",
        defaultMessage: "Reading from API"
    }) : t === "n7jupd_cf" && e ? s.formatMessage({
        id: "1ETpL6",
        defaultMessage: "Reading from {source}"
    }, {
        source: e.name
    }) : t === "n7jupd_cs" && e ? s.formatMessage({
        id: "nqEMzN",
        defaultMessage: "Searching {source}"
    }, {
        source: e.name
    }) : s.formatMessage({
        id: "soOFxK",
        defaultMessage: "Reading from API"
    }),
    Ge = ({
        contextualAnswerSources: t,
        intl: e
    }) => {
        if (t.length === 0) return e.formatMessage({
            id: "browsingMessage.startingRetrieval",
            defaultMessage: "Reading documents"
        });
        const s = t.map(r => Ve[r]).filter(Boolean);
        return t.length === 1 ? e.formatMessage({
            id: "Jzt2om",
            defaultMessage: "Reading {source}"
        }, {
            source: s[0]
        }) : t.length === 2 ? e.formatMessage({
            id: "wTM7gR",
            defaultMessage: "Reading {source1} and {source2}"
        }, {
            source1: s[0],
            source2: s[1]
        }) : e.formatMessage({
            id: "xnwjH1",
            defaultMessage: "Reading {source1}, {source2} and more"
        }, {
            source1: s[0],
            source2: s[1]
        })
    },
    ve = 24,
    Ss = 12,
    Ns = 4,
    Gt = 5e3;

function Le({
    chunk: t,
    intl: e
}) {
    var n, i;
    const s = (n = t == null ? void 0 : t.queries.map(l => l.query)) != null ? n : [];
    if (((i = t == null ? void 0 : t.results) != null ? i : []).length > 0) return "";
    const o = new Set(s);
    return e.formatMessage({
        id: "F+zud/",
        defaultMessage: "Searching for {queries_list}{add_more, select, true { and {remaining_count} more} other {}}"
    }, {
        queries_list: Array.from(o).map(l => '"'.concat(we(l), '"')).slice(0, 3).join(", "),
        add_more: Array.from(o).length > 3,
        remaining_count: Array.from(o).length - 3
    })
}

function Lt(t) {
    "use forget";
    const e = V.c(12),
        {
            chunk: s,
            isExpanded: r,
            isComplete: o
        } = t,
        n = O(),
        i = qe(),
        l = (i == null ? void 0 : i.type) === "cot";
    let c;
    e[0] !== s || e[1] !== n || e[2] !== o || e[3] !== l ? (c = l ? null : a.jsx("div", {
        className: "text-token-text-secondary flex flex-row gap-1 truncate text-sm overflow-ellipsis",
        children: P(n, s, o)
    }), e[0] = s, e[1] = n, e[2] = o, e[3] = l, e[4] = c) : c = e[4];
    let u;
    e[5] !== s || e[6] !== r || e[7] !== l ? (u = r && a.jsx(Ut, {
        queries: s.queries,
        results: s.results,
        maxResults: l ? 3 : 4
    }), e[5] = s, e[6] = r, e[7] = l, e[8] = u) : u = e[8];
    let d;
    return e[9] !== c || e[10] !== u ? (d = a.jsxs("div", {
        children: [c, u]
    }), e[9] = c, e[10] = u, e[11] = d) : d = e[11], d
}

function Ut(t) {
    "use forget";
    const e = V.c(10),
        {
            maxResults: s,
            queries: r,
            results: o
        } = t,
        n = s === void 0 ? 3 : s;
    let i;
    e[0] !== n || e[1] !== r || e[2] !== o.length ? (i = r.length <= n || !o.length ? r.map(Wt) : [...r.slice(0, n - 1).map(Ht), a.jsx(Nt, {
        maxResults: n,
        queries: r
    }, "query-overflow")], e[0] = n, e[1] = r, e[2] = o.length, e[3] = i) : i = e[3];
    const l = i;
    let c;
    e[4] !== n || e[5] !== o ? (c = o.length <= n ? o.map(Qt) : [...o.slice(0, n - 1).map($t), a.jsx(bt, {
        maxResults: n,
        results: o
    }, "result-overflow")], e[4] = n, e[5] = o, e[6] = c) : c = e[6];
    const u = c;
    let d;
    return e[7] !== l || e[8] !== u ? (d = a.jsx("div", {
        className: "mt-2",
        children: a.jsxs("div", {
            className: "flex flex-row flex-wrap items-center gap-2",
            children: [l, u]
        })
    }), e[7] = l, e[8] = u, e[9] = d) : d = e[9], d
}

function $t(t) {
    return a.jsx(Fe, {
        url: t.url,
        name: t.name
    }, t.id)
}

function Qt(t) {
    return a.jsx(Fe, {
        url: t.url,
        name: t.name
    }, t.id)
}

function Ht(t, e) {
    return a.jsx(Be, {
        query: we(t.query)
    }, "query-".concat(t.query, "-").concat(e))
}

function Wt(t, e) {
    return a.jsx(Be, {
        query: we(t.query)
    }, "query-".concat(t.query, "-").concat(e))
}
const Xt = Object.freeze(Object.defineProperty({
        __proto__: null,
        GlauxCoTChunk: Lt,
        getGlauxCoTChunkV4TextContent: Le
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Jt = ({
        chunk: t,
        isExpanded: e,
        isComplete: s,
        enableV4: r
    }) => {
        const o = O(),
            n = t.assistantMessage,
            i = t.toolMessage,
            l = n != null && Ue(n) != null;
        return a.jsxs("div", {
            className: b("flex w-full flex-col gap-2 text-sm", r && "mt-1"),
            children: [e && !r && P(o, t, s), l && a.jsxs("div", {
                children: [a.jsx(Kt, {
                    message: n,
                    forceDarkMode: !0,
                    showActionBar: !1,
                    codeRendererClassName: b("rounded-md max-h-[calc(clamp(20px,1/4*var(--thread-safe-area-height,100lvh),400px))] overflow-auto", i && "rounded-b-none"),
                    codeContainerClassName: "overflow-visible!"
                }), i && a.jsx(Yt, {
                    forceDarkMode: !0,
                    wrapperClassName: "max-h-[calc(clamp(20px,1/8*var(--thread-safe-area-height,100lvh),200px))] w-full overflow-auto dark rounded-b-md",
                    codeContainerClassName: "whitespace-pre-wrap",
                    message: i
                })]
            })]
        })
    };

function Ue(t) {
    function e(r, o, n) {
        return "```".concat(n, "\nagent@chatgpt:").concat(r, "$ ").concat(o, "\n```")
    }

    function s(r) {
        var i;
        const o = JSON.parse(r);
        if (!o.cmd) return null;
        const n = (i = o.workdir) != null ? i : "/";
        return o.cmd.length === 3 && o.cmd[0] === "bash" && o.cmd[1] === "-lc" ? e(n, o.cmd[2], o.cmd[2].startsWith("python") ? "python" : "bash") : e(n, o.cmd.join(" "), "bash")
    }
    if (t.recipient !== "container.exec") return null;
    switch (t.content.content_type) {
        case Te.Code:
            return s(t.content.text);
        case Te.Text:
            return s(t.content.parts.join(""));
        default:
            return null
    }
}

function Kt({
    message: t,
    codeRendererClassName: e,
    forceDarkMode: s,
    removeTopBorderRadius: r,
    showActionBar: o,
    codeContainerClassName: n
}) {
    const i = dt() || s,
        l = Ue(t);
    return l == null ? null : a.jsx(Ze.Provider, {
        value: {
            isWithinDataAnalysisToolMessage: !0
        },
        children: a.jsx(De, {
            className: b("markdown prose dark:prose-invert w-full break-words", i ? "dark" : "light"),
            forceDarkMode: s,
            componentOverrides: {
                code: c => a.jsx(et, W(H({}, c), {
                    wrapperClassName: e,
                    codeContainerClassName: n,
                    removeTopBorderRadius: r,
                    showActionBar: o
                }))
            },
            children: l
        })
    })
}

function Yt({
    message: t,
    wrapperClassName: e,
    codeContainerClassName: s,
    forceDarkMode: r
}) {
    const o = t.content.content_type === "text" ? t.content.parts.join("") : null;
    return o ? a.jsx(_t, {
        forceDarkMode: r,
        wrapperClassName: e,
        codeContainerClassName: s,
        output: o,
        label: null
    }) : null
}

function Vt() {
    return Date.now()
}

function Zt({
    tasks: t
}) {
    return a.jsxs("div", {
        className: "flex w-full flex-col gap-1",
        children: [a.jsx("div", {
            className: "text-token-text-secondary mb-1 text-sm",
            children: a.jsx(Y, {
                id: "FTmQVN",
                defaultMessage: "Delegated Tasks"
            })
        }), a.jsx("div", {
            className: "flex flex-col divide-y divide-gray-200 rounded-lg border border-gray-200",
            children: t.map(e => a.jsx(es, {
                task: e
            }, String(e.id)))
        })]
    })
}

function es({
    task: t
}) {
    var o, n;
    const e = (o = t.startedAtMs) != null ? o : Vt(),
        s = tt(e, 90 * 1e3),
        r = t.status === "completed" ? a.jsx(ft, {
            className: "icon text-token-text-secondary h-4 w-4"
        }) : t.status === "gathering" || t.status === "running" ? a.jsx(st, {
            percentage: s,
            thickness: 1 / 12,
            className: "text-token-text-tertiary h-4 w-4",
            backgroundStrokeClassName: "stroke-token-main-surface-tertiary",
            transitionDuration: "".concat((100 - s) / 100 * .2, "s"),
            transitionTimingFunction: "cubic-bezier(0.55, 0, 1, 1)"
        }) : a.jsx("div", {
            className: "h-4 w-4"
        });
    return a.jsxs("div", {
        className: "grid grid-cols-[1fr_auto] items-center gap-2 p-2",
        children: [a.jsx("div", {
            className: "min-w-0",
            children: a.jsx("div", {
                className: "text-token-text-tertiary truncate text-xs",
                children: (n = t.instruction) != null ? n : t.model
            })
        }), a.jsx("div", {
            className: "flex items-center justify-center",
            children: r
        })]
    })
}
const ts = ({
        chunk: t,
        isExpanded: e,
        isComplete: s,
        enableV4: r
    }) => {
        const o = O(),
            n = t.assistantMessage,
            i = t.toolMessage,
            l = n != null && Rt(n) != null;
        return a.jsxs("div", {
            className: b("flex w-full flex-col gap-2 text-sm", r && "mt-1"),
            children: [e && !r && P(o, t, s), l && a.jsxs("div", {
                className: "flex flex-col gap-0.5",
                children: [a.jsx(Tt, {
                    message: n,
                    forceDarkMode: !0,
                    FormattedText: De,
                    showActionBar: !1,
                    codeRendererClassName: "rounded-md max-h-[calc(clamp(20px,1/4*var(--thread-safe-area-height,100lvh),400px))] overflow-auto",
                    codeContainerClassName: "overflow-visible!"
                }), i && a.jsx(At, {
                    forceDarkMode: !0,
                    wrapperClassName: "max-h-[calc(clamp(20px,1/8*var(--thread-safe-area-height,100lvh),200px))] w-full overflow-auto dark rounded-md",
                    codeContainerClassName: "whitespace-pre-wrap",
                    message: i,
                    showLabel: !1
                })]
            })]
        })
    },
    ss = ({
        chunk: t,
        isExpanded: e,
        isComplete: s,
        enableV4: r
    }) => {
        var x, C, S, N, j, v, h;
        const o = O(),
            n = t.toolMessage,
            i = gt(),
            l = !mt();
        let c;
        const u = (C = (x = n.author.name) == null ? void 0 : x.includes("container")) != null ? C : !1;
        if ((S = n.author.name) != null && S.includes("python")) {
            const p = (j = (N = n.metadata) == null ? void 0 : N.aggregate_result) == null ? void 0 : j.messages.find(It);
            c = (p == null ? void 0 : p.image_url) && xt(p.image_url)
        } else if (u) {
            const p = (h = (v = n.metadata) == null ? void 0 : v.attachments) == null ? void 0 : h[0];
            c = p == null ? void 0 : p.id
        }
        const {
            data: d
        } = Ke(c ? kt(c, l) : {
            enabled: !1,
            queryKey: []
        }), w = (d == null ? void 0 : d.status) === ht.Success ? d.download_url : void 0, {
            isSuccess: g
        } = ze(w), [m] = y.useState(g);
        return a.jsxs("div", {
            className: b("flex w-full flex-col gap-2 text-sm", r && "mt-1"),
            children: [e && !r && P(o, t, s), a.jsxs("div", {
                className: "bg-token-bg-secondary relative flex h-[calc(clamp(150px,1/4*var(--thread-safe-area-height,100lvh),400px))] justify-center overflow-hidden rounded-md p-2",
                children: [w && a.jsx(_.div, {
                    initial: {
                        opacity: m ? .5 : 0,
                        scale: 1.1
                    },
                    animate: {
                        opacity: g ? .5 : 0,
                        scale: s || i ? 1.1 : [1.1, 1.25, 1.1]
                    },
                    transition: {
                        opacity: {
                            ease: "easeInOut"
                        },
                        scale: s ? {
                            type: "spring",
                            stiffness: 300,
                            damping: 20
                        } : {
                            duration: 2.5,
                            repeat: 1 / 0,
                            ease: "easeInOut"
                        }
                    },
                    className: "absolute inset-0 bg-cover bg-center bg-no-repeat opacity-40 blur-lg filter",
                    style: {
                        backgroundImage: "url(".concat(JSON.stringify(w), ")")
                    }
                }), a.jsx(_.div, {
                    initial: {
                        opacity: m ? 1 : 0
                    },
                    animate: {
                        opacity: g ? 1 : 0
                    },
                    className: "relative *:m-0 *:h-full *:w-full *:rounded-md *:object-center *:shadow-lg",
                    children: c && (u ? a.jsx(Et, {
                        fileId: c
                    }) : a.jsx(Ot, {
                        isCoT: !0,
                        message: n
                    }))
                })]
            })]
        })
    },
    as = 4,
    rs = 3,
    ns = 3,
    os = {
        hidden: {
            opacity: 0
        },
        visible: {
            opacity: 1
        }
    },
    Ee = {
        hidden: {
            opacity: 0,
            x: -5
        },
        visible: {
            opacity: 1,
            x: 0
        }
    },
    is = ({
        chunk: t,
        isExpanded: e,
        isComplete: s
    }) => {
        var l, c, u;
        const r = O();
        if (!t.searchResults && !t.fetchResult) return e && a.jsx(X, {
            content: de({
                action: t.action,
                source: t.source,
                intl: r
            })
        });
        const o = [];
        let n = [];
        if (t.action === "n7jupd_cs" && t.searchResults) n = t.searchResults.map(d => ({
            entries: [{
                url: d.url,
                title: d.title,
                snippet: "",
                attribution: d.title
            }]
        }));
        else if (t.action === "n7jupd_cf" && t.fetchResult) n = [{
            entries: [{
                url: (l = t.fetchResult) == null ? void 0 : l.url,
                title: (c = t.fetchResult) == null ? void 0 : c.title,
                snippet: "",
                attribution: (u = t.fetchResult) == null ? void 0 : u.title
            }]
        }];
        else return null;
        const i = {
            type: f.Search,
            queries: o,
            sources: n
        };
        return e && a.jsx($e, {
            chunk: i,
            isExpanded: e,
            isComplete: s,
            headlineContents: de({
                action: t.action,
                source: t.source,
                intl: r
            }),
            useCloudDocIcons: !0
        })
    },
    ls = ({
        chunk: t,
        isExpanded: e,
        isComplete: s,
        enableV4: r
    }) => {
        const o = O();
        return a.jsx($e, {
            chunk: t,
            isExpanded: e,
            isComplete: s,
            headlineContents: r ? void 0 : P(o, t, s),
            useCloudDocIcons: !1
        })
    },
    $e = ({
        chunk: t,
        isExpanded: e,
        isComplete: s,
        headlineContents: r,
        useCloudDocIcons: o,
        isSmall: n,
        isVisualCoT: i = !1
    }) => {
        const {
            queries: l,
            sources: c
        } = t, [u, d] = y.useState(s), w = i ? _.div : "div";
        return a.jsxs(w, W(H({
            className: b("flex min-w-0 flex-col gap-2 text-sm", i && "overflow-hidden")
        }, i ? {
            initial: {
                height: 0,
                opacity: 0
            },
            animate: {
                height: "auto",
                opacity: 1
            },
            transition: {
                duration: .25,
                ease: "easeOut"
            }
        } : {}), {
            children: [e && r, a.jsxs("div", {
                className: "flex min-w-0 flex-col gap-1",
                children: [a.jsx(Oe, {
                    isComplete: s,
                    items: l,
                    max: ns,
                    getKey: g => g.q,
                    Item: cs,
                    ShowMoreButton: fs,
                    onAnimationComplete: () => d(!0),
                    isSmall: n,
                    isVisualCoT: i
                }), a.jsx(Oe, {
                    isComplete: s,
                    items: u ? c : [],
                    max: as,
                    getKey: g => g.entries[0].url,
                    Item: us,
                    ShowMoreButton: ds,
                    useCloudDocIcons: o,
                    isSmall: n,
                    isVisualCoT: i
                })]
            })]
        }))
    },
    Oe = ({
        isComplete: t,
        items: e,
        max: s,
        getKey: r,
        Item: o,
        ShowMoreButton: n,
        onAnimationComplete: i,
        useCloudDocIcons: l,
        isSmall: c,
        isVisualCoT: u = !1
    }) => {
        const [d, w] = y.useState(!1), [g, m] = e.length > s ? [e.slice(0, s - 1), e.slice(s - 1)] : [e];
        return a.jsxs(_.div, {
            className: b("flex flex-wrap items-center gap-1", u && "justify-center"),
            initial: u ? "hidden" : t ? "visible" : "hidden",
            animate: "visible",
            transition: {
                duration: .25,
                staggerChildren: .1,
                delayChildren: .3
            },
            onAnimationComplete: i,
            children: [g.map(x => a.jsx(_.div, {
                variants: os,
                className: "flex max-w-full items-center",
                children: a.jsx(o, {
                    item: x,
                    isComplete: t,
                    useCloudDocIcons: l,
                    isSmall: c,
                    isVisualCoT: u
                })
            }, r(x))), d && a.jsx(_.div, {
                className: "contents",
                initial: "hidden",
                animate: "visible",
                transition: {
                    duration: .2,
                    staggerChildren: .02
                },
                children: m == null ? void 0 : m.map(x => a.jsx(_.div, {
                    variants: Ee,
                    className: "flex max-w-full items-center",
                    children: a.jsx(o, {
                        item: x,
                        isComplete: t,
                        useCloudDocIcons: l,
                        isSmall: c,
                        isVisualCoT: u
                    })
                }, r(x)))
            }), m && a.jsx(_.div, {
                variants: Ee,
                className: "flex items-center",
                children: a.jsx(n, {
                    moreItems: m,
                    isShowingMore: d,
                    onClick: () => w(x => !x),
                    useCloudDocIcons: l,
                    isSmall: c
                })
            }, "more")]
        })
    },
    cs = ({
        item: t,
        isSmall: e
    }) => a.jsxs(fe, {
        componentType: "span",
        isSmall: e,
        children: [a.jsx(pt, {
            className: "-ms-1 h-3 w-3 shrink-0"
        }), a.jsx("span", {
            className: "max-w-[8rem] overflow-hidden text-ellipsis whitespace-nowrap",
            children: t.q
        })]
    }),
    us = ({
        item: t,
        isComplete: e,
        useCloudDocIcons: s,
        isSmall: r,
        isVisualCoT: o
    }) => {
        var u;
        const n = t.entries[0],
            i = y.useMemo(() => ({
                url: n.url,
                title: n.title
            }), [n.url, n.title]);
        y.useEffect(() => {
            Ae.logEvent("link_action", W(H({}, i), {
                action: "show"
            }))
        }, [i]);
        const l = () => {
                Ae.logEvent("link_action", W(H({}, i), {
                    action: "click"
                }))
            },
            c = (u = n.attribution) != null ? u : at(n.url);
        return a.jsxs(fe, {
            componentType: Mt,
            href: n.url,
            onClick: l,
            animateScan: !e,
            isSmall: r,
            children: [a.jsx(Qe, {
                url: n.url,
                useCloudDocIcons: s
            }), o ? a.jsx("div", {
                className: "max-w-[8rem] truncate",
                children: c
            }) : c]
        })
    },
    Qe = ({
        url: t,
        withBorder: e = !1,
        useCloudDocIcons: s
    }) => {
        const {
            isSuccess: r,
            isError: o
        } = ze(rt(t, 32)), [n] = y.useState(r);
        if (o) return null;
        if (s) {
            const i = nt(t);
            if ((i == null ? void 0 : i.Icon) != null) return a.jsx(_.div, {
                initial: {
                    opacity: n ? 1 : 0
                },
                animate: {
                    opacity: r ? 1 : 0
                },
                className: b("bg-token-main-surface-primary -ms-3 box-content h-3 w-3 shrink-0 overflow-hidden rounded-full first:-ms-1", e && "border-token-main-surface-secondary group-hover:border-token-text-primary dark:group-hover:border-token-text-primary border"),
                children: a.jsx(i.Icon, {
                    className: "m-0 h-3 w-3"
                })
            })
        }
        return a.jsx(_.div, {
            initial: {
                opacity: n ? 1 : 0
            },
            animate: {
                opacity: r ? 1 : 0
            },
            className: b("bg-token-main-surface-primary -ms-3 box-content h-3 w-3 shrink-0 overflow-hidden rounded-full first:-ms-1", e && "border-token-main-surface-secondary group-hover:border-token-text-primary dark:group-hover:border-token-text-primary border"),
            children: a.jsx(ot, {
                url: t,
                size: 32,
                minSize: 16,
                className: "m-0 h-3 w-3"
            })
        })
    },
    ds = ({
        moreItems: t,
        isShowingMore: e,
        onClick: s,
        useCloudDocIcons: r,
        isSmall: o
    }) => a.jsx(fe, {
        onClick: s,
        isSmall: o,
        children: e ? a.jsx(Y, {
            id: "19fGXl",
            defaultMessage: "Show less"
        }) : a.jsxs(a.Fragment, {
            children: [t.slice(0, rs).map((n, i) => a.jsx(Qe, {
                url: n.entries[0].url,
                withBorder: !0,
                useCloudDocIcons: r
            }, i)), a.jsx("div", {
                className: "max-w-[8rem] truncate",
                children: a.jsx(Y, {
                    id: "5ob5C8",
                    defaultMessage: "{count} more",
                    values: {
                        count: t.length
                    }
                })
            })]
        })
    }),
    fs = ({
        moreItems: t,
        isShowingMore: e,
        onClick: s,
        isSmall: r
    }) => a.jsx(fe, {
        onClick: s,
        isSmall: r,
        children: e ? a.jsx(Y, {
            id: "0SWns2",
            defaultMessage: "Show less"
        }) : a.jsx(Y, {
            id: "PpZw7t",
            defaultMessage: "{count} more",
            values: {
                count: t.length
            }
        })
    }),
    gs = 1500,
    fe = t => {
        "use forget";
        var M;
        const e = V.c(26);
        let s, r, o, n, i, l;
        e[0] !== t ? (M = t, {
            className: o,
            componentType: i,
            children: r,
            animateScan: s,
            isSmall: l
        } = M, n = be(M, ["className", "componentType", "children", "animateScan", "isSmall"]), e[0] = t, e[1] = s, e[2] = r, e[3] = o, e[4] = n, e[5] = i, e[6] = l) : (s = e[1], r = e[2], o = e[3], n = e[4], i = e[5], l = e[6]);
        const c = i === void 0 ? "button" : i,
            u = l === void 0 ? !1 : l,
            [d, w] = y.useState(!1),
            g = Math.random() * gs;
        let m, x;
        e[7] !== s ? (m = () => {
            s && (w(!1), requestAnimationFrame(() => w(!0)))
        }, x = [s, g], e[7] = s, e[8] = m, e[9] = x) : (m = e[8], x = e[9]), y.useEffect(m, x);
        const C = u ? qt : Dt,
            S = s && "dark:border-token-main-surface-secondary border border-[#f4f4f4] bg-transparent dark:bg-transparent",
            N = (n.href != null || n.onClick != null) && "hover:bg-token-main-surface-primary-inverse hover:text-token-text-inverted dark:hover:bg-token-text-primary";
        let j;
        e[10] !== o || e[11] !== C || e[12] !== S || e[13] !== N ? (j = b(C, "group relative max-w-full overflow-hidden", S, N, o), e[10] = o, e[11] = C, e[12] = S, e[13] = N, e[14] = j) : j = e[14];
        let v;
        e[15] !== s || e[16] !== d ? (v = s && a.jsx("span", {
            className: b("dark:bg-token-main-surface-secondary absolute start-0 top-0 z-[-1] h-full rounded-se-full rounded-ee-full bg-[#f4f4f4] transition-[width] ease-in-out", d ? "w-full" : "w-0"),
            style: {
                transitionDuration: "".concat(g, "ms")
            }
        }), e[15] = s, e[16] = d, e[17] = v) : v = e[17];
        let h;
        e[18] !== r ? (h = a.jsx("div", {
            className: "z-1 inline-flex items-center gap-1",
            children: r
        }), e[18] = r, e[19] = h) : h = e[19];
        let p;
        return e[20] !== c || e[21] !== n || e[22] !== h || e[23] !== j || e[24] !== v ? (p = a.jsxs(c, W(H({
            className: j
        }, n), {
            children: [v, h]
        })), e[20] = c, e[21] = n, e[22] = h, e[23] = j, e[24] = v, e[25] = p) : p = e[25], p
    },
    ke = null,
    ms = jt(() => Ye(() => Promise.resolve().then(() => Xt), void 0).then(t => t.GlauxCoTChunk)),
    xs = t => {
        "use forget";
        const e = V.c(60),
            {
                index: s,
                chunk: r,
                onClick: o,
                onMeasure: n,
                onAnimationComplete: i,
                gap: l,
                showBullet: c,
                isExpanded: u,
                isAnimationComplete: d,
                isLast: w,
                isKAUR1BR5: g,
                hasGlauxMessages: m,
                isAgentTurn: x,
                interruptionInProgress: C,
                odysseyLoadingState: S,
                disableAnimation: N
            } = t,
            j = l === void 0 ? 0 : l,
            v = c === void 0 ? !1 : c,
            h = u === void 0 ? !1 : u,
            p = d === void 0 ? !1 : d,
            M = w === void 0 ? !1 : w,
            T = g === void 0 ? !1 : g,
            A = m === void 0 ? !1 : m,
            I = x === void 0 ? !1 : x,
            Z = C === void 0 ? !1 : C,
            q = S === void 0 ? K.Done : S,
            ye = N === void 0 ? !1 : N,
            ge = O(),
            J = M || h,
            E = !M || p,
            ee = M ? 0 : j,
            me = qe(),
            te = (me == null ? void 0 : me.type) === "cot";
        let se;
        e[0] !== r || e[1] !== Z || e[2] !== ge || e[3] !== I || e[4] !== E || e[5] !== M || e[6] !== te || e[7] !== q ? (se = te ? P(ge, r, E, Z, I && M, q, !0) : void 0, e[0] = r, e[1] = Z, e[2] = ge, e[3] = I, e[4] = E, e[5] = M, e[6] = te, e[7] = q, e[8] = se) : se = e[8];
        const D = se,
            xe = E || ye ? "static" : "stage",
            R = E || ye ? "static" : "enter";
        let ae;
        e[9] !== s || e[10] !== i ? (ae = () => {
            i == null || i(s, "enter")
        }, e[9] = s, e[10] = i, e[11] = ae) : ae = e[11];
        const k = vt(ae);
        let re, ne;
        e[12] !== R || e[13] !== k ? (re = () => {
            if (R !== "enter") return;
            const Q = setTimeout(() => {
                Ct.count(St.COT_SUMMARIZER, "cot_chunk_timeout"), k()
            }, Gt);
            return () => clearTimeout(Q)
        }, ne = [R, k], e[12] = R, e[13] = k, e[14] = re, e[15] = ne) : (re = e[14], ne = e[15]), y.useEffect(re, ne);
        const he = R === "static",
            je = y.useRef(null);
        let oe;
        e[16] !== s || e[17] !== n ? (oe = () => ct({
            axis: "height",
            target: je.current,
            onChange: Q => {
                const {
                    height: He
                } = Q;
                return n(s, He)
            }
        }), e[16] = s, e[17] = n, e[18] = oe) : oe = e[18];
        let ie;
        e[19] === Symbol.for("react.memo_cache_sentinel") ? (ie = [], e[19] = ie) : ie = e[19], wt(oe, ie);
        const pe = te ? void 0 : "button";
        let le;
        e[20] === Symbol.for("react.memo_cache_sentinel") ? (le = {
            static: {
                opacity: 1,
                scale: 1,
                position: "static",
                translateY: 0
            },
            enter: {
                position: "static",
                translateY: 0,
                scale: 1,
                opacity: 1
            },
            stage: {
                position: "absolute",
                translateY: -ve,
                scale: .95,
                opacity: 0
            }
        }, e[20] = le) : le = e[20];
        let z;
        e[21] !== h ? (z = h ? void 0 : {
            opacity: 0,
            pointerEvents: "none",
            position: "absolute",
            translateY: ve,
            filter: "blur(8px)"
        }, e[21] = h, e[22] = z) : z = e[22];
        let B;
        e[23] !== s ? (B = {
            zIndex: s
        }, e[23] = s, e[24] = B) : B = e[24];
        let F;
        e[25] !== R || e[26] !== p ? (F = p || R === "static" ? {
            duration: 0
        } : {
            type: "spring",
            bounce: .05
        }, e[25] = R, e[26] = p, e[27] = F) : F = e[27];
        const Me = !J && "pointer-events-none";
        let G;
        e[28] !== Me ? (G = b("text-token-text-secondary origin-start start-0 end-0 top-0 mb-2 flex", Me), e[28] = Me, e[29] = G) : G = e[29];
        let L;
        e[30] !== s || e[31] !== i ? (L = Q => Q !== "enter" && i(s, Q), e[30] = s, e[31] = i, e[32] = L) : L = e[32];
        let U;
        e[33] !== r || e[34] !== D || e[35] !== A || e[36] !== ee || e[37] !== I || e[38] !== E || e[39] !== h || e[40] !== T || e[41] !== M || e[42] !== J || e[43] !== v ? (U = v ? a.jsxs("div", {
            className: b("relative flex w-full items-start gap-2 overflow-clip", ke),
            children: [ke, a.jsxs("div", {
                className: "flex h-full w-4 shrink-0 flex-col items-center",
                children: [a.jsx("div", {
                    className: "flex h-5 shrink-0 items-center justify-center",
                    children: a.jsx(Pt, {
                        chunk: r,
                        size: "small"
                    })
                }), !M && a.jsx(_.div, {
                    initial: {
                        translateY: -ve,
                        opacity: 0
                    },
                    animate: {
                        translateY: 0,
                        opacity: 1
                    },
                    className: "bg-token-border-heavy h-full w-[1px] rounded-full"
                })]
            }), a.jsxs("div", {
                className: "w-full",
                style: {
                    marginBottom: ee
                },
                children: [J && a.jsx("div", {
                    className: "w-full",
                    children: D && a.jsx("div", {
                        className: "text-token-text-primary text-[14px] leading-5",
                        children: D
                    })
                }), a.jsx(Pe, {
                    chunk: r,
                    isExpanded: h,
                    isComplete: E,
                    isLast: M,
                    isKAUR1BR5: T,
                    hasGlauxMessages: A,
                    isAgentTurn: I
                })]
            })]
        }) : a.jsxs("div", {
            className: "w-full",
            style: {
                marginBottom: ee
            },
            children: [J && a.jsx("div", {
                className: "w-full",
                children: D && a.jsx("div", {
                    className: "text-token-text-primary text-sm",
                    children: D
                })
            }), a.jsx(Pe, {
                chunk: r,
                isExpanded: h,
                isComplete: E,
                isLast: M,
                isKAUR1BR5: T,
                isAgentTurn: I
            })]
        }), e[33] = r, e[34] = D, e[35] = A, e[36] = ee, e[37] = I, e[38] = E, e[39] = h, e[40] = T, e[41] = M, e[42] = J, e[43] = v, e[44] = U) : U = e[44];
        let $;
        e[45] !== he || e[46] !== k || e[47] !== U ? ($ = a.jsx(ut, {
            onComplete: k,
            isDisabled: he,
            defaultDelayPerSegmentMs: 20,
            children: U
        }), e[45] = he, e[46] = k, e[47] = U, e[48] = $) : $ = e[48];
        let ce;
        return e[49] !== R || e[50] !== xe || e[51] !== o || e[52] !== pe || e[53] !== z || e[54] !== B || e[55] !== F || e[56] !== G || e[57] !== L || e[58] !== $ ? (ce = a.jsx(_.div, {
            role: pe,
            variants: le,
            initial: xe,
            animate: R,
            exit: z,
            style: B,
            transition: F,
            className: G,
            onAnimationComplete: L,
            onClick: o,
            ref: je,
            children: $
        }), e[49] = R, e[50] = xe, e[51] = o, e[52] = pe, e[53] = z, e[54] = B, e[55] = F, e[56] = G, e[57] = L, e[58] = $, e[59] = ce) : ce = e[59], ce
    },
    bs = y.memo(xs),
    _s = t => {
        "use forget";
        const e = V.c(17),
            {
                className: s,
                dot: r,
                text: o,
                isStreamingAnimation: n,
                isInteractive: i,
                onClick: l
            } = t,
            c = i === void 0 ? !0 : i,
            [u, d] = y.useState(""),
            w = y.useDeferredValue(u),
            g = y.useRef(null),
            m = y.useRef("");
        let x, C;
        e[0] !== n ? (x = () => {
            if (n) return g.current = new _e(Re, d, "", !0), () => {
                var A;
                (A = g.current) == null || A.destroy(), g.current = null
            }
        }, C = [n], e[0] = n, e[1] = x, e[2] = C) : (x = e[1], C = e[2]), y.useEffect(x, C);
        let S, N;
        e[3] !== n || e[4] !== o ? (S = () => {
            var q;
            if (!n) return;
            const A = g.current;
            if (!A) return;
            const I = m.current;
            o.startsWith(I) || (A.destroy(), d(""), g.current = new _e(Re, d, "", !0)), (q = g.current) == null || q.setText(o), m.current = o
        }, N = [o, n], e[3] = n, e[4] = o, e[5] = S, e[6] = N) : (S = e[5], N = e[6]), y.useEffect(S, N);
        const j = c ? "cursor-pointer" : "cursor-default";
        let v;
        e[7] !== s || e[8] !== j ? (v = b("text-token-text-tertiary line-clamp-3", j, s), e[7] = s, e[8] = j, e[9] = v) : v = e[9];
        const h = c ? l : void 0,
            p = n ? w : o;
        let M;
        e[10] !== r ? (M = r && a.jsx("span", {
            className: "ms-1 inline-block size-3.5 rounded-full bg-black dark:bg-white"
        }), e[10] = r, e[11] = M) : M = e[11];
        let T;
        return e[12] !== M || e[13] !== v || e[14] !== h || e[15] !== p ? (T = a.jsxs("p", {
            className: v,
            onClick: h,
            children: [p, M]
        }), e[12] = M, e[13] = v, e[14] = h, e[15] = p, e[16] = T) : T = e[16], T
    },
    Rs = ({
        chunk: t,
        isLast: e,
        hasGlauxMessages: s,
        intl: r
    }) => {
        switch (t.type) {
            case f.Thought:
                return t.thought.content.trim() || t.thought.summary;
            case f.Recap:
                return t.didFailReasoning || t.didSkipReasoning ? null : t.content.includes("Stopped") ? r.formatMessage({
                    id: "sOsSsn",
                    defaultMessage: "Stopped"
                }) : s && !e ? "" : r.formatMessage({
                    id: "Eo2n2s",
                    defaultMessage: "Done"
                });
            case f.Search:
                return t.sources.slice(0, 3).map(o => o.domain).join(", ") + "...";
            case f.CodeAnalysis:
                return P(r, t, !1) + "...";
            case f.N7jupdAPI:
                return null;
            case f.Browsing:
                return null;
            case f.ImageAnalysis:
                return r.formatMessage({
                    id: "IrgecZ",
                    defaultMessage: "Analyzing image"
                });
            case f.ComputerOutput:
                return r.formatMessage({
                    id: "QJACwT",
                    defaultMessage: "Using browser"
                });
            case f.N7jupdLoading:
                return null;
            case f.e1ld0dvz:
                return r.formatMessage({
                    id: "f87J+9",
                    defaultMessage: "Delegating tasks"
                });
            case f.Glaux:
                return Le({
                    intl: r,
                    chunk: t
                });
            case f.Strix:
                return
        }
    },
    Pe = ({
        chunk: t,
        isExpanded: e,
        isComplete: s,
        isLast: r,
        isKAUR1BR5: o,
        hasGlauxMessages: n,
        isAgentTurn: i
    }) => {
        var d, w;
        const l = yt(),
            c = O(),
            u = it(l, !!i);
        switch (t.type) {
            case f.Thought:
                return a.jsx(X, {
                    content: t.thought.content.trim() || t.thought.summary
                });
            case f.Recap:
                return t.didFailReasoning || t.didSkipReasoning ? null : t.content.includes("Stopped") ? a.jsx(X, {
                    content: c.formatMessage({
                        id: "sOsSsn",
                        defaultMessage: "Stopped"
                    })
                }) : n && !r ? null : a.jsx(X, {
                    content: c.formatMessage({
                        id: "Eo2n2s",
                        defaultMessage: "Done"
                    })
                });
            case f.Search:
                return a.jsx(ls, {
                    chunk: t,
                    isExpanded: e,
                    isComplete: s,
                    enableV4: u
                });
            case f.CodeAnalysis:
                {
                    const g = t.assistantMessage,
                        m = t.toolMessage;
                    return (g == null ? void 0 : g.recipient) === "container.exec" && ((d = g == null ? void 0 : g.metadata) != null && d.n7jupd_message) && ((w = m == null ? void 0 : m.metadata) != null && w.n7jupd_message) ? a.jsx(Jt, {
                        chunk: t,
                        isExpanded: e,
                        isComplete: s,
                        enableV4: u
                    }) : a.jsx(ts, {
                        chunk: t,
                        isExpanded: e,
                        isComplete: s,
                        enableV4: u
                    })
                }
            case f.N7jupdAPI:
                return t.action === "n7jupd_as" || t.action === "n7jupd_ag" ? e && a.jsx(X, {
                    content: de({
                        action: t.action,
                        source: t.source,
                        intl: c
                    })
                }) : a.jsx(is, {
                    chunk: t,
                    isExpanded: e,
                    isComplete: s
                });
            case f.Browsing:
                return e && a.jsx(X, {
                    content: Ge({
                        contextualAnswerSources: t.sources,
                        intl: c
                    })
                });
            case f.ImageAnalysis:
                return a.jsx(ss, {
                    chunk: t,
                    isExpanded: e,
                    isComplete: s,
                    enableV4: u
                });
            case f.ComputerOutput:
                return a.jsx(lt, {
                    chunk: t,
                    isKAUR1BR5: o
                });
            case f.N7jupdLoading:
                return null;
            case f.e1ld0dvz:
                return a.jsx(Zt, {
                    tasks: t.tasks
                });
            case f.Glaux:
                return a.jsx(ms, {
                    chunk: t,
                    isExpanded: e,
                    isComplete: s
                });
            case f.Strix:
                return
        }
    };
export {
    bs as C, ve as S, Ss as a, _s as b, $e as c, Rs as d, Ns as e, P as f, de as g
};
//# sourceMappingURL=d500l0l73692yic4.js.map