const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/m3djk6i2wc28kwrx.js", "assets/fg33krlcm0qyi6yw.js", "assets/dykg4ktvbu3mhmdo.js", "assets/root-ipvq9zhe.css", "assets/bdob0mmccomv88dh.js", "assets/k15yxxoybkkir2ou.js", "assets/conversation-small-332fs9rk.css", "assets/cdnrxzg58mayu5uf.js", "assets/gmop4abenl57iboh.js", "assets/jhvz2qkf3st8xisu.js", "assets/lts8z3c38wfynrxz.js", "assets/ccj0kc5w6drbfrlh.js", "assets/ef7gr7kimbtxrws9.js", "assets/nr0ly5umft9hqfl0.js", "assets/ebc4iyfg14nu1gw4.js", "assets/gy1lpvuoewmzh42c.js", "assets/jed1ux7qibe55pmj.js", "assets/h1em0bjkpkjv8ykw.js", "assets/nfccle6oyncifphl.js", "assets/hu1bt0oauegdhua6.js", "assets/b5s349mvbdzayaxi.js", "assets/dbshkzvpochy4889.js", "assets/gjyisy9q1t8rz8p4.js", "assets/lqog7ixiwnif6sbp.js", "assets/nzl91iujqafxz8y1.js", "assets/ktlrbeajo849nxci.js", "assets/kl7c6054usfnqmd4.js", "assets/ns51nblw8ziscsgd.js", "assets/lxz8iceptw5q89al.js", "assets/aozfqr1i52mjkof3.js", "assets/gnf5x18zszgh02tj.js", "assets/jq369xe6tq4tfy56.js", "assets/gvldjhupitopee77.js"]))) => i.map(i => d[i]);
var ge = Object.defineProperty,
    $e = Object.defineProperties;
var Ee = Object.getOwnPropertyDescriptors;
var Wt = Object.getOwnPropertySymbols;
var be = Object.prototype.hasOwnProperty,
    ke = Object.prototype.propertyIsEnumerable;
var dt = (e, t) => (t = Symbol[e]) ? t : Symbol.for("Symbol." + e),
    ve = e => {
        throw TypeError(e)
    };
var Rt = (e, t, n) => t in e ? ge(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : e[t] = n,
    S = (e, t) => {
        for (var n in t || (t = {})) be.call(t, n) && Rt(e, n, t[n]);
        if (Wt)
            for (var n of Wt(t)) ke.call(t, n) && Rt(e, n, t[n]);
        return e
    },
    pt = (e, t) => $e(e, Ee(t));
var y = (e, t, n) => Rt(e, typeof t != "symbol" ? t + "" : t, n);
var Ct = function(e, t) {
        this[0] = e, this[1] = t
    },
    It = (e, t, n) => {
        var o = (l, a, u, m) => {
                try {
                    var p = n[l](a),
                        g = (a = p.value) instanceof Ct,
                        b = p.done;
                    Promise.resolve(g ? a[0] : a).then(c => g ? o(l === "return" ? l : "next", a[1] ? {
                        done: c.done,
                        value: c.value
                    } : c, u, m) : u({
                        value: c,
                        done: b
                    })).catch(c => o("throw", c, u, m))
                } catch (c) {
                    m(c)
                }
            },
            s = l => i[l] = a => new Promise((u, m) => o(l, a, u, m)),
            i = {};
        return n = n.apply(e, t), i[dt("asyncIterator")] = () => i, s("next"), s("throw"), s("return"), i
    },
    Ft = e => {
        var t = e[dt("asyncIterator")],
            n = !1,
            o, s = {};
        return t == null ? (t = e[dt("iterator")](), o = i => s[i] = l => t[i](l)) : (t = t.call(e), o = i => s[i] = l => {
            if (n) {
                if (n = !1, i === "throw") throw l;
                return l
            }
            return n = !0, {
                done: !1,
                value: new Ct(new Promise(a => {
                    var u = t[i](l);
                    u instanceof Object || ve("Object expected"), a(u)
                }), 1)
            }
        }), s[dt("iterator")] = () => s, o("next"), "throw" in t ? o("throw") : s.throw = i => {
            throw i
        }, "return" in t && o("return"), s
    },
    qt = (e, t, n) => (t = e[dt("asyncIterator")]) ? t.call(e) : (e = e[dt("iterator")](), t = {}, n = (o, s) => (s = e[o]) && (t[o] = i => new Promise((l, a, u) => (i = s.call(e, i), u = i.done, Promise.resolve(i.value).then(m => l({
        value: m,
        done: u
    }), a)))), n("next"), n("return"), t);
import {
    _ as K,
    c as Yt,
    r as N,
    j as yt
} from "./fg33krlcm0qyi6yw.js";
import {
    p as Se,
    P as Ce,
    iU as we,
    gh as B,
    gi as nt,
    ks as H,
    kq as j,
    c3 as d,
    kr as Ht,
    lv as Xt,
    jw as Dt,
    zz as Ae,
    c4 as Qt,
    bh as Lt,
    i_ as Te,
    h as T,
    b7 as wt,
    g9 as Pt,
    cU as Nt,
    aU as X,
    R as Zt,
    dB as Re,
    lt as At,
    oe as Pe,
    mv as Oe,
    sy as xe,
    zA as De,
    en as Vt,
    oh as Le,
    k5 as Ne,
    aX as mt,
    gb as Ue,
    hg as Me,
    kN as We,
    d as Ie,
    dI as Fe,
    b as qe,
    e1 as Ve,
    eg as Jt
} from "./dykg4ktvbu3mhmdo.js";
import {
    t as Be
} from "./ef7gr7kimbtxrws9.js";
import {
    C as Bt,
    a as je,
    i as Ke
} from "./ktlrbeajo849nxci.js";
import {
    pr as te,
    cG as ze,
    bB as Ge
} from "./k15yxxoybkkir2ou.js";
import {
    d as Ye
} from "./kl7c6054usfnqmd4.js";
import {
    M as Ot,
    E as He
} from "./ns51nblw8ziscsgd.js";
const Xe = e => !!e && typeof e == "object" && e.should_display === !1 && "original_error" in e,
    ee = e => {
        var t;
        return Array.isArray(e) && (t = e.find(Xe)) != null ? t : null
    };

function ao(e) {
    var o, s, i, l;
    if (!(e instanceof Se)) return null;
    const t = (i = (o = e.json) == null ? void 0 : o.errors) != null ? i : (s = e.detail) == null ? void 0 : s.errors,
        n = ee(t);
    return n ? (l = n.original_error) != null ? l : n : null
}
const st = ({
        conversation: e,
        checkoutId: t,
        connectorId: n,
        messageId: o
    }, s) => {
        Ce.logEventWithStatsig("product_checkout", "product_checkout", S(pt(S(S(S({}, we({
            clientThreadId: e.id,
            messageId: o != null ? o : void 0
        })), t ? {
            checkout_id: t
        } : {}), n ? {
            connector_id: n
        } : {}), {
            merchant_platform: "ecosystem"
        }), s))
    },
    co = (e, t) => st(e, S(S(S({
        action: "shown"
    }, t.merchantName ? {
        merchant_name: t.merchantName
    } : {}), t.merchantUrl ? {
        merchant_url: t.merchantUrl
    } : {}), t.hadSavedPaymentMethod !== void 0 ? {
        hadSavedPaymentMethod: t.hadSavedPaymentMethod
    } : {})),
    xt = (e, t, n) => st(e, S({
        action: "cart_load_failed",
        reason: t
    }, n ? {
        error_message: n
    } : {})),
    uo = (e, {
        label: t,
        source: n,
        hasExistingPaymentMethod: o
    }) => st(e, {
        credit_card_type: t != null ? t : void 0,
        prefill: n === "prefill",
        action: o ? "payment_method_updated" : "payment_method_added"
    }),
    mo = (e, t) => st(e, {
        credit_card_type: t != null ? t : void 0,
        action: "payment_method_removed"
    }),
    _o = (e, {
        paymentMethod: t,
        attemptId: n
    }) => st(e, S({
        payment_method: t != null ? t : void 0,
        action: "express_checkout_button_clicked"
    }, n ? {
        attempt_id: n
    } : {})),
    fo = (e, {
        paymentMethod: t,
        attemptId: n,
        isExpressCheckout: o,
        merchantName: s,
        merchantUrl: i
    }) => st(e, S(S(S(S(S({
        action: "pay_button_clicked"
    }, t ? {
        payment_method: t
    } : {}), s ? {
        merchant_name: s
    } : {}), i ? {
        merchant_url: i
    } : {}), n ? {
        attempt_id: n
    } : {}), o !== void 0 ? {
        is_express_checkout: o
    } : {})),
    po = (e, {
        attemptId: t,
        reason: n,
        errorMessage: o,
        succeeded: s
    }) => st(e, S(S(S({
        action: s ? "payment_succeeded" : "payment_failed"
    }, t ? {
        attempt_id: t
    } : {}), n ? {
        reason: n
    } : {}), o ? {
        error_message: o
    } : {})),
    Qe = ["stripe"],
    Ze = ["card", "link", "apple_pay", "google_pay"],
    Je = ["terms_of_use", "privacy_policy", "seller_shop_policies"],
    tn = ["missing", "invalid", "out_of_stock", "payment_declined", "requires_sign_in", "requires_3ds"],
    en = ["plain", "markdown"],
    nn = ["items_base_amount", "items_discount", "subtotal", "discount", "fulfillment", "tax", "fee", "tip", "total"],
    ne = ["not_ready_for_payment", "ready_for_payment", "completed", "canceled"],
    on = ["live", "test"],
    oe = B({
        id: d,
        item: B({
            id: d,
            quantity: j
        }),
        base_amount: j,
        discount: j,
        subtotal: j,
        tax: j,
        total: j
    }),
    se = B({
        type: nt(nn),
        display_text: d,
        amount: j
    }),
    sn = B({
        id: d,
        type: () => "shipping",
        title: d,
        subtitle: d,
        subtotal: j,
        tax: j,
        total: j,
        carrier_info: d,
        earliest_delivery_time: d,
        latest_delivery_time: d
    }),
    ln = B({
        id: d,
        type: () => "digital",
        title: d,
        subtitle: d,
        subtotal: j,
        tax: j,
        total: j
    }),
    ie = e => {
        var n;
        switch (Dt((n = Qt(e)) == null ? void 0 : n.type, ["shipping", "digital"])) {
            case "shipping":
                return sn(e);
            case "digital":
                return ln(e)
        }
    },
    le = nt(en),
    rn = B({
        type: () => "info",
        param: d,
        content_type: le,
        content: d
    }),
    re = B({
        type: () => "error",
        code: nt(tn),
        param: d,
        content_type: le,
        content: d
    }),
    ae = e => {
        var n;
        switch (Dt((n = Qt(e)) == null ? void 0 : n.type, ["info", "error"])) {
            case "info":
                return rn(e);
            case "error":
                return re(e)
        }
    },
    ce = B({
        type: nt(Je),
        url: d
    }),
    ue = B({
        name: d,
        line_one: d,
        line_two: d,
        city: d,
        state: d,
        country: e => {
            var t;
            return (t = Be(e)) != null ? t : "US"
        },
        postal_code: d
    }),
    an = B({
        id: d,
        checkout_session_id: d,
        permalink_url: d
    }),
    cn = B({
        merchant_id: d,
        provider: nt(Qe),
        supported_payment_methods: H(nt(Ze))
    }),
    de = e => Dt(d(e).toUpperCase(), Ae),
    un = nt(on),
    dn = B({
        id: d,
        payment_provider: cn,
        payment_mode: un,
        status: nt(ne),
        currency: de,
        line_items: H(oe),
        totals: H(se),
        fulfillment_options: H(ie),
        fulfillment_address: Xt(ue),
        fulfillment_option_id: Ht(d),
        messages: H(ae),
        links: H(ce)
    }),
    ho = B({
        id: d,
        buyer: B({
            email: d,
            phone_number: d
        }),
        status: nt(ne),
        currency: de,
        line_items: H(oe),
        totals: H(se),
        fulfillment_options: H(ie),
        fulfillment_address: Xt(ue),
        fulfillment_option_id: Ht(d),
        messages: H(ae),
        links: H(ce),
        order: an
    }),
    mn = Lt(() => K(() =>
        import ("./m3djk6i2wc28kwrx.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27])).then(e => e.EcosystemCheckoutModal));
class _n {
    constructor(t) {
        y(this, "checkoutPromise$", T(null));
        y(this, "chatSDK$", T(null));
        y(this, "resolvedWidget$", T(null));
        y(this, "isLoadingPayment$", T(!0));
        y(this, "checkoutSession$", T(null));
        y(this, "grandTotal$", wt(() => {
            var t;
            return (t = this.checkoutSession$()) == null ? void 0 : t.totals.find(n => n.type === "total")
        }));
        y(this, "status$", T("idle"));
        y(this, "messages$", T([]));
        y(this, "errorMessages$", wt(() => this.messages$().filter(t => t.type === "error")));
        y(this, "paymentDetails$", T(null));
        y(this, "paymentTypes$", T([]));
        y(this, "allowedCountries$", T([]));
        y(this, "paymentSheetButtonCta$", T(""));
        y(this, "publishableKey$", T(null));
        y(this, "customerId$", T(null));
        y(this, "footerMessage$", T(null));
        y(this, "sellerDetails$", T(null));
        y(this, "orderId$", T(null));
        y(this, "billingAddress$", T(null));
        y(this, "billingAddressComplete$", wt(() => {
            var t, n, o, s, i, l;
            return this.billingAddress$() ? !!((t = this.billingAddress$()) != null && t.name) && !!((n = this.billingAddress$()) != null && n.line_one) && !!((o = this.billingAddress$()) != null && o.city) && !!((s = this.billingAddress$()) != null && s.state) && !!((i = this.billingAddress$()) != null && i.country) && !!((l = this.billingAddress$()) != null && l.postal_code) : !1
        }));
        y(this, "openCheckout", (t, n, o) => new Promise((s, i) => {
            Pt(() => {
                var l;
                this.checkoutPromise$.set({
                    resolve: s,
                    reject: i
                }), this.chatSDK$.set(t), this.resolvedWidget$.set(n), this.checkoutSession$.set(o), this.billingAddress$.set((l = o.fulfillment_address) != null ? l : null), this.paymentDetails$.set(null), Nt(this.conversation.ctx, mn, {
                    conversation: this.conversation
                })
            })
        }));
        y(this, "closeCheckout", () => Pt(() => {
            this.messages$.set([]), this.chatSDK$.set(null), this.checkoutSession$.set(null), this.billingAddress$.set(null), this.paymentSheetButtonCta$.set(""), this.checkoutPromise$.set(null), this.status$.set("idle"), this.paymentDetails$.set(null), this.billingAddress$.set(null)
        }));
        y(this, "cancelCheckout$", () => {
            var t;
            (t = this.checkoutPromise$()) == null || t.reject(), this.closeCheckout()
        });
        y(this, "completeCheckout$", t => {
            var n, o;
            this.status$.set("complete"), (o = (n = this.checkoutPromise$()) == null ? void 0 : n.resolve) == null || o.call(n, t)
        });
        y(this, "addErrorMessage$", t => {
            this.messages$.set([...this.messages$(), re({
                code: "invalid",
                content: t
            })])
        });
        y(this, "fetchStripeSession$", async () => {
            var u, m, p, g, b, c, O;
            const t = window.location.href,
                n = t.includes("/share/"),
                {
                    widgetParent: o,
                    connectorId: s
                } = X(this.chatSDK$()),
                {
                    name: i,
                    logoUrl: l
                } = X(this.resolvedWidget$()),
                a = X(this.checkoutSession$());
            try {
                const {
                    cart: $,
                    customer_id: k,
                    id: x,
                    customer_session_client_secret: D,
                    publishable_key: R,
                    allowed_countries: v,
                    payment_surfaces_and_types: E,
                    seller_details: G,
                    payment_sheet_button_cta: U
                } = await Zt.safePost("/shopping/ecosystem/checkout_v2", {
                    requestBody: pt(S({}, a), {
                        logo_url: l != null ? l : null,
                        merchant: {
                            name: i != null ? i : ""
                        },
                        shared_conversation_url: n ? t : null,
                        ecosystem_app_uri: o,
                        connector_id: s
                    })
                }), M = ee($ == null ? void 0 : $.errors);
                if (M) {
                    const C = M.original_error;
                    return xt({
                        conversation: this.conversation,
                        checkoutId: a.id,
                        connectorId: s,
                        messageId: (m = (u = this.chatSDK$()) == null ? void 0 : u.toolMessageId) != null ? m : null
                    }, "non_displayable_cart_error", C), (p = this.checkoutPromise$()) == null || p.reject(C != null ? C : M), this.closeCheckout(), {
                        error: "Failed to load cart session (ecosystem)"
                    }
                }
                return !D || !R ? (xt({
                    conversation: this.conversation,
                    checkoutId: a.id,
                    connectorId: s,
                    messageId: (b = (g = this.chatSDK$()) == null ? void 0 : g.toolMessageId) != null ? b : null
                }, "error_response_from_endpoint", "Missing customer_session_client_secret or publishable_key"), {
                    error: "Failed to load cart session (ecosystem)"
                }) : (Pt(() => {
                    var C, W;
                    this.orderId$.set(x), this.footerMessage$.set((C = $ == null ? void 0 : $.footer_level_message) != null ? C : null), this.publishableKey$.set(R), this.customerId$.set(k), this.paymentTypes$.set((W = E == null ? void 0 : E.filter(h => h.surface === "payment_sheet").flatMap(h => h.types)) != null ? W : []), this.allowedCountries$.set(v), this.sellerDetails$.set(G), this.paymentSheetButtonCta$.set(U)
                }), {
                    client_secret: D,
                    publishable_key: R
                })
            } catch ($) {
                throw xt({
                    conversation: this.conversation,
                    checkoutId: a.id,
                    connectorId: s,
                    messageId: (O = (c = this.chatSDK$()) == null ? void 0 : c.toolMessageId) != null ? O : null
                }, "error_thrown_from_endpoint", $ instanceof Error ? $.message : "Unknown error"), $
            }
        });
        this.conversation = t
    }
}
const fn = Te(e => new _n(e)),
    pn = /^[A-Z]{3}$/,
    hn = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/i,
    yn = /^\+[1-9]\d{1,14}$/,
    gn = ["fee", "tax", "fulfillment", "discount", "items_discount", "tip"];

function f(e, t, n) {
    if (!e) {
        if (n) throw new Error("Invalid checkout session: ".concat(t));
        console.warn("Invalid checkout session: ".concat(t))
    }
}
const V = (e, t, n) => {
        f(e.trim().length > 0, "".concat(t, " must be a non-empty string"), n)
    },
    ht = (e, t, n, o) => {
        f(e.length <= t, "".concat(n, " must be ").concat(t, " characters or fewer"), o)
    },
    et = (e, t, n) => {
        f(Number.isInteger(e), "".concat(t, " must be provided in integer minor currency units"), n), f(e >= 0, "".concat(t, " must be greater than or equal to 0"), n)
    },
    $n = (e, t, n) => {
        f(Number.isInteger(e) && e > 0, "".concat(t, " must be a positive integer"), n)
    },
    jt = e => hn.test(e) && !Number.isNaN(Date.parse(e)),
    En = (e, t) => {
        f(e.length > 0, "links must include at least one entry (e.g. terms of use or privacy policy)", t), e.forEach((n, o) => {
            V(n.url, "links[".concat(o, "].url"), t);
            try {
                new URL(n.url)
            } catch (s) {
                throw new Error("Invalid checkout session: links[".concat(o, "].url must be an absolute URL"))
            }
        })
    },
    bn = (e, t) => {
        var n;
        V(e.name, "fulfillment_address.name", t), ht(e.name, 256, "fulfillment_address.name", t), V(e.line_one, "fulfillment_address.line_one", t), ht(e.line_one, 60, "fulfillment_address.line_one", t), (n = e.line_two) != null && n.trim() && ht(e.line_two, 60, "fulfillment_address.line_two", t), V(e.city, "fulfillment_address.city", t), ht(e.city, 60, "fulfillment_address.city", t), V(e.state, "fulfillment_address.state", t), V(e.country, "fulfillment_address.country", t), V(e.postal_code, "fulfillment_address.postal_code", t), ht(e.postal_code, 20, "fulfillment_address.postal_code", t), e.phone_number && f(yn.test(e.phone_number), "fulfillment_address.phone_number must follow the E.164 format (example: +15551234567)", t)
    },
    kn = (e, t) => {
        const n = {
            baseAmount: 0,
            discount: 0,
            subtotal: 0,
            tax: 0,
            total: 0
        };
        for (const [o, s] of e.entries()) {
            V(s.id, "line_items[".concat(o, "].id"), t), V(s.item.id, "line_items[".concat(o, "].item.id"), t), $n(s.item.quantity, "line_items[".concat(o, "].item.quantity"), t), et(s.base_amount, "line_items[".concat(o, "].base_amount"), t), et(s.discount, "line_items[".concat(o, "].discount"), t), et(s.subtotal, "line_items[".concat(o, "].subtotal"), t), et(s.tax, "line_items[".concat(o, "].tax"), t), et(s.total, "line_items[".concat(o, "].total"), t);
            const i = s.base_amount - s.discount;
            f(s.subtotal === i, "line_items[".concat(o, "].subtotal must equal base_amount - discount (").concat(i, ")"), t);
            const l = s.subtotal + s.tax;
            f(s.total === l, "line_items[".concat(o, "].total must equal subtotal + tax (").concat(l, ")"), t), n.baseAmount += s.base_amount, n.discount += s.discount, n.subtotal += s.subtotal, n.tax += s.tax, n.total += s.total
        }
        return n
    },
    vn = (e, t, n) => {
        var c, O, $, k, x, D;
        f(e.length > 0, "totals must contain at least one entry", n);
        const o = {};
        for (const [R, v] of e.entries()) {
            et(v.amount, "totals[".concat(R, "].amount"), n);
            const E = o[v.type];
            E != null && f(gn.includes(v.type), 'totals contains duplicate total type "'.concat(v.type, '"'), n), o[v.type] = (E != null ? E : 0) + v.amount
        }
        f(o.items_base_amount !== void 0, "totals must include an items_base_amount entry", n), f(o.subtotal !== void 0, "totals must include a subtotal entry", n), f(o.total !== void 0, "totals must include a total entry", n);
        const s = o;
        f(s.items_base_amount === t.baseAmount, "totals.items_base_amount (".concat(s.items_base_amount, ") must equal the sum of line item base_amounts (").concat(t.baseAmount, ")"), n), s.items_discount !== void 0 && f(s.items_discount === t.discount, "totals.items_discount (".concat(s.items_discount, ") must equal the sum of line item discounts (").concat(t.discount, ")"), n);
        const i = (c = s.items_discount) != null ? c : t.discount,
            l = t.baseAmount - i;
        f(s.subtotal === l, "subtotal must equal items_base_amount - items_discount (".concat(l, ")"), n);
        const a = (O = s.discount) != null ? O : 0,
            u = ($ = s.fulfillment) != null ? $ : 0,
            m = (k = s.tax) != null ? k : t.tax,
            p = (x = s.fee) != null ? x : 0,
            g = (D = s.tip) != null ? D : 0,
            b = t.baseAmount - i - a + u + m + p + g;
        return f(s.total === b, "total must equal items_base_amount - items_discount - discount + fulfillment + tax + fee (".concat(b, ")"), n), s
    },
    Sn = (e, t) => {
        const n = new Map;
        for (const [o, s] of e.entries()) {
            if (V(s.id, "fulfillment_options[".concat(o, "].id"), t), V(s.title, "fulfillment_options[".concat(o, "].title"), t), s.type === "shipping" && V(s.subtitle, "fulfillment_options[".concat(o, "].subtitle"), t), et(s.subtotal, "fulfillment_options[".concat(o, "].subtotal"), t), et(s.tax, "fulfillment_options[".concat(o, "].tax"), t), et(s.total, "fulfillment_options[".concat(o, "].total"), t), f(s.total === s.subtotal + s.tax, "fulfillment_options[".concat(o, "].total must equal subtotal + tax"), t), f(!n.has(s.id), 'fulfillment option ids must be unique; duplicate id "'.concat(s.id, '"'), t), s.type === "shipping") {
                V(s.carrier_info, "fulfillment_options[".concat(o, "].carrier_info"), t), f(jt(s.earliest_delivery_time), "fulfillment_options[".concat(o, "].earliest_delivery_time must be an RFC 3339 timestamp"), t), f(jt(s.latest_delivery_time), "fulfillment_options[".concat(o, "].latest_delivery_time must be an RFC 3339 timestamp"), t);
                const i = Date.parse(s.earliest_delivery_time),
                    l = Date.parse(s.latest_delivery_time);
                f(i <= l, "fulfillment_options[".concat(o, "].earliest_delivery_time must be before or equal to latest_delivery_time"), t)
            }
            n.set(s.id, s)
        }
        return n
    },
    Cn = (e, t = !1) => {
        V(e.id, "id", t), f(pn.test(e.currency), 'currency "'.concat(e.currency, '" must be a lower-case ISO 4217 code'), t), f(e.payment_provider.supported_payment_methods.length > 0, "payment_provider.supported_payment_methods must include at least one entry", t), V(e.payment_provider.merchant_id, "payment_provider.merchant_id", t), f(e.line_items.length > 0, "line_items must contain at least one entry", t), f(e.totals.length > 0, "totals must contain at least one entry", t), En(e.links, t), e.fulfillment_address && bn(e.fulfillment_address, t);
        const n = kn(e.line_items, t),
            o = vn(e.totals, n, t),
            s = Sn(e.fulfillment_options, t);
        if (e.fulfillment_option_id) {
            const i = X(s.get(e.fulfillment_option_id), 'fulfillment_option_id "'.concat(e.fulfillment_option_id, '" must match an available fulfillment option'));
            f(o.fulfillment !== void 0, "totals must include a fulfillment entry when a fulfillment option is selected", t), f(o.fulfillment === i.total, "fulfillment total (".concat(o.fulfillment, ") must equal the selected fulfillment option total (").concat(i.total, ")"), t)
        }
    },
    wn = async ({
        ctx: e,
        chatSDK: t,
        clientThreadId: n,
        resolvedWidget: o,
        checkoutSession: s
    }) => {
        const i = dn(s);
        return Cn(i, !1), fn(Re(e, n)).openCheckout(t, o, i)
    },
    me = new Set(["http:", "https:"]),
    Kt = {
        "http:": 80,
        "https:": 443,
        "ws:": 80,
        "wss:": 443
    };

function _e(e) {
    if (!e) return null;
    const t = e.trim();
    if (!t || t.includes("\\")) return null;
    try {
        return {
            url: new URL(t)
        }
    } catch (n) {
        if (!/^[a-z][a-z0-9+.-]*:/.test(t)) try {
            const o = t.startsWith("//") ? "https:".concat(t) : "https://".concat(t);
            return {
                url: new URL(o)
            }
        } catch (o) {
            return null
        }
        return null
    }
}

function fe(e) {
    var b, c;
    const t = e.trim();
    if (!t) return null;
    const n = /^([a-z][a-z0-9+.-]*):$/i.exec(t);
    if (n) return {
        kind: "scheme",
        scheme: "".concat(n[1].toLowerCase(), ":")
    };
    const o = /^(?:([a-z][a-z0-9+.+-]*):\/\/)?(\*|\*\.[^/:]+|[^/:]+)(?::(\*|\d+))?(\/.*)?$/i.exec(t);
    if (!o) return null;
    const s = o[1] ? "".concat(o[1].toLowerCase(), ":") : void 0,
        i = o[2],
        l = (b = o[3]) != null ? b : null,
        a = (c = o[4]) != null ? c : null,
        u = i.startsWith("*."),
        m = (u ? i.slice(2) : i).toLowerCase().replace(/\.$/, "");
    let p = null,
        g = !1;
    return l !== null && (g = !0, p = l === "*" ? "*" : Number(l), p !== "*" && (!Number.isFinite(p) || p < 0)) ? null : {
        kind: "host",
        scheme: s,
        host: m,
        wildcard: u,
        portExplicit: g,
        port: p,
        path: a
    }
}

function Tt(e) {
    return e.toLowerCase().replace(/\.$/, "")
}

function pe(e, t) {
    const n = Tt(e),
        o = Tt(t);
    return n === o || n.endsWith("." + o)
}

function An(e, t, n) {
    return n ? pe(e, t) : Tt(e) === Tt(t)
}

function Tn(e, t) {
    var o, s;
    if (t.port === "*") return !0;
    const n = e.port ? Number(e.port) : (o = Kt[e.protocol]) != null ? o : null;
    if (!t.portExplicit) {
        const i = (s = Kt[e.protocol]) != null ? s : null;
        return n === i
    }
    return typeof t.port == "number" && n === t.port
}

function Rn(e) {
    var s, i;
    const t = (s = e.scheme) != null ? s : "https:";
    if (!me.has(t) || !e.host) return null;
    const n = typeof e.port == "number" ? ":".concat(e.port) : "",
        o = (i = e.path) != null ? i : "";
    try {
        return new URL("".concat(t, "//").concat(e.host).concat(n).concat(o))
    } catch (l) {
        return null
    }
}

function yo(e) {
    var o, s;
    const t = _e(e != null ? e : void 0);
    if (t && me.has(t.url.protocol) && !t.url.hostname.includes("*")) return t.url.toString();
    if (!e) return null;
    const n = fe(e);
    return !n || n.kind === "scheme" ? null : (s = (o = Rn(n)) == null ? void 0 : o.toString()) != null ? s : null
}

function Pn(e, t, n) {
    var i;
    const o = [];
    (i = t == null ? void 0 : t.connectDomains) != null && i.length && o.push(...t.connectDomains);
    const s = n == null ? void 0 : n.trim();
    return s && o.push(s), he(e, o)
}

function he(e, t) {
    if (!e) return !1;
    const n = _e(e);
    if (!n) return !1;
    const o = n.url;
    return o.username || o.password || !(t != null && t.length) ? !1 : t.some(s => {
        const i = fe(s);
        if (!i) return !1;
        if (i.kind === "scheme") return o.protocol === i.scheme;
        if (i.scheme) return !(o.protocol !== i.scheme || !An(o.hostname, i.host, i.wildcard) || !Tn(o, i)); {
            const l = i.host;
            return !!pe(o.hostname, l)
        }
    })
}
const zt = "redirectUrl";

function On(e, t) {
    if (!t) return e;
    let n;
    try {
        n = new URL(e)
    } catch (s) {
        return e
    }
    return n.protocol !== "http:" && n.protocol !== "https:" || n.searchParams.get(zt) ? e : (n.searchParams.set(zt, t), n.toString())
}
const xn = Lt(() => K(() =>
        import ("./lxz8iceptw5q89al.js"), __vite__mapDeps([28, 1, 2, 3, 29])).then(e => e.ConfirmExternalLinkModal)),
    Dn = Lt(() => K(() =>
        import ("./gnf5x18zszgh02tj.js"), __vite__mapDeps([30, 1, 2, 3])).then(e => e.SafeLinkWarningModal)),
    Gt = (e, t, n) => {
        const o = On(t, n);
        Pe() ? Nt(e, xn, {
            url: o
        }) : window.open(o, "_blank", "noopener,noreferrer")
    },
    Ln = async ({
        ctx: e,
        href: t,
        resolvedPineappleUri: n,
        csp: o,
        redirectDomains: s,
        domain: i,
        distributionChannel: l,
        redirectUrl: a
    }) => {
        if (!t) {
            console.error("No href provided to handleExternalLink");
            return
        }
        if (Pn(t, o, i) || he(t, s)) {
            Gt(e, t, a);
            return
        }
        if (l === At.OPENAI && await Nn(t, n)) {
            Gt(e, t, null);
            return
        }
        Nt(e, Dn, {
            urls: t,
            displayUrls: t
        })
    };
async function Nn(e, t) {
    try {
        return (await Zt.safePost("/ecosystem/url_safe", {
            requestBody: {
                url: e,
                resolved_pineapple_uri: t
            }
        })).safe
    } catch (n) {
        return !1
    }
}
const ye = e => {
        let t = "unknown";
        Oe() ? t = "mobile" : xe() ? t = "tablet" : De() && (t = "desktop");
        let n = "web";
        return e === "skybridge" && (n = "native"), {
            device: {
                type: t,
                platform: n
            },
            capabilities: {
                hover: Vt(Ne),
                touch: Vt(Le)
            }
        }
    },
    Un = e => e.concat().sort().map(t => "".concat(t, " *")).join("; "),
    Mn = (e, t, n) => "?" + ["", "app=".concat(e), "locale=".concat(t), "deviceType=".concat(ye(e).device.type), ""].filter(Boolean).join("&"),
    Wn = e => {
        if (e) {
            const t = new URL(Bt);
            return t.hostname = "".concat(e, ".").concat(t.hostname), t.protocol = je, t.origin
        }
        return Bt
    };

function In(e) {
    "use forget";
    const t = Yt.c(24),
        {
            host: n,
            features: o,
            isInert: s,
            title: i,
            ref: l,
            subdomain: a,
            iframeRef: u,
            api: m,
            locale: p
        } = e,
        g = n === void 0 ? "chatgpt" : n,
        b = s === void 0 ? !1 : s,
        [c] = N.useState(Fn);
    let O;
    t[0] !== c ? (O = async (z, ...A) => {
        var tt;
        const L = A;
        return await Ue(() => !!c()), X((tt = c()) == null ? void 0 : tt[z], "Method ".concat(String(z), " not found"))(...L)
    }, t[0] = c, t[1] = O) : O = t[1];
    const $ = mt(O);
    let k, x;
    t[2] !== $ ? (k = () => new Proxy({}, {
        get: (z, A) => (...L) => $(A, ...L)
    }), x = [$], t[2] = $, t[3] = k, t[4] = x) : (k = t[3], x = t[4]), N.useImperativeHandle(l, k, x);
    const D = N.useRef(m);
    let R, v;
    t[5] !== m ? (R = () => {
        D.current = m
    }, v = [m], t[5] = m, t[6] = R, t[7] = v) : (R = t[6], v = t[7]), N.useEffect(R, v);
    let E;
    t[8] !== c ? (E = z => z ? (Ke(z, new Proxy(D.current, {
        get: (A, L) => D.current[L]
    }), ["runUserCode", "runWidgetCode", "runComponent"]).then(A => {
        c.set(A)
    }), () => {
        c.set(null)
    }) : c.set(null), t[8] = c, t[9] = E) : E = t[9];
    const G = mt(E);
    let U;
    t[10] !== a ? (U = Wn(a), t[10] = a, t[11] = U) : U = t[11];
    const M = U,
        C = "sandbox-".concat(M);
    let W;
    t[12] !== g || t[13] !== p ? (W = Mn(g, p), t[12] = g, t[13] = p, t[14] = W) : W = t[14];
    const h = "".concat(M).concat(W),
        w = te(G, u);
    let I;
    t[15] !== o ? (I = o != null && o.length ? Un(o) : void 0, t[15] = o, t[16] = I) : I = t[16];
    let Q;
    return t[17] !== b || t[18] !== C || t[19] !== h || t[20] !== w || t[21] !== I || t[22] !== i ? (Q = yt.jsx(Me, {
        children: yt.jsx("iframe", {
            title: i,
            inert: b,
            src: h,
            ref: w,
            sandbox: "allow-scripts allow-same-origin allow-forms",
            allow: I,
            className: "h-full w-full max-w-full"
        }, C)
    }), t[17] = b, t[18] = C, t[19] = h, t[20] = w, t[21] = I, t[22] = i, t[23] = Q) : Q = t[23], Q
}

function Fn() {
    return T(null)
}
const qn = async (e, t) => {
        const {
            trackFatalWidgetError: n
        } = await K(async () => {
            const {
                trackFatalWidgetError: o
            } = await
            import ("./jq369xe6tq4tfy56.js");
            return {
                trackFatalWidgetError: o
            }
        }, __vite__mapDeps([31, 2, 1, 3]));
        n(e, t)
    },
    Vn = async (e, t) => {
        const {
            trackWidgetError: n
        } = await K(async () => {
            const {
                trackWidgetError: o
            } = await
            import ("./jq369xe6tq4tfy56.js");
            return {
                trackWidgetError: o
            }
        }, __vite__mapDeps([31, 2, 1, 3]));
        n(e, t)
    },
    Bn = async e => {
        const {
            trackWidgetLinkOut: t
        } = await K(async () => {
            const {
                trackWidgetLinkOut: n
            } = await
            import ("./jq369xe6tq4tfy56.js");
            return {
                trackWidgetLinkOut: n
            }
        }, __vite__mapDeps([31, 2, 1, 3]));
        t(e)
    },
    jn = async (e, t) => {
        const {
            trackSandboxInstrument: n
        } = await K(async () => {
            const {
                trackSandboxInstrument: o
            } = await
            import ("./jq369xe6tq4tfy56.js");
            return {
                trackSandboxInstrument: o
            }
        }, __vite__mapDeps([31, 2, 1, 3]));
        n(e, t)
    },
    Kn = async e => {
        const {
            trackSecurityPolicyViolation: t
        } = await K(async () => {
            const {
                trackSecurityPolicyViolation: n
            } = await
            import ("./jq369xe6tq4tfy56.js");
            return {
                trackSecurityPolicyViolation: n
            }
        }, __vite__mapDeps([31, 2, 1, 3]));
        t(e)
    },
    zn = async (e, t) => {
        const {
            trackWidgetDisplayMode: n
        } = await K(async () => {
            const {
                trackWidgetDisplayMode: o
            } = await
            import ("./jq369xe6tq4tfy56.js");
            return {
                trackWidgetDisplayMode: o
            }
        }, __vite__mapDeps([31, 2, 1, 3]));
        n(e, t)
    },
    Gn = async (e, t) => {
        const {
            trackWidgetNavigation: n
        } = await K(async () => {
            const {
                trackWidgetNavigation: o
            } = await
            import ("./jq369xe6tq4tfy56.js");
            return {
                trackWidgetNavigation: o
            }
        }, __vite__mapDeps([31, 2, 1, 3]));
        n(e, t)
    },
    Yn = async e => {
        const {
            trackWidgetCheckoutSession: t
        } = await K(async () => {
            const {
                trackWidgetCheckoutSession: n
            } = await
            import ("./jq369xe6tq4tfy56.js");
            return {
                trackWidgetCheckoutSession: n
            }
        }, __vite__mapDeps([31, 2, 1, 3]));
        t(e)
    },
    Hn = {
        insets: {
            top: 0,
            bottom: 0,
            left: 0,
            right: 0
        }
    };

function Xn() {
    let e, t;
    return {
        promise: new Promise((o, s) => {
            e = o, t = s
        }),
        resolve: e,
        reject: t
    }
}
const Qn = ({
        host: e,
        ref: t,
        iframeRef: n,
        html: o,
        measureWidth: s,
        accessToken: i,
        features: l,
        safeArea: a = Hn,
        attributionId: u,
        conversationId: m,
        widgetId: p,
        widgetParent: g,
        widgetDistributionChannel: b,
        suggestionMessageId: c,
        widgetType: O,
        csp: $,
        subdomain: k,
        viewParams: x,
        widgetState: D = null,
        toolInput: R = null,
        toolOutput: v = null,
        toolResponseMetadata: E = null,
        subjectId: G = null,
        maxHeight: U,
        maxWidth: M,
        theme: C,
        title: W,
        api: h,
        locale: w,
        displayMode: I = "inline",
        onReady: Q,
        onError: z
    }) => {
        "use no forget";
        const A = N.useMemo(() => {
                var r;
                return {
                    attribution_id: (r = u != null ? u : g) != null ? r : "",
                    name: O,
                    conversation_id: m != null ? m : null,
                    message_id: p || null,
                    suggestion_message_id: c != null ? c : null,
                    distribution_channel: b,
                    host: e
                }
            }, [e, b, u, g, O, m, p, c]),
            L = N.useRef(null),
            Z = N.useRef(null),
            tt = N.useRef(null),
            _t = mt(() => {
                z == null || z()
            }),
            ft = mt(() => {
                Q == null || Q()
            }),
            it = mt(async r => {
                var P, Y;
                Z.current = Xn();
                const _ = (P = L.current) == null ? void 0 : P.runWidgetCode({
                    html: r,
                    measureWidth: s,
                    isFirstParty: b === At.OPENAI,
                    widgetId: p,
                    viewParams: x,
                    widgetState: D,
                    toolInput: R,
                    toolOutput: v,
                    toolResponseMetadata: E,
                    subjectId: G,
                    features: l,
                    maxHeight: U != null ? U : void 0,
                    maxWidth: M != null ? M : void 0,
                    theme: C,
                    displayMode: I,
                    safeArea: a,
                    userAgent: ye(e),
                    csp: $
                });
                if (_) try {
                    for (var rt = qt(await _), at, ct, gt; at = !(ct = await rt.next()).done; at = !1) {
                        const J = ct.value;
                        J.type === Ot.ENVIRONMENT_STATUS && J.status === He.RUNNING_CODE ? (ft(), (Y = Z.current) == null || Y.resolve()) : J.type === Ot.ERROR ? (Vn(A, J.error), tt.current = J.error) : J.type === Ot.RUN_COMPLETE && J.wasFatalError && (qn(A, tt.current), _t())
                    }
                } catch (ct) {
                    gt = [ct]
                } finally {
                    try {
                        at && (ct = rt.return) && await ct.call(rt)
                    } finally {
                        if (gt) throw gt[0]
                    }
                }
            }),
            lt = N.useRef(null);
        N.useEffect(() => {
            !o || lt.current === o || (lt.current = o, it(o))
        }, [o, it]);
        const F = mt(async r => {
            var _;
            await ((_ = Z.current) == null ? void 0 : _.promise), r()
        });
        return N.useEffect(() => {
            F(() => {
                var r;
                (r = L.current) == null || r.setWidgetProps({
                    widgetId: p,
                    widgetState: D,
                    toolInput: R,
                    toolOutput: v,
                    toolResponseMetadata: E,
                    subjectId: G
                })
            })
        }, [p, D, R, v, E, G, F]), N.useEffect(() => {
            F(() => {
                var r;
                (r = L.current) == null || r.setAdditionalGlobals({
                    additionalGlobals: {
                        maxHeight: U,
                        maxWidth: M
                    }
                })
            })
        }, [U, M, F]), N.useEffect(() => {
            F(() => {
                var r;
                (r = L.current) == null || r.setAdditionalGlobals({
                    additionalGlobals: {
                        displayMode: I,
                        view: {
                            params: x,
                            mode: I
                        }
                    }
                })
            })
        }, [I, x, F]), N.useEffect(() => {
            F(() => {
                var r;
                (r = L.current) == null || r.setTheme({
                    theme: C
                })
            })
        }, [C, F]), N.useEffect(() => {
            F(() => {
                var r;
                (r = L.current) == null || r.setSafeArea({
                    safeArea: a
                })
            })
        }, [a, F]), yt.jsx(In, {
            title: W,
            host: e,
            subdomain: k,
            features: l,
            api: pt(S({}, h), {
                downloadBlob: b === At.OPENAI ? ({
                    blob: r,
                    name: _
                }) => {
                    Ye(r, _)
                } : void 0,
                notifyNavigation: r => {
                    var _;
                    Gn(A, r), (_ = h.notifyNavigation) == null || _.call(h, r)
                },
                requestCheckout: h.requestCheckout ? r => {
                    var _;
                    return Yn(A), (_ = h.requestCheckout) == null ? void 0 : _.call(h, r)
                } : void 0,
                requestDisplayMode: r => {
                    var P, Y;
                    const {
                        mode: _
                    } = r;
                    return _ !== I && zn(A, _), (Y = (P = h.requestDisplayMode) == null ? void 0 : P.call(h, r)) != null ? Y : {
                        mode: _
                    }
                },
                share: async r => {
                    const {
                        url: _,
                        title: P,
                        text: Y,
                        files: rt
                    } = r;
                    return await navigator.share({
                        url: _,
                        title: P,
                        text: Y,
                        files: rt
                    })
                },
                openExternal: r => {
                    var _;
                    Bn(A), (_ = h.openExternal) == null || _.call(h, r)
                },
                sendInstrument: r => {
                    jn(r, A)
                },
                notifySecurityPolicyViolation: r => {
                    Kn(pt(S({}, A), {
                        violation: r
                    }))
                },
                streamCompletion: function(r) {
                    return It(this, null, function*() {
                        const {
                            completionStream: _
                        } = yield new Ct(K(async () => {
                            const {
                                completionStream: P
                            } = await
                            import ("./gvldjhupitopee77.js");
                            return {
                                completionStream: P
                            }
                        }, __vite__mapDeps([32, 2, 1, 3, 5, 6])));
                        yield* Ft(_(r, X(g), i))
                    })
                },
                callCompletion: async function(r) {
                    const {
                        callCompletion: _
                    } = await K(async () => {
                        const {
                            callCompletion: P
                        } = await
                        import ("./gvldjhupitopee77.js");
                        return {
                            callCompletion: P
                        }
                    }, __vite__mapDeps([32, 2, 1, 3, 5, 6]));
                    return await _(r, X(g), i)
                }
            }),
            iframeRef: n,
            ref: ze(L, t),
            locale: w
        })
    },
    go = e => {
        "use forget";
        var J, Ut;
        const t = Yt.c(65),
            {
                heightHint: n,
                safeArea: o,
                widgetRef: s,
                conversation: i,
                chatSDK: l,
                clientThreadId: a,
                resolvedWidget: u,
                onReady: m,
                onClose: p,
                onCanGoBack: g,
                domain: b,
                html: c,
                attributionId: O,
                widgetId: $,
                widgetParent: k,
                suggestionMessageId: x,
                widgetType: D,
                features: R,
                subdomain: v,
                csp: E,
                locale: G,
                params: U,
                displayMode: M
            } = e,
            C = n === void 0 ? null : n,
            W = qe();
        let h;
        t[0] !== i ? (h = Ge(i), t[0] = i, t[1] = h) : h = t[1];
        const w = h,
            [I, Q] = N.useState(C),
            z = N.useRef(null),
            A = te(s, z),
            L = We();
        let Z;
        t[2] !== l || t[3] !== w ? (Z = () => w.getWidgetStateAndProps$(l), t[2] = l, t[3] = w, t[4] = Z) : Z = t[4];
        const {
            toolInput: tt,
            toolOutput: _t,
            widgetState: ft,
            toolResponseMetadata: it
        } = Ie(Z), lt = (Ut = (J = l.metadata) == null ? void 0 : J.subject_id) != null ? Ut : null;
        let F;
        t[5] !== a ? (F = Fe(a), t[5] = a, t[6] = F) : F = t[6];
        const r = F,
            _ = Math.max(I != null ? I : 0, C != null ? C : 0);
        let P;
        t[7] !== _ ? (P = {
            height: _
        }, t[7] = _, t[8] = P) : P = t[8];
        const Y = L != null ? L : "light";
        let rt;
        t[9] === Symbol.for("react.memo_cache_sentinel") ? (rt = ut => {
            Q(ut)
        }, t[9] = rt) : rt = t[9];
        let at;
        if (t[10] !== l || t[11] !== a || t[12] !== E || t[13] !== W || t[14] !== b || t[15] !== w || t[16] !== g || t[17] !== p || t[18] !== u || t[19] !== r || t[20] !== k) {
            let ut;
            t[22] !== l || t[23] !== a || t[24] !== W || t[25] !== u ? (ut = q => wn({
                ctx: W,
                chatSDK: l,
                clientThreadId: a,
                checkoutSession: q,
                resolvedWidget: u
            }), t[22] = l, t[23] = a, t[24] = W, t[25] = u, t[26] = ut) : ut = t[26];
            let $t;
            t[27] !== g ? ($t = q => {
                const {
                    canGoBack: ot
                } = q;
                g(ot)
            }, t[27] = g, t[28] = $t) : $t = t[28];
            let Et, bt, kt, vt;
            t[29] !== w || t[30] !== k ? (Et = (q, ot) => w.callTool$(X(k), q, ot), bt = q => w.uploadFile$(X(k), q), kt = q => w.getFileDownloadUrl$(X(k), q.fileId), vt = q => w.getFileMetadata$(X(k), q.fileId), t[29] = w, t[30] = k, t[31] = Et, t[32] = bt, t[33] = kt, t[34] = vt) : (Et = t[31], bt = t[32], kt = t[33], vt = t[34]);
            let St;
            t[35] !== w ? (St = (q, ot) => w.setWidgetState$(q, ot), t[35] = w, t[36] = St) : St = t[36], at = {
                notifyIntrinsicHeight: rt,
                openExternal(q) {
                    var Mt;
                    const {
                        href: ot
                    } = q;
                    Ln({
                        ctx: W,
                        href: ot,
                        csp: E,
                        redirectDomains: u.redirectDomains,
                        resolvedPineappleUri: (Mt = l.metadata.resolved_pineapple_uri) != null ? Mt : null,
                        domain: b,
                        distributionChannel: l.distributionChannel,
                        redirectUrl: r ? new URL(Ve(r), window.location.origin).toString() : new URL(window.location.href).toString()
                    })
                },
                requestClose: p,
                notifyEscapeKey: p,
                requestCheckout: ut,
                notifyNavigation: $t,
                callTool: Et,
                uploadFile: bt,
                getFileDownloadUrl: kt,
                getFileMetadata: vt,
                updateWidgetState: St
            }, t[10] = l, t[11] = a, t[12] = E, t[13] = W, t[14] = b, t[15] = w, t[16] = g, t[17] = p, t[18] = u, t[19] = r, t[20] = k, t[21] = at
        } else at = t[21];
        let ct;
        t[37] !== O || t[38] !== l.distributionChannel || t[39] !== E || t[40] !== M || t[41] !== R || t[42] !== A || t[43] !== c || t[44] !== G || t[45] !== m || t[46] !== U || t[47] !== o || t[48] !== r || t[49] !== v || t[50] !== lt || t[51] !== x || t[52] !== Y || t[53] !== at || t[54] !== tt || t[55] !== _t || t[56] !== it || t[57] !== $ || t[58] !== k || t[59] !== ft || t[60] !== D ? (ct = yt.jsx(Qn, {
            host: "chatgpt",
            html: c,
            ref: A,
            theme: Y,
            attributionId: O,
            measureWidth: !1,
            onReady: m,
            conversationId: r,
            widgetId: $,
            widgetParent: k,
            widgetDistributionChannel: l.distributionChannel,
            suggestionMessageId: x,
            widgetType: D,
            subdomain: v,
            widgetState: ft,
            toolInput: tt,
            toolOutput: _t,
            toolResponseMetadata: it,
            subjectId: lt,
            features: R,
            viewParams: U,
            safeArea: o,
            displayMode: M,
            api: at,
            csp: E,
            locale: G
        }), t[37] = O, t[38] = l.distributionChannel, t[39] = E, t[40] = M, t[41] = R, t[42] = A, t[43] = c, t[44] = G, t[45] = m, t[46] = U, t[47] = o, t[48] = r, t[49] = v, t[50] = lt, t[51] = x, t[52] = Y, t[53] = at, t[54] = tt, t[55] = _t, t[56] = it, t[57] = $, t[58] = k, t[59] = ft, t[60] = D, t[61] = ct) : ct = t[61];
        let gt;
        return t[62] !== ct || t[63] !== P ? (gt = yt.jsx("div", {
            className: "max-h-full flex-shrink overflow-y-auto",
            style: P,
            children: ct
        }), t[62] = ct, t[63] = P, t[64] = gt) : gt = t[64], gt
    },
    Zn = Jt(() => T(null));
Jt(e => wt(() => Zn(e) != null));
const Jn = ["midi", "microphone", "local-network-access"],
    $o = (e, t) => {
        const n = [];
        return e && n.push(...Jn), t.distributionChannel === At.OPENAI && n.push("clipboard-read", "clipboard-write", "microphone", "camera", "web-share"), Array.from(new Set(n))
    };
export {
    go as E, fn as a, fo as b, ee as c, ae as d, Zn as e, ao as f, $o as g, _o as h, mo as i, uo as j, co as k, po as l, yo as m, Qn as n, wn as o, Ln as p, ho as t
};
//# sourceMappingURL=jzcvgi3ud281qm7h.js.map