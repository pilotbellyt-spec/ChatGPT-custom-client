import {
    c as e,
    s as t
} from "./dykg4ktvbu3mhmdo.js";
const s = e(t, "7ef0de", 16, 16),
    c = e(t, "d8dcbc", 16, 16);
export {
    s as B, c as I
};
//# sourceMappingURL=owg1rbxotm5jsyn7.js.map