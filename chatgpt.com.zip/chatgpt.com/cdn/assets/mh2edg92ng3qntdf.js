import {
    c as e,
    s as o
} from "./dykg4ktvbu3mhmdo.js";
const r = e(o, "e13340", 20, 20);
export {
    r as S
};
//# sourceMappingURL=mh2edg92ng3qntdf.js.map