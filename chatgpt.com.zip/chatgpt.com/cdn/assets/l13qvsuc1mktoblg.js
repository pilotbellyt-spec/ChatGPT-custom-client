var Ne = Object.defineProperty;
var ne = Object.getOwnPropertySymbols;
var Me = Object.prototype.hasOwnProperty,
    Te = Object.prototype.propertyIsEnumerable;
var oe = (c, e, o) => e in c ? Ne(c, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: o
    }) : c[e] = o,
    B = (c, e) => {
        for (var o in e || (e = {})) Me.call(e, o) && oe(c, o, e[o]);
        if (ne)
            for (var o of ne(e)) Te.call(e, o) && oe(c, o, e[o]);
        return c
    };
import {
    c as H,
    j as t,
    f as _e,
    M as W,
    e as de,
    r as V
} from "./fg33krlcm0qyi6yw.js";
import {
    P as ie,
    F as we,
    G as ye,
    J as Ee,
    K as Le,
    M as Be,
    N as Fe,
    O as Oe,
    Q as Ie,
    S as Ue,
    U as ze,
    X as Ge,
    Y as re,
    Z as ue,
    _ as X,
    $ as $e,
    a0 as He,
    a1 as le,
    a2 as Re,
    a3 as De,
    a4 as Ke,
    a5 as We,
    a6 as Ve,
    a7 as Xe,
    a8 as Je,
    a9 as Ye,
    aa as Ze
} from "./k15yxxoybkkir2ou.js";
import {
    dg as qe,
    c_ as G,
    b as R,
    d8 as Qe,
    r2 as ge,
    dB as es,
    hh as ss,
    ag as ts,
    fN as ce,
    d as F,
    dC as as,
    oO as ns,
    eX as os,
    i as is,
    nm as rs,
    hX as ls,
    aJ as cs,
    fG as ds,
    o9 as us,
    o as gs,
    ed as hs,
    ib as fs,
    V as ms,
    eo as ps,
    p7 as Ss,
    r3 as xs,
    a9 as $,
    aK as vs,
    T as he,
    l as Cs,
    dF as J,
    hZ as js,
    B as Y,
    P as Z
} from "./dykg4ktvbu3mhmdo.js";
import {
    P as bs
} from "./jlu292yvnhcpthaw.js";
import {
    S as Ps
} from "./f78b2oufkmgyeo1t.js";
import {
    P as ks
} from "./ib78f9d5brp6znzf.js";

function Is({
    showShareButton: c,
    showProfileDropdown: e,
    showConversationPrivacyIndicator: o,
    clientThreadId: n
}) {
    const r = R(),
        u = es(r, n),
        s = ss(n),
        i = de(),
        l = ts(),
        [C, g, m, p, f, j, h, d, S] = ce(n, a => {
            const z = J.getGizmoId(a);
            return [J.hasUserMessage(a), z, Xe(a == null ? void 0 : a.mode, z), a == null ? void 0 : a.title, a == null ? void 0 : a.is_do_not_remember, a == null ? void 0 : a.isStarred, a == null ? void 0 : a.continuingFromSharedProjectConversationId, a == null ? void 0 : a.sharedProjectConversationOwner, Je(a)]
        }),
        x = F(() => {
            var a;
            return (a = as(u)) == null ? void 0 : a.value
        }),
        N = V.useMemo(() => Le({
            clientThreadId: d != null && d.id && h ? h : s != null ? s : n,
            gizmoId: g,
            conversationTitle: p,
            conversationAsyncStatus: x,
            isDoNotRemember: f,
            isStarred: j,
            owner: d != null && d.id ? {
                user_id: d.id
            } : null
        }), [d == null ? void 0 : d.id, h, s, n, g, p, x, f, j]),
        M = F(ns),
        O = ge(),
        A = os(n),
        y = V.use(ks) != null,
        v = is(r),
        T = rs(),
        U = !v && M,
        P = i.formatMessage({
            id: "GizmoInformation.shareChat",
            defaultMessage: "Share"
        }),
        E = ls(r, g),
        _ = cs(),
        b = !G(),
        {
            shouldShowProjectsChatShareModal: k,
            openProjectsChatShareModal: fe
        } = Be({
            clientThreadId: n
        }),
        Q = () => k ? fe() : vs.openSharingModal(s),
        me = Fe(r),
        D = F(() => ds(r)),
        pe = us(s),
        Se = ce(n, a => {
            var ae;
            const z = J.getConversationTurns(a);
            return js(z, {
                title: (ae = a == null ? void 0 : a.title) != null ? ae : null,
                threadUpdateTimeMs: (a == null ? void 0 : a.update_time) != null ? a.update_time * 1e3 : void 0
            }).filter(Ae => !Ae.isTurnEnded).length
        }) > 0,
        xe = gs(r, "3018147683"),
        ve = hs(g),
        Ce = Oe(r),
        L = ve ? fs(r, g) : null,
        je = F(() => {
            var a;
            return (a = L == null ? void 0 : L.isShared$()) != null ? a : !1
        });
    F(() => L == null ? void 0 : L.serverState$().data);
    const ee = je && Ce && s != null && !0,
        be = g == null && h == null,
        Pe = V.useMemo(() => !b && c && !D ? ms(r, "2874358162").get("open_personalization_button_enabled", !1) : !1, [r, b, c, D]),
        K = me.hasAccess && !b && c && !D && !T && !y && !v && (be || ee) && !S;
    let w = null;
    K ? s != null ? w = ee ? "from-shared-project" : "from-conversation" : A && !C && (w = "new-chat") : w = null;
    const [ke, se, te] = F(() => [ps(r), Ss(), xs(u)]);
    return t.jsxs(t.Fragment, {
        children: [!A && O && !v && t.jsx(q, {
            location: "Atlas header"
        }), te && l && se && t.jsx(Ie, {
            conversationMode: m
        }), G() ? t.jsx(Ue, {}) : null, G() && (_ == null ? void 0 : _.includes("caterpillar")) && t.jsx(ze, {}), g && E && t.jsx(Ge, {
            gizmoId: g,
            serverThreadId: s != null ? s : h
        }), c && (s != null ? s : h) && t.jsx(t.Fragment, {
            children: U ? t.jsx($, {
                onClick: Q,
                icon: re,
                label: P,
                "data-testid": "share-chat-button",
                color: "ghost",
                className: "text-token-text-primary hover:bg-token-surface-hover keyboard-focused:bg-token-surface-hover rounded-lg max-sm:hidden",
                style: {
                    viewTransitionName: "var(--vt_share_chat_wide_button)"
                },
                children: P
            }) : t.jsx(he, {
                label: i.formatMessage({
                    id: "CPEfES",
                    defaultMessage: "Share chat"
                }),
                children: t.jsx(ue, {
                    "data-testid": "share-chat-button",
                    className: "max-sm:hidden",
                    onClick: Q,
                    icon: re,
                    style: {
                        viewTransitionName: "var(--vt_share_chat_compact_button)"
                    }
                })
            })
        }), K && s != null ? w === "from-conversation" ? t.jsx(X, {
            type: "from-conversation",
            serverThreadId: s
        }) : w === "from-shared-project" && g != null ? t.jsx(X, {
            type: "from-shared-project",
            serverThreadId: s,
            projectId: g
        }) : null : null, t.jsxs("div", {
            className: "flex items-center",
            children: [K && w === "new-chat" ? t.jsx(X, {
                type: w,
                variant: "default"
            }) : null, !b && !g && A && !y && !C && !v && !T && t.jsx(t.Fragment, {
                children: t.jsx($e, {
                    clientThreadId: n
                })
            }), o && t.jsx("div", {
                className: "me-2",
                children: t.jsx(He, {
                    clientThreadId: n,
                    gizmoId: g
                })
            }), Pe ? s ? t.jsx(le, {
                variant: M ? "default" : "icon"
            }) : C ? null : t.jsx(le, {
                variant: "icon"
            }) : null, t.jsx(Re, {}), (s != null || h != null) && !b && t.jsx(De, {
                conversation: N,
                inMainScreen: !0,
                isActiveConversation: !0,
                inChatWindow: !0,
                shouldShowAdultSearchToggle: te && !se,
                children: t.jsxs("div", {
                    className: "relative overflow-hidden",
                    children: [t.jsx(Ke, {
                        "aria-label": i.formatMessage({
                            id: "9Mk/E3",
                            defaultMessage: "Open conversation options"
                        }),
                        "data-testid": "conversation-options-button"
                    }), (pe.length > 0 && xe || Se) && t.jsx("div", {
                        className: "pointer-events-none absolute inset-0 grid place-items-center",
                        children: t.jsx(We, {
                            size: 28,
                            backgroundStrokeClassName: "stroke-black/10 dark:stroke-white/10"
                        })
                    })]
                })
            }), ke && (s != null || h != null) && t.jsx(q, {
                location: "Atlas header"
            }), e && t.jsx(As, {
                clientThreadId: n
            })]
        })]
    })
}
const As = c => {
    "use forget";
    const e = H.c(9),
        {
            clientThreadId: o
        } = c,
        n = R(),
        r = qe();
    ie.markStart("LoginOrProfileMenu"), ie.markRendered("LoginOrProfileMenu");
    let u;
    e[0] !== n || e[1] !== r ? (u = !r && !G() && t.jsx(Ns, {}), e[0] = n, e[1] = r, e[2] = u) : u = e[2];
    let s;
    e[3] !== o || e[4] !== r ? (s = !r && t.jsx(bs, {
        clientThreadId: o
    }), e[3] = o, e[4] = r, e[5] = s) : s = e[5];
    let i;
    return e[6] !== u || e[7] !== s ? (i = t.jsxs(t.Fragment, {
        children: [u, s]
    }), e[6] = u, e[7] = s, e[8] = i) : i = e[8], i
};

function q(c) {
    "use forget";
    const e = H.c(19),
        {
            location: o,
            className: n,
            testId: r,
            to: u,
            state: s
        } = c,
        i = R(),
        l = de(),
        C = Ve();
    let g;
    e[0] !== l ? (g = l.formatMessage({
        id: "OFyxqj",
        defaultMessage: "New chat"
    }), e[0] = l, e[1] = g) : g = e[1];
    const m = g;
    let p;
    e[2] !== n ? (p = Cs("flex", n), e[2] = n, e[3] = p) : p = e[3];
    let f;
    e[4] !== i || e[5] !== o ? (f = N => {
        Ye(i, N, {
            location: o
        })
    }, e[4] = i, e[5] = o, e[6] = f) : f = e[6];
    const j = u != null ? u : "/",
        h = s != null ? s : C;
    let d;
    e[7] !== j || e[8] !== h ? (d = {
        to: j,
        state: h
    }, e[7] = j, e[8] = h, e[9] = d) : d = e[9];
    let S;
    e[10] !== m || e[11] !== f || e[12] !== d || e[13] !== r ? (S = t.jsx(ue, {
        onClick: f,
        icon: Ze,
        "aria-label": m,
        "data-testid": r,
        as: "link",
        linkProps: d
    }), e[10] = m, e[11] = f, e[12] = d, e[13] = r, e[14] = S) : S = e[14];
    let x;
    return e[15] !== m || e[16] !== p || e[17] !== S ? (x = t.jsx(he, {
        label: m,
        className: p,
        children: S
    }), e[15] = m, e[16] = p, e[17] = S, e[18] = x) : x = e[18], x
}

function Us(c) {
    "use forget";
    const e = H.c(5),
        {
            hideNewChat: o
        } = c,
        n = o === void 0 ? !1 : o;
    if (!ge()) return null;
    let u;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (u = t.jsx(Ps, {}), e[0] = u) : u = e[0];
    let s;
    e[1] !== n ? (s = !n && t.jsx(q, {
        location: "Navigation actions"
    }), e[1] = n, e[2] = s) : s = e[2];
    let i;
    return e[3] !== s ? (i = t.jsxs("div", {
        className: "flex items-center",
        children: [u, s]
    }), e[3] = s, e[4] = i) : i = e[4], i
}

function Ns(c) {
    "use forget";
    const e = H.c(41);
    let o;
    e[0] !== c ? (o = c === void 0 ? {} : c, e[0] = c, e[1] = o) : o = e[1];
    const {
        callbackUrl: n,
        skipLoginModal: r,
        location: u
    } = o, s = r === void 0 ? !1 : r, i = u === void 0 ? "Chat header" : u, l = R();
    let C;
    e[2] !== l ? (C = we(l), e[2] = l, e[3] = C) : C = e[3];
    const g = C;
    let m;
    e[4] !== l ? (m = ye(l, Ms.signUpCta), e[4] = l, e[5] = m) : m = e[5];
    const p = m;
    let f;
    e[6] !== l ? (f = Ee(l), e[6] = l, e[7] = f) : f = e[7];
    const j = f,
        h = Qe.ACCESS_FLOW_ENTRY_POINT_CHAT_HEADER;
    let d;
    e[8] !== n || e[9] !== l || e[10] !== i || e[11] !== s ? (d = () => {
        Y(l, B({
            fallbackScreenHint: "login",
            callback: k => {
                Z.logLogInButtonClicked({
                    location: i,
                    provider: k
                }, h)
            },
            skipLoginModal: s != null ? s : !1
        }, n ? {
            callbackUrl: n
        } : {}))
    }, e[8] = n, e[9] = l, e[10] = i, e[11] = s, e[12] = d) : d = e[12];
    const S = d;
    let x;
    e[13] !== n || e[14] !== l || e[15] !== i || e[16] !== s ? (x = () => {
        Y(l, B({
            fallbackScreenHint: "signup",
            callback: k => {
                Z.logSignUpButtonClicked({
                    location: i,
                    provider: k
                }, h)
            },
            skipLoginModal: s != null ? s : !1
        }, n ? {
            callbackUrl: n
        } : {}))
    }, e[13] = n, e[14] = l, e[15] = i, e[16] = s, e[17] = x) : x = e[17];
    const N = x;
    let M;
    e[18] !== n || e[19] !== l || e[20] !== i || e[21] !== s ? (M = () => {
        Y(l, B({
            fallbackScreenHint: "login_or_signup",
            callback: k => {
                Z.logLoginOrSignUpButtonClicked({
                    location: i,
                    provider: k
                }, h)
            },
            skipLoginModal: s != null ? s : !1
        }, n ? {
            callbackUrl: n
        } : {}))
    }, e[18] = n, e[19] = l, e[20] = i, e[21] = s, e[22] = M) : M = e[22];
    const O = M;
    let A;
    e[23] === Symbol.for("react.memo_cache_sentinel") ? (A = t.jsx(W, {
        id: "B1SN7b",
        defaultMessage: "Log in"
    }), e[23] = A) : A = e[23];
    let I;
    e[24] !== S ? (I = t.jsx($, {
        onClick: S,
        color: "primary",
        "data-testid": "login-button",
        children: A
    }, "login"), e[24] = S, e[25] = I) : I = e[25];
    const y = I;
    let v;
    e[26] !== p ? (v = t.jsx(W, B({}, p)), e[26] = p, e[27] = v) : v = e[27];
    let T;
    e[28] !== N || e[29] !== v ? (T = t.jsx($, {
        color: "secondary",
        onClick: N,
        "data-testid": "signup-button",
        className: "screen-arch:hidden md:screen-arch:flex max-xs:hidden",
        children: v
    }, "signup"), e[28] = N, e[29] = v, e[30] = T) : T = e[30];
    const U = T;
    let P;
    e[31] !== j ? (P = t.jsx(W, B({}, j)), e[31] = j, e[32] = P) : P = e[32];
    let E;
    e[33] !== O || e[34] !== P ? (E = t.jsx($, {
        color: "primary",
        onClick: O,
        "data-testid": "login-or-signup-button",
        className: "screen-arch:hidden md:screen-arch:flex",
        children: P
    }, "signup"), e[33] = O, e[34] = P, e[35] = E) : E = e[35];
    const _ = E;
    let b;
    if (e[36] !== y || e[37] !== _ || e[38] !== U || e[39] !== g) {
        const k = g ? [_] : [y, U];
        b = t.jsx("div", {
            className: "flex items-center justify-center gap-2",
            children: k
        }), e[36] = y, e[37] = _, e[38] = U, e[39] = g, e[40] = b
    } else b = e[40];
    return b
}
const Ms = _e({
    signUpCta: {
        id: "P6cySK",
        defaultMessage: "Sign up"
    }
});
export {
    Is as C, As as L, Us as N, Ns as a
};
//# sourceMappingURL=l13qvsuc1mktoblg.js.map