import {
    c as t,
    s as e
} from "./dykg4ktvbu3mhmdo.js";
const a = t(e, "b624fa", 20, 20);
export {
    a as L
};
//# sourceMappingURL=jnh7gh80gtj0452q.js.map