import {
    w as f,
    ag as k,
    p1 as M,
    t as i,
    n as T
} from "./dykg4ktvbu3mhmdo.js";
import {
    V as A
} from "./k15yxxoybkkir2ou.js";
import {
    p as R
} from "./lans8a2ikbh9ax9r.js";
import {
    f as E,
    e as c,
    r as D
} from "./fg33krlcm0qyi6yw.js";

function F() {
    const e = c(),
        a = e.formatMessage(t.adminRoleName),
        s = e.formatMessage(t.ownerRoleName),
        n = e.formatMessage(t.standardRoleName);
    return D.useMemo(() => ({
        [i.OWNER]: s,
        [i.ADMIN]: a,
        [i.STANDARD]: n
    }), [s, a, n])
}

function L(e) {
    const a = c();
    return e != null && e.isWorkspaceAccount() ? e.isFreeWorkspace() ? a.formatMessage(t.freeWorkspacePlanName) : e.isSelfServeBusiness() ? a.formatMessage(t.businessPlanName) : e.isK12() ? a.formatMessage(t.k12PlanName) : e.isEdu() ? a.formatMessage(t.eduPlanName) : a.formatMessage(t.enterprisePlanName) : a.formatMessage(t.personalPlanName)
}

function S(e) {
    const a = c();
    return d(a, e)
}

function y() {
    const {
        data: e
    } = f(), a = M(e), s = c();
    return d(s, a)
}

function B() {
    const {
        data: e,
        isLoading: a
    } = f(), s = M(e), n = c();
    return {
        workspaceName: d(n, s),
        isLoading: a
    }
}

function d(e, a) {
    var s;
    return a == null || a.isPersonalAccount() ? e.formatMessage(t.personalWorkspaceTitle) : (s = a.data.name) != null ? s : e.formatMessage(t.defaultWorkspaceTitle)
}

function h(e, a, s) {
    var o;
    const n = (o = a == null ? void 0 : a.data.name) == null ? void 0 : o.trim();
    if (n) return n;
    const r = I(e, s != null ? s : null);
    if (r) return r;
    if (a == null || a.isPersonalAccount()) {
        const l = p(e, s);
        return l || e.formatMessage(t.personalWorkspaceTitle)
    }
    return e.formatMessage(t.defaultWorkspaceTitle)
}

function _(e, a) {
    const s = p(e, a);
    return s || h(e, null, a)
}

function I(e, a) {
    var r, o;
    const s = (o = (r = a == null ? void 0 : a.email) == null ? void 0 : r.trim()) != null ? o : null;
    if (!s || !A.test(s)) return null;
    if ((a == null ? void 0 : a.email_domain_type) === "social") return p(e, a);
    const n = U(s);
    return n || null
}

function p(e, a) {
    var n;
    const s = (n = a == null ? void 0 : a.name) == null ? void 0 : n.trim();
    return s ? e.formatMessage(t.personalDefaultWorkspaceTitle, {
        name: s
    }) : null
}

function U(e) {
    var l, N;
    const a = (l = e.split("@")[1]) == null ? void 0 : l.toLowerCase();
    if (!a) return null;
    const s = R.parse(a);
    if (!("error" in s) || s.error == null) {
        const {
            sld: u,
            domain: m
        } = s, W = (N = u != null ? u : m == null ? void 0 : m.split(".").filter(Boolean)[0]) != null ? N : null;
        if (W) return g(W)
    }
    const n = a.split(".").filter(Boolean);
    if (n.length === 0) return null;
    const r = n.length === 1 ? 0 : n.length - 2,
        o = n[r];
    return o ? g(o) : null
}

function g(e) {
    const a = e.replace(/[^a-zA-Z0-9]+/g, " ").trim();
    return a ? a.split(/\s+/).map(s => b(s.toLowerCase())).join(" ") : null
}

function b(e) {
    return e.charAt(0).toUpperCase() + e.slice(1)
}

function G(e, a, s) {
    var n;
    return a == null || a.isPersonalAccount() ? (n = s == null ? void 0 : s.name) != null ? n : e.formatMessage(t.personalWorkspaceTitle) : a.data.name ? a.data.name : e.formatMessage(t.defaultWorkspaceTitle)
}

function V() {
    var a;
    const e = k();
    return (a = e == null ? void 0 : e.email) != null ? a : null
}

function j() {
    var a, s;
    const e = k();
    return (s = (a = e == null ? void 0 : e.name) != null ? a : e == null ? void 0 : e.email) != null ? s : null
}

function P() {
    return T(({
        workspaces: e
    }) => e)
}

function v() {
    var n;
    const {
        data: e,
        isFetching: a
    } = f();
    return {
        data: (n = e == null ? void 0 : e.accountItems.filter(r => !r.isDeactivated())) != null ? n : [],
        isFetching: a
    }
}

function H(e) {
    const s = P().find(n => n.id === e);
    return (s == null ? void 0 : s.role) === i.OWNER
}

function K(e) {
    const s = P().find(n => n.id === e);
    return (s == null ? void 0 : s.role) === i.ADMIN
}
const t = E({
    defaultWorkspaceTitle: {
        id: "useWorkspaces.defaultWorkspaceTitle",
        defaultMessage: "Untitled Workspace"
    },
    personalWorkspaceTitle: {
        id: "useWorkspaces.personalWorkspaceTitle",
        defaultMessage: "Personal account"
    },
    personalDefaultWorkspaceTitle: {
        id: "useWorkspaces.personaldefaultWorkspaceTitle",
        defaultMessage: "{name}'s Workspace"
    },
    personalPlanName: {
        id: "useWorkspaces.personalPlanName",
        defaultMessage: "Personal"
    },
    enterprisePlanName: {
        id: "useWorkspaces.enterprisePlanName",
        defaultMessage: "Enterprise"
    },
    k12PlanName: {
        id: "useWorkspaces.k12PlanName",
        defaultMessage: "ChatGPT for Teachers"
    },
    eduPlanName: {
        id: "useWorkspaces.eduPlanName",
        defaultMessage: "Edu"
    },
    businessPlanName: {
        id: "useWorkspaces.businessPlanName",
        defaultMessage: "Business"
    },
    freeWorkspacePlanName: {
        id: "useWorkspaces.freeWorkspacePlanName",
        defaultMessage: "Business Free"
    },
    adminRoleName: {
        id: "useWorkspaces.adminRoleName",
        defaultMessage: "Admin"
    },
    ownerRoleName: {
        id: "useWorkspaces.ownerRoleName",
        defaultMessage: "Owner"
    },
    standardRoleName: {
        id: "useWorkspacews.standardRoleName",
        defaultMessage: "Member"
    }
});
export {
    S as a, y as b, d as c, V as d, B as e, j as f, G as g, h, _ as i, H as j, F as k, K as l, L as m, v as u
};
//# sourceMappingURL=k2oaaf8ac9lafsub.js.map